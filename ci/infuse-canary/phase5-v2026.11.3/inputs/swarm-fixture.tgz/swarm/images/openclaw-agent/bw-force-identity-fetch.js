const Module = require("module");

const originalLoad = Module._load;
let patchedNodeFetch;

function patchNodeFetch(nodeFetch) {
  if (patchedNodeFetch) {
    return patchedNodeFetch;
  }

  const realFetch = nodeFetch.default || nodeFetch;
  const HeadersCtor = nodeFetch.Headers;

  function forceIdentityEncoding(input, init) {
    if (
      input &&
      typeof input === "object" &&
      input.headers &&
      typeof input.headers.set === "function"
    ) {
      input.headers.set("accept-encoding", "identity");
      input.headers.set("Accept-Encoding", "identity");
      return realFetch(input, init);
    }

    const nextInit = { ...(init || {}) };
    const headers = HeadersCtor
      ? new HeadersCtor(nextInit.headers || {})
      : { ...(nextInit.headers || {}) };

    if (headers && typeof headers.set === "function") {
      headers.set("accept-encoding", "identity");
      headers.set("Accept-Encoding", "identity");
    } else {
      headers["accept-encoding"] = "identity";
      headers["Accept-Encoding"] = "identity";
    }

    nextInit.headers = headers;
    return realFetch(input, nextInit);
  }

  Object.assign(forceIdentityEncoding, nodeFetch);
  forceIdentityEncoding.default = forceIdentityEncoding;
  patchedNodeFetch = forceIdentityEncoding;
  return patchedNodeFetch;
}

Module._load = function loadWithIdentityEncoding(request, parent, isMain) {
  const loaded = originalLoad.apply(this, arguments);
  if (request === "node-fetch") {
    return patchNodeFetch(loaded);
  }
  return loaded;
};
