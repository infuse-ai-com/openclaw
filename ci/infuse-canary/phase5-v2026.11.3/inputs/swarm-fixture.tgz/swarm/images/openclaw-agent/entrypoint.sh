#!/usr/bin/env bash
set -euo pipefail

startup_delay_seconds="${OPENCLAW_STARTUP_DELAY_SECONDS:-0}"
if [[ "$startup_delay_seconds" =~ ^[0-9]+$ && "$startup_delay_seconds" -gt 0 ]]; then
  echo "Delaying OpenClaw agent startup for ${startup_delay_seconds}s."
  sleep "$startup_delay_seconds"
elif [[ ! "$startup_delay_seconds" =~ ^[0-9]+$ ]]; then
  echo "ERROR: OPENCLAW_STARTUP_DELAY_SECONDS must be a non-negative integer" >&2
  exit 1
fi

workspace="${OPENCLAW_WORKSPACE:-/workspace}"
mkdir -p "$workspace"

playwright_cache_helper="${OPENCLAW_PLAYWRIGHT_CACHE_HELPER:-/usr/local/bin/openclaw-agent-ensure-playwright-cache}"
if [[ ! -x "$playwright_cache_helper" ]]; then
  echo "ERROR: Playwright cache setup helper is unavailable: $playwright_cache_helper" >&2
  exit 1
fi
"$playwright_cache_helper"

export OPENCLAW_BW_SERVER="${OPENCLAW_BW_SERVER:-https://vault.infuse-ai-tech.party}"
export OPENCLAW_BW_DATA="${OPENCLAW_BW_DATA:-$HOME/.config/Bitwarden CLI}"
export BITWARDENCLI_APPDATA_DIR="${BITWARDENCLI_APPDATA_DIR:-$OPENCLAW_BW_DATA}"
mkdir -p "$OPENCLAW_BW_DATA"
chmod 700 "$OPENCLAW_BW_DATA"

persist_secret_file() {
  local target="$1"
  local value="$2"
  umask 077
  printf '%s' "$value" >"$target"
  chmod 600 "$target"
}

if [[ -n "${BW_SESSION:-}" ]]; then
  persist_secret_file "$OPENCLAW_BW_DATA/session" "$BW_SESSION"
elif [[ -r "$OPENCLAW_BW_DATA/session" ]]; then
  BW_SESSION="$(<"$OPENCLAW_BW_DATA/session")"
  export BW_SESSION
fi
if [[ -n "${BW_DATA_JSON:-}" ]]; then
  persist_secret_file "$OPENCLAW_BW_DATA/data.json" "$BW_DATA_JSON"
fi

bw_profile_migration_helper="${OPENCLAW_BW_PROFILE_MIGRATION_HELPER:-/usr/local/bin/openclaw-agent-migrate-bitwarden-profile}"
if [[ ! -x "$bw_profile_migration_helper" ]]; then
  echo "ERROR: Bitwarden CLI profile migration helper is unavailable: $bw_profile_migration_helper" >&2
  exit 1
fi
"$bw_profile_migration_helper" --data-dir "$OPENCLAW_BW_DATA"

bw_status() {
  bw status 2>/dev/null \
    | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status", "unknown"))' \
    2>/dev/null || printf 'unknown'
}

bw_config_server() {
  local config_error
  config_error="$(mktemp)"
  if bw config server "$OPENCLAW_BW_SERVER" >/dev/null 2>"$config_error"; then
    rm -f "$config_error"
    return 0
  fi
  if grep -q "Logout required before server config update" "$config_error"; then
    rm -f "$config_error"
    return 0
  fi
  rm -f "$config_error"
  return 1
}

prewarm_vaultwarden() {
  local required="${OPENCLAW_BW_PREWARM_REQUIRED:-false}"
  local status

  if ! command -v bw >/dev/null 2>&1; then
    if [[ "$required" == "true" ]]; then
      echo "ERROR: Vaultwarden prewarm required but bw is not installed" >&2
      exit 1
    fi
    return 0
  fi

  if ! bw_config_server; then
    if [[ "$required" == "true" ]]; then
      echo "ERROR: failed to configure Vaultwarden CLI server" >&2
      exit 1
    fi
    echo "WARNING: failed to configure Vaultwarden CLI server; continuing" >&2
    return 0
  fi

  status="$(bw_status)"
  if [[ "$status" == "unauthenticated" && -n "${BW_CLIENTID:-}" && -n "${BW_CLIENTSECRET:-}" ]]; then
    if bw login --apikey >/dev/null 2>&1; then
      status="$(bw_status)"
    elif [[ "$required" == "true" ]]; then
      echo "ERROR: Vaultwarden API-key login failed" >&2
      exit 1
    else
      echo "WARNING: Vaultwarden API-key login failed; continuing" >&2
      return 0
    fi
  fi

  if [[ "$status" == "locked" ]]; then
    if [[ -n "${BW_PASSWORD:-}" ]]; then
      if BW_SESSION="$(bw unlock --passwordenv BW_PASSWORD --raw 2>/dev/null)"; then
        export BW_SESSION
        persist_secret_file "$OPENCLAW_BW_DATA/session" "$BW_SESSION"
        status="unlocked"
      elif [[ "$required" == "true" ]]; then
        echo "ERROR: Vaultwarden unlock failed" >&2
        exit 1
      else
        echo "WARNING: Vaultwarden unlock failed; continuing" >&2
        return 0
      fi
    elif [[ -n "${BW_MASTER_PASSWORD:-}" ]]; then
      if BW_SESSION="$(bw unlock --passwordenv BW_MASTER_PASSWORD --raw 2>/dev/null)"; then
        export BW_SESSION
        persist_secret_file "$OPENCLAW_BW_DATA/session" "$BW_SESSION"
        status="unlocked"
      elif [[ "$required" == "true" ]]; then
        echo "ERROR: Vaultwarden unlock failed" >&2
        exit 1
      else
        echo "WARNING: Vaultwarden unlock failed; continuing" >&2
        return 0
      fi
    elif [[ "$required" == "true" ]]; then
      echo "ERROR: Vaultwarden locked; runtime owner must prewarm/unlock agent vault" >&2
      exit 1
    fi
  fi

  if [[ "$status" == "unlocked" || -n "${BW_SESSION:-}" ]]; then
    if ! bw sync >/dev/null 2>&1; then
      if [[ "$required" == "true" ]]; then
        echo "ERROR: Vaultwarden sync failed" >&2
        exit 1
      fi
      echo "WARNING: Vaultwarden sync failed; continuing" >&2
    fi
  elif [[ "$required" == "true" ]]; then
    echo "ERROR: Vaultwarden is not ready: $status" >&2
    exit 1
  fi
}

if [[ "${OPENCLAW_BW_PREWARM:-true}" == "true" ]]; then
  prewarm_vaultwarden
fi

if command -v git >/dev/null 2>&1; then
  agent_id="${AGENT_ID:-openclaw-agent}"
  agent_name="${AGENT_NAME:-$agent_id}"
  if [[ "${OPENCLAW_GIT_CONFIGURE_AGENT_IDENTITY:-true}" == "true" ]]; then
    git_author_name="${AGENT_GIT_NAME:-$agent_name}"
    if [[ -n "${AGENT_GIT_EMAIL:-}" ]]; then
      git_author_email="$AGENT_GIT_EMAIL"
    else
      git_email_local_part="$(
        printf '%s' "$git_author_name" \
          | tr '[:upper:]' '[:lower:]' \
          | sed -E 's/[^a-z0-9]+/./g; s/^\.//; s/\.$//'
      )"
      git_author_email="${git_email_local_part:-$agent_id}@${AGENT_GIT_EMAIL_DOMAIN:-infuse-ai.com}"
    fi
    git config --global user.name "$git_author_name"
    git config --global user.email "$git_author_email"
  fi
  git config --global --add safe.directory "$workspace" >/dev/null 2>&1 || true

  # Retire only the known legacy provider; preserve unrelated Git settings.
  git config --global --unset-all credential.https://dev.azure.com.helper || true
  git config --global --unset-all credential.https://dev.azure.com.useHttpPath || true
  rm -f "$HOME/.git-credential-dev-azure.sh"
  case ",${AGENT_SKILLS:-}," in
    *,gitlab,*)
      gitlab_bootstrap="${OPENCLAW_GITLAB_BOOTSTRAP_HELPER:-/usr/local/bin/openclaw-git-credential-bootstrap}"
      [[ -x "$gitlab_bootstrap" ]] || { echo "ERROR: GitLab bootstrap helper missing" >&2; exit 1; }
      # Empty helper resets inherited global helpers for this host only.
      git config --global --replace-all credential.https://gitlab.infuse-ai-tech.party.helper ""
      git config --global --add credential.https://gitlab.infuse-ai-tech.party.helper "$gitlab_bootstrap"
      git config --global credential.https://gitlab.infuse-ai-tech.party.useHttpPath true
      ;;
  esac
fi

if command -v gog >/dev/null 2>&1; then
  gog_config_dir="${GOG_CONFIG_DIR:-$HOME/.config/gogcli}"
  mkdir -p "$gog_config_dir"
  chmod 700 "$gog_config_dir"

  if [[ -n "${GOG_OAUTH_CLIENT_JSON:-}" ]]; then
    umask 077
    printf '%s' "$GOG_OAUTH_CLIENT_JSON" >"$gog_config_dir/credentials.json"
    gog auth keyring file >/dev/null 2>&1 || true
  fi

  if [[ -n "${GOG_REFRESH_TOKEN_JSON:-}" ]]; then
    umask 077
    token_import_path="$gog_config_dir/token-import.json"
    printf '%s' "$GOG_REFRESH_TOKEN_JSON" >"$token_import_path"
    if ! gog auth tokens import "$token_import_path" >/dev/null 2>&1; then
      if [[ "${GOG_AUTH_REQUIRED:-false}" == "true" ]]; then
        echo "ERROR: failed to import gog refresh token" >&2
        exit 1
      fi
      echo "WARNING: failed to import gog refresh token; continuing without Gmail auth" >&2
    fi
    rm -f "$token_import_path"
  elif [[ "${GOG_AUTH_REQUIRED:-false}" == "true" ]]; then
    echo "ERROR: GOG_AUTH_REQUIRED=true but GOG_REFRESH_TOKEN_JSON is not set" >&2
    exit 1
  fi
fi

auto_sync_skills="${OPENCLAW_AUTO_SYNC_SKILLS:-false}"
if [[ "$auto_sync_skills" == "true" ]]; then
  if /usr/local/bin/openclaw-agent-sync-skills-startup; then
    :
  elif [[ "${OPENCLAW_SKILL_SYNC_REQUIRED:-false}" == "true" ]]; then
    exit 1
  else
    echo "WARNING: startup skill sync failed; continuing with existing runtime skills" >&2
  fi
fi

case ",${AGENT_SKILLS:-}," in
  *,gitlab,*)
    if [[ -z "${AGENT_ID:-}" || -z "${AGENT_SKILLS_ROOT:-}" ]]; then
      echo "ERROR: GitLab skill requires AGENT_ID and AGENT_SKILLS_ROOT" >&2
      exit 1
    fi
    gitlab_credential_helper="$AGENT_SKILLS_ROOT/scripts/git-credential-gitlab-vault.sh"
    if [[ ! -x "$gitlab_credential_helper" ]]; then
      echo "ERROR: GitLab credential helper is unavailable: $gitlab_credential_helper" >&2
      exit 1
    fi
    # Bootstrap remains the native Git helper: exact vault item and API identity
    # are checked on every request. The reviewed source wrapper owns glab calls.
    ;;
esac

if [[ "${OPENCLAW_SHARED_MEMORY_SYNC:-false}" == "true" ]]; then
  if /usr/local/bin/openclaw-agent-sync-shared-memory-startup; then
    :
  elif [[ "${OPENCLAW_SHARED_MEMORY_REQUIRED:-false}" == "true" ]]; then
    exit 1
  else
    echo "WARNING: shared memory sync failed; continuing without refreshed shared memory" >&2
  fi
fi

persona_source_path="${OPENCLAW_PERSONA_SOURCE_PATH:-${OPENCLAW_WORKSPACE:-/workspace}/openclaw-agents-persona}"
persona_agent_rel="${OPENCLAW_PERSONA_AGENT_REL:-agents/${AGENT_ID:-}}"
persona_template_rel="${OPENCLAW_PERSONA_TEMPLATE_REL:-templates/agent-persona}"
persona_template_dir="${AGENT_PERSONA_TEMPLATE_DIR:-$persona_source_path/$persona_template_rel}"
persona_agent_dir=""

if [[ "${OPENCLAW_PERSONA_SYNC:-false}" == "true" ]]; then
  if /usr/local/bin/openclaw-agent-sync-persona-startup; then
    if [[ -n "${AGENT_ID:-}" && -d "$persona_source_path/$persona_agent_rel" ]]; then
      persona_agent_dir="$persona_source_path/$persona_agent_rel"
    fi
    if [[ -d "$persona_source_path/$persona_template_rel" ]]; then
      persona_template_dir="$persona_source_path/$persona_template_rel"
    fi
  elif [[ "${OPENCLAW_PERSONA_REQUIRED:-false}" == "true" ]]; then
    exit 1
  else
    echo "WARNING: persona sync failed; continuing only if an existing external persona source is available" >&2
  fi
fi

cat >"$workspace/.openclaw-runtime-info" <<EOF
started_at=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
hostname=$(hostname)
workspace=$workspace
persona_source_path=$persona_source_path
persona_agent_dir=$persona_agent_dir
persona_template_dir=$persona_template_dir
shared_memory_path=${OPENCLAW_SHARED_MEMORY_PATH:-}
EOF

auto_install_persona="${OPENCLAW_AUTO_INSTALL_PERSONA:-true}"
if [[ "$auto_install_persona" == "true" && -n "${AGENT_ID:-}" ]]; then
  if [[ -x /usr/local/bin/openclaw-agent-install-persona ]]; then
    AGENT_SKILL_BUNDLE_DIR="${AGENT_SKILL_BUNDLE_DIR:-/opt/openclaw-agent-skill-config/config/agent-skill-bundles}" \
    AGENT_PERSONA_SOURCE_DIR="$persona_agent_dir" \
    AGENT_PERSONA_TEMPLATE_DIR="$persona_template_dir" \
      /usr/local/bin/openclaw-agent-install-persona
  else
    echo "WARNING: persona installer not found; continuing without persona refresh" >&2
  fi
fi

if [[ "${1:-}" == "openclaw" ]]; then
  exec "$@"
fi

if [[ "${OPENCLAW_BOOT_SCRIPT:-}" != "" ]]; then
  if [[ ! -x "$OPENCLAW_BOOT_SCRIPT" ]]; then
    echo "ERROR: OPENCLAW_BOOT_SCRIPT is not executable: $OPENCLAW_BOOT_SCRIPT" >&2
    exit 1
  fi
  exec "$OPENCLAW_BOOT_SCRIPT"
fi

if [[ "${OPENCLAW_BOOT_COMMAND:-}" != "" ]]; then
  exec bash -lc "$OPENCLAW_BOOT_COMMAND"
fi

exec "$@"
