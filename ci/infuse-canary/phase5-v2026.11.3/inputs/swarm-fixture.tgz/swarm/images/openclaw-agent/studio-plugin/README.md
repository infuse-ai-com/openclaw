# Studio OpenClaw integration

Current Studio uses **native V2 outbound mode**: the standalone backend owns
mission authority, and each enrolled Gateway plugin journals messages and runs
its existing agents. See the [native contract](../../docs/architecture/native-missions.md),
[setup](../../docs/STANDALONE_WORKSPACE.md#enroll-outbound-gateways) and
[roadmap](../../docs/ROADMAP.md) for lifecycle, configuration and release status.

| Mode | Scope |
| --- | --- |
| `outbound`, `nativeEnabled: true` | Current V2; native Mattermost accounts, existing tools, task assignments and coordinator closeout. |
| `outbound`, native disabled | Legacy V1 bridge, optional finite capability papers and dedicated-bot conversations. |
| `authority` / `bridge` | Legacy V1 OpenClaw Control UI topology and isolated proofs. |

Native V2 approval authorizes coordination; there is no separate human Start
command. Same-scope revision retains the assignment/session/thread. Emon closes
after verification, settled runs and any explicit human gate. Legacy V1 papers
retain their own approval/start, correction and acceptance rules.

No Studio data backups are required or authorized until MVP; use the
[database policy](../../database/README.md#data-policy-until-mvp) for upgrades.

## Native Mattermost missions (V2, disabled by default)

The native transport is selected with `mode: "outbound"` and
`nativeEnabled: true`. It requires the pinned fork's supported
`api.conversationRoutes.protect/inspect` API. An older host fails startup; it must
not substitute an unprotected inbound hook. Existing V1 transport and historical
mission records are retained when native mode is disabled.

`nativeRoutes` enrolls explicit `projectId`, `installationId`, `accountId`,
`agentId`, `nativeBotUserId`, `channelId`, and `role` values. The coordinator needs
routes in specialist channels as well as its coordination channel. Studio's
server configuration must independently attest the same account, actual channel
membership and native user identity. Registering a route grants no tools or
credentials. The native path does not apply the earlier three-tool/source-only
session policy; ordinary enrolled agent tools and skills remain in effect.

Native posts are limited to **4,000 UTF-16 units including headers and delivery
markers**. Replies and Studio comments allow **3,000 units of user text**; emoji
may count as two. Longer messages must be split explicitly or stored as task
evidence. No content is silently truncated. Exact approval papers are split into
surrogate-safe parts of at most 3,500 units plus headers/markers, and every part
must have its own attested native receipt before the approval control is sent.
Committed handoffs link to the immutable assignment record and digest; agents
read its exact JSON fragments through `studio_mission_context` before acting.

The plugin uses supported public SDK resolvers and the current host config to
require effective Mattermost `textChunkLimit >= 4000`,
`streaming.chunkMode: "length"`, and `markdown.tables: "off"` for each managed
account. These are compatible with the pinned connector defaults. It checks
again before sends and rejects incompatible settings or sanitizer changes; it
never bypasses the native connector or relaxes exact-post attestation.

Startup installs required-owner protection before reporting it to Studio.
`inbound_claim` copies exact native source identity into the local SQLite worker
journal before returning `accepted`. Studio outages retain local custody. The
hook never invokes ordinary model dispatch. Model tools are scoped to the exact
observed action/run/session through current host tool-call hooks, and cannot
provide their own assignment or actor identity.

All machine calls use `/api/bridge/v2` with `{version: 2, kind, ...}` and expect
`{version: 2, kind, value}`. Gateway enrollment, authority headers and scoped TLS
trust remain identical to V1. The transport reports route protection, drains
managed-message intake, polls idempotent provisioning effects and action claims,
binds idle sessions, requests admission, and reports actual host run receipts.
Provisioning sends neutral roots, handoffs and exact human decision instructions
through Emon's configured native account. Specialist execution waits for Studio's
protected thread binding. Replies use the originating thread and the replying
agent's account through the supported Gateway `send` method.
Each provisioning POST requires a fresh Studio grant with a five-second lifetime;
the complete request round trip counts against that lifetime. An ambiguous grant
is retained as uncertain and does not authorize another attempt.

Prepared controls are literal posts: `!studio prepare approve` requests the exact
decision, and `!studio approve <decision-id>` consumes that decision. The same
syntax supports hold, resume, cancel and optional accept. A slash-command prefix
is intentionally avoided because [Mattermost executes slash commands without
posting the source message](https://docs.mattermost.com/integrations-guide/slash-commands)
unless a separate integration is registered.
Before the control is published, Emon delivers every field of the exact reviewed
paper, split into numbered native posts when needed. The control depends on
attested delivery receipts for every paper part. A pending or uncertain paper
delivery cannot expose an actionable approval control.

Journal schema 2 derives indexed native pending queues from each retained record's
ID and phase. Active action inspection runs before pending inbound/reply/provision
effects, independently of completed history. A failed action does not prevent
other actions in that page from receiving cancellation or settlement checks; the
original error is surfaced before admitting new work. Enrollment loss still
triggers the immediate global abort path. Upgrade from version 1 preserves every body,
revision, realm and receipt; terminal effects leave the pending index but remain
available for exact recovery. Keep a schema 2-compatible plugin after upgrade;
older journal readers intentionally refuse the newer version. This is local
transport scheduling, not additional mission authority.

The native journal lives at
`<stateDir>/studio-bridge/<journalNamespace-or-native>/native.sqlite`, with an
exclusive writer and an authority/Gateway/enrollment fence. Persist it with the
Gateway state. A message and dispatch share Studio's logical action ID. Native
post sends and `chat.send` are journaled before the effect. Missing receipts
remain visibly uncertain and are never resent just because an in-memory host
idempotency cache expired. Lost runtime send receipts first query current
`chat.history` by session key and verify the returned physical session. The pinned
host rejects a standalone `sessionId` selector, while a message-anchored query
does not return input receipts. Recovery requires either one consumed input
receipt plus actual `agent.wait` run evidence, or an `agent.wait` terminal receipt
binding the exact action/run ID to that physical session. Ordinary Codex turns
may have no pending-input receipt; they remain uncertain until a matching
terminal receipt exists. Replaced sessions and contradictory receipts cannot
clear uncertainty. This recovery only reads receipts and never starts a turn. Native
provisioning effects reconcile through Studio's attested unique effect marker and
post receipt. Native replies preserve the agent's text separately and append an
immutable `Studio reply: <reply-id>` marker for delivery. Their uncertain sends
use `reconcile-reply`, which attests the exact native author, channel, originating
thread and complete marked text. Missing, ambiguous or unrelated records remain
uncertain and never authorize a resend.

The running-action poll checks Studio's current stop request. Hold, cancellation
or revoked enrollment triggers an exact `sessions.abort` using the journal's
agent/session/run. Abort acknowledgement is stored separately; only a terminal
`agent.wait` receipt settles the action. A failed abort remains uncertain.
`studio.identity` reports native `active` only after every configured route has
been protected and acknowledged by Studio; its legacy response is unchanged.
Native context history is paged with `history.collection` and the returned
`pages[collection].nextBefore` cursor. Evidence history is metadata: retrieve
artifact content and its verification receipt through `studio_mission_evidence`.
Partial paper, task and history values carry a `recordRef`; pass it as `record`
and follow `nextOffset` to reconstruct the exact JSON and check its digest.
The model-facing context uses a conservative 12,000-character weighted budget,
below the pinned host's smallest 16,000-character tool limit. Enlarging the HTTP
transport bound does not bypass model-tool output limits.

Run `node --test tests/missions/native-plugin.test.mjs` from the repository root
after building the shared packages. These tests exercise the real durable journal
with injected Studio/Gateway transports. `native-plugin-http.test.mjs` additionally
opens a disposable loopback HTTP listener to verify the V2 path and enrollment
headers. `native-plugin-authority.test.mjs` connects the real plugin journals to
the real Studio authority and PostgreSQL writer, using fake Mattermost/Gateway
transports for a two-role mission, clarification, revision and autonomous closeout.
These are not evidence of a disposable Mattermost/Gateway server proof or
production activation. Live enablement remains
gated by the native routing proof, authority checks, current memberships and the
end-to-end project pilot described in plan 010. Rollback stops new native execution
while retaining host route protection and all receipts.

Lifecycle delivery is an explicit, separately activated capability. Set
`nativeMissions.lifecycleNotifications: true` in Studio only after deploying the
matching plugin on every enrolled account. Version-1 lifecycle polls publish
specialist delivery/blocker notices and Emon review/revision/settled-closeout
notices from the transactional outbox. Revision posts reference their existing
continuation and cannot create duplicate turns; comments and clarification keep
their existing native reply path. Migration 011 introduced a writer compatibility
fence for action-to-delivery dependencies; the current writer is schema 12. Disable delivery/execution on the
compatible writer for rollback; retain route ownership and journals. See
[the lifecycle contract and rollout](../../docs/plans/archive/010-native-mattermost-missions/lifecycle-notifications.md).

The opt-in real-server harness is
`integrations/openclaw-studio/scripts/native-smoke.mjs`. Build the plugin and the
isolated pinned OpenClaw fork first, then run it with `STUDIO_OPENCLAW_ROOT` and
`STUDIO_NATIVE_MATTERMOST_FIXTURE`. The latter must name a private (0600) JSON file
for a disposable loopback Mattermost server, containing `origin`, `readerToken`,
`human: {userId, token}`, and `roles` with `role`, `agentId`, `accountId`,
`nativeBotUserId`, `nativeUsername`, `token` and `channelId`. Supply one coordinator
and developer, optionally a design agent. The human and Emon must already belong
to all fixture channels; specialists belong to their role channel. The script
creates and cleans its own Studio/Gateway processes, uses a synthetic OIDC and
model service, and wraps HTTP Mattermost in a locally trusted TLS proxy. It leaves
private proof or failure records under its printed temporary directory. It never
uses production routes or real model credentials. A successful run verifies
actual native connector ingress, native-account handoffs and replies, ordinary
workspace tool access, explicit approval, clarification, revision, task evidence,
autonomous closeout and matching physical session/run receipts. Disposable
Mattermost itself remains owned by the caller. A fixture controller may set
`STUDIO_NATIVE_DISPOSABLE_NETWORK=1` to admit only the fixed `mattermost` and
`proxy` aliases on its owned private network; this does not admit arbitrary
remote origins or proxy settings.
`STUDIO_NATIVE_OUTPUT` may select one new private output directory owned by that
controller; otherwise the harness retains its historical temporary directory.

For the 2026.10.2, 2026.10.3, 2026.11.1 or 2026.11.3 custom canary qualification, additionally set
`STUDIO_OPENCLAW_CANDIDATE_MANIFEST` to its recorded candidate manifest. The
manifest must have `schema: 1`, one of those exact `hostVersion` values and `hostCommit` equal
to the complete 40-character candidate source SHA. The harness checks both the
installed package version and build commit before starting any fixture process.
Without that explicit selection, the legacy fixture's 2026.9.7 / `0fcc9360` pin remains
required. This fixture option does not change deployment configuration or enable
execution on existing Gateways. The harness selects the matching bundled
Mattermost entry and compatible agent configuration for the selected host, and records the
selected host version and source in its private proof. The optional
`STUDIO_NATIVE_NPM_PROXY=http://172.16.6.2:3128` applies only to npm packing and
plugin installation within the isolated qualification environment; no other
proxy value is accepted. Requests and owned network cleanup are bounded.
See [harness delivery and verification](../../docs/evidence/2026-10-15-native-canary-harness.md).

The 2026-10-05 disposable proof passed against host commit
`4caaaa378d818b8d91aeb462d4964ff472cf2d57`: three native Gateways completed a
developer/design mission with one clarification and one revision, three evidence
revisions, ten settled runtime turns and autonomous closeout. Both tasks were
verified. Each runtime turn exercised the existing workspace `read` tool; the
developer retained its original task thread and physical session. All owned
Studio/Gateway processes were stopped after the proof. This records a disposable
server proof. The later production acceptance is linked from the roadmap;
new enrollments still require the project rollout gates.
The final rerun also reconstructed the complete paper from its actual Mattermost
posts, matched it to the stored revision, and verified that every paper receipt
preceded the approval control. The real-authority integration separately covers
multipart delivery and refuses control admission while a part remains pending.

## Proactive native task messages

Emon receives enrolled coordination messages without a mention. Specialist
threads require the actual recipient’s mention. A coordinator can use V2
`studio_mission_command` `message-task` with `commandId`, `taskId`,
`expectedTaskVersion`, `expectedAssignmentId`, `expectedSessionGeneration` and
`text`. Studio chooses the existing protected task thread and native specialist
handle; the model cannot supply a channel or session. The plugin posts through
Emon, and the committed continuation waits for the exact delivery receipt.

This preserves the assignment/session and approved paper. Existing `reply`
continues to answer in the originating thread. Use `revise` for delivered work.
Queued and uncertain instructions appear in Studio; retry only the exact command
identity and never duplicate an uncertain send. Deploy the schema-12 backend
before this plugin, whose provisioning poll advertises `taskMessageVersion: 1`.
See [the contract and rollout](../../docs/architecture/task-messages.md).

## Legacy V1 modes and compatibility

The Gateway-local `authority` mode, its launcher and real-host Control UI smokes
were retired in C4. Their implementation and evidence are available at Git commit
`a103226c7a6ee39a1aa020484c3ccf7c38921b52`. Use `workspace:preview` for a synthetic
PostgreSQL standalone preview and the standalone guide for enrolled Gateways.

Current proof commands include `test:missions`, `test:bridge:host`,
`test:native:runtime`, `test:workspace` and the bounded whiteboard host checks.
Real-host tests require their documented disposable host/provider fixtures; do
not point them at personal or production profiles. The descriptions below retain
the V1 data/finite-capability contracts still readable in standalone PostgreSQL;
they do not re-enable a Gateway-local writer.

## Stored text artifacts

An assigned specialist can deliver `artifact: { mediaType, content, summary }`
instead of the existing `evidence` metadata. Exactly one is allowed. Types are
`text/plain` and `text/markdown`; exact UTF-8 content is limited to 8192 bytes and
summary to 512 bytes. Malformed Unicode and C0 controls other than tab, LF and
CR are rejected. No newline normalization occurs. The signed bridge envelope
also retains its independent 24 KB bound.

Studio derives the hash, revision (`1` initially, `2` after correction) and `artifact:studio:<missionId>:<sha256>`
reference. Callers cannot supply that reserved namespace through metadata-only
delivery. Content, producer assignment, mission transition, receipt and coordinator
continuation commit together. Each delivery revision is immutable within the single-task mission, including when two revisions have identical bytes. A retry uses the identical command and returns its original
receipt; it cannot overwrite the artifact.

`studio.evidence.read({missionId,evidenceRevision,evidenceHash})` and
`studio_mission_evidence({evidenceRevision,evidenceHash})` return `status: "available"` plus the
content/provenance, or `status: "metadata-only"` for external references. A missing
managed artifact or failed hash/provenance check is an error. Reads, verification
and acceptance recheck stored integrity. Agent reads require a current assigned
session; terminal missions remain readable to configured human members. Omitting the revision reads the current result for compatibility; an explicit revision selects current or retained historical evidence. Responses always identify their revision.

The viewer shows escaped text, including Markdown source; embedded HTML and
links do not execute or fetch resources. It clears inspected content on detected
identity, mission, version and connection changes. Inspection is read-only;
coordinator verification, byte integrity and human acceptance stay separate.
This is a bounded generated mission attachment, not a filesystem/URL reader or
an edit to a canonical repository.

## One correction round

After inspecting a verified managed revision 1, an approver can request one
correction within the approved paper. The UI provides literal feedback entry,
a separate final review, and explicit submission. The command is:

```js
{
  type: 'request-correction', commandId, missionId, expectedVersion,
  evidenceRevision: '1', evidenceHash, reason
}
```

Feedback is limited to 2000 characters. Studio records its wording, approver,
time and original evidence together with a new specialist assignment and receipt.
The original specialist session is revoked and its known run gets an abort intent.
A fresh generation-2 session uses the same approved specialist target. A held
mission retains the queued assignment until resume. Correction does not change
the approved objective, criteria, team or permissions.

The replacement specialist reads `correction.reason` and `correction.evidence`
from its scoped context, retrieves the original bytes with the scoped evidence
tool, and delivers a managed revision 2. Metadata-only replacement is rejected.
Delivery queues a new turn in the existing coordinator session. Verification and
acceptance must explicitly name revision `2` and its exact hash, even when the
replacement bytes equal the original. The previous verification cannot authorize
acceptance of the replacement.

The viewer preserves both artifacts, their producer assignments and feedback.
Selecting an older revision clears inspection and acknowledgment; history cannot
unlock acceptance of the current result. Command recovery preserves the exact
feedback envelope across reload. A definite conflict preserves unsent wording
but requires current-content inspection and a new final review. It cannot
silently retarget feedback to another revision.

This bounded round does not reopen accepted/cancelled missions, permit repeated
corrections, or change mission scope. Those require subsequent lifecycle work.

## Package and module boundaries

| Location | Responsibility |
| --- | --- |
| `packages/contracts/src/missions.ts` | Strict commands and browser-safe projections |
| `packages/server/src/modules/missions/` | Lifecycle, roles, assignment fencing, dispatcher |
| `packages/server/src/persistence/missions/` | PostgreSQL worker and transaction admission |
| `database/postgresql/` | Canonical PostgreSQL baseline and catalog |
| `packages/server/src/integrations/openclaw/` | Public Gateway v4 transport |
| `integrations/openclaw-studio/src/` | Plugin service, authenticated RPCs, tools, bridge |
| `apps/web/src/features/studio/` | Native mission UI and validated live projections |

`npm run build:plugin` bundles transport tools, Gateway journal workers and
native UI JavaScript/CSS into `dist`. Central PostgreSQL runs in the standalone
server and is not packaged as a Gateway-local authority. Fonts and artwork are embedded;
their licenses/provenance accompany the archive. Assets are scoped to Studio's
mount and checked against the host's size limits. OpenClaw's public SDK remains supplied by the host; the package
declares the pinned Gateway client as a runtime dependency. `npm pack` can produce
an installable archive. Packaging alone does not install or activate a Gateway. Production release
status is recorded in the roadmap; these V1 fixtures remain isolated.

## Outbound mode and retired local authority

An **outbound** instance requires `studioUrl`, `authorityId`, `gatewayId`,
`enrollmentGeneration`, `bridgeTokenEnv`, enrolled `agents`, and authenticated
`localConnection`. The Studio connection is HTTPS; local Gateway RPC is loopback.
It creates only `studio-bridge/journal.sqlite` under the service state directory.
The versioned HTTP protocol authenticates each Gateway independently. No native
mission authority is opened. The [standalone setup guide](../../docs/STANDALONE_WORKSPACE.md#enroll-outbound-gateways)
describes current native enrollment. For V1 finite capabilities, use the
[legacy capability contract](../../docs/plans/archive/009-studio-openclaw-interaction/scoped-capabilities.md). The following
`authority` mode is retired and fails before opening a database. Current humans
use the standalone Studio UI. Local Gateway journals remain available.

A **bridge** instance requires `gatewayId`, `authorityConnection` and
`bridgeKeyEnv`. It creates no mission database. Tools forward a signed envelope
containing the host-provided Gateway/agent/session identity. The authority maps
each remote Gateway to its configured key environment variable in `bridgeKeys`.
The key must have at least 32 characters and remain outside model context.

Connections support `url`, `tokenEnv`, `passwordEnv`, `headersEnv`, and optional
`tlsFingerprint`. Only explicitly named environment variables are read. Identity-
bearing WSS connections are exercised in the host proof; other authentication
modes need their own deployment checks. Proxy headers require WSS. Secrets and
destinations cannot be supplied by a mission command.

One standalone PostgreSQL authority serves enrolled outbound Gateways. The
former SQLite local-authority launcher, Control UI RPC handlers and host smokes
are reproduced only at Git commit `a103226c7a6ee39a1aa020484c3ccf7c38921b52`.

## Historical V1 operations

The local `studio.bootstrap/list/get/evidence.read/command/bridge` RPCs now
return a retirement error. The descriptions below record the former protocol;
current native/outbound tools continue through standalone Studio.

| Surface | Authorization / purpose |
| --- | --- |
| `studio.identity` | Gateway-authenticated caller's actual profile ID and plugin mode |
| `studio.bootstrap` | Configured member; caller role, authority, safe registered targets and dispatch availability |
| `studio.list` | Configured member; bounded mission summaries in descending creation-time/ID order |
| `studio.get` | Configured Studio member; reads a mission and its dispatches |
| `studio.evidence.read` | Configured member; reads current or historical evidence by mission, revision and hash, rechecking stored artifact integrity |
| `studio.command` | Configured member creates; configured approver approves, starts, holds, resumes, cancels and accepts |
| `studio.bridge` | Authenticated Gateway connection plus configured remote signature; agent operations only |
| `studio_mission_context` | Exact host-provided assigned session; reads current context |
| `studio_mission_command` | Assigned coordinator delegates/verifies; assigned specialist delivers |
| `studio_mission_evidence` | Exact current assigned session; reads the current evidence hash without accepting mission IDs or paths |

Human commands contain `type`, `commandId`, `missionId`, `expectedVersion` and
the action's payload. Agent tools omit `missionId`: scope is resolved from the
persisted assignment, never from model arguments. The prototype grants members
visibility across its missions; project-level access control is not implemented.

`studio.list` accepts an optional `limit` (1–50, default 20) and opaque-position
`cursor` containing the last returned `createdAt` and `id`. `studio.bootstrap`
accepts an empty object. Neither exposes Gateway URLs, headers, environment names
or credentials. Browser response parsers validate known fields before rendering;
the authority remains responsible for authorization.

Gateway `operator.write` alone cannot approve or accept a mission. Human identity
comes from `authenticatedUserProfile.profileId`, not an argument, display name or
request header read by the plugin. Live invocation authority is checked before
queueing and again at transaction admission. The latter synchronous guard and
worker grant are the acceptance point; accepted work can finish after transport
disconnect. Revocation before that point rolls back all writes.

## Dispatch and recovery

Mission mutations, immutable command receipts and dispatch intent commit in the
same central transaction. Delivery also commits one coordinator continuation,
keyed by the accepted delivery command and original assignment. Reusing a command ID with another actor or payload is
rejected. Duplicate accepted commands return the original receipt, subject to
current assignment authority. SQL work runs in a worker thread.

Dispatch creates an idle session, records its exact identity, previews the tool
policy, marks a durable send intent, and sends the first prompt with a stable
idempotency key. The actual returned `runId` is stored. `toolBindings` is omitted:
the pinned host reserves that field for paired browser copilots. Studio uses its
own persisted runtime tuple instead.

A continuation has its own dispatch ID and actual run receipt, and references the
original coordinator assignment. It reuses that assignment's exact Gateway,
agent, session key and session ID; no new session or assignment generation is
created. `chat.history` supplies the current session identity and transcript leaf.
The send pins both, uses `queueMode: "followup"`, and remains separate from an
already active turn. Normal transcript appends are permitted; session replacement
or an incompatible branch change rejects the guarded send. OpenClaw's in-place
reset keeps its session ID and remains the same Studio assignment; use Studio
cancel to revoke that assignment's authority.

Hold leaves unsent continuations ready for resume. If verification already happened
before send admission, the redundant continuation becomes `superseded`. Cancel
revokes all dispatches and aborts each known run, including a late continuation
receipt. Dispatch admission is the transaction that marks `sending`; a hold after
that point does not retract accepted work. A crash after that point leaves the
effect uncertain. An accepted runtime receipt proves admission, not completed
verification; Studio task state is the completion evidence.

The tool preview is a readiness check, not a permission boundary. Provision the
agent's final execution policy and validate the tools offered to an actual model
turn; the host proof inspects that request. No arbitrary execution tools are
needed for this synthetic artifact proof. Adding real specialist capabilities
requires extending the approved capability policy and its negative tests.

That paragraph describes the legacy three-tool proof. Capability papers instead
persist a finite session allowlist before preview/admission, and the source tool
enforces the role's exact paths and content digests. Do not replace persistent
agents' global tools to fit the legacy fixture. The local Gateway principal needs
`operator.admin` for the isolated `sessions.patch` capability operation and
exact-run `sessions.abort` across reconnects. The latter requires a run ID and a
matching agent-prefixed session key; session-wide aborts are not elevated. The
host still checks the target run belongs to that agent/session. The plugin does
not expose that credential or RPC to the model.

The fixture uses `tools.toolSearch: false` to inspect direct schemas. Each fixture
agent uses `profile: "minimal"`, adds the three Studio tools (`studio_mission_context`,
`studio_mission_command`, `studio_mission_evidence`) with `alsoAllow`, and
denies `session_status`, `gateway` and `presence`. OpenClaw normally wraps eligible
tools behind `tool_search`, `tool_describe` and `tool_call`; those wrapper names
alone do not indicate additional underlying permissions.

An interrupted create/send becomes `uncertain` after restart. It is never blindly
resent or inferred successful from unrelated session metadata. Reconciliation of
uncertain effects, general task reassignment, repeated corrections, multi-task missions, budgets and external
artifact retrieval are follow-up work. Studio checks stored text artifacts, but
does not fetch or independently hash externally hosted artifacts.

Stopping the service stops admission and closes its local store or journal.
The shared [database contract](../../database/README.md) defines schema 12,
identity guards and the no-backups-until-MVP policy. Earlier per-schema backup
recipes are superseded. V1 records retain their original paper digests,
evidence, receipts and acceptance history under forward migrations.

## Floor management tool

`studio_floor_manage` adapts the shared Studio floor/repository management service.
It requires outbound mode, a current host `before_tool_call` observation for this
exact tool/call, bound agent/session/run identity and explicit Studio management
admission. It supports listing floors/members/candidates, revisioned saves,
reversible retire/restore commands (floor ID, expected revision and command ID),
repository connect/update and actor-owned receipt recovery. It grants no new
mission role, enrollment, source access or review authority. Reconcile a lost
response by the same command ID before retrying. Local hook/adapter tests do not
qualify a live Gateway host. See [the contract](../../docs/plans/active/022-floor-knowledge/k0-contract.md).


## Automatic floor routes

With `floorRuntimeDiscovery: true`, the native plugin discovers additional
channels from its existing authenticated authority using `floor-routes`.
Every discovered identity must match a configured native agent/account/bot/role
and installation. The plugin verifies delivery policy, installs required-owner
protection and reports its receipt before accepting that route. Withdrawal never
removes protection or permits ordinary chat. No new tool grants are introduced.
`STUDIO_NATIVE_AUTOMATIC_FLOOR=1` runs the disposable native smoke lifecycle on
an automatically connected second floor, including real private channels and
actual host route protection; it uses the same isolated fixture prerequisites.


## Whiteboard agent qualification (W5.0)

The W5.0 qualification did not register production tools. W5.1–W5.3 register native read/edit/render tools only when explicitly configured; see the next section.
`src/whiteboard-tools.mjs` owns the exact-call/image-result foundation; its
separate disposable plugin proves the native transport without a mission or
personal/production profile. Current results and proof limits live in the
[W5.0 qualification record](../../docs/plans/active/020-collaborative-whiteboard/w5-qualification.md).

With Docker running and the exact recorded local image already provisioned:

```sh
npm run test:whiteboard:agent:host
npm run test:whiteboard:agent:renderer
```

The harness pins image ID
`sha256:bb706f1789176be7488517f99dc2d8f752d27c41683123065dc9e7fe0216bfd8`
(OpenClaw 2026.10.3/source `877030b3a66bec373d235129919a5a7a964ca07f`). It fails
if missing instead of pulling or using the Mac installation. The native probe
uses loopback synthetic TLS/provider/session state. The renderer probe uses the
[pinned qualification seccomp profile](../../tests/fixtures/whiteboard-renderer-seccomp.md)
with Chromium's sandbox enabled. Both run non-root, read-only, without external
networking, mounted credentials or channels; bounded containers are removed and
only synthetic result logs remain in the printed local output directory.

Actual provider image input is verified. A synthetic provider does not establish
real-model recognition, production board admission, full Registry rendering,
production companion lifecycle. Managed provenance/cancellation now has real
Studio owner/journal fixtures (with synthetic Gateway transport), documented in
the qualification record. Qualify the remaining gates before
advertising their capabilities or enabling live access.


For the actual Infuse Codex runtime, `npm run test:whiteboard:agent:vision:preflight`
checks the same pinned host with Codex CLI 0.160.0 and `openai/gpt-5.6-sol`; no
credential or external model call occurs. The separate
`npm run test:whiteboard:agent:vision` accepts only an operator-approved access-only
credential object on stdin (`accessToken`, `accountId`, `expiresAt`); never paste
values into command arguments or docs. The harness rejects refresh tokens, expired
or oversized input and uses a fresh token-only profile in container tmpfs. It
requires provider networking but mounts no production profile and starts no
channels. The renderer stays offline. A valid preflight is not a visual recognition
result. The fixture migrates only its own temporary token profile and uses
sandboxed browser text for the visual clue. See the qualification record for the
completed access-token-only real-model proof and its remaining scope limits.


## Whiteboard native reading (W5.1)

The supported W5.1 adapter uses the existing enrolled Gateway bridge; no new
credential, mission assignment or floor-manager permission is needed. Rollout
requires reviewed backend **and** plugin configuration. This implementation does
not enable a live floor or change the human-only general MCP contract.

For a selected floor, the standalone configuration uses:

```json
{"whiteboardAgents":{"defaultAccess":"disabled","projects":[{"projectId":"studio","access":"read"}]}}
```

The matching outbound plugin requires `"whiteboardEnabled": true`. It is false
by default. The backend applies the intersection of startup/live policy, current
enrollment and active settled floor connections. Removing membership, pausing a
floor or disabling policy denies later reads; held/cancelled managed sessions
cannot become independent reads. Roll back by disabling the flag/policy; no
schema downgrade or stored-data migration is involved.

- `studio_whiteboard_context`: section outline, paged item IDs/geometry, stable
  links, supported capabilities and explicitly shared human views.
- `studio_whiteboard_search`: literal saved title/body/label search across the
  project, including unopened sections, with bounded excerpts and stable links.
- `studio_whiteboard_read`: exact saved bodies and metadata at the chosen board
  revision. Follow continuation cursors unchanged to reconstruct UTF-16 text or
  stroke point fragments. Whole-body hashes use UTF-8. HTML/image references and
  crops are metadata by default; explicit `html_source` returns exact verified
  UTF-8 source fragments. The render tool returns actual pixels separately.

Inputs never contain an actor or runtime grant. The host's exact current
agent/session/run/tool-call identity supplies those checks. Tool descriptions
mark all board content as untrusted data. Errors return fixed codes/recovery,
not raw server diagnostics. A stale continuation requires fresh context/search.

Humans choose a recipient using **Share view** beside board participants. Sharing
includes section, visible bounds and selected item IDs, never draft text; multiple
people stay distinct. Stop, disconnect, reload, project switch, permission loss
or expiry removes it. Reads never move a human camera.

Run the complete disposable workflows:

```sh
npm run test:whiteboard:agents:ui
npm run test:whiteboard:agents:host
```

The browser proof uses two synthetic signed-in people and the actual production
plugin/HTTP/writer. The pinned-host proof installs the production registration and
read tools on OpenClaw 2026.10.3, with a synthetic idle legacy poller, synthetic
model and local Studio database inside the isolated container. It proves ordinary
native context/search/read plus two explicit human shares, not model judgment or
live Infuse rollout. [Full evidence](../../docs/plans/active/020-collaborative-whiteboard/w5-1-progress.md).


## Whiteboard native editing and vision (W5.2–W5.3)

These phases are implemented on `codex/whiteboard-w5`; see the current
[qualification and limits](../../docs/plans/active/020-collaborative-whiteboard/w5-3-progress.md).
They are not live-enabled by their implementation. The original W5.1 heading and
proof above describe its read-only delivery checkpoint.

The same backend policy now accepts `edit`; live policy can narrow but cannot
widen startup access. Context advertises permitted tools. `studio_whiteboard_apply`
uses typed spatial, saved-body semantic and anchored-comment commands. Preserve
IDs, item revisions, body epoch/revision/hash and exact UTF-16 ranges. Locks,
topology and current native/managed custody remain enforced by existing owners.

The plugin journals the exact command hash before HTTP. After uncertainty use
`studio_whiteboard_receipt` with the original commandId; a missing payloadHash
is resolved only from that actor/project's retained journal. An explicit original
hash also works. The result is outcome metadata only. Repeating the exact apply
returns its immutable original receipt; a changed payload under that ID fails.
`studio_whiteboard_changes` returns bounded attributed receipts; follow its
unchanged cursor. On `RESYNC_REQUIRED`, reread context/saved content and begin a
new changes query with `afterRevision` equal to that fresh context revision. No raw Yjs/drafts appear.

`studio_whiteboard_render` is advertised only with a configured internal
`whiteboardAgents.rendererUrl`. Deployment must follow the separate
[renderer contract](../../apps/whiteboard-renderer/README.md). Modes are overview,
bounded region, exact HTML tile and cropped image; `fullImage` explicitly requests
the full original. Metadata pins revision/source/coverage/node bounds. HTML runs
at its saved viewport and may contain hidden or scrollable content; use the exact
source facet for semantic inspection. All returned content remains untrusted.

Local visual verification, after building the optional renderer image:

```sh
node scripts/studio-whiteboard-visual-smoke.mjs
node scripts/studio-whiteboard-renderer-abuse.mjs
node scripts/studio-whiteboard-renderer-http-smoke.mjs
```

`whiteboard-qualify.mjs --vision-captures [overview|region|html|image]` consumes
those synthetic captures and approved access-only credentials from stdin. Omitting
the mode tests all four. Never pass credentials in arguments/environment or use
production host profiles. The model sees pixels and metadata, not the expected
visual code. Targeted reruns preserve earlier mode evidence and report failures.
Companion conversation lifecycle, production rollout and per-agent Vaultwarden
credentials remain later W5.4 slices; this does not expand the human-only generic MCP interface.


## Whiteboard presence and board-only updates (W5.4 slice 1)

The existing plugin now registers `studio_whiteboard_presence` and
`studio_whiteboard_post_update` when whiteboard tools are enabled. Studio still
owns access and storage. Presence accepts section, selected IDs, bounds and an
activity; native hooks supply identity. It expires after 30 seconds without
another explicit call. Read-only board access permits presence, but posting
an update requires current edit access. No task or mission is fabricated.

`post_update` accepts a fresh command ID, literal text (2,000 UTF-16 units),
current block IDs in its section and the agent's own applied edit command IDs
in `receiptIds`. Invalid links, another actor's receipts and oversized results
fail before commit. The plugin journals before sending, exact retries preserve
original provenance, and `receipt` recovers outcome metadata after revocation.
Mentions are plain text: posting never sends Mattermost/chat messages, wakes an
agent or acknowledges a mission inbox. `changes` includes updates in the same
revision stream; follow its opaque cursor unchanged.

Humans can open a compact **Agent updates** surface, follow an observed agent
location explicitly and open linked content. Navigating manually stops following;
editing or another panel collapses the surface. Slice 2 adds the ordinary
Start/Stop conversation described below. See
[W5.4 progress](../../docs/plans/active/020-collaborative-whiteboard/w5-4-progress.md).

## Whiteboard companion conversations (W5.4, local qualification)

The compact board chat creates or resumes one **Studio-owned ordinary session**
per project, Gateway and agent. It does not attach private host chats, create a
mission, or change required-owner Mattermost routes. The sole Studio writer owns
messages, current membership, native run custody and shared agent reservations.
Availability describes enrolled plugin contact and Studio execution reservations;
it does not claim to inspect unrelated external conversations.

Enable only after release qualification: Studio's startup and live
`whiteboardAgents.companionEnabled` and the outbound plugin's `companionEnabled`
must both be true, alongside the existing `whiteboardEnabled`/board access policy.
The plugin advertises its actual configured agents on `whiteboard-companion` V2
polls. The server expires these observations after 15 seconds. No new credential
or access grant is implied by these flags.

Each explicit Start has a durable human-scoped command ID and a unique native run
ID. An ambiguous browser response retains that command ID. Creation, admission
and send effects are fenced in `studio-bridge/<namespace>/companion.sqlite`,
separate from the mission journal but never a second Studio writer. Lost sends
use supported `chat.history` and `agent.wait` receipt recovery, never resend or a
new idempotency key. A lost admission response fails the unsent turn explicitly.

Stop immediately prevents more board tool effects. Each public RPC uses a fresh
connection, so the original send connection cannot authorize a later abort. The
transport requests admin scope only for an exact agent/session/run selector;
read/write-only reconnects are deliberately rejected by the host. No global
client scope, runtime configuration or model tool permission is widened. An admitted run remains
occupied until actual terminal `agent.wait` evidence. The pinned 2026.10.3 host's
RPC abort terminal has no model receipt: a previously acknowledged send or
consumed-input recovery must already bind that run, and current history must
confirm the same physical session. A contradictory receipt never settles.
An abort acknowledgment by itself is insufficient. Final visible reply text comes
from the host's exact run projection; arbitrary transcript content is not imported.

Disable server admission first and keep the compatible plugin and schema-32
writer until admitted runs settle. Revoked enrollments, replaced sessions and
unconfirmed sends remain visibly occupied; do not reset their IDs or journals.
There is no production backup or schema downgrade procedure.

Verify with `node --test tests/whiteboard/companion-*.test.mjs`,
`node scripts/studio-whiteboard-chat-smoke.mjs`, and
`node integrations/openclaw-studio/scripts/whiteboard-qualify.mjs --companion`.
The last command uses the existing pinned disposable network-isolated host, two
synthetic signed-in humans and a deterministic model. It proves Start, eight real
whiteboard tool calls, lost-send recovery, final reply and Stop; it does not prove
real-model conversational quality or production activation. The fixture now uses
token authentication and fresh connections, with explicit read/write denial,
wrong-session denial, unscoped denial and a ten-second Stop settlement bound.

`node integrations/openclaw-studio/scripts/whiteboard-qualify.mjs --codex-companion`
adds a separately authorized real-model check: ordinary XML-driven title/body
editing, linked update, active Stop and the next turn. It accepts the same strict
access-only credential object on stdin as the vision check, but starts no browser
or renderer. Only this explicit mode allows outbound model networking on the
owned disposable PostgreSQL/host network namespace; synthetic modes remain
network-isolated. It never copies a production profile or refresh token and
removes its owned containers. Use an unexpired token and an expiry no later than
its signed expiry.


## Agent XML context (local implementation, 2026-10-22)

Native `context`, `read`, `search` and `changes` accept optional `format: "xml"`.
Omitting it retains the existing JSON result. The wire response has
`result.kind: "xml"` and `value: { format: "studio-whiteboard-xml/1", operation,
projectId, revision, document }`; the plugin gives the document directly to the
model as text and retains the envelope in tool details. Companion prompts prefer
XML. A backend/plugin pair supporting this extension is required; old servers
reject the explicit format rather than silently supplying a different format.

The XML keeps literal text, source references, body epoch/revision/hash and
UTF-16 ranges. Illegal XML 1.0 code units are labeled `encoding="base64-utf16le"`;
decode exactly before editing. HTML is escaped source; visual content stays
`not-inspected`. Follow `next-cursor` with the same request and format. Changes
cursors are checkpoints for polling, not proof that more events exist.

Relationships cover only returned rectangles in the same section, with a
four-canvas-unit alignment tolerance, 400-unit maximum gap, four neighbors per
item and 32 relations. Omission counts are explicit. Alignment/overlap do not
imply dependency, grouping, pixel visibility or persistent constraints. Read
narrower item sets for relationships omitted from a large page. Use existing
typed commands for edits; XML is never writeback or permission.

Studio's separately authenticated MCP `context/read/search` HTTP endpoints accept
the same option, preserving read-only admission. The external Infuse MCP provider
owns its client tool schema and must opt into forwarding `format` and presenting
this result; this repository does not publish that separate provider.
See [design and progress](../../docs/plans/active/020-collaborative-whiteboard/agent-xml-context.md).


Run `npm run test:whiteboard:agents:xml` for the actual pinned OpenClaw
2026.10.3 companion workflow with a deterministic provider receiving XML. It
includes Start, two explicit human shares, search with spatial relationships,
body read, edit, receipt, changes, presence/update, lost-send recovery and Stop.
This uses the existing network-isolated disposable container, no model credential
and no renderer. `npm run test:postgresql` also runs the XML native edit workflow
against disposable PostgreSQL. Neither proof measures real-model judgment.


### Model-facing edit help

`studio_whiteboard_apply` documents each strict family separately with tested
examples. Item titles/geometry use spatial operations; saved bodies use complete
read fences and UTF-16 text edits; anchored comments use their own guards. A local
schema rejection returns the unchanged typed error plus static correction text
before journaling or sending. It never echoes validator messages, unknown input
keys or values. This does not reconcile an earlier uncertain command: use its
original receipt. Server denials and conflicts retain their existing semantics.
