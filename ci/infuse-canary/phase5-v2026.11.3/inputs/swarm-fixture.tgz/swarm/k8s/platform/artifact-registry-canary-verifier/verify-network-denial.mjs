const base = (process.env.ARTIFACT_REGISTRY_URL || "").replace(/\/$/, "");
if (!base) throw new Error("ARTIFACT_REGISTRY_URL is required");

const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 5000);
try {
  const response = await fetch(`${base}/live`, { signal: controller.signal });
  throw new Error(`network policy unexpectedly allowed HTTP ${response.status}`);
} catch (error) {
  if (error instanceof Error && error.message.startsWith("network policy unexpectedly")) throw error;
  console.log(JSON.stringify({
    schema: "infuse.artifact-registry-canary-proof/v1",
    phase: "network-denial",
    outcome: "succeeded",
  }));
} finally {
  clearTimeout(timeout);
}
