#!/usr/bin/env python3

import argparse
import hashlib
import os
from pathlib import Path
import stat
import tempfile


PROFILE = "openclaw-chromium-v1.json"
SHA256 = "6d83d97537b59fb26bdd82ce685d911e3ed1419aa8d23852ac829311c74d43f8"
MODE = 0o644


def install(kubelet_root: Path, check: bool) -> Path:
    payload = Path(__file__).with_name(PROFILE).read_bytes()
    if hashlib.sha256(payload).hexdigest() != SHA256:
        raise ValueError("Repository profile checksum mismatch")

    root = kubelet_root.resolve(strict=True)
    if not root.is_dir():
        raise ValueError(f"Kubelet root is not a directory: {root}")

    directory = root
    for part in ("seccomp", "infuse"):
        directory = directory / part
        if not check:
            directory.mkdir(mode=0o755, exist_ok=True)
        if directory.is_symlink() or not directory.is_dir():
            raise ValueError(f"Expected a real profile directory: {directory}")

    target = directory / PROFILE
    if not check and not target.exists() and not target.is_symlink():
        with tempfile.NamedTemporaryFile(dir=directory, prefix=".chromium-") as temporary:
            temporary.write(payload)
            temporary.flush()
            os.fchmod(temporary.fileno(), MODE)
            os.fsync(temporary.fileno())
            try:
                os.link(temporary.name, target)
            except FileExistsError:
                # A concurrent installer may have already published this version.
                pass

    metadata = target.lstat()
    if not stat.S_ISREG(metadata.st_mode):
        raise ValueError(f"Expected a regular profile file: {target}")
    if target.read_bytes() != payload:
        raise ValueError(f"Installed profile checksum mismatch: {target}")
    if stat.S_IMODE(metadata.st_mode) != MODE:
        raise ValueError(f"Expected profile mode 0644: {target}")
    return target


def main() -> None:
    parser = argparse.ArgumentParser(description="Install or check the pinned Chromium seccomp profile.")
    parser.add_argument("--kubelet-root", type=Path, required=True)
    parser.add_argument("--check", action="store_true", help="Verify the installed profile without writing.")
    args = parser.parse_args()
    try:
        target = install(args.kubelet_root, args.check)
    except (OSError, ValueError) as error:
        parser.exit(1, f"{error}\n")
    print(f"Verified {target} ({SHA256})")


if __name__ == "__main__":
    main()
