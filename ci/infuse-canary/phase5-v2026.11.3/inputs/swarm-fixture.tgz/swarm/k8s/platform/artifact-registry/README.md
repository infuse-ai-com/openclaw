# Backoffice Artifact Registry runtime

## Backoffice retirement — October 22, 2026

The owner approved retiring the Backoffice application and its dedicated data.
Remove its `core/backoffice` ingress peer; Studio and all five Kubernetes agent
peers, scanner/storage egress and publisher-only policies remain unchanged.
The Backoffice retirement procedure removes only its reader and lifecycle auth
principals and preserves all ten retained principals. Do not rerun the historical
whole-auth provisioning procedure or reissue Backoffice credentials.

The shared Registry remains active under Studio code/image ownership and Swarm
runtime/policy ownership. Its historical `backoffice-*` names are not deletion
criteria. Preserve its Deployment, Service, PVCs, content, auth, recovery tooling,
scanner and object store. The older build/provisioning notes below are historical;
current source and the P7 owner decision take precedence.


This base owns the dedicated internal Artifact Registry in `core`. The service
was activated through the reviewed T5.1 path and is the selected canonical
authority for the 2026-09-01 clean-start cutover. It remains separately applied
from the automatic InfuseAI overlay so a normal agent image release cannot
replace its pinned server image or PVC.

The source is fail-closed and manually gated. It pins Backoffice build
6400 (`20260902.6`, source `ae1b2254…`) by immutable image digest and records
the same evidence in `config/artifact-registry-runtime.v1.json`.

Canonical rollout invariants:

1. verify the pinned digest still corresponds to the named Backoffice build
   containing `/app/artifact-registry.cjs`;
2. provision `core/backoffice-artifact-registry-auth` through the approved
   secret path with one `auth.json` key;
3. make `auth.json` use schema `infuse.artifact-auth/v1` and SHA-256 token
   digests as keys; never store raw bearer tokens in Git or ConfigMaps;
4. issue one unique `read/write` identity for Kapiteky and each of the five
   persistent agents plus separate Backoffice `read` and `lifecycle` clients;
5. keep every raw token in Vaultwarden and file-mounted Kubernetes Secrets;
6. activate publishers in `registry` mode with no silent feed fallback;
7. keep the retired collector, relay, worker, RBAC, and PVCs absent after the
   proven fresh publish/read/trash/restore/purge cutover.

The owner explicitly approved a clean start: existing feed content is not
imported, and initial backup/restore is not an activation gate. Producer
isolation, exact revisions, lifecycle authorization, and content-free audit
evidence remain mandatory.

Local render and contract verification:

```bash
task verify-artifact-registry-runtime
```

Admission-only server proof uses a prefixed copy in the operator-owned
`oleagut` namespace and does not persist resources:

```bash
KUBE_CONTEXT=infuseai-k8s task verify-artifact-registry-server-dry-run
```

The production runtime base remains absent from `k8s/overlays/infuseai`; the
five Registry-only producer credential patches are included there so mounts
and modes survive normal releases. The historical canary path uses
`../artifact-registry-canary/` and
`../artifact-registry-canary-verifier/`. The producer patches contain only
Secret references; they do not contain credential values and keep every
persistent publisher in `registry` mode.

Credential plan and approved provisioning:

```bash
python3 scripts/provision_artifact_registry_credentials.py plan
python3 scripts/provision_artifact_registry_credentials.py cutover --approved
```

The provisioner creates only missing exact Vaultwarden items, refuses scope
drift or duplicate names, applies raw values to Kubernetes over stdin, and
prints names/status only. `cutover` creates the dedicated Backoffice clients,
updates server authorization, materializes
`core/backoffice-artifact-registry-client`, and removes the temporary canary
client. `finalize` is an idempotent reconciliation of the same canonical state.

Sequential rotation keeps old and replacement digests valid only during one
bounded verification window. The credential helper waits for the live
projected server auth file before activating the client and again before
returning from `finalize`:

```bash
python3 scripts/provision_artifact_registry_credentials.py rotate --approved --principal agent-infra
# verify the exact client, then remove the overlap
python3 scripts/provision_artifact_registry_credentials.py finalize --approved
```

### Studio reader

Studio uses a separate read-only identity and `core/studio-artifact-registry`
Secret (`token` key). Its Vaultwarden item is
`Artifact Registry / Studio reader token` in the existing registry-owner
collection `07-Project-Backoffice`; this does not make Backoffice a mission authority.
The credential is mounted only in Studio's backend, never its browser or agents.

```bash
python3 scripts/provision_artifact_registry_credentials.py plan
python3 scripts/provision_artifact_registry_credentials.py studio --approved --bw-helper /path/to/bw-helper
```

The `studio` action loads or creates only that exact Vaultwarden item, preserves
all existing auth principals, guards the server Secret update with its resource
version, waits for projected auth and materializes only the Studio client Secret.
Existing token/scope drift is rejected rather than silently rotated. Interrupted
activation is safe to repeat. Normal `finalize` preserves the new identity;
`rotate --principal studio-reader` uses the existing overlap/verification flow.

The normal Swarm release currently preserves network policies in its bounded
runtime-only mode. A green normal release therefore does not prove this policy
was applied. For the approved Backoffice retirement, manually run pipeline 56
from reviewed current main with `retireBackofficeNetwork=true` and the Studio
profile set to `preserve`. This isolated stage skips image/runtime deployment,
uses the existing deployment connection/lock, and checks that the app and six
collectors are stopped, both Backoffice queues are disabled, and no Backoffice
build is active. The helper accepts only the exact existing policy with its one
Backoffice peer removed; any other drift stops before mutation. It patches with
UID/resource-version preconditions and verifies readback. No credentials, RBAC,
PVCs, workload templates or other policy are changed. The Registry Deployment/PVC
remain separate from automatic Swarm delivery.
Its Studio peer requires both namespace `core` and workload label
`app.kubernetes.io/name: studio`, limited to TCP 3010. Do not reapply the pinned
registry Deployment/PVC for this reader change. Studio owns its Helm token
mount, optional reader config, authenticated project filtering and live browser
acceptance. The runtime image and skill grants are unchanged.

See `docs/ARTIFACT_REGISTRY_BACKUP_RESTORE.md` for the 90-day cadence,
principal order, rollout requirements, and failure handling.

Backoffice web has network access only. It does not mount the writable registry
PVC. Production Secret/storage/cutover changes require explicit approval. This
runtime uses no Kubernetes API credential and creates no RBAC object.

The reviewed recovery foundation remains available at
`k8s/platform/artifact-registry-recovery/`. The owner waived only the initial
clean-start backup. Ongoing off-node backups use
`scripts/artifact-registry-backup.py`; the reusable Job templates remain
suspended by default.

## Studio image activation (2026-10-16)

The owner approved the shared SeaweedFS tenant and Registry image input. Studio
owns shared Registry and `artifact-image-scanner` delivery. The retained release
overlay excludes PVCs, recovery Jobs and persistent agents. Existing metadata
stays on the same Registry PVC. The image config maps only Studio to dedicated
buckets.

Provision the separate upload token with
`scripts/provision_artifact_registry_credentials.py studio-images --approved` using
the approved Vaultwarden helper. It preserves all existing principals and reader
secrets. Rotate with `--principal studio-image-upload`; finalize preserves the
project/producer restriction. The S3 credential is materialized by the SeaweedFS
pipeline into `core/studio-whiteboard-storage`, never into Studio or a browser.

ClamAV 1.5.4 is pinned by digest, runs as uid 1000, accepts only Registry traffic
and updates signatures through public HTTP(S). Its definitions are regenerable
cache; no new persistent volume is required. The Registry has only DNS, S3 and
scanner egress. See [ClamAV configuration](https://docs.clamav.net/manual/Usage/Configuration.html).

Backups remain deferred to the platform solution. Legacy suspended volume-only
recovery templates retain their historical image and are not qualification or
recovery for S3 images. Do not run them for this activation.
