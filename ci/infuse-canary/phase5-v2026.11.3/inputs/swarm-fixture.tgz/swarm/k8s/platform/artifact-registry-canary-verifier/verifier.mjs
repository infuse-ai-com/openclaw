import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

const base = (process.env.ARTIFACT_REGISTRY_URL || "").replace(/\/$/, "");
const phase = process.env.ARTIFACT_REGISTRY_PHASE || "";
const artifactId = process.env.ARTIFACT_REGISTRY_CANARY_ARTIFACT_ID || "";
const ID = /^[a-z0-9][a-z0-9._-]{0,127}$/;
if (!base || !["publish", "resume"].includes(phase) || !ID.test(artifactId) || artifactId === "replace-before-unsuspend") {
  throw new Error("canary verifier configuration is invalid");
}

const producerIds = [
  "kapiteky",
  "agent-coordinator",
  "agent-designer",
  "agent-developer",
  "agent-infra",
  "agent-intake",
];
const tokenRoot = "/var/run/artifact-registry-tokens";
const tokens = Object.fromEntries(await Promise.all(producerIds.map(async (producer) => {
  const token = (await readFile(`${tokenRoot}/${producer}/token`, "utf8")).trim();
  if (token.length < 32 || token.length > 512 || /\s/.test(token)) throw new Error(`invalid mounted token for ${producer}`);
  return [producer, token];
})));
const readerToken = (await readFile(`${tokenRoot}/canary/reader`, "utf8")).trim();
const lifecycleToken = (await readFile(`${tokenRoot}/canary/lifecycle`, "utf8")).trim();
if ([readerToken, lifecycleToken].some((token) => token.length < 32 || token.length > 512 || /\s/.test(token))) {
  throw new Error("invalid mounted canary client token");
}

const html = "<!doctype html><title>T5.1 canary</title><p>synthetic-disposable</p>\n";
const evidence = `${JSON.stringify({ schema: "infuse.artifact-canary/v1", disposable: true, phase: "t5.1" }, null, 2)}\n`;
const digest = (value) => createHash("sha256").update(value).digest("hex");
const publication = {
  producer: "kapiteky",
  artifactId,
  title: "T5.1 synthetic canary",
  kind: "report",
  summary: "Disposable internal Artifact Registry acceptance evidence.",
  sourceRef: "azure:openclaw-k8s-swarm:t5.1",
  files: [
    { path: "index.html", mediaType: "text/html", contentBase64: Buffer.from(html).toString("base64") },
    { path: "evidence.json", mediaType: "application/json", contentBase64: Buffer.from(evidence).toString("base64") },
  ],
};
const checks = [];

async function request(name, path, { method = "GET", token, body, timeoutMs = 10000 } = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const headers = {};
    if (token) headers.authorization = `Bearer ${token}`;
    if (body !== undefined) headers["content-type"] = "application/json";
    const response = await fetch(`${base}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });
    checks.push({ name, status: response.status, requestId: response.headers.get("x-request-id") });
    return response;
  } finally {
    clearTimeout(timeout);
  }
}

function expectStatus(name, response, expected) {
  if (response.status !== expected) throw new Error(`${name} returned HTTP ${response.status}; expected ${expected}`);
  if (!response.headers.get("x-request-id")) throw new Error(`${name} did not return a request id`);
}

async function expectJson(name, response, expected) {
  expectStatus(name, response, expected);
  return response.json();
}

async function lifecycle(action, revision, token = lifecycleToken) {
  return request(action, `/v1/artifacts/kapiteky/${artifactId}/actions/${action}`, {
    method: "POST",
    token,
    body: { revision },
  });
}

async function verifyStoredRevision(revision) {
  const manifest = await expectJson("read-manifest", await request(
    "read-manifest",
    `/v1/artifacts/kapiteky/${artifactId}/revisions/${revision}`,
    { token: readerToken },
  ), 200);
  if (manifest.revision !== revision || manifest.files.length !== 2) throw new Error("stored manifest identity is incorrect");
  const expected = new Map([
    ["index.html", { bytes: Buffer.byteLength(html), sha256: digest(html), body: html }],
    ["evidence.json", { bytes: Buffer.byteLength(evidence), sha256: digest(evidence), body: evidence }],
  ]);
  for (const file of manifest.files) {
    const wanted = expected.get(file.path);
    if (!wanted || file.bytes !== wanted.bytes || file.sha256 !== wanted.sha256) throw new Error(`manifest mismatch for ${file.path}`);
    const response = await request(`read-content-${file.path}`, `/v1/artifacts/kapiteky/${artifactId}/revisions/${revision}/files/${file.path}`, { token: readerToken });
    expectStatus(`read-content-${file.path}`, response, 200);
    if (Buffer.from(await response.arrayBuffer()).toString("utf8") !== wanted.body) throw new Error(`content mismatch for ${file.path}`);
  }
}

for (const path of ["/live", "/ready"]) {
  expectStatus(path, await request(path, path), 200);
}

if (phase === "publish") {
  expectStatus("anonymous-denied", await request("anonymous-denied", "/v1/artifacts"), 401);
  for (const [index, producer] of producerIds.entries()) {
    expectStatus(`${producer}-read`, await request(`${producer}-read`, "/v1/artifacts", { token: tokens[producer] }), 200);
    const otherProducer = producerIds[(index + 1) % producerIds.length];
    expectStatus(`${producer}-producer-binding`, await request(`${producer}-producer-binding`, "/v1/artifacts", {
      method: "POST",
      token: tokens[producer],
      body: { ...publication, producer: otherProducer, artifactId: `${artifactId}-denied` },
    }), 403);
  }
  expectStatus("reader-write-denied", await request("reader-write-denied", "/v1/artifacts", {
    method: "POST", token: readerToken, body: publication,
  }), 403);
  expectStatus("reader-lifecycle-denied", await lifecycle("trash", "0".repeat(64), readerToken), 403);
  expectStatus("writer-lifecycle-denied", await lifecycle("trash", "0".repeat(64), tokens.kapiteky), 403);
  expectStatus("lifecycle-read-denied", await request("lifecycle-read-denied", "/v1/artifacts", { token: lifecycleToken }), 403);
  expectStatus("lifecycle-write-denied", await request("lifecycle-write-denied", "/v1/artifacts", {
    method: "POST", token: lifecycleToken, body: publication,
  }), 403);

  const created = await expectJson("publish", await request("publish", "/v1/artifacts", {
    method: "POST", token: tokens.kapiteky, body: publication,
  }), 201);
  const revision = created.manifest?.revision;
  if (!/^[a-f0-9]{64}$/.test(revision || "")) throw new Error("publish receipt revision is invalid");
  const retried = await expectJson("idempotent-retry", await request("idempotent-retry", "/v1/artifacts", {
    method: "POST", token: tokens.kapiteky, body: { ...publication, revision },
  }), 200);
  if (retried.idempotent !== true || retried.manifest?.revision !== revision) throw new Error("idempotent retry evidence is invalid");
  await verifyStoredRevision(revision);
  console.log(JSON.stringify({
    schema: "infuse.artifact-registry-canary-proof/v1",
    phase,
    outcome: "succeeded",
    producerCredentials: producerIds.length,
    artifactId,
    revision,
    checks: checks.length,
  }));
} else {
  const history = await expectJson("history-after-restart", await request(
    "history-after-restart",
    `/v1/artifacts/kapiteky/${artifactId}/revisions`,
    { token: readerToken },
  ), 200);
  if (history.revisions?.length !== 1) throw new Error("restart persistence history is incorrect");
  const revision = history.revisions[0].revision;
  await verifyStoredRevision(revision);
  expectStatus("trash", await lifecycle("trash", revision), 200);
  const binned = await expectJson("list-bin", await request("list-bin", "/v1/artifacts?state=bin", { token: readerToken }), 200);
  if (!binned.artifacts?.some((item) => item.producer === "kapiteky" && item.artifactId === artifactId && item.state === "bin")) throw new Error("trash state was not visible");
  expectStatus("restore", await lifecycle("restore", revision), 200);
  const active = await expectJson("list-active", await request("list-active", "/v1/artifacts", { token: readerToken }), 200);
  if (!active.artifacts?.some((item) => item.producer === "kapiteky" && item.artifactId === artifactId && item.state === "active")) throw new Error("restore state was not visible");
  expectStatus("trash-before-purge", await lifecycle("trash", revision), 200);
  expectStatus("purge", await lifecycle("purge", revision), 200);
  const all = await expectJson("list-after-purge", await request("list-after-purge", "/v1/artifacts?state=all", { token: readerToken }), 200);
  if (!all.artifacts?.some((item) => item.producer === "kapiteky" && item.artifactId === artifactId && item.state === "purged")) throw new Error("purged tombstone evidence is missing");
  console.log(JSON.stringify({
    schema: "infuse.artifact-registry-canary-proof/v1",
    phase,
    outcome: "succeeded",
    artifactId,
    revision,
    checks: checks.length,
  }));
}
