# Artifact Registry recovery templates

This base is intentionally absent from every production overlay. It contains
two separate PVCs and suspended, network-isolated backup/restore Job templates.

The backup transfer PVC is not a disaster-recovery copy: the current cluster
uses same-node `microk8s-hostpath`. A successful backup must be verified and
exported off the source node/PVC before it is accepted. No retention controller
or automatic deletion exists.

Never apply these files directly. Follow
`docs/ARTIFACT_REGISTRY_BACKUP_RESTORE.md`, choose one exact reviewed backup
identifier, materialize only the required Job, and keep it suspended until the
source quiescence or empty-target preconditions are proven.

The reviewed operator `scripts/artifact-registry-backup.py` performs that
materialization, verifies the transfer bundle, exports it off-node, and can
restore-prove the off-node copy into isolated temporary PVCs.

Before the first scheduled run, a separately approved elevated apply installs
the deny-all recovery NetworkPolicy and
`operator-networkpolicy-read-rbac.yaml`. The latter grants the normal
`platform-operators/kapiteky-cluster-operator` service account only `get` on
that exact named policy. The backup operator verifies the complete live policy spec
against reviewed source before it quiesces the Registry; it cannot create,
patch, or delete NetworkPolicies.

The RoleBinding retains the legacy Oleagut Kapiteky subject only for the
bounded identity-migration rollback window. Remove it in the cutover-closeout
change after the normal context proves the replacement identity.
