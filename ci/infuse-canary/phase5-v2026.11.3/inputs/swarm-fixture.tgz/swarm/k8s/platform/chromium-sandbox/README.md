# Chromium sandbox for persistent agents

Stewie, Ramiro, and Satwa use `infuse/openclaw-chromium-v1.json` on their agent container. This profile starts with the [containerd 2.2.3 default for Linux AMD64 with all capabilities dropped](https://github.com/containerd/containerd/blob/v2.2.3/contrib/seccomp/seccomp_default.go). It adds `unshare(CLONE_NEWUSER)`, the Chromium user, PID, and network namespace combinations for `clone`, and `chroot` for Chromium's isolated renderer. Chromium keeps its Linux sandbox and the agent container runs as non-root with privilege escalation disabled and all capabilities dropped.

A node must have the profile under its kubelet root at `seccomp/infuse/openclaw-chromium-v1.json` before it can run these workloads. On each new or rebuilt production MicroK8s node, run these commands from the swarm checkout before deploying the agents.

```sh
sudo python3 k8s/platform/chromium-sandbox/install-profile.py \
  --kubelet-root /var/snap/microk8s/common/var/lib/kubelet
python3 k8s/platform/chromium-sandbox/install-profile.py --check \
  --kubelet-root /var/snap/microk8s/common/var/lib/kubelet
```

The installer verifies the repository checksum, publishes a missing file atomically with mode `0644`, and rejects a conflicting file at the versioned path. Recheck the default profile and Chromium launch when the node runtime changes.

To verify the rollout, confirm the agent container's effective profile is `Localhost`, open a company site in the session Browser, and check Chromium's sandbox status in the running agent container.

```sh
profile=$(mktemp -d /tmp/openclaw-chromium-check.XXXXXX)
trap 'rm -rf -- "$profile"' EXIT
chromium --headless --allow-chrome-scheme-url --disable-dev-shm-usage \
  --user-data-dir="$profile" --dump-dom chrome://sandbox 2>/dev/null |
  grep -F 'You are adequately sandboxed.'
```

To roll back one workload, remove the agent container's seccomp override so it inherits the pod's `RuntimeDefault` profile. Leave the node profile installed while any workload still references it.
