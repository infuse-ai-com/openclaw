# Artifact Registry producer mounts

This T5.1-approved patch set gives the five persistent agent deployments
distinct Secret-backed token-file mounts. The automatic InfuseAI overlay owns
the durable inclusion, and every producer remains in `feed` mode.

The named Secrets are provisioned through
`scripts/provision_artifact_registry_credentials.py`. Applying this overlay
before all five exact producer Secrets exist fails closed at pod startup; it
does not fall back to an inline or shared token.

Render only:

```bash
kubectl kustomize k8s/platform/artifact-registry/producers
```

Do not apply the standalone render directly: its agent image tag is the local
`dev` default. Normal releases consume the canonical component at
`k8s/components/artifact-registry-producer-mounts` from
`k8s/overlays/infuseai`, whose renderer replaces the image with the release
tag/digest. A bounded live repair may use each component patch file as a
strategic merge patch, which preserves the existing image and unrelated
Deployment state.

T5.1 authorizes fleet-wide credential mounts while publisher mode remains
`feed`. Later `dual`/`registry` activation is still sequential and requires the
separate parity, rollback, and approval evidence in the canonical Artifact
Registry plan. Kapiteky's durable credential is provisioned now but is not a
Kubernetes Deployment in this patch set.
