# Artifact Registry T5.1 canary runtime

This overlay activates the reviewed internal Artifact Registry runtime in
`core` and adds one temporary, label-bound ingress path for the T5.1 verifier.
It creates no public route and is intentionally absent from
`k8s/overlays/infuseai`.

The base NetworkPolicy continues to admit only Backoffice and the five
persistent agent workloads. The additive canary policy admits only pods in
`agents-swarm` carrying
`infuse.ai/artifact-registry-canary-verifier=true`. Delete that additive policy
after the acceptance proof; keep the base policy.

Apply order:

1. run the credential provisioner with the recorded secret-change approval;
2. server-dry-run the exact overlay;
3. apply non-NetworkPolicy resources with the normal scoped identity;
4. use the approved task-scoped privileged path only for the two exact
   NetworkPolicy objects in the rendered overlay;
5. verify rollout and run `../artifact-registry-canary-verifier`;
6. remove verifier Jobs, scripts ConfigMap, temporary client Secret, and the
   additive verifier NetworkPolicy.

Never delete `core/backoffice-artifact-registry` PVC during rollback or canary
cleanup. Publisher modes remain `feed`; issuing and mounting credentials does
not authorize registry writes from normal agent workflows.
