# Artifact Registry T5.1 verifier

This temporary overlay contains two suspended Jobs:

- `backoffice-artifact-registry-canary-verifier` mounts six durable producer
  tokens plus temporary reader/lifecycle tokens and runs the denial,
  publication, idempotency, exact-byte, restart-persistence, and lifecycle
  proof in two phases;
- `backoffice-artifact-registry-network-denied` has no admitted label or
  credentials and succeeds only when it cannot reach the Registry.

Both Jobs are suspended so a plain apply cannot publish or purge. Before
unsuspending the verifier, replace its artifact ID with a unique bounded value.
Run `publish`, restart the Registry Deployment, recreate the Job as `resume`,
then verify the disposable tombstone. The only permanent purge target is the
exact synthetic identity created by the publish phase.

Delete both Jobs and the generated scripts ConfigMap after proof. Finalize the
credential provisioner to remove the temporary client Secret and reader/
lifecycle principals from the server auth map. Remove the additive verifier
NetworkPolicy while retaining the base Registry NetworkPolicy and PVC.
