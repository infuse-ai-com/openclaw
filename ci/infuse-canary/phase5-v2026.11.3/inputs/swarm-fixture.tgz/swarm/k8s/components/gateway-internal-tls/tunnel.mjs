import { constants, X509Certificate } from 'node:crypto';
import { readFileSync, realpathSync } from 'node:fs';
import { connect } from 'node:net';
import { createServer } from 'node:tls';
import { pathToFileURL } from 'node:url';

export const DASHBOARD_CLIENT_NAME = 'openclaw-dashboard.agents-swarm.svc.cluster.local';
const CLIENT_AUTH = '1.3.6.1.5.5.7.3.2';
const SERVER_AUTH = '1.3.6.1.5.5.7.3.1';
const exactDns = { subject: 'never', wildcards: false };

// Transport only: HTTP and WebSocket bytes come from the authenticated dashboard,
// whose fixed-gateway relay overwrites identity/forwarding headers. No destination
// is selected from a request, URL, environment variable, or client certificate.
export function createGatewayTlsTunnel(credentials) {
  const sockets = new Set();
  const server = createServer({
    ...credentials,
    minVersion: 'TLSv1.3',
    requestCert: true,
    rejectUnauthorized: true,
    handshakeTimeout: 10_000,
    secureOptions: constants.SSL_OP_NO_TICKET,
    ALPNProtocols: ['http/1.1'],
  }, (downstream) => {
    const peer = downstream.getPeerX509Certificate();
    if (!downstream.authorized || !peer || peer.ca ||
        peer.checkHost(DASHBOARD_CLIENT_NAME, exactDns) !== DASHBOARD_CLIENT_NAME ||
        !peer.keyUsage?.includes(CLIENT_AUTH) || peer.keyUsage.includes(SERVER_AUTH)) {
      downstream.destroy();
      return;
    }
    downstream.pause();
    const upstream = connect({ host: '127.0.0.1', port: 18791 });
    sockets.add(upstream);
    const timer = setTimeout(() => upstream.destroy(), 5_000);
    timer.unref();
    upstream.on('connect', () => {
      clearTimeout(timer);
      downstream.pipe(upstream);
      upstream.pipe(downstream);
    });
    upstream.on('error', () => downstream.destroy());
    downstream.on('error', () => upstream.destroy());
    downstream.on('close', () => upstream.destroy());
    upstream.on('close', () => {
      clearTimeout(timer);
      sockets.delete(upstream);
      // pipe() ends the TLS writable after a normal EOF. Let its queued bytes
      // flush; destroying here can truncate a large final HTTP response/frame.
      if (!upstream.readableEnded) downstream.destroy();
    });
  });
  server.maxConnections = 128;
  server.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('error', () => socket.destroy());
    socket.on('close', () => sockets.delete(socket));
  });
  server.on('tlsClientError', (_error, socket) => socket.destroy());
  // Closing a tunnel never invokes an agent lifecycle action. The gateway owns
  // its existing preStop/run drain; browser connections reconnect after rollout.
  server.shutdown = () => {
    server.close();
    for (const socket of sockets) socket.destroy();
  };
  return server;
}

export function loadGatewayTlsCredentials(directory, serverName) {
  if (!/^agent-(developer|designer|coordinator|intake|infra)-dashboard-internal\.agents-swarm\.svc\.cluster\.local$/.test(serverName ?? '')) {
    throw new Error('invalid internal gateway TLS server name');
  }
  const cert = readFileSync(`${directory}/tls.crt`);
  const certificate = new X509Certificate(cert);
  if (certificate.ca || certificate.checkHost(serverName, exactDns) !== serverName ||
      !certificate.keyUsage?.includes(SERVER_AUTH) || certificate.keyUsage.includes(CLIENT_AUTH) ||
      Date.parse(certificate.validFrom) > Date.now() || Date.parse(certificate.validTo) <= Date.now()) {
    throw new Error('invalid internal gateway server certificate');
  }
  return {
    cert,
    key: readFileSync(`${directory}/tls.key`),
    ca: readFileSync(`${directory}/client-ca.crt`),
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try {
    const server = createGatewayTlsTunnel(loadGatewayTlsCredentials(
      '/var/run/openclaw-gateway-tls', process.env.GATEWAY_TLS_SERVER_NAME,
    ));
    server.on('error', () => {
      process.stderr.write('gateway TLS tunnel listener failed\n');
      server.shutdown();
      process.exitCode = 1;
    });
    server.listen(8443, '0.0.0.0');
    process.once('SIGTERM', () => server.shutdown());
    process.once('SIGINT', () => server.shutdown());
  } catch {
    process.stderr.write('gateway TLS tunnel configuration failed\n');
    process.exitCode = 1;
  }
}
