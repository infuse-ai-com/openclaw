# Agent Overlays

Each directory under this folder describes one persistent agent runtime.

The target shape is one Kubernetes Deployment and one workspace PVC per persistent agent.

The active `agent-developer` overlay renders:

- `deploy/agent-developer`
- `pvc/agent-developer-workspace`
- optional secret reference `agent-developer-mattermost`

The active `agent-designer` overlay renders:

- `deploy/agent-designer`
- `pvc/agent-designer-workspace`
- optional secret reference `agent-designer-mattermost`

The active `agent-infra` overlay renders:

- `deploy/agent-infra`
- `pvc/agent-infra-workspace`
- optional secret reference `agent-infra-mattermost`

The active `agent-coordinator` overlay renders:

- `deploy/agent-coordinator`
- `pvc/agent-coordinator-workspace`
- optional secret reference `agent-coordinator-mattermost`

The active `agent-intake` overlay renders:

- `deploy/agent-intake`
- `pvc/agent-intake-workspace`
- optional secret reference `agent-intake-mattermost`
- optional Vaultwarden-backed role mailbox access for `rmr.g@infuse-ai.com`

These overlays are applied through `k8s/overlays/infuseai/`, which is the only
maintained deployment overlay. Add a new agent here only after its access
bundle, Mattermost identity, secret contract, and profile bootstrap are
approved, then include it from the InfuseAI overlay.
