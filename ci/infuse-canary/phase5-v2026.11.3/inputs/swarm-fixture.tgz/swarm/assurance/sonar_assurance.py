#!/usr/bin/env python3
"""Wait for the swarm Sonar analysis and emit one bounded structured verdict."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import time
import urllib.parse
import urllib.request
from pathlib import Path

PROJECT_KEY = "infuse-ai_openclaw-k8s-swarm"
REPORT_TASK = Path(".scannerwork/report-task.txt")
METRICS = (
    "software_quality_security_rating",
    "software_quality_reliability_rating",
    "software_quality_maintainability_rating",
    "new_software_quality_security_rating",
    "new_software_quality_reliability_rating",
    "new_software_quality_maintainability_rating",
    "coverage",
    "new_coverage",
    "duplicated_lines_density",
)


def api(host: str, token: str, path: str) -> dict:
    request = urllib.request.Request(urllib.parse.urljoin(f"{host}/", path))
    request.add_header(
        "Authorization", f"Basic {base64.b64encode(f'{token}:'.encode()).decode()}"
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        value = json.load(response)
    if not isinstance(value, dict):
        raise ValueError("Sonar API returned a non-object")
    return value


def parse_task() -> dict[str, str]:
    values = {}
    for line in REPORT_TASK.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    return values


def wait(host: str, token: str, task_id: str) -> None:
    deadline = time.monotonic() + 600
    while time.monotonic() < deadline:
        task = api(host, token, f"api/ce/task?id={urllib.parse.quote(task_id)}").get("task", {})
        status = task.get("status")
        if status == "SUCCESS":
            return
        if status in {"FAILED", "CANCELED"}:
            raise RuntimeError(f"Sonar analysis {str(status).lower()}")
        time.sleep(3)
    raise TimeoutError("Sonar analysis timed out")


def rating(value: float | None) -> str:
    letters = ["?", "A", "B", "C", "D", "E"]
    return "n/a" if value is None else letters[round(value)]


def main() -> int:
    result_path = Path(os.environ.get("SONAR_ASSURANCE_RESULT", "assurance-result.json"))
    evidence: dict[str, object] = {}
    status = "failed"
    try:
        host = os.environ["SONAR_HOST_URL"].rstrip("/")
        token = os.environ["SONAR_TOKEN"]
        task_id = parse_task()["ceTaskId"]
        wait(host, token, task_id)
        query = urllib.parse.urlencode({"component": PROJECT_KEY, "metricKeys": ",".join(METRICS)})
        measures = {}
        for item in api(host, token, f"api/measures/component?{query}").get("component", {}).get("measures", []):
            raw = item.get("value")
            if raw is None and item.get("period"):
                raw = item["period"].get("value")
            measures[item["metric"]] = float(raw) if raw is not None else None
        required = METRICS[:3]
        if any(measures.get(metric) is None for metric in required):
            raise ValueError("required overall MQR measures unavailable")
        overall = "/".join(rating(measures.get(metric)) for metric in METRICS[:3])
        new = "/".join(rating(measures.get(metric)) for metric in METRICS[3:6])
        failures = [metric for metric in required if (measures.get(metric) or 0) >= 4]
        status = "failed" if failures else "success"
        summary = (
            f"Sonar overall S/R/M {overall}; new S/R/M {new}; "
            f"coverage {measures.get('coverage', 'n/a')}%; new coverage {measures.get('new_coverage', 'n/a')}%; "
            f"duplication {measures.get('duplicated_lines_density', 'n/a')}%"
        )[:500]
        evidence = {"measures": measures, "failed_overall_metrics": failures}
    except Exception as error:
        summary = f"Sonar analysis or policy evidence unavailable: {' '.join(str(error).split())}"[:500]
        evidence = {"error": summary}
    fingerprint = hashlib.sha256(json.dumps(evidence, sort_keys=True).encode()).hexdigest()
    result_path.parent.mkdir(parents=True, exist_ok=True)
    result_path.write_text(
        json.dumps({"schema_version": 1, "status": status, "summary": summary, "fingerprint": fingerprint}, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(summary)
    return 0 if status == "success" else 1


if __name__ == "__main__":
    raise SystemExit(main())
