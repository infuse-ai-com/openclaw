#!/usr/bin/env python3
"""Install one checksum-pinned kubectl binary for the assurance jobs."""

from __future__ import annotations

import hashlib
import platform
import sys
import urllib.request
from pathlib import Path

VERSION = "v1.36.1"
SHA256 = {"x86_64": "629d3f410e09bf49b64ae7079f7f0bda1191efed311f7d37fdbab0ad5b0ec2b7"}


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: install-kubectl.py <tools-directory>")
    machine = platform.machine()
    if platform.system() != "Linux" or machine not in SHA256:
        raise SystemExit(f"unsupported kubectl platform: {platform.system()}/{machine}")
    tools = Path(sys.argv[1])
    tools.mkdir(parents=True, exist_ok=True)
    target = tools / "kubectl"
    with urllib.request.urlopen(
        f"https://dl.k8s.io/release/{VERSION}/bin/linux/amd64/kubectl", timeout=120
    ) as response, target.open("wb") as output:
        while chunk := response.read(1024 * 1024):
            output.write(chunk)
    if hashlib.sha256(target.read_bytes()).hexdigest() != SHA256[machine]:
        raise SystemExit("kubectl checksum mismatch")
    target.chmod(0o755)
    print(f"Installed kubectl {VERSION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
