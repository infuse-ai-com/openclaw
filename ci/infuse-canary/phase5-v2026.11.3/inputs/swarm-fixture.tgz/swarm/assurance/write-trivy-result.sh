#!/bin/sh
set -eu

mode="${1:?usage: write-trivy-result.sh <repository|image> <result> <findings> <scanner-exit> <report...>}"
result="${2:?missing result path}"
findings="${3:?missing findings path}"
scanner_exit="${4:?missing scanner exit code}"
shift 4
test "$#" -gt 0

: > "$findings"
for report in "$@"; do
  test -s "$report"
  trivy convert --format template --template @assurance/trivy-finding-lines.tpl "$report" >> "$findings"
done
sort -u "$findings" -o "$findings"
critical_count="$(awk -F '\t' '$1 == "CRITICAL" { print $1 "\t" $2 }' "$findings" | sort -u | wc -l | tr -d ' ')"
high_count="$(awk -F '\t' '$1 == "HIGH" { print $1 "\t" $2 }' "$findings" | sort -u | wc -l | tr -d ' ')"

case "$mode" in
  repository) label='Repository source'; clean='Repository source: no fixed HIGH/CRITICAL findings' ;;
  image) label='Exact OpenClaw image'; clean='Exact OpenClaw image: no fixed HIGH/CRITICAL findings' ;;
  *) echo "invalid Trivy result mode: $mode" >&2; exit 2 ;;
esac

if [ "$scanner_exit" -eq 0 ] && [ "$critical_count" -eq 0 ] && [ "$high_count" -eq 0 ]; then
  status=success
  summary="$clean"
else
  status=failed
  summary="$label: $critical_count distinct CRITICAL / $high_count distinct HIGH findings"
fi
fingerprint="$(printf '%s' "$summary" | sha256sum | cut -d ' ' -f 1)"
printf '{"fingerprint":"%s","schema_version":1,"status":"%s","summary":"%s"}\n' \
  "$fingerprint" "$status" "$summary" > "$result"
test "$status" = success
