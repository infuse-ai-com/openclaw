#!/usr/bin/env python3
"""Install one checksum-pinned pure-Python coverage wheel without pip."""

from __future__ import annotations

import hashlib
import io
import sys
import urllib.request
import zipfile
from pathlib import Path

VERSION = "7.11.0"
URL = (
    "https://files.pythonhosted.org/packages/5f/04/"
    "642c1d8a448ae5ea1369eac8495740a79eb4e581a9fb0cbdce56bbf56da1/"
    "coverage-7.11.0-py3-none-any.whl"
)
SHA256 = "4b7589765348d78fb4e5fb6ea35d07564e387da2fc5efff62e0222971f155f68"


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: install-coverage.py <target-directory>")
    with urllib.request.urlopen(URL, timeout=120) as response:
        wheel = response.read()
    if hashlib.sha256(wheel).hexdigest() != SHA256:
        raise SystemExit("coverage wheel checksum mismatch")
    target = Path(sys.argv[1])
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(wheel)) as archive:
        archive.extractall(target)
    print(f"Installed coverage {VERSION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
