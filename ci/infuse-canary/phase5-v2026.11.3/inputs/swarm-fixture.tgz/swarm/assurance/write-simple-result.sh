#!/bin/sh
set -eu

label="${1:?usage: write-simple-result.sh <label> <success-summary> <failure-summary> <result> <exit-code>}"
success_summary="${2:?missing success summary}"
failure_summary="${3:?missing failure summary}"
result="${4:?missing result path}"
exit_code="${5:?missing exit code}"

if [ "$exit_code" -eq 0 ]; then
  status=success
  summary="$success_summary"
else
  status=failed
  summary="$failure_summary"
fi
fingerprint="$(printf '%s:%s:%s' "$label" "$status" "$summary" | sha256sum | cut -d ' ' -f 1)"
printf '{"fingerprint":"%s","schema_version":1,"status":"%s","summary":"%s"}\n' \
  "$fingerprint" "$status" "$summary" > "$result"
test "$status" = success
