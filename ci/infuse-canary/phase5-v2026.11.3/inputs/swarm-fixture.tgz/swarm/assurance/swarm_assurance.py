#!/usr/bin/env python3
"""Read-only weekly assurance probes for the OpenClaw Kubernetes swarm."""

from __future__ import annotations

import datetime as dt
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAMESPACE = "agents-swarm"
IDENTITY = "system:serviceaccount:agents-swarm:gitlab-openclaw-swarm-assurance"
AGENTS = (
    "agent-developer",
    "agent-designer",
    "agent-infra",
    "agent-intake",
    "agent-coordinator",
)
DASHBOARDS = tuple(f"{agent}-dashboard" for agent in AGENTS)
PVCS = tuple(f"{agent}-workspace" for agent in AGENTS)
COLLECTORS = {
    "openclaw-agent-memory-sync": ("30 3 * * *", dt.timedelta(hours=36)),
    "openclaw-agent-model-policy-collector": ("0,15,30,45 * * * *", dt.timedelta(minutes=90)),
    "openclaw-agent-skill-proposal-monitor": ("3,18,33,48 * * * *", dt.timedelta(minutes=90)),
    "openclaw-agent-token-usage-collector": ("6,21,36,51 * * * *", dt.timedelta(minutes=90)),
    "openclaw-scheduler-collector": ("9,24,39,54 * * * *", dt.timedelta(minutes=90)),
}
TLS_ANNOTATIONS = {
    "server": "openclaw.infuse-ai.com/internal-tls-server",
    "client": "openclaw.infuse-ai.com/internal-tls-dashboard-client",
}


def internal_transport_agents() -> set[str]:
    spec = importlib.util.spec_from_file_location("internal_transport", ROOT / "scripts/prepare-internal-gateway-transport.py")
    assert spec and spec.loader
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    return set(owner.validate(json.loads((ROOT / "config/internal-gateway-transport.json").read_text())))


def certificate_record(raw: str, role: str, agent: str, now: dt.datetime) -> dict:
    """Validate public operator-attested metadata; this is not a Secret/handshake probe."""
    if not isinstance(raw, str) or len(raw) > 4096:
        raise ValueError("internal TLS public certificate record is missing")
    record = json.loads(raw)
    keys = {"version", "role", "sha256", "notBefore", "notAfter", "dns", "secretName", "namespace", "issuer"}
    if role == "server":
        keys.add("agentId")
    if not isinstance(record, dict) or set(record) != keys or type(record["version"]) is not int or record["version"] != 1:
        raise ValueError("internal TLS certificate record shape differs")
    dns = f"{agent}-dashboard-internal.agents-swarm.svc.cluster.local" if role == "server" else "openclaw-dashboard.agents-swarm.svc.cluster.local"
    secret = f"{agent}-dashboard-internal-tls" if role == "server" else "openclaw-dashboard-gateway-client-tls"
    if record["role"] != role or record["dns"] != dns or record["secretName"] != secret or record["namespace"] != NAMESPACE or (role == "server" and record["agentId"] != agent):
        raise ValueError("internal TLS certificate record identity differs")
    issuer = record["issuer"]
    if not isinstance(issuer, dict) or set(issuer) != {"sha256", "notBefore", "notAfter"}:
        raise ValueError("internal TLS issuer record shape differs")
    for entry, maximum_days, warning_days in ((record, 90, 30), (issuer, 1825, 180)):
        if not isinstance(entry["sha256"], str) or re.fullmatch(r"[a-f0-9]{64}", entry["sha256"]) is None:
            raise ValueError("internal TLS certificate fingerprint differs")
        for key in ("notBefore", "notAfter"):
            if not isinstance(entry[key], str) or re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z", entry[key]) is None:
                raise ValueError("internal TLS certificate timestamp differs")
        start, end = parse_time(entry["notBefore"]), parse_time(entry["notAfter"])
        if start.tzinfo is None or end.tzinfo is None or not start <= now < end or not dt.timedelta(0) < end - start <= dt.timedelta(days=maximum_days):
            raise ValueError("internal TLS certificate lifetime differs")
        if end - now <= dt.timedelta(days=warning_days):
            raise ValueError(f"internal TLS {role} {'leaf' if entry is record else 'CA'} renewal is due")
    if parse_time(record["notAfter"]) > parse_time(issuer["notAfter"]) or record["sha256"] == issuer["sha256"]:
        raise ValueError("internal TLS leaf and issuer records differ")
    return record


def deployment_transport(item: dict, name: str, expected_image: str, enabled: bool, now: dt.datetime) -> dict:
    containers = item.get("spec", {}).get("template", {}).get("spec", {}).get("containers", [])
    names = [container.get("name") for container in containers]
    wanted = {"agent", "gateway-internal-tls"} if enabled else {"agent"}
    if len(names) != len(set(names)) or set(names) != wanted:
        raise ValueError("agent container set differs from the selected transport")
    by_name = {container["name"]: container for container in containers}
    if by_name["agent"].get("image") != expected_image:
        raise ValueError("agent immutable image differs")
    if not enabled:
        return {"transport": "tailscale"}
    sidecar = by_name["gateway-internal-tls"]
    if sidecar.get("image") != expected_image or sidecar.get("command") != ["/usr/local/bin/node", "/opt/gateway-internal-tls/tunnel.mjs"] or sidecar.get("env") != [{"name": "GATEWAY_TLS_SERVER_NAME", "value": f"{name}-dashboard-internal.agents-swarm.svc.cluster.local"}]:
        raise ValueError("internal TLS sidecar image or identity differs")
    annotations = item.get("metadata", {}).get("annotations", {})
    server = certificate_record(annotations.get(TLS_ANNOTATIONS["server"]), "server", name, now)
    client = certificate_record(annotations.get(TLS_ANNOTATIONS["client"]), "client", name, now)
    if server["issuer"]["sha256"] == client["issuer"]["sha256"]:
        raise ValueError("internal TLS server and client issuers must differ")
    return {"transport": "internal-mtls", "server": server, "client": client}


def write_result(directory: Path, status: str, summary: str, evidence: object) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    fingerprint = hashlib.sha256(json.dumps(evidence, sort_keys=True).encode()).hexdigest()
    (directory / "assurance-result.json").write_text(
        json.dumps(
            {
                "fingerprint": fingerprint,
                "schema_version": 1,
                "status": status,
                "summary": summary[:500],
            },
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def kubectl(*args: str) -> dict:
    completed = subprocess.run(
        ["kubectl", *args, "-o", "json"],
        check=True,
        text=True,
        capture_output=True,
    )
    value = json.loads(completed.stdout)
    if not isinstance(value, dict):
        raise ValueError("kubectl returned a non-object")
    return value


def exact_image(policy: str = "approved-openclaw-image.env") -> str:
    values = {}
    for line in (ROOT / "deploy/gitlab" / policy).read_text(encoding="utf-8").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    image = values.get("OPENCLAW_IMAGE", "")
    if not re.fullmatch(r"registry\.infuse-ai-tech\.party/agents-swarm/openclaw-agent@sha256:[0-9a-f]{64}", image):
        raise ValueError("exact OpenClaw image policy is unavailable")
    return image


def assert_identity() -> None:
    actual = kubectl("auth", "whoami").get("status", {}).get("userInfo", {}).get("username")
    if actual != IDENTITY:
        raise ValueError(f"unexpected Kubernetes identity: {actual}")


def runtime(directory: Path, now: dt.datetime | None = None) -> int:
    now = now or dt.datetime.now(dt.timezone.utc)
    evidence: dict[str, object] = {"deployments": {}, "services": {}, "pvcs": {}}
    failures: list[str] = []
    observed_images: set[str] = set()
    try:
        assert_identity()
        internal_agents = internal_transport_agents()
        clients: set[str] = set()
        expected_images = dict.fromkeys(AGENTS, exact_image())
        for name in AGENTS:
            item = kubectl("-n", NAMESPACE, "get", f"deployment/{name}")
            status = item.get("status", {})
            ready = status.get("readyReplicas", 0) == 1 and status.get("replicas", 0) == 1
            # Retain observed images for the downstream risk scan even when
            # transport admission fails. Expected policy is never scan evidence.
            containers = item.get("spec", {}).get("template", {}).get("spec", {}).get("containers", [])
            deployment_images = sorted({
                container["image"] for container in containers
                if isinstance(container, dict) and isinstance(container.get("image"), str)
                and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/@+-]*", container["image"])
            })
            observed_images.update(deployment_images)
            evidence["deployments"][name] = {"ready": ready, "observedImages": deployment_images}
            try:
                transport = deployment_transport(item, name, expected_images[name], name in internal_agents, now)
            except (ValueError, TypeError, KeyError):
                failures.append(f"deployment/{name}: internal TLS/image evidence invalid or renewal due")
            else:
                evidence["deployments"][name].update({"image": expected_images[name], **transport})
                if name in internal_agents:
                    clients.add(json.dumps(transport["client"], sort_keys=True))
            if not ready:
                failures.append(f"deployment/{name}")
        if len(clients) > 1:
            failures.append("internal TLS dashboard client rotation records disagree")
        otel = kubectl("-n", NAMESPACE, "get", "deployment/openclaw-otel-collector")
        otel_status = otel.get("status", {})
        otel_ready = otel_status.get("readyReplicas", 0) == 1 and otel_status.get("replicas", 0) == 1
        evidence["deployments"]["openclaw-otel-collector"] = {"ready": otel_ready}
        if not otel_ready:
            failures.append("deployment/openclaw-otel-collector")
        for name in DASHBOARDS:
            item = kubectl("-n", NAMESPACE, "get", f"service/{name}")
            ports = item.get("spec", {}).get("ports", [])
            valid = (
                item.get("spec", {}).get("type") == "ClusterIP"
                and not item.get("spec", {}).get("loadBalancerClass")
                and len(ports) == 1
                and ports[0].get("port") == 80
                and ports[0].get("targetPort") == 18791
            )
            evidence["services"][name] = {"privateDashboard": valid}
            if not valid:
                failures.append(f"service/{name}")
        collector = kubectl("-n", NAMESPACE, "get", "service/openclaw-otel-collector")
        collector_valid = collector.get("spec", {}).get("type") == "ClusterIP"
        evidence["services"]["openclaw-otel-collector"] = {"clusterInternal": collector_valid}
        if not collector_valid:
            failures.append("service/openclaw-otel-collector")
        for name in PVCS:
            item = kubectl("-n", NAMESPACE, "get", f"persistentvolumeclaim/{name}")
            bound = item.get("status", {}).get("phase") == "Bound"
            evidence["pvcs"][name] = {"bound": bound}
            if not bound:
                failures.append(f"persistentvolumeclaim/{name}")
        status = "failed" if failures else "success"
        summary = (
            f"Fleet runtime drift: {', '.join(failures)}"
            if failures
            else "Five agents, private dashboards, OTEL, and five persistent workspaces match their exact approved images"
        )
    except Exception as error:
        status = "failed"
        summary = f"Fleet runtime evidence unavailable: {' '.join(str(error).split())}"
        evidence["error"] = summary
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "openclaw-image-references.txt").write_text(
        "".join(image + "\n" for image in sorted(observed_images)), encoding="utf-8"
    )
    write_result(directory, status, summary, evidence)
    print(summary)
    return 0 if status == "success" else 1


def parse_time(value: str) -> dt.datetime:
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


def collectors(directory: Path, now: dt.datetime | None = None) -> int:
    now = now or dt.datetime.now(dt.timezone.utc)
    evidence: dict[str, object] = {"collectors": {}}
    failures: list[str] = []
    try:
        assert_identity()
        for name, (schedule, maximum_age) in COLLECTORS.items():
            item = kubectl("-n", NAMESPACE, "get", f"cronjob/{name}")
            observed_schedule = item.get("spec", {}).get("schedule")
            last = item.get("status", {}).get("lastSuccessfulTime")
            fresh = bool(last) and now - parse_time(str(last)) <= maximum_age
            valid = observed_schedule == schedule and not item.get("spec", {}).get("suspend", False) and fresh
            evidence["collectors"][name] = {
                "schedule": observed_schedule,
                "lastSuccessfulTime": last,
                "fresh": fresh,
            }
            if not valid:
                failures.append(name)
        status = "failed" if failures else "success"
        summary = (
            f"Collector schedule/freshness drift: {', '.join(failures)}"
            if failures
            else "All five maintenance collectors are enabled, correctly staggered, and recently successful"
        )
    except Exception as error:
        status = "failed"
        summary = f"Collector freshness evidence unavailable: {' '.join(str(error).split())}"
        evidence["error"] = summary
    write_result(directory, status, summary, evidence)
    print(summary)
    return 0 if status == "success" else 1


def dependency(directory: Path, source: Path) -> int:
    data = json.loads(source.read_text(encoding="utf-8"))
    npm = data.get("npm", {})
    python = data.get("python", {})
    failed = any(
        int(value or 0) != 0
        for value in (
            npm.get("exitCode"),
            npm.get("high"),
            npm.get("critical"),
            python.get("exitCode"),
            python.get("vulnerabilities"),
        )
    )
    status = "failed" if failed else "success"
    summary = (
        f"Runtime dependencies: npm {int(npm.get('critical', 0))} CRITICAL / {int(npm.get('high', 0))} HIGH; "
        f"Python {int(python.get('vulnerabilities', 0))} vulnerabilities"
    )
    write_result(directory, status, summary, data)
    print(summary)
    return 0 if status == "success" else 1


def fetch_json(url: str) -> object:
    request = urllib.request.Request(url, headers={"User-Agent": "openclaw-swarm-assurance/1"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)


def release(directory: Path) -> int:
    dockerfile = (ROOT / "images/openclaw-agent/Dockerfile").read_text(encoding="utf-8")
    otel_manifest = (ROOT / "k8s/overlays/infuseai/otel-collector.yaml").read_text(encoding="utf-8")
    evidence: dict[str, object] = {}
    try:
        node_major = re.search(r"^FROM node:(\d+)-", dockerfile, re.MULTILINE).group(1)
        playwright = re.search(r"^ARG PLAYWRIGHT_VERSION=([^\s]+)", dockerfile, re.MULTILINE).group(1)
        openclaw = re.search(r"^ARG OPENCLAW_VERSION=([^\s]+)", dockerfile, re.MULTILINE).group(1)
        package_url = re.search(r'^ARG OPENCLAW_PACKAGE_URL="([^"]+)"', dockerfile, re.MULTILINE).group(1)
        otel = re.search(r"opentelemetry-collector-contrib:([0-9.]+)@sha256:", otel_manifest).group(1)
        node_releases = fetch_json("https://nodejs.org/dist/index.json")
        latest_node = next(item["version"].lstrip("v") for item in node_releases if item["version"].startswith(f"v{node_major}."))
        latest_playwright = fetch_json("https://registry.npmjs.org/playwright/latest")["version"]
        latest_otel = fetch_json("https://api.github.com/repos/open-telemetry/opentelemetry-collector-releases/releases/latest")["tag_name"].lstrip("v")
        package_request = urllib.request.Request(package_url, method="HEAD", headers={"User-Agent": "openclaw-swarm-assurance/1"})
        with urllib.request.urlopen(package_request, timeout=30) as response:
            package_available = 200 <= response.status < 400
        current = playwright == latest_playwright and otel == latest_otel and package_available
        evidence = {
            "node": {"pinnedMajor": node_major, "latestInMajor": latest_node},
            "playwright": {"pinned": playwright, "latest": latest_playwright},
            "otelCollector": {"pinned": otel, "latest": latest_otel},
            "openclaw": {"pinned": openclaw, "sealedPackageAvailable": package_available},
        }
        status = "success" if current else "failed"
        summary = (
            f"Pins: OpenClaw {openclaw} sealed; Node {node_major}/{latest_node}; "
            f"Playwright {playwright}/{latest_playwright}; OTEL {otel}/{latest_otel}"
        )
    except Exception as error:
        status = "failed"
        summary = f"Release evidence unavailable: {' '.join(str(error).split())}"
        evidence = {"error": summary}
    write_result(directory, status, summary, evidence)
    print(summary)
    return 0 if status == "success" else 1


def recovery(directory: Path) -> int:
    delivery = (ROOT / "docs/GITLAB_DELIVERY.md").read_text(encoding="utf-8")
    explicit = "No GitLab backup, restore, or PVC-content job is provided" in delivery
    status = "failed"
    summary = (
        "Recovery is unqualified: rollback is resource-only and no workspace/PVC restore exercise is approved"
        if explicit
        else "Recovery evidence unavailable: the explicit recovery deviation is missing"
    )
    write_result(directory, status, summary, {"explicitDeviation": explicit, "qualified": False})
    print(summary)
    return 1


def contract() -> int:
    ci = (ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8")
    required = (
        'CI_PIPELINE_SOURCE == "schedule" && $ASSURANCE_MODE == "weekly"',
        'CI_PIPELINE_SOURCE != "schedule"',
        "mattermost-assurance-notify@v0.8.4",
        "weekly_application_assurance:",
        "weekly_dependency_assurance:",
        "weekly_sonar_assurance:",
        "weekly_repository_assurance:",
        "weekly_live_runtime_assurance:",
        "weekly_collector_assurance:",
        "weekly_release_assurance:",
        "weekly_deployed_image_assurance:",
        "weekly_recovery_assurance:",
        "OPENCLAW_SWARM_ASSURANCE_KUBE_CONFIG_B64",
        "OPENCLAW_SWARM_ASSURANCE_HARBOR_USERNAME",
        "OPENCLAW_SWARM_ASSURANCE_HARBOR_PASSWORD",
    )
    missing = [item for item in required if item not in ci]
    if missing:
        raise SystemExit(f"weekly assurance contract missing: {', '.join(missing)}")
    print("OpenClaw swarm weekly assurance contract verified")
    return 0


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        raise SystemExit("usage: swarm_assurance.py <contract|runtime|collectors|dependency|release|recovery> ...")
    command = argv[1]
    if command == "contract":
        return contract()
    if len(argv) < 3:
        raise SystemExit(f"{command} requires an evidence directory")
    directory = Path(argv[2])
    if command == "runtime":
        return runtime(directory)
    if command == "collectors":
        return collectors(directory)
    if command == "dependency":
        if len(argv) != 4:
            raise SystemExit("dependency requires the dependency summary path")
        return dependency(directory, Path(argv[3]))
    if command == "release":
        return release(directory)
    if command == "recovery":
        return recovery(directory)
    raise SystemExit(f"unknown command: {command}")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
