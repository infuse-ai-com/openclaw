{{- range . }}
{{- range .Vulnerabilities }}{{ .Severity }}	{{ .VulnerabilityID }}	{{ .PkgName }}	{{ .InstalledVersion }}	{{ .FixedVersion }}{{ "\n" }}
{{- end }}
{{- range .Misconfigurations }}{{ .Severity }}	{{ .ID }}	{{ .Type }}	{{ .Title }}	{{ .Resolution }}{{ "\n" }}
{{- end }}
{{- range .Secrets }}{{ .Severity }}	{{ .RuleID }}	{{ .Category }}	{{ .Title }}	redacted{{ "\n" }}
{{- end }}
{{- end }}
