---
title: OpenClaw Kubernetes Swarm
description: Infuse AI repo for moving Kapiteky/OpenClaw from a single Mac mini
  runtime toward a Kubernetes-hosted, PVC-backed, secure agent swarm.
type: overview
status: active
owner: team:agent-platform
tags:
  - overview
---
# OpenClaw Kubernetes Swarm

Infuse AI repo for moving Kapiteky/OpenClaw from a single Mac mini runtime toward a Kubernetes-hosted, PVC-backed, secure agent swarm.

The goal is not to replace every Mac capability with Linux. The goal is to make the always-on agent runtime cloud-native, durable, and scalable, while keeping macOS-only capabilities as explicit worker integrations.

## Goals

- Run the main OpenClaw/Kapiteky runtime as a Kubernetes workload.
- Persist workspace, memory, skills, and working state on a dedicated PVC.
- Secure access through internal Kubernetes networking and Tailscale/private connectivity.
- Support browser smoke tests with Playwright/Chromium, headed Xvfb, and optional noVNC debugging.
- Support Docker-like build/test workflows through BuildKit or controlled remote Docker contexts.
- Grow into a swarm of scoped agents with clear roles, context packs, approval gates, and verification loops.

## Non-Goals

- Running the main agent pod as a broadly privileged Docker-in-Docker host.
- Storing secrets in Git, prompts, memory, screenshots, or container images.
- Pretending Linux containers replace macOS-only integrations such as Messages.app, Apple Notes, Keychain, or native UI automation.
- Giving every agent the full company brain by default.

## Repo Map

- `AGENTS.md` - repo-specific agent operating rules.
- `Taskfile.yml` - canonical local automation and image build tasks.
- `.gitlab-ci.yml` - source verification plus protected, explicit GitLab image
  publication, scan, rollout, and resource rollback.
- `docs/REPO_MAP.md` - detailed file ownership and change map.
- `docs/CURRENT_STATE.md` - short current-state summary for live agents, deployment target, and source-of-truth files.
- `docs/DECISIONS.md` - dated decisions and rationale.
- `docs/ARCHITECTURE.md` - target architecture and component split.
- `docs/ROADMAP.md` - implementation milestones.
- `docs/SECURITY.md` - access, network, secret, and approval model.
- `docs/AGENT_IDENTITIES.md` - persistent agent identity and Mattermost onboarding model.
- `docs/GITLAB_AGENT_SOURCE_MIGRATION.md` - current GitLab source, per-agent identity and job qualification contract.
- `docs/AGENT_DRAFT_SYNC.md` - v1 local draft detection, own daily-memory export, dogfood notes, and common operator runbooks.
- `docs/AGENT_PERSONA_DOGFOOD.md` - persona improvement backlog, runtime sync acceptance, context-pack gaps, and live dogfood loop.
- `docs/ACCESS_REVIEW.md` - runtime exceptions, temporary credential bridges, and review/cleanup triggers.
- `docs/AGENT_VAULTWARDEN_ACCOUNT_RUNBOOK.md` - manual Authentik, Vaultwarden, API-key, and Kubernetes setup for an agent direct Vaultwarden account.
- `docs/BACKOFFICE_COMMAND_CENTER.md` - Backoffice plan for agent status, access review, approvals, and command-center progression.
- `docs/BACKOFFICE_AGENT_MODEL_POLICY_FEED.md` - read-only Backoffice feed for each agent's default model, thinking depth, reasoning visibility, and drift status.
- `docs/BACKOFFICE_AGENT_CATALOG_FEED.md` - generated sanitized agent identity
  and declared-ownership contract consumed by the current control-plane owner.
- `docs/BACKOFFICE_MISSION_CONTROL_FEED.md` - retirement record for the filesystem feed replaced by the authenticated Artifact Registry.
- `docs/TAILSCALE_AGENT_DASHBOARDS.md` - runbook for exposing OpenClaw Control dashboards through Tailscale-only Kubernetes Services.
- `docs/INTERNAL_GATEWAY_TRANSPORT.md` - selective dashboard-to-agent mutual TLS inside the cluster, with Tailscale retained for external agents and rollback.
- `docs/MATTERMOST_INTERACTIONS_CALLBACK.md` - investigation notes for replacing loopback Mattermost interaction callbacks with reachable private callback URLs.
- `docs/NEW_AGENT_RUNBOOK.md` - how to add a persistent agent, using `agent-designer` as the example.
- `docs/SKILL_MANAGEMENT.md` - skill sources, catalog, and per-agent bundle policy.
- `docs/RUNTIME_BOOTSTRAP.md` - historical ncase bootstrap notes from the first prototype.
- `docs/agents/README.md` - agent-doc contract, roster, reporting format, and live core-file sync checklist.
- `docs/agents/` - per-agent access bundles and activation notes.
- `config/skill-catalog.json` - reviewed skill source and skill registry.
- `config/agent-skill-bundles/` - per-agent specialist skill bundles.
- `config/agent-model-policies.json` - per-agent default model, thinking depth, reasoning visibility, and runtime policy.
- `docs/secrets/` - example secret contracts only; no real values.
- Persona source lives in the sibling `openclaw-agents-persona` repo. This repo
  owns the Kubernetes runtime, sync helpers, PVCs, skill bundles, and access
  grants; update `openclaw-agents-persona/agents/<agent-id>/` or
  `openclaw-agents-persona/templates/agent-persona/` for persona behavior.
- `k8s/components/persistent-agent/` - reusable component for one persistent agent Deployment/PVC/NetworkPolicy.
- `k8s/agents/` - concrete per-agent overlays, including active `agent-developer`, `agent-designer`, `agent-infra`, `agent-coordinator`, and `agent-intake`.
- `k8s/overlays/infuseai/` - the only maintained Kubernetes deployment overlay, targeting InfuseAI namespace `agents-swarm`.
- `k8s/tailscale/` - Tailscale Kubernetes Operator resources used by private agent dashboard exposure.

GitLab runs source verification for merge requests and protected `main` pushes.
Image-relevant protected `main` pushes automatically build and scan a new
immutable image candidate through the reusable rootless build component.
`RUN_GITLAB_DELIVERY=1` qualifies the already approved digest and
exposes manual, serialized rollout and resource-rollback jobs. See [GitLab delivery](docs/GITLAB_DELIVERY.md) and the
[release runbook](docs/RUNBOOK.md). Scheduled assurance remains a separately
qualified workflow.

## Automation

Use Task as the canonical runner:

```bash
task verify
```

Run the broader local CI-safe gate when preparing a release:

```bash
AGENT_ID=agent-designer task verify-ci
```

The GitLab job runs unit tests, knowledge-format validation, shell syntax and
diff checks. The local gates run `task knowledge:verify` over every Markdown document selected by
`.knowledge-base.yml`. Missing or invalid IKF metadata fails verification with
the document path. Generated and excluded evidence stays outside that scope.

The unit suite includes a hermetic, stateful OpenClaw CLI boundary. It executes
the production session-create and coordinator-continuation runners through real
subprocesses while keeping Gateway state, credentials, and network access out
of the test. This guards the exact argv, JSON, idempotency, and recovery
contract without relying on a live agent.

The runtime uses a pinned OpenClaw distribution built from exact
checksum-verified artifacts. The release target is OpenClaw `2026.11.1` at
source `19818bb59a7bf9d4e9989fb9a4df6f1b4ffe8ca6`, with its Codex, Mattermost,
ACPX, and diagnostics plugins loaded only from the Core bundle, Codex CLI
`0.160.0`, ACPX CLI `0.19.1`, and Bitwarden CLI `2026.10.0`. The sealed consumer
lock, candidate manifest, Taskfile, and Dockerfile bind the package URL,
checksum, and source identity into every image build; do not replace them with
moving npm tags during routine work.

```bash
task image-build
TAG="$(git rev-parse --short=12 HEAD)-amd64" task image-push-agent
```

OpenClaw upgrades are deliberate canary promotions: change the exact source,
artifacts, checksums, and compatible plugin pins together on a branch; build
and exercise a real agent turn; then merge only after live lifecycle evidence.
After rollout, run
`openclaw doctor` in each active pod and check persisted plugin projects with
`openclaw plugins list --json`; PVC-backed installs can keep old plugin shadows
active even when the image contains the new bundle. The
full upgrade checklist lives in `docs/RUNBOOK.md`.

The Studio plugin producer is pinned independently by source commit, reproducible
Node/npm build identity, cross-architecture output fingerprint, and an exact file
inventory in `config/qualification/studio-tool-inventory-2026.11.1.json`.
Floor/repository management adds `studio_floor_manage`; image qualification and
the post-rollout smoke both require its loaded tool inventory. The startup
fingerprint refreshes PVC-installed copies when the packaged content changes.
Studio remains the permission authority: its approved pilot policy admits all
current enrolled humans and Gateway agents while retaining current generation,
session and run checks. This does not enroll additional agents or grant GitLab
credentials to them.

Per-agent model, capacity-failure, and thinking defaults are declared in
`config/agent-model-policies.json` and verified against the Kubernetes
`OPENCLAW_CONFIG_JSON` blobs by `task verify-agent-model-policies`.

The shared `openclaw-agent` image includes the base toolbox expected by persistent agents: Git, Task, kubectl, Helm, kustomize, Docker CLI, crane, Python/pip/uv plus common Python utility packages, ripgrep, fd, jq, yq, Node/npm/npx/pnpm/yarn, pinned npm and Python Playwright APIs with their matching managed Chromium browser, build/patch/archive/sync tools, Git LFS, shellcheck, system Chromium with Xvfb/xauth and common fonts, network/debug CLIs, PDF/image helpers, Vaultwarden/BW tooling, gog, Codex, ACPX as an OpenAI-backed transport, and OpenClaw. At startup the image links its managed browser into the writable PVC-backed `/workspace/.cache/ms-playwright` cache without duplicating the browser payload; project Taskfiles remain responsible for their own Playwright package and browser pins. Docker is CLI-only unless a task intentionally provides a socket or remote builder.

The Python toolbox lives in `/opt/agent-python-toolbox`, a hash-locked virtual
environment on the runtime PATH. This keeps Debian's Python modules under apt
ownership and avoids pip uninstalling or overwriting them during base upgrades.
`python`, `python3`, `pip3`, `uv`, `yq` and Playwright remain available by command
name. Project dependencies still belong in their own declared environments.

Persistent agents require browser sandboxing: native OpenClaw uses
`browser.noSandbox=false` and the existing Chromium seccomp profile; Python
Playwright must set `chromium_sandbox=True`, Node Playwright must set
`chromiumSandbox: true`. Toolbox smokes exercise both APIs with those settings.
A launch failure must be reported, never retried with `--no-sandbox`. These
settings do not isolate browser code from same-pod credentials or memory;
separate workers remain a distinct architecture phase. Installed project
Playwright packages retain their own defaults and must pass the explicit option.

Ruby, RubyGems and Bundler are intentionally absent from the persistent image.
`openclaw-agent-capabilities --json` reports the actual Ruby availability and
routes missing Ruby to a project-specific environment. A Ruby-dependent task
must declare that requirement and use a reviewed project CI or worker image;
do not install an undeclared Ruby toolchain into the agent PVC. No shared Ruby
worker is implied by this capability report.

Runtime availability is not artifact portability. `NODE_PATH` exposes the
image's Playwright package to work performed inside the pod, but an attached ZIP
must declare and lock that dependency or bundle it. Before making a package-wide
verification claim, run the artifact from an isolated copy with ambient Node
module lookup and agent-toolbox fallbacks disabled:

```bash
openclaw-agent-capabilities --json \
  --require-browser-automation \
  --require-image-composition

openclaw-agent-evidence-verify evidence.zip \
  --command 'node build-native.js' \
  --command 'node verify-native.js' \
  --command 'node verify-text-only-200.js'
```

The evidence verifier rejects ungated pod paths such as
`/opt/agent-node-toolbox` and `/workspace/agents/...`, plus fixed Chromium paths
that have no `CHROMIUM_PATH` or managed-browser resolution. It also rejects
undeclared or unlocked Playwright imports.
Every generated task brief repeats this boundary and requires exact command,
exit-code, stderr-tail, and failure-classification evidence for nonzero runs.

Persistent agent dry-runs use `AGENT_ID`:

```bash
AGENT_ID=agent-developer task verify-agent-profile
AGENT_ID=agent-developer task verify-agent-skill-install
AGENT_ID=agent-developer task verify-agent-persona
AGENT_ID=agent-designer task verify-agent-profile
AGENT_ID=agent-designer task verify-agent-skills
AGENT_ID=agent-designer task verify-agent-skill-install
AGENT_ID=agent-designer task verify-agent-mattermost-secret
AGENT_ID=agent-designer task verify-agent-persona
AGENT_ID=agent-designer task verify-agent-mattermost-bot
```

InfuseAI live diagnostics use the same `AGENT_ID` and default to
`KUBE_CONTEXT=infuseai-k8s`, `NAMESPACE=agents-swarm`:

```bash
AGENT_ID=agent-developer task status-agent
AGENT_ID=agent-developer task smoke-agent-runtime
AGENT_ID=agent-developer task smoke-agent-toolbox
```

The persistent agent image includes the Docker CLI and Compose plugin but no
Docker daemon or socket. Inside an agent pod, run
`openclaw-agent-capabilities --json` before container work. Compose config is a
local validation capability; image builds are expected to report
`ci_required` and use the product PR BuildKit gate.

InfuseAI deployment helpers default to the Harbor project and namespace `agents-swarm`:

```bash
TAG="$(git rev-parse --short=12 HEAD)" task render-infuseai-agents
TAG="$(git rev-parse --short=12 HEAD)" task deploy-infuseai-agents
```

The deploy helper defaults to a bounded `canary-wave` rollout: developer is
replaced and fully verified alone; designer, infra, and intake then advance as
one parallel leaf batch; coordinator is promoted only after that complete batch
passes. Every agent still prepares its own live OpenClaw Gateway, stops its own
single writer, applies its Deployment held at zero, and verifies the replacement
before returning. A failed leaf waits for its already-started peers to settle
and blocks coordinator promotion. Use
`OPENCLAW_FLEET_ROLLOUT_STRATEGY=sequential` to restore the original one-agent-
at-a-time order.

Stable CI defaults to `OPENCLAW_ROLLOUT_MODE=bounded`: it gives active work 30
seconds, requires terminal persistence, and requires the exact-predecessor
handoff before the pod exits. Current images arm a ready handoff from `preStop`
for uncoordinated termination. Controller-led rollouts arm the exact predecessor
before termination and carry a 15-second grace in the initial pod delete request,
because OpenClaw treats SIGTERM as a restart and Kubernetes cannot reliably
shorten an already-started 420-second termination. Pod deletion must still
finish inside 30 seconds. `OPENCLAW_ROLLOUT_MODE=drain` is the opt-in 300-second
mode; its timeout resumes the old Gateway and stops the rollout. Agents already
at zero remain at zero.

Pod startup has no artificial per-agent delay. The pod `fsGroup` uses
`OnRootMismatch`, and the root init container skips recursive ownership repair
when the workspace root is already `10001:10001`; a fresh or stale-root volume
still receives the full repair before OpenClaw starts.

An approved release promotes the same pinned internal runtime to all five agents.
The immediate pre-upgrade image is OpenClaw 2026.10.3 at digest
`sha256:5b660ae33ba1587475fdfc56df989e490ff904f6382d3ea8943a75c3183ecec7`
from swarm source `b32e131d3413f4869a317264db27e81f76c6f4bc`. OpenClaw 2026.11.1 can
migrate shared state from schema 20 to schema 22, so that image is a rollback
candidate only with the matching verified pre-upgrade PVC recovery artifacts.
Never lower schema markers, delete runtime state, or restore the older image over
newer state.

For the approved retrieval capability, each persistent agent runs under its
own `openclaw-agent-<role>` ServiceAccount while the shared component projects
a rotating token with audience `knowledge-base-retrieval` and configures the
private `knowledge-base-retrieval.knowledge-base.svc.cluster.local` Service.
The distinct identities receive no repo-declared RBAC binding; the old shared
ServiceAccount remains only as a bounded migration rollback identity.
After the Knowledge Base and dual-version skill-client gates pass, use
`scripts/rollout-retrieval-agent-identity.sh` to move one Deployment at a time.
The confirmation-gated helper preserves the image, fingerprints every peer pod
template, and requires both runtime and content-free Discover-to-Fetch smokes.
Start with `agent-developer`; advance only after live attribution is visible.
After all five guarded migrations pass, merge the desired-state overlay so the
next approved release reconciles the already-proven identities rather than becoming
the mechanism for a simultaneous fleet rollout.

Do not deploy a new persistent agent until its access bundle, profile, bot token, and secrets are approved and ready. For the current live agents, use `docs/GITLAB_AGENT_SOURCE_MIGRATION.md` before adding repo checkout, GitLab, Vaultwarden, or Kubernetes permissions.

## Company Context

Use `/Users/mac/Code/Infuse AI/company-docs/docs/agent-bootstrap.md` as the default compact company context. Load deeper company docs only when relevant, especially:

- `docs/agentic-operating-model.md`
- `docs/security-and-access-model.md`
- `docs/engineering-handbook.md`
- `docs/quality-gates.md`
- `docs/specialized-agent-roles.md`
