"""Contract tests for the sanitized Backoffice agent catalog."""

from __future__ import annotations

import importlib.util
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "generate-backoffice-agent-catalog.py"
OUTPUT_PATH = ROOT / "config" / "backoffice-agent-catalog.v1.json"
SPEC = importlib.util.spec_from_file_location("backoffice_agent_catalog", SCRIPT_PATH)
assert SPEC and SPEC.loader
CATALOG_MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CATALOG_MODULE)


class BackofficeAgentCatalogTests(unittest.TestCase):
    def setUp(self) -> None:
        self.catalog = CATALOG_MODULE.build_catalog()

    def test_checked_in_catalog_matches_authoritative_sources(self) -> None:
        checked_in = json.loads(OUTPUT_PATH.read_text(encoding="utf-8"))
        self.assertEqual(checked_in, self.catalog)

    def test_schema_is_exact_and_agents_are_unique(self) -> None:
        self.assertEqual(
            set(self.catalog),
            {"schemaVersion", "source", "agents"},
        )
        self.assertEqual(self.catalog["schemaVersion"], 1)
        self.assertEqual(
            set(self.catalog["source"]),
            {"type", "repository", "branch"},
        )
        agent_ids = [agent["agentId"] for agent in self.catalog["agents"]]
        self.assertEqual(len(agent_ids), len(set(agent_ids)))
        self.assertGreater(len(agent_ids), 0)

        for agent in self.catalog["agents"]:
            self.assertEqual(
                set(agent),
                {
                    "agentId",
                    "displayName",
                    "role",
                    "description",
                    "lifecycle",
                    "mattermost",
                    "skills",
                },
            )
            self.assertEqual(
                set(agent["mattermost"]),
                {"username", "groupActivation"},
            )
            self.assertIn(agent["mattermost"]["groupActivation"], {"all", "mention"})
            self.assertEqual(set(agent["skills"]), {"installed"})
            self.assertEqual(agent["lifecycle"], "active")
            self.assertEqual(
                len(agent["skills"]["installed"]),
                len(set(agent["skills"]["installed"])),
            )

    def test_catalog_contains_only_active_overlay_agents_in_overlay_order(self) -> None:
        overlay_text = CATALOG_MODULE.OVERLAY_PATH.read_text(encoding="utf-8")
        expected = CATALOG_MODULE.active_agent_ids(overlay_text)
        actual = [agent["agentId"] for agent in self.catalog["agents"]]
        self.assertEqual(actual, expected)
        for agent_id in actual:
            bundle = json.loads(
                (ROOT / "config" / "agent-skill-bundles" / f"{agent_id}.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(bundle["status"], "active")

    def test_catalog_excludes_private_runtime_content(self) -> None:
        forbidden_keys = {
            "allowFrom",
            "botToken",
            "credential_access",
            "credentials",
            "groupAllowFrom",
            "openclawConfig",
            "ownerAllowFrom",
            "runtime",
            "secretKeyRef",
            "secrets",
            "workload",
            "overlayPath",
            "imageRepository",
            "deploymentName",
            "pvcName",
            "workspacePath",
            "links",
            "agentDocPath",
            "bundlePath",
        }

        def visit(value: object) -> None:
            if isinstance(value, dict):
                self.assertTrue(forbidden_keys.isdisjoint(value))
                for nested in value.values():
                    visit(nested)
            elif isinstance(value, list):
                for nested in value:
                    visit(nested)

        visit(self.catalog)
        serialized = json.dumps(self.catalog)
        for forbidden_value in (
            "MATTERMOST_BOT_TOKEN",
            "OPENCLAW_CONFIG_JSON",
            "/workspace/.openclaw-secure",
            "bitwarden-cli",
            "kubernetes.io/serviceaccount",
            ".ts.net",
            "/workspace/",
            "k8s/overlays/",
            "registry.infuse-ai-tech.party",
            "docs/agents/",
            "config/agent-skill-bundles/",
            "agent-developer-workspace",
        ):
            self.assertNotIn(forbidden_value, serialized)

    def test_catalog_source_does_not_embed_a_commit(self) -> None:
        self.assertNotIn("commit", self.catalog["source"])


if __name__ == "__main__":
    unittest.main()
