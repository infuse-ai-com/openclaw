import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { mkdtempSync, readFileSync, writeFileSync, rmSync, symlinkSync, mkdirSync } from 'node:fs';
import { createServer } from 'node:http';
import { get } from 'node:https';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { connect } from 'node:tls';
import { after, before, test } from 'node:test';
import { createGatewayTlsTunnel, loadGatewayTlsCredentials, DASHBOARD_CLIENT_NAME } from '../k8s/components/gateway-internal-tls/tunnel.mjs';

const serverName = 'agent-designer-dashboard-internal.agents-swarm.svc.cluster.local';
const fixture = mkdtempSync(join(tmpdir(), 'gateway-internal-tls-'));
const file = (name) => join(fixture, name);
const pem = (name) => readFileSync(file(name));
const openssl = (...args) => execFileSync('openssl', args, { stdio: 'pipe' });
function ca(name) {
  openssl('req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:prime256v1', '-nodes',
    '-keyout', file(`${name}.key`), '-out', file(`${name}.crt`), '-days', '1', '-subj', `/CN=${name}`,
    '-addext', 'basicConstraints=critical,CA:TRUE', '-addext', 'keyUsage=critical,keyCertSign,cRLSign');
}
let serial = 1;
function leaf(name, authority, dns, purpose, days = '1') {
  openssl('req', '-new', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:prime256v1', '-nodes',
    '-keyout', file(`${name}.key`), '-out', file(`${name}.csr`), '-subj', `/CN=${dns}`);
  writeFileSync(file(`${name}.ext`), `basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature\nextendedKeyUsage=${purpose}\nsubjectAltName=DNS:${dns}\n`, { mode: 0o600 });
  if (days === '-1') {
    writeFileSync(file('index'), '', { mode: 0o600 });
    writeFileSync(file('serial'), '1000\n', { mode: 0o600 });
    writeFileSync(file('ca.cnf'), `[ca]\ndefault_ca=fixture\n[fixture]\ndatabase=${file('index')}\nserial=${file('serial')}\nnew_certs_dir=${fixture}\ncertificate=${file(`${authority}.crt`)}\nprivate_key=${file(`${authority}.key`)}\ndefault_md=sha256\npolicy=names\n[names]\ncommonName=supplied\n`, { mode: 0o600 });
    openssl('ca', '-batch', '-config', file('ca.cnf'), '-in', file(`${name}.csr`), '-out', file(`${name}.crt`),
      '-startdate', '20200101000000Z', '-enddate', '20200102000000Z', '-extfile', file(`${name}.ext`), '-notext');
    return;
  }
  openssl('x509', '-req', '-in', file(`${name}.csr`), '-CA', file(`${authority}.crt`), '-CAkey', file(`${authority}.key`),
    '-set_serial', String(serial++), '-days', days, '-extfile', file(`${name}.ext`), '-out', file(`${name}.crt`));
}
let upstream;
let tunnel;
let port;
let requests = 0;
const upstreamSockets = new Set();
function client(name = 'dashboard', overrides = {}) {
  return { host: '127.0.0.1', port, servername: serverName, ca: pem('server-ca.crt'),
    ...(name ? { cert: pem(`${name}.crt`), key: pem(`${name}.key`) } : {}), ...overrides };
}
function request(options) {
  return new Promise((resolve, reject) => {
    const req = get({ ...options, path: options.path ?? '/__openclaw/avatar/agent-designer', agent: false,
      headers: { 'x-forwarded-user': 'issuer|immutable-sub', 'x-forwarded-host': 'agents.infuse-ai.com', 'x-forwarded-proto': 'https' } }, (res) => {
      let body = '';
      res.on('data', (data) => { body += data; });
      res.on('end', () => resolve(JSON.parse(body)));
      res.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(2_000, () => req.destroy(new Error('fixture timeout')));
  });
}

before(async () => {
  for (const name of ['server-ca', 'client-ca', 'untrusted-ca']) ca(name);
  leaf('server', 'server-ca', serverName, 'serverAuth');
  leaf('dashboard', 'client-ca', DASHBOARD_CLIENT_NAME, 'clientAuth');
  leaf('other-client', 'client-ca', 'another.agents-swarm.svc.cluster.local', 'clientAuth');
  leaf('wildcard-client', 'client-ca', '*.agents-swarm.svc.cluster.local', 'clientAuth');
  leaf('server-as-client', 'client-ca', DASHBOARD_CLIENT_NAME, 'serverAuth');
  leaf('dual-purpose-client', 'client-ca', DASHBOARD_CLIENT_NAME, 'serverAuth,clientAuth');
  leaf('untrusted-client', 'untrusted-ca', DASHBOARD_CLIENT_NAME, 'clientAuth');
  leaf('expired-client', 'client-ca', DASHBOARD_CLIENT_NAME, 'clientAuth', '-1');
  upstream = createServer((req, res) => {
    requests++;
    res.setHeader('content-type', 'application/json');
    if (req.url === '/large') {
      res.setHeader('connection', 'close');
      res.end(JSON.stringify({ payload: 'x'.repeat(2 * 1024 * 1024) }));
      return;
    }
    res.end(JSON.stringify({ path: req.url, user: req.headers['x-forwarded-user'], host: req.headers['x-forwarded-host'], proto: req.headers['x-forwarded-proto'], peer: req.socket.remoteAddress }));
  });
  upstream.on('connection', (socket) => {
    upstreamSockets.add(socket);
    socket.on('close', () => upstreamSockets.delete(socket));
  });
  upstream.on('upgrade', (_req, socket, head) => {
    requests++;
    socket.write('HTTP/1.1 101 Switching Protocols\r\nConnection: Upgrade\r\nUpgrade: websocket\r\n\r\n');
    if (head.length) socket.write(head);
    socket.on('data', (data) => socket.write(data));
  });
  upstream.listen(18791, '127.0.0.1');
  await once(upstream, 'listening');
  tunnel = createGatewayTlsTunnel({ cert: pem('server.crt'), key: pem('server.key'), ca: pem('client-ca.crt') });
  tunnel.listen(0, '127.0.0.1');
  await once(tunnel, 'listening');
  port = tunnel.address().port;
});

after(async () => {
  tunnel?.shutdown();
  for (const socket of upstreamSockets) socket.destroy();
  if (upstream?.listening) await new Promise((resolve) => upstream.close(resolve));
  rmSync(fixture, { recursive: true, force: true });
});

test('authenticated HTTP reaches only the loopback gateway with dashboard-owned headers intact', async () => {
  assert.deepEqual(await request(client()), { path: '/__openclaw/avatar/agent-designer',
    user: 'issuer|immutable-sub', host: 'agents.infuse-ai.com', proto: 'https', peer: '127.0.0.1' });
});

test('WebSocket upgrade and bidirectional frame bytes survive the tunnel', async () => {
  const socket = connect(client());
  socket.setTimeout(2_000, () => socket.destroy(new Error('fixture timeout')));
  await once(socket, 'secureConnect');
  socket.write('GET /ws HTTP/1.1\r\nHost: agents.infuse-ai.com\r\nConnection: Upgrade\r\nUpgrade: websocket\r\n\r\n');
  const [upgrade] = await once(socket, 'data');
  assert.match(upgrade.toString(), /^HTTP\/1.1 101 /);
  const bytes = Buffer.from([0x81, 0x02, 0x6f, 0x6b]);
  socket.write(bytes);
  const [echo] = await once(socket, 'data');
  assert.deepEqual(echo, bytes);
  socket.destroy();
});

test('a large final gateway response flushes completely before connection close', async () => {
  const response = await request(client('dashboard', { path: '/large' }));
  assert.equal(response.payload.length, 2 * 1024 * 1024);
});

for (const name of [null, 'other-client', 'wildcard-client', 'server-as-client', 'dual-purpose-client', 'untrusted-client', 'expired-client']) {
  test(`reject ${name ?? 'missing client certificate'} before forwarding HTTP`, async () => {
    const count = requests;
    await assert.rejects(request(client(name)));
    assert.equal(requests, count);
  });
}

test('client rejects the wrong gateway DNS and an untrusted gateway CA', async () => {
  await assert.rejects(request(client('dashboard', { servername: 'agent-developer-dashboard-internal.agents-swarm.svc.cluster.local' })), /altname|hostname/i);
  await assert.rejects(request(client('dashboard', { ca: pem('untrusted-ca.crt') })));
});

test('TLS 1.2 is refused', async () => {
  await assert.rejects(request(client('dashboard', { maxVersion: 'TLSv1.2' })));
});

test('startup checks the exact server name and server-only certificate purpose', () => {
  writeFileSync(file('tls.crt'), pem('server.crt'));
  writeFileSync(file('tls.key'), pem('server.key'), { mode: 0o600 });
  assert.equal(loadGatewayTlsCredentials(fixture, serverName).key.toString(), pem('server.key').toString());
  assert.throws(() => loadGatewayTlsCredentials(fixture, 'arbitrary.example'), /server name/);
  assert.throws(() => loadGatewayTlsCredentials(fixture, 'agent-developer-dashboard-internal.agents-swarm.svc.cluster.local'), /certificate/);
  writeFileSync(file('tls.crt'), pem('dashboard.crt'));
  assert.throws(() => loadGatewayTlsCredentials(fixture, serverName), /certificate/);
});

test('shutdown closes existing sockets and listener', async () => {
  const socket = connect(client());
  await once(socket, 'secureConnect');
  socket.write('GET /ws HTTP/1.1\r\nHost: agents.infuse-ai.com\r\nConnection: Upgrade\r\nUpgrade: websocket\r\n\r\n');
  await once(socket, 'data');
  const closed = once(socket, 'close');
  tunnel.shutdown();
  await closed;
  assert.equal(tunnel.listening, false);
});

test('unavailable local gateway closes the client without selecting another destination', async () => {
  for (const socket of upstreamSockets) socket.destroy();
  await new Promise((resolve) => upstream.close(resolve));
  tunnel = createGatewayTlsTunnel({ cert: pem('server.crt'), key: pem('server.key'), ca: pem('client-ca.crt') });
  tunnel.listen(0, '127.0.0.1');
  await once(tunnel, 'listening');
  port = tunnel.address().port;
  await assert.rejects(request(client()));
  tunnel.shutdown();
});

// ConfigMap keys are symlinks through ..data; Node resolves the module URL.
// Missing credentials must reach startup validation, never silently skip main.
test('projected ConfigMap symlink executes the CLI entrypoint', () => {
  const projection = file('projection');
  mkdirSync(projection);
  const source = fileURLToPath(new URL('../k8s/components/gateway-internal-tls/tunnel.mjs', import.meta.url));
  symlinkSync(source, join(projection, 'tunnel.mjs'));
  const child = spawnSync(process.execPath, [join(projection, 'tunnel.mjs')], {
    env: { ...process.env, GATEWAY_TLS_SERVER_NAME: 'invalid-test-name' }, encoding: 'utf8', timeout: 5_000,
  });
  assert.equal(child.status, 1, child.stderr);
  assert.match(child.stderr, /gateway TLS tunnel configuration failed/);
});
