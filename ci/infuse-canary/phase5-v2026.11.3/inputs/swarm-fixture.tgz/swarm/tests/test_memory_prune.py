import hashlib
import importlib.util
from pathlib import Path
import sqlite3
import unittest
s = importlib.util.spec_from_file_location('prune', Path(__file__).resolve().parents[1] / 'scripts/prune-agent-dreaming-state.py')
m = importlib.util.module_from_spec(s); s.loader.exec_module(m)


class PruneTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:'); self.addCleanup(self.db.close)
        self.db.execute('CREATE TABLE plugin_state_entries(plugin_id TEXT, namespace TEXT, entry_key TEXT, value_json TEXT, created_at INT, expires_at INT)')
        self.workspace = Path('/workspace/agents/agent-developer')
        self.key = hashlib.sha256(str(self.workspace).encode()).hexdigest() + ':one'
        rows = [('memory-core', 'short-term-recall', self.key, '{}', 1, None),
                ('memory-core', 'short-term-recall', 'peer:one', '{}', 1, None),
                ('memory-core', 'dreaming-session-ingestion-files', self.key, '{"value":{"lastContentLine":4,"lineCount":4}}', 1, None),
                ('memory-core', 'memory-host.event-cursors', self.key, '{}', 1, None),
                ('other-plugin', 'short-term-recall', self.key, '{}', 1, None)]
        self.db.executemany('INSERT INTO plugin_state_entries VALUES(?,?,?,?,?,?)', rows); self.db.commit()

    def test_prune_preserves_peer_and_event_cursor(self):
        plan = m.rows_and_plan(self.db, self.workspace)[2]
        self.assertEqual(m.prune(self.db, self.workspace, plan)['removed_rows'], 1)
        self.assertEqual(self.db.execute('SELECT count(*) FROM plugin_state_entries').fetchone()[0], 4)

    def test_changed_state_refuses_without_deleting(self):
        plan = m.rows_and_plan(self.db, self.workspace)[2]
        self.db.execute('UPDATE plugin_state_entries SET value_json=? WHERE entry_key=?', ('{"changed":true}', self.key)); self.db.commit()
        with self.assertRaisesRegex(ValueError, 'changed'):
            m.prune(self.db, self.workspace, plan)
        self.assertEqual(self.db.execute('SELECT count(*) FROM plugin_state_entries').fetchone()[0], 5)

    def test_partial_ingestion_refuses_without_deleting(self):
        self.db.execute('UPDATE plugin_state_entries SET value_json=? WHERE namespace=?', ('{"value":{"lastContentLine":1,"lineCount":4}}', 'dreaming-session-ingestion-files')); self.db.commit()
        plan = m.rows_and_plan(self.db, self.workspace)[2]
        with self.assertRaisesRegex(ValueError, 'incomplete'):
            m.prune(self.db, self.workspace, plan)
        self.assertEqual(self.db.execute('SELECT count(*) FROM plugin_state_entries').fetchone()[0], 5)
