import argparse
import copy
import importlib.util
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'scripts' / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

mr = load('memory_mr', 'create-agent-memory-sync-pr.py')
bootstrap = load('gitlab_bootstrap', 'git-credential-agent-bootstrap.py')
SHA = 'a' * 40
BRANCH = 'agent-memory-sync/agent-infra/test'

class MemoryMergeTests(unittest.TestCase):
    def setUp(self):
        self.args = argparse.Namespace(agent_id='agent-infra',source_branch=BRANCH,target_branch='main',source_commit=SHA,timeout_seconds=10)
        self.record = dict(iid=42,source_project_id=8,target_project_id=8,source_branch=BRANCH,target_branch='main',sha=SHA,state='opened',draft=False,has_conflicts=False,head_pipeline={'sha':SHA,'status':'success'},detailed_merge_status='mergeable')
        self.existing = []
        self.calls = []
        self.identity = 'agent-infra'
        self.settled = True
        self.branch_sha = SHA

    def request(self, method, path, body=None):
        self.calls.append((method,path,body))
        if path == 'user': return {'username':self.identity,'state':'active'}
        if '/repository/branches/' in path: return {'commit':{'id':self.branch_sha}}
        if '/merge_requests?' in path: return copy.deepcopy(self.existing)
        if method == 'POST': return {'iid':42}
        if method == 'PUT':
            if self.settled: self.record.update(state='merged',merge_commit_sha='b'*40)
            return copy.deepcopy(self.record)
        if path.endswith('/42'): return copy.deepcopy(self.record)
        return {'id':8}

    def run_sync(self):
        with patch.object(mr.time,'monotonic', side_effect=iter(range(30))), patch.object(mr.time,'sleep'):
            return mr.complete(self.args,self,5)

    def writes(self): return [c for c in self.calls if c[0] == 'PUT']

    def test_review_receipt_is_bound_to_source_sha_without_merging(self):
        result=self.run_sync()
        self.assertEqual(result['status'],'review_pending')
        self.assertEqual(result['source_commit'],SHA)
        self.assertEqual(self.writes(),[])

    def test_existing_mr_is_reused(self):
        self.existing=[copy.deepcopy(self.record)]
        self.run_sync()
        self.assertFalse(any(c[0]=='POST' for c in self.calls))

    def test_merged_mr_reconciles_after_source_branch_deletion(self):
        self.record.update(state='merged',merge_commit_sha='b'*40)
        self.existing=[copy.deepcopy(self.record)]
        self.assertEqual(self.run_sync()['status'],'merged')
        self.assertFalse(any('/repository/branches/' in c[1] or c[0] in {'POST','PUT'} for c in self.calls))

    def test_ambiguous_mrs_fail_without_new_mr(self):
        self.existing=[self.record,self.record]
        with self.assertRaises(mr.SyncError): self.run_sync()
        self.assertFalse(any(c[0] in {'POST','PUT'} for c in self.calls))

    def test_wrong_identity_fails_before_project_reads(self):
        self.identity='agent-developer'
        with self.assertRaises(mr.SyncError): self.run_sync()
        self.assertEqual(len(self.calls),1)

    def test_changed_branch_is_never_submitted(self):
        self.branch_sha='c'*40
        with self.assertRaises(mr.SyncError): self.run_sync()
        self.assertFalse(any(c[0] in {'POST','PUT'} for c in self.calls))

    def test_changed_mr_is_never_merged_or_closed(self):
        self.record['sha']='c'*40
        with self.assertRaises(mr.SyncError): self.run_sync()
        self.assertEqual(self.writes(),[])

    def test_failed_missing_or_stale_pipeline_does_not_merge(self):
        for pipeline in [{}, {'sha':SHA,'status':'failed'}, {'sha':'c'*40,'status':'success'}]:
            with self.subTest(pipeline=pipeline):
                self.record['head_pipeline']=pipeline; self.calls=[]
                with self.assertRaises(mr.SyncError): self.run_sync()
                self.assertEqual(self.writes(),[])

    def test_required_approvals_are_not_bypassed(self):
        self.record['detailed_merge_status']='not_approved'
        self.assertEqual(self.run_sync()['status'], 'review_pending')
        self.assertEqual(self.writes(),[])

    def test_missing_merge_permission_preserves_mr_without_attempt(self):
        self.record['user'] = {'can_merge': False}
        self.existing = [copy.deepcopy(self.record)]
        self.assertEqual(self.run_sync()['status'], 'review_pending')
        self.assertFalse(any(c[0] in {'POST', 'PUT'} for c in self.calls))

    def test_merge_capable_identity_still_requires_review(self):
        self.record['user'] = {'can_merge': True}
        self.assertEqual(self.run_sync()['status'], 'review_pending')
        self.assertEqual(self.writes(),[])

    def test_cross_agent_branch_and_identity_rejected(self):
        with patch.dict(os.environ,{'AGENT_ID':'agent-infra','GITLAB_AGENT_ID':'agent-developer'}):
            with self.assertRaises(mr.SyncError): mr.validate_args(self.args)
        with patch.dict(os.environ,{'AGENT_ID':'agent-infra','GITLAB_AGENT_ID':'agent-infra'}):
            self.args.source_branch='agent-memory-sync/agent-developer/test'
            with self.assertRaises(mr.SyncError): mr.validate_args(self.args)


class BootstrapTests(unittest.TestCase):
    def setUp(self):
        self.fields={'protocol':'https','host':bootstrap.HOST}
        self.env={'AGENT_ID':'agent-infra','OPENCLAW_BW_SERVER':'https://vault.infuse-ai-tech.party','GITLAB_TOKEN':'wrong-ambient-fixture'}
        self.items=[{'name':'GitLab / agent-infra service account token','id':'fixture-item'}]
        self.username='agent-infra';self.calls=[]

    def capture(self,command,*,env=None):
        self.calls.append(command)
        if command[0]=='glab':
            self.assertEqual(env['GITLAB_TOKEN'],'fixture-vault-value')
            self.assertEqual(Path(env['GLAB_CONFIG_DIR'],'config.yml').stat().st_mode & 0o777, 0o600)
            self.assertNotIn('wrong-ambient-fixture',env.values())
            self.assertEqual(json.loads(Path(env['GLAB_CONFIG_DIR'],'config.yml').read_text().replace('hosts: {}','{"hosts":{}}')),{'hosts':{}})
            return json.dumps({'username':self.username,'state':'active'})
        self.assertEqual(command,['/usr/local/bin/openclaw-agent-secret-get'])
        self.assertEqual(env['VAULTWARDEN_ITEM_NAME'],'GitLab / agent-infra service account token')
        self.assertEqual(env['CREDENTIAL_SOURCE_FIELD'],'password')
        self.assertEqual(env['BW_HELPER'],'/usr/local/bin/bw-local-vaultwarden')
        self.assertEqual(env['DRY_RUN'],'false')
        if len(self.items) != 1: raise ValueError('provider denied ambiguous item')
        return 'fixture-vault-value\n'

    def get(self,action='get',fields=None):
        with patch.dict(os.environ,self.env,clear=True), patch.object(bootstrap,'capture',side_effect=self.capture):
            return bootstrap.credential(action,fields or self.fields)

    def test_exact_vault_item_and_verified_identity_replace_ambient_token(self):
        self.assertEqual(self.get(),'username=agent-infra\npassword=fixture-vault-value\n')

    def test_wrong_api_identity_never_returns_credentials(self):
        self.username='agent-developer'
        with self.assertRaises(ValueError): self.get()

    def test_ambiguous_item_never_reads_password(self):
        self.items*=2
        with self.assertRaises(ValueError): self.get()
        self.assertEqual(len(self.calls),1)

    def test_other_hosts_and_store_are_noops(self):
        self.assertEqual(self.get('store'),'')
        self.assertEqual(self.get(fields={'protocol':'https','host':'example.invalid'}),'')
        self.assertEqual(self.calls,[])

    def test_runtime_identity_override_is_rejected(self):
        self.env['GITLAB_AGENT_ID']='agent-developer'
        with self.assertRaises(ValueError): self.get()
        self.assertEqual(self.calls,[])

if __name__ == '__main__': unittest.main()
