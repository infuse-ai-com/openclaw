import base64
import hashlib
import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'scripts' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


operator = load('security-worker-prototype')
fixture = load('security-worker-fixture')


class WorkerBoundaryTests(unittest.TestCase):
    def test_effective_resources_have_no_persistent_or_credential_mounts(self):
        objects = operator.resources('test', 'registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:' + 'a' * 64, 'agents-swarm', 'n1.infuse-ai.com')
        policy = objects[0]['spec']
        self.assertEqual(policy['policyTypes'], ['Ingress', 'Egress'])
        self.assertEqual(policy['egress'], [])
        for job in objects[2:]:
            pod = job['spec']['template']['spec']
            self.assertEqual(job['spec']['template']['metadata']['labels'], policy['podSelector']['matchLabels'])
            self.assertFalse(pod['automountServiceAccountToken'])
            self.assertFalse(pod.get('hostNetwork', False))
            self.assertFalse(pod.get('hostPID', False))
            self.assertTrue(all('emptyDir' in v or 'configMap' in v for v in pod['volumes']))
            self.assertEqual(pod['securityContext']['runAsUser'], 10001)
            container = pod['containers'][0]
            self.assertFalse(container['securityContext']['allowPrivilegeEscalation'])
            self.assertEqual(container['securityContext']['capabilities']['drop'], ['ALL'])
            self.assertNotIn('envFrom', container)
            self.assertTrue(all('valueFrom' not in e for e in container['env']))
            self.assertEqual(job['spec']['activeDeadlineSeconds'], 300)

    def test_artifact_transport_rejects_traversal_corruption_and_oversize(self):
        data = b'{}'
        entry = {'base64': base64.b64encode(data).decode(), 'sha256': hashlib.sha256(data).hexdigest()}
        self.assertEqual(operator.decode_artifacts({'receipt.json': entry}), {'receipt.json': data})
        for payload in [
            {'receipt.json': entry, '../escape': entry},
            {'receipt.json': {**entry, 'sha256': '0' * 64}},
            {'receipt.json': {**entry, 'base64': 'A' * (2 * operator.MAX_BYTES)}},
        ]:
            with self.assertRaises(ValueError):
                operator.decode_artifacts(payload)

    def test_export_rejects_symlink_even_with_allowlisted_name(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / 'outside'
            target.write_text('synthetic secret')
            output = root / 'output'
            output.mkdir()
            (output / 'receipt.json').symlink_to(target)
            with self.assertRaises(ValueError):
                fixture.export_files(output)


if __name__ == '__main__':
    unittest.main()
