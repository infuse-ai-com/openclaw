import json
import os
import tempfile
import re
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DASHBOARD_ORIGIN = "https://agents.infuse-ai.com"
DASHBOARD_PROXY_SOURCE = "10.1.42.208"


def render() -> str:
    return subprocess.run(
        ["kubectl", "kustomize", "k8s/overlays/infuseai"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout


def documents(manifest: str) -> list[str]:
    return [document.strip() for document in re.split(r"^---\s*$", manifest, flags=re.M) if document.strip()]


def resource(manifest: str, kind: str, name: str) -> str:
    for document in documents(manifest):
        if re.search(rf"^kind: {re.escape(kind)}$", document, flags=re.M) and re.search(
            rf"^  name: {re.escape(name)}$", document, flags=re.M
        ):
            return document
    raise AssertionError(f"missing {kind}/{name}")


def agent_gateway_config(agent_id: str) -> dict:
    deployment = (ROOT / "k8s" / "agents" / agent_id / "deployment.yaml").read_text(
        encoding="utf-8"
    )
    match = re.search(
        r"name: OPENCLAW_CONFIG_JSON\n\s+value: '(?P<config>[^'\n]+)'",
        deployment,
    )
    if not match:
        raise AssertionError(f"missing OPENCLAW_CONFIG_JSON for {agent_id}")
    return json.loads(match.group("config"))


class DashboardTlsIngressTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.manifest = render()

    def test_all_five_agents_receive_private_tls_ingress(self) -> None:
        expected = {
            f"agent-{role}-dashboard-tls": (
                f"openclaw-{role}-dashboard", f"agent-{role}-dashboard"
            ) for role in ("developer", "designer", "coordinator", "intake", "infra")
        }
        tls_ingresses = [
            document
            for document in documents(self.manifest)
            if re.search(r"^kind: Ingress$", document, flags=re.M)
            and "app.kubernetes.io/component: persistent-agent-dashboard-tls" in document
        ]
        self.assertEqual(len(tls_ingresses), 5)
        for name, (hostname, service) in expected.items():
            ingress = resource(self.manifest, "Ingress", name)
            self.assertIn("ingressClassName: tailscale", ingress)
            self.assertIn("tailscale.com/proxy-group: openclaw-agent-dashboard-ingress", ingress)
            self.assertIn(f"- {hostname}", ingress)
            self.assertIn(f"name: {service}", ingress)
            self.assertIn("number: 80", ingress)

    def test_central_gateways_retire_the_incompatible_direct_l3_fallback(self) -> None:
        for name in ("agent-developer-dashboard", "agent-designer-dashboard", "agent-coordinator-dashboard", "agent-intake-dashboard", "agent-infra-dashboard"):
            service = resource(self.manifest, "Service", name)
            self.assertIn("type: ClusterIP", service)
            self.assertNotIn("loadBalancerClass: tailscale", service)
            self.assertNotIn("tailscale.com/hostname", service)
    def test_all_five_agents_grant_admin_only_to_fitos_verified_proxy_identity(self) -> None:
        dashboard_agents = {"agent-developer", "agent-designer", "agent-coordinator", "agent-intake", "agent-infra"}
        all_agents = {
            "agent-coordinator",
            "agent-designer",
            "agent-developer",
            "agent-infra",
            "agent-intake",
        }
        configured = set()
        for agent_id in all_agents:
            gateway = agent_gateway_config(agent_id)["gateway"]
            origins = gateway["controlUi"]["allowedOrigins"]
            if (
                DASHBOARD_ORIGIN in origins
                or DASHBOARD_PROXY_SOURCE in gateway.get("trustedProxies", [])
            ):
                configured.add(agent_id)
            if agent_id in dashboard_agents:
                self.assertEqual(gateway["auth"], {
                    "mode": "trusted-proxy",
                    "password": {"source": "env", "provider": "default", "id": "OPENCLAW_GATEWAY_PASSWORD"},
                    "identityScopes": {"aog.olea@gmail.com": ["operator.admin"]},
                    "trustedProxy": {
                        "userHeader": "x-forwarded-user",
                        "requiredHeaders": ["x-forwarded-proto", "x-forwarded-host"],
                        "allowUsers": ["aog.olea@gmail.com"],
                        "deviceAutoApprove": {
                            "enabled": True,
                            "scopes": [
                                "operator.sessions.read",
                                "operator.sessions.write",
                                "operator.read",
                                "operator.write",
                            ],
                        },
                    },
                })
                self.assertNotIn("roles", gateway)
                self.assertEqual(gateway["trustedProxies"], [DASHBOARD_PROXY_SOURCE])
                self.assertIn(DASHBOARD_ORIGIN, origins)
        self.assertEqual(configured, dashboard_agents)

    def test_gateway_process_uses_trusted_proxy_for_each_dashboard_agent(self) -> None:
        boot = (ROOT / "scripts/boot-agent-developer-canary.sh").read_text()
        launch = boot.split("# Launch the Gateway with the auth mode reviewed for this fleet.\n", 1)[1]
        with tempfile.TemporaryDirectory() as directory:
            stub = Path(directory) / "openclaw"
            stub.write_text("#!/bin/sh\nprintf '%s\\n' \"$@\"\n")
            stub.chmod(0o755)
            for role in ("developer", "designer", "coordinator", "intake", "infra"):
                agent = "agent-" + role
                env = {**os.environ, "PATH": directory + os.pathsep + os.environ["PATH"]}
                env.pop("OPENCLAW_GATEWAY_TOKEN", None)
                process = subprocess.run(["bash", "-eu", "-c", 'agent_id="$1"; profile="$1";\n' + launch, "test", agent],
                                         env=env, capture_output=True, text=True, check=True)
                self.assertEqual(process.stdout.splitlines(), ["--profile", agent, "gateway", "run",
                    "--auth", "trusted-proxy", "--bind", "lan", "--port", "18791", "--compact", "--allow-unconfigured"])

    def test_dashboard_agents_receive_the_private_local_password_fallback(self) -> None:
        for agent_id in ("agent-developer", "agent-designer", "agent-coordinator", "agent-intake", "agent-infra"):
            deployment = resource(self.manifest, "Deployment", agent_id)
            self.assertIn("name: OPENCLAW_GATEWAY_PASSWORD", deployment)
            self.assertNotIn("name: OPENCLAW_GATEWAY_TOKEN", deployment)
            self.assertRegex(
                deployment,
                r"name: OPENCLAW_GATEWAY_PASSWORD\s+valueFrom:\s+secretKeyRef:\s+key: OPENCLAW_GATEWAY_TOKEN\s+name: openclaw-agent-dashboard-gateway",
            )


if __name__ == "__main__":
    unittest.main()
