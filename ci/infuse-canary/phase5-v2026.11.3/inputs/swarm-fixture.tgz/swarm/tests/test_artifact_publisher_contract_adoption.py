from __future__ import annotations

import json
from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "config" / "skill-catalog.json"
BUNDLES = ROOT / "config" / "agent-skill-bundles"
DEPLOYMENTS = ROOT / "k8s" / "agents"
SKILL_ID = "mission-control-publishing"
EXPECTED_AGENTS = {
    "agent-coordinator",
    "agent-designer",
    "agent-developer",
    "agent-infra",
    "agent-intake",
}
REGISTRY_RUNTIME_NAMES = {
    "ARTIFACT_PUBLISH_MODE",
    "ARTIFACT_REGISTRY_URL",
    "ARTIFACT_REGISTRY_TOKEN_FILE",
}
REVIEWED_SOURCE_COMMIT = "910962a62c54cb0f4ec41bf59ca0bce8c4d208a0"
REVIEWED_FILES_MANIFEST_DIGEST = "a55cb2ebd27208764f5e8da23c2e54e94971231fde74e4b87ba1d521ff312235"


class ArtifactPublisherContractAdoptionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.catalog = json.loads(CATALOG.read_text(encoding="utf-8"))
        self.bundle_paths = sorted(BUNDLES.glob("*.json"))

    def test_catalog_records_reviewed_registry_adoption(self) -> None:
        skill = self.catalog["skills"][SKILL_ID]
        adoption = skill["runtime_adoption"]
        self.assertEqual(adoption["reviewed_source_commit"], REVIEWED_SOURCE_COMMIT)
        self.assertEqual(
            adoption["reviewed_files_manifest_digest"],
            REVIEWED_FILES_MANIFEST_DIGEST,
        )
        self.assertEqual(adoption["delivery_mode"], "registry")
        self.assertTrue(adoption["registry_credentials_enabled"])
        self.assertTrue(adoption["registry_writes_enabled"])
        self.assertEqual(skill["runtime_requirements"]["bins"], ["python3"])
        self.assertEqual(
            set(skill["runtime_requirements"]["env"]),
            {
                "MISSION_CONTROL_ROOT",
                "MISSION_CONTROL_AGENT_DIR",
                "ARTIFACT_PUBLISH_MODE",
                "ARTIFACT_REGISTRY_URL",
                "ARTIFACT_REGISTRY_TOKEN_FILE",
            },
        )

    def test_every_persistent_agent_receives_the_same_publisher_skill(self) -> None:
        observed_agents: set[str] = set()
        for bundle_path in self.bundle_paths:
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            agent_id = bundle["agent_id"]
            observed_agents.add(agent_id)
            self.assertIn(SKILL_ID, bundle["skills"]["installed"], bundle_path.name)
        self.assertEqual(observed_agents, EXPECTED_AGENTS)

    def test_no_persistent_deployment_activates_registry_delivery(self) -> None:
        for agent_id in EXPECTED_AGENTS:
            deployment_path = DEPLOYMENTS / agent_id / "deployment.yaml"
            deployment = deployment_path.read_text(encoding="utf-8")
            self.assertIn(SKILL_ID, deployment, deployment_path.as_posix())
            self.assertNotIn("artifact-registry", deployment.lower(), deployment_path.as_posix())
            for runtime_name in REGISTRY_RUNTIME_NAMES:
                self.assertNotRegex(
                    deployment,
                    rf"(?m)^\s*-?\s*name:\s*{re.escape(runtime_name)}\s*$",
                    deployment_path.as_posix(),
                )

    def test_no_bundle_declares_registry_credentials(self) -> None:
        forbidden = tuple(name.lower() for name in REGISTRY_RUNTIME_NAMES)
        for bundle_path in self.bundle_paths:
            serialized = bundle_path.read_text(encoding="utf-8").lower()
            for runtime_name in forbidden:
                self.assertNotIn(runtime_name, serialized, bundle_path.name)
            self.assertNotIn("artifact-registry", serialized, bundle_path.name)


if __name__ == "__main__":
    unittest.main()
