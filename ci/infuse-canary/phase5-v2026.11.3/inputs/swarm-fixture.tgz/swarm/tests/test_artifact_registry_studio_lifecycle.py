import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest import mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import provision_studio_artifact_lifecycle as lifecycle

class StudioLifecycleGrantTests(unittest.TestCase):
    def setUp(self):
        self.auth={'schema':'infuse.artifact-auth/v1','principals':{'a'*64:{'subject':'existing-reader','scopes':['read']}}}
        self.tokens={'core':'core-fixture-'+'c'*40,'studio':'studio-fixture-'+'s'*40}
    def test_exact_additive_grants_idempotence_and_no_token_disclosure(self):
        original=copy.deepcopy(self.auth);updated=lifecycle.add_principals(self.auth,self.tokens)
        self.assertEqual(self.auth,original);self.assertEqual(updated['principals']['a'*64],original['principals']['a'*64])
        self.assertEqual(lifecycle.add_principals(updated,self.tokens),updated)
        for project,token in self.tokens.items():
            self.assertEqual(updated['principals'][hashlib.sha256(token.encode()).hexdigest()]['project'],project)
            self.assertNotIn(token,json.dumps(updated));self.assertNotIn(token,json.dumps(lifecycle.plan()))
    def test_drift_duplicate_token_scope_upgrade_and_unknown_project_fail_closed(self):
        updated=lifecycle.add_principals(self.auth,self.tokens)
        for tokens in [dict(self.tokens,core='replacement-'+'r'*40),dict(self.tokens,core=self.tokens['studio']),dict(self.tokens,other='x'*40)]:
            with self.assertRaises(lifecycle.credentials.ProvisioningError):lifecycle.add_principals(updated,tokens)
        updated['principals'][hashlib.sha256(self.tokens['core'].encode()).hexdigest()]['scopes'].append('read')
        with self.assertRaises(lifecycle.credentials.ProvisioningError):lifecycle.add_principals(updated,self.tokens)
    def test_unapproved_apply_does_not_read_vault_or_cluster(self):
        with mock.patch.object(lifecycle.credentials,'preflight_kubernetes') as preflight:
            with self.assertRaises(lifecycle.credentials.ProvisioningError):lifecycle.main(['apply'])
            preflight.assert_not_called()
    def test_plan_is_offline(self):
        with mock.patch.object(lifecycle.credentials,'run_checked') as command:
            lifecycle.plan();command.assert_not_called()
    def test_existing_client_drift_prevents_all_mutations(self):
        import base64
        server={'metadata':{'resourceVersion':'17'},'data':{'auth.json':base64.b64encode(json.dumps(self.auth).encode()).decode()}}
        with mock.patch.object(lifecycle.credentials,'kube_json',return_value=server), mock.patch.object(lifecycle.credentials,'run_checked',return_value=json.dumps({'data':{'core':'wrong'}})) as command:
            with self.assertRaises(lifecycle.credentials.ProvisioningError):lifecycle.provision('fixture',self.tokens)
            self.assertEqual(command.call_count,1)
            self.assertIn('get',command.call_args.args[0])
    def test_first_activation_uses_exact_secret_and_version_checked_auth_patch(self):
        import base64
        server={'metadata':{'resourceVersion':'17'},'data':{'auth.json':base64.b64encode(json.dumps(self.auth).encode()).decode()}}
        with mock.patch.object(lifecycle.credentials,'kube_json',return_value=server), mock.patch.object(lifecycle.credentials,'run_checked',return_value='') as command, mock.patch.object(lifecycle.credentials,'wait_for_server_auth_projection'):
            result=lifecycle.provision('fixture',self.tokens)
            self.assertEqual(command.call_count,3)
            created=json.loads(command.call_args_list[1].kwargs['input_text'])
            self.assertEqual(created['metadata']['name'],'studio-artifact-lifecycle')
            self.assertEqual(set(created['stringData']),{'core','studio'})
            patch=json.loads(command.call_args_list[2].kwargs['input_text'])
            self.assertEqual(patch[0],{'op':'test','path':'/metadata/resourceVersion','value':'17'})
            auth=json.loads(base64.b64decode(patch[1]['value']))
            self.assertEqual(auth['principals']['a'*64],self.auth['principals']['a'*64])
            self.assertEqual(result['existingPrincipalsPreserved'],1)
            for token in self.tokens.values():self.assertNotIn(token,json.dumps(result))
    def test_activation_requires_reviewed_independent_image_before_any_credentials(self):
        with mock.patch.object(lifecycle.credentials,'preflight_kubernetes') as preflight:
            with self.assertRaises(lifecycle.credentials.ProvisioningError):lifecycle.main(['apply','--approved','--expected-image','registry.infuse-ai-tech.party/backoffice/backoffice:old'])
            preflight.assert_not_called()
    def test_old_ready_replica_does_not_authorize_credentials_during_rollout(self):
        image='registry.infuse-ai-tech.party/studio/artifact-registry@sha256:'+'a'*64
        deployment={'metadata':{'generation':2},'spec':{'template':{'spec':{'containers':[{'name':'registry','image':image}]}}},'status':{'observedGeneration':1,'replicas':1,'updatedReplicas':0,'readyReplicas':1,'availableReplicas':1}}
        with mock.patch.object(lifecycle.credentials,'preflight_kubernetes'), mock.patch.object(lifecycle.credentials,'kube_json',return_value=deployment), mock.patch.object(lifecycle.credentials,'load_or_create_service_client_tokens') as vault:
            with self.assertRaises(lifecycle.credentials.ProvisioningError):lifecycle.main(['apply','--approved','--expected-image',image])
            vault.assert_not_called()
    def test_legacy_reconciliation_cannot_remove_activated_clients(self):
        import base64
        active=lifecycle.add_principals(self.auth,self.tokens)
        server={'data':{'auth.json':base64.b64encode(json.dumps(active).encode()).decode()}}
        helper=str(Path(__file__).resolve().parents[1]/'scripts/provision_studio_artifact_lifecycle.py')
        with mock.patch.object(lifecycle.credentials,'preflight_kubernetes'), mock.patch.object(lifecycle.credentials.os,'access',return_value=True), mock.patch.object(lifecycle.credentials,'run_checked',return_value=json.dumps(server)), mock.patch.object(lifecycle.credentials,'load_or_create_tokens') as vault:
            with self.assertRaises(lifecycle.credentials.ProvisioningError):lifecycle.credentials.main(['finalize','--approved','--bw-helper',helper])
            vault.assert_not_called()
