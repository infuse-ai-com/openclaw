from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

from scripts import openclaw_gateway_lifecycle as lifecycle


class Clock:
    def __init__(self) -> None:
        self.seconds = 0.0
        self.epoch_ms = 1_800_000_000_000

    def monotonic(self) -> float:
        return self.seconds

    def wall_time_ms(self) -> int:
        return self.epoch_ms + int(self.seconds * 1000)

    def sleep(self, seconds: float) -> None:
        self.seconds += seconds


class FakeClient:
    def __init__(self, responses: dict[str, list[dict]]) -> None:
        self.responses = {key: list(value) for key, value in responses.items()}
        self.calls: list[tuple[str, dict | None]] = []

    def call(self, method: str, params: dict | None = None) -> dict:
        self.calls.append((method, params))
        values = self.responses.get(method, [])
        if not values:
            raise AssertionError(f"unexpected call: {method}")
        value = values.pop(0)
        if isinstance(value, Exception):
            raise value
        return value


def identity() -> dict:
    return {"pid": 7, "processInstanceId": "process-1"}


class OpenClawGatewayLifecycleTests(unittest.TestCase):
    def test_state_path_honors_explicit_lifecycle_path(self) -> None:
        with mock.patch.dict(
            lifecycle.os.environ,
            {"OPENCLAW_LIFECYCLE_STATE_FILE": "/run/openclaw/lifecycle.json"},
            clear=True,
        ):
            self.assertEqual(Path("/run/openclaw/lifecycle.json"), lifecycle.state_path())

    def test_state_path_defaults_to_private_user_state_directory(self) -> None:
        with (
            mock.patch.dict(lifecycle.os.environ, {}, clear=True),
            mock.patch.object(lifecycle.Path, "home", return_value=Path("/home/openclaw")),
        ):
            self.assertEqual(
                Path("/home/openclaw/.local/state/openclaw/gateway-lifecycle.json"),
                lifecycle.state_path(),
            )

    def test_state_path_honors_xdg_state_home(self) -> None:
        with mock.patch.dict(
            lifecycle.os.environ,
            {"XDG_STATE_HOME": "/var/lib/openclaw-state"},
            clear=True,
        ):
            self.assertEqual(
                Path("/var/lib/openclaw-state/openclaw/gateway-lifecycle.json"),
                lifecycle.state_path(),
            )

    def run_prepare(
        self,
        client: FakeClient,
        *,
        drain_seconds: int = 60,
        force_handoff: bool = False,
        arm_handoff: bool = False,
    ) -> tuple[dict, int, dict]:
        clock = Clock()
        with tempfile.TemporaryDirectory() as temporary:
            state_file = Path(temporary) / "state.json"
            result, exit_code = lifecycle.prepare_gateway(
                client,
                request_id="k8s-stop:pod-1",
                drain_seconds=drain_seconds,
                force_handoff=force_handoff,
                arm_handoff=arm_handoff,
                lifecycle_state_path=state_file,
                sleep=clock.sleep,
                monotonic=clock.monotonic,
                wall_time_ms=clock.wall_time_ms,
            )
            state = json.loads(state_file.read_text(encoding="utf-8"))
        return result, exit_code, state

    def test_immediate_ready_can_arm_exact_predecessor(self) -> None:
        client = FakeClient(
            {
                "system.info": [identity()],
                "gateway.suspend.prepare": [
                    {
                        "status": "ready",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                    }
                ],
                "gateway.suspend.handoff": [
                    {"status": "armed", "suspensionId": "lease-1", "expiresAtMs": 1_800_000_120_000}
                ],
            }
        )
        result, exit_code, state = self.run_prepare(client, arm_handoff=True)
        self.assertEqual(
            [{"suspensionId": "lease-1", "target": identity()}],
            [params for method, params in client.calls if method == "gateway.suspend.handoff"],
        )
        self.assertEqual(("armed", 0, "armed"), (result["status"], exit_code, state["phase"]))

    def test_immediate_ready_records_exact_gateway_identity(self) -> None:
        client = FakeClient(
            {
                "system.info": [identity()],
                "gateway.suspend.prepare": [
                    {
                        "status": "ready",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                    }
                ],
            }
        )
        result, exit_code, state = self.run_prepare(client)
        self.assertEqual(0, exit_code)
        self.assertEqual("ready", result["status"])
        self.assertEqual(identity(), result["target"])
        self.assertEqual("ready", state["phase"])

    def test_draining_polls_until_ready(self) -> None:
        client = FakeClient(
            {
                "system.info": [identity()],
                "gateway.suspend.prepare": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                        "retryAfterMs": 1_000,
                    }
                ],
                "gateway.suspend.status": [
                    {
                        "status": "ready",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                    }
                ],
            }
        )
        result, exit_code, state = self.run_prepare(client)
        self.assertEqual(("ready", 0, "ready"), (result["status"], exit_code, state["phase"]))

    def test_renews_same_lease_before_expiry(self) -> None:
        client = FakeClient(
            {
                "system.info": [identity()],
                "gateway.suspend.prepare": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_020_000,
                        "retryAfterMs": 1_000,
                    },
                    {
                        "status": "ready",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_140_000,
                    },
                ],
            }
        )
        result, exit_code, _ = self.run_prepare(client)
        prepares = [params for method, params in client.calls if method == "gateway.suspend.prepare"]
        self.assertEqual(2, len(prepares))
        self.assertEqual(prepares[0], prepares[1])
        self.assertEqual(("ready", 0), (result["status"], exit_code))

    def test_normal_timeout_resumes_and_returns_bounded_failure(self) -> None:
        client = FakeClient(
            {
                "system.info": [identity()],
                "gateway.suspend.prepare": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                        "retryAfterMs": 1_000,
                    }
                ],
                "gateway.suspend.status": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                        "retryAfterMs": 1_000,
                    }
                ],
                "gateway.suspend.resume": [{"ok": True, "status": "running", "resumed": True}],
            }
        )
        result, exit_code, state = self.run_prepare(client, drain_seconds=1)
        self.assertEqual(lifecycle.EXIT_DRAIN_TIMEOUT, exit_code)
        self.assertEqual("drain_timeout", result["status"])
        self.assertEqual("resumed", state["phase"])

    def test_forced_timeout_arms_exact_predecessor(self) -> None:
        client = FakeClient(
            {
                "system.info": [identity()],
                "gateway.suspend.prepare": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                        "retryAfterMs": 1_000,
                    }
                ],
                "gateway.suspend.status": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                        "retryAfterMs": 1_000,
                    }
                ],
                "gateway.suspend.handoff": [
                    {"status": "armed", "suspensionId": "lease-1", "expiresAtMs": 1_800_000_120_000}
                ],
            }
        )
        result, exit_code, state = self.run_prepare(client, drain_seconds=1, force_handoff=True)
        handoff = [params for method, params in client.calls if method == "gateway.suspend.handoff"]
        self.assertEqual([{"suspensionId": "lease-1", "target": identity()}], handoff)
        self.assertEqual(("armed", 0, "armed"), (result["status"], exit_code, state["phase"]))

    def test_failed_controller_handoff_reopens_admission(self) -> None:
        client = FakeClient(
            {
                "system.info": [identity()],
                "gateway.suspend.prepare": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                        "retryAfterMs": 1_000,
                    }
                ],
                "gateway.suspend.status": [
                    {
                        "status": "draining",
                        "suspensionId": "lease-1",
                        "expiresAtMs": 1_800_000_120_000,
                        "retryAfterMs": 1_000,
                    }
                ],
                "gateway.suspend.handoff": [
                    lifecycle.LifecycleError("gateway_handoff_refused", "refused")
                ],
                "gateway.suspend.resume": [{"ok": True, "status": "running", "resumed": True}],
            }
        )
        clock = Clock()
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(lifecycle.LifecycleError, "refused"):
                lifecycle.prepare_gateway(
                    client,
                    request_id="k8s-stop:pod-1",
                    drain_seconds=1,
                    force_handoff=True,
                    lifecycle_state_path=Path(temporary) / "state.json",
                    sleep=clock.sleep,
                    monotonic=clock.monotonic,
                    wall_time_ms=clock.wall_time_ms,
                )
        self.assertIn("gateway.suspend.resume", [method for method, _ in client.calls])

    def test_prestop_reuses_an_already_armed_handoff(self) -> None:
        client = FakeClient(
            {
                "gateway.suspend.status": [
                    {"status": "armed", "suspensionId": "lease-1", "expiresAtMs": 1_800_000_120_000}
                ]
            }
        )
        with tempfile.TemporaryDirectory() as temporary:
            state_file = Path(temporary) / "state.json"
            lifecycle.write_state(
                state_file,
                {
                    "requestId": "k8s-stop:pod-1",
                    "suspensionId": "lease-1",
                    "phase": "armed",
                    "target": identity(),
                },
            )
            result, exit_code = lifecycle.command_prestop(
                SimpleNamespace(request_id="k8s-stop:pod-1", drain_seconds=300),
                client,
                state_file,
            )
        self.assertEqual(("armed", 0), (result["status"], exit_code))
        self.assertEqual(["gateway.suspend.status"], [method for method, _ in client.calls])

    def test_prestop_arms_a_controller_ready_handoff(self) -> None:
        client = FakeClient(
            {
                "gateway.suspend.status": [
                    {"status": "ready", "suspensionId": "lease-1", "expiresAtMs": 1_800_000_120_000}
                ],
                "gateway.suspend.handoff": [
                    {"status": "armed", "suspensionId": "lease-1", "expiresAtMs": 1_800_000_120_000}
                ],
            }
        )
        with tempfile.TemporaryDirectory() as temporary:
            state_file = Path(temporary) / "state.json"
            lifecycle.write_state(
                state_file,
                {
                    "requestId": "k8s-stop:pod-1",
                    "suspensionId": "lease-1",
                    "phase": "ready",
                    "target": identity(),
                },
            )
            result, exit_code = lifecycle.command_prestop(
                SimpleNamespace(request_id="k8s-stop:pod-1", drain_seconds=300),
                client,
                state_file,
            )
            state = json.loads(state_file.read_text(encoding="utf-8"))
        self.assertEqual(("armed", 0, "armed"), (result["status"], exit_code, state["phase"]))
        self.assertEqual(
            ["gateway.suspend.status", "gateway.suspend.handoff"],
            [method for method, _ in client.calls],
        )


if __name__ == "__main__":
    unittest.main()
