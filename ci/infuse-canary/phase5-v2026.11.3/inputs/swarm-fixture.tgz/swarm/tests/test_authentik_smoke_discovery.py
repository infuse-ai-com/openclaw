from __future__ import annotations

import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class AuthentikSmokeDiscoveryTests(unittest.TestCase):
    def test_runtime_catalog_frontloads_authentik_login_triggers(self) -> None:
        catalog = json.loads((ROOT / "config" / "skill-catalog.json").read_text(encoding="utf-8"))
        summary = catalog["skills"]["playwright-browser-evidence"]["summary"]
        prefix = summary[:80].lower()

        self.assertIn("authentik", prefix)
        self.assertIn("login", prefix)
        self.assertIn("authenticated", prefix)


if __name__ == "__main__":
    unittest.main()
