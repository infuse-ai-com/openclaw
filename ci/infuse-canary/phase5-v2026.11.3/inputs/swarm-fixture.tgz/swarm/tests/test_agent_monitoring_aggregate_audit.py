import copy
import importlib.util
import json
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "audit-agent-monitoring-aggregates.py"
CONTRACT = ROOT / "config" / "observability" / "telemetry-contract.v1.json"
BASELINE = (
    ROOT
    / "config"
    / "observability"
    / "baselines"
    / "agent-monitoring-dogfood-2026-08-31.json"
)

SPEC = importlib.util.spec_from_file_location("agent_monitoring_audit", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class AgentMonitoringAggregateAuditTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.snapshot = json.loads(BASELINE.read_text(encoding="utf-8"))

    def test_frozen_baseline_reproduces_truth_discrepancies(self) -> None:
        report = MODULE.build_report(self.snapshot, self.contract)
        MODULE.assert_frozen_baseline(report)
        self.assertEqual(report["canonicalTruth"]["run"]["failures"], 30)
        self.assertEqual(report["curatedDrilldown"]["turn"]["failures"], 4)
        self.assertEqual(report["canonicalTruth"]["tool"]["failures"], 63)
        self.assertEqual(report["curatedDrilldown"]["tool"]["failures"], 2)
        self.assertEqual(
            report["disagreement"]["officialMinusCuratedRunFailures"], 26
        )
        self.assertEqual(
            report["disagreement"]["officialMinusCuratedToolFailures"], 61
        )
        self.assertEqual(report["traceIntegrity"]["missingParentRatePct"], 100.0)

    def test_frozen_baseline_has_exact_fleet_and_revision_segments(self) -> None:
        report = MODULE.build_report(self.snapshot, self.contract)
        self.assertEqual(len(report["provenance"]["agents"]), 5)
        self.assertEqual(len(report["provenance"]["containerImageRevisions"]), 1)
        self.assertEqual(len(report["provenance"]["openclawRuntimeRevisions"]), 1)
        self.assertEqual(report["provenance"]["skillBundleRevisions"], ["unavailable"])
        self.assertEqual(report["provenance"]["trafficSources"], ["unavailable"])
        self.assertIn("official_run_counts_by_agent", report["segmentationGaps"])
        self.assertIn("skill_bundle_revision", report["segmentationGaps"])
        self.assertIn("traffic_source", report["segmentationGaps"])

    def test_curated_signal_cannot_replace_official_truth(self) -> None:
        mutated = copy.deepcopy(self.snapshot)
        mutated["signals"]["officialRun"] = "infuse.agent.turn"
        with self.assertRaisesRegex(
            MODULE.AuditError, "signal identities disagree"
        ):
            MODULE.build_report(mutated, self.contract)

    def test_content_shaped_fields_and_values_are_rejected(self) -> None:
        mutated = copy.deepcopy(self.snapshot)
        mutated["aggregates"]["prompt"] = "not allowed"
        with self.assertRaisesRegex(MODULE.AuditError, "forbidden field name"):
            MODULE.build_report(mutated, self.contract)

        mutated = copy.deepcopy(self.snapshot)
        mutated["scope"]["rolloutBoundary"] = "/workspace/private"
        with self.assertRaisesRegex(MODULE.AuditError, "forbidden value shape"):
            MODULE.build_report(mutated, self.contract)

    def test_cross_revision_segment_is_rejected(self) -> None:
        mutated = copy.deepcopy(self.snapshot)
        mutated["segments"][0]["containerImageRevision"] = "sha256:" + "a" * 64
        with self.assertRaisesRegex(MODULE.AuditError, "crosses the declared scope"):
            MODULE.build_report(mutated, self.contract)

    def test_cli_emits_json_and_asserts_the_frozen_baseline(self) -> None:
        completed = subprocess.run(
            [
                sys.executable,
                str(SCRIPT),
                "--input",
                str(BASELINE),
                "--contract",
                str(CONTRACT),
                "--assert-frozen-baseline",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        report = json.loads(completed.stdout)
        self.assertTrue(report["privacy"]["aggregateOnly"])
        self.assertEqual(report["privacy"]["forbiddenContentMatches"], 0)


if __name__ == "__main__":
    unittest.main()
