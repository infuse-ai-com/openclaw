# MEMORY.md for __AGENT_NAME__

This is a CI fixture memory file.
