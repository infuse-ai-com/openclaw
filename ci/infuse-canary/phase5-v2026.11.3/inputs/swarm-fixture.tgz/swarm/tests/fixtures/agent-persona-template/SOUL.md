# SOUL.md for __AGENT_NAME__

Fixture soul file for installer smoke checks.
