# AGENTS.md for __AGENT_NAME__

Agent id: __AGENT_ID__
Role: __AGENT_ROLE__
Coordinator: __AGENT_COORDINATOR__
Mattermost channel: __MATTERMOST_CHANNEL__
