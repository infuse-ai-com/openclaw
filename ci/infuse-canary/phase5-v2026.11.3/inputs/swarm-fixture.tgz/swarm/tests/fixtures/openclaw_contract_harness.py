#!/usr/bin/env python3
"""Stateful, hermetic OpenClaw CLI boundary for SQL Mission Control tests."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys
from typing import Any


def fail(code: str) -> None:
    print(code, file=sys.stderr)
    raise SystemExit(2)


def option(arguments: list[str], name: str) -> str:
    try:
        index = arguments.index(name)
        value = arguments[index + 1]
    except (ValueError, IndexError):
        fail(f"missing_{name.removeprefix('--').replace('-', '_')}")
    return value


def load(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"sessions": [], "tickets": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("sessions"), list) or not isinstance(value.get("tickets"), dict):
        fail("state_invalid")
    return value


def save(path: Path, value: dict[str, Any]) -> None:
    path.write_text(json.dumps(value, sort_keys=True, separators=(",", ":")), encoding="utf-8")


def append_log(path: Path, value: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n")


def main() -> int:
    state_path_value = os.environ.get("OPENCLAW_CONTRACT_STATE", "")
    log_path_value = os.environ.get("OPENCLAW_CONTRACT_LOG", "")
    expected_url = os.environ.get("OPENCLAW_CONTRACT_EXPECTED_URL", "")
    if not state_path_value or not log_path_value or not expected_url:
        fail("contract_environment_missing")
    if os.environ.get("OPENCLAW_GATEWAY_URL") != expected_url:
        fail("gateway_url_mismatch")

    arguments = sys.argv[1:]
    profile = None
    if arguments[:1] == ["--profile"]:
        if len(arguments) < 3:
            fail("profile_invalid")
        profile = arguments[1]
        arguments = arguments[2:]
    if "--token" in arguments or "--url" in arguments:
        fail("credential_or_url_in_argv")

    state_path = Path(state_path_value)
    log_path = Path(log_path_value)
    state = load(state_path)
    record: dict[str, Any] = {"argv": arguments, "profile": profile}

    if arguments[:2] == ["gateway", "call"]:
        if len(arguments) < 3:
            fail("gateway_method_missing")
        method = arguments[2]
        try:
            params = json.loads(option(arguments, "--params"))
        except json.JSONDecodeError:
            fail("gateway_params_invalid")
        record.update({"kind": "gateway", "method": method, "params": params})
        if method == "sessions.list":
            if set(params) != {"agentId", "limit", "search"}:
                fail("sessions_list_contract_invalid")
            matches = [
                item
                for item in state["sessions"]
                if item.get("agentId") == params["agentId"] and item.get("key") == params["search"]
            ]
            response = {"sessions": matches[: params["limit"]]}
        elif method == "sessions.create":
            if set(params) != {"key", "idempotencyKey", "agentId", "task"} or params.get("agentId") != "agent-coordinator":
                fail("sessions_create_contract_invalid")
            matches = [item for item in state["sessions"] if item.get("key") == params["key"]]
            if matches:
                fail("sessions_create_duplicate")
            sequence = len(state["sessions"]) + 1
            session_id = f"contract-session-{sequence:04d}"
            run_id = f"contract-run-{sequence:04d}"
            state["sessions"].append(
                {
                    "key": params["key"],
                    "agentId": params["agentId"],
                    "sessionId": session_id,
                    "status": "running",
                    "hasActiveRun": True,
                    "lastRunId": run_id,
                }
            )
            save(state_path, state)
            response = {
                "ok": True,
                "key": params["key"],
                "sessionId": session_id,
                "runStarted": True,
                "runId": run_id,
            }
        else:
            fail("gateway_method_unsupported")
    elif arguments[:2] == ["system", "wake-status"]:
        selector = option(arguments, "--idempotency-key") if "--idempotency-key" in arguments else option(arguments, "--ticket-id")
        record.update({"kind": "wake_status", "selector": selector})
        response = {"ticket": state["tickets"].get(selector)}
    elif arguments[:2] == ["system", "event"]:
        session_key = option(arguments, "--session-key")
        idempotency_key = option(arguments, "--idempotency-key")
        if option(arguments, "--mode") != "now" or not option(arguments, "--text"):
            fail("system_event_contract_invalid")
        if not any(item.get("key") == session_key for item in state["sessions"]):
            fail("system_event_session_missing")
        ticket = state["tickets"].get(idempotency_key)
        if ticket is None:
            sequence = len(state["tickets"]) + 1
            ticket = {
                "ticketId": f"contract-ticket-{sequence:04d}",
                "agentId": "agent-coordinator",
                "sessionKey": session_key,
                "status": "started",
                "runId": f"contract-wake-run-{sequence:04d}",
            }
            state["tickets"][idempotency_key] = ticket
            state["tickets"][ticket["ticketId"]] = ticket
            save(state_path, state)
        record.update({"kind": "system_event", "sessionKey": session_key, "idempotencyKey": idempotency_key})
        response = {"ticket": ticket}
    else:
        fail("command_unsupported")

    append_log(log_path, record)
    print(json.dumps(response, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
