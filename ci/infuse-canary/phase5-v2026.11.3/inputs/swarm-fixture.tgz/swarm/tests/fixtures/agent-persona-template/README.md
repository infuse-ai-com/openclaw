# Persona Template Fixture

This minimal persona template exists so `task verify-agent-persona` can run in CI
without a sibling `openclaw-agents-persona` checkout.
