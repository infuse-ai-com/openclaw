# IDENTITY.md for __AGENT_NAME__

- Agent id: __AGENT_ID__
- Role: __AGENT_ROLE__
