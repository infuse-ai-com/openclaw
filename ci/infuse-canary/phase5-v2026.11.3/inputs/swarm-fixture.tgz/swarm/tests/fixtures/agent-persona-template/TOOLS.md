# TOOLS.md for __AGENT_NAME__

Fixture tools file for installer smoke checks.
