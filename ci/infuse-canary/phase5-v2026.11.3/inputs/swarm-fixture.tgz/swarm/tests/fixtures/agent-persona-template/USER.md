# USER.md for __AGENT_NAME__

Fixture user file for installer smoke checks.
