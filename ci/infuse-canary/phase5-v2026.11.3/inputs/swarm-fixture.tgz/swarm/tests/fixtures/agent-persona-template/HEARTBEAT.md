# HEARTBEAT.md for __AGENT_NAME__

Use this fixture only for CI dry-run persona installation checks.
