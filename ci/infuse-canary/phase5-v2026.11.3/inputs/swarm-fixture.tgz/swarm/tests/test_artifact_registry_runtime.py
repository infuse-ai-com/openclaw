from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "artifact-registry-runtime.v1.json"
BASE = ROOT / "k8s" / "platform" / "artifact-registry"
PRODUCERS = BASE / "producers"
SERVER_DRY_RUN = ROOT / "k8s" / "platform" / "artifact-registry-server-dry-run"
RECOVERY = ROOT / "k8s" / "platform" / "artifact-registry-recovery"
RECOVERY_SERVER_DRY_RUN = ROOT / "k8s" / "platform" / "artifact-registry-recovery-server-dry-run"
PRODUCTION_OVERLAY = ROOT / "k8s" / "overlays" / "infuseai" / "kustomization.yaml"
EXPECTED_AGENTS = {
    "kapiteky",
    "agent-coordinator",
    "agent-designer",
    "agent-developer",
    "agent-infra",
    "agent-intake",
}
EXPECTED_KUBERNETES_AGENTS = EXPECTED_AGENTS - {"kapiteky"}
CANARY = ROOT / "k8s" / "platform" / "artifact-registry-canary"
CANARY_VERIFIER = ROOT / "k8s" / "platform" / "artifact-registry-canary-verifier"
KAPITEKY_PUBLISHER = ROOT / "scripts" / "publish-kapiteky-artifact-registry.sh"


def render(path: Path) -> str:
    return subprocess.run(
        ["kubectl", "kustomize", str(path)],
        check=True,
        text=True,
        capture_output=True,
    ).stdout


class ArtifactRegistryRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = json.loads(CONFIG.read_text(encoding="utf-8"))
        cls.runtime = render(BASE)
        cls.producers = render(PRODUCERS)
        cls.server_dry_run = render(SERVER_DRY_RUN)
        cls.recovery = render(RECOVERY)
        cls.recovery_server_dry_run = render(RECOVERY_SERVER_DRY_RUN)
        cls.canary = render(CANARY)
        cls.canary_verifier = render(CANARY_VERIFIER)
        cls.kapiteky_publisher = KAPITEKY_PUBLISHER.read_text(encoding="utf-8")

    def test_image_release_cannot_mutate_claims_agents_or_recovery(self):
        release = render(ROOT / "k8s/platform/artifact-registry-release")
        self.assertNotRegex(release, r"(?m)^kind: (PersistentVolumeClaim|Role|RoleBinding|Job|Ingress|IngressRoute)$")
        self.assertEqual(release.count("kind: Deployment"), 2)
        self.assertIn("name: artifact-image-scanner", release)
        self.assertIn("secretName: studio-whiteboard-storage", release)
        self.assertIn("runAsUser: 1000", release)
        self.assertNotIn("name: agent-", release)
        images = (BASE / "images-configmap.yaml").read_text()
        self.assertIn("studio-dev-images", images)
        self.assertIn("studio-dev-intake", images)

    def test_typed_runtime_contract_is_exact_and_disabled(self) -> None:
        self.assertEqual(self.config["schema"], "infuse.artifact-registry-runtime/v1")
        self.assertTrue(self.config["enabled"])
        self.assertEqual(self.config["namespace"], "core")
        self.assertEqual(self.config["service"]["port"], 3010)
        self.assertRegex(self.config["image"]["source_revision"], r"^[a-f0-9]{40}$")
        self.assertRegex(self.config["image"]["digest"], r"^sha256:[a-f0-9]{64}$")
        self.assertEqual(self.config["image"]["build_id"], 10091)
        self.assertEqual(self.config["image"]["tag"], "20261020.3")
        self.assertEqual(
            self.config["storage"]["recovery"],
            {
                "method": "offline-file-bundle",
                "source_quiescence_required": True,
                "backup_transfer_pvc": "backoffice-artifact-registry-backup-transfer",
                "backup_transfer_mount_path": "/var/lib/artifact-registry-backups",
                "backup_transfer_size": "50Gi",
                "restore_target_pvc": "backoffice-artifact-registry-restore-target",
                "restore_target_mount_path": "/var/lib/artifact-registry-restore",
                "restore_target_size": "20Gi",
                "off_node_copy_required": True,
                "automatic_retention": False,
                "capacity_warning_percent": 70,
                "capacity_block_percent": 85,
            },
        )
        self.assertEqual({item["agent_id"] for item in self.config["producers"]}, EXPECTED_AGENTS)
        for producer in self.config["producers"]:
            self.assertEqual(producer["delivery_mode"], "registry")
            self.assertTrue(producer["credentials_provisioned"])
            self.assertTrue(producer["writes_enabled"])
        self.assertEqual(
            self.config["activation"],
            {
                "base_in_production_overlay": False,
                "producer_overlay_in_production_overlay": True,
                "clean_start_cutover_approved": True,
                "legacy_feed_retained_for_cutover": False,
                "public_route": False,
                "canary_runtime_overlay": "k8s/platform/artifact-registry-canary",
                "canary_verifier_overlay": "k8s/platform/artifact-registry-canary-verifier",
            },
        )

    def test_runtime_render_pins_image_and_separates_live_from_ready(self) -> None:
        image = self.config["image"]
        self.assertIn(f"image: {image['repository']}@{image['digest']}", self.runtime)
        self.assertIn(f"infuse.ai/backoffice-build-id: \"{image['build_id']}\"", self.runtime)
        self.assertIn("path: /live", self.runtime)
        self.assertIn("path: /ready", self.runtime)
        self.assertNotIn("REPLACE_WITH_REVIEWED_TAG", self.runtime)
        self.assertIn("readOnlyRootFilesystem: true", self.runtime)
        self.assertIn("automountServiceAccountToken: false", self.runtime)
        self.assertIn("name: harbor-pull", self.runtime)
        self.assertIn("name: backoffice-artifact-registry-config-v1", self.runtime)
        self.assertIn("secretName: backoffice-artifact-registry-auth", self.runtime)
        self.assertIn("key: auth.json", self.runtime)
        self.assertNotRegex(self.runtime, r"(?m)^kind: (Ingress|IngressRoute)$")

    def test_network_policy_limits_producer_ingress_to_the_five_agents(self) -> None:
        for agent_id in EXPECTED_KUBERNETES_AGENTS:
            self.assertIn(f"- {agent_id}", self.runtime)
        self.assertIn("kubernetes.io/metadata.name: core", self.runtime)
        self.assertIn("kubernetes.io/metadata.name: agents-swarm", self.runtime)
        self.assertIn("port: 8333", self.runtime)
        self.assertIn("port: 3310", self.runtime)

    def test_studio_reader_ingress_requires_both_namespace_and_workload(self) -> None:
        policy = (BASE / "networkpolicy.yaml").read_text()
        studio_peer = """        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: core
          podSelector:
            matchLabels:
              app.kubernetes.io/name: studio"""
        self.assertIn(studio_peer, policy)
        self.assertIn("port: 3010", policy)
        self.assertEqual(self.config["authentication"]["studio_client_secret"], "studio-artifact-registry")
        self.assertEqual(self.config["authentication"]["studio_reader_key"], "token")

    def test_retired_backoffice_has_no_registry_network_peer(self) -> None:
        policy = (BASE / "networkpolicy.yaml").read_text()
        self.assertNotIn("app.kubernetes.io/name: backoffice\n", policy)
        self.assertIn("app.kubernetes.io/name: studio\n", policy)

    def test_producer_overlay_mounts_unique_token_files_and_selects_registry(self) -> None:
        self.assertEqual(len(re.findall(r"(?m)^kind: Deployment$", self.producers)), 5)
        for producer in [item for item in self.config["producers"] if item["agent_id"] != "kapiteky"]:
            self.assertIn(f"name: {producer['agent_id']}", self.producers)
            self.assertIn(f"secretName: {producer['secret']}", self.producers)
        self.assertEqual(self.producers.count("name: ARTIFACT_REGISTRY_TOKEN_FILE"), 5)
        self.assertEqual(self.producers.count("name: ARTIFACT_REGISTRY_URL"), 5)
        self.assertEqual(self.producers.count("name: ARTIFACT_PUBLISH_MODE"), 5)
        self.assertEqual(self.producers.count("value: registry"), 5)
        self.assertEqual(self.producers.count("mountPath: /var/run/openclaw-agent/tokens/artifact-registry/token"), 5)
        self.assertEqual(self.producers.count("subPath: token"), 5)
        self.assertNotRegex(self.producers, r"(?m)^\s*value: (feed|dual)\s*$")

    def test_kapiteky_publisher_uses_an_isolated_short_lived_pod(self) -> None:
        self.assertIn("automountServiceAccountToken: false", self.kapiteky_publisher)
        self.assertIn("subPath: \"token\"", self.kapiteky_publisher)
        self.assertIn("kubectl --context \"$kube_context\" create -f -", self.kapiteky_publisher)
        self.assertIn("journal.json journal.html", self.kapiteky_publisher)
        self.assertNotIn("port-forward", self.kapiteky_publisher)
        self.assertNotIn('tar -C "${agent_dir%/*}" -cf - kapiteky', self.kapiteky_publisher)

    def test_t5_1_canary_is_internal_additive_and_verifier_is_suspended(self) -> None:
        self.assertEqual(len(re.findall(r"(?m)^kind: NetworkPolicy$", self.canary)), 2)
        self.assertIn('infuse.ai/artifact-registry-canary-verifier: "true"', self.canary)
        self.assertIn("kubernetes.io/metadata.name: agents-swarm", self.canary)
        self.assertIn("name: backoffice-artifact-registry", self.canary)
        self.assertNotRegex(self.canary, r"(?m)^kind: (Ingress|IngressRoute)$")
        self.assertEqual(len(re.findall(r"(?m)^kind: Job$", self.canary_verifier)), 2)
        self.assertEqual(self.canary_verifier.count("suspend: true"), 2)
        self.assertEqual(self.canary_verifier.count("automountServiceAccountToken: false"), 2)
        self.assertEqual(self.canary_verifier.count("fsGroup: 1001"), 2)
        self.assertIn("name: backoffice-artifact-registry-canary-verifier", self.canary_verifier)
        self.assertIn("name: backoffice-artifact-registry-network-denied", self.canary_verifier)
        self.assertIn("value: replace-before-unsuspend", self.canary_verifier)
        self.assertIn("artifact-registry-kapiteky", self.canary_verifier)
        for agent_id in EXPECTED_KUBERNETES_AGENTS:
            self.assertIn(f"artifact-registry-{agent_id}", self.canary_verifier)
        self.assertIn("artifact-registry-canary-client", self.canary_verifier)
        self.assertEqual(
            self.canary_verifier.count("registry.infuse-ai-tech.party/backoffice/backoffice@sha256:613b7d8fc4ee4ddce4b9bf6341bfb2fef684dd61a7f3bb66b1e98c5f4623ea3b"),
            2,
        )

    def test_registry_producer_mounts_and_production_capability_readers_are_explicit(self) -> None:
        production = PRODUCTION_OVERLAY.read_text(encoding="utf-8")
        self.assertNotIn("../artifact-registry\n", production)
        self.assertIn("../../components/artifact-registry-producer-mounts", production)
        production_render = render(PRODUCTION_OVERLAY.parent)
        self.assertEqual(production_render.count("name: ARTIFACT_REGISTRY_TOKEN_FILE"), 5)
        self.assertEqual(production_render.count("name: ARTIFACT_REGISTRY_URL"), 5)
        self.assertEqual(production_render.count("name: ARTIFACT_PUBLISH_MODE"), 5)
        self.assertEqual(production_render.count("value: registry"), 5)
        self.assertNotRegex(production_render, r"(?m)^\s*value: (feed|dual)\s*$")
        self.assertIn("namespace: agents-swarm", self.server_dry_run)
        self.assertIn("name: artifact-registry-dry-run-backoffice-artifact-registry", self.server_dry_run)

    def test_recovery_templates_are_suspended_isolated_and_separate(self) -> None:
        image = self.config["image"]
        self.assertEqual(len(re.findall(r"(?m)^kind: Job$", self.recovery)), 2)
        self.assertEqual(self.recovery.count("suspend: true"), 2)
        self.assertEqual(self.recovery.count("activeDeadlineSeconds: 1800"), 2)
        self.assertEqual(self.recovery.count("image: REPLACE_WITH_DEPLOYED_REGISTRY_IMAGE"), 2)
        self.assertNotIn("backoffice/backoffice@", self.recovery)
        self.assertNotIn("REPLACE_WITH_REVIEWED_TAG", self.recovery)
        self.assertEqual(self.recovery.count("REPLACE_WITH_REVIEWED_BACKUP_ID"), 2)
        self.assertEqual(self.recovery.count("automountServiceAccountToken: false"), 2)
        self.assertEqual(self.recovery.count("readOnlyRootFilesystem: true"), 2)
        self.assertIn("command:\n        - node\n        - /app/artifact-registry-recovery.cjs\n        - create", self.recovery)
        self.assertIn("command:\n        - node\n        - /app/artifact-registry-recovery.cjs\n        - restore", self.recovery)
        self.assertIn("claimName: backoffice-artifact-registry", self.recovery)
        self.assertIn("claimName: backoffice-artifact-registry-backup-transfer", self.recovery)
        self.assertIn("claimName: backoffice-artifact-registry-restore-target", self.recovery)
        self.assertIn("readOnly: true", self.recovery)
        self.assertIn("storage: 50Gi", self.recovery)
        self.assertIn("storage: 20Gi", self.recovery)
        self.assertEqual(self.recovery.count("storageClassName: microk8s-hostpath"), 2)
        self.assertIn("infuse.ai/recovery-role: transfer-only-not-disaster-recovery", self.recovery)
        self.assertIn("ingress: []", self.recovery)
        self.assertIn("egress: []", self.recovery)
        self.assertEqual(len(re.findall(r"(?m)^kind: Role$", self.recovery)), 1)
        self.assertEqual(len(re.findall(r"(?m)^kind: RoleBinding$", self.recovery)), 1)
        self.assertIn("name: artifact-registry-recovery-policy-reader", self.recovery)
        self.assertIn("resourceNames:\n  - backoffice-artifact-registry-recovery-deny-all", self.recovery)
        self.assertIn("verbs:\n  - get", self.recovery)
        self.assertIn("name: kapiteky-cluster-operator", self.recovery)
        self.assertIn("namespace: platform-operators", self.recovery)
        self.assertNotIn("artifact-registry-recovery", PRODUCTION_OVERLAY.read_text(encoding="utf-8"))

    def test_recovery_server_dry_run_is_prefixed_and_non_executing(self) -> None:
        self.assertIn("namespace: agents-swarm", self.recovery_server_dry_run)
        self.assertIn("name: ar-recovery-dry-backoffice-artifact-registry-backup-template", self.recovery_server_dry_run)
        self.assertIn("name: ar-recovery-dry-backoffice-artifact-registry-restore-template", self.recovery_server_dry_run)
        self.assertEqual(self.recovery_server_dry_run.count("suspend: true"), 2)
        self.assertEqual(len(re.findall(r"(?m)^kind: Role$", self.recovery_server_dry_run)), 1)
        self.assertNotRegex(self.recovery_server_dry_run, r"(?m)^kind: RoleBinding$")


if __name__ == "__main__":
    unittest.main()
