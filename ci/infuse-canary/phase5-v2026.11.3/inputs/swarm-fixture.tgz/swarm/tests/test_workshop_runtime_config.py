from __future__ import annotations

import importlib.util
from pathlib import Path
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
VALIDATOR_PATH = ROOT / "scripts" / "verify-agent-skill-bundles.py"
SPEC = importlib.util.spec_from_file_location("workshop_config_validator", VALIDATOR_PATH)
assert SPEC is not None and SPEC.loader is not None
VALIDATOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VALIDATOR)


def raise_value_error(message: str) -> None:
    raise ValueError(message)


class WorkshopRuntimeConfigTests(unittest.TestCase):
    def validate(self, workshop: dict[str, object]) -> None:
        VALIDATOR.validate_workshop_runtime_config(
            {"skills": {"workshop": workshop}},
            Path("k8s/agents/agent-test/deployment.yaml"),
        )

    def test_off_mode_is_accepted(self) -> None:
        self.validate({"autonomous": {"mode": "off"}})

    def test_auto_mode_is_accepted(self) -> None:
        self.validate({"autonomous": {"mode": "auto"}})

    def test_legacy_propose_mode_is_rejected(self) -> None:
        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "must be 'off' or 'auto'"
        ):
            self.validate({"autonomous": {"mode": "propose"}})

    def test_retired_approval_policy_is_rejected(self) -> None:
        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "retired keys"
        ):
            self.validate(
                {
                    "autonomous": {"mode": "off"},
                    "approvalPolicy": "pending",
                }
            )


if __name__ == "__main__":
    unittest.main()
