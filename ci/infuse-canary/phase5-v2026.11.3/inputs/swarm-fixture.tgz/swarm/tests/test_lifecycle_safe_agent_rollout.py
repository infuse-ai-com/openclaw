from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest


ROOT = Path(__file__).resolve().parents[1]
ROLLOUT = ROOT / "scripts" / "rollout-persistent-agent.sh"


FAKE_KUBECTL = r'''#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys
import time

state_path = Path(os.environ["FAKE_KUBECTL_STATE"])
state = json.loads(state_path.read_text()) if state_path.exists() else {"stage": "old", "replicas": "1"}
args = sys.argv[1:]
if args[:2] == ["-n", "agents-swarm"]:
    args = args[2:]
with Path(os.environ["FAKE_KUBECTL_LOG"]).open("a") as handle:
    handle.write(" ".join(args) + "\n")

def save():
    state_path.write_text(json.dumps(state))

if args[:2] == ["get", "deployment/agent-developer"]:
    if "-o" not in args:
        raise SystemExit(0)
    expression = args[args.index("-o") + 1]
    if "spec.replicas" in expression:
        print(state["replicas"], end="")
    elif "deployment\\.kubernetes\\.io/revision" in expression:
        print("7", end="")
    elif "metadata.resourceVersion" in expression:
        print("123", end="")
    raise SystemExit(0)

if args[:2] == ["get", "pods"]:
    if state["stage"] == "old":
        old_unready = os.environ.get("FAKE_OLD_UNREADY") == "true"
        items = [{
            "metadata": {"name": "old-pod", "deletionTimestamp": None},
            "status": {
                "phase": "Running",
                "containerStatuses": [{
                    "name": "agent",
                    "ready": not old_unready,
                    "restartCount": 5 if old_unready else 0,
                }],
            },
        }]
    elif state["stage"] == "new":
        items = [{
            "metadata": {"name": "new-pod", "deletionTimestamp": None},
            "status": {
                "phase": "Running",
                "containerStatuses": [{"name": "agent", "ready": True, "restartCount": 0}],
            },
        }]
    else:
        items = []
    print(json.dumps({"items": items}))
    raise SystemExit(0)

if args and args[0] == "exec":
    if "test" in args:
        raise SystemExit(0)
    if "--help" in args:
        if os.environ.get("FAKE_PRESTOP_ARMS", "true") == "true":
            print("usage: lifecycle prepare [--arm-handoff]")
        else:
            print("usage: lifecycle prepare")
        raise SystemExit(0)
    if "identity" in args:
        pod = "old-pod" if "old-pod" in args else "new-pod"
        if pod == "old-pod" and os.environ.get("FAKE_OLD_IDENTITY_FAIL") == "true":
            raise SystemExit(12)
        instance = "old-instance" if pod == "old-pod" else "new-instance"
        print(json.dumps({"status": "running", "target": {"pid": 42, "processInstanceId": instance}}))
        raise SystemExit(0)
    if "prepare" in args:
        status = "drain_timeout" if os.environ.get("FAKE_FAIL") == "prepare" else os.environ.get("FAKE_PREPARE_STATUS", "ready")
        print(json.dumps({"status": status}))
        raise SystemExit(10 if os.environ.get("FAKE_FAIL") == "prepare" else 0)
    if "prestop" in args:
        print(json.dumps({"status": "armed"}))
        raise SystemExit(0)
    if "resume" in args or "curl" in args:
        raise SystemExit(0)

if args and args[0] == "scale":
    replicas = next(value.split("=", 1)[1] for value in args if value.startswith("--replicas="))
    state["replicas"] = replicas
    state["stage"] = "stopped" if replicas == "0" else "new"
    save()
    raise SystemExit(0)

if args and args[0] == "wait":
    time.sleep(float(os.environ.get("FAKE_WAIT_SECONDS", "0")))
    raise SystemExit(1 if os.environ.get("FAKE_FAIL") == "wait" else 0)

if args and args[0] == "delete":
    raise SystemExit(0)

if args and args[0] == "apply":
    sys.stdin.read()
    if os.environ.get("FAKE_FAIL") == "apply":
        raise SystemExit(1)
    state["stage"] = "applied"
    save()
    raise SystemExit(0)

if args and args[0] == "replace":
    replacement = json.load(sys.stdin)
    if os.environ.get("FAKE_FAIL") == "apply":
        raise SystemExit(1)
    state["replacement"] = replacement
    state["stage"] = "applied"
    save()
    raise SystemExit(0)

if args[:2] == ["rollout", "undo"]:
    state["stage"] = "old"
    save()
    raise SystemExit(0)

if args[:2] == ["rollout", "status"]:
    if os.environ.get("FAKE_FAIL") == "startup" and state["stage"] == "new":
        raise SystemExit(1)
    raise SystemExit(0)

raise SystemExit("unexpected kubectl invocation: " + " ".join(args))
'''


class LifecycleSafeRolloutTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        root = Path(self.temporary.name)
        self.bin_dir = root / "bin"
        self.bin_dir.mkdir()
        kubectl = self.bin_dir / "kubectl"
        kubectl.write_text(FAKE_KUBECTL)
        kubectl.chmod(0o755)
        self.state = root / "state.json"
        self.log = root / "kubectl.log"
        self.manifest = root / "rendered.json"
        self.manifest.write_text(
            json.dumps(
                {
                    "apiVersion": "apps/v1",
                    "kind": "Deployment",
                    "metadata": {"name": "agent-developer"},
                    "spec": {"replicas": 1, "template": {"spec": {"containers": [{"name": "agent"}]}}},
                }
            )
        )

    def run_rollout(
        self,
        failure: str = "",
        environment_updates: dict[str, str] | None = None,
    ) -> subprocess.CompletedProcess[str]:
        environment = {
            **os.environ,
            "PATH": f"{self.bin_dir}:{os.environ['PATH']}",
            "FAKE_KUBECTL_STATE": str(self.state),
            "FAKE_KUBECTL_LOG": str(self.log),
            "FAKE_FAIL": failure,
            "FAKE_PRESTOP_ARMS": "true",
            **(environment_updates or {}),
        }
        return subprocess.run(
            [str(ROLLOUT), "agents-swarm", "agent-developer", str(self.manifest)],
            cwd=ROOT,
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )

    def log_lines(self) -> list[str]:
        return self.log.read_text().splitlines()

    def test_normal_rollout_orders_drain_stop_replace_start_and_health(self) -> None:
        completed = self.run_rollout()
        self.assertEqual(0, completed.returncode, completed.stderr)
        lines = self.log_lines()
        prepare = next(index for index, line in enumerate(lines) if " prepare " in f" {line} ")
        stop = next(index for index, line in enumerate(lines) if line.startswith("scale ") and "--replicas=0" in line)
        replace = next(index for index, line in enumerate(lines) if line.startswith("replace "))
        start = next(index for index, line in enumerate(lines) if line.startswith("scale ") and "--replicas=1" in line)
        ready = next(index for index, line in enumerate(lines) if "curl -fsS" in line)
        self.assertLess(prepare, stop)
        self.assertLess(stop, replace)
        self.assertLess(replace, start)
        self.assertLess(start, ready)
        state = json.loads(self.state.read_text())
        self.assertEqual("123", state["replacement"]["metadata"]["resourceVersion"])
        self.assertEqual(0, state["replacement"]["spec"]["replicas"])

    def test_bounded_mode_is_default_and_arms_before_termination(self) -> None:
        completed = self.run_rollout()
        self.assertEqual(0, completed.returncode, completed.stderr)
        prepare = next(line for line in self.log_lines() if "python3 - --profile agent-developer prepare" in line)
        self.assertIn("python3 - --profile agent-developer", prepare)
        self.assertIn("--drain-seconds 30", prepare)
        self.assertNotIn("--arm-handoff", prepare)
        self.assertIn("--force-handoff", prepare)
        self.assertTrue(any(" prestop " in f" {line} " for line in self.log_lines()))

    def test_drain_mode_waits_three_hundred_seconds_and_fails_closed(self) -> None:
        completed = self.run_rollout(environment_updates={"OPENCLAW_ROLLOUT_MODE": "drain"})
        self.assertEqual(0, completed.returncode, completed.stderr)
        prepare = next(line for line in self.log_lines() if "python3 - --profile agent-developer prepare" in line)
        self.assertIn("--drain-seconds 300", prepare)
        self.assertNotIn("--arm-handoff", prepare)
        self.assertNotIn("--force-handoff", prepare)

    def test_old_prestop_helper_is_bootstrapped_before_scale_and_gets_short_grace(self) -> None:
        completed = self.run_rollout(environment_updates={"FAKE_PRESTOP_ARMS": "false"})
        self.assertEqual(0, completed.returncode, completed.stderr)
        lines = self.log_lines()
        handoff = next(index for index, line in enumerate(lines) if " prestop " in f" {line} ")
        stop = next(index for index, line in enumerate(lines) if line.startswith("scale ") and "--replicas=0" in line)
        shortened = next(index for index, line in enumerate(lines) if line.startswith("delete "))
        self.assertLess(handoff, stop)
        self.assertLess(shortened, stop)
        self.assertIn("--grace-period=15", lines[shortened])

    def test_forced_timeout_shortens_only_the_armed_predecessor(self) -> None:
        completed = self.run_rollout(environment_updates={"FAKE_PREPARE_STATUS": "armed"})
        self.assertEqual(0, completed.returncode, completed.stderr)
        delete = next(line for line in self.log_lines() if line.startswith("delete "))
        self.assertIn("pod/old-pod", delete)
        self.assertIn("--grace-period=15", delete)

    def test_ready_current_helper_gets_bounded_initial_delete(self) -> None:
        completed = self.run_rollout()
        self.assertEqual(0, completed.returncode, completed.stderr)
        lines = self.log_lines()
        handoff = next(index for index, line in enumerate(lines) if " prestop " in f" {line} ")
        delete = next(index for index, line in enumerate(lines) if line.startswith("delete "))
        stop = next(index for index, line in enumerate(lines) if line.startswith("scale ") and "--replicas=0" in line)
        self.assertLess(handoff, delete)
        self.assertLess(delete, stop)
        self.assertIn("--grace-period=15", lines[delete])

    def test_delete_wait_is_bounded_by_the_pod_slo(self) -> None:
        completed = self.run_rollout()
        self.assertEqual(0, completed.returncode, completed.stderr)
        wait = next(line for line in self.log_lines() if line.startswith("wait "))
        self.assertIn("--timeout=30s", wait)

    def test_slow_predecessor_deletion_fails_before_applying_replacement(self) -> None:
        completed = self.run_rollout(
            environment_updates={
                "OPENCLAW_POD_DELETION_SLO_SECONDS": "0",
                "OPENCLAW_FORCED_POD_GRACE_SECONDS": "0",
                "FAKE_WAIT_SECONDS": "1.1",
            }
        )
        self.assertNotEqual(0, completed.returncode)
        lines = self.log_lines()
        self.assertFalse(any(line.startswith("replace ") for line in lines))
        self.assertTrue(any(line.startswith("scale ") and "--replicas=1" in line for line in lines))

    def test_delete_wait_timeout_requests_recovery_without_another_long_wait(self) -> None:
        completed = self.run_rollout("wait")
        self.assertNotEqual(0, completed.returncode)
        lines = self.log_lines()
        self.assertFalse(any(line.startswith("replace ") for line in lines))
        self.assertTrue(any(line.startswith("scale ") and "--replicas=1" in line for line in lines))
        self.assertFalse(any(line.startswith("rollout status ") for line in lines))

    def test_replace_failure_restores_previous_revision_before_start(self) -> None:
        completed = self.run_rollout("apply")
        self.assertNotEqual(0, completed.returncode)
        lines = self.log_lines()
        self.assertTrue(any(line.startswith("rollout undo ") and "--to-revision=7" in line for line in lines))
        self.assertTrue(any(line.startswith("scale ") and "--replicas=1" in line for line in lines))

    def test_prepare_timeout_never_stops_the_old_pod(self) -> None:
        completed = self.run_rollout("prepare")
        self.assertNotEqual(0, completed.returncode)
        self.assertFalse(any(line.startswith("scale ") for line in self.log_lines()))

    def test_started_replacement_failure_does_not_downgrade(self) -> None:
        completed = self.run_rollout("startup")
        self.assertNotEqual(0, completed.returncode)
        lines = self.log_lines()
        self.assertFalse(any(line.startswith("rollout undo ") for line in lines))
        self.assertGreaterEqual(sum(line.startswith("scale ") and "--replicas=1" in line for line in lines), 1)

    def test_unready_restarted_predecessor_uses_guarded_replacement(self) -> None:
        completed = self.run_rollout(
            environment_updates={
                "FAKE_OLD_IDENTITY_FAIL": "true",
                "FAKE_OLD_UNREADY": "true",
            }
        )
        self.assertEqual(0, completed.returncode, completed.stderr)
        lines = self.log_lines()
        self.assertFalse(any(" prepare " in f" {line} " for line in lines))
        self.assertTrue(any(line.startswith("delete pod/old-pod") for line in lines))
        self.assertTrue(any(line.startswith("replace ") for line in lines))
        self.assertIn("Completed failed-startup replacement", completed.stdout)

    def test_identity_failure_on_ready_predecessor_still_fails_closed(self) -> None:
        completed = self.run_rollout(
            environment_updates={"FAKE_OLD_IDENTITY_FAIL": "true"}
        )
        self.assertNotEqual(0, completed.returncode)
        lines = self.log_lines()
        self.assertFalse(any(line.startswith("delete ") for line in lines))
        self.assertFalse(any(line.startswith("replace ") for line in lines))
        self.assertIn("Refusing recovery", completed.stderr)


class ManifestSafetyContractTests(unittest.TestCase):
    def test_persistent_agent_manifest_has_lifecycle_safeguards(self) -> None:
        rendered = subprocess.run(
            [
                "kubectl",
                "create",
                "--dry-run=client",
                "-f",
                str(ROOT / "k8s/components/persistent-agent/deployment.yaml"),
                "-o",
                "json",
            ],
            text=True,
            capture_output=True,
            check=True,
        )
        deployment = json.loads(rendered.stdout)
        spec = deployment["spec"]
        pod = spec["template"]["spec"]
        container = pod["containers"][0]
        self.assertEqual("Recreate", spec["strategy"]["type"])
        self.assertEqual(420, pod["terminationGracePeriodSeconds"])
        self.assertEqual("/readyz", container["readinessProbe"]["httpGet"]["path"])
        self.assertEqual("/healthz", container["startupProbe"]["httpGet"]["path"])
        self.assertGreaterEqual(
            container["startupProbe"]["periodSeconds"] * container["startupProbe"]["failureThreshold"],
            600,
        )
        self.assertEqual("/healthz", container["livenessProbe"]["httpGet"]["path"])
        self.assertEqual(
            ["/usr/local/bin/openclaw-gateway-lifecycle", "prestop"],
            container["lifecycle"]["preStop"]["exec"]["command"],
        )

    def test_fleet_deployer_has_no_fleetwide_stop_or_restart(self) -> None:
        source = (ROOT / "scripts/deploy-infuseai-agents.sh").read_text()
        self.assertIn("deployments=(agent-developer agent-designer agent-infra agent-intake agent-coordinator)", source)
        self.assertIn('"$script_dir/rollout-persistent-agent-fleet.sh"', source)
        self.assertIn('"$script_dir/rollout-and-verify-persistent-agent.sh"', source)
        self.assertNotIn("scale_existing_deployments_to_zero", source)
        self.assertNotIn("rollout restart deployment/agent-", source)
        self.assertNotIn("sql_platform_deployments=(", source)
        self.assertIn("retire_legacy_mission_control_resources", source)
        self.assertIn("sql-mission-session-manager", source)
        self.assertIn("sql-mission-gateway-adapter", source)

    def test_backup_requires_gateway_drain_and_full_restore_verification(self) -> None:
        source = (ROOT / "scripts/backup-agent-workspace.sh").read_text()
        self.assertLess(source.index('run_helper prepare'), source.index('tar -C /workspace'))
        self.assertLess(source.index('--replicas=0'), source.index('tar -C /workspace'))
        self.assertIn('readOnly: true', source)
        self.assertIn('activeDeadlineSeconds: 7200', source)
        self.assertIn('command: ["sh", "-c", "sleep 7200"]', source)
        self.assertIn('tar -C /workspace --exclude=node_modules -cf - .', source)
        self.assertIn('excludedDirectoryBasenames:["node_modules"]', source)
        self.assertIn('for transfer_attempt in 1 2; do', source)
        self.assertIn('Backup transfer failed validation twice', source)
        self.assertLess(source.index('tar -tzf "$partial"'), source.rindex('--replicas="$original_replicas"'))
        self.assertIn('tar -xzf "$partial" -C "$restore_directory"', source)
        self.assertIn("PRAGMA quick_check;", source)
        self.assertIn('run_helper resume', source)


if __name__ == "__main__":
    unittest.main()
