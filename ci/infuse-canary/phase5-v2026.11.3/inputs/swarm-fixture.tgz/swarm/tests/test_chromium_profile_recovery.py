from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest


PROFILE_DIR = Path(__file__).resolve().parents[1] / "k8s/platform/chromium-sandbox"
PROFILE_NAME = "openclaw-chromium-v1.json"


class ChromiumProfileRecoveryTest(unittest.TestCase):
    def setUp(self):
        directory = TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.target = self.root / "seccomp/infuse" / PROFILE_NAME

    def invoke(self, *args):
        return subprocess.run(
            [sys.executable, str(PROFILE_DIR / "install-profile.py"), "--kubelet-root", str(self.root), *args],
            capture_output=True,
            text=True,
        )

    def test_clean_recovery_and_idempotent_recheck(self):
        self.assertNotEqual(self.invoke("--check").returncode, 0)
        self.assertEqual(list(self.root.iterdir()), [])
        self.assertEqual(self.invoke().returncode, 0)
        self.assertEqual(self.target.read_bytes(), (PROFILE_DIR / PROFILE_NAME).read_bytes())
        self.assertEqual(self.target.stat().st_mode & 0o777, 0o644)
        original = self.target.stat()
        self.assertEqual(self.invoke().returncode, 0)
        self.assertEqual(self.invoke("--check").returncode, 0)
        self.assertEqual(self.target.stat().st_ino, original.st_ino)
        self.assertEqual(self.target.stat().st_mtime_ns, original.st_mtime_ns)

    def test_conflicting_or_linked_profile_is_preserved(self):
        self.target.parent.mkdir(parents=True)
        self.target.write_text("existing node profile")
        self.assertNotEqual(self.invoke().returncode, 0)
        self.assertEqual(self.target.read_text(), "existing node profile")
        self.target.unlink()
        other = self.root / "other.json"
        other.write_bytes((PROFILE_DIR / PROFILE_NAME).read_bytes())
        self.target.symlink_to(other)
        self.assertNotEqual(self.invoke().returncode, 0)
        self.assertNotEqual(self.invoke("--check").returncode, 0)
        self.assertTrue(self.target.is_symlink())
