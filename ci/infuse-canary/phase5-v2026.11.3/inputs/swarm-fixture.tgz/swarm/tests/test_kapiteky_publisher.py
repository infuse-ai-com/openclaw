"""Exercise preflight and ownership against a fake Kubernetes transport."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class KapitekyPublisherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.agent = self.root / "kapiteky"
        self.agent.mkdir()
        self.skill = self.root / "mission-control-publishing"
        (self.skill / "scripts").mkdir(parents=True)
        self.helper = self.skill / "scripts/artifact_tool.py"
        self.helper.write_text("import sys\nprint('--studio-origin') if '--help' in sys.argv else None\n")
        (self.skill / "scripts/artifact_registry.py").write_text("")
        self.spec = self.root / "spec.json"
        self.spec.write_text("{}")
        self.log = self.root / "calls.jsonl"
        policy = json.loads((ROOT / "config/kapiteky-artifact-publisher-network-policy.json").read_text())
        self.policies = self.root / "policies.json"
        self.policies.write_text(json.dumps({"items": [policy]}))
        bin_dir = self.root / "bin"
        bin_dir.mkdir()
        fake = bin_dir / "kubectl"
        fake.write_text('''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
a=sys.argv[1:];body=None
# Remote `test -f` is not kubectl's manifest input flag. CI keeps stdin open.
if '-i' in a or ('-f' in a and ('create' in a or 'delete' in a)):
 body=sys.stdin.buffer.read()
with open(os.environ['TEST_CALLS'],'a') as f:
 f.write(json.dumps({'args':a,'body':body.decode() if body and ('create' in a or 'delete' in a) else None})+'\\n')
if 'get' in a:
 if 'networkpolicy' in a: print(Path(os.environ['TEST_POLICIES']).read_text())
 elif 'pod' in a:
  if os.environ.get('TEST_POD_READ_FAILURE'): sys.exit(1)
  print('pod/already-owned' if os.environ.get('TEST_COLLISION') else '')
 else: print('reviewed-runtime@sha256:'+'a'*64)
elif 'create' in a: print(json.dumps({'metadata':{'uid':'owned-uid'}}))
elif 'wait' in a and os.environ.get('TEST_WAIT_FAILURE'): sys.exit(1)
elif 'exec' in a and 'test' in a: sys.exit(1)
''')
        fake.chmod(0o755)
        self.env = dict(os.environ, PATH=f"{bin_dir}:{os.environ['PATH']}",
                        MISSION_CONTROL_AGENT_DIR=str(self.agent),
                        MISSION_CONTROL_PUBLISHING_SKILL_DIR=str(self.skill),
                        KUBE_CONTEXT="infuseai-k8s", ARTIFACT_REGISTRY_PUBLISHER_NAMESPACE="agents-swarm",
                        TEST_CALLS=str(self.log), TEST_POLICIES=str(self.policies))

    def run_wrapper(self):
        return subprocess.run(["bash", str(ROOT / "scripts/publish-kapiteky-artifact-registry.sh"),
                               "--spec", str(self.spec), "--studio-origin", "https://studio.infuse-ai.com"],
                              env=self.env, capture_output=True, text=True, timeout=15)

    def calls(self):
        return [json.loads(l) for l in self.log.read_text().splitlines()] if self.log.exists() else []

    def assert_no_creation_or_deletion(self):
        self.assertFalse(any("create" in c["args"] or "delete" in c["args"] for c in self.calls()))

    def test_old_helper_fails_before_cluster_access(self):
        self.helper.write_text("print('older helper')\n")
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        self.assertEqual(self.calls(), [])

    def test_incomplete_journal_fails_before_cluster_access(self):
        (self.agent / "journal.json").write_text("{}")
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        self.assertEqual(self.calls(), [])

    def test_symlink_journal_fails_before_cluster_access(self):
        (self.agent / "journal.json").symlink_to(self.spec)
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        self.assertEqual(self.calls(), [])

    def test_invalid_spec_fails_before_cluster_access(self):
        self.helper.write_text("import sys\nprint('--studio-origin')\nsys.exit(1 if 'validate' in sys.argv else 0)\n")
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        self.assertEqual(self.calls(), [])

    def test_pod_collision_is_never_deleted(self):
        self.env['TEST_COLLISION'] = '1'
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        self.assert_no_creation_or_deletion()

    def test_failed_pod_preflight_never_creates(self):
        self.env["TEST_POD_READ_FAILURE"] = "1"
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        self.assert_no_creation_or_deletion()

    def test_missing_or_drifted_policy_is_fail_closed(self):
        for policies in ({'items': []}, {'items': [{'spec': {'podSelector': {}, 'policyTypes': ['Egress'], 'egress': [{}]}}]}):
            self.policies.write_text(json.dumps(policies))
            self.assertNotEqual(self.run_wrapper().returncode, 0)
            self.assert_no_creation_or_deletion()

    def test_second_permissive_policy_is_rejected(self):
        policies = json.loads(self.policies.read_text())
        policies['items'].append({'spec': {'podSelector': {}, 'policyTypes': ['Egress'], 'egress': [{}]}})
        self.policies.write_text(json.dumps(policies))
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        self.assert_no_creation_or_deletion()

    def test_success_uses_uid_cleanup_and_bounded_pod(self):
        result = self.run_wrapper()
        self.assertEqual(result.returncode, 0, result.stderr)
        creates = [c for c in self.calls() if 'create' in c['args']]
        deletes = [c for c in self.calls() if 'delete' in c['args']]
        self.assertEqual(len(creates), 1)
        self.assertEqual(len(deletes), 1)
        manifest = json.loads(creates[0]['body'])
        self.assertEqual(manifest['spec']['activeDeadlineSeconds'], 300)
        self.assertFalse(manifest['spec']['automountServiceAccountToken'])
        self.assertTrue(manifest['spec']['containers'][0]['securityContext']['readOnlyRootFilesystem'])
        self.assertEqual(json.loads(deletes[0]['body'])['preconditions']['uid'], 'owned-uid')

    def test_wait_failure_cleans_only_created_uid(self):
        self.env['TEST_WAIT_FAILURE'] = '1'
        self.assertNotEqual(self.run_wrapper().returncode, 0)
        deletes = [c for c in self.calls() if 'delete' in c['args']]
        self.assertEqual(len(deletes), 1)
        self.assertEqual(json.loads(deletes[0]['body'])['preconditions']['uid'], 'owned-uid')


if __name__ == '__main__':
    unittest.main()
