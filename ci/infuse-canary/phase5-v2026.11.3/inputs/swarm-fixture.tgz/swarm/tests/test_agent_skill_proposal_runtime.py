from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class AgentSkillProposalRuntimeTests(unittest.TestCase):
    def test_monitor_reuses_existing_exec_only_service_account_without_secret_mounts(self) -> None:
        manifest = (
            ROOT / "k8s/overlays/infuseai/agent-skill-proposal-monitor.yaml"
        ).read_text(
            encoding="utf-8"
        )
        self.assertIn("kind: CronJob", manifest)
        self.assertIn("serviceAccountName: openclaw-agent-memory-sync", manifest)
        self.assertNotIn("secretKeyRef:", manifest)
        self.assertNotIn("envFrom:", manifest)
        self.assertNotIn("volumes:", manifest)
        self.assertIn("value: agent-infra", manifest)
        self.assertIn("value: channel:wzgn18p5xjgiir3zkxnpdcieye", manifest)

    def test_startup_quarantines_only_after_reviewed_install_manifest_is_written(self) -> None:
        startup = (ROOT / "scripts/sync-agent-skills-startup.sh").read_text(encoding="utf-8")
        install = '"$config_root/scripts/install-agent-skills.py"'
        quarantine = '"$proposal_helper" scan --agent-id "$agent_id" --quarantine'
        self.assertLess(startup.index(install), startup.index(quarantine))

    def test_image_contains_proposal_scanner_and_collector(self) -> None:
        dockerfile = (ROOT / "images/openclaw-agent/Dockerfile").read_text(encoding="utf-8")
        self.assertIn("openclaw-agent-skill-proposal", dockerfile)
        self.assertIn("openclaw-agent-skill-proposal-collect", dockerfile)

    def test_collector_addresses_notifier_by_permitted_pod_identity(self) -> None:
        collector = (ROOT / "scripts/collect-agent-skill-proposals.sh").read_text(
            encoding="utf-8"
        )
        self.assertIn('exec "pod/$notifier_pod"', collector)
        self.assertNotIn('exec "deploy/$notifier_deployment"', collector)


if __name__ == "__main__":
    unittest.main()
