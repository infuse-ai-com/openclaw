from __future__ import annotations

import copy
import importlib.util
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "agent_image_identity",
    ROOT / "scripts" / "verify-agent-image-identity.py",
)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


DIGEST = "sha256:" + ("a" * 64)
IMAGE = f"registry.example.test/openclaw-agent@{DIGEST}"
SOURCE_REVISION = "b" * 40


def deployment() -> dict[str, object]:
    return {
        "spec": {
            "template": {
                "metadata": {
                    "annotations": {
                        "openclaw.infuse-ai.com/image-revision": DIGEST,
                        "openclaw.infuse-ai.com/swarm-source-revision": SOURCE_REVISION,
                    },
                },
                "spec": {
                    "containers": [{"name": "agent", "image": IMAGE}],
                },
            },
        },
    }


def pods() -> dict[str, object]:
    return {
        "items": [
            {
                "metadata": {
                    "annotations": {
                        "openclaw.infuse-ai.com/image-revision": DIGEST,
                        "openclaw.infuse-ai.com/swarm-source-revision": SOURCE_REVISION,
                    },
                },
                "status": {
                    "phase": "Running",
                    "containerStatuses": [
                        {"name": "agent", "ready": True, "imageID": f"containerd://image@{DIGEST}"},
                    ],
                },
            },
        ],
    }


class AgentImageIdentityTests(unittest.TestCase):
    def test_accepts_one_ready_exact_digest_runtime(self) -> None:
        result = MODULE.validate_identity(
            deployment(),
            pods(),
            expected_digest=DIGEST,
            expected_source_revision=SOURCE_REVISION,
        )
        self.assertTrue(result["image_identity_verified"])
        self.assertTrue(result["source_identity_verified"])
        self.assertEqual(1, result["container_count"])

    def test_rejects_dev_and_other_mutable_expected_revisions(self) -> None:
        for revision in ("dev", "latest", "20260906.9"):
            with self.subTest(revision=revision), self.assertRaises(MODULE.IdentityError):
                MODULE.validate_identity(deployment(), pods(), expected_digest=revision)

    def test_rejects_stale_annotation_and_mutable_deployment_image(self) -> None:
        stale = copy.deepcopy(deployment())
        stale["spec"]["template"]["metadata"]["annotations"][
            "openclaw.infuse-ai.com/image-revision"
        ] = "sha256:" + ("b" * 64)
        with self.assertRaises(MODULE.IdentityError):
            MODULE.validate_identity(stale, pods(), expected_digest=DIGEST)

        mutable = copy.deepcopy(deployment())
        mutable["spec"]["template"]["spec"]["containers"][0]["image"] = (
            "registry.example.test/openclaw-agent:20260906.9"
        )
        with self.assertRaises(MODULE.IdentityError):
            MODULE.validate_identity(mutable, pods(), expected_digest=DIGEST)

    def test_rejects_runtime_image_id_disagreement(self) -> None:
        mismatched = copy.deepcopy(pods())
        mismatched["items"][0]["status"]["containerStatuses"][0]["imageID"] = (
            "containerd://image@sha256:" + ("b" * 64)
        )
        with self.assertRaises(MODULE.IdentityError):
            MODULE.validate_identity(deployment(), mismatched, expected_digest=DIGEST)

    def test_rejects_stale_source_revision_on_deployment_or_pod(self) -> None:
        stale_deployment = copy.deepcopy(deployment())
        stale_deployment["spec"]["template"]["metadata"]["annotations"][
            "openclaw.infuse-ai.com/swarm-source-revision"
        ] = "c" * 40
        with self.assertRaises(MODULE.IdentityError):
            MODULE.validate_identity(
                stale_deployment,
                pods(),
                expected_digest=DIGEST,
                expected_source_revision=SOURCE_REVISION,
            )

        stale_pod = copy.deepcopy(pods())
        stale_pod["items"][0]["metadata"]["annotations"][
            "openclaw.infuse-ai.com/swarm-source-revision"
        ] = "c" * 40
        with self.assertRaises(MODULE.IdentityError):
            MODULE.validate_identity(
                deployment(),
                stale_pod,
                expected_digest=DIGEST,
                expected_source_revision=SOURCE_REVISION,
            )


if __name__ == "__main__":
    unittest.main()
