import copy
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('retire_network', ROOT / 'scripts/retire-backoffice-network.py')
m = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)


class RetirementNetworkTests(unittest.TestCase):
    def setUp(self):
        self.desired = {'ingress': [{'from': [{'podSelector': {'matchLabels': {'app': 'studio'}}}],
                                    'ports': [{'port': 3010, 'protocol': 'TCP'}]}], 'egress': [{'to': ['retained']}]}
        self.before = copy.deepcopy(self.desired)
        self.before['ingress'][0]['from'].insert(0, m.BO_PEER)

    def test_only_exact_peer_removed_and_retry_is_noop(self):
        self.assertTrue(m.target_spec(self.before, self.desired))
        self.assertFalse(m.target_spec(self.desired, self.desired))
        self.assertIn(m.BO_PEER, self.before['ingress'][0]['from'])

    def test_rejects_other_drift_and_duplicate_peer(self):
        for mutation in ('egress', 'duplicate', 'broader'):
            live = copy.deepcopy(self.before)
            if mutation == 'egress': live['egress'] = []
            if mutation == 'duplicate': live['ingress'][0]['from'].append(m.BO_PEER)
            if mutation == 'broader': live['ingress'][0]['from'][0].pop('namespaceSelector')
            with self.assertRaises(RuntimeError): m.target_spec(live, self.desired)

    def test_refuses_active_or_partial_shutdown(self):
        crons = [{'metadata': {'name': name}, 'spec': {'suspend': True}} for name in m.CRONS]
        m.stopped(None, crons, [])
        m.stopped(None, [], [])
        with self.assertRaises(RuntimeError): m.stopped(None, crons[:3], [])
        crons[0]['spec']['suspend'] = False
        with self.assertRaises(RuntimeError): m.stopped(None, crons, [])
        with self.assertRaises(RuntimeError): m.stopped(None, [], [{'spec': {'serviceAccountName': 'backoffice'}, 'status': {'phase': 'Running'}}])

    def test_gitlab_source_verification_excludes_registry_maintenance(self):
        pipeline = (ROOT / '.gitlab-ci.yml').read_text()
        for fragment in ('retire-backoffice-network.py', 'artifact-registry-release', 'kubectl apply'):
            self.assertNotIn(fragment, pipeline)


if __name__ == '__main__': unittest.main()
