from __future__ import annotations

import os
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
ROLLOUT = ROOT / "scripts" / "rollout-persistent-agent-fleet.sh"


FAKE_AGENT_ROLLOUT = r'''#!/usr/bin/env bash
set -euo pipefail

deployment="$2"
printf 'start:%s\n' "$deployment" >>"$FAKE_ROLLOUT_LOG"
touch "$FAKE_ROLLOUT_STATE/$deployment.started"

if [ "${FAKE_REQUIRE_LEAF_BARRIER:-false}" = "true" ]; then
  case "$deployment" in
    agent-designer|agent-infra|agent-intake)
      for _attempt in $(seq 1 500); do
        if [ -f "$FAKE_ROLLOUT_STATE/agent-designer.started" ] \
          && [ -f "$FAKE_ROLLOUT_STATE/agent-infra.started" ] \
          && [ -f "$FAKE_ROLLOUT_STATE/agent-intake.started" ]; then
          break
        fi
        sleep 0.01
      done
      test -f "$FAKE_ROLLOUT_STATE/agent-designer.started"
      test -f "$FAKE_ROLLOUT_STATE/agent-infra.started"
      test -f "$FAKE_ROLLOUT_STATE/agent-intake.started"
      ;;
  esac
fi

if [ "${FAKE_FAIL_DEPLOYMENT:-}" = "$deployment" ]; then
  printf 'fail:%s\n' "$deployment" >>"$FAKE_ROLLOUT_LOG"
  exit 17
fi

printf 'end:%s\n' "$deployment" >>"$FAKE_ROLLOUT_LOG"
'''


class PersistentAgentFleetRolloutTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        root = Path(self.temporary.name)
        self.state = root / "state"
        self.state.mkdir()
        self.log = root / "rollout.log"
        self.manifest = root / "rendered.json"
        self.manifest.write_text("{}")
        self.helper = root / "fake-agent-rollout.sh"
        self.helper.write_text(FAKE_AGENT_ROLLOUT)
        self.helper.chmod(0o755)

    def run_fleet(self, **updates: str) -> subprocess.CompletedProcess[str]:
        environment = {
            **os.environ,
            "FAKE_ROLLOUT_LOG": str(self.log),
            "FAKE_ROLLOUT_STATE": str(self.state),
            **updates,
        }
        return subprocess.run(
            [
                str(ROLLOUT),
                "agents-swarm",
                str(self.manifest),
                "sha256:" + "a" * 64,
                "source-revision",
                str(self.helper),
            ],
            cwd=ROOT,
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )

    def events(self) -> list[str]:
        return self.log.read_text().splitlines() if self.log.exists() else []

    def test_default_canary_wave_keeps_canary_and_coordinator_boundaries(self) -> None:
        completed = self.run_fleet(FAKE_REQUIRE_LEAF_BARRIER="true")
        self.assertEqual(0, completed.returncode, completed.stderr)
        events = self.events()
        leaf_agents = ("agent-designer", "agent-infra", "agent-intake")

        developer_end = events.index("end:agent-developer")
        leaf_starts = [events.index(f"start:{agent}") for agent in leaf_agents]
        leaf_ends = [events.index(f"end:{agent}") for agent in leaf_agents]
        coordinator_start = events.index("start:agent-coordinator")

        self.assertLess(developer_end, min(leaf_starts))
        self.assertLess(max(leaf_starts), min(leaf_ends))
        self.assertLess(max(leaf_ends), coordinator_start)

    def test_leaf_failure_blocks_coordinator_after_waiting_for_the_batch(self) -> None:
        completed = self.run_fleet(
            FAKE_REQUIRE_LEAF_BARRIER="true",
            FAKE_FAIL_DEPLOYMENT="agent-infra",
        )
        self.assertNotEqual(0, completed.returncode)
        events = self.events()
        self.assertIn("fail:agent-infra", events)
        self.assertIn("end:agent-designer", events)
        self.assertIn("end:agent-intake", events)
        self.assertNotIn("start:agent-coordinator", events)
        self.assertIn("coordinator promotion is blocked", completed.stderr)

    def test_sequential_strategy_preserves_the_legacy_order(self) -> None:
        completed = self.run_fleet(OPENCLAW_FLEET_ROLLOUT_STRATEGY="sequential")
        self.assertEqual(0, completed.returncode, completed.stderr)
        self.assertEqual(
            [
                "start:agent-developer",
                "end:agent-developer",
                "start:agent-designer",
                "end:agent-designer",
                "start:agent-infra",
                "end:agent-infra",
                "start:agent-intake",
                "end:agent-intake",
                "start:agent-coordinator",
                "end:agent-coordinator",
            ],
            self.events(),
        )

    def test_preserved_agents_are_not_invoked(self) -> None:
        completed = self.run_fleet(
            PRESERVE_DEPLOYMENTS="agent-developer,agent-designer,agent-infra,agent-intake,agent-coordinator"
        )
        self.assertEqual(0, completed.returncode, completed.stderr)
        self.assertEqual([], self.events())

    def test_preserved_developer_cannot_be_bypassed_as_the_canary(self) -> None:
        completed = self.run_fleet(PRESERVE_DEPLOYMENTS="agent-developer")
        self.assertNotEqual(0, completed.returncode)
        self.assertEqual([], self.events())
        self.assertIn("cannot preserve agent-developer", completed.stderr)

    def test_unknown_strategy_fails_before_any_agent_rollout(self) -> None:
        completed = self.run_fleet(OPENCLAW_FLEET_ROLLOUT_STRATEGY="all-at-once")
        self.assertEqual(2, completed.returncode)
        self.assertEqual([], self.events())


if __name__ == "__main__":
    unittest.main()
