"""Run the real deploy/filter/selector/fleet chain with isolated transport fixtures."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
AGENTS = ("agent-developer", "agent-designer", "agent-infra", "agent-intake", "agent-coordinator")
PLATFORM = ("openclaw-otel-collector",)
MAINTENANCE_CRONJOBS = (
    "openclaw-agent-memory-sync",
    "openclaw-agent-model-policy-collector",
    "openclaw-agent-skill-proposal-monitor",
    "openclaw-agent-token-usage-collector",
    "openclaw-scheduler-collector",
)
KINDS = (
    "ConfigMap", "NetworkPolicy", "PersistentVolumeClaim", "Role",
    "RoleBinding", "ClusterRole", "ClusterRoleBinding", "Service", "ServiceAccount",
)
DEVELOPER = {
    "apiVersion": "apps/v1", "kind": "Deployment",
    "metadata": {"name": "agent-developer"}, "spec": {"replicas": 1},
}

FAKE_KUBECTL = r'''#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys

args = sys.argv[1:]
log = Path(os.environ["FIXTURE_LOG"])
previous = log.read_text().splitlines() if log.exists() else []
with log.open("a") as handle:
    handle.write(json.dumps(args) + "\n")
if args[:2] == ["-n", "fixture"]:
    args = args[2:]
if args[:3] == ["get", "configmap", "studio-mission-authority"]:
    print(json.dumps({"data": {"authority": "studio", "nativeProfileState": "active"}}))
elif args and args[0] == "get" and args[1].startswith("deployment/"):
    if args[-1] == "json":
        reads = sum(json.loads(line) == sys.argv[1:] for line in previous)
        image = "changed" if reads and os.environ.get("FIXTURE_DRIFT") == "true" else "stable"
        print(json.dumps({"spec": {"template": {"spec": {"containers": [{"image": image}]}}}}))
    elif args[-1].startswith("jsonpath="):
        print("1")
elif args and args[0] in ("get", "describe"):
    pass  # Read-only inventory and diagnostics, never a live cluster.
elif args[:3] == ["create", "-n", "fixture"] and "--dry-run=client" in args:
    manifest = Path(args[args.index("-f") + 1]).read_text()
    if not manifest.strip() or os.environ.get("FIXTURE_CONVERSION_FAIL") == "true":
        raise SystemExit("invalid or empty manifest")
    expected_name = os.environ.get("FIXTURE_EXPECT_MANIFEST_NAME", "agent-developer")
    assert "name: " + expected_name in manifest
    print(os.environ["FIXTURE_CONVERTED"])
elif args[:4] == ["apply", "-n", "fixture", "-f"]:
    source = args[4]
    content = sys.stdin.read() if source == "-" else Path(source).read_text()
    Path(os.environ["FIXTURE_APPLY"]).write_text(content)
    print("cronjobs configured")
else:
    raise SystemExit("unexpected kubectl command: " + " ".join(args))
'''


class PreservedDeployIntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.scripts = self.directory / "scripts"
        self.scripts.mkdir()
        for name in (
            "deploy-infuseai-agents.sh", "filter-preserved-deployments.py",
            "select-agent-rollout-manifests.py", "rollout-persistent-agent-fleet.sh",
            "studio_native_profiles.py",
        ):
            shutil.copy2(ROOT / "scripts" / name, self.scripts / name)
        self.write_executable("kubectl", FAKE_KUBECTL)
        self.write_executable("render-infuseai-agents.sh", '#!/usr/bin/env bash\ncat "$FIXTURE_RENDER"\nexit "${FIXTURE_RENDER_EXIT:-0}"\n')
        self.write_executable("rollout-and-verify-persistent-agent.sh", '#!/usr/bin/env bash\nset -euo pipefail\nprintf "%s\\n" "$2" >> "$FIXTURE_ROLLOUT"\ncp "$3" "$FIXTURE_MANIFEST"\n')
        self.render = self.directory / "render.yaml"
        self.render.write_text("\n---\n".join(
            f"apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: {name}\nspec: {{}}"
            for name in (*AGENTS, *PLATFORM)
        ) + "\n---\n" + "\n---\n".join(
            f"apiVersion: v1\nkind: {kind}\nmetadata:\n  name: fixture-{kind.lower()}"
            for kind in KINDS
        ) + "\n---\n" + "\n---\n".join(
            f"apiVersion: batch/v1\nkind: CronJob\nmetadata:\n  name: {name}\nspec: {{}}"
            for name in MAINTENANCE_CRONJOBS
        ) + "\n")
        self.log = self.directory / "kubectl.jsonl"
        self.rollout = self.directory / "rollouts.txt"
        self.manifest = self.directory / "manifest.json"
        self.applied = self.directory / "applied.json"

    def write_executable(self, name: str, source: str) -> None:
        path = self.scripts / name
        path.write_text(source)
        path.chmod(0o755)

    def deploy(self, **overrides: str) -> subprocess.CompletedProcess[str]:
        environment = {
            "PATH": f"{self.scripts}:{os.environ['PATH']}",
            "HOME": str(self.directory), "TMPDIR": str(self.directory),
            "NAMESPACE": "fixture", "IMAGE_REVISION": "sha256:" + "a" * 64,
            "SOURCE_REVISION": "b" * 40, "RUNTIME_ONLY_UPGRADE": "true",
            "PRESERVE_DEPLOYMENTS": ",".join(AGENTS),
            "FIXTURE_RENDER": str(self.render), "FIXTURE_LOG": str(self.log),
            "FIXTURE_ROLLOUT": str(self.rollout), "FIXTURE_MANIFEST": str(self.manifest),
            "FIXTURE_APPLY": str(self.applied),
            "FIXTURE_CONVERTED": json.dumps(DEVELOPER), **overrides,
        }
        return subprocess.run(
            ["bash", str(self.scripts / "deploy-infuseai-agents.sh")],
            env=environment, capture_output=True, text=True, timeout=30,
        )

    def test_fully_preserved_deploy_finishes_without_conversion_or_mutation(self) -> None:
        result = self.deploy()
        self.assertEqual(0, result.returncode, result.stderr)
        calls = [json.loads(line) for line in self.log.read_text().splitlines()]
        self.assertTrue(all((args[2] if args[0] == "-n" else args[0]) == "get" for args in calls))
        self.assertFalse(self.rollout.exists())
        self.assertIn("verified rendered shared manifest is empty", result.stdout)
        self.assertEqual(len(AGENTS), result.stdout.count("pod template and replicas are unchanged"))
        self.assertIn("Agents swarm deployed", result.stdout)
        self.assertEqual([], list(self.directory.glob("tmp.*")), "manifest scratch files leaked")

    def test_failed_renderer_cannot_be_mistaken_for_empty_success(self) -> None:
        # The filter succeeds with empty output even though the renderer failed.
        result = self.deploy(FIXTURE_RENDER_EXIT="9")
        self.assertNotEqual(0, result.returncode)
        self.assertFalse(self.rollout.exists())
        self.assertNotIn("Agents swarm deployed", result.stdout)

    def test_missing_preservation_target_fails_before_conversion(self) -> None:
        self.render.write_text(self.render.read_text().replace("name: agent-intake", "name: missing-intake"))
        result = self.deploy()
        self.assertNotEqual(0, result.returncode)
        self.assertIn("preserved Deployment objects were not rendered", result.stderr)
        self.assertFalse(self.rollout.exists())
        self.assertNotIn('"create"', self.log.read_text())

    def test_nonempty_conversion_failure_stops_deployment(self) -> None:
        result = self.deploy(PRESERVE_DEPLOYMENTS=",".join(AGENTS[1:]), FIXTURE_CONVERSION_FAIL="true")
        self.assertNotEqual(0, result.returncode)
        self.assertIn("invalid or empty manifest", result.stderr)
        self.assertFalse(self.rollout.exists())

    def test_nonempty_manifest_reaches_only_the_unpreserved_agent(self) -> None:
        result = self.deploy(PRESERVE_DEPLOYMENTS=",".join(AGENTS[1:]))
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertEqual(["agent-developer"], self.rollout.read_text().splitlines())
        self.assertEqual({"apiVersion": "v1", "kind": "List", "items": [DEVELOPER]}, json.loads(self.manifest.read_text()))
        self.assertEqual(4, result.stdout.count("pod template and replicas are unchanged"))

    def test_preservation_assertions_still_reject_drift_after_empty_render(self) -> None:
        result = self.deploy(FIXTURE_DRIFT="true")
        self.assertNotEqual(0, result.returncode)
        self.assertIn("changed preserved deployment/agent-developer pod template", result.stderr)
        self.assertNotIn("Agents swarm deployed", result.stdout)

    def test_runtime_release_applies_only_the_five_maintenance_cronjobs(self) -> None:
        image = "registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:" + "a" * 64
        cronjobs = [
            {
                "apiVersion": "batch/v1",
                "kind": "CronJob",
                "metadata": {"name": name},
                "spec": {
                    "jobTemplate": {
                        "spec": {
                            "template": {
                                "spec": {"containers": [{"name": "collector", "image": image}]}
                            }
                        }
                    }
                },
            }
            for name in MAINTENANCE_CRONJOBS
        ]
        result = self.deploy(
            RECONCILE_MAINTENANCE_CRONJOBS="true",
            FIXTURE_EXPECT_MANIFEST_NAME=MAINTENANCE_CRONJOBS[0],
            FIXTURE_CONVERTED="\n".join(json.dumps(item) for item in cronjobs),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        applied = json.loads(self.applied.read_text())
        self.assertEqual("List", applied["kind"])
        self.assertEqual(set(MAINTENANCE_CRONJOBS), {item["metadata"]["name"] for item in applied["items"]})
        self.assertEqual({"CronJob"}, {item["kind"] for item in applied["items"]})
        self.assertIn("reconciled five maintenance CronJobs", result.stdout)


if __name__ == "__main__":
    unittest.main()
