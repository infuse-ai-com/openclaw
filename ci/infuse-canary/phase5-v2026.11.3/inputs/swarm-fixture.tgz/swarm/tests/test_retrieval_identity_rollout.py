import json
import os
from pathlib import Path
import stat
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SMOKE = ROOT / "scripts" / "smoke-agent-knowledge-retrieval.mjs"
ROLLOUT = ROOT / "scripts" / "rollout-retrieval-agent-identity.sh"
RUNTIME_SMOKE = ROOT / "scripts" / "smoke-agent-runtime.sh"


class RetrievalIdentityRolloutTest(unittest.TestCase):
    def test_smoke_reports_only_bounded_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            client = Path(directory) / "client.mjs"
            client.write_text(
                """#!/usr/bin/env node
const operation = process.argv[2];
process.stdin.resume();
process.stdin.on('end', () => {
  const result = operation === 'discover'
    ? {mode: 'hybrid', candidates: [{fetchReference: `kbfr2.${'a'.repeat(80)}`}]}
    : {markdown: '# private synthetic document\\n'};
  process.stdout.write(`${JSON.stringify(result)}\\n`);
});
""",
                encoding="utf-8",
            )
            client.chmod(client.stat().st_mode | stat.S_IXUSR)
            result = subprocess.run(
                ["node", str(SMOKE)],
                cwd=ROOT,
                env={
                    **os.environ,
                    "AGENT_ID": "agent-developer",
                    "KNOWLEDGE_RETRIEVAL_CLIENT": str(client),
                },
                text=True,
                capture_output=True,
                check=True,
            )
        payload = json.loads(result.stdout)
        self.assertEqual(
            payload,
            {
                "ok": True,
                "agentId": "agent-developer",
                "discover": {"mode": "hybrid", "candidateCount": 1},
                "fetch": {"documentBytesBucket": "le_4k"},
            },
        )
        self.assertNotIn("private", result.stdout)
        self.assertNotIn("kbfr", result.stdout)

    def test_rollout_is_confirmation_gated_and_identity_only(self) -> None:
        source = ROLLOUT.read_text(encoding="utf-8")
        self.assertIn("CONFIRM_RETRIEVAL_IDENTITY_ROLLOUT", source)
        self.assertIn('target_service_account="openclaw-$agent_id"', source)
        self.assertIn("serviceAccountName", source)
        self.assertIn("original_image", source)
        self.assertIn("smoke-agent-runtime.sh", source)
        self.assertIn("smoke-agent-knowledge-retrieval.mjs", source)
        self.assertNotIn("kubectl apply -k k8s/overlays/infuseai", source)

    def test_runtime_smoke_ignores_terminating_selector_peers(self) -> None:
        source = RUNTIME_SMOKE.read_text(encoding="utf-8")
        self.assertNotIn('wait pod -l "$selector"', source)
        self.assertIn("select(.metadata.deletionTimestamp == null)", source)
        self.assertIn('if [[ "$active_count" == "1"', source)


if __name__ == "__main__":
    unittest.main()
