from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = ROOT / "scripts" / "document-normalizer-client-launcher.sh"


class DocumentNormalizerLauncherTests(unittest.TestCase):
    def run_launcher(
        self, workspace: Path | None, *arguments: str
    ) -> subprocess.CompletedProcess[str]:
        environment = os.environ.copy()
        environment.pop("OPENCLAW_AGENT_WORKSPACE", None)
        if workspace is not None:
            environment["OPENCLAW_AGENT_WORKSPACE"] = str(workspace)
        return subprocess.run(
            ["bash", str(LAUNCHER), *arguments],
            check=False,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=environment,
        )

    def test_workspace_is_required(self) -> None:
        result = self.run_launcher(None, "--help")

        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("OPENCLAW_AGENT_WORKSPACE is required", result.stderr)

    def test_missing_canonical_client_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            result = self.run_launcher(Path(directory), "--help")

        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("canonical Document Normalizer client is unavailable", result.stderr)

    def test_launcher_executes_installed_skill_client_and_forwards_arguments(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory)
            client = (
                workspace
                / "skills"
                / "document-normalizer"
                / "scripts"
                / "document-normalizer-client.py"
            )
            client.parent.mkdir(parents=True)
            client.write_text(
                "import json, sys\nprint(json.dumps(sys.argv[1:]))\n",
                encoding="utf-8",
            )

            result = self.run_launcher(
                workspace,
                "synthetic.pdf",
                "--output",
                "normalized.md",
                "--confirm-sanitized",
            )

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(
            json.loads(result.stdout),
            [
                "synthetic.pdf",
                "--output",
                "normalized.md",
                "--confirm-sanitized",
            ],
        )

    def test_runtime_image_packages_only_the_thin_launcher(self) -> None:
        dockerfile = (ROOT / "images" / "openclaw-agent" / "Dockerfile").read_text(
            encoding="utf-8"
        )

        self.assertIn(
            "COPY scripts/document-normalizer-client-launcher.sh "
            "/usr/local/bin/openclaw-document-normalizer",
            dockerfile,
        )
        self.assertNotIn("COPY scripts/document-normalizer-client.py", dockerfile)


if __name__ == "__main__":
    unittest.main()
