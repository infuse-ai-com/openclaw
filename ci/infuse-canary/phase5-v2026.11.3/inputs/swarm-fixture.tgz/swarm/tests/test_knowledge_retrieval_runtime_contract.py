import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AGENTS = (
    "agent-coordinator",
    "agent-developer",
    "agent-designer",
    "agent-infra",
    "agent-intake",
)
URL = "http://knowledge-base-retrieval.knowledge-base.svc.cluster.local"
TOKEN_FILE = "/var/run/openclaw-agent/tokens/knowledge-retrieval/token"


class KnowledgeRetrievalRuntimeContractTest(unittest.TestCase):
    def render(self, agent: str) -> str:
        return subprocess.run(
            ["kubectl", "kustomize", str(ROOT / "k8s" / "agents" / agent)],
            check=True,
            capture_output=True,
            text=True,
        ).stdout

    def assert_contract(self, rendered: str) -> None:
        self.assertIn("name: KNOWLEDGE_RETRIEVAL_URL", rendered)
        self.assertIn(f"value: {URL}", rendered)
        self.assertIn("name: KNOWLEDGE_RETRIEVAL_TOKEN_FILE", rendered)
        self.assertIn(f"value: {TOKEN_FILE}", rendered)
        self.assertIn("name: knowledge-retrieval-token", rendered)
        self.assertIn("audience: knowledge-base-retrieval", rendered)
        self.assertIn("expirationSeconds: 3600", rendered)
        self.assertIn("path: token", rendered)

    def test_all_active_agents_render_the_exact_contract(self) -> None:
        for agent in AGENTS:
            with self.subTest(agent=agent):
                rendered = self.render(agent)
                self.assert_contract(rendered)
                self.assertGreaterEqual(rendered.count("knowledge-retrieval"), 4)

    def test_canary_patch_matches_shared_contract(self) -> None:
        patch = (ROOT / "k8s" / "canary" / "agent-developer-knowledge-retrieval-patch.yaml").read_text()
        self.assert_contract(patch)


if __name__ == "__main__":
    unittest.main()
