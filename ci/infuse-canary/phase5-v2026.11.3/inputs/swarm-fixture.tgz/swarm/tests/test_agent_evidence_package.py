"""Regression coverage for portable review-artifact verification."""

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / "scripts/verify-agent-evidence-package.py"
SPEC = importlib.util.spec_from_file_location("agent_evidence_package", SCRIPT_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class AgentEvidencePackageTests(unittest.TestCase):
    def test_v2_style_ambient_playwright_and_fixed_chromium_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "verify-native.js").write_text(
                'const { chromium } = require("playwright");\n'
                'chromium.launch({ executablePath: "/usr/bin/chromium" });\n'
            )

            findings = MODULE.scan_package(root)

        codes = {finding["code"] for finding in findings}
        self.assertIn("undeclared_playwright_dependency", codes)
        self.assertIn("fixed_chromium_path", codes)

    def test_v3_style_agent_toolbox_fallback_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "verify-native.js").write_text(
                'require("/opt/agent-node-toolbox/node_modules/playwright");\n'
            )

            findings = MODULE.scan_package(root)

        self.assertIn("agent_toolbox_path", {item["code"] for item in findings})

    def test_bundled_playwright_with_documented_strict_gate_allows_host_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "node_modules/playwright").mkdir(parents=True)
            (root / "node_modules/playwright/package.json").write_text('{"version":"1.55.0"}')
            (root / "VERIFY.md").write_text(
                "Set `KB_PACKAGED_RUNTIME_ONLY=1` for strict verification.\n"
            )
            (root / "browser-runtime.js").write_text(
                "const strict = process.env.KB_PACKAGED_RUNTIME_ONLY === '1';\n"
                "const fallback = '/opt/agent-node-toolbox/node_modules/playwright';\n"
            )

            findings = MODULE.scan_package(root)
            strict_names = MODULE.packaged_runtime_env_names(root)

        self.assertNotIn("agent_toolbox_path", {item["code"] for item in findings})
        self.assertEqual(strict_names, ["KB_PACKAGED_RUNTIME_ONLY"])

    def test_declared_playwright_without_lockfile_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "verify-native.js").write_text('require("playwright");\n')
            (root / "package.json").write_text(
                json.dumps({"dependencies": {"playwright": "1.55.0"}})
            )

            findings = MODULE.scan_package(root)

        self.assertIn("missing_node_lockfile", {item["code"] for item in findings})

    def test_chromium_path_override_allows_common_linux_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "VERIFY.md").write_text("Run `node verify.js`.\n")
            (root / "verify.js").write_text(
                "const executable = process.env.CHROMIUM_PATH || '/usr/bin/chromium';\n"
                "console.log(executable);\n"
            )

            findings = MODULE.scan_package(root)

        self.assertNotIn("fixed_chromium_path", {item["code"] for item in findings})

    def test_missing_verify_instructions_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            findings = MODULE.scan_package(Path(temp))

        self.assertIn(
            "missing_verification_instructions", {item["code"] for item in findings}
        )

    def test_command_runs_from_copy_without_ambient_node_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "artifact"
            root.mkdir()
            (root / "verify.js").write_text(
                "if (process.env.NODE_PATH) process.exit(4);\n"
                "if (process.env.OPENCLAW_AGENT_TOOLBOX_DISABLED !== '1') process.exit(5);\n"
                "console.log('portable pass');\n"
            )
            with mock.patch.dict(os.environ, {"NODE_PATH": "/ambient/modules"}):
                results = MODULE.run_commands(root, ["node verify.js"], 10)

        self.assertEqual(results[0]["exitCode"], 0)
        self.assertEqual(results[0]["classification"], "verification_passed")
        self.assertIn("portable pass", results[0]["stdoutTail"])

    def test_missing_module_is_classified_as_tooling_gap(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "verify.js").write_text('require("definitely-not-installed-openclaw-test");\n')
            results = MODULE.run_commands(root, ["node verify.js"], 10)

        self.assertNotEqual(results[0]["exitCode"], 0)
        self.assertEqual(results[0]["classification"], "tooling_gap")
        self.assertIn("Cannot find module", results[0]["stderrTail"])

    def test_unsafe_zip_path_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            archive = Path(temp) / "unsafe.zip"
            destination = Path(temp) / "out"
            destination.mkdir()
            with zipfile.ZipFile(archive, "w") as package:
                package.writestr("../escape.txt", "nope")

            with self.assertRaises(MODULE.PackageError):
                MODULE.safe_extract_zip(archive, destination)

    def test_directory_symlink_is_rejected_before_copy(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "artifact"
            root.mkdir()
            outside = Path(temp) / "outside.txt"
            outside.write_text("private host data\n")
            (root / "leak.txt").symlink_to(outside)

            with self.assertRaisesRegex(MODULE.PackageError, "unsupported symlink"):
                MODULE.materialize(root, Path(temp) / "isolated")

    def test_cli_requires_commands_unless_check_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            result = subprocess.run(
                [str(SCRIPT_PATH), temp],
                capture_output=True,
                check=False,
                text=True,
            )

        self.assertEqual(result.returncode, 2)
        self.assertIn("pass at least one --command", result.stderr)


if __name__ == "__main__":
    unittest.main()
