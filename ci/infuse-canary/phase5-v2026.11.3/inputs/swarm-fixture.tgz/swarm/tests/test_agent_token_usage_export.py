"""Regression coverage for the Backoffice agent token-usage feed."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import subprocess
import unittest
from datetime import datetime, timezone
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
EXPORTER_PATH = ROOT / "scripts" / "export-openclaw-agent-token-usage.py"
COLLECTOR_PATH = ROOT / "scripts" / "collect-openclaw-agent-token-usage-feed.sh"


def load_exporter():
    spec = importlib.util.spec_from_file_location("agent_token_usage_exporter", EXPORTER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load agent token usage exporter")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


EXPORTER = load_exporter()


def totals(input_tokens: int, output_tokens: int, cache_read: int = 0) -> dict[str, int]:
    total_tokens = input_tokens + output_tokens + cache_read
    return {
        "input": input_tokens,
        "output": output_tokens,
        "cacheRead": cache_read,
        "cacheWrite": 0,
        "totalTokens": total_tokens,
    }


class AgentTokenUsageExportTests(unittest.TestCase):
    def test_explicit_empty_gateway_window_without_cache_is_not_a_failure(self) -> None:
        now = datetime.now(timezone.utc)
        dates = EXPORTER.date_window(now, 7)
        raw = {"sessions": [], "totals": totals(0, 0),
               "aggregates": {"sessionCount": 0, "byModel": []},
               "updatedAt": int(now.timestamp() * 1000),
               "startDate": dates[0], "endDate": dates[-1]}
        result = EXPORTER.build_snapshot_from_gateway_usage(
            raw_usage=raw, agent_id="agent-intake", gateway_label="Intake Gateway", days=7, now=now)
        self.assertEqual(result["source"]["cacheStatus"], "empty_window")
        self.assertEqual(result["source"]["status"], "no_usage_entries")
        self.assertEqual(len(result["usage"]["daily"]), 7)
        self.assertEqual(result["usage"]["last7d"]["totalTokens"], 0)
        with mock.patch.object(EXPORTER.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, json.dumps(raw), "")) as run:
            EXPORTER.fetch_gateway_usage(openclaw_command="openclaw", days=7, attempts=3,
                                         retry_delay_seconds=0, timeout_seconds=10)
            self.assertEqual(run.call_count, 1)
        for change in [
            {"cacheStatus": {"status": "refreshing"}}, {"cacheStatus": None},
            {"updatedAt": 0}, {"sessions": [{}]}, {"totals": {"totalTokens": 0}},
            {"totals": totals(1, 0)}, {"aggregates": {}},
            {"startDate": "2020-01-01"}, {"endDate": "2020-01-07"},
            {"aggregates": {"sessionCount": False, "byModel": []}},
        ]:
            with self.subTest(change=change), self.assertRaises(EXPORTER.GatewayUsageError):
                EXPORTER.build_snapshot_from_gateway_usage(raw_usage={**raw, **change},
                    agent_id="agent-intake", gateway_label="Intake Gateway", days=7, now=now)

    def test_gateway_usage_builds_sanitized_daily_and_four_hour_buckets(self) -> None:
        first = totals(10, 2, 100)
        second = totals(20, 3, 200)
        raw = {
            "updatedAt": 1_787_770_000_000,
            "startDate": "2026-08-21",
            "endDate": "2026-08-27",
            "cacheStatus": {
                "status": "fresh",
                "cachedFiles": 2,
                "pendingFiles": 0,
                "staleFiles": 0,
            },
            "totals": {key: first[key] + second[key] for key in EXPORTER.TOKEN_KEYS},
            "sessions": [
                {
                    "key": "private-session-key",
                    "sessionId": "private-session-id",
                    "modelProvider": "openai",
                    "model": "gpt-5.6-sol",
                    "usage": {
                        **first,
                        "sessionFile": "/private/runtime/session.sqlite",
                        "modelUsage": [
                            {
                                "provider": "openai",
                                "model": "gpt-5.6-sol",
                                "count": 1,
                                "totals": first,
                            }
                        ],
                        "utcQuarterHourTokenUsage": [
                            {"date": "2026-08-27", "quarterIndex": 0, **first}
                        ],
                    },
                },
                {
                    "key": "another-private-key",
                    "sessionId": "another-private-id",
                    "usage": {
                        **second,
                        "modelUsage": [
                            {"provider": "openai", "model": "gpt-5.6-sol", "count": 1, "totals": first},
                            {"provider": "openai", "model": "gpt-5.6-terra", "count": 1, "totals": second},
                        ],
                        "utcQuarterHourTokenUsage": [
                            {"date": "2026-08-27", "quarterIndex": 20, **second}
                        ],
                    },
                },
            ],
            "aggregates": {
                "byModel": [
                    {
                        "provider": "openai",
                        "model": "gpt-5.6-sol",
                        "count": 2,
                        "totals": first,
                    },
                    {
                        "provider": "openai",
                        "model": "gpt-5.6-terra",
                        "count": 1,
                        "totals": second,
                    },
                ]
            },
        }

        snapshot = EXPORTER.build_snapshot_from_gateway_usage(
            raw_usage=raw,
            agent_id="agent-coordinator",
            gateway_label="Emon Gateway",
            days=7,
            now=EXPORTER.datetime(2026, 8, 27, 12, tzinfo=EXPORTER.timezone.utc),
        )

        self.assertEqual(snapshot["source"]["backend"], "gateway_sessions_usage")
        self.assertEqual(snapshot["source"]["status"], "available")
        self.assertEqual(snapshot["source"]["cacheStatus"], "fresh")
        self.assertEqual(snapshot["usage"]["last7d"], raw["totals"])
        self.assertEqual(snapshot["usage"]["today"], raw["totals"])
        self.assertEqual(
            [(row["periodStart"], row["provider"], row["model"]) for row in snapshot["usage"]["periods4h"]],
            [
                ("2026-08-27T00:00:00+00:00", "openai", "gpt-5.6-sol"),
                ("2026-08-27T04:00:00+00:00", "mixed", "mixed"),
            ],
        )
        self.assertEqual(len(snapshot["usage"]["byModel"]), 2)
        serialized = json.dumps(snapshot)
        self.assertNotIn("private-session", serialized)
        self.assertNotIn("session.sqlite", serialized)
        self.assertNotIn("totalCost", serialized)

    def test_gateway_usage_rejects_partial_session_rows(self) -> None:
        raw = {
            "cacheStatus": {"status": "fresh"},
            "totals": totals(10, 2),
            "sessions": [],
            "aggregates": {"byModel": []},
        }

        with self.assertRaisesRegex(EXPORTER.GatewayUsageError, "refusing a partial export"):
            EXPORTER.build_snapshot_from_gateway_usage(
                raw_usage=raw,
                agent_id="agent-coordinator",
                gateway_label="Emon Gateway",
                days=7,
                now=EXPORTER.datetime(2026, 8, 27, 12, tzinfo=EXPORTER.timezone.utc),
            )

    def test_fresh_zero_usage_is_valid_and_distinct_from_failure(self) -> None:
        raw = {
            "cacheStatus": {
                "status": "fresh",
                "cachedFiles": 0,
                "pendingFiles": 0,
                "staleFiles": 0,
            },
            "totals": totals(0, 0),
            "sessions": [],
            "aggregates": {"byModel": []},
        }

        snapshot = EXPORTER.build_snapshot_from_gateway_usage(
            raw_usage=raw,
            agent_id="agent-intake",
            gateway_label="Ramiro Gateway",
            days=7,
            now=EXPORTER.datetime(2026, 8, 27, 12, tzinfo=EXPORTER.timezone.utc),
        )

        self.assertEqual(snapshot["source"]["status"], "no_usage_entries")
        self.assertEqual(snapshot["usage"]["last7d"], totals(0, 0))
        self.assertEqual(snapshot["usage"]["periods4h"], [])

    def test_gateway_auth_failure_does_not_publish_a_snapshot(self) -> None:
        rejected = subprocess.CompletedProcess(
            [],
            1,
            json.dumps(
                {
                    "ok": False,
                    "error": {
                        "code": "AUTH_FAILED",
                        "message": "authentication rejected",
                    },
                }
            ),
            "",
        )

        with (
            mock.patch.object(EXPORTER.subprocess, "run", return_value=rejected) as run,
            self.assertRaisesRegex(EXPORTER.GatewayUsageError, "AUTH_FAILED"),
        ):
            EXPORTER.fetch_gateway_usage(
                openclaw_command="openclaw",
                days=7,
                attempts=3,
                retry_delay_seconds=0.1,
                timeout_seconds=10,
            )

        command = run.call_args.args[0]
        self.assertNotIn("--token", command)
        self.assertNotIn("--password", command)

    def test_gateway_usage_retries_refreshing_empty_cache(self) -> None:
        refreshing = {
            "cacheStatus": {"status": "refreshing", "pendingFiles": 2},
            "totals": totals(0, 0),
            "sessions": [],
            "aggregates": {"byModel": []},
        }
        fresh = {
            "cacheStatus": {"status": "fresh", "pendingFiles": 0},
            "totals": totals(5, 1),
            "sessions": [],
            "aggregates": {"byModel": []},
        }
        completed = [
            subprocess.CompletedProcess([], 0, json.dumps(refreshing), ""),
            subprocess.CompletedProcess([], 0, json.dumps(fresh), ""),
        ]

        with (
            mock.patch.object(EXPORTER.subprocess, "run", side_effect=completed) as run,
            mock.patch.object(EXPORTER.time, "sleep") as sleep,
        ):
            result = EXPORTER.fetch_gateway_usage(
                openclaw_command="openclaw",
                days=7,
                attempts=3,
                retry_delay_seconds=0.1,
                timeout_seconds=10,
            )

        self.assertEqual(result["cacheStatus"]["status"], "fresh")
        self.assertEqual(run.call_count, 2)
        sleep.assert_called_once_with(0.1)
        params = json.loads(run.call_args_list[0].args[0][-1])
        self.assertEqual(params, {"range": "7d", "limit": 1000})

    def test_collector_fails_closed_instead_of_publishing_zero_error_rows(self) -> None:
        script = COLLECTOR_PATH.read_text(encoding="utf-8")
        self.assertNotIn("writing empty error snapshot", script)
        self.assertIn("Refusing to update", script)


if __name__ == "__main__":
    unittest.main()
