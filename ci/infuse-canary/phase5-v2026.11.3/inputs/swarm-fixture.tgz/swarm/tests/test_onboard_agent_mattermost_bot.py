from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "onboard-agent-mattermost-bot.py"
SPEC = importlib.util.spec_from_file_location("onboard_agent_mattermost_bot", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
ONBOARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ONBOARD)


class OnboardAgentMattermostBotTests(unittest.TestCase):
    def test_exec_secretref_uses_stdin_protocol_and_returns_only_value(self) -> None:
        with tempfile.TemporaryDirectory() as root:
            command = Path(root).resolve() / "provider"
            command.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
            command.chmod(0o700)
            config = {
                "secrets": {
                    "providers": {
                        "company": {
                            "source": "exec",
                            "command": str(command),
                            "args": ["resolve"],
                            "jsonOnly": True,
                        }
                    }
                }
            }
            completed = mock.Mock(
                returncode=0,
                stdout=json.dumps({"protocolVersion": 1, "values": {"mattermost": "resolved-value"}}).encode(),
                stderr=b"",
            )
            with mock.patch.object(ONBOARD.subprocess, "run", return_value=completed) as run:
                self.assertEqual(
                    ONBOARD.resolve_secret_ref(
                        {"source": "exec", "provider": "company", "id": "mattermost"}, config
                    ),
                    "resolved-value",
                )
            request = json.loads(run.call_args.kwargs["input"])
            self.assertEqual(request, {"protocolVersion": 1, "provider": "company", "ids": ["mattermost"]})
            self.assertNotIn("resolved-value", run.call_args.args[0])

    def test_env_secretref_requires_value(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(SystemExit):
                ONBOARD.resolve_secret_ref({"source": "env", "id": "MM_TEST_TOKEN"}, {})

    def test_unsupported_secretref_fails_closed(self) -> None:
        with self.assertRaises(SystemExit):
            ONBOARD.resolve_secret_ref({"source": "file", "id": "mattermost"}, {})


if __name__ == "__main__":
    unittest.main()
