import importlib.util
import json
from pathlib import Path
import stat
import subprocess
import tempfile
import types
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = ROOT / "tools" / "agent-evals" / "runner.py"
SUITE = ROOT / "tools" / "agent-evals" / "cases.v1.json"
BASELINE = ROOT / "tools" / "agent-evals" / "fixtures" / "baseline-results.v1.json"
DEGRADED = ROOT / "tools" / "agent-evals" / "fixtures" / "degraded-results.v1.json"


def load_runner():
    spec = importlib.util.spec_from_file_location("agent_eval_runner", RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("runner import failed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class AgentEvalRunnerTest(unittest.TestCase):
    def command(self, replay: Path, output: Path) -> list[str]:
        return [
            "python3",
            str(RUNNER_PATH),
            "--suite",
            str(SUITE),
            "--replay",
            str(replay),
            "--output",
            str(output),
            "--runner-revision",
            "c791fdfe688c5babfd1f574b9b402912c7bbf4df",
            "--image-revision",
            "sha256:8a854483faad6916a77fdaa815e2648aa38f9d6975df3c3707c415731f23d3d3",
            "--runtime-revision",
            "3d1a6e4197b2bcce4b90cd3fc5b6de8a5b1f24c0",
            "--skill-bundle-revision",
            "sha256:074f0831eb250c80329e35e9827b9415080a887f336daba5b7bc090b2609d587",
            "--model-revision",
            "openai:gpt-5.6-sol",
        ]

    def test_baseline_replay_passes_and_writes_metadata_only_private_report(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "report.json"
            completed = subprocess.run(
                self.command(BASELINE, output),
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            summary = json.loads(completed.stdout)
            report = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(summary["case_count"], 12)
            self.assertEqual(summary["trial_count"], 20)
            self.assertEqual(summary["passed_cases"], 12)
            self.assertTrue(summary["eligible_for_human_review"])
            self.assertEqual(
                summary["trace_propagation"], "unsupported_by_gateway_cli"
            )
            self.assertEqual(report["execution"]["external_delivery"], False)
            self.assertEqual(report["execution"]["model_assisted_grader"], "disabled")
            self.assertFalse(report["execution"]["trace_correlation_claimed"])
            rendered = json.dumps(report)
            for forbidden in (
                '"prompt"',
                '"response"',
                '"final_text"',
                '"stdout"',
                '"stderr"',
                '"traceparent"',
            ):
                self.assertNotIn(forbidden, rendered)
            self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o600)

    def test_degraded_candidate_is_rejected_by_deterministic_gates(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "degraded.json"
            completed = subprocess.run(
                self.command(DEGRADED, output),
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 2, completed.stderr)
            report = json.loads(output.read_text(encoding="utf-8"))
            self.assertFalse(report["summary"]["eligible_for_human_review"])
            blockers = report["summary"]["blockers"]
            self.assertIn("tool-efficiency:final_mismatch", blockers)
            self.assertIn("tool-efficiency:required_tool_missing", blockers)
            self.assertIn("tool-efficiency:forbidden_tool_used", blockers)
            self.assertIn("tool-efficiency:tool_call_budget_exceeded", blockers)

    def test_suite_rejects_non_read_only_and_enabled_model_grader(self) -> None:
        runner = load_runner()
        source = json.loads(SUITE.read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "cases.json"
            source["cases"][0]["execution_mode"] = "write"
            target.write_text(json.dumps(source), encoding="utf-8")
            with self.assertRaisesRegex(runner.EvaluationError, "not_read_only"):
                runner.load_suite(target)
            source["cases"][0]["execution_mode"] = "read_only"
            source["cases"][0]["model_assisted_grader"]["enabled"] = True
            target.write_text(json.dumps(source), encoding="utf-8")
            with self.assertRaisesRegex(runner.EvaluationError, "model_grader"):
                runner.load_suite(target)

    def test_gateway_invocation_uses_supported_no_delivery_cli_path(self) -> None:
        runner = load_runner()
        args = types.SimpleNamespace(
            kube_context="infuseai-k8s",
            namespace="agents-swarm",
            deployment="agent-developer",
            profile="agent-developer",
            agent_id="agent-developer",
            timeout_seconds=120,
        )
        case = json.loads(SUITE.read_text(encoding="utf-8"))["cases"][4]
        payload = {
            "status": "ok",
            "result": {
                "payloads": [{"text": "HEALTHY"}],
                "meta": {
                    "toolSummary": {
                        "calls": 1,
                        "tools": ["session_status"],
                        "failures": 0,
                    }
                },
            },
        }
        completed = subprocess.CompletedProcess([], 0, json.dumps(payload), "")
        with mock.patch.object(runner.subprocess, "run", return_value=completed) as run:
            result = runner.gateway_trial(args, case, 1)
        command = run.call_args.args[0]
        self.assertIn("openclaw", command)
        self.assertIn("--session-key", command)
        self.assertIn("--json", command)
        self.assertNotIn("--deliver", command)
        self.assertEqual(result["final_text"], "HEALTHY")
        self.assertEqual(result["tool_summary"]["tools"], ["session_status"])


if __name__ == "__main__":
    unittest.main()
