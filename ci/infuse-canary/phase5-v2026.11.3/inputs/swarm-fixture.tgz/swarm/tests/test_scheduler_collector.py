"""Scheduler collector fail-closed transport qualification."""
import json,os,subprocess,tempfile,textwrap,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
COLLECTOR_PATH=ROOT/'scripts/collect-openclaw-scheduler-feed.sh'
def install_fake_timeout(fake_bin):
 p=fake_bin/'timeout';p.write_text('#!/usr/bin/env bash\nshift\nexec "$@"\n');p.chmod(0o755)
class SchedulerCollectorTests(unittest.TestCase):
    def test_collector_does_not_apply_when_one_agent_export_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fake_bin = root / "bin"
            fake_bin.mkdir()
            install_fake_timeout(fake_bin)
            mutation_log = root / "mutations.log"
            fake_kubectl = fake_bin / "kubectl"
            fake_kubectl.write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env bash
                    set -euo pipefail
                    if [[ "$*" == *"get pods"* ]]; then
                      printf '%s\\n' '{"items":[{"metadata":{"name":"agent-test-pod","creationTimestamp":"2026-08-27T00:00:00Z","labels":{"app.kubernetes.io/name":"agent-test"}},"status":{"phase":"Running","containerStatuses":[{"name":"agent","ready":true}]}}]}'
                    elif [[ "$*" == *"exec pod/agent-test-pod"* ]]; then
                      exit 9
                    elif [[ "$*" == *"create configmap"* || "$*" == *"apply"* ]]; then
                      printf '%s\\n' "$*" >> "$FAKE_MUTATION_LOG"
                    else
                      printf 'unexpected kubectl invocation: %s\\n' "$*" >&2
                      exit 10
                    fi
                    """
                ),
                encoding="utf-8",
            )
            os.chmod(fake_kubectl, 0o755)
            env = os.environ.copy()
            env.update(
                {
                    "PATH": f"{fake_bin}{os.pathsep}{env['PATH']}",
                    "EXPECTED_AGENT_IDS": "agent-test",
                    "FAKE_MUTATION_LOG": str(mutation_log),
                    "EXPORT_TIMEOUT_SECONDS": "2",
                }
            )

            completed = subprocess.run(
                ["bash", str(COLLECTOR_PATH)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("Refusing to update configmap", completed.stderr)
        self.assertFalse(mutation_log.exists())

    def test_collector_dry_run_validates_a_complete_snapshot_without_applying(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fake_bin = root / "bin"
            fake_bin.mkdir()
            install_fake_timeout(fake_bin)
            mutation_log = root / "mutations.log"
            fake_kubectl = fake_bin / "kubectl"
            snapshot = json.dumps(
                {
                    "schemaVersion": 1,
                    "generatedAt": "2026-08-27T00:00:00Z",
                    "source": {
                        "type": "openclaw_schedules",
                        "agentId": "agent-test",
                        "gatewayLabel": "Test Gateway",
                        "backend": "gateway_cron_list",
                        "status": "available",
                        "paginationComplete": True,
                        "snapshotRevision": "sha256:test",
                    },
                    "tasks": [],
                }
            )
            fake_kubectl.write_text(
                textwrap.dedent(
                    f"""\
                    #!/usr/bin/env bash
                    set -euo pipefail
                    if [[ "$*" == *"get pods"* ]]; then
                      printf '%s\\n' '{{"items":[{{"metadata":{{"name":"agent-test-pod","creationTimestamp":"2026-08-27T00:00:00Z","labels":{{"app.kubernetes.io/name":"agent-test"}}}},"status":{{"phase":"Running","containerStatuses":[{{"name":"agent","ready":true}}]}}}}]}}'
                    elif [[ "$*" == *"exec pod/agent-test-pod"* ]]; then
                      printf '%s\\n' '{snapshot}'
                    elif [[ "$*" == *"create configmap"* || "$*" == *"apply"* ]]; then
                      printf '%s\\n' "$*" >> "$FAKE_MUTATION_LOG"
                    else
                      printf 'unexpected kubectl invocation: %s\\n' "$*" >&2
                      exit 10
                    fi
                    """
                ),
                encoding="utf-8",
            )
            os.chmod(fake_kubectl, 0o755)
            env = os.environ.copy()
            env.update(
                {
                    "PATH": f"{fake_bin}{os.pathsep}{env['PATH']}",
                    "EXPECTED_AGENT_IDS": "agent-test",
                    "FAKE_MUTATION_LOG": str(mutation_log),
                    "EXPORT_TIMEOUT_SECONDS": "2",
                    "DRY_RUN": "true",
                }
            )

            completed = subprocess.run(
                ["bash", str(COLLECTOR_PATH)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )

        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("dry run left configmap", completed.stdout)
        self.assertFalse(mutation_log.exists())


if __name__=="__main__":unittest.main()
