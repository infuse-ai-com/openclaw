import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class LangfuseV4SignalQualityRunbookTest(unittest.TestCase):
    def test_runbook_keeps_views_privacy_and_release_gates_versioned(self) -> None:
        source = (ROOT / "docs/runbooks/langfuse-v4-signal-quality.md").read_text(
            encoding="utf-8"
        )
        for view in (
            "OpenClaw · Actionable failures",
            "OpenClaw · Slow or incomplete turns",
            "OpenClaw · Tool reliability",
            "OpenClaw · Model tokens and cost",
            "OpenClaw · Skills and knowledge",
        ):
            self.assertIn(view, source)
        self.assertIn("privacy.contentObservationsAcrossAllObservations", source)
        self.assertIn("Tinus first", source)
        self.assertIn("Do not manually apply production manifests", source)
        self.assertNotIn("captureContent: true", source)


if __name__ == "__main__":
    unittest.main()
