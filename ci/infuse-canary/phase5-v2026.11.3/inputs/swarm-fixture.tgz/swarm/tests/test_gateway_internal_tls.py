import copy
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("internal_transport", ROOT / "scripts/prepare-internal-gateway-transport.py")
transport = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(transport)


class GatewayInternalTlsTest(unittest.TestCase):
    def tree(self, temporary):
        root = Path(temporary) / "k8s"
        shutil.copytree(ROOT / "k8s", root)
        return root

    def test_disabled_contract_leaves_source_tree_untouched(self):
        transport.validate(json.loads((ROOT / "config/internal-gateway-transport.json").read_text()))
        contract = {"version": 1, "enabledAgents": []}
        with tempfile.TemporaryDirectory() as temporary:
            root = self.tree(temporary)
            before = {str(path.relative_to(root)): path.read_bytes() for path in root.rglob("*") if path.is_file()}
            transport.prepare(root, contract)
            self.assertEqual(before, {str(path.relative_to(root)): path.read_bytes() for path in root.rglob("*") if path.is_file()})

    def test_pilot_preserves_identity_studio_and_all_unselected_agents(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = self.tree(temporary)
            path = root / "agents/agent-designer/deployment.yaml"
            source = path.read_text()
            initial = json.loads(transport.CONFIG.search(source)[2])
            # Model the preceding identity MR so preparation cannot erase it.
            initial["gateway"]["auth"]["identityScopes"] = {"issuer|immutable-sub": ["operator.admin"]}
            initial["gateway"]["auth"]["trustedProxy"]["allowUsers"] = ["issuer|immutable-sub"]
            source = transport.CONFIG.sub(lambda match: match[1] + "'" + json.dumps(initial) + "'", source)
            path.write_text(source)
            transport.prepare(root, {"version": 1, "enabledAgents": ["agent-designer"]})
            updated = json.loads(transport.CONFIG.search(path.read_text())[2])
            expected = copy.deepcopy(initial)
            expected["gateway"]["auth"]["trustedProxy"]["allowLoopback"] = True
            expected["gateway"]["trustedProxies"].append("127.0.0.1")
            self.assertEqual(updated, expected)
            for agent in transport.AGENTS - {"agent-designer"}:
                for name in ("deployment.yaml", "kustomization.yaml"):
                    self.assertEqual((root / "agents" / agent / name).read_bytes(), (ROOT / "k8s/agents" / agent / name).read_bytes())
            # Every original operation is preserved except the two reviewed JSON fields.
            original_without_config = transport.CONFIG.sub("CONFIG", source)
            updated_without_config = transport.CONFIG.sub("CONFIG", path.read_text())
            self.assertTrue(updated_without_config.startswith(original_without_config))
            with self.assertRaisesRegex(ValueError, "once"):
                transport.prepare(root, {"version": 1, "enabledAgents": ["agent-designer"]})

    def test_transport_cannot_expand_the_trust_namespace_or_agent_set(self):
        for contract in ({"version": 1, "enabledAgents": ["unknown"]}, {"version": 1, "enabledAgents": ["agent-designer"] * 2},
                         {"version": True, "enabledAgents": []}, {"version": 1, "enabledAgents": [], "proxy": "0.0.0.0/0"}):
            with self.assertRaises(ValueError):
                transport.validate(contract)
        with tempfile.TemporaryDirectory() as temporary:
            root = self.tree(temporary)
            path = root / "agents/agent-designer/deployment.yaml"
            path.write_text(path.read_text().replace('"10.1.42.208"', '"10.0.0.0/8"'))
            with self.assertRaisesRegex(ValueError, "transport boundary"):
                transport.prepare(root, {"version": 1, "enabledAgents": ["agent-designer"]})

    def test_sidecar_and_network_policy_are_narrow_and_credential_isolated(self):
        container = transport.sidecar("agent-designer")
        self.assertEqual(container["command"][0], "/usr/local/bin/node")
        self.assertEqual(container["securityContext"]["runAsUser"], 10001)
        self.assertTrue(container["securityContext"]["readOnlyRootFilesystem"])
        self.assertEqual(len(container["env"]), 1)
        self.assertNotIn("envFrom", container)
        self.assertEqual({mount["name"] for mount in container["volumeMounts"]}, {"gateway-tls-code", "gateway-tls-identity", "gateway-tls-no-api-token"})
        service, policy = transport.resources("agent-designer")
        self.assertEqual(service["spec"]["ports"], [{"name": "https", "port": 443, "targetPort": 8443, "protocol": "TCP"}])
        ingress = policy["spec"]["ingress"]
        self.assertEqual(ingress, [{"from": [{"namespaceSelector": {"matchLabels": {"kubernetes.io/metadata.name": "agents-swarm"}},
            "podSelector": {"matchLabels": {"app.kubernetes.io/name": "openclaw-dashboard"}}}], "ports": [{"protocol": "TCP", "port": 8443}]}])

    def test_pilot_and_fleet_render_pin_tunnel_to_the_same_immutable_agent_image(self):
        for agents, overlay in ((["agent-designer"], "infuseai"), (sorted(transport.AGENTS), "infuseai"),
                                (["agent-designer"], "studio-mission-cutover")):
            with self.subTest(agents=agents, overlay=overlay), tempfile.TemporaryDirectory() as temporary:
                path = Path(temporary) / "transport.json"
                path.write_text(json.dumps({"version": 1, "enabledAgents": agents}))
                digest = "sha256:" + "a" * 64
                result = subprocess.run([str(ROOT / "scripts/render-infuseai-agents.sh")], cwd=ROOT,
                    env={**os.environ, "INTERNAL_GATEWAY_TRANSPORT_CONFIG": str(path), "IMAGE_REVISION": digest, "OVERLAY_NAME": overlay,
                         "STUDIO_NATIVE_PROFILE": "production"},
                    capture_output=True, text=True, check=True)
                documents = re.split(r"^---\s*$", result.stdout, flags=re.M)
                for agent in transport.AGENTS:
                    deployment = next(doc for doc in documents if re.search(r"^kind: Deployment$", doc, re.M) and re.search(rf"^  name: {agent}$", doc, re.M))
                    expected = 2 if agent in agents else 1
                    self.assertEqual(deployment.count("image: registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@" + digest), expected)
                    self.assertEqual("name: gateway-internal-tls" in deployment, agent in agents)
                    if agent in agents:
                        self.assertRegex(deployment, r"name: openclaw-gateway-tls-tunnel-[a-z0-9]+")
                        self.assertIn(f"secretName: {agent}-dashboard-internal-tls", deployment)
                self.assertEqual(result.stdout.count("port: 443\n    protocol: TCP\n    targetPort: 8443"), len(agents))

    def test_real_tls_http_websocket_and_certificate_rejection_contract(self):
        result = subprocess.run([os.environ.get("NODE_BINARY", "node"), "--test", str(ROOT / "tests/gateway-internal-tls.test.mjs")],
            cwd=ROOT, capture_output=True, text=True, timeout=45)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
