from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "phase5-fixtures/v2026.11.3"


def load_run_lane():
    spec = importlib.util.spec_from_file_location("phase5_swarm_run_lane", FIXTURE / "run_lane.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


RUN_LANE = load_run_lane()


class Phase5SwarmFixtureTests(unittest.TestCase):
    def test_contracts_close_the_two_swarm_lanes(self) -> None:
        expected = {"amd64.json": "amd64", "local-image.json": "localImage"}
        for filename, lane in expected.items():
            contract = json.loads((FIXTURE / "contracts" / filename).read_text())
            self.assertEqual(contract["schema"], 1)
            self.assertEqual(contract["lane"], lane)
            self.assertEqual(contract["command"]["argv"], ["python3", "-B", "run_lane.py", lane])
            self.assertEqual(contract["cleanup"]["argv"], ["python3", "-B", "cleanup.py"])
            self.assertEqual(contract["cleanupScope"], "fixture-owned-only")

    def test_candidate_and_image_inputs_are_digest_pinned(self) -> None:
        contract = json.loads((FIXTURE / "candidate-contract.json").read_text())
        self.assertEqual((contract["schema"], contract["version"]), (1, "2026.11.3"))
        self.assertNotIn("sourceCommit", contract)
        self.assertNotIn("sourceLockSha256", contract)
        self.assertNotIn("buildTimestamp", contract)
        self.assertRegex(contract["nodeImage"], r"@sha256:[a-f0-9]{64}$")
        self.assertRegex(contract["playwrightImage"], r"@sha256:[a-f0-9]{64}$")
        dockerfile = (FIXTURE / "local-image.Dockerfile").read_text()
        self.assertIn(contract["playwrightImage"], dockerfile)
        self.assertNotIn(":latest", dockerfile)

    def test_candidate_identity_and_package_are_read_from_the_sealed_inputs(self) -> None:
        source_commit = "a" * 40
        package_file = "openclaw-2026.11.3-aabbccddee.tgz"
        package_bytes = b"candidate"
        package_sha = hashlib.sha256(package_bytes).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            plan = Path(directory)
            packages = plan / "packages"
            packages.mkdir()
            (packages / package_file).write_bytes(package_bytes)
            (plan / "phase5-plan.json").write_text(json.dumps({
                "sourceCommit": source_commit,
                "packages": [{"name": "openclaw", "file": package_file, "sha256": package_sha}],
            }))
            candidate = plan / "candidate-manifest.json"
            candidate.write_text(json.dumps({
                "hostVersion": "2026.11.3",
                "hostCommit": source_commit,
                "hostPackageFile": package_file,
                "hostPackageSha256": package_sha,
            }))

            _, candidate_data, core = RUN_LANE.sealed_candidate_inputs(plan, packages, candidate)

        self.assertEqual(candidate_data["hostCommit"], source_commit)
        self.assertEqual(core["file"], package_file)

    def test_fixture_does_not_retain_a_candidate_specific_source_or_package_name(self) -> None:
        stale_source = "f5fce6c00efea370749cd56d00c7600048e0e080"
        stale_package = "openclaw-2026.11.3-f5fce6c00e.tgz"
        fixture_source = "\n".join(path.read_text() for path in FIXTURE.iterdir() if path.is_file())
        self.assertNotIn(stale_source, fixture_source)
        self.assertNotIn(stale_package, fixture_source)

    def test_lane_checks_are_explicit_and_non_synthetic(self) -> None:
        self.assertEqual(
            RUN_LANE.CHECKS,
            {
                "amd64": ["normalInstall", "pluginStartup", "readiness", "ownerPersistence", "signalContinuity", "cleanTermination", "beforeAfterCustody"],
                "localImage": ["assembledInputPreflight", "build", "architecture", "imageDigest", "packageCustody", "runtimeAssets", "browserToolbox", "beforeAfterSourceCustody"],
            },
        )
        amd64 = (FIXTURE / "run-amd64.mjs").read_text()
        self.assertIn('process.kill(pid, "SIGSTOP")', amd64)
        self.assertIn('process.kill(pid, "SIGCONT")', amd64)
        self.assertIn('"plugins", "list", "--json"', amd64)
        image = (FIXTURE / "image-probe.mjs").read_text()
        self.assertIn("chromium.launch({ headless: true })", image)

    def test_controller_restricts_inputs_network_and_cleanup_ownership(self) -> None:
        source = (FIXTURE / "run_lane.py").read_text()
        cleanup = (FIXTURE / "cleanup.py").read_text()
        self.assertIn('"--network", "none"', source)
        self.assertIn('"build", "--pull=false", "--network", "none"', source)
        self.assertIn('"--read-only"', source)
        self.assertIn('"--cap-drop", "ALL"', source)
        self.assertIn('"--cap-add", "CHOWN"', source)
        self.assertIn("adapter imported an unreviewed environment value", source)
        self.assertIn("refusing foreign container cleanup", cleanup)
        self.assertIn("refusing foreign image cleanup", cleanup)
        self.assertIn(f'label={{OWNER_LABEL}}=', cleanup)

    def test_proxy_allows_only_the_public_npm_registry(self) -> None:
        proxy = (FIXTURE / "proxy.mjs").read_text()
        self.assertIn('const allowedHost = "registry.npmjs.org"', proxy)
        self.assertIn("refused-http", proxy)
        self.assertIn("refused-connect", proxy)


if __name__ == "__main__":
    unittest.main()
