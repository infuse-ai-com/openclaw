from __future__ import annotations

from pathlib import Path
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[1]
DEPLOY = ROOT / "scripts" / "deploy-infuseai-agents.sh"
OVERLAY = ROOT / "k8s" / "overlays" / "studio-mission-cutover"

RETIRED_DEPLOYMENTS = {
    "sql-mission-session-manager",
    "sql-mission-coordinator-starter",
    "sql-mission-specialist-dispatcher",
    "sql-mission-continuation-dispatcher",
    "sql-mission-gateway-adapter",
}
MAINTENANCE_CRONJOBS = {
    "openclaw-agent-memory-sync",
    "openclaw-agent-model-policy-collector",
    "openclaw-agent-skill-proposal-monitor",
    "openclaw-agent-token-usage-collector",
    "openclaw-scheduler-collector",
}


class SqlMissionRetirementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.rendered = subprocess.run(
            ["kubectl", "kustomize", str(OVERLAY)],
            check=True,
            text=True,
            capture_output=True,
        ).stdout
        cls.deploy = DEPLOY.read_text(encoding="utf-8")
        cls.retirement = cls.deploy.split(
            "retire_legacy_mission_control_resources() {", 1
        )[1].split("\n}\n\n", 1)[0]

    def test_studio_render_contains_no_sql_workers_or_legacy_sidecars(self) -> None:
        for deployment in RETIRED_DEPLOYMENTS:
            self.assertNotIn(f"name: {deployment}", self.rendered)
        self.assertNotIn("name: mission-event-intake", self.rendered)
        self.assertNotIn("name: mission-capability-responder", self.rendered)

    def test_deploy_removes_every_retired_worker(self) -> None:
        for deployment in RETIRED_DEPLOYMENTS:
            self.assertIn(deployment, self.retirement)

    def test_maintenance_cronjobs_are_outside_retirement_scope(self) -> None:
        for cronjob in MAINTENANCE_CRONJOBS:
            self.assertNotIn(cronjob, self.retirement)


if __name__ == "__main__":
    unittest.main()
