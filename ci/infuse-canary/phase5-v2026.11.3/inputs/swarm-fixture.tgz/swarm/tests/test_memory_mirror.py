import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('mirror', Path(__file__).resolve().parents[1] / 'scripts/mirror-agent-memory.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class MirrorTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.repo = self.root / 'seed'
        self.repo.mkdir()
        m.run('git', 'init', '-b', 'main', cwd=self.repo)
        m.run('git', 'config', 'user.name', 'Test', cwd=self.repo)
        m.run('git', 'config', 'user.email', 'test@example.invalid', cwd=self.repo)
        for agent in ('agent-developer', 'agent-designer'):
            p = self.repo / 'agents' / agent
            (p / 'memory').mkdir(parents=True)
            (p / 'MEMORY.md').write_text('# Learned memory\n')
            (p / 'memory/day.md').write_text('original\n')
        self.commit()
        self.origin = self.root / 'origin.git'
        m.run('git', 'clone', '--bare', str(self.repo), str(self.origin))
        self.local = self.root / 'workspace'
        shutil.copytree(self.repo / 'agents/agent-developer', self.local)
        self.state = self.root / 'state'
        self.publish()

    def commit(self):
        m.run('git', 'add', '.', cwd=self.repo)
        m.run('git', 'commit', '-m', 'fixture', cwd=self.repo)

    def publish(self):
        return m.publish('agent-developer', self.local, self.state, origin=str(self.origin))

    def remote(self, path):
        return m.run('git', '--git-dir', str(self.origin), 'show', 'main:' + path)

    def advance(self, agent, data):
        (self.repo / 'agents' / agent / 'memory/day.md').write_text(data)
        self.commit()
        m.run('git', 'push', str(self.origin), 'HEAD:main', cwd=self.repo)

    def test_publish_idempotence_deletion_and_no_profile(self):
        (self.local / 'memory/day.md').unlink()
        (self.local / 'MEMORY.md').write_text('# New learning\n')
        (self.local / 'AGENTS.md').write_text('never export persona')
        result = self.publish()
        self.assertEqual(result['status'], 'published')
        self.assertEqual(self.publish()['status'], 'unchanged')
        tree = m.run('git', '--git-dir', str(self.origin), 'ls-tree', '-r', '--name-only', 'main')
        self.assertNotIn('AGENTS.md', tree)
        self.assertNotIn('agent-developer/memory/day.md', tree)
        self.assertEqual(self.remote('agents/agent-designer/memory/day.md'), 'original')

    def test_peer_advance_retries_without_overwriting(self):
        (self.local / 'memory/day.md').write_text('own update')
        original = m.run
        raced = False
        def race(*args, **kwargs):
            nonlocal raced
            if args[:2] == ('git', 'push') and not raced:
                raced = True
                self.advance('agent-designer', 'peer update')
            return original(*args, **kwargs)
        with patch.object(m, 'run', side_effect=race):
            self.assertEqual(self.publish()['status'], 'published')
        self.assertEqual(self.remote('agents/agent-designer/memory/day.md'), 'peer update')

    def test_same_file_conflict_keeps_learning(self):
        self.advance('agent-developer', 'remote edit')
        (self.local / 'memory/day.md').write_text('local edit')
        with self.assertRaisesRegex(RuntimeError, 'same-file'):
            self.publish()
        self.assertEqual((self.local / 'memory/day.md').read_text(), 'local edit')
        self.assertEqual(self.remote('agents/agent-developer/memory/day.md'), 'remote edit')

    def test_failed_push_keeps_recovery_bundle(self):
        (self.local / 'MEMORY.md').write_text('new learning')
        original = m.run
        def denied(*args, **kwargs):
            if args[:2] == ('git', 'push'): raise RuntimeError('denied')
            return original(*args, **kwargs)
        before = (self.state / 'baseline.json').read_text()
        with patch.object(m, 'run', side_effect=denied), self.assertRaisesRegex(RuntimeError, 'push failed'):
            self.publish()
        self.assertTrue(list((self.state / 'pending').glob('*.bundle')))
        self.assertEqual((self.state / 'baseline.json').read_text(), before)

    def test_changed_capture_rejected(self):
        original = m.snapshot
        calls = 0
        def unstable(path):
            nonlocal calls
            calls += 1
            result = original(path)
            if calls == 2: result['MEMORY.md'] += b'changed'
            return result
        with patch.object(m, 'snapshot', side_effect=unstable), self.assertRaisesRegex(RuntimeError, 'capture'):
            self.publish()

    def test_secret_and_symlink_rejected(self):
        p = self.local / 'memory/day.md'
        p.write_text('API_KEY=' + 'x' * 24)
        with self.assertRaisesRegex(ValueError, 'credential'):
            self.publish()
        p.unlink()
        p.symlink_to(self.repo / 'agents/agent-designer/MEMORY.md')
        with self.assertRaisesRegex(ValueError, 'regular'):
            self.publish()

    def test_first_sync_requires_reconciliation(self):
        (self.state / 'baseline.json').unlink()
        (self.local / 'MEMORY.md').write_text('unreconciled')
        with self.assertRaisesRegex(RuntimeError, 'initial baseline'):
            self.publish()
