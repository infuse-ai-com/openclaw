import assert from 'node:assert/strict';
import { X509Certificate } from 'node:crypto';
import { chmodSync, copyFileSync, mkdtempSync, readFileSync, realpathSync, rmSync, statSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { after, test } from 'node:test';
import { AGENTS, prepare } from '../scripts/internal-gateway-pki.mjs';

const base = realpathSync(mkdtempSync(join(tmpdir(), 'openclaw-pki-fixture-')));
const serverDir = join(base, 'server-ca');
const clientDir = join(base, 'client-ca');
const server = prepare('init-server-ca', { output: serverDir });
const client = prepare('init-client-ca', { output: clientDir });
after(() => rmSync(base, { recursive: true, force: true }));

test('separate dedicated CA identities use constrained CA profiles and protected files', () => {
  assert.notEqual(server.sha256, client.sha256);
  for (const [directory, role] of [[serverDir, 'server'], [clientDir, 'client']]) {
    const certificate = new X509Certificate(readFileSync(join(directory, 'ca.crt')));
    assert.equal(certificate.ca, true);
    assert.equal(certificate.verify(certificate.publicKey), true);
    assert.deepEqual(certificate.keyUsage, [role === 'server' ? '1.3.6.1.5.5.7.3.1' : '1.3.6.1.5.5.7.3.2']);
    assert.equal(statSync(directory).mode & 0o777, 0o700);
    assert.equal(statSync(join(directory, 'ca.key')).mode & 0o777, 0o600);
  }
});

test('all five servers and the dashboard receive exact names, single roles and 90-day leaves', () => {
  const identities = [...AGENTS.map((agent) => ({ role: 'server', agent })), { role: 'client' }];
  for (const { role, agent } of identities) {
    const ca = role === 'server' ? server : client;
    const caDir = role === 'server' ? serverDir : clientDir;
    const output = join(base, agent ?? 'dashboard');
    const record = prepare(`issue-${role}`, { output, caDir, caSha256: ca.sha256, ...(agent ? { agent } : {}) });
    const certificate = new X509Certificate(readFileSync(join(output, 'tls.crt')));
    assert.equal(certificate.ca, false);
    assert.equal(certificate.subjectAltName, `DNS:${record.dns}`);
    assert.equal(Date.parse(record.notAfter) - Date.parse(record.notBefore), 90 * 86400000);
    assert.equal(record.issuer.sha256, ca.sha256);
    assert.equal(statSync(join(output, 'tls.key')).mode & 0o777, 0o600);
    const opposite = spawnSync('openssl', ['verify', '-CAfile', join(caDir, 'ca.crt'), '-purpose', role === 'server' ? 'sslclient' : 'sslserver', join(output, 'tls.crt')]);
    assert.notEqual(opposite.status, 0, 'role confusion must fail chain-purpose verification');
  }
});

test('renewal issues a new key and serial without modifying the retained CA', () => {
  const original = readFileSync(join(serverDir, 'ca.key'));
  const first = new X509Certificate(readFileSync(join(base, AGENTS[0], 'tls.crt')));
  const output = join(base, 'renewed');
  const renewed = prepare('issue-server', { output, caDir: serverDir, caSha256: server.sha256, agent: AGENTS[0] });
  const next = new X509Certificate(readFileSync(join(output, 'tls.crt')));
  assert.notEqual(next.serialNumber, first.serialNumber);
  assert.notEqual(renewed.sha256, first.fingerprint256.replaceAll(':', '').toLowerCase());
  assert.notDeepEqual(readFileSync(join(output, 'tls.key')), readFileSync(join(base, AGENTS[0], 'tls.key')));
  assert.deepEqual(readFileSync(join(serverDir, 'ca.key')), original);
});

test('wrong issuer role, fingerprint, key pairing and unknown identities fail closed', () => {
  const options = { output: join(base, 'must-not-exist'), caDir: serverDir, caSha256: server.sha256, agent: AGENTS[0] };
  assert.throws(() => prepare('issue-server', { ...options, caDir: clientDir, caSha256: client.sha256 }));
  assert.throws(() => prepare('issue-server', { ...options, caSha256: '0'.repeat(64) }));
  assert.throws(() => prepare('issue-server', { ...options, agent: 'agent-unknown' }));
  assert.throws(() => prepare('issue-client', options));
  const original = readFileSync(join(serverDir, 'ca.key'));
  copyFileSync(join(clientDir, 'ca.key'), join(serverDir, 'ca.key'));
  assert.throws(() => prepare('issue-server', options));
  // Restore only ephemeral test fixtures, never production CA material.
  writeFileSync(join(serverDir, 'ca.key'), original);
});

test('output reuse, symlinks, permissive key files and unexpected flags are refused', () => {
  assert.throws(() => prepare('init-client-ca', { output: clientDir }));
  const link = join(base, 'linked-ca');
  symlinkSync(clientDir, link);
  assert.throws(() => prepare('issue-client', { output: join(base, 'bad-link'), caDir: link, caSha256: client.sha256 }));
  chmodSync(join(clientDir, 'ca.key'), 0o644);
  assert.throws(() => prepare('issue-client', { output: join(base, 'bad-mode'), caDir: clientDir, caSha256: client.sha256 }));
  chmodSync(join(clientDir, 'ca.key'), 0o600);
  assert.throws(() => prepare('init-client-ca', { output: join(base, 'extra'), arbitraryHost: 'other' }));
});

test('issuance refuses a CA that cannot safely cover the next renewal window', () => {
  const originalNow = Date.now;
  try {
    Date.now = () => Date.parse(client.notAfter) - 119 * 86400000;
    assert.throws(() => prepare('issue-client', { output: join(base, 'near-expiry'), caDir: clientDir, caSha256: client.sha256 }));
  } finally {
    Date.now = originalNow;
  }
});

test('CLI failures never echo private input, OpenSSL errors or PEM data', () => {
  const sentinel = 'PRIVATE_SENTINEL_MUST_NOT_APPEAR';
  const result = spawnSync(process.execPath, ['scripts/internal-gateway-pki.mjs', 'issue-client', '--ca-dir', sentinel, '--ca-sha256', '0'.repeat(64), '--output', join(base, 'bad-cli')], { encoding: 'utf8' });
  assert.notEqual(result.status, 0);
  assert.equal(result.stdout, '');
  assert.equal(result.stderr.includes(sentinel), false);
  assert.match(result.stderr, /no live systems were changed/);
});
