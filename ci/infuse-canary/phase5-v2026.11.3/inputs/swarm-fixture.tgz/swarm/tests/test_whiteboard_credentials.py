import copy
import importlib.util
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import provision_whiteboard_credentials as provision


class WhiteboardCredentialTests(unittest.TestCase):
    def setUp(self):
        self.studio = {'enabled': True, 'signers': [], 'bindings': []}
        self.verifier = {'version': 1, 'resource': provision.RESOURCE, 'credentials': []}
        self.metadata = {'credentialId': 'example', 'clientId': 'client', 'gatewayId': 'swarm-developer',
                         'agentId': 'agent-developer', 'issuedAt': 1, 'expiresAt': 2}

    def test_staging_is_read_only_and_idempotent_and_preserves_unrelated(self):
        self.studio['bindings'] = [{'credentialId': 'other', 'clientId': 'other'}]
        self.verifier['credentials'] = [{'credentialId': 'other', 'clientId': 'other'}]
        result, verifier = provision.stage_admission(self.studio, self.verifier, self.metadata, 'a' * 64, 3)
        self.assertEqual(result['bindings'][0], self.studio['bindings'][0])
        self.assertEqual(result['bindings'][1]['projectId'], 'studio')
        self.assertEqual(result['bindings'][1]['enrollmentGeneration'], 3)
        self.assertFalse(verifier['credentials'][1]['enabled'])
        self.assertEqual(provision.stage_admission(result, verifier, self.metadata, 'a' * 64, 3), (result, verifier))
        self.assertEqual(len(self.studio['bindings']), 1)

    def test_conflicting_credential_cannot_be_overwritten_or_broadened(self):
        result, verifier = provision.stage_admission(self.studio, self.verifier, self.metadata, 'a' * 64, 1)
        for field, value in [('agentId', 'agent-infra'), ('gatewayId', 'swarm-infra'), ('expiresAt', 3)]:
            metadata = dict(self.metadata, **{field: value})
            with self.assertRaises(provision.common.ProvisioningError):
                provision.stage_admission(result, verifier, metadata, 'a' * 64, 1)
        with self.assertRaises(provision.common.ProvisioningError):
            provision.stage_admission(result, verifier, self.metadata, 'b' * 64, 1)
        altered = copy.deepcopy(result)
        altered['bindings'][0]['projectId'] = 'private'
        with self.assertRaises(provision.common.ProvisioningError):
            provision.stage_admission(altered, verifier, self.metadata, 'a' * 64, 1)

    def test_failed_vault_write_never_returns_a_credential_for_admission(self):
        def run(_helper, args, **kwargs):
            if args == ['sync']: return '{}'
            if args[:2] == ['list', 'items']: return '[]'
            if args[:3] == ['get', 'template', 'item']: return '{}'
            if args == ['encode']: return 'encoded-fixture'
            raise provision.common.ProvisioningError('Synthetic vault failure')
        with patch.object(provision.common, 'run_bw', side_effect=run):
            with self.assertRaises(provision.common.ProvisioningError):
                provision.stored_item('fixture', 'test', 'collection', lambda: ('synthetic', {}))

    def test_remote_readback_failure_cannot_return_a_usable_credential(self):
        syncs = 0
        def run(_helper, args, **kwargs):
            nonlocal syncs
            if args == ['sync']:
                syncs += 1
                if syncs == 2: raise provision.common.ProvisioningError('Synthetic post-create readback failure')
                return '{}'
            if args[:2] == ['list', 'items']: return '[]'
            if args[:3] == ['get', 'template', 'item']: return '{}'
            if args == ['encode']: return 'encoded-fixture'
            if args == ['create', 'item']: return '{"id":"persisted-but-unverified"}'
            self.fail('Unexpected Vault action')
        with patch.object(provision.common, 'run_bw', side_effect=run):
            with self.assertRaises(provision.common.ProvisioningError):
                provision.stored_item('fixture', 'test', 'collection', lambda: ('synthetic', {}))
        self.assertEqual(syncs, 2)

    def test_existing_item_in_wrong_collection_is_not_replaced(self):
        import json
        item = {'id': 'existing', 'name': 'test', 'organizationId': provision.ORG,
                'collectionIds': ['other-agent'], 'login': {'password': 'synthetic'}}
        actions = []
        def run(_helper, args, **kwargs):
            actions.append(args)
            return '{}' if args == ['sync'] else json.dumps([item])
        with patch.object(provision.common, 'run_bw', side_effect=run):
            with self.assertRaises(provision.common.ProvisioningError):
                provision.stored_item('fixture', 'test', 'expected-agent', lambda: self.fail('Must not rotate'))
        self.assertFalse(any(a[0] in ['create', 'edit'] for a in actions))

    def test_intake_is_not_enrolled_from_pod_presence(self):
        self.assertNotIn('intake', provision.COLLECTIONS)

    def test_agent_cli_cannot_send_writes(self):
        spec = importlib.util.spec_from_file_location('whiteboard_client', ROOT / 'scripts/studio-whiteboard.py')
        client = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(client)
        for kind in ['apply', 'render', 'start', 'post_update']:
            with self.assertRaises(ValueError): client.call(kind, {})


if __name__ == '__main__': unittest.main()
