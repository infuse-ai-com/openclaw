from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "export-agent-capability-snapshot.py"
SPEC = importlib.util.spec_from_file_location("agent_capability_snapshot", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
SNAPSHOT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SNAPSHOT)
SKILL_REVISION = "6f4f6b83619e2fb095578c27eee11a5ebf76d092"


def sealed_handoff(repository: str = "openclaw-k8s-swarm") -> dict:
    value = {
        "schema": SNAPSHOT.HANDOFF_SCHEMA,
        "content_sha256": "",
        "target": {
            "agent": "agent-developer",
            "role": "implementation engineer",
            "mattermost_handle": "@agent-developer",
        },
        "repository": {"name": repository},
        "input_refs": [{
            "input_id": "coordinator-handoff",
            "producer": "agent-coordinator",
            "artifact_id": "handoff",
            "revision": "r1",
        }],
        "requirements": [
            {"class": "input", "subject": "coordinator-handoff"},
            {"class": "skill", "subject": "scoped-implementation-delivery"},
            {"class": "repository", "subject": repository},
            {"class": "tool", "subject": "pnpm"},
            {"class": "workspace", "subject": "isolated-task-workspace"},
            {"class": "verification", "subject": "unit"},
            {"class": "approval", "subject": "production-v2-activation"},
        ],
    }
    value["content_sha256"] = SNAPSHOT.sha256({key: item for key, item in value.items() if key != "content_sha256"})
    return value


def runtime_capabilities() -> dict:
    return {
        "schemaVersion": 2,
        "docker": {"cli": {"available": True, "version": "Docker 27"}},
        "composeValidation": {"available": True},
        "containerBuild": {"mode": "ci_required"},
        "browserAutomation": {"available": False},
        "imageComposition": {"available": False},
        "nodeWorkspace": {"pnpm": {"available": True, "version": "10.0.0"}},
    }


class AgentCapabilitySnapshotTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.handoff = self.root / "handoff.json"
        self.manifest = self.root / "skill-manifest.json"
        self.runtime = self.root / "runtime.json"
        self.registry = self.root / "task-registry.json"
        self.handoff.write_text(json.dumps(sealed_handoff()), encoding="utf-8")
        self.manifest.write_text(json.dumps({
            "agent_id": "agent-developer",
            "source_sync": "latest",
            "source_filter": None,
            "declared_skills": ["scoped-implementation-delivery"],
            "sources": {
                "infuse-ai-agent-skills": {
                    "id": "infuse-ai-agent-skills",
                    "repo": "agent-skills",
                    "kind": "git",
                    "branch": "main",
                    "commit": SKILL_REVISION,
                    "dirty": False,
                },
            },
            "skills": [{
                "id": "scoped-implementation-delivery",
                "source": "infuse-ai-agent-skills",
                "source_commit": SKILL_REVISION,
                "files": [{"path": "SKILL.md", "sha256": "b" * 64, "bytes": 123}],
            }],
            "runtime_native_skills": [],
        }), encoding="utf-8")
        self.active_manifest = self.root / "skill-source-sync-manifest.json"
        active_manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
        active_manifest["source_filter"] = ["infuse-ai-agent-skills"]
        self.active_manifest.write_text(json.dumps(active_manifest), encoding="utf-8")
        self.runtime.write_text(json.dumps(runtime_capabilities()), encoding="utf-8")
        self.registry.write_text(json.dumps({
            "version": 1,
            "tasks": {"task-a": {"status": "active"}},
        }), encoding="utf-8")

    def tearDown(self) -> None:
        self.temp.cleanup()

    def args(self, **overrides: object) -> argparse.Namespace:
        values = {
            "handoff": self.handoff,
            "agent_id": None,
            "bundle_dir": ROOT / "config" / "agent-skill-bundles",
            "catalog": ROOT / "config" / "backoffice-agent-catalog.v1.json",
            "skill_manifest": self.manifest,
            "active_skill_manifest": self.active_manifest,
            "runtime_capabilities": self.runtime,
            "task_registry": self.registry,
            "approval": ["production-v2-activation:pending"],
            "observed_at": "2026-09-01T08:05:00Z",
            "ttl_seconds": 900,
            "pod_uid": "pod-uid-1",
            "image_revision": "image-r1",
            "artifact_client": None,
            "artifact_registry_url": None,
            "artifact_registry_token_file": None,
            "output": None,
        }
        values.update(overrides)
        return argparse.Namespace(**values)

    def test_exports_only_requested_sanitized_capabilities(self) -> None:
        result = SNAPSHOT.build_snapshot(self.args())
        self.assertEqual(result["agent_id"], "agent-developer")
        self.assertEqual(result["mattermost_handle"], "@agent-developer")
        self.assertEqual(result["skills"], [{"id": "scoped-implementation-delivery", "source_revision": SKILL_REVISION}])
        self.assertEqual(result["repositories"], ["openclaw-k8s-swarm"])
        self.assertEqual(result["tools"], [{"id": "pnpm", "version": "10.0.0"}])
        self.assertEqual(result["verification_classes"], ["unit"])
        self.assertEqual(result["workspace"]["capacity_remaining"], 3)
        self.assertEqual(result["readable_inputs"], [])
        self.assertEqual(result["runtime_identity"]["pod_uid"], "pod-uid-1")
        self.assertEqual(
            result["runtime_identity"]["approval_revision"],
            SNAPSHOT.sha256(result["approvals"]),
        )
        self.assertRegex(result["snapshot_revision"], r"^[0-9a-f]{64}$")
        serialized = json.dumps(result)
        for forbidden in ("command", "path", "purpose", "sync_target", "raw", "password", "token"):
            self.assertNotIn(forbidden, serialized.casefold())

    def test_denied_repository_is_not_claimed(self) -> None:
        self.handoff.write_text(json.dumps(sealed_handoff("infrastructure")), encoding="utf-8")
        result = SNAPSHOT.build_snapshot(self.args())
        self.assertEqual(result["repositories"], [])

    def test_absent_runtime_skill_revision_is_not_invented(self) -> None:
        sources = json.loads(self.manifest.read_text(encoding="utf-8"))["sources"]
        empty = {
            "agent_id": "agent-developer",
            "source_sync": "latest",
            "source_filter": None,
            "declared_skills": [],
            "sources": sources,
            "skills": [],
            "runtime_native_skills": [],
        }
        self.manifest.write_text(json.dumps(empty), encoding="utf-8")
        empty["source_filter"] = ["infuse-ai-agent-skills"]
        self.active_manifest.write_text(json.dumps(empty), encoding="utf-8")
        result = SNAPSHOT.build_snapshot(self.args())
        self.assertEqual(result["skills"], [])

    def test_bundle_and_active_source_sync_drift_fails_closed(self) -> None:
        active = json.loads(self.active_manifest.read_text(encoding="utf-8"))
        active["sources"]["infuse-ai-agent-skills"]["commit"] = "a" * 40
        active["skills"][0]["source_commit"] = "a" * 40
        self.active_manifest.write_text(json.dumps(active), encoding="utf-8")

        with self.assertRaisesRegex(SNAPSHOT.SnapshotError, "bundle and active skill manifests differ"):
            SNAPSHOT.build_snapshot(self.args())

    def test_active_manifest_without_synchronized_source_fails_closed(self) -> None:
        active = json.loads(self.active_manifest.read_text(encoding="utf-8"))
        active["source_filter"] = []
        active["sources"] = {}
        active["skills"] = []
        self.active_manifest.write_text(json.dumps(active), encoding="utf-8")

        with self.assertRaisesRegex(SNAPSHOT.SnapshotError, "synchronized sources"):
            SNAPSHOT.build_snapshot(self.args())

    def test_active_manifest_without_file_hash_fails_closed(self) -> None:
        active = json.loads(self.active_manifest.read_text(encoding="utf-8"))
        del active["skills"][0]["files"][0]["sha256"]
        self.active_manifest.write_text(json.dumps(active), encoding="utf-8")

        with self.assertRaisesRegex(SNAPSHOT.SnapshotError, "invalid sha256"):
            SNAPSHOT.build_snapshot(self.args())

    def test_active_manifest_revision_is_sealed_into_runtime_identity(self) -> None:
        result = SNAPSHOT.build_snapshot(self.args())
        active = json.loads(self.active_manifest.read_text(encoding="utf-8"))
        self.assertEqual(result["runtime_identity"]["skill_bundle_revision"], SNAPSHOT.sha256(active))

    @mock.patch.object(SNAPSHOT.subprocess, "run")
    def test_readable_input_requires_successful_recipient_manifest_probe(self, run: mock.Mock) -> None:
        run.return_value = mock.Mock(
            returncode=0,
            stdout=json.dumps({
                "producer": "agent-coordinator",
                "artifactId": "handoff",
                "revision": "r1",
            }),
        )
        result = SNAPSHOT.build_snapshot(self.args(
            artifact_client=Path("/runtime/artifact-client"),
            artifact_registry_url="https://artifacts.example.invalid",
            artifact_registry_token_file=Path("/runtime/token"),
        ))
        self.assertEqual(result["readable_inputs"], [{
            "input_id": "coordinator-handoff",
            "source_revision": "r1",
        }])
        self.assertEqual(run.call_count, 1)

    def test_missing_registry_reports_workspace_unavailable(self) -> None:
        result = SNAPSHOT.build_snapshot(self.args(task_registry=self.root / "missing.json"))
        self.assertEqual(result["workspace"], {
            "available": False,
            "capacity_remaining": 0,
            "source_revision": "unavailable",
        })

    def test_tampered_handoff_is_rejected(self) -> None:
        value = sealed_handoff()
        value["repository"]["name"] = "backoffice"
        self.handoff.write_text(json.dumps(value), encoding="utf-8")
        with self.assertRaisesRegex(SNAPSHOT.SnapshotError, "content_sha256"):
            SNAPSHOT.build_snapshot(self.args())

    def test_cli_output_matches_library_and_is_deterministic(self) -> None:
        command = [
            str(SCRIPT),
            "--handoff", str(self.handoff),
            "--skill-manifest", str(self.manifest),
            "--active-skill-manifest", str(self.active_manifest),
            "--runtime-capabilities", str(self.runtime),
            "--task-registry", str(self.registry),
            "--approval", "production-v2-activation:pending",
            "--observed-at", "2026-09-01T08:05:00Z",
            "--pod-uid", "pod-uid-1",
            "--image-revision", "image-r1",
        ]
        first = subprocess.run(command, check=False, text=True, capture_output=True)
        second = subprocess.run(command, check=False, text=True, capture_output=True)
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(first.stdout, second.stdout)

    def test_runtime_image_installs_the_snapshot_exporter_and_sanitized_identity_catalog(self) -> None:
        dockerfile = (ROOT / "images" / "openclaw-agent" / "Dockerfile").read_text(encoding="utf-8")
        self.assertIn("COPY scripts/export-agent-capability-snapshot.py /usr/local/bin/openclaw-agent-capability-snapshot", dockerfile)
        self.assertIn("COPY config/backoffice-agent-catalog.v1.json /opt/openclaw-agent-skill-config/config/backoffice-agent-catalog.v1.json", dockerfile)
        self.assertIn("/usr/local/bin/openclaw-agent-capability-snapshot", dockerfile)


if __name__ == "__main__":
    unittest.main()
