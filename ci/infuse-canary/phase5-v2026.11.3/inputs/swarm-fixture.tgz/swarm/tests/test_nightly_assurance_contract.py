from __future__ import annotations

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]


class NightlyAssuranceContractTests(unittest.TestCase):
    def test_local_assurance_inputs_remain_available(self) -> None:
        sonar = (ROOT / "sonar-project.properties").read_text(encoding="utf-8")
        self.assertTrue((ROOT / "scripts/run-dependency-assurance.sh").is_file())
        self.assertIn("sonar.javascript.lcov.reportPaths=plugin-lcov.info", sonar)
        self.assertIn("sonar.tests=tests,plugins/behavioral-observability/test", sonar)
        self.assertIn("plugins/behavioral-observability/test/**", sonar)

    def test_image_build_uses_exact_canary_inputs(self) -> None:
        taskfile = (ROOT / "Taskfile.yml").read_text(encoding="utf-8")
        for key in (
            "OPENCLAW_PACKAGE_URL",
            "OPENCLAW_PACKAGE_SHA256",
            "OPENCLAW_SOURCE_SHA",
            "OPENCLAW_CANDIDATE_MANIFEST_SHA256",
        ):
            self.assertIn(f"--build-arg {key}={{{{.{key}}}}}", taskfile)
        self.assertNotIn("MATTERMOST_PINNED_PACKAGE_URL", taskfile)

    def test_image_inputs_are_immutable_and_python_packages_are_hash_locked(self) -> None:
        dockerfile = (ROOT / "images/openclaw-agent/Dockerfile").read_text(encoding="utf-8")
        lock = (ROOT / "images/openclaw-agent/requirements-toolbox.lock").read_text(
            encoding="utf-8"
        )

        self.assertRegex(dockerfile, r"FROM node:24.21.0-trixie-slim@sha256:[0-9a-f]{64}")
        self.assertRegex(dockerfile, r"golang:1\.27\.4-bookworm@sha256:[0-9a-f]{64}")
        self.assertRegex(dockerfile, r"ARG KUBERNETES_SOURCE_SHA512=[0-9a-f]{128}")
        self.assertIn("ARG KUBECTL_VERSION=v1.35.8", dockerfile)
        self.assertIn("sha512sum -c -", (ROOT / "scripts/build-agent-go-toolbox.sh").read_text())
        self.assertIn("--require-hashes", dockerfile)
        self.assertIn("sha256sum -c -", dockerfile)
        self.assertIn("npm install -g npm@${NPM_VERSION}", dockerfile)
        self.assertIn("ARG NPM_VERSION=12.2.2", dockerfile)
        self.assertIn("overrides.tmp=0.2.7", dockerfile)
        self.assertNotIn("ARG KUSTOMIZE_VERSION=v5.6.0", dockerfile)
        self.assertIn("playwright==1.63.0", lock)

        package_blocks = re.findall(
            r"(?ms)^[a-z0-9][a-z0-9._-]*==.*?(?=^[a-z0-9][a-z0-9._-]*==|\Z)",
            lock,
        )
        self.assertGreater(len(package_blocks), 20)
        for package_block in package_blocks:
            self.assertIn("--hash=sha256:", package_block)

    def test_gitlab_weekly_assurance_is_isolated_and_structured(self) -> None:
        pipeline = (ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8")
        self.assertIn(
            '$CI_PIPELINE_SOURCE == "schedule" && $ASSURANCE_MODE == "weekly"',
            pipeline,
        )
        self.assertIn("mattermost-assurance-notify@v0.8.4", pipeline)
        for job in (
            "weekly_application_assurance",
            "weekly_dependency_assurance",
            "weekly_sonar_assurance",
            "weekly_repository_assurance",
            "weekly_live_runtime_assurance",
            "weekly_collector_assurance",
            "weekly_release_assurance",
            "weekly_deployed_image_assurance",
            "weekly_recovery_assurance",
        ):
            self.assertIn(f"{job}:", pipeline)
            self.assertIn(f'"{job}":".gitlab-evidence/', pipeline)
        self.assertGreaterEqual(pipeline.count('CI_PIPELINE_SOURCE != "schedule"'), 3)
        self.assertIn(".automatic_candidate_image_policy:", pipeline)
        self.assertEqual(
            pipeline.count("rules: *automatic_candidate_image_rules"), 2
        )
        self.assertIn(
            '$CI_PIPELINE_SOURCE == "push" && $CI_COMMIT_BRANCH == '
            '$CI_DEFAULT_BRANCH && $CI_COMMIT_REF_PROTECTED == "true"',
            pipeline,
        )
        self.assertIn("OPENCLAW_SWARM_ASSURANCE_KUBE_CONFIG_B64", pipeline)
        self.assertIn("OPENCLAW_SWARM_ASSURANCE_HARBOR_USERNAME", pipeline)
        self.assertIn("OPENCLAW_SWARM_ASSURANCE_HARBOR_PASSWORD", pipeline)
        self.assertIn("python3 assurance/install-coverage.py .ci-coverage", pipeline)
        self.assertNotIn("python3 -m pip install", pipeline)

    def test_dependency_assurance_has_no_jq_runtime_dependency(self) -> None:
        script = (ROOT / "scripts/run-dependency-assurance.sh").read_text(
            encoding="utf-8"
        )
        self.assertNotIn("jq ", script)
        self.assertIn('python3 - "$evidence_dir" "$npm_exit" "$python_exit"', script)
        self.assertIn('"summary.json"', script)

    def test_schedule_jobs_do_not_use_delivery_credentials(self) -> None:
        pipeline = (ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8")
        assurance = pipeline.split("verify_openclaw_swarm:", 1)[1]
        self.assertNotIn('test -n "$KUBE_CONFIG_B64"', assurance)
        self.assertNotIn('test -n "$HARBOR_USERNAME"', assurance)
        self.assertNotIn('test -n "$HARBOR_PASSWORD"', assurance)

    def test_delivery_credentials_have_non_assurance_environments(self) -> None:
        pipeline = (ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8")
        self.assertIn(
            "scan_openclaw_image:\n  environment:\n    name: release/image",
            pipeline,
        )
        self.assertIn(
            "verify_approved_openclaw_image:\n"
            "  stage: build\n"
            "  image: >-\n",
            pipeline,
        )
        verifier = pipeline.split("verify_approved_openclaw_image:", 1)[1]
        verifier = verifier.split(".openclaw_kubernetes_job:", 1)[0]
        self.assertIn("environment:\n    name: release/image", verifier)
        self.assertIn("environment:\n    name: production", pipeline)

    def test_assurance_rbac_is_exact_name_get_only(self) -> None:
        manifest = (ROOT / "deploy/gitlab/openclaw-swarm-assurance-rbac.yaml").read_text(
            encoding="utf-8"
        )
        self.assertGreaterEqual(manifest.count("name: gitlab-openclaw-swarm-assurance"), 4)
        self.assertEqual(manifest.count("verbs: [get]"), 4)
        for forbidden in ("list", "watch", "create", "update", "patch", "delete", "secrets", "pods"):
            self.assertNotIn(f"- {forbidden}", manifest)
        for name in (
            "agent-developer",
            "agent-designer",
            "agent-infra",
            "agent-intake",
            "agent-coordinator",
            "openclaw-otel-collector",
            "openclaw-agent-memory-sync",
            "openclaw-scheduler-collector",
        ):
            self.assertIn(f"- {name}", manifest)

    def test_trivy_convert_template_uses_single_result_root(self) -> None:
        template = (ROOT / "assurance/trivy-finding-lines.tpl").read_text(
            encoding="utf-8"
        )
        self.assertNotIn(".Results", template)
        self.assertIn("range . }}", template)
        self.assertIn("range .Vulnerabilities", template)
        self.assertIn("range .Misconfigurations", template)
        self.assertIn("range .Secrets", template)
        self.assertGreaterEqual(template.count('{{ "\\n" }}'), 3)

        result_writer = (ROOT / "assurance/write-trivy-result.sh").read_text(
            encoding="utf-8"
        )
        self.assertIn("print $1 \"\\t\" $2", result_writer)


if __name__ == "__main__":
    unittest.main()
