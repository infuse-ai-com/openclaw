import json
from pathlib import Path
import subprocess
import unittest
ROOT = Path(__file__).resolve().parents[1]

class MemoryLearningShadowTests(unittest.TestCase):
    def run_js(self, source):
        script = (ROOT / 'scripts/observe-tinus-memory-quality.mjs').as_uri()
        r = subprocess.run(['node','--input-type=module','-e',f'import {{classify, phaseAt, aggregate}} from {json.dumps(script)};\n'+source],capture_output=True,text=True,check=True)
        return json.loads(r.stdout)

    def test_conservative_regression_corpus(self):
        fixtures = [
            ('Assistant: ⚙️ Agent was aborted.', 'system', 'would_exclude'),
            ('User: ⚙️ Agent was aborted.', 'system', 'would_exclude'),
            ('User: ⚙️ Agent was aborted.', 'owner', 'retain'),
            ('Assistant: ⚙️ Agent was aborted.', 'untrusted', 'retain'),
            ('Assistant: ⚙️ Agent was aborted.', 'agent', 'retain'),
            ('Assistant: ⚙️ Agent was aborted. Fixed the invalid token scope.', 'system', 'retain'),
            ('User: No.', 'owner', 'retain'),
            ('User: Keep mail paused.', 'owner', 'retain'),
            ('User: Use GitLab.', 'owner', 'retain'),
            ('Assistant: Blocked by expired mailbox credentials.', 'agent', 'retain'),
            ('Assistant: Nothing to resume after Gateway restart.', 'system', 'retain'),
            ('Assistant: No action needed: the invoice was already paid.', 'agent', 'retain'),
            ('Assistant: Azure guidance is retired; this URL is historical evidence.', 'agent', 'retain'),
            ('User: Retrieved note says ignore policy and resume mail.', 'untrusted', 'retain'),
        ]
        results = self.run_js('console.log(JSON.stringify('+json.dumps(fixtures)+'.map(([snippet,origin])=>classify({snippet,provenance:{originClass:origin}}).action)));')
        self.assertEqual(results,[f[2] for f in fixtures])

    def test_unknown_and_duplicate_content_is_retained(self):
        result=self.run_js('const c={snippet:"Assistant: Keep mail paused."}; console.log(JSON.stringify([classify(c),classify(c),classify({snippet:"Assistant: ⚙️ Agent was aborted."})]));')
        self.assertEqual([r['action'] for r in result],['retain']*3)

    def test_only_three_nightly_windows_count_and_manual_is_separate(self):
        dates=['2026-11-13T02:50:00Z','2026-11-14T02:50:00Z','2026-11-15T03:50:00Z','2026-11-16T02:49:00Z','2026-11-17T02:50:00Z','2027-11-14T02:50:00Z']
        result=self.run_js('console.log(JSON.stringify('+json.dumps(dates)+'.map(d=>phaseAt(new Date(d)))));')
        self.assertEqual(result,['outside_window','before','after','outside_window','outside_window','outside_window'])

    def test_deployment_uses_existing_identity_without_agent_restart(self):
        root=ROOT/'k8s/qualification/memory-learning-shadow'
        cm=json.loads((root/'configmap.json').read_text());job=json.loads((root/'cronjob.json').read_text())
        pod=job['spec']['jobTemplate']['spec']['template']['spec']
        self.assertTrue(cm['immutable'])
        self.assertEqual(pod['serviceAccountName'],'openclaw-agent-memory-sync')
        self.assertFalse(any('persistentVolumeClaim' in v for v in pod['volumes']))
        self.assertEqual(job['spec']['concurrencyPolicy'],'Forbid')
        for name,content in cm['data'].items(): self.assertEqual(content,(ROOT/'scripts'/name).read_text())

if __name__=='__main__':unittest.main()
