import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "dashboard_capabilities", ROOT / "scripts/prepare-dashboard-capabilities.py")
ROLLOUT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ROLLOUT)


class DashboardCapabilitiesRolloutTest(unittest.TestCase):
    def test_five_agents_preserve_live_defaults_and_unrelated_settings(self):
        def read_source(_commit, path):
            return (ROOT / path).read_text()

        policy = json.loads(read_source(None, "config/agent-model-policies.json"))
        choices = policy["defaults"]["selectableModels"]
        with patch.object(ROLLOUT, "source_file", read_source):
            for agent in policy["agents"]:
                with self.subTest(agent=agent):
                    live = {
                        "gateway": {"auth": {"mode": "trusted-proxy"}},
                        "agents": {"defaults": {"model": {"primary": "openai/existing"},
                                                "modelPolicy": {"allow": ["openai/existing"]}},
                                   "entries": {agent: {"model": {"primary": "openai/existing"}}}},
                        "plugins": {"allow": ["codex"], "entries": {"codex": {"enabled": True}}},
                        "browser": {"noSandbox": False, "ssrfPolicy": {"allowedHostnames": ["test.invalid"]}},
                    }
                    container = {"name": "agent", "env": [
                        {"name": "AGENT_ID", "value": agent},
                        {"name": "OPENCLAW_CONFIG_JSON", "value": json.dumps(live)},
                    ]}
                    deployment = {"kind": "Deployment", "metadata": {"name": agent},
                                  "spec": {"template": {"spec": {"containers": [container]}}}}
                    result = json.loads(ROLLOUT.prepare(deployment, "reviewed", agent))
                    self.assertEqual(result["gateway"], live["gateway"])
                    self.assertEqual(result["agents"]["defaults"]["model"], live["agents"]["defaults"]["model"])
                    self.assertEqual(result["agents"]["defaults"]["modelPolicy"]["allow"], ["openai/existing", *choices])
                    self.assertEqual(set(result["agents"]["entries"][agent]["models"]), set(choices))
                    self.assertEqual(result["plugins"]["allow"], ["codex", "browser"])
                    self.assertTrue(result["plugins"]["entries"]["browser"]["enabled"])
                    self.assertEqual(result["browser"]["ssrfPolicy"]["allowedHostnames"], [
                        "test.invalid", "infuse-ai.com", "*.infuse-ai.com",
                        "infuse-ai-tech.party", "*.infuse-ai-tech.party",
                    ])
                    self.assertFalse(result["browser"]["ssrfPolicy"]["dangerouslyAllowPrivateNetwork"])
                    self.assertFalse(result["browser"]["noSandbox"])
                    rerun = copy.deepcopy(deployment)
                    rerun["spec"]["template"]["spec"]["containers"][0]["env"][1]["value"] = json.dumps(result)
                    self.assertEqual(json.loads(ROLLOUT.prepare(rerun, "reviewed", agent)), result)
