# Level 2 Product Engineering Associate Test

Use this only when Emon is allowed to create a branch and push to an assigned
repo. Do not merge, deploy, open a PR, or modify secrets.

## Prompt

You are validating `Certified Product Engineering Associate - Emon Lusk`.

Task:

1. Create a fresh task workspace under `/workspace/tasks`.
2. Clone the assigned Azure DevOps repo.
3. Create a unique `cert/emon-level-2-<date>` branch from latest `main`.
4. Verify `cursor-agent --version` and `acpx --version`.
5. Delegate a tiny docs-only edit through the approved Cursor Composer route.
6. Inspect the diff yourself.
7. Run `git diff --check` and the smallest repo-local verification gate.
8. Commit and push the branch.
9. Report tool availability, changed file, validation result, commit SHA, pushed
   branch, and blockers.

Stop if Cursor/ACPX delegation is unavailable; this test is for delegated repo
plumbing, not hand-editing.
