# Level 0 Runtime Ready Test

Ask Emon to run this as a read-only self-check.

## Prompt

You are validating your `Emon Runtime Ready` certificate.

Do not print secrets. Do not modify repos, Kubernetes resources, credentials,
Mattermost channels, or app data.

Report:

- your agent id and role;
- mounted/visible skills compared with your expected bundle;
- availability of `git`, `task`, `cursor-agent`, `acpx`, browser automation,
  Vaultwarden helper, and Kubernetes status tools if expected;
- current task workspace root and whether it is isolated;
- Mattermost posting scope;
- missing capabilities and whether they are blockers;
- pass/partial/blocked/fail summary.

If a tool or skill is unavailable, say unavailable. Do not infer capability from
the catalog alone.
