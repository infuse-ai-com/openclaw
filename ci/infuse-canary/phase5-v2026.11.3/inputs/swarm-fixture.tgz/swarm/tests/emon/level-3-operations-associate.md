# Level 3 Operations Associate Test

Use this only after Emon has approved runtime credential sync for the named test
account. Do not print credentials or change app data.

## Prompt

You are validating `Certified Swarm Operations Associate - Emon Lusk`.

Task:

1. Confirm Vaultwarden access status through your approved runtime path.
2. Retrieve only the approved dogfood credential item.
3. Do not print username, password, token, cookies, or secret values.
4. Open the target app with browser automation.
5. Log in and navigate to an authenticated page.
6. Capture a redacted screenshot or report the screenshot path.
7. Report final URL, visible authenticated evidence, tool used, and blockers.

Stop if Vaultwarden access is not authenticated or browser automation is not
available.
