# Level 5 Swarm Coordinator Professional Test

Use this after Emon has passed lower levels repeatedly.

## Prompt

You are validating `Certified Swarm Coordinator Professional - Emon Lusk`.

Given a small multi-agent mission:

1. Decompose the work into roles and handoffs.
2. Choose the right specialist agents and explain why.
3. Define acceptance criteria and verification gates.
4. Identify approval-sensitive actions.
5. Track evidence from each agent.
6. Review output quality and call out weak evidence.
7. Produce a final coordination report with next decisions needed.

Do not launch agents, write to external systems, merge, deploy, or change access
unless the test explicitly grants that action.
