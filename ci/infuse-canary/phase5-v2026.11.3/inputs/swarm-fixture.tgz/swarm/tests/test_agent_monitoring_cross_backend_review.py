import copy
import importlib.util
import json
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "review-agent-monitoring-evidence.py"
REVIEW = (
    ROOT
    / "config"
    / "observability"
    / "reviews"
    / "agent-monitoring-cross-backend-acceptance-2026-09-01.json"
)
SPEC = importlib.util.spec_from_file_location("agent_monitoring_review", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class AgentMonitoringCrossBackendReviewTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.package = json.loads(REVIEW.read_text(encoding="utf-8"))

    def test_review_covers_exact_claims_and_fleet(self) -> None:
        report = MODULE.build_report(self.package)
        self.assertEqual(set(report["claims"]), MODULE.EXPECTED_CLAIMS)
        self.assertEqual(set(report["fleetScorecard"]), MODULE.EXPECTED_AGENTS)
        self.assertEqual(
            report["drilldownBackends"],
            ["prometheus", "grafana", "loki", "langfuse"],
        )
        self.assertEqual(report["mutationPolicy"], "human_review_required")

    def test_every_claim_uses_a_governed_status(self) -> None:
        report = MODULE.build_report(self.package)
        self.assertEqual(sum(report["claimStatusCounts"].values()), 8)
        self.assertGreater(report["claimStatusCounts"]["verified"], 0)
        self.assertGreater(report["claimStatusCounts"]["inconclusive"], 0)

    def test_alert_history_cannot_be_misclassified_as_active_impact(self) -> None:
        mutated = copy.deepcopy(self.package)
        mutated["alertClassification"]["historicalNoise"][0]["class"] = (
            "active_agent_impact"
        )
        with self.assertRaisesRegex(MODULE.ReviewError, "alert class disagrees"):
            MODULE.build_report(mutated)

    def test_raw_identifiers_and_content_fields_are_rejected(self) -> None:
        mutated = copy.deepcopy(self.package)
        mutated["claims"][0]["trace_id"] = "a" * 32
        with self.assertRaisesRegex(MODULE.ReviewError, "forbidden field name"):
            MODULE.build_report(mutated)

        mutated = copy.deepcopy(self.package)
        mutated["claims"][0]["summary"] = "trace " + "a" * 32
        with self.assertRaisesRegex(MODULE.ReviewError, "forbidden identifier"):
            MODULE.build_report(mutated)

    def test_recommendations_cannot_auto_mutate_owner_repositories(self) -> None:
        mutated = copy.deepcopy(self.package)
        mutated["recommendations"][0]["requiresHumanReview"] = False
        with self.assertRaisesRegex(MODULE.ReviewError, "human-reviewed"):
            MODULE.build_report(mutated)

    def test_cli_emits_metadata_only_report(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "--input", str(REVIEW)],
            check=True,
            capture_output=True,
            text=True,
        )
        report = json.loads(completed.stdout)
        self.assertEqual(report["privacy"], "metadata_only")
        self.assertNotIn("prompt", completed.stdout.lower())


if __name__ == "__main__":
    unittest.main()
