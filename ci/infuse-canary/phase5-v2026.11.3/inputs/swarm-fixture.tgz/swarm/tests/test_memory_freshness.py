import concurrent.futures
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('memory_refresh', Path(__file__).resolve().parents[1] / 'scripts/refresh-shared-agent-memory.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


class MemoryFreshnessTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name); self.origin = self.base / 'origin'; self.reader = self.base / 'reader'; self.state = self.base / 'state'
        self.origin.mkdir(); m.git(self.origin, 'init', '-b', 'main')
        m.git(self.origin, 'config', 'user.email', 'fixture@example.invalid'); m.git(self.origin, 'config', 'user.name', 'Fixture')
        self.commit('agents/agent-developer/MEMORY.md', 'Useful memory\n')
        self.commit('agents/agent-designer/summaries/handoff.md', 'Original handoff\n')
        self.commit('agents/agent-designer/memory/private.md', 'Peer raw note\n')
        self.commit('history/agents/agent-designer/old.md', 'Historical evidence\n')

    def commit(self, name, text):
        p = self.origin / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text)
        m.git(self.origin, 'add', '.'); m.git(self.origin, 'commit', '-m', 'fixture')
        return m.git(self.origin, 'rev-parse', 'HEAD')

    def refresh(self, **kw):
        return m.refresh(self.reader, self.state, 'agent-developer', origin=str(self.origin), **kw)

    def test_peer_handoff_requires_remote_commit_and_refreshes_without_restart(self):
        first = self.refresh(); self.assertEqual(first['status'], 'unchanged')
        sha = self.commit('agents/agent-designer/summaries/handoff.md', 'New verified handoff\n')
        cached = self.refresh(); self.assertEqual(cached['status'], 'cached'); self.assertEqual(cached['checked_at'], first['checked_at'])
        refreshed = self.refresh(after_commit=sha)
        self.assertEqual(refreshed['status'], 'updated'); self.assertEqual(refreshed['commit'], sha)
        self.assertEqual((self.reader / 'agents/agent-designer/summaries/handoff.md').read_text(), 'New verified handoff\n')
        self.assertFalse((self.reader / 'agents/agent-designer/memory/private.md').exists())
        self.assertFalse((self.reader / 'history').exists())

    def test_missing_handoff_is_not_ready(self):
        self.refresh(); r = self.refresh(after_commit='0' * 40)
        self.assertEqual(r['status'], 'stale'); self.assertEqual(r['reason'], 'handoff_not_on_remote_main')

    def test_dirty_work_is_retained_and_not_published_or_overwritten(self):
        first = self.refresh(); file = self.reader / 'agents/agent-developer/MEMORY.md'; file.write_text('Unpublished correction\n')
        self.commit('agents/agent-developer/MEMORY.md', 'Remote correction\n')
        r = self.refresh(force=True)
        self.assertEqual(r['reason'], 'dirty_checkout'); self.assertEqual(r['commit'], first['commit'])
        self.assertEqual(file.read_text(), 'Unpublished correction\n')

    def test_divergence_and_legacy_refs_are_preserved(self):
        self.refresh(); m.git(self.reader, 'config', 'user.email', 'fixture@example.invalid'); m.git(self.reader, 'config', 'user.name', 'Fixture')
        m.git(self.reader, 'branch', 'agent-memory-legacy/fixture')
        (self.reader / 'agents/agent-developer/MEMORY.md').write_text('Local evidence\n'); m.git(self.reader, 'add', '.'); m.git(self.reader, 'commit', '-m', 'local')
        head = m.git(self.reader, 'rev-parse', 'HEAD'); legacy = m.git(self.reader, 'rev-parse', 'agent-memory-legacy/fixture')
        self.commit('shared/new.md', 'Remote advance\n'); r = self.refresh(force=True)
        self.assertEqual(r['reason'], 'divergent_checkout'); self.assertEqual(m.git(self.reader, 'rev-parse', 'HEAD'), head)
        self.assertEqual(m.git(self.reader, 'rev-parse', 'agent-memory-legacy/fixture'), legacy)

    def test_offline_failure_does_not_reuse_previous_fresh_status(self):
        first = self.refresh(); self.origin.rename(self.base / 'offline')
        r = self.refresh(force=True); self.assertEqual(r['status'], 'stale')
        self.assertEqual(r['checked_at'], first['checked_at']); self.assertEqual(self.refresh()['status'], 'stale')

    def test_authentication_failure_is_explicit_without_stderr_disclosure(self):
        self.refresh(); original = m.git
        def denied(root, *args, **kw):
            if args[0] == 'fetch': raise m.Refused('authentication_failed')
            return original(root, *args, **kw)
        with patch.object(m, 'git', side_effect=denied):
            r = self.refresh(force=True)
        self.assertEqual(r['status'], 'stale'); self.assertEqual(r['reason'], 'authentication_failed')
        with patch.object(m.subprocess, 'run', return_value=subprocess.CompletedProcess([], 128, b'', b'HTTP 401 private diagnostic')):
            with self.assertRaisesRegex(m.Refused, '^authentication_failed$'): m.git(self.reader, 'fetch')

    def test_unexpected_origin_or_branch_never_claims_usable_data(self):
        self.refresh(); m.git(self.reader, 'remote', 'set-url', 'origin', '/untrusted')
        r = self.refresh(force=True); self.assertEqual(r['reason'], 'unexpected_origin'); self.assertIsNone(r['commit'])
        m.git(self.reader, 'remote', 'set-url', 'origin', str(self.origin)); m.git(self.reader, 'checkout', '-b', 'local-draft')
        r = self.refresh(force=True); self.assertEqual(r['reason'], 'unexpected_branch'); self.assertIsNone(r['commit'])

    def test_symlink_state_is_refused(self):
        outside = self.base / 'outside'; outside.mkdir(); self.state.symlink_to(outside)
        self.assertEqual(self.refresh()['reason'], 'unsafe_state_path'); self.assertEqual(list(outside.iterdir()), [])

    def test_overlapping_refreshes_share_one_verified_result(self):
        self.refresh(); sha = self.commit('shared/new.md', 'New evidence\n')
        # Expire the cache so the first caller must fetch; the second must wait and reuse it.
        r = json.loads((self.state / 'receipt.json').read_text()); r['checked_at'] = '2000-01-01T00:00:00+00:00'; m.save_receipt(self.state, r)
        original = m.git; calls = []
        def delayed(root, *args, **kw):
            if args[0] == 'fetch': calls.append(1); time.sleep(0.2)
            return original(root, *args, **kw)
        with patch.object(m, 'git', side_effect=delayed), concurrent.futures.ThreadPoolExecutor(2) as pool:
            results = list(pool.map(lambda _: self.refresh(), range(2)))
        self.assertEqual(len(calls), 1); self.assertEqual({r['commit'] for r in results}, {sha})
        self.assertEqual({r['status'] for r in results}, {'updated', 'cached'})

    def test_busy_lock_is_explicit_and_does_not_mutate_checkout(self):
        self.refresh()
        with m.checkout_lock(self.state):
            r = self.refresh(lock_wait=0)
        self.assertEqual(r['reason'], 'refresh_busy')

    def test_refresh_does_not_execute_checkout_hooks(self):
        self.refresh(); marker = self.base / 'hook-executed'
        hook = self.reader / '.git/hooks/post-merge'
        hook.write_text('#!/bin/sh\ntouch ' + str(marker) + '\n'); hook.chmod(0o755)
        self.commit('shared/new.md', 'Peer evidence\n')
        self.assertEqual(self.refresh(force=True)['status'], 'updated'); self.assertFalse(marker.exists())

    def test_sparse_control_symlink_cannot_overwrite_another_file(self):
        self.refresh(); outside = self.base / 'preserve'; outside.write_text('untouched')
        sparse = self.reader / '.git/info/sparse-checkout'; sparse.unlink(); sparse.symlink_to(outside)
        self.assertEqual(self.refresh(force=True)['reason'], 'unsafe_sparse_checkout_path')
        self.assertEqual(outside.read_text(), 'untouched')


if __name__ == '__main__': unittest.main()
