from pathlib import Path
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[1]


class RuntimeDependencySecurityTests(unittest.TestCase):
    def test_advisory_floors_reject_recorded_regressions(self):
        result = subprocess.run(["node", "--input-type=module", "-e", """
import assert from 'node:assert/strict';
import {nodeFloor, verifyGoReceipt} from './scripts/verify-agent-runtime-dependencies.mjs';
for (const [name, oldVersion, fixed] of [
  ['@modelcontextprotocol/sdk', '1.31.0', '1.32.1'],
  ['body-parser', '2.3.0', '2.4.0'],
  ['brace-expansion', '5.0.9', '5.0.12'],
  ['undici', '6.28.1', '6.29.1'],
  ['undici', '8.11.2', '8.12.2'],
  ['multer', '2.3.0', '2.5.0']]) {
  assert.equal(nodeFloor(name, oldVersion), false);
  assert.equal(nodeFloor(name, fixed), true);
}
assert.equal(nodeFloor('undici', '9.0.0'), false, 'unreviewed major must fail');
assert.throws(() => nodeFloor('undici', '8.12.2-rc.1'));
assert.throws(() => verifyGoReceipt('crane', '/out/crane: go1.26.6\\n'));
assert.throws(() => verifyGoReceipt('kubectl', '/out/kubectl: go1.27.4\\n'));
assert.throws(() => verifyGoReceipt('helm', '/out/helm: go1.27.4\\n\\tdep golang.org/x/net v0.60.0 h1:test\\n'));
assert.equal(verifyGoReceipt('helm', '/out/helm: go1.27.4\\n\\tdep golang.org/x/net v0.62.0 h1:test\\n').compiler, 'go1.27.4');
"""], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
