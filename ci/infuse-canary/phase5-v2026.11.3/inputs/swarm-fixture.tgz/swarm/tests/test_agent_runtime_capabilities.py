"""Tests for the daemon-aware agent capability contract."""

from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path
from unittest import mock


SCRIPT_PATH = Path(__file__).resolve().parents[1] / "scripts/agent-runtime-capabilities.py"
SPEC = importlib.util.spec_from_file_location("agent_runtime_capabilities", SCRIPT_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
EXPORTER_PATH = Path(__file__).resolve().parents[1] / "scripts/export-openclaw-agent-model-policy.py"
EXPORTER_SPEC = importlib.util.spec_from_file_location("model_policy_exporter", EXPORTER_PATH)
assert EXPORTER_SPEC and EXPORTER_SPEC.loader
EXPORTER = importlib.util.module_from_spec(EXPORTER_SPEC)
EXPORTER_SPEC.loader.exec_module(EXPORTER)


class RuntimeCapabilityTests(unittest.TestCase):
    """Keep daemon absence distinct from Compose availability."""

    def test_missing_command_is_classified(self) -> None:
        with mock.patch.object(MODULE.shutil, "which", return_value=None):
            self.assertEqual(
                MODULE.probe(["docker", "--version"]),
                {"available": False, "reason": "command_not_found"},
            )

    def test_required_empty_output_is_unavailable(self) -> None:
        completed = mock.Mock(returncode=0, stdout="", stderr="daemon unavailable")
        with (
            mock.patch.object(MODULE.shutil, "which", return_value="/usr/local/bin/docker"),
            mock.patch.object(MODULE.subprocess, "run", return_value=completed),
        ):
            result = MODULE.probe(
                ["docker", "version", "--format", "{{.Server.Version}}"],
                require_output=True,
            )
        self.assertEqual(result["reason"], "empty_output")
        self.assertFalse(result["available"])

    def test_daemonless_runtime_requires_ci_build(self) -> None:
        docker_results = [
            {"available": True, "version": "Docker version 27.5.1"},
            {"available": True, "version": "2.40.3"},
            {"available": False, "reason": "probe_failed", "exitCode": 1},
        ]
        available = {"available": True, "version": "ok"}
        with (
            mock.patch.object(
                MODULE, "probe", side_effect=docker_results + [available] * 8
            ),
            mock.patch.object(
                MODULE,
                "probe_contact_sheet",
                return_value={"available": True, "backend": "imagemagick_montage"},
            ),
        ):
            payload = MODULE.collect()
        self.assertTrue(payload["composeValidation"]["available"])
        self.assertFalse(payload["composeValidation"]["requiresDaemon"])
        self.assertEqual(payload["containerBuild"]["mode"], "ci_required")
        self.assertTrue(payload["browserAutomation"]["available"])
        self.assertTrue(payload["imageComposition"]["available"])
        self.assertEqual(
            payload["artifactPortability"]["mode"], "project_declared_or_bundled"
        )
        self.assertFalse(payload["artifactPortability"]["ambientRuntimeIsPortable"])

    def test_daemon_enables_local_build(self) -> None:
        available = {"available": True, "version": "ok"}
        with (
            mock.patch.object(MODULE, "probe", side_effect=[available] * 11),
            mock.patch.object(
                MODULE,
                "probe_contact_sheet",
                return_value={"available": True, "backend": "imagemagick_montage"},
            ),
        ):
            payload = MODULE.collect()
        self.assertEqual(payload["containerBuild"]["mode"], "local")
        self.assertEqual(payload["languageRuntimes"]["ruby"]["executionMode"], "local")

    def test_browser_and_image_capabilities_report_missing_tools(self) -> None:
        available = {"available": True, "version": "ok"}
        missing = {"available": False, "reason": "command_not_found"}
        probe_results = [
            available,
            available,
            missing,
            available,
            missing,
            available,
            available,
            missing,  # Ruby is independently unavailable.
            available,
            available,
            missing,
        ]
        with (
            mock.patch.object(MODULE, "probe", side_effect=probe_results),
            mock.patch.object(
                MODULE,
                "probe_contact_sheet",
                return_value={"available": False, "reason": "probe_failed"},
            ),
        ):
            payload = MODULE.collect()

        self.assertFalse(payload["browserAutomation"]["available"])
        self.assertFalse(payload["imageComposition"]["available"])

    def test_ruby_absence_routes_to_project_environment(self) -> None:
        def probe(command, **_kwargs):
            if command[0] == "ruby":
                return {"available": False, "reason": "command_not_found"}
            return {"available": True, "version": "fixture"}

        with (
            mock.patch.object(MODULE, "probe", side_effect=probe),
            mock.patch.object(MODULE, "probe_contact_sheet", return_value={"available": True}),
        ):
            payload = MODULE.collect()
        self.assertFalse(payload["languageRuntimes"]["ruby"]["available"])
        self.assertEqual(
            payload["languageRuntimes"]["ruby"]["executionMode"],
            "project_environment_required",
        )
        self.assertTrue(payload["browserAutomation"]["available"])
        self.assertTrue(payload["imageComposition"]["available"])

    def test_contact_sheet_probe_reports_failing_stage(self) -> None:
        passed = mock.Mock(returncode=0, stdout="", stderr="")
        failed = mock.Mock(returncode=134, stdout="", stderr="Aborted")
        with (
            mock.patch.object(MODULE.shutil, "which", return_value="/usr/bin/tool"),
            mock.patch.object(
                MODULE.subprocess, "run", side_effect=[passed, passed, failed]
            ),
        ):
            payload = MODULE.probe_contact_sheet()

        self.assertFalse(payload["available"])
        self.assertEqual(payload["reason"], "probe_failed")
        self.assertEqual(payload["stage"], "montage")
        self.assertEqual(payload["stageIndex"], 2)
        self.assertEqual(payload["exitCode"], 134)

    def test_model_exporter_reads_openclaw_fallbacks_key(self) -> None:
        self.assertEqual(
            EXPORTER.extract_fallbacks(
                {"primary": "openai/gpt-5.6-sol", "fallbacks": ["openai/gpt-5.6-terra"]}
            ),
            ["openai/gpt-5.6-terra"],
        )

    def test_model_exporter_prefers_openclaw_entries_schema(self) -> None:
        observed = EXPORTER.extract_observed_policy(
            {
                "agents": {
                    "defaults": {"model": {"primary": "openai/default"}},
                    "entries": {
                        "agent-designer": {
                            "model": {
                                "primary": "openai/gpt-6-astra",
                                "fallbacks": ["openai/gpt-5.6-sol"],
                            },
                            "thinkingDefault": "high",
                        }
                    },
                }
            },
            "agent-designer",
        )
        self.assertEqual(observed["model"], "openai/gpt-6-astra")
        self.assertEqual(observed["fallbackModels"], ["openai/gpt-5.6-sol"])
        self.assertEqual(observed["thinkingDefault"], "high")


if __name__ == "__main__":
    unittest.main()
