from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "agent-skill-proposal.py"
SPEC = importlib.util.spec_from_file_location("agent_skill_proposal", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class AgentSkillProposalTests(unittest.TestCase):
    def test_quarantine_preserves_content_and_deduplicates_notification(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = Path(temp_dir)
            agent_id = "agent-developer"
            agent_dir = workspace / "agents" / agent_id
            skill_dir = agent_dir / "skills" / "new-local-skill"
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text("# Candidate\n", encoding="utf-8")
            reporter = workspace / "reporter.py"
            reporter.write_text(
                "#!/usr/bin/env python3\n"
                "import json\n"
                "print(json.dumps({'skills': {'unmanaged_directories': ['new-local-skill']}}))\n",
                encoding="utf-8",
            )
            reporter.chmod(0o755)
            previous = os.environ.get("OPENCLAW_AGENT_DRIFT_REPORT")
            os.environ["OPENCLAW_AGENT_DRIFT_REPORT"] = str(reporter)
            try:
                proposals_root = agent_dir / "skill-proposals"
                quarantined = MODULE.quarantine(
                    agent_id=agent_id,
                    workspace=workspace,
                    proposals_root=proposals_root,
                )
                self.assertEqual(len(quarantined), 1)
                digest = quarantined[0]["digest"]
                self.assertFalse(skill_dir.exists())
                preserved = proposals_root / "new-local-skill" / digest / "skill" / "SKILL.md"
                self.assertEqual(preserved.read_text(encoding="utf-8"), "# Candidate\n")
                proposals = MODULE.list_proposals(proposals_root, agent_id)
                self.assertEqual(len(proposals), 1)
                self.assertFalse(proposals[0]["notified"])
                marker = MODULE.mark_notified(
                    proposals_root,
                    "new-local-skill",
                    digest,
                    "channel:test",
                )
                self.assertEqual(marker["digest"], digest)
                self.assertTrue(MODULE.list_proposals(proposals_root, agent_id)[0]["notified"])

                skill_dir.mkdir(parents=True)
                (skill_dir / "SKILL.md").write_text("# Candidate\n", encoding="utf-8")
                MODULE.quarantine(
                    agent_id=agent_id,
                    workspace=workspace,
                    proposals_root=proposals_root,
                )
                self.assertFalse(skill_dir.exists())
                self.assertEqual(len(MODULE.list_proposals(proposals_root, agent_id)), 1)
            finally:
                if previous is None:
                    os.environ.pop("OPENCLAW_AGENT_DRIFT_REPORT", None)
                else:
                    os.environ["OPENCLAW_AGENT_DRIFT_REPORT"] = previous

    def test_digest_changes_when_content_changes(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            path = root / "SKILL.md"
            path.write_text("first\n", encoding="utf-8")
            first = MODULE.tree_digest(root)
            path.write_text("second\n", encoding="utf-8")
            self.assertNotEqual(first, MODULE.tree_digest(root))

    def test_unsafe_directory_name_is_not_reflected_in_proposal_identity(self) -> None:
        self.assertRegex(MODULE.proposal_key("line\nbreak"), r"^invalid-name-[0-9a-f]{16}$")


if __name__ == "__main__":
    unittest.main()
