"""Authority switches retain native custody and cannot silently select another backend."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from studio_native_profiles import ROLES, select_profile, validate_contract

spec = importlib.util.spec_from_file_location('native_profiles_overlay', ROOT / 'scripts/prepare-studio-native-overlay.py')
overlay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(overlay)
PRODUCTION = json.loads((ROOT / 'config/studio-native-routes.json').read_text())
LOCAL = json.loads((ROOT / 'config/studio-native-routes.local-mac.json').read_text())


class StudioNativeProfileTests(unittest.TestCase):
    def test_authority_switch_requires_explicit_settlement_attestation_both_directions(self):
        production = {'data': {'authority': 'studio'}}
        local = {'data': {'authority': 'studio-local-mac', 'nativeProfile': 'local-mac'}}
        self.assertEqual(select_profile(None, 'preserve', False), {'profile': 'production', 'changed': False, 'preserveDeployments': []})
        self.assertEqual(select_profile(local, 'preserve', False), {'profile': 'local-mac', 'changed': False, 'preserveDeployments': []})
        for marker, destination in ((production, 'local-mac'), (local, 'production')):
            with self.assertRaisesRegex(ValueError, 'all runs/effects are settled'):
                select_profile(marker, destination, False)
            self.assertEqual(select_profile(marker, destination, True), {'profile': destination, 'changed': True, 'preserveDeployments': []})
        for marker, requested in ((None, 'local-mac'), ({'data': {'authority': 'unknown'}}, 'preserve'),
                                  ({'data': {'authority': 'studio', 'nativeProfile': 'local-mac'}}, 'preserve'),
                                  (local, 'unknown')):
            with self.assertRaises(ValueError):
                select_profile(marker, requested, True)

    def test_switch_replaces_all_native_gateways_even_when_the_classifier_preserves_them(self):
        marker = {'data': {'authority': 'studio'}}
        fleet = [*ROLES.values(), 'agent-intake']
        self.assertEqual(select_profile(marker, 'preserve', False, fleet)['preserveDeployments'], fleet)
        self.assertEqual(select_profile(marker, 'local-mac', True, fleet)['preserveDeployments'], ['agent-intake'])
        with self.assertRaisesRegex(ValueError, 'Unknown or duplicate'):
            select_profile(marker, 'local-mac', True, ['unknown-agent'])

    def test_partial_profile_rollout_retry_replaces_the_entire_native_fleet(self):
        fleet = [*ROLES.values(), 'agent-intake']
        for name, authority in (('production', 'studio'), ('local-mac', 'studio-local-mac')):
            marker = {'data': {'authority': authority, 'nativeProfile': name, 'nativeProfileState': 'pending'}}
            result = select_profile(marker, 'preserve', False, fleet)
            self.assertEqual(result, {'profile': name, 'changed': False, 'preserveDeployments': ['agent-intake']})
            marker['data']['nativeProfileState'] = 'active'
            self.assertEqual(select_profile(marker, 'preserve', False, fleet)['preserveDeployments'], fleet)
            marker['data']['nativeProfileState'] = 'unknown'
            with self.assertRaisesRegex(ValueError, 'rollout state'):
                select_profile(marker, 'preserve', False, fleet)

    def test_mac_rejects_production_channels_identity_drift_and_unreviewed_destinations(self):
        for mutation in (
            lambda c: c.update(studioUrl='https://different.example'),
            lambda c: c.update(authorityId='studio-production'),
            lambda c: c.update(journalNamespace='production'),
            lambda c: c['routes'][0].update(channelId=PRODUCTION['routes'][1]['channelId']),
            lambda c: c['routes'][0].update(nativeBotUserId='x' * 26),
            lambda c: c['routes'].pop(),
        ):
            contract = copy.deepcopy(LOCAL)
            mutation(contract)
            with self.assertRaises(ValueError):
                validate_contract(contract, PRODUCTION)

    def test_render_retains_ordinary_capabilities_and_separates_every_credential_and_route(self):
        with tempfile.TemporaryDirectory() as directory:
            prepared = {}
            for name, contract in (('production', PRODUCTION), ('local-mac', LOCAL)):
                k8s = Path(directory) / name
                shutil.copytree(ROOT / 'k8s', k8s)
                overlay.prepare(k8s, contract)
                prepared[name] = k8s
                for route in contract['routes']:
                    agent = route['agentId']
                    path = Path('agents') / agent / 'deployment.yaml'
                    original = json.loads(overlay.CONFIG.search((ROOT / 'k8s' / path).read_text())[2])
                    text = (k8s / path).read_text()
                    updated = json.loads(overlay.CONFIG.search(text)[2])
                    native = updated['plugins']['entries'].pop('infuse-studio')['config']
                    original['plugins']['entries'].pop('infuse-studio', None)
                    for config in (original, updated):
                        config['plugins']['allow'] = [x for x in config['plugins']['allow'] if x != 'infuse-studio']
                    self.assertEqual(original, updated)
                    self.assertEqual(native['authorityId'], contract['authorityId'])
                    self.assertEqual(native['journalNamespace'], name)
                    self.assertEqual(native.get('floorRuntimeDiscovery', False), name == 'production')
                    self.assertEqual(native.get('whiteboardEnabled', False), name == 'production')
                    self.assertEqual(native.get('companionEnabled', False), name == 'production')
                    self.assertEqual(native['studioUrl'], contract['studioUrl'])
                    if agent in overlay.DASHBOARD_TRUSTED_PROXY_AGENTS:
                        self.assertEqual(native['localConnection'], {
                            'url': 'ws://127.0.0.1:18791', 'passwordEnv': 'OPENCLAW_GATEWAY_PASSWORD'})
                    else:
                        self.assertEqual(native['localConnection'], {
                            'url': 'ws://127.0.0.1:18791', 'tokenEnv': 'OPENCLAW_GATEWAY_TOKEN'})
                    self.assertEqual(native['nativeRoutes'][0]['nativeBotUserId'], route['nativeBotUserId'])
                    channels = {r['channelId'] for r in native['nativeRoutes']}
                    all_routes = contract['routes'] + [r for p in contract.get('projects', []) for r in p['routes']]
                    self.assertEqual(channels, {r['channelId'] for r in all_routes if route['role'] == 'coordinator' or r['agentId'] == agent})
                    self.assertEqual({r['projectId'] for r in native['nativeRoutes']}, {'studio', 'finaxis'} if name == 'production' and agent != 'agent-infra' else {'studio'})
                    if name == 'local-mac':
                        self.assertEqual(native['studioConnectAddress'], '100.66.41.78')
                        self.assertNotIn('studioCaFile', native)
                        self.assertIn('name: ' + agent + '-studio-local-mac\n', text)
                        self.assertNotIn('name: ' + agent + '-studio\n', text)
                        self.assertNotIn('name: studio-trust\n', text)
                        self.assertNotIn('name: whiteboard-mcp\n', text)
                    else:
                        self.assertEqual(native['studioCaFile'], '/var/run/studio/ca.crt')
                        self.assertIn('name: ' + agent + '-studio\n', text)
                self.assertEqual((k8s / 'agents/agent-intake/deployment.yaml').read_bytes(),
                                 (ROOT / 'k8s/agents/agent-intake/deployment.yaml').read_bytes())
                result = subprocess.run(['kubectl', 'kustomize', str(k8s / 'overlays/studio-mission-cutover')], capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stderr)
            local_marker = (prepared['local-mac'] / 'overlays/studio-mission-cutover/authority.yaml').read_text()
            self.assertIn('authority: studio-local-mac', local_marker)
            self.assertIn('nativeProfile: local-mac', local_marker)
            self.assertIn('nativeProfileState: pending', local_marker)
            # The legacy deployer accepted only authority=studio; it must refuse
            # a Mac profile rather than silently restoring production config.
            self.assertNotRegex(local_marker, r'(?m)^  authority: studio$')

    def test_projects_reject_identity_drift_overlap_and_mac_rebinding(self):
        for mutate in (
            lambda c: c['projects'][0].update(projectId='unreviewed'),
            lambda c: c['projects'][0]['routes'][0].update(nativeBotUserId='x' * 26),
            lambda c: c['projects'][0]['routes'][0].update(channelId=c['routes'][0]['channelId']),
            lambda c: c['projects'][0]['routes'].pop(),
        ):
            changed = copy.deepcopy(PRODUCTION)
            mutate(changed)
            with self.assertRaises(ValueError):
                validate_contract(changed, PRODUCTION)
        local = copy.deepcopy(LOCAL)
        local['routes'][0]['channelId'] = PRODUCTION['projects'][0]['routes'][0]['channelId']
        with self.assertRaisesRegex(ValueError, 'cannot be rebound'):
            validate_contract(local, PRODUCTION)
        local = copy.deepcopy(LOCAL)
        local['projects'] = PRODUCTION['projects']
        with self.assertRaises(ValueError):
            validate_contract(local, PRODUCTION)

    def test_cli_profile_selection_and_render_are_explicit(self):
        result = subprocess.run([str(ROOT / 'scripts/render-infuseai-agents.sh')],
            env={**os.environ, 'OVERLAY_NAME': 'infuseai', 'STUDIO_NATIVE_PROFILE': 'local-mac'},
            capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, '')
        result = subprocess.run([str(ROOT / 'scripts/render-infuseai-agents.sh')],
            env={**os.environ, 'OVERLAY_NAME': 'studio-mission-cutover', 'STUDIO_NATIVE_PROFILE': 'local-mac'},
            capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('studio-local-mac', result.stdout)
        self.assertIn('100.66.41.78', result.stdout)


if __name__ == '__main__':
    unittest.main()
