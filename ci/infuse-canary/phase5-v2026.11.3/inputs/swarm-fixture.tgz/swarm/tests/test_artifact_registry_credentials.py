from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "provision_artifact_registry_credentials.py"
SPEC = importlib.util.spec_from_file_location("artifact_registry_credentials", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class ArtifactRegistryCredentialTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tokens = {
            producer.producer: f"test-only-{index:02d}-" + ("x" * 40)
            for index, producer in enumerate(MODULE.PRODUCERS)
        }

    def test_image_identity_is_scoped_and_survives_reconciliation(self):
        import hashlib
        token = "image-" + "i" * 48
        auth = MODULE.build_server_auth(self.tokens, studio_token="reader-" + "r" * 48, studio_image_token=token)
        expected = {"subject": MODULE.STUDIO_IMAGE_CLIENT.subject, "scopes": ["image-upload"], "producer": "studio-whiteboard", "studioFloors": True}
        self.assertEqual(auth["principals"][hashlib.sha256(token.encode()).hexdigest()], expected)
        resources = MODULE.build_secret_resources(self.tokens, core_namespace="core", agent_namespace="agents-swarm", studio_image_token=token)
        self.assertEqual(next(x for x in resources if x["metadata"]["name"] == MODULE.STUDIO_IMAGE_SECRET)["stringData"], {"token": token})
        existing = MODULE.build_server_auth(self.tokens, reader_token="r" * 48)
        additive = MODULE.add_studio_reader(existing, token, image_upload=True)
        for digest, principal in existing["principals"].items():
            self.assertEqual(additive["principals"][digest], principal)
        self.assertEqual(MODULE.add_studio_reader(additive, token, image_upload=True), additive)
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.add_studio_reader(additive, "other-" + "o" * 48, image_upload=True)
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.build_server_auth(self.tokens, studio_token=token, studio_image_token=token)
        overlap = MODULE.build_server_auth(self.tokens, studio_image_token=token, overlap_principals=[dict(expected, token="new-" + "n" * 48)])
        self.assertEqual(sum(p == expected for p in overlap["principals"].values()), 2)

    def test_floor_image_migration_requires_exact_prior_principal_and_explicit_flag(self):
        import hashlib
        token = "image-" + "i" * 48
        digest = hashlib.sha256(token.encode()).hexdigest()
        auth = MODULE.build_server_auth(self.tokens)
        legacy = {"subject": MODULE.STUDIO_IMAGE_CLIENT.subject, "scopes": ["image-upload"], "producer": "studio-whiteboard", "project": "studio"}
        auth["principals"][digest] = legacy
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.add_studio_reader(auth, token, image_upload=True)
        updated = MODULE.add_studio_reader(auth, token, image_upload=True, migrate_studio_floors=True)
        self.assertTrue(updated["principals"][digest]["studioFloors"])
        self.assertEqual(auth["principals"][digest], legacy)
        for key, value in auth["principals"].items():
            if key != digest:
                self.assertEqual(updated["principals"][key], value)
        auth["principals"][digest] = dict(legacy, scopes=["image-upload", "write"])
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.add_studio_reader(auth, token, image_upload=True, migrate_studio_floors=True)

    def test_plan_names_six_distinct_scoped_producers(self) -> None:
        plan = MODULE.plan()
        self.assertEqual(len(plan["producers"]), 6)
        self.assertEqual({item["producer"] for item in plan["producers"]}, {
            "kapiteky", "agent-coordinator", "agent-designer", "agent-developer", "agent-infra", "agent-intake",
        })
        self.assertEqual(len({item["item"] for item in plan["producers"]}), 6)
        self.assertEqual(len({item["secret"] for item in plan["producers"]}), 6)
        self.assertEqual([item["collection"] for item in plan["producers"]].count("personal"), 1)
        self.assertEqual(plan["backofficeClientSecret"], "core/backoffice-artifact-registry-client")
        self.assertEqual(
            {(item["key"], tuple(item["scopes"])) for item in plan["backofficeClients"]},
            {("reader", ("read",)), ("lifecycle", ("lifecycle",))},
        )

    def test_server_auth_contains_hashes_only_and_exact_scopes(self) -> None:
        reader = "reader-" + ("r" * 40)
        lifecycle = "lifecycle-" + ("l" * 40)
        auth = MODULE.build_server_auth(self.tokens, reader_token=reader, lifecycle_token=lifecycle)
        rendered = json.dumps(auth)
        for token in [*self.tokens.values(), reader, lifecycle]:
            self.assertNotIn(token, rendered)
        self.assertEqual(len(auth["principals"]), 8)
        writers = [principal for principal in auth["principals"].values() if "write" in principal["scopes"]]
        self.assertEqual(len(writers), 6)
        self.assertTrue(all(principal["scopes"] == ["read", "write"] for principal in writers))
        self.assertEqual(sum(principal["scopes"] == ["read"] for principal in auth["principals"].values()), 1)
        self.assertEqual(sum(principal["scopes"] == ["lifecycle"] for principal in auth["principals"].values()), 1)

    def test_overlap_adds_one_equivalent_principal_without_exposing_tokens(self) -> None:
        reader = "reader-" + ("r" * 40)
        lifecycle = "lifecycle-" + ("l" * 40)
        replacement = "replacement-" + ("z" * 40)
        auth = MODULE.build_server_auth(
            self.tokens,
            reader_token=reader,
            lifecycle_token=lifecycle,
            overlap_principals=[{
                "subject": "Satwa Nutella",
                "producer": "agent-infra",
                "scopes": ["read", "write"],
                "token": replacement,
            }],
        )
        rendered = json.dumps(auth)
        self.assertEqual(len(auth["principals"]), 9)
        self.assertNotIn(replacement, rendered)
        infra = [
            principal for principal in auth["principals"].values()
            if principal.get("producer") == "agent-infra"
        ]
        self.assertEqual(len(infra), 2)
        self.assertTrue(all(item["scopes"] == ["read", "write"] for item in infra))

    def test_rotation_target_is_exact_and_bounded(self) -> None:
        producer, client = MODULE.rotation_target("agent-infra")
        self.assertEqual(producer.producer, "agent-infra")
        self.assertIsNone(client)
        producer, client = MODULE.rotation_target("reader")
        self.assertIsNone(producer)
        self.assertEqual(client.key, "reader")
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.rotation_target("all")

    def test_server_auth_projection_accepts_only_the_exact_server_secret(self) -> None:
        body = json.dumps({"schema": "infuse.artifact-auth/v1", "principals": {}})
        resource = MODULE.opaque_secret("core", MODULE.SERVER_SECRET, {"auth.json": body})
        self.assertEqual(MODULE.server_auth_body(resource), body)
        resource["metadata"]["name"] = "other"
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.server_auth_body(resource)

    def test_rotation_sync_failure_rolls_back_vault_and_kubernetes(self) -> None:
        service_tokens = {
            "reader": "reader-" + ("r" * 40),
            "lifecycle": "lifecycle-" + ("l" * 40),
        }
        item = {
            "id": "test-item",
            "name": "Artifact Registry / agent-infra producer token",
            "login": {"password": self.tokens["agent-infra"]},
        }
        with (
            mock.patch.object(MODULE, "lookup_item", return_value=item),
            mock.patch.object(MODULE.secrets, "token_urlsafe", return_value="replacement-" + ("z" * 40)),
            mock.patch.object(MODULE, "replace_item_password") as replace_item,
            mock.patch.object(
                MODULE,
                "run_bw",
                side_effect=[MODULE.ProvisioningError("sync failed"), ""],
            ),
            mock.patch.object(MODULE, "apply_resources") as apply_resources,
            mock.patch.object(MODULE, "wait_for_server_auth_projection"),
        ):
            with self.assertRaises(MODULE.ProvisioningError):
                MODULE.rotate_one(
                    helper="helper",
                    context="context",
                    core_namespace="core",
                    agent_namespace="agents-swarm",
                    principal_name="agent-infra",
                    producer_tokens=self.tokens,
                    service_tokens=service_tokens,
                )

        self.assertEqual(replace_item.call_count, 2)
        self.assertEqual(apply_resources.call_count, 2)
        rollback_resources = apply_resources.call_args_list[-1].args[1]
        rollback_server = next(
            resource for resource in rollback_resources
            if resource["metadata"]["name"] == MODULE.SERVER_SECRET
        )
        self.assertEqual(len(json.loads(rollback_server["stringData"]["auth.json"])["principals"]), 8)

    def test_secret_resources_keep_raw_tokens_out_of_server_secret(self) -> None:
        reader = "reader-" + ("r" * 40)
        lifecycle = "lifecycle-" + ("l" * 40)
        resources = MODULE.build_secret_resources(
            self.tokens,
            core_namespace="core",
            agent_namespace="agents-swarm",
            reader_token=reader,
            lifecycle_token=lifecycle,
        )
        self.assertEqual(len(resources), 8)
        server = next(item for item in resources if item["metadata"]["name"] == MODULE.SERVER_SECRET)
        server_auth = server["stringData"]["auth.json"]
        for token in [*self.tokens.values(), reader, lifecycle]:
            self.assertNotIn(token, server_auth)
        client = next(item for item in resources if item["metadata"]["name"] == MODULE.CANARY_CLIENT_SECRET)
        self.assertEqual(set(client["stringData"]), {"reader", "lifecycle"})
        producer_secrets = [item for item in resources if item["metadata"]["name"].startswith("artifact-registry-") and item not in (server, client)]
        self.assertEqual(len(producer_secrets), 6)

    def test_cutover_client_secret_is_durable_and_core_scoped(self) -> None:
        reader = "reader-" + ("r" * 40)
        lifecycle = "lifecycle-" + ("l" * 40)
        resources = MODULE.build_secret_resources(
            self.tokens,
            core_namespace="core",
            agent_namespace="agents-swarm",
            reader_token=reader,
            lifecycle_token=lifecycle,
            client_secret_name=MODULE.BACKOFFICE_CLIENT_SECRET,
        )
        client = next(item for item in resources if item["metadata"]["name"] == MODULE.BACKOFFICE_CLIENT_SECRET)
        self.assertEqual(client["metadata"]["namespace"], "core")
        self.assertEqual(set(client["stringData"]), {"reader", "lifecycle"})

class StudioReaderTests(unittest.TestCase):
    def setUp(self):
        self.token = 'studio-test-' + 's' * 48
        self.producers = {p.producer: p.producer + '-' + 'x' * 48 for p in MODULE.PRODUCERS}
        self.services = {'reader': 'r' * 48, 'lifecycle': 'l' * 48, 'studio-reader': self.token}
        self.auth = MODULE.build_server_auth(self.producers, reader_token='r' * 48, lifecycle_token='l' * 48)

    def test_addition_is_read_only_preserves_existing_auth_and_is_idempotent(self):
        auth = MODULE.add_studio_reader(self.auth, self.token)
        self.assertEqual(len(auth['principals']), len(self.auth['principals']) + 1)
        for key, principal in self.auth['principals'].items():
            self.assertEqual(auth['principals'][key], principal)
        digest = MODULE.hashlib.sha256(self.token.encode()).hexdigest()
        self.assertEqual(auth['principals'][digest], {'subject': MODULE.STUDIO_CLIENT.subject, 'scopes': ['read']})
        self.assertNotIn(self.token, json.dumps(auth))
        self.assertEqual(MODULE.add_studio_reader(auth, self.token), auth)
        self.assertEqual(len(self.auth['principals']), 8)

    def test_scope_token_and_identity_collisions_fail_closed(self):
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.add_studio_reader(self.auth, 'r' * 48)
        auth = MODULE.add_studio_reader(self.auth, self.token)
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.add_studio_reader(auth, 'different-' + 'a' * 48)
        digest = MODULE.hashlib.sha256(self.token.encode()).hexdigest()
        auth['principals'][digest]['scopes'].append('write')
        with self.assertRaises(MODULE.ProvisioningError):
            MODULE.add_studio_reader(auth, self.token)

    def test_canonical_reconciliation_retains_separate_studio_secret(self):
        resources = MODULE.build_secret_resources(self.producers, core_namespace='core', agent_namespace='agents-swarm',
            reader_token=self.services['reader'], lifecycle_token=self.services['lifecycle'], studio_token=self.token,
            client_secret_name=MODULE.BACKOFFICE_CLIENT_SECRET)
        studio = next(r for r in resources if r['metadata']['name'] == MODULE.STUDIO_CLIENT_SECRET)
        self.assertEqual(studio['metadata']['namespace'], 'core')
        self.assertEqual(studio['stringData'], {'token': self.token})
        backoffice = next(r for r in resources if r['metadata']['name'] == MODULE.BACKOFFICE_CLIENT_SECRET)
        self.assertEqual(set(backoffice['stringData']), {'reader', 'lifecycle'})
        server = next(r for r in resources if r['metadata']['name'] == MODULE.SERVER_SECRET)
        self.assertEqual(json.loads(server['stringData']['auth.json']), MODULE.add_studio_reader(self.auth, self.token))

    def test_activation_uses_resource_version_and_changes_no_other_client(self):
        server = {'metadata': {'resourceVersion': '12'}, 'data': {'auth.json': MODULE.base64.b64encode(json.dumps(self.auth).encode()).decode()}}
        with mock.patch.object(MODULE, 'kube_json', return_value=server), mock.patch.object(MODULE, 'run_checked', return_value='') as run, \
             mock.patch.object(MODULE, 'wait_for_server_auth_projection') as wait, mock.patch.object(MODULE, 'apply_resources') as apply:
            result = MODULE.provision_studio_reader('context', 'core', self.token)
        patch = json.loads(run.call_args_list[-1].kwargs['input_text'])
        self.assertEqual(patch[0], {'op': 'test', 'path': '/metadata/resourceVersion', 'value': '12'})
        wait.assert_called_once()
        self.assertEqual([r['metadata']['name'] for r in apply.call_args.args[1]], [MODULE.STUDIO_CLIENT_SECRET])
        self.assertFalse(result['otherClientSecretsChanged'])
        self.assertNotIn(self.token, json.dumps(result))

    def test_stale_write_or_client_drift_does_not_activate(self):
        server = {'metadata': {'resourceVersion': '12'}, 'data': {'auth.json': MODULE.base64.b64encode(json.dumps(self.auth).encode()).decode()}}
        for responses in [[json.dumps({'data': {'token': 'drift'}})], ['', MODULE.ProvisioningError('stale resource')]]:
            with self.subTest(responses=responses), mock.patch.object(MODULE, 'kube_json', return_value=server), \
                 mock.patch.object(MODULE, 'run_checked', side_effect=responses), mock.patch.object(MODULE, 'apply_resources') as apply:
                with self.assertRaises(MODULE.ProvisioningError):
                    MODULE.provision_studio_reader('context', 'core', self.token)
                apply.assert_not_called()

    def test_studio_rotation_preserves_all_other_principals_and_targets_only_studio(self):
        with mock.patch.object(MODULE, 'lookup_item', return_value={'name': MODULE.STUDIO_CLIENT.item_name}), \
             mock.patch.object(MODULE, 'replace_item_password'), mock.patch.object(MODULE, 'run_bw', return_value=''), \
             mock.patch.object(MODULE, 'wait_for_server_auth_projection'), mock.patch.object(MODULE, 'apply_resources') as apply:
            result = MODULE.rotate_one(helper='helper', context='context', core_namespace='core', agent_namespace='agents-swarm',
                principal_name='studio-reader', producer_tokens=self.producers, service_tokens=self.services)
        server = apply.call_args_list[0].args[1][0]
        principals = json.loads(server['stringData']['auth.json'])['principals']
        self.assertEqual(len(principals), 10)
        for key, principal in self.auth['principals'].items(): self.assertEqual(principals[key], principal)
        self.assertEqual([r['metadata']['name'] for r in apply.call_args_list[1].args[1]], [MODULE.STUDIO_CLIENT_SECRET])
        self.assertEqual(result['workloadToVerify'], 'studio')


if __name__ == "__main__":
    unittest.main()
