"""Regression coverage for the Backoffice OpenClaw cron calendar feed."""

from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import textwrap
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
EXPORTER_PATH = ROOT / "scripts" / "export-openclaw-cron-calendar.py"
COLLECTOR_PATH = ROOT / "scripts" / "collect-openclaw-cron-calendar-feed.sh"
MANIFEST_PATH = ROOT / "k8s" / "overlays" / "infuseai" / "cron-calendar-collector.yaml"


def load_exporter():
    spec = importlib.util.spec_from_file_location("cron_calendar_exporter", EXPORTER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load cron calendar exporter")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


EXPORTER = load_exporter()


def install_fake_timeout(fake_bin: Path) -> None:
    timeout = fake_bin / "timeout"
    timeout.write_text(
        "#!/usr/bin/env bash\nshift\nexec \"$@\"\n",
        encoding="utf-8",
    )
    os.chmod(timeout, 0o755)


def gateway_page(
    jobs: list[dict[str, object]],
    *,
    total: int,
    offset: int,
    has_more: bool,
    next_offset: int | None,
    revision: int = 17,
) -> dict[str, object]:
    return {
        "jobs": jobs,
        "total": total,
        "offset": offset,
        "limit": 2,
        "hasMore": has_more,
        "nextOffset": next_offset,
        "snapshotRevision": revision,
    }


class CronCalendarExportTests(unittest.TestCase):
    def test_gateway_cron_list_paginates_a_stable_snapshot(self) -> None:
        completed = [
            subprocess.CompletedProcess(
                [],
                0,
                json.dumps(
                    gateway_page(
                        [
                            {"id": "one", "name": "one", "schedule": {"kind": "every", "everyMs": 60_000}},
                            {"id": "two", "name": "two", "schedule": {"kind": "cron", "expr": "0 9 * * *"}},
                        ],
                        total=3,
                        offset=0,
                        has_more=True,
                        next_offset=2,
                    )
                ),
                "",
            ),
            subprocess.CompletedProcess(
                [],
                0,
                json.dumps(
                    gateway_page(
                        [{"id": "three", "name": "three", "schedule": {"kind": "at", "at": "2026-08-27T09:00:00Z"}}],
                        total=3,
                        offset=2,
                        has_more=False,
                        next_offset=None,
                    )
                ),
                "",
            ),
        ]

        with mock.patch.object(EXPORTER.subprocess, "run", side_effect=completed) as run:
            result = EXPORTER.fetch_gateway_cron_jobs(
                openclaw_bin="openclaw",
                profile="agent-coordinator",
                page_size=2,
                attempts=1,
                retry_delay_seconds=0,
            )

        self.assertEqual([job["id"] for job in result["jobs"]], ["one", "two", "three"])
        self.assertEqual(result["total"], 3)
        self.assertEqual(result["snapshotRevision"], "17")
        self.assertEqual(run.call_count, 2)
        for index, call in enumerate(run.call_args_list):
            command = call.args[0]
            self.assertEqual(command[:3], ["openclaw", "--profile", "agent-coordinator"])
            self.assertEqual(command[3:7], ["gateway", "call", "cron.list", "--json"])
            self.assertNotIn("--token", command)
            self.assertNotIn("--password", command)
            params = json.loads(command[-1])
            self.assertEqual(params["includeDisabled"], True)
            self.assertEqual(params["limit"], 2)
            self.assertEqual(params["offset"], index * 2)

    def test_gateway_snapshot_revision_drift_is_retried_then_rejected(self) -> None:
        completed = []
        for _ in range(2):
            completed.extend(
                [
                    subprocess.CompletedProcess(
                        [],
                        0,
                        json.dumps(gateway_page([{"id": "one"}], total=2, offset=0, has_more=True, next_offset=1, revision=1)),
                        "",
                    ),
                    subprocess.CompletedProcess(
                        [],
                        0,
                        json.dumps(gateway_page([{"id": "two"}], total=2, offset=1, has_more=False, next_offset=None, revision=2)),
                        "",
                    ),
                ]
            )

        with (
            mock.patch.object(EXPORTER.subprocess, "run", side_effect=completed),
            mock.patch.object(EXPORTER.time, "sleep") as sleep,
            self.assertRaisesRegex(EXPORTER.CronGatewayError, "complete stable snapshot"),
        ):
            EXPORTER.fetch_gateway_cron_jobs(
                openclaw_bin="openclaw",
                profile=None,
                page_size=1,
                attempts=2,
                retry_delay_seconds=0.1,
            )

        sleep.assert_called_once_with(0.1)

    def test_gateway_failure_exits_nonzero_without_publishing_an_empty_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fake_openclaw = root / "openclaw"
            fake_openclaw.write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env bash
                    exit 7
                    """
                ),
                encoding="utf-8",
            )
            os.chmod(fake_openclaw, 0o755)

            completed = subprocess.run(
                [
                    "python3",
                    str(EXPORTER_PATH),
                    "--jobs-file",
                    str(root / "missing-jobs.json"),
                    "--openclaw-bin",
                    str(fake_openclaw),
                    "--allow-missing",
                    "--gateway-attempts",
                    "1",
                    "--agent-id",
                    "agent-test",
                    "--output",
                    "-",
                ],
                check=False,
                capture_output=True,
                text=True,
            )

        self.assertNotEqual(completed.returncode, 0)
        self.assertEqual(completed.stdout, "")
        self.assertIn("cron calendar export failed", completed.stderr)
        self.assertNotIn("collection_failed", completed.stderr)

    def test_valid_empty_gateway_snapshot_is_distinct_from_failure(self) -> None:
        snapshot = EXPORTER.build_snapshot_from_raw(
            raw_jobs={"jobs": [], "snapshotRevision": 9},
            raw_state={},
            agent_id="agent-intake",
            gateway_label="Ramiro Gateway",
            system="openclaw-k8s-swarm",
            source_label="openclaw gateway cron.list",
            state_included=True,
            backend=EXPORTER.GATEWAY_BACKEND,
            pagination_complete=True,
            snapshot_revision="9",
        )

        self.assertEqual(snapshot["source"]["status"], "no_cron_jobs")
        self.assertEqual(snapshot["source"]["backend"], "gateway_cron_list")
        self.assertTrue(snapshot["source"]["paginationComplete"])
        self.assertEqual(snapshot["events"], [])

    def test_snapshot_omits_raw_prompts_and_delivery_targets(self) -> None:
        prompt = "private cron prompt that must stay inside OpenClaw"
        target = "private delivery target"
        snapshot = EXPORTER.build_snapshot_from_raw(
            raw_jobs={
                "jobs": [
                    {
                        "id": "private-job",
                        "name": "private job",
                        "schedule": {"kind": "cron", "expr": "0 9 * * *"},
                        "payload": {"kind": "agentTurn", "message": prompt},
                        "delivery": {"mode": "announce", "target": target},
                    }
                ]
            },
            raw_state={},
            agent_id="agent-test",
            gateway_label="Test Gateway",
            system="openclaw-k8s-swarm",
            source_label="openclaw gateway cron.list",
            state_included=True,
            backend=EXPORTER.GATEWAY_BACKEND,
            pagination_complete=True,
            snapshot_revision="9",
        )

        serialized = json.dumps(snapshot)
        self.assertNotIn("rawPromptText", snapshot["events"][0])
        self.assertNotIn(prompt, serialized)
        self.assertNotIn(target, serialized)

    def test_snapshot_excludes_heartbeats_dreaming_and_memory_maintenance(self) -> None:
        snapshot = EXPORTER.build_snapshot_from_raw(
            raw_jobs={
                "jobs": [
                    {"id": "heartbeat", "name": "heartbeat-agent-test"},
                    {"id": "dreaming", "name": "Memory Dreaming Promotion"},
                    {"id": "backup", "name": "agent-memory-backup"},
                    {"id": "sync", "name": "openclaw-agent-memory-sync"},
                    {"id": "review", "name": "weekly-memory-review"},
                    {"id": "product-dream", "name": "product-dream-review"},
                ]
            },
            raw_state={},
            agent_id="agent-test",
            gateway_label="Test Gateway",
            system="openclaw-k8s-swarm",
            source_label="openclaw gateway cron.list",
            state_included=True,
            backend=EXPORTER.GATEWAY_BACKEND,
            pagination_complete=True,
            snapshot_revision="10",
        )

        self.assertEqual(
            [event["cronJobId"] for event in snapshot["events"]],
            ["review", "product-dream"],
        )
        self.assertEqual(snapshot["source"]["excludedInternalMaintenanceCount"], 4)

    def test_collector_fails_closed_and_requires_the_five_agent_set(self) -> None:
        collector = COLLECTOR_PATH.read_text(encoding="utf-8")
        manifest = MANIFEST_PATH.read_text(encoding="utf-8")

        self.assertNotIn("writing empty error snapshot", collector)
        self.assertNotIn('"status": "collection_failed"', collector)
        self.assertIn("Refusing to update configmap", collector)
        self.assertIn("paginationComplete", collector)
        self.assertIn("EXPECTED_AGENT_IDS", collector)
        self.assertIn(
            "agent-coordinator,agent-designer,agent-developer,agent-infra,agent-intake",
            manifest,
        )

    def test_collector_does_not_apply_when_one_agent_export_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fake_bin = root / "bin"
            fake_bin.mkdir()
            install_fake_timeout(fake_bin)
            mutation_log = root / "mutations.log"
            fake_kubectl = fake_bin / "kubectl"
            fake_kubectl.write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env bash
                    set -euo pipefail
                    if [[ "$*" == *"get pods"* ]]; then
                      printf '%s\\n' '{"items":[{"metadata":{"name":"agent-test-pod","creationTimestamp":"2026-08-27T00:00:00Z","labels":{"app.kubernetes.io/name":"agent-test"}},"status":{"phase":"Running","containerStatuses":[{"name":"agent","ready":true}]}}]}'
                    elif [[ "$*" == *"exec pod/agent-test-pod"* ]]; then
                      exit 9
                    elif [[ "$*" == *"create configmap"* || "$*" == *"apply"* ]]; then
                      printf '%s\\n' "$*" >> "$FAKE_MUTATION_LOG"
                    else
                      printf 'unexpected kubectl invocation: %s\\n' "$*" >&2
                      exit 10
                    fi
                    """
                ),
                encoding="utf-8",
            )
            os.chmod(fake_kubectl, 0o755)
            env = os.environ.copy()
            env.update(
                {
                    "PATH": f"{fake_bin}{os.pathsep}{env['PATH']}",
                    "EXPECTED_AGENT_IDS": "agent-test",
                    "FAKE_MUTATION_LOG": str(mutation_log),
                    "EXPORT_TIMEOUT_SECONDS": "2",
                }
            )

            completed = subprocess.run(
                ["bash", str(COLLECTOR_PATH)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )

        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("Refusing to update configmap", completed.stderr)
        self.assertFalse(mutation_log.exists())

    def test_collector_dry_run_validates_a_complete_snapshot_without_applying(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fake_bin = root / "bin"
            fake_bin.mkdir()
            install_fake_timeout(fake_bin)
            mutation_log = root / "mutations.log"
            fake_kubectl = fake_bin / "kubectl"
            snapshot = json.dumps(
                {
                    "schemaVersion": 1,
                    "generatedAt": "2026-08-27T00:00:00Z",
                    "source": {
                        "type": "openclaw_cron_export",
                        "agentId": "agent-test",
                        "gatewayLabel": "Test Gateway",
                        "backend": "gateway_cron_list",
                        "status": "available",
                        "paginationComplete": True,
                        "snapshotRevision": "sha256:test",
                    },
                    "events": [{"id": "test-job"}],
                }
            )
            fake_kubectl.write_text(
                textwrap.dedent(
                    f"""\
                    #!/usr/bin/env bash
                    set -euo pipefail
                    if [[ "$*" == *"get pods"* ]]; then
                      printf '%s\\n' '{{"items":[{{"metadata":{{"name":"agent-test-pod","creationTimestamp":"2026-08-27T00:00:00Z","labels":{{"app.kubernetes.io/name":"agent-test"}}}},"status":{{"phase":"Running","containerStatuses":[{{"name":"agent","ready":true}}]}}}}]}}'
                    elif [[ "$*" == *"exec pod/agent-test-pod"* ]]; then
                      printf '%s\\n' '{snapshot}'
                    elif [[ "$*" == *"create configmap"* || "$*" == *"apply"* ]]; then
                      printf '%s\\n' "$*" >> "$FAKE_MUTATION_LOG"
                    else
                      printf 'unexpected kubectl invocation: %s\\n' "$*" >&2
                      exit 10
                    fi
                    """
                ),
                encoding="utf-8",
            )
            os.chmod(fake_kubectl, 0o755)
            env = os.environ.copy()
            env.update(
                {
                    "PATH": f"{fake_bin}{os.pathsep}{env['PATH']}",
                    "EXPECTED_AGENT_IDS": "agent-test",
                    "FAKE_MUTATION_LOG": str(mutation_log),
                    "EXPORT_TIMEOUT_SECONDS": "2",
                    "DRY_RUN": "true",
                }
            )

            completed = subprocess.run(
                ["bash", str(COLLECTOR_PATH)],
                check=False,
                capture_output=True,
                text=True,
                env=env,
            )

        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("dry run left configmap", completed.stdout)
        self.assertFalse(mutation_log.exists())


if __name__ == "__main__":
    unittest.main()
