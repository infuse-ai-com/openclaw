from __future__ import annotations

import copy
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "dashboard-identity-scope-patch.py"
SPEC = importlib.util.spec_from_file_location("dashboard_identity_scope_patch", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
IMAGE = "registry.example.invalid/agent@sha256:" + "a" * 64
AGENT = "agent-developer"
PRIVATE_MARKER = "synthetic-private-config-never-on-console"


def fixture(agent_id: str = AGENT) -> tuple[dict, dict]:
    reviewed = MODULE.reviewed_config(agent_id)
    gateway = copy.deepcopy(reviewed["gateway"])
    del gateway["auth"]["identityScopes"]
    gateway["roles"] = {"default": "existing-role", "definitions": {"existing-role": {"scopes": ["operator.read"]}}}
    config = {
        "gateway": gateway,
        "agents": {"entries": {agent_id: {"name": "Fixture person é"}}, "defaults": {"heartbeat": {"every": "0m"}}},
        "commands": {"ownerAllowFrom": ["mattermost:synthetic-owner"]},
        "channels": {"mattermost": {"allowFrom": ["synthetic-owner"], "botToken": PRIVATE_MARKER}},
        "plugins": {"entries": {"infuse-studio": {"config": {"localConnection": {"passwordEnv": "UNCHANGED_PASSWORD_REF"}}}}},
        "unrelatedExtension": {"retained": [False, None, 3.5, "preserved"]},
    }
    deployment = {
        "apiVersion": "apps/v1", "kind": "Deployment",
        "metadata": {"namespace": MODULE.NAMESPACE, "name": agent_id, "uid": "synthetic-deployment-uid", "resourceVersion": "789", "annotations": {"other": "unchanged"}},
        "spec": {"replicas": 1, "template": {
            "metadata": {"labels": {"app.kubernetes.io/name": agent_id}},
            "spec": {"serviceAccountName": "retained-account", "volumes": [{"name": "workspace", "persistentVolumeClaim": {"claimName": "retained-pvc"}}],
                "containers": [
                    {"name": "sidecar", "image": "unchanged-sidecar", "env": [{"name": "SIDECAR", "value": "retained"}]},
                    {"name": "agent", "image": IMAGE, "env": [
                        {"name": "AGENT_ID", "value": agent_id},
                        {"name": "UNCHANGED_PASSWORD_REF", "valueFrom": {"secretKeyRef": {"name": "unchanged-secret", "key": "password"}}},
                        {"name": MODULE.CONFIG_ENV, "value": json.dumps(config, ensure_ascii=False, indent=2)},
                    ]},
                ],
            },
        }},
    }
    return deployment, reviewed


def config_env(deployment: dict) -> dict:
    return deployment["spec"]["template"]["spec"]["containers"][1]["env"][2]


def edit_config(deployment: dict, edit) -> None:
    entry = config_env(deployment)
    config = json.loads(entry["value"])
    edit(config)
    entry["value"] = json.dumps(config)


def apply_json_patch(document: dict, patch: list[dict]) -> dict:
    result = copy.deepcopy(document)
    for operation in patch:
        parts = operation["path"].lstrip("/").split("/")
        parent = result
        for part in parts[:-1]:
            parent = parent[int(part)] if isinstance(parent, list) else parent[part]
        key = int(parts[-1]) if isinstance(parent, list) else parts[-1]
        if operation["op"] == "test":
            if parent[key] != operation["value"]:
                raise ValueError("JSON Patch test failed")
        elif operation["op"] == "replace":
            parent[key] = operation["value"]
        else:
            raise AssertionError("Unexpected patch operation")
    return result


class DashboardIdentityScopePatchTest(unittest.TestCase):
    def test_all_five_patch_only_one_config_field_and_preserve_exact_rollback_value(self) -> None:
        for agent_id in sorted(MODULE.AGENTS):
            with self.subTest(agent_id=agent_id):
                live, source = fixture(agent_id)
                before = copy.deepcopy(live)
                patch = MODULE.build_patch(live, source, agent_id=agent_id, expected_image=IMAGE)
                self.assertEqual(live, before, "preparation must not mutate its input")
                writes = [operation for operation in patch if operation["op"] != "test"]
                self.assertEqual(len(writes), 1)
                self.assertEqual(writes[0]["op"], "replace")
                self.assertEqual(writes[0]["path"], "/spec/template/spec/containers/1/env/2/value")
                tests = {operation["path"]: operation["value"] for operation in patch if operation["op"] == "test"}
                self.assertEqual(tests["/metadata/resourceVersion"], live["metadata"]["resourceVersion"])
                self.assertEqual(tests["/metadata/uid"], live["metadata"]["uid"])
                self.assertEqual(tests[writes[0]["path"]], config_env(live)["value"])
                after = apply_json_patch(live, patch)
                config = json.loads(config_env(after)["value"])
                self.assertEqual(config["gateway"]["auth"].pop("identityScopes"), {MODULE.IDENTITY: ["operator.admin"]})
                self.assertEqual(config, json.loads(config_env(live)["value"]), "only the reviewed semantic field may change")
                config_env(after)["value"] = tests[writes[0]["path"]]
                self.assertEqual(after, live, "the protected old-value test retains exact rollback bytes")

    def test_existing_unrelated_identity_grants_and_roles_are_preserved(self) -> None:
        live, source = fixture()
        other = {"another@example.invalid": ["operator.read"]}
        edit_config(live, lambda config: config["gateway"]["auth"].update(identityScopes=other))
        patch = MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE)
        config = json.loads(config_env(apply_json_patch(live, patch))["value"])
        self.assertEqual(config["gateway"]["auth"]["identityScopes"], {**other, MODULE.IDENTITY: ["operator.admin"]})
        self.assertEqual(config["gateway"]["roles"], json.loads(config_env(live)["value"])["gateway"]["roles"])

    def test_matching_grant_is_idempotent_even_with_unrelated_grants(self) -> None:
        live, source = fixture()
        edit_config(live, lambda config: config["gateway"]["auth"].update(identityScopes={MODULE.IDENTITY: ["operator.admin"], "other@example.invalid": ["operator.read"]}))
        before = copy.deepcopy(live)
        self.assertEqual(MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE), [])
        self.assertEqual(live, before)

    def test_conflicting_or_malformed_existing_grant_fails_closed(self) -> None:
        for scopes in (None, [], "operator.admin", {MODULE.IDENTITY: []}, {MODULE.IDENTITY: ["operator.read"]}, {MODULE.IDENTITY: ["operator.admin", "operator.read"]}):
            with self.subTest(scopes=scopes):
                live, source = fixture()
                edit_config(live, lambda config: config["gateway"]["auth"].update(identityScopes=scopes))
                with self.assertRaises(MODULE.PatchError):
                    MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE)

    def test_reviewed_source_must_contain_only_the_exact_authorized_identity_grant(self) -> None:
        for scopes in ({}, {MODULE.IDENTITY: ["operator.read"]}, {MODULE.IDENTITY: ["operator.admin"], "other@example.invalid": ["operator.admin"]}):
            live, source = fixture()
            source["gateway"]["auth"]["identityScopes"] = scopes
            with self.assertRaises(MODULE.PatchError):
                MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE)

    def test_namespace_workload_incarnation_and_exact_image_are_required(self) -> None:
        mutations = [
            lambda live: live.update(kind="StatefulSet"),
            lambda live: live.update(apiVersion="v1"),
            lambda live: live["metadata"].update(namespace="another-namespace"),
            lambda live: live["metadata"].update(name="agent-designer"),
            lambda live: live["metadata"].pop("resourceVersion"),
            lambda live: live["metadata"].pop("uid"),
            lambda live: live["spec"]["template"]["spec"]["containers"][1].update(image=IMAGE.replace("a" * 64, "b" * 64)),
        ]
        for mutate in mutations:
            live, source = fixture()
            mutate(live)
            with self.assertRaises(MODULE.PatchError):
                MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE)
        for image in ("dev", "registry.example.invalid/agent:latest", "sha256:" + "a" * 64):
            live, source = fixture()
            with self.assertRaises(MODULE.PatchError):
                MODULE.build_patch(live, source, agent_id=AGENT, expected_image=image)

    def test_auth_and_trust_drift_is_refused_without_changing_roles(self) -> None:
        mutations = [
            lambda config: config["gateway"]["auth"].update(mode="password"),
            lambda config: config["gateway"]["auth"].update(password="changed"),
            lambda config: config["gateway"]["auth"]["trustedProxy"].update(userHeader="x-other-user"),
            lambda config: config["gateway"]["auth"]["trustedProxy"].update(requiredHeaders=[]),
            lambda config: config["gateway"]["auth"]["trustedProxy"]["allowUsers"].append("other@example.invalid"),
            lambda config: config["gateway"]["auth"]["trustedProxy"]["deviceAutoApprove"]["scopes"].append("operator.admin"),
            lambda config: config["gateway"]["auth"]["trustedProxy"]["deviceAutoApprove"].update(enabled=1),
            lambda config: config["gateway"].update(trustedProxies=["0.0.0.0/0"]),
            lambda config: config["gateway"]["controlUi"]["allowedOrigins"].append("https://other.example.invalid"),
            lambda config: config["agents"]["entries"].update({"agent-designer": {}}),
        ]
        for mutate in mutations:
            live, source = fixture()
            edit_config(live, mutate)
            with self.assertRaises(MODULE.PatchError):
                MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE)

    def test_ambiguous_container_or_environment_and_nonliteral_config_are_rejected(self) -> None:
        for change in ("duplicate-agent", "duplicate-config", "duplicate-other-env", "value-from", "wrong-agent-env", "missing-config"):
            live, source = fixture()
            containers = live["spec"]["template"]["spec"]["containers"]
            env = containers[1]["env"]
            if change == "duplicate-agent":
                containers.append(copy.deepcopy(containers[1]))
            elif change == "duplicate-config":
                env.append(copy.deepcopy(env[2]))
            elif change == "duplicate-other-env":
                env.append(copy.deepcopy(env[1]))
            elif change == "value-from":
                env[2]["valueFrom"] = {"secretKeyRef": {"name": "foreign", "key": "config"}}
            elif change == "wrong-agent-env":
                env[0]["value"] = "agent-designer"
            else:
                env.pop()
            with self.subTest(change=change), self.assertRaises(MODULE.PatchError):
                MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE)

    def test_patch_cas_rejects_stale_version_config_and_reordered_containers(self) -> None:
        live, source = fixture()
        patch = MODULE.build_patch(live, source, agent_id=AGENT, expected_image=IMAGE)
        for change in ("version", "config", "container", "uid"):
            changed = copy.deepcopy(live)
            if change == "version":
                changed["metadata"]["resourceVersion"] = "790"
            elif change == "config":
                config_env(changed)["value"] += " "
            elif change == "uid":
                changed["metadata"]["uid"] = "replacement-workload"
            else:
                changed["spec"]["template"]["spec"]["containers"].reverse()
            with self.subTest(change=change), self.assertRaises((ValueError, KeyError)):
                apply_json_patch(changed, patch)

    def test_duplicate_json_keys_and_invalid_json_are_not_normalized_away(self) -> None:
        for raw in ('{"gateway":{},"gateway":{}}', '{"nested":{"identityScopes":{},"identityScopes":{}}}', '{"bad":NaN}', '{"bad":1e999}', '[]', '{broken'):
            with self.subTest(raw=raw), self.assertRaises(MODULE.PatchError):
                MODULE.parse_json(raw)

    def test_output_is_exclusive_private_and_never_stdout(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "patch.json"
            MODULE.write_patch(str(path), [])
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
            self.assertEqual(json.loads(path.read_text()), [])
            with self.assertRaises(MODULE.PatchError):
                MODULE.write_patch(str(path), [{"op": "replace", "value": "must-not-overwrite"}])
            self.assertEqual(json.loads(path.read_text()), [])
            link = Path(directory) / "link.json"
            link.symlink_to(path)
            with self.assertRaises(MODULE.PatchError):
                MODULE.write_patch(str(link), [])
            with self.assertRaises(MODULE.PatchError):
                MODULE.write_patch("-", [])

    def test_cli_accepts_protected_input_and_stdin_without_emitting_private_data(self) -> None:
        live, _source = fixture()
        with tempfile.TemporaryDirectory() as directory:
            input_path = Path(directory) / "live.json"
            input_path.write_text(json.dumps(live))
            output_path = Path(directory) / "patch.json"
            base = [sys.executable, str(SCRIPT), "--agent-id", AGENT, "--expected-image", IMAGE]
            # No kubectl or other executable is available: preparation is local only.
            environment = {**os.environ, "PATH": ""}
            dry = subprocess.run([*base, "--input", "-", "--dry-run"], input=json.dumps(live), text=True, capture_output=True, env=environment)
            self.assertEqual(dry.returncode, 0, dry.stderr)
            self.assertEqual(json.loads(dry.stdout), {"agentId": AGENT, "changedGrants": 1, "noop": False, "dryRun": True})
            prepared = subprocess.run([*base, "--input", str(input_path), "--output", str(output_path)], text=True, capture_output=True, env=environment)
            self.assertEqual(prepared.returncode, 0, prepared.stderr)
            self.assertNotIn(PRIVATE_MARKER, dry.stdout + dry.stderr + prepared.stdout + prepared.stderr)
            self.assertIn(PRIVATE_MARKER, output_path.read_text(), "rollback data belongs only in the protected patch")
            self.assertEqual(stat.S_IMODE(output_path.stat().st_mode), 0o600)
            self.assertTrue(json.loads(prepared.stdout)["changedGrants"])
            updated = apply_json_patch(live, json.loads(output_path.read_text()))
            no_op = subprocess.run([*base, "--input", "-", "--dry-run"], input=json.dumps(updated), text=True, capture_output=True, env=environment)
            self.assertEqual(no_op.returncode, 0, no_op.stderr)
            self.assertEqual(json.loads(no_op.stdout)["changedGrants"], 0)
            self.assertTrue(json.loads(no_op.stdout)["noop"])
            denied = subprocess.run([*base, "--input", "-", "--output", "-"], input=json.dumps(live), text=True, capture_output=True, env=environment)
            self.assertEqual(denied.returncode, 1)
            self.assertEqual(denied.stdout, "")
            self.assertNotIn(PRIVATE_MARKER, denied.stderr)


if __name__ == "__main__":
    unittest.main()
