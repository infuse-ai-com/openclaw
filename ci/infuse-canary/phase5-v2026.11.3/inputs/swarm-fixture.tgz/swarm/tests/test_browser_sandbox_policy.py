"""Check effective agent manifests, including inherited security settings."""
import json
from pathlib import Path
import subprocess
import unittest

import re

ROOT = Path(__file__).resolve().parents[1]
AGENTS = ['agent-developer', 'agent-designer', 'agent-infra', 'agent-coordinator', 'agent-intake']


class BrowserSandboxPolicyTests(unittest.TestCase):
    def test_every_rendered_agent_keeps_browser_sandbox_and_pod_restrictions(self):
        for agent in AGENTS:
            with self.subTest(agent=agent):
                result = subprocess.run(
                    ['kubectl', 'kustomize', str(ROOT / 'k8s/agents' / agent)],
                    check=True, capture_output=True, text=True,
                )
                # Use the existing repository's dependency-free rendered-contract
                # style; local verification does not require Python PyYAML.
                document = next(d for d in re.split(r"^---\s*$", result.stdout, flags=re.M)
                                if "kind: Deployment\n" in d and f"  name: {agent}\n" in d)
                source = (ROOT / 'k8s/agents' / agent / 'deployment.yaml').read_text()
                raw = re.search(r"name: OPENCLAW_CONFIG_JSON\n\s+value: '([^'\n]+)'", source).group(1)
                self.assertIs(json.loads(raw)['browser']['noSandbox'], False)
                self.assertIn('"noSandbox":false', document)
                self.assertNotIn('"noSandbox":true', document)
                containers = re.search(r'(?ms)^      containers:\n(.*?)(?=^      [^- ])', document).group(1)
                pod_security = re.search(r'(?m)^      securityContext:\n((?:^        .*\n)+)', document).group(1)
                security = containers + pod_security
                self.assertIn('runAsNonRoot: true', security)
                self.assertIn('runAsUser: 10001', security)
                self.assertNotRegex(security, r"runAsUser: 0(?:\s|$)")
                self.assertNotIn('allowPrivilegeEscalation: true', security)
                self.assertIn('allowPrivilegeEscalation: false', security)
                self.assertIn('- ALL', security)
                self.assertNotIn('privileged: true', security)
                self.assertNotIn('SYS_ADMIN', security)
                self.assertNotIn('type: Unconfined', security)
                self.assertRegex(document, r"seccompProfile:\n\s+localhostProfile: infuse/openclaw-chromium-v1.json\n\s+type: Localhost")
