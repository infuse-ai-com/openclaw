from __future__ import annotations

from pathlib import Path
import stat
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "render-agent-memory.py"


class RenderAgentMemoryTests(unittest.TestCase):
    def test_rendered_memory_is_owner_read_write_only(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "source.md"
            destination = Path(temporary) / "nested" / "MEMORY.md"
            source.write_text("# Durable memory\n", encoding="utf-8")

            subprocess.run(
                [
                    "python3",
                    str(SCRIPT),
                    "--agent-id",
                    "agent-designer",
                    "--source",
                    str(source),
                    "--destination",
                    str(destination),
                ],
                check=True,
            )

            self.assertEqual(stat.S_IMODE(destination.stat().st_mode), 0o600)
            self.assertIn("# Durable memory", destination.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
