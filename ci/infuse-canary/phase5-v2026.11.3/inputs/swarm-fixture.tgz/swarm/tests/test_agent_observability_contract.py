import importlib.util
import copy
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "verify-agent-observability-contract.py"
CONTRACT = ROOT / "config" / "observability" / "telemetry-contract.v1.json"
FIXTURES = ROOT / "config" / "observability" / "fixtures"

SPEC = importlib.util.spec_from_file_location("observability_contract", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class AgentObservabilityContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))

    def test_all_fixtures_have_the_expected_result(self) -> None:
        self.assertEqual(MODULE.verify_fixtures(self.contract, FIXTURES), [])

    def test_unknown_fields_are_rejected_even_when_not_secret_shaped(self) -> None:
        event = {
            "signal": "infuse.workflow.phase",
            "attributes": {
                "phase": "plan",
                "outcome": "started",
                "sequence": 1,
                "extra": "bounded",
            },
            "metricLabels": {"phase": "plan", "outcome": "started"},
        }
        codes = {finding.code for finding in MODULE.validate_event(self.contract, event)}
        self.assertIn("attribute.unexpected", codes)

    def test_metric_labels_must_copy_approved_attributes(self) -> None:
        event = {
            "signal": "infuse.knowledge.access",
            "attributes": {
                "action": "read",
                "source_class": "skill",
                "path_class": "skills",
                "outcome": "success",
            },
            "metricLabels": {"action": "search"},
        }
        codes = {finding.code for finding in MODULE.validate_event(self.contract, event)}
        self.assertIn("label.value_mismatch", codes)

    def test_contract_declares_only_namespaced_custom_signals(self) -> None:
        self.assertTrue(self.contract["signals"])
        self.assertTrue(all(name.startswith("infuse.") for name in self.contract["signals"]))

    def test_curated_turn_tree_is_bounded_and_model_ids_are_not_metric_labels(self) -> None:
        self.assertEqual(self.contract["schemaVersion"], "1.10.0")
        turn = self.contract["signals"]["infuse.agent.turn"]
        model = self.contract["signals"]["infuse.model.call"]
        self.assertEqual(
            turn["requiredAttributes"],
            ["outcome", "duration_ms", "closure_state"],
        )
        self.assertEqual(turn["metricLabels"], ["outcome", "closure_state"])
        self.assertEqual(
            model["requiredAttributes"],
            [
                "provider",
                "model",
                "attempt_role",
                "attempt_index",
                "outcome",
                "duration_ms",
            ],
        )
        self.assertEqual(
            model["metricLabels"],
            ["outcome", "attempt_role", "failure_category"],
        )
        self.assertEqual(model["attributes"]["provider"]["maxLength"], 96)
        self.assertEqual(model["attributes"]["model"]["maxLength"], 96)

    def test_every_curated_signal_accepts_one_bounded_common_traffic_source(self) -> None:
        self.assertEqual(self.contract["commonMetricLabels"], ["traffic.source"])
        self.assertEqual(
            self.contract["commonSignalAttributes"]["traffic.source"]["enum"],
            ["human", "automation", "smoke", "startup", "unavailable"],
        )

    def test_knowledge_decisions_are_explicit_or_derived_from_tool_outcomes(self) -> None:
        decision = self.contract["signals"]["infuse.knowledge.decision"]
        self.assertEqual(
            decision["attributes"]["decision"]["enum"],
            ["not_needed", "considered_unavailable", "invoked", "failed"],
        )
        self.assertEqual(
            decision["attributes"]["evidence_method"]["enum"],
            ["explicit_marker", "tool_outcome", "wrapper_outcome"],
        )

    def test_trace_integrity_and_anomaly_contracts_are_bounded(self) -> None:
        integrity = self.contract["signals"]["infuse.trace.integrity"]
        anomaly = self.contract["signals"]["infuse.turn.anomaly"]
        self.assertEqual(
            integrity["metricLabels"],
            [
                "integrity_state",
                "root_state",
                "parent_state",
                "child_state",
                "closure_state",
            ],
        )
        self.assertEqual(anomaly["metricLabels"], ["anomaly_type"])
        self.assertEqual(
            self.contract["turnAnomalyThresholds"],
            {
                "slowTurnDurationMs": 60000,
                "excessiveToolCount": 50,
                "repeatedFailureCount": 3,
                "largeTraceChildCount": 100,
            },
        )

    def test_official_run_and_tool_signals_are_canonical(self) -> None:
        self.assertEqual(MODULE.verify_signal_authorities(self.contract), [])
        authorities = self.contract["signalAuthorities"]
        self.assertEqual(authorities["run"]["canonicalSignal"], "openclaw.run")
        self.assertEqual(
            authorities["run"]["drilldownSignal"], "infuse.agent.turn"
        )
        self.assertEqual(
            authorities["tool"]["canonicalSignal"], "openclaw.tool.execution"
        )
        self.assertEqual(
            authorities["tool"]["drilldownSignal"], "infuse.tool.execution"
        )
        self.assertTrue(
            all(
                row["disagreementPolicy"] == "surface"
                for row in authorities.values()
            )
        )

    def test_contract_rejects_curated_counts_as_official_truth(self) -> None:
        mutated = copy.deepcopy(self.contract)
        mutated["signalAuthorities"]["run"]["canonicalSignal"] = "infuse.agent.turn"
        mutated["signalAuthorities"]["tool"]["canonicalSignal"] = (
            "infuse.tool.execution"
        )
        errors = MODULE.verify_signal_authorities(mutated)
        self.assertTrue(
            any("signalAuthorities.run.canonicalSignal" in error for error in errors)
        )
        self.assertTrue(
            any("signalAuthorities.tool.canonicalSignal" in error for error in errors)
        )

    def test_mission_semantics_are_bounded_and_identity_free_in_metrics(self) -> None:
        authorities = self.contract["signalAuthorities"]
        self.assertEqual(
            authorities["mission"]["canonicalSignal"],
            "infuse.mission.transition",
        )
        self.assertEqual(
            authorities["task"]["canonicalSignal"],
            "infuse.task.transition",
        )
        self.assertEqual(
            authorities["orchestration_event"]["canonicalSignal"],
            "infuse.orchestration.event",
        )
        self.assertEqual(
            self.contract["missionCorrelation"],
            {
                "traceReferenceAttribute": "correlation_ref",
                "traceReferencePattern": "^[0-9a-f]{64}$",
                "metricIdentityLabelsForbidden": [
                    "mission_id",
                    "task_id",
                    "event_id",
                    "correlation_ref",
                ],
                "unavailableState": "unavailable",
                "timestampOnlyInference": "forbidden",
            },
        )
        for name in (
            "infuse.mission.transition",
            "infuse.task.transition",
            "infuse.orchestration.event",
        ):
            signal = self.contract["signals"][name]
            self.assertIn("traffic.source", signal["requiredAttributes"])
            self.assertIn("correlation_state", signal["metricLabels"])
            self.assertNotIn("correlation_ref", signal["metricLabels"])
            self.assertNotIn("mission_id", signal["attributes"])
            self.assertNotIn("task_id", signal["attributes"])
            self.assertNotIn("event_id", signal["attributes"])

        event = self.contract["signals"]["infuse.orchestration.event"]
        self.assertEqual(
            event["attributes"]["intake_outcome"]["enum"],
            ["accepted", "duplicate", "rejected", "coalesced"],
        )
        self.assertIn(
            {"when": {"intake_outcome": "rejected"}, "required": ["rejection_code"]},
            event["conditionalAttributes"],
        )

    def test_comparisons_require_exact_provenance_and_traffic_boundary(self) -> None:
        boundaries = self.contract["comparisonBoundaries"]
        self.assertEqual(
            boundaries["requiredDimensions"],
            [
                "openclaw.agent.name",
                "deployment.environment.name",
                "container.image.revision",
                "openclaw.runtime.revision",
                "infuse.skill_bundle.revision",
                "rollout.boundary",
                "traffic.source",
            ],
        )
        self.assertEqual(boundaries["crossBoundaryPolicy"], "segment")

    def test_dynamic_tool_alias_normalization_is_explicit_and_shared(self) -> None:
        normalization = self.contract["toolNameNormalization"]
        self.assertEqual(
            normalization,
            {
                "strategy": "strip_openclaw_dynamic_alias_prefix_then_apply_static_aliases",
                "officialAttribute": "openclaw.toolName",
                "curatedAttribute": "tool_name",
                "aliasPrefix": "openclaw",
                "staticAliases": {"bash": "exec"},
                "canonicalExamples": {
                    "openclawmessage": "message",
                    "openclawsessions_spawn": "sessions_spawn",
                    "openclawweb_fetch": "web_fetch",
                },
            },
        )

    def test_unapproved_process_resource_attributes_are_rejected(self) -> None:
        event = {
            "signal": "infuse.workflow.phase",
            "attributes": {"phase": "verify", "outcome": "completed", "sequence": 4},
            "metricLabels": {"phase": "verify", "outcome": "completed"},
            "resourceAttributes": {
                "service.name": "openclaw-agent-developer",
                "deployment.environment.name": "production",
                "openclaw.agent.name": "agent-developer",
                "openclaw.runtime.version": "2026.8.1",
                "openclaw.runtime.revision": "reviewed",
                "container.image.revision": "reviewed",
                "infuse.skill_bundle.revision": "reviewed",
                "process.command_args": ["openclaw", "gateway", "--credential", "redacted"],
            },
        }
        codes = {finding.code for finding in MODULE.validate_event(self.contract, event)}
        self.assertIn("resource.unapproved", codes)
        self.assertIn("resource.type", codes)

    def test_wrapper_failure_taxonomy_is_exact_and_fully_fixture_covered(self) -> None:
        expected = {
            "authentication_unavailable",
            "authorization_denied",
            "dependency_unavailable",
            "internal_error",
            "invalid_input",
            "nonzero_exit",
            "parse_failure",
            "timeout",
            "upstream_contract_mismatch",
            "unknown",
        }
        declared = set(
            self.contract["signals"]["infuse.wrapper.execution"]["attributes"]["error_code"]["enum"]
        )
        self.assertEqual(declared, expected)

        fixture_codes = set()
        for path in FIXTURES.glob("wrapper-*-pass.json"):
            fixture = json.loads(path.read_text(encoding="utf-8"))
            if (
                fixture["event"]["signal"] == "infuse.wrapper.execution"
                and "error_code" in fixture["event"]["attributes"]
            ):
                fixture_codes.add(fixture["event"]["attributes"]["error_code"])
        self.assertEqual(fixture_codes, expected)

        signal = self.contract["signals"]["infuse.wrapper.execution"]
        self.assertEqual(
            signal["attributes"]["outcome"]["enum"],
            ["started", "success", "error", "skipped"],
        )
        self.assertEqual(
            signal["conditionalAttributes"],
            [
                {"when": {"outcome": "started"}, "forbidden": ["error_code"]},
                {"when": {"outcome": "success"}, "forbidden": ["error_code"]},
                {"when": {"outcome": "error"}, "required": ["error_code"]},
                {"when": {"outcome": "skipped"}, "forbidden": ["error_code"]},
            ],
        )

    def test_tool_failure_taxonomy_is_exact_and_rejects_raw_correlation(self) -> None:
        expected = {
            "aborted",
            "authentication_unavailable",
            "authorization_denied",
            "dependency_unavailable",
            "internal_error",
            "invalid_input",
            "nonzero_exit",
            "parse_failure",
            "permission_denied",
            "policy_denied",
            "protocol_conversion",
            "runtime_error",
            "timeout",
            "unknown",
            "upstream_contract_mismatch",
            "upstream_unavailable",
        }
        signal = self.contract["signals"]["infuse.tool.execution"]
        self.assertEqual(set(signal["attributes"]["failure_category"]["enum"]), expected)
        self.assertEqual(
            signal["metricLabels"],
            ["tool_name", "failure_category", "classification_source", "outcome"],
        )
        self.assertEqual(
            signal["conditionalAttributes"],
            [
                {
                    "when": {"outcome": "success"},
                    "forbidden": ["failure_category", "classification_source"],
                },
                {
                    "when": {"outcome": "error"},
                    "required": ["failure_category", "classification_source"],
                },
            ],
        )
        expected_fixture_codes = {
            "tool-execution-success-category-fail.json": {
                "attribute.forbidden_for_condition"
            },
            "tool-execution-error-category-missing-fail.json": {
                "attribute.required_for_condition"
            },
            "tool-failure-raw-error-fail.json": {
                "attribute.unexpected",
                "attribute.forbidden_name",
            },
            "tool-failure-run-id-fail.json": {
                "attribute.unexpected",
                "attribute.forbidden_name",
            },
        }
        for fixture_name, expected_codes in expected_fixture_codes.items():
            fixture = json.loads((FIXTURES / fixture_name).read_text(encoding="utf-8"))
            codes = {
                finding.code
                for finding in MODULE.validate_event(self.contract, fixture["event"])
            }
            self.assertTrue(expected_codes.issubset(codes))

    def test_skill_attribution_is_exact_and_inference_is_rejected(self) -> None:
        expected = {"native", "explicit_wrapper", "declared_marker"}
        signal = self.contract["signals"]["infuse.skill.execution"]
        self.assertEqual(set(signal["attributes"]["attribution_method"]["enum"]), expected)
        self.assertEqual(
            signal["metricLabels"],
            ["skill_name", "phase", "outcome", "attribution_method", "lifecycle_state"],
        )
        self.assertEqual(
            signal["allowedAttributeCombinations"],
            [
                {"phase": "start", "outcome": "started"},
                {"phase": "finish", "outcome": "success"},
                {"phase": "finish", "outcome": "error"},
                {"phase": "finish", "outcome": "skipped"},
            ],
        )

        passing_methods = set()
        for path in FIXTURES.glob("skill-execution-*-pass.json"):
            fixture = json.loads(path.read_text(encoding="utf-8"))
            passing_methods.add(fixture["event"]["attributes"]["attribution_method"])
        self.assertEqual(passing_methods, expected)

        inferred = json.loads(
            (FIXTURES / "skill-execution-inferred-fail.json").read_text(encoding="utf-8")
        )
        codes = {
            finding.code
            for finding in MODULE.validate_event(self.contract, inferred["event"])
        }
        self.assertIn("attribute.enum", codes)

        invalid_lifecycle = json.loads(
            (FIXTURES / "skill-execution-invalid-lifecycle-fail.json").read_text(
                encoding="utf-8"
            )
        )
        codes = {
            finding.code
            for finding in MODULE.validate_event(self.contract, invalid_lifecycle["event"])
        }
        self.assertIn("attribute.combination", codes)

    def test_lifecycle_integrity_contract_is_bounded_and_content_free(self) -> None:
        signal = self.contract["signals"]["infuse.lifecycle.integrity"]
        self.assertEqual(
            signal["requiredAttributes"],
            ["lifecycle_type", "lifecycle_state", "incomplete_count"],
        )
        self.assertEqual(
            set(signal["attributes"]["lifecycle_state"]["enum"]),
            {"unmatched_finish", "incomplete_start"},
        )
        self.assertEqual(signal["attributes"]["incomplete_count"]["maximum"], 100)
        self.assertNotIn("content", signal["attributes"])


if __name__ == "__main__":
    unittest.main()
