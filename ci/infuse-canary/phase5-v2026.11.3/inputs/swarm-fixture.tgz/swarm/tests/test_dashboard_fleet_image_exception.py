import importlib.util
import re
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


guard = module('image_guard', 'scripts/verify-openclaw-image-risk-exception.py')
assurance = module('fleet_assurance', 'assurance/swarm_assurance.py')


class FleetImageExceptionTests(unittest.TestCase):
    def test_old_and_new_images_have_separate_expiring_approvals(self):
        now = guard.parse_utc('2026-11-10T12:00:00Z')
        old = guard.validate_exception(now)
        fleet = guard.validate_exception(now, 'dashboard-fleet')
        self.assertNotEqual(old['OPENCLAW_IMAGE'], fleet['OPENCLAW_IMAGE'])
        self.assertEqual('agent-intake,agent-infra,agent-coordinator', fleet['APPROVED_DEPLOYMENTS'])
        for profile in ('default', 'dashboard-fleet'):
            with self.assertRaisesRegex(SystemExit, 'expired'):
                guard.validate_exception(guard.parse_utc('2026-12-08T00:00:00Z'), profile)

    def test_fleet_scope_cannot_be_widened_to_tinus(self):
        now = guard.parse_utc('2026-11-10T12:00:00Z')
        values = guard.validate_exception(now, 'dashboard-fleet')
        values['APPROVED_DEPLOYMENTS'] += ',agent-developer'
        with patch.object(guard, 'read_env', return_value=values):
            with self.assertRaisesRegex(SystemExit, 'APPROVED_DEPLOYMENTS'):
                guard.validate_exception(now, 'dashboard-fleet')

    def test_fleet_exception_cannot_replace_the_default(self):
        now = guard.parse_utc('2026-11-10T12:00:00Z')
        values = guard.validate_exception(now, 'dashboard-fleet')
        del values['APPROVED_DEPLOYMENTS']
        with patch.object(guard, 'read_env', return_value=values):
            with self.assertRaisesRegex(SystemExit, 'OPENCLAW_IMAGE'):
                guard.validate_exception(now)

    def test_qualification_denies_broad_mutation_jobs_even_with_delivery_enabled(self):
        ci = (ROOT / '.gitlab-ci.yml').read_text()
        self.assertNotIn('rollback_openclaw_to_qualified_baseline:', ci)
        for name in ('deploy_openclaw_tinus_canary', 'deploy_openclaw_swarm'):
            job = re.search(rf"(?ms)^{name}:\n(.*?)(?=^[^ \n#]|\Z)", ci).group(1)
            self.assertIn(
                "  rules:\n"
                "    - if: '$RUN_GITLAB_FLEET_IMAGE_QUALIFICATION == \"1\"'\n"
                "      when: never\n",
                job,
            )

    def runtime(self, wrong_image=False, public_backend=False, unapproved_image=None, internal_agents=()):
        observed_images = set()

        def kubectl(*args):
            target = args[-1]
            if args == ('auth', 'whoami'):
                return {'status': {'userInfo': {'username': assurance.IDENTITY}}}
            if target.startswith('deployment/agent-'):
                name = target.split('/')[1]
                policy = 'approved-openclaw-image.env'
                if wrong_image and name == 'agent-developer':
                    policy = 'dashboard-fleet-image-risk-exception.env'
                image = unapproved_image if unapproved_image and name == 'agent-developer' else assurance.exact_image(policy)
                observed_images.add(image)
                return {'status': {'readyReplicas': 1, 'replicas': 1}, 'spec': {'template': {
                    'spec': {'containers': [{'name': 'agent', 'image': image}]}}}}
            if target == 'deployment/openclaw-otel-collector':
                return {'status': {'readyReplicas': 1, 'replicas': 1}}
            if target.startswith('service/agent-'):
                return {'spec': {'type': 'LoadBalancer' if public_backend else 'ClusterIP',
                                 'ports': [{'port': 80, 'targetPort': 18791}]}}
            if target == 'service/openclaw-otel-collector':
                return {'spec': {'type': 'ClusterIP'}}
            if target.startswith('persistentvolumeclaim/'):
                return {'status': {'phase': 'Bound'}}
            self.fail('unexpected read: ' + repr(args))

        # These image-policy fixtures model the existing Tailscale-only Pods.
        # Select transport explicitly instead of inheriting the deployment pilot.
        with tempfile.TemporaryDirectory() as directory, patch.object(assurance, 'kubectl', side_effect=kubectl), \
                patch.object(assurance, 'internal_transport_agents', return_value=set(internal_agents)):
            result = assurance.runtime(Path(directory))
            images = (Path(directory) / 'openclaw-image-references.txt').read_text().splitlines()
            self.assertEqual(set(images), observed_images)
            self.assertEqual(len(images), 2 if unapproved_image or wrong_image else 1)
            return result

    def test_runtime_accepts_the_approved_fleet_image_and_private_backends(self):
        self.assertEqual(self.runtime(), 0)

    def test_runtime_rejects_selected_pilot_without_its_tls_sidecar(self):
        self.assertEqual(self.runtime(internal_agents=('agent-developer',)), 1)

    def test_runtime_rejects_prior_three_agent_image_on_tinus(self):
        self.assertEqual(self.runtime(wrong_image=True), 1)

    def test_runtime_preserves_unapproved_observed_image_for_risk_scan(self):
        self.assertEqual(self.runtime(unapproved_image='registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:' + 'f' * 64), 1)

    def test_runtime_rejects_direct_load_balancer_backend(self):
        self.assertEqual(self.runtime(public_backend=True), 1)
