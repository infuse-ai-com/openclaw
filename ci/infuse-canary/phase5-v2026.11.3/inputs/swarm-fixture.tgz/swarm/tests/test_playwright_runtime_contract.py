"""Regression tests for the shared Playwright browser runtime contract."""

from __future__ import annotations

import os
import re
import subprocess
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]


class PlaywrightRuntimeContractTests(unittest.TestCase):
    """Ensure Playwright can launch without a pod-local browser download."""

    def test_image_seeds_matching_managed_browser_into_pvc_cache(self) -> None:
        dockerfile = (REPO_ROOT / "images/openclaw-agent/Dockerfile").read_text()
        requirements = (
            REPO_ROOT / "images/openclaw-agent/requirements-toolbox.lock"
        ).read_text()

        self.assertIn("ARG PLAYWRIGHT_VERSION=", dockerfile)
        self.assertIn("OPENCLAW_PLAYWRIGHT_SEED_PATH=/opt/playwright-browsers", dockerfile)
        self.assertIn("PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright", dockerfile)
        version = re.search(r"^ARG PLAYWRIGHT_VERSION=(.+)$", dockerfile, re.MULTILINE)
        self.assertIsNotNone(version)
        self.assertIn(f"playwright=={version.group(1)}", requirements)
        self.assertIn("playwright@${PLAYWRIGHT_VERSION}", dockerfile)
        self.assertIn(
            "PLAYWRIGHT_BROWSERS_PATH=/opt/playwright-browsers "
            "python3 -m playwright install chromium",
            dockerfile,
        )

    def test_persistent_agent_cache_follows_the_agent_workspace(self) -> None:
        deployment = (
            REPO_ROOT / "k8s/components/persistent-agent/deployment.yaml"
        ).read_text()

        self.assertIn("- name: PLAYWRIGHT_BROWSERS_PATH", deployment)
        self.assertIn(
            "value: $(OPENCLAW_WORKSPACE)/.cache/ms-playwright", deployment
        )
        self.assertLess(
            deployment.index("- name: OPENCLAW_WORKSPACE"),
            deployment.index("- name: PLAYWRIGHT_BROWSERS_PATH"),
        )

    def test_cache_links_seed_and_preserves_project_browser_revisions(self) -> None:
        helper = REPO_ROOT / "scripts/ensure-playwright-browser-cache.sh"
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            workspace = root / "workspace"
            seed = root / "seed"
            cache = workspace / ".cache" / "ms-playwright"
            (seed / "chromium-seeded").mkdir(parents=True)
            (seed / "chromium-seeded" / "browser").write_text("seeded")
            (seed / ".links").mkdir()
            (seed / ".links" / "image-package").write_text("/opt/image-package")
            (cache / "chromium-project").mkdir(parents=True)
            (cache / "chromium-project" / "browser").write_text("project")
            (cache / ".links").mkdir()
            (cache / ".links" / "project-package").write_text("/workspace/project")
            (cache / "chromium-stale").symlink_to(seed / "missing-revision")

            env = os.environ.copy()
            env.update(
                {
                    "OPENCLAW_WORKSPACE": str(workspace),
                    "PLAYWRIGHT_BROWSERS_PATH": str(cache),
                    "OPENCLAW_PLAYWRIGHT_SEED_PATH": str(seed),
                }
            )
            subprocess.run([str(helper)], check=True, env=env)
            subprocess.run([str(helper)], check=True, env=env)

            self.assertTrue((cache / "chromium-seeded").is_symlink())
            self.assertEqual(
                (cache / "chromium-seeded" / "browser").read_text(), "seeded"
            )
            self.assertEqual(
                (cache / "chromium-seeded").resolve(),
                (seed / "chromium-seeded").resolve(),
            )
            self.assertFalse((cache / "chromium-stale").exists())
            self.assertFalse((cache / "chromium-stale").is_symlink())
            self.assertFalse((cache / "chromium-project").is_symlink())
            self.assertEqual(
                (cache / "chromium-project" / "browser").read_text(), "project"
            )
            self.assertEqual(
                (cache / ".links" / "image-package").read_text(),
                "/opt/image-package",
            )
            self.assertEqual(
                (cache / ".links" / "project-package").read_text(),
                "/workspace/project",
            )

    def test_cache_hydration_rejects_non_pvc_destination(self) -> None:
        helper = REPO_ROOT / "scripts/ensure-playwright-browser-cache.sh"
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            workspace = root / "workspace"
            seed = root / "seed" / "chromium-seeded"
            seed.mkdir(parents=True)

            env = os.environ.copy()
            env.update(
                {
                    "OPENCLAW_WORKSPACE": str(workspace),
                    "PLAYWRIGHT_BROWSERS_PATH": str(root / "outside-cache"),
                    "OPENCLAW_PLAYWRIGHT_SEED_PATH": str(seed.parent),
                }
            )
            result = subprocess.run(
                [str(helper)], check=False, env=env, capture_output=True, text=True
            )

            self.assertEqual(result.returncode, 2)
            self.assertIn("must be inside the workspace PVC", result.stderr)

    def test_live_toolbox_smoke_launches_playwright_chromium(self) -> None:
        smoke = (REPO_ROOT / "scripts/smoke-agent-toolbox.sh").read_text()

        self.assertIn('os.environ["PLAYWRIGHT_BROWSERS_PATH"]', smoke)
        self.assertIn("executable_path.is_relative_to(cache_path)", smoke)
        self.assertIn("resolved_executable_path.is_relative_to(seed_path)", smoke)
        self.assertIn("playwright_api.chromium.launch(headless=True, chromium_sandbox=True)", smoke)
        self.assertIn('page.set_content("<title>OpenClaw toolbox smoke</title>")', smoke)

    def test_image_contains_portable_evidence_verifier(self) -> None:
        dockerfile = (REPO_ROOT / "images/openclaw-agent/Dockerfile").read_text()

        self.assertIn(
            "COPY scripts/verify-agent-evidence-package.py "
            "/usr/local/bin/openclaw-agent-evidence-verify",
            dockerfile,
        )
        self.assertIn("/usr/local/bin/openclaw-agent-evidence-verify", dockerfile)

    def test_live_toolbox_smoke_composes_real_contact_sheet(self) -> None:
        smoke = (REPO_ROOT / "scripts/smoke-agent-toolbox.sh").read_text()
        dockerfile = (REPO_ROOT / "images/openclaw-agent/Dockerfile").read_text()

        self.assertIn("--require-image-composition", smoke)
        self.assertIn(".imageComposition.contactSheet.available == true", smoke)
        self.assertIn(
            '.imageComposition.contactSheet.backend == \\"imagemagick_montage\\"',
            smoke,
        )
        self.assertIn("montage -version", smoke)
        self.assertIn("fonts-urw-base35", dockerfile)


if __name__ == "__main__":
    unittest.main()
