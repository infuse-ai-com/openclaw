"""Contract tests for the live agent repository checkout smoke wrapper."""

from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import tempfile
import textwrap
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]
SMOKE_SCRIPT = REPO_ROOT / "scripts/smoke-agent-repo-checkout.sh"


class RepoCheckoutSmokeContractTests(unittest.TestCase):
    def run_smoke(self, source_url: str | None = None) -> list[list[str]]:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_root = Path(temp_dir)
            log_path = temp_root / "kubectl-calls.jsonl"
            fake_kubectl = temp_root / "kubectl"
            fake_kubectl.write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env python3
                    import json
                    import os
                    from pathlib import Path
                    import sys

                    args = sys.argv[1:]
                    with Path(os.environ["FAKE_KUBECTL_LOG"]).open("a", encoding="utf-8") as handle:
                        handle.write(json.dumps(args) + "\\n")
                    if "get" in args and "pod" in args:
                        print("fake-agent-pod")
                    """
                ),
                encoding="utf-8",
            )
            fake_kubectl.chmod(0o755)

            env = {
                **os.environ,
                "PATH": f"{temp_root}:{os.environ['PATH']}",
                "FAKE_KUBECTL_LOG": str(log_path),
                "TASK_ID": "repo-smoke-contract-test",
                "REPO_NAME": "openclaw-k8s-swarm",
            }
            if source_url is not None:
                env["REPO_SOURCE_URL"] = source_url

            completed = subprocess.run(
                ["bash", str(SMOKE_SCRIPT), "agents-swarm", "agent-developer"],
                cwd=REPO_ROOT,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            return [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]

    @staticmethod
    def create_call(calls: list[list[str]]) -> list[str]:
        return next(
            call
            for call in calls
            if "openclaw-agent-task-workspace" in call
            and "create" in call
        )

    def test_default_source_url_is_explicit_for_wildcard_repo(self) -> None:
        call = self.create_call(self.run_smoke())
        self.assertIn(
            "REPO_SOURCE_URL=https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-k8s-swarm.git",
            call,
        )

    def test_explicit_source_url_override_is_forwarded(self) -> None:
        source_url = "https://dev.azure.com/infuse-ai/Infuse%20AI/_git/assigned-repo"
        call = self.create_call(self.run_smoke(source_url))
        self.assertIn(f"REPO_SOURCE_URL={source_url}", call)


if __name__ == "__main__":
    unittest.main()
