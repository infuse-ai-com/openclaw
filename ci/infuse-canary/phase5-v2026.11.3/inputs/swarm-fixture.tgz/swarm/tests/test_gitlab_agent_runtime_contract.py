import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUNDLE_DIR = ROOT / "config" / "agent-skill-bundles"
AGENT_SKILLS_COMMIT = "93bbfe938470d704f33b6657c6001e312bf3a68b"


class GitLabAgentRuntimeContractTests(unittest.TestCase):
    def test_glab_is_pinned_with_checksums_for_both_runtime_architectures(self) -> None:
        dockerfile = (ROOT / "images" / "openclaw-agent" / "Dockerfile").read_text()
        self.assertIn("ARG GLAB_VERSION=1.128.0", dockerfile)
        self.assertIn(
            "bc024819e7598b19429a199cd87f640d98b2b67416d8ad796f19e4260b57a7c7",
            dockerfile,
        )
        self.assertIn(
            "60d0512085a8c1be7c5ef51aa7e4ee28213444cea0376b3260707d90489199ea",
            dockerfile,
        )
        self.assertIn(
            "glab_${GLAB_VERSION}_linux_${arch}.tar.gz", dockerfile
        )

    def test_toolbox_smoke_requires_glab(self) -> None:
        smoke = (ROOT / "scripts" / "smoke-agent-toolbox.sh").read_text()
        self.assertIn("for bin in git glab task", smoke)
        self.assertIn("glab --version", smoke)

    def test_catalog_pins_merged_gitlab_skill(self) -> None:
        catalog = json.loads((ROOT / "config" / "skill-catalog.json").read_text())
        source = catalog["sources"]["infuse-ai-agent-skills"]
        self.assertEqual(AGENT_SKILLS_COMMIT, source["sync"]["commit"])
        self.assertEqual(
            ["git", "glab", "jq"], catalog["skills"]["gitlab"]["runtime_requirements"]["bins"]
        )

    def test_every_persistent_agent_gets_the_gitlab_skill_without_token_sync(self) -> None:
        for bundle_path in sorted(BUNDLE_DIR.glob("*.json")):
            with self.subTest(bundle=bundle_path.name):
                bundle = json.loads(bundle_path.read_text())
                self.assertIn("gitlab", bundle["skills"]["installed"])
                item_names = {
                    item["name"]
                    for item in bundle["credential_access"]["vaultwarden"]["allowed_items"]
                }
                self.assertFalse(
                    any(name.startswith("GitLab /") for name in item_names),
                    "GitLab tokens must stay task-time Vaultwarden lookups, not Kubernetes Secret sync targets",
                )

    def test_runtime_exposes_the_pinned_source_root_to_skill_wrappers(self) -> None:
        deployment = (
            ROOT / "k8s" / "components" / "persistent-agent" / "deployment.yaml"
        ).read_text()
        self.assertIn("name: AGENT_SKILLS_ROOT", deployment)
        self.assertIn(
            "value: /workspace/agents/$(AGENT_ID)/skill-sources/infuse-ai-agent-skills",
            deployment,
        )
        self.assertIn("name: OPENCLAW_WORKSPACE", deployment)
        self.assertIn("value: /workspace", deployment)
        self.assertIn("name: OPENCLAW_AGENT_WORKSPACE", deployment)
        self.assertIn("value: /workspace/agents/$(AGENT_ID)", deployment)

    def test_entrypoint_configures_tokenless_native_git_helper(self) -> None:
        entrypoint = (
            ROOT / "images" / "openclaw-agent" / "entrypoint.sh"
        ).read_text()

        self.assertIn("git-credential-gitlab-vault.sh", entrypoint)
        self.assertIn(
            "credential.https://gitlab.infuse-ai-tech.party.useHttpPath true",
            entrypoint,
        )
        self.assertIn(
            "credential.https://gitlab.infuse-ai-tech.party.helper",
            entrypoint,
        )
        self.assertIn('openclaw-git-credential-bootstrap', entrypoint)
        self.assertLess(entrypoint.index('openclaw-git-credential-bootstrap'), entrypoint.index('auto_sync_skills='))
        self.assertNotIn("glab auth login", entrypoint)

    def test_agent_overlays_do_not_patch_environment_by_numeric_index(self) -> None:
        for deployment_path in sorted((ROOT / "k8s" / "agents").glob("*/deployment.yaml")):
            with self.subTest(agent=deployment_path.parent.name):
                deployment = deployment_path.read_text()
                self.assertNotIn(
                    "/spec/template/spec/containers/0/env/3/value", deployment
                )


if __name__ == "__main__":
    unittest.main()
