from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class PlatformOperatorIdentityTest(unittest.TestCase):
    def test_gitlab_delivery_is_protected_explicit_and_scoped(self) -> None:
        pipeline = (ROOT / ".gitlab-ci.yml").read_text()
        self.assertIn(
            "stages: [verify, assurance, build, security, deploy, notify]",
            pipeline,
        )
        self.assertIn("job-name: verify_openclaw_swarm", pipeline)
        self.assertIn('RUN_GITLAB_DELIVERY == "1"', pipeline)
        self.assertIn('CI_COMMIT_REF_PROTECTED == "true"', pipeline)
        self.assertIn("resource_group: openclaw-swarm-production", pipeline)
        self.assertIn("when: manual", pipeline)
        self.assertIn("KUBE_CONFIG_B64", pipeline)
        self.assertNotIn("rollback_openclaw_to_qualified_baseline:", pipeline)
        self.assertNotIn("deploy-infuseai-agents.sh", pipeline)
        self.assertNotIn("kubectl apply", pipeline)

    def test_ci_deployer_uses_stable_operator_namespace(self) -> None:
        bootstrap = (ROOT / "k8s/overlays/infuseai/bootstrap-rbac.yaml").read_text()
        diagnostics = (
            ROOT / "k8s/overlays/infuseai/local-openclaw-readonly-rbac.yaml"
        ).read_text()

        for manifest in (bootstrap, diagnostics):
            self.assertIn("name: openclaw-swarm-deployer", manifest)
            self.assertIn("namespace: platform-operators", manifest)
            self.assertNotIn("namespace: oleagut", manifest)

        self.assertIn(
            """  - apiGroups:
      - batch
    resources:
      - cronjobs
    verbs:
      - get
      - list
      - watch
      - create
      - update
      - patch
      - delete
""",
            bootstrap,
        )

    def test_ci_deployer_covers_rollout_subresources(self) -> None:
        bootstrap = (ROOT / "k8s/overlays/infuseai/bootstrap-rbac.yaml").read_text()

        self.assertIn("      - pods/exec", bootstrap)
        self.assertIn("      - deployments/scale", bootstrap)
        self.assertIn("      - jobs", bootstrap)

    def test_agent_tokens_use_platform_operator_service_accounts(self) -> None:
        deploy = (ROOT / "scripts/deploy-infuseai-agents.sh").read_text()
        self.assertIn('local service_account_namespace="${5:-$namespace}"', deploy)
        self.assertIn('-n "$service_account_namespace" create token', deploy)
        self.assertNotIn("apply_agent_readonly_kubeconfig", deploy)

        for agent in ("coordinator", "designer", "developer", "infra", "intake"):
            self.assertIn(
                f"apply_agent_operator_kubeconfig agent-{agent}-operator "
                f"agent-{agent}-kubeconfig agent-{agent}-operator "
                '"$namespace" platform-operators',
                deploy,
            )

    def test_ci_deployer_accepts_namespaced_access_without_namespace_read(self) -> None:
        deploy = (ROOT / "scripts/deploy-infuseai-agents.sh").read_text()
        self.assertIn(
            'auth can-i get configmaps -n "$namespace"',
            deploy,
        )
        self.assertIn(
            "confirmed namespace-scoped access to $namespace",
            deploy,
        )

    def test_recovery_access_uses_normal_platform_operator(self) -> None:
        recovery = (
            ROOT
            / "k8s/platform/artifact-registry-recovery/operator-networkpolicy-read-rbac.yaml"
        ).read_text()
        self.assertIn("name: kapiteky-cluster-operator", recovery)
        self.assertIn("namespace: platform-operators", recovery)
        self.assertNotIn("namespace: oleagut", recovery)


if __name__ == "__main__":
    unittest.main()
