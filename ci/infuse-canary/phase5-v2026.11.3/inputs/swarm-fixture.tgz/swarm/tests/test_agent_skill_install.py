from __future__ import annotations

import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
INSTALLER_PATH = ROOT / "scripts" / "install-agent-skills.py"
SPEC = importlib.util.spec_from_file_location("agent_skill_installer", INSTALLER_PATH)
assert SPEC is not None and SPEC.loader is not None
INSTALLER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(INSTALLER)


class PruneUnselectedSkillsTests(unittest.TestCase):
    def setUp(self) -> None:
        self.catalog = {
            "sources": {
                "source-a": {"materialization": "managed-copy"},
                "source-b": {"materialization": "managed-copy"},
                "runtime": {"materialization": "runtime-native"},
            },
            "skills": {
                "selected": {"source": "source-a"},
                "stale-a": {"source": "source-a"},
                "stale-b": {"source": "source-b"},
                "native-shadow": {"source": "runtime"},
            }
        }

    @staticmethod
    def create_skill(root: Path, skill_id: str) -> None:
        skill = root / skill_id
        skill.mkdir()
        (skill / "SKILL.md").write_text("fixture\n", encoding="utf-8")

    def test_full_install_prunes_every_catalog_known_absent_skill(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir)
            for skill_id in (
                "selected",
                "stale-a",
                "stale-b",
                "native-shadow",
                "unmanaged",
            ):
                self.create_skill(target, skill_id)

            INSTALLER.prune_unselected_skills(
                target,
                self.catalog,
                ["selected"],
                None,
            )

            self.assertTrue((target / "selected").is_dir())
            self.assertFalse((target / "stale-a").exists())
            self.assertFalse((target / "stale-b").exists())
            self.assertFalse((target / "native-shadow").exists())
            self.assertTrue((target / "unmanaged").is_dir())

    def test_source_scoped_sync_prunes_only_that_source(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir)
            for skill_id in ("selected", "stale-a", "stale-b", "native-shadow"):
                self.create_skill(target, skill_id)

            INSTALLER.prune_unselected_skills(
                target,
                self.catalog,
                ["selected"],
                {"source-a"},
            )

            self.assertTrue((target / "selected").is_dir())
            self.assertFalse((target / "stale-a").exists())
            self.assertTrue((target / "stale-b").is_dir())
            self.assertFalse((target / "native-shadow").exists())

    def test_runtime_native_selection_does_not_prepare_copy_source(self) -> None:
        prepared = INSTALLER.prepare_sources(
            self.catalog,
            ["native-shadow"],
            "none",
        )
        self.assertEqual(prepared, {})


class PinnedSourceSyncTests(unittest.TestCase):
    @staticmethod
    def git(root: Path, *args: str) -> str:
        result = subprocess.run(["git", "-C", str(root), *args], check=True, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return result.stdout.strip()

    def test_pinned_sync_detaches_at_the_reviewed_ancestor(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            remote, seed, runtime = base / "remote.git", base / "seed", base / "runtime"
            subprocess.run(["git", "init", "--bare", str(remote)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git", "init", "--initial-branch=main", str(seed)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.git(seed, "config", "user.email", "test@example.invalid")
            self.git(seed, "config", "user.name", "Skill Test")
            (seed / "SKILL.md").write_text("first\n", encoding="utf-8")
            self.git(seed, "add", "SKILL.md"); self.git(seed, "commit", "-m", "first")
            pinned = self.git(seed, "rev-parse", "HEAD")
            self.git(seed, "remote", "add", "origin", str(remote)); self.git(seed, "push", "-u", "origin", "main")
            (seed / "SKILL.md").write_text("second\n", encoding="utf-8")
            self.git(seed, "commit", "-am", "second"); self.git(seed, "push", "origin", "main")
            subprocess.run(["git", "clone", "--branch", "main", str(remote), str(runtime)], check=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            source = {"repo": "fixture/skills", "sync": {"strategy": "pinned", "remote": "origin",
                "branch": "main", "commit": pinned}}
            INSTALLER.sync_git_source("fixture", source, runtime, "latest")
            self.assertEqual(pinned, self.git(runtime, "rev-parse", "HEAD"))
            self.assertEqual("HEAD", self.git(runtime, "rev-parse", "--abbrev-ref", "HEAD"))


if __name__ == "__main__":
    unittest.main()
