from __future__ import annotations

import copy
import importlib.util
from pathlib import Path
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
VALIDATOR_PATH = ROOT / "scripts" / "verify-agent-skill-bundles.py"
SPEC = importlib.util.spec_from_file_location("skill_catalog_validator", VALIDATOR_PATH)
assert SPEC is not None and SPEC.loader is not None
VALIDATOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VALIDATOR)


def raise_value_error(message: str) -> None:
    raise ValueError(message)


class SkillCatalogAlignmentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.runtime_catalog = {
            "sources": {
                "source-a": {
                    "catalog_version": 2,
                    "contract_fields": [
                        "status",
                        "default_exposure",
                        "display_name",
                        "depends_on",
                    ],
                    "optional_contract_fields": [],
                }
            },
            "skills": {
                "example": {
                    "source": "source-a",
                    "status": "active",
                    "default_exposure": "role",
                    "display_name": "Example",
                    "depends_on": [],
                    "summary": "Runtime-facing summary.",
                }
            }
        }
        self.source_catalog = {
            "version": 2,
            "skills": {
                "example": {
                    "status": "active",
                    "default_exposure": "role",
                    "display_name": "Example",
                    "depends_on": [],
                    "summary": "Source-owned summary may be more detailed.",
                }
            }
        }

    def validate(self, runtime_catalog: dict, source_catalog: dict) -> None:
        VALIDATOR.validate_source_catalog_alignment(runtime_catalog, "source-a", source_catalog)

    def test_exact_ids_status_and_exposure_are_accepted(self) -> None:
        self.validate(self.runtime_catalog, self.source_catalog)

    def test_source_only_skill_is_rejected(self) -> None:
        source_catalog = copy.deepcopy(self.source_catalog)
        source_catalog["skills"]["missing"] = {
            "status": "active",
            "default_exposure": "role",
        }

        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, r"missing_from_runtime=\['missing'\]"
        ):
            self.validate(self.runtime_catalog, source_catalog)

    def test_exposure_drift_is_rejected(self) -> None:
        runtime_catalog = copy.deepcopy(self.runtime_catalog)
        runtime_catalog["skills"]["example"]["default_exposure"] = "restricted"

        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "default_exposure drifted"
        ):
            self.validate(runtime_catalog, self.source_catalog)

    def test_portfolio_metadata_drift_is_rejected(self) -> None:
        runtime_catalog = copy.deepcopy(self.runtime_catalog)
        runtime_catalog["skills"]["example"]["display_name"] = "Drifted"

        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "display_name drifted"
        ):
            self.validate(runtime_catalog, self.source_catalog)

    def test_source_catalog_version_drift_is_rejected(self) -> None:
        source_catalog = copy.deepcopy(self.source_catalog)
        source_catalog["version"] = 1

        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "version drifted"
        ):
            self.validate(self.runtime_catalog, source_catalog)


class SkillMaterializationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.catalog = VALIDATOR.load_json(ROOT / "config" / "skill-catalog.json")

    def validate_failure(self, catalog: dict, pattern: str) -> None:
        with mock.patch.object(
            VALIDATOR, "fail", side_effect=raise_value_error
        ), self.assertRaisesRegex(ValueError, pattern):
            VALIDATOR.validate_catalog(catalog)

    def test_repository_catalog_materialization_contract_is_valid(self) -> None:
        VALIDATOR.validate_catalog(self.catalog)

    def test_source_without_materialization_is_rejected(self) -> None:
        catalog = copy.deepcopy(self.catalog)
        del catalog["sources"]["openclaw-core"]["materialization"]
        self.validate_failure(catalog, "materialization must be one of")

    def test_legacy_runtime_catalog_version_is_rejected(self) -> None:
        catalog = copy.deepcopy(self.catalog)
        catalog["version"] = 1
        self.validate_failure(catalog, "catalog.version must be 2")

    def test_runtime_native_skill_requires_expected_provenance(self) -> None:
        catalog = copy.deepcopy(self.catalog)
        del catalog["skills"]["diagram-maker"]["runtime_native"]
        self.validate_failure(catalog, "runtime_native must be an object")

    def test_runtime_native_skill_must_match_source_provenance(self) -> None:
        catalog = copy.deepcopy(self.catalog)
        catalog["skills"]["diagram-maker"]["runtime_native"]["expected_source"] = (
            "openclaw-extra"
        )
        self.validate_failure(catalog, "expected_source must match source")

    def test_plugin_runtime_native_skill_requires_plugin_id(self) -> None:
        catalog = copy.deepcopy(self.catalog)
        del catalog["skills"]["browser-automation"]["runtime_native"]["plugin_id"]
        self.validate_failure(catalog, "plugin_id must be a non-empty string")

    def test_browser_plugin_uses_openclaw_extra_runtime_provenance(self) -> None:
        source = self.catalog["sources"]["openclaw-plugin-skills"]
        skill = self.catalog["skills"]["browser-automation"]
        self.assertEqual(source["expected_runtime_source"], "openclaw-extra")
        self.assertEqual(skill["runtime_native"]["expected_source"], "openclaw-extra")


class ContextRouteTests(unittest.TestCase):
    def test_rejects_host_paths_retired_layout_and_peer_workspaces(self):
        bundle = VALIDATOR.load_json(ROOT / "config/agent-skill-bundles/agent-developer.json")
        for ref in ("/Users/mac/Code/Infuse AI/company-docs/docs/company-os.md",
                    "company-docs/docs/company-os.md",
                    "docs/../README.md",
                    "/workspace/agents/agent-coordinator/skills/gitlab/SKILL.md"):
            with self.subTest(ref=ref):
                candidate = copy.deepcopy(bundle)
                candidate["context_profile"]["default_docs"] = [ref]
                with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaises(ValueError):
                    VALIDATOR.validate_context_profile(candidate, Path("bundle.json"))


class BundleDependencyClosureTests(unittest.TestCase):
    def setUp(self) -> None:
        self.skills = {
            "base": {"depends_on": []},
            "composed": {"depends_on": ["base"]},
        }

    def validate(
        self,
        installed: set[str],
    ) -> None:
        VALIDATOR.validate_bundle_dependency_closure(
            Path("bundle.json"),
            self.skills,
            installed,
        )

    def test_installed_dependency_closure_is_accepted(self) -> None:
        self.validate({"base", "composed"})

    def test_installed_skill_with_missing_dependency_is_rejected(self) -> None:
        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "without installed dependencies"
        ):
            self.validate({"composed"})


class ContextProfileSkillPolicyTests(unittest.TestCase):
    def validate(self, profile: dict) -> None:
        VALIDATOR.validate_context_profile(
            {"context_profile": {"default_docs": ["docs/RUNBOOK.md"], **profile}},
            Path("bundle.json"),
        )

    def test_binary_skill_change_policy_is_accepted(self) -> None:
        self.validate({"skill_change_policy": "Reviewed bundle update required."})

    def test_legacy_temporary_elevation_is_rejected(self) -> None:
        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "temporary_elevation is retired"
        ):
            self.validate(
                {
                    "temporary_elevation": "Optional skill for one task.",
                    "skill_change_policy": "Reviewed bundle update required.",
                }
            )

    def test_missing_skill_change_policy_is_rejected(self) -> None:
        with mock.patch.object(VALIDATOR, "fail", side_effect=raise_value_error), self.assertRaisesRegex(
            ValueError, "skill_change_policy must be a non-empty string"
        ):
            self.validate({})


if __name__ == "__main__":
    unittest.main()
