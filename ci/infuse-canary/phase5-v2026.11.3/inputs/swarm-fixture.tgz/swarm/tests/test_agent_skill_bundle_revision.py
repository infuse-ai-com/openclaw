import copy
import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "derive-agent-skill-bundle-revision.py"
SPEC = importlib.util.spec_from_file_location("skill_bundle_revision", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def manifest() -> dict:
    return {
        "agent_id": "agent-developer",
        "bundle": "/volatile/config/agent-developer.json",
        "installed_at": "2026-08-28T00:00:00Z",
        "source_sync": "latest",
        "declared_skills": ["verify-this"],
        "sources": {
            "infuse-ai-agent-skills": {
                "id": "infuse-ai-agent-skills",
                "repo": "agent-skills",
                "path": "/volatile/source",
                "kind": "git",
                "branch": "main",
                "commit": "a" * 40,
                "dirty": False,
                "remote_url": "https://example.invalid/private",
            }
        },
        "skills": [
            {
                "id": "verify-this",
                "source": "infuse-ai-agent-skills",
                "source_commit": "a" * 40,
                "installed_path": "/volatile/skills/verify-this",
                "files": [
                    {"path": "SKILL.md", "sha256": "b" * 64, "bytes": 123},
                ],
            }
        ],
        "runtime_native_skills": [],
    }


class AgentSkillBundleRevisionTest(unittest.TestCase):
    def test_ignores_volatile_install_metadata(self) -> None:
        first = manifest()
        second = copy.deepcopy(first)
        second["installed_at"] = "2026-08-29T01:02:03Z"
        second["bundle"] = "/different/bundle.json"
        second["sources"]["infuse-ai-agent-skills"]["path"] = "/different/source"
        second["skills"][0]["installed_path"] = "/different/skills/verify-this"
        self.assertEqual(MODULE.revision(first), MODULE.revision(second))

    def test_changes_when_skill_content_changes(self) -> None:
        first = manifest()
        second = copy.deepcopy(first)
        second["skills"][0]["files"][0]["sha256"] = "c" * 64
        self.assertNotEqual(MODULE.revision(first), MODULE.revision(second))

    def test_revision_is_bounded_sha256(self) -> None:
        value = MODULE.revision(manifest())
        self.assertRegex(value, r"^sha256:[0-9a-f]{64}$")


if __name__ == "__main__":
    unittest.main()
