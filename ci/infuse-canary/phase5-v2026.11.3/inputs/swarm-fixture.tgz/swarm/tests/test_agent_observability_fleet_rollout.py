from pathlib import Path
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[1]
ROLLOUT = ROOT / "scripts" / "rollout-agent-observability.sh"
SMOKE = ROOT / "scripts" / "smoke-agent-runtime.sh"


class AgentObservabilityFleetRolloutTest(unittest.TestCase):
    def test_rollout_is_ordered_digest_pinned_and_rollback_guarded(self) -> None:
        source = ROLLOUT.read_text(encoding="utf-8")
        subprocess.run(["bash", "-n", str(ROLLOUT)], check=True)
        self.assertIn("CONFIRM_AGENT_OBSERVABILITY_ROLLOUT", source)
        self.assertIn("agent-developer agent-infra agent-designer agent-coordinator agent-intake", source)
        self.assertIn('immutable_image="$image_repository@$digest"', source)
        self.assertIn("rollout undo", source)
        self.assertIn("apply --dry-run=server", source)
        self.assertIn("EXPECTED_OBSERVABILITY=true", source)
        self.assertIn("scripts/smoke-agent-runtime.sh", source)
        self.assertIn("original_service_account", source)
        self.assertIn("template_fingerprint", source)
        self.assertNotIn("apply -k k8s/overlays/infuseai", source)

    def test_runtime_smoke_proves_both_plugins_and_metadata_only_config(self) -> None:
        source = SMOKE.read_text(encoding="utf-8")
        subprocess.run(["bash", "-n", str(SMOKE)], check=True)
        self.assertIn("EXPECTED_OBSERVABILITY", source)
        self.assertIn("plugins inspect diagnostics-otel", source)
        self.assertIn("plugins inspect behavioral-observability", source)
        self.assertIn("captureContent == false", source)
        self.assertIn('expected_service_name="openclaw-$agent_id"', source)


if __name__ == "__main__":
    unittest.main()
