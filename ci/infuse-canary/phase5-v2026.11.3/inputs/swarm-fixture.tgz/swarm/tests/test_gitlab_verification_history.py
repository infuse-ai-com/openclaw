import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class GitLabVerificationHistoryTests(unittest.TestCase):
    def test_ancestry_verification_uses_complete_git_history(self) -> None:
        lines = (ROOT / ".gitlab-ci.yml").read_text().splitlines()
        start = lines.index("verify_openclaw_swarm:")
        end = next(
            index
            for index in range(start + 1, len(lines))
            if lines[index] and not lines[index].startswith((" ", "\t"))
        )
        verification = "\n".join(lines[start:end])

        self.assertIn('  variables:\n    GIT_DEPTH: "0"', verification)


if __name__ == "__main__":
    unittest.main()
