from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "artifact-registry-backup.py"
SPEC = importlib.util.spec_from_file_location("artifact_registry_backup_operator", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class ArtifactRegistryBackupOperatorTests(unittest.TestCase):
    def test_remote_target_is_exact_and_rejects_unsafe_shapes(self) -> None:
        self.assertEqual(
            MODULE.remote_target("nas-rpi:/mnt/wds2/infuse-ai-backups/artifact-registry/"),
            ("nas-rpi", "/mnt/wds2/infuse-ai-backups/artifact-registry"),
        )
        for value in (
            "nas-rpi",
            "nas-rpi:relative",
            "nas-rpi:/",
            "nas-rpi:/path with space",
            "nas-rpi:/safe/../escape",
            "nas-rpi:/path;touch-bad",
            "nas-rpi:/path/$HOME",
            "bad;host:/path",
        ):
            with self.assertRaises(MODULE.BackupError):
                MODULE.remote_target(value)

    def test_verify_local_bundle_checks_exact_inventory(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            bundle = Path(temporary)
            payload = bundle / "payload" / "objects" / "agent-infra"
            payload.mkdir(parents=True)
            body = b"bounded synthetic backup fixture"
            target = payload / "state.json"
            target.write_bytes(body)
            files = [{
                "path": "objects/agent-infra/state.json",
                "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest(),
            }]
            manifest = {
                "schema": "infuse.artifact-registry-backup/v1",
                "sourceReconciliationDigest": "a" * 64,
                "rootDigest": "b" * 64,
                "fileCount": 1,
                "totalBytes": len(body),
                "files": files,
            }
            (bundle / "backup-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            receipt = MODULE.verify_local_bundle(bundle)
            self.assertEqual(receipt["fileCount"], 1)
            target.write_bytes(b"changed")
            with self.assertRaises(MODULE.BackupError):
                MODULE.verify_local_bundle(bundle)

    def test_verify_job_removes_source_mount_and_runs_verify(self) -> None:
        template = {
            "metadata": {"name": "template", "annotations": {"suspended": "true"}},
            "spec": {
                "suspend": True,
                "template": {"spec": {
                    "containers": [{
                        "command": ["node", "/app/recovery.cjs", "create"],
                        "env": [
                            {"name": "ARTIFACT_REGISTRY_ROOT", "value": "/source"},
                            {"name": "ARTIFACT_REGISTRY_BACKUP_PATH", "value": "/backup/placeholder"},
                        ],
                        "volumeMounts": [
                            {"name": "source", "mountPath": "/source"},
                            {"name": "backup", "mountPath": "/backup"},
                            {"name": "tmp", "mountPath": "/tmp"},
                        ],
                    }],
                    "volumes": [
                        {"name": "source"},
                        {"name": "backup"},
                        {"name": "tmp"},
                    ],
                }},
            },
        }
        job = MODULE.sanitized_job(template, name="verify", backup_id="registry-20260901-010101", action="verify", image="registry.invalid/studio/artifact-registry@sha256:" + "a" * 64)
        container = job["spec"]["template"]["spec"]["containers"][0]
        self.assertEqual(container["image"], "registry.invalid/studio/artifact-registry@sha256:" + "a" * 64)
        self.assertEqual(container["command"][-1], "verify")
        self.assertEqual({mount["name"] for mount in container["volumeMounts"]}, {"backup", "tmp"})

        self.assertFalse(job["spec"]["suspend"])

    def test_every_recovery_operation_uses_deployed_image_and_rejects_tags(self):
        objects = MODULE.load_recovery_objects(ROOT)
        for action, template_name in [("create", "backoffice-artifact-registry-backup-template"),
                                      ("verify", "backoffice-artifact-registry-backup-template"),
                                      ("restore", "backoffice-artifact-registry-restore-template")]:
            template = objects[("Job", template_name)]
            image = "registry.invalid/studio/artifact-registry@sha256:" + "b" * 64
            job = MODULE.sanitized_job(template, name="qualified", backup_id="synthetic", action=action, image=image)
            self.assertEqual(job["spec"]["template"]["spec"]["containers"][0]["image"], image)
            self.assertTrue(template["spec"]["suspend"])
            self.assertEqual(template["spec"]["template"]["spec"]["containers"][0]["image"], "REPLACE_WITH_DEPLOYED_REGISTRY_IMAGE")
            for invalid in ["registry.invalid/image:latest", "REPLACE_WITH_DEPLOYED_REGISTRY_IMAGE", image + "\n"]:
                with self.assertRaises(MODULE.BackupError):
                    MODULE.sanitized_job(template, name="blocked", backup_id="synthetic", action=action, image=invalid)

    def test_mutable_deployed_image_fails_before_quiescence(self):
        deployment = {"spec": {"replicas": 1, "template": {"spec": {
            "containers": [{"image": "registry.invalid/artifact-registry:latest"}]
        }}}}
        with patch.object(MODULE, "preflight"), \
             patch.object(MODULE, "load_recovery_objects", return_value={("NetworkPolicy", "backoffice-artifact-registry-recovery-deny-all"): {}}), \
             patch.object(MODULE, "verify_recovery_network_policy"), \
             patch.object(MODULE, "kube", return_value=json.dumps(deployment)) as kube, \
             patch.object(MODULE, "apply_object") as apply:
            with self.assertRaisesRegex(MODULE.BackupError, "exact deployed Registry image"):
                MODULE.main(["--approved", "--off-node-target", "nas-rpi:/mnt/wds2/synthetic"])
        kube.assert_called_once()
        self.assertEqual(kube.call_args.args[2], "get")
        apply.assert_not_called()

    def test_helper_pod_uses_private_work_volume_for_temporary_files(self) -> None:
        pod = MODULE.helper_pod(
            namespace="core",
            name="backup-export",
            image="registry.invalid/backup@sha256:" + "a" * 64,
            claim_name="backup-pvc",
            read_only=True,
        )
        container = pod["spec"]["containers"][0]
        temporary_mount = next(
            mount for mount in container["volumeMounts"] if mount["name"] == "tmp"
        )
        self.assertEqual("/work", temporary_mount["mountPath"])
        self.assertEqual([{"name": "TMPDIR", "value": "/work"}], container["env"])

    def test_recovery_network_policy_must_match_reviewed_source(self) -> None:
        expected = {
            "apiVersion": "networking.k8s.io/v1",
            "kind": "NetworkPolicy",
            "metadata": {
                "name": "backoffice-artifact-registry-recovery-deny-all",
                "namespace": "core",
            },
            "spec": {
                "podSelector": {"matchLabels": {"component": "recovery"}},
                "policyTypes": ["Ingress", "Egress"],
                "ingress": [],
                "egress": [],
            },
        }
        live = json.loads(json.dumps(expected))
        live["spec"].pop("ingress")
        live["spec"].pop("egress")
        live["spec"]["policyTypes"].reverse()
        MODULE.validate_recovery_network_policy(live, expected, "core")
        live["spec"]["policyTypes"] = ["Ingress"]
        with self.assertRaises(MODULE.BackupError):
            MODULE.validate_recovery_network_policy(live, expected, "core")

        live = json.loads(json.dumps(expected))
        live["spec"]["egress"] = [{"to": [{"namespaceSelector": {}}]}]
        with self.assertRaises(MODULE.BackupError):
            MODULE.validate_recovery_network_policy(live, expected, "core")

    def test_wait_job_fails_immediately_on_terminal_failure(self) -> None:
        failed = json.dumps({"status": {"conditions": [{"type": "Failed", "status": "True"}]}})
        with patch.object(MODULE, "kube", return_value=failed) as kube:
            with self.assertRaisesRegex(MODULE.BackupError, "failed before producing a receipt"):
                MODULE.wait_job("infuseai-k8s", "core", "failed-job")
        kube.assert_called_once()

    def test_wait_job_reads_receipt_after_completion(self) -> None:
        complete = json.dumps({"status": {"conditions": [{"type": "Complete", "status": "True"}]}})
        receipt = json.dumps({"schema": "infuse.artifact-registry-backup-receipt/v1"})
        with patch.object(MODULE, "kube", side_effect=[complete, receipt]) as kube:
            self.assertEqual(
                MODULE.wait_job("infuseai-k8s", "core", "complete-job"),
                {"schema": "infuse.artifact-registry-backup-receipt/v1"},
            )
        self.assertEqual(kube.call_count, 2)


if __name__ == "__main__":
    unittest.main()
