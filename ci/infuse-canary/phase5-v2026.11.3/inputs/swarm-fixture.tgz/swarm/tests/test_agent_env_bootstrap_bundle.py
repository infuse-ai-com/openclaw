from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
VALIDATOR_PATH = ROOT / "scripts" / "verify-agent-skill-bundles.py"
SPEC = importlib.util.spec_from_file_location("bundle_validator", VALIDATOR_PATH)
assert SPEC is not None and SPEC.loader is not None
VALIDATOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VALIDATOR)


class AgentEnvBootstrapBundleTests(unittest.TestCase):
    def setUp(self) -> None:
        bundle = json.loads(
            (ROOT / "config" / "agent-skill-bundles" / "agent-developer.json").read_text(
                encoding="utf-8"
            )
        )
        self.bundle = bundle
        self.grant = {
            "projects": {
                "md-poc-monorepo": {
                    "purpose": "Generate the approved MarkdownGPT local-minimal env profile.",
                    "review_or_expiry": "Review after the pilot.",
                    "profiles": ["local-minimal"],
                    "vault_refs": {
                        "mdgpt/local/TEST_USERNAME": {
                            "item": "Project MarkdownGPT / env bootstrap fixture",
                            "field": "password",
                        }
                    },
                }
            }
        }

    def validate(self, bundle: dict[str, object]) -> None:
        VALIDATOR.validate_credential_access(bundle, Path("config/test-bundle.json"))

    def test_exact_env_bootstrap_binding_is_accepted_without_sync_target(self) -> None:
        bundle = copy.deepcopy(self.bundle)
        bundle["credential_access"]["vaultwarden"]["env_bootstrap"] = self.grant

        self.validate(bundle)

    def test_unsupported_item_field_is_rejected(self) -> None:
        bundle = copy.deepcopy(self.bundle)
        grant = copy.deepcopy(self.grant)
        grant["projects"]["md-poc-monorepo"]["vault_refs"]["mdgpt/local/TEST_USERNAME"][
            "field"
        ] = "totp"
        bundle["credential_access"]["vaultwarden"]["env_bootstrap"] = grant

        with mock.patch.object(VALIDATOR, "fail", side_effect=ValueError), self.assertRaises(
            ValueError
        ):
            self.validate(bundle)

    def test_retired_direct_lookup_metadata_is_rejected(self) -> None:
        bundle = copy.deepcopy(self.bundle)
        bundle["credential_access"]["vaultwarden"]["direct_lookup"] = {}

        with mock.patch.object(VALIDATOR, "fail", side_effect=ValueError), self.assertRaises(
            ValueError
        ):
            self.validate(bundle)

    def test_retired_collection_metadata_is_rejected(self) -> None:
        bundle = copy.deepcopy(self.bundle)
        bundle["credential_access"]["vaultwarden"]["allowed_collections"] = ["obsolete"]

        with mock.patch.object(VALIDATOR, "fail", side_effect=ValueError), self.assertRaises(
            ValueError
        ):
            self.validate(bundle)


if __name__ == "__main__":
    unittest.main()
