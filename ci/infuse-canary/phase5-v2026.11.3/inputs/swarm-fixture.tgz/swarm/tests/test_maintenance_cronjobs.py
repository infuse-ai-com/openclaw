from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
OVERLAY = ROOT / "k8s" / "overlays" / "infuseai"

EXPECTED_SCHEDULES = {
    "agent-memory-sync.yaml": 'schedule: "30 3 * * *"',
    "agent-model-policy-collector.yaml": 'schedule: "0,15,30,45 * * * *"',
    "agent-skill-proposal-monitor.yaml": 'schedule: "3,18,33,48 * * * *"',
    "agent-token-usage-collector.yaml": 'schedule: "6,21,36,51 * * * *"',
    "scheduler-collector.yaml": 'schedule: "9,24,39,54 * * * *"',
}


class MaintenanceCronJobTests(unittest.TestCase):
    def test_schedules_are_staggered_and_jobs_expire_after_seven_days(self) -> None:
        for filename, schedule in EXPECTED_SCHEDULES.items():
            with self.subTest(filename=filename):
                manifest = (OVERLAY / filename).read_text(encoding="utf-8")
                self.assertIn(schedule, manifest)
                if filename == "agent-memory-sync.yaml":
                    self.assertIn("timeZone: Etc/UTC", manifest)
                self.assertIn("successfulJobsHistoryLimit: 2", manifest)
                self.assertIn("failedJobsHistoryLimit: 3", manifest)
                self.assertIn("ttlSecondsAfterFinished: 604800", manifest)
                self.assertIn("imagePullSecrets:", manifest)
                self.assertIn("- name: harbor-pull", manifest)

    def test_runtime_release_reconciles_maintenance_cronjobs(self) -> None:
        deploy = (ROOT / "scripts" / "deploy-infuseai-agents.sh").read_text(encoding="utf-8")
        self.assertIn('RECONCILE_MAINTENANCE_CRONJOBS:-false', deploy)
        self.assertIn("reconcile_maintenance_cronjobs", deploy)
        self.assertIn("reconciled five maintenance CronJobs", deploy)
        for name in (
            "openclaw-agent-memory-sync",
            "openclaw-agent-model-policy-collector",
            "openclaw-agent-skill-proposal-monitor",
            "openclaw-agent-token-usage-collector",
            "openclaw-scheduler-collector",
        ):
            self.assertIn(name, deploy)


if __name__ == "__main__":
    unittest.main()
