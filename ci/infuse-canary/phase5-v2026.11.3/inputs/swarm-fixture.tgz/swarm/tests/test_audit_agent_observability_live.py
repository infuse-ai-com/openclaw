import importlib.util
import unittest
from unittest import mock
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "audit-agent-observability-live.py"
SPEC = importlib.util.spec_from_file_location("audit_agent_observability_live", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


class AuditAgentObservabilityLiveTest(unittest.TestCase):
    def test_v4_client_uses_cursor_pagination_and_bounded_fields(self) -> None:
        client = MODULE.LangfuseClient("https://langfuse.example", "pk-lf-test", "sk-lf-test")
        self.assertEqual(
            client.endpoint,
            "https://langfuse.example/api/public/v2/observations",
        )
        pages = [
            {"data": [{"id": "one"}], "meta": {"cursor": "next"}},
            {"data": [{"id": "two"}], "meta": {"cursor": None}},
        ]
        with mock.patch.object(client, "request", side_effect=pages) as request:
            rows = list(
                client.observations(
                    start="2026-10-17T00:00:00.000Z",
                    end="2026-10-17T01:00:00.000Z",
                    name="openclaw.run",
                )
            )
        self.assertEqual([row["id"] for row in rows], ["one", "two"])
        first_query = request.call_args_list[0].args[0]
        second_query = request.call_args_list[1].args[0]
        self.assertEqual(
            first_query["fields"],
            "core,basic,metadata,io,model,usage,trace_context",
        )
        self.assertNotIn("cursor", first_query)
        self.assertEqual(second_query["cursor"], "next")
        self.assertNotIn("page", second_query)

    def test_v4_client_rejects_invalid_cursor_metadata(self) -> None:
        client = MODULE.LangfuseClient("https://langfuse.example", "pk-lf-test", "sk-lf-test")
        with mock.patch.object(
            client,
            "request",
            return_value={"data": [], "meta": {"cursor": 123}},
        ):
            with self.assertRaisesRegex(MODULE.AuditError, "invalid cursor"):
                list(
                    client.observations(
                        start="2026-10-17T00:00:00.000Z",
                        end="2026-10-17T01:00:00.000Z",
                    )
                )

    def test_summary_is_aggregate_only_and_normalizes_shell_aliases(self) -> None:
        rows = [
            {
                "level": "DEFAULT",
                "input": None,
                "output": None,
                "traceId": "must-not-survive",
                "metadata": {
                    "attributes": {
                        "openclaw.toolName": "bash",
                        "traffic.source": "human",
                        "gen_ai.tool.call.id": "must-not-survive",
                    },
                    "resourceAttributes": {"openclaw.agent.name": "agent-developer"},
                },
            },
            {
                "level": "ERROR",
                "statusMessage": "must-not-survive",
                "input": None,
                "output": None,
                "metadata": {
                    "attributes": {"openclaw.toolName": "exec"},
                    "resourceAttributes": {"openclaw.agent.name": "agent-developer"},
                },
            },
        ]
        report = MODULE.summarize_signal("openclaw.tool.execution", rows)
        self.assertEqual(report["attempts"], 2)
        self.assertEqual(report["errors"], 1)
        self.assertEqual(report["tools"], {"exec": {"attempts": 2, "errors": 1}})
        serialized = str(report)
        self.assertNotIn("must-not-survive", serialized)

    def test_v4_flattened_metadata_preserves_bounded_agent_attribution(self) -> None:
        report = MODULE.summarize_signal(
            "openclaw.run",
            [
                {
                    "input": None,
                    "output": None,
                    "metadata": {
                        "attributes.openclaw.outcome": "success",
                        "attributes.traffic.source": "smoke",
                        "resourceAttributes.openclaw.agent.name": "agent-infra",
                        "resourceAttributes.service.name": "openclaw-agent-infra",
                    },
                }
            ],
        )
        self.assertEqual(report["attempts"], 1)
        self.assertEqual(report["byAgent"], {"agent-infra": 1})
        self.assertEqual(report["trafficSource"], {"smoke": 1})
        self.assertEqual(report["contentObservations"], 0)

    def test_unapproved_traffic_source_fails_closed_to_unavailable(self) -> None:
        report = MODULE.summarize_signal(
            "infuse.agent.turn",
            [{"metadata": {"attributes": {"traffic.source": "guess"}}}],
        )
        self.assertEqual(report["trafficSource"], {"unavailable": 1})

    def test_window_summary_reports_shape_types_failure_coverage_and_cost_state(self) -> None:
        rows = [
            {
                "traceId": "curated",
                "name": "infuse.agent.turn",
                "type": "AGENT",
                "input": None,
                "output": None,
            },
            {
                "traceId": "curated",
                "name": "infuse.model.call",
                "type": "GENERATION",
                "usageDetails": {"input": 10, "output": 2, "total": 12},
                "totalCost": 0,
                "metadata": {"pricing_status": "unpriced"},
            },
            {
                "traceId": "curated",
                "name": "infuse.tool.execution",
                "type": "TOOL",
                "level": "ERROR",
                "metadata": {
                    "failure_category": "invalid_input",
                    "tool_name": "studio_whiteboard_apply",
                    "attributes": {
                        "outcome": "error",
                    }
                },
            },
            {
                "traceId": "singleton",
                "name": "openclaw.memory.pressure",
                "type": "SPAN",
            },
        ]
        summary = MODULE.summarize_window(rows)
        self.assertEqual(summary["traces"], 2)
        self.assertEqual(summary["singletonTraces"], 1)
        self.assertEqual(summary["singletonFamilies"], {"openclaw.memory.pressure": 1})
        self.assertEqual(summary["canonicalCuratedTurnTraces"], 1)
        self.assertEqual(summary["mixedOfficialCuratedTraces"], 0)
        self.assertEqual(summary["observationTypes"]["generation"], 1)
        self.assertEqual(summary["toolFailureCoverage"]["actionablePct"], 100.0)
        self.assertEqual(summary["modelUsage"]["withUsage"], 1)
        self.assertEqual(summary["modelUsage"]["costState"], {"unpriced": 1})
        self.assertEqual(summary["contentObservations"], 0)


if __name__ == "__main__":
    unittest.main()
