import json
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLUGIN = ROOT / "plugins" / "behavioral-observability"
CONTRACT = ROOT / "config" / "observability" / "telemetry-contract.v1.json"


class BehavioralObservabilityPluginTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.package = json.loads((PLUGIN / "package.json").read_text(encoding="utf-8"))
        cls.manifest = json.loads(
            (PLUGIN / "openclaw.plugin.json").read_text(encoding="utf-8")
        )
        cls.source = (PLUGIN / "index.js").read_text(encoding="utf-8")
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))

    def source_array(self, name: str) -> list[str]:
        match = re.search(
            rf"const {name} = Object\.freeze\(\[(.*?)\]\);",
            self.source,
            re.DOTALL,
        )
        self.assertIsNotNone(match)
        return re.findall(r'"([a-z0-9_]+)"', match.group(1))

    def test_plugin_uses_public_entrypoint_and_pinned_otel_sdk(self) -> None:
        self.assertEqual(
            self.package["dependencies"],
            {
                "@opentelemetry/api": "1.9.1",
                "@opentelemetry/exporter-trace-otlp-proto": "0.221.0",
                "@opentelemetry/resources": "2.10.0",
                "@opentelemetry/sdk-trace-base": "2.10.0",
            },
        )
        self.assertEqual(self.package["openclaw"]["extensions"], ["./index.js"])
        self.assertIn('from "openclaw/plugin-sdk/plugin-entry"', self.source)
        self.assertIn('from "openclaw/plugin-sdk/tool-results"', self.source)
        self.assertNotIn('from "openclaw/plugin-sdk/diagnostic-runtime"', self.source)

    def test_plugin_owns_a_fail_open_otlp_exporter(self) -> None:
        self.assertIn("new BasicTracerProvider", self.source)
        self.assertIn("new OTLPTraceExporter", self.source)
        self.assertIn("new BatchSpanProcessor", self.source)
        self.assertIn("api.registerService(createTelemetryService())", self.source)
        self.assertIn("behavioralTracer.startSpan", self.source)
        self.assertNotIn("trace.getTracer", self.source)
        self.assertIn('normalized.endsWith("/v1/traces")', self.source)
        self.assertIn("RESOURCE_ATTRIBUTE_ALLOWLIST", self.source)

    def test_tool_contract_is_bounded_and_content_free(self) -> None:
        self.assertEqual(
            self.manifest["contracts"]["tools"],
            [
                "knowledge_decision",
                "knowledge_retrieval",
                "skill_execution",
                "workflow_phase",
                "wrapper_execution",
            ],
        )
        self.assertIn("additionalProperties: false", self.source)
        self.assertEqual(
            self.source_array("PHASES"),
            self.contract["signals"]["infuse.workflow.phase"]["attributes"]["phase"]["enum"],
        )
        self.assertEqual(
            self.source_array("OUTCOMES"),
            self.contract["signals"]["infuse.workflow.phase"]["attributes"]["outcome"]["enum"],
        )
        self.assertEqual(
            self.source_array("WORKFLOW_ATTRIBUTION_METHODS"),
            self.contract["signals"]["infuse.workflow.phase"]["attributes"]["attribution_method"]["enum"],
        )
        for forbidden in (
            '"rationale"',
            '"prompt"',
            '"path"',
            '"tool_input"',
            '"tool_output"',
            '"content"',
        ):
            self.assertNotIn(forbidden, self.source)
        self.assertEqual(self.source.count("(toolContext) => ({"), 5)
        for semantic_scope in (
            "workflow",
            "knowledge",
            "knowledge-decision",
            "wrapper",
            "skill",
        ):
            self.assertIn(
                f'isFirstToolHook("{semantic_scope}", {{ toolCallId }}, context)',
                self.source,
            )

    def test_spans_use_only_bounded_semantic_attributes(self) -> None:
        self.assertIn('const WORKFLOW_SPAN_NAME = "infuse.workflow.phase"', self.source)
        self.assertIn('const KNOWLEDGE_SPAN_NAME = "infuse.knowledge.retrieve"', self.source)
        self.assertIn('const KNOWLEDGE_DECISION_SPAN_NAME = "infuse.knowledge.decision"', self.source)
        self.assertIn('const WRAPPER_EXECUTION_SPAN_NAME = "infuse.wrapper.execution"', self.source)
        self.assertIn('const SKILL_EXECUTION_SPAN_NAME = "infuse.skill.execution"', self.source)
        self.assertIn('const TOOL_EXECUTION_SPAN_NAME = "infuse.tool.execution"', self.source)
        self.assertIn('const TURN_SPAN_NAME = "infuse.agent.turn"', self.source)
        self.assertIn('const MODEL_SPAN_NAME = "infuse.model.call"', self.source)
        self.assertIn(
            'const TRACE_INTEGRITY_SPAN_NAME = "infuse.trace.integrity"',
            self.source,
        )
        self.assertIn(
            'const TURN_ANOMALY_SPAN_NAME = "infuse.turn.anomaly"',
            self.source,
        )
        self.assertIn(
            'const LIFECYCLE_INTEGRITY_SPAN_NAME = "infuse.lifecycle.integrity"',
            self.source,
        )
        self.assertNotRegex(self.source, re.compile(r'"openclaw\.(workflow|knowledge|wrapper)'))
        for required in (
            "phase",
            "outcome",
            "sequence",
            "operation",
            "mode",
            "duration_ms",
            "result_count",
            "skill_name",
            "skill_revision",
            "wrapper",
            "retry_count",
            "error_code",
        ):
            self.assertIn(required, self.source)
        self.assertIn('{ matcher: [WORKFLOW_TOOL_NAME] }', self.source)
        self.assertIn('{ matcher: [KNOWLEDGE_TOOL_NAME] }', self.source)
        self.assertIn('{ matcher: [WRAPPER_EXECUTION_TOOL_NAME] }', self.source)
        self.assertIn('{ matcher: [SKILL_EXECUTION_TOOL_NAME] }', self.source)
        self.assertIn('api.on("agent_end"', self.source)
        self.assertIn("finishRunSpans(api, event, context)", self.source)
        self.assertIn("clearAuxiliaryRunState(event.runId ?? context.runId, {", self.source)

    def test_trace_correlation_owns_one_bounded_turn_tree_without_emitting_ids(self) -> None:
        self.assertIn("runSpanStore.begin", self.source)
        self.assertIn("turnState?.rootContext", self.source)
        self.assertIn('api.on("llm_input"', self.source)
        self.assertIn('api.on("model_call_started"', self.source)
        self.assertIn('api.on("model_call_ended"', self.source)
        self.assertIn('api.on("before_agent_run"', self.source)
        self.assertIn('api.on("before_agent_finalize", (event, context)', self.source)
        self.assertIn('api.on("after_tool_call"', self.source)
        self.assertIn("const parentContext = ROOT_CONTEXT", self.source)
        self.assertIn("trace.setSpan(parentContext, rootSpan)", self.source)
        self.assertIn("traceIntegrityAttributes(closureState)", self.source)
        self.assertIn("turnAnomalyTypes({", self.source)
        self.assertIn("emitOrphanIntegrityIssue(api)", self.source)
        self.assertIn('trace_link_state: "curated_canonical"', self.source)
        self.assertNotIn("diagnosticParentContext", self.source)
        self.assertNotIn('attributes: { runId', self.source)
        self.assertNotIn('attributes: { traceId', self.source)
        self.assertIn('"traffic.source": source ?? "unavailable"', self.source)
        self.assertIn("classifyTrafficSource({", self.source)
        self.assertIn("preferTrafficSource(current, preferTrafficSource(candidate, ingressSource))", self.source)
        self.assertIn("trafficSourceStore.rememberContext({ sessionKey, sessionId }, candidate)", self.source)
        self.assertIn('state.rootSpan?.setAttribute("traffic.source", resolved)', self.source)
        self.assertIn("pluginToolRunContext(toolContext)", self.source)
        self.assertIn("runContextStore.resolve({", self.source)
        self.assertIn("sessionKey: toolContext?.sessionKey", self.source)
        self.assertIn("sessionId: toolContext?.sessionId", self.source)
        self.assertEqual(self.source.count("resolveRunTrafficSource(context, context)"), 2)
        self.assertIn("runContextStore.delete(runId)", self.source)
        self.assertIn("modelAttemptRole(attemptIndex)", self.source)
        self.assertIn("classifyModelFailure(event)", self.source)
        self.assertIn('api.on("llm_output"', self.source)
        self.assertIn('"langfuse.observation.type": "generation"', self.source)
        self.assertIn('"langfuse.observation.usage_details"', self.source)
        self.assertNotIn("internalDiagnostics", self.source)
        self.assertIn("normalizedHookUsageDetails(event)", self.source)
        self.assertIn("state.modelUsage = usage", self.source)
        self.assertIn("finishLatestCompletedModelAttempt", self.source)

    def test_tool_execution_and_failures_use_bounded_hook_classification(self) -> None:
        self.assertIn("classifyToolHookEvent(event)", self.source)
        self.assertIn("canonicalToolName(event?.toolName)", self.source)
        self.assertIn("new ToolCallDeduplicator(MAX_RUN_STATE_ENTRIES)", self.source)
        self.assertIn('isFirstToolHook("tool", event, context)', self.source)
        for semantic_scope in ("workflow", "knowledge", "wrapper", "skill"):
            self.assertIn(
                f'isFirstToolHook("{semantic_scope}", event, context)',
                self.source,
            )
        self.assertIn("toolCallDeduplicator.clearRun(runId)", self.source)
        self.assertNotIn('attributes: { toolCallId', self.source)
        self.assertIn('classification.outcome === "error"', self.source)
        self.assertIn("classification.failureCategory", self.source)
        self.assertIn("classification.classificationSource", self.source)
        self.assertIn("recordToolAttempt(", self.source)
        self.assertIn("flushToolAttemptAggregatesForState(state)", self.source)
        self.assertIn("drainToolAttemptAggregates(state.toolAggregates)", self.source)
        self.assertIn('classification_source: "logical_retry_aggregate"', self.source)
        for attribute in (
            "tool_name",
            "failure_category",
            "classification_source",
            "outcome",
            "duration_ms",
        ):
            self.assertIn(attribute, self.source)

    def test_emission_is_fail_open(self) -> None:
        self.assertRegex(
            self.source,
            re.compile(r"function emitSpan\(.*?try \{.*?\} catch \(error\)", re.DOTALL),
        )
        self.assertIn("api.logger.warn", self.source)

    def test_knowledge_tool_delegates_to_the_canonical_client(self) -> None:
        self.assertIn('"knowledge-retrieval.mjs"', self.source)
        self.assertIn('const KNOWLEDGE_OPERATIONS = Object.freeze(["discover", "fetch"])', self.source)
        self.assertIn("MAX_KNOWLEDGE_OUTPUT_BYTES", self.source)
        self.assertIn("safeKnowledgeError", self.source)
        self.assertIn("parsed?.error_code", self.source)
        self.assertIn("isToolFailureCategory", self.source)
        self.assertIn(
            'objective: { type: "string", minLength: 2, maxLength: 2000 }',
            self.source,
        )
        self.assertIn(
            'reference: { type: "string", minLength: 64, maxLength: 4096 }',
            self.source,
        )
        self.assertIn('limit: { type: "integer", minimum: 1, maximum: 20 }', self.source)
        self.assertIn('["repositories", "types", "statuses", "owners", "tags"]', self.source)
        self.assertIn("return jsonResult({ ...result, ok: true })", self.source)
        self.assertNotIn("Authorization", self.source)

    def test_wrapper_marker_accepts_only_safe_ids_outcomes_and_error_codes(self) -> None:
        self.assertIn("WRAPPER_ID_RE", self.source)
        self.assertIn("maxLength: 64", self.source)
        self.assertEqual(
            self.source_array("WRAPPER_ERROR_CODES"),
            self.contract["signals"]["infuse.wrapper.execution"]["attributes"]["error_code"]["enum"],
        )
        self.assertEqual(self.source_array("WRAPPER_PHASES"), ["start", "finish"])
        self.assertEqual(
            self.source_array("WRAPPER_OUTCOMES"),
            ["started", "success", "error", "skipped"],
        )
        self.assertIn('const phase = requestedPhase || "finish"', self.source)
        self.assertIn('const lifecycleMethod = requestedPhase ? "explicit_pair" : "legacy_terminal"', self.source)
        self.assertIn("canonicalLifecycleId(wrapperInput)", self.source)
        self.assertIn("canonicalLifecycleId(operationInput)", self.source)
        self.assertIn('evidenceMethod: "wrapper_outcome"', self.source)
        self.assertIn('isFirstToolHook("wrapper", { toolCallId }, context)', self.source)
        self.assertIn('(outcome === "error" && !WRAPPER_ERROR_CODE_SET.has(errorCode))', self.source)
        self.assertIn('(outcome !== "error" && errorCode !== "")', self.source)

    def test_lifecycle_integrity_is_turn_scoped_and_fail_open(self) -> None:
        self.assertIn("recordLifecycle(", self.source)
        self.assertIn("drainIncompleteLifecycles(state)", self.source)
        self.assertIn("emitIncompleteLifecycleIssues(state)", self.source)
        self.assertIn('lifecycleType: "wrapper"', self.source)
        self.assertIn('lifecycleType: "skill"', self.source)
        self.assertIn('lifecycleState === "unmatched_finish"', self.source)
        self.assertNotIn("incomplete_count: issue.incompleteCount ?? 0,\n        content", self.source)

    def test_skill_marker_is_explicit_bounded_and_never_claims_native(self) -> None:
        signal = self.contract["signals"]["infuse.skill.execution"]
        self.assertEqual(
            self.source_array("SKILL_PHASES"),
            signal["attributes"]["phase"]["enum"],
        )
        self.assertEqual(
            self.source_array("SKILL_OUTCOMES"),
            signal["attributes"]["outcome"]["enum"],
        )
        self.assertEqual(
            self.source_array("SKILL_ATTRIBUTION_METHODS"),
            signal["attributes"]["attribution_method"]["enum"],
        )
        self.assertEqual(
            self.source_array("SKILL_MARKER_ATTRIBUTION_METHODS"),
            ["explicit_wrapper", "declared_marker"],
        )
        self.assertIn('phase === "start" && outcome === "started"', self.source)
        self.assertIn('phase === "finish" && outcome !== "started"', self.source)
        self.assertIn("!SKILL_MARKER_ATTRIBUTION_METHOD_SET.has(attributionMethod)", self.source)
        self.assertIn("Never infer use or include task content", self.source)

    def test_high_value_attribution_tools_stay_directly_visible_to_codex(self) -> None:
        self.assertEqual(self.source.count('catalogMode: "direct-only"'), 4)
        for tool_name in (
            "KNOWLEDGE_TOOL_NAME",
            "KNOWLEDGE_DECISION_TOOL_NAME",
            "WRAPPER_EXECUTION_TOOL_NAME",
            "SKILL_EXECUTION_TOOL_NAME",
        ):
            self.assertRegex(
                self.source,
                rf"name: {tool_name},\n\s+catalogMode: \"direct-only\"",
            )


if __name__ == "__main__":
    unittest.main()
