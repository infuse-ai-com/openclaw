"""Keep the qualified Studio payload bound to the exact 11.3 host."""

import json
import importlib.util
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
PIN_PATH = ROOT / "config/qualification/studio-tool-inventory-2026.11.3.json"
PIN = json.loads(PIN_PATH.read_text(encoding="utf-8"))
VERIFIER = ROOT / "scripts/verify-studio-plugin-package.py"


class StudioToolInventoryPinTests(unittest.TestCase):
    def test_pin_matches_taskfile_and_image_inputs(self) -> None:
        taskfile = (ROOT / "Taskfile.yml").read_text(encoding="utf-8")
        for key, value in (
            ("OPENCLAW_VERSION", PIN["hostVersion"]),
            ("OPENCLAW_SOURCE_SHA", PIN["hostCommit"]),
            ("OPENCLAW_PACKAGE_SHA256", PIN["hostPackageSha256"]),
        ):
            self.assertIn(f"""{key}: '{{{{default "{value}" .{key}}}}}'""", taskfile)
        self.assertEqual(len(PIN["plugin"]["sources"]), PIN["plugin"]["fileCount"])
        # The outbound-only producer no longer ships the central authority worker
        # or SQL migrations; pin the new package shape as well as every hash.
        self.assertEqual(PIN["plugin"]["fileCount"], 17)
        self.assertIn("dist/bridge-journal-worker.mjs", PIN["plugin"]["sources"])
        self.assertIn("dist/index.mjs", PIN["plugin"]["sources"])
        self.assertNotIn("dist/mission-worker.mjs", PIN["plugin"]["sources"])
        self.assertFalse(any(name.endswith(".sql") for name in PIN["plugin"]["sources"]))
        image = (ROOT / "images/openclaw-agent/Dockerfile").read_text(encoding="utf-8")
        self.assertNotIn("studio-plugin-overrides/", image)
        self.assertNotIn("ARG STUDIO_PLUGIN_IMAGE=", image)
        self.assertIn("COPY images/openclaw-agent/studio-plugin/ /opt/openclaw-plugins/infuse-studio/", image)
        self.assertEqual(
            PIN["plugin"]["producer"]["sourceCommit"],
            "cd460ed8878a5617d9da3913a0493a98c8e29f46",
        )
        self.assertFalse(PIN["plugin"]["producer"]["build"]["crossArchitectureDeterministic"])
        self.assertIn("verify-studio-plugin-package.py", image)
        self.assertNotIn("patch-studio-tool-inventory", image)

    def test_vendored_payload_matches_the_closed_inventory(self) -> None:
        result = subprocess.run(
            [
                "python3",
                "-I",
                str(VERIFIER),
                str(ROOT / "images/openclaw-agent/studio-plugin"),
                str(PIN_PATH),
            ],
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_verifier_rejects_incomplete_payload(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            result = subprocess.run(
                ["python3", "-I", str(VERIFIER), directory, str(PIN_PATH)],
                capture_output=True,
                text=True,
            )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("inventory mismatch", result.stderr)


if __name__ == "__main__":
    unittest.main()


class StudioRuntimeInventoryTests(unittest.TestCase):
    def test_native_whiteboard_tools_are_required_only_for_production(self):
        spec = importlib.util.spec_from_file_location('studio_runtime_inventory', ROOT / 'scripts/verify-studio-runtime-inventory.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        value = {'plugin': {'status': 'loaded', 'toolNames': sorted(module.BASE_TOOLS)}, 'install': {'source': 'path'}}
        self.assertEqual(module.verify(value, 'local-mac')['verifiedTools'], 5)
        with self.assertRaises(ValueError): module.verify(value, 'production')
        value['plugin']['toolNames'] = sorted(module.BASE_TOOLS | module.WHITEBOARD_TOOLS)
        self.assertEqual(module.verify(value, 'production')['verifiedTools'], 14)
        with self.assertRaises(ValueError): module.verify(value, 'local-mac')
        value['plugin']['toolNames'].append('unreviewed_tool')
        with self.assertRaises(ValueError): module.verify(value, 'production')
