from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]


class SecurityScanPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ci = (ROOT / '.gitlab-ci.yml').read_text()

    def job(self, name):
        match = re.search(rf'(?ms)^{re.escape(name)}:\n(.*?)(?=^[^ \n#]|\Z)', self.ci)
        self.assertIsNotNone(match, name)
        return match.group(1)

    def test_both_full_image_scans_remain_visible_allowed_failures(self):
        components = re.findall(r'(?ms)^  - component:.*?(?=^  - component:|^[^ \n#]|\Z)', self.ci)
        scans = [item for item in components if '/container-image-scan@' in item]
        self.assertEqual(len(scans), 2)
        for scan in scans:
            self.assertIn('allow-failure: true', scan)
            self.assertIn('ignore-unfixed: false', scan)
        for name in ('scan_openclaw_image', 'scan_candidate_openclaw_image'):
            # An override must not quietly make the shared component blocking.
            self.assertNotIn('allow_failure: false', self.job(name))

    def test_scan_errors_or_missing_reports_cannot_block_deploy(self):
        canary = self.job('deploy_openclaw_tinus_canary')
        fleet = self.job('deploy_openclaw_swarm')
        canary_needs = re.search(r'(?ms)^  needs:\n(.*?)(?=^  [a-z_]+:|\Z)', canary).group(1)
        fleet_needs = re.search(r'(?ms)^  needs:\n(.*?)(?=^  [a-z_]+:|\Z)', fleet).group(1)
        self.assertEqual(re.findall(r'job: (\S+)', canary_needs), ['verify_approved_openclaw_image'])
        self.assertEqual(
            re.findall(r'job: (\S+)', fleet_needs),
            ['verify_approved_openclaw_image', 'deploy_openclaw_tinus_canary'],
        )
        self.assertIn('artifacts: true', canary_needs)
        self.assertIn('artifacts: true', fleet_needs)
        self.assertNotIn('openclaw_image_exception_guard:', self.ci)
        rollout = (ROOT / 'scripts/gitlab-rollout-openclaw.sh').read_text()
        for text in ('trivy-image.json', 'image-risk-exception.json', 'verify-openclaw-image-risk-exception.py'):
            self.assertNotIn(text, canary + fleet + rollout)

    def test_image_identity_and_manual_release_remain_mandatory(self):
        verify = self.job('verify_approved_openclaw_image')
        self.assertNotIn('allow_failure: true', verify)
        self.assertIn('test "$observed_digest" = "$image_digest"', verify)
        self.assertIn('test "$image_reference" = "$expected_reference"', verify)
        for name in ('deploy_openclaw_tinus_canary', 'deploy_openclaw_swarm'):
            deploy = self.job(name)
            self.assertIn('when: manual\n      allow_failure: false', deploy)
            self.assertIn('CI_COMMIT_REF_PROTECTED == "true"', deploy)
            self.assertIn('resource_group: openclaw-swarm-production', deploy)
            self.assertRegex(deploy, r'environment:\n(?:    #.*\n)*    name: production\n')

    def test_rollout_reconciles_the_reviewed_plugin_archives(self):
        rollout = (ROOT / 'scripts/gitlab-rollout-openclaw.sh').read_text()
        self.assertIn(
            "behavioral_observability_archive='/opt/openclaw-plugin-archives/behavioral-observability.tgz'",
            rollout,
        )
        self.assertIn(
            "studio_archive='/opt/openclaw-plugin-archives/infuse-studio.tgz'",
            rollout,
        )
        self.assertIn('required_plugin_archives_for()', rollout)
        self.assertIn('name:"OPENCLAW_REQUIRED_PLUGINS",value:$required_plugins', rollout)
        self.assertIn(
            'name:"OPENCLAW_CAPABILITY_CONSENT_PLUGINS",value:$required_plugins',
            rollout,
        )
        self.assertIn('live_plugin_contract', rollout)
