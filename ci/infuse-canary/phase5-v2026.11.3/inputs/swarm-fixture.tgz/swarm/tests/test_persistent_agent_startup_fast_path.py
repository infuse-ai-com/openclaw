from __future__ import annotations

from pathlib import Path
import re
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[1]
AGENTS = (
    "agent-developer",
    "agent-designer",
    "agent-infra",
    "agent-intake",
    "agent-coordinator",
)


class PersistentAgentStartupFastPathTests(unittest.TestCase):
    def test_openclaw_2026_11_3_runs_bounded_schema_v27_repair(self) -> None:
        deployment = (ROOT / "k8s/components/persistent-agent/deployment.yaml").read_text()
        boot = (ROOT / "scripts/boot-agent-developer-canary.sh").read_text()
        migration = (
            ROOT / "scripts/migrate-openclaw-agent-schema-v27.mjs"
        ).read_text()

        self.assertRegex(
            deployment,
            re.compile(
                r"name: OPENCLAW_DOCTOR_REPAIR_MODE\n\s+value: automatic",
                re.MULTILINE,
            ),
        )
        self.assertIn("doctor-2026.11.3-agent-schema-v27-v1", boot)
        self.assertIn("openclaw-agent-migrate-schema-v27", boot)
        self.assertIn(".plugins.entries.acpx.enabled = true", boot)
        self.assertIn(
            '["acpx", "codex", "mattermost", "openai", "memory-core"]',
            boot,
        )
        self.assertIn('database.prepare("PRAGMA user_version").get()', boot)
        self.assertIn(
            'retry_check "agent database schema v27" verify_agent_database_schema_v27',
            boot,
        )
        self.assertIn(
            'if ! openclaw-agent-ensure-plugins "$profile"; then',
            boot,
        )
        self.assertIn(
            "runtime plugin convergence remained nonzero after state migration; "
            "continuing to exact runtime admission checks",
            boot,
        )
        self.assertLess(
            boot.index('if ! openclaw-agent-ensure-plugins "$profile"; then'),
            boot.index(
                'retry_check "Codex runtime verification after state migration"'
            ),
        )
        self.assertLess(
            boot.index('retry_check "agent database schema v27"'),
            boot.index('touch \\\n  "$auth_migration_marker"'),
        )
        self.assertIn('const EXPECTED_RUNTIME_VERSION = "2026.11.3"', migration)
        self.assertIn("const EXPECTED_SCHEMA_VERSION = 27", migration)
        self.assertIn("withAgentDatabaseMaintenanceLease", migration)
        self.assertIn("migrateOpenClawAgentDatabaseForMaintenance", migration)

    def test_workspace_ownership_repair_is_guarded_by_root_ownership(self) -> None:
        source = (ROOT / "k8s/components/persistent-agent/deployment.yaml").read_text()
        self.assertIn("fsGroupChangePolicy: OnRootMismatch", source)
        self.assertIn("stat -c '%u:%g' /workspace", source)
        self.assertIn('!= "10001:10001"', source)
        self.assertIn("chown -R 10001:10001 /workspace", source)
        self.assertNotIn("chown -R 10001:10001 /workspace && chmod", source)

    def test_all_agents_disable_artificial_startup_delay(self) -> None:
        for agent in AGENTS:
            with self.subTest(agent=agent):
                source = (ROOT / "k8s/agents" / agent / "deployment.yaml").read_text()
                self.assertRegex(
                    source,
                    re.compile(
                        r"name: OPENCLAW_STARTUP_DELAY_SECONDS\n\s+value: [\"']?0[\"']?",
                        re.MULTILINE,
                    ),
                )

    def test_rendered_agents_keep_the_startup_fast_path(self) -> None:
        for agent in AGENTS:
            with self.subTest(agent=agent):
                rendered = subprocess.run(
                    ["kubectl", "kustomize", str(ROOT / "k8s/agents" / agent)],
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout
                self.assertIn("fsGroupChangePolicy: OnRootMismatch", rendered)
                self.assertIn("stat -c '%u:%g' /workspace", rendered)
                self.assertRegex(
                    rendered,
                    re.compile(
                        r"name: OPENCLAW_STARTUP_DELAY_SECONDS\n\s+value: [\"']?0[\"']?",
                        re.MULTILINE,
                    ),
                )


if __name__ == "__main__":
    unittest.main()
