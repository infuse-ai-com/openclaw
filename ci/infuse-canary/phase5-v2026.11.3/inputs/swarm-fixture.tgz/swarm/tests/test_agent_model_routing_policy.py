import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
POLICY_PATH = ROOT / "config" / "agent-model-policies.json"
SCRIPT_PATH = ROOT / "scripts" / "verify-agent-model-policies.py"
SPEC = importlib.util.spec_from_file_location("agent_model_policy", SCRIPT_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class AgentModelRoutingPolicyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.policy = json.loads(POLICY_PATH.read_text(encoding="utf-8"))

    def test_every_agent_has_an_explicit_capacity_policy(self) -> None:
        self.assertEqual(self.policy["schemaVersion"], 2)
        self.assertEqual(len(self.policy["agents"]), 5)
        for agent_id, policy in self.policy["agents"].items():
            self.assertEqual(MODULE.validate_policy(agent_id, policy, self.policy["defaults"]), [])

    def test_availability_roles_have_one_bounded_alternate(self) -> None:
        for agent_id in ("agent-coordinator", "agent-developer"):
            policy = self.policy["agents"][agent_id]
            self.assertEqual(policy["capacityFailurePolicy"], "single_approved_fallback")
            self.assertEqual(len(policy["fallbackModels"]), 1)
            self.assertNotEqual(policy["model"], policy["fallbackModels"][0])

    def test_other_roles_fail_closed_instead_of_silently_rerouting(self) -> None:
        for agent_id in ("agent-designer", "agent-infra", "agent-intake"):
            policy = self.policy["agents"][agent_id]
            self.assertEqual(policy["capacityFailurePolicy"], "fail_closed")
            self.assertEqual(policy["fallbackModels"], [])


if __name__ == "__main__":
    unittest.main()
