from __future__ import annotations

import importlib.util
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "persistent_agent_impact",
    ROOT / "scripts" / "classify-persistent-agent-impact.py",
)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class PersistentAgentImpactTests(unittest.TestCase):
    def test_registry_reader_activation_preserves_agents_but_mixed_runtime_changes_do_not(self):
        paths = ["scripts/provision_artifact_registry_credentials.py",
                 "config/artifact-registry-runtime.v1.json",
                 "k8s/platform/artifact-registry/networkpolicy.yaml"]
        result = MODULE.classify(paths)
        self.assertEqual(result["scope"], "platform")
        self.assertEqual(result["preserveDeployments"], list(MODULE.PERSISTENT_AGENTS))
        result = MODULE.classify(paths + ["scripts/agent-task-workspace.py"])
        self.assertEqual(result["preserveDeployments"], [])
        self.assertEqual(result["scope"], "full")

    def test_image_release_preserves_agents_but_producer_overlay_does_not(self):
        paths = ["k8s/platform/artifact-image-scanner/scanner.yaml", "k8s/platform/artifact-registry-release/kustomization.yaml", "k8s/platform/artifact-registry/deployment.yaml"]
        self.assertEqual(MODULE.classify(paths)["scope"], "platform")
        self.assertEqual(MODULE.classify(paths + ["k8s/platform/artifact-registry/producers/deployments.yaml"])["scope"], "full")

    def test_agent_component_change_requires_full_rollout(self) -> None:
        result = MODULE.classify(["k8s/components/persistent-agent/deployment.yaml"])
        self.assertEqual("full", result["scope"])

    def test_collector_only_change_preserves_all_persistent_agents(self) -> None:
        result = MODULE.classify(
            [
                "k8s/overlays/infuseai/otel-collector.yaml",
                "scripts/sync_agent_observability_secret.py",
                "scripts/audit-agent-observability-live.py",
                "tests/test_agent_observability_runtime_contract.py",
                "docs/AGENT_OBSERVABILITY.md",
            ]
        )
        self.assertEqual("platform", result["scope"])
        self.assertEqual(list(MODULE.PERSISTENT_AGENTS), result["preserveDeployments"])

    def test_missing_changed_paths_fails_closed_to_full_rollout(self) -> None:
        result = MODULE.classify([])
        self.assertEqual("full", result["scope"])
        self.assertEqual("changed_paths_unavailable", result["reason"])


if __name__ == "__main__":
    unittest.main()
