import importlib.util
import io
import json
import unittest
from unittest import mock
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "sync_agent_observability_secret.py"
SPEC = importlib.util.spec_from_file_location("observability_secret_sync", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)


class AgentObservabilitySecretSyncTest(unittest.TestCase):
    def test_project_keys_build_the_exact_one_key_secret_contract(self) -> None:
        public_key, secret_key = MODULE.validate_project_keys(
            "pk-lf-test-public", "sk-lf-test-secret"
        )
        manifest = MODULE.build_secret_manifest(public_key, secret_key)
        self.assertEqual(manifest["metadata"], {"name": MODULE.SECRET_NAME, "namespace": MODULE.NAMESPACE})
        self.assertEqual(set(manifest["stringData"]), {MODULE.SECRET_KEY})
        self.assertTrue(manifest["stringData"][MODULE.SECRET_KEY].startswith("Basic "))

    def test_project_keys_reject_wrong_prefixes(self) -> None:
        for public_key, secret_key in (
            ("wrong", "sk-lf-test-secret"),
            ("pk-lf-test-public", "wrong"),
            ("", ""),
        ):
            with self.subTest(public_key=public_key, secret_key=secret_key):
                with self.assertRaises(ValueError):
                    MODULE.validate_project_keys(public_key, secret_key)

    def test_project_scope_accepts_only_the_exact_agent_project(self) -> None:
        payload = {
            "data": [
                {"id": MODULE.EXPECTED_PROJECT_ID, "name": MODULE.EXPECTED_PROJECT_NAME}
            ]
        }
        response = mock.MagicMock()
        response.__enter__.return_value = io.BytesIO(json.dumps(payload).encode())
        with mock.patch.object(MODULE.urllib.request, "urlopen", return_value=response):
            observed = MODULE.verify_project_scope("pk-lf-test-public", "sk-lf-test-secret")
        self.assertEqual(observed, (MODULE.EXPECTED_PROJECT_ID, MODULE.EXPECTED_PROJECT_NAME))

    def test_project_scope_rejects_a_valid_key_for_another_project(self) -> None:
        payload = {"data": [{"id": "old-project", "name": "mdgpt"}]}
        response = mock.MagicMock()
        response.__enter__.return_value = io.BytesIO(json.dumps(payload).encode())
        with mock.patch.object(MODULE.urllib.request, "urlopen", return_value=response):
            with self.assertRaisesRegex(ValueError, "approved agent project"):
                MODULE.verify_project_scope("pk-lf-test-public", "sk-lf-test-secret")


if __name__ == "__main__":
    unittest.main()
