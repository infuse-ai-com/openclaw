from __future__ import annotations

import copy
from pathlib import Path
import unittest

import importlib.util


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "select-agent-rollout-manifests.py"
SPEC = importlib.util.spec_from_file_location("select_agent_rollout_manifests", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
SELECTOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SELECTOR)


def deployment(name: str, replicas: int = 1) -> dict:
    return {"apiVersion": "apps/v1", "kind": "Deployment", "metadata": {"name": name}, "spec": {"replicas": replicas}}


class SelectAgentRolloutManifestsTests(unittest.TestCase):
    def setUp(self) -> None:
        self.documents = [
            {"apiVersion": "v1", "kind": "Service", "metadata": {"name": "agent-developer"}},
            deployment("agent-developer"),
            deployment("agent-coordinator"),
            deployment("shared-platform"),
        ]
        self.agents = {"agent-developer", "agent-coordinator"}

    def test_shared_mode_excludes_only_persistent_agent_deployments(self) -> None:
        selected = SELECTOR.select_documents(
            copy.deepcopy(self.documents), mode="shared", agents=self.agents, deployment=None
        )
        identities = [(value["kind"], value["metadata"]["name"]) for value in selected]
        self.assertEqual(
            [("Service", "agent-developer"), ("Deployment", "shared-platform")],
            identities,
        )

    def test_deployment_mode_emits_one_target_held_at_zero(self) -> None:
        selected = SELECTOR.select_documents(
            copy.deepcopy(self.documents),
            mode="deployment",
            agents=self.agents,
            deployment="agent-developer",
        )
        self.assertEqual(1, len(selected))
        self.assertEqual("agent-developer", selected[0]["metadata"]["name"])
        self.assertEqual(0, selected[0]["spec"]["replicas"])

    def test_deployment_mode_rejects_unknown_or_missing_targets(self) -> None:
        with self.assertRaisesRegex(ValueError, "declared persistent agent"):
            SELECTOR.select_documents(
                copy.deepcopy(self.documents),
                mode="deployment",
                agents=self.agents,
                deployment="unknown",
            )
        with self.assertRaisesRegex(ValueError, "expected exactly one"):
            SELECTOR.select_documents(
                [self.documents[0]],
                mode="deployment",
                agents=self.agents,
                deployment="agent-developer",
            )


if __name__ == "__main__":
    unittest.main()
