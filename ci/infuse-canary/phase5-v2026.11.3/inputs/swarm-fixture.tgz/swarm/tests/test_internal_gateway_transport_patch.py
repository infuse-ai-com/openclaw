from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/internal-gateway-transport-patch.py"
SPEC = importlib.util.spec_from_file_location("internal_gateway_transport_patch", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
AGENT = "agent-developer"
IMAGE = "registry.example.invalid/agent@sha256:" + "a" * 64
UID, RV = "selected-agent-uid", "456"
PRIVATE = "synthetic-private-value-never-printed"
CODE_NAME = "openclaw-gateway-tls-tunnel-abc123def4"


def config_env(deployment):
    return deployment["spec"]["template"]["spec"]["containers"][1]["env"][2]


def edit_config(deployment, edit):
    env = config_env(deployment)
    config = json.loads(env["value"])
    edit(config)
    env["value"] = json.dumps(config)


def fixture(agent=AGENT):
    reviewed = MODULE.identity.reviewed_config(agent)
    config = copy.deepcopy(reviewed)
    config["gateway"]["auth"]["identityScopes"]["another@example.invalid"] = ["operator.read"]
    config["privateLiveSettings"] = {"retained": PRIVATE, "nested": [False, None, "é"]}
    live = {"apiVersion": "apps/v1", "kind": "Deployment", "metadata": {
        "name": agent, "namespace": "agents-swarm", "uid": UID, "resourceVersion": RV,
        "annotations": {"unrelated-live-owner": "preserved"}},
        "spec": {"replicas": 1, "strategy": {"type": "Recreate"}, "selector": {"matchLabels": {"app.kubernetes.io/name": agent}},
            "template": {"metadata": {"labels": {"app.kubernetes.io/name": agent}, "annotations": {"live-revision": "preserved"}},
                "spec": {"securityContext": {"fsGroup": 10001, "runAsUser": 10001}, "serviceAccountName": "unchanged-account",
                    "terminationGracePeriodSeconds": 420, "nodeSelector": {"live-workload-node": "preserved"},
                    "initContainers": [{"name": "existing-init", "image": "unchanged-init"}],
                    "containers": [{"name": "existing-sidecar", "image": "unchanged", "ports": [{"containerPort": 9100}]},
                        {"name": "agent", "image": IMAGE, "ports": [{"containerPort": 18791}],
                         "env": [{"name": "AGENT_ID", "value": agent}, {"name": "PRIVATE_ENV", "value": PRIVATE},
                                 {"name": "OPENCLAW_CONFIG_JSON", "value": json.dumps(config, indent=2, ensure_ascii=False)}],
                         "resources": {"limits": {"memory": "9Gi"}}, "lifecycle": {"preStop": {"exec": {"command": ["unchanged-drain"]}}},
                         "readinessProbe": {"httpGet": {"path": "/health", "port": 18791}},
                         "volumeMounts": [{"name": "workspace", "mountPath": "/workspace"}]}],
                    "volumes": [{"name": "workspace", "persistentVolumeClaim": {"claimName": "unchanged-pvc"}}]}}}}
    rendered = copy.deepcopy(live)
    rendered["metadata"].pop("uid")
    rendered["metadata"].pop("resourceVersion")
    rendered["spec"]["replicas"] = 9
    pod = rendered["spec"]["template"]["spec"]
    pod["serviceAccountName"] = "different-render-account"
    pod["containers"][1]["resources"] = {"limits": {"memory": "8Gi"}}
    config_env(rendered)["value"] = json.dumps(reviewed)
    edit_config(rendered, lambda value: value["gateway"]["trustedProxies"].append("127.0.0.1"))
    edit_config(rendered, lambda value: value["gateway"]["auth"]["trustedProxy"].update(allowLoopback=True))
    sidecar = MODULE.transport.sidecar(agent)
    sidecar["image"] = IMAGE
    pod["containers"].append(sidecar)
    pod["volumes"].extend([
        {"name": "gateway-tls-code", "configMap": {"name": CODE_NAME, "defaultMode": 292}},
        {"name": "gateway-tls-identity", "secret": {"secretName": f"{agent}-dashboard-internal-tls", "defaultMode": 288,
            "items": [{"key": key, "path": key} for key in ("tls.crt", "tls.key", "client-ca.crt")]}},
        {"name": "gateway-tls-no-api-token", "emptyDir": {"medium": "Memory", "sizeLimit": "1Mi"}},
    ])
    configmap = {"apiVersion": "v1", "kind": "ConfigMap", "metadata": {"name": CODE_NAME, "namespace": "agents-swarm"},
        "data": {"tunnel.mjs": (ROOT / "k8s/components/gateway-internal-tls/tunnel.mjs").read_text()}}
    return live, {"apiVersion": "v1", "kind": "List", "items": [rendered, configmap]}


def build(live, rendered, **overrides):
    return MODULE.build_patch(live, rendered, **{"agent_id": AGENT, "expected_image": IMAGE,
        "expected_uid": UID, "expected_resource_version": RV, **overrides})


def apply(document, patch):
    result = copy.deepcopy(document)
    for operation in patch:
        parts = operation["path"].lstrip("/").split("/")
        parent = result
        for part in parts[:-1]:
            parent = parent[int(part)] if isinstance(parent, list) else parent[part]
        if operation["op"] == "add" and parts[-1] == "-":
            parent.append(copy.deepcopy(operation["value"]))
            continue
        key = int(parts[-1]) if isinstance(parent, list) else parts[-1]
        if operation["op"] == "test":
            if parent[key] != operation["value"]:
                raise ValueError("guarded patch rejected")
        elif operation["op"] == "replace":
            parent[key] = operation["value"]
        else:
            raise AssertionError("unreviewed patch operation")
    return result


class InternalGatewayTransportPatchTest(unittest.TestCase):
    def test_all_five_only_append_transport_and_preserve_every_unrelated_live_field(self):
        for agent in sorted(MODULE.identity.AGENTS):
            with self.subTest(agent=agent):
                live, rendered = fixture(agent)
                before, render_before = copy.deepcopy(live), copy.deepcopy(rendered)
                patch = build(live, rendered, agent_id=agent)
                self.assertEqual(live, before)
                self.assertEqual(rendered, render_before)
                writes = [item for item in patch if item["op"] != "test"]
                self.assertEqual([item["op"] for item in writes], ["replace", "add", "add", "add", "add"])
                after = apply(live, patch)
                updated = json.loads(config_env(after)["value"])
                self.assertEqual(updated["gateway"]["trustedProxies"], ["10.1.42.208", "127.0.0.1"])
                self.assertIs(updated["gateway"]["auth"]["trustedProxy"].pop("allowLoopback"), True)
                updated["gateway"]["trustedProxies"].remove("127.0.0.1")
                self.assertEqual(updated, json.loads(config_env(before)["value"]))
                config_env(after)["value"] = config_env(before)["value"]
                after["spec"]["template"]["spec"]["containers"].pop()
                del after["spec"]["template"]["spec"]["volumes"][-3:]
                self.assertEqual(after, before)

    def test_completed_transport_is_idempotent_with_only_kubernetes_defaults(self):
        live, rendered = fixture()
        complete = apply(live, build(live, rendered))
        sidecar = complete["spec"]["template"]["spec"]["containers"][-1]
        sidecar.update(terminationMessagePath="/dev/termination-log", terminationMessagePolicy="File", stdin=False)
        for key in ("readinessProbe", "livenessProbe"):
            sidecar[key].update(timeoutSeconds=1, failureThreshold=3, successThreshold=1)
        self.assertEqual(build(complete, rendered), [])
        edit_config(complete, lambda config: config["privateLiveSettings"].update(newSetting="preserved"))
        self.assertEqual(build(complete, rendered), [])
        sidecar["readinessProbe"]["timeoutSeconds"] = 7
        with self.assertRaises(MODULE.PatchError):
            build(complete, rendered)

    def test_partial_state_and_installed_drift_are_refused(self):
        live, rendered = fixture()
        complete = apply(live, build(live, rendered))
        for change in ("sidecar-only", "volume-only", "trust-only", "missing-volume", "image", "secret", "command", "extra-mount", "code-hash"):
            with self.subTest(change=change):
                candidate = copy.deepcopy(live if change.endswith("only") else complete)
                pod = candidate["spec"]["template"]["spec"]
                if change == "sidecar-only": pod["containers"].append(copy.deepcopy(complete["spec"]["template"]["spec"]["containers"][-1]))
                elif change == "volume-only": pod["volumes"].append(copy.deepcopy(complete["spec"]["template"]["spec"]["volumes"][-1]))
                elif change == "trust-only": config_env(candidate)["value"] = config_env(complete)["value"]
                elif change == "missing-volume": pod["volumes"].pop()
                elif change == "image": pod["containers"][-1]["image"] = "unreviewed"
                elif change == "secret": pod["volumes"][-2]["secret"]["secretName"] = "another-identity"
                elif change == "command": pod["containers"][-1]["command"].append("--unreviewed")
                elif change == "extra-mount": pod["containers"][-1]["volumeMounts"].append({"name": "workspace", "mountPath": "/workspace"})
                else: pod["volumes"][-3]["configMap"]["name"] = "openclaw-gateway-tls-tunnel-other12345"
                with self.assertRaises(MODULE.PatchError): build(candidate, rendered)

    def test_live_identity_image_trust_and_pod_conflicts_fail_closed(self):
        mutations = [lambda item: item["metadata"].update(uid="replacement"), lambda item: item["metadata"].update(resourceVersion="457"),
            lambda item: item["metadata"].update(namespace="other"), lambda item: item["metadata"].update(name="agent-infra"),
            lambda item: item["spec"]["template"]["spec"]["containers"][1].update(image=IMAGE.replace("a" * 64, "b" * 64)),
            lambda item: item["spec"]["template"]["spec"].update(hostNetwork=True),
            lambda item: item["spec"]["template"]["spec"]["securityContext"].update(fsGroup=0),
            lambda item: item["spec"]["template"]["spec"]["containers"][0]["ports"][0].update(containerPort=8443),
            lambda item: edit_config(item, lambda config: config["gateway"]["auth"].pop("identityScopes")),
            lambda item: edit_config(item, lambda config: config["gateway"]["auth"]["trustedProxy"].update(allowLoopback=True)),
            lambda item: edit_config(item, lambda config: config["gateway"].update(trustedProxies=["10.0.0.0/8"])),
            lambda item: edit_config(item, lambda config: config["gateway"]["auth"].update(password="changed"))]
        for mutate in mutations:
            live, rendered = fixture()
            mutate(live)
            with self.assertRaises(MODULE.PatchError): build(live, rendered)
        live, rendered = fixture()
        for overrides in ({"expected_image": "agent:latest"}, {"expected_uid": ""}, {"expected_resource_version": ""}, {"expected_resource_version": "0"}):
            with self.assertRaises(MODULE.PatchError): build(live, rendered, **overrides)

    def test_rendered_transport_and_code_must_match_the_reviewed_owner(self):
        for change in ("main-image", "sidecar-image", "missing-sidecar", "wrong-secret", "missing-code", "different-code", "unhashed-code", "duplicate-deployment"):
            live, rendered = fixture()
            pod = rendered["items"][0]["spec"]["template"]["spec"]
            if change == "main-image": pod["containers"][1]["image"] = "other"
            elif change == "sidecar-image": pod["containers"][-1]["image"] = "other"
            elif change == "missing-sidecar": pod["containers"].pop()
            elif change == "wrong-secret": pod["volumes"][-2]["secret"]["secretName"] = "other"
            elif change == "missing-code": rendered["items"].pop()
            elif change == "different-code": rendered["items"][-1]["data"]["tunnel.mjs"] += "\n// unreviewed code\n"
            elif change == "unhashed-code": pod["volumes"][-3]["configMap"]["name"] = "openclaw-gateway-tls-tunnel"
            else: rendered["items"].append(copy.deepcopy(rendered["items"][0]))
            with self.subTest(change=change), self.assertRaises(MODULE.PatchError): build(live, rendered)

    def test_json_patch_cas_rejects_recreated_changed_or_reordered_workload(self):
        live, rendered = fixture()
        patch = build(live, rendered)
        for change in ("version", "uid", "config", "container"):
            changed = copy.deepcopy(live)
            if change == "version": changed["metadata"]["resourceVersion"] = "457"
            elif change == "uid": changed["metadata"]["uid"] = "replacement"
            elif change == "config": config_env(changed)["value"] += " "
            else: changed["spec"]["template"]["spec"]["containers"].reverse()
            with self.subTest(change=change), self.assertRaises((ValueError, KeyError, IndexError)): apply(changed, patch)

    def test_cli_dry_run_and_private_exclusive_output_never_print_configuration(self):
        live, rendered = fixture()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, review, output = (root / name for name in ("live.json", "rendered.json", "patch.json"))
            source.write_text(json.dumps(live))
            review.write_text(json.dumps(rendered))
            args = [sys.executable, str(SCRIPT), "--agent-id", AGENT, "--expected-image", IMAGE,
                "--expected-uid", UID, "--expected-resource-version", RV, "--input", str(source), "--rendered", str(review)]
            dry = subprocess.run([*args, "--dry-run"], capture_output=True, text=True)
            self.assertEqual(dry.returncode, 0, dry.stderr)
            self.assertTrue(json.loads(dry.stdout)["changedTransport"])
            written = subprocess.run([*args, "--output", str(output)], capture_output=True, text=True)
            self.assertEqual(written.returncode, 0, written.stderr)
            self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o600)
            self.assertIn(PRIVATE, output.read_text())
            for target in (str(output), "-"):
                refused = subprocess.run([*args, "--output", target], capture_output=True, text=True)
                self.assertNotEqual(refused.returncode, 0)
                self.assertNotIn(PRIVATE, refused.stdout + refused.stderr)
            for result in (dry, written): self.assertNotIn(PRIVATE, result.stdout + result.stderr)
            link = root / "link.json"
            link.symlink_to(output)
            refused = subprocess.run([*args, "--output", str(link)], capture_output=True, text=True)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(json.loads(source.read_text()), live)

    def test_duplicate_json_keys_and_malformed_inputs_are_content_free_refusals(self):
        for raw in ('{"a":1,"a":2}', '{"a":NaN}', '{"a":1e999}', PRIVATE):
            with self.assertRaises(MODULE.PatchError) as context: MODULE.identity.parse_json(raw)
            self.assertNotIn(PRIVATE, str(context.exception))


if __name__ == "__main__":
    unittest.main()
