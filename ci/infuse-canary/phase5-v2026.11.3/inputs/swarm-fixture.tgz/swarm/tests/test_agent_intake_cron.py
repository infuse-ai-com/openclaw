from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import textwrap
import unittest


ROOT = Path(__file__).resolve().parents[1]
PREFILTER = ROOT / "scripts" / "agent-intake-mail-prefilter.sh"
CRON_INSTALLER = ROOT / "scripts" / "install-agent-intake-consulting-crons.sh"
EXPORTER = ROOT / "scripts" / "export-openclaw-cron-calendar.py"
TRIAGE_PROMPT = ROOT / "prompts" / "agent-intake-consulting-email-triage.md"
REMINDER_PROMPT = ROOT / "prompts" / "agent-intake-client-waiting-reminders.md"
CANONICAL_INTAKE_ROOT = "/workspace/agents/agent-intake/clients-projects/consulting-intake"


def load_exporter():
    spec = importlib.util.spec_from_file_location("export_openclaw_cron_calendar", EXPORTER)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load cron calendar exporter")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class AgentIntakeCronTests(unittest.TestCase):
    def test_install_keeps_all_three_jobs_paused_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            fake_bin = root / 'bin'; fake_bin.mkdir()
            checkout = root / 'clients-projects'
            subprocess.run(['git','init','-q',str(checkout)],check=True)
            (checkout / 'consulting-intake').mkdir()
            prompts = root / 'prompts'; prompts.mkdir()
            for name in ['agent-intake-consulting-email-triage.md','agent-intake-client-waiting-reminders.md']:
                (prompts / name).write_text('Fixture internal-only task')
            (fake_bin / 'kubectl').write_text('''#!/usr/bin/env python3
import os,subprocess,sys
args=sys.argv[1:]
if 'exec' in args:
    script=sys.stdin.read().replace('/opt/openclaw-agent-skill-config/prompts',os.environ['FIXTURE_PROMPTS'])
    command=args[args.index('bash'):]
    raise SystemExit(subprocess.run(command,input=script,text=True).returncode)
if 'get' in args: print('fixture-pod')
''')
            (fake_bin / 'openclaw').write_text('''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
p=Path(os.environ['FIXTURE_CRON_STATE']);jobs=json.loads(p.read_text()) if p.exists() else []
a=sys.argv;action=a[a.index('cron')+1]
if action=='list': print(json.dumps({'jobs':jobs}));raise SystemExit(0)
if action=='remove': jobs=[j for j in jobs if j['id']!=a[-1]]
if action=='add':
    name=a[a.index('--name')+1]
    jobs.append({'id':name,'name':name,'enabled':'--disabled' not in a})
p.write_text(json.dumps(jobs));print('{}')
''')
            for helper in fake_bin.iterdir(): helper.chmod(0o755)
            env={k:v for k,v in os.environ.items() if not k.startswith('AGENT_INTAKE_')}
            env.update(PATH=str(fake_bin)+os.pathsep+env['PATH'], FIXTURE_PROMPTS=str(prompts),
                       FIXTURE_CRON_STATE=str(root/'jobs.json'),AGENT_INTAKE_CONSULTING_ROOT=str(checkout/'consulting-intake'))
            for _ in range(2):
                result=subprocess.run(['bash',str(CRON_INSTALLER)],env=env,text=True,capture_output=True)
                self.assertEqual(result.returncode,0,result.stderr)
                jobs=json.loads((root/'jobs.json').read_text())
                self.assertEqual(len(jobs),3)
                self.assertTrue(all(job['enabled'] is False for job in jobs))

    def test_prompts_require_versioned_intake_state_root(self) -> None:
        for prompt_path in (TRIAGE_PROMPT, REMINDER_PROMPT):
            text = prompt_path.read_text(encoding="utf-8")
            with self.subTest(prompt=prompt_path.name):
                self.assertIn(CANONICAL_INTAKE_ROOT, text)
                self.assertIn("CONSULTING_INTAKE_ROOT=", text)
                self.assertIn("do not create a local fallback", text)
                self.assertNotIn(
                    "State root: `/workspace/agents/agent-intake/consulting-intake`",
                    text,
                )
                for line in text.splitlines():
                    if "python3 skills/consulting-intake-orchestrator/scripts/intake_state.py" in line:
                        self.assertIn("CONSULTING_INTAKE_ROOT=", line)

        installer = CRON_INSTALLER.read_text(encoding="utf-8")
        self.assertIn(
            '--command-env "CONSULTING_INTAKE_ROOT=$consulting_intake_root"',
            installer,
        )
        self.assertIn("AGENT_INTAKE_CLIENTS_PROJECTS_URL", installer)
        self.assertIn("git clone --branch main --single-branch", installer)
        self.assertIn("rev-parse --is-inside-work-tree", installer)
        self.assertLess(
            installer.index("rev-parse --is-inside-work-tree"),
            installer.index("remove_existing_job()"),
        )

    def test_prefilter_fingerprint_suppresses_unchanged_model_runs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            workspace = root / "workspace"
            script_dir = workspace / "skills" / "consulting-intake-orchestrator" / "scripts"
            fake_bin = root / "bin"
            runtime_dir = workspace / "consulting-intake" / "runtime"
            intake_root = workspace / "clients-projects" / "consulting-intake"
            script_dir.mkdir(parents=True)
            fake_bin.mkdir()
            intake_root.mkdir(parents=True)
            (intake_root / "state.json").write_text(
                json.dumps(
                    {
                        "version": 1,
                        "opportunities": {
                            "example": {
                                "status": "qualified",
                                "next_action": "prepare brief",
                            }
                        },
                    }
                ),
                encoding="utf-8",
            )

            (script_dir / "mail_intake.py").write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env python3
                    from __future__ import annotations

                    import json
                    import os
                    import sys

                    args = sys.argv[1:]
                    mailbox = "INBOX"
                    if "--mailbox" in args:
                        mailbox = args[args.index("--mailbox") + 1]
                    subject = os.environ.get("MAIL_SUBJECT", "Invoice workflow")
                    prefix = "sent" if mailbox == "Sent" else "inbound"
                    messages = [{
                        "mailbox": mailbox,
                        "id": "42" if mailbox != "Sent" else "99",
                        "message_id": f"<{prefix}@example.com>",
                        "date": "Tue, 30 Jun 2026 10:00:00 +0000",
                        "from_address": "Client <client@example.com>",
                        "to": "Ramiro Garcia <rmr.g@infuse-ai.com>",
                        "subject": subject,
                        "flags": "",
                        "in_reply_to": "",
                        "references": "",
                    }]
                    print(json.dumps({
                        "mailbox": mailbox,
                        "matched_count": len(messages),
                        "message_count": len(messages),
                        "messages": messages,
                    }))
                    """
                ),
                encoding="utf-8",
            )

            openclaw_log = root / "openclaw.log"
            (fake_bin / "openclaw").write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env bash
                    set -euo pipefail
                    printf '%s\\n' "$*" >> "$OPENCLAW_FAKE_LOG"
                    if [[ "$*" == *"cron list --all --json"* ]]; then
                      printf '{"jobs":[{"name":"agent-intake-consulting-email-triage","id":"model-job"}]}\\n'
                    elif [[ "$*" == *"cron run"* ]]; then
                      printf 'model triage final\\n'
                    else
                      printf '{}\\n'
                    fi
                    """
                ),
                encoding="utf-8",
            )
            (fake_bin / "date").write_text(
                textwrap.dedent(
                    """\
                    #!/usr/bin/env bash
                    if [[ "${1:-}" == "-u" && "${2:-}" == "-d" ]]; then
                      printf '27-Jun-2026\\n'
                    else
                      /bin/date "$@"
                    fi
                    """
                ),
                encoding="utf-8",
            )
            os.chmod(fake_bin / "openclaw", 0o755)
            os.chmod(fake_bin / "date", 0o755)

            env = os.environ.copy()
            env.update(
                {
                    "AGENT_INTAKE_WORKSPACE": str(workspace),
                    "AGENT_INTAKE_EMAIL_PREFILTER_STATE_DIR": str(runtime_dir),
                    "OPENCLAW_AGENT_PROFILE": "agent-intake",
                    "OPENCLAW_FAKE_LOG": str(openclaw_log),
                    "PATH": f"{fake_bin}{os.pathsep}{env['PATH']}",
                }
            )

            first = self.run_prefilter(env)
            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertIn("running model triage", first.stdout)
            self.assertIn("1 active state record(s)", first.stdout)
            self.assertIn("cron run", openclaw_log.read_text(encoding="utf-8"))

            log_after_first = openclaw_log.read_text(encoding="utf-8")
            second = self.run_prefilter(env)
            self.assertEqual(second.returncode, 0, second.stderr)
            self.assertEqual(second.stdout.strip(), "NO_REPLY")
            self.assertEqual(openclaw_log.read_text(encoding="utf-8"), log_after_first)

            changed_env = env.copy()
            changed_env["MAIL_SUBJECT"] = "Invoice workflow update"
            third = self.run_prefilter(changed_env)
            self.assertEqual(third.returncode, 0, third.stderr)
            self.assertIn("running model triage", third.stdout)
            self.assertGreater(
                openclaw_log.read_text(encoding="utf-8").count("cron run"),
                log_after_first.count("cron run"),
            )

    def test_cron_export_marks_disabled_jobs_as_installed_but_disabled(self) -> None:
        exporter = load_exporter()
        snapshot = exporter.build_snapshot_from_raw(
            raw_jobs={
                "jobs": [
                    {
                        "id": "enabled-job",
                        "name": "enabled-job",
                        "enabled": True,
                        "schedule": {"kind": "cron", "expr": "*/10 * * * *", "tz": "Europe/Madrid"},
                    },
                    {
                        "id": "disabled-job",
                        "name": "disabled-job",
                        "enabled": False,
                        "schedule": {"kind": "cron", "expr": "0 10 * * *", "tz": "Europe/Madrid"},
                    },
                ]
            },
            raw_state={},
            agent_id="agent-intake",
            gateway_label="agent-intake OpenClaw",
            system="openclaw",
            source_label="test",
            state_included=False,
        )
        by_name = {event["cronJobName"]: event for event in snapshot["events"]}

        self.assertEqual(by_name["enabled-job"]["status"], "live")
        self.assertTrue(by_name["enabled-job"]["enabled"])
        self.assertEqual(by_name["disabled-job"]["status"], "installed-but-disabled")
        self.assertFalse(by_name["disabled-job"]["enabled"])

    def run_prefilter(self, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["bash", str(PREFILTER)],
            check=False,
            capture_output=True,
            text=True,
            env=env,
        )


if __name__ == "__main__":
    unittest.main()
