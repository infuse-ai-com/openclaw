import importlib.util
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "filter-preserved-deployments.py"
SPEC = importlib.util.spec_from_file_location("filter_preserved_deployments", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


RENDERED = """apiVersion: v1
kind: Service
metadata:
  name: agent-developer-dashboard
---
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: agent-developer
  name: agent-developer
spec: {}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-designer
spec: {}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: emon-mission-event-producer-policy
data: {}
"""


class FilterPreservedDeploymentsTest(unittest.TestCase):
    def test_removes_only_the_named_deployment(self) -> None:
        output, found = MODULE.filter_documents(RENDERED, {"agent-developer"})
        self.assertEqual(found, {"agent-developer"})
        self.assertNotIn("name: agent-developer\nspec", output)
        self.assertIn("name: agent-developer-dashboard", output)
        self.assertIn("name: agent-designer", output)

    def test_reports_unrendered_preservation_target(self) -> None:
        _, found = MODULE.filter_documents(RENDERED, {"agent-intake"})
        self.assertEqual(found, set())

    def test_removes_an_exact_preserved_resource(self) -> None:
        resource = "ConfigMap/emon-mission-event-producer-policy"
        output, found = MODULE.filter_documents(RENDERED, set(), {resource})
        self.assertEqual(found, {resource})
        self.assertNotIn("name: emon-mission-event-producer-policy", output)
        self.assertIn("name: agent-developer", output)

    def test_removes_all_resources_of_a_preserved_kind(self) -> None:
        output, found = MODULE.filter_documents(RENDERED, set(), set(), {"Service"})
        self.assertEqual(found, {"kind:Service"})
        self.assertNotIn("name: agent-developer-dashboard", output)
        self.assertIn("name: agent-developer", output)


if __name__ == "__main__":
    unittest.main()
