import re
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AGENTS = (
    "agent-coordinator",
    "agent-designer",
    "agent-developer",
    "agent-infra",
    "agent-intake",
)


def render() -> str:
    result = subprocess.run(
        ["kubectl", "kustomize", "k8s/overlays/infuseai"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout


def documents(manifest: str) -> list[str]:
    return [document.strip() for document in re.split(r"^---\s*$", manifest, flags=re.M) if document.strip()]


def resource(manifest: str, kind: str, name: str) -> str:
    for document in documents(manifest):
        if re.search(rf"^kind: {re.escape(kind)}$", document, flags=re.M) and re.search(
            rf"^  name: {re.escape(name)}$", document, flags=re.M
        ):
            return document
    raise AssertionError(f"missing {kind}/{name}")


class RetrievalAgentIdentityTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.manifest = render()

    def test_each_agent_uses_its_exact_distinct_service_account(self) -> None:
        for agent_id in AGENTS:
            service_account = f"openclaw-{agent_id}"
            resource(self.manifest, "ServiceAccount", service_account)
            deployment = resource(self.manifest, "Deployment", agent_id)
            self.assertIn(f"serviceAccountName: {service_account}", deployment)
            self.assertIn("audience: knowledge-base-retrieval", deployment)
            self.assertIn(
                "mountPath: /var/run/openclaw-agent/tokens/knowledge-retrieval",
                deployment,
            )

    def test_new_identities_gain_no_repo_declared_rbac(self) -> None:
        role_bindings = [
            document
            for document in documents(self.manifest)
            if re.search(r"^kind: (ClusterRoleBinding|RoleBinding)$", document, flags=re.M)
        ]
        for agent_id in AGENTS:
            service_account = f"openclaw-{agent_id}"
            self.assertFalse(
                any(
                    re.search(
                        rf"subjects:[\s\S]*?kind: ServiceAccount[\s\S]*?name: {re.escape(service_account)}(?:\n|$)",
                        binding,
                    )
                    for binding in role_bindings
                ),
                f"{service_account} unexpectedly received an RBAC binding",
            )

    def test_shared_identity_remains_only_as_bounded_rollback_subject(self) -> None:
        resource(self.manifest, "ServiceAccount", "openclaw-agent")
        for agent_id in AGENTS:
            deployment = resource(self.manifest, "Deployment", agent_id)
            self.assertNotIn("serviceAccountName: openclaw-agent\n", deployment)


if __name__ == "__main__":
    unittest.main()
