from __future__ import annotations

from datetime import datetime, timedelta, timezone
import unittest

from scripts import deployment_configmap_lock as lock


NOW = datetime(2026, 9, 21, 20, 0, tzinfo=timezone.utc)


class FakeClient:
    def __init__(self, current: dict | None = None) -> None:
        self.current = current
        self.created: list[dict] = []
        self.replaced: list[dict] = []

    def read(self) -> dict | None:
        return self.current

    def create(self, body: dict) -> bool:
        self.created.append(body)
        self.current = body
        return True

    def replace(self, body: dict) -> bool:
        self.replaced.append(body)
        self.current = body
        return True


def existing(holder: str, renewed: datetime = NOW) -> dict:
    return {
        "metadata": {"name": "infuse-delivery-agents-swarm", "namespace": "agents-swarm", "resourceVersion": "7"},
        "data": {"holder": holder, "durationSeconds": "900", "renewedAt": lock.timestamp(renewed)},
    }


class DeploymentConfigMapLockTests(unittest.TestCase):
    def test_acquire_creates_missing_lock(self) -> None:
        client = FakeClient()
        result = lock.acquire(
            client,
            namespace="agents-swarm",
            name="infuse-delivery-agents-swarm",
            holder="azure/build/1",
            duration_seconds=900,
            wait_seconds=0,
            poll_seconds=1,
            now=lambda: NOW,
        )
        self.assertEqual("acquired", result["state"])
        self.assertEqual("azure/build/1", client.created[0]["data"]["holder"])

    def test_acquire_reclaims_only_expired_lock(self) -> None:
        client = FakeClient(existing("azure/build/old", NOW - timedelta(seconds=901)))
        lock.acquire(
            client,
            namespace="agents-swarm",
            name="infuse-delivery-agents-swarm",
            holder="azure/build/new",
            duration_seconds=900,
            wait_seconds=0,
            poll_seconds=1,
            now=lambda: NOW,
        )
        self.assertEqual("azure/build/new", client.replaced[0]["data"]["holder"])
        self.assertEqual("7", client.replaced[0]["metadata"]["resourceVersion"])

    def test_active_other_holder_times_out(self) -> None:
        client = FakeClient(existing("azure/build/other"))
        with self.assertRaisesRegex(lock.LockError, "lock_wait_timeout"):
            lock.acquire(
                client,
                namespace="agents-swarm",
                name="infuse-delivery-agents-swarm",
                holder="azure/build/new",
                duration_seconds=900,
                wait_seconds=0,
                poll_seconds=1,
                now=lambda: NOW,
            )

    def test_renew_and_release_require_exact_holder(self) -> None:
        client = FakeClient(existing("azure/build/other"))
        with self.assertRaisesRegex(lock.LockError, "lock_not_owned"):
            lock.renew(
                client,
                namespace="agents-swarm",
                name="infuse-delivery-agents-swarm",
                holder="azure/build/new",
                duration_seconds=900,
                now=lambda: NOW,
            )
        with self.assertRaisesRegex(lock.LockError, "lock_not_owned"):
            lock.release(
                client,
                namespace="agents-swarm",
                name="infuse-delivery-agents-swarm",
                holder="azure/build/new",
                duration_seconds=900,
                now=lambda: NOW,
            )

    def test_release_retains_empty_lock(self) -> None:
        client = FakeClient(existing("azure/build/1"))
        result = lock.release(
            client,
            namespace="agents-swarm",
            name="infuse-delivery-agents-swarm",
            holder="azure/build/1",
            duration_seconds=900,
            now=lambda: NOW,
        )
        self.assertEqual("released", result["state"])
        self.assertEqual("", client.replaced[0]["data"]["holder"])

    def test_rejects_invalid_targets(self) -> None:
        for namespace, name, holder in (
            ("", "lock", "azure/build/1"),
            ("agents-swarm", "UPPER", "azure/build/1"),
            ("agents-swarm", "lock", "bad holder"),
        ):
            with self.assertRaises(lock.LockError):
                lock.validate(namespace, name, holder)


if __name__ == "__main__":
    unittest.main()
