from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "verify-agent-skill-manifest-parity.py"
SPEC = importlib.util.spec_from_file_location("agent_skill_manifest_parity", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
PARITY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PARITY)
REVISION = "7" * 40


def manifest(*, active: bool) -> dict:
    return {
        "agent_id": "agent-designer",
        "source_sync": "latest",
        "source_filter": ["infuse-ai-agent-skills"] if active else None,
        "declared_skills": ["mission-control"],
        "sources": {
            "infuse-ai-agent-skills": {
                "id": "infuse-ai-agent-skills",
                "repo": "infuse-ai/agent-skills",
                "kind": "git",
                "branch": "main",
                "commit": REVISION,
                "dirty": False,
            }
        },
        "skills": [
            {
                "id": "mission-control",
                "source": "infuse-ai-agent-skills",
                "source_commit": REVISION,
                "files": [
                    {
                        "path": "SKILL.md",
                        "sha256": "a" * 64,
                        "bytes": 123,
                    }
                ],
            }
        ],
        "runtime_native_skills": [],
    }


class AgentSkillManifestParityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.bundle = self.root / "skill-bundle-manifest.json"
        self.active = self.root / "skill-source-sync-manifest.json"
        self.bundle.write_text(json.dumps(manifest(active=False)), encoding="utf-8")
        self.active.write_text(json.dumps(manifest(active=True)), encoding="utf-8")

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_cli(self) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [
                str(SCRIPT),
                "--agent-id",
                "agent-designer",
                "--bundle",
                str(self.bundle),
                "--active",
                str(self.active),
            ],
            check=False,
            capture_output=True,
            text=True,
        )

    def test_matching_manifests_pass_with_bounded_summary(self) -> None:
        result = self.run_cli()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(
            json.loads(result.stdout),
            {
                "action": "skill_manifest_parity_verified",
                "agentId": "agent-designer",
                "declaredSkills": 1,
                "sourceRevisions": [REVISION],
            },
        )

    def test_source_revision_drift_fails_closed(self) -> None:
        active = manifest(active=True)
        active["sources"]["infuse-ai-agent-skills"]["commit"] = "8" * 40
        active["skills"][0]["source_commit"] = "8" * 40
        self.active.write_text(json.dumps(active), encoding="utf-8")
        result = self.run_cli()
        self.assertEqual(result.returncode, 2)
        self.assertEqual(
            json.loads(result.stderr),
            {"action": "failed_closed", "reasonCode": "skill_manifest_parity_failed"},
        )

    def test_missing_active_manifest_fails_closed(self) -> None:
        self.active.unlink()
        result = self.run_cli()
        self.assertEqual(result.returncode, 2)
        self.assertEqual(
            json.loads(result.stderr),
            {"action": "failed_closed", "reasonCode": "skill_manifest_parity_failed"},
        )


if __name__ == "__main__":
    unittest.main()
