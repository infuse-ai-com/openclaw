import os
import re
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEVELOPER_PATCH = ROOT / "k8s" / "agents" / "agent-developer" / "deployment.yaml"
OVERLAY = ROOT / "k8s" / "overlays" / "infuseai"
FLEET_AGENTS = (
    "agent-developer",
    "agent-coordinator",
    "agent-designer",
    "agent-infra",
    "agent-intake",
)


class AgentObservabilityRuntimeContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.patch = DEVELOPER_PATCH.read_text(encoding="utf-8")
        cls.rendered = subprocess.run(
            ["kubectl", "kustomize", str(OVERLAY)],
            check=True,
            capture_output=True,
            text=True,
        ).stdout

    def test_all_agents_enable_the_metadata_only_observability_plugins(self) -> None:
        for agent in FLEET_AGENTS:
            patch = (ROOT / "k8s" / "agents" / agent / "deployment.yaml").read_text(encoding="utf-8")
            self.assertIn("name: OPENCLAW_DIAGNOSTICS_OTEL_CANARY", patch)
            self.assertIn("name: OPENCLAW_BEHAVIORAL_OBSERVABILITY_CANARY", patch)
            self.assertIn("name: OTEL_RESOURCE_ATTRIBUTES", patch)
            self.assertIn("name: OTEL_SERVICE_NAME", patch)
            self.assertIn("openclaw.infuse-ai.com/image-revision", patch)
            self.assertRegex(
                patch,
                re.compile(
                    r"name: OPENCLAW_IMAGE_REVISION\n"
                    r"\s+valueFrom:\n"
                    r"\s+fieldRef:\n"
                    r"\s+fieldPath: metadata.annotations\['openclaw\.infuse-ai\.com/image-revision'\]"
                ),
            )
            self.assertIn("infuse.skill_bundle.revision=unavailable", patch)
            self.assertIn(f"openclaw.agent.name={agent}", patch)
            self.assertIn(f"value: openclaw-{agent}", patch)
            self.assertIn("codex mattermost acpx diagnostics-otel", patch)
            self.assertNotIn("@openclaw/diagnostics-otel@", patch)
            self.assertIn(
                "/opt/openclaw-plugin-archives/behavioral-observability.tgz",
                patch,
            )
            self.assertIn("OPENCLAW_CAPABILITY_CONSENT_PLUGINS", patch)

    def test_boot_injection_is_metadata_only(self) -> None:
        boot = (ROOT / "scripts" / "boot-agent-developer-canary.sh").read_text(encoding="utf-8")
        self.assertIn('endpoint: "http://openclaw-otel-collector:4318"', boot)
        self.assertIn("captureContent: false", boot)
        self.assertNotIn("captureContent: true", boot)
        self.assertIn("logs: false", boot)
        self.assertNotIn("logsExporter:", boot)
        self.assertIn('sampleRate: 1.0', boot)
        self.assertIn('--arg otel_service_name "${OTEL_SERVICE_NAME:-openclaw-$agent_id}"', boot)
        self.assertIn("serviceName: $otel_service_name", boot)
        self.assertNotIn('serviceName: "openclaw-agent-developer"', boot)
        self.assertIn('.plugins.entries["diagnostics-otel"].enabled = true', boot)
        self.assertIn('[[ "${OPENCLAW_DIAGNOSTICS_OTEL_CANARY:-false}" == "true" ]]', boot)
        self.assertIn("openclaw-agent-skill-bundle-revision", boot)
        self.assertIn('replace_otel_resource_attribute "infuse.skill_bundle.revision"', boot)
        self.assertIn('.plugins.entries["behavioral-observability"].enabled = true', boot)
        self.assertIn(
            '.plugins.entries["behavioral-observability"].hooks.allowConversationAccess = true',
            boot,
        )
        self.assertIn("verify_behavioral_observability_runtime", boot)

    def test_image_pins_and_smokes_the_official_plugin(self) -> None:
        dockerfile = (ROOT / "images" / "openclaw-agent" / "Dockerfile").read_text(encoding="utf-8")
        self.assertIn('ARG OPENCLAW_VERSION=2026.11.3', dockerfile)
        self.assertIn('for plugin in codex mattermost acpx diagnostics-otel', dockerfile)
        self.assertIn("codex mattermost acpx diagnostics-otel", dockerfile)
        self.assertIn('.plugin.origin == "bundled"', dockerfile)
        self.assertIn(
            "COPY plugins/behavioral-observability /opt/openclaw-plugins/behavioral-observability",
            dockerfile,
        )
        self.assertIn("behavioral-observability-image-smoke", dockerfile)
        self.assertIn(
            "/opt/openclaw-plugin-archives/behavioral-observability.tgz",
            dockerfile,
        )
        self.assertIn('.install.source == "archive"', dockerfile)
        self.assertIn(
            'for plugin in behavioral-observability infuse-studio; do',
            dockerfile,
        )
        self.assertIn(
            'stat -c \'%h\' "/opt/openclaw-plugins/$plugin/openclaw.plugin.json"',
            dockerfile,
        )
        self.assertIn(
            '["knowledge_decision", "knowledge_retrieval", "skill_execution", "workflow_phase", "wrapper_execution"]',
            dockerfile,
        )

    def test_overlay_contains_a_hardened_collector_without_a_secret_value(self) -> None:
        self.assertRegex(
            self.rendered,
            re.compile(r"^kind: Deployment\nmetadata:\n.*?^  name: openclaw-otel-collector$", re.MULTILINE | re.DOTALL),
        )
        self.assertRegex(
            self.rendered,
            re.compile(r"^kind: Service\nmetadata:\n.*?^  name: openclaw-otel-collector$", re.MULTILINE | re.DOTALL),
        )
        self.assertIn("kind: NetworkPolicy", self.rendered)
        self.assertIn("operator: In", self.rendered)
        for agent in FLEET_AGENTS:
            self.assertIn(f"- {agent}", self.rendered)
        self.assertIn("memory_limiter:", self.rendered)
        self.assertIn("attributes/privacy:", self.rendered)
        self.assertIn("transform/tool_aliases:", self.rendered)
        self.assertIn('replace_pattern(attributes["openclaw.toolName"], "^openclaw", "")', self.rendered)
        self.assertIn('replace_pattern(attributes["tool_name"], "^openclaw", "")', self.rendered)
        self.assertIn('set(attributes["openclaw.toolName"], "exec")', self.rendered)
        self.assertIn('set(attributes["tool_name"], "exec")', self.rendered)
        self.assertIn("transform/metric_descriptions:", self.rendered)
        self.assertIn('set(description, "Gateway RPC queue wait")', self.rendered)
        self.assertIn("filter/langfuse_noise:", self.rendered)
        self.assertIn('IsMatch(name, "^openclaw[.]")', self.rendered)
        for noisy_span in (
            "openclaw.gateway.rpc.handler",
            "openclaw.gateway.rpc.dispatch",
            "openclaw.gateway.rpc.response",
            "openclaw.diagnostic.phase",
            "openclaw.memory.pressure",
            "openclaw.model.usage",
        ):
            self.assertIn(f'name == "{noisy_span}"', self.rendered)
        self.assertIn('attributes["openclaw.toolName"] != nil', self.rendered)
        self.assertIn("transform/langfuse_semantics:", self.rendered)
        for signal, observation_type in (
            ("infuse.agent.turn", "agent"),
            ("infuse.model.call", "generation"),
            ("infuse.tool.execution", "tool"),
            ("infuse.knowledge.retrieve", "retriever"),
            ("infuse.workflow.phase", "chain"),
        ):
            self.assertIn(
                f'set(attributes["langfuse.observation.type"], "{observation_type}") where name == "{signal}"',
                self.rendered,
            )
        self.assertIn("transform/resource_privacy:", self.rendered)
        self.assertIn('keep_keys(resource.attributes, ["service.name",', self.rendered)
        self.assertIn('"service.version"', self.rendered)
        self.assertIn("transform/tool_aliases, transform/langfuse_semantics, transform/resource_privacy, filter/langfuse_noise, tail_sampling", self.rendered)
        self.assertIn("traces/langfuse:", self.rendered)
        self.assertIn("traces/span_metrics:", self.rendered)
        self.assertIn("otlp_http/langfuse:", self.rendered)
        self.assertIn("endpoint: http://langfuse-web.langfuse.svc.cluster.local:3000/api/public/otel", self.rendered)
        self.assertIn('x-langfuse-ingestion-version: "4"', self.rendered)
        self.assertIn("exporters: [otlp_http/langfuse]", self.rendered)
        self.assertIn("exporters: [span_metrics]", self.rendered)
        self.assertIn("transform/resource_privacy, batch", self.rendered)
        self.assertIn("tail_sampling:", self.rendered)
        self.assertIn("name: canary-keep-all", self.rendered)
        self.assertIn("span_metrics:", self.rendered)
        for dimension in (
            "phase",
            "outcome",
            "traffic.source",
            "operation",
            "mode",
            "decision",
            "evidence_method",
            "attempt_role",
            "skill_name",
            "attribution_method",
            "lifecycle_method",
            "lifecycle_type",
            "lifecycle_state",
            "wrapper",
            "error_code",
            "tool_name",
            "failure_category",
            "classification_source",
            "openclaw.toolName",
            "integrity_state",
            "root_state",
            "parent_state",
            "child_state",
            "closure_state",
            "anomaly_type",
            "openclaw.outcome",
            "openclaw.errorCategory",
            "openclaw.channel",
            "openclaw.provider",
            "openclaw.model",
        ):
            self.assertIn(f"- name: {dimension}", self.rendered)
        for resource_key in (
            "service.name",
            "deployment.environment.name",
            "openclaw.agent.name",
            "openclaw.runtime.version",
            "openclaw.runtime.revision",
            "container.image.revision",
            "infuse.skill_bundle.revision",
        ):
            self.assertIn(f"          - {resource_key}", self.rendered)
        self.assertIn("- collector.instance.id", self.rendered)
        self.assertIn("action: delete", self.rendered)
        self.assertIn("host: 0.0.0.0", self.rendered)
        self.assertIn("port: 8888", self.rendered)
        self.assertIn("readOnlyRootFilesystem: true", self.rendered)
        self.assertIn("automountServiceAccountToken: false", self.rendered)
        self.assertIn("name: openclaw-observability-exporters", self.rendered)
        self.assertIn("key: LANGFUSE_OTEL_AUTH_HEADER", self.rendered)
        for forbidden_attribute in (
            "error.message",
            "error_message",
            "exception.message",
            "exception.stacktrace",
            "kb.evaluation_sample",
            "kb.retrieval.objective",
            "kb.retrieval.candidate.excerpts",
            "kb.retrieval.fetch_reference",
            "kb.retrieval.markdown",
        ):
            self.assertIn(f"key: {forbidden_attribute}", self.rendered)
        self.assertIn("kubernetes.io/metadata.name: knowledge-base", self.rendered)
        self.assertIn("app: knowledge-base-retrieval", self.rendered)
        self.assertIn("app.kubernetes.io/component: retrieval", self.rendered)
        self.assertNotRegex(self.rendered, re.compile(r"LANGFUSE_OTEL_AUTH_HEADER\s*\n\s*value:"))

    def test_collector_image_is_immutable(self) -> None:
        self.assertIn(
            "otel/opentelemetry-collector-contrib:0.159.0@sha256:1f2c54a30e713fac6b3ae77a1ec84010c2007e29ced8ec666214fc2f6739c1cc",
            self.rendered,
        )

    def test_canary_deployer_is_tinus_only_digest_pinned_and_rollback_guarded(self) -> None:
        script_path = ROOT / "scripts" / "deploy-agent-observability-canary.sh"
        script = script_path.read_text(encoding="utf-8")
        subprocess.run(["bash", "-n", str(script_path)], check=True)
        self.assertIn('deployment="agent-developer"', script)
        self.assertIn('immutable_image="$image_repository@$digest"', script)
        self.assertIn('.spec.template.metadata.annotations["openclaw.infuse-ai.com/image-revision"] = $digest', script)
        self.assertIn("apply --dry-run=server", script)
        self.assertIn("rollout restart deployment/openclaw-otel-collector", script)
        self.assertIn("rollout undo", script)
        self.assertIn('EXPECTED_IMAGE_DIGEST="$digest"', script)
        self.assertIn('EXPECTED_IMAGE_REF="$immutable_image"', script)
        self.assertIn("scripts/smoke-agent-runtime.sh", script)
        for agent in FLEET_AGENTS[1:]:
            self.assertIn(agent, script)
        self.assertNotIn("scripts/deploy-infuseai-agents.sh", script)

    def test_runtime_smoke_selects_only_the_expected_canary_digest(self) -> None:
        script_path = ROOT / "scripts" / "smoke-agent-runtime.sh"
        script = script_path.read_text(encoding="utf-8")
        subprocess.run(["bash", "-n", str(script_path)], check=True)
        self.assertIn('expected_image_digest="${EXPECTED_IMAGE_DIGEST:-}"', script)
        self.assertIn('expected_image_ref="${EXPECTED_IMAGE_REF:-}"', script)
        self.assertIn('.image == $expected_image_ref', script)
        self.assertIn('.metadata.annotations["openclaw.infuse-ai.com/image-revision"]', script)
        self.assertIn('.imageID | type == "string" and length > 0', script)
        self.assertIn('.imageID | endswith("@" + $expected_image_digest)', script)
        self.assertIn("ss -ltnH", script)
        self.assertIn("/:18791\\$/", script)
        self.assertNotIn("pgrep -f '^openclaw-gateway", script)

    def test_render_hands_the_immutable_digest_to_runtime_metadata(self) -> None:
        deploy = (ROOT / "scripts" / "deploy-infuseai-agents.sh").read_text(
            encoding="utf-8"
        )
        self.assertIn('reconcile_observability_collector="${RECONCILE_OBSERVABILITY_COLLECTOR:-false}"', deploy)
        self.assertIn('apply --dry-run=server -f "$manifest"', deploy)
        self.assertIn('diff -f "$manifest"', deploy)
        self.assertIn('rollout restart deployment/openclaw-otel-collector', deploy)
        self.assertIn("reconcile_observability_collector_resources", deploy)

        digest = "sha256:" + ("a" * 64)
        rendered = subprocess.run(
            [str(ROOT / "scripts" / "render-infuseai-agents.sh")],
            check=True,
            capture_output=True,
            text=True,
            env={
                "PATH": os.environ["PATH"],
                "IMAGE_TAG": "verification-tag",
                "IMAGE_REVISION": digest,
                "SOURCE_REVISION": "a" * 40,
            },
        ).stdout
        self.assertIn(f"image: registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@{digest}", rendered)
        self.assertIn(f"openclaw.infuse-ai.com/image-revision: {digest}", rendered)
        self.assertIn(f"openclaw.infuse-ai.com/swarm-source-revision: {'a' * 40}", rendered)

    def test_render_rejects_a_mutable_non_dev_image_revision(self) -> None:
        result = subprocess.run(
            [str(ROOT / "scripts" / "render-infuseai-agents.sh")],
            check=False,
            capture_output=True,
            text=True,
            env={
                "PATH": os.environ["PATH"],
                "IMAGE_TAG": "verification-tag",
                "IMAGE_REVISION": "verification-tag",
            },
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("IMAGE_REVISION must be dev or an immutable sha256 digest", result.stderr)


if __name__ == "__main__":
    unittest.main()
