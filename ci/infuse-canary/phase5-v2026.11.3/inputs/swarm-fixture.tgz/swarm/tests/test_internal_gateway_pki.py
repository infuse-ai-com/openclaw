from pathlib import Path
import subprocess
import unittest


class InternalGatewayPkiTests(unittest.TestCase):
    def test_offline_issuance_and_renewal_profiles(self):
        root = Path(__file__).resolve().parents[1]
        subprocess.run(["node", "--test", "tests/internal-gateway-pki.test.mjs"], cwd=root, check=True, capture_output=True)

    def test_runtime_assurance_and_public_expiry_contract(self):
        root = Path(__file__).resolve().parents[1]
        subprocess.run(["python3", "-m", "unittest", "discover", "-s", "tests/assurance", "-p", "test_swarm_assurance.py"], cwd=root, check=True, capture_output=True)
