import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('schedule_export', Path(__file__).parents[1]/'scripts/export-openclaw-schedules.py')
exporter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exporter)


class SchedulerExportTests(unittest.TestCase):
    def task(self, **overrides):
        return {'id':'task-1','name':'Heartbeat maintenance','enabled':False,
                'schedule':{'kind':'cron','expr':'0 9 * * *','tz':'Europe/Madrid'},
                'payload':{'text':'PRIVATE-PROMPT'},'delivery':{'to':'PRIVATE-TARGET'},
                'state':{'nextRunAtMs':1792680000000,'lastRunAtMs':1792670000000,'lastRunStatus':'error','lastError':'PRIVATE-ERROR'},**overrides}

    def test_disabled_and_internal_tasks_retained_without_private_payloads(self):
        result=exporter.snapshot({'jobs':[self.task()],'snapshotRevision':17},'agent-infra','Infra Gateway')
        task=result['tasks'][0]
        self.assertFalse(task['enabled'])
        self.assertEqual(task['lastStatus'],'error')
        self.assertEqual(task['schedule']['timezone'],'Europe/Madrid')
        self.assertNotIn('PRIVATE',str(result))
        self.assertEqual(result['source']['snapshotRevision'],'17')

    def test_empty_snapshot_is_explicit_success(self):
        self.assertEqual(exporter.snapshot({'jobs':[],'snapshotRevision':1},'agent-intake','Intake Gateway')['tasks'],[])

    def test_all_schedule_types_and_missing_timezone_are_preserved(self):
        for schedule,expected in [({'kind':'every','everyMs':60000},{'kind':'every','everyMs':60000}),
                                  ({'kind':'at','at':'2026-10-22T18:00:00+02:00'},{'kind':'at','at':'2026-10-22T16:00:00.000Z'}),
                                  ({'kind':'cron','expr':'0 9 * * *'},{'kind':'cron','expression':'0 9 * * *','timezone':None})]:
            result=exporter.snapshot({'jobs':[self.task(schedule=schedule)],'snapshotRevision':1},'agent-infra','Infra Gateway')
            self.assertEqual(result['tasks'][0]['schedule'],expected)

    def test_incomplete_invalid_oversized_and_duplicate_snapshots_fail(self):
        for raw in [{'jobs':[]}, {'jobs':[self.task(),self.task()],'snapshotRevision':1},
                    {'jobs':[self.task()]*257,'snapshotRevision':1},
                    {'jobs':[self.task(enabled='false')],'snapshotRevision':1},
                    {'jobs':[self.task(schedule={'kind':'at','at':'2026-10-22T18:00:00'})],'snapshotRevision':1},
                    {'jobs':[self.task(schedule={'kind':'every','everyMs':True})],'snapshotRevision':1}]:
            with self.subTest(raw=raw),self.assertRaises(ValueError):
                exporter.snapshot(raw,'agent-infra','Infra Gateway')


if __name__=='__main__':unittest.main()
