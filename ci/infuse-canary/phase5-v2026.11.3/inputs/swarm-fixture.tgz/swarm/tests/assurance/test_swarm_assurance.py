from __future__ import annotations

import datetime as dt
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "swarm_assurance", ROOT / "assurance/swarm_assurance.py"
)
assert SPEC and SPEC.loader
assurance = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(assurance)


class SwarmAssuranceTests(unittest.TestCase):
    def test_contract_is_complete(self) -> None:
        self.assertEqual(assurance.contract(), 0)

    def test_exact_image_is_digest_pinned(self) -> None:
        image = assurance.exact_image()
        self.assertRegex(image, r"@sha256:[0-9a-f]{64}$")

    def test_dependency_result_is_structured_and_stable(self) -> None:
        data = {
            "npm": {"exitCode": 0, "high": 0, "critical": 0},
            "python": {"exitCode": 0, "vulnerabilities": 0},
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "summary.json"
            source.write_text(json.dumps(data), encoding="utf-8")
            self.assertEqual(assurance.dependency(root / "result", source), 0)
            result = json.loads((root / "result/assurance-result.json").read_text())
            self.assertEqual(result["status"], "success")
            self.assertIn("0 CRITICAL / 0 HIGH", result["summary"])

    def test_collectors_require_exact_schedules_and_fresh_success(self) -> None:
        now = dt.datetime(2026, 11, 8, 16, 0, tzinfo=dt.timezone.utc)

        def fake_kubectl(*args: str) -> dict:
            if args[:2] == ("auth", "whoami"):
                return {"status": {"userInfo": {"username": assurance.IDENTITY}}}
            name = args[-1].split("/", 1)[1]
            schedule = assurance.COLLECTORS[name][0]
            return {
                "spec": {"schedule": schedule, "suspend": False},
                "status": {"lastSuccessfulTime": "2026-11-08T15:45:00Z"},
            }

        with tempfile.TemporaryDirectory() as temporary, mock.patch.object(
            assurance, "kubectl", side_effect=fake_kubectl
        ):
            self.assertEqual(assurance.collectors(Path(temporary), now=now), 0)
            result = json.loads((Path(temporary) / "assurance-result.json").read_text())
            self.assertEqual(result["status"], "success")

    def test_runtime_requires_all_exact_boundaries(self) -> None:
        expected_image = assurance.exact_image()

        def fake_kubectl(*args: str) -> dict:
            if args[:2] == ("auth", "whoami"):
                return {"status": {"userInfo": {"username": assurance.IDENTITY}}}
            resource = args[-1]
            kind, name = resource.split("/", 1)
            if kind == "deployment" and name in assurance.AGENTS:
                return {
                    "spec": {"template": {"spec": {"containers": [{"name": "agent", "image": expected_image}]}}},
                    "status": {"replicas": 1, "readyReplicas": 1},
                }
            if resource == "deployment/openclaw-otel-collector":
                return {"status": {"replicas": 1, "readyReplicas": 1}}
            if kind == "service" and name in assurance.DASHBOARDS:
                return {"spec": {"type": "ClusterIP", "ports": [{"port": 80, "targetPort": 18791}]}}
            if resource == "service/openclaw-otel-collector":
                return {"spec": {"type": "ClusterIP"}}
            if kind == "persistentvolumeclaim" and name in assurance.PVCS:
                return {"status": {"phase": "Bound"}}
            raise AssertionError(resource)

        with tempfile.TemporaryDirectory() as temporary, mock.patch.object(
            assurance, "kubectl", side_effect=fake_kubectl
        ), mock.patch.object(assurance, "internal_transport_agents", return_value=set()):
            self.assertEqual(assurance.runtime(Path(temporary)), 0)
            result = json.loads((Path(temporary) / "assurance-result.json").read_text())
            self.assertEqual(result["status"], "success")
            self.assertEqual(
                set((Path(temporary) / "openclaw-image-references.txt").read_text().splitlines()),
                {expected_image},
            )

    def certificate(self, role="server", agent="agent-developer", remaining=60):
        now = dt.datetime(2026, 11, 10, tzinfo=dt.timezone.utc)
        iso = lambda value: value.isoformat().replace("+00:00", "Z")
        return {
            "version": 1, "role": role, "namespace": "agents-swarm", "sha256": ("a" if role == "server" else "b") * 64,
            "notBefore": iso(now - dt.timedelta(days=90-remaining)), "notAfter": iso(now + dt.timedelta(days=remaining)),
            "dns": f"{agent}-dashboard-internal.agents-swarm.svc.cluster.local" if role == "server" else "openclaw-dashboard.agents-swarm.svc.cluster.local",
            "secretName": f"{agent}-dashboard-internal-tls" if role == "server" else "openclaw-dashboard-gateway-client-tls",
            **({"agentId": agent} if role == "server" else {}),
            "issuer": {"sha256": ("c" if role == "server" else "d") * 64, "notBefore": iso(now-dt.timedelta(days=30)), "notAfter": iso(now+dt.timedelta(days=1795))},
        }

    def tls_deployment(self):
        return {"metadata": {"annotations": {key: json.dumps(self.certificate(role)) for role, key in assurance.TLS_ANNOTATIONS.items()}},
                "spec": {"template": {"spec": {"containers": [
                    {"name": "gateway-internal-tls", "image": assurance.exact_image(),
                     "command": ["/usr/local/bin/node", "/opt/gateway-internal-tls/tunnel.mjs"],
                     "env": [{"name": "GATEWAY_TLS_SERVER_NAME", "value": "agent-developer-dashboard-internal.agents-swarm.svc.cluster.local"}]},
                    {"name": "agent", "image": assurance.exact_image()}]}}}}

    def test_tls_sidecar_does_not_hide_named_agent_or_change_approved_image(self):
        now = dt.datetime(2026, 11, 10, tzinfo=dt.timezone.utc)
        item = self.tls_deployment()
        self.assertEqual(assurance.deployment_transport(item, "agent-developer", assurance.exact_image(), True, now)["transport"], "internal-mtls")
        for index in (0, 1):
            altered = self.tls_deployment()
            altered["spec"]["template"]["spec"]["containers"][index]["image"] = "unreviewed"
            with self.assertRaises(ValueError):
                assurance.deployment_transport(altered, "agent-developer", assurance.exact_image(), True, now)
        with self.assertRaises(ValueError):
            assurance.deployment_transport(item, "agent-developer", assurance.exact_image(), False, now)

    def test_expiry_missing_wrong_identity_same_issuer_and_unknown_fields_fail_closed(self):
        now = dt.datetime(2026, 11, 10, tzinfo=dt.timezone.utc)
        for change in ("missing", "due", "expired", "wrong-agent", "same-ca", "extra"):
            item = self.tls_deployment()
            annotations = item["metadata"]["annotations"]
            record = self.certificate(remaining=30 if change == "due" else (-1 if change == "expired" else 60))
            if change == "missing":
                del annotations[assurance.TLS_ANNOTATIONS["client"]]
            if change == "wrong-agent":
                record["agentId"] = "agent-designer"
            if change == "same-ca":
                record["issuer"]["sha256"] = "d" * 64
            if change == "extra":
                record["privateKey"] = "must-not-be-accepted"
            annotations[assurance.TLS_ANNOTATIONS["server"]] = json.dumps(record)
            with self.subTest(change=change), self.assertRaises(ValueError):
                assurance.deployment_transport(item, "agent-developer", assurance.exact_image(), True, now)

    def test_ca_warning_and_leaf_lifetime_are_bounded(self):
        now = dt.datetime(2026, 11, 10, tzinfo=dt.timezone.utc)
        for role in ("server", "client"):
            record = self.certificate(role)
            record["issuer"]["notAfter"] = (now+dt.timedelta(days=180)).isoformat().replace("+00:00", "Z")
            with self.assertRaisesRegex(ValueError, "CA renewal is due"):
                assurance.certificate_record(json.dumps(record), role, "agent-developer", now)
            record = self.certificate(role, remaining=91)
            record["notBefore"] = (now-dt.timedelta(days=1)).isoformat().replace("+00:00", "Z")
            with self.assertRaisesRegex(ValueError, "lifetime"):
                assurance.certificate_record(json.dumps(record), role, "agent-developer", now)

    def test_weekly_runtime_accepts_pilot_and_detects_inconsistent_client_rotation(self):
        now = dt.datetime(2026, 11, 10, tzinfo=dt.timezone.utc)
        enabled = {"agent-developer", "agent-designer"}
        mismatch = False
        calls = []

        def fake_kubectl(*args):
            calls.append(args)
            if args[:2] == ("auth", "whoami"):
                return {"status": {"userInfo": {"username": assurance.IDENTITY}}}
            kind, name = args[-1].split("/", 1)
            if kind == "deployment" and name in assurance.AGENTS:
                image = assurance.exact_image()
                item = {"status": {"replicas": 1, "readyReplicas": 1}, "spec": {"template": {"spec": {"containers": [{"name": "agent", "image": image}]}}}}
                if name in enabled:
                    tls = self.tls_deployment()
                    tls["spec"]["template"]["spec"]["containers"][0]["env"][0]["value"] = f"{name}-dashboard-internal.agents-swarm.svc.cluster.local"
                    for container in tls["spec"]["template"]["spec"]["containers"]:
                        container["image"] = image
                    records = {role: self.certificate(role, name) for role in assurance.TLS_ANNOTATIONS}
                    if mismatch and name == "agent-designer":
                        records["client"]["sha256"] = "e" * 64
                    tls["metadata"]["annotations"] = {assurance.TLS_ANNOTATIONS[role]: json.dumps(record) for role, record in records.items()}
                    tls["status"] = item["status"]
                    item = tls
                return item
            if kind == "deployment":
                return {"status": {"replicas": 1, "readyReplicas": 1}}
            if kind == "service":
                return {"spec": {"type": "ClusterIP", "ports": [{"port": 80, "targetPort": 18791}]}}
            if kind == "persistentvolumeclaim":
                return {"status": {"phase": "Bound"}}
            raise AssertionError(args)

        with tempfile.TemporaryDirectory() as temporary, mock.patch.object(assurance, "kubectl", side_effect=fake_kubectl), mock.patch.object(assurance, "internal_transport_agents", return_value=enabled):
            self.assertEqual(assurance.runtime(Path(temporary), now=now), 0)
            mismatch = True
            self.assertEqual(assurance.runtime(Path(temporary), now=now), 1)
            result = json.loads((Path(temporary) / "assurance-result.json").read_text())
            self.assertIn("client rotation records disagree", result["summary"])
            self.assertTrue(all(args[:2] == ("auth", "whoami") or args[2] == "get" for args in calls))
            self.assertFalse(any("secret" in part or "exec" == part for args in calls for part in args))

    def test_recovery_remains_explicitly_unqualified(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            self.assertEqual(assurance.recovery(Path(temporary)), 1)
            result = json.loads((Path(temporary) / "assurance-result.json").read_text())
            self.assertEqual(result["status"], "failed")
            self.assertIn("resource-only", result["summary"])


if __name__ == "__main__":
    unittest.main()
