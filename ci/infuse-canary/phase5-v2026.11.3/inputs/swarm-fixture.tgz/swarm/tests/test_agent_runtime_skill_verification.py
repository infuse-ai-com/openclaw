from __future__ import annotations

import importlib.util
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
VERIFIER_PATH = ROOT / "scripts" / "verify-agent-runtime-skills.py"
SPEC = importlib.util.spec_from_file_location("runtime_skill_verifier", VERIFIER_PATH)
assert SPEC is not None and SPEC.loader is not None
VERIFIER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFIER)


class RuntimeSkillVerificationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.catalog = {
            "sources": {
                "company": {"materialization": "managed-copy"},
                "core": {"materialization": "runtime-native"},
            },
            "skills": {
                "company-skill": {
                    "source": "company",
                    "runtime_requirements": {"bins": []},
                },
                "native-skill": {
                    "source": "core",
                    "runtime_requirements": {"bins": ["native-cli"]},
                    "runtime_native": {"expected_source": "openclaw-bundled"},
                },
            },
        }
        self.runtime_payload = {
            "skills": [
                {
                    "name": "company-skill",
                    "source": "openclaw-workspace",
                    "eligible": True,
                    "disabled": False,
                },
                {
                    "name": "native-skill",
                    "source": "openclaw-bundled",
                    "eligible": True,
                    "disabled": False,
                },
            ]
        }

    @staticmethod
    def materialize(skills_dir: Path, skill_id: str) -> None:
        skill_dir = skills_dir / skill_id
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("fixture\n", encoding="utf-8")

    def verify(self, skills_dir: Path, installed: list[str]) -> list[str]:
        return VERIFIER.collect_errors(
            catalog=self.catalog,
            bundle={"skills": {"installed": installed}},
            runtime_payload=self.runtime_payload,
            skills_dir=skills_dir,
            which=lambda binary: f"/usr/bin/{binary}",
        )

    def test_managed_and_runtime_native_provenance_are_accepted(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            skills_dir = Path(temp_dir)
            self.materialize(skills_dir, "company-skill")
            self.assertEqual(
                self.verify(skills_dir, ["company-skill", "native-skill"]),
                [],
            )

    def test_runtime_native_workspace_shadow_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            skills_dir = Path(temp_dir)
            self.materialize(skills_dir, "company-skill")
            self.materialize(skills_dir, "native-skill")
            errors = self.verify(skills_dir, ["company-skill"])
            self.assertTrue(any("is shadowed" in error for error in errors))

    def test_wrong_runtime_native_source_is_rejected_even_when_not_installed(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            skills_dir = Path(temp_dir)
            self.materialize(skills_dir, "company-skill")
            self.runtime_payload["skills"][1]["source"] = "openclaw-workspace"
            errors = self.verify(skills_dir, ["company-skill"])
            self.assertTrue(any("expected 'openclaw-bundled'" in error for error in errors))

    def test_selected_runtime_native_binary_requirement_is_enforced(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            skills_dir = Path(temp_dir)
            self.materialize(skills_dir, "company-skill")
            errors = VERIFIER.collect_errors(
                catalog=self.catalog,
                bundle={"skills": {"installed": ["company-skill", "native-skill"]}},
                runtime_payload=self.runtime_payload,
                skills_dir=skills_dir,
                which=lambda _binary: None,
            )
            self.assertTrue(any("missing required binaries" in error for error in errors))

    def test_selected_runtime_native_agent_filter_is_enforced(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            skills_dir = Path(temp_dir)
            self.materialize(skills_dir, "company-skill")
            self.runtime_payload["skills"][1]["blockedByAgentFilter"] = True
            errors = self.verify(skills_dir, ["company-skill", "native-skill"])
            self.assertTrue(any("blocked by the agent filter" in error for error in errors))

    def test_runtime_verifier_is_packaged_and_called_by_live_smoke(self) -> None:
        dockerfile = (ROOT / "images" / "openclaw-agent" / "Dockerfile").read_text(
            encoding="utf-8"
        )
        smoke = (ROOT / "scripts" / "smoke-agent-runtime.sh").read_text(
            encoding="utf-8"
        )
        self.assertIn(
            "COPY scripts/verify-agent-runtime-skills.py "
            "/usr/local/bin/openclaw-agent-runtime-skills-verify",
            dockerfile,
        )
        self.assertIn(
            "COPY scripts/verify-agent-skill-manifest-parity.py "
            "/usr/local/bin/openclaw-agent-skill-manifest-parity",
            dockerfile,
        )
        self.assertIn("/usr/local/bin/openclaw-agent-skill-manifest-parity", dockerfile)
        self.assertIn("openclaw-agent-runtime-skills-verify", smoke)
        self.assertIn("openclaw-agent-skill-manifest-parity", smoke)

        deploy = (ROOT / "scripts" / "deploy-infuseai-agents.sh").read_text(
            encoding="utf-8"
        )
        rollout_verifier = (
            ROOT / "scripts" / "rollout-and-verify-persistent-agent.sh"
        ).read_text(encoding="utf-8")
        self.assertIn("rollout-and-verify-persistent-agent.sh", deploy)
        self.assertIn("verify_skill_manifest_parity", rollout_verifier)
        self.assertIn("openclaw-agent-skill-manifest-parity", rollout_verifier)

        sync = (ROOT / "scripts" / "sync-agent-skills-runtime.sh").read_text(
            encoding="utf-8"
        )
        self.assertIn("SKILL_MANIFEST_NAME=skill-source-sync-manifest.json", sync)
        self.assertIn("verify-agent-skill-manifest-parity.py", sync)

        startup = (ROOT / "scripts" / "sync-agent-skills-startup.sh").read_text(
            encoding="utf-8"
        )
        self.assertIn("SKILL_MANIFEST_NAME=skill-bundle-manifest.json", startup)
        self.assertIn("SKILL_MANIFEST_NAME=skill-source-sync-manifest.json", startup)
        self.assertIn("openclaw-agent-skill-manifest-parity", startup)


if __name__ == "__main__":
    unittest.main()
