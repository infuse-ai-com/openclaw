"""Regression coverage for permanent legacy Mission Control retirement."""

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
DEPLOY = ROOT / "scripts" / "deploy-infuseai-agents.sh"
DOCKERFILE = ROOT / "images" / "openclaw-agent" / "Dockerfile"
TASKFILE = ROOT / "Taskfile.yml"


class MissionControlRetirementTests(unittest.TestCase):
    def test_deploy_only_retires_legacy_feed_resources(self) -> None:
        deploy = DEPLOY.read_text(encoding="utf-8")
        deploy_tail = deploy[deploy.rindex("apply_emon_app_readonly_rbac\n") :]

        self.assertIn("retire_legacy_mission_control_resources", deploy_tail)
        self.assertNotIn("apply_mission_control_feed_resources", deploy)
        self.assertNotIn("apply_mission_control_lifecycle_resources", deploy)
        self.assertIn("delete cronjob", deploy)
        self.assertIn("delete deployment kapiteky-mission-control-relay", deploy)
        self.assertIn("delete pvc openclaw-mission-control", deploy)
        self.assertIn("delete pvc kapiteky-mission-control-relay", deploy)

    def test_legacy_executables_and_operator_tasks_are_absent(self) -> None:
        dockerfile = DOCKERFILE.read_text(encoding="utf-8")
        taskfile = TASKFILE.read_text(encoding="utf-8")

        self.assertNotIn("openclaw-mission-control-collect", dockerfile)
        self.assertNotIn("openclaw-mission-control-lifecycle", dockerfile)
        self.assertNotIn("collect-openclaw-mission-control-feed", taskfile)
        self.assertNotIn("publish-kapiteky-mission-control", taskfile)

        for relative_path in (
            "scripts/collect-openclaw-mission-control-feed.sh",
            "scripts/process-mission-control-lifecycle.py",
            "scripts/publish-kapiteky-mission-control.sh",
        ):
            self.assertFalse((ROOT / relative_path).exists(), relative_path)


if __name__ == "__main__":
    unittest.main()
