import assert from "node:assert/strict";
import test from "node:test";

import {
  classifyModelFailure,
  isSafeModelCallId,
  modelAttemptRole,
} from "../model-attempt.js";

test("model attempts distinguish primary from fallback without model-specific policy", () => {
  assert.equal(modelAttemptRole(1), "primary");
  assert.equal(modelAttemptRole(2), "fallback");
  assert.equal(modelAttemptRole(100), "fallback");
});

test("model failures collapse to a closed bounded taxonomy", () => {
  assert.equal(classifyModelFailure({ errorCategory: "provider_capacity_exhausted" }), "capacity");
  assert.equal(classifyModelFailure({ errorCategory: "HTTP 429 too many requests" }), "rate_limit");
  assert.equal(classifyModelFailure({ failureKind: "connection_reset" }), "connection");
  assert.equal(classifyModelFailure({ failureKind: "timeout" }), "timeout");
  assert.equal(classifyModelFailure({ errorCategory: "/private/raw/message" }), "unknown");
});

test("model call identifiers are bounded in-memory keys only", () => {
  assert.equal(isSafeModelCallId("call-a:17"), true);
  assert.equal(isSafeModelCallId(""), false);
  assert.equal(isSafeModelCallId("a".repeat(129)), false);
  assert.equal(isSafeModelCallId("contains a space"), false);
});
