import assert from "node:assert/strict";
import test from "node:test";

import { canonicalToolName, ToolCallDeduplicator } from "../tool-call-dedup.js";

test("dynamic-tool aliases normalize to one bounded canonical name", () => {
  assert.equal(canonicalToolName("openclawsession_status"), "session_status");
  assert.equal(canonicalToolName("openclawwrapper_execution"), "wrapper_execution");
  assert.equal(canonicalToolName("session_status"), "session_status");
  assert.equal(canonicalToolName("bash"), "exec");
  assert.equal(canonicalToolName("openclawbash"), "exec");
  assert.equal(canonicalToolName("exec"), "exec");
  assert.equal(canonicalToolName("openclaw"), "openclaw");
  assert.equal(canonicalToolName("contains a space"), "unknown");
});

test("one tool call emits once per semantic scope despite alias hook replay", () => {
  const deduplicator = new ToolCallDeduplicator(8);
  const event = { runId: "run-1", toolCallId: "call-1" };
  assert.equal(deduplicator.shouldEmit("tool", event), true);
  assert.equal(deduplicator.shouldEmit("tool", event), false);
  assert.equal(deduplicator.shouldEmit("wrapper", event), true);
  assert.equal(deduplicator.shouldEmit("wrapper", event), false);
});

test("missing call IDs fail open and run cleanup permits bounded reuse", () => {
  const deduplicator = new ToolCallDeduplicator(1);
  assert.equal(deduplicator.shouldEmit("tool", { runId: "run-1" }), true);
  assert.equal(
    deduplicator.shouldEmit("tool", { runId: "run-1", toolCallId: "call-1" }),
    true,
  );
  deduplicator.clearRun("run-1");
  assert.equal(
    deduplicator.shouldEmit("tool", { runId: "run-1", toolCallId: "call-1" }),
    true,
  );
  deduplicator.clear();
});
