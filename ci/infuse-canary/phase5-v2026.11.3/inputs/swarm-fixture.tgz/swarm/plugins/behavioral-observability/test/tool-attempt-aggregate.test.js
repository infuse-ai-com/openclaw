import assert from "node:assert/strict";
import test from "node:test";

import {
  drainToolAttemptAggregates,
  recordToolAttempt,
  shouldAggregateTool,
} from "../tool-attempt-aggregate.js";

test("only the noisy Studio apply operation is logically aggregated", () => {
  assert.equal(shouldAggregateTool("studio_whiteboard_apply"), true);
  assert.equal(shouldAggregateTool("studio_whiteboard_read"), false);
  assert.equal(shouldAggregateTool("exec"), false);
});

test("retry storms become one bounded logical outcome", () => {
  const aggregates = new Map();
  recordToolAttempt(
    aggregates,
    "studio_whiteboard_apply",
    { outcome: "error", failureCategory: "invalid_input" },
    10,
  );
  recordToolAttempt(
    aggregates,
    "studio_whiteboard_apply",
    { outcome: "error", failureCategory: "unknown" },
    20,
  );
  recordToolAttempt(
    aggregates,
    "studio_whiteboard_apply",
    { outcome: "success" },
    30,
  );
  assert.deepEqual(drainToolAttemptAggregates(aggregates), [
    {
      toolName: "studio_whiteboard_apply",
      outcome: "success",
      attemptCount: 3,
      retryCount: 2,
      errorCount: 2,
      durationMs: 60,
      failureCategory: "invalid_input",
    },
  ]);
  assert.deepEqual(drainToolAttemptAggregates(aggregates), []);
});

test("a fully failed storm stays an error and selects a stable dominant category", () => {
  const aggregates = new Map();
  for (const category of ["unknown", "timeout", "timeout"]) {
    recordToolAttempt(
      aggregates,
      "studio_whiteboard_apply",
      { outcome: "error", failureCategory: category },
      1,
    );
  }
  assert.deepEqual(drainToolAttemptAggregates(aggregates), [
    {
      toolName: "studio_whiteboard_apply",
      outcome: "error",
      attemptCount: 3,
      retryCount: 2,
      errorCount: 3,
      durationMs: 3,
      failureCategory: "timeout",
    },
  ]);
});
