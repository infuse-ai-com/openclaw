import assert from "node:assert/strict";
import test from "node:test";

import { RunContextStore } from "../run-context-store.js";

test("resolves a run through either trusted session correlation key", () => {
  const store = new RunContextStore(2);
  store.remember({
    runId: "run-a",
    sessionKey: "agent:agent-developer:smoke-routing-a",
    sessionId: "session-a",
  });
  assert.equal(store.resolve({ sessionKey: "agent:agent-developer:smoke-routing-a" }), "run-a");
  assert.equal(store.resolve({ sessionId: "session-a" }), "run-a");

  store.remember({ runId: "run-a", sessionKey: "agent:agent-developer:smoke-routing-a" });
  assert.equal(store.resolve({ sessionId: "session-a" }), "run-a");
});

test("replacement, deletion, and eviction remove stale correlation keys", () => {
  const store = new RunContextStore(1);
  store.remember({ runId: "run-a", sessionKey: "key-a", sessionId: "session-a" });
  store.remember({ runId: "run-a", sessionKey: "key-b", sessionId: "session-b" });
  assert.equal(store.resolve({ sessionKey: "key-a" }), undefined);
  assert.equal(store.resolve({ sessionId: "session-a" }), undefined);
  store.remember({ runId: "run-b", sessionKey: "key-c", sessionId: "session-c" });
  assert.equal(store.resolve({ sessionKey: "key-b" }), undefined);
  assert.equal(store.resolve({ sessionId: "session-b" }), undefined);
  assert.equal(store.resolve({ sessionId: "session-c" }), "run-b");
  store.delete("run-b");
  assert.equal(store.resolve({ sessionKey: "key-c" }), undefined);
  assert.equal(store.resolve({ sessionId: "session-c" }), undefined);
});

test("rejects missing, oversized, and unsafe identifiers", () => {
  const store = new RunContextStore(2);
  store.remember({ runId: "unsafe run", sessionKey: "key-a", sessionId: "session-a" });
  store.remember({ runId: "run-a", sessionKey: "x".repeat(257) });
  assert.equal(store.resolve({ sessionKey: "key-a" }), undefined);
  assert.equal(store.resolve({ sessionKey: "x".repeat(257) }), undefined);
});
