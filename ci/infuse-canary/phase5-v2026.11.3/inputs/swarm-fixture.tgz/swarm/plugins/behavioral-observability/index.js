import { spawn } from "node:child_process";
import path from "node:path";
import { ROOT_CONTEXT, SpanKind, SpanStatusCode, trace } from "@opentelemetry/api";
import { OTLPTraceExporter } from "@opentelemetry/exporter-trace-otlp-proto";
import { resourceFromAttributes } from "@opentelemetry/resources";
import { BatchSpanProcessor, BasicTracerProvider } from "@opentelemetry/sdk-trace-base";
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { jsonResult } from "openclaw/plugin-sdk/tool-results";

import { classifyToolHookEvent, isToolFailureCategory } from "./failure-taxonomy.js";
import {
  canonicalLifecycleId,
  drainIncompleteLifecycles,
  LIFECYCLE_METHODS,
  LIFECYCLE_STATES,
  LIFECYCLE_TYPES,
  recordLifecycle,
} from "./lifecycle-integrity.js";
import { RunSpanStore, isSafeRunId } from "./run-span-store.js";
import { RunContextStore } from "./run-context-store.js";
import { canonicalToolName, ToolCallDeduplicator } from "./tool-call-dedup.js";
import {
  drainToolAttemptAggregates,
  recordToolAttempt,
} from "./tool-attempt-aggregate.js";
import {
  orphanIntegrityAttributes,
  traceIntegrityAttributes,
  turnAnomalyTypes,
} from "./trace-integrity.js";
import {
  classifyModelFailure,
  isSafeModelCallId,
  modelAttemptRole,
} from "./model-attempt.js";
import {
  modelPricingStatus,
  normalizedHookUsageDetails,
} from "./model-usage.js";
import {
  classifyTrafficSource,
  preferTrafficSource,
  TrafficSourceStore,
} from "./traffic-source.js";

const PLUGIN_ID = "behavioral-observability";
const WORKFLOW_TOOL_NAME = "workflow_phase";
const KNOWLEDGE_TOOL_NAME = "knowledge_retrieval";
const KNOWLEDGE_DECISION_TOOL_NAME = "knowledge_decision";
const WRAPPER_EXECUTION_TOOL_NAME = "wrapper_execution";
const SKILL_EXECUTION_TOOL_NAME = "skill_execution";
const WORKFLOW_SPAN_NAME = "infuse.workflow.phase";
const KNOWLEDGE_SPAN_NAME = "infuse.knowledge.retrieve";
const KNOWLEDGE_DECISION_SPAN_NAME = "infuse.knowledge.decision";
const WRAPPER_EXECUTION_SPAN_NAME = "infuse.wrapper.execution";
const SKILL_EXECUTION_SPAN_NAME = "infuse.skill.execution";
const TOOL_EXECUTION_SPAN_NAME = "infuse.tool.execution";
const TURN_SPAN_NAME = "infuse.agent.turn";
const MODEL_SPAN_NAME = "infuse.model.call";
const TRACE_INTEGRITY_SPAN_NAME = "infuse.trace.integrity";
const TURN_ANOMALY_SPAN_NAME = "infuse.turn.anomaly";
const LIFECYCLE_INTEGRITY_SPAN_NAME = "infuse.lifecycle.integrity";
const PHASES = Object.freeze([
  "intake",
  "plan",
  "retrieve",
  "execute",
  "verify",
  "deliver",
  "recover",
]);
const OUTCOMES = Object.freeze(["started", "completed", "error", "skipped"]);
const PHASE_SET = new Set(PHASES);
const OUTCOME_SET = new Set(OUTCOMES);
const KNOWLEDGE_OPERATIONS = Object.freeze(["discover", "fetch"]);
const KNOWLEDGE_OPERATION_SET = new Set(KNOWLEDGE_OPERATIONS);
const KNOWLEDGE_DECISIONS = Object.freeze([
  "not_needed",
  "considered_unavailable",
]);
const KNOWLEDGE_DECISION_SET = new Set(KNOWLEDGE_DECISIONS);
const WRAPPER_ERROR_CODES = Object.freeze([
  "authentication_unavailable",
  "authorization_denied",
  "dependency_unavailable",
  "internal_error",
  "invalid_input",
  "nonzero_exit",
  "parse_failure",
  "timeout",
  "upstream_contract_mismatch",
  "unknown",
]);
const WRAPPER_ERROR_CODE_SET = new Set(WRAPPER_ERROR_CODES);
const WRAPPER_PHASES = Object.freeze(["start", "finish"]);
const WRAPPER_PHASE_SET = new Set(WRAPPER_PHASES);
const WRAPPER_OUTCOMES = Object.freeze(["started", "success", "error", "skipped"]);
const WRAPPER_OUTCOME_SET = new Set(WRAPPER_OUTCOMES);
const WORKFLOW_ATTRIBUTION_METHODS = Object.freeze(["automatic_hook", "explicit_marker"]);
const WORKFLOW_ATTRIBUTION_METHOD_SET = new Set(WORKFLOW_ATTRIBUTION_METHODS);
const SKILL_PHASES = Object.freeze(["start", "finish"]);
const SKILL_OUTCOMES = Object.freeze(["started", "success", "error", "skipped"]);
const SKILL_ATTRIBUTION_METHODS = Object.freeze([
  "native",
  "explicit_wrapper",
  "declared_marker",
]);
const SKILL_MARKER_ATTRIBUTION_METHODS = Object.freeze([
  "explicit_wrapper",
  "declared_marker",
]);
const SKILL_PHASE_SET = new Set(SKILL_PHASES);
const SKILL_OUTCOME_SET = new Set(SKILL_OUTCOMES);
const SKILL_MARKER_ATTRIBUTION_METHOD_SET = new Set(SKILL_MARKER_ATTRIBUTION_METHODS);
const WRAPPER_ID_RE = /^[a-z0-9][a-z0-9._-]{0,63}$/u;
const SKILL_ID_RE = /^[a-z0-9][a-z0-9-]{0,62}$/u;
const SAFE_ERROR_CODE_RE = /^[a-z][a-z0-9_]{1,95}$/u;
const SAFE_RUNTIME_ID_RE = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,95}$/u;
const MAX_KNOWLEDGE_OUTPUT_BYTES = 4_500_000;
const MAX_RUN_STATE_ENTRIES = 1024;
const RESOURCE_ATTRIBUTE_ALLOWLIST = new Set([
  "service.name",
  "deployment.environment.name",
  "openclaw.agent.name",
  "openclaw.runtime.version",
  "openclaw.runtime.revision",
  "container.image.revision",
  "infuse.skill_bundle.revision",
]);
const sequenceByRun = new Map();
const knowledgeMetadataByCall = new Map();
const knowledgeWrapperDecisionByRun = new Map();
const planStartedRuns = new Map();
const runContextStore = new RunContextStore(MAX_RUN_STATE_ENTRIES);
const runSpanStore = new RunSpanStore(MAX_RUN_STATE_ENTRIES);
const trafficSourceStore = new TrafficSourceStore(MAX_RUN_STATE_ENTRIES);
const toolCallDeduplicator = new ToolCallDeduplicator(MAX_RUN_STATE_ENTRIES);
let traceProvider;
let behavioralTracer;

const OBSERVABILITY_GUIDANCE = `For multi-step work, call ${WORKFLOW_TOOL_NAME} only at meaningful explicit workflow transitions. Prefer ${KNOWLEDGE_TOOL_NAME} over shelling out to the knowledge-retrieval client when the tool is available. Call ${KNOWLEDGE_DECISION_TOOL_NAME} only after an explicit decision that authoritative KB knowledge is not needed or the canonical client was considered but unavailable; never backfill or infer a decision. When an installed skill instructs you to trace a skill-owned wrapper or script, call ${WRAPPER_EXECUTION_TOOL_NAME} once at start and once at its terminal finish with stable skill/wrapper/operation IDs and a bounded error code only for errors. Use ${SKILL_EXECUTION_TOOL_NAME} only when an installed skill explicitly instructs you to mark actual execution; never infer skill use or claim native attribution through the marker. Never pass rationale, task text, prompts, paths, task or resource identifiers, tool inputs, tool outputs, error messages, or other content to observability marker tools.`;

function boundedMapSet(map, key, value, maximum) {
  if (!key) return;
  map.delete(key);
  while (map.size >= maximum) {
    map.delete(map.keys().next().value);
  }
  map.set(key, value);
}

function pluginToolRunContext(toolContext) {
  const runId = runContextStore.resolve({
    sessionKey: toolContext?.sessionKey,
    sessionId: toolContext?.sessionId,
  });
  if (!isSafeRunId(runId)) return {};
  const context = {
    runId,
    sessionKey: toolContext?.sessionKey,
    sessionId: toolContext?.sessionId,
  };
  resolveRunTrafficSource(context, context);
  return context;
}

function nextSequence(runId) {
  if (!runId) {
    return 1;
  }
  const next = Math.min((sequenceByRun.get(runId) ?? 0) + 1, 1000);
  sequenceByRun.set(runId, next);
  return next;
}

function decodeResourceValue(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function resourceAttributesFromEnvironment() {
  const attributes = {};
  for (const item of (process.env.OTEL_RESOURCE_ATTRIBUTES ?? "").split(",")) {
    const separator = item.indexOf("=");
    if (separator <= 0) continue;
    const key = item.slice(0, separator).trim();
    const value = decodeResourceValue(item.slice(separator + 1).trim());
    if (RESOURCE_ATTRIBUTE_ALLOWLIST.has(key) && value) {
      attributes[key] = value;
    }
  }
  if (process.env.OTEL_SERVICE_NAME) {
    attributes["service.name"] = process.env.OTEL_SERVICE_NAME;
  }
  return attributes;
}

function resolveTraceEndpoint(config) {
  const endpoint = config?.diagnostics?.otel?.endpoint;
  if (typeof endpoint !== "string" || endpoint.length === 0) return undefined;
  const normalized = endpoint.replace(/\/+$/u, "");
  return normalized.endsWith("/v1/traces") ? normalized : `${normalized}/v1/traces`;
}

function createTelemetryService() {
  return {
    id: `${PLUGIN_ID}-telemetry`,
    start(context) {
      try {
        const url = resolveTraceEndpoint(context.config);
        if (!url || context.config?.diagnostics?.otel?.traces !== true) {
          context.logger.warn("behavioral observability trace exporter is disabled");
          return;
        }
        const exporter = new OTLPTraceExporter({ url });
        traceProvider = new BasicTracerProvider({
          resource: resourceFromAttributes(resourceAttributesFromEnvironment()),
          spanProcessors: [
            new BatchSpanProcessor(exporter, {
              maxQueueSize: 512,
              maxExportBatchSize: 128,
              scheduledDelayMillis: 1000,
              exportTimeoutMillis: 10000,
            }),
          ],
        });
        behavioralTracer = traceProvider.getTracer(PLUGIN_ID, "0.10.0");
        context.logger.info("behavioral observability trace exporter started");
      } catch (error) {
        traceProvider = undefined;
        behavioralTracer = undefined;
        context.logger.warn(`behavioral observability trace exporter failed to start: ${String(error)}`);
      }
    },
    async stop(context) {
      const provider = traceProvider;
      for (const state of runSpanStore.drain()) {
        finishRunSpanState(state, { success: false, closureState: "shutdown" });
      }
      traceProvider = undefined;
      behavioralTracer = undefined;
      sequenceByRun.clear();
      knowledgeMetadataByCall.clear();
      planStartedRuns.clear();
      runContextStore.clear();
      trafficSourceStore.clear();
      toolCallDeduplicator.clear();
      if (!provider) return;
      try {
        await provider.shutdown();
      } catch (error) {
        context.logger.warn(`behavioral observability trace exporter failed to stop: ${String(error)}`);
      }
    },
  };
}

function safeRuntimeId(value) {
  return typeof value === "string" && SAFE_RUNTIME_ID_RE.test(value) ? value : "unknown";
}

function trafficAttributes(source) {
  return { "traffic.source": source ?? "unavailable" };
}

function langfuseTraceAttributes(source) {
  const boundedSource = source ?? "unavailable";
  const agentName = safeRuntimeId(
    resourceAttributesFromEnvironment()["openclaw.agent.name"],
  );
  return {
    "langfuse.trace.name": "openclaw-agent-turn",
    "langfuse.trace.tags": [
      "openclaw",
      "agent-turn",
      `agent:${agentName}`,
      `traffic:${boundedSource}`,
    ],
    "langfuse.trace.metadata.traffic_source": boundedSource,
    "langfuse.trace.metadata.agent": agentName,
  };
}

function langfuseObservationAttributes(name) {
  if (name === TURN_SPAN_NAME) return { "langfuse.observation.type": "agent" };
  if (name === MODEL_SPAN_NAME) return { "langfuse.observation.type": "generation" };
  if (name === TOOL_EXECUTION_SPAN_NAME) return { "langfuse.observation.type": "tool" };
  if (name === KNOWLEDGE_SPAN_NAME) return { "langfuse.observation.type": "retriever" };
  if (name === WORKFLOW_SPAN_NAME) return { "langfuse.observation.type": "chain" };
  return {};
}

function langfuseFilterMetadata(attributes) {
  const filterable = {};
  for (const key of [
    "anomaly_type",
    "classification_source",
    "closure_state",
    "decision",
    "error_count",
    "failure_category",
    "operation",
    "outcome",
    "retry_count",
    "skill_name",
    "tool_name",
  ]) {
    const value = attributes?.[key];
    if (["string", "number", "boolean"].includes(typeof value)) {
      filterable[`langfuse.observation.metadata.${key}`] = String(value);
    }
  }
  return filterable;
}

function emitTraceIntegritySummary(state, closureState, durationMs) {
  if (!behavioralTracer || !state?.rootContext) return;
  const summary = behavioralTracer.startSpan(
    TRACE_INTEGRITY_SPAN_NAME,
    {
      kind: SpanKind.INTERNAL,
      attributes: {
        ...traceIntegrityAttributes(closureState),
        ...trafficAttributes(state.trafficSource),
      },
    },
    state.rootContext,
  );
  summary.end();
  for (const anomalyType of turnAnomalyTypes({
    durationMs,
    toolCount: state.toolCount,
    failureCount: state.failureCount,
    childCount: state.childCount,
    closureState,
  })) {
    const anomaly = behavioralTracer.startSpan(
      TURN_ANOMALY_SPAN_NAME,
      {
        kind: SpanKind.INTERNAL,
        attributes: {
          anomaly_type: anomalyType,
          duration_ms: durationMs,
          ...trafficAttributes(state.trafficSource),
        },
        ...(durationMs > 0 ? { startTime: Date.now() - durationMs } : {}),
      },
      state.rootContext,
    );
    anomaly.end();
  }
}

function emitLifecycleIntegrityIssue(state, issue) {
  if (
    !behavioralTracer ||
    !state?.rootContext ||
    !issue ||
    !LIFECYCLE_TYPES.includes(issue.lifecycleType) ||
    !LIFECYCLE_STATES.includes(issue.lifecycleState)
  ) {
    return;
  }
  const span = behavioralTracer.startSpan(
    LIFECYCLE_INTEGRITY_SPAN_NAME,
    {
      kind: SpanKind.INTERNAL,
      attributes: {
        lifecycle_type: issue.lifecycleType,
        lifecycle_state: issue.lifecycleState,
        incomplete_count: issue.incompleteCount ?? 0,
        ...(issue.skill_name ? { skill_name: issue.skill_name } : {}),
        ...(issue.wrapper ? { wrapper: issue.wrapper } : {}),
        ...(issue.operation ? { operation: issue.operation } : {}),
        ...(issue.attribution_method
          ? { attribution_method: issue.attribution_method }
          : {}),
        ...trafficAttributes(state.trafficSource),
      },
    },
    state.rootContext,
  );
  span.setStatus({ code: SpanStatusCode.ERROR });
  span.end();
  state.childCount += 1;
}

function emitIncompleteLifecycleIssues(state) {
  for (const issue of drainIncompleteLifecycles(state)) {
    emitLifecycleIntegrityIssue(state, issue);
  }
}

function emitOrphanIntegrityIssue(api) {
  try {
    if (!behavioralTracer) return;
    const span = behavioralTracer.startSpan(
      TRACE_INTEGRITY_SPAN_NAME,
      {
        kind: SpanKind.INTERNAL,
        attributes: {
          ...orphanIntegrityAttributes(),
          ...trafficAttributes("unavailable"),
        },
      },
      ROOT_CONTEXT,
    );
    span.setStatus({ code: SpanStatusCode.ERROR });
    span.end();
  } catch (error) {
    api.logger.warn(`behavioral observability integrity emission failed: ${String(error)}`);
  }
}

function finishRunSpanState(state, { success, durationMs, closureState }) {
  if (!state || state.ended) return;
  state.ended = true;
  const outcome = success ? "success" : "error";
  const finalClosureState = closureState ?? (success ? "completed" : "error");
  const duration = boundedDuration(
    Number.isFinite(durationMs) ? durationMs : Date.now() - state.startedAt,
  );
  flushToolAttemptAggregatesForState(state);
  closePendingModelAttempts(state);
  if (state.modelAttemptCount === 0) emitSyntheticModelAttempt(state, outcome, duration);
  try {
    emitIncompleteLifecycleIssues(state);
  } catch {
    // Lifecycle integrity emission cannot prevent the root from closing.
  }
  try {
    emitTraceIntegritySummary(state, finalClosureState, duration);
  } catch {
    // Integrity/anomaly emission cannot prevent the root from closing.
  }
  try {
    state.rootSpan.setAttribute("outcome", outcome);
    state.rootSpan.setAttribute("duration_ms", duration);
    state.rootSpan.setAttribute("closure_state", finalClosureState);
    state.rootSpan.setAttribute("langfuse.observation.metadata.outcome", outcome);
    state.rootSpan.setAttribute(
      "langfuse.observation.metadata.closure_state",
      finalClosureState,
    );
    if (!success) state.rootSpan.setStatus({ code: SpanStatusCode.ERROR });
    state.rootSpan.end();
  } catch {
    // Telemetry is fail-open even while closing an evicted or shutdown run.
  }
}

function closePendingModelAttempts(state) {
  if (!state?.modelCalls) return;
  for (const attempt of state.modelCalls.values()) {
    try {
      const duration = boundedDuration(Date.now() - attempt.startedAt);
      if (!attempt.completed) {
        attempt.span.setAttribute("outcome", "error");
        attempt.span.setAttribute("duration_ms", duration);
        attempt.span.setAttribute("failure_category", "unknown");
        attempt.span.setStatus({ code: SpanStatusCode.ERROR });
        state.failureCount += 1;
      }
      attempt.span.end();
    } catch {
      // Pending model telemetry is fail-open during turn closure.
    }
  }
  state.modelCalls.clear();
}

function emitSyntheticModelAttempt(state, outcome, durationMs) {
  try {
    if (!behavioralTracer || !state?.rootContext) return;
    const error = outcome === "error";
    const span = behavioralTracer.startSpan(
      MODEL_SPAN_NAME,
      {
        kind: SpanKind.INTERNAL,
        attributes: {
          ...langfuseObservationAttributes(MODEL_SPAN_NAME),
          ...langfuseTraceAttributes(state.trafficSource),
          ...langfuseFilterMetadata({
            outcome,
            ...(error ? { failure_category: "unknown" } : {}),
          }),
          "langfuse.observation.model.name": state.model,
          "langfuse.observation.metadata.pricing_status": modelPricingStatus(state.model),
          ...(state.modelUsage
            ? {
                "langfuse.observation.usage_details": JSON.stringify(state.modelUsage),
              }
            : {}),
          provider: state.modelProvider,
          model: state.model,
          attempt_role: "primary",
          attempt_index: 1,
          outcome,
          duration_ms: durationMs,
          ...(error ? { failure_category: "unknown" } : {}),
          ...trafficAttributes(state.trafficSource),
        },
        ...(durationMs > 0 ? { startTime: Date.now() - durationMs } : {}),
      },
      state.rootContext,
    );
    if (error) span.setStatus({ code: SpanStatusCode.ERROR });
    span.end();
    state.childCount += 1;
    state.modelAttemptCount = 1;
  } catch {
    // Synthetic compatibility telemetry is fail-open.
  }
}

function beginRunSpans(api, event, context) {
  let incompleteState;
  try {
    if (!behavioralTracer) return undefined;
    const runId = event?.runId ?? context?.runId;
    if (!isSafeRunId(runId)) return undefined;
    const existing = runSpanStore.get(runId);
    if (existing) return existing;
    const provider = safeRuntimeId(event?.provider ?? context?.modelProviderId);
    const model = safeRuntimeId(event?.model ?? context?.modelId);
    const trafficSource = trafficSourceStore.get(runId);
    const startedAt = Date.now();
    const parentContext = ROOT_CONTEXT;
    const rootSpan = behavioralTracer.startSpan(
      TURN_SPAN_NAME,
      {
        kind: SpanKind.INTERNAL,
        attributes: {
          ...langfuseObservationAttributes(TURN_SPAN_NAME),
          ...langfuseTraceAttributes(trafficSource),
          ...trafficAttributes(trafficSource),
          "langfuse.observation.metadata.traffic_source": trafficSource,
          trace_link_state: "curated_canonical",
        },
      },
      parentContext,
    );
    const rootContext = trace.setSpan(parentContext, rootSpan);
    incompleteState = {
      rootSpan,
      rootContext,
      modelCalls: new Map(),
      modelAttemptCount: 0,
      modelProvider: provider,
      model,
      trafficSource,
      toolAggregates: new Map(),
      startedAt,
      ended: false,
      childCount: 0,
      toolCount: 0,
      failureCount: 0,
    };
    const state = {
      rootSpan,
      rootContext,
      modelCalls: new Map(),
      modelAttemptCount: 0,
      modelProvider: provider,
      model,
      trafficSource,
      toolAggregates: new Map(),
      startedAt,
      ended: false,
      childCount: 0,
      toolCount: 0,
      failureCount: 0,
    };
    incompleteState = undefined;
    const stored = runSpanStore.begin(runId, state);
    if (!stored.inserted) {
      finishRunSpanState(state, {
        success: false,
        durationMs: 0,
        closureState: "start_failed",
      });
      return stored.state;
    }
    if (stored.evicted) {
      finishRunSpanState(stored.evicted, {
        success: false,
        closureState: "evicted",
      });
    }
    return state;
  } catch (error) {
    finishRunSpanState(incompleteState, {
      success: false,
      durationMs: 0,
      closureState: "start_failed",
    });
    api.logger.warn(`behavioral observability turn span start failed: ${String(error)}`);
    return undefined;
  }
}

function resolveRunTrafficSource(event, context, senderIsOwner) {
  const runId = event?.runId ?? context?.runId;
  const sessionKey = event?.sessionKey ?? context?.sessionKey;
  const sessionId = event?.sessionId ?? context?.sessionId;
  const candidate = classifyTrafficSource({
    trigger: event?.trigger ?? context?.trigger,
    channel: event?.channel ?? context?.channel,
    messageProvider: event?.messageProvider ?? context?.messageProvider,
    sessionKey,
    senderIsOwner: senderIsOwner ?? event?.senderIsOwner,
    inputProvenanceKind:
      event?.inputProvenance?.kind ?? context?.inputProvenance?.kind,
  });
  trafficSourceStore.rememberContext({ sessionKey, sessionId }, candidate);
  const ingressSource = trafficSourceStore.getContext({ sessionKey, sessionId });
  if (!isSafeRunId(runId)) return preferTrafficSource(candidate, ingressSource);
  runContextStore.remember({ runId, sessionKey, sessionId });
  const current = trafficSourceStore.get(runId);
  const resolved = preferTrafficSource(current, preferTrafficSource(candidate, ingressSource));
  trafficSourceStore.remember(runId, resolved);
  const state = runSpanStore.get(runId);
  if (state && state.trafficSource !== resolved) {
    state.trafficSource = resolved;
    state.rootSpan?.setAttribute("traffic.source", resolved);
    state.rootSpan?.setAttribute(
      "langfuse.observation.metadata.traffic_source",
      resolved,
    );
    for (const [key, value] of Object.entries(langfuseTraceAttributes(resolved))) {
      state.rootSpan?.setAttribute(key, value);
    }
  }
  return resolved;
}

function beginModelAttempt(api, event, context) {
  try {
    const state = beginRunSpans(api, event, context);
    if (!state?.rootContext || !isSafeModelCallId(event?.callId)) return;
    if (state.modelCalls.has(event.callId)) return;
    const attemptIndex = Math.min(state.modelAttemptCount + 1, 100);
    const span = behavioralTracer.startSpan(
      MODEL_SPAN_NAME,
      {
        kind: SpanKind.INTERNAL,
        attributes: {
          ...langfuseObservationAttributes(MODEL_SPAN_NAME),
          ...langfuseTraceAttributes(state.trafficSource),
          "langfuse.observation.model.name": safeRuntimeId(event?.model),
          "langfuse.observation.metadata.pricing_status": modelPricingStatus(event?.model),
          provider: safeRuntimeId(event?.provider),
          model: safeRuntimeId(event?.model),
          attempt_role: modelAttemptRole(attemptIndex),
          attempt_index: attemptIndex,
          ...trafficAttributes(state.trafficSource),
        },
      },
      state.rootContext,
    );
    state.modelCalls.set(event.callId, { span, startedAt: Date.now(), completed: false });
    state.modelAttemptCount = attemptIndex;
    state.childCount += 1;
  } catch (error) {
    api.logger.warn(`behavioral observability model attempt start failed: ${String(error)}`);
  }
}

function finishModelAttempt(api, event, context) {
  try {
    const state = runSpanStore.get(event?.runId ?? context?.runId);
    if (!state?.modelCalls || !isSafeModelCallId(event?.callId)) return;
    const attempt = state.modelCalls.get(event.callId);
    if (!attempt) return;
    const error = event?.outcome !== "completed";
    const duration = boundedDuration(event?.durationMs);
    attempt.span.setAttribute("outcome", error ? "error" : "success");
    attempt.span.setAttribute("duration_ms", duration);
    attempt.span.setAttribute(
      "langfuse.observation.metadata.outcome",
      error ? "error" : "success",
    );
    if (error) {
      const failureCategory = classifyModelFailure(event);
      attempt.span.setAttribute("failure_category", failureCategory);
      attempt.span.setAttribute(
        "langfuse.observation.metadata.failure_category",
        failureCategory,
      );
      attempt.span.setStatus({ code: SpanStatusCode.ERROR });
      state.failureCount += 1;
      state.modelCalls.delete(event.callId);
      attempt.span.end();
      return;
    }
    attempt.completed = true;
    attempt.completedAt = Date.now();
  } catch (error) {
    api.logger.warn(`behavioral observability model attempt finish failed: ${String(error)}`);
  }
}

function finishModelUsage(api, event, context) {
  try {
    const state = runSpanStore.get(event?.runId ?? context?.runId);
    if (!state) return;
    const usage = normalizedHookUsageDetails(event);
    if (!usage) return;
    state.modelUsage = usage;
    state.model = safeRuntimeId(event?.model ?? state.model);
    state.modelProvider = safeRuntimeId(event?.provider ?? state.modelProvider);
    finishLatestCompletedModelAttempt(state, {
      usage,
      model: event?.model,
      provider: event?.provider,
    });
  } catch (error) {
    api.logger.warn(`behavioral observability model usage failed: ${String(error)}`);
  }
}

function finishLatestCompletedModelAttempt(state, { usage, model, provider }) {
  if (!state?.modelCalls || !usage) return false;
  const candidate = [...state.modelCalls.entries()]
    .reverse()
    .find(([, attempt]) => attempt.completed);
  if (!candidate) return false;
  const [callId, attempt] = candidate;
  attempt.span.setAttribute("langfuse.observation.usage_details", JSON.stringify(usage));
  const resolvedModel = safeRuntimeId(model ?? state.model);
  const resolvedProvider = safeRuntimeId(provider ?? state.modelProvider);
  attempt.span.setAttribute("langfuse.observation.model.name", resolvedModel);
  attempt.span.setAttribute(
    "langfuse.observation.metadata.pricing_status",
    modelPricingStatus(resolvedModel),
  );
  attempt.span.setAttribute("provider", resolvedProvider);
  attempt.span.setAttribute("model", resolvedModel);
  state.modelCalls.delete(callId);
  attempt.span.end();
  return true;
}

function finishRunSpans(api, event, context) {
  try {
    const state = runSpanStore.take(event?.runId ?? context?.runId);
    finishRunSpanState(state, {
      success: event?.success === true,
      durationMs: event?.durationMs,
      closureState: event?.success === true ? "completed" : "error",
    });
  } catch (error) {
    api.logger.warn(`behavioral observability turn span finish failed: ${String(error)}`);
  }
}

function emitSpan(api, { name, attributes, context, error = false, durationMs }) {
  try {
    if (!behavioralTracer) return;
    resolveRunTrafficSource(context, context);
    const turnState = runSpanStore.get(context?.runId);
    if (!turnState?.rootContext) {
      emitOrphanIntegrityIssue(api);
      return;
    }
    const boundedSpanDuration = boundedDuration(durationMs);
    const span = behavioralTracer.startSpan(
      name,
      {
        kind: SpanKind.INTERNAL,
        attributes: {
          ...langfuseObservationAttributes(name),
          ...langfuseTraceAttributes(turnState.trafficSource),
          ...langfuseFilterMetadata(attributes),
          ...attributes,
          ...trafficAttributes(turnState.trafficSource),
        },
        ...(boundedSpanDuration > 0
          ? { startTime: Date.now() - boundedSpanDuration }
          : {}),
      },
      turnState.rootContext,
    );
    if (error) {
      span.setStatus({ code: SpanStatusCode.ERROR });
    }
    span.end();
    turnState.childCount += 1;
    if (name === TOOL_EXECUTION_SPAN_NAME) {
      turnState.toolCount += 1;
    }
    if (error) turnState.failureCount += 1;
  } catch (error) {
    api.logger.warn(`behavioral observability span emission failed: ${String(error)}`);
  }
}

function emitToolExecution(api, { event, context }) {
  const classification = classifyToolHookEvent(event);
  const toolName = canonicalToolName(event?.toolName);
  const turnState = runSpanStore.get(context?.runId);
  if (
    turnState?.toolAggregates &&
    recordToolAttempt(
      turnState.toolAggregates,
      toolName,
      classification,
      boundedDuration(event?.durationMs),
    )
  ) {
    return;
  }
  const attributes = {
    tool_name: toolName,
    outcome: classification.outcome,
    duration_ms: boundedDuration(event?.durationMs),
  };
  if (classification.outcome === "error") {
    attributes.failure_category = classification.failureCategory;
    attributes.classification_source = classification.classificationSource;
  }
  emitSpan(api, {
    name: TOOL_EXECUTION_SPAN_NAME,
    attributes,
    context,
    error: classification.outcome === "error",
    durationMs: event?.durationMs,
  });
}

function flushToolAttemptAggregatesForState(state) {
  if (!behavioralTracer || !state?.rootContext || !state?.toolAggregates) return;
  for (const summary of drainToolAttemptAggregates(state.toolAggregates)) {
    try {
      const attributes = {
        tool_name: summary.toolName,
        outcome: summary.outcome,
        duration_ms: boundedDuration(summary.durationMs),
        attempt_count: summary.attemptCount,
        retry_count: summary.retryCount,
        error_count: summary.errorCount,
        classification_source: "logical_retry_aggregate",
        ...(summary.failureCategory
          ? { failure_category: summary.failureCategory }
          : {}),
      };
      const span = behavioralTracer.startSpan(
        TOOL_EXECUTION_SPAN_NAME,
        {
          kind: SpanKind.INTERNAL,
          attributes: {
            ...langfuseObservationAttributes(TOOL_EXECUTION_SPAN_NAME),
            ...langfuseTraceAttributes(state.trafficSource),
            ...langfuseFilterMetadata(attributes),
            ...attributes,
            ...trafficAttributes(state.trafficSource),
          },
          ...(summary.durationMs > 0
            ? { startTime: Date.now() - boundedDuration(summary.durationMs) }
            : {}),
        },
        state.rootContext,
      );
      if (summary.outcome === "error") span.setStatus({ code: SpanStatusCode.ERROR });
      span.end();
      state.childCount += 1;
      state.toolCount += 1;
      if (summary.outcome === "error") state.failureCount += 1;
    } catch {
      // Aggregated tool telemetry is fail-open during turn closure.
    }
  }
}

function isFirstToolHook(scope, event, context) {
  return toolCallDeduplicator.shouldEmit(scope, {
    runId: context?.runId,
    toolCallId: event?.toolCallId,
  });
}

function emitPlanOnce(api, context) {
  const runId = context?.runId;
  if (!runId || planStartedRuns.has(runId)) return;
  boundedMapSet(planStartedRuns, runId, true, MAX_RUN_STATE_ENTRIES);
  emitPhase(api, {
    phase: "plan",
    outcome: "started",
    attributionMethod: "automatic_hook",
    context,
  });
}

function clearAuxiliaryRunState(runId, context = {}) {
  if (!runId) return;
  sequenceByRun.delete(runId);
  planStartedRuns.delete(runId);
  toolCallDeduplicator.clearRun(runId);
  trafficSourceStore.delete(runId);
  trafficSourceStore.deleteContext(context);
  knowledgeWrapperDecisionByRun.delete(runId);
  runContextStore.delete(runId);
}

function emitPhase(api, { phase, outcome, attributionMethod, context }) {
  if (
    !PHASE_SET.has(phase) ||
    !OUTCOME_SET.has(outcome) ||
    !WORKFLOW_ATTRIBUTION_METHOD_SET.has(attributionMethod)
  ) {
    return;
  }
  emitSpan(api, {
    name: WORKFLOW_SPAN_NAME,
    attributes: {
      phase,
      outcome,
      sequence: nextSequence(context?.runId),
      attribution_method: attributionMethod,
    },
    context,
    error: outcome === "error",
  });
}

function emitKnowledgeAccess(api, { operation, outcome, durationMs, metadata, context }) {
  if (
    !KNOWLEDGE_OPERATION_SET.has(operation) ||
    !["success", "empty", "error"].includes(outcome)
  ) {
    return;
  }
  const attributes = {
    operation,
    mode: metadata?.mode ?? (operation === "fetch" ? "direct" : "unknown"),
    outcome,
    duration_ms: boundedDuration(durationMs),
    result_count: metadata?.resultCount ?? 0,
  };
  if (metadata?.fallbackReason) attributes.fallback_reason = metadata.fallbackReason;
  if (metadata?.snapshot) attributes.kb_snapshot = metadata.snapshot;
  emitSpan(api, {
    name: KNOWLEDGE_SPAN_NAME,
    attributes,
    context,
    error: outcome === "error",
  });
}

function readKnowledgeDecisionParams(params) {
  const decision = typeof params?.decision === "string" ? params.decision : "";
  if (!KNOWLEDGE_DECISION_SET.has(decision)) {
    throw new Error("knowledge_decision received an unsupported bounded decision");
  }
  return { decision };
}

function emitKnowledgeDecision(api, { decision, evidenceMethod, context, error = false }) {
  if (
    !["not_needed", "considered_unavailable", "invoked", "failed"].includes(decision) ||
    !["explicit_marker", "tool_outcome", "wrapper_outcome"].includes(evidenceMethod)
  ) {
    return;
  }
  emitSpan(api, {
    name: KNOWLEDGE_DECISION_SPAN_NAME,
    attributes: {
      decision,
      evidence_method: evidenceMethod,
    },
    context,
    error,
  });
}

function emitWrapperExecution(api, { marker, context }) {
  if (!marker) {
    return;
  }
  const turnState = runSpanStore.get(context?.runId);
  const descriptor = {
    skill_name: marker.skillName,
    wrapper: marker.wrapper,
    operation: marker.operation,
  };
  const lifecycleState = recordLifecycle(
    turnState,
    "wrapper",
    `${marker.skillName}|${marker.wrapper}|${marker.operation}`,
    descriptor,
    marker.phase,
  );
  emitSpan(api, {
    name: WRAPPER_EXECUTION_SPAN_NAME,
    attributes: {
      skill_name: marker.skillName,
      skill_revision: "unknown",
      wrapper: marker.wrapper,
      operation: marker.operation,
      phase: marker.phase,
      outcome: marker.outcome,
      duration_ms: marker.durationMs,
      retry_count: marker.retryCount,
      exit_class:
        marker.outcome === "success"
          ? "zero"
          : marker.outcome === "error"
            ? "nonzero"
            : "not_applicable",
      lifecycle_method: marker.lifecycleMethod,
      lifecycle_state: lifecycleState,
      ...(marker.errorCode ? { error_code: marker.errorCode } : {}),
    },
    context,
    error: marker.outcome === "error",
  });
  if (
    marker.skillName === "knowledge-retrieval" &&
    marker.phase === "finish" &&
    ["success", "error"].includes(marker.outcome) &&
    !knowledgeWrapperDecisionByRun.has(context?.runId)
  ) {
    boundedMapSet(
      knowledgeWrapperDecisionByRun,
      context?.runId,
      marker.outcome,
      MAX_RUN_STATE_ENTRIES,
    );
    emitKnowledgeDecision(api, {
      decision: marker.outcome === "success" ? "invoked" : "failed",
      evidenceMethod: "wrapper_outcome",
      context,
      error: marker.outcome === "error",
    });
  }
  if (lifecycleState === "unmatched_finish") {
    emitLifecycleIntegrityIssue(turnState, {
      lifecycleType: "wrapper",
      lifecycleState,
      incompleteCount: 0,
      ...descriptor,
    });
  }
}

function emitSkillExecution(api, { marker, context }) {
  if (!marker) {
    return;
  }
  const turnState = runSpanStore.get(context?.runId);
  const descriptor = {
    skill_name: marker.skillName,
    attribution_method: marker.attributionMethod,
  };
  const lifecycleState = recordLifecycle(
    turnState,
    "skill",
    `${marker.skillName}|${marker.attributionMethod}`,
    descriptor,
    marker.phase,
  );
  emitSpan(api, {
    name: SKILL_EXECUTION_SPAN_NAME,
    attributes: {
      skill_name: marker.skillName,
      phase: marker.phase,
      outcome: marker.outcome,
      attribution_method: marker.attributionMethod,
      lifecycle_state: lifecycleState,
    },
    context,
    error: marker.outcome === "error",
  });
  if (lifecycleState === "unmatched_finish") {
    emitLifecycleIntegrityIssue(turnState, {
      lifecycleType: "skill",
      lifecycleState,
      incompleteCount: 0,
      ...descriptor,
    });
  }
}

function readBoundedParams(params) {
  const phase = typeof params?.phase === "string" ? params.phase : "";
  const outcome = typeof params?.outcome === "string" ? params.outcome : "";
  if (!PHASE_SET.has(phase) || !OUTCOME_SET.has(outcome)) {
    throw new Error("workflow_phase received an unsupported phase or outcome");
  }
  return { phase, outcome };
}

function normalizeKnowledgeParams(params) {
  const operation = typeof params?.operation === "string" ? params.operation : "";
  const request = params?.request;
  if (!KNOWLEDGE_OPERATION_SET.has(operation) || !request || typeof request !== "object" || Array.isArray(request)) {
    throw new Error("knowledge_retrieval received an unsupported operation or request");
  }
  if (operation === "discover") {
    return {
      operation,
      request: {
        objective: request.objective,
        ...(request.filters === undefined ? {} : { filters: request.filters }),
        ...(request.limit === undefined ? {} : { limit: request.limit }),
      },
    };
  }
  return { operation, request: { reference: request.reference } };
}

function readWrapperExecutionParams(params) {
  const skillName = typeof params?.skill_name === "string" ? params.skill_name : "";
  const wrapperInput = typeof params?.wrapper === "string" ? params.wrapper : "";
  const operationInput = typeof params?.operation === "string" ? params.operation : "";
  const requestedPhase = typeof params?.phase === "string" ? params.phase : "";
  const outcome = typeof params?.outcome === "string" ? params.outcome : "";
  const errorCode = typeof params?.error_code === "string" ? params.error_code : "";
  const durationMs = params?.duration_ms ?? 0;
  const retryCount = params?.retry_count ?? 0;
  const lifecycleMethod = requestedPhase ? "explicit_pair" : "legacy_terminal";
  const phase = requestedPhase || "finish";
  const lifecycleValid =
    (phase === "start" && outcome === "started") ||
    (phase === "finish" && outcome !== "started");
  if (
    !SKILL_ID_RE.test(skillName) ||
    !WRAPPER_ID_RE.test(wrapperInput) ||
    !WRAPPER_ID_RE.test(operationInput) ||
    !WRAPPER_PHASE_SET.has(phase) ||
    !WRAPPER_OUTCOME_SET.has(outcome) ||
    !LIFECYCLE_METHODS.includes(lifecycleMethod) ||
    !lifecycleValid ||
    (lifecycleMethod === "legacy_terminal" && !["success", "error"].includes(outcome)) ||
    (outcome === "error" && !WRAPPER_ERROR_CODE_SET.has(errorCode)) ||
    (outcome !== "error" && errorCode !== "") ||
    !Number.isInteger(durationMs) ||
    durationMs < 0 ||
    durationMs > 3_600_000 ||
    !Number.isInteger(retryCount) ||
    retryCount < 0 ||
    retryCount > 100
  ) {
    throw new Error("wrapper_execution received unsupported bounded metadata");
  }
  return {
    skillName,
    wrapper: canonicalLifecycleId(wrapperInput),
    operation: canonicalLifecycleId(operationInput),
    phase,
    outcome,
    errorCode,
    durationMs,
    retryCount,
    lifecycleMethod,
  };
}

function readSkillExecutionParams(params) {
  const skillName = typeof params?.skill_name === "string" ? params.skill_name : "";
  const phase = typeof params?.phase === "string" ? params.phase : "";
  const outcome = typeof params?.outcome === "string" ? params.outcome : "";
  const attributionMethod =
    typeof params?.attribution_method === "string" ? params.attribution_method : "";
  const lifecycleValid =
    (phase === "start" && outcome === "started") ||
    (phase === "finish" && outcome !== "started");
  if (
    !SKILL_ID_RE.test(skillName) ||
    !SKILL_PHASE_SET.has(phase) ||
    !SKILL_OUTCOME_SET.has(outcome) ||
    !SKILL_MARKER_ATTRIBUTION_METHOD_SET.has(attributionMethod) ||
    !lifecycleValid
  ) {
    throw new Error("skill_execution received unsupported bounded metadata");
  }
  return { skillName, phase, outcome, attributionMethod };
}

function boundedDuration(value) {
  if (!Number.isFinite(value)) return 0;
  return Math.min(Math.max(Math.round(value), 0), 3_600_000);
}

function rememberKnowledgeMetadata(toolCallId, operation, result) {
  if (!toolCallId) return;
  const mode =
    operation === "fetch"
      ? "direct"
      : result?.mode === "hybrid"
        ? "hybrid"
        : result?.mode === "lexical_fallback"
          ? "lexical"
          : "unknown";
  const fallbackReason = SAFE_ERROR_CODE_RE.test(result?.fallbackReason ?? "")
    ? result.fallbackReason
    : undefined;
  const snapshot = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/u.test(result?.snapshotSetHash ?? "")
    ? result.snapshotSetHash
    : undefined;
  const resultCount =
    operation === "fetch"
      ? 1
      : Array.isArray(result?.candidates)
        ? Math.min(result.candidates.length, 10_000)
        : 0;
  if (knowledgeMetadataByCall.size >= 1024) {
    knowledgeMetadataByCall.delete(knowledgeMetadataByCall.keys().next().value);
  }
  knowledgeMetadataByCall.set(toolCallId, { mode, fallbackReason, snapshot, resultCount });
}

function safeKnowledgeError(stderr) {
  try {
    const parsed = JSON.parse(stderr);
    return isToolFailureCategory(parsed?.error_code) ? parsed.error_code : "unknown";
  } catch {
    return "unknown";
  }
}

function runKnowledgeClient(operation, request, signal) {
  const workspace = process.env.OPENCLAW_AGENT_WORKSPACE ?? "";
  const script = path.join(
    workspace,
    "skills",
    "knowledge-retrieval",
    "scripts",
    "knowledge-retrieval.mjs",
  );
  return new Promise((resolve, reject) => {
    let stdout = "";
    let stderr = "";
    let outputBytes = 0;
    let settled = false;
    const child = spawn(process.execPath, [script, operation], {
      stdio: ["pipe", "pipe", "pipe"],
      signal,
    });
    const finish = (callback) => {
      if (settled) return;
      settled = true;
      callback();
    };
    child.stdout.on("data", (chunk) => {
      outputBytes += chunk.length;
      if (outputBytes > MAX_KNOWLEDGE_OUTPUT_BYTES) {
        child.kill();
        finish(() => reject(new Error("knowledge_retrieval:upstream_contract_mismatch")));
        return;
      }
      stdout += chunk.toString("utf8");
    });
    child.stderr.on("data", (chunk) => {
      if (stderr.length < 4096) {
        stderr = `${stderr}${chunk.toString("utf8")}`.slice(0, 4096);
      }
    });
    child.stdin.on("error", () => {
      finish(() => reject(new Error("knowledge_retrieval:dependency_unavailable")));
    });
    child.on("error", () => {
      finish(() => reject(new Error("knowledge_retrieval:dependency_unavailable")));
    });
    child.on("close", (code) => {
      if (code !== 0) {
        finish(() => reject(new Error(`knowledge_retrieval:${safeKnowledgeError(stderr.trim())}`)));
        return;
      }
      try {
        const parsed = JSON.parse(stdout);
        finish(() => resolve(parsed));
      } catch {
        finish(() => reject(new Error("knowledge_retrieval:parse_failure")));
      }
    });
    child.stdin.end(JSON.stringify(request));
  });
}

export default definePluginEntry({
  id: PLUGIN_ID,
  name: "Behavioral Observability",
  description: "Metadata-only correlated tool, workflow, knowledge, wrapper, and skill telemetry",
  register(api) {
    api.registerService(createTelemetryService());

    api.registerTool(
      (toolContext) => ({
        name: WORKFLOW_TOOL_NAME,
        label: "Workflow Phase",
        description:
          "Record one bounded workflow transition. Do not include rationale, content, paths, task or resource identifiers, tool inputs, or tool outputs.",
        parameters: {
          type: "object",
          additionalProperties: false,
          required: ["phase", "outcome"],
          properties: {
            phase: { type: "string", enum: PHASES },
            outcome: { type: "string", enum: OUTCOMES },
          },
        },
        async execute(toolCallId, params) {
          const marker = readBoundedParams(params);
          const context = pluginToolRunContext(toolContext);
          if (isFirstToolHook("workflow", { toolCallId }, context)) {
            emitPhase(api, {
              phase: marker.phase,
              outcome: marker.outcome,
              attributionMethod: "explicit_marker",
              context,
            });
          }
          return jsonResult(marker);
        },
      }),
      { name: WORKFLOW_TOOL_NAME },
    );

    api.registerTool(
      (toolContext) => ({
        name: KNOWLEDGE_TOOL_NAME,
        catalogMode: "direct-only",
        label: "Knowledge Retrieval",
        description:
          "Discover or fetch authoritative internal knowledge through the installed canonical client.",
        parameters: {
          type: "object",
          additionalProperties: false,
          required: ["operation", "request"],
          properties: {
            operation: { type: "string", enum: KNOWLEDGE_OPERATIONS },
            request: {
              type: "object",
              additionalProperties: false,
              properties: {
                objective: { type: "string", minLength: 2, maxLength: 2000 },
                filters: {
                  type: "object",
                  additionalProperties: false,
                  properties: Object.fromEntries(
                    ["repositories", "types", "statuses", "owners", "tags"].map(
                      (name) => [
                        name,
                        {
                          type: "array",
                          maxItems: 20,
                          uniqueItems: true,
                          items: { type: "string", minLength: 1, maxLength: 128 },
                        },
                      ],
                    ),
                  ),
                },
                limit: { type: "integer", minimum: 1, maximum: 20 },
                reference: { type: "string", minLength: 64, maxLength: 4096 },
              },
            },
          },
        },
        async execute(toolCallId, params, signal) {
          const { operation, request } = normalizeKnowledgeParams(params);
          const startedAt = Date.now();
          const context = pluginToolRunContext(toolContext);
          try {
            const result = await runKnowledgeClient(operation, request, signal);
            rememberKnowledgeMetadata(toolCallId, operation, result);
            const metadata = toolCallId ? knowledgeMetadataByCall.get(toolCallId) : undefined;
            if (isFirstToolHook("knowledge", { toolCallId }, context)) {
              emitKnowledgeAccess(api, {
                operation,
                outcome:
                  metadata?.resultCount === 0 && operation === "discover"
                    ? "empty"
                    : "success",
                durationMs: Date.now() - startedAt,
                metadata,
                context,
              });
              emitKnowledgeDecision(api, {
                decision: "invoked",
                evidenceMethod: "tool_outcome",
                context,
              });
            }
            if (toolCallId) knowledgeMetadataByCall.delete(toolCallId);
            return jsonResult({ ...result, ok: true });
          } catch (error) {
            if (isFirstToolHook("knowledge", { toolCallId }, context)) {
              emitKnowledgeAccess(api, {
                operation,
                outcome: "error",
                durationMs: Date.now() - startedAt,
                context,
              });
              emitKnowledgeDecision(api, {
                decision: "failed",
                evidenceMethod: "tool_outcome",
                context,
                error: true,
              });
            }
            throw error;
          }
        },
      }),
      { name: KNOWLEDGE_TOOL_NAME },
    );

    api.registerTool(
      (toolContext) => ({
        name: KNOWLEDGE_DECISION_TOOL_NAME,
        catalogMode: "direct-only",
        label: "Knowledge Decision",
        description:
          "Record only an explicit bounded decision that Knowledge Base retrieval is not needed or its canonical client was considered but unavailable. Never include rationale or task content.",
        parameters: {
          type: "object",
          additionalProperties: false,
          required: ["decision"],
          properties: {
            decision: { type: "string", enum: KNOWLEDGE_DECISIONS },
          },
        },
        async execute(toolCallId, params) {
          const marker = readKnowledgeDecisionParams(params);
          const context = pluginToolRunContext(toolContext);
          if (isFirstToolHook("knowledge-decision", { toolCallId }, context)) {
            emitKnowledgeDecision(api, {
              decision: marker.decision,
              evidenceMethod: "explicit_marker",
              context,
            });
          }
          return jsonResult(marker);
        },
      }),
      { name: KNOWLEDGE_DECISION_TOOL_NAME },
    );

    api.registerTool(
      (toolContext) => ({
        name: WRAPPER_EXECUTION_TOOL_NAME,
        catalogMode: "direct-only",
        label: "Wrapper Execution",
        description:
          "Record the start or terminal finish of one skill-owned wrapper with stable skill, wrapper, and operation IDs plus a bounded error code only for errors. Never include error text or paths.",
        parameters: {
          type: "object",
          additionalProperties: false,
          required: ["skill_name", "wrapper", "operation", "outcome"],
          properties: {
            skill_name: { type: "string", pattern: SKILL_ID_RE.source, maxLength: 63 },
            wrapper: { type: "string", pattern: WRAPPER_ID_RE.source, maxLength: 64 },
            operation: { type: "string", pattern: WRAPPER_ID_RE.source, maxLength: 64 },
            phase: { type: "string", enum: WRAPPER_PHASES },
            outcome: { type: "string", enum: WRAPPER_OUTCOMES },
            error_code: { type: "string", enum: WRAPPER_ERROR_CODES },
            duration_ms: { type: "integer", minimum: 0, maximum: 3600000 },
            retry_count: { type: "integer", minimum: 0, maximum: 100 },
          },
        },
        async execute(toolCallId, params) {
          const marker = readWrapperExecutionParams(params);
          const context = pluginToolRunContext(toolContext);
          if (isFirstToolHook("wrapper", { toolCallId }, context)) {
            emitWrapperExecution(api, { marker, context });
          }
          return jsonResult(marker);
        },
      }),
      { name: WRAPPER_EXECUTION_TOOL_NAME },
    );

    api.registerTool(
      (toolContext) => ({
        name: SKILL_EXECUTION_TOOL_NAME,
        catalogMode: "direct-only",
        label: "Skill Execution",
        description:
          "Record the start or finish of one actually executed skill using explicit wrapper or declared marker attribution. Never infer use or include task content.",
        parameters: {
          type: "object",
          additionalProperties: false,
          required: ["skill_name", "phase", "outcome", "attribution_method"],
          properties: {
            skill_name: { type: "string", pattern: SKILL_ID_RE.source, maxLength: 63 },
            phase: { type: "string", enum: SKILL_PHASES },
            outcome: { type: "string", enum: SKILL_OUTCOMES },
            attribution_method: {
              type: "string",
              enum: SKILL_MARKER_ATTRIBUTION_METHODS,
            },
          },
        },
        async execute(toolCallId, params) {
          const marker = readSkillExecutionParams(params);
          const context = pluginToolRunContext(toolContext);
          if (isFirstToolHook("skill", { toolCallId }, context)) {
            emitSkillExecution(api, { marker, context });
          }
          return jsonResult(marker);
        },
      }),
      { name: SKILL_EXECUTION_TOOL_NAME },
    );

    api.on("before_prompt_build", () => {
      return { prependSystemContext: OBSERVABILITY_GUIDANCE };
    });

    api.on("before_agent_run", (event, context) => {
      resolveRunTrafficSource(event, context, event?.senderIsOwner);
    });

    api.on("llm_input", (event, context) => {
      resolveRunTrafficSource(event, context);
      beginRunSpans(api, event, context);
    });

    api.on("model_call_started", (event, context) => {
      resolveRunTrafficSource(event, context);
      beginModelAttempt(api, event, context);
      emitPlanOnce(api, context);
    });

    api.on("model_call_ended", (event, context) => {
      finishModelAttempt(api, event, context);
    });

    api.on("llm_output", (event, context) => {
      finishModelUsage(api, event, context);
    });

    api.on("before_agent_finalize", (event, context) => {
      resolveRunTrafficSource(event, context);
      beginRunSpans(api, event, context);
      emitPlanOnce(api, context);
      emitPhase(api, {
        phase: "deliver",
        outcome: "started",
        attributionMethod: "automatic_hook",
        context,
      });
    });

    api.on(
      "after_tool_call",
      (event, context) => {
        if (!isFirstToolHook("workflow", event, context)) return;
        try {
          const { phase, outcome } = readBoundedParams(event.params);
          emitPhase(api, {
            phase,
            outcome,
            attributionMethod: "explicit_marker",
            context,
          });
        } catch (error) {
          api.logger.warn(`behavioral observability workflow marker failed: ${String(error)}`);
        }
      },
      { matcher: [WORKFLOW_TOOL_NAME] },
    );

    api.on(
      "after_tool_call",
      (event, context) => {
        if (!isFirstToolHook("knowledge", event, context)) return;
        const operation =
          typeof event.params?.operation === "string" ? event.params.operation : "";
        const metadata = event.toolCallId
          ? knowledgeMetadataByCall.get(event.toolCallId)
          : undefined;
        if (event.toolCallId) knowledgeMetadataByCall.delete(event.toolCallId);
        emitKnowledgeAccess(api, {
          operation,
          outcome: event.error
            ? "error"
            : metadata?.resultCount === 0 && operation === "discover"
              ? "empty"
              : "success",
          durationMs: event.durationMs,
          metadata,
          context,
        });
        emitKnowledgeDecision(api, {
          decision: event.error ? "failed" : "invoked",
          evidenceMethod: "tool_outcome",
          context,
          error: Boolean(event.error),
        });
      },
      { matcher: [KNOWLEDGE_TOOL_NAME] },
    );

    api.on(
      "after_tool_call",
      (event, context) => {
        if (!isFirstToolHook("knowledge-decision", event, context)) return;
        try {
          const marker = readKnowledgeDecisionParams(event.params);
          emitKnowledgeDecision(api, {
            decision: marker.decision,
            evidenceMethod: "explicit_marker",
            context,
          });
        } catch (error) {
          api.logger.warn(`behavioral observability knowledge decision failed: ${String(error)}`);
        }
      },
      { matcher: [KNOWLEDGE_DECISION_TOOL_NAME] },
    );

    api.on(
      "after_tool_call",
      (event, context) => {
        if (!isFirstToolHook("wrapper", event, context)) return;
        try {
          const marker = readWrapperExecutionParams(event.params);
          emitWrapperExecution(api, { marker, context });
        } catch (error) {
          api.logger.warn(`behavioral observability wrapper marker failed: ${String(error)}`);
        }
      },
      { matcher: [WRAPPER_EXECUTION_TOOL_NAME] },
    );

    api.on(
      "after_tool_call",
      (event, context) => {
        if (!isFirstToolHook("skill", event, context)) return;
        try {
          const marker = readSkillExecutionParams(event.params);
          emitSkillExecution(api, { marker, context });
        } catch (error) {
          api.logger.warn(`behavioral observability skill marker failed: ${String(error)}`);
        }
      },
      { matcher: [SKILL_EXECUTION_TOOL_NAME] },
    );

    api.on("after_tool_call", (event, context) => {
      if (!isFirstToolHook("tool", event, context)) return;
      emitToolExecution(api, { event, context });
    });

    api.on("agent_end", (event, context) => {
      resolveRunTrafficSource(event, context);
      beginRunSpans(api, event, context);
      emitPlanOnce(api, context);
      emitPhase(api, {
        phase: "deliver",
        outcome: event.success ? "completed" : "error",
        attributionMethod: "automatic_hook",
        context,
      });
      finishRunSpans(api, event, context);
      clearAuxiliaryRunState(event.runId ?? context.runId, {
        sessionKey: event?.sessionKey ?? context?.sessionKey,
        sessionId: event?.sessionId ?? context?.sessionId,
      });
    });
  },
});
