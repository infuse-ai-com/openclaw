const INTERNAL_MODEL_ALIAS_RE = /^gpt-[0-9]+(?:\.[0-9]+)?-(?:astra|luna|sol|terra)$/u;

export function modelPricingStatus(model) {
  return INTERNAL_MODEL_ALIAS_RE.test(model ?? "") ? "unpriced" : "catalog";
}

export function normalizedUsageDetails(usage) {
  if (!usage || typeof usage !== "object") return undefined;
  const details = {};
  for (const [source, target] of [
    ["input", "input"],
    ["output", "output"],
    ["cacheRead", "cache_read_input_tokens"],
    ["cacheWrite", "cache_write_input_tokens"],
    ["total", "total"],
  ]) {
    const value = usage[source];
    if (Number.isFinite(value) && value >= 0) details[target] = Math.trunc(value);
  }
  return Object.keys(details).length > 0 ? details : undefined;
}

export function normalizedHookUsageDetails(event) {
  return (
    normalizedUsageDetails(event?.usage) ??
    normalizedUsageDetails(event?.lastAssistant?.usage)
  );
}
