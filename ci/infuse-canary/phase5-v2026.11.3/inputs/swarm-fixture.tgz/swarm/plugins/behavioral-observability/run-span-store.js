const RUN_ID_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u;

export function isSafeRunId(value) {
  return typeof value === "string" && RUN_ID_RE.test(value);
}

export class RunSpanStore {
  constructor(maxEntries = 1024) {
    if (!Number.isInteger(maxEntries) || maxEntries < 1) {
      throw new TypeError("RunSpanStore maxEntries must be a positive integer");
    }
    this.maxEntries = maxEntries;
    this.entries = new Map();
  }

  begin(runId, state) {
    if (!isSafeRunId(runId) || !state) {
      return { state: undefined, inserted: false, evicted: undefined };
    }
    const existing = this.entries.get(runId);
    if (existing) {
      return { state: existing, inserted: false, evicted: undefined };
    }
    let evicted;
    if (this.entries.size >= this.maxEntries) {
      const oldestRunId = this.entries.keys().next().value;
      evicted = this.entries.get(oldestRunId);
      this.entries.delete(oldestRunId);
    }
    this.entries.set(runId, state);
    return { state, inserted: true, evicted };
  }

  get(runId) {
    return isSafeRunId(runId) ? this.entries.get(runId) : undefined;
  }

  take(runId) {
    if (!isSafeRunId(runId)) return undefined;
    const state = this.entries.get(runId);
    this.entries.delete(runId);
    return state;
  }

  drain() {
    const states = [...this.entries.values()];
    this.entries.clear();
    return states;
  }
}
