export const TRAFFIC_SOURCES = Object.freeze([
  "human",
  "automation",
  "smoke",
  "startup",
  "unavailable",
]);

const AUTOMATION_TRIGGERS = new Set(["cron", "heartbeat"]);
const CONTROLLED_SESSION_RE = /(?:^|:)(smoke|startup)-[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/u;

function controlledSessionSource(sessionKey) {
  if (typeof sessionKey !== "string" || sessionKey.length > 160) return undefined;
  return CONTROLLED_SESSION_RE.exec(sessionKey)?.[1];
}

export function classifyTrafficSource({
  trigger,
  channel,
  messageProvider,
  sessionKey,
  senderIsOwner,
  inputProvenanceKind,
} = {}) {
  if (AUTOMATION_TRIGGERS.has(trigger)) return "automation";

  const hasChannel =
    (typeof channel === "string" && channel.length > 0) ||
    (typeof messageProvider === "string" && messageProvider.length > 0);
  if ((trigger === "user" || inputProvenanceKind === "external_user") && hasChannel) {
    return "human";
  }

  if (!hasChannel && senderIsOwner !== true) {
    const controlledSource = controlledSessionSource(sessionKey);
    if (controlledSource) return controlledSource;
  }
  return "unavailable";
}

export function preferTrafficSource(current, candidate) {
  if (TRAFFIC_SOURCES.includes(current) && current !== "unavailable") return current;
  return TRAFFIC_SOURCES.includes(candidate) ? candidate : "unavailable";
}

export class TrafficSourceStore {
  constructor(maximum = 1024) {
    this.maximum = Math.max(1, maximum);
    this.entries = new Map();
  }

  remember(runId, source) {
    this.#rememberKey(this.#boundedKey("run", runId), source);
  }

  rememberContext({ sessionKey, sessionId } = {}, source) {
    this.#rememberKey(this.#boundedKey("session-key", sessionKey), source);
    this.#rememberKey(this.#boundedKey("session-id", sessionId), source);
  }

  #boundedKey(kind, value) {
    return typeof value === "string" && value.length > 0 && value.length <= 256
      ? `${kind}\u0000${value}`
      : undefined;
  }

  #rememberKey(key, source) {
    if (!key || !TRAFFIC_SOURCES.includes(source) || source === "unavailable") return;
    this.entries.delete(key);
    while (this.entries.size >= this.maximum) {
      this.entries.delete(this.entries.keys().next().value);
    }
    this.entries.set(key, source);
  }

  get(runId) {
    return this.entries.get(this.#boundedKey("run", runId)) ?? "unavailable";
  }

  getContext({ sessionKey, sessionId } = {}) {
    return preferTrafficSource(
      this.entries.get(this.#boundedKey("session-key", sessionKey)),
      this.entries.get(this.#boundedKey("session-id", sessionId)),
    );
  }

  delete(runId) {
    this.entries.delete(this.#boundedKey("run", runId));
  }

  deleteContext({ sessionKey, sessionId } = {}) {
    this.entries.delete(this.#boundedKey("session-key", sessionKey));
    this.entries.delete(this.#boundedKey("session-id", sessionId));
  }

  clear() {
    this.entries.clear();
  }
}
