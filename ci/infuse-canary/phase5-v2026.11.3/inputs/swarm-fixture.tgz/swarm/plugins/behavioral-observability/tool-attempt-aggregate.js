const AGGREGATED_TOOLS = new Set(["studio_whiteboard_apply"]);
const MAX_ATTEMPTS = 1000;
const MAX_DURATION_MS = 86_400_000;

export function shouldAggregateTool(toolName) {
  return AGGREGATED_TOOLS.has(toolName);
}

export function recordToolAttempt(aggregates, toolName, classification, durationMs) {
  if (!aggregates || !shouldAggregateTool(toolName)) return false;
  const current = aggregates.get(toolName) ?? {
    toolName,
    attempts: 0,
    errors: 0,
    durationMs: 0,
    failureCounts: new Map(),
  };
  current.attempts = Math.min(current.attempts + 1, MAX_ATTEMPTS);
  current.durationMs = Math.min(
    current.durationMs + (Number.isFinite(durationMs) && durationMs > 0 ? durationMs : 0),
    MAX_DURATION_MS,
  );
  if (classification?.outcome === "error") {
    current.errors = Math.min(current.errors + 1, MAX_ATTEMPTS);
    const category = classification.failureCategory ?? "unknown";
    current.failureCounts.set(
      category,
      Math.min((current.failureCounts.get(category) ?? 0) + 1, MAX_ATTEMPTS),
    );
  }
  aggregates.set(toolName, current);
  return true;
}

function dominantFailureCategory(failureCounts) {
  return [...failureCounts.entries()].sort(
    ([leftName, leftCount], [rightName, rightCount]) =>
      rightCount - leftCount || leftName.localeCompare(rightName),
  )[0]?.[0];
}

export function drainToolAttemptAggregates(aggregates) {
  if (!aggregates) return [];
  const summaries = [...aggregates.values()]
    .sort((left, right) => left.toolName.localeCompare(right.toolName))
    .map((aggregate) => ({
      toolName: aggregate.toolName,
      outcome: aggregate.errors === aggregate.attempts ? "error" : "success",
      attemptCount: aggregate.attempts,
      retryCount: Math.max(aggregate.attempts - 1, 0),
      errorCount: aggregate.errors,
      durationMs: Math.trunc(aggregate.durationMs),
      failureCategory: dominantFailureCategory(aggregate.failureCounts),
    }));
  aggregates.clear();
  return summaries;
}
