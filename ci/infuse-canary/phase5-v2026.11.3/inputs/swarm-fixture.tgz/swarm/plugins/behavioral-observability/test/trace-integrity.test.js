import assert from "node:assert/strict";
import test from "node:test";

import {
  orphanIntegrityAttributes,
  traceIntegrityAttributes,
  turnAnomalyTypes,
  TURN_ANOMALY_THRESHOLDS,
} from "../trace-integrity.js";

test("closed turns declare one parentless root with unique attached children", () => {
  assert.deepEqual(traceIntegrityAttributes("completed"), {
    integrity_state: "valid",
    root_state: "single",
    parent_state: "parentless",
    child_state: "attached_unique",
    closure_state: "completed",
  });
  assert.equal(traceIntegrityAttributes("shutdown").integrity_state, "incomplete");
});

test("a prevented orphan attempt has bounded metadata and no identifier", () => {
  assert.deepEqual(orphanIntegrityAttributes(), {
    integrity_state: "orphan_child",
    root_state: "unavailable",
    parent_state: "missing",
    child_state: "orphan",
    closure_state: "unavailable",
  });
});

test("turn anomaly thresholds are exact, deterministic, and independently additive", () => {
  assert.deepEqual(TURN_ANOMALY_THRESHOLDS, {
    slowTurnDurationMs: 60_000,
    excessiveToolCount: 50,
    repeatedFailureCount: 3,
    largeTraceChildCount: 100,
  });
  assert.deepEqual(
    turnAnomalyTypes({
      durationMs: 60_000,
      toolCount: 50,
      failureCount: 3,
      childCount: 100,
      closureState: "evicted",
    }),
    [
      "slow_turn",
      "excessive_tools",
      "repeated_failures",
      "incomplete_turn",
      "large_trace",
    ],
  );
  assert.deepEqual(
    turnAnomalyTypes({
      durationMs: 59_999,
      toolCount: 49,
      failureCount: 2,
      childCount: 99,
      closureState: "completed",
    }),
    [],
  );
});
