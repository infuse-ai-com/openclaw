const MAX_OPEN_LIFECYCLES_PER_KEY = 100;

export const LIFECYCLE_TYPES = Object.freeze(["skill", "wrapper"]);
export const LIFECYCLE_STATES = Object.freeze([
  "started",
  "complete",
  "unmatched_finish",
  "incomplete_start",
]);
export const LIFECYCLE_METHODS = Object.freeze(["explicit_pair", "legacy_terminal"]);

export function canonicalLifecycleId(value) {
  return typeof value === "string" ? value.replaceAll("_", "-") : "";
}

function lifecycleMap(state, lifecycleType) {
  if (!state.lifecycleOpen) {
    state.lifecycleOpen = {
      skill: new Map(),
      wrapper: new Map(),
    };
  }
  return state.lifecycleOpen[lifecycleType];
}

export function recordLifecycle(state, lifecycleType, key, descriptor, phase) {
  if (!state || !LIFECYCLE_TYPES.includes(lifecycleType) || !key) {
    return "unmatched_finish";
  }
  const open = lifecycleMap(state, lifecycleType);
  const current = open.get(key);
  if (phase === "start") {
    const count = Math.min((current?.count ?? 0) + 1, MAX_OPEN_LIFECYCLES_PER_KEY);
    open.set(key, { count, descriptor });
    return "started";
  }
  if (!current || current.count < 1) {
    return "unmatched_finish";
  }
  if (current.count === 1) {
    open.delete(key);
  } else {
    open.set(key, { ...current, count: current.count - 1 });
  }
  return "complete";
}

export function drainIncompleteLifecycles(state) {
  if (!state?.lifecycleOpen) return [];
  const incomplete = [];
  for (const lifecycleType of LIFECYCLE_TYPES) {
    const open = state.lifecycleOpen[lifecycleType];
    for (const { count, descriptor } of open.values()) {
      incomplete.push({
        lifecycleType,
        lifecycleState: "incomplete_start",
        incompleteCount: count,
        ...descriptor,
      });
    }
    open.clear();
  }
  return incomplete;
}
