export const TRACE_CLOSURE_STATES = Object.freeze([
  "completed",
  "error",
  "evicted",
  "shutdown",
  "start_failed",
]);

export const TURN_ANOMALY_TYPES = Object.freeze([
  "slow_turn",
  "excessive_tools",
  "repeated_failures",
  "incomplete_turn",
  "large_trace",
]);

export const TURN_ANOMALY_THRESHOLDS = Object.freeze({
  slowTurnDurationMs: 60_000,
  excessiveToolCount: 50,
  repeatedFailureCount: 3,
  largeTraceChildCount: 100,
});

const CLOSED_STATES = new Set(["completed", "error"]);
const CLOSURE_STATE_SET = new Set(TRACE_CLOSURE_STATES);

function boundedCount(value) {
  return Number.isInteger(value) && value >= 0 ? Math.min(value, 3_600_000) : 0;
}

export function traceIntegrityAttributes(closureState) {
  const safeClosureState = CLOSURE_STATE_SET.has(closureState)
    ? closureState
    : "start_failed";
  return {
    integrity_state: CLOSED_STATES.has(safeClosureState) ? "valid" : "incomplete",
    root_state: "single",
    parent_state: "parentless",
    child_state: "attached_unique",
    closure_state: safeClosureState,
  };
}

export function orphanIntegrityAttributes() {
  return {
    integrity_state: "orphan_child",
    root_state: "unavailable",
    parent_state: "missing",
    child_state: "orphan",
    closure_state: "unavailable",
  };
}

export function turnAnomalyTypes({
  durationMs,
  toolCount,
  failureCount,
  childCount,
  closureState,
}) {
  const anomalies = [];
  if (boundedCount(durationMs) >= TURN_ANOMALY_THRESHOLDS.slowTurnDurationMs) {
    anomalies.push("slow_turn");
  }
  if (boundedCount(toolCount) >= TURN_ANOMALY_THRESHOLDS.excessiveToolCount) {
    anomalies.push("excessive_tools");
  }
  if (
    boundedCount(failureCount) >= TURN_ANOMALY_THRESHOLDS.repeatedFailureCount
  ) {
    anomalies.push("repeated_failures");
  }
  if (!CLOSED_STATES.has(closureState)) anomalies.push("incomplete_turn");
  if (boundedCount(childCount) >= TURN_ANOMALY_THRESHOLDS.largeTraceChildCount) {
    anomalies.push("large_trace");
  }
  return anomalies;
}
