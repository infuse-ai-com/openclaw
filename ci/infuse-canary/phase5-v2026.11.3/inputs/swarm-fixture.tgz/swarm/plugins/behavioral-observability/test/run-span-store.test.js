import assert from "node:assert/strict";
import test from "node:test";

import { RunSpanStore, isSafeRunId } from "../run-span-store.js";

test("run identifiers are accepted only as bounded in-memory lookup keys", () => {
  assert.equal(isSafeRunId("run-a:17"), true);
  assert.equal(isSafeRunId(""), false);
  assert.equal(isSafeRunId("a".repeat(129)), false);
  assert.equal(isSafeRunId("contains a space"), false);
});

test("one run keeps one state and never replaces its parent", () => {
  const store = new RunSpanStore(2);
  const first = { name: "first" };
  const replacement = { name: "replacement" };
  assert.deepEqual(store.begin("run-a", first), {
    state: first,
    inserted: true,
    evicted: undefined,
  });
  assert.deepEqual(store.begin("run-a", replacement), {
    state: first,
    inserted: false,
    evicted: undefined,
  });
  assert.equal(store.get("run-a"), first);
});

test("capacity eviction, take, drain, and cross-run isolation are deterministic", () => {
  const store = new RunSpanStore(1);
  const first = { name: "first" };
  const second = { name: "second" };
  store.begin("run-a", first);
  assert.deepEqual(store.begin("run-b", second), {
    state: second,
    inserted: true,
    evicted: first,
  });
  assert.equal(store.get("run-a"), undefined);
  assert.equal(store.take("run-b"), second);
  assert.equal(store.get("run-b"), undefined);
  store.begin("run-c", first);
  assert.deepEqual(store.drain(), [first]);
  assert.deepEqual(store.drain(), []);
});
