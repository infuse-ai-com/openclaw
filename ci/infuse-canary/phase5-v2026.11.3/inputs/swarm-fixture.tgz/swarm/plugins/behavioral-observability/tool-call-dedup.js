const TOOL_NAME_RE = /^[a-z0-9][a-z0-9._-]{0,63}$/u;
const DYNAMIC_TOOL_ALIAS_PREFIX = "openclaw";
const STATIC_TOOL_ALIASES = new Map([["bash", "exec"]]);

function boundedLookupKey(value) {
  return typeof value === "string" && value.length > 0 && value.length <= 256
    ? value
    : undefined;
}

export function canonicalToolName(value) {
  if (!TOOL_NAME_RE.test(value ?? "")) return "unknown";
  const staticAlias = STATIC_TOOL_ALIASES.get(value);
  if (staticAlias) return staticAlias;
  if (
    value.startsWith(DYNAMIC_TOOL_ALIAS_PREFIX) &&
    value.length > DYNAMIC_TOOL_ALIAS_PREFIX.length
  ) {
    const canonical = value.slice(DYNAMIC_TOOL_ALIAS_PREFIX.length);
    if (!TOOL_NAME_RE.test(canonical)) return value;
    return STATIC_TOOL_ALIASES.get(canonical) ?? canonical;
  }
  return value;
}

export class ToolCallDeduplicator {
  constructor(maxEntries = 1024) {
    if (!Number.isInteger(maxEntries) || maxEntries < 1) {
      throw new TypeError("ToolCallDeduplicator maxEntries must be a positive integer");
    }
    this.maxEntries = maxEntries;
    this.entries = new Map();
  }

  shouldEmit(scope, { runId, toolCallId } = {}) {
    const safeScope = boundedLookupKey(scope);
    const safeToolCallId = boundedLookupKey(toolCallId);
    if (!safeScope || !safeToolCallId) return true;
    const safeRunId = boundedLookupKey(runId) ?? "";
    const key = `${safeScope}\u0000${safeRunId}\u0000${safeToolCallId}`;
    if (this.entries.has(key)) return false;
    while (this.entries.size >= this.maxEntries) {
      this.entries.delete(this.entries.keys().next().value);
    }
    this.entries.set(key, safeRunId);
    return true;
  }

  clearRun(runId) {
    const safeRunId = boundedLookupKey(runId);
    if (!safeRunId) return;
    for (const [key, entryRunId] of this.entries) {
      if (entryRunId === safeRunId) this.entries.delete(key);
    }
  }

  clear() {
    this.entries.clear();
  }
}
