import assert from "node:assert/strict";
import test from "node:test";

import {
  TOOL_FAILURE_CATEGORIES,
  classifyDynamicToolError,
  classifyToolHookEvent,
  inspectedErrorLimit,
} from "../failure-taxonomy.js";

test("the failure taxonomy is exact and bounded", () => {
  assert.deepEqual(TOOL_FAILURE_CATEGORIES, [
    "aborted",
    "authentication_unavailable",
    "authorization_denied",
    "dependency_unavailable",
    "internal_error",
    "invalid_input",
    "nonzero_exit",
    "parse_failure",
    "permission_denied",
    "policy_denied",
    "protocol_conversion",
    "runtime_error",
    "timeout",
    "unknown",
    "upstream_contract_mismatch",
    "upstream_unavailable",
  ]);
  assert.equal(inspectedErrorLimit(), 4096);
});

test("thrown hook errors classify stable remediation causes", () => {
  assert.deepEqual(classifyToolHookEvent({ error: "request timed out" }), {
    outcome: "error",
    failureCategory: "timeout",
    classificationSource: "tool_hook_error",
  });
  assert.equal(
    classifyToolHookEvent({ error: "structured result could not convert" }).failureCategory,
    "protocol_conversion",
  );
  assert.equal(
    classifyToolHookEvent({ error: "invalid argument: missing required field" }).failureCategory,
    "invalid_input",
  );
  assert.equal(
    classifyToolHookEvent({ error: "OpenClaw dynamic tool call failed." }).failureCategory,
    "unknown",
  );
  assert.equal(
    classifyToolHookEvent({ error: "TypeError: value is not a function" }).failureCategory,
    "runtime_error",
  );
  assert.equal(
    classifyToolHookEvent({ error: "knowledge_retrieval:invalid_input" }).failureCategory,
    "invalid_input",
  );
  assert.equal(
    classifyToolHookEvent({ error: "knowledge_retrieval:internal_error" }).failureCategory,
    "internal_error",
  );
});

test("structured result fields outrank free text and cover shell outcomes", () => {
  assert.equal(
    classifyToolHookEvent({
      result: {
        details: { status: "failed", exitCode: 17, error: "permission denied" },
      },
    }).failureCategory,
    "nonzero_exit",
  );
  assert.equal(
    classifyToolHookEvent({ result: { details: { status: "blocked" } } }).failureCategory,
    "policy_denied",
  );
  assert.equal(
    classifyToolHookEvent({ result: { details: { timedOut: true } } }).failureCategory,
    "timeout",
  );
  assert.equal(
    classifyToolHookEvent({ result: { details: { ok: false, timedOut: true } } })
      .failureCategory,
    "timeout",
  );
  assert.equal(
    classifyToolHookEvent({ result: { details: { code: "ENOENT", success: false } } })
      .failureCategory,
    "dependency_unavailable",
  );
});

test("resolved successes stay successes and opaque failures stay explicit", () => {
  assert.deepEqual(
    classifyToolHookEvent({ result: { details: { status: "completed", success: true } } }),
    { outcome: "success" },
  );
  assert.equal(
    classifyToolHookEvent({ result: { details: { status: "failed" } } }).failureCategory,
    "unknown",
  );
});

test("dynamic error inspection returns only categories and discards source text", () => {
  const source =
    "permission denied at /workspace/private and token=never-export-this\nadditional output";
  assert.equal(classifyDynamicToolError(source), "permission_denied");
  assert.equal(classifyDynamicToolError("process exited with code 3"), "nonzero_exit");
  assert.equal(classifyDynamicToolError("unrecognized opaque failure"), "unknown");
  assert.equal(
    classifyToolHookEvent({
      result: {
        details: { status: "failed", error: `${"x".repeat(20_000)} permission denied` },
      },
    }).failureCategory,
    "unknown",
  );
  assert.ok(!TOOL_FAILURE_CATEGORIES.some((value) => value.includes("workspace")));
});

test("each remediation category has a deterministic representative", () => {
  const cases = new Map([
    ["operation cancelled", "aborted"],
    ["authentication required", "authentication_unavailable"],
    ["HTTP 403 forbidden", "authorization_denied"],
    ["command not found", "dependency_unavailable"],
    ["invalid argument", "invalid_input"],
    ["process exited with code 7", "nonzero_exit"],
    ["invalid JSON", "parse_failure"],
    ["permission denied", "permission_denied"],
    ["approval denied", "policy_denied"],
    ["structured result conversion failed", "protocol_conversion"],
    ["TypeError: value is not a function", "runtime_error"],
    ["deadline exceeded", "timeout"],
    ["unexpected response schema", "upstream_contract_mismatch"],
    ["service unavailable", "upstream_unavailable"],
  ]);
  for (const [message, expected] of cases) {
    assert.equal(classifyDynamicToolError(message), expected, message);
  }
});
