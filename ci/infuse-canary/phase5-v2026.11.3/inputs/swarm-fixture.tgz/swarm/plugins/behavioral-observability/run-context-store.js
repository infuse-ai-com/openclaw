import { isSafeRunId } from "./run-span-store.js";

function safeContextId(value) {
  return typeof value === "string" && value.length > 0 && value.length <= 256;
}

export class RunContextStore {
  constructor(maximumEntries = 1024) {
    this.maximumEntries = maximumEntries;
    this.byRun = new Map();
    this.bySessionKey = new Map();
    this.bySessionId = new Map();
  }

  remember({ runId, sessionKey, sessionId }) {
    if (!isSafeRunId(runId)) return;
    const previous = this.byRun.get(runId);
    if (previous?.sessionKey) this.bySessionKey.delete(previous.sessionKey);
    if (previous?.sessionId) this.bySessionId.delete(previous.sessionId);

    const bounded = {
      ...(safeContextId(previous?.sessionKey) ? { sessionKey: previous.sessionKey } : {}),
      ...(safeContextId(previous?.sessionId) ? { sessionId: previous.sessionId } : {}),
      ...(safeContextId(sessionKey) ? { sessionKey } : {}),
      ...(safeContextId(sessionId) ? { sessionId } : {}),
    };
    if (!bounded.sessionKey && !bounded.sessionId) return;

    this.byRun.delete(runId);
    while (this.byRun.size >= this.maximumEntries) {
      this.delete(this.byRun.keys().next().value);
    }
    this.byRun.set(runId, bounded);
    if (bounded.sessionKey) this.bySessionKey.set(bounded.sessionKey, runId);
    if (bounded.sessionId) this.bySessionId.set(bounded.sessionId, runId);
  }

  resolve({ sessionKey, sessionId }) {
    const runId =
      (safeContextId(sessionKey) ? this.bySessionKey.get(sessionKey) : undefined) ??
      (safeContextId(sessionId) ? this.bySessionId.get(sessionId) : undefined);
    return isSafeRunId(runId) ? runId : undefined;
  }

  delete(runId) {
    const context = this.byRun.get(runId);
    if (context?.sessionKey) this.bySessionKey.delete(context.sessionKey);
    if (context?.sessionId) this.bySessionId.delete(context.sessionId);
    this.byRun.delete(runId);
  }

  clear() {
    this.byRun.clear();
    this.bySessionKey.clear();
    this.bySessionId.clear();
  }
}
