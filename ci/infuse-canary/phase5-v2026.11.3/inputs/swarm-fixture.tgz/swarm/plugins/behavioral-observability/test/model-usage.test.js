import assert from "node:assert/strict";
import test from "node:test";

import {
  modelPricingStatus,
  normalizedHookUsageDetails,
  normalizedUsageDetails,
} from "../model-usage.js";

test("normalized OpenClaw usage stays in mutually exclusive Langfuse buckets", () => {
  assert.deepEqual(
    normalizedUsageDetails({
      input: 86,
      output: 188,
      cacheRead: 17_817,
      cacheWrite: 0,
      total: 18_091,
    }),
    {
      input: 86,
      output: 188,
      cache_read_input_tokens: 17_817,
      cache_write_input_tokens: 0,
      total: 18_091,
    },
  );
});

test("usage normalization drops invalid values and never invents totals", () => {
  assert.deepEqual(normalizedUsageDetails({ input: 10.9, output: -1 }), { input: 10 });
  assert.equal(normalizedUsageDetails(), undefined);
  assert.equal(normalizedUsageDetails({}), undefined);
});

test("public llm output usage falls back to the structured assistant usage", () => {
  assert.deepEqual(
    normalizedHookUsageDetails({
      usage: { input: 100, output: 40, total: 140 },
      lastAssistant: { usage: { input: 12, output: 3, total: 15 } },
    }),
    { input: 100, output: 40, total: 140 },
  );
  assert.deepEqual(
    normalizedHookUsageDetails({
      lastAssistant: { usage: { input: 8, output: 2, total: 10 } },
    }),
    { input: 8, output: 2, total: 10 },
  );
});

test("internal model aliases are explicitly unpriced until a reviewed price exists", () => {
  assert.equal(modelPricingStatus("gpt-5.6-sol"), "unpriced");
  assert.equal(modelPricingStatus("gpt-6-astra"), "unpriced");
  assert.equal(modelPricingStatus("gpt-4o"), "catalog");
  assert.equal(modelPricingStatus("unknown"), "catalog");
});
