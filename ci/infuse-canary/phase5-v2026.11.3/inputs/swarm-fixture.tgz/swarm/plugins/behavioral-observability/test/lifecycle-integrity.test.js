import assert from "node:assert/strict";
import test from "node:test";

import {
  canonicalLifecycleId,
  drainIncompleteLifecycles,
  recordLifecycle,
} from "../lifecycle-integrity.js";

test("normalizes wrapper and operation aliases at source", () => {
  assert.equal(canonicalLifecycleId("runtime_operations"), "runtime-operations");
  assert.equal(canonicalLifecycleId("status_namespace"), "status-namespace");
});

test("pairs starts with exactly one terminal state", () => {
  const state = {};
  const descriptor = { skill_name: "runtime-operations" };
  assert.equal(recordLifecycle(state, "skill", "runtime-operations", descriptor, "start"), "started");
  assert.equal(recordLifecycle(state, "skill", "runtime-operations", descriptor, "finish"), "complete");
  assert.equal(recordLifecycle(state, "skill", "runtime-operations", descriptor, "finish"), "unmatched_finish");
  assert.deepEqual(drainIncompleteLifecycles(state), []);
});

test("reports interrupted starts without inventing success", () => {
  const state = {};
  const descriptor = {
    skill_name: "runtime-operations",
    wrapper: "runtime-operations",
    operation: "status-namespace",
  };
  recordLifecycle(state, "wrapper", "runtime-operations|runtime-operations|status-namespace", descriptor, "start");
  assert.deepEqual(drainIncompleteLifecycles(state), [
    {
      lifecycleType: "wrapper",
      lifecycleState: "incomplete_start",
      incompleteCount: 1,
      ...descriptor,
    },
  ]);
  assert.deepEqual(drainIncompleteLifecycles(state), []);
});
