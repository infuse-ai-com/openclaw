export const MODEL_ATTEMPT_ROLES = Object.freeze(["primary", "fallback"]);
export const MODEL_FAILURE_CATEGORIES = Object.freeze([
  "aborted",
  "capacity",
  "connection",
  "rate_limit",
  "timeout",
  "upstream",
  "unknown",
]);

const SAFE_CALL_ID_RE = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/u;

export function isSafeModelCallId(value) {
  return typeof value === "string" && SAFE_CALL_ID_RE.test(value);
}

export function modelAttemptRole(index) {
  return index <= 1 ? "primary" : "fallback";
}

export function classifyModelFailure(event = {}) {
  const failureKind = typeof event.failureKind === "string" ? event.failureKind : "";
  if (failureKind === "timeout") return "timeout";
  if (["aborted", "terminated"].includes(failureKind)) return "aborted";
  if (["connection_closed", "connection_reset"].includes(failureKind)) return "connection";

  const category =
    typeof event.errorCategory === "string"
      ? event.errorCategory.slice(0, 256).toLowerCase()
      : "";
  if (/capacity|overload|server_busy|server-busy/u.test(category)) return "capacity";
  if (/rate.?limit|too_many_requests|\b429\b/u.test(category)) return "rate_limit";
  if (/timeout|deadline/u.test(category)) return "timeout";
  if (/connection|socket|network/u.test(category)) return "connection";
  if (/abort|terminat/u.test(category)) return "aborted";
  if (/upstream|provider|service_unavailable|\b5\d\d\b/u.test(category)) return "upstream";
  return "unknown";
}
