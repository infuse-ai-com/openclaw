export const TOOL_FAILURE_CATEGORIES = Object.freeze([
  "aborted",
  "authentication_unavailable",
  "authorization_denied",
  "dependency_unavailable",
  "internal_error",
  "invalid_input",
  "nonzero_exit",
  "parse_failure",
  "permission_denied",
  "policy_denied",
  "protocol_conversion",
  "runtime_error",
  "timeout",
  "unknown",
  "upstream_contract_mismatch",
  "upstream_unavailable",
]);

const CATEGORY_SET = new Set(TOOL_FAILURE_CATEGORIES);
const MAX_INSPECTED_ERROR_CHARS = 4096;
const ERROR_PATTERNS = Object.freeze([
  ["timeout", /timed?\s*out|timeout|deadline exceeded|etimedout/iu],
  ["aborted", /\baborted\b|\bcancelled\b|\bcanceled\b/iu],
  [
    "authentication_unavailable",
    /unauthenticated|authentication (?:failed|required|unavailable)|invalid api key|login required/iu,
  ],
  [
    "authorization_denied",
    /\bunauthorized\b|\bforbidden\b|authorization denied|access denied|http\s*40[13]/iu,
  ],
  [
    "policy_denied",
    /approval (?:required|unavailable|denied)|blocked by policy|policy denied|not approved/iu,
  ],
  ["permission_denied", /permission denied|operation not permitted|\beacces\b|\beperm\b/iu],
  [
    "dependency_unavailable",
    /command not found|module not found|cannot find (?:module|package)|\benoent\b|no such file or directory/iu,
  ],
  [
    "protocol_conversion",
    /structured result|(?:tool|dynamic tool) result.{0,80}(?:serializ|deserializ|convert|unsupported|expected)|(?:serializ|deserializ|convert).{0,80}(?:tool|structured) result|invalid type: (?:map|object).{0,40}expected (?:a )?string/iu,
  ],
  ["invalid_input", /invalid (?:argument|input|parameter)|schema validation|validation failed|unsupported .*params/iu],
  ["nonzero_exit", /non[- ]?zero|exit(?:ed)?(?: with)? (?:status|code)/iu],
  ["parse_failure", /parse|invalid json|unexpected token/iu],
  [
    "upstream_contract_mismatch",
    /contract mismatch|unexpected response (?:shape|schema)|unsupported response (?:shape|schema)/iu,
  ],
  [
    "upstream_unavailable",
    /connection refused|connection reset|service unavailable|bad gateway|econnrefused|econnreset/iu,
  ],
  [
    "runtime_error",
    /\b(?:typeerror|referenceerror|rangeerror)\b|cannot read propert(?:y|ies)|is not a function/iu,
  ],
]);

function boundedText(value) {
  return typeof value === "string"
    ? value.slice(0, MAX_INSPECTED_ERROR_CHARS).toLowerCase()
    : "";
}

export function classifyDynamicToolError(value) {
  const text = boundedText(value);
  if (!text) return "unknown";
  const stableSuffix = text.match(/(?:^|[:\s])([a-z][a-z0-9_]{1,95})[.!]?$/u)?.[1];
  if (CATEGORY_SET.has(stableSuffix)) return stableSuffix;
  for (const [category, pattern] of ERROR_PATTERNS) {
    if (pattern.test(text)) return category;
  }
  return "unknown";
}

function normalizedStableCode(value) {
  return typeof value === "string"
    ? value.trim().toLowerCase().replaceAll("-", "_")
    : "";
}

function safeField(value, key) {
  try {
    return value && typeof value === "object" ? value[key] : undefined;
  } catch {
    return undefined;
  }
}

function safeDetails(result) {
  const details = safeField(result, "details");
  return details && typeof details === "object" && !Array.isArray(details)
    ? details
    : undefined;
}

function safeResultText(result) {
  const details = safeDetails(result);
  const values = [safeField(details, "error"), safeField(details, "message")];
  const content = safeField(result, "content");
  if (Array.isArray(content)) {
    for (const item of content.slice(0, 16)) {
      values.push(safeField(item, "text"));
    }
  }
  let inspected = "";
  for (const value of values) {
    if (typeof value !== "string" || inspected.length >= MAX_INSPECTED_ERROR_CHARS) continue;
    const separator = inspected ? " " : "";
    const remaining = MAX_INSPECTED_ERROR_CHARS - inspected.length - separator.length;
    if (remaining <= 0) break;
    inspected += `${separator}${value.slice(0, remaining)}`;
  }
  return inspected;
}

function classifyStableCode(value) {
  const code = normalizedStableCode(value);
  if (CATEGORY_SET.has(code)) return code;
  if (["enoent", "command_not_found", "module_not_found"].includes(code)) {
    return "dependency_unavailable";
  }
  if (["eacces", "eperm", "not_executable"].includes(code)) {
    return "permission_denied";
  }
  if (["etimedout", "deadline_exceeded", "timed_out"].includes(code)) {
    return "timeout";
  }
  if (["invalid", "invalid_argument", "schema_validation"].includes(code)) {
    return "invalid_input";
  }
  return undefined;
}

function classifyResultFailure(result) {
  const details = safeDetails(result);
  if (!details) return undefined;
  const status = normalizedStableCode(safeField(details, "status"));
  const ok = safeField(details, "ok");
  const success = safeField(details, "success");
  const explicitlySuccessful = ok === true || success === true;
  if (safeField(details, "timedOut") === true || ["timeout", "timed_out"].includes(status)) {
    return "timeout";
  }
  if (["aborted", "cancelled", "canceled", "killed"].includes(status)) {
    return "aborted";
  }
  if (["blocked", "denied", "forbidden", "disabled", "approval_unavailable"].includes(status)) {
    return "policy_denied";
  }
  if (status === "unavailable") return "upstream_unavailable";
  if (status === "invalid") return "invalid_input";
  const exitCode = safeField(details, "exitCode");
  if (Number.isInteger(exitCode) && exitCode !== 0) return "nonzero_exit";
  if (ok === false || success === false) return "unknown";
  if (!explicitlySuccessful && ["error", "failed", "failure"].includes(status)) {
    return "unknown";
  }
  if (!explicitlySuccessful && safeField(details, "error")) return "unknown";
  return undefined;
}

export function classifyToolHookEvent(event) {
  if (typeof event?.error === "string" && event.error) {
    return {
      outcome: "error",
      failureCategory: classifyDynamicToolError(event.error),
      classificationSource: "tool_hook_error",
    };
  }

  const resultFailure = classifyResultFailure(event?.result);
  if (!resultFailure) return { outcome: "success" };
  const details = safeDetails(event?.result);
  const stableCategory =
    classifyStableCode(safeField(details, "code")) ??
    classifyStableCode(safeField(details, "errorCode"));
  const textCategory = classifyDynamicToolError(safeResultText(event?.result));
  return {
    outcome: "error",
    failureCategory:
      stableCategory ?? (resultFailure === "unknown" ? textCategory : resultFailure),
    classificationSource: "tool_hook_result",
  };
}

export function isToolFailureCategory(value) {
  return CATEGORY_SET.has(value);
}

export function inspectedErrorLimit() {
  return MAX_INSPECTED_ERROR_CHARS;
}
