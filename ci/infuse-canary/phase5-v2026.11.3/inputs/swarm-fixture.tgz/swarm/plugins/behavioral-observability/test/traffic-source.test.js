import assert from "node:assert/strict";
import test from "node:test";

import {
  classifyTrafficSource,
  preferTrafficSource,
  TrafficSourceStore,
} from "../traffic-source.js";

test("user-originated channel turns are human regardless of workspace ownership", () => {
  assert.equal(
    classifyTrafficSource({ trigger: "user", channel: "mattermost", senderIsOwner: true }),
    "human",
  );
  assert.equal(
    classifyTrafficSource({ trigger: "user", channel: "mattermost", senderIsOwner: false }),
    "human",
  );
  assert.equal(
    classifyTrafficSource({
      inputProvenanceKind: "external_user",
      messageProvider: "mattermost",
      senderIsOwner: true,
    }),
    "human",
  );
  assert.equal(
    classifyTrafficSource({ channel: "mattermost", senderIsOwner: true }),
    "unavailable",
  );
});

test("cron and heartbeat traffic are automation", () => {
  assert.equal(classifyTrafficSource({ trigger: "cron" }), "automation");
  assert.equal(classifyTrafficSource({ trigger: "heartbeat" }), "automation");
});

test("only exact channel-free controlled session suffixes classify smoke or startup", () => {
  assert.equal(
    classifyTrafficSource({ trigger: "user", sessionKey: "agent:agent-developer:smoke-routing-1" }),
    "smoke",
  );
  assert.equal(
    classifyTrafficSource({ sessionKey: "agent:agent-developer:startup-health-1" }),
    "startup",
  );
  assert.equal(
    classifyTrafficSource({ channel: "mattermost", sessionKey: "agent:a:smoke-routing-1" }),
    "unavailable",
  );
  assert.equal(classifyTrafficSource({ sessionKey: "agent:a:not-smoke-routing-1" }), "unavailable");
});

test("late bounded evidence upgrades unavailable without overriding trusted attribution", () => {
  assert.equal(preferTrafficSource("unavailable", "smoke"), "smoke");
  assert.equal(preferTrafficSource("unavailable", "startup"), "startup");
  assert.equal(preferTrafficSource("human", "smoke"), "human");
  assert.equal(preferTrafficSource("automation", "startup"), "automation");
  assert.equal(preferTrafficSource("unavailable", "not-approved"), "unavailable");
});

test("the bounded store evicts oldest entries and never invents a source", () => {
  const store = new TrafficSourceStore(1);
  store.remember("run-a", "human");
  store.remember("run-b", "smoke");
  assert.equal(store.get("run-a"), "unavailable");
  assert.equal(store.get("run-b"), "smoke");
  store.remember("run-c", "not-approved");
  assert.equal(store.get("run-c"), "unavailable");
});

test("pre-run ingress attribution transfers through bounded session correlation", () => {
  const store = new TrafficSourceStore(4);
  store.rememberContext(
    { sessionKey: "agent:agent-developer:mattermost:thread", sessionId: "session-1" },
    "human",
  );
  assert.equal(
    store.getContext({ sessionKey: "agent:agent-developer:mattermost:thread" }),
    "human",
  );
  store.remember("run-1", store.getContext({ sessionId: "session-1" }));
  assert.equal(store.get("run-1"), "human");
  store.deleteContext({ sessionKey: "agent:agent-developer:mattermost:thread", sessionId: "session-1" });
  assert.equal(store.getContext({ sessionId: "session-1" }), "unavailable");
});
