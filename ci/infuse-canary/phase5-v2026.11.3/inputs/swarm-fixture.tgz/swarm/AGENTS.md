---
title: AGENTS.md - OpenClaw Kubernetes Swarm
description: This repo builds the Kubernetes-hosted OpenClaw/Kapiteky runtime
  and the agent swarm operating layer for Infuse AI.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
---
# AGENTS.md - OpenClaw Kubernetes Swarm

This repo builds the Kubernetes-hosted OpenClaw/Kapiteky runtime and the agent swarm operating layer for Infuse AI.

## Operating Rules

- Treat this as infrastructure plus agent-runtime code. Prefer small, reviewable changes.
- Never commit secrets, kubeconfigs with tokens, browser cookies, Vaultwarden exports, Tailscale auth keys, or private runtime state.
- Use company context sparingly. Start from `company-docs/docs/00-start-here/agent-bootstrap.md`, then load only the deeper docs needed for the task.
- Persistent agent personas are owned by `openclaw-agents-persona`. Put behavior
  changes to agent `AGENTS.md`, `TOOLS.md`, `SOUL.md`, identity, or memory files
  there first; update this repo only for runtime sync/install logic, bundle
  grants, Kubernetes resources, or fallback template behavior.
- Treat each persistent agent as its own OpenClaw instance/pod. Local runtime lists, cron jobs, sessions, and state belong to that lane unless a source explicitly says it is global.
- Treat each persistent agent workspace as its own PVC. From inside a pod, `/workspace/agents/<current-agent-id>` is the current agent home; do not assume sibling paths for other agents are mounted or inspectable.
- Preserve Mattermost mention hygiene in runtime docs and prompts: when an agent is expected to act, use its resolved `@handle`; friendly names alone are context only.
- Preserve repo handoff hygiene in runtime docs and prompts: another persistent agent needs a pushed branch, PR URL, commit SHA, or patch artifact it can fetch; local-only PVC branches are blockers.
- Do not document or implement behavior that infers swarm-wide topology from one agent's local tools.
- Keep macOS-only capabilities explicit. If a feature needs macOS, design it as a worker integration, not as a hidden assumption in the Linux runtime.
- Default to least privilege for pods, service accounts, network access, and mounted volumes.
- Add verification commands for every meaningful runtime or deployment change.

## Architecture Bias

- Main runtime: unprivileged Kubernetes deployment with a dedicated PVC.
- Browser checks: separate Playwright runner image/job; headless by default, headed/Xvfb or noVNC for visual debugging.
- Builds: BuildKit/rootless or remote Docker context; avoid privileged Docker-in-Docker unless isolated and justified.
- Secrets: Kubernetes secrets, external secret integration, or Vaultwarden references. No raw secrets in repo files.
- Networking: internal services first; Tailscale/private access for operator entry points and homelab reachability.

## Human Approval Required

Ask Fito before:

- changing production cluster access, RBAC, secrets, Tailscale ACLs, DNS, firewall, or paid resources;
- deploying a persistent privileged workload;
- granting agent write access to external systems;
- deleting PVCs, namespaces, repositories, or live runtime state.
