# Compatibility notice

The broad mission-dispatcher contract was retired. Install and use
`emon-mission-steward.md`; it evaluates Emon's canonical mission registry and
stays silent when no due or material action exists.
