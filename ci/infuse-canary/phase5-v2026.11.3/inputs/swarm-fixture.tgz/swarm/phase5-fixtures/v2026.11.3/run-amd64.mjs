import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { access, cp, mkdir, readFile, writeFile } from "node:fs/promises";
import { connect } from "node:net";
import { join } from "node:path";

const work = "/work";
const packagesRoot = "/phase5/packages";
const plan = JSON.parse(await readFile("/phase5/phase5-plan.json", "utf8"));
const candidate = JSON.parse(await readFile("/phase5/candidate-manifest.json", "utf8"));
const contract = JSON.parse(await readFile("/fixture/candidate-contract.json", "utf8"));
assert.equal(process.platform, "linux");
assert.equal(process.arch, "x64");
assert.equal(candidate.hostVersion, contract.version);
assert.equal(candidate.hostCommit, contract.sourceCommit);
assert.equal(plan.sourceCommit, contract.sourceCommit);

const sha256 = async (path) => createHash("sha256").update(await readFile(path)).digest("hex");
const before = {};
for (const item of plan.packages) {
  const path = join(packagesRoot, item.file);
  assert.equal(await sha256(path), item.sha256);
  before[item.file] = item.sha256;
}
const core = plan.packages.find((item) => item.name === "openclaw");
assert(core);
await cp(join(packagesRoot, core.file), join(work, core.file));
await writeFile(join(work, "package.json"), `${JSON.stringify({ private: true, dependencies: { openclaw: `file:./${core.file}` } }, null, 2)}\n`);
await writeFile(join(work, ".npmrc"), "audit=false\nfund=false\nregistry=https://registry.npmjs.org/\n");
await mkdir(join(work, "home"), { mode: 0o700 });
const env = { ...process.env, HOME: join(work, "home"), npm_config_userconfig: join(work, ".npmrc") };

const run = (command, args, options = {}) => new Promise((resolve, reject) => {
  const child = spawn(command, args, { cwd: options.cwd ?? work, env: options.env ?? env, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [];
  const stderr = [];
  const timer = setTimeout(() => child.kill("SIGKILL"), options.timeout ?? 900_000);
  child.stdout.on("data", (chunk) => stdout.push(chunk));
  child.stderr.on("data", (chunk) => stderr.push(chunk));
  child.once("error", reject);
  child.once("close", async (code, signal) => {
    clearTimeout(timer);
    const out = Buffer.concat(stdout);
    const err = Buffer.concat(stderr);
    if (options.record) {
      await writeFile(join(work, `${options.record}.stdout.log`), out);
      await writeFile(join(work, `${options.record}.stderr.log`), err);
    }
    if (code !== 0) reject(Error(`${command} exited ${code ?? signal}: ${err.toString().slice(-2000)}`));
    else resolve(out);
  });
});

await run("npm", ["install", "--foreground-scripts", "--no-audit", "--no-fund"], { timeout: 1_800_000, record: "npm-install" });
const host = join(work, "node_modules/openclaw");
await access(join(host, "openclaw.mjs"));
const version = (await run(process.execPath, [join(host, "openclaw.mjs"), "--version"], { timeout: 60_000, record: "openclaw-version" })).toString().trim();
assert(version.includes(contract.version));

const pluginsOutput = (await run(process.execPath, [join(host, "openclaw.mjs"), "plugins", "list", "--json"], { timeout: 120_000, record: "plugin-list" })).toString();
for (const name of ["acpx", "codex", "diagnostics-otel", "mattermost"]) assert(pluginsOutput.includes(name));
const ownerModules = {};
for (const name of ["acpx", "codex", "diagnostics-otel", "mattermost"]) {
  const path = join(host, "dist/extensions", name, "index.js");
  ownerModules[name] = await sha256(path);
}

const gatewayLog = [];
const gatewayError = [];
const gateway = spawn(process.execPath, [join(host, "openclaw.mjs"), "gateway", "run", "--auth", "none", "--bind", "loopback", "--port", "18789", "--compact", "--allow-unconfigured"], {
  cwd: work,
  env,
  stdio: ["ignore", "pipe", "pipe"],
});
gateway.stdout.on("data", (chunk) => gatewayLog.push(chunk));
gateway.stderr.on("data", (chunk) => gatewayError.push(chunk));
const gatewayExit = new Promise((resolve) => gateway.once("close", (code, signal) => resolve({ code, signal })));
const ready = async () => {
  for (let attempt = 0; attempt < 120; attempt += 1) {
    const connected = await new Promise((resolve) => {
      const socket = connect(18789, "127.0.0.1");
      socket.setTimeout(500);
      socket.once("connect", () => { socket.destroy(); resolve(true); });
      socket.once("error", () => resolve(false));
      socket.once("timeout", () => { socket.destroy(); resolve(false); });
    });
    if (connected) return;
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw Error("candidate gateway did not become ready");
};
try {
  await ready();
  const pid = gateway.pid;
  process.kill(pid, "SIGSTOP");
  await new Promise((resolve) => setTimeout(resolve, 500));
  process.kill(pid, 0);
  process.kill(pid, "SIGCONT");
  await ready();
  assert.equal(gateway.pid, pid);
  process.kill(pid, "SIGTERM");
  const exit = await Promise.race([gatewayExit, new Promise((_, reject) => setTimeout(() => reject(Error("gateway shutdown timed out")), 30_000))]);
  assert([0, 143].includes(exit.code) || exit.signal === "SIGTERM");
  await writeFile(join(work, "gateway.stdout.log"), Buffer.concat(gatewayLog));
  await writeFile(join(work, "gateway.stderr.log"), Buffer.concat(gatewayError));
  const after = {};
  for (const item of plan.packages) after[item.file] = await sha256(join(packagesRoot, item.file));
  assert.deepEqual(after, before);
  await writeFile(join(work, "phase5-proof.json"), `${JSON.stringify({ schema: 1, lane: "amd64", metrics: {
    normalInstall: { version, platform: `${process.platform}/${process.arch}`, packageCount: plan.packages.length },
    pluginStartup: { required: Object.keys(ownerModules), commandAuthenticated: true },
    readiness: { initialReady: true, readyAfterContinue: true, port: 18789 },
    ownerPersistence: { modules: ownerModules, stableGatewayPid: pid },
    signalContinuity: { pid, stoppedAndContinued: true, readyAfterContinue: true },
    cleanTermination: { exitCode: exit.code, signal: exit.signal },
    beforeAfterCustody: { packageInputsUnchanged: true, candidateManifestSha256: await sha256("/phase5/candidate-manifest.json") },
  } }, null, 2)}\n`);
} finally {
  if (gateway.exitCode === null && gateway.signalCode === null) gateway.kill("SIGKILL");
}
