#!/usr/bin/env python3
"""Remove exactly the Docker objects named in the swarm Phase 5 ownership record."""
import json

from run_lane import Docker, LANE_LABEL, OWNER_LABEL, atomic_json, environment, require, state_file


def execute():
    _, evidence, _, _, _ = environment()
    docker = Docker(evidence)
    path = state_file(evidence)
    if not path.is_file():
        atomic_json(evidence / "cleanup-proof.json", {"schema": 1, "status": "passed", "reason": "no owned resources were created", "remaining": {"containers": [], "volumes": [], "networks": [], "images": []}})
        return
    state = json.loads(path.read_bytes())
    require(set(state) == {"schema", "owner", "lane", "network", "volume", "proxy", "runner", "image"} and state["schema"] == 1, "ownership record differs")
    expected = {OWNER_LABEL: state["owner"], LANE_LABEL: state["lane"]}
    removed = []
    for name in (state["runner"], state["proxy"]):
        result = docker.run(["container", "inspect", name], "cleanup-inspect-" + name, check=False)
        if result.returncode != 0:
            continue
        value = json.loads(result.stdout)[0]
        require(all((value["Config"].get("Labels") or {}).get(key) == item for key, item in expected.items()), "refusing foreign container cleanup")
        if name == state["proxy"]:
            logs = docker.run(["logs", name], "cleanup-proxy-log", check=False)
            (evidence / "registry-proxy.jsonl").write_bytes(logs.stdout)
        docker.run(["rm", "--force", name], "cleanup-remove-" + name)
        removed.append({"kind": "container", "name": name})
    if state["image"]:
        result = docker.run(["image", "inspect", state["image"]], "cleanup-inspect-image", check=False)
        if result.returncode == 0:
            value = json.loads(result.stdout)[0]
            require(all((value["Config"].get("Labels") or {}).get(key) == item for key, item in expected.items()), "refusing foreign image cleanup")
            docker.run(["image", "rm", state["image"]], "cleanup-remove-image", 300)
            removed.append({"kind": "image", "name": state["image"]})
    for kind in ("volume", "network"):
        name = state[kind]
        result = docker.run([kind, "inspect", name], "cleanup-inspect-" + kind, check=False)
        if result.returncode == 0:
            value = json.loads(result.stdout)[0]
            label_key = "Labels"
            require(all((value.get(label_key) or {}).get(key) == item for key, item in expected.items()), f"refusing foreign {kind} cleanup")
            docker.run([kind, "rm", name], "cleanup-remove-" + kind, 300)
            removed.append({"kind": kind, "name": name})
    remaining = {}
    for kind, command in (
        ("containers", ["ps", "-aq", "--filter", f"label={OWNER_LABEL}={state['owner']}"]),
        ("volumes", ["volume", "ls", "-q", "--filter", f"label={OWNER_LABEL}={state['owner']}"]),
        ("networks", ["network", "ls", "-q", "--filter", f"label={OWNER_LABEL}={state['owner']}"]),
        ("images", ["image", "ls", "-q", "--filter", f"label={OWNER_LABEL}={state['owner']}"]),
    ):
        result = docker.run(command, "cleanup-remaining-" + kind)
        remaining[kind] = [line for line in result.stdout.decode().splitlines() if line]
    require(not any(remaining.values()), "owned Docker objects remain after cleanup")
    atomic_json(evidence / "cleanup-proof.json", {"schema": 1, "status": "passed", "removed": removed, "remaining": remaining})


if __name__ == "__main__":
    execute()
