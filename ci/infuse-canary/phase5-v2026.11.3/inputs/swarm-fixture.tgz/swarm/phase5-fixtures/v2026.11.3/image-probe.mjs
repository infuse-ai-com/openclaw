import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { chromium } from "playwright-core";

const manifest = JSON.parse(await readFile("/app/node_modules/openclaw/package.json", "utf8"));
const build = JSON.parse(await readFile("/app/node_modules/openclaw/dist/build-info.json", "utf8"));
const expected = JSON.parse(await readFile("/app/phase5-image-contract.json", "utf8"));
assert.equal(manifest.version, expected.version);
assert.equal(build.commit, expected.sourceCommit);

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();
await page.setContent("<title>OpenClaw Phase 5 local image</title><main>candidate browser runtime</main>");
const title = await page.title();
const text = await page.locator("main").textContent();
const browserVersion = browser.version();
await browser.close();
assert.equal(title, "OpenClaw Phase 5 local image");
assert.equal(text, "candidate browser runtime");

const extensionNames = (await readdir("/app/node_modules/openclaw/dist/extensions")).sort();
for (const name of ["acpx", "codex", "diagnostics-otel", "mattermost"]) assert(extensionNames.includes(name));
const sha256 = (value) => createHash("sha256").update(value).digest("hex");
process.stdout.write(`${JSON.stringify({
  schema: 1,
  version: manifest.version,
  commit: build.commit,
  node: process.version,
  platform: `${process.platform}/${process.arch}`,
  browserVersion,
  title,
  contentSha256: sha256(text),
  runtimeExtensionCount: extensionNames.length,
})}\n`);
