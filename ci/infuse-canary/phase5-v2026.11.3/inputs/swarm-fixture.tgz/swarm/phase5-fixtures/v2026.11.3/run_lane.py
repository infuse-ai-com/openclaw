#!/usr/bin/env python3
"""Execute the amd64 or local-image Phase 5 lane using only owned Docker objects."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid


ROOT = Path(__file__).resolve().parent
CONTRACT = json.loads((ROOT / "candidate-contract.json").read_bytes())
OWNER_LABEL = "infuse.phase5.swarm-owner"
LANE_LABEL = "infuse.phase5.swarm-lane"
ALLOWED_ENV = {"PHASE5_OUTPUT", "PHASE5_PLAN_DIR", "PHASE5_PACKAGE_DIR", "PHASE5_CANDIDATE_MANIFEST", "PHASE5_LANE", "HOME", "TMPDIR", "PATH", "LANG", "LC_ALL", "LC_CTYPE", "__CF_USER_TEXT_ENCODING"}
CHECKS = {
    "amd64": ["normalInstall", "pluginStartup", "readiness", "ownerPersistence", "signalContinuity", "cleanTermination", "beforeAfterCustody"],
    "localImage": ["assembledInputPreflight", "build", "architecture", "imageDigest", "packageCustody", "runtimeAssets", "browserToolbox", "beforeAfterSourceCustody"],
}


def require(value, reason):
    if not value:
        raise ValueError(reason)


def atomic_json(path: Path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    os.chmod(temporary, 0o600)
    temporary.replace(path)


class Docker:
    def __init__(self, evidence: Path):
        self.evidence = evidence
        self.count = 0

    def run(self, arguments, label, timeout=60, check=True, cwd=None):
        self.count += 1
        stem = f"{self.count:02d}-{label}"
        try:
            result = subprocess.run(["docker", *arguments], stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout, check=False, cwd=cwd)
        except subprocess.TimeoutExpired as error:
            (self.evidence / (stem + ".stdout.log")).write_bytes(error.stdout or b"")
            (self.evidence / (stem + ".stderr.log")).write_bytes(error.stderr or b"")
            raise ValueError("Docker operation timed out: " + label) from error
        (self.evidence / (stem + ".stdout.log")).write_bytes(result.stdout)
        (self.evidence / (stem + ".stderr.log")).write_bytes(result.stderr)
        atomic_json(self.evidence / (stem + ".json"), {"argv": ["docker", *arguments], "returnCode": result.returncode, "stdoutBytes": len(result.stdout), "stderrBytes": len(result.stderr)})
        if check:
            require(result.returncode == 0, "Docker operation failed: " + label)
        return result

    def json(self, arguments, label, timeout=60):
        return json.loads(self.run(arguments, label, timeout).stdout)


def labels(owner, lane):
    return ["--label", f"{OWNER_LABEL}={owner}", "--label", f"{LANE_LABEL}={lane}"]


def environment():
    require(set(os.environ) <= ALLOWED_ENV, "adapter imported an unreviewed environment value")
    for name in os.environ:
        require(re.search(r"TOKEN|SECRET|PASSWORD|COOKIE|CREDENTIAL", name, re.I) is None, "secret-shaped adapter environment name")
    output = Path(os.environ["PHASE5_OUTPUT"]).resolve(strict=True)
    evidence = output / "evidence"
    plan = Path(os.environ["PHASE5_PLAN_DIR"]).resolve(strict=True)
    packages = Path(os.environ["PHASE5_PACKAGE_DIR"]).resolve(strict=True)
    candidate = Path(os.environ["PHASE5_CANDIDATE_MANIFEST"]).resolve(strict=True)
    require(evidence.is_dir() and not evidence.is_symlink(), "missing evidence directory")
    require(packages == plan / "packages" and candidate == plan / "candidate-manifest.json", "adapter input paths differ")
    return output, evidence, plan, packages, candidate


def wait_proxy(docker, proxy):
    for _ in range(50):
        result = docker.run(["logs", proxy], "proxy-readiness", check=False)
        if b'"kind":"ready"' in result.stdout:
            return
        time.sleep(0.2)
    raise ValueError("owned registry proxy did not become ready")


def state_file(evidence):
    return evidence / "owned-resources.json"


def create_common(docker, lane, evidence):
    owner = uuid.uuid4().hex
    stem = f"phase5-swarm-{lane.lower()}-{owner[:12]}"
    state = {"schema": 1, "owner": owner, "lane": lane, "network": stem + "-network", "volume": stem + "-work", "proxy": stem + "-proxy", "runner": stem + "-runner", "image": stem + "-image" if lane == "localImage" else None}
    atomic_json(state_file(evidence), state)
    docker.run(["network", "create", "--internal", *labels(owner, lane), state["network"]], "network-create")
    docker.run(["volume", "create", *labels(owner, lane), state["volume"]], "volume-create")
    docker.run(["run", "--rm", "--pull", "never", "--platform", "linux/amd64", "--network", "none", *labels(owner, lane),
                "--cap-drop", "ALL", "--cap-add", "CHOWN", "--security-opt", "no-new-privileges",
                "--mount", f"source={state['volume']},target=/work", CONTRACT["nodeImage"],
                "sh", "-c", "chown 1000:1000 /work"], "volume-owner", 120)
    docker.run(["create", "--name", state["proxy"], "--pull", "never", "--platform", "linux/amd64", "--network", state["network"], "--network-alias", "proxy", *labels(owner, lane), "--user", "1000:1000", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--memory", "256m", "--memory-swap", "256m", "--cpus", "0.5", "--tmpfs", "/tmp:rw,noexec,nosuid,size=32m", "--mount", f"type=bind,src={ROOT},dst=/fixture,readonly", CONTRACT["nodeImage"], "node", "/fixture/proxy.mjs"], "proxy-create", 120)
    docker.run(["network", "connect", "bridge", state["proxy"]], "proxy-public-connect")
    docker.run(["start", state["proxy"]], "proxy-start")
    wait_proxy(docker, state["proxy"])
    return state


def container_base(state, plan, packages, candidate):
    return ["create", "--name", state["runner"], "--pull", "never", "--platform", "linux/amd64", "--network", state["network"], *labels(state["owner"], state["lane"]), "--user", "1000:1000", "--read-only", "--init", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--pids-limit", "2048", "--memory", "8g", "--memory-swap", "8g", "--cpus", "6", "--tmpfs", "/tmp:rw,noexec,nosuid,size=512m", "--mount", f"source={state['volume']},target=/work", "--mount", f"type=bind,src={ROOT},dst=/fixture,readonly", "--mount", f"type=bind,src={plan / 'phase5-plan.json'},dst=/phase5/phase5-plan.json,readonly", "--mount", f"type=bind,src={candidate},dst=/phase5/candidate-manifest.json,readonly", "--mount", f"type=bind,src={packages},dst=/phase5/packages,readonly", "--env", "npm_config_proxy=http://proxy:3128", "--env", "npm_config_https_proxy=http://proxy:3128", "--env", "npm_config_noproxy="]


def amd64_lane(docker, state, evidence, plan, packages, candidate):
    docker.run(container_base(state, plan, packages, candidate) + [CONTRACT["nodeImage"], "node", "/fixture/run-amd64.mjs"], "runner-create", 120)
    inspected = docker.json(["container", "inspect", state["runner"]], "runner-inspect")
    require(inspected[0]["Config"]["Labels"].get(OWNER_LABEL) == state["owner"], "runner owner label differs")
    require(inspected[0]["HostConfig"]["Privileged"] is False and inspected[0]["HostConfig"]["ReadonlyRootfs"] is True, "runner boundary differs")
    docker.run(["start", "--attach", state["runner"]], "runner-run", 3300)
    for source, destination in (("phase5-proof.json", "lane-proof.json"), ("gateway.stdout.log", "gateway.stdout.log"), ("gateway.stderr.log", "gateway.stderr.log"), ("plugin-list.stdout.log", "plugin-list.stdout.log"), ("plugin-list.stderr.log", "plugin-list.stderr.log"), ("npm-install.stdout.log", "npm-install.stdout.log"), ("npm-install.stderr.log", "npm-install.stderr.log")):
        docker.run(["cp", f"{state['runner']}:/work/{source}", str(evidence / destination)], "copy-" + destination.replace(".", "-"), 120)
    return json.loads((evidence / "lane-proof.json").read_bytes())


def local_image_lane(docker, state, output, evidence, plan, packages, candidate):
    docker.run(container_base(state, plan, packages, candidate) + [CONTRACT["nodeImage"], "sh", "-lc", "mkdir -p /work/home && cp /phase5/packages/openclaw-2026.11.3-f5fce6c00e.tgz /work/openclaw.tgz && printf '{\"private\":true,\"dependencies\":{\"openclaw\":\"file:./openclaw.tgz\"}}\\n' >/work/package.json && cd /work && HOME=/work/home npm_config_cache=/work/home/.npm npm install --foreground-scripts --no-audit --no-fund"], "assembler-create", 120)
    docker.run(["start", "--attach", state["runner"]], "assembler-run", 3300)
    context = output / "owned-build-context"
    require(not context.exists(), "owned build context already exists")
    context.mkdir(mode=0o700)
    try:
        docker.run(["cp", f"{state['runner']}:/work/.", str(context / "app")], "assembler-copy", 600)
        shutil.copy2(ROOT / "image-probe.mjs", context / "app/phase5-image-probe.mjs")
        atomic_json(context / "app/phase5-image-contract.json", {"schema": 1, "version": CONTRACT["version"], "sourceCommit": CONTRACT["sourceCommit"]})
        docker.run(["build", "--pull=false", "--network", "none", *labels(state["owner"], state["lane"]), "-f", str(ROOT / "local-image.Dockerfile"), "-t", state["image"], str(context)], "offline-image-build", 1800)
    finally:
        shutil.rmtree(context, ignore_errors=True)
    inspected = docker.json(["image", "inspect", state["image"]], "image-inspect")
    require(len(inspected) == 1 and inspected[0]["Os"] == "linux" and inspected[0]["Architecture"] == "amd64", "local image platform differs")
    require(inspected[0]["Config"]["Labels"].get(OWNER_LABEL) == state["owner"], "local image owner label differs")
    result = docker.run(["run", "--rm", "--pull", "never", "--platform", "linux/amd64", "--network", "none", *labels(state["owner"], state["lane"]), "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--memory", "2g", "--memory-swap", "2g", "--cpus", "2", "--tmpfs", "/tmp:rw,noexec,nosuid,size=256m", state["image"]], "image-runtime", 300)
    runtime = json.loads(result.stdout)
    package_hashes = {item["file"]: hashlib.sha256((packages / item["file"]).read_bytes()).hexdigest() for item in json.loads((plan / "phase5-plan.json").read_bytes())["packages"]}
    plan_hashes = {item["file"]: item["sha256"] for item in json.loads((plan / "phase5-plan.json").read_bytes())["packages"]}
    require(package_hashes == plan_hashes, "candidate package custody differs")
    proof = {"schema": 1, "lane": "localImage", "metrics": {
        "assembledInputPreflight": {"packages": len(package_hashes), "candidateManifestSha256": hashlib.sha256(candidate.read_bytes()).hexdigest()},
        "build": {"network": "none", "baseImage": CONTRACT["playwrightImage"], "pushed": False},
        "architecture": {"os": inspected[0]["Os"], "architecture": inspected[0]["Architecture"]},
        "imageDigest": {"id": inspected[0]["Id"]},
        "packageCustody": {"version": runtime["version"], "commit": runtime["commit"], "packages": package_hashes},
        "runtimeAssets": {"node": runtime["node"], "runtimeExtensionCount": runtime["runtimeExtensionCount"]},
        "browserToolbox": {"browserVersion": runtime["browserVersion"], "title": runtime["title"], "contentSha256": runtime["contentSha256"]},
        "beforeAfterSourceCustody": {"candidateManifestSha256": hashlib.sha256(candidate.read_bytes()).hexdigest(), "packageInputsUnchanged": True},
    }}
    atomic_json(evidence / "lane-proof.json", proof)
    return proof


def execute(lane):
    require(lane in CHECKS, "unknown swarm fixture lane")
    require(os.environ["PHASE5_LANE"] == lane, "adapter lane differs from fixture argv")
    output, evidence, plan, packages, candidate = environment()
    docker = Docker(evidence)
    info = docker.json(["info", "--format", "{{json .}}"], "docker-info")
    require(info["NCPU"] >= 8 and info["MemTotal"] >= 11 * 1024**3, "Docker resources are below the lane contract")
    image = CONTRACT["nodeImage"] if lane == "amd64" else CONTRACT["playwrightImage"]
    inspected = docker.json(["image", "inspect", image], "base-image-inspect")
    require(len(inspected) == 1 and inspected[0]["Os"] == "linux" and inspected[0]["Architecture"] == "amd64", "pinned base image differs")
    state = create_common(docker, lane, evidence)
    proof = amd64_lane(docker, state, evidence, plan, packages, candidate) if lane == "amd64" else local_image_lane(docker, state, output, evidence, plan, packages, candidate)
    require(proof["schema"] == 1 and proof["lane"] == lane and set(proof["metrics"]) == set(CHECKS[lane]), "lane proof closure differs")
    checks = {name: {"status": "passed", "metrics": proof["metrics"][name]} for name in CHECKS[lane]}
    atomic_json(evidence / "host-admission.json", {"schema": 1, "lane": lane, "cpus": info["NCPU"], "memoryBytes": info["MemTotal"], "baseImage": image, "baseImageId": inspected[0]["Id"]})
    limits = [
        "No model, Mattermost, cluster, registry-publish or production credentials were present",
        "Public dependency traffic was restricted to registry.npmjs.org through the owned proxy",
    ]
    limits.append("Gateway readiness was proven over a local TCP connection only" if lane == "amd64" else "The local image was built with network=none and was not pushed")
    atomic_json(evidence / "fixture-result.json", {"schema": 1, "status": "passed", "checks": checks, "scopeLimits": limits, "reason": ""})


if __name__ == "__main__":
    require(len(sys.argv) == 2, "pass exactly one swarm fixture lane")
    execute(sys.argv[1])
