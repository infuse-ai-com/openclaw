FROM mcr.microsoft.com/playwright@sha256:eff16c30e6f3f4af0a03fa4b706120d5e9b0891c344a27d64559aff5900a4a27

COPY --chown=pwuser:pwuser app /app
WORKDIR /app
USER pwuser
ENV HOME=/home/pwuser \
    PLAYWRIGHT_BROWSERS_PATH=/ms-playwright
CMD ["node", "/app/phase5-image-probe.mjs"]
