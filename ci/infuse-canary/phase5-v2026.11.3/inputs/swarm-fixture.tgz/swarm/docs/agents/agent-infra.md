---
title: agent-infra
description: "agent-infra is Satwa Nutella: the active runtime operations /
  Kubernetes triage agent for the OpenClaw swarm."
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - agent
  - infra
---
# agent-infra

`agent-infra` is Satwa Nutella: the active runtime operations / Kubernetes triage agent for the OpenClaw swarm.

## Purpose

Satwa Nutella helps with runtime health, Kubernetes rollout checks, pod events, logs, Harbor/image state, and smoke-test triage. Satwa Nutella is not an autonomous production operator; it reports evidence-backed summaries and proposed next commands to Emon, who escalates approval or advisory questions to Fito or Kapiteky as needed.

## Default Access

- Read assigned OpenClaw swarm runtime docs and manifests.
- Inspect scoped Kubernetes/runtime status when explicitly assigned.
- Summarize logs, events, rollout state, and smoke failures.
- Draft proposed commands or patches.
- Post in assigned Mattermost channels only when mentioned or assigned.
- Consult and report to Emon in the assigned project-infrastructure task thread; do not route routine execution questions or status to Kapiteky.

## Hard Boundaries

Satwa Nutella must not:

- change production infrastructure without explicit approval;
- change DNS, firewall, router, Tailscale, Vaultwarden, or Mattermost access;
- rotate, print, or manage secrets;
- merge PRs or complete releases;
- join channels outside the approved scope without a temporary assignment.

## Skill Bundle

Primary bundle:

```text
config/agent-skill-bundles/agent-infra.json
```

Installed skills:

- `gitlab`
- `text-diagramming`
- `knowledge-retrieval`
- `mattermost-channel-management`
- `mission-control-publishing`
- `runtime-operations`
- `shared-agent-memory`
- `source-synthesis`
- `tech-org`
- `vaultwarden-credential-management`
- `verify-this`
- `workspace-context`

All skills not listed in the bundle's binary installed set are absent.

## Mattermost Identity

```text
friendly name: Satwa Nutella
runtime slug: agent-infra
Mattermost username: agent-infra
display name: Satwa Nutella
default channel: backoffice-infra (current); equivalent private project-infrastructure channels as assigned
```

Expected secret contract:

- Vaultwarden item: `Mattermost / agent-infra BOT token`
- Kubernetes Secret: `agent-infra-mattermost`
- Vaultwarden item: `Kubernetes / agent-infra platform operator kubeconfig`
- Kubernetes Secret: `agent-infra-kubeconfig`
- Mount path: `/var/run/openclaw-agent/secrets/kubeconfig/kubeconfig`
- Kubernetes permissions: source-managed infra operator and product-diagnostics roles; never `cluster-admin`.

Activation checks:

- bot token resolves to Mattermost user `agent-infra`;
- bot is a member of its assigned private project-infrastructure channel;
- Kubernetes Secret `agent-infra-mattermost` exists in `agents-swarm`;
- Kubernetes Secret `agent-infra-kubeconfig` exists in `agents-swarm`;
- OpenClaw config validates in the pod;
- runtime skills match the required bundle;
- direct Mattermost messages from Fito are allowed by user-id allowlist;
- Mattermost channel status connects from the runtime.
- `task smoke-agent-infra-kube-access` passes.

## First Useful Task

Give Satwa Nutella a read-only triage prompt after deployment:

```text
@agent-infra inspect the OpenClaw swarm runtime status for agent-developer and agent-designer. Read-only: summarize rollout, PVC, channel connectivity, and any obvious risk. Do not change anything.
```

## Review Condition

Review after the first two operations tasks and after any noisy, over-broad, or access-sensitive behavior.
