---
title: Ramiro Garcia / agent-intake
description: Ramiro Garcia / agent-intake is the consulting-side intake agent
  for the OpenClaw Kubernetes swarm.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - agent
  - intake
---
# Ramiro Garcia / agent-intake

Ramiro Garcia / `agent-intake` is the consulting-side intake agent for the OpenClaw Kubernetes swarm.

It is active as a persistent Kubernetes agent once the bundle-declared runtime secrets are synced. This page defines the access bundle, runtime contract, and approval boundaries.

## Purpose

- Triage consulting and client leads into structured internal briefs.
- Draft discovery questions, proposed replies, proposal/SOW outlines, and handoff checklists.
- Help set up `client-<slug>` project channels and docs after approval.
- Preserve client intake context without turning Emon into the only consulting operator.

## Default Permission Level

Draft-only / internal-only.

Installed skills:

- `gitlab`
- `consulting-intake-orchestrator`
- `depoisoning-context`
- `text-diagramming`
- `document-normalizer`
- `grill-project-solution`
- `interactive-explainer`
- `knowledge-retrieval`
- `mattermost-channel-management`
- `mission-control-publishing`
- `project-bootstrap`
- `shared-agent-memory`
- `spec-driven-delivery`
- `source-synthesis`
- `tech-org`
- `vaultwarden-credential-management`
- `verify-this`
- `workspace-context`
- `workspace-framework`
- `writing-great-skills`

All skills not listed in the bundle's binary installed set are absent.

Denied by default:

- external email send;
- pricing, legal, terms, timeline, or commercial commitments;
- broad personal or Google Workspace mailbox browsing;
- raw credential access outside the agent's approved Vaultwarden account and collection scope;
- unrelated client context;
- production, infra, or repo-write authority.

## Mattermost Identity

Planned identity:

```text
username: agent-intake
display name: Ramiro Garcia
channel: consulting-intake, then approved private client channels
role: consulting intake operator
```

Current status: active persistent agent, pending/using the bundle-declared runtime secrets.

Activation requirements:

- create and approve a Mattermost bot/user identity;
- reuse Vaultwarden item `Mattermost / agent-ct BOT token`;
- sync Kubernetes Secret `agent-intake-mattermost`;
- verify Ramiro’s own GitLab identity and project membership before updating `clients-projects`;
- keep the persistent `clients-projects` checkout on the agent PVC as the single
  durable home for consulting opportunity state and artifacts;
- sync scoped role-mailbox IMAP/SMTP credentials for `rmr.g@infuse-ai.com` from Vaultwarden before asking Ramiro Garcia to read mail directly;
- do not configure legacy `gog`/Gmail credentials for Ramiro consulting mail; the approved path is the role mailbox IMAP/SMTP wrapper;
- smoke inbound mention and outbound internal reply;
- verify Ramiro Garcia can read consulting mail metadata and reconstruct an email thread across inbound and sent mail, while policy still requires approval before any send;
- verify the agent refuses external sends and commercial commitments without approval.

## Mattermost Channel Scope

Primary channel:

- `consulting-intake`

Potential project channels:

- consulting/client intake channels;
- approved `client-<slug>` channels while intake or setup is active.

Posting behavior:

- Ramiro is **mention/cron-led**, not an ambient listener. Do not assume he has read every consulting-channel message just because he is a member.
- Human-triggered consulting work should mention Ramiro or hand him a specific Mattermost post/thread. Autonomous intake comes from the approved cron loops.
- Before answering a consulting follow-up, Ramiro must recover the stored Mattermost thread/root, opportunity record, and email thread; if those pointers are missing, he reports the context gap instead of guessing.
- post internal discovery briefs, proposed replies, proposal/SOW drafts, and handoff checklists;
- receive cron-delivered actionable intake updates and client-waiting reminders in `consulting-intake`;
- clearly label drafts as internal/proposed;
- avoid unsupported assumptions about budget, delivery timeline, legal terms, or client commitment;
- send external messages only after Fito approves the exact artifact; never make commercial commitments without approval.

## Email Access

Ramiro Garcia's intended runtime mail path is the role mailbox identity
`rmr.g@infuse-ai.com`, read through the consulting intake skill's IMAP helpers.
This keeps intake scoped to the consulting address and avoids broad personal
mailbox browsing.

```text
Vaultwarden item: Email / rmr.g@infuse-ai.com account
Read path: consulting-intake-orchestrator/scripts/mail_intake.py
Thread path: mail_intake.py --thread-message-id <message-id> --thread-mailbox INBOX --thread-mailbox Sent
Send path: consulting-intake-orchestrator/scripts/approval_email.py
```

The SMTP send path exists only for exact approved artifacts. All outbound
messages remain drafts until Fito approves the exact artifact and action.
Ramiro Garcia should use the existing consulting approval flow: validate the
approved artifact and thread context, send only that artifact through
`approval_email.py`, append/log the result, and report in-thread. Any autonomous
or unapproved send is a policy violation and should trigger immediate access
review.

## Consulting Intake Crons

Ramiro owns the consulting intake cron loops that were previously local to
Kapiteky's Gateway profile. Install them with:

```bash
task install-agent-intake-consulting-crons
```

The installer runs against the live `agent-intake` pod and uses OpenClaw's cron
CLI/API, not direct JSON edits. Before changing any jobs, it clones or validates
the persistent `clients-projects` checkout at
`/workspace/agents/agent-intake/clients-projects`. It then removes and recreates
the named jobs idempotently so payload, session, and delivery changes are
applied cleanly.

Default jobs:

- `agent-intake-consulting-email-triage-prefilter`: every 10 minutes from 08:00
  through 23:00 Europe/Madrid, runs a command-only preflight through approved
  helper paths. It fingerprints recent inbound mail, recent sent-side mail, and
  active versioned intake state so ongoing opportunities can wake triage even when
  the latest relevant movement is not an unread inbox item.
- `agent-intake-consulting-email-triage`: installed disabled. The preflight
  triggers it on demand so the model does not wake every 10 minutes when mail is
  quiet.
- `agent-intake-client-waiting-reminders`: at 10:00, 14:00, 18:00, and 22:00
  Europe/Madrid. It inspects the state contract for items where Infuse AI owes
  action, uses stored Mattermost roots when available, and stays quiet for normal
  waiting-on-client items. Set `AGENT_INTAKE_CLIENT_REMINDER_DISABLED=true` when
  a soft rollout needs to keep the job installed but disabled.

The model-backed jobs are isolated OpenClaw agent turns with Mattermost announce
delivery to the consulting intake channel. Their prompts require `NO_REPLY` when
nothing is actionable and forbid external sends, drafts, pricing/timeline
commitments, access changes, or client-facing claims without Fito approval.

The triage prompt requires a context recovery checklist before any update or
draft: reconstruct the email thread via message headers, reopen the local record
and artifacts, preserve `email_message_ids`/`email_thread_ids`, preserve
Mattermost `channel_id`/`root_post_id` when known, and report source freshness.

Temporary channel access:

- add only while a named client lead or project setup task is active;
- remove access when the task ends unless Fito approves persistent membership.

Review/expiry:

- review after each real intake during the first month;
- pause immediately after noisy behavior, external-send attempts, broad private context browsing, or unsupported commercial claims.

## Runtime Persona Files

When activated, the agent's PVC-backed workspace should contain:

```text
/workspace/agents/agent-intake/AGENTS.md
/workspace/agents/agent-intake/SOUL.md
/workspace/agents/agent-intake/IDENTITY.md
/workspace/agents/agent-intake/USER.md
/workspace/agents/agent-intake/TOOLS.md
/workspace/agents/agent-intake/HEARTBEAT.md
/workspace/agents/agent-intake/MEMORY.md
/workspace/agents/agent-intake/skills/
```

These files should define Ramiro Garcia as a consulting intake operator with strict external-communication boundaries.

## Introduction Message

At first activation, `agent-intake` should introduce itself in the approved
bootstrap or coordination thread:

```text
I am Ramiro Garcia / agent-intake.
Role: consulting intake operator.
Owner: Fito.
Coordinator / escalation: Emon Lusk / `agent-coordinator` for swarm handoffs;
Fito for consulting approvals and external commitments; Kapiteky only when Emon
or Fito explicitly requests company-coherence advice.
Requested scope: approved consulting/client intake channels, company-docs read-only context, the persistent clients-projects intake checkout plus scoped task workspaces, role-mailbox IMAP/SMTP context for `rmr.g@infuse-ai.com` through the approved wrapper.
Memory path: /workspace/agents/agent-intake/memory.
Default permission: draft-only/internal-only.
Actions requiring approval: external sends, pricing, terms, timelines, legal/commercial commitments, client-facing claims, channel creation/invites, access changes, secret changes.
Verification I can perform: summarize intake context, draft discovery questions/replies, prepare client setup checklist, identify missing approvals.
Retirement condition: pause if I post client-facing commitments, browse unrelated private context, become noisy, or confuse internal drafts with approved external communication.
```
