---
title: Agent Docs
description: This directory is the repo-local access-bundle layer for persistent
  OpenClaw swarm agents.
type: overview
status: active
owner: team:agent-platform
tags:
  - overview
---
# Agent Docs

This directory is the repo-local access-bundle layer for persistent OpenClaw
swarm agents.

Use these files when changing an agent's role, channel scope, skill bundle,
credential intent, runtime persona, or review cadence. Do not make an agent
figure out its authority from chat history.

## Source Of Truth Split

- `company-docs` owns company vision, operating model, governance, approval
  levels, and default specialized roles.
- `engineering-handbook` owns reusable engineering and agentic-system standards.
- `agent-skills` owns executable skills, helper scripts, handoff contracts, and
  role behavior.
- `openclaw-k8s-swarm` owns deployed persistent-agent runtime docs, Kubernetes
  manifests, skill bundle assignment, credential intent, PVC persona files, and
  runtime sync.

If these disagree, update the upstream source first or quote the source that
justifies a temporary repo-local exception.

## Current Roster

| Runtime id | Friendly name | Primary role | Coordinator / escalation |
|---|---|---|---|
| `agent-coordinator` | Emon Lusk | Agent-team CEO and accountable execution lead: mission intake, decomposition, handoffs, integration, release, and closeout. | Owns missions end to end; asks Fito for decisions and Kapiteky for direction or operating-system advice without transferring execution. |
| `agent-developer` | Tinus Lordvals | Scoped implementation engineer, repo-local verification, release/readiness evidence. | Reports to Emon; Kapiteky only by explicit advisory request. |
| `agent-designer` | Stewie Hobs | UX/design review, screenshot critique, accessibility, design-parity findings. | Reports to Emon; Kapiteky only by explicit advisory request. |
| `agent-infra` | Satwa Nutella | Runtime operations, Kubernetes/CI/CD triage, rollout/log/event evidence. | Reports to Emon; Kapiteky only by explicit advisory request. |
| `agent-intake` | Ramiro Garcia | Consulting intake, discovery/proposal drafts, client handoff checklists. | Emon for engineering handoffs; Fito for external, commercial, access, and consulting approvals. |

## Agent Doc Contract

Every persistent-agent doc should answer these questions without requiring
private chat history:

- What is the friendly name, runtime id, and primary role?
- Why does this role deserve a persistent identity instead of a temporary role
  hat?
- What is the default permission level?
- What is allowed autonomously?
- What always needs Fito approval or an explicit recorded mission boundary?
- Which Mattermost channels can the agent use, and how should it behave there?
- Which skill bundle is enforced by `config/agent-skill-bundles/<agent-id>.json`?
- Which credentials are referenced, where are they materialized, and what must
  never be printed?
- What context should the agent load first?
- What should the agent report back with?
- What smoke checks prove the runtime is usable?
- What review, expiry, or offboarding condition narrows/removes the agent?

Use `docs/agents/TEMPLATE.md` for new agents. Keep role details in the agent doc
and executable permissions in the skill bundle; avoid duplicating long skill
instructions here.

## Context Loading

Default context for swarm work should be compact:

1. task brief or Mattermost handoff;
2. this agent's `docs/agents/<agent-id>.md`;
3. `docs/AGENT_IDENTITIES.md`;
4. repo-local `AGENTS.md` and `docs/REPO_MAP.md`;
5. only the relevant company/skill docs needed for the task.

Avoid giving every agent all of `company-docs`. Emon should choose source
context and pass scoped handoffs to specialists.

## Reporting Contract

Agent output should be reviewable and easy to route:

```text
Status: pass | revise | wait | blocked
Scope:
Inspected:
Findings:
Changed:
Verification:
Risks:
Approval needed:
Recommended next action:
```

Specialists report once in their project-role task thread. After dispatch, that
root contains only the neutral root, one dispatcher handoff, and one specialist
final report. Emon updates canonical mission state without replying there and
routes material synthesis to the mission coordination thread, escalating only
real approval, product, access, or risk decisions.

## Runtime Sync Checklist

After editing templates, agent docs, or skill bundles:

```bash
task verify
for agent in agent-coordinator agent-developer agent-designer agent-infra agent-intake; do
  AGENT_ID="$agent" task verify-agent-persona
  AGENT_ID="$agent" task verify-agent-skills
  AGENT_ID="$agent" task verify-agent-skill-install
done
```

To update live PVC core files after review:

```bash
SKILL_SOURCE_SYNC=none AGENT_ID=<agent-id> task install-agent-runtime-files
```

Use `SKILL_SOURCE_SYNC=none` when the local `agent-skills` checkout has
unrelated local changes and you only want to sync the currently available
approved runtime files. Do not stash, reset, or pull another repo's dirty work
just to update persona files.

Read back the installed files when authority wording changed:

```bash
AGENT_ID=<agent-id> task smoke-agent-runtime
```

For targeted manual inspection, read only non-secret files such as
`/workspace/agents/<agent-id>/AGENTS.md`, `SOUL.md`, `USER.md`, `TOOLS.md`, and
`MEMORY.md`.

## Common Improvements

When improving agent docs, prefer changes that reduce coordination mistakes:

- make coordinator/escalation boundaries explicit;
- replace broad labels like "read-only" with role-scoped permissions;
- name exact approval gates for external sends, merges, deploys, secrets, access,
  RBAC, DNS, firewall, production, and product direction;
- add concrete verification/reporting expectations;
- point to source truth instead of copying long upstream docs;
- keep runtime state, known caveats, and review cadence current.
