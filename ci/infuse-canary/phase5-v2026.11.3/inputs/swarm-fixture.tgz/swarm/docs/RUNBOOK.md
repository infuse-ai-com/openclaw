---
title: Runbook
description: "This repo now maintains one Kubernetes deployment target: InfuseAI
  Kubernetes namespace agents-swarm."
type: runbook
status: active
owner: team:agent-platform
tags:
  - runbook
---
# Runbook

This repo now maintains one Kubernetes deployment target: InfuseAI Kubernetes
namespace `agents-swarm`.

Historical ncase and local/kind deployment notes were removed from the active
runbook so operators do not accidentally follow an obsolete path. See
`docs/DECISIONS.md` and `docs/RUNTIME_BOOTSTRAP.md` only for history.

## Local Verification

Run:

```bash
task verify
```

This checks:

- InfuseAI deployment overlay renders with kustomize.
- Each active persistent-agent overlay renders with kustomize.
- Shell scripts parse with `bash -n`.
- The selected `AGENT_ID` OpenClaw profile bootstrap config renders as valid JSON.
- The selected `AGENT_ID` Mattermost Secret manifest renders with a placeholder token.
- The selected `AGENT_ID` persona files render into `/tmp`.
- Per-agent persona source install, manifest metadata, memory preservation, and
  drift reporting work in a temporary workspace.
- Agent skill bundles validate, including bundle-to-runtime drift checks.
- Local agent draft reporting and daily-memory export wrapper smoke against a
  temporary runtime workspace.

CI runs the no-host-skill-copy subset:

```bash
AGENT_ID=agent-designer task verify-ci
```

## Document Normalizer Pilot

The runtime image includes the approval-gated `openclaw-document-normalizer`
launcher and private service URL; the canonical client arrives with the synced
`document-normalizer` skill. See `docs/DOCUMENT_NORMALIZER_PILOT.md`. This
integration alone grants no consumer credential and performs no live
conversion; secret authorization/materialization remains a separate explicit
approval.

## Agent Memory Sync

Use `docs/AGENT_DRAFT_SYNC.md` before restarting, refreshing, or cleaning a
persistent agent that may have useful local edits.

Memory-core dreaming is separate from repository sync. Each agent's managed
dreaming job uses `openai/gpt-5.6-terra`; OpenClaw's built-in dreaming
execution profile supplies medium thinking. The model override is explicitly
allowlisted in each agent deployment, while the repository sync below remains
a mechanical Git publication step and does not invoke a model.

Daily raw memory/profile sync is handled by the Kubernetes CronJob
`openclaw-agent-memory-sync` at 04:00 Europe/Madrid. It runs
`openclaw-agent-sync-memory-repo-collector`, which execs into each running
persistent-agent pod and runs `openclaw-agent-sync-memory-repo`.

The v1 flow is mechanical:

1. Copy the agent's own local `memory/*.md` files.
2. Copy key local workspace Markdown files into `agents/<agent-id>/profile/`.
3. Copy local `MEMORY.md` into `agents/<agent-id>/MEMORY.md`.
4. Commit only under `agents/<agent-id>/` on a unique sync branch.
5. Open or reuse and squash-merge a GitLab MR after matching CI and merge policy pass into protected
   `openclaw-agents-memory/main`, then restore the local checkout to clean
   `main`.

Agents are responsible for curating their own local memory before sync. The
daily sync does not summarize or post Mattermost success messages. It skips
empty daily-note placeholders, validates the complete IKF selection, and uses
an automatic PR because direct writes to `main` are blocked by repository
policy.

Quick live summary:

```bash
for pod in $(kubectl --context infuseai-k8s -n agents-swarm get pods --no-headers \
  | awk '$1 ~ /^agent-/ && $3 == "Running" {print $1}' | sort); do
  echo "== $pod =="
  kubectl --context infuseai-k8s -n agents-swarm exec "$pod" -- sh -lc '
    openclaw-agent-local-drift-report | jq -r "
      [
        .agent_id,
        (.persona.dirty|tostring),
        ([.skills.manifests[]?.dirty] | map(tostring) | join(\",\")),
        (.memory.dirty|tostring),
        (.memory.unsynced|length|tostring),
        (.memory.changed|length|tostring)
      ] | @tsv"
  '
done
```

## Build Runtime Image

```bash
task image-build
```

Defaults:

- image: `openclaw-agent:dev`
- OpenClaw package version: pinned `2026.11.1` source `19818bb59a`
- bundled plugins: Codex, Mattermost, ACPX, and diagnostics `2026.11.1`
- Codex CLI version: `0.160.0`
- ACPX CLI version: `0.19.1`
- Bitwarden CLI package version: `2026.10.0` (qualified against the persisted
  Vaultwarden cached-session sync path; startup atomically removes the two
  legacy policy-cache records once and re-unlocks stale persisted sessions;
  do not bump without the runtime smoke)
- Dockerfile: `images/openclaw-agent/Dockerfile`

Override:

```bash
IMAGE=registry.example.com/openclaw-agent:branch task image-build
```

## Upgrade OpenClaw Runtime Version

The persistent agents do not update OpenClaw directly at runtime. They run the
exact checksum-verified internal distribution installed into the shared image.
Do not change only `OPENCLAW_VERSION` or substitute a moving npm tag. Upgrades
must update the source SHA, Core artifact URL/checksum, sealed consumer lock,
candidate manifest, compatible Studio metadata, and image smoke contract
together.

1. Confirm the target source and release package exist and verify the published
   checksum before using the archive:

```bash
curl -fsSL <release>/SHA256SUMS | rg 'openclaw-<version>-<commit>.tgz'
```

2. Update the tracked source, artifact, checksum, and version pins:

- `Taskfile.yml`: canonical reviewed source, artifact, checksum and build defaults.
- `images/openclaw-agent/openclaw-consumer/`: sealed consumer package and lock.
- `config/qualification/`: candidate manifest and Studio inventory pin.
- `images/openclaw-agent/Dockerfile`: Core and CLI composition plus bundled-plugin smoke.
- `README.md`: operator examples.
- `docs/RUNBOOK.md`: this runbook's defaults and examples.

The Dockerfile must remain checksum-gated and install Core through the sealed
consumer with normal npm lifecycle/native optional dependency handling. Do not
install duplicate Codex, Mattermost, ACPX, or diagnostics plugin packages.

```text
echo "${OPENCLAW_PACKAGE_SHA256}  artifacts/openclaw-<version>-<commit>.tgz" | sha256sum -c -
npm ci --omit=dev --no-audit --no-fund
```

Keep Dockerfile, Taskfile, and release-input pins aligned. Persisted PVC plugin
installs can otherwise shadow the reviewed image runtime after rollout.

3. Verify locally:

```bash
rg -n "OPENCLAW_VERSION|CODEX_CLI_VERSION|ACPX_CLI_VERSION|OPENCLAW_PINNED_SOURCE_SHA"
AGENT_ID=agent-designer task verify-ci
git diff --check
```

4. Commit, push, and open a GitLab merge request:

```bash
git switch -c chore/openclaw-runtime-<version>
git add Taskfile.yml images/openclaw-agent/Dockerfile README.md docs/RUNBOOK.md docs/REPO_MAP.md scripts/verify-openclaw-agent-entrypoint.sh
git commit -m "chore: promote pinned OpenClaw runtime"
git push -u origin chore/openclaw-runtime-<version>
```

5. After source verification and integration pass, create a protected `main`
pipeline with `RUN_GITLAB_CANDIDATE_BUILD=1` to build and scan a candidate.
Candidate jobs cannot deploy. Select the exact new digest and source through
the release workflow and retain the complete scan for remediation. Under the
[13 November advisory-scan policy](GITLAB_DELIVERY.md#advisory-security-scans-2026-11-13),
`RUN_GITLAB_DELIVERY=1` verifies the selected image and exposes manual rollout;
scan failures show GitLab warnings without blocking it. The historical
exception guard is retired. Registry identity and runtime compatibility checks
remain mandatory; scan results or missing reports are not deploy dependencies.
The rollout uses
`system:serviceaccount:agents-swarm:gitlab-openclaw-swarm-deployer`, patches
only the five persistent-agent Deployments, serializes through the
`openclaw-swarm-production` resource group, rejects stale live source
annotations, and advances developer, leaf, then coordinator. Secret reads,
pod exec, PVC mutation, RBAC mutation and cross-namespace access are denied.

Historical image-only rollback is retired. Recovery must preserve the captured
source, configuration and PVC-schema compatibility recorded in the current
release qualification. Keep the deployed Studio authority profile unchanged unless a
separate switch has settled runs and effects with source admission disabled.
Artifact Registry shared-service delivery belongs to Studio.

Security rebuilds preserve the pinned Core archive and existing CLI versions
while updating the consumer lock and rebuilding the Go toolbox. The Dockerfile
checks actual installed dependencies with
`scripts/verify-agent-runtime-dependencies.mjs`, retains Go module receipts under
`/usr/local/share/agent-go-build-info/`, and runs the isolated HTTP/MCP smoke in
`scripts/smoke-agent-http-dependencies.mjs`. These checks supplement the full
image scan. See the [remediation plan](plans/active/runtime-security-remediation-2026-11-12.md).

Before scheduling Stewie, Ramiro, or Satwa on a new or rebuilt node,
[install and verify its Chromium seccomp profile](../k8s/platform/chromium-sandbox/README.md).

6. After an approved release, confirm rollout and live OpenClaw versions:

```bash
kubectl --context infuseai-k8s -n agents-swarm get deploy \
  -o 'custom-columns=NAME:.metadata.name,IMAGE:.spec.template.spec.containers[0].image,READY:.status.readyReplicas,UPDATED:.status.updatedReplicas,AVAILABLE:.status.availableReplicas'

for agent in agent-developer agent-designer agent-infra agent-coordinator agent-intake; do
  kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
    sh -lc 'openclaw --version'
  AGENT_ID="${agent}" task smoke-agent-runtime
done
```

7. Run `openclaw doctor` diagnostically inside every active pod:

```bash
for agent in agent-developer agent-designer agent-infra agent-intake agent-coordinator; do
  kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
    sh -lc 'openclaw --profile "${OPENCLAW_AGENT_PROFILE:-$AGENT_ID}" doctor'
done
```

Expected post-upgrade findings can include auth-profile SQLite migration,
plugin registry refreshes, browser config migration, and cron storage
normalization. Review each finding before any repair; run `doctor --fix` only
as a separately justified action:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec deploy/agent-developer -c agent -- \
  sh -lc 'openclaw --profile "${OPENCLAW_AGENT_PROFILE:-$AGENT_ID}" doctor --fix'
```

8. Check effective bundled plugin custody after persisted shadows are migrated:

```bash
for agent in agent-developer agent-designer agent-infra agent-intake agent-coordinator; do
  kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
    sh -lc 'openclaw --profile "${OPENCLAW_AGENT_PROFILE:-$AGENT_ID}" plugins list --json' \
    | jq -r --arg agent "$agent" '
        .plugins[]
        | select(.enabled == true and (.id == "acpx" or .id == "codex" or .id == "mattermost" or .id == "diagnostics-otel"))
        | "\($agent) \(.id) \(.version) \(.origin) \(.status)"'
done
```

Codex, Mattermost, ACPX, and diagnostics must all report version `2026.11.1`,
origin `bundled`, status `loaded`, and no managed install record. Stop the
rollout if any persisted shadow remains; do not repair it with an ad hoc npm
install or a manual pod restart.

Do not approve device scope-upgrade prompts as part of routine version updates.
Report the request id and leave approval to Fito.

Scope-upgrade prompts from `kubectl exec` diagnostics are not harmless: approving
`operator.write` or `operator.admin` turns that CLI device from a read-only
diagnostic client into a runtime control-plane actor that can mutate gateway or
agent state. Approve those scopes only for an explicit operations task, record
the request id, and remove or rotate the device after the task if the elevation
was temporary.

9. Confirm command-owner config is present in repo manifests before rollout:

```bash
rg -n 'commands.*ownerAllowFrom|mattermost:qx31qia617r38b4huiyx8jo7de' k8s/agents
AGENT_ID=agent-designer task verify-ci
```

If any deployment does not roll out or reports the old OpenClaw version, inspect
the approved build evidence first to confirm the Docker build received the expected
`OPENCLAW_VERSION` build arg, then check the deployment image tag and recent pod
logs with `AGENT_ID=<agent> task status-agent`.

## Push Runtime Image

Publish only from an approved release of a reviewed `main` commit. Record
the immutable image digest and the exact source before any rollout.

```bash
TAG="$(git rev-parse --short=12 HEAD)" task image-push-agent
```

## Model Auth Reauthentication Triage

Doctor can report expired or invalid model auth for a provider profile, for
example `openai:aog.olea@gmail.com`. Treat this as credential maintenance, not
as part of a routine image or package upgrade.

The full single-agent OpenAI/Codex OAuth repair flow lives in
`docs/AGENT_VAULTWARDEN_ACCOUNT_RUNBOOK.md#openaicodex-oauth-refresh-for-one-agent`.
Use that runbook rather than inventing a new reauth path. The important lesson
from the Emon Lusk repair is that stale OAuth refresh state may live in the
agent's per-agent PVC SQLite auth store, so rotating a Vaultwarden item or K8s
env Secret alone may not fix `refresh_token_reused`.

Read-only triage:

```bash
for agent in agent-coordinator agent-developer agent-designer agent-infra agent-intake; do
  kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
    sh -lc 'openclaw --profile "${OPENCLAW_AGENT_PROFILE:-$AGENT_ID}" doctor --no-workspace-suggestions'
done
```

If the gateway is running, also inspect model status without printing secrets:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec deploy/agent-developer -c agent -- \
  sh -lc 'openclaw --profile "${OPENCLAW_AGENT_PROFILE:-$AGENT_ID}" models status'
```

Reauthentication should be done only through the approved single-agent runbook.
Do not paste OAuth tokens, refresh tokens, API keys, browser callback URLs,
SQLite contents, or Kubernetes Secret YAML into Mattermost, Git, shell history
snippets, or docs. After reauth, rerun `doctor`, model status/probe, the agent
runtime smoke, and watch the next scheduled/background turn for that agent.

## Semantic Memory Search

Persistent swarm agents currently run with semantic memory search disabled:

```json
"agents": {
  "defaults": {
    "memorySearch": {
      "enabled": false
    }
  }
}
```

This avoids noisy doctor warnings and avoids creating a hidden dependency on an
OpenAI API key for semantic recall. Re-enable it only after a dedicated
per-agent credential path is approved and documented.

## Archive Orphan Session Transcripts

Doctor may report orphan transcript `.jsonl` files under an agent's
`sessions/` directory. These are files that are no longer referenced by
`sessions.json`; they can be archived by renaming them to
`*.deleted.<timestamp>`.

Use the repo helper so the archive is based on the session store, not on a
blanket file move:

```bash
pod="$(kubectl --context infuseai-k8s -n agents-swarm get pod \
  -l app.kubernetes.io/name=agent-intake \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"
kubectl --context infuseai-k8s -n agents-swarm cp \
  scripts/archive-orphan-session-transcripts.py \
  "${pod}:/tmp/archive-orphan-session-transcripts.py" -c agent
kubectl --context infuseai-k8s -n agents-swarm exec "$pod" -c agent -- \
  python3 /tmp/archive-orphan-session-transcripts.py \
    /workspace/.openclaw-state/agents/agent-intake/sessions
kubectl --context infuseai-k8s -n agents-swarm exec "$pod" -c agent -- \
  python3 /tmp/archive-orphan-session-transcripts.py \
    /workspace/.openclaw-state/agents/agent-intake/sessions --apply
```

Repeat per agent after reviewing the dry-run count.

## Render Manifests

```bash
task render
```

Rendered files are written under `/tmp/openclaw-k8s-swarm-*.yaml`.

Render the exact InfuseAI overlay image/tag used by CI:

```bash
TAG="$(git rev-parse --short=12 HEAD)" task render-infuseai-agents
```

## InfuseAI Agents Swarm Deploy

The live target is:

- kube context/service connection: `infuseai-k8s`
- namespace: `agents-swarm`
- Harbor project: `agents-swarm`
- runtime image: `registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:<tag>`

GitLab verifies source on merge requests and ordinary default-branch pushes.
An approved protected pipeline builds and scans an immutable image, then
exposes a manual deployment. The `openclaw-swarm-production` resource group
serializes deployment and rollback without requiring ConfigMap write access.
The narrowly scoped deployer patches only the five persistent-agent
Deployments, and the rollout job allows up to 120 minutes for the bounded
sequence.

The 2026-11-07 GitLab authority cutover is same-version and does not perform a
state-schema upgrade. Fito explicitly excluded backup and restore work from
that cutover. This is not restore qualification; its rollback is limited to
the exact pre-cutover image and source annotations.

For the bounded `2026.11.1` upgrade, use
`RUNTIME_ONLY_UPGRADE=true`. The rendered apply stream is reduced to the five
persistent-agent Deployments; PVCs, Services, NetworkPolicies, ConfigMaps,
CronJobs, RBAC/ServiceAccounts, Studio authority, OTel, SQL mission workloads,
credentials, and retired resources are omitted and preserved. Automatic Doctor
repair is disabled, so a missing persisted migration marker stops the canary.

This promotion is a **high-risk persistent-state upgrade**: the existing
2026.10.3 runtime supports shared-state schema 20, while 2026.11.1 supports and
may migrate to schema 22. Before authorizing any release that upgrades persisted
state, create and verify a
restricted recovery artifact for every active persistent-agent PVC. Bind those
five receipts to the live 2026.10.3 image digest
`sha256:5b660ae33ba1587475fdfc56df989e490ff904f6382d3ea8943a75c3183ecec7`
and swarm source `b32e131d3413f4869a317264db27e81f76c6f4bc`. If any backup, SQLite
integrity check, or post-backup recovery fails, stop the upgrade. After schema 22 is
written, binary rollback requires the matching pre-upgrade recovery artifacts;
never point 2026.10.3 at migrated state.

The deploy helper preserves each existing persistent agent's replica count and
defaults to a bounded `canary-wave`: `agent-developer` advances alone;
`agent-designer`, `agent-infra`, and `agent-intake` then advance concurrently;
`agent-coordinator` advances only after the complete leaf batch passes. For each
active agent it independently:

1. obtains the exact Gateway PID and process-instance identity;
2. requests `gateway.suspend.prepare` with draining enabled and renews the
   lease while work finishes; the current in-pod `preStop` helper arms a ready
   exact-predecessor handoff after Kubernetes starts termination;
3. scales only that Deployment to zero and waits for the exact old pod to exit;
4. applies the target Deployment held at zero, then restores its prior replica
   count;
5. requires rollout readiness, startup evidence, `/readyz`, a different
   process-instance identity, and the expected immutable image digest before
   returning. A leaf failure waits for already-started leaf rollouts to settle,
   then blocks coordinator promotion.

Use the sequential rollback strategy when a change needs strict one-agent
promotion or when diagnosing wave-level capacity:

```bash
OPENCLAW_FLEET_ROLLOUT_STRATEGY=sequential \
  TAG="$(git rev-parse --short=12 HEAD)" task deploy-infuseai-agents
```

All persistent-agent Deployments use `Recreate`, a 420-second safety ceiling,
`/readyz` and `/healthz` probes, and an in-pod lifecycle `preStop` helper. The
stable controller defaults to bounded mode: it gives active work 30 seconds,
requires terminal persistence to clear, and requires the exact-predecessor
handoff. Controller-led rollouts arm the handoff before termination and send a
15-second grace in the initial pod delete request. This is required for current
and older helpers: OpenClaw handles SIGTERM as a restart request, while a kubelet
may not honor a shorter deadline after termination has begun with the 420-second
emergency ceiling. The pod-level `preStop` remains the fail-safe for termination
outside the controller. The old pod must disappear in 30 seconds or the rollout
stops before applying the replacement and requests asynchronous recovery.

```bash
OPENCLAW_ROLLOUT_MODE=bounded TAG="$(git rev-parse --short=12 HEAD)" task deploy-infuseai-agents
```

Use opt-in drain mode when completing active work is more important than
deployment latency. It waits up to 300 seconds and resumes the old Gateway and
fails closed if work remains; it never silently converts into forced handoff:

```bash
OPENCLAW_ROLLOUT_MODE=drain TAG="$(git rev-parse --short=12 HEAD)" task deploy-infuseai-agents
```

Startup does not use role-stagger delays; rollout orchestration owns fleet
concurrency. Kubernetes applies the workspace `fsGroup` only on root mismatch,
and the root init container checks the workspace root owner before deciding
whether to run recursive `chown`. Existing correctly owned PVCs therefore take
the constant-time path. Fresh volumes or restored volumes whose root ownership
is not `10001:10001` still take the full repair path. If a restore can contain
mixed ownership under a correctly owned root, normalize that recovery artifact
before rollout or use the sequential recovery procedure rather than relying on
the fast path.

Stable delivery records the full Swarm source commit on every persistent-agent
pod template. It compares the new source against the one consistently running
across the fleet. Changes limited to the SQL mission platform, docs, and tests
preserve all five persistent-agent pod templates while updating platform
workloads. Missing, mixed, or unreachable live provenance fails safe to a full
canary-wave rollout.

Before an exact canary or fleet promotion, classify persistent-state risk and
record the classification in the release evidence. Fresh recovery artifacts
are required when the rollout changes persistent storage layout, data or
database schemas, state ownership or permissions, state migration or deletion
behavior, or rollback compatibility with post-upgrade state. Treat uncertain
state compatibility as high risk. Routine image, code, or configuration
releases that leave persistent state backward-compatible use the lifecycle
drain and immutable previous-image rollback path without a fresh full-PVC
backup.

For a high-risk promotion, create a restricted-permission, fully extracted
recovery artifact for every affected PVC. The backup helper drains the Gateway,
stops exactly that one Deployment, mounts its PVC read-only in an isolated
no-token backup pod, streams the artifact, restores the existing Deployment,
extracts the entire archive, and runs SQLite `quick_check` on recovered
databases. Any directory whose basename is `node_modules` is omitted because
dependencies are reproducible from the retained source and lockfiles; the JSON
verification record declares that exclusion explicitly. OpenClaw state,
repositories, Git metadata, uncommitted files, and other workspace data remain
in scope. A single failed stream or archive validation is retried once while
the same read-only backup pod remains mounted; a second failure restores the
original Deployment and rejects the partial artifact:

```bash
mkdir -p /absolute/private/backup-root
KUBE_CONTEXT=infuseai-k8s scripts/backup-agent-workspace.sh \
  agents-swarm agent-developer /absolute/private/backup-root
```

Keep the emitted archive, JSON verification record, and SHA-256 sidecar outside
the cluster. Agents that were already scaled to zero remain at zero.

Do not merge to `main` unless a live swarm deploy is intended and approved.

Before the first rollout, ensure namespace-scoped runtime secrets exist in
`agents-swarm`:

- `harbor-pull`
- `openclaw-runtime`
- `agent-developer-mattermost`
- `agent-developer-vaultwarden`
- `agent-developer-authentik`
- `agent-designer-mattermost`
- `agent-designer-vaultwarden`
- `agent-designer-authentik`
- `agent-infra-mattermost`
- `agent-infra-kubeconfig`
- `agent-infra-vaultwarden`
- `agent-infra-authentik`
- `agent-coordinator-mattermost`
- `agent-coordinator-vaultwarden`
- `agent-coordinator-authentik`
- `agent-intake-mattermost`
- `agent-intake-vaultwarden`
- `agent-intake-authentik`
- role mailbox item `Email / rmr.g@infuse-ai.com account` available through the `agent-intake-vaultwarden` lookup path

The current local `infuseai-k8s` context is not cluster-admin. A cluster-admin
identity must run this one-time bootstrap before CI can deploy:

```bash
kubectl apply -f k8s/overlays/infuseai/bootstrap-rbac.yaml
```

The bootstrap RoleBinding grants deploy rights to service account
`openclaw-swarm-deployer` in namespace `platform-operators`, which is the
least-privilege identity used only by the dedicated
`infuseai-k8s-openclaw-swarm` Kubernetes service connection. Do not rotate the
shared `infuseai-k8s-Infuse AI` endpoint in place; other pipelines use it.
The approval-only cluster-admin identity is never configured on that endpoint.
During the bounded cutover, the same RoleBindings retain the legacy
`oleagut/openclaw-agent` subject for rollback. Remove that subject immediately
after the GitLab release and post-deploy checks prove the replacement.

After bootstrap, CI applies only namespaced runtime resources. The normal deploy
script intentionally renders the namespace object out of the runtime manifest so
the deploy identity does not need cluster-scoped namespace write permissions.

The InfuseAI overlay also grants
`system:serviceaccount:platform-operators:openclaw-swarm-deployer` bounded
diagnostics in `agents-swarm` for post-deploy smoke checks: pods, pod logs,
events, deployments, replicasets, PVCs, services, configmaps, and jobs. It does
not grant Secret reads. It also grants `create` on the `pods/exec` subresource
for targeted in-pod acceptance checks.

## Status And Smokes

Inspect one live agent:

```bash
AGENT_ID=agent-developer task status-agent
```

Run live smokes only when a runtime check is intended. Some smokes use
`kubectl exec`, and `task smoke-workspace` restarts the selected deployment.

```bash
AGENT_ID=agent-developer task smoke-agent-runtime
AGENT_ID=agent-developer task smoke-agent-toolbox
AGENT_ID=agent-infra task smoke-agent-infra-kube-access
```

Repo checkout smoke:

```bash
AGENT_ID=agent-infra TASK_ID=repo-smoke-$(date -u +%Y%m%d%H%M%S) task smoke-agent-repo-checkout
```

Workspace persistence smoke:

```bash
AGENT_ID=agent-developer task smoke-workspace
```

PVC backup/restore mechanics smoke:

```bash
AGENT_ID=agent-developer task smoke-pvc-backup-restore
```

Follow logs:

```bash
AGENT_ID=agent-coordinator task logs-agent
```

## Add A New Persistent Agent

Use the dedicated runbook:

```text
docs/NEW_AGENT_RUNBOOK.md
```

Start from:

```text
docs/agents/TEMPLATE.md
../openclaw-agents-persona/templates/agent-persona/
k8s/components/persistent-agent/
```

Each active persistent agent has its own Kubernetes Deployment and PVC. Current
live workloads are:

- `deploy/agent-developer`
- `deploy/agent-designer`
- `deploy/agent-infra`
- `deploy/agent-coordinator`

Do not activate a new persistent agent by adding another profile to a shared
legacy deployment. Add the agent overlay under `k8s/agents/<agent-id>/`, include
it from `k8s/overlays/infuseai/kustomization.yaml`, and include it in the
separately approved release from the reviewed `main` commit.

## Scheduled assurance qualification

The former daily assurance ran at 02:15 UTC. The current GitLab configuration
provides source checks. Qualify a separate schedule before relying on automated
dependency evidence, SonarQube coverage, image scans or notifications. Preserve
the exact Taskfile build inputs and digest, run the dependency check with
`scripts/run-dependency-assurance.sh`, and collect Python JUnit and coverage
plus the behavioral-observability plugin’s LCOV report as defined in
`sonar-project.properties`. Route notifications through the approved protected
webhook. Preserve success evidence and independent failure reporting without
exposing credentials or private runtime state.
