---
title: Internal Gateway Transport
description: Provision, validate, rotate and roll back the dashboard's authenticated in-cluster gateway transport.
type: runbook
status: draft
owner: team:agent-platform
tags:
  - openclaw
  - kubernetes
  - security
  - operations
---

# Internal gateway transport

The dashboard can reach a selected same-cluster agent through a private Kubernetes
Service with mutual TLS. Tailscale remains a separately selected transport for
external agents and a deliberate rollback choice. The browser still uses
`https://agents.infuse-ai.com`; it never receives cluster URLs or TLS keys.

`config/internal-gateway-transport.json` selects the five explicitly reviewed
agents. All five were activated and individually verified on 2026-11-10, after
Tinus qualified first. The dated evidence below records that rollout; a future
render selection is not itself fresh live activation evidence. No image build, RBAC change, public Ingress,
Tailscale ACL change, or broad node/network trust is required by this transport.

The Tinus pilot passed fresh TLS 1.3 certificate fingerprint checks, real HTTP and
native WebSocket/admin/Fito identity checks, and missing-client, wrong-server-name
and untrusted-client rejection. Local password administration and Mattermost
connectivity remained healthy. Real Tinus/Stewie chats answered synthetic checks
while Tinus used internal mTLS and Stewie retained Tailscale; docked Details stayed
352 pixels wide at a 1600-pixel viewport. No production latency percentile or
wire-count improvement is claimed.

The first pilot attempt exposed a projected ConfigMap symlink entrypoint bug.
It was rolled back before any route change, then fixed through swarm MR !34.
The corrected listener resolves its CLI path and passed a real projected-file
startup check with Node24 and UID10001. Use the current content-hashed ConfigMap;
do not reuse the first pilot's listener artifact.

## Connection and trust boundary

1. The existing dashboard relay authenticates the browser, checks the exact
   gateway grant, and constructs upstream headers. It must overwrite identity,
   forwarding, Origin and scope headers for both HTTP and WebSocket upgrades;
   client cookies, Authorization and incoming forwarding headers are not passed
   through. Phase2 identity and gateway administration policy remain authoritative.
2. For an explicitly configured internal transport, that relay validates the
   gateway's dedicated server CA and exact Service DNS name, presents its
   dashboard-only client certificate, and connects to Service port 443. TLS
   verification cannot be disabled; redirects cannot change the destination.
3. The Service targets port 8443 on the selected agent Pod. A NetworkPolicy admits
   only Pods labelled `app.kubernetes.io/name=openclaw-dashboard` in namespace
   `agents-swarm`. The namespace and Pod selectors are in the **same** peer. The
   dashboard repository must also permit egress to the selected agent Pod labels
   on destination port 8443; ClusterIP port 443 is translated to that Pod port.
4. The tunnel requires TLS 1.3, a valid chain from the dedicated client CA, an exact
   DNS SAN `openclaw-dashboard.agents-swarm.svc.cluster.local`, and a clientAuth-only
   leaf certificate. Missing, expired, wrong-CA, wildcard, different-name,
   server-only and dual-purpose certificates are rejected. It forwards opaque
   HTTP/1.1 and WebSocket bytes only to `127.0.0.1:18791`.
5. OpenClaw sees a loopback proxy. The render preparation appends only
   `127.0.0.1` to the existing `gateway.trustedProxies=["10.1.42.208"]` and enables
   `gateway.auth.trustedProxy.allowLoopback`. It preserves the Tailscale source,
   exact allowUsers, identityScopes, required forwarding headers, allowed browser
   origins, and the local password fallback used by Studio. Native auth explicitly
   tests local-direct password fallback with allowLoopback enabled.

Loopback trust covers the **whole existing agent Pod trust domain**, including
processes in the agent container. It cannot distinguish processes by container.
The agent already owns its local gateway password and gateway state; this change
does not turn that Pod into an isolation boundary for untrusted tools. Do not add
untrusted containers to these Pods or treat mTLS as a replacement for dashboard
grant checks. No cluster CIDR, node address or dashboard Pod IP is trusted by the
native gateway.

The sidecar uses the exact same immutable image as its agent. Kubernetes overrides
the image entrypoint with `/usr/local/bin/node /opt/gateway-internal-tls/tunnel.mjs`,
so agent bootstrap does not run twice. UID/GID 10001, a read-only root filesystem,
no capabilities and no privilege escalation are explicit. It mounts only its code,
its own TLS leaf/key and client CA bundle. An empty read-only mount at the automatic
service-account-token path prevents token injection into this container; existing
agent token, workspace, Mattermost, provider and Studio mounts are unchanged.

## Certificates and Secrets

Use **two dedicated issuance hierarchies**: gateway server certificates and
dashboard client certificates. Never reuse the cluster serving CA, Tailscale
certificates, Authentik signing keys, or either hierarchy for the opposite role.
CA private keys stay in the approved issuer/credential store; they are never put
in application Pods, source, CI logs or this repository. Certificates are not
obtained from the gateway's chat/tool capabilities.

All resources below are in namespace `agents-swarm`:

| Agent | Server DNS SAN / dashboard upstream hostname | Server Secret |
| --- | --- | --- |
| Tinus | `agent-developer-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-developer-dashboard-internal-tls` |
| Stewie | `agent-designer-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-designer-dashboard-internal-tls` |
| Emon Lusk | `agent-coordinator-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-coordinator-dashboard-internal-tls` |
| Ramiro Garcia | `agent-intake-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-intake-dashboard-internal-tls` |
| Satwa Nutella | `agent-infra-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-infra-dashboard-internal-tls` |

Each server Secret has `tls.crt` (server leaf then intermediates), `tls.key` (that
agent's private key), and `client-ca.crt` (client trust bundle only). File mode is
0440 with Pod fsGroup 10001. Use a distinct key/leaf per agent with `CA:FALSE`,
digitalSignature and **only** EKU serverAuth; no wildcard or CN fallback. The
tunnel checks its own configured DNS SAN, role and validity before listening.
Use a short descriptive Common Name: some full Service DNS names exceed X.509's
64-character CN limit. Put the full exact hostname in DNS SAN, never rely on CN.

The dashboard repository owns Secret `openclaw-dashboard-gateway-client-tls`,
containing `tls.crt`, `tls.key` and `server-ca.crt`. Its leaf has `CA:FALSE`,
digitalSignature, **only** EKU clientAuth, and exact DNS SAN
`openclaw-dashboard.agents-swarm.svc.cluster.local`. Only the dashboard mounts its
private key. The server trust bundle contains only the dedicated gateway server
CA hierarchy. Do not mount any agent's private key in the dashboard.

Provision leaves with a bounded lifetime (at most 90 days), record expiration and
public certificate fingerprints in protected operations evidence, and renew at
least 30 days before expiry. The bounded operating mode is an offline operator-run
issuer, durable Vaultwarden custody, and automated expiry checking in the existing
weekly runtime assurance. [Internal gateway PKI](INTERNAL_GATEWAY_PKI.md) defines
the four commands, exact custody, renewal and activation prerequisites. It does
not install cert-manager, give CI signing keys, or perform unattended renewal.

## Dashboard transport contract

The dashboard adapter must designate each registry entry explicitly, for example
`internal-mtls` versus the existing Tailscale transport. An internal entry binds
exactly one of the hostnames above to HTTPS/WSS port 443, system cluster DNS,
that hostname for TLS verification/SNI, the dedicated server CA, and the
dashboard client identity. It must use the same transport for resource HTTP and
gateway WebSocket requests. Do not infer internal routing from arbitrary URLs,
Pod availability or an agent display name. There is no automatic downgrade to
HTTP, Tailscale or another gateway after a TLS/authentication failure.

The adapter must not send the private dashboard client certificate to Tailscale
or a bring-your-own-agent origin. Tailscale retains its existing hostname
verification, DNS/egress routing and explicit grant configuration. Gateway IDs,
browser routes, approved sidebar layout and persistent connection pool keys stay
stable when the operator changes an entry's transport.

## Local verification and phase2 integration

Use `scripts/render-infuseai-agents.sh`, not a direct `kubectl kustomize`, when
testing the selected internal transport. The renderer applies Studio preparation
first and then structurally edits the resulting gateway JSON in a temporary tree.
It refuses unexpected source trust/auth shapes. It does not rewrite checked-in
agent configuration. This avoids conflicts with the preceding Fito identity MR;
rebase this MR onto that merge, rerun the focused tests, and confirm its exact
allowUsers/identityScopes are unchanged in the rendered manifest.

```sh
python3 -m unittest discover -s tests -p test_gateway_internal_tls.py -v
python3 -m unittest discover -s tests -p test_internal_gateway_transport_patch.py -v
python3 -m unittest discover -s tests -p test_dashboard_tls_ingress.py -v
python3 -m unittest discover -s tests -p test_studio_native_profiles.py -v
python3 scripts/verify_knowledge_format.py --root=.
bash -n scripts/render-infuseai-agents.sh
git diff --check
```

The focused suite generates ephemeral test certificates and runs real HTTP,
WebSocket and TLS rejection checks against a loopback gateway fixture; it needs
Node (24 is the deployed runtime), OpenSSL and free local port 18791. It also
renders both one-agent and five-agent configurations and checks immutable image
parity, ConfigMap hash references, scope preservation and unchanged unselected
agents. No kube context, live credentials or cluster access is used by these tests.

For each selected agent, render the checked-in fleet selection
with its existing immutable image and the reviewed checkout commit:

```sh
umask 077
IMAGE_REVISION=sha256:ff0fac8da285c4b94e1b95ab94b4cbafdd06d10dd161104941894fe6ba4e1ea9 \
SOURCE_REVISION="$(git rev-parse HEAD)" \
  scripts/render-infuseai-agents.sh > /private/operations/tinus-reviewed-render.yaml
```

Confirm that the live Tinus image still matches this pin before preparing its
guarded patch. Extract only the selected agent's reviewed additions from its matching render;
never apply the other rendered Deployments or change their image pins. Stewie retains its existing `ff0fac8…` image; Emon, Ramiro
and Satwa retain `sha256:488aaa8ec4c115bb5782f251f8832de1f9beb914e1be3bb35734ad46b25a20fe`.
For an offline alternate selection, set `INTERNAL_GATEWAY_TRANSPORT_CONFIG` to
a non-secret temporary contract; that override is not activation authorization.
The ordinary renderer accepts one image revision per
render; a mixed-image fleet therefore requires separate reviewed renders. Never
apply a rendered agent Deployment over a live one: that can overwrite unrelated
live changes, even with the correct image. The current GitLab image deploy job
does not install sidecars. Use the additive patch procedure below for this change;
do not converge Tinus/Stewie onto a different image.

## Guarded additive Deployment patch

`scripts/internal-gateway-transport-patch.py` is an offline preparation tool. It
does not invoke kubectl, access the network, provision Secrets, scale workloads,
or apply manifests. It reads one protected live Deployment snapshot and a reviewed
render represented as a Kubernetes JSON List. The List must include the selected
Deployment and its content-hashed TLS ConfigMap. Preserve a reviewed render's
source revision and immutable image in the operations evidence; converting the
local YAML artifact to JSON must not change its contents.

The tool verifies the selected namespace, agent, explicit Deployment UID and
resourceVersion, and the current immutable agent image. The rendered agent and
tunnel must have that same exact image. The tunnel's command/security/mounts must
match the reviewed source, and the referenced ConfigMap data must byte-match
`tunnel.mjs`. Its Secret name and mounted keys are fixed to the selected agent.
Existing Fito administration, trusted-proxy header/device/password settings,
Pod network isolation and fsGroup must still match their required boundaries.

Only two native config fields change: `127.0.0.1` is appended to trustedProxies
and allowLoopback is enabled. The helper serializes the **live** configuration,
preserving all its other values, rather than copying configuration from the
render. It appends the reviewed sidecar and three TLS volumes, preserving every
other Pod/Deployment field, including images, probes, drain handling, replicas,
service accounts, PVCs, env, annotations, node placement and unrelated sidecars.
The patch tests UID, resourceVersion, agent image and exact original config bytes
before any writes, so a concurrent change/recreated Pod controller requires a
fresh read and review. It never retries against a newer resourceVersion itself.

This preservation guarantee covers the live Deployment and its config environment
value. The existing `scripts/boot-agent-developer-canary.sh` derives its canonical
config from `OPENCLAW_CONFIG_JSON`, then rewrites the profile/state `openclaw.json`
files during startup. Native settings changed only in those files can therefore
be replaced on **any** restart, including this rollout. Before patching, compare
the effective runtime config against the Deployment's boot-canonicalized config
using protected operations evidence. Reconcile legitimate file-only changes with
the config owner before proceeding; do not assume this offline helper observes
or merges them. Never print file contents, credentials or raw config diffs in the
MR or terminal. User profiles and chat state are separate persisted owners and
are not inputs to this helper.

Example preparation with explicit values from the selected live snapshot:

```sh
python3 scripts/internal-gateway-transport-patch.py \
  --agent-id agent-developer \
  --expected-image 'registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:<verified-current-digest>' \
  --expected-uid '<selected-deployment-uid>' \
  --expected-resource-version '<selected-resource-version>' \
  --input /private/operations/tinus-live.json \
  --rendered /private/operations/tinus-reviewed-render.json \
  --dry-run
```

After reviewing the safe summary, repeat with
`--output /private/operations/tinus-internal-transport.patch.json` instead of
`--dry-run`. The new patch file is created exclusively at mode 0600. Existing
files, symlinks and stdout output are refused. Config bytes and environment values
are never printed; the patch itself contains private live configuration and must
remain protected. The original input is the protected rollback evidence.

A complete matching installation returns an empty patch. Only harmless Kubernetes
API defaults on the sidecar's termination/probe fields are normalized. Partial
installations, changed sidecar settings/mounts, different ConfigMap code/hash,
wrong Secrets, additional loopback trust or another declared 8443 listener are
refused. Reconcile such state explicitly; do not delete guards or overwrite it
with a full rendered Deployment. This install helper deliberately does not perform
automatic code upgrades or rollback of an already drifted transport.

The operator separately applies only the reviewed hashed ConfigMap and selected
internal Service/NetworkPolicy after Secret provisioning. Apply the protected
JSON Patch to the exact selected Deployment under the approved rollout procedure,
then observe its existing Recreate/drain/readiness behavior. Do not pass the full
fleet render or a zero-replica Deployment from the ordinary image rollout helper.
If a guard rejects the patch, capture a new snapshot, investigate the change and
regenerate; do not strip UID/resourceVersion/config tests.

The runtime image Dockerfile uses Node 24 and final USER 10001:10001. A local
existing trusted-proxy agent image was exercised on 2026-11-10 with no network,
read-only root, all capabilities dropped and UID 10001; `/usr/local/bin/node`
loaded core TLS and bound port 8443 successfully (Node 24.21.0). The delivery
owner also performed read-only `/usr/local/bin/node` checks in Tinus and Emon
on 2026-11-10: both reported Node 24.21.0, UID 10001 and core TLS availability.
Those checks cover the two deployed image digests:
`sha256:ff0fac8da285c4b94e1b95ab94b4cbafdd06d10dd161104941894fe6ba4e1ea9`
and `sha256:488aaa8ec4c115bb5782f251f8832de1f9beb914e1be3bb35734ad46b25a20fe`.
The checks did not invoke agent bootstrap or rebuild an image. Repeat them if
an agent's selected digest changes; the internal TLS listener still needs its
own pilot qualification with the issued production certificates.

## Pilot, fleet rollout and runtime evidence

1. Merge/verify phase2 identity first. Snapshot only the relevant non-secret
   transport settings, Deployment image/revision and Secret public fingerprints;
   keep private rollback material in the approved credential store.
2. Provision the dedicated CAs/leaves and Secret references through the approved
   operations path. Verify cert/key pairing, chains, EKUs, SANs and lifetime.
   Add the narrow dashboard egress and client Secret mount in its own MR. Confirm
   a Pod with the dashboard label but no client certificate is refused.
3. Enable **Tinus only** in the explicit pilot render contract. Review that render
   with its current image digest and prepare the guarded additive patch above. Preserve
   other Deployments and all original probes, preStop handling, images, PVCs,
   init containers, security identity, Mattermost and Studio configuration.
4. Apply only the reviewed selected transport resources and guarded Deployment
   patch through the approved operations path. Observe Recreate/agent drain for Tinus. Confirm gateway
   readiness and the TLS sidecar. The source code ConfigMap is content-hashed;
   TLS Secrets must exist before rollout. Missing/invalid TLS material prevents
   listener readiness and must not lead to a plaintext fallback.
5. Before changing the dashboard entry, validate from the permitted dashboard
   path: exact server chain/hostname; client certificate acceptance; no-client,
   wrong-client and wrong-name rejection; HTTP resources and WebSocket upgrade;
   Fito profile/admin scopes; and native localhost password authentication for
   Studio. Confirm gateway startup/readiness and Mattermost still work.
6. Change Tinus's explicit dashboard transport only. Test real Tinus/Stewie chat
   switching with persistent connections and the approved Details layout. Check
   that Tinus now reaches the ClusterIP while Stewie remains on Tailscale, and
   that a reconnect uses the same authenticated identity and physical session.
7. Advance remaining agents individually, preserving each current image digest.
   Repeat gateway/admin/profile, resource, Studio and Mattermost checks. Save
   bounded health/handshake/route evidence without chat bodies, private keys or
   bearer tokens. Commit the final explicit enabled-agent list through an MR.

The repository change itself does not prove CNI policy enforcement, cluster DNS,
Secret projection, actual certificate issuance, TLS permission boundaries, or
the five running images. These are required pilot checks before switching traffic.
The rollout evidence below is bounded to its observation; future source selection
or a previously published record does not prove a current handshake.

## Completed rollout observation — 2026-11-10

Swarm MR !35 merged at `4d29123f76237bf484dce681a29d86727564c475`, with
main pipeline 1493 passing. Stewie, Emon, Ramiro and Satwa were then activated
individually, following Tinus. Each restart had a fresh effective-config versus
boot-derived-config check with no unresolved drift. Guarded patches preserved the
current primary image, personal profiles, provider accounts, PVCs, probes, drain
handling and unrelated configuration. The TLS sidecar used the same image as its
primary agent. No full rendered Deployment was applied.

All five selected routes passed fresh TLS1.3 server/client issuance fingerprint
checks, native HTTP/bootstrap and WebSocket/admin/Fito identity checks, and
missing-client, wrong-server-name and untrusted-client rejection. Local password
admin reads succeeded after enabling loopback proxy trust. Default Mattermost
accounts remained connected; no Mattermost-origin message was sent by this
verification. A disposable Pod without the dashboard label resolved the Service
but timed out connecting, while the permitted dashboard path succeeded. Both
probe Pods were removed.

At **19:38:47 UTC**, a final read-only audit using the assurance module's pure
image/transport/certificate validation functions confirmed five ready Deployments,
private Services, explicit internal dashboard routes, preserved Fito grants and
consistent public certificate annotations. This was not the full scheduled
assurance job. Each annotation was published only after matching a fresh actual
handshake to its issued and Vault-restored leaf. All five actual browser chats
answered a synthetic no-tools/no-changes prompt; twenty final Tinus/Stewie switches
retained Connected and stable 352-pixel docked Details geometry at 1600×1000.
Production wire counts and latency percentiles were not measured.

The existing agent images remain `ff0fac8da285…` on Tinus/Stewie and
`488aaa8ec4c1…` on Emon/Ramiro/Satwa. Separate server/client CA credentials and
all six leaves passed Vaultwarden save/restore and key-pair verification in the
existing `02-Kubernetes` collection. CA private keys were never mounted in Pods.
The leaves expire on **2027-02-08**; renew them **before 2027-01-09** using
[the PKI procedure](INTERNAL_GATEWAY_PKI.md). The weekly assurance implementation validates public expiry records; its
validation passed synthetic expiry fixtures and the live public-record audit.
This rollout did not execute a new scheduled end-to-end expiry notification.
Renewal remains an explicit operator operation.

Schedule 27 was observed active on `main` on 2026-11-10, with cron `15 5 * * 1`
in `Europe/Madrid`. Its latest scheduled pipeline 1353 failed overall on November 9;
the existing failure-notification job 5897 succeeded. This is evidence of enabled
scheduling and prior notification-job execution, not a new certificate-expiry
alert or a successful complete weekly assurance run. No new notification was
sent by this rollout verification.

The dashboard's `docs/operations/connection-identity-rollout-20261110.md` holds
the companion delivery record, exact image pins and public leaf fingerprints.
Tailscale remains available as an explicit transport and guarded rollback path.
The approved UI, personal accounts policy and Studio custody remain unchanged.

## Rotation and rollback

TLS material is loaded at process start. A projected Secret update alone does
**not** reload the listener or retire existing WebSocket sessions. Use the
existing controlled per-agent rollout and restart the dashboard connection owner
when rotating its identity; verify new certificate fingerprints on new handshakes.

For a CA rotation, first distribute overlapping old/new **public** trust bundles
to the opposite endpoint and restart those consumers. Then rotate leaves/keys and
restart their owners one at a time. Confirm all new chains and reconnects before
removing the old CA from each bundle and restarting consumers again. Never create
a bundle that mixes server and client issuers. For emergency revocation, replace
the compromised role's trust/identity and close existing connections; do not rely
on a certificate-file change to revoke already-established sessions.

Rollback order preserves access: switch the affected dashboard registry entry
explicitly back to its known Tailscale URL/transport and verify reconnection,
identity/admin scopes and Studio. Then remove that agent from enabledAgents and
prepare a separately reviewed inverse JSON Patch from a **fresh** live snapshot.
Guard its current UID/resourceVersion, config bytes and exact transport objects;
remove only the selected TLS sidecar, its three volumes, `127.0.0.1` and
allowLoopback. Remove array entries in descending index order. Preserve the current
image, phase2 identity and all other current config/Pod fields. Do not restore an
old whole Deployment or old whole config over later live changes. The install
helper does not generate this inverse patch automatically. Remove the
corresponding internal Service/NetworkPolicy and dashboard
egress only after traffic has moved; ordinary apply does not prune those objects.
Retire TLS Secret references and public trust only after no remaining selected
agent uses them. Preserve PVCs and native profiles throughout.

This indexed draft requires human review of the certificate issuer, activation
evidence and final rollout state before it is treated as an active operating
procedure. No human-review attestation is supplied by automation.
