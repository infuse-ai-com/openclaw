---
title: Agent Identities
description: This project is not meant to create another Kapiteky.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - agent
  - identities
---
# Agent Identities

This project is not meant to create another Kapiteky.

Kapiteky used to carry most coordination directly. Emon Lusk /
`agent-coordinator` is now the agent-team CEO and execution lead: Emon owns
missions, delegation, specialist management, synthesis, and follow-through.
Kapiteky guides vision/company coherence with Fito and advises Emon, without a
parallel specialist-management loop. The Kubernetes swarm is the substrate for
scoped teammates with their own identity, memory boundary, Mattermost presence,
and tool permissions.

## Strategy

Follow the hybrid model from `company-docs`:

- Start with role hats for most work.
- Promote a role into a persistent named agent only when repeated use proves that continuity, audit identity, or tool access is valuable.
- Keep product direction and final approvals with Fito.
- Keep swarm coordination and execution with Emon. Kapiteky participates only
  when Fito or Emon explicitly requests advice or a safety correction is needed.
- Prefer persistent identities first for bounded, verifiable work.

## Mattermost Identity Model

Each persistent agent should have its own Mattermost account or bot identity.

Identity conventions:

- runtime slug: `agent-<slug>` for Kubernetes, PVCs, config, and docs
- Mattermost username: prefer `agent-<slug>` for audit logs, but friendly variants such as `agent-designer` are acceptable when documented
- display name: friendly persona name when approved, such as Tinus Lordvals
- profile/bio: role, owner, permission level, and escalation rule
- default channel: the relevant private project-role channel managed by Emon
- project access: only the agent's role channels; mention-only by default

Agents should introduce themselves to Emon before receiving execution access:

```text
I am agent-<slug>.
Role: <role>.
Owner: Fito.
Coordinator / escalation: Emon Lusk / `agent-coordinator`; Kapiteky only when Emon or Fito explicitly requests advice.
Requested scope: <channels/repos/tools>.
Memory path: <path>.
Default permission: <read-only/draft/internal-write/etc>.
Actions requiring approval: <list>.
Verification I can perform: <checks>.
Retirement condition: <when to pause/remove me>.
```

Emon validates the execution role and routing. Fito approves access or autonomy
changes; Kapiteky advises only when Emon or Fito requests it. Record the result
in this repo or the relevant project docs.

## Access Bundle

Every persistent agent needs an access bundle before it becomes active:

- Mattermost identity and channel membership.
- Repository/project scope.
- Skill bundle from `config/agent-skill-bundles/<agent-id>.json`.
- Kubernetes namespace/service account if needed.
- Secret references, not secret values.
- Memory location.
- Allowed tools.
- Approval boundaries.
- Audit trail location.
- Review cadence.
- Offboarding checklist.

Use `docs/agents/README.md` as the agent-doc contract. It defines the required
sections, context-loading rule, reporting format, roster, and live core-file
sync checklist for these per-agent docs.

## First Persistent Candidates

### Tinus Lordvals / `agent-developer`

Purpose: implementation engineering, repo-local verification, engineering quality gates, release readiness for assigned work, and PR confidence reports.

Why first: the first runtime identity started as release/QA, but the durable role is more useful as the engineer. Release verification remains part of engineering delivery rather than a separate persistent agent.

Default access:

- read/write in assigned dev-log channels;
- read and edit assigned repo task branches/workspaces inside scope;
- run tests, lint, build, browser smoke jobs, and repo-local verification gates;
- read Kubernetes status/logs for scoped namespaces when the task ships to runtime;
- no merge or production change without approval.

Current status:

- active private project-development channels are registered per project;
- InfuseAI runtime exists as `deploy/agent-developer` with PVC `agent-developer-workspace`;
- Mattermost bot identity `agent-developer` exists and is scoped to assigned
  private project-development channels;
- the live gateway answers only when mentioned in an assigned role channel;
- access bundle is documented in `docs/agents/agent-developer.md`.
- friendly name is Tinus Lordvals; runtime username, Kubernetes deployment, PVC, Secret, and docs path remain `agent-developer` while the role pivots to engineer.

### Satwa Nutella / `agent-infra`

Purpose: Kubernetes, CI/CD, registry, logs, rollouts, runtime health, and incident triage.

Why early: OpenClaw-on-k8s needs recurring operational attention.

Default access:

- read cluster status for assigned namespaces;
- manage staging workloads for this project;
- inspect Harbor project metadata;
- create proposed rollout/rollback commands;
- no production, DNS, firewall, secret, or access changes without approval.

Current status:

- InfuseAI runtime exists as `deploy/agent-infra` with PVC `agent-infra-workspace`;
- Mattermost bot identity `agent-infra` exists and is scoped to assigned private
  project-infrastructure channels;
- profile/persona/binary skill-set files have been installed into the PVC;
- runtime smoke passes with Mattermost connected;
- friendly name is Satwa Nutella; runtime slug, Kubernetes deployment, PVC, Secret, and docs path remain `agent-infra`.

### Scout / `agent-research`

Purpose: technical/product research, option comparison, and evidence gathering.

Why early: useful without broad write permissions.

Default access:

- read public sources and assigned docs;
- draft findings and decision briefs;
- no external posting or private-data browsing outside assigned context.

### Scribe / `agent-docs`

Purpose: keep repo maps, runbooks, task briefs, and decision logs clean.

Why early: the swarm needs durable context to avoid repeated explanation.

Default access:

- edit docs branches;
- propose context pack updates;
- no policy changes without Fito approval or an explicit recorded boundary.

### Stewie Hobs / `agent-designer`

Purpose: design review, UX critique, visual QA, accessibility notes, and screenshot-based design-parity reports.

Why candidate: design review is bounded and evidence-driven when scoped to screenshots, browser artifacts, and assigned frontend repos.

Default access:

- read assigned design/product docs and frontend repos;
- inspect screenshots and browser-smoke artifacts;
- draft UX review comments and proposed patches;
- no merge, deployment, brand direction, external/client feedback, secret, or access changes without approval.

Current status:

- active in InfuseAI `agents-swarm` as `deploy/agent-designer` with PVC `agent-designer-workspace`;
- access bundle exists in `docs/agents/agent-designer.md`;
- skill bundle exists in `config/agent-skill-bundles/agent-designer.json`;
- Mattermost bot identity `agent-designer` exists and is scoped to assigned
  private project-design channels;
- profile/persona/binary skill-set files have been installed into the PVC;
- runtime smoke passes with Mattermost connected;
- friendly name is Stewie Hobs; runtime slug, Kubernetes deployment, PVC, Secret, and docs path remain `agent-designer`.

### Emon Lusk / `agent-coordinator`

Purpose: default product/engineering coordination, task decomposition, agent routing, PR/build evidence gathering, and swarm follow-through.

Coordinator contract: Emon is expected to behave as PM/EM + staff engineer, not
a passive assistant. He translates Fito's intent into scoped work, picks the
right agent path, reviews outputs, verifies evidence, keeps execution
accountability, and owns mission intake, GitLab issue readiness checks,
single-agent or team-mission classification, one-agent handoffs, role-thread
mission stewardship, synthesis, and escalation routing. The installed
`agentic-product-engineering` coordinator operating contract is the canonical
behavior reference.

Why active: Fito explicitly wants Emon to be the responsible coordinator for
delegation, coordination, and task decomposition in the Kubernetes swarm, while
Kapiteky advises on vision, company coherence, system design, and capability
gaps; Fito keeps human approval authority and private personal context separate.

Default access:

- ambient access in assigned private project-role channels;
- read/write in `agents-org` for agent-team operating model, channel/access reviews, and team ritual coordination;
- read assigned Infuse AI repos/docs under task scope;
- create isolated task workspaces and proposed patches for assigned coordination/runtime work;
- inspect GitLab PR/build status through approved scoped credentials;
- coordinate other agents, but not approve sensitive actions.

Current status:

- repo access bundle exists in `docs/agents/agent-coordinator.md`;
- skill bundle exists in `config/agent-skill-bundles/agent-coordinator.json`;
- Kubernetes overlay exists for `deploy/agent-coordinator` with PVC `agent-coordinator-workspace`;
- Mattermost bot identity `agent-coordinator` exists and resolves from `Mattermost / agent-coordinator BOT token`;
- runtime secrets are synced for the active InfuseAI deployment;
- friendly name is Emon Lusk; runtime slug, Kubernetes deployment, PVC, Secret, and docs path remain `agent-coordinator`.

### Ramiro Garcia / `agent-intake`

Purpose: consulting/client intake, lead triage, discovery briefs, proposal/SOW drafts, client-project setup plans, and handoff to delivery agents.

Why active: consulting intake is recurring enough to deserve a named role, but external communication and commercial commitments need strong approval boundaries. Ramiro Garcia makes the intake workflow repeatable without making Emon the only consulting operator.

Default access:

- read assigned consulting/client intake channels;
- read approved consulting email context through the scoped role mailbox IMAP helper;
- draft internal discovery briefs, proposed replies, proposal/SOW outlines, and handoff checklists;
- help prepare `client-<slug>` project setup plans after approval;
- no external sends, pricing, terms, timelines, legal/commercial commitments, or client-facing claims without Fito approval.

Current status:

- active Kubernetes agent once bundle-declared runtime secrets are synced;
- runtime slug, Kubernetes deployment, PVC, Secret names, and docs path use `agent-intake`;
- friendly name is Ramiro Garcia;
- role-mailbox IMAP/SMTP access is draft-only unless an exact artifact/action is approved, and must be reviewed after each real intake during the first month.

## Activation Lifecycle

1. Role hat is used for a task.
2. Role repeats enough that a context pack helps.
3. Emon proposes a persistent execution identity.
4. Fito approves identity if it changes access or autonomy.
5. Agent posts its introduction to Emon in the assigned role channel.
6. Emon prepares the execution bundle; Fito approves access/autonomy changes.
7. Agent starts in read-only or draft-only mode.
8. After useful evidence, permissions may expand.
9. Agent is reviewed, paused, merged back into role-hat mode, or retired.

## MVP Implementation

For this repo, the MVP is:

- Kubernetes namespace `agents-swarm`.
- Deployed runtime hosts on InfuseAI Kubernetes for `agent-developer`, `agent-designer`, `agent-infra`, and `agent-coordinator`.
- Live Mattermost agent identities: `agent-developer`, `agent-designer`,
  `agent-infra`, and `agent-coordinator`.
- A documented identity/access model.
- First active identity: `agent-developer`, because browser smoke and deployment verification are already in scope.
- Next active identities: `agent-designer` for bounded design review and `agent-infra` for bounded runtime operations triage.

## Open Questions

- Should future Mattermost agent accounts be bot accounts or normal users?
- Where do persistent agent memories live: PVC paths, repo docs, Mattermost logs, or dedicated storage?
- Which private project-role channel should receive each future agent introduction?
- Should Backoffice read agent state directly from Git/Kubernetes/Mattermost or through a small aggregation API?
- Should runtime startup copy approved skills into each workspace, symlink them, or make them discoverable through a central skill service?
