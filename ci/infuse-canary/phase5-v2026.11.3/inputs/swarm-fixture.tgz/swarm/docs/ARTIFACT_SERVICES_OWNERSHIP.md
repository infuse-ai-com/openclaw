---
title: Artifact services ownership
description: Defines Studio ownership of shared artifact services and the Swarm consumer transition.
type: decision
status: active
owner: team:agent-platform
tags:
  - artifacts
  - ownership
  - studio
---
# Artifact services ownership

Owner decision, 2026-10-22: Studio owns Registry and antivirus deployment
sources as separate `core/artifact-registry` and `core/files-scanner-av`
services. Disable and drain the former Swarm definition 117, then transfer that
same definition to Studio's reviewed deployment YAML, preserving its identity and
history. It must never deploy from Swarm again. This repository's main pipeline and retired maintenance entrypoint no longer mutate those services.

Historical manifests and recovery/credential tooling remain source history and
compatibility references, not an active deployment owner. Do not apply them to
production. Bastion/Kopia backup design is separate future work; no backup or
restore runs as part of this handoff. Existing Registry storage and credentials
are preserved. The five agents and agent-side telemetry/publishers remain Swarm's
responsibility.

Runtime naming and publisher endpoint migration are ordered by Studio's
`infrastructure/artifact-services/README.md`. Existing endpoints remain unchanged
in this PR, so retiring the old deployment owner has no publisher outage. Studio
creates the canonical service alias before a subsequent producer change.

## Consumer transition

The five agent publishers and Mac/Kapiteky wrapper now use
`http://artifact-registry.core.svc.cluster.local:3010`. Before merging this
consumer change, Studio must create and qualify that canonical Service alias
against the existing Registry writer. Credentials and journal behavior do not
change. Historical canary, recovery and credential provisioning inputs remain
retired compatibility references, not an active deployment owner.

The publisher-only policy temporarily permits the old and renamed Registry Pod
labels in `core`, only on TCP 3010, plus cluster DNS. Apply this exact reviewed
policy separately before using the updated Mac wrapper or handing off the
Registry. No new audience or destination is added. After the single-writer
handoff, narrow the policy to `artifact-registry` and update the matching local
wrapper policy together. Do not execute publication to test this configuration;
qualify the existing artifact reads and endpoint reachability.
