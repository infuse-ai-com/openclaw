---
title: Document Normalizer Internal Pilot
description: The bounded client is implemented for the Kubernetes agent swarm.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - document
  - normalizer
  - pilot
---
# Document Normalizer Internal Pilot

## Status

The bounded client is implemented for the Kubernetes agent swarm. Fito approved
Tinus Lordvals / `agent-developer` as the first consumer on 2026-08-05, then
approved Emon Lusk / `agent-coordinator` and Ramiro Garcia / `agent-intake` as
separate synthetic-only consumers on 2026-08-06. Each consumer has its own
runtime-env-only token. No RBAC or public-exposure change is part of the agent
expansion.

## Boundary

- Service: `http://document-normalizer.internal-tools.svc.cluster.local`
- API: authenticated `POST /v1/conversions` with `mode=local` and explicit
  `engine=markitdown|anydoc`
- Formats: PDF, DOCX, PPTX, and XLSX detected from content
- Pilot data: synthetic, sanitized, non-client documents only
- Output: an explicit Markdown file with mode `0600`
- Console output: content-free conversion metadata only
- Public ingress, arbitrary URLs, cloud OCR/LLMs, and implicit persistence: disabled

The client never accepts a bearer token as a command-line argument. Supply it
through `DOCUMENT_NORMALIZER_API_TOKEN` or a mounted file named by
`DOCUMENT_NORMALIZER_API_TOKEN_FILE` / `--token-file`. Do not put tokens in
shell history, task briefs, logs, or repository files.

## Client

The agent image installs a thin `openclaw-document-normalizer` launcher. The
canonical bounded client is installed from
`agent-skills/skills/document-normalizer/scripts/document-normalizer-client.py`
during startup skill sync. The client refuses inputs over
20 MiB, uses a constant multipart filename so local source names are not sent,
requires an explicit sanitized-input acknowledgement, bounds the response, and
does not print extracted Markdown.

```bash
openclaw-document-normalizer synthetic.pdf \
  --output /workspace/tasks/example/normalized.md \
  --confirm-sanitized
```

AnyDoc is the default and falls back to MarkItDown only for parser/conversion
failure or empty output. The client validates and reports requested/actual
engine provenance. To bypass AnyDoc and use MarkItDown directly:

```bash
openclaw-document-normalizer synthetic.pdf \
  --output /workspace/tasks/example/normalized-markitdown.md \
  --engine markitdown \
  --confirm-sanitized
```

The client fails closed for any unrecognized engine transition. Encryption,
OCR-required documents, limits, timeouts, memory, and capacity do not fall back.

The output file is downstream consumer data. The caller owns its classification,
retention, deletion, and access. Never place real client or sensitive documents
into the pilot.

## Approved Activation

Activation follows this fail-closed sequence:

1. Name the exact consumer and its synthetic-only workflow.
2. Store one consumer-specific key in Vaultwarden and the service API-key map.
3. Inject only that consumer key through
   `agents-swarm/<agent-id>-document-normalizer`; do not copy the service's full
   key map or grant the project collection to the agent.
4. Require the Secret in the agent overlay so missing credentials fail closed.
5. Run one sanitized conversion per newly activated consumer and decide whether
   to continue, change, or revoke access.

The active consumer Secrets are `agent-coordinator-document-normalizer` and
`agent-intake-document-normalizer`.
Each Secret reference is required, so no consumer can roll out with its pilot
contract declared but its credential missing. The service and agent changes
must continue through their normal Azure pipelines. Technical access does not
authorize real, private, or client data; that remains a separate approval.
Fito also waived the earlier Milestone 2 port-forward conversion and remaining
live acceptance evidence; that waiver is not a passing smoke result.

## Local Verification

```bash
python3 -m unittest tests.test_document_normalizer_client
task verify-ci
```
