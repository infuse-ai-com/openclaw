---
title: Langfuse v4 Signal Quality Operations
description: Operate the privacy-safe OpenClaw Langfuse project through bounded observation views and aggregate audits.
type: runbook
status: active
owner: team:agent-platform
tags:
  - runbook
  - observability
  - langfuse
  - opentelemetry
---

# Langfuse v4 Signal Quality Operations

## Purpose

Use Langfuse for turn investigation, model/token analysis, tool reliability,
and bounded skill or Knowledge Base outcomes. Prometheus remains the complete
operational count surface. The Langfuse branch intentionally removes background
and duplicate spans while the Prometheus span-metrics branch retains them.

Never enable input/output capture to make a view more convenient. Prompt,
response, system prompt, tool arguments/output, retrieved content, raw errors,
sender identity, and conversation identifiers remain out of scope.

## Saved-view definitions

Langfuse saved views are user-owned UI state. Create or reconcile these views
in the `OpenClaw Agents Swarm` project from **Observations**. The names and
filters below are the source-of-truth definitions.

| View | Filters | Sort / columns | Operator question |
|---|---|---|---|
| `OpenClaw · Actionable failures` | `Level = ERROR`; exclude `failure_category = unknown` only when investigating classified failures | newest first; trace name, observation name/type, agent tag, failure category, latency | What failed with a bounded remediation category? |
| `OpenClaw · Slow or incomplete turns` | `Name = infuse.agent.turn`; `Type = agent`; then inspect `closure_state != completed` or latency ≥ 60 s | latency descending; agent tag, traffic source, closure state | Which turns are slow, interrupted, or failed? |
| `OpenClaw · Tool reliability` | `Type = tool` | newest first; tool name, outcome, failure category, retry count, error count, latency | Which logical tools fail or retry most? |
| `OpenClaw · Model tokens and cost` | `Type = generation` | total usage descending; model, usage details, total cost, pricing status, latency | Where are tokens spent, and is cost priced or explicitly unpriced? |
| `OpenClaw · Skills and knowledge` | `Name in (infuse.skill.execution, infuse.wrapper.execution, infuse.knowledge.retrieve, infuse.knowledge.decision)` | newest first; name/type, skill, operation, decision, outcome, latency | Did the selected skill/wrapper/KB path execute and finish coherently? |

Start from root observations for turn-level review, then drill into the shared
trace. Do not use the raw observations table as a trace-volume dashboard.

## Daily aggregate check

Supply project-scoped credentials through environment variables and run:

```bash
python3 scripts/audit-agent-observability-live.py \
  --start <RFC3339-window-start> \
  --end <RFC3339-window-end>
```

The JSON report deliberately omits trace and observation identifiers. Review:

- `traceQuality.traces` and `traceQuality.singletonFamilies`;
- `traceQuality.canonicalCuratedTurnTraces`, `mixedOfficialCuratedTraces`, and
  `duplicateCuratedTurnTraces`;
- semantic `observationTypes`;
- `toolFailureCoverage.actionablePct`;
- `modelUsage.withUsage` and `modelUsage.costState`;
- `privacy.contentObservationsAcrossAllObservations`;
- the exact filtered `backend.noiseFamilies`.

## Release gates

A rollout passes only when all applicable checks hold:

1. Collector is Ready with no new exporter refusal/failure or sustained queue.
2. A controlled turn has one canonical trace containing exactly one
   `infuse.agent.turn`; no official `openclaw.*` observation or second curated
   trace exists in Langfuse.
3. A controlled tool call has one curated `tool` observation in Langfuse and
   retains official + curated counting evidence in Prometheus.
4. A Studio apply retry sequence produces one logical tool observation with
   bounded attempt, retry, error, and failure-category metadata.
5. A generation contains model and usage details. Internal model aliases are
   explicitly `unpriced` until a reviewed model price exists.
6. Human channel traffic is `human`; cron/heartbeat traffic is `automation`;
   controlled smoke/startup sessions keep their exact bounded classes.
7. Content observations remain zero across the entire reviewed window.

## Rollout and rollback

Use the repository pipeline and existing canary-wave contract: Tinus first,
then leaf agents, then Emon. Do not manually apply production manifests. On a
privacy, hierarchy, exporter, metrics, or behavior regression, stop the wave
and revert the source revision through the normal pipeline. A rollback never
deletes historical traces or Prometheus series.
