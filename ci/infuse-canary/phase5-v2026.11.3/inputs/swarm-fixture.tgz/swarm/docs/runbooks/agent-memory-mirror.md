---
title: Agent memory mirror and controlled cleansing
description: Own-agent fast-forward publishing, scoped retrieval and backed-up native memory cutover.
type: runbook
status: active
owner: team:agent-platform
tags: [agents, memory, operations]
---
# Agent memory mirror

See the [12 November qualification](../plans/active/agent-memory-mirror-qualification-2026-11-12.md)
for deployed source pins and per-agent cutover evidence, and the
[13 November admission](../plans/active/ramiro-memory-admission-2026-11-13.md)
for Ramiro's own writer and collector qualification.

The own PVC is the live authoring surface. The memory repository is the
share-safe mirror. Persona and executable authority remain in their reviewed
repositories. The publisher runs from the image or an immutable, content-hashed
`memory-mirror` ConfigMap; it never executes code fetched from the mirror.
The overlay reuses the approved image and introduces no new dependency.

## Publisher

`openclaw-agent-sync-memory-repo` verifies the own GitLab identity, validates
plain UTF-8 Markdown, captures twice to reject concurrent changes and takes a
local sync lock. Only own `MEMORY.md`, `memory/*.md` and `summaries/*.md` are
eligible. Profiles, hidden native state, symlinks and obvious credential
material are excluded. Validation is mechanical, not a privacy or truth oracle.

The publisher uses a disposable checkout, preserving the retrieval checkout
and legacy recovery refs. A baseline under `/workspace/.agent-memory-mirror/`
records the last acknowledged content hashes. First adoption requires identical
live and mirrored files. Subsequent snapshots apply only changed own paths.
Concurrent peer pushes retry four times; same-file conflicts fail with live
learning intact. A failed push retains a private Git bundle. Never force push.
A no-change receipt is distinct from a published commit.

Pre-push validation runs before publication; push-triggered CI runs afterwards.
Protected main must explicitly admit the intended writers with force disabled.
Path checks are an application contract, not server-side folder ACLs. An own
read-only token cannot push even when its account has Developer membership.

## Retrieval and rollout

The installed `shared-agent-memory` skill owns executable search. Its default
scope includes own MEMORY/summaries, project/shared context and own daily notes.
Peer summaries and historical evidence require explicit flags. History is not
part of sparse startup or native daily ingestion. A source date or checkout
revision is evidence of provenance, not proof that an old claim remains true.

`openclaw-agent-refresh-shared-memory` supplies startup and on-demand refresh.
It pins the approved GitLab origin/main, uses the own credential helper, locks
the checkout and fast-forwards only clean, non-divergent work. Recovery branches
are preserved. It reports JSON with `status`, `commit`, `remote_commit`,
`checked_at` and a redacted failure reason. Successful checks may be reused for
five minutes; `--force` and `--after-commit <full-sha>` bypass this cache. A failed
attempt invalidates cache reuse. Optional startup may continue after a failure,
but the receipt remains stale/unavailable; on-demand failure returns nonzero.

The installed search helper calls this launcher automatically, then reads Git
objects at the returned commit. It never executes mirror scripts or reads a
mixture of working-tree revisions. Search exits 0 for matches, 1 for no matches,
2 for unavailable/invalid context and 3 for stale context. `--require-fresh` and
handoff-commit checks refuse stale fallback; other low-risk searches can return
explicitly labelled committed evidence. Freshness means the mirror was checked,
not that every peer PVC has published or that its content is authoritative.

Before a handoff needs new learned context, the installed `prepare-handoff.py`
invokes the existing own publisher. A successful receipt carries the full
`required_memory_commit`; its receiver searches with `--after-commit`. Failed
publication stays pending with local learning retained. Delivery workflow skills
make this the default for memory-dependent handoffs; ordinary chat does not
trigger pushes and the helper sends no coordination messages.

For a freshness rollout, merge the skill source, pin its exact main revision,
regenerate this component, then use lifecycle-safe rollout for Tinus before
peers. Keep the existing runtime image and all unrelated Deployment fields.
Verify startup, runtime skill provenance, source revision, fresh/cached search
and one real published-summary handoff. Rollback selects the preceding immutable
component/skill pin; do not reset learned memory or recovery refs.

Regenerate the immutable component with
`python3 scripts/render-memory-mirror-component.py` after helper changes. Pin
reviewed skill source in the runtime catalog. Apply the generated ConfigMap and
mount patch to Tinus first, then qualify before remaining agents. Keep the
collector suspended until every selected writer has adopted its baseline.
The mirror collector runs at 03:30 UTC, after the native 03:00 UTC dreaming
schedule. This reduces routine overlap; stable capture remains necessary for
long-running or manually triggered dreaming. The selector includes all five
qualified own identities, including Ramiro. Developer membership alone is
insufficient: the own token needs `write_repository` as well as the existing
read scopes. After an operator updates the named Vaultwarden item, refresh the
agent's local vault cache through its trusted wrapper before rechecking identity
and scopes. A cached revoked token can otherwise keep returning HTTP 401.
Do not print token values or substitute another identity.

## Controlled memory cleanse

1. Confirm the user-approved scope, idle target and current persona hashes.
   Record schedules, current source heads, memory hashes and all recovery refs.
2. Unless the user explicitly declines further backup work, create a native backup with `openclaw backup create --no-include-workspace
   --verify` into private storage outside the native state directory. Separately
   checkpoint own MEMORY, daily/summary directories and DREAMS. Native backup
   can contain credentials and private sessions: never commit it. An off-PVC
   destination requires its explicit authorization. Verify the full transfer
   hash; an interrupted copy is not a backup.
3. When using a native checkpoint, use `openclaw backup restore` into a fresh private staging directory and
   verify SQLite inventory. Rehearse native reset and scoped derived-state pruning against an isolated
   config/state/workspace copy. Inspect selected session IDs, refusals and
   lineage, rather than deleting an unknown database.
4. Audit current transcript admission with the reviewed
   `scripts/audit-agent-memory-replay.mjs` on the exact supported runtime. A stored
   cursor with `lastContentLine == lineCount` can still predate an appended tail.
   Drain any pending native session candidates through a no-delivery dreaming
   pass before replacing memory, repeating bounded passes for the native
   per-file admission cap, until substantive pending candidates are zero.
   The probe reports exact lifecycle-abort markers separately; those contain
   no retained task instructions and may be emitted by a controlled stop.
   Inspect/reconcile any changed learned files; preserve the drained output
   outside ingestion before pruning. Do not permanently forget current session
   IDs to bypass the backlog. A new excluded/empty cron cursor is not a replay
   candidate. Keep every non-memory schedule paused.
5. Stop the selected Gateway through its Kubernetes owner and run a temporary
   maintenance pod on the same PVC using the same approved image and identity.
   Give the temporary maintenance pod a short termination grace and a PID 1
   that handles TERM; do not inherit the Gateway’s long drain period for a
   sleeping maintenance container. Native maintenance requires exclusive offline
   state ownership. Take the final
   checkpoint after writers stop; recheck before-hashes and reconcile any drift.
6. Preserve original selected files outside native ingestion. Apply the exact
   curated own-agent revision. Use `memory reset --agent ... --yes` for the
   derived search index. Use `scripts/prune-agent-dreaming-state.py` for the
   exact workspace-scoped daily/recall namespaces, after a matching hash/count
   plan and isolated rehearsal. Preserve completed session-ingestion cursors,
   seen-message hashes, event cursors, other plugins/workspaces and all sessions.
   The helper refuses incomplete cursors. Do not blanket-forget current session
   IDs: native context reset retains those logical IDs, so permanent tombstones
   would also suppress future learning. Historical session content remains
   evidence; the preserved cursors prevent ordinary replay of consumed messages.
7. Start the Gateway, refresh existing sessions through supported `sessions.reset`
   with expected session IDs where needed, and verify preserved transcripts and
   routing. A file replacement alone does not refresh an already loaded prompt.
8. Adopt the matching mirror baseline, run one safe no-delivery dreaming cycle,
   wait for asynchronous native diary output, inspect resulting files/candidates
   and qualify one own-identity push. Check
   that neither profiles nor retired guidance returns before peers proceed.
9. Record per-agent source hashes, backup/restore results, native exclusions,
   new mirror commits and schedule readback. Ramiro's mail remains paused.

Rollback restores the selected checkpoint with export paused. Never restart the
old profile exporter as a recovery shortcut. Shared historical notes are data;
old approvals and assignments do not become active work through restoration.
