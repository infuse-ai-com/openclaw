---
title: Studio native mission cutover
description: Guarded promotion of the native Mattermost Studio authority with required route ownership.
type: runbook
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
---
# Studio native mission cutover

## Mission reliability protocol (2026-10-09)

Studio PR 3766 adds assignment instruction protocol 1 and review findings
protocol 1. The schema-15 backend is compatible with existing histories and
assignments. The Dockerfile pins its published plugin image; the skill catalog
pins agent-skills PR 3764. Emon's approved-scope correction is owned by persona
PR 3767. See [the promotion record](../evidence/2026-10-09-mission-reliability.md).

Keep `nativeMissions.instructionVersion` absent during backend/plugin staging.
Before setting it to `1` for one project's new assignments, check each enrolled
Gateway's installed plugin hashes, native service health and `studio.identity`
response (`instructionVersion:1`, `findingsVersion:1`). Verify installed skill
and persona manifests, current channel membership and required-owner bindings.
Drain or explicitly reconcile old active work; never rewrite historical receipts.

Specialists read the complete `inbox` at turn start and before delivery, then
submit the exact sequence and applied outcomes. Reading alone is not application.
The delivery barrier rejects unread, pending or unsettled actionable feedback.
Feedback resolved by the current run consumes its queued cause without another
turn. Required review findings need immutable fix evidence and coordinator closure.
New capabilities, credentials or tool grants are not part of this rollout.

Qualify production intra-cluster transport first, then the separate Mac authority
using [the profile-switch runbook](studio-mac-profile.md). Only switch after all
source-authority runs and uncertain effects are reconciled. Production and Mac
routes keep separate ownership and journals. A deterministic disposable proof
does not replace the bounded real-model pilot with busy feedback, clarification,
independent review, revision and autonomous closeout.

Rollback disables new managed execution while retaining the schema-15 writer,
pending instructions, journal and protected routes. Do not downgrade the writer,
clear custody or restore ordinary model fallback. No Studio backups are required.

This supersedes the single-task pilot after activation. Source preparation does
not prove deployment. The host required-owner commit, Studio image/plugin, skill
source commit and persona commit must all be pinned to reviewed artifacts before
activation. The first project is `core/studio`, with `studio-dev`, `studio-design`
and `studio-infra`; resolve actual channel IDs and native accounts, verify Fito,
Emon and the role specialist are members, and create missing channels before
installing managed routes. Do not import old SQL routes or records.

## Promotion order

1. Pass the Studio disposable real-server test on the exact built host and
   packaged plugin. It must cover developer/design work, clarification, revision,
   native identities, actual enrolled tools and coordinator closeout. Retain
   absent-owner/restart/uncertain-send evidence and the complete repository gates.
2. Publish immutable host/plugin artifacts and update the image package URLs,
   checksums and Studio image digest. A local checkout or source SHA alone is not
   a deployable runtime release. Preserve each agent PVC and native account.
3. Merge/sync the reviewed `studio-mission-control` skill and persona policy.
   Set the skill catalog's pinned source to the promoted commit. Existing tools,
   credentials, model profiles and unrelated Backoffice publishing stay scoped
   as before; installation of workflow guidance is not a capability expansion.
4. Confirm no legacy mission run is active, then deploy the Backoffice removal.
   Its migration drops the SQL mission and operator-intent proof-of-concept
   tables, and its application removes command, read, dispatch, session-adapter,
   and operator-intent routes. Verify the removed routes return 404.
5. Set `STUDIO_MISSION_CUTOVER=true` for the reviewed normal deployment. Its
   renderer selects `k8s/overlays/studio-mission-cutover`. The persistent
   `studio-mission-authority` ConfigMap makes future deployments retain cutover
   even when the environment switch is omitted. The deployment also disables
   only the known legacy mission cron jobs. The deploy also removes all five SQL
   worker deployments, mission sidecars, services, routes, identities, policies,
   and configuration. Future renders must contain none of those resources.
6. Enroll coordinator/developer/designer/infra Gateways with distinct Studio
   credentials. Install the plugin on the two new roles without granting extra
   tools. Set `nativeEnabled:true` only after the patched host is running; Emon
   protects all four channels under its own account and each specialist protects
   its own channel. Studio route/membership admission must pass before posting.
7. Studio production plugins call the private service
   `https://studio-bridge.core.svc.cluster.local/api/bridge/v2`. The Studio
   NetworkPolicy needs only the four exact role Pod labels on 8443. Existing
   Gateway ingress and tailnet ACLs are not widened. Probe from the actual Pods.
8. Enable the Studio project, run its bounded live pilot and reconcile matching
   task/post/session/run/evidence IDs. Keep additional project routes disabled
   until this passes. Stop new V1 Studio creation with the native cutover flag.

## Emon instructions in existing task threads

Emon receives unmentioned human intake and follow-ups in the enrolled project
coordination conversation. Specialists require their actual native Mattermost
username, such as `@agent-developer`; friendly names, quoted mentions and
unaddressed updates remain context. Address Emon explicitly in specialist task
threads. Self echoes and committed lifecycle posts cannot trigger extra turns.

The admitted coordinator can use `studio_mission_command` V2 `message-task` for
unchanged assigned, blocked or revision work. Studio checks the current task
version, assignment, session generation and approved scope, then commits one
outbox instruction and one continuation together. It resolves the native
specialist identity, posts through Emon in the existing protected thread, and
resumes that specialist's existing session only after exact delivery. Delivered
work uses `revise`; changed scope requires a revised paper and fresh approval.
The source coordinator turn must settle before posting. Hold delays delivery;
reassignment, cancellation and completed work supersede stale queued effects.
Uncertain sends are reconciled through the existing journal, never blindly sent
again. Studio exposes the recipient, instruction, delivery state and post link.

Deploy the compatible Studio backend before this plugin. `provision-next`
negotiates `taskMessageVersion: 1`, so older plugins do not receive the new
outbox effect. Keep the schema-12 writer during rollback and disable managed
execution while retaining required-owner routes. Do not downgrade the writer,
clear journals or permit ordinary-chat fallback. This update preserves the
pinned OpenClaw host, repaired source/knowledge helpers, Bitwarden version,
credentials, tools, role membership and production/local authority isolation.

The reviewed skill source is `34d7247767f35e6f7b726a6db20d395a79568be4`
(agent-skills PR 3736). Studio PR 3735 qualifies the command against disposable
real Mattermost and pinned Gateways using deterministic model replies; that
fixture is distinct from a real-model production mission. Verify all four live
Studio plugin services, the installed plugin bytes and seven protected room
routes after deployment before starting that mission.
Studio build 8961 includes the schema-12 plugin packaging repair (PR 3737);
its deployed immutable image is the plugin source pinned in the Dockerfile.

## Local backend on the Mac

Use the separate `studio-local-mac` authority, SQLite files, bridge tokens,
`local-mac` journal namespace and separate Mattermost test channels/threads.
Set the plugin's `studioUrl` to the verified Tailscale HTTPS origin, optionally
with the verified tailnet IP in `studioConnectAddress`; preserve Host/SNI and
certificate checks. Production uses intra-cluster DNS. Real local OIDC is
required; do not expose the synthetic browser preview. Only one authority profile
is active per Gateway: stop admission and settle runs before switching, retaining
both journals. Never rebind production or legacy roots to local test routes.

## Rollback

Disable new native execution at Studio and reconcile/abort exact active runs.
Retain the patched host, required-owner route records, plugin journal and Studio
SQLite history. Missing/disabled/failing owner plugins must block model fallback.
Do not downgrade to the old host, clear route ownership, delete a journal to fix a
realm mismatch, re-enable legacy admission, or blindly resend uncertain effects.
Keep unrelated Backoffice features and data available.

## Resolved Studio project routes

`config/studio-native-routes.json` records the verified private core project
channel IDs and native bot identities. The cutover renderer applies these only
to a disposable render tree; normal renders retain their existing behavior. It
adds the Studio plugin, role credential and CA mount for designer and infra,
and preserves all ordinary tool, model, skill and channel policies. Coordinator
protection covers all four channels; specialist protection covers its own only.
The intake agent is unchanged. The referenced `agent-<role>-studio` Secrets must
exist before applying the cutover render.

## Published runtime and plugin qualification

The pinned host `0fcc9360aa8ea03f61ca6ffd2692995ec74e726c` is published in
[the required-owner canary release](https://github.com/aolea/openclaw/releases/tag/canary-v2026.9.7-studio-required-owner-0fcc9360aa-r1).
All six public assets were downloaded and hash-verified before promotion. The
host and Mattermost/Codex package pins remain unchanged by subsequent Studio
plugin repairs. The Dockerfile records the exact immutable Studio image used to
supply the plugin; the image build must still pass the actual runtime capability
gate before deployment.

The production pilot completed two verified tasks and autonomous closeout using
real models. It exposed a receipt-recovery compatibility issue and incomplete
Mattermost lifecycle visibility. The recovery adapter is qualified against the
pinned runtime; lifecycle visibility and the separate Mac mission remain follow-up
gates. Do not treat successful closeout as proof that every lifecycle update is
already visible in Mattermost. See Studio's
`docs/evidence/2026-10-06-production-native-pilot.md` and
`docs/evidence/2026-10-06-native-run-recovery-server-proof.json` for those distinct
proof boundaries. Preserve all existing route ownership and journals during a
plugin rollout; never clear them to force a clean start.

## Lifecycle notification rollout

The lifecycle repair is qualified with eight native notification posts against
real disposable Mattermost and Gateways, using deterministic model fixtures.
Deploy Studio's schema-11-compatible backend with
`nativeMissions.lifecycleNotifications` absent or false, then promote the exact
plugin image. Verify all 30 installed files and the seven persisted owner rooms
across the four enrolled Gateways before enabling that flag through the owning
Studio configuration pipeline. The plugin advertises lifecycle protocol version
1; older polls never receive new lifecycle effects.

A separate bounded real-model mission must prove specialist delivery notices,
Emon's same-thread revision/verification, no extra turns from echoes, and the
coordination closeout post after actual closing-run settlement. Preserve older
mission history without backfilling notifications. Rollback keeps the compatible
writer with delivery/execution disabled; schema 11 deliberately refuses older
writers that would ignore delivery prerequisites. See
[the lifecycle promotion record](../evidence/2026-10-06-native-lifecycle-delivery.md).

## Finaxis alongside Studio

The production route manifest includes project `finaxis`: Emon on
`fnx/finaxis-missions`, `finaxis-dev` and `finaxis-design`, Tinus on dev and
Stewie on design. The renderer retains every existing Studio route and the
existing authority, native identity, credentials, capabilities and journal.
The Mac profile remains isolated and cannot take ownership of these channels.
No OpenClaw fork/package rebuild is required for multiple project routes.

Deploy Studio multi-project support and configure Finaxis with execution disabled
before deploying this manifest. Confirm five Finaxis required-owner host bindings
and corresponding Studio protection receipts before enabling intake. Emon accepts
unmentioned human coordination messages; specialists still require their resolved
`@agent-developer` or `@agent-designer` mention. Do not launch the EUR/USD mission
until its exact paper and repository permissions are checked. Rollback disables
Finaxis execution while retaining its protected routes; no ordinary chat fallback.

Verify: `python3 -m unittest discover -s tests -p 'test_studio*.py'` and
`AGENT_ID=agent-designer task verify-ci`.

The Finaxis rollout advances the reviewed skill pin to `bf99ddb389eeff4f13615c3f37e97dfe3fa854ed`
(agent-skills PR 3752), retaining the task-message guidance from PR 3736 and
adding project-aware artifact links. Studio PR 3751 supplies the multi-project
authority; deploy it before the route manifest.

## Pending journal scheduling repair — October 23

Studio PR 4231/main `46a06f4d0646882ffa630a89d89944930af0cd5a`, build 10716,
supplies the plugin pinned by the Dockerfile and exact 17-file inventory. Journal
schema 2 derives an indexed pending queue without rewriting retained bodies,
revisions, realms or receipts. Each tick inspects active actions before intake;
a failure for one action no longer prevents another action's cancellation check.
The backend schema 33 release is already deployed. Existing OpenClaw 2026.10.3,
agent enrollments, native routes, credentials and tool permissions stay unchanged.

The owner authorized activation and live verification on October 23. Before the
normal main pipeline, reconcile current mission/companion runs and pending native
effects. The existing canary-wave rollout manages shutdown and preserves each
PVC. Verify all 17 installed package hashes, fourteen registered native tools,
active `studio.identity`, healthy service and retained protected routes on all
four enrolled Gateways. Use read-only authenticated probes; no production mission
or model turn is needed to establish package activation. Qualification includes
1,079 Studio tests, 666 container tests and real-journal migration, large-history,
no-replay and independent-cancellation regressions.

After any journal opens at schema 2, retain a schema-2-compatible plugin. An older
plugin intentionally refuses that journal; do not downgrade or discard it. If
activation fails, stop new admission and reconcile exact runs while preserving
route protection, journals and uncertain receipts. Deployment and observed live
verification are recorded separately from this prepared release procedure.
