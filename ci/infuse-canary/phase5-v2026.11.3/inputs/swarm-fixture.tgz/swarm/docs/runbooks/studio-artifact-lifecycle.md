---
title: Studio artifact lifecycle activation
description: Exact-project lifecycle credentials and staged independent Registry image release.
type: runbook
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - artifacts
---
# Studio artifact lifecycle activation

The reviewed Studio Registry image provides the additive exact-command lifecycle
protocol. Swarm pipeline 117 remains the only deployment owner of the shared
Registry. Backoffice stays running with its existing clients. Studio's independent
image builder does not deploy. Service, PVC, auth, S3 and scanner identities remain
stable; deployment-owner transfer is a separate P7 gate.

Prepare the exact grant without network or credentials:

```sh
python3 scripts/provision_studio_artifact_lifecycle.py plan
```

The plan adds two lifecycle-only principals, bound separately to `core` and `studio`,
and the `core/studio-artifact-lifecycle` Secret with those two token-file keys.
Vault items live in the existing Registry owner collection `07-Project-Backoffice`:
`Artifact Registry / Studio lifecycle core token` and
`Artifact Registry / Studio lifecycle studio token`. Their stable client subjects
bind receipts. No reader, publisher, upload, Backoffice or human membership is
changed. Other projects are not admitted by these credentials.

After explicit owner approval, a green reviewed Registry image release and a
reviewed Studio mount/configuration PR, provision through the operator helper:

```sh
python3 scripts/provision_studio_artifact_lifecycle.py apply --approved \
  --expected-image registry.infuse-ai-tech.party/studio/artifact-registry@sha256:<reviewed-digest>
```

Credentials remain process-local until written to Vaultwarden and Kubernetes;
output contains references only. The helper refuses identity/token/scope drift,
uses a resource-version test when adding server admission and is retryable after a
partial activation. An unmounted new client Secret may remain after a failed
admission patch; reconcile the same Vault items and retry, never rotate implicitly.
Enable the matching Studio mount only through its reviewed main pipeline.

Qualification: project-scoped active/bin reads, exact revision history, disposable
canary trash and restore, uncertain-response recovery with the same command ID,
current-member boundaries and admin-only purge/audit. Use local fixtures for purge
unless an exact disposable production identity has fresh approval. Never purge
legacy pending obligations, valuable artifacts, volumes or Studio database state.
No Studio backup or restore rehearsal is introduced. Keep Backoffice running until
human UX acceptance and the remaining P7 obligations are reconciled.

The helper refuses activation against the old Backoffice Registry image. Legacy
whole-auth bootstrap/cutover/rotation/finalize commands refuse to run once these
clients exist, so they cannot silently remove the independent lifecycle grants.
A future whole-auth reconciliation must explicitly preserve their stable subjects
and exact scoped credentials. Additive reader/image operations remain available.

## Qualified image publication

Studio PR #4061 merged as `3e8f33439cbcabf61a5d9524260cd0344f6a2bdd`.
Independent pipeline 124 build 10091 (`20261020.3`) passed verification and published
`registry.infuse-ai-tech.party/studio/artifact-registry@sha256:9328e437076f576ddd1cc5f20aaa086a90c5698aae9b85d81bd6a829daa3281f`.
The runtime pin uses that digest, preserving the existing service, claim, auth
mounts, security context and compatible entrypoint. Legacy annotation names remain
for compatibility; their build/source values now identify this Studio image.

The reviewed release may deploy through Swarm pipeline 117. The credential helper
is prepared only: no grant or Secret activation is implied by merging this change.
Studio PR #4063 remains separately gated on explicit scoped-grant approval.
