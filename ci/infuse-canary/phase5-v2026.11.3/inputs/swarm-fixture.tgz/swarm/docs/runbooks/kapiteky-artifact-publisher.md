---
title: Kapiteky Artifact Publisher
description: Qualify the existing Mac publisher with reviewed helpers and bounded runtime isolation.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - artifacts
---
# Kapiteky Artifact Publisher

Use `task publish-kapiteky-artifact-registry -- --spec <file> --studio-origin
https://studio.infuse-ai.com`. The spec must carry the intended Studio project ID.
The wrapper uses the existing `artifact-registry-kapiteky` producer credential;
it does not create credentials, grant project access, or expose a Registry route.

## Local preparation

The installed `mission-control-publishing` skill must include `--studio-origin`.
Its reviewed owner is `agent-skills`. An older Mac installation fails before any
cluster access. Update from a merged source revision after comparing the entire
local skill tree; preserve local modifications for review. An explicit
`MISSION_CONTROL_PUBLISHING_SKILL_DIR` may select an already reviewed installation.
The October 22 qualification found the Mac tree exactly matched historical source
`a91389f41b55ab18f0ca5f6897cad470f5c66293`; current reviewed source is
`0239947486a16f9276c8a50ef0fb7bda0891c094`.

`MISSION_CONTROL_AGENT_DIR` must name a regular `kapiteky` staging directory.
For a standalone qualification artifact, use an empty private temporary directory
and omit `--update-journal`. An existing journal must be a complete regular-file
pair; the wrapper never repairs or discards an incomplete pair. This avoids
changing real journals during qualification.

## Production prerequisite

The reviewed source is `config/kapiteky-artifact-publisher-network-policy.json`.
It is deliberately **not included in the automatic production overlays**. Obtain
the owner’s approval to create this exact NetworkPolicy in `agents-swarm`, then
stage it separately. The normal publisher only reads policies and refuses missing
or drifted rules; it never changes networking.

The policy selects only the temporary publisher component. It permits outbound
TCP 3010 to the Registry pods in `core`, plus TCP/UDP 53 to cluster DNS. Existing
Registry ingress uses the `agent-infra` name label; that label also means the
existing dashboard ingress rules select the temporary pod. The publisher opens
no listening port. This is an egress restriction, not a claim of deny-all ingress.
NetworkPolicy allows are additive, so preflight rejects any additional egress
policy selecting the publisher. Persistent agent traffic is unaffected.

The pod has no service-account token, runs as UID 1000 with no capabilities, uses
a read-only root filesystem, mounts only its producer credential and disposable
work volume, and has a five-minute active deadline. Preflight rejects a pod-name
collision. Cleanup uses an atomic UID precondition, so it cannot delete an
unrelated same-name replacement. If create succeeds but its response is lost,
reconcile the chosen name before retrying; the deadline bounds execution but does
not itself remove the terminated pod object.

## Qualification and retained dependencies

Publish one synthetic standalone `studio` artifact, then retry identical content.
Record exact receipts, parity, one unchanged revision, search and authenticated
rendering. Do not republish the five already qualified agent samples or refresh
the human Skills catalog for this test. Keep Backoffice and all six schedules
running; no purge or alert-sender change is included.

Validation: `python3 -m unittest discover -s tests -p test_kapiteky_publisher.py`
exercises old-helper rejection, malformed local inputs, missing/drifted/additive
policies, name collision, bounded pod creation and UID cleanup on success/failure.
Run the repository CI gate and required PR validation before production use.
