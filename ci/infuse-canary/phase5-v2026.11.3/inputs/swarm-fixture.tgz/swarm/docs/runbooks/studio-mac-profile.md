---
title: Studio Mac authority profile
description: Switch the existing named Gateways between production and a separate Mac backend without rebinding managed conversations.
type: runbook
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - tailscale
---
# Studio Mac authority profile

This is an explicit operator-controlled switch of the same four named Gateways.
It does not provide simultaneous control by production and the Mac authority.
The default pipeline selection, `preserve`, retains the deployed profile.

| Boundary | Production | Mac test |
| --- | --- | --- |
| Authority | studio-production | studio-local-mac |
| Backend | private Studio cluster service | https://macs-mac-mini.tailc4f8d5.ts.net:8443 |
| Connect address | cluster DNS | 100.66.41.78, preserving HTTPS Host/SNI |
| Journal | production | local-mac |
| Bridge Secret | agent-role-studio | agent-role-studio-local-mac |
| TLS trust | scoped cluster service CA | ordinary system trust |
| Conversations | existing Studio channels | four separate private Studio Mac channels |

`config/studio-native-routes.local-mac.json` pins the actual local channel IDs.
The renderer rejects production channel reuse, changed native identities and
unreviewed authorities/destinations. It preserves the accounts' ordinary tools,
skills, model and channel policy. The intake agent is not enrolled or changed.
The local Secrets contain the same role-specific bridge token key names with
independent token values; no production token or CA is mounted for this profile.

## Prepare

The authenticated Mac backend is separate from the synthetic workspace preview.
Studio owns its configuration, launcher, SQLite files and authentication proof.
The existing proof establishes private Tailscale HTTPS reachability, real OIDC
and machine-route authentication, not a completed local mission.

1. Ensure the Mac is available on its verified private HTTPS origin. Retain
   certificate verification; do not enable Funnel or widen tailnet/cluster access.
2. Configure four separate local enrollments and independent per-Gateway tokens.
   Create the four `agent-role-studio-local-mac` Secrets through the authorized
   owning process. Do not put tokens in Git, pipeline arguments, logs or receipts.
3. Verify Fito, Emon and each assigned specialist's membership in the pinned
   private local channels. The channels were prepared on 2026-10-06 with headers
   stating local testing is inactive; no mission intake was sent during setup.
4. Keep local native execution disabled until the selected profile's exact
   installed plugin, backend identity, protected routes and credentials pass.

## Switch through the owning pipeline

Finish and reconcile the source authority's work first. Disable its admission;
verify every accepted run and external effect is settled with no uncertain
receipt. A closed mission alone is insufficient evidence for this check.

Queue the owning pipeline with `studioRuntimeProfile: local-mac` and
`studioProfileSwitchConfirmed: 'true'` only after that checkpoint. This parameter
is the operator's explicit attestation of the checkpoint; the deployment script
cannot establish runtime settlement on its own. It is not an authorization grant
or a replacement for reading current Studio/Gateway receipts.

The deployer records the selected profile with the existing Studio authority
marker before the staged rollout. It forces replacement of all four participating
Pods even if the ordinary source-impact classifier would preserve them. A partial
rollout retains the requested profile with `nativeProfileState: pending`; a retry
also replaces all four native Pods instead of preserving a partly switched fleet.
The deployer marks the profile active only after successful fleet verification. Keep admission
closed on both authorities until all four Gateways match; do not start a mission
on a partly switched fleet.

The local marker uses `authority: studio-local-mac` and `nativeProfile: local-mac`.
Older deployers that recognize only `authority: studio` reject it rather than
silently restoring production configuration. New default deployments preserve
it. An unknown or contradictory marker fails closed.

## Pilot and return

Verify local route protection before any actionable post. Retain every production
owner row and both journals. Messages for the inactive authority stay protected
and rejected as unregistered routes; do not remove custody to get an ordinary
chat response. The live proof must check that boundary in both directions.

Enable local native intake, run one bounded mission with exact paper approval,
then settle/reconcile and disable local admission. Select `production` with the
same explicit settlement attestation to return through the owning pipeline.
Verify the production services, exact plugin files, active production routes and
retained local custody before restoring production admission.

A failed connection or uncertain receipt is a stop/reconciliation condition.
Do not delete a journal, rebind a production/legacy root, weaken TLS, backfill
history or resend uncertain effects. No Studio data backup or import is required.
