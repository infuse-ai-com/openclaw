---
title: Studio whiteboard agent access
description: Stage and verify per-agent whiteboard access without shared-host changes.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
---
# Studio whiteboard agent access

Status: Studio companion fixes from PR 4227/main build 10692 are deployed and
healthy. This change pins its exact 17-file plugin payload, byte-matched to the
qualified local build, for the existing OpenClaw 2026.10.3 host. Agent rollout and
live acceptance follow release. The earlier XML promotion is recorded below.
Per-agent credentials and native reading/editing/chat remain enabled for
coordinator, designer, developer and infra; intake remains ungranted.
Owner approval: 2026-10-21.
Shared-VM host changes and Chromium rendering are explicitly deferred.

## Paths and authority

The native Studio plugin supplies board reading, edits, receipts, presence and
companion chat with actual host session/run custody. The production profile enables
`whiteboardEnabled` and `companionEnabled`; Studio independently gates board and
companion access. The local Mac profile does not receive production MCP secrets or
those production flags. No personal profile or native enrollment is invented.

The separate MCP endpoint at
`https://studio-bridge.core.svc.cluster.local/whiteboard/mcp` exposes context/read/
search only. Its private TLS entry reuses the agent's existing Studio CA; public
browser access is denied. MCP credentials do not authorize native bridge calls.

`studio-whiteboard context`, `search` and `read` accept JSON tool arguments on stdin
and use `/var/run/studio-whiteboard/token` without printing it. For example,
`printf '%s' '{"project_id":"studio"}' | studio-whiteboard context` reads saved
context. Native tools remain the preferred path inside an OpenClaw session. The
CLI also makes the independently authenticated MCP connection inspectable from
an agent runtime without creating a model turn. `studio-whiteboard probe` prints
only status, actor identity, capabilities and wrong-project denial, never board
content or credentials. It cannot edit, render, Start/Stop chat or send messages.

## Rollout

1. Verify both reviewed Studio/MCP main images and the qualified native plugin
   image. Reconcile active missions, companion runs and pending native effects
   before a runtime rollout. Use the reviewed main pipelines; no host changes.
2. Run `scripts/provision_whiteboard_credentials.py plan`. `prepare --approved
   --studio-image <digest> --mcp-image <digest>` creates the dedicated signer in
   the existing MCP Vaultwarden collection, verifies it, then stages the private
   service key and public Studio admission file with no agent grants. It enables
   no environment flag and restarts nothing.
3. Stage each admitted agent independently with `stage-agent --agent developer --approved` and
   the two exact image arguments. The helper verifies current Studio enrollment,
   stores and re-reads the individual Vaultwarden item, installs a disabled digest
   verifier, projects only that agent's credential, and adds its exact Studio
   read binding. It preserves unrelated entries and rejects identity/expiry/key
   drift rather than silently rotating. Intake remains ungranted because it has
   no native Studio floor enrollment.
   All intended agents may be staged with disabled MCP verifiers before one
   application restart; enable and probe them individually afterward.
4. In the existing protected Studio floor configuration (and its Azure owner), set
   `whiteboardMcpConfigFile` to
   `/etc/studio-whiteboard-mcp/config.json` and admit only Studio's native board
   editing/companion policy through that same owned floor configuration. Keep the full root configuration unchanged. Project
   `WHITEBOARD_ENABLED=true` through `infuse-whiteboard-mcp-runtime`. Release through
   the reviewed application pipelines so startup sees the intended upper bound.
   When the reviewed images are already deployed, a scoped restart of only the
   Studio/MCP application deployments reloads the staged configuration; preserve
   Studio's single-writer Recreate strategy and settle native work first. This does
   not restart the node or container runtime.
   Optional Secret volumes alone grant no access.
5. Enable the staged agent's MCP verifier, wait for the projected file update,
   then run `kubectl --context infuseai-k8s -n agents-swarm exec deploy/agent-developer
   -- studio-whiteboard probe`. Require allowed Studio context and wrong-project
   denial before enabling the next agent. A Secret API write is not proof of
   a mounted update or successful access. No production board edit/model turn is
   needed for this access check.
6. Record only item IDs/collection references, fingerprint, expiry, exact images,
   probe results and enabled capability. All values remain in Vaultwarden and
   intended private projections. The helper's `enable-agent` result is explicitly
   not an access qualification result.

## Expiry, failure and revocation

Credentials contain at least 256 random bits and expire after 90 days. Each agent
has a unique client/credential ID. Server assertions last at most 30 seconds and
cannot exceed credential expiry. No refresh token or shared human identity exists.

Stop after a failed/ambiguous Vaultwarden write and reconcile the exact item name
before retrying. No server grant is written before the item has been verified.
A staged but disabled credential is recoverable; never regenerate a different
value under the same existing item. Expired/mismatched items require explicit
rotation, not broad overwrite. A failed stage may leave a disabled projection;
retry verifies the same item, identity and hash.

Revoke the exact Studio binding first (enabled=false), wait until the application
has observed its projected configuration and prove read denial, then disable that
record in MCP and retire the private client projection. Kubernetes Secret mounts
update asynchronously; do not claim instant revocation from the API write alone.
The application rechecks the mounted policy during pending reads and immediately
before returning content. Keep the Vault item reference for reconciliation;
deleting or rotating unrelated credentials is outside this workflow.

## Agent XML plugin promotion — October 23

Studio PR 4223/main build 10678 adds opt-in `format: "xml"` to native context,
search, read and changes. The model receives the XML document directly, including
bounded spatial relationships and explicitly shared human locations. JSON remains
the default and typed edits/receipts are unchanged. Companion instructions request
XML. Neither renderer is enabled. The separate MCP provider retains its existing
JSON-only composition until its own schema/presentation update is qualified.

The Dockerfile and exact package inventory now bind the deployed Studio image
`sha256:e8867fe938c7587aa1a3bda5caf281d2f3278ca053789a83c7491884f9e6d229`
(source `dcf5f6e87229b6f767ec48404210fa3ab378f662`). The 17-file outbound-only
package retains the Gateway journal and removes central writer/schema artifacts;
its package version remains 0.1.0, so version labels alone cannot prove parity.
The existing startup content fingerprint must refresh the PVC-installed plugin.

Before merging, verify the source gate and reconcile current mission/companion
custody. After the normal main pipeline, compare all expected package file hashes
on every enrolled agent, verify its loaded fourteen-tool inventory and active
native identity, and probe each existing MCP credential. Then use a disposable
section on the live Studio board to qualify actual model XML reading, spatial
reasoning, a guarded edit, receipt/change visibility, an attributed update and
Stop. Remove only the test-owned content and record the result separately from
local synthetic qualification. Keep shared VM settings and credentials unchanged.


## Companion editing and Stop fixes — October 23

Studio PR 4227/main `faf35ff8c3c39fd05a9e615c5f2cb466a30e054c`, build 10692,
published the package now pinned in the Dockerfile and inventory. Model-facing
instructions distinguish spatial title/geometry updates, guarded saved-text
edits and anchored comments. Local malformed-call guidance is static and does
not echo invalid input or bypass strict validation.

Stop previously used read/write rights on a fresh connection, which cannot cancel
a run owned by the disconnected sending connection. The transport now requests
admin scope only for the exact agent/session/run abort; host binding checks and
actual terminal settlement still apply. No Gateway credential, model tool scope,
agent grant, host setting or runtime version changes.

Qualification: Studio full gate 1,051 tests, six browser recovery checks, token-auth
host negative cancellation checks and 224 ms settlement. A real Codex model on an
isolated board completed ordinary title/body edits, a linked update, 362 ms Stop,
and a subsequent turn. Existing credentials and renderers are unchanged. Repeat
all four installed-package hash/inventory checks and a disposable live workflow
after the normal reviewed main release.
