---
title: Studio Gateway Pilot
description: Connect Emon and Tinus to the standalone Studio authority using private cluster TLS, with a separate Tailscale route for Mac testing.
type: runbook
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
---
# Studio Gateway pilot

This records the completed V1 connection pilot. Native multi-task rollout is
owned by [Studio native mission cutover](studio-native-missions.md).

Studio owns missions in `core/studio`; each Gateway owns only its runtime
sessions and a durable plugin journal on its existing PVC. The two enrolled
Gateways are `swarm-coordinator` / `agent-coordinator` and
`swarm-developer` / `agent-developer`. Other agents do not install the plugin.
Existing ordinary Mattermost routes, personas, model policies and tools remain.
No Studio Mattermost channel or bot is activated by this rollout.

## Artifact and configuration

The agent image copies `/opt/studio-plugin` from the digest-pinned Studio image
into `/opt/openclaw-plugins/infuse-studio`, installs its exact declared
dependencies with lifecycle scripts disabled, and packs the reviewed payload as
`/opt/openclaw-plugin-archives/infuse-studio.tgz`. The build independently
installs and inspects that archive on the pinned OpenClaw host without starting a
Gateway or model. The managed runtime installer hashes and installs the immutable
archive; it never installs directly from the image source directory because that
path is not an atomic OpenClaw plugin artifact.
Required-plugin and capability-consent additions are
limited to the coordinator and developer; there is no global consent expansion.

The image also applies the checksum-guarded OpenClaw tool-inventory correction
and runs `probe-studio-tool-inventory.mjs` on a disposable loopback Gateway.
That proof covers the enrolled agents' primary/fallback models, exact three-tool
and four-tool child policies, empty transcripts and unchanged ordinary tools.
It sends no model or bridge request. See the
[compatibility evidence](../evidence/2026-10-04-studio-tool-inventory.md).
Installing a plugin and reading `tools.catalog` alone are insufficient: Studio
admits work only after `tools.effective` matches the assignment exactly.

Each agent's deployment-owned `OPENCLAW_CONFIG_JSON` enables outbound mode at
`https://studio-bridge.core.svc.cluster.local`, with authority `studio-production`,
generation 1, journal namespace `production`, and its actual agent ID. Local RPC
uses the existing Gateway token on `ws://127.0.0.1:18791`. Runtime-only config edits
are overwritten at boot and are not a deployment mechanism.

Each `agent-*-studio` Secret contains only that Gateway's 256-bit bridge token
and the public Studio TLS certificate. Only `ca.crt` is mounted at
`/var/run/studio`; only the matching token key is exposed as an environment
reference. The server private key never enters a Gateway. The plugin trusts
this certificate only for its Studio client, with redirects forbidden and
hostname verification enabled.

The Studio release owns its inbound NetworkPolicy: only these two Pod labels
in `agents-swarm` reach port 8443. No inbound Gateway port, service account,
RBAC, DNS or tailnet ACL changes are part of production enrollment.

## Local backend on the Mac

Local Studio uses a distinct authority, credentials and databases, and the
plugin uses journal namespace `local-mac`. One profile is active per Gateway.
Before switching, stop admission and reconcile/settle all runs from the current
Studio authority. Update the deployment-owned configuration and Secret
references, then use the normal controlled rollout. Retain both journals and
never bypass a journal realm mismatch by deleting state.

The tested private route is Tailscale Serve on
`https://macs-mac-mini.tailc4f8d5.ts.net:8443`. Cluster DNS does not resolve that
name. Set `studioConnectAddress` to the verified Mac tailnet IP (currently
`100.66.41.78`) while keeping `studioUrl` at that HTTPS origin. The plugin sends
that origin's Host/SNI and checks its certificate; it does not disable TLS.
Tailscale Serve forwards to a loopback backend with real OIDC. The synthetic
localhost preview is not exposed. Recheck the IP and route before a local test.

## Verify and stop

Run `task verify-ci` and the image's plugin-install inspection. After deployment,
verify both Pods are ready on the expected digest, the `infuse-studio` service
has no failures, its retained journal advances across authenticated empty polls,
and authenticated loopback RPC works. Check TLS/health from each actual Pod,
reject wrong tokens and unenrolled Pod traffic, and deny the public bridge route.
For an existing prepared Studio child, compare `tools.effective` with its
approved policy and confirm `chat.history` still reports the same session ID.
No `chat.send`, mission start, or model request is needed for these checks.

Actual mission execution is the next bounded pilot: Emon delegates to Tinus,
Tinus returns an artifact, and Emon verifies/closes. Separately test hold/restart
and uncertain-response recovery before expanding. Existing SQL mission workers
must not select Studio session keys; verify their selectors before that pilot.

To stop new admission, revoke enrollment at Studio. Reconcile/abort exact active
runs before disabling the plugin or switching profiles. Retain PVCs and journals.
Do not roll an older Studio image back onto a newer database schema.
