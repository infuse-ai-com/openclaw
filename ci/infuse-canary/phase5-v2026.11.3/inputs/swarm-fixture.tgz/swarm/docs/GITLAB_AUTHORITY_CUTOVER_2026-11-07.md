---
title: GitLab authority cutover evidence — 2026-11-07
description: Evidence for the Azure DevOps to GitLab delivery-authority transfer of the OpenClaw Kubernetes swarm.
type: evidence
status: active
owner: team:agent-platform
tags:
  - evidence
  - gitlab
  - azure-devops
  - kubernetes
  - delivery
---
# GitLab authority cutover evidence — 2026-11-07

## Outcome

GitLab is the sole forward CI/CD authority for `openclaw-k8s-swarm`.
Azure DevOps build definition 56 (`openclaw-k8s-swarm`) was changed from
`queueStatus=enabled`, revision 1, to `queueStatus=disabled`, revision 2 only
after the GitLab rollout and independent runtime qualification passed.

All 17 Azure-only commits, including Azure tip
`4f897abd38bb52d962719ead2f7cf774b4cb92c1`, are reachable from GitLab
`main`. The runtime image source is
`2914d296acee0b1a9c9dd7ac6c70273716e0ea0e`, and the final evidence commit
descends from protected GitLab main `06a171ee6f8bd6b37606ab10ac8f95785fa4ca0e`.

## GitLab delivery evidence

- Source reconciliation: MR !3.
- Delivery contract and scoped identity: MR !5.
- Rootless image-build corrections: MRs !6 and !7.
- Exact image-risk exception: MR !8.
- Protected deploy tooling and least-privilege corrections: MRs !9 through
  !12.
- Final protected delivery pipeline: 958 at exact commit
  `06a171ee6f8bd6b37606ab10ac8f95785fa4ca0e`.
- Repository verification job 4082: passed.
- Existing immutable Harbor artifact verification job 4083: passed.
- Unsuppressed Trivy job 4084: failed visibly as an approved allowed failure.
- Blocking exception guard job 4085: passed.
- Deploy job 4086: passed and changed only the two remaining Deployments.
- Resource rollback job 4087: manual and unplayed.

The deployed image is
`registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:2d8825e59766cc09c741c4c2a92fd9b6779a8b55cf531cd8a9e13c2f5fae7cdf`.
It is accepted, not clean: 2 distinct CRITICAL findings (2 occurrences) and
23 distinct HIGH findings (73 occurrences), represented by 46 exact finding
tuples. The digest/count/tuple-bound exception expires automatically at
`2026-12-07T23:59:59Z`.

## Fail-closed rollout evidence

The first protected attempt failed before Kubernetes access because the deploy
image lacked `jq`; production was unchanged. Subsequent attempts exposed two
least-privilege client assumptions and one unavailable log-scanner binary:

1. aggregate Deployment reads required denied list access;
2. `kubectl rollout status` internally required denied list/watch access;
3. `rg` was absent and could have skipped the fatal-log check inside an
   `if` condition.

The permanent corrections install pinned/checksummed `jq`, use only exact-name
Deployment reads, poll exact generation/readiness state without list/watch,
and enforce fatal log patterns with portable `grep -E`. RBAC was not widened.
Incrementally updated canaries were independently qualified before work
continued. Pipeline 958 then converged the final intake and coordinator
Deployments through the corrected path.

## Runtime qualification

All five Deployments are 1/1 Ready on the exact target digest and source, with
one active pod each and zero restarts. Every agent passed configuration,
toolbox, skill-manifest parity, Gateway, and Mattermost runtime smoke checks.
Fatal log-pattern scans were clean. Rollout-only probe warnings stopped at
`2026-11-07T20:18:45Z` and did not recur through the follow-up window.

The original Kubernetes object identities were preserved:

| Resource | UID | Final state |
| --- | --- | --- |
| `deployment/agent-coordinator` | `8014f017-dc69-4083-abef-12bfa933e3de` | Ready |
| `deployment/agent-designer` | `f4d26112-4465-4672-bc89-7098261798f8` | Ready |
| `deployment/agent-developer` | `f9fe8d7f-be60-4509-af89-cb5c50572054` | Ready |
| `deployment/agent-infra` | `0b805892-2d59-42b2-9b60-f5125b6c2fc4` | Ready |
| `deployment/agent-intake` | `f7aaf605-6e32-4791-9252-dc2cb2e3fe6a` | Ready |
| `pvc/agent-coordinator-workspace` | `be975448-c1a4-4edc-8763-78c37f44a843` | Bound, 10Gi |
| `pvc/agent-designer-workspace` | `670dca39-c5b9-4de7-829f-eafd339427cf` | Bound, 10Gi |
| `pvc/agent-developer-workspace` | `1a035d6d-f890-4747-8899-08379933c56a` | Bound, 10Gi |
| `pvc/agent-infra-workspace` | `ae7714ce-4b83-4cf3-912b-46b7c26930bf` | Bound, 10Gi |
| `pvc/agent-intake-workspace` | `23377bd6-db74-487e-8a44-3deb0cd33011` | Bound, 10Gi |

The scoped deployer can get and patch only the five exact Deployments, can
read the bounded rollout evidence resources, and cannot read Secrets, execute
in pods, delete PVCs, or access another namespace. Its one-year kubeconfig and
the project-scoped Harbor robot remain in company Vaultwarden and protected,
masked, hidden, raw GitLab variables.

## Recovery boundary

Fito explicitly excluded backup and restore from this cutover. No backup,
restore, Secret, credential, PVC-content, workspace-data, RBAC, DNS, or
firewall mutation was performed. Rollback job 4087 is resource-only and does
not constitute data-recovery proof.
