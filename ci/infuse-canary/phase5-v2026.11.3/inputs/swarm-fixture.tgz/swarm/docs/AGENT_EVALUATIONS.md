---
title: OpenClaw Agent Evaluation Runner
description: Reproducible, read-only, metadata-only evaluation of sanitized agent workflows without custom runtime artifacts.
type: runbook
status: active
owner: team:agent-platform
tags:
  - runbook
  - agents
  - evaluation
  - opik
  - observability
---

# OpenClaw Agent Evaluation Runner

## Purpose

`tools/agent-evals/runner.py` evaluates a versioned 12-case sanitized workflow
suite through deterministic gates. Four nondeterministic cases run three
trials; the complete suite is 20 trials. The suite covers verification,
Knowledge Base use and non-use, wrapper outcomes, recovery, tool efficiency,
workflow lifecycle, external-delivery safety, and credential refusal.

The runner is offline and read-only by default. It stores no prompt, model
response, stdout, stderr, traceparent, session key, or credential. The report
keeps only hashes and lengths of sanitized final answers, bounded tool names
and counts, deterministic blockers, and exact artifact revisions. Output
directories are mode `0700` and reports are mode `0600`.

## Deterministic replay

Run the accepted control fixture:

```bash
python3 tools/agent-evals/runner.py \
  --suite tools/agent-evals/cases.v1.json \
  --replay tools/agent-evals/fixtures/baseline-results.v1.json \
  --output /secure/path/agent-evals/baseline.json \
  --runner-revision <exact-swarm-revision> \
  --image-revision <exact-image-digest> \
  --runtime-revision <exact-openclaw-runtime-revision> \
  --skill-bundle-revision <exact-skill-bundle-revision> \
  --model-revision <exact-provider-model-revision>
```

Exit code `0` means every deterministic gate passed. Exit code `2` means the
candidate was correctly rejected and the metadata-only report lists its
blockers. The checked-in degraded fixture proves rejection for a wrong final
answer, missing required tool, forbidden external-message tool, and excess
tool calls. It is test-only and is never deployed.

## Live Gateway execution

Live execution is an explicit operator action. The runner uses the supported
`openclaw agent --json` Gateway CLI through exact `kubectl exec` arguments. It
does not use `--deliver`, invoke a shell, or accept an arbitrary command
prefix. Every case is declared `read_only` and must forbid the `message` tool.

```bash
python3 tools/agent-evals/runner.py \
  --suite tools/agent-evals/cases.v1.json \
  --allow-live-gateway \
  --candidate-revision <exact-candidate-revision> \
  --output /secure/path/agent-evals/live.json \
  --runner-revision <exact-swarm-revision> \
  --image-revision <exact-image-digest> \
  --runtime-revision <exact-openclaw-runtime-revision> \
  --skill-bundle-revision <exact-skill-bundle-revision> \
  --model-revision <exact-provider-model-revision> \
  --kube-context infuseai-k8s \
  --namespace agents-swarm \
  --deployment agent-developer \
  --profile agent-developer \
  --agent-id agent-developer
```

Run only against the reviewed Tinus target before any broader use. Existing
Kubernetes RBAC remains the execution boundary, and the runner has no path to
send an external chat reply.

## Trace-correlation boundary

The pinned Gateway CLI has no supported input for W3C `traceparent` and its
JSON result does not expose an authoritative OTel trace ID. The runner records
`trace_propagation=unsupported_by_gateway_cli`, writes `trace_id=null`, and
sets `trace_correlation_claimed=false`. It does not infer a Langfuse or Loki
trace from time proximity, session data, or tool names. Tool, workflow, skill,
and wrapper metrics remain useful aggregate evidence, but exact agent-eval
trace linkage is a documented boundary until a public Gateway capability
exists.

## Grading and promotion boundary

Deterministic graders enforce exact final status, required and forbidden
tools, tool-call budget, failure budget, complete trial sets, and no external
delivery. Model-assisted grading is represented separately and disabled; it
can never be the sole promotion gate. A passing report is only eligible for
human review. The runner cannot edit a skill, open or merge a pull request,
deploy a candidate, or promote a runtime.

## Verification

```bash
task verify-agent-evals
task verify
```

The tests validate strict schemas, 12-case/20-trial completeness, private
metadata-only output, the no-delivery Gateway invocation, disabled
model-assisted grading, and deterministic degraded-candidate rejection.
