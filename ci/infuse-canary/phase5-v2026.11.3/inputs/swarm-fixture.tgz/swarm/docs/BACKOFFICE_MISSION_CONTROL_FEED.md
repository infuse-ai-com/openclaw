---
title: Retired Backoffice Mission Control Feed
description: Retirement record for the filesystem feed replaced by the
  authenticated Artifact Registry on 2026-09-01.
type: guide
status: deprecated
owner: team:agent-platform
tags:
  - guide
  - backoffice
  - mission
  - control
  - feed
---
# Retired Backoffice Mission Control Feed

The filesystem Mission Control feed is permanently retired. The authenticated
Artifact Registry is the only artifact authority for all six producers and for
Backoffice read and lifecycle operations.

The 2026-09-01 clean-start cutover intentionally discarded legacy content and
removed:

- the `openclaw-mission-control-collector` and
  `openclaw-mission-control-lifecycle` CronJobs and their completed Jobs;
- the Kapiteky relay Deployment and default-deny NetworkPolicy;
- the collector and lifecycle service accounts, Roles, and RoleBindings;
- the 5 GiB `core/openclaw-mission-control` feed PVC;
- the 1 GiB `agents-swarm/kapiteky-mission-control-relay` PVC;
- the lifecycle-worker credential key.

The deployment helper keeps one idempotent retirement function so a stale
resource cannot survive a later release or manual drift. It does not contain a
feed/relay/worker creation path, and the agent image no longer ships the
historical collector or lifecycle executables.

## Current path

- Persistent agents publish in runtime-selected `registry` mode with
  producer-bound file-mounted credentials.
- Kapiteky publishes through `task publish-kapiteky-artifact-registry -- ...`,
  which uses a short-lived internal publisher pod and no public Registry route.
  Follow the [publisher runbook](runbooks/kapiteky-artifact-publisher.md) for
  reviewed local helpers, the explicit isolation prerequisite and qualification.
- Backoffice mounts separate read and lifecycle client files and never mounts
  the Registry PVC.
- Exact immutable revisions are used for handoffs and lifecycle actions.

The maintained runtime and recovery contract is
`k8s/platform/artifact-registry/README.md`. Historical feed implementation
details remain available through Git history; they are intentionally absent
from the active tree.

## Retirement audit

The following query must return no resources:

```bash
kubectl --context infuseai-k8s get cronjob,job,deploy,serviceaccount,role,rolebinding,networkpolicy,pvc \
  -n core -l 'app.kubernetes.io/name in (openclaw-mission-control-collector,openclaw-mission-control-lifecycle)'
kubectl --context infuseai-k8s get deploy,networkpolicy,pvc \
  -n agents-swarm -l 'app.kubernetes.io/component=mission-control-relay'
```

The dedicated 20 GiB `core/backoffice-artifact-registry` PVC and every agent
workspace PVC are outside this retirement scope and must remain Bound.
