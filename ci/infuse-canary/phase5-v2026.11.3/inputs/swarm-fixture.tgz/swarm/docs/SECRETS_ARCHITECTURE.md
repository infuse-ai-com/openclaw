---
title: Secrets Architecture
description: This document records the target secrets model for persistent
  OpenClaw agents. It explains why Vaultwarden owns durable secret values, how
  per-agent access is scoped, and how Kubernetes receives only runtime
  materialization.
type: architecture
status: active
owner: team:agent-platform
tags:
  - architecture
  - secrets
---
# Secrets Architecture

This document records the target secrets model for persistent OpenClaw agents.
It explains why Vaultwarden owns durable secret values, how per-agent access is
scoped, and how Kubernetes receives only runtime materialization.

## Decision

Vaultwarden is the only durable source of truth for agent runtime secrets.

Git stores reviewable access intent. Kubernetes stores runtime copies needed by
pods. Agent workspaces, prompts, memory, screenshots, logs, images, and docs
must not store secret values.

## Why

The swarm needs fast rotation and small blast radius.

If Tinus Lordvals's Mattermost token leaks, we should rotate one Vaultwarden item,
re-materialize one runtime target, and restart or reload only `agent-developer`.
We should not hunt through CI variables, Kubernetes hand-created secrets,
local `.env` files, docs, and chat history.

The model also makes access reviewable:

- Vaultwarden answers which secret value exists.
- `config/agent-skill-bundles/<agent-id>.json` answers which agent is allowed
  to receive which item through persistent sync or materialization.
- Kubernetes answers which runtime copy is currently mounted or injected.
- Backoffice may show metadata and sync status, but never values.

## Non-Goals

- No shared "all agents" Vaultwarden credential.
- No broad Vaultwarden login material inside normal worker-agent pods.
- No durable runtime tokens directly authored in Kubernetes or CI without a
  matching Vaultwarden source item and Git allowlist entry.
- No secret values in Git, task briefs, memory files, Mattermost, screenshots,
  logs, PVC workspaces, or container images.
- No agent-managed credential rotation without human approval.

## Control Layers

Direct lookup and persistent materialization have distinct control layers.

First, Vaultwarden access control limits what an identity can read. The target
shape is one per-agent collection or equivalent scoping boundary for each
persistent agent. A future broker or sync identity may read more broadly, but
then the sync helper must still enforce Git allowlists before writing runtime
secrets.

For persistent materialization, Git declares exact intent. Each agent bundle uses
`credential_access.default_policy: deny` and lists exact item names, purpose,
runtime target, visibility, and review or expiry conditions. The sync helper
must fail closed when the requested item or destination is not declared.

For direct lookup, Vaultwarden account and collection membership is the item
authorization boundary. The runtime bundle deliberately has no duplicate
item/field allowlist; it only supplies fixed caller identity, supported-field,
and project-materialization checks.

## Vaultwarden Organization And Collections

The current organization is `Infuse AI`.

Current collection usage is capability-oriented:

- `05-Mattermost` stores per-agent bot tokens.
- GitLab uses exact `GitLab / <agent-id> service account token` items via each agent’s direct account; collection names are verified in Vaultwarden.
- `02-Homelab` stores operational material such as Satwa Nutella read-only kubeconfig.

The longer-term preferred shape is per-agent scoping, for example:

- `agents/agent-developer`
- `agents/agent-designer`
- `agents/agent-infra`

The collection naming can evolve, but the important rule is stable: an agent
or its runtime sync path must not be able to read unrelated agents' credentials.

## Agent Bundle Contract

The reviewable contract lives in:

```text
config/agent-skill-bundles/<agent-id>.json
```

Each persistent sync or materialization declaration must include:

- Vaultwarden organization;
- exact Vaultwarden item name;
- purpose;
- runtime target type;
- Kubernetes namespace, Secret name, and key;
- optional mount path for file targets;
- agent visibility;
- review or expiry condition.

The bundle may name item metadata, but never the secret value or full item JSON.
Direct lookup visibility is maintained in Vaultwarden, not duplicated as bundle
item metadata.

## Runtime Delivery

Runtime delivery starts with Kubernetes Secrets because that is available and
easy to audit today.

Supported target types:

- `kubernetes-secret-env` for declared runtime tokens such as Mattermost bot tokens.
  GitLab service tokens use task-time lookup, not an env Secret sync target.
- `kubernetes-secret-file` for kubeconfigs, JSON credentials, and credentials
  that should be mounted as files instead of exposed as environment variables.

Prefer mounted files for new credential types when the consumer can read files
or reload them. Environment variables are frozen at process start, so they make
rotation depend on a pod restart.

### Temporary Runtime Auth Bridge

During the first InfuseAI `agents-swarm` rollout, `openclaw-runtime` may contain
`OPENCLAW_AUTH_PROFILES_JSON` copied from Kapiteky's approved local OpenClaw
auth profile. This is an explicitly temporary bridge so the first Tinus Lordvals, Stewie Hobs,
and Satwa Nutella pods can start and perform model-backed smokes.

Follow-up target: replace this bridge with a Vaultwarden-backed item such as
`OpenClaw / agents-swarm runtime auth profiles`, sync it through the same
bundle-enforced or control-plane-secret path, and remove dependence on local
Kapiteky profile material.

## Startup Flow

The current control-plane sync flow is:

```text
AGENT_ID
  -> read config/agent-skill-bundles/<agent-id>.json
  -> validate requested Vaultwarden item and target
  -> fetch only that item from Vaultwarden
  -> write the declared Kubernetes Secret
  -> deploy or restart the affected agent pod
```

Inside the pod, OpenClaw receives only the runtime material it needs, such as:

```text
MATTERMOST_BOT_TOKEN
/var/run/openclaw-agent/secrets/kubeconfig/kubeconfig
```

Only approved persistent agents receive Vaultwarden bootstrap material, and
each uses a dedicated account with narrow collection scope. Other runtimes must
use persistent sync or a reviewed broker path; direct-account bootstrap is not
an application credential bridge.

Agent direct-account model: each persistent agent can receive a dedicated
Vaultwarden account bootstrap secret and agent-specific collection scope for
task-time lookup. The goal is to avoid pod restarts for normal secret rotation;
Vaultwarden account and collection membership authorizes direct reads, while
Git declarations remain limited to persistent sync and materialization paths.

## Hot Rotation Direction

The target direction is no gateway restart for adding or rotating tokens when
the consuming subsystem can support it.

The preferred future flow is:

```text
rotate in Vaultwarden
  -> trusted sync or broker refreshes mounted credential files
  -> OpenClaw watches or lazy-reads the files
  -> new requests use the new token
```

Until hot reload exists for a given credential, rotation may still require
re-materializing the Kubernetes Secret and restarting only the affected agent
Deployment. That is acceptable as an MVP runtime behavior, but new credential
types should avoid env-only delivery when file-based reload is practical.

## Current Credentials

Tinus Lordvals / `agent-developer`:

- `Mattermost / agent-developer BOT token`
- `GitLab / agent-developer service account token`

Stewie Hobs / `agent-designer`:

- `Mattermost / agent-designer BOT token`
- `GitLab / agent-designer service account token`

Satwa Nutella / `agent-infra`:

- `Mattermost / agent-infra BOT token`
- `GitLab / agent-infra service account token`
- `Kubernetes / agent-infra read-only kubeconfig`

GitLab operations must resolve the executing agent’s own item. There is no
shared credential fallback. Legacy Azure access is a separate revocation audit;
a source migration alone does not demonstrate that old credentials expired.

## Rotation Flow

For a normal token rotation:

1. Rotate or replace the value in Vaultwarden.
2. Re-run the bundle-enforced sync for the affected agent and item.
3. Reload the file consumer, or restart only the affected Deployment when the
   credential is env-backed.
4. Run the relevant smoke.
5. Record the rotation or access change if it changes scope or risk.

For suspected compromise:

1. Disable or rotate the exposed credential in the upstream service first.
2. Rotate the Vaultwarden item.
3. Remove unnecessary runtime targets and temporary bundle entries.
4. Re-sync and restart or reload only affected agents.
5. Review Mattermost channel membership, repo access, Kubernetes RBAC, and logs
   for the affected agent.

## Verification

Static verification:

```bash
task verify-agent-credential-sync
```

Live smokes should prove capability without printing values. Examples:

```bash
AGENT_ID=agent-developer task smoke-agent-repo-checkout
AGENT_ID=agent-infra task smoke-agent-infra-kube-access
```

Expected proof is behavioral: clone succeeds, kube read-only verbs work, and
denied operations fail. Secret values must never appear in smoke output.

## Related Docs

- `docs/CREDENTIAL_ACCESS.md` - exact credential bundle contract.
- `docs/AGENT_VAULTWARDEN_ACCESS_PLAN.md` - implementation plan and sync helper
  behavior.
- `docs/AGENT_WORKER_READINESS_PLAN.md` - worker access rollout plan.
- `docs/SECURITY.md` - repo security boundaries.
- `docs/RUNBOOK.md` - operator commands.
