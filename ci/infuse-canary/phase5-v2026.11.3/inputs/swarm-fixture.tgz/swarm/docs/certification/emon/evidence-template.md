---
title: Emon Certificate Evidence Template
description: Template for recording bounded Emon certification scope, run
  evidence, verification, findings, and human approval.
type: template
status: draft
owner: team:agent-platform
tags:
  - evidence
  - certification
  - emon
  - template
---
# Emon Certificate Evidence Template

## Run Metadata

- Agent id:
- Agent display name:
- Certification level:
- Certificate name:
- Run date:
- Issuer:
- Approved by:
- Runtime image/version:
- Skill bundle source:
- Test runner:
- Mattermost thread:

## Scope

- Goal:
- Allowed actions:
- Disallowed actions:
- Repositories:
- Credentials:
- Services:

## Results

- Overall status:
- Runtime/tool availability:
- Skill-group statuses:
- Verification commands:
- Evidence links:
- Commit/branch:
- Screenshot/path:
- Blockers:

## Safety Review

- Secrets exposed: yes/no
- External actions performed: yes/no
- Destructive actions performed: yes/no
- Approval-sensitive actions requested: yes/no
- Approval-sensitive actions performed: yes/no
- Notes:

## Recertification Triggers

- Runtime image change:
- Skill catalog or bundle change:
- Credential mount change:
- Toolchain change:
- Role/approval policy change:
