---
title: Emon Swarm Certification
description: This folder defines the certification suite for agent-coordinator.
type: overview
status: active
owner: team:agent-platform
tags:
  - overview
  - certification
  - emon
---
# Emon Swarm Certification

This folder defines the certification suite for `agent-coordinator`.

The suite is a staged trust ladder. Each level validates one category of agent
capability, records evidence, and states what Emon may be trusted to do next.
Certificates are operational evidence, not blanket approval. They expire when
runtime images, skill bundles, credential mounts, toolchains, or agent identity
rules change.

## Levels

- Level 0: Runtime Ready
- Level 1: Swarm Practitioner
- Level 2: Product Engineering Associate
- Level 3: Operations Associate
- Level 4: Delivery Professional
- Level 5: Swarm Coordinator Professional

See [levels.md](levels.md) for the level definitions and
[scoring-rubric.md](scoring-rubric.md) for pass criteria.

## Current Baseline

As of the live Mattermost smoke threads from 2026-05-30:

- Thread-safe Mattermost behavior: pass.
- Identity, safety, and approval reasoning: pass.
- Azure repo clone, branch, Cursor Composer delegation, commit, and push: pass
  after the runtime was fixed.
- Repo verification: partial, because `task verify-ci` hit runtime/repo
  constraints and Emon reported that honestly.
- Runtime skill manifest consistency: partial, because earlier granted skill
  names were not mounted or visible.
- Vaultwarden authenticated access: blocked.
- Browser login using Vaultwarden credentials: blocked until vault access works.

The next useful certification target is Level 1 plus Level 2, followed by a
rerun of the Level 3 Vaultwarden/browser tests after runtime credential sync is
fixed.

## Evidence

Use [evidence-template.md](evidence-template.md) for a human-readable run
record. Store final certificate records as JSON so the
`agent-certification-validation` skill can inspect them deterministically.

Suggested paths:

```text
docs/certification/emon/evidence/<YYYY-MM-DD>-level-<n>.md
docs/certification/emon/certificates/<YYYY-MM-DD>-level-<n>.json
```

Do not store credentials, raw screenshots with secrets, private Mattermost
content unrelated to the test, or unredacted logs.
