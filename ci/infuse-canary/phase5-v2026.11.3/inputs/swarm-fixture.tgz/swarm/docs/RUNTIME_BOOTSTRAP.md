---
title: Runtime Bootstrap
description: "Historical note: this document records the original ncase
  prototype bootstrap. It is not an active deployment runbook. The maintained
  deployment path is InfuseAI Kubernetes through k8s/overlays/infuseai/ and
  docs/RUNBOOK.md."
type: overview
status: active
owner: team:agent-platform
tags:
  - overview
  - runtime
  - bootstrap
---
# Runtime Bootstrap

Historical note: this document records the original ncase prototype bootstrap.
It is not an active deployment runbook. The maintained deployment path is
InfuseAI Kubernetes through `k8s/overlays/infuseai/` and `docs/RUNBOOK.md`.

At the time, the ncase deployment was a safe staging host:

- image is pulled from Harbor;
- `/workspace` is backed by a PVC;
- the main pod container runs non-root as UID/GID `10001`;
- OpenClaw is installed;
- a live, scoped Mattermost-speaking `agent-developer` runtime is enabled.

## Historical ncase Runtime

```text
cluster: ncase-microk8s
namespace: openclaw-swarm-staging
deployment: agent-developer
workspace: /workspace
profile target: agent-developer
coordination channel: openclaw-swarm-dev
```

## Boot Phases

### Phase A - Host Alive

Status: done.

The container starts and stays alive with the default command. It writes runtime metadata to `/workspace/.openclaw-runtime-info`.

The shared image includes the common runtime toolbox for all persistent agents:

- `git`
- `task`
- `kubectl`
- `helm`
- Docker CLI, without an in-pod Docker daemon by default
- `crane`
- `python3` and `pip3`; `python` is also shimmed to `python3` for common
  agent-generated snippets, but checked-in docs/scripts should still prefer
  explicit `python3`
- `uv`
- `rg`
- `fd`
- `jq`
- `yq`
- Node.js, `npm`, `npx`, `pnpm`, and `yarn`
- pinned npm and Python Playwright packages with their matching managed Chromium
  browser; the image seed is linked into the writable PVC-backed
  `/workspace/.cache/ms-playwright` cache at startup without copying its payload,
  while system `chromium` remains available for direct CLI use
- Xvfb/xauth, Noto fonts, network/debug CLIs, PDF/image helpers, and archive/sync tools
- Ruby, Bundler, Git LFS, shellcheck, and basic native build tools
- `openclaw`

Verify a live agent's toolbox with:

```bash
AGENT_ID=agent-developer task smoke-agent-toolbox
```

The shared cache removes repeated pod-local browser downloads and survives pod
replacement because `/workspace` is the agent PVC. Image-managed revisions are
links to the immutable image seed, so each agent does not duplicate roughly 1 GiB
of browser data. Project-installed revisions remain real PVC directories and
coexist with the image links; Playwright's package registry and garbage
collection remain authoritative for revision lifecycle. Project repositories
still own their Playwright package version, explicit browser-install task, and
dev dependency policy; the runtime does not replace project pins or change
global `NODE_ENV`. The toolbox smoke proves the shared Python API resolves its
cache path through the image seed and can launch it, but project end-to-end smoke
remains the project's evidence boundary.

After the own-agent Vaultwarden prewarm, the entrypoint installs a host-scoped
GitLab credential helper before cloning skills. It resolves the exact agent
item and verifies the API username; inherited tokens are ignored. The helper
returns credentials only to Git and persists no token. The old Azure helper is
removed. See `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`.

### Phase B - Profile Bootstrap

Status: done.

Create a profile-isolated OpenClaw config inside the PVC:

```bash
pod=$(kubectl --context ncase-microk8s -n openclaw-swarm-staging get pod \
  -l app.kubernetes.io/name=agent-developer \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')

kubectl --context ncase-microk8s -n openclaw-swarm-staging cp \
  scripts/bootstrap-developer-agent-profile.sh \
  "$pod:/tmp/bootstrap-developer-agent-profile.sh"

kubectl --context ncase-microk8s -n openclaw-swarm-staging exec "$pod" -- \
  sh -lc 'chmod +x /tmp/bootstrap-developer-agent-profile.sh && /tmp/bootstrap-developer-agent-profile.sh'
```

The profile must not copy Kapiteky's full Mac config. It should use only scoped values for the release agent.

### Phase C - Mattermost Identity

Status: done for `agent-developer`.

Required secret:

```text
agent-developer-mattermost
  MATTERMOST_BASE_URL
  MATTERMOST_BOT_TOKEN
  MATTERMOST_CHANNEL_ID
```

Do not put this token in Git or memory files.

Source of truth:

```text
Vaultwarden item: Mattermost / agent-developer BOT token
Kubernetes Secret: agent-developer-mattermost
```

### Phase D - Gateway/Agent Boot

Status: done for the staging release agent.

`OPENCLAW_BOOT_COMMAND` in the `openclaw-runtime` Kubernetes Secret starts the profile-specific gateway:

- profile: `agent-developer`
- gateway: loopback port `18791`
- model: `openai/gpt-5.5` through the `@openclaw/codex` app-server harness
- channel: Mattermost `openclaw-swarm-dev`
- group policy: allowlist, Fito/Kapiteky/Tinus Lordvals/Stewie Hobs/Satwa Nutella/Emon Lusk/`@almar456` as approved swarm participants; mention required for non-coordinator agents and not required for Emon / `agent-coordinator`

Current verified state:

- the bot token is valid;
- the bot is a member of `openclaw-swarm-dev`;
- the gateway connects to Mattermost as `@agent-developer`;
- `openclaw --profile agent-developer models status` reports `openai/gpt-5.5` as the default;
- direct agent smoke loads the PVC persona files and succeeds with provider `openai` and agent harness `codex`.
- the runtime image syncs `openclaw-agents-persona` on startup and installs PVC
  persona files from that external checkout when `AGENT_ID` is set, preserving
  an existing `MEMORY.md`.

Temporary exception: Fito approved copying Kapiteky's OpenAI/Codex OAuth profile into the isolated agent-developer auth store. Keep this as an MVP bridge only; replace it with a scoped agent-developer credential through Vaultwarden/Kubernetes Secrets.

For persistent embedded agents, provider auth must exist in the embedded agent directories, not only at the profile root:

```text
$HOME/.openclaw-<profile>/agents/<agent-id>/agent/auth-profiles.json
$OPENCLAW_STATE_DIR/agents/<agent-id>/agent/auth-profiles.json
```

If `OPENCLAW_AUTH_PROFILES_JSON` is used during bootstrap, write it to the profile root, the home embedded agent directory, the state root, and the state embedded agent directory. Otherwise Mattermost can connect while model calls or cron-triggered agent turns fail with missing OpenAI/Codex auth.

After writing config/auth files, the boot command must run `openclaw-agent-ensure-plugins "$profile"` before `gateway run`. The helper installs and indexes required external runtime plugins such as `@openclaw/codex` into the active profile/PVC registry. ACPX remains installed in the image as an OpenAI/Codex-backed transport only and is registered by the gateway as an embedded runtime backend; it is not force-installed into fresh profile registries during normal startup. Use `openclaw --profile <profile> doctor --fix --yes --non-interactive` only as a manual repair path for legacy profile migration or stale route state.

Each persistent agent's `OPENCLAW_CONFIG_JSON` must include
`commands.ownerAllowFrom` with Fito's Mattermost owner id
(`mattermost:qx31qia617r38b4huiyx8jo7de`). This is separate from Mattermost
`allowFrom`: direct-message access allows normal chat access, while
Mattermost channel membership controls group-channel access. The
`commands.ownerAllowFrom` list gates owner-only commands, diagnostics, config
commands, and dangerous action approvals.

Persistent Mattermost-enabled agents keep `replyToMode: "all"` for thread
placement and use the pinned fleet boot policy: typed progress with the
`Thinking… please wait` headline, `finalDelivery: "separate"`, reaction actions
enabled, raw command text in progress rows, a 12,000-character outbound chunk
limit, and a 1,500 ms Mattermost inbound debounce. Raw command rendering must
not be used as an excuse to inline credentials or secret values in shell
commands. The Mattermost adapter keys that debounce by account,
channel, thread, and sender; control commands and attachments bypass it.
Mattermost group handling uses `groupPolicy: "open"` so channel
membership is the group access boundary. `agent-coordinator` / Emon uses
`chatmode: "onmessage"` and `requireMention: false` for ambient coordination.
Specialist agents use `chatmode: "oncall"`, `requireMention: true`, and disable
reply-to-bot, quoted-bot, and thread-participation implicit mentions. This makes
the literal dispatcher mention the only task-root activation signal and avoids
noisy thread fan-out.

## Guardrails

- Do not reuse Kapiteky's Mattermost token for `agent-developer`.
- Do not copy the full local `~/.openclaw/openclaw.json` into the pod.
- Do not enable open group response policies for the first agent identity.
- Keep `agent-developer` scoped to assigned engineering work, repo-local verification, and smoke evidence until reviewed.
- Do not use legacy `openai-codex/gpt-5.5` model refs on OpenClaw 2026.6.1+. Use `openai/gpt-5.5` with the `@openclaw/codex` plugin installed by `openclaw-agent-ensure-plugins`.
