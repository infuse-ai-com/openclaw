---
title: Backoffice Ritual Calendar Export
description: Backoffice can ingest sanitized OpenClaw cron metadata through
  OPENCLAWCRONCALENDAREXPORTPATH. The snapshot is read-only display data for the
  Ritual Calendar.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - backoffice
  - ritual
  - calendar
  - export
---
# Backoffice Ritual Calendar Export

Backoffice can ingest sanitized OpenClaw cron metadata through
`OPENCLAW_CRON_CALENDAR_EXPORT_PATH`. The snapshot is read-only display data for
the Ritual Calendar. It must never include raw prompts, delivery targets,
secrets, auth material, memory contents, or environment variables.

Current OpenClaw versions store live cron jobs in SQLite behind the Gateway
automation APIs after legacy `~/.openclaw/cron/jobs.json` import. Use
`openclaw cron add|edit|remove` or the Gateway cron API for writes. The exporter
uses authenticated, paginated `cron.list` Gateway calls by default. A legacy
jobs file is read only when `--jobs-file` or `OPENCLAW_CRON_JOBS_FILE` points to
an existing compatibility snapshot.

## Generate A Snapshot

From an OpenClaw runtime profile or agent pod workspace:

```bash
python3 scripts/export-openclaw-cron-calendar.py \
  --output /tmp/openclaw-cron-calendar.json
```

The Gateway query requests disabled jobs and follows every page from one stable
snapshot revision. Backoffice pause/resume controls need disabled jobs to remain
in the feed so a paused row can still render a Resume action. Authentication,
transport, malformed-page, duplicate-job, incomplete-pagination, or revision
drift failures exit non-zero and do not emit a snapshot. A successful empty
Gateway response is emitted as `source.status=no_cron_jobs`.

The export intentionally excludes system-owned heartbeat wake loops and
internal model-memory maintenance. `heartbeat-*` jobs, dreaming jobs, and
memory backup/sync jobs are operational implementation details, not team
rituals, so they are counted in
`source.excludedInternalMaintenanceCount` but never emitted as calendar events.
This includes the managed `Memory Dreaming Promotion` jobs and the Kubernetes
memory-sync name if it is ever mirrored into an OpenClaw cron store. The
Kubernetes `openclaw-agent-memory-sync` CronJob is not an OpenClaw Gateway job
and is already outside this feed.

The `task` wrapper writes a local smoke snapshot:

```bash
AGENT_ID=agent-coordinator task export-openclaw-cron-calendar
```

For a Backoffice-readable feed directory, write one snapshot per agent:

```bash
AGENT_ID=agent-coordinator \
CRON_CALENDAR_DIR=/tmp/openclaw-cron-calendar \
task export-openclaw-cron-calendar-feed
```

Backoffice can read every `*.json` file in that directory with:

```bash
OPENCLAW_CRON_CALENDAR_EXPORT_DIR=/tmp/openclaw-cron-calendar
```

If the deployment path prefers a single file, merge the feed directory into one
catalog:

```bash
CRON_CALENDAR_DIR=/tmp/openclaw-cron-calendar \
task merge-openclaw-cron-calendar-feed
```

Then point Backoffice at:

```bash
OPENCLAW_CRON_CALENDAR_EXPORT_PATH=/tmp/openclaw-cron-calendar/merged-openclaw-cron-calendar.json
```

## Snapshot Shape

```json
{
  "schemaVersion": 1,
  "generatedAt": "2026-06-02T15:20:00+00:00",
  "source": {
    "type": "openclaw_cron_export",
    "agentId": "agent-coordinator",
    "gatewayLabel": "agent-coordinator OpenClaw",
    "jobsFile": "openclaw gateway cron.list",
    "stateIncluded": true,
    "backend": "gateway_cron_list",
    "status": "available",
    "paginationComplete": true,
    "snapshotRevision": "sha256:example",
    "excludedInternalMaintenanceCount": 1
  },
  "events": [
    {
      "id": "openclaw-agent-coordinator-example",
      "title": "Example",
      "sourceType": "openclaw_cron",
      "status": "live",
      "system": "openclaw",
      "ownerAgentSlug": "agent-coordinator",
      "gatewayLabel": "agent-coordinator OpenClaw",
      "enabled": true,
      "sessionTarget": "isolated",
      "deliveryMode": "none",
      "riskLabel": "OpenClaw runtime task",
      "scheduleLabel": "Daily 09:00",
      "cronExpression": "0 9 * * *",
      "timezone": "Europe/Madrid",
      "hour": 9,
      "minute": 0,
      "durationMinutes": 20,
      "expectedDurationLabel": "sanitized cron run",
      "loadClass": "low",
      "tags": ["agent-coordinator", "cron", "openclaw"],
      "description": "Sanitized OpenClaw cron metadata. Raw prompt/payload and delivery targets are intentionally omitted.",
      "sourceLabel": "openclaw cron runtime store",
      "displayMode": "week_block"
    }
  ]
}
```

Backoffice also accepts the legacy raw event-array shape for local testing, but
new producers should use the envelope above so source metadata is explicit.

## Redaction Contract

Allowed:

- job id/name;
- enabled state;
- schedule kind, cron expression, timezone, simple computed hour/minute;
- session target class;
- delivery mode class;
- non-secret runtime state labels from `jobs-state.json`;
- generated/source metadata with home paths abbreviated.

Forbidden:

- `payload.message` or any raw prompt;
- Mattermost channel ids, email addresses, webhook URLs, or delivery targets;
- secret names/values, environment variables, cookies, tokens, auth JSON;
- private memory/session/task contents.

## Integration Path

For the first production slice, each agent/gateway can write one snapshot to a
shared read-only location that Backoffice mounts or syncs, then set either:

```bash
OPENCLAW_CRON_CALENDAR_EXPORT_PATH=/path/to/openclaw-cron-calendar.json
OPENCLAW_CRON_CALENDAR_EXPORT_DIR=/path/to/openclaw-cron-calendar-feed
```

Backoffice marks snapshots stale when their `generatedAt` or file mtime is older
than its configured freshness window. Runtime writes should remain
approval-gated and go through OpenClaw cron APIs rather than direct JSON edits.

## Kubernetes Swarm Feed

The InfuseAI swarm deployment includes a dedicated
`openclaw-cron-calendar-collector` CronJob. It runs every 15 minutes with a
narrow service account that can list ready persistent-agent pods, exec the
sanitized exporter in those pods, and write one ConfigMap only after all five
expected agents return complete Gateway snapshots:

```text
core/configmap/openclaw-cron-calendar-feed
```

Backoffice mounts that ConfigMap read-only at:

```text
/var/run/openclaw-cron-calendar
```

and reads it with:

```bash
OPENCLAW_CRON_CALENDAR_EXPORT_DIR=/var/run/openclaw-cron-calendar
```

To run a one-shot collection from an operator shell:

```bash
KUBE_CONTEXT=infuseai-k8s \
SOURCE_NAMESPACE=agents-swarm \
TARGET_NAMESPACE=core \
CONFIGMAP_NAME=openclaw-cron-calendar-feed \
EXPECTED_AGENT_IDS=agent-coordinator,agent-designer,agent-developer,agent-infra,agent-intake \
task collect-openclaw-cron-calendar-feed
```

Set `DRY_RUN=true` to execute pod selection, Gateway export, fleet completeness,
and snapshot validation without applying the ConfigMap.

When an agent has no cron jobs, the Gateway returns a successful empty result
and the exporter emits `no_cron_jobs`. If any agent cannot be queried or returns
an incomplete/invalid snapshot, the collector leaves the last good ConfigMap
unchanged so Backoffice can age it to stale instead of displaying a fresh,
misleading zero-job feed.
