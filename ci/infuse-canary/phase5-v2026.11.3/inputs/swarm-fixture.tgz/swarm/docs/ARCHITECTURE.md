---
title: Architecture
description: Defines the target Kubernetes runtime, persistence, security, and
  worker boundaries for durable OpenClaw agents.
type: architecture
status: active
owner: team:agent-platform
tags:
  - architecture
---
# Architecture

## Target Shape

OpenClaw should run as a durable Kubernetes-native operating layer:

- `openclaw-agent`: shared image and runtime shape for persistent agents.
- per-agent PVCs: persistent workspace, memory, skills, repo checkouts, and durable task state.
- `browser-desktop`: optional headed Chromium/Xvfb/noVNC deployment for visual debugging.
- `build-runner`: BuildKit/rootless or controlled remote-Docker build path.
- `mac-worker`: optional Mac mini worker for macOS-only tools and real desktop checks.
- `agent-workers`: scoped implementation, QA, research, DevOps, security, docs, and operations agents.
- `backoffice`: human-facing command center for read-only agent inventory, access review, smokes, and eventually approved controls.

## Runtime Boundaries

### Main Agent Pod

The main pod should be boring and durable:

- non-root where possible;
- no host Docker socket by default;
- no broad cluster-admin role;
- PVC-mounted workspace;
- internal service discovery;
- outbound access limited by network policy where practical;
- explicit tool configuration via mounted config and secrets.

### Browser Checks

Browser tests should run inside scoped task smokes or purpose-built future
workers, not through a second maintained Kubernetes deployment path in this repo.

Default progression:

1. Playwright/headless Chromium from the agent runtime for routine smoke checks.
2. Headed Chromium under Xvfb for rendering-sensitive flows if a future worker needs it.
3. noVNC/Kasm-style visual desktop when we need human-visible debugging.
4. Mac worker for real macOS browser or native desktop behavior.

### Build Runner

Avoid privileged Docker-in-Docker as the default. Prefer:

- BuildKit rootless for image builds;
- Kaniko or equivalent when registry workflows fit;
- temporary Kubernetes namespaces for compose-like stacks;
- controlled remote Docker contexts for tests that require Docker semantics.

### Mac Worker

The Mac mini remains valuable as a specialized worker for:

- Apple Notes, Reminders, Messages.app, and Keychain-backed workflows;
- Peekaboo/native macOS UI automation;
- real desktop/browser checks when container rendering is not enough;
- local Docker workflows that are intentionally Mac-hosted.

## Agent Swarm Model

Emon Lusk / `agent-coordinator` is the default swarm coordinator and scoped
product-engineering executor. Kapiteky is the advisor/enabler/reviewer who keeps
the agent system legible, capable, and safe. Specialized agents receive:

- a compact task brief;
- relevant source docs only;
- repo/path scope;
- non-goals;
- permission level;
- verification gate;
- escalation rules.

The swarm should improve throughput without hiding responsibility. Emon owns
delegation, decomposition, role handoffs, mission stewardship, reviews, synthesis,
normal internal delivery decisions, merges, deploys, and follow-through.
Kapiteky advises when Emon or Fito asks or when a named system-level boundary
needs review; Kapiteky does not run a parallel specialist-management loop.

Live InfuseAI agents use one Deployment and PVC per persistent identity:

- Tinus Lordvals / `agent-developer`
- Stewie Hobs / `agent-designer`
- Satwa Nutella / `agent-infra`
- Emon Lusk / `agent-coordinator`

The shared image includes a common CLI toolbox, but repo checkout, GitLab credentials, and Kubernetes permissions remain separate reviewed access steps. See `docs/AGENT_WORKER_READINESS_PLAN.md`.

## Backoffice Command Center

Backoffice should present the swarm's state without becoming a secret store.

Initial Backoffice integration should be read-only:

- agent identity and role;
- Kubernetes deployment/PVC/image readiness;
- Mattermost handle and scope;
- declared skill and credential access intent;
- last smoke result;
- links to docs, PRs, and channels.

Human-triggered writes such as smokes, repo sync, task dispatch, or temporary elevation can come later through audited scripts. See `docs/BACKOFFICE_COMMAND_CENTER.md`.

## Open Decisions

- Which long-term secret-sync mechanism replaces the current Vaultwarden-to-Kubernetes helper path, if any?
- Whether Tailscale runs as an operator, sidecar, subnet router, or cluster egress path.
- How OpenClaw dynamic tools should address remote workers: native node routes, internal services, or task queue.
- Which registry/build path we standardize on for agent runner images.
- Whether Backoffice reads swarm state directly from Git/Kubernetes/Mattermost or through a small aggregation API.
