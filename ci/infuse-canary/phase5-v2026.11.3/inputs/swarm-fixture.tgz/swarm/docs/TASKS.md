---
title: Task Backlog
description: Tracks completed, current, and next delivery work for the OpenClaw
  Kubernetes swarm runtime.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - tasks
---
# Task Backlog

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Now

- [x] Keep `task verify` as the default local quality gate.
- [x] Keep the InfuseAI deployment overlay and active agent overlays rendering.
- [x] Keep the live agent smokes green for Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon.
- [x] Document the worker-readiness and Backoffice command-center plans.
- [x] Add controlled per-task repo checkout into agent PVCs.
- [x] Add local repo smoke checks for isolated assigned task checkouts.
- [x] Add Satwa Nutella read-only Kubernetes RBAC and `kubectl auth can-i` smoke.
- [x] Document bounded Vaultwarden access plan for multi-agent credentials.
- [x] Generalize Mattermost token sync into a bundle-enforced agent credential sync helper.
- [x] Prepare per-agent Azure DevOps credential policy for live repo checkout after Vaultwarden access is ready.
- [ ] Sync scoped Azure DevOps repo tokens and run live InfuseAI repo checkout smoke for Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon.

## Next

- [x] Decide initial target cluster and namespace.
- [x] Choose registry for runtime images.
- [x] Wire real OpenClaw startup command.
- [x] Define secret bootstrap strategy.
- [x] Add persistence smoke script.
- [x] Deploy first prototype pod on ncase staging.
- [x] Run in-cluster browser smoke job.
- [x] Define persistent agent identity model.
- [x] Create private coordination channel `openclaw-swarm-dev`.
- [x] Enable/create Mattermost bot identity `agent-developer`.
- [x] Add `agent-developer` Mattermost token as Kubernetes Secret.
- [x] Verify `agent-developer` outbound Mattermost send from the runtime pod.
- [x] Add scoped model/provider auth for `agent-developer`.
- [x] Enable live gateway loop for `agent-developer`.

## Later

- [ ] Add BuildKit runner.
- [ ] Add noVNC browser desktop.
- [ ] Add Tailscale private access layer.
- [ ] Add Mac mini worker integration.
- [ ] Add agent swarm worker templates.
- [ ] Add Backoffice read-only agent inventory/status page.
- [ ] Add Backoffice access review view for bundle-declared credential intent.
- [x] Add swarm-side Mission Control filesystem feed for public journals/artifacts.
- [ ] Add human-triggered Backoffice smokes after the read-only view is reviewed.
- [x] Create first Mattermost identity for `agent-developer`.
- [x] Add CI/CD pipeline.
- [x] Add `docs/REPO_MAP.md`.
- [x] Add `docs/DECISIONS.md`.
- [x] Add secret contract examples under `docs/secrets/`.
- [x] Add local/kind development overlay.
- [x] Add PVC backup/restore smoke.
- [x] Add new-agent onboarding runbook.
- [x] Draft `agent-designer` access bundle as the second-agent example.
- [x] Decide deployment topology: one Kubernetes Deployment per persistent agent.
- [x] Decide to keep the temporary Kapiteky OAuth bridge as accepted near-term debt.
- [x] Add per-agent Kubernetes Deployment template or overlay.
- [x] Add generic `scripts/bootstrap-agent-profile.sh`.
- [x] Add generic `scripts/sync-agent-mattermost-secret.sh`.
- [x] Add `docs/agents/TEMPLATE.md`.
- [x] Add persona template files for new persistent agents.
- [x] Add persona installer/generator for new persistent agents.
- [x] Add Mattermost bot onboarding helper that stores tokens in Vaultwarden.
- [x] Add `task verify-agent-profile AGENT_ID=agent-designer`.
- [x] Add skill catalog and per-agent skill bundle verification.
- [x] Add runtime skill installer for approved bundle skills.
- [ ] Add Mattermost inbound mention/allowlist smoke.
- [ ] Add `task smoke-agent-mattermost AGENT_ID=agent-designer`.
- [x] Wire runtime boot to install approved Git-backed company skills automatically.
- [x] Add InfuseAI `agents-swarm` overlay and CI/CD path with unique image tags.
- [x] Apply one-time InfuseAI `agents-swarm` namespace/RBAC bootstrap with a cluster-admin identity.
- [ ] Replace InfuseAI `openclaw-runtime` temporary local auth bridge with a Vaultwarden-backed runtime auth item.
- [ ] Replace temporary Kapiteky OAuth bridge with scoped per-agent model credentials.
- [ ] Add runtime secret cleanup workflow for temporary credential elevation.

## Decisions Needed

- [x] First prototype target: ncase MicroK8s namespace `openclaw-swarm-staging` (historical).
- [x] Registry: Harbor project `openclaw-k8s-swarm`.
- [x] Next target registry/namespace: Harbor project `agents-swarm`, Kubernetes namespace `agents-swarm`.
- [x] Secrets: Kubernetes Secrets for MVP, sourced from Vaultwarden where applicable.
- [ ] Tailscale pattern: operator, sidecar, subnet router, or egress gateway.
- [ ] Backoffice state source: direct Git/Kubernetes/Mattermost reads or a small aggregation API.
- [x] Agent task registry: record explicit task assignments in `/workspace/tasks/task-registry.json`.
