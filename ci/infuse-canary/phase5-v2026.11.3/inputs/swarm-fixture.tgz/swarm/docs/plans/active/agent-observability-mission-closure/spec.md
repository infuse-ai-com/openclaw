---
title: Agent Observability Mission Closure Specification
description: Accepted requirements for closing fleet-wide behavioral observability and the governed skill-improvement loop without rebuilding OpenClaw or Codex.
type: standard
status: active
owner: team:agent-platform
tags:
  - standard
  - observability
  - agents
  - evaluation
  - skills
---

# Agent Observability Mission Closure Specification

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Problem

The agent observability substrate and Knowledge Base retrieval telemetry are
operational, but the original mission is not complete. Agent-side tool and
workflow telemetry remains Tinus-only, wrapper failure evidence covers too few
skills, Codex-native skill activation is not an authoritative public signal,
the reviewed evaluation corpus has not been admitted to Opik, and no real
finding has completed the evidence-to-fleet improvement loop.

Shipping more telemetry infrastructure is not the goal. The system must now
produce trustworthy fleet-wide evidence and prove that the evidence can reject
a bad candidate and promote a useful human-reviewed improvement.

## Users And Scenarios

- Fito compares tool, workflow, wrapper, and knowledge behavior across all five
  agents without opening private session storage.
- A skill owner sees a stable failure cluster and its exact wrapper and skill
  revision without reading raw command output.
- An evaluator reproduces the 75-case Knowledge Base baseline in Opik and runs
  a candidate against the same immutable dataset and semantic fixture.
- An agent-platform owner distinguishes native, wrapper-owned, and explicitly
  declared skill attribution without claiming that an unobserved skill ran.
- A reviewed improvement is evaluated, canaried on Tinus, promoted through the
  fleet, and then measured against its baseline.
- A weekly report proposes evidence-backed work and says `insufficient_evidence`
  when sample thresholds are not met. It never edits or promotes a skill.

## Goals

1. Enable the proven metadata-only diagnostics and behavioral telemetry on all
   five managed agents.
2. Add structured, bounded wrapper failure evidence to the highest-value
   Knowledge Base, Azure DevOps, and runtime-operations paths.
3. Establish honest no-core skill attribution with explicit provenance and
   confidence semantics.
4. Reproduce reviewed Knowledge Base and agent-workflow baselines in Opik with
   exact revision and trace correlation.
5. Run controlled one-variable retrieval experiments against the accepted
   75-case Fixture V2 baseline.
6. Complete one human-reviewed evidence-to-improvement-to-fleet loop and
   establish a governed recurring review.

## Non-Goals

- No custom OpenClaw, Codex, ACP, app-server, or dynamic-tool bundle rebuild.
- No hidden chain-of-thought, prompt, model response, raw objective, raw
  command, stdout/stderr, token, opaque Fetch reference, or full Markdown in
  production telemetry.
- No inference that a skill was considered or used when no approved signal
  exists.
- No automatic production trace ingestion into Opik.
- No automated skill mutation, pull request, merge, deployment, or promotion.
- No new metrics, tracing, logging, or evaluation platform.
- No arbitrary 24-hour wait when a bounded sample/evidence gate can determine
  acceptance.

## Domain Language

- **Native attribution:** an official `skill.used` event emitted by the runtime.
- **Explicit wrapper attribution:** a skill-owned wrapper emits a governed
  start/outcome marker for its own operation.
- **Declared marker attribution:** a wrapperless skill explicitly records that
  it began or completed a bounded workflow.
- **Inferred attribution:** a hypothesis derived from surrounding actions. It
  may aid investigation but cannot support evaluation or promotion.
- **Wrapper failure envelope:** the existing `infuse.wrapper.execution` signal
  with bounded skill, wrapper, operation, revision, outcome, duration, retry,
  and stable error fields.
- **Mission closure loop:** evidence, classification, proposed change,
  controlled comparison, human decision, Tinus canary, fleet promotion, and
  post-promotion measurement.
- **Sample gate:** an explicit minimum set of controlled or organic events,
  not a fixed elapsed-time delay.

## Acceptance Criteria

### Fleet telemetry

- All five agent Deployments are Ready, preserve replica/state/channel health,
  and emit tool and workflow telemetry separated by stable agent identity.
- Each agent produces at least five controlled successful tool calls and two
  controlled failures with expected bounded categories.
- Collector or backend outage does not change tool or agent behavior.
- Live resource attributes contain exact image, runtime, and skill-bundle
  revisions and none of the prohibited resource or content fields.

### Wrapper and skill attribution

- Knowledge retrieval, Azure DevOps, and runtime-operations pilot wrappers
  produce stable failure classes for approved fixtures.
- Telemetry serialization or export failure does not change wrapper output,
  retries, or exit status.
- Skill events state one of `native`, `explicit_wrapper`, or
  `declared_marker`; inferred signals remain visibly separate.
- Controlled tasks prove start/outcome/revision attribution for
  `knowledge-retrieval`, `azure-devops`, `runtime-operations`, and
  `verify-this` without a custom OpenClaw/Codex build.

### Opik and experiments

- The reviewed 75-case Fixture V2 corpus is admitted only after exact preview,
  privacy review, and explicit approval, and reproduces the accepted baseline.
- A 10-20 case sanitized agent-workflow suite runs at least three trials for
  nondeterministic cases and links failures to Langfuse/Loki evidence.
- A deliberately degraded candidate is rejected by deterministic gates.
- Retrieval experiments change one variable at a time and record dataset,
  fixture, service, client, skill, evaluator, model, and candidate revisions.

### First completed loop

- One useful candidate passes its comparison, receives an explicit human
  decision, canaries on Tinus, promotes sequentially, and is measured against
  the accepted baseline.
- A manual weekly-review dry run classifies findings into retrieval defect,
  wrapper defect, skill guidance gap, missing skill, runtime defect, or
  insufficient evidence.
- Scheduling the weekly review remains a separate explicit approval after the
  manual report is accepted.

## Constraints

- Existing Grafana/Prometheus, Loki, Langfuse, Opik, OTel Collector, Agent
  Swarm, Knowledge Base, and Azure CI/CD are reused.
- Runtime changes use reviewed branches, PRs, immutable artifacts, Tinus-first
  canaries, and sequential promotion.
- Production telemetry remains metadata-only and fail-open.
- Agent-specific Kubernetes identity and existing RBAC boundaries remain
  unchanged unless a separately approved requirement proves otherwise.

## Risks And Approval Gates

- Fleet rollout and any production canary require reviewed runtime changes and
  health/rollback evidence.
- Opik dataset admission is an external production-data write and requires an
  explicit approval after preview. Acceptance of this specification is not
  dataset-admission approval.
- Deployment of a winning candidate requires an explicit promotion decision
  after comparison evidence.
- Enabling a recurring schedule requires a separately accepted manual report.
- Any step that requires OpenClaw/Codex artifact changes stops the mission and
  reports the blocker rather than crossing the no-core boundary.

## Open Questions

No question blocks Iteration 1. Initial sample thresholds in this specification
are the accepted defaults; evidence may raise them without widening content or
access. The first Opik admission, winning-candidate promotion, and recurring
schedule remain explicit runtime approval gates.

## Source Links

- [Accepted Mattermost mission-closure structure](https://mattermost.infuse-ai.com/ai-lab/pl/c9ksqs66nf8tjdji8new8xxpry)
- `../agent-behavioral-observability-and-skill-evaluation-2026-08-27.md`
- `../../../AGENT_OBSERVABILITY.md`
- `../../../../config/observability/telemetry-contract.v1.json`
- Knowledge Base `docs/specs/retrieval-observability/spec.md`
- Knowledge Base `docs/specs/retrieval-observability/telemetry-contract.md`
