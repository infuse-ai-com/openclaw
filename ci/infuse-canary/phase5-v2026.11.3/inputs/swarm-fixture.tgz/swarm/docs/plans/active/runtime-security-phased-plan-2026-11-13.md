---
title: Runtime security investigation and phased remediation
description: Records bounded live applicability evidence and six independently approvable remediation phases for the internal agent runtime.
type: plan
status: active
owner: team:agent-platform
tags: [agents, security, planning, release]
sources:
  - ref: runtime-security-remediation-2026-11-12.md
    role: baseline
---
# Runtime security — phased plan, 13 November 2026

## Authority and current state

All six authorized bounded phases are complete. The corrected P4/P5 release
passed its fresh Tinus canary, all five role checks and all six maintenance
controllers. P6 completes the nonproduction prototype/proposal only; production
worker adoption and unresolved XML/LMDB remediation remain separate follow-ups.
The [final acceptance receipt](../../evidence/2026-11-13-security-p4-p5-qualification.json)
owns exact identities, checks and remaining risks.

After reviewing the investigation, Fito directed completion of all six planned
steps on 13 November. P1–P5 source implementation, integration, qualification
and staged runtime delivery are authorized; P6 is the nonproduction prototype
and adoption proposal described below. This supersedes waiting for individual
phase approval. Existing advisory scans and identity/mail boundaries remain.

P1 protected candidate pipeline 1902 builds source
`5fddaf941554e4a0cf69a78eb92376fd1d5570f0`. It includes newer main changes to
admit Ramiro's own memory publisher and consume CI components v0.8.4; preserve
those changes. No deployment occurs in the candidate pipeline.

Fresh worktrees start at swarm main `6e7fa202c931` and company-docs main
`67d79ab3df42`. Company-docs owns the approval ledger and cross-repo priority;
this document owns implementation scope, technical evidence and acceptance.
Satwa is the accountable runtime/security owner, Tinus the implementation owner,
and Fito the phase and production-release decision owner. Codex prepared this
investigation; no task was dispatched to an agent.

At `2026-11-13T08:46:53Z`, context `infuseai-k8s`, namespace `agents-swarm`, all
five agent deployments had one ready replica and still selected
`sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4`.
All were on `n1.infuse-ai.com`. No replacement image was deployed at that initial snapshot; see delivery evidence for subsequent promotions.

## Delivery evidence

- P1 protected pipeline 1902 / build 8394 / scan 8395 published exact image
  `bfd1f406b30ae0c78c8ae58067f9988f72f86a2efe8cf65d53101afd310b5efe`.
  The [P1 receipt](../../evidence/2026-11-13-security-p1-qualification.json)
  now contains the frozen-DB comparison: 16 CRITICAL / 511 HIGH to 16 / 493,
  exactly the 18 targeted IDs removed and none added. Tinus passed native runtime,
  auth/session/dashboard, own HTTPS checkout, fresh memory retrieval and the
  deterministic collector Job. Observation began at 12:36:52 UTC but the separate Mattermost release MR !68
  superseded it before the 30-minute window completed. That incomplete window
  is not release acceptance. The selected descendant `db3cdfaa...` (source
  `5d12e3c...`, containing P1/P2) was subsequently qualified, then superseded by
  the accepted corrected Trixie release below. Its silent-reply policy remains
  preserved; the old manifests are retired.
- P2 source MR !60 and protected pipeline 1924 / build 8433 / scan 8430 produced
  `c2ad9879b2b43b187eb758aa1cf15303749db322b354226deebf3d3a2df53acf`.
  The [P2 receipt](../../evidence/2026-11-13-security-p2-qualification.json)
  confirms Ruby absence, retained native toolbox/browser functions and the same-DB
  reduction from 16 / 493 to 10 / 482 IDs, with none added. Runtime release is
  complete through the corrected descendant and combined acceptance receipt.
- P3 sandbox source MR !62 merged as `6007f6b26ba9010ee484a1e531e440239fa9674a`.
  The native and production three-path sandbox checks pass on all five roles, together with runtime/session/dashboard and own-account checkout. The browser-control canary and separate final-pin stability window each exceed 30 minutes; all five maintenance jobs pass deterministic qualification. Skills MR !12 merged as `93bbfe938470d704f33b6657c6001e312bf3a68b`; the immutable runtime catalog pin follows it, with no new credential grants.
- P4 source MR !65 merged as `25723930bec6bcac1229e613948175e7663b0996`.
  Candidate pipeline 1960 failed before publication because pip tried to uninstall
  Debian-owned `packaging` without a RECORD file. The dedicated hash-locked Python
  toolbox fix merged in MR !69 as `a63af87cefd2b0937f821ed54da22dc552246d7d`;
  protected rebuild 1973 / build 8529 succeeds with image
  `2946f21dacd33d700d0a95cbbcfa4709e13590bd229e769cf31785fd820a5154`.
  Scan 8530 is complete and advisory: 5 CRITICAL / 279 HIGH IDs. The
  [P4 receipt](../../evidence/2026-11-13-security-p4-qualification.json) records
  native toolbox, actual Python/library inventory, sandbox/headed browsers,
  isolated build/media/PDF fixtures and old/new/old synthetic-state rollback.
  The identical-DB native comparison is complete, with a full-image positive control: 223 IDs removed, 15 HIGH added. Their applicability is recorded in the residual dependency disposition. The original trial was rejected; the corrected descendant is accepted below.
- P5 MR !71 merged maintained OpenSSH 10.6p2 and Soup Sieve 4.0 after the fresh
  P4 scan confirmed those residual targets. Protected native pipeline 1983
  passed upstream SSH tests and produced exact candidate `0e04ff2ed898faec53850079152fd227d0ec9ff0cc167d1d261a09388ee39ad2`. Native retained tools, parser fixtures and sandbox paths pass. The frozen comparison removes Soup Sieve with no added IDs: 5 CRITICAL / 278 HIGH remain in the raw report, including the annotated upstream-patched SSH row. Runtime release is complete through the corrected descendant below.
  [XML/LMDB dispositions](residual-runtime-dependencies-2026-11-13.md) stay
  explicit and unresolved; no claim of zero remaining findings.
- P6 MR !67 merged as `c7980b586a8cbec8e6b00171a1d6b1f794f5a799` after its
  three isolated worker fixtures and exact-head CI passed. The
  [adoption proposal](isolated-worker-adoption-proposal-2026-11-13.md) and
  [receipt](../../evidence/2026-11-13-security-worker-prototype.json) complete
  the authorized prototype scope. Production routing/access remain separate.

At the start of delivery, memory freshness used immutable component
`agent-memory-mirror-f39a0b2c9438`. P3 advanced the catalog-only pin to
`agent-memory-mirror-59a12e77baa5`, retained by the final fleet; all six memory
helper contents are byte-identical (see P3 receipt). Every rollout was recaptured
from current live state and checked for drift. Ramiro mail remains paused. Soup Sieve
CVE-2026-126190 was newly reported on the baseline too, not introduced by P1/P2.

## Trixie login-shell regression and corrected release

The P4 Tinus trial exposed a real command-routing gap: `bash -lc` resets PATH,
so `python3` selected Debian Python and could not import the declared `lxml`
toolbox. Direct interpreter/browser checks passed, but that narrower coverage
was insufficient. The `python` alias also selected system Python. Both original
P4/P5 candidates are withheld from release; their package/native evidence is
retained with this limit. Tinus was restored to the qualified P3 image, preserving
PVCs, memory, credentials, sandbox configuration and skill pin. Runtime, sessions,
three browser paths, dashboard, own-account checkout and the originally failing
login-shell import all pass after rollback.

The [repair receipt](../../evidence/2026-11-13-security-python-entrypoints.json)
records a native negative control and 20 passing command/shell combinations.
Explicit launchers bind `python`, `python3`, `pip` and `pip3` to the isolated
toolbox without modifying `/usr/bin/python3` or apt-owned modules. The image
checks direct, ordinary and login shells as root and UID 10001; the native
runtime toolbox smoke repeats the same regression check.

Current main already contains the reviewed P5 SSH/Soup Sieve repairs. The
corrected protected rebuild retains those changes. P4 base compatibility and P5
consumer/provenance checks remain separate acceptance checklists, while one
corrected exact image may satisfy both through a full native qualification,
frozen scan comparison, Tinus observation and sequential fleet release. This
avoids reverting reviewed fixes solely to reconstruct an older candidate. No
new access, worker routing or host change is introduced. The prior active release selection remained P3 while the corrected image qualified.

Protected pipeline 2003 / build 8581 now produces corrected image
`sha256:74ca6120a569721fab46008c17444c87b37d45ff4eb2e9fda13034674173d424`
from `83fc6c6d339e2a8a8143bde83de444f440f34c22`. The
[combined qualification receipt](../../evidence/2026-11-13-security-p4-p5-qualification.json)
records all 20 native Python/pip command paths, retained toolbox/DNS, parser and
SSH provenance, all three headless and headed sandbox paths, isolated worker
fixtures and synthetic old/new/old rollback. Every check passes. The identical-DB
comparison matches the original P5 tuples exactly: 5 CRITICAL / 278 HIGH IDs,
zero scanner-reported fixable entries. The current-image positive control also
matches all 794 HIGH/CRITICAL occurrences exactly. MR !76 selected the corrected
image. Tinus completed a fresh 30.72-minute same-pod observation without
restarts, followed by sequential qualification of all four remaining roles.
All five agent containers and TLS sidecars, plus six maintenance controllers,
now use that digest. Every role passes runtime, all 20 Python/pip paths, auth,
three sandboxed browsers, dashboard mTLS and own-account checkout. Existing
maintenance workflows pass deterministic qualification; the inactive shadow
controller passes transport only and remains 0/3 natural nights. Final readback
preserves PVCs, secret references, service accounts and schedules. P4/P5 are
accepted within their bounded scope; original failed candidates remain rejected
historical evidence. Ramiro mail and heartbeat stay paused. Scans stay advisory.

## What the additional investigation establishes

The [current descendant receipt](../../evidence/2026-11-13-security-current-release-qualification.json)
records the selected Mattermost-compatible image's native and Tinus functional
checks. Its 30.73-minute observation completed at 13:40 UTC without pod replacement or
restarts and with all four short-cadence collectors successful. P3 release selection kept
that exact image and separately identified sandbox configuration source
`6007f6b26ba9010ee484a1e531e440239fa9674a`; native sandbox/headed paths pass.
The [P3 receipt](../../evidence/2026-11-13-security-p3-qualification.json) records completed browser-control and final-pin windows, all five role checks and five maintenance jobs. Both agent/TLS containers and both skill manifests converge. Two scheduled scheduler-collector runs failed during other-role restart windows; exact stderr is unavailable. Its fail-closed readiness rule is a plausible cause, and both the deterministic post-rollout run and next regular cycle passed. Retain those failed-run receipts. The inactive memory-shadow controller converged with the corrected P4/P5 release; natural memory-quality qualification stays 0/3. The first Trixie trial was subsequently rejected for the login-shell regression above; P3 was restored until the corrected rebuild qualified and its subsequent release was accepted. Fresh manifests preserve the current memory
component, identity references and silent-reply policy; stale P1 manifests are
explicitly retired. The weekly assurance memory schedule is corrected to the
already-declared/live `30 3 * * *`; this does not reschedule the job.

The [sanitized evidence](../../evidence/2026-11-13-runtime-security-investigation.json)
contains allowlisted deployment security fields, package metadata, library
versions, installed-skill reference counts and the historical scan's per-ID
severity provenance. Reads used bounded Kubernetes get/exec calls and Python
with bytecode writing disabled. No browser was launched, exploit attempted,
credential read, or private session/history inspected.

| Observation | Consequence and limit |
| --- | --- |
| Historical candidate scan hash `3e8b131a649a21309c6647a553f399ca794244e6aaa943c4b61563a4c2a37361` matches the retained qualification report: 16 CRITICAL IDs, 34 occurrences | This is the 12 November scan, not a fresh 13 November image scan. Eleven IDs explicitly select NVD severity; five omit `SeveritySource`, although vendor CVSS entries exist. Do not invent a chosen source or silently downgrade severity. |
| Six Ruby IDs account for 24 of the 34 occurrences across interpreter/library/dev/docs packages | Removing the complete Ruby dependency chain could remove six distinct IDs. Duplicate package rows are not separate exploit paths. A new image scan must prove the result. |
| No Ruby/Bundler/Gemfile keyword usage found across 551 installed skill Markdown files; no Ruby process in the five snapshots | Supports a removal pilot, not a claim of zero historical or future Ruby use. No shell/session history was inspected. Counts by agent: Emon 147, Stewie 84, Tinus 133, Satwa 91, Ramiro 96. |
| Tinus and Emon have `browser.noSandbox=true`; the other three omit that override and select the existing Chromium seccomp profile | No active browser was observed. A configured profile is not proof that a renderer successfully runs sandboxed. Native OpenClaw, Python Playwright and Node Playwright are separate launch paths. |
| All five agent containers are nonroot, drop all capabilities and forbid privilege escalation | Retain these controls. No SYS_ADMIN, privileged container, unconfined seccomp or host-level relaxation is an accepted workaround. |
| Fifteen policies selecting the five agent workloads are ingress-only; the other three namespace policies select different workloads | No matching Kubernetes NetworkPolicy egress restriction was found. Cluster-wide CNI/firewall controls were not inspected. Do not infer unrestricted Internet reachability from this alone. |
| Tinus's Python sqlite3 uses system SQLite 3.40.1; Node 24.21.0 reports SQLite 3.53.4 | The Debian SQLite finding applies to the system package. Do not automatically attribute it to Node's embedded SQLite. Python consumers still need review. |
| Tinus's lxml reports compiled/runtime libxml 2.14.6 and no dynamic system-libxml linkage; system libxml2 remains 2.9.14 | The flagged Debian library and Python lxml are distinct copies. System consumers include ImageMagick, BIND libraries, LLVM and shared MIME tooling. This is not an all-consumer non-applicability claim. |
| zlib1g is 1:1.2.13.dfsg-1; separate libminizip1 is 1.1-8+deb12u1; pyminizip is not importable in the sampled interpreter | Strong narrow non-applicability evidence for CVE-2023-45853 on this zlib package, consistent with Debian. Other vendored copies were not exhaustively searched. Preserve the raw finding and annotate the exact package/image. |
| Container-visible kernel is 6.8.0-149-generic; ksmbd absent from both /proc/modules and /sys/module/ksmbd | The scan's linux-libc-dev 6.1.190-1 describes headers, not this running kernel. The snapshot does not prove the host is patched, that ksmbd cannot load, or that it was never used. Route any host assessment to infrastructure; do not patch/reboot nodes here. |

Installed dependency relationships confirm `libaom3 <- libheif1 <- ImageMagick`,
`liblmdb0 <- bind9-libs`, `linux-libc-dev <- libc6-dev`, and system SQLite used
by Python's standard library and NSS. Blind library deletion would break
declared capabilities. Ruby, compilers, SSH, DNS commands, Chromium and image
composition are explicitly checked by `scripts/smoke-agent-toolbox.sh`; remove
a capability only with a deliberate contract change and replacement/deferral.

## Approval and release contract

- Fito's subsequent completion instruction authorizes all six bounded phases.
  Keep commits, qualification and rollout sequentially reviewable; do not bundle
  unrelated runtime changes or broaden access to resolve a local failure.
- Record concrete MR, image/config identity, evidence and rollback before merge
  and production release. No repeat phase approval is needed within that scope.
  P6 production adoption and out-of-scope access/cost/host changes remain separate.
- Every production change uses an exact image/config decision, Tinus canary,
  then separately observed fleet progression. No floating-tag promotion.
- Scans continue warning-only. Raw and annotated results remain separate;
  scanner errors/missing reports are unknown evidence, not a clean scan. None
  of these phases restores the retired vulnerability-exception CI gate.
- Preserve sessions, memory PVCs, own-agent identities, and Ramiro's paused
  mail. No new memory backup/export or credential/access change is implied.
- For a canary, observe at least 30 minutes plus the relevant short-cadence
  collector cycle and a bounded operator functional check. Daily/weekly jobs
  require their next natural-run receipt or an explicitly approved deterministic
  qualification. A short canary never claims weekly-job coverage.
- Pause progression on functional/data/auth regressions and restore the exact
  prior approved image/config. Do not restore PVCs or replay migrations as a
  routine image rollback. If rollback requires a state migration, obtain a
  separately reviewed recovery procedure before release.

## Phase matrix

| Phase | Bounded outcome | Benefit | Change risk | Dependency |
| --- | --- | --- | --- | --- |
| P1 | Qualify and release already-merged dependency repairs | Removes the 18 targeted fixable HIGH IDs from the running fleet if candidate evidence reproduces | Medium: runtime/auth/browser compatibility | Reviewed source; accepted through corrected descendant |
| P2 | Remove Ruby from the persistent image | Targets six CRITICAL IDs / 24 occurrences in the recorded baseline | Low–medium: undeclared Ruby tasks may exist | Prefer P1 stable; may prepare independently |
| P3 | Qualify and enforce browser sandboxing | Reduces consequences of hostile web content; no CVE-count promise | Medium: launch/profile/session compatibility | P1 image, existing node profile, all three browser launch paths |
| P4 | Qualify a supported newer Debian base | Targets AV1, GLib and system SQLite findings, plus broader distro maintenance | Medium–high: Python/ABI/browser/package changes | Rebase on whichever of P2/P3 were approved; neither is mandatory |
| P5 | Prepare targeted fixes for residual SSH/XML/DNS dependencies | Addresses issues that survive P4; preserves required tooling | Medium–high: dependency ownership and protocol compatibility | Fresh P4 evidence, or a deliberate decision to retain Bookworm |
| P6 | Prototype isolated browser/build/media workers | Separates untrusted processing from persistent credentials and memory | High: new execution, session and network contracts | Independent design; production adoption requires its own concrete approval |

### P1 — release the existing fixes

Scope: build through the protected candidate pipeline from the reviewed merged
source, verify registry digest/source identity, and qualify on native AMD64.
Use the same fresh scanner DB for baseline/candidate comparison; retain full
reports and the targeted Node/Go finding comparison. The previous Mac/QEMU
browser failures remain unqualified, even though both images failed identically.

Acceptance: canonical source checks; actual installed dependency guard; all
eight CLI checks; native OpenClaw/browser/plugin flows; own-account GitLab;
cached Bitwarden session/sync without rotation; dashboard session access and
memory collector. Complete exact-image release review, Tinus observation, then
one agent at a time. No package removal, base migration or sandbox redesign.

Rollback: previous approved image and rendered config; no memory/state reset.
Stop if exclusive runtime migrations make image-only rollback unsafe. Benefit
is measured against the retained 18-ID target list, not an arbitrary total-CVE gate.

### P2 — remove Ruby with an honest capability contract

Scope: remove `ruby-full`, bundled gems/Bundler and remaining installed Ruby
runtime/dev/docs dependencies from the image build. Update toolbox smoke and
capability guidance so agents do not advertise local Ruby. Preserve compilers,
DNS, media tools and browsers in this phase. Do not install a worker implicitly.

Before source removal, check declared project/job manifests available to this
workstream for Ruby requirements; historical interactive use is still unknown.
If required, return a choice to retain a patched Ruby build or defer removal
until a worker exists. A future Ruby request should report the missing capability
and request the appropriate environment; never silently install it into the PVC.

Acceptance: clean package/dependency inventory, no Ruby executables/gems in the
candidate, complete existing non-Ruby toolbox tests, fresh same-DB scan showing
the expected six IDs absent, and native representative agent tasks. Check both
image and startup logic so Ruby is not reintroduced at boot. No promise that
removing dev/docs packages alone removes interpreter vulnerabilities.

Rollback: prior image/capability declaration. No application-data conversion.
Security benefit is removal of unused code; package counts are secondary.

### P3 — make sandbox use demonstrable

Scope: prepare explicit sandbox settings for native OpenClaw, Python Playwright
and Node Playwright; extend the existing reviewed seccomp profile to Tinus/Emon
only after native qualification. Node/Python Playwright defaults disable the
Chromium sandbox, independently of OpenClaw's `noSandbox` setting.

Acceptance: native renderer sandbox status and effective launch arguments for
all three paths; nonroot/drop-ALL/no-escalation retained; data-URL/local-fixture
screenshots, downloads, headed debugging where supported, and existing
authenticated session flow with no cookie/token logging. Verify no automatic
`--no-sandbox` fallback on failure. Recheck each role, not only Tinus.

Rollback: exact prior per-role config/image. If the existing profile cannot
support the launch, return with evidence; no privileged or unconfined fallback.
This is defense in depth inside the existing pod, not a credential/PVC isolation
boundary. The worker boundary belongs to P6; reducing child-process environment
does not prevent a compromised same-UID process from reading mounted state.

### P4 — newer-base candidate, with compatibility evidence

Scope: test a digest-pinned Node 24 image on supported Debian Trixie with its
security updates, preserving approved tool/runtime versions and P2/P3 choices.
Resolve the actual available base digest at implementation time. Do not mix
Bookworm/Trixie/unstable apt repositories or change the host OS.

Debian currently records Trixie fixes for AV1, GLib and SQLite; SSH, XML and LMDB
remain affected there. These are expected targets, not promised final counts.
Ruby is an additional target only if P2 was declined; never double-count it.

Acceptance: complete native image build; Python lock/wheel compatibility and
actual linked library inventory; browser/sandbox, DNS/SSH and PNG/JPEG/PDF/contact
sheet tests; OpenClaw/plugin/auth/memory checks; full scan with identical-DB
baseline comparison; startup and image-only rollback rehearsal against synthetic
state. Do not migrate production databases simply to qualify the new base.

Rollback: the preceding approved base/image. If a Python/native extension cannot
be qualified, report that consumer and defer the migration rather than force
unreviewed package substitutions.

### P5 — residual packages, one reviewed change at a time

Scope: after refreshing the chosen base's findings, prepare separate candidate
changes for (a) SSH client, (b) system XML consumers, and (c) DNS/LMDB dependency
chain. Prefer maintained distribution packages/backports; a private patched
build must have an owner, source/checksum, build receipt and update obligation.

Acceptance: SSH client interoperability and host-key verification with an
isolated test server; XML consumer tests including safe parser configuration;
DNS functionality with the retained or replacement tool. Use benign fixtures
and upstream regression tests in isolated test environments, never malicious
inputs against production. Keep the existing HTTP(S) Git path operational.

Return the concrete patch/replacement-versus-containment choice for each
dependency before release. If no maintainable fix exists, propose documented
containment and review date; do not silently suppress or delete the library.
The currently newer Python lxml and Node SQLite do not justify suppressing
different system-package findings. Rollback each dependency change separately.

### P6 — isolated worker prototype and adoption proposal

First deliver a nonproduction design/prototype with explicit resource cost,
identity/session model and rendered manifests. Split build/media workers from
an untrusted browsing worker. Browser protocol/version compatibility, native
browser panel integration, bounded artifact transfer and task attribution are
part of the design. An extra container sharing the existing credential mounts
and unrestricted pod network is not sufficient isolation.

Target properties: nonroot, bounded lifetime/resources, sandboxed browser,
no persistent-agent PVC or general credential environment, no Kubernetes API
token by default, authenticated private control channel, and a reviewed egress
policy. Prevent access to metadata/control-plane/internal services except
explicitly approved destinations. Authenticated browsing must receive only
task-specific session material, with lifetime and deletion rules. Test the
boundary with synthetic canary secrets/files, not real credentials.

Approval of the prototype does not approve production RBAC, NetworkPolicy,
secret delivery, resource spend or new persistent workloads. Return those exact
changes and budgets as P6's production-adoption decision. Only then move compiler,
Ruby/media or browser packages out of persistent images; preserve task routing
and capability discovery. Roll back routing to the last approved runtime while
recording the exposure that returns. Do not automatically re-enable an unsafe
fallback after a worker failure.

## Findings accounting and deferred host scope

Keep raw findings, package-specific applicability notes, and actual remediation
separate. The proposed report should show severity source, package/version,
runtime consumer, precondition, evidence date, owner, phase and disposition.
Do not claim 16 demonstrated exploit paths or subtract annotations from raw totals.
MiniZip may receive an exact-package reviewed annotation; no blanket ignore rule
or VEX change has been applied. Re-evaluate it after any image/package change.

An infrastructure-owned kernel/ksmbd assessment remains a separate read-only
follow-up on the actual host distribution, patch provenance and service exposure.
No host access escalation, kernel patch, module change or node reboot is part
of these container phases. The container-visible observations only narrow the question.

## Operational follow-up: collectors during controlled restarts

Retain the failed scheduled runs and their later recovery in the combined
receipt. Failed pod logs were already absent for the token-collector restart
overlap, so its exact cause is unknown. A subsequent scheduler log was captured
live: it refused to publish because `agent-infra` had no ready pod during its
controlled restart. Satwa should own a bounded follow-up for
restart tolerance and failure-log retention while preserving complete, fresh
fleet snapshots and the last valid feed.

Source review also finds that the token collector selects Running pods and
checks for a nonempty set, then rejects failed/invalid selected snapshots. It
does not validate the expected five-agent membership before replacing the feed.
The scheduler collector already supports an expected-agent set and ready-pod
selection. A future token-collector repair should add explicit membership and
readiness checks plus bounded retries; silently publishing a reduced fleet is
not an acceptable recovery strategy. This existing source behavior is a
separate reliability follow-up, not a measured regression of the new image.

## Sources and freshness

Advisories checked on 13 November 2026; recheck before building each phase:

- [Ruby regexp prerequisites and fixes](https://www.ruby-lang.org/en/news/2026/10/23/regexp-fixes-for-gitlab-cves/).
- [Debian MiniZip packaging](https://security-tracker.debian.org/tracker/CVE-2023-45853) and [kernel ksmbd record](https://security-tracker.debian.org/tracker/CVE-2026-99083).
- [SQLite](https://security-tracker.debian.org/tracker/CVE-2025-7458), [AV1](https://security-tracker.debian.org/tracker/CVE-2023-6879), [GLib](https://security-tracker.debian.org/tracker/CVE-2026-58016), [XML](https://security-tracker.debian.org/tracker/CVE-2026-6653), [SSH](https://security-tracker.debian.org/tracker/CVE-2026-60002), and [LMDB](https://security-tracker.debian.org/tracker/CVE-2019-16225).
- Playwright [Node sandbox default](https://playwright.dev/docs/api/class-browsertype#browser-type-launch-option-chromium-sandbox), [Python sandbox default](https://playwright.dev/python/docs/api/class-browsertype#browser-type-launch-option-chromium-sandbox), and [container isolation guidance](https://playwright.dev/docs/docker).

The initial read-only investigation changed no production settings. Subsequent
authorized delivery is recorded above; schedules, credential grants, PVCs and
the advisory scan policy remain preserved.
