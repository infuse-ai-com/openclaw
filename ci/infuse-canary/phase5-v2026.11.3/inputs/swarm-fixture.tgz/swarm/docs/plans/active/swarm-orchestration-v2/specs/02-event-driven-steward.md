---
title: Spec 2 - Event-Driven Steward
description: Authenticated mission events, idempotent intake, coalesced Emon wakeups, leases, adapters, and reconciliation.
type: architecture
status: active
owner: team:agent-platform
tags: [agents, orchestration, events, steward]
---
# Spec 2 - Event-Driven Steward

## Outcome

Material mission events wake Emon once and quickly. Periodic coordination runs
become a silent recovery mechanism instead of the normal execution loop.

## Event Sources

V1 adapters support:

- specialist handoff acknowledgement, decline, blocker, delivery, and review
  result;
- human gate decision or bounded Backoffice operator intent;
- known pull-request, policy-build, deployment, and smoke state changes;
- task acknowledgement lease expiry; and
- explicit coordinator-created mission or next-action change.

Broad repository scans, ambient backlog changes, ordinary chat, artifact
publication, and unchanged status are not mission events.

## Event Intake Contract

The intake accepts only `infuse.mission-event/v1` envelopes. It validates:

- authenticated producer identity;
- producer authorization for event kind and referenced mission/task;
- mission and task existence;
- allowlisted event-specific data schema;
- timestamp bounds;
- stable event id and idempotency key;
- payload size and string limits; and
- absence of credentials, raw content, paths, commands, logs, and unbounded
  identifiers.

Accepted events are durably written before success is returned. A duplicate
returns the original accepted outcome without writing or waking again.

## Event Kinds

Initial allowlist:

- `mission_created`
- `next_action_changed`
- `task_assigned`
- `task_acknowledged`
- `task_declined`
- `task_waiting`
- `task_blocked`
- `task_delivered`
- `task_reviewed`
- `gate_decided`
- `pull_request_changed`
- `build_changed`
- `deployment_changed`
- `smoke_changed`
- `ack_lease_expired`
- `operator_intent_created`

External state-change events record a durable pointer and bounded outcome; they
do not instruct Emon to merge, deploy, or accept incomplete verification.

## Wake Coalescing

- The first newly accepted actionable event opens a short coalescing window.
- Further events in that window are durably queued without additional wakeups.
- One wake lease prevents concurrent steward runs.
- The wake targets Emon's verified existing Mattermost mission-thread session.
- If the exact session is absent or does not acknowledge within one minute, a
  separately credentialed Mission Watcher posts one idempotent wake-only reply
  in the registered thread.
- A failed wake keeps events pending and increments bounded operational state.
- A successful steward run acknowledges only processed event ids.
- New events arriving during execution schedule one subsequent wake.

## Steward Behavior

The steward reads only canonical registry state and accepted pending events. It
validates current revisions, applies legal state transitions, takes the smallest
useful coordination action, exports the snapshot, and acknowledges processed
events. It remains silent when events produce no material action after
deduplication or current-state reconciliation.

## Reconciliation

The one-minute script-only reconciler checks:

- pending events left by failed wakeups;
- acknowledgement leases that newly expired;
- registry/snapshot revision mismatch;
- invalid or stale event-inbox state; and
- a steward run lease that exceeded its bound.

It performs no model call when no lease is due, does not ask agents for routine
updates, and does not post unchanged summaries. Registry route mismatch fails
closed and never falls back to Emon's main session.

## Source Adapters

Adapters translate source-specific state into the common envelope. They may not
change canonical mission state directly. Each adapter has its own producer
identity, event-kind allowlist, retry policy, and disable switch.

The first safe implementation order is:

1. local deterministic publisher and fake wake adapter;
2. specialist/Emon client path;
3. one Azure PR/build event adapter;
4. Backoffice operator-intent adapter;
5. deployment/smoke adapter.

The source paths now exist without activation. `agent-skills` owns bounded role
adapters for coordinator, specialist, reviewer, and human-gate state plus a
delivery adapter for Azure PR/build and runtime deployment/smoke state;
Backoffice owns its disabled operator-intent producer. Every source validates
against the common event client, derives deterministic idempotency, discards
raw upstream failures, fails open to its source system, and uses an independent
exact enable flag. No endpoint, producer credential, listener, or production
invocation is supplied by these source changes.

## Acceptance Criteria

- One event produces one durable inbox record and one steward wake.
- One hundred duplicate deliveries produce no additional registry mutation or
  wake.
- A burst of independent events produces one coalesced wake and no lost event.
- Two steward processes cannot hold the wake lease simultaneously.
- An event for an unknown mission/task or unauthorized producer fails closed.
- A failed wake is recovered by reconciliation without a duplicate chat post.
- An unchanged reconciliation run emits no Mattermost message and no model
  wake unless maintenance requires one actionable recovery.
- Adapter disablement is independent and preserves already accepted events.

## Security And Approval

Source code, local tests, and disabled manifests are in scope. Production
producer credentials, Kubernetes Secrets, NetworkPolicy, ServiceAccount, RBAC,
and activation require exact review and approval.

## Owning Repositories

- Event contract/client: `agent-skills`.
- Intake/wake runtime and manifests: `openclaw-k8s-swarm`.
- Azure adapter may use the existing approved integration repository after
  exact ownership review.
- Operator-intent producer: `backoffice`.

## Rollback

Disable event-triggered wakeups and leave reconciliation active. Accepted
events remain queued. No event source is allowed to require the intake for its
own success path.
