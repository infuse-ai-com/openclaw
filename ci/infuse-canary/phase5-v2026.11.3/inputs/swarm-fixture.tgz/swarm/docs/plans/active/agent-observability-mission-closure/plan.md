---
title: Agent Observability Mission Closure Implementation Plan
description: Six gated iterations for fleet telemetry, wrapper and skill attribution, Opik evaluation, retrieval experiments, and one complete governed improvement loop.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - observability
  - agents
  - evaluation
  - skills
---

# Agent Observability Mission Closure Implementation Plan

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Scope

Deliver six independently reviewable iterations across
`openclaw-k8s-swarm`, `agent-skills`, `grafana`, and `knowledge-base`. The
program reuses the current OpenClaw runtime and deployed observability stack.
It stops before any custom OpenClaw/Codex artifact change.

## Current State

- Tinus alone enables `@openclaw/diagnostics-otel` and the standalone
  behavioral-observability plugin.
- All five agents already run the same image and use distinct Knowledge Base
  ServiceAccounts.
- Tool metrics and bounded workflow, knowledge, and wrapper spans are proven on
  Tinus. Native Codex skill invocation has no reliable public signal.
- Knowledge Base metrics, Loki audit events, metadata-only Langfuse traces,
  per-agent Discover-to-Fetch correlation, candidate provenance, and fetched
  document provenance are live across the fleet.
- A private deterministic Fixture V2 baseline exists for 75 reviewed cases.
  Lexical Recall@5/MRR is 0.84/0.8173; hybrid is 0.80/0.7498; discovery improves
  from 0.60 to 0.68 while typo Recall@5 falls from 0.8667 to 0.5333.
- The Opik-compatible admission, baseline, comparison, and human-routing tools
  exist, but no live Opik dataset has been admitted.

## Proposed Approach

### Iteration 1: Fleet behavioral rollout

Enable the existing diagnostics and behavioral plugins sequentially on Satwa,
Stewie, Emon, and Ramiro after reconfirming Tinus. Reuse the exact image and
collector configuration. Add or correct only per-agent resource attributes and
dashboard coverage needed for separable evidence.

Promotion order is `agent-developer`, `agent-infra`, `agent-designer`,
`agent-coordinator`, `agent-intake`. Stop at the first readiness, channel,
plugin, privacy, or exporter regression. A controlled smoke supplies five
successes and two stable failures per agent. Tinus alone receives the
collector-outage fail-open drill.

### Iteration 2: Wrapper failure coverage

Keep `infuse.wrapper.execution` as the single failure envelope. Extend the
pilot to the Knowledge Base client, Azure DevOps helper/wrapper, and runtime
status/rollout helpers. Wrappers expose stable machine-readable error codes;
skill instructions record the marker after a failed invocation. Do not add raw
output transport or a second telemetry client to each script.

Use fixtures for authentication unavailable, authorization denied, timeout,
dependency unavailable, invalid input, parse failure, non-zero exit, and
unknown failure. Compare functional output with telemetry enabled, disabled,
malformed, and unavailable.

### Iteration 3: Explicit no-core skill attribution

Add `infuse.skill.execution` to the governed contract with:

- `attribution_method=native` for official runtime events;
- `attribution_method=explicit_wrapper` for skill-owned wrappers; and
- `attribution_method=declared_marker` for wrapperless workflows.

Inferred attribution is not emitted as equivalent evidence and cannot support
promotion. Extend the standalone behavioral plugin with bounded
`skill_execution` marker input and exact enum validation. Pilot
`knowledge-retrieval`, `azure-devops`, `runtime-operations`, and `verify-this`.

### Iteration 4: Opik evaluation foundation

Use two suites:

1. Admit the reviewed 75-case Fixture V2 dataset using the Knowledge Base's
   preview-first, exact-confirmed adapter after a separate approval. Reproduce
   the accepted baseline and store immutable revisions.
2. Add a thin offline runner under
   `openclaw-k8s-swarm/tools/agent-evals` with 10-20 sanitized agent workflow
   cases. It invokes the supported Gateway API in an isolated/read-only
   environment, propagates W3C trace context when supported, records three
   trials for nondeterministic cases, and separates deterministic from
   model-assisted graders.

The runner records task success, skill attribution, workflow adherence, tool
efficiency, expected Knowledge Base use, recovery, verification, safety, and
output quality. It cannot send external messages or mutate production state.

### Iteration 5: Controlled retrieval experiments

Status: **deferred by Fito on 2026-08-29**. The implementation-ready contract
is frozen in `iteration-5-deferred-spec.md`. Reactivation and candidate
promotion remain separate human approval gates.

Freeze the accepted baseline and test one variable at a time:

1. semantic gating for typo and exact-query categories;
2. stronger lexical precedence;
3. RRF/fusion weighting; and
4. query or embedding-input formatting.

Each candidate has its own immutable config/revision and Opik comparison. A
candidate is eligible for human review only with zero critical misses, no
privacy/provenance failure, Recall@5 at least 0.84, MRR at least 0.8173,
discovery Recall@5 at least 0.68, typo Recall@5 at least 0.8667, and p95 below
1.5 seconds. If none passes, promote nothing.

### Iteration 6: Complete the first loop and recurring review

Route the winning finding to its owning repository. For a Knowledge Base
candidate, use an internal canary Deployment/Service and point only Tinus at
it; for a skill/wrapper candidate, use a Tinus-only skill-bundle revision.
After smoke and comparison evidence, promote sequentially and remeasure.

Produce one manual metadata-only review from Prometheus, Loki, Langfuse, and
Opik. It groups failures and slow/looping workflows by bounded revisions and
classifies findings as retrieval defect, wrapper defect, skill guidance gap,
missing skill, runtime defect, or insufficient evidence. Only after human
acceptance may the same report be scheduled weekly. It never mutates source or
opens/promotes work automatically.

## Alternatives Considered

- **Rebuild OpenClaw/Codex for native skill events:** rejected by accepted
  scope. Explicit attribution is honest, reversible, and sufficient for the
  improvement loop.
- **Infer skill usage from nearby tool calls:** rejected as promotion evidence
  because the relationship is ambiguous.
- **Instrument every wrapper immediately:** rejected in favor of a three-path
  pilot with stable taxonomy and measured value.
- **Create another observability/evaluation platform:** rejected because the
  current stack owns each required plane.
- **Automatically harvest production traces into Opik:** rejected because
  dataset admission is a privacy and relevance review boundary.
- **Use fixed burn-in time:** rejected in favor of explicit sample, health, and
  failure gates.

## Data, API, Auth, And Deployment Impact

- Iteration 1 changes agent runtime configuration, not the OpenClaw/Codex
  artifact, ServiceAccounts, RBAC, Secrets, PVCs, or Knowledge Base contract.
- Iterations 2-3 add bounded telemetry schemas, skill guidance, wrapper error
  codes, dashboard queries, and standalone plugin marker behavior.
- Iteration 4 writes only reviewed versioned evaluation data after approval.
  The agent runner remains outside the production serving path.
- Iteration 5 changes no production runtime until a winner receives a separate
  promotion decision.
- Iteration 6 may add a temporary internal Knowledge Base canary or a Tinus-only
  skill bundle. Existing authentication and NetworkPolicy boundaries remain.

## Verification Gates

1. Repository-native tests, schema fixtures, leak scans, and deterministic
   dashboard/query validation.
2. Cross-repository alignment for signal names, skill/wrapper revisions,
   runtime flags, and dashboard labels.
3. Protected Azure PR builds and exact immutable artifact evidence.
4. Tinus-first canary and per-agent sequential runtime health.
5. Collector/backend outage fail-open proof.
6. Opik dataset preview/privacy proof before admission.
7. Deterministic baseline and degraded-candidate rejection.
8. Winning-candidate canary, fleet promotion, and post-promotion comparison.

## Rollback Or Disable Path

- Disable diagnostics/behavioral flags or revert one agent Deployment.
- Disable marker calls without changing wrapper functional behavior.
- Archive/supersede an Opik dataset or disable the offline runner.
- Discard candidates that fail comparison; they never enter production.
- Remove the temporary canary route after promotion or rollback through its
  reviewed manifest. No authoritative Knowledge Base data is deleted.
- Pause the recurring review independently; no mutation path exists.

## Decisions

- `openclaw-k8s-swarm` owns the program contract, fleet runtime, standalone
  plugin, agent evaluation runner, and recurring review implementation.
- `agent-skills` owns wrapper error taxonomies and explicit skill marker
  instructions.
- `knowledge-base` owns the reviewed retrieval corpus, Opik admission adapter,
  retrieval candidates, comparisons, and winning retrieval behavior.
- `grafana` owns dashboards, PromQL/LogQL, and alerts.
- Native skill activation remains a documented limitation. No custom
  OpenClaw/Codex rebuild is authorized.

## Known Gaps

- W3C trace propagation through the supported Gateway must be proven before it
  becomes an agent-evaluation acceptance fact. A bounded correlation fallback
  may be proposed but cannot be invented during implementation.
- A low-traffic week may yield `insufficient_evidence`; the report must not
  rank agents or skills below minimum samples.
- The first winning retrieval candidate is unknown until Iteration 5. No
  production canary design should assume a winner before comparison.
