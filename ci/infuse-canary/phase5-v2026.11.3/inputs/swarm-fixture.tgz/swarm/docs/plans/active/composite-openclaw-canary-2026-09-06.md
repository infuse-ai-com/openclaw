---
title: Composite OpenClaw Mattermost and wake-ticket canary
description: Pins the v2026.9.4 fork-only composite runtime while preserving the upstream Mattermost PR and rolling out sequentially.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - openclaw
  - mattermost
  - mission-continuation
  - canary
---

# Composite OpenClaw Mattermost and Wake-Ticket Canary

## Goal

Deploy one immutable OpenClaw v2026.9.4 runtime containing both the Mattermost
separate-final contribution and the Infuse mission wake-ticket patch. Keep the
two contribution histories independent while proving their combined runtime in
the private swarm, first on Tinus and then on Emon.

## Branch topology

- Signed upstream base `v2026.9.4` is
  `3a9d69db306cd7f081e06254cb89c4bcc14a7107`.
- Upstream PR `openclaw/openclaw#120854` is outside this rollout. It must not be
  changed, rebased, pushed, or otherwise modified without Fito's separate
  approval.
- Local feature lanes retain independent commits: Mattermost at `3890caa2fd`
  and mission wake tickets at `ac09aa1a52`.
- Disposable fork branch
  `aolea/openclaw:canary/infuse-mattermost-wake-20260917` combines both lanes at
  `3224797e085a86d76e3ce0d0b2c90f8f8559d11f`.
- The swarm consumes only immutable release artifacts and checksums from the
  composite commit. It does not merge the two contribution branches.

## Immutable artifacts

- Release tag: `canary-infuse-mattermost-wake-3224797e-r2`
- OpenClaw core: `openclaw-2026.9.4-3224797e-r2.tgz`
- Core SHA-256: `400e05ddc15c76463282ea9026e0e343b5c9c52ff7abe87010850a011520a7b0`
- Packaging note: the core uses the canonical package-for-Docker workflow and
  bundles the private runtime workspace dependencies at version `2026.9.4`.
- Mattermost plugin: `openclaw-mattermost-2026.9.4.tgz`
- Mattermost SHA-256: `cbdcc8b1881a35d78ac6b8855531067d0651f15823c6ac86aff2c55960f2f02b`
- ACPX plugin: `openclaw-acpx-2026.9.4.tgz`
- ACPX SHA-256: `0a975ef081448a896a277f79f752587afa8d732c17ae935e1f099cff081fc11a`
- Release note: `r1` failed the image-package contract because its plugin
  archives were packed from build output without the generated
  `openclaw.runtimeExtensions` metadata. It remains immutable for audit and
  must not be deployed. `r2` uses the canonical plugin npm packaging overlay.

## Rollout boundary

The canary branch builds a pinned immutable runtime image without changing live
workloads. Before the first rollout, create encrypted, restore-verified recovery
artifacts for every persistent agent. Deploy the exact image digest to Tinus
(`agent-developer`) first, prove the Mattermost lifecycle, then deploy the same
digest to Emon (`agent-coordinator`) and prove the mission wake-ticket lifecycle.
Only after both canaries soak successfully may the remaining agents be promoted
sequentially through the protected `main` workflow. Existing model, Mattermost,
RBAC, Secret, and network policies must remain unchanged.

The existing failed controlled canary remains preserved through deployment:

- its exact producer admission and Emon reconciler remain as found;
- its recipient responders and credentials remain present;
- its private channel and blocked mission remain intact; and
- no teardown, archive, disablement, or deletion is performed without Fito's
  explicit follow-up approval.

The approved remediation canary uses a separate mission and evidence window and
is likewise preserved after the oracle runs.

## Acceptance

1. Composite source verification, canonical packaging, release-asset checksum
   verification, and the branch-specific pinned image build pass.
2. Encrypted recovery artifacts are restore-tested before any workload change.
3. Tinus reports the exact digest and source revision, remains Ready, and proves
   progress replacement, separate final delivery, and cleanup behavior.
4. Emon reports the same digest and revision, remains Ready, and proves exact-
   thread wake receipt, bot-turn isolation, idempotency, and late recovery.
5. Both canaries soak without rollout, restart, queue, or delivery regressions.
6. The protected PR build passes; after approval the exact digest is promoted
   sequentially to the remaining agents and the branch merges to `main`.
7. The preserved canary boundary is verified before and after rollout; the new
   controlled event uses a separate exact mission and does not mutate the old
   failed canary.
