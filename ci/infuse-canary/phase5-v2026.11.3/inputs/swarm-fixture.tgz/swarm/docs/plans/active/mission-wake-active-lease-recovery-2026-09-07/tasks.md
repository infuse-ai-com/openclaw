---
title: Active-Lease Wake-Ticket Recovery Tasks
description: Reviewable implementation tasks for delayed wake-ticket adoption within the active lease.
type: plan
status: active
owner: team:agent-platform
tags: [plan, agents, mission-continuation, recovery]
---

# Tasks: Active-Lease Wake-Ticket Recovery

- [x] Add a deterministic red regression for a ticket that appears after the
  watcher fallback.
- [x] Poll the stable key before the active-lease watcher short circuit.
- [x] Prove late-ticket adoption, no second submission, and no duplicate watcher.
- [x] Run focused and full repository verification.
- [x] Review the diff and record evidence.
- [ ] Open one private swarm PR; do not merge or deploy.
