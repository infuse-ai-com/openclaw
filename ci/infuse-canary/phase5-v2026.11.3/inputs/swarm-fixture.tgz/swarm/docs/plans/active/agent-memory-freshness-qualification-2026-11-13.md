---
title: Automatic memory freshness qualification
description: Evidence for automatic own-summary publication and verified shared-memory retrieval before conservative learning qualification.
type: evidence
status: active
owner: team:agent-platform
tags: [agents, memory, qualification]
---
# Memory freshness — 13 November 2026

Fito chose automatic freshness, conservative learning changes and sequential
delivery. Freshness is qualified first; native learning behavior is unchanged
by this source slice. Ramiro's three mail schedules remain paused.

## Source and contract

Skills MR !11 merged as `f5106d23c7ca6ce42c69e5f0f090868b0d34ff35`
after pipeline 1914 passed. It introduces immutable-revision retrieval and a handoff helper using
the existing own publisher. Swarm owns guarded refresh, startup integration,
the immutable component and runtime source pin. The mirror remains data only.
No new runtime skill grant, GitLab role, credential scope, image or dependency
is required. Current source contains the separately reviewed restricted
`initiative-bootstrap` catalog entry; catalog metadata is aligned but no bundle
receives a new grant.

New tasks force a remote check; follow-up searches may reuse it for five minutes.
Known handoffs force a check and must be ancestors of remote main. Receipts
distinguish updated, unchanged, cached, stale and unavailable. Dirty or divergent
work is preserved. Search reads only the named committed revision and excludes
symlink objects; history and peer summaries retain explicit scopes.

## Verification before deployment

- Skills `task verify`: 281 tests, source/IKF validation, whitespace and secret
  scan passed. The generic Codex quick validator could not start because its host
  PyYAML dependency is absent; the repository's OpenClaw-specific gate passed.
- Swarm `AGENT_ID=agent-designer task verify-ci`: 482 tests and all canonical
  checks passed. Strict comparison against the reviewed source catalog passed
  for five bundles and the one available source catalog.
- Real disposable Git fixtures verified peer updates, handoff ancestry, cache
  expiry/reuse, dirty and divergent work retention, offline/auth failures,
  concurrent refresh, bounded locking, hook non-execution and symlink refusal.
- Skills tests verified exact-revision search during concurrent changes, scoped
  retrieval, stale/strict behavior, receipt rejection, own handoff failures and
  termination of timed-out command children.

## Runtime qualification

Swarm MR !61 merged as `806ca67f18b0a093455c7f2ca7e14c712e8f0ae8`
after exact-source pipeline 1926 passed. The immutable component is
`agent-memory-mirror-f39a0b2c9438`; its source pin is the merged skills revision.
The rollout preserves image digest `acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4`.

Tinus and Satwa completed lifecycle-safe single-writer restarts, manifest parity
and native installed-skill checks. Both passed forced remote-check and cached
retrieval checks. Every non-memory native schedule remains disabled.

Tinus published `1a540dddbe7806ae298d9bca59520b0ba7fbfb44` through the
installed handoff helper using his own account. The commit changes only
`agents/agent-developer/summaries/2026-11-13-memory-freshness.md`; GitLab
pipeline 1936 passed and identifies `agent-developer` as the pusher.
Satwa used `--peers --after-commit` and found that summary at the exact published
revision, with a successful remote check at `2026-11-13T12:10:35Z`.

Kala, Emon and Ramiro completed the same rollout, manifest and fresh/cache checks.
All five are ready on the same component and skills pin. Emon's first 60-second
graceful drain timed out and resumed safely; the five-minute graceful retry
succeeded. There was no forced handoff. Last fleet qualification: Ramiro at
`2026-11-13T12:23:10Z`. His mail and all other non-memory schedules remain disabled.
Freshness is delivered. Native learning remains unchanged while Tinus enters
[shadow qualification](agent-memory-learning-qualification-2026-11-13.md).
