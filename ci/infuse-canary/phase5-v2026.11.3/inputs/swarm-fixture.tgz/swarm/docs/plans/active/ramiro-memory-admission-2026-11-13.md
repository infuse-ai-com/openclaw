---
title: Ramiro memory writer admission — 13 November 2026
description: Own-token publication and five-agent collector evidence after the approved Ramiro credential update.
type: evidence
status: active
owner: team:agent-platform
tags: [agents, memory, qualification]
---
# Ramiro memory writer admission

Fito updated `GitLab / agent-intake service account token` with `read_api`,
`read_repository` and `write_repository`, then requested completion of Ramiro's
memory publication. The prior Developer grant and approved direct-main policy
remain unchanged. This is the admission follow-up to the
[12 November cleanse](agent-memory-mirror-qualification-2026-11-12.md), not another
PVC cleanse or a mailbox repair.

## Credential and own push

Target: context `infuseai-k8s`, namespace `agents-swarm`, deployment
`agent-intake`, container `agent`. All five persistent-agent pods were Ready.

The first own API check returned HTTP 401 because the local Vaultwarden cache
still held the old credential. The installed `bw-infuse-vaultwarden.sh sync`
refreshed that cache. No credential was copied to the operator machine, no token
was rotated by this task, and no Kubernetes Secret or access rule was changed.

The installed GitLab wrapper then returned active user 19, `agent-intake`.
The own token was active, unrevoked and had exactly the three requested scopes;
expiry was 2 February 2027. GitLab readback confirmed Developer level 30 in
memory project 67, protected-main push level 30 and force push disabled.

The existing baseline was `165dcfc3a6f0281949ea639611359eb4294c91bf`.
The only local delta was the retained 12 November cutover receipt. The trusted
`openclaw-agent-sync-memory-repo` published it without re-adoption:

- Commit: `ddf79cce131347d23e35e5e8075701d229e23764`.
- Changed path: `agents/agent-intake/memory/2026-11-12.md` only.
- GitLab pipeline: [1823](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory/-/pipelines/1823), passed.
- Pipeline pusher: `agent-intake`, independently checked through the API.

## Collector qualification

The reviewed selector adds only `agent-intake` to the four admitted agents.
Schedule remains `30 3 * * *`, timezone `Etc/UTC`, concurrency `Forbid`.
The exact selector change passed [MR !59's pipeline 1826](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-k8s-swarm/-/pipelines/1826)
at `54debd22df278717660d03d4a4b4211fe3961225`. A resource-version-guarded
JSON patch changed only that live field; full CronJob spec comparison confirmed
no other spec change. The collector stays unsuspended on the existing image:
`registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4`.

Manual Job `memory-mirror-qualification-20261113` completed successfully at
`2026-11-13T09:06:37Z`. All five own publishers — coordinator, designer,
developer, infra and intake — returned `unchanged` at
`ddf79cce131347d23e35e5e8075701d229e23764`. Ramiro's repeated publication is
therefore idempotent, and the daily collector now includes his own writer.

## Preserved boundaries

The three mail jobs (triage, prefilter and client-waiting reminders) and
`heartbeat-agent-intake` remain disabled; Memory Dreaming Promotion remains
enabled. The three `agent-memory-legacy/agent-intake/*` local refs remain present.
No session, persona or memory pruning was performed.

The installed skill source remains `fd5f8d66c6e873bba0eeaaf3cda6a4a7fcc7e8f7`.
After publication Ramiro's reader remained at `165dcfc3a6f0`: publishing uses a
disposable checkout and does not imply retrieval freshness. Company-docs owns
the requested next proposal; no quality filter or retrieval behavior changed here.

## Verification

`AGENT_ID=agent-designer task verify-ci` passed, including all 470 unit tests.
The first sandboxed run failed localhost/socket and client-render fixtures; the
same canonical check passed with the required local permissions. The fixture
suite's deliberately printed drift cases are not live fleet findings.
