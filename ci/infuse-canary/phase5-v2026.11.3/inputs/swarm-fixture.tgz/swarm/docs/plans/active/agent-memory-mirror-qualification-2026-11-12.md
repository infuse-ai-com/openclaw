---
title: Memory mirror and PVC cleansing qualification — 12 November 2026
description: Source revisions, sequential live checks, preserved history and remaining own-credential dependency.
type: report
status: active
owner: team:agent-platform
tags: [agents, memory, operations, assurance]
---
# Memory mirror qualification

Fito authorized curated native Markdown, direct mirror pushes and a Tinus-first
cleanse followed by the other agents. He explicitly approved Developer and
Maintainer pushes to this memory repository, including future Developers,
with force push disabled. He declined further backup work after Tinus's verified
on-PVC checkpoint and restore rehearsal. Ramiro's mail remains paused.

## Reviewed sources

| Surface | Integrated evidence |
| --- | --- |
| Curated memory | Memory !15/!16; `7a350c34db0760a566d758b8ddbeaf8e7fd1c613`; pipelines 1689/1695 |
| Scoped retrieval | Skills !6/!7; `fd5f8d66c6e873bba0eeaaf3cda6a4a7fcc7e8f7`; final pipeline 1694 |
| Publisher and native pruning | Swarm !52; `1102e3751b3ee1fd8b9d61782c18b0c1220ff9b6`; pipeline 1702 |
| Collector schedule | Swarm !53; `dd19754d9d5ece50c3e87085a8e741842438b7bc`; pipeline 1713 |
| Runtime component | Immutable `agent-memory-mirror-6f55477e02a9` mounted on all five agents |

The existing approved image remains
`sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4`,
OpenClaw 2026.11.1. No new image/dependency or vulnerability exception was
introduced. The [renewal qualification](agent-system-renewal-qualification-2026-11-12.md)
still owns outstanding findings and the 7 December remediation/exception review.

Runtime verification passed 466 unit tests plus the complete `task verify-ci`
gate. Skills verification passed 273 tests. Publisher tests cover concurrent
peer pushes, same-file conflicts, failed pushes, changed capture and secret/path
rejection; pruning tests cover exact workspace scope, changed plans and partial
cursors. Initial sandbox socket/cache failures were rerun successfully with
those local test facilities available. No failing check was waived.

## Preserved history and scope

The source removes 35 duplicated profile snapshots and replaces five policy-filled
MEMORY bodies with dated learned lessons. All 65 original daily journals matched
the live PVC hashes and remain byte-preserved in explicit history, plus the !5
diagnostic note: 66 SHA-256 manifest entries. Git history and legacy refs remain.
History is excluded from normal sparse startup and native daily ingestion.

Each agent was quiesced and processed sequentially. The exact three curated own
files were installed. Original MEMORY, daily/summary directories and DREAMS were
moved to private `/workspace/.memory-cleansing/20261112/original-memory/`, outside
native ingestion. Credentials, repository refs, persona, mailbox/mission state
and retained session history were not reset. All 25 session-table hashes and
six persona-file hashes were unchanged by each offline cleanup.

Tinus's native checkpoint is 465,294,850 bytes, SHA-256
`a90fd26c271205f8f2aef3b47f22298beae6c9c74d1cbc5cf624ee56474c277c`.
An isolated restore verified SQLite inventory and 2,300 entries. The complete
archive/rehearsal remains private on PVC. No valid off-PVC copy is claimed;
the incomplete local copy was removed after Fito declined further backup work.
No additional native archives were created for peers.

## Native replay boundary

A supported main-session reset cleared loaded context/token state but retained
its logical session ID. The first isolated tombstone rehearsal was therefore
not used live: blanket-forgetting current IDs would suppress future learning
from those same conversations. No live session tombstones were added.

The reviewed helper pruned only known daily/provenance/short-term derived
namespaces for the exact workspace. Completed session-ingestion cursors and
seen-message hashes, memory-host cursors, other workspaces/plugins and session
records were preserved. Partial cursors or a changed before-plan cause refusal.

Satwa's first canary exposed four previously unconsumed session candidates,
including a retired Azure URL. Publication/peer rollout stopped. Native
admission drained that tail; a second scoped cleanup removed nine newly derived
rows while preserving advanced cursors, and the repeat canary was clean.
A stored complete cursor is insufficient if the underlying transcript changed.
The version-pinned native replay probe now checks current admission, configured
lookback and seen-message hashes. Exact lifecycle-abort markers are counted
separately; they carry no historical task guidance. Emon's 65-candidate backlog
required three native passes because of the per-file cap before curated files
were installed. Learned Markdown stayed unchanged during the drain.
Native `memory reset` cleared the derived index/cache; native memory search
remains disabled as before. Scoped repository retrieval was separately tested.

| Agent | Derived rows pruned | Ingestion records retained | Legacy refs retained | Own-account mirror commit |
| --- | ---: | ---: | ---: | --- |
| agent-developer | 572 | 545 | 2 | `76d520b1e575a40697e800dc48d3642933910a28` |
| agent-designer | 605 | 128 | 3 | `5a8d6233d0af5aa7ee7fbf90a3999f38dbeffbd1` |
| agent-infra | 536 + 9 reconciliation | 114 | 3 | `f8727739dbd842aefe8297a26d645ebd79b3fbb6` |
| agent-intake | 69 | 71 | 3 | Excluded: own token read-only |
| agent-coordinator | 595 | 620 | 5 | `165dcfc3a6f0281949ea639611359eb4294c91bf` |

All five rollouts became Ready. Each no-delivery dreaming cycle produced fresh
native recall and light/REM/diary files without retired Azure guidance in active
memory or recall. The diary can finish after cron reports success; qualification
waited for its actual files and scanned them. A successful scheduler receipt
alone was not accepted as proof. These cutover notes demonstrate
runtime operation, not useful new subject-matter learning or semantic truth.

Each write-capable agent published only its own dated cutover receipt with its
own account. Tinus's immediate second run was unchanged. Final collector and
post-push CI evidence is appended below. Default retrieval returned own memory
and summaries; peers were available only through the explicit summary scope.

## Schedules, admission and limitations

Only native Memory Dreaming Promotion is enabled in each instance. Ramiro's
email triage, mail prefilter and client-waiting reminders remain disabled.
The mirror collector selects coordinator, designer, developer and infra; it
runs at 03:30 UTC after native dreaming at 03:00 UTC. Stable capture remains
required for manual or long-running overlap. Other schedules were not enabled.

Ramiro is Developer in the memory project, but his own token still has only
`read_api`/`read_repository`. His curated PVC, retrieval and dreaming were
qualified; his local cutover receipt remains unmirrored. He stays excluded
from publication until an approved own write-capable credential is provided.
No operator/shared credential, API-write scope or token rotation was substituted.

GitLab protected main readback permits push/merge level 30 with force false.
The publisher's own-path checks are an application contract, not server-side
folder ACLs. Push-triggered CI validates after publication. Mechanical checks
are not a privacy or truth oracle. Canonical persona/skill/company-policy changes
still require their normal reviewed source path.

Per-agent nonsecret receipts are retained under the private cutover directory;
raw sessions/native stores are not included in this report. Company decisions,
remaining work and final MR dispositions are tracked in company-docs under
`docs/40-agent-system/agent-memory-refactor-2026-11-12/tasks.md`.

## Final collector and GitLab readback

Job `memory-mirror-qualification-20261112` completed at `2026-11-12T19:25:34Z`. All four admitted
publishers returned unchanged at `165dcfc3a6f0281949ea639611359eb4294c91bf`.
The collector was then unsuspended; schedule/timezone readback is
`30 3 * * *`, `Etc/UTC`, suspend false. All five Deployments report 1/1 Ready.

| Own pusher | Direct commit | Successful post-push pipeline |
| --- | --- | --- |
| agent-developer | `76d520b1e575a40697e800dc48d3642933910a28` | 1712 |
| agent-designer | `5a8d6233d0af5aa7ee7fbf90a3999f38dbeffbd1` | 1715 |
| agent-infra | `f8727739dbd842aefe8297a26d645ebd79b3fbb6` | 1718 |
| agent-coordinator | `165dcfc3a6f0281949ea639611359eb4294c91bf` | 1721 |

Server diff verification confirmed that every push changed only that agent's
`memory/2026-11-12.md`. The 66-file history manifest still matches the final main
revision. All five reader checkouts were refreshed to that same revision.

Old memory MRs !5 and !7–!14 are closed as superseded at the reviewed heads;
every source branch remains. The 16 original recovery commits were verified
under their previously preserved `agent-memory-legacy/` names, including
Ramiro's three local-only refs. No historical Git commit was rewritten.

Ramiro's final recall also contains four fresh Gateway-recovery messages from
this restart. They describe checking interrupted work and finding nothing to
resume; they are current lifecycle evidence, not replayed old routing guidance.
His three mail schedules are all disabled. His local cutover receipt remains
unpublished because the own token is read-only.
