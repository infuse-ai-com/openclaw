---
title: Agent Monitoring Truth and Alerts
description: Dependency-ordered remediation plan for aligning official and curated agent telemetry, alerting on user-visible failures, and making behavioral evidence safe for improvement decisions.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - observability
  - monitoring
  - opentelemetry
  - langfuse
  - grafana
  - loki
  - openclaw
---

# Agent Monitoring Truth and Alerts

## Decision

The next observability program is **Monitoring Truth and Alerts**. It follows
the 2026-08-31 twelve-hour dogfood audit and precedes any telemetry-driven skill
or retrieval change.

The program makes official OpenClaw run and tool telemetry the canonical source
for outcome, count, and duration. The standalone behavioral trace remains the
correlated operational drilldown. When the two surfaces disagree, dashboards
and alerts must show the disagreement rather than selecting the more favorable
result.

No iteration requires a custom OpenClaw or Codex artifact rebuild. A finding
that cannot be repaired through public hooks, collector policy, wrappers, or
dashboard logic is documented as an explicit platform limitation and stopped
at that boundary.

## Audit evidence that authorizes this plan

Frozen window: `2026-08-30T23:12:19Z` through
`2026-08-31T11:12:19Z`.

| Finding | Evidence | Why it matters |
| --- | --- | --- |
| Run outcomes disagree | Official telemetry recorded 30 failed runs out of 575; the curated layer recorded 4 failed turns out of 545. | Pod health and curated success can hide user-visible run failures. |
| Native tool failures are underclassified | Official telemetry recorded 63 failed tools out of 1,073, including 55 Bash failures; correlated taxonomy spans recorded 2 failures, both `unknown`. | The classified-cause panel does not represent the dominant failure population. |
| Trace correlation improved but is not structurally complete | Singleton traces fell to 7.7%; all 545 curated turn children used the turn span, but every turn root retained a parent absent from its trace. | Drilldown is useful, but the trace tree still has a dangling-parent defect. |
| Curated tool counts are inflated | At least 145 observations appeared under paired aliases such as `message` and `openclawmessage`. | Fleet counts and rates can be overstated. |
| Curated duration is not canonical | Curated Bash/exec p95 was near zero while official Bash p95 was 15.5 seconds. | Efficiency and slow-tool conclusions must use official spans. |
| Workflow evidence is mostly synthetic | 99% of 1,654 workflow events were automatic plan/deliver lifecycle markers. | The current view cannot prove execution or verification discipline. |
| Skill lifecycles are incomplete | 33 explicit starts and 30 finishes were recorded; Stewie emitted no skill markers across 99 turns. | Missing markers cannot yet support skill-quality decisions. |
| Wrapper evidence has no denominator | Nine bounded failure markers were useful, but success markers were absent and wrapper names used both hyphen and underscore forms. | Clustering works, but reliability rates and ownership are ambiguous. |
| Knowledge Base use was absent | Langfuse, Prometheus, Loki, and service logs all showed zero Discover or Fetch traffic. | Retrieval habits cannot be evaluated, and routing may not invoke the KB when expected. |
| One agent had no turns | Ramiro emitted startup diagnostics but no model, harness, turn, or tool activity. | Routing absence and telemetry absence are not distinguishable today. |
| Model fallback policy is inconsistent | Two capacity incidents occurred; Tinus had an allowed fallback while Stewie did not. Five background memory attempts also used fallback output after policy rejection. | Healthy pods can still have preventable availability and memory-quality failures. |
| Agent alerts are missing | The 30 failed runs fired no dedicated agent alert; current alerts were generic failed Jobs and a Prometheus duplicate-timestamp warning. | Operators cannot rely on the alert surface for agent health. |
| Privacy remained clean | No prompt or response content, no secret-shaped values, and no collector refusal/failure were observed. | The metadata-only and fail-open boundaries should be preserved. |

## Program constraints

- No custom OpenClaw or Codex bundle rebuild.
- Official OpenClaw signals are canonical for run/tool counts, outcome, and
  duration.
- Curated signals own turn-scoped drilldown, explicit workflow, skill, wrapper,
  and Knowledge Base semantics.
- No prompts, responses, raw errors, arguments, commands, paths, retrieved
  content, session identifiers, or chain-of-thought.
- Telemetry remains fail-open; no wrapper or agent action depends on a backend.
- Alerts require minimum-volume and startup/smoke exclusions.
- No automatic instruction, skill, wrapper, or retrieval changes.
- Production changes use Tinus first, then the remaining agents sequentially.
- Each iteration produces reviewable source, automated verification, live
  evidence, rollback instructions, and an explicit stop boundary.

## Dependency sequence

```text
Iteration 0: truth contract and baseline
        |
        v
Iteration 1: run truth and availability alerts
        |
        v
Iteration 2: tool truth, failure classification, and deduplication
        |
        v
Iteration 3: trace integrity and workflow anomaly views
        |
        v
Iteration 4: skill, workflow, and wrapper evidence quality
        |
        v
Iteration 5: traffic attribution, routing, fallback, and KB dogfood
        |
        v
Iteration 6: cross-backend acceptance and governed review
```

Iterations are promoted independently. A failed gate blocks only its dependent
iterations; it does not roll back already accepted privacy-safe telemetry.

## Iteration 0 — Truth contract and reproducible baseline

### Addresses

- Conflicting official and curated outcomes.
- Ambiguous source-of-truth rules in dashboards and acceptance reports.
- Comparisons that cross image, skill-bundle, rollout, startup, or traffic
  boundaries.

### Deliverables

1. Extend the telemetry contract with canonical-source and reconciliation
   rules for each signal family.
2. Add a reproducible twelve-hour audit command that emits aggregate evidence
   only and never stores credentials or content.
3. Record the exact official-versus-curated discrepancy fixtures: 30 versus 4
   failed runs and 63 versus 2 failed tools.
4. Require every report to segment by agent, immutable image, runtime revision,
   skill-bundle revision, rollout boundary, and traffic source when available.
5. Correct documentation that currently implies the curated trace is canonical
   for fleet outcome or that the turn root is always parentless.

### Exit gate

- Every dashboard panel names its canonical signal.
- Contract tests fail when curated counts replace official counts.
- The aggregate audit reproduces the frozen evidence without content leakage.
- No live change occurs in this iteration.

### Primary authorities

`openclaw-k8s-swarm`, `grafana`.

## Iteration 1 — Run truth and availability alerts

### Addresses

- Thirty official run failures hidden by green pods.
- Twenty-eight settled-turn finalization failures.
- Two capacity incidents and inconsistent fallback behavior.
- No dedicated alert for failed turns or missing per-agent turn telemetry.

### Deliverables

1. Add recording rules for official run attempts, failures, failure rate,
   latency, and per-agent last-seen timestamps.
2. Add minimum-volume alerts for elevated run failure rate, repeated settled-
   turn finalization failure, agent telemetry absence while the Deployment is
   Ready, and collector export failure.
3. Add a run-health dashboard row that distinguishes pod availability, model
   availability, harness/run completion, and curated trace availability.
4. Add bounded Loki views for settled-turn finalization, model capacity, and
   model-policy rejection counts.
5. Test one controlled failure, one missing-telemetry condition, and recovery;
   verify firing and clearing states.

### Exit gate

- A failed official run is visible within the accepted alert delay even when
  the pod remains Ready.
- Healthy low-volume agents do not page merely for inactivity.
- Startup, smoke, and rollout traffic cannot trigger the production failure-
  rate alert.
- No alert contains raw errors or user/task identifiers.

### Primary authorities

`grafana`, `openclaw-k8s-swarm`.

## Iteration 2 — Tool truth, failure classification, and deduplication

### Addresses

- Sixty-three official tool failures versus two correlated failures.
- Dominant `codex_native_tool_error` failures without stable cause.
- Duplicate dynamic-tool aliases.
- Non-canonical curated duration measurements.
- Wrapper failure clusters without success denominators.

### Deliverables

1. Make official tool spans the sole source for volume, duration, and generic
   outcome panels.
2. Keep curated tool spans only for turn parenting and bounded classification;
   display coverage and `unknown` rate explicitly.
3. Normalize dynamic-tool aliases before metrics are projected.
4. Reconcile each classified tool failure with an official failed tool span;
   unmatched failures appear in a dedicated integrity panel.
5. Extend high-value wrappers to emit bounded success and failure lifecycle
   evidence with one canonical wrapper identifier.
6. Preserve `unknown` when the public hook lacks trustworthy cause evidence;
   never relabel all native errors as non-zero exit.

### Exit gate

- Dashboard call, failure, and duration totals match official Langfuse spans
  for the acceptance window.
- No logical dynamic tool is counted under both aliased names.
- Every official failed tool is classified, explicitly `unknown`, or shown as
  unmatched; none disappear.
- Wrapper rates have both numerator and denominator.

### Primary authorities

`openclaw-k8s-swarm`, `agent-skills`, `grafana`.

## Iteration 3 — Trace integrity and workflow anomaly views

### Addresses

- A dangling parent on every curated turn root.
- Long or tool-heavy turns that are difficult to discover.
- Cross-backend navigation that still depends on agent and timestamp.
- Trace trees that are correlated but not fully integrity-checked.

### Deliverables

1. Ensure every curated turn root is parentless or its parent exists in the
   same trace; export no dangling parent reference.
2. Add trace-integrity metrics for root count, missing parent, orphan child,
   duplicate child, and turn closure.
3. Add anomaly views for slow turns, excessive tool counts, repeated failures,
   incomplete turns, and unusually large traces.
4. Add safe Grafana-to-Langfuse drilldown using backend-supported trace links;
   do not export run or session identifiers as metric labels.
5. Retain the official trace as a separate diagnostic surface while making the
   curated trace's scope explicit.

### Exit gate

- Zero dangling parents in the controlled suite.
- One controlled long turn and one repeated-failure turn appear in anomaly
  views and link to the correct Langfuse trace.
- Privacy scans remain clean and metric cardinality stays bounded.

### Primary authorities

`openclaw-k8s-swarm`, `grafana`.

## Iteration 4 — Skill, workflow, and wrapper evidence quality

### Addresses

- Ninety-nine percent workflow lifecycle boilerplate.
- Three unmatched skill starts.
- Missing explicit skill evidence for active agents.
- Inconsistent wrapper identifiers and failure-only evidence.

### Deliverables

1. Separate automatic lifecycle phases from explicit workflow markers through
   an attribution field that cannot be confused in dashboards.
2. Add lifecycle completeness rules for skill and wrapper start/finish pairs.
3. Normalize wrapper and operation identifiers at source.
4. Expand explicit markers only where the owning skill's procedure requires
   them; absence remains unknown rather than evidence of non-use.
5. Add views for incomplete lifecycles, explicit verification, recovery,
   wrapper reliability, and attribution confidence.

### Exit gate

- Controlled skill and wrapper runs finish with exactly one terminal state.
- Interrupted runs appear as incomplete rather than successful or absent.
- Automatic plan/deliver events cannot dominate explicit workflow panels.
- No inferred skill use supports an evaluation or promotion decision.

### Primary authorities

`agent-skills`, `openclaw-k8s-swarm`, `grafana`.

## Iteration 5 — Traffic attribution, routing, fallback, and KB dogfood

### Addresses

- No distinction between human, automation, smoke, and startup traffic.
- Ramiro's absence from turn telemetry despite expected use.
- Zero organic Knowledge Base Discover/Fetch traffic.
- Inconsistent model fallback allowlists and background-memory fallback output.

### Deliverables

1. Add a bounded traffic-source enum at the ingress or task-dispatch boundary:
   `human`, `automation`, `smoke`, and `startup`.
2. Verify one routed human turn for every agent, including message receipt,
   model start, run completion, and delivery evidence.
3. Reconcile approved model and fallback policy for every agent; separately
   test primary capacity failure and fallback success.
4. Run reviewed read-only tasks where authoritative company knowledge is
   genuinely required, then verify Discover, candidate return, Fetch, and
   authenticated agent attribution.
5. Distinguish `KB not needed`, `KB considered but unavailable`, `KB invoked`,
   and `KB failed` only when deterministic evidence exists.

### Exit gate

- All five agents emit a controlled human turn in the dedicated project.
- Source attribution covers every new acceptance observation.
- Primary model failure has an approved bounded fallback or a documented
  fail-closed policy.
- At least one legitimate Discover-to-Fetch flow succeeds for each selected
  KB-dependent role without content capture.

### Primary authorities

`openclaw-k8s-swarm`, `openclaw-agents-persona`, `agent-skills`,
`knowledge-base`.

## Iteration 6 — Cross-backend acceptance and governed review

### Addresses

- Operators manually reconciling Grafana, Loki, Langfuse, Kubernetes, and
  Knowledge Base evidence.
- Generic failed-Job alert noise.
- No repeatable human-reviewed monitoring report before skill changes.

### Deliverables

1. Add one read-only aggregate review command or service boundary for the
   approved cross-backend evidence set.
2. Produce a Mission Control verification artifact containing run health,
   tool reliability, trace integrity, workflow/skill coverage, KB use, alert
   state, privacy, and provenance.
3. Classify noisy stale failed-Job alerts separately from active agent-impact
   alerts; do not delete history merely to make the dashboard green.
4. Run the complete dogfood scorecard across all five agents.
5. Convert findings into proposed owner-repository work only after human
   review; no automatic skill or runtime mutation.

### Exit gate

- One reviewer can move from alert to Grafana aggregate, Loki evidence, and
  the corresponding Langfuse trace without privileged ad-hoc investigation.
- The report states `verified`, `not verified`, or `inconclusive` for every
  monitoring claim.
- The review recommends at least one evidence-backed improvement or explicitly
  concludes that no promotion is justified.

### Primary authorities

`openclaw-k8s-swarm`, `grafana`, Backoffice Artifacts.

## Rollout and rollback contract

1. Source and contract verification precede every live change.
2. Tinus receives the first runtime-affecting change.
3. The sequence continues through Satwa, Stewie, Emon, and Ramiro only after
   the target's run, tool, trace, privacy, channel, and restart gates pass.
4. Dashboard and alert changes use controlled synthetic evidence before they
   evaluate organic traffic.
5. Roll back only the affected rule, dashboard, collector configuration,
   plugin configuration, wrapper revision, or Deployment.
6. A collector or backend outage must never alter the agent or wrapper result.

## Completion criteria

The program is complete when:

- official and curated run/tool outcomes reconcile or visibly disagree;
- user-visible failed runs alert even when pods remain healthy;
- official tool totals, duration, failures, and curated drilldown agree;
- no alias duplication or dangling parent remains;
- workflow, skill, and wrapper lifecycle coverage is honest and complete for
  controlled cases;
- traffic source, all-agent routing, fallback behavior, and reviewed KB use
  are proven;
- privacy and fail-open gates pass; and
- the first governed cross-backend review artifact is feed-visible in
  Backoffice.

## Immediate next action

Iterations 0 through 6 were implemented and accepted through the 2026-09-01
cross-backend review package. The 2026-10-15 production audit found regressions
in Langfuse signal density, shell alias reconciliation, traffic attribution,
and direct marker visibility. Those bounded follow-ups are owned by
`agent-observability-signal-quality-2026-10-15.md`. This historical plan remains
active only until that plan's seven-day soak closes, at which point both plans
move to completed status together.
