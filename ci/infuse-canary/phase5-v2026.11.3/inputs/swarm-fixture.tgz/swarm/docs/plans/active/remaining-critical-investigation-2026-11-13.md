---
title: Remaining CRITICAL findings — remediation investigation
description: Records installed XML and LMDB consumers, maintained patch candidates and qualification requirements for the four unresolved CRITICAL findings.
type: report
status: active
owner: team:agent-platform
tags: [agents, security, dependencies, qualification]
sources:
  - ref: residual-runtime-dependencies-2026-11-13.md
    role: baseline
  - ref: https://ubuntu.com/security/CVE-2026-6653
    role: advisory
  - ref: https://github.com/jnwatson/py-lmdb/pull/429
    role: patch-source
---
# Remaining CRITICAL findings — investigation

13 November 2026. This is investigation and proposal evidence; no package,
runtime, credential, schedule or scan-policy changes were made. Company-docs
owns the [remediation decision and work plan](https://gitlab.infuse-ai-tech.party/platform/engineering/company-docs/-/blob/main/docs/40-agent-system/remaining-critical-remediation-plan-2026-11-13.md).
The [sanitized inventory](../../evidence/2026-11-13-remaining-critical-investigation.json)
owns measured package facts and source hashes.

## Baseline and limits

All five agent deployments remain ready with both containers selecting image
`sha256:74ca6120a569721fab46008c17444c87b37d45ff4eb2e9fda13034674173d424`.
Read-only package/linkage inspection on Tinus at 17:24 UTC confirms the two
affected libraries. Reused scan job 8582 reports the four target rows; this
investigation did not perform a new scan or exercise malicious input.

| Finding | Installed package | Relevant precondition |
| --- | --- | --- |
| CVE-2026-6653 | libxml2 `2.12.7+dfsg+really2.9.14-2.1+deb13u3`; runtime reports `20914` | Crafted XML reaching affected internal-subset/entity handling |
| CVE-2019-16224 | liblmdb0 `0.9.31-1+b2` | Crafted database flags lead to an invalid write |
| CVE-2019-16225 | Same liblmdb0 | Crafted database page flags lead to an invalid write |
| CVE-2019-16227 | Same liblmdb0 | Crafted duplicate-data metadata reaches invalid cursor handling |

These are package findings, not demonstrated compromise paths. Debian marks
Trixie affected for [XML](https://security-tracker.debian.org/tracker/CVE-2026-6653)
and all three LMDB IDs ([16224](https://security-tracker.debian.org/tracker/CVE-2019-16224),
[16225](https://security-tracker.debian.org/tracker/CVE-2019-16225),
[16227](https://security-tracker.debian.org/tracker/CVE-2019-16227)). Its lower
distribution urgency does not rewrite the retained scanner severity. Network
privacy does not prevent agents from processing downloaded hostile inputs.

## Measured dependency graph

- BIND is the only installed **declared package dependent** of liblmdb0.
  `dig`, `host`, `nslookup`, `nsupdate` and `delv` exist; `named` and
  `named-nzd2nzf` do not. Removing liblmdb0 in an apt simulation removes
  bind9-dnsutils, bind9-host and bind9-libs too.
- System libxml2 has four declared dependents: bind9-libs, libllvm19,
  libmagickcore-7.q16-10 and shared-mime-info. LLVM feeds mesa-libgallium;
  MIME data feeds GTK/GDK. Simulating libxml2 removal removes 24 packages,
  including Chromium, Xvfb and ImageMagick. Removing compiler commands alone
  would not remove the graphics dependency.
- Actual linkage confirms XML/LMDB in DNS clients, and XML in ImageMagick and
  update-mime-database. Chromium's direct linkage output does not include XML;
  package dependencies and possible dynamically loaded graphics paths still
  matter. No specific browser exploit path is established.
- Python lxml uses its separate bundled libxml2 2.14.6. It is outside this
  particular old-system-library finding, but not a blanket safe parser:
  [CVE-2026-86139](https://security-tracker.debian.org/tracker/CVE-2026-86139)
  requires separate embedded-library review.

The graph uses installed dpkg dependencies and selected linkage checks, not
an exhaustive search of every binary, dynamic loader or private project.
Full package/file/ELF closure is an acceptance requirement for removal.

## LMDB: removal first, maintained patch fallback

The exact [BIND 9.20.30 configuration source](https://raw.githubusercontent.com/isc-projects/bind9/v9.20.30/configure.ac)
supports `--without-lmdb` and `--without-libxml2`. [ISC's build documentation](https://bind9.readthedocs.io/en/v9.20.15/chapter10.html)
ties LMDB to runtime-added server zones and XML to server statistics. This
supports a client-only rebuild hypothesis, not proof of an accepted build.

Recommended candidate: build maintained BIND clients on the pinned Trixie base,
disable those two optional integrations, package the actual clients and required
libraries with accurate dependencies, and remove the old BIND/LMDB packages
only in the candidate image. Preserve all five installed DNS commands and their
existing features, including IDN, DNSSEC, TCP, DoH and GSSAPI where supported.
Do not replace dig with a partial wrapper or statically hide LMDB in a binary.
Keep an explicit package update owner and prevent later apt operations from
silently reintroducing the distribution libraries.

Qualification must compare old/new output, exit codes and errors using a local
synthetic DNS fixture: A/AAAA/TXT/MX/SRV/PTR, NXDOMAIN, UDP/TCP, custom server/port,
timeouts/retries, DNSSEC and the retained command-specific features. Exercise
nsupdate only against the synthetic server. Check full rootfs/SBOM/linkage for
LMDB absence, package consistency, native AMD64 behavior and full advisory scan.

The fallback is real patch work, not waiting indefinitely. py-lmdb merged
[PR 429](https://github.com/jnwatson/py-lmdb/pull/429) at
`4454d12634a478166dc52a5cf0edd9ef92b16832` and follow-up
[PR 430](https://github.com/jnwatson/py-lmdb/pull/430) at
`6827beb3f39754502a46f0c64911013b7a07bfa4`. These patch bundled C LMDB;
installing a newer Python package does not repair system liblmdb0. Review the
follow-up fixes too, port against the exact Debian source, and independently
run C corruption regressions, valid transaction/concurrency tests and sanitizers
in isolation. Their published results do not constitute our qualification.
This adds a private C-library maintenance obligation and may retain raw distro
scanner rows after a successful repair.

## XML: published 2.9.14 backport first

New evidence improves the earlier P5 disposition. [Ubuntu's advisory](https://ubuntu.com/security/CVE-2026-6653)
records a fix in Noble `2.9.14+dfsg-1.3ubuntu3.8`, on the same underlying branch
as this image. The [current Noble source patch](https://git.launchpad.net/ubuntu/+source/libxml2/plain/debian/patches/CVE-2026-6653.patch?h=ubuntu/noble-security)
was retrieved over HTTPS; SHA-256:
`6c2b8a7b6fa470efcb1854e5c73bd7e1ae1663d8b111e27ce9232bbc1fe44f54`.
The mutable branch file was inspected, not installed. Its release signature,
exact published release correspondence and applicability to Debian's patch
stack remain to be verified before a build.

The patch is derived from upstream
[`463bbeec`](https://github.com/GNOME/libxml2/commit/463bbeeca1805b5c4828f50d0fefc4eebaf620df)
and changes seven files. Inspection finds added fields in public entity/input
structures. Therefore a retained soname or a passing link is insufficient ABI
evidence. Start with a bounded feasibility exercise: verify source provenance,
retain Debian's existing fixes, audit patch prerequisites and public layouts,
then use ABI tooling plus actual consumer tests. Stop for review if existing
consumer allocations/layout assumptions require a broader rebuild.

If feasible, build an auditable private Debian package on Trixie. Run the
specific UAF negative/positive regression under sanitizers only in disposable
fixtures, upstream parser/entity/XPath tests, valid XML/HTML/catalog cases,
ImageMagick configuration/conversion/contact sheets, MIME database generation,
Mesa/LLVM paths and three headless/headed sandbox browser paths. No Ubuntu
binary packages, forged version metadata or library symlinks are proposed.

Alternative: move all retained consumers to a current libxml2 release built
on Trixie. Upstream [2.14 explicitly changed ABI and soname](https://download.gnome.org/sources/libxml2/2.14/libxml2-2.14.0.news),
so 2.15.4 cannot replace libxml2.so.2 directly. This means auditing/rebuilding
the entire consumer closure or qualifying a different supported base. It is
a larger fallback, with no guarantee the original package disappears until
every old consumer is removed. Production worker adoption can reduce exposure
but does not itself patch a library remaining in the persistent image.

## Acceptance, ownership and remaining unknowns

Satwa owns security review and ongoing package maintenance; Tinus implements;
Emon integrates. Fito chooses the follow-up scope. The prior six phases remain
complete; these four unresolved findings have not been fixed by this research.

Each selected repair needs its own source/image receipt, complete scan, retained
capability checks and rollback image. After release authorization: Tinus first,
at least 30 minutes with functional/collector evidence, then sequential roles
and all six maintenance controllers. Preserve per-agent credentials/PVCs,
memory, sandbox controls, Ramiro mail/heartbeat pause and advisory scans.

Unknowns: BIND client feature parity, full artifact closure, vendor patch
compatibility with Debian, actual exploit reachability per consumer and the
future scanner treatment of private packages. All require evidence; no raw
finding is suppressed. Review remains due **7 December 2026**, sooner on new
exposure or a failed feasibility gate. Retirement of private builds requires
qualified maintained distribution replacements.
