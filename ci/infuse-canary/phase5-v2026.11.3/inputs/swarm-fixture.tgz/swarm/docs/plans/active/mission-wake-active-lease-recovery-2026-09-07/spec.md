---
title: Active-Lease Wake-Ticket Recovery Specification
description: Requirements for adopting a delayed durable wake ticket without duplicate submission or watcher activity.
type: standard
status: active
owner: team:agent-platform
tags: [standard, agents, mission-continuation, recovery]
---

# Feature Spec: Active-Lease Wake-Ticket Recovery

## Problem

An OpenClaw wake can be accepted while the submitting process receives an
ambiguous timeout or rejection. If the ticket is not visible during the same
process, the steward records no ticket and posts its one watcher fallback. On
later reconciler passes the active-lease branch currently returns immediately
when that watcher exists, so it never discovers the durable ticket that became
visible under the stable wake idempotency key.

## Goal

Poll the stable wake key during every eligible active-lease reconciliation,
including after a watcher was posted, adopt one late queued/started/completed
ticket, and never submit another internal wake or duplicate the watcher.

## Acceptance Criteria

1. An initial ambiguous no-ticket result may post one watcher and keep the lease.
2. The next active-lease pass performs `runner.status` with the same wake key
   before returning `watcher_pending`.
3. A late ticket is written to the existing ledger record with its exact ticket,
   run, status, and start receipt.
4. A queued or started late ticket returns `internal_pending` and suppresses any
   additional watcher post.
5. A completed late ticket settles normally if inbox processing is complete;
   otherwise the existing watcher/grace behavior remains available.
6. No active-lease recovery path calls `runner.run` or creates a second ticket.

## Non-Goals And Gates

- No OpenClaw core change or release.
- No new API, credential, producer policy, route, reconciler, or responder.
- No merge, deployment, fourth canary, or teardown without separate approval.

## Source Links

- `scripts/mission-event-steward-wake.py`
- `tests/test_mission_event_steward_wake.py`
- `docs/MISSION_CONTINUATION_PRODUCTION.md`
