---
title: Agent Execution System v2 Specification
description: Defines Emon-led mission execution, role-isolated Mattermost coordination, Backoffice mission visibility, and one canonical authenticated artifact registry.
type: architecture
status: active
owner: team:agent-platform
tags:
  - agents
  - artifacts
  - backoffice
  - missions
  - orchestration
---
# Agent Execution System v2 Specification

## Problem

Infuse AI's persistent agents are individually capable, but the current
coordination model allows Kapiteky, Emon, and specialists to overlap. Shared
project channels, repeated status requests, mutable authority, and
producer-owned artifact storage create noise and brittle handoffs.

The Backoffice Agents Truth delivery exposed the failure mode: technically good
work was surrounded by 315 posts, repeated no-change updates, stale handoffs,
and inconsistent acceptance state.

## Users And Scenarios

- Fito needs one readable view of current missions, blockers, next actions, and
  evidence without following every specialist thread.
- Kapiteky needs to guide direction and improve Emon's operating system without
  becoming the execution bottleneck.
- Emon needs one durable local mission registry and one event-driven steward
  loop that tells him what is actionable.
- Specialists need focused project/function channels and exact assignments
  without ambient cross-agent chatter.
- Agents and authenticated humans need one durable artifact handoff contract
  that supports HTML, reports, images, and other bounded files.

## Goals

1. Make Emon the accountable CEO/execution lead of the agent organization.
2. Keep Kapiteky in an advisor, direction, enablement, and backstop role.
3. Make missions, not chat polling, the durable execution state.
4. Separate specialist conversations by project and function.
5. Add a read-only Backoffice Missions surface sourced from Emon's registry.
6. Replace producer workspaces, relays, and collected copies as artifact
   authority with one authenticated Artifact Registry API.
7. Preserve the existing shared bin: no automatic retention, reversible trash
   and restore for company users, admin-only permanent deletion and empty bin.

## Non-Goals

- Automatically creating a new task whenever an artifact is published.
- Allowing specialists to self-assign from artifact events.
- Making Mattermost the durable source of mission or artifact truth.
- Granting Kapiteky routine membership in specialist project channels.
- Removing the current artifact collector, relay, or lifecycle worker before
  parity and rollback evidence pass.
- Creating a new persistent agent identity.

## Domain Language

- **Direction plane:** Fito, Kapiteky, and Emon align vision, priorities,
  authority, and escalation in `ai-lab/kapiteky-emon-coordination`.
- **Execution plane:** Emon owns missions, specialist assignments, evidence,
  integration, release, and closeout.
- **Artifact plane:** the Artifact Registry API owns accepted artifact content
  and immutable revisions.
- **Mission:** a durable outcome record with one accountable coordinator,
  explicit status, task slices, gates, next action, and evidence pointers.
- **Mission steward:** Emon's scheduled, event-sensitive review of mission
  records. It is not a general backlog sweep or agent-status poller.
- **Portfolio review:** a low-frequency, allowlisted, proposal-only discovery
  pass. It may shape a complete planned candidate but never activates work.
- **Delivery campaign:** one approved mission over a bounded ticket set or
  selection rule, delivered in coordinated waves and reconciled as a whole.
- **Material event:** a new assignment, artifact revision, commit, PR, build,
  runtime observation, blocker, gate decision, or completion.

## Authority And Interaction Invariants

- Fito is the human principal and final authority when he chooses to intervene.
- Kapiteky represents Fito's company direction with Emon, advises and
  challenges for coherence, and improves the agent operating system without
  becoming the routine executor.
- Emon translates direction into missions and owns execution end to end,
  including integration, PR creation, merge, deploy, verification,
  reconciliation, and closeout, until an explicit human or safety boundary is
  reached.
- Capability and access gaps remain Emon-owned until routed to a capable
  approved worker or raised as a precise blocker; they do not silently transfer
  execution to Kapiteky.
- Specialists execute only an assigned slice and report to Emon.
- Specialists do not routinely consult Kapiteky. Emon escalates strategic,
  capability, safety, or approval questions through
  `kapiteky-emon-coordination`.
- Kapiteky runs no recurring job that chases specialists for updates.
- Emon's mission steward never posts an unchanged update merely to prove it ran.

## Mattermost Topology

For a project such as Backoffice:

| Channel | Ambient agent | Mention-only agent | Human | Kapiteky |
| --- | --- | --- | --- | --- |
| `core/backoffice-dev` | Emon | Tinus | Fito | absent |
| `core/backoffice-design` | Emon | Stewie | Fito | absent |
| `core/backoffice-infra` | Emon | Satwa | Fito | absent |

Each mission task uses one Mattermost thread in the appropriate function
channel. Different tasks use different threads. Emon may participate across
the role channels; specialists wake only when mentioned in their channel.

Kapiteky's verified Mattermost `system_admin` identity can inspect private
channel content without membership. The runtime must not use that capability
for unrelated browsing; it exists for explicit review and backstop work.

## Mission Contract

The first canonical mission file lives in Emon's local workspace at:

`/workspace/agents/agent-coordinator/state/team-missions.json`

Every native v2 mission records:

- stable mission id, title, project, purpose/why now, measurable outcome,
  status, and coordinator;
- repository and Mattermost pointers;
- scope, non-goals, acceptance criteria, and approval boundaries;
- task slices with one responsible owner, dependencies, capability needs,
  acceptance, and verification expectations each;
- artifacts as stable registry id plus immutable revision;
- exact next action with owner, source reference, machine-checkable trigger,
  fallback due time, and expected evidence;
- last material event and latest synthesis;
- closeout evidence.

Mission statuses are `planned`, `active`, `blocked`, `waiting_for_human`,
`integration_review`, `ready_to_merge`, `done`, `cancelled`, and `legacy`.
Only `active`, `blocked`, `waiting_for_human`, `integration_review`, and
`ready_to_merge` consume the one execution-active mission slot per project.
Migrated v1 history is `legacy`, audit-only, and never reopened.

The steward acts only when the next action is due, its trigger is satisfied, a
mission is explicitly blocked, or a material event requires synthesis. A future
event publisher may wake the steward immediately; v1 uses a bounded cron over
the same deterministic rules.

An explicitly approved backlog batch may be one delivery-campaign mission.
Portfolio discovery is separate, low-frequency, allowlisted, and proposal-only.

## Backoffice Missions Surface

The first page is read-only. It shows:

- active, blocked, awaiting-gate, acceptance, and completed counts;
- mission owner, status, current outcome, next action, and freshness;
- assigned task slices and exact artifacts;
- approval gates and blockers;
- links to Mattermost threads, repositories, PRs, builds, and artifacts.

The page must label its source and freshness. Missing or invalid snapshots must
produce an honest unavailable/stale state rather than seed mission data.

## Artifact Registry Contract

The registry is a dedicated internal service. Backoffice remains the
authenticated human UI and lifecycle control plane but does not receive a
writable artifact mount.

V1 accepts a versioned JSON bundle containing a manifest and bounded base64
files. This supports HTML, Markdown, JSON, images, and other approved regular
files without unsafe archive extraction. A compressed transport may be added
later without changing artifact identity or lifecycle semantics.

Required properties:

- authenticated producer identity;
- read access for every authenticated Infuse AI agent and human;
- producer namespace derived from authentication, not request claims;
- stable artifact id and content-derived immutable revision;
- atomic, idempotent publication;
- bounded file count, path, size, MIME, and total bundle limits;
- no absolute paths, traversal, symlinks, or special files;
- ordinary artifacts immutable after publication;
- journals may publish later revisions;
- exact-revision reads and purge;
- content-free tombstones preventing ordinary identity resurrection;
- no automatic retention deadline;
- content-free audit events only.

Artifact publication records an optional intended consumer but does not create
a mission task in v1. The API and event schema must leave room for a later
reviewed rule that converts selected artifact types into proposed assignments.

## Acceptance Criteria

- Live Kapiteky access is proven for one non-member private channel without
  reading or exposing message content in evidence.
- Kapiteky has no recurring specialist-status cron.
- Emon's installed steward reads the v2 mission registry and is silent when no
  action is due.
- Emon is ambient and each specialist is mention-only in the intended project
  role channel.
- Backoffice exposes an authenticated, source-labeled `/missions` page.
- The registry service passes identity, atomicity, idempotency, hostile path,
  size-limit, ordinary tombstone, journal revision, and exact-purge tests.
- A Mac producer and one Kubernetes producer publish through the same client
  and produce byte/hash-equivalent canonical content.
- Backoffice trash, restore, purge, and empty-bin behavior continues with no
  automatic retention.
- Production cutover preserves a rollback path until parity and lifecycle
  convergence are accepted.

## Risks And Approval Gates

- Channel membership and runtime routing changes are reviewed access changes.
- New registry tokens, Kubernetes Secrets, PVCs, ServiceAccounts, RBAC,
  migrations, and production deployment remain explicit activation gates.
- The current artifact system remains authoritative until dual-write parity,
  restore, purge, backup, and rollback evidence pass.
- Do not expose the registry publicly or reuse Backoffice browser sessions as
  agent credentials.

## Source Links

- Fito's accepted direction in the 2026-08-31 direct Mattermost conversation.
- `company-docs/docs/40-agent-system/agentic-operating-model.md`
- `company-docs/docs/40-agent-system/agent-team-mission-workflow.md`
- `backoffice/docs/plans/deferred/mission-control-artifact-registry.md`
- `agent-skills/skills/agentic-product-engineering/`
