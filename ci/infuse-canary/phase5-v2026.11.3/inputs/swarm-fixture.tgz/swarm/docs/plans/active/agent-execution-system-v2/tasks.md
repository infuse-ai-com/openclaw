---
title: Agent Execution System v2 Tasks
description: Reviewable vertical delivery slices for the accepted cross-repository agent execution system.
type: plan
status: active
owner: team:agent-platform
tags:
  - agents
  - artifacts
  - backoffice
  - missions
  - orchestration
---
# Agent Execution System v2 Tasks

## Story 1: Durable authority and interaction model

- [x] Update `company-docs` operating model, mission workflow, Backoffice
  control-center direction, and decision log.
- [x] Update `openclaw-agents-persona` so Emon leads execution, specialists
  report to Emon, and Kapiteky is an advisor/backstop rather than an ordinary
  execution reviewer.
- [x] Verify company docs and persona repositories with their canonical gates.

## Story 2: Emon-local mission registry and quiet steward

- [x] Add a versioned mission schema and lifecycle CLI to `agent-skills` with
  create, list, show, task, artifact, event, next-action, status, and validate
  operations.
- [x] Add deterministic due/trigger evaluation that never requires reading
  agent chat just to determine whether a mission is actionable.
- [x] Replace the old broad dispatcher prompt/installer in
  `openclaw-k8s-swarm` with a mission steward that reads only registered
  missions and acts on material state.
- [ ] Prove a no-action run produces no Mattermost post.

## Story 3: Focused Backoffice role channels

- [x] Create `core/backoffice-dev` with Fito, Emon, and Tinus.
- [x] Create `core/backoffice-design` with Fito, Emon, and Stewie.
- [x] Create `core/backoffice-infra` with Fito, Emon, and Satwa.
- [x] Keep Kapiteky absent and record the verified read-on-demand result.
- [x] Update the canonical channel registry and verify live runtime routing.

## Story 4: Read-only Backoffice Missions page

- [x] Define and validate the mission snapshot contract.
- [x] Export only Emon's canonical registry file into a read-only Backoffice
  source with freshness metadata.
- [x] Add `/missions`, shell navigation, source/invalid/stale states, mission
  counts, task owners, next actions, gates, and durable links.
- [x] Add unit/build/browser evidence without introducing write controls.

## Story 5: Canonical Artifact Registry v1

- [x] Build a standalone internal registry service from the Backoffice repo.
- [x] Add the JSON bundle protocol, identity binding, atomic/idempotent writes,
  exact reads, ordinary immutability, journal revisions, purge, and tombstones.
- [x] Add hostile path, size, MIME, duplicate retry, and atomic publish
  tests.
- [x] Add an `agent-skills` publish/list/read/lifecycle client with safe credential
  lookup and no token logging.
- [x] Add deployment manifests with placeholders only; do not create secrets or
  activate production until explicitly approved.

## Story 6: Dual-write canaries and lifecycle integration

- [ ] Canary Kapiteky through the same publish client used by Kubernetes.
- [ ] Canary one persistent Kubernetes agent.
- [ ] Compare identity, metadata, HTML, file, and total bundle hashes to the
  current feed.
- [ ] Connect Backoffice reads, trash/restore, and exact purge to the registry
  behind a rollback switch.
- [ ] Prove no automatic retention, ordinary tombstone rejection, journal
  revision exception, inaccessible purged content, backup/restore, and rollback.

## Story 7: Incremental migration and retirement

- [ ] Migrate remaining agents one at a time with parity evidence.
- [ ] Observe stable registry-backed reads and lifecycle behavior.
- [ ] Remove collector, relay, source-purge branches, and pod-exec RBAC only
  after the reviewed observation window.
- [ ] Close the mission with exact PR/build/deploy/runtime evidence and archive
  this active plan.

## Review And Delivery

- [ ] Verify each repository with its canonical task/verification command.
- [ ] Review exact diffs and approval boundaries before each merge.
- [ ] Record shared code refs, CI builds, runtime revisions, and browser proofs.
- [ ] Keep Emon's mission state and `kapiteky-emon-coordination` synthesis
  current at material gates only.
