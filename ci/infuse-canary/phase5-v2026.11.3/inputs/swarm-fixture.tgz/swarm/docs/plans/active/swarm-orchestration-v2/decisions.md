---
title: Swarm Orchestration v2 Decisions
description: Durable implementation decisions and deferred choices for the orchestration program.
type: decision
status: active
owner: team:agent-platform
tags: [agents, orchestration, decisions]
---
# Swarm Orchestration v2 Decisions

## Accepted Decisions

### 2026-08-31 - Improve the control plane before the roster

Do not add a persistent agent identity until utilization and missing-
responsibility evidence justify one. Improve mission state, events, handoffs,
preflight, evidence, and evaluation first.

### 2026-08-31 - Emon's registry remains canonical

Backoffice projects mission state and may later submit bounded operator intents.
It never writes Emon's registry directly. Mattermost, Boards, artifacts, and
telemetry remain collaboration/evidence surfaces.

### 2026-08-31 - Extend the shipped v1 baseline

Reuse `agent-execution-system-v2`, the v1 registry/steward, role-isolated
channels, read-only `/missions`, and the current telemetry program. Do not
create parallel mission or monitoring systems.

### 2026-08-31 - Event intake precedes event wake

An event is durably validated and deduplicated before any wake request. Source
redelivery must not repeat a wake or transition.

### 2026-08-31 - Backoffice controls express intent

Pause, resume, gate decision, and reassignment are requests applied by Emon's
transition engine. Backoffice shows pending state until a fresh canonical
snapshot confirms the result.

### 2026-08-31 - Delivered and verified are distinct

Specialist delivery is not mission acceptance. Verification requires explicit
evidence and a verifier allowed by the mission contract.

### 2026-08-31 - Reconciliation is silent recovery

Keep a low-frequency reconciliation path for missed events and stale leases.
It must not become a periodic status-posting or specialist-chasing loop.

### 2026-08-31 - Mission ids are not metric labels

Exact identity belongs in canonical state and safe trace/offline joins. Fleet
metrics use bounded phases, roles, outcomes, categories, and traffic sources.

### 2026-09-01 - Delivery adapters share the reviewed event client

`agent-skills` owns source-only role and delivery translation helpers beside
the canonical event contract. They cover coordinator, specialist, reviewer,
human-gate, Azure PR/build, and runtime deployment/smoke state. Each producer
class has an independent exact enable flag and fails open to its source system.
This does not select or activate the production event-ingress deployment
owner.

### 2026-09-03 - Continue the exact mission thread with a hybrid wake

The normal path targets Emon's verified Mattermost mission-thread session key,
including the registered `group` (private) or `channel` (public) peer kind.
If that run does not durably acknowledge the mission-scoped lease within one
minute, a separate Mission Watcher identity posts one idempotent wake-only reply
in the registered thread. Neither path carries event content or execution
authority. Raw session ids are non-canonical, and route mismatch never falls
back to Emon's main session.

Accepted actionable event to material next action has a twenty-minute service
target. Bounded recovery may occur before that threshold; one deduplicated
human alert is allowed after one hour. Reconciliation is zero-model and quiet
when no action exists.

Durable producer and dispatch outboxes are required. Existing missions are not
globally frozen during delivery. Promotion starts with a disposable synthetic
mission and then one light, reversible Backoffice task; Eagle Eye is excluded.

## Deferred Implementation Choices

### Event-ingress deployment owner

Choose between an Emon-adjacent swarm service and an existing internal
integration service during Spec 2 implementation. The accepted interface and
security properties are fixed; repository placement is not yet fixed.

### File registry versus database

Keep the JSON registry plus serialized event inbox for v2. Revisit a database
only when measured concurrency, volume, query, or recovery requirements exceed
the file-backed contract.

### Remaining timing defaults

Acknowledgement leases and event coalescing remain bounded configuration
selected from dogfood evidence. Continuation SLOs are fixed at one minute to
wake, twenty minutes to material next action, and one hour to human alert.

### Exact mission cost

Do not estimate currency from token counts until one canonical price/cost
source exists for the actual model route and time window.
