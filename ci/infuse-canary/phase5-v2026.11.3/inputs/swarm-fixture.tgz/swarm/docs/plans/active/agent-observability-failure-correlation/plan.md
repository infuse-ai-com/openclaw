---
title: Agent Failure Taxonomy and Turn Trace Correlation Plan
description: Plans the bounded classifier, curated turn trace, operator visibility, and Tinus-first production proof.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - agents
  - observability
  - telemetry
---

# Implementation Plan: Agent failure taxonomy and turn trace correlation

## Scope

The implementation spans `openclaw-k8s-swarm` for the plugin, telemetry
contract, collector dimensions, tests, container, and Tinus canary, plus
`grafana` for the operator panel. The two changes are independently reviewable;
the Grafana query is inert until the swarm signal exists.

## Current State

- Official diagnostics provide reliable model/tool lifecycle observations and
  generic tool error categories.
- The public `onDiagnosticEvent` subscription intentionally excludes trusted
  core events, so it cannot supply tool failure fields to a standalone plugin.
- The exact Codex `llm_input`, `after_tool_call`, and `agent_end` relays contain
  the same `runId` but omit the official diagnostic `trace`.
- The generic embedded path may expose trace context on model hooks, but the
  production Codex app-server path does not dispatch that model hook.
- The behavioral plugin currently parents only from immediate hook context, so
  every curated span becomes an unrelated root under the production path.

## Proposed Approach

1. Add pure, unit-tested modules for the closed failure taxonomy and bounded
   run-span state.
2. Start one plugin-owned `infuse.agent.turn` root and
   `infuse.model.call` child on `llm_input`, with `model_call_started` as a
   compatible fallback.
3. Classify `after_tool_call` errors from structured result fields first and a
   strictly bounded in-memory error/result text fallback second; never retain
   or log source text.
4. Resolve every curated behavioral span parent from the stored turn root for
   `runId`; close model/root spans after `agent_end`, shutdown, or eviction.
5. Add `infuse.agent.turn`, `infuse.model.call`, and
   `infuse.tool.execution` to the telemetry contract. Keep provider/model out
   of metric labels to avoid unnecessary series cardinality.
6. Add a Grafana classified-failure panel alongside the official failure panel.
7. Build the normal swarm image, canary Tinus, exercise known categories and a
   workflow/skill/wrapper/KB lifecycle, then query Langfuse for trace ancestry
   and privacy.

## Alternatives Considered

- **Rebuild OpenClaw/Codex to enrich native errors:** rejected by owner
  constraint; the public hook path provides a useful bounded taxonomy without
  changing the custom artifacts.
- **Export raw error messages to Langfuse/Loki:** rejected for privacy,
  cardinality, and secret-leak risk.
- **Depend on public diagnostic events:** rejected after exact-canary source
  verification proved that the public subscriber filters trusted core events.
- **Use only isolated official tool observations:** rejected because that does
  not repair one-tree behavioral drilldown. A bounded curated tool child is
  emitted, while official metrics remain the canonical fleet totals.
- **Join the official diagnostic trace:** unavailable on the exact pinned Codex
  path without rebuilding a custom artifact. The accepted no-bundle path is a
  separate curated trace with an explicit turn root.

## Data, API, Auth, And Deployment Impact

- New metadata-only spans: `infuse.agent.turn`, `infuse.model.call`, and
  `infuse.tool.execution`.
- No application API, user data, auth, RBAC, Secret, or external endpoint
  changes.
- Collector adds three bounded span dimensions.
- One new Grafana panel uses existing Prometheus access.
- Normal immutable swarm image rollout; no custom runtime package build.

## Verification Gates

- Pure classifier and run-span-store unit tests.
- Telemetry schema/fixture verification and privacy-negative fixtures.
- Repository unit tests, render checks, runtime/plugin smoke, and image build.
- Collector configuration validation.
- Grafana dashboard JSON/query verification.
- Tinus readiness, zero restart, plugin load, Mattermost connection, and skill
  provenance.
- Controlled Langfuse proof of one curated trace containing turn, model, tool,
  and all custom span families with no captured content.
- Collector outage/recovery equivalence.

## Rollback Or Disable Path

Restore Tinus or the fleet to the previous immutable image digest. The existing
collector and Grafana panel may remain; absent metrics render empty. No PVC reset
or credential change is required.

## Decisions

- Preserve official tool telemetry as canonical fleet totals.
- Emit every correlated tool completion; opaque failures use `unknown` rather
  than guessing.
- Use `runId` only as the bounded in-memory key for a plugin-owned trace; never
  emit it.
- Canary Tinus before sequential fleet rollout.

## Known Gaps

- Some non-exec native failures expose only a generic category and remain
  unknown without a future upstream diagnostic improvement.
- Official diagnostic spans remain separate from the curated turn trace until
  a future upstream public context-propagation change; no custom rebuild is
  justified for this operational view.
- Knowledge Base internal service spans remain a separate trace until a future
  reviewed W3C propagation slice.
