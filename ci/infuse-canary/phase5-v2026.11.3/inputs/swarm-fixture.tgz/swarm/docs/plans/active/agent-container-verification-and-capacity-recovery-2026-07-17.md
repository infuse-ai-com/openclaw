---
title: Agent container verification and capacity recovery
description: "Status: active Owner: Kapiteky Date: 2026-07-17."
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - plans
  - active
  - agent
  - container
  - verification
  - capacity
  - recovery
---
# Agent container verification and capacity recovery

Status: active  
Owner: Kapiteky  
Date: 2026-07-17

## Problem

The persistent developer and coordinator run as unprivileged Kubernetes pods. The shared image includes the Docker CLI but neither the Compose plugin nor a Docker daemon. Product instructions currently describe Docker tasks without distinguishing daemonless Compose validation from local container execution. That ambiguity caused malformed Compose calls, repeated retries of a known-unavailable daemon, and weak evidence about whether product images still build.

Separately, the coordinator did not recover a mission when the selected model reported capacity pressure. The configured agent primary was strict, so OpenClaw had no approved fallback candidate.

## Decisions

1. Keep the agent pods unprivileged and daemonless. Do not mount a Docker socket, add privileged Docker-in-Docker, or grant a remote Docker daemon.
2. Install a pinned Docker Compose CLI plugin so agents can render and validate Compose files without a daemon.
3. Add a machine-readable runtime capability probe. Container execution is `local` only when a daemon is reachable; otherwise image-build evidence is `ci_required`.
4. Give the coordinator and developer explicit OpenAI-backed model fallbacks: Terra to Sol for coordination, Sol to Terra for implementation.
5. Add a bounded, mission-scoped coordinator recovery contract for terminal capacity failures. It must never become a broad autonomous board sweep.
6. Give Finaxis and MarkdownGPT safe example-environment Compose validation, a capability-aware doctor, and a focused backend-test wrapper that sets cwd and test defaults without shell heredocs.
7. Add a shared Azure PR image-build gate using remote BuildKit and an OCI output. It validates Dockerfiles without deploying or granting Docker access to agent pods.

## Repository slices

- `openclaw-k8s-swarm`: Compose plugin, capability probe, toolbox smoke, model policy and deployment configuration.
- `openclaw-agents-persona`: coordinator capacity-recovery and command-evidence behavior.
- `fnx-poc-monorepo`: capability-aware tasks, safe Compose env substitution, focused backend-test wrapper, agent guidance.
- `md-poc-monorepo`: same product contract, plus a safe frontend example env file.
- `infrastructure`: optional PR BuildKit verification job enabled by both product pipelines.

## Acceptance criteria

- `docker compose version` succeeds in a rebuilt persistent-agent pod.
- The capability probe reports Docker CLI and Compose as available, Docker daemon as unavailable, and container builds as `ci_required` in the normal pod.
- Product `agent:container-check` validates Compose using committed example env files and succeeds without a Docker daemon.
- Product image changes receive an actual remote BuildKit build in PR validation; no deployment occurs from that stage.
- Coordinator and developer deployment configs use the documented `fallbacks` key and declare both permitted models.
- Model policy verification and Backoffice export agree with live configuration.
- Coordinator guidance retries or reroutes bounded capacity failures, cancels pending retries on progress, and escalates with evidence after exhaustion.
- All five repository PRs pass their proportional verification and are squash-merged before runtime rollout evidence is collected.

## Verification and rollout

1. Run repo-local verification and self-review for every slice.
2. Push branches and open PRs; use PR merge-ref builds as shared evidence.
3. Merge infrastructure before product PRs so the new template parameter exists.
4. Merge persona and swarm runtime changes, then wait for the runtime image rollout.
5. Run the live toolbox smoke for coordinator and developer.
6. Confirm live model config and capability JSON from both pods.

## Rollback

- Revert the product pipeline parameter to disable PR image verification if remote BuildKit capacity is unhealthy.
- Revert fallback arrays independently without changing primary model policy.
- Revert the Compose plugin/capability script image layer without affecting pod privilege or data.
- Persona recovery guidance can be reverted independently through the persona sync path.
