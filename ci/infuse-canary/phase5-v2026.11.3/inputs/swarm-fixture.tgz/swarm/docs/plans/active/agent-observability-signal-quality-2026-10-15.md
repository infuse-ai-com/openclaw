---
title: Agent Observability Signal Quality
description: Phased remediation of Langfuse noise, tool reconciliation, traffic attribution, and behavioral evidence visibility.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - observability
  - langfuse
  - opentelemetry
  - openclaw
---

# Agent Observability Signal Quality

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Accepted outcome

Keep the existing metadata-only observability stack, but make Langfuse useful
for meaningful turn investigation and make tool, traffic, skill, wrapper, and
Knowledge Base evidence honest enough for operational review.

Accepted by Fito on 2026-10-15. Production delivery follows the reviewed main
pipeline; no manual Kubernetes apply is part of this plan.

## Scope and non-goals

In scope:

- a reproducible aggregate-only live Langfuse audit;
- removal of the three singleton Gateway RPC envelope trace families from the
  Langfuse export branch while preserving span metrics;
- normalization of the conflicting Gateway RPC queue-wait metric description;
- canonical `bash` to `exec` tool naming on official and curated surfaces;
- pre-run to run traffic-source correlation;
- direct Codex visibility for the four high-value behavioral attribution tools;
- controlled canary, fleet rollout, privacy verification, and a seven-day soak.

Non-goals:

- Langfuse v4 migration, retention changes, or a replacement platform;
- prompt, response, command, tool argument/output, raw error, or retrieved
  content capture;
- inferred skill credit or autonomous skill/KB changes;
- OpenClaw/Codex core rebuild unless a public-hook limitation is proven to make
  an accepted gate impossible.

## Phases and gates

### Phase 0 — Rebaseline truth

- [x] Pin implementation to swarm `origin/main` revision
  `4c68228ad4d02161bf35d3ac7cf4b3a8163c1dfd`.
- [x] Add an aggregate-only live audit using project-scoped API credentials from
  environment variables.
- [x] Verify live collector metric names and preserve the monitoring namespace
  ownership boundary rather than widening RBAC.
- [x] Record the 2026-10-08 through 2026-10-15 baseline in
  `docs/evidence/2026-10-15-agent-observability-signal-quality.md`.

### Phase 1 — Remove export noise and collector conflicts

- [x] Split the trace pipeline so Langfuse can drop only the exact Gateway RPC
  envelope allowlist while span metrics still receive every trace.
- [x] Normalize the queue-wait metric description before Prometheus export.
- [x] Validate the rendered configuration with collector `0.159.0`.
- [ ] After rollout, prove at least 85% fewer new Langfuse traces in a comparable
  active window, no new description-conflict logs for 24 hours, and no exporter
  refusal/failure increase.

### Phase 2 — Restore canonical tool telemetry

- [x] Canonicalize both `bash` and `openclawbash` to `exec` in the behavioral
  plugin and collector defense-in-depth transform.
- [x] Extend the telemetry contract and tests.
- [ ] Run a controlled success, non-zero exit, validation failure, and dynamic
  tool call after canary rollout; compare official and curated aggregates.

### Phase 3 — Restore attribution

- [x] Preserve trusted ingress attribution by bounded session correlation until
  a run ID exists; no session or sender identifier is exported.
- [x] Keep `skill_execution`, `wrapper_execution`, `knowledge_retrieval`, and
  `knowledge_decision` directly model-visible under the Codex harness.
- [x] Preserve `agent-intake` as expected-idle; inactivity alone does not alert.
- [ ] Prove one human turn and one selected role-anchor skill lifecycle on Tinus,
  then one representative turn on each active role.
- [ ] Prove one legitimate Knowledge Base discover-to-fetch flow with matching
  authenticated service evidence, or record the exact external-service blocker.

### Phase 4 — Merge, roll out, and soak

- [ ] Complete full repository verification and self-review.
- [ ] Merge through Azure DevOps and monitor the main build/deploy pipeline.
- [ ] Verify Tinus first, then the existing parallel leaf wave, then Emon
  through the established canary-wave rollout contract; preserve expected-idle
  Ramiro semantics.
- [ ] Start a seven-day soak with daily aggregate checks for export health,
  privacy, meaningful turns, traffic attribution, tool reconciliation, and
  lifecycle completeness.
- [ ] Close this plan and reconcile the 2026-08-31 monitoring plan after the
  soak passes.

## Rollback

- Revert the merged source revision and let the main pipeline restore the prior
  collector/plugin image.
- If only the collector branch is faulty, revert `filter/langfuse_noise` and the
  split trace pipelines; agent behavior remains fail-open.
- If direct tool visibility or ingress correlation regresses a turn, revert the
  behavioral plugin revision and roll Tinus back before continuing the fleet.

No rollback deletes Langfuse history, Prometheus series, PVCs, Secrets, or
other live state.
