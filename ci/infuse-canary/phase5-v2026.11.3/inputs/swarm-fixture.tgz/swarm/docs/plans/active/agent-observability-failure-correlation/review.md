---
title: Agent Failure Taxonomy and Turn Trace Correlation Review
description: Reviews the bounded failure taxonomy, curated trace design, privacy invariants, and Tinus canary gates.
type: evidence
status: active
owner: team:agent-platform
tags:
  - evidence
  - agents
  - observability
  - review
---

# Requirements Review: Agent failure taxonomy and turn trace correlation

## Verdict

Ready for PR/CI and fleet delivery. No blocking owner decision remains.

## Checklist

- [x] Problem is stated from the operator and skill-owner point of view.
- [x] Acceptance criteria are observable in tests and the Tinus canary.
- [x] Non-goals explicitly preserve the custom OpenClaw/Codex bundles.
- [x] Agent turn, official diagnostic trace, curated turn trace, behavioral
  span, stable category, and correlation are defined.
- [x] Auth, data, API, deployment, privacy, and external effects are considered.
- [x] Tinus-first production and custom-artifact gates are visible.
- [x] Tasks are independently reviewable vertical outcomes.
- [x] Verification commands and runtime evidence are named.
- [x] Source artifacts and the mission thread are linked.

## Analysis Findings

- **Checked:** the exact canary's public diagnostic subscriber excludes trusted
  core events, so the implementation must not depend on it.
- **Checked:** the exact Codex `llm_input`, after-tool, and end hooks retain the
  same run ID while omitting official trace context. A bounded plugin-owned
  curated trace is the honest no-rebuild correlation path.
- **Checked:** public after-tool events expose structured result fields and a
  raw error/result fallback that can be inspected in memory, bounded to 4096
  characters, then discarded.
- **Accepted:** emit a correlated `infuse.tool.execution` behavioral view for
  drilldown, while official tool telemetry remains canonical for fleet totals.
- **Accepted:** emit `infuse.agent.turn` and `infuse.model.call` as the curated
  root/model lifecycle; provider and model remain trace attributes, not metric
  labels.
- **Follow-up:** W3C propagation into Knowledge Base service internals is useful
  but not required for the accepted agent-turn child-span outcome.

## Acceptance Invariants

1. No raw error or content field crosses the plugin boundary.
2. No run/session/channel/user identifier becomes an attribute or metric label.
3. Failure categorization never changes tool execution or returned results.
4. The official tool signal remains canonical for total calls and failures.
5. Unsupported cases remain unknown; the plugin does not guess.

## Tinus Evidence

- The final normal swarm image is immutable digest
  `sha256:c70c011c55a97e49db9653664539da8ddd50faeca5ebcffc4c8f3207d7f3e9d6`;
  it retains the existing pinned OpenClaw/Codex artifacts.
- Tinus remained Ready with zero restarts, connected Mattermost, reachable
  Gateway, and 25-skill provenance. The other four pod templates were
  unchanged during canary.
- One controlled turn exported 25 curated observations covering all seven
  required families. The turn root had no parent and every other curated span
  had that root as its direct parent.
- The controlled Knowledge Base rejection classified as `invalid_input`; the
  same trace contained 12 successful tool completions and one failed tool
  completion without raw error export.
- Langfuse contained no input/output payloads, forbidden attributes, or
  unexpected attributes for the curated trace. Prometheus projected the turn,
  model, and classified tool series with the reviewed dimensions.
- Span-metrics keys include the exact runtime, image, and skill-bundle
  revisions. The final scrape contained current-digest turn/model/classified
  failure series and zero stale curated series from the prior fleet digest.
- With the collector scaled to zero, the synthetic agent result remained
  successful. After restoration both workloads were Ready, a new complete
  content-free trace arrived, and the collector reported sent spans with no
  failed/refused span series.
