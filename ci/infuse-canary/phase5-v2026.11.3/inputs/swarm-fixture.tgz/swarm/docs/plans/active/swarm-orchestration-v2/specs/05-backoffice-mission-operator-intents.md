---
title: Spec 5 - Backoffice Mission Operator Intents
description: Authenticated pause, resume, gate-decision, and reassignment requests without making Backoffice a second mission writer.
type: architecture
status: active
owner: team:company-operations
tags: [agents, orchestration, backoffice, missions]
---
# Spec 5 - Backoffice Mission Operator Intents

## Outcome

Fito can express a bounded mission-control intent from Backoffice and see its
authoritative result without Backoffice writing Emon's registry or bypassing
mission transition rules.

## Authority Model

- Emon's registry remains canonical.
- Backoffice Postgres owns intent request, authorization, audit, expiry, and
  display state.
- The mission event intake transports accepted intents to Emon.
- Emon applies, rejects, or supersedes the intent against the current mission
  revision and approval contract.
- A fresh mission snapshot proves the resulting state.

## Supported Intents

### Pause mission

Requests that Emon move a non-terminal mission to a blocked/waiting state with
bounded reason `human_pause`. It does not cancel work or terminate running
external processes automatically.

### Resume mission

Requests that Emon restore a paused mission to its recorded prior active state
after checking unresolved blockers and gates.

### Decide gate

Approve or reject one named, currently pending mission gate. The intent carries
the gate id, expected mission revision, decision, and bounded optional note.
Approval of the mission gate does not bypass downstream system approvals such
as Azure branch policy, environment approval, RBAC, or secret provisioning.

### Request reassignment

Requests coordinator review of one non-terminal task. It never selects or
mentions a replacement agent automatically. Emon validates ownership,
capability, current evidence, and the target handoff before any reassignment.

## Intent Lifecycle

`pending -> accepted_for_delivery -> applied | rejected | expired | superseded`

Backoffice must not display the mission as changed while the intent is merely
pending or delivered. The UI shows both intent state and last canonical
snapshot revision.

## Authorization

- Company users may view missions.
- Only the reviewed operator role may create pause/resume/reassignment intents.
- Gate decisions require the gate's named authority; Fito remains the final
  human authority for boundaries assigned to him.
- Every server-side action is CSRF-protected, session-bound, rate-limited, and
  audited without storing session cookies or tokens.

## Concurrency And Safety

- Every intent names the expected mission revision and current gate/task id.
- Stale revision produces `superseded` or a conflict; it never applies to newer
  state silently.
- Repeated submission with the same idempotency key returns the original
  intent.
- Destructive, secret, access, DNS, firewall, external, and incomplete-
  verification actions remain outside these controls.
- Feature flags independently disable creation and delivery while preserving
  read-only mission display.

## User Experience

The `/missions` detail view shows:

- canonical source and freshness;
- mission revision and current state;
- next action, blockers, tasks, gates, and evidence;
- allowed actions based on role and state;
- confirmation copy describing what the intent does and does not do;
- pending/applied/rejected state with timestamp and actor; and
- an honest stale/unavailable state that disables control submission.

Pause/resume may use immediate confirmation. Gate rejection and reassignment
require a short bounded reason. No free-form secret-bearing operational payload
is accepted.

## Acceptance Criteria

- Backoffice cannot write, mount, or directly mutate Emon's registry.
- Unauthorized and stale-revision intents fail closed.
- Duplicate submission is idempotent.
- An applied state is shown only after a canonical snapshot at or beyond the
  expected resulting revision arrives.
- Pausing does not cancel external work automatically.
- Gate approval does not bypass independent approval systems.
- Read-only `/missions` remains available when intent delivery is disabled.
- Unit, integration, and authenticated browser tests cover every lifecycle
  outcome at desktop and mobile widths.

## Approval Gate

Implementation behind disabled flags is in scope. Production event-delivery
credentials, role grants, and enabling write-capable controls require explicit
activation approval after the read-only and event-intake contracts pass.

## Owning Repositories

- UI, Postgres intent model, authorization, and producer adapter: `backoffice`.
- Intake and Emon transition application: `openclaw-k8s-swarm` and
  `agent-skills`.

## Rollback

Disable intent creation and delivery flags. Preserve audit rows and read-only
mission projection. Pending intents expire; they are not silently replayed
after re-enable without operator review.
