---
title: Agent Execution System v2 Requirements Review
description: Pre-implementation analysis of the accepted agent execution system specification, plan, and tasks.
type: report
status: active
owner: team:agent-platform
tags:
  - agents
  - artifacts
  - backoffice
  - missions
  - orchestration
---
# Agent Execution System v2 Requirements Review

## Verdict

The program is startable in reviewed vertical slices. The company and runtime
sources already contain partial building blocks, so implementation should adapt
them instead of creating parallel mission, channel, or artifact systems.

## Checked

- Owner decisions are explicit for authority, channel roles, Kapiteky
  membership, mission-source placement, artifact visibility, retention, and
  assignment-trigger behavior.
- Kapiteky's non-member private-channel read ability was live-proven without
  exposing post contents.
- The coordination channel already exists with exactly Fito, Kapiteky, and
  Emon.
- The existing dispatcher source and deferred Artifact Registry proposal were
  inspected before planning replacements.
- Production secrets, RBAC, PVC, and deployment activation remain visible
  gates rather than hidden implementation steps.

## Issues Resolved During Implementation

- Repository docs described one coordinator thread plus separate role threads
  in the same developer-log channel; the active contract now uses private
  project-role channels and one top-level thread per task.
- `mission_create.py` was board-item-specific; the new mission registry helper
  now represents due and triggered next actions without inventing board work.
- The old dispatcher prompt allowed stale handoff reminders and broad lane
  shaping; its installer is now a compatibility alias for the registry steward.
- The Backoffice registry proposal was explicitly reactivated while preserving
  the old artifact system as authoritative until cutover evidence passes.

## Follow-Up

- Immediate event-driven steward wake-up may replace or supplement the cron
  after the mission event contract is proven.
- Selected artifact types may later create proposed tasks, but v1 records only
  the intended consumer.
- Object storage may replace the initial PVC through the storage adapter.

## Implementation Evidence

- `company-docs` verification passed after the authority, mission, Backoffice,
  and decision sources were updated.
- `openclaw-agents-persona` verification passed after Emon and specialist
  contracts were updated.
- Mission-registry lifecycle, active-project WIP, snapshot, and deduplicated
  steward tests pass in `agent-skills`.
- Backoffice's full 83-test suite passed; the new mission projection and
  Artifact Registry tests cover fail-closed parsing, multi-file publication,
  producer binding, shared authenticated reads, path/MIME limits,
  idempotency, exact lifecycle, ordinary tombstones, and journal reuse.
- Backoffice production build includes `/missions`; desktop and 390 px browser
  smokes rendered the validated mission fixture without horizontal overflow.
- The gated Artifact Registry Kustomize base renders with a placeholder image,
  read-only root filesystem, dedicated PVC, dedicated auth Secret reference,
  and no service-account token.
- Live private channel membership was verified as Fito + Emon + the relevant
  specialist, with Kapiteky absent and system-admin non-member read returning
  HTTP 200. No assignment was posted.

## Hidden External Effects Review

- Channel creation/membership: authorized by Fito's accepted topology, but live
  membership must be verified and the canonical registry updated.
- Secret and credential creation: not yet authorized at exact-value/action
  level; code and placeholder manifests may proceed, activation stops.
- Production deployment: requires reviewed PR/build/runtime gates and explicit
  approval where the existing governance contract requires it.
- Permanent deletion: no destructive live proof is included until a dedicated
  disposable artifact is approved.

## Requirements Checklist

- [x] Problem is stated from the human and operating-system perspective.
- [x] Acceptance criteria are observable.
- [x] Non-goals are explicit.
- [x] Authority, mission, artifact, and event vocabulary is defined.
- [x] Auth, data, API, deployment, and external effects are covered.
- [x] Approval gates are visible.
- [x] Tasks are vertical and independently reviewable.
- [x] Verification and evidence expectations are named.
- [x] Existing source-of-truth artifacts are linked.
