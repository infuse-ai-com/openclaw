---
title: Isolated worker prototype and production adoption proposal
description: Records synthetic browser, build and media isolation evidence and the concrete decisions required before persistent agents use workers.
type: plan
status: active
owner: team:agent-platform
tags: [agents, security, workers, architecture]
sources:
  - ref: runtime-security-phased-plan-2026-11-13.md
    role: authority
---
# Isolated workers — P6 outcome

## Delivered boundary

The [qualification receipt](../../evidence/2026-11-13-security-worker-prototype.json)
records three serial, disposable native AMD64 Jobs on 13 November. Browser,
compiler and media processing run in separate pods from persistent agents.
There are no agent PVCs, secret volumes, credential environment variables,
Docker sockets or mounted service-account tokens. The runtime stays UID 10001,
drop-ALL, no privilege escalation, read-only root, bounded emptyDir storage.
Only the browser uses the already installed Chromium seccomp profile.

The existing authenticated operator Kubernetes API is the private control and
artifact channel. No unauthenticated listener, agent submission permission,
new service account or RBAC grant was introduced. Image pull uses the existing
registry pull-secret reference; its value is never mounted into the worker.

A temporary deny-all ingress/egress NetworkPolicy selected only each run's
unique prototype label. The controller refused a label already selecting pods.
All three workers failed bounded TCP connections to the Kubernetes service,
metadata address and external test address; loopback browser fixtures worked.
A credential-free control pod could reach Kubernetes TCP 443 without that
policy. This establishes the tested policy difference, not exhaustive proof
against every CNI bypass. No request was sent to a metadata API.

## Functional and negative evidence

- Browser: Chromium 153.0.8010.12 under Playwright 1.63.0; actual PID/network
  namespace and seccomp sandbox diagnostics; no `--no-sandbox`; screenshot,
  download and synthetic task-cookie transfer between disposable contexts.
- Build: compile and execute a tiny local C fixture without network or daemon.
- Media: the declared ImageMagick tools produce PNG, JPEG and contact sheet;
  Poppler reads a tiny synthetic PDF. An initial test wrongly assumed Pillow
  was installed; the fixture was corrected without changing runtime capabilities.
- Isolation: a synthetic host-only file and operator environment canary remain
  unavailable; the API token, agent workspace and Docker socket are absent.
- Artifacts: allowlisted flat names only, regular files opened without following
  symlinks, 1 MiB total cap, base64 validation and SHA-256 verification. Unit tests
  reject path traversal, altered hashes, oversized bundles and symlinks. No tar
  extraction or executable artifacts reach the operator.
- Cleanup: successful Jobs are deleted immediately. Failure cleanup tolerates
  TTL deletion and still attempts remaining resources. All owned resources from
  the final run are deleted; the first failed run's leftovers were also removed.

`scripts/security-worker-prototype.py` defaults to render-only. Its explicit
`--execute` mode is an operator qualification tool for these synthetic fixtures,
not a generic command-execution service or production task router. The original
receipt uses the exact qualified P2 toolbox image. All three worker fixtures also
pass on the corrected Trixie release; the [combined release receipt](../../evidence/2026-11-13-security-p4-p5-qualification.json)
records that rerun and cleanup. Minimal production worker images remain a design task.

## Resource budget

One Job at a time; each requests 100 millicores / 128 MiB and limits 2 CPUs /
2 GiB, 300 seconds, 256 MiB `/tmp`, and 256 MiB memory-backed shared storage.
The worst-case three-job envelope is 15 wall-clock minutes, 30 CPU-minutes and
30 GiB-minutes, plus image-pull/node overhead. The final successful run took
less than one minute. Existing cluster capacity was used, with no paid resource
created. These are bounds, not a production cost estimate or capacity promise.

## Proposed production design — decision still required

1. **Submission and identity.** A narrow broker validates agent ID, task ID,
   approved operation, immutable image, resource budget and input hashes. Use
   short-lived audience-bound authentication and an audit receipt. Prefer broker
   ownership of Job creation over giving every agent arbitrary Kubernetes exec
   or Job privileges. Define quotas and cancellation before granting access.
2. **Network.** Default deny; route browser HTTP(S) through an allowlisted egress
   proxy with DNS-rebinding and metadata/internal-address defenses. Build jobs
   use approved dependency mirrors; media jobs usually need no egress. Render
   exact policies and test them before adoption. The prototype's deny-all policy
   does not provide a working Internet browsing service.
3. **Sessions.** Deliver only task-specific browser session material, encrypted
   for its worker, with explicit destination, expiry and deletion. Never mount
   the agent's general browser profile, Vaultwarden session or GitLab token.
   Define whether refreshed cookies may return; require explicit provenance and
   size/schema checks. The synthetic cookie test is not real account acceptance.
4. **Browser protocol/UI.** Keep the browser client and worker protocol versions
   paired. The prototype uses the same Playwright/Chromium build and P3 supplies
   native OpenClaw evidence, but the native browser panel is not routed remotely.
   Qualify remote CDP/control, downloads, screenshots, cancellation, session
   renewal and browser-panel status before changing agent routing.
5. **Artifacts and supply chain.** Use small signed worker images, provenance and
   per-operation SBOMs. A production artifact service needs a hard streaming
   response limit, content/type checks, retention and audit ownership. Treat
   outputs as untrusted data; never auto-execute returned binaries or HTML.
6. **Rollout and ownership.** Satwa owns isolation/runtime; Tinus owns broker and
   adapters; Stewie validates browser-panel behavior. First adopt one browser
   operation on Tinus with the existing runtime as an explicitly reviewed
   rollback. Do not silently fall back to unsandboxed same-pod execution. Only
   after accepted routing/capability discovery should packages leave the agent
   image. Ruby remains unavailable locally under P2's existing contract.

Fito's six-phase instruction authorized this nonproduction prototype and proposal.
Production adoption, exact new permissions/policies/session delivery, persistent
services and any added resource spend remain a separate concrete decision.

## Rollback and remaining risk

The prototype changes no production routing and leaves no long-lived workload.
Its rollback is deletion of its uniquely named temporary resources. This does
not remove the existing same-pod browser/credential exposure; P3 sandboxing is
defense in depth until worker adoption is separately qualified and approved.
