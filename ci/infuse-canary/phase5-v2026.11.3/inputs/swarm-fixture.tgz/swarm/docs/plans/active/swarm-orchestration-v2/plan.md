---
title: Swarm Orchestration v2 Implementation Plan
description: Dependency-ordered multi-repository plan for implementing all six accepted orchestration specifications.
type: plan
status: active
owner: team:agent-platform
tags: [agents, orchestration, delivery]
---
# Swarm Orchestration v2 Implementation Plan

## Scope

Deliver the six component specifications through small reviewed branches and
PRs. Complete one dependency slice before beginning its dependent slice. Reuse
the existing `agent-execution-system-v2` and Monitoring Truth implementations.

## Delivery Sequence

```text
Spec 1: canonical control plane
        |
        +--> Spec 3: handoff + capability preflight
        |
        +--> Spec 2: event-driven steward
                    |
                    +--> Spec 5: Backoffice intents
                    |
                    +--> Spec 4: mission telemetry
                                |
                                +--> Spec 6: full canary suite
```

Spec 6 pure fixtures begin alongside each implementation slice, but the full
live canary is last because it requires all contracts.

## Phase 0 - Preserve Baseline And Prove Routes

- Record the existing v1 registry, quiet steward, `/missions`, telemetry, and
  behavior-canary baseline without freezing unrelated missions.
- Review this package for contradictions and hidden activation effects.
- Prove exact Mattermost-thread session resolution and targeted wake behavior
  on the pinned OpenClaw runtime; wrong or missing routes must fail closed.
- Publish a reviewable docs branch before behavioral implementation diverges.

Gate: all requirements are observable, repository ownership is explicit, and
no material open decision blocks Spec 1.

## Phase 1 - Canonical Mission Control Plane

Primary repository: `agent-skills`.

- Implement schema/transition library and CLI v2.
- Add file locking, optimistic revision checks, processed-event idempotency,
  evidence/gate/lease records, and explicit v1 migration.
- Keep v1 snapshot reader compatibility in Backoffice.
- Update swarm source catalog only after the skill PR merges.

Gate: exact-backup migration, complete transition fixtures, concurrent-writer
proof, and canonical repository verification.

## Phase 2 - Handoff And Capability Preflight

Primary repositories: `agent-skills`, then `openclaw-k8s-swarm`.

- Add machine-readable handoff v2 schema/renderer/validator.
- Add static preflight against skill catalog, bundle, repository policy, task
  workspace limits, and declared verification capabilities.
- Add bounded runtime probes only where configuration cannot prove capability.
- Run report-only against one task for each persistent role before enforcement.

Gate: no specialist mention occurs in enforcement fixtures when required
capability is missing; successful preflight contains no sensitive data.

## Phase 3 - Event-Driven Steward

Primary repositories: `agent-skills`, `openclaw-k8s-swarm`.

- Add event schema/client and local inbox processor.
- Implement durable producer outboxes, idempotent intake, mission-scoped
  coalescing, wake leases, dispatch outbox, fake adapters, and reconciliation.
- Target Emon's existing Mattermost thread session first; use one idempotent
  Mission Watcher thread reply after one minute when that path does not start.
- Add one source adapter at a time; keep every adapter independently disabled.

Gate: duplicate/burst/failure/restart/session-roll fixtures pass; one live
non-production event wakes the same Emon mission lane once; accepted event to
run start is at most one minute, material next action is durable within twenty
minutes, and no-action reconciliation stays silent. One deduplicated alert is
permitted only at one hour.

Activation gate: production ingress authentication, Secrets, NetworkPolicy,
ServiceAccount, RBAC, and producer enablement require exact approval.

## Phase 4 - Mission Correlation And Metrics

Primary repositories: `openclaw-k8s-swarm`, `grafana`.

- Extend the telemetry contract and plugin/client emission.
- Add deterministic fixtures and forbidden-field/cardinality tests.
- Add recording rules, dashboards, and alerts after baseline thresholds are
  reviewed.
- Produce one exact mission-level offline/Backoffice join report.

Gate: registry aggregates and telemetry reconcile; mission/task ids never
become metric labels; outage remains fail-open.

## Phase 5 - Backoffice Operator Intents

Primary repository: `backoffice`.

- Add database model, authorization, API, audit, expiry, and disabled producer.
- Add `/missions` controls with canonical-state confirmation.
- Integrate with event intake only after Phase 3 activation is accepted.
- Keep read-only display independent.

Gate: full Backoffice verification and authenticated browser evidence; stale,
duplicate, unauthorized, rejected, applied, expired, and superseded fixtures.

Activation gate: production role grants and event-delivery credential require
explicit approval.

## Phase 6 - Orchestration Canary And Promotion

Primary repository: `openclaw-k8s-swarm`, with fixtures in owner repos.

- Build one PR-safe deterministic orchestration suite.
- Add simulated runtime adapters and mutation tests.
- Run a disposable live canary on the exact candidate revisions.
- Then run one small reversible Backoffice task as the first real mission;
  Eagle Eye is explicitly outside this canary.
- Promote runtime changes Tinus first, then Satwa, Stewie, Emon, and Ramiro when
  the changed surface applies fleet-wide.
- Complete one real mission and compare coordination/outcome measures.

Gate: all scenarios pass, cleanup is complete, runtime health and privacy are
green, and the real mission closes with verified evidence.

## Verification Matrix

| Repository | Canonical gate |
| --- | --- |
| `agent-skills` | `scripts/verify.sh` |
| `openclaw-k8s-swarm` | `task verify` and `AGENT_ID=agent-coordinator task verify-ci` where appropriate |
| `backoffice` | `task verify`, focused unit/integration tests, authenticated Playwright |
| `grafana` | repository dashboard/rule validators and live bounded query proof |
| `company-docs` | `scripts/verify.sh` after proven durable decision updates |
| `openclaw-agents-persona` | repository persona/source validation when behavior text changes |

## Branch And Release Policy

- One reviewable branch/PR per owner-repository slice.
- Merge shared contracts before consumer changes.
- Squash merge and delete source branches after success.
- Do not merge `openclaw-k8s-swarm` main unless a live fleet deploy is intended
  and approved; use docs-only CI suppression only when repository policy
  explicitly permits it.
- Stop rather than accept failed/incomplete verification.

## Rollback Strategy

- Every source change has a feature/config disable independent of data restore.
- v1 mission state and read-only projection remain available through migration
  acceptance.
- Event intake is optional and fail-open to source systems.
- Backoffice controls disable independently from mission display.
- Telemetry and alerts disable independently from mission execution.
- Canary failures leave production on the last accepted revisions.

## Known Gaps

- Exact event-ingress deployment owner and authentication mechanism will be
  selected during Phase 3 from existing internal-service patterns.
- Exact acknowledgement and reconciliation timing defaults require baseline
  evidence; configuration will be bounded and tested rather than hard-coded in
  this spec.
- Mission-level cost reporting waits for one canonical cost source.
