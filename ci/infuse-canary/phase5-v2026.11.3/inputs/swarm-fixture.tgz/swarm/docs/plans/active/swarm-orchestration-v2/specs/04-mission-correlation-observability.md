---
title: Spec 4 - Mission Correlation And Orchestration Metrics
description: Privacy-safe correlation from mission intent through task execution and verified outcome, with bounded orchestration metrics and alerts.
type: architecture
status: active
owner: team:agent-platform
tags: [agents, orchestration, observability, metrics]
---
# Spec 4 - Mission Correlation And Orchestration Metrics

## Outcome

The team can determine whether orchestration produces verified outcomes with
less delay, noise, rework, and human intervention—not merely whether tools ran.

## Existing Baseline

Official OpenClaw telemetry is canonical for run/tool count, outcome, and
duration. The curated trace owns bounded turn-scoped semantic drilldown. The
current contract already defines traffic-source segmentation, trace integrity,
anomaly events, failure taxonomy, explicit workflow/skill/wrapper lifecycles,
and privacy/cardinality rejection.

## Correlation Model

One mission context is propagated across:

```text
mission -> task -> handoff revision -> agent turn -> tools
        -> pull request -> policy build -> deployment -> smoke -> verification
```

Mission and task identity must not become Prometheus labels. The implementation
uses:

- bounded mission phase, role, event, outcome, and waiting-category labels for
  metrics;
- backend-safe trace correlation attributes or a one-way correlation token for
  Langfuse drilldown;
- durable source pointers in mission evidence; and
- an offline/Backoffice join for exact mission-level review.

If an integration cannot propagate a safe correlation value, it reports
`correlation_state=unavailable`; timestamps and agent names are not treated as
proof of exact linkage.

## New Semantic Signals

### `infuse.mission.transition`

Required bounded attributes:

- mission phase before and after;
- transition outcome;
- actor class (`human`, `coordinator`, `specialist`, `system`);
- trigger class;
- traffic source;
- correlation state.

### `infuse.task.transition`

Required bounded attributes:

- task role;
- task state before and after;
- transition outcome;
- wait/block category when applicable;
- verification class;
- traffic source;
- correlation state.

### `infuse.orchestration.event`

Required bounded attributes:

- event kind;
- intake outcome (`accepted`, `duplicate`, `rejected`, `coalesced`);
- producer class;
- wake outcome;
- bounded rejection code.

No signal contains mission title, task title, user id, channel id, post id,
repository path, PR URL, command, raw error, or content.

## Derived Measures

The first reviewed measures are:

- accepted events and duplicate rate;
- steward wakeups per material event;
- reconciliation wakeups with no action;
- assignment-to-acknowledgement time;
- acknowledgement-to-delivery time;
- waiting and blocked duration by bounded category;
- delivery-to-verification time;
- revision/rework count;
- tasks delivered versus independently verified;
- human approval and intervention count;
- coordination posts per material transition;
- agent wakeups without resulting material transition;
- elapsed time and model/tool use per verified outcome; and
- mission closeout evidence completeness.

Cost is reported only when a canonical cost source exists. Token counts are not
converted to money through guessed pricing.

## Alerts

After baseline review, add minimum-volume alerts for:

- event intake unavailable or persistent rejected-event spike;
- accepted events without steward processing beyond the bound;
- duplicate wake amplification;
- reconciliation repeatedly waking with no action;
- task acknowledgement lease expiry;
- mission snapshot lagging canonical registry revision;
- required task delivered but never reviewed; and
- agent/relay/collector/missing-telemetry failures already owned by Monitoring
  Truth and Alerts.

Alerts link to bounded runbooks and aggregate drilldown. They never expose
mission content or identifiers in notification text.

## Acceptance Criteria

- Controlled events produce exactly one matching transition signal.
- Mission and task identifiers are absent from metric labels and forbidden
  telemetry fields.
- A controlled mission can be joined exactly across registry evidence and
  Langfuse without timestamp-only inference.
- Dashboard values reconcile with canonical registry/event aggregates for the
  same window.
- Startup, smoke, automation, and human traffic remain separately filterable.
- One duplicate storm, stuck event, expired lease, and snapshot-lag condition
  fires and clears the intended alert in tests.
- Telemetry outage changes no mission transition or agent result.

## Owning Repositories

- Contract and emission: `openclaw-k8s-swarm`.
- Skill marker guidance where explicit: `agent-skills`.
- Dashboards, recording rules, and alerts: `grafana`.
- Exact mission outcome review: Backoffice read model or approved offline
  aggregate tool.

## Rollback

Disable new emission and dashboard rules independently. Mission processing
continues. Preserve existing official/curated telemetry contracts.
