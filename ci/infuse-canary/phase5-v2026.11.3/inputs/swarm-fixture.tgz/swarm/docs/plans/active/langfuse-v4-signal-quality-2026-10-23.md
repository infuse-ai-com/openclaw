---
title: Langfuse v4 Signal Quality
description: Deliver one privacy-safe, operationally useful Langfuse trace per meaningful OpenClaw turn while preserving Prometheus truth.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - observability
  - langfuse
  - opentelemetry
  - openclaw
---

# Langfuse v4 Signal Quality

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Authority and boundary

Fito approved implementation, merge, and normal pipeline rollout of phases 1
through 4 on 2026-10-23. The delivery must remain on the official OpenClaw
package. If an accepted gate requires an OpenClaw core patch or custom package
build, stop and return for a separate decision.

Production delivery follows the reviewed Azure DevOps pipeline. No manual
Kubernetes apply, secret change, RBAC expansion, historical deletion, or
retention change is part of this mission.

## Outcome

Langfuse should present one coherent, metadata-only trace for each meaningful
agent turn. It should retain useful model, tool, skill, wrapper, workflow,
Knowledge Base, failure, retry, and latency evidence without background
singletons or duplicate official/curated call trees.

## Acceptance criteria

- Comparable activity produces no more than 20 Langfuse traces per day instead
  of the 59-trace 2026-10-22/23 baseline.
- A controlled turn resolves to one canonical curated trace containing exactly
  one `infuse.agent.turn` root and its metadata-only child observations.
- Controlled run and tool aggregates reconcile exactly after canonicalization.
- At least 95% of meaningful controlled turns have a bounded traffic source.
- At least 95% of tool failures have an actionable bounded failure category.
- Model usage is represented as a generation with token usage and either a
  calculated cost or an explicit `unpriced` classification.
- No prompt, response, system prompt, tool argument/output, retrieved content,
  raw error, sender identity, or conversation identifier is exported.
- Prometheus span metrics retain the spans removed from the Langfuse branch.

## Baseline

The 2026-10-16 through 2026-10-23 aggregate review found 1,581 observations in
1,122 traces. Of those traces, 1,074 were singletons. The latest 24-hour window
contained 59 traces, 39 of which were low-value singletons: 29 memory-pressure,
five message-processed, and five model-usage traces. The same window exposed a
useful Studio retry storm: 39 failures from 42 whiteboard apply attempts.

Content capture was zero across all reviewed observations. Collector health was
1/1 Ready with no restart or exporter-error evidence. These privacy and health
properties are release gates, not trade-offs.

## Delivery phases

### Phase 0 — Reproducible truth and design

- [x] Record the approved mission and the current aggregate-only baseline.
- [x] Confirm live that the OpenClaw 2026.10.3 hook trace context is diagnostic
  correlation, not the exporter-owned OTel trace context.
- [x] Extend the aggregate audit so trace shape, singleton families, semantic
  types, token/cost state, and bounded failure coverage are reproducible.

### Phase 1 — Remove Langfuse-only background noise

- [x] Drop `openclaw.memory.pressure` only from the Langfuse export pipeline.
- [x] Preserve existing Gateway RPC and diagnostic filters.
- [x] Prove the Prometheus span-metrics pipeline still receives the unfiltered
  trace stream and collector validation passes.

### Phase 2 — Canonical trace hierarchy

- [x] Keep `infuse.agent.turn` as the canonical parentless Langfuse trace root.
- [x] Remove all official `openclaw.*` spans from only the Langfuse branch;
  preserve them in the Prometheus span-metrics branch.
- [x] Map turn, model, tool, and retrieval observations to Langfuse v4 semantic
  types without exporting content.
- [ ] Prove one controlled turn appears as exactly one trace with no orphaned
  curated observations.

### Phase 3 — Insight enrichment and bounded aggregation

- [x] Classify trusted user/external-user channel runs as `human` without
  requiring the sender to be the workspace owner.
- [x] Normalize actual-name official tool spans and `bash`/`openclawbash` to
  `exec` before metrics extraction.
- [x] Aggregate repeated Studio whiteboard apply attempts into one logical tool
  observation with attempt, retry, error, and bounded failure-category counts.
- [x] Attach model identity and token usage from the public `llm_output` hook to
  both native and synthetic Langfuse generations; mark internal model aliases
  explicitly `unpriced` until a reviewed price exists.
- [x] Preserve Knowledge Base observations in the same trace and classify them
  as retrievers.

### Phase 4 — Operational views and soak

- [x] Ship version-controlled view definitions and a repeatable aggregate audit
  for actionable failures, slow/incomplete turns, tool reliability, model
  usage/cost state, and skill/Knowledge Base outcomes.
- [ ] Roll Tinus first, then leaf agents, then Emon through the existing pipeline
  and canary-wave contract.
- [ ] Run controlled success/failure/retry/KB interactions and preserve
  aggregate-only evidence.
- [ ] Start a seven-day daily validation window and close the superseded 2026-10-15
  observability plan when all gates pass.

## Stop gates

Stop or roll back on any content capture, Prometheus metric loss, collector
export refusal/queue growth, missing or duplicated controlled turns,
double-counted cache cost, material agent latency/behavior regression, or a
requirement to build a custom OpenClaw package.

## Rollback

Revert the merged source revision and let the normal main pipeline restore the
prior collector/plugin image. Collector-only regressions can be isolated by
reverting the Langfuse branch processors. No rollback deletes Langfuse history,
Prometheus series, PVCs, Secrets, or other live state.
