---
title: Mattermost separate progress and final canary
description: Defines the scoped agent-developer canary for OpenClaw's separate Mattermost progress and final delivery lifecycle.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - mattermost
  - openclaw
  - canary
  - kubernetes
---

# Mattermost Separate Progress/Final Canary

## Goal

Prove the OpenClaw Mattermost `finalDelivery: "separate"` feature against the
live `agents-swarm` runtime, then promote the verified exact-head runtime to
the complete persistent-agent fleet. Fito approved this rollout on 2026-09-06,
including advancing Tinus directly to the new candidate instead of restoring
an older runtime first.

## Source and artifacts

- OpenClaw fork: `aolea/openclaw`
- Feature commit: `0270094e6c250664df62ea88446d360ef3723d37`
- Prerelease tag: `canary-mattermost-separate-progress-0270094e-r1`
- Core version: `2026.9.2`
- Core SHA-256: `b8393e70c8e8cf12592217a4b0b89f51cf5142bc2eb852e2d94c5807ee2653ef`
- Mattermost plugin SHA-256: `9a95e9b253188f5720d9332165413125db33cabbe2de3b78d7ffc097aa6f38a8`
- ACPX plugin SHA-256: `9f360e5381a4e2c76ed8fb173920ea53a5597f08e257e52200a7b7c8c70f6cd4`
- Codex and diagnostics plugin version: `2026.9.2`
- Codex CLI version: `0.153.4`

Azure BuildKit downloads the exact core, Mattermost, and ACPX tarballs, verifies
their hashes, and installs them into one private Harbor canary image. The plugin
tarballs use the repository's canonical package-local runtime builder; the core
tarball uses OpenClaw's canonical self-contained Docker packer. All artifacts
passed their canonical integrity checks and an isolated Node 24 install smoke.
The image records the exact feature commit in
`openclaw.infuse-ai.com/source-revision`.

## Canary attempt record

- Azure build `4806` produced the first exact-head image, but its Mattermost
  tarball contained stale package-local `dist` output and the gateway failed on
  the removed `openclaw/plugin-sdk/runtime-doctor` export. The deployment was
  rolled back immediately without deleting or rewriting persistent state.
- The exact-head startup migrated the shared SQLite state schema. The older
  canary cannot read that newer schema and restart-loops after rollback. The
  corrected exact-head `r2` image is therefore the non-destructive recovery
  path; do not attempt another in-place downgrade without a compatible state
  snapshot or a verified schema rollback procedure.
- The canary was refreshed to `6dbab62b` after ClawSweeper found that an early
  turn failure could settle before any progress post existed. This revision
  creates a typed terminal progress post in that path and adds transport-level
  regression coverage; live evidence must include this early-failure case.
- The first `6dbab62b` image used raw `npm pack` after building plugin `dist/`
  output. That omitted OpenClaw's generated `runtimeExtensions` metadata, so
  Node resolved the TypeScript source entries under `node_modules` and refused
  to load Mattermost, Codex, and ACPX. The `r2` artifacts use the canonical
  `scripts/plugin-npm-publish.sh --pack` path and advertise compiled runtime
  entries explicitly.
- The PR was then refreshed to mergeable head `fd719232` after upstream moved;
  that exact-head canary supplied the successful live UI and transport trace.
- ClawSweeper's next review identified a public Plugin SDK surface expansion and
  an account-streaming compatibility risk. Head `5e732dfc` keeps strict cleanup
  private to Mattermost, restores legacy account replacement semantics, and is
  the exact revision used for the final canary rebuild and review evidence.
- ClawSweeper then identified a late-warning lifecycle regression. Cleanly
  rebased head `6a47d328` latches successful separate final delivery before
  cleanup, so a later tool warning remains separate and cannot recreate a typed
  `Failed.` progress post.
- ClawSweeper's following review found the same invariant was missing when the
  accepted final arrived through source-routed/message-tool delivery. Exact head
  `6b09485f` records successful delivery before clearing typed progress at that
  ingress boundary. The boundary regression failed before the fix and passes
  after it, including a simulated late turn failure with no recreated `Failed.`
  progress post. This is the exact revision for the refreshed canary.
- The canary branch also contains the current safe runtime baseline from swarm
  main `0ec48fc`; only `agent-developer` remains in deployment scope.
- Upstream moved again while the canary was being prepared. Merge head
  `1230e82a` resolves the two generated-only conflicts through canonical
  regeneration, adopts upstream's safer default that hides raw command text,
  and keeps the boundary test explicit with `commandText: "raw"` where command
  text is required for that test's assertions.
- Azure build `4887` failed before package use when Docker Hub returned HTTP 500
  for the unchanged Node 22 base image. Retry build `4889` verified every
  artifact digest but correctly rejected the earlier plain-packed core tarball:
  it retained an unresolved `@openclaw/ai` workspace dependency. Neither build
  deployed anything. The final `1230e82a` core artifact uses the canonical
  self-contained Docker packer and passed the exact Node 22 install smoke.
- ClawSweeper then found that a provider-accepted partial final could still be
  followed by typed `Failed.` progress. Head `82dccdb8` latches that accepted
  delivery before cleanup, preserves the partial-delivery receipt if cleanup
  also fails, and includes both boundary and full-turn regressions. It is
  merged with current OpenClaw main `877e9831`; all four exact-head packages
  passed integrity checks and an isolated Node 22 install/runtime-entry smoke.
- ClawSweeper's next review found that the partial-delivery catch also covered
  progress quiescing, allowing an accepted progress post with an unreadable
  receipt to be misclassified as the final before the final sender ran. Head
  `ae8b87f3` isolates the final sender boundary, proceeds with the final only
  for an accepted partial progress receipt, and settles an actual final-send
  failure as failure. The helper and full-turn regressions failed before the
  fix and pass after it. This head includes upstream main `8e54d696e`; all four
  exact-head packages passed integrity checks and an isolated Node 22
  install/runtime-entry smoke.
- Upstream then advanced through shared delivery/runtime owners. Merge head
  `010d5554` includes main `6e851103d` without changing the Mattermost repair.
  The canary was rebuilt from this exact integrated head so its live evidence
  covers both the lifecycle fix and the current shared delivery boundaries.
  All four packages passed integrity checks and the isolated Node 22
  install/version/runtime-entry smoke.
- On 2026-08-25 the PR was cleanly rebased to `3d1a6e419` on OpenClaw main
  `8160c6e90`. The refreshed source preserves sender-scoped debounce and
  pre-debounce typed-post suppression, passed 303 focused tests, all 801
  Mattermost tests, the canonical changed-scope gate, and a clean Sol
  autoreview. All four refreshed packages passed canonical integrity checks
  and an isolated Node 22 install/version/runtime-entry smoke.
- Azure build `5706` / `20260825.1` produced the first refreshed image. Its
  core/plugin loader rejected the copied bundled Codex path, and the upgraded
  state schema prevented an unsafe downgrade to the older image. The PVC and
  upgraded state were preserved.
- Azure build `5711` / `20260825.2` loaded Codex from its exact global package
  path and passed an image-level loader gate, but startup exposed a shell
  defaulting bug that treated an explicitly empty plugin requirement list as
  unset and attempted to install an unpublished package.
- Azure build `5712` / `20260825.3` fixed the empty-list contract and its
  regression test. Live startup then exposed two packaging-only issues: stale
  Codex install metadata required one supported local link, and the copied
  bundled Mattermost runtime hit Node's ESM/CommonJS WebSocket boundary only
  when the channel actually started.
- Azure build `5713` / `20260825.4` keeps Mattermost bundled and trusted, patches
  its packed WebSocket import during canary image assembly, and imports that
  exact packed channel runtime as a mandatory build gate. The live Gateway now
  loads the exact global Codex package, loads bundled Mattermost and ACPX,
  connects Mattermost, and reports no channel restart or runtime error.
- Azure build `5722` / `20260825.12` produced the first fleet-promotion image.
  The sequential rollout stopped on `agent-coordinator` before touching the
  other sleeping agents: its legacy PVC still had a stable Mattermost plugin
  record, and the boot script wrote the new `finalDelivery` config before the
  stale record could be uninstalled. Config validation failed, the pod recorded
  one restart, and Emon was scaled back to zero. The r13 repair writes a minimal
  beta-channel bootstrap config first, removes stale plugin records, verifies
  the trusted exact Codex runtime, and only then writes the canonical fleet
  config and performs credential migration.
- Azure build `5724` / `20260825.13` proved the bootstrap ordering repair but
  exposed an older registry migration edge: Emon's 2026.7 Mattermost install
  record has no authoritative package-owner metadata, so uninstall refuses it
  and the stale global plugin remains authoritative. A controlled reinstall of
  the exact image-packaged Mattermost artifact refreshed the registry and made
  bundled Mattermost `2026.8.1` authoritative. The r14 boot gate applies that
  replacement before installing Codex and requires the exact bundled
  Mattermost version, source, and channel registration before writing the new
  delivery config.
- Azure build `5725` / `20260825.14` passed the exact Mattermost migration and
  brought Emon up with valid config, trusted Codex, SQLite auth, and connected
  Mattermost. The operator smoke then stopped on Stewie because child OpenClaw
  CLI processes could still observe the original Kubernetes bootstrap JSON and
  warn about its legacy `agents.list` form. The r15 boot path consumes that env
  input once, writes the canonical file, and unsets `OPENCLAW_CONFIG_JSON`
  before any OpenClaw process so file state is the sole runtime authority.
- Azure build `5726` / `20260825.15` proved canonical config authority and
  started Emon with separate delivery active, but gateway health exposed a
  forward-only legacy direct-message session key requiring SQLite repair while
  the Gateway is stopped. The r16 path tracks session migration independently
  from credential migration, runs Doctor before gateway startup when either is
  pending, restores the exact Codex and Mattermost runtimes afterward, and
  makes the runtime smoke fail on any remaining canonical-session repair error.
- Azure build `5727` / `20260825.16` reached the session migration gate, but a
  later restart showed that the supported stale-record replacement can resolve
  the exact image-packaged Mattermost `2026.8.1` as a managed global path
  install instead of the bundled path. The r17 assertion accepts only those two
  exact proven shapes: bundled `2026.8.1`, or global `2026.8.1` whose install
  source is the image-owned `/usr/local/lib/node_modules/@openclaw/mattermost`.
  Arbitrary global or registry Mattermost installs remain rejected.
- Azure build `5728` / `20260825.17` proved that the image-owned path install is
  still intentionally untrusted for durable ingress state and that Kubernetes
  container readiness can precede the exclusive Doctor migration. The r18 boot
  now normalizes legacy managed Mattermost records through supported
  install/uninstall lifecycle commands back to the exact image-bundled plugin,
  proves the canonical session store after Doctor, and publishes its migration
  marker only after that proof. Fleet smoke waits for those markers and the real
  gateway process before invoking any OpenClaw CLI, preventing a SQLite lock
  race during first startup.
- Azure build `5731` / `20260825.18` restored the trusted bundled Mattermost
  runtime, then exposed one legacy SQLite row whose empty entry blob prevented
  Doctor from reaching its own canonical repair. The r19 image adds a narrowly
  guarded offline pre-Doctor repair: it accepts only invalid `{}` rows with
  promoted session identity, refuses retained-history tombstones or any unknown
  shape, checkpoints SQLite, preserves a mode-0600 database backup, and updates
  the accepted rows atomically before Doctor and the canonical-session proof.
- Azure build `5732` / `20260825.19` migrated Emon cleanly, then found Stewie's
  legacy Mattermost package in the managed npm project store rather than the
  extensions directory. The r20 migration now uses runtime origin as the
  invariant: any non-bundled Mattermost instance is removed through its
  authoritative OpenClaw install record, regardless of managed storage shape,
  before the exact bundled canary is asserted.

## Previous fleet baseline (pre-027 canary)

- Swarm runtime commit: `41b6950b`
- Azure build: `5733` / `20260825.20` (`succeeded`)
- Image: `canary-20260825.20-3d1a6e419-r20`
- Immutable digest:
  `sha256:94a7e87362f5f5c2c8f67ddfd713f854c2f4ccba19fceb1ef25fd98af690b8e9`
- Image source-revision label:
  `3d1a6e4197b2bcce4b90cd3fc5b6de8a5b1f24c0`
- Deployment revisions: coordinator `291`, designer `219`, infra `332`,
  intake `176`, developer `225`
- Fleet status: all five Deployments Ready `1/1`; all five current pods have
  zero restarts and resolve to the exact immutable digest above
- Runtime: `OpenClaw 2026.8.1 (3d1a6e4)`
- Codex plugin: official `@openclaw/codex@2026.8.1-beta.3`, trusted global npm
  install, `agentHarnessIds=["codex"]` on every agent
- Mattermost plugin: version `2026.8.1`, bundled/trusted, connected as
  each agent's own bot identity, channel lifecycle `running, connected`
- ACPX plugin: version `2026.8.1`, bundled and loaded
- Runtime config: progress mode with `finalDelivery: "separate"` and tool
  progress enabled on all agents; coordinator retains `requireMention=false`
  and the other four retain `requireMention=true`
- Full repository verification: passed, including 50 unit tests
- Per-agent runtime/toolbox/channel smoke: passed for all five agents
- Runtime log audit: no canonical-session repair, untrusted durable-ingress, or
  Mattermost route-conflict errors after gateway startup
- Emon's one guarded legacy-row repair preserved
  `openclaw-agent.sqlite.backup-before-r18-invalid-row-repair` on its PVC before
  the atomic repair; the automated r19 fallback preserves the equivalent
  mode-0600 backup name for any future matching row
- Applied scope: Deployment resources only. PVCs, Secrets, ServiceAccounts,
  RBAC, Services, and NetworkPolicies were not modified.

## Previous exact-head deployment (superseded)

- Swarm branch commit: `8ad10d11`
- Azure build: `4904` / `20260811.4` (`succeeded`)
- Image: `canary-20260811.4-010d5554-r1`
- Immutable digest:
  `sha256:ba34b769a58c3ee525fac4a85cf9e055d4fe4c6405c511e7e2addea310a063a6`
- Image source-revision label:
  `010d5554de737e428648d92c54a2bbcf30c4d72d`
- Deployment revision: `202`
- Pod status: Ready `1/1`, zero restarts
- Runtime: `OpenClaw 2026.8.1 (010d555)`
- Mattermost plugin: packaged runtime loaded and connected as
  `@agent-developer`
- Runtime smoke: passed
- Full toolbox smoke: passed
- Non-canary deployments: images, revisions, readiness, and replica counts
  unchanged

The first runtime-smoke invocation immediately after rollout hit a transient
pod-selection/config convergence race and failed its skill-array assertion.
After rollout convergence, only the exact-head pod remained and both runtime
and toolbox suites passed. This was a probe race, not a canary restart or
runtime failure.

## Scope

- Build and push one exact-head canary image from this branch.
- Upgrade `agent-developer` first, prove its runtime and a fresh human-authored
  Mattermost lifecycle, then promote the same immutable digest sequentially to
  `agent-designer`, `agent-infra`, `agent-intake`, and `agent-coordinator`.
- Apply only each rendered Deployment; preserve every PVC, Secret,
  ServiceAccount, RBAC resource, Service, and NetworkPolicy.
- Stop the sequential rollout on the first failed rollout or runtime smoke.
- Capture and verify a quiesced, encrypted, off-cluster runtime-state backup for
  each agent immediately before its Deployment is advanced.

## Non-goals

- No merge to `main` before the exact-head canary and fleet promotion passed.
- No Secret, RBAC, DNS, ingress, Mattermost server, or PVC mutation.
- No stable-image downgrade after the forward-only 2026.8 state migration.
- No change to agent identities, skills, model policies, Mattermost handles,
  mention gates, or per-agent credentials.

## Canary configuration

Every persistent agent uses the same Mattermost delivery contract while
retaining its existing mention and chat-mode policy:

```json
{
  "streaming": {
    "mode": "progress",
    "progress": {
      "label": "Thinking… please wait",
      "finalDelivery": "separate",
      "toolProgress": true,
      "commandText": "raw",
      "maxLines": 8,
      "maxLineChars": 120
    }
  }
}
```

The fleet boot gate canonicalizes legacy agent-list configuration, performs the
one-time credential migration when required, restores the exact official
`@openclaw/codex@2026.9.2` registry install after Doctor, validates the
SQLite-backed model status, and only then starts the gateway.

## Acceptance matrix

1. A tool-heavy successful turn creates one typed progress post, edits only
   that post, sends a distinct final in the same thread, and then deletes the
   progress post.
2. A recovered tool failure still ends with one durable final and no stale
   progress post.
3. A terminal turn failure retains a bounded sanitized progress status and
   does not expose raw command text, stderr, credentials, or tokens.
4. A final-send failure retains progress and never deletes or duplicates an
   accepted final.
5. Late tool/error callbacks cannot edit or delete the separate final.
6. `agent-designer` receives no invocation or session/history entry from a
   `custom_openclaw_progress` post.
7. A human message whose text begins with `|` remains actionable.
8. Core and Mattermost plugin both report version `2026.9.2`; the image label
   reports `0270094e6c250664df62ea88446d360ef3723d37`.

## Recovery

Tinus is not deliberately downgraded before this rollout. Recovery is based on
the verified per-agent pre-upgrade state archive and the exact image recorded in
the backup receipt. Never apply an older image to a newer state database unless
that compatibility has been proved. Preserve the PVC and collect diagnostics;
do not delete the database or run an unreviewed schema repair.

## Completion evidence

- Swarm branch commit and Azure build ID/number.
- Harbor image tag and immutable digest.
- Kubernetes deployment image, rollout revision, readiness, and restarts.
- Live OpenClaw/plugin versions and image revision label.
- Mattermost post IDs/types/root IDs for the success and failure cases.
- Observer agent log/session evidence showing zero progress-post invocation.
- Explicit rollback status.

## Exact-head fleet evidence (2026-09-06)

- Swarm branch commits: `b4589d0` (exact 027 baseline), `1053eb7`
  (quiesced persistent-agent rollout), `1d2f63d` (per-agent gate and reviewed
  plugin capability consent), `d00a18f` (immutable coordinator sidecar), and
  `6d5bb85` (main-pipeline quiescence before template apply).
- Azure build `6762` / `20260906.1` succeeded and published
  `pinned-20260906.1-0270094e` at immutable digest
  `sha256:b1372b83a8a886b22c6c3707f5537f4483ba8592d0019cf9715aeb7d8085e2a1`.
- Rollout order was developer, designer, infra, intake, coordinator. Each
  persistent deployment was scaled to zero and its old pod deleted before the
  replacement Deployment was applied, preventing concurrent SQLite writers on
  the shared ReadWriteOnce PVC.
- All five deployments are Ready `1/1`; current pod restarts are zero.
  Deployment revisions are developer `388`, designer `346`, infra `574`,
  intake `302`, and coordinator `533`. Every agent container resolves to the
  immutable digest above; coordinator's `mission-event-intake` sidecar resolves
  to the same digest and is also Ready with zero restarts.
- Every runtime reports `OpenClaw 2026.9.2 (0270094)`. Mattermost `2026.9.2`
  is bundled and loaded; Codex and diagnostics `2026.9.2` are trusted global
  installs and loaded. Each channel smoke reports Mattermost running and
  connected.
- Existing model policy was preserved: developer Astra with Sol fallback,
  coordinator Terra with Sol fallback, designer and infra Sol, and intake
  Luna. Every pod's downward-API image revision equals the deployment
  annotation and immutable digest.
- The human-authored success lifecycle used root post
  `naxw9887atfeufrkzgntykbhby`, request `6x3nufordfgdmm6fez6zg8iror`, and
  separate final `sw1eqyei4fdgtybo5mf8m1js9w` containing
  `CURRENT_HEAD_CANARY_OK`; the typed progress post was deleted after delivery.
  Peer logs showed no `custom_openclaw_progress` dispatch from that progress
  lifecycle.
- Quiesced encrypted off-cluster receipts exist for all five agents under the
  `0270094e` backup set. Each receipt proves a non-empty SHA-256 archive,
  successful decrypt/list verification, and credential-file exclusion.
- Designer's first 027 startup stopped because the reviewed local
  `behavioral-observability` plugin required explicit capability consent. The
  rollout stopped before later peers, consent was scoped to that one plugin on
  every agent, and the replacement designer pod passed full smoke with zero
  restarts.
- Coordinator's first replacement rendered its mission-event sidecar with the
  obsolete `:dev` placeholder and stopped at `ImagePullBackOff`; the main
  container did not fail. The rollout was interrupted, the deployment was
  quiesced again, and the operator now pins every repository-owned container in
  the target Deployment to the exact digest. Both coordinator containers then
  passed the final gate.
- Post-start audit found none of the guarded canonical-session, trusted-ingress,
  Mattermost route-conflict, capability-consent, or image-pull error signatures
  in current agent-container logs. No PVC, Secret, ServiceAccount, RBAC,
  Service, or NetworkPolicy was replaced. No runtime downgrade was attempted.

## Main baseline promotion

Fito approved promoting the new exact-head runtime into the repository's
`main` delivery baseline on 2026-09-06. The promotion must:

- make the exact `0270094e` source/artifact/checksum set the normal Azure and
  Task image-build inputs;
- deploy the same pinned runtime to all five agents from `main`;
- retain the Mattermost separate-progress contract and existing mention gates;
- keep the verified `0270094e` digest and per-agent pre-upgrade state receipts
  as the recovery boundary;
- reject automatic or moving-tag OpenClaw upgrades; and
- complete only after PR verification, pinned-image validation, squash merge,
  main-pipeline rollout, and five-agent runtime/channel smoke evidence.
