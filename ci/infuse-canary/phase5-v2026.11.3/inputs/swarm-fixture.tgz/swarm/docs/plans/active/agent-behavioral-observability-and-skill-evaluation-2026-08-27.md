---
title: Agent behavioral observability and skill evaluation
description: Iterative delivery plan for tracing agent workflows, skill and knowledge use, tool failures, and evidence-based skill evaluation across the OpenClaw fleet.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - observability
  - opentelemetry
  - langfuse
  - opik
  - skills
  - openclaw
  - kubernetes
---

# Agent Behavioral Observability and Skill Evaluation

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Goal

Build an evidence loop that lets the team answer, for every agent and runtime
revision:

1. Which skills and tools were selected, in what order, and in which workflow
   phase?
2. When was knowledge discovery or retrieval attempted, what kind of result was
   returned, and did the agent subsequently use it?
3. Which tools, wrappers, and skill scripts fail, retry, or consume unexpected
   time?
4. Which workflows are inefficient, which skills need repair, and which missing
   skills are recurring candidates?
5. Does a proposed skill, wrapper, prompt, model, or runtime change improve a
   representative task set without regressing safety or reliability?

The system must provide useful fleet-level telemetry even when no content is
captured, must never make an agent operation depend on the telemetry backend,
and must support exact correlation from an Opik evaluation item to its OpenClaw
trace.

## Accepted architecture

| Concern | System of record | Purpose |
| --- | --- | --- |
| Per-run trace inspection | Langfuse | Trace tree, model/tool/skill sequence, latency, token and cost inspection |
| Fleet metrics and dashboards | Prometheus + Grafana | Rates, distributions, regressions, SLOs, and comparisons by agent/runtime/skill revision |
| Sanitized operational failures | Loki | Searchable error envelopes and bounded diagnostic context correlated by trace ID |
| Datasets, experiments, and scores | Opik | Golden scenarios, production-derived regression cases, candidate comparisons, and promotion evidence |
| Collection, policy, and routing | OpenTelemetry Collector | Redaction, batching, memory limits, sampling, span-derived metrics, and backend fan-out |

No additional trace UI or metrics platform is required for the initial program.
The missing pieces are OpenClaw instrumentation, a collector policy boundary,
and an evaluation runner.

## Execution status — 2026-08-28

Mission closure work continues in
`agent-observability-mission-closure/`. On 2026-08-29 Fito accepted six final
iterations: fleet behavioral rollout, wrapper failure coverage, explicit
no-core skill attribution, Opik evaluation, controlled retrieval experiments,
and one complete governed improvement loop. This original plan remains the
program authority; the continuation package owns the executable closure tasks
and current acceptance gates.

- Iteration 0 is complete: contract, fixtures, authority, backend inventory,
  and baseline evidence are checked in.
- Iteration 1's official OTel substrate is proven on Tinus without rebuilding
  the custom OpenClaw bundle. Export, privacy, bounded cardinality, failure,
  fail-open, recovery, and backend health checks pass.
- A post-canary source and live-metric audit corrected the earlier trace-list
  inference: the official diagnostic surface already exports tool name,
  duration, source, block outcome, and stable failure class. Tinus Prometheus
  series prove successful `session_status` and `bash` calls plus the single
  intentional `codex_native_tool_error` failure.
- The remaining gaps are workflow phases, knowledge envelopes, immutable
  revision attribution, and Codex-native skill activation. The first three can
  be implemented without rebuilding OpenClaw core. Reliable Codex-native skill
  and structured Read/Search/ListFiles projection are the custom plugin-artifact
  gate.
- No rebuild or deployment was performed during this audit. The next slice may
  implement config, dashboards, wrappers, and a standalone hook plugin, but it
  must stop before building any Codex or OpenClaw custom artifact.

The current Tinus deployment already uses the official
`@openclaw/diagnostics-otel@2026.8.1-beta.3` plugin against the custom OpenClaw
`2026.8.1` canary. The exact core already contains the required tool and
`skill.used` schemas. A core-schema rebuild is not justified by current
evidence; any gated artifact work should be limited to the Codex adapter or a
standalone plugin unless a new first-class event contract is separately
approved.

### Implementation-path audit

| Signal | Current capability | Next path | Rebuild boundary |
| --- | --- | --- | --- |
| Tool execution and failure | Already exported by the official diagnostics plugin and proven live | Surface child spans/metrics in Langfuse and Grafana | No rebuild |
| Workflow lifecycle | Public prompt/model/tool/agent hooks expose run and trace context | Standalone metadata-only hook plugin | Swarm image only; no core/Codex rebuild |
| Knowledge retrieval and wrapper execution | Wrapper layer owns the stable operations and failure taxonomy | Shared fail-open `agent-skills` helper plus a trace-correlated plugin tool or bridge | No core/Codex rebuild |
| Runtime/image/skill-bundle revision | Resource attributes exist; live `dev` values are incorrect | Populate immutable manifest and image revisions in runtime configuration | No rebuild |
| Embedded-agent skill use | Existing `skill.used` event recognizes known skill reads/commands | Add a focused verification scenario | No rebuild |
| Codex-native skill use | Detected inside Codex but not exposed by its app-server protocol or projected by OpenClaw | Add an upstream notification and Codex-adapter projection, or review an adapter-local structured fallback | Stop before Codex/OpenClaw plugin artifact rebuild |
| Structured Read/Search/ListFiles access | `commandActions` reach the Codex adapter but not public tool hooks | Project sanitized action classes in the Codex adapter | Stop before OpenClaw Codex plugin artifact rebuild |

## Reasoning visibility boundary

The useful target is the observable decision process: plans, workflow phases,
tool and skill choices, retrieval decisions, verification steps, retries,
model-produced reasoning summaries, and outcomes.

This plan does not depend on access to hidden provider chain-of-thought, which
is not an exported OpenClaw telemetry surface. Controlled evaluation runs may
record explicitly emitted reasoning summaries or visible plan artifacts under
the same access, retention, and redaction policy as other captured content.
Production telemetry remains metadata-first unless a later, separately approved
content-capture policy says otherwise.

## Non-goals

- Automatically editing or publishing skills from telemetry.
- Sending every production trace to Opik as a second general-purpose trace
  store.
- Logging prompts, objectives, retrieved passages, credentials, headers,
  opaque knowledge references, or raw command output by default.
- Defining alert thresholds before a representative baseline exists.
- Replacing Langfuse, Grafana, Loki, Opik, or the current Kubernetes monitoring
  stack.

## Repository and system ownership

| Surface | Authority | Planned responsibility |
| --- | --- | --- |
| Agent image, Kubernetes runtime, collector, canary scripts | `openclaw-k8s-swarm` | Install/pin the diagnostics plugin, deploy collector resources, configure agents, smoke and roll back |
| Skill and wrapper source | `agent-skills` | Emit privacy-safe knowledge and wrapper events; own stable error taxonomy and tests |
| Fleet dashboards and monitoring configuration | `grafana` | Prometheus/Loki discovery, dashboards-as-code convention, recording rules, and later alerts |
| OpenClaw diagnostic schemas and Codex event projection | `aolea/openclaw` fork | Add only the behavioral events that cannot be produced by the official plugin or wrapper layer |
| Trace and evaluation data | Langfuse and Opik | Store traces and experiment evidence; no source code authority |

Changes spanning these authorities must be delivered as separately reviewable
PRs with an explicit dependency order. The dirty or unrelated current checkouts
must not be reused for implementation; use isolated branches/worktrees.

## Signal contract

Iteration 0 freezes a versioned schema before deployment. The following names
describe the intended information; final event names must follow existing
OpenClaw conventions where an equivalent event already exists.

| Signal | Required fields | Forbidden or bounded fields |
| --- | --- | --- |
| Existing run/model/tool events | agent ID, run/session correlation, runtime/image revision, model, outcome, duration, tokens/cost where available | No prompt or response body in production baseline |
| `skill.used` enrichment | skill name, skill revision/content hash, invocation source | No complete `SKILL.md` body |
| `workflow.phase` | stable phase enum, phase outcome, sequence | Free-form rationale is optional eval-only content |
| `knowledge.retrieve` | discover/fetch operation, mode, outcome, duration, candidate/result count, fallback reason, stable error code, KB snapshot/version when available | No objective, raw filters, references, excerpts, Markdown, authorization material, or unbounded path labels |
| `knowledge.access` | Read/Search/ListFiles action, repository/source class, repo-relative path classification, outcome | No absolute host paths, file contents, search query text, or secret-bearing arguments; path values must be reviewed for cardinality and sensitivity |
| `wrapper.execution` | skill and revision, wrapper, operation, duration, outcome, retry count, exit class, stable error signature | Raw stdout/stderr excluded from metrics and traces; only bounded sanitized failure detail may enter Loki |
| Evaluation linkage | dataset, case ID, experiment, candidate revision, trial, score names | No production user content copied into datasets without explicit sanitization and approval |

### Cross-cutting requirements

- Every trace carries agent identity, OpenClaw version/source revision, image
  digest or immutable revision, model, skill bundle revision, environment, and
  a trace ID usable in Langfuse, Grafana, Loki, and Opik evidence.
- Metric labels are bounded enums or stable revisions. Session IDs, paths,
  error messages, objectives, and user/channel identifiers are not metric
  labels.
- Telemetry exporters are asynchronous and fail open. Collector or backend
  failure cannot fail, delay materially, or retry an agent tool operation.
- Collector credentials are supplied by Kubernetes Secret references and are
  never copied into agent configuration or repository files.
- Metrics remain complete. Trace sampling may reduce successful production
  traces only after the canary burn-in; errors, slow runs, and evaluation runs
  remain retained.
- Sanitization is tested with adversarial fixtures, not accepted only by visual
  inspection.

## Delivery sequence

```text
Iteration 0: contract and baseline
             |
             v
Iteration 1: official OTel substrate + Tinus canary
             |
             v
Iteration 3: Tinus behavioral events
             |
             v
Iteration 2: fleet rollout + useful dashboards
             |
             v
Iteration 4: wrapper failures
             |
             v
Iteration 5: scored Opik regression suite
             |
             v
Iteration 6: governed improvement loop
```

The numbering preserves the accepted work packages, while live evidence changes
their execution order: the Tinus behavioral slice now precedes fleet rollout.
The Iteration 5 runner skeleton and fixture design may begin after Iteration 0,
but scored trace assertions require the stable event contract from Iteration 3.

## Iteration 0 — Contract, authority, and baseline

### Outcome

A reviewed telemetry contract and baseline evidence package exist before any
runtime or cluster change.

### Work

1. Add an architecture decision record covering backend roles, collector trust
   boundary, content policy, sampling principles, retention owners, and the
   no-automatic-skill-mutation rule.
2. Convert the signal table above into versioned schema fixtures with allowed
   fields, types, enums, cardinality expectations, and redaction tests.
3. Inventory existing OpenClaw diagnostic events and map each approved field to
   one of: already available, wrapper-emitted, custom Codex projection, or
   deferred.
4. Capture a pre-OTel fleet baseline from existing Gateway usage/log evidence:
   run duration, model calls, token/cost data, tool failures, restart counts,
   and current image/runtime revisions.
5. Through an authorized read-only operator, verify the live Grafana,
   Prometheus, Loki, promtail, Langfuse, and Opik versions and health. Current
   Kapiteky cluster identity does not have monitoring-namespace visibility, so
   lack of direct evidence is a gate rather than a reason to expand RBAC
   silently.
6. Confirm dashboard provisioning ownership. The current Grafana values disable
   dashboard sidecars, so dashboard JSON provisioning needs an explicit
   reviewed convention before dashboard work begins.
7. Decide the eval-runner code location, retention periods, initial trace
   sampling values, and Secret owner. These decisions must be recorded without
   storing credential material.

### Verification gate

- Schema fixtures reject secret-bearing and high-cardinality examples.
- Every desired question maps to a signal, query, or explicit deferred item.
- Live component versions and collector-compatible endpoints have evidence.
- Baseline measurements and exact agent revisions are recorded.
- The four source repositories and their review owners are confirmed.

### Rollback

None. This iteration changes documentation and test fixtures only.

## Iteration 1 — Official OTel substrate and Tinus canary

### Outcome

One agent exports official OpenClaw traces and metrics through a central
collector without a custom core rebuild and without exposing content.

### Work

1. Pin and install `@openclaw/diagnostics-otel@2026.8.1-beta.3` in the swarm
   agent image. Extend the image/plugin integrity and startup tests.
2. Add the plugin to Tinus's runtime allowlist and required-plugin gate. Enable
   diagnostics with content capture disabled.
3. Deploy a collector in `agents-swarm` with a memory limiter, batch processor,
   schema redaction/filtering, tail-sampling policy, span-to-metrics connector,
   health endpoints, and bounded queues.
4. Route traces to Langfuse, metrics to Prometheus, and collector/agent
   structured logs to stdout for the existing promtail-to-Loki path. Keep Opik
   out of the general production trace fan-out.
5. Add a ServiceMonitor compatible with the existing cross-namespace Prometheus
   selectors and document collector endpoint/Secret ownership.
6. Build a new immutable agent image and roll only Tinus.
7. Exercise a successful tool, a failed command, a skill activation, a model
   call, and a collector/backend outage followed by recovery.

### Verification gate

- Tinus is Ready with zero unexplained restarts and the expected image digest.
- Plugin and collector health checks pass; queues do not grow after recovery.
- Langfuse shows a correlated run/model/tool trace without prompt, response,
  tool argument, command output, or retrieved content.
- Prometheus scrapes collector metrics and exposes bounded agent/run/tool
  dimensions.
- A failed command can be correlated from Loki to Langfuse using trace ID.
- Disabling or breaking the collector does not change the tool result delivered
  by the agent.

Current gate result: the substrate and fail-open requirements are verified, but
cross-backend failed-command correlation is not. Loki contains the OpenClaw run
marker without raw command text; Langfuse does not contain that run marker or a
shared trace key. Recent official traces expose only harness/model activity and
no tool, skill, or knowledge fields. This unmet behavioral gate intentionally
blocks Iteration 2 fleet promotion and routes next to Iteration 3.

### Rollback

Disable diagnostics or restore Tinus's previously verified Deployment image.
Do not alter or delete its PVC. The collector may remain deployed but unused.

## Iteration 2 — Baseline fleet rollout and operational dashboards

### Outcome

All five agents emit the proven baseline signals, and the team can identify
fleet, skill, and tool regressions without opening individual sessions.

### Work

1. Promote the exact Tinus-proven image sequentially, one Deployment at a time,
   stopping on the first readiness, plugin, channel, or telemetry regression.
2. Run the existing runtime/toolbox/channel smoke and the new telemetry smoke
   for each agent before continuing.
3. Add Grafana dashboards for:
   - fleet runs, failures, latency, tokens, cost, loops, and exporter health;
   - skill usage by agent and revision;
   - tool outcome/duration/retry patterns;
   - trace/log correlation and collector drops/queue pressure.
4. Add Loki queries for stable failure signatures and a documented drill-down
   from Grafana to Langfuse.
5. After a burn-in window, sample ordinary successful traces while retaining
   all errors, slow traces, and evaluation traces. Keep derived metrics at
   full coverage.

### Verification gate

- All five Deployments are Ready, preserve their replica intent, and run the
  exact verified digest with no new channel or state errors.
- Signals are separable by agent, environment, image/runtime, model, skill
  bundle revision, and outcome without high-cardinality labels.
- Dashboards answer the baseline questions for a known success and known
  failure.
- Collector/backend outage drills preserve agent behavior across the fleet.

### Rollback

Restore only the affected Deployment to the previous digest and stop the
sequence. Preserve already proven agents unless evidence shows a fleet-wide
fault. Diagnostics can be disabled independently of the image.

## Iteration 3 — Behavioral workflow and knowledge telemetry

### Outcome

A Tinus trace shows the observable workflow from skill selection through
knowledge access, tool use, verification, and result, without raw task or
knowledge content.

### Work

1. Extend `agent-skills` knowledge retrieval wrappers with the approved
   `knowledge.retrieve` envelope for discover/fetch duration, mode, result
   count, fallback, outcome, and stable error code. Preserve the current
   lexical-first behavior and never record objectives, opaque references,
   excerpts, Markdown, or authorization material.
2. Populate immutable runtime, image, and skill-bundle revision attributes from
   the existing image/source-sync contract; remove the current live `dev`
   attribution.
3. Add stable coarse workflow phases through a standalone metadata-only plugin
   using the public prompt/model/tool/agent lifecycle hooks and their run/trace
   context. Do not rebuild OpenClaw core for this slice.
4. Validate the existing official tool spans and metrics through Langfuse child
   observations and Grafana before adding duplicate instrumentation.
5. Stop for approval before the two Codex-adapter gaps: native skill invocation
   and structured `commandActions` for Read, Search, and ListFiles. If approved,
   prefer an upstream Codex app-server skill-invocation notification and project
   only sanitized action classes; never export absolute paths, query text, or
   content.
6. Extend the OpenClaw diagnostic schema only if a separately reviewed
   first-class event cannot be represented by the standalone plugin or wrapper
   layer. A new schema is not required for the already-live tool lifecycle.
7. Allow explicitly emitted reasoning summaries or visible plan artifacts only
   in controlled evaluation mode. Keep production content capture disabled.
8. Canary on Tinus with representative direct, skill-driven, KB-driven,
   retrying, and verification-heavy tasks.

### Verification gate

- A trace reliably distinguishes skill selection, workflow phase, KB
  discover/fetch, file/search access class, tool execution, retry, verification,
  and final outcome.
- Sanitization fixtures prove that objectives, raw references, file contents,
  search queries, absolute paths, prompts, and command output do not leave the
  process.
- Signal emission has bounded overhead and cannot block the underlying action.
- Existing wrapper output and exit semantics are unchanged.
- Tinus passes runtime/toolbox/channel and telemetry smokes on the new image.

### Rollback

Restore the Iteration 2 image and disable the new event schema. Wrapper event
emission must be independently feature-gated and fail open.

## Iteration 4 — Wrapper and skill-script failure intelligence

### Outcome

Repeated wrapper failures cluster by operation, stable signature, and skill
revision, making repair candidates visible without exposing raw tool data.

### Work

1. Add one reusable instrumentation helper in `agent-skills` for the
   `wrapper.execution` envelope. Do not hand-roll incompatible logging in each
   skill.
2. Pilot the helper on three high-value paths: knowledge retrieval, Azure DevOps
   operations, and runtime/Kubernetes operations.
3. Preserve a stable taxonomy for timeout, authentication unavailable,
   authorization denied, dependency unavailable, invalid input, upstream
   contract mismatch, non-zero exit, parse failure, and unknown failure.
4. Put stable code/signature and counts in telemetry. Put only bounded,
   sanitized diagnostic detail in Loki; raw stdout/stderr remains local to the
   authorized execution path.
5. Add dashboards comparing failure and retry rates across skill revisions,
   wrappers, operations, agents, and runtime images.
6. Expand wrapper coverage only after the pilot proves low overhead and useful
   failure clustering.

### Verification gate

- Known fixture failures land in the correct stable classes and correlate to
  traces.
- Unrecognized failures fall back safely without leaking raw text.
- Wrapper functional tests and `agent-skills/scripts/verify.sh` pass.
- Collector outage and event serialization failure do not alter wrapper
  results, retries, or exit codes.
- The dashboard identifies an injected repeated failure by wrapper, operation,
  and skill revision.

### Rollback

Disable the instrumentation helper while retaining existing wrapper behavior,
or revert only the affected skill release and bundled swarm revision.

## Iteration 5 — OpenClaw skill evaluation runner and Opik suite

### Outcome

Proposed skill and runtime changes can be compared against a stable baseline
using repeatable tasks, linked traces, and explicit promotion scores.

### Work

1. Build a small OpenClaw evaluation runner in the Iteration 0 approved code
   location. It must invoke the Gateway through the supported API and propagate
   W3C `traceparent` so each Opik dataset item links to its Langfuse trace.
2. Seed 10–20 sanitized golden scenarios from representative workflows and
   real failure classes. Production-derived cases must be minimized and
   reviewed before entering Opik.
3. Score task success, correct skill selection, workflow adherence, tool
   efficiency, KB use when expected, recovery, verification, safety, and output
   quality. Keep deterministic checks separate from model-graded checks.
4. Record model/reasoning effort, OpenClaw revision, image digest, skill bundle
   and individual skill revisions, KB snapshot/version, dataset version, and
   trial number.
5. Run at least three trials per non-deterministic case and report both quality
   and resource distributions rather than a single aggregate score.
6. Run candidates in a sandboxed or read-only environment. The evaluator must
   not send external messages, mutate production state, or reuse production
   credentials for unsafe fixtures.
7. Export an evidence package containing Opik experiment links/IDs, score
   deltas, trace correlation, failure clusters, cost/latency deltas, and a
   promotion recommendation.

### Verification gate

- The same dataset and pinned candidate reproduce within documented variance.
- Every failed case links to the exact Langfuse trace and relevant Loki failure
  envelope without manual session matching.
- Deterministic graders have unit fixtures; model graders have a rubric and
  calibration examples.
- A deliberately degraded wrapper or skill fails the expected regression gate.
- The runner cannot perform unapproved production writes.

### Rollback

Evaluation infrastructure is out of the production serving path. Disable the
runner or revert its dataset/scorer version; no agent rollout is required.

## Iteration 6 — Governed continuous-improvement loop

### Outcome

Telemetry and evaluations produce a regular, human-reviewed queue of concrete
skill, wrapper, KB, prompt, and runtime improvements.

### Work

1. Produce a weekly evidence report covering top failure signatures, slow or
   looping workflows, KB bypass/overuse, low-value or unused skills, missing
   skill candidates, and regressions by revision.
2. Define minimum sample counts and confidence rules before ranking a skill or
   agent. Separate rare critical failures from frequent low-impact failures.
3. Turn accepted findings into normal repository issues/specs. Do not create a
   skill change from a trace alone, and never mutate skill source
   automatically.
4. Require candidate skill changes to pass `agent-skills` verification, the
   Opik regression suite, bundle synchronization, Tinus canary, and sequential
   fleet promotion.
5. Set SLOs and alerts only after baseline distributions are stable. Start with
   exporter health, failure-rate regressions, loop spikes, latency shifts, and
   wrapper signature bursts.
6. Review retention, sampling, field allowlists, and dataset contents
   periodically. Remove signals that do not drive decisions.

### Verification gate

- At least one real finding completes the full evidence -> proposal -> change
  -> eval -> Tinus -> fleet loop with linked artifacts.
- Promotion requires an explicit human decision and preserves repository review
  boundaries.
- Alerts are actionable, have owners and runbooks, and are tested without
  flooding Mattermost.
- Sampling and retention costs remain within the Iteration 0 budget.

### Rollback

Pause scheduled reports or alerts independently. No automated mutation path
exists to unwind.

## Promotion rules for every runtime iteration

1. Build one immutable artifact from the reviewed exact revision and record its
   digest and source revision.
2. Verify image/plugin integrity before touching Kubernetes.
3. Roll Tinus only and capture readiness, restart, channel, tool, telemetry,
   and privacy evidence.
4. Require explicit approval before expanding beyond Tinus.
5. Promote sequentially and stop on the first failure.
6. Preserve PVCs, Secrets, ServiceAccounts, RBAC, Services, and NetworkPolicies
   unless the iteration explicitly owns a reviewed change to one of them.
7. Keep the last verified image and diagnostics-off configuration as two
   independent rollback paths.

## Program acceptance criteria

The program is complete when the team can select a runtime or skill revision
and, without inspecting private session storage:

- reconstruct the observable workflow and skill/tool/KB sequence;
- find tool and wrapper failures grouped by stable cause and revision;
- compare latency, cost, retries, loops, and outcomes against a baseline;
- replay representative cases through an Opik dataset with exact trace
  correlation;
- demonstrate that a deliberately bad candidate is rejected and a useful
  candidate improves the intended measures without a safety regression; and
- promote or reject a skill change through an explicit human-reviewed path.

## Open decisions to close in Iteration 0

- Initial retention periods for Langfuse traces, Loki failures, Prometheus
  metrics, and Opik datasets/experiments.
- Initial successful-trace sampling rate and slow-trace threshold after the
  full-fidelity Tinus burn-in.
- Collector credential/Secret owner and rotation procedure.
- Dashboard provisioning convention while Grafana dashboard sidecars remain
  disabled.
- Eval-runner repository location and sandbox identity.
- Whether any production reasoning-summary capture is justified later;
  default remains evaluation-only and explicitly emitted content.
- Exact live component versions and Loki structured-metadata capabilities.

These decisions do not block drafting code-level tasks, but they block the
first production deployment.
