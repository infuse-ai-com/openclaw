---
title: Active-Lease Wake-Ticket Recovery Requirements Checklist
description: Completeness checks for delayed wake-ticket recovery during an active continuation lease.
type: evidence
status: active
owner: team:agent-platform
tags: [evidence, agents, mission-continuation, recovery]
---

# Requirements Checklist: Active-Lease Wake-Ticket Recovery

- [x] Problem and user-visible failure are explicit.
- [x] Acceptance criteria are observable.
- [x] Stable wake identity and ticket ownership are explicit.
- [x] Duplicate submission and watcher behavior are covered.
- [x] Auth, secret, API, deployment, and cost impact are considered.
- [x] Rollback and approval gates are explicit.
- [x] Verification commands and source artifacts are named.
