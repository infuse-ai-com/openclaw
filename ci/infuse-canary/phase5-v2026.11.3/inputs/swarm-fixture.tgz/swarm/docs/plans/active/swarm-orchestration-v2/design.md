---
title: Swarm Orchestration v2 Design
description: Cross-repository architecture and data-flow design for the accepted orchestration program.
type: architecture
status: active
owner: team:agent-platform
tags:
  - agents
  - orchestration
  - architecture
---
# Swarm Orchestration v2 Design

## Architecture

```text
Mattermost role events     Azure/build events     Backoffice operator intents
          |                        |                         |
          +------------------------+-------------------------+
                                   |
                         authenticated event intake
                    validate -> normalize -> deduplicate
                                   |
                         Emon event inbox/spool
                                   |
                    exact mission-thread continuation
                         /                     \
                targeted system wake      Mission Watcher reply
                  (normal path)           (one-minute fallback)
                         \                     /
                          same Mattermost session lane
                                   |
                     mission registry transition engine
                          /                     \
                 canonical v2 state       bounded event journal
                          |
                validated read-only snapshot
                          |
                Backoffice Missions projection

Mission/task transitions -> privacy-safe orchestration telemetry -> Collector
                                                               -> Langfuse
                                                               -> Prometheus/Grafana
                                                               -> Loki (bounded failures)
```

## Repository Ownership

| Repository | Ownership in this program |
| --- | --- |
| `agent-skills` | Mission v2 schema/CLI, transition engine, handoff validator, capability-preflight contract, client helpers. |
| `openclaw-k8s-swarm` | Event intake runtime, steward installer, bundle/capability materialization, telemetry contract/plugin, canary harness, deployment manifests. |
| `backoffice` | Read-only mission projection and bounded operator-intent UI/API; no direct registry write. |
| `grafana` | Mission-level recording rules, alerts, and dashboards using bounded dimensions. |
| `company-docs` | Durable operating-model and authority decisions after implementation proves the design. |
| `openclaw-agents-persona` | Persona behavior only when runtime-proven interaction rules need a durable role change. |

## Canonical State And Event Separation

The canonical registry remains in Emon's PVC. Incoming events do not directly
edit it. They enter a bounded inbox as one validated envelope per event. The
transition engine serializes registry mutation with an exclusive lock, applies
the event exactly once, atomically replaces the registry, records the processed
event, and exports a new snapshot.

This preserves the current simple, inspectable JSON authority while adding safe
concurrency. A database migration is intentionally deferred until measured
event volume or query needs exceed the file-backed contract.

## Mission Registry v2 Shape

Root fields:

```text
schema: infuse.team-missions/v2
registry_revision: monotonic integer
updated_at: UTC timestamp
missions: bounded list
```

Mission additions over v1:

- `revision` for optimistic concurrency;
- transition-safe task lifecycle;
- task acknowledgement and lease fields;
- task requirements and preflight result;
- evidence records with type, immutable ref, producer, and verifier;
- bounded blocker and waiting reason;
- latest processed material-event pointer;
- closeout verifier and verified timestamp.

Event content is not embedded indefinitely in the registry. The registry keeps
the latest pointers required for decisions; the processed event archive keeps
bounded metadata for replay and audit.

## Event Envelope

```json
{
  "schema": "infuse.mission-event/v1",
  "event_id": "source-stable-id",
  "idempotency_key": "source-kind-and-version",
  "mission_id": "swarm-orchestration-v2",
  "task_id": "optional-task-id",
  "kind": "task_acknowledged",
  "source": {
    "type": "mattermost",
    "actor": "agent-developer",
    "ref": "opaque-durable-pointer"
  },
  "occurred_at": "2026-08-31T22:00:00Z",
  "observed_at": "2026-08-31T22:00:01Z",
  "data": {
    "status": "acknowledged",
    "artifact_ref": "optional-immutable-pointer"
  }
}
```

Allowlisted `kind` and `data` schemas prevent arbitrary payload storage. Event
ids, mission ids, task ids, user ids, channel ids, and source refs are never
Prometheus labels.

## Mission Continuation Contract

After at least one new actionable event is durably accepted, intake acquires
one mission-scoped wake lease. Bursts for that mission are coalesced; events for
another mission remain pending for their own lane. The normal path resolves the
mission's canonical Mattermost peer kind, coordination channel, and thread,
derives the stable Emon thread session key, verifies the exact stored route, and enqueues a
bounded system event to that session. A raw session id is never canonical and
an unknown or mismatched route never falls back to Emon's main session.

The wake message carries only the mission id and lease reference. It instructs
Emon to reconcile the canonical registry and inbox and grants no approval,
transition, merge, deploy, or reassignment authority. If the exact thread run
does not durably acknowledge the lease within one minute, a separately owned
Mission Watcher webhook posts one idempotent, non-authoritative reply in the
same Mattermost thread. That inbound reply recreates the same mission lane when
local session state is absent. It is a recovery transport, not a second event
bus, and never includes event payloads.

A frequent zero-model reconciler checks pending events, expired leases, missed
wakes, and required dispatch receipts. It may perform bounded recovery at the
twenty-minute next-action threshold. One deduplicated human-facing alert is
allowed only after an actionable event remains unresolved for one hour. It
remains silent when no material action exists.

## Backoffice Operator Intent Boundary

Backoffice may later accept four bounded intents:

- pause mission;
- resume mission;
- approve or reject a named gate;
- request task reassignment.

Backoffice stores the human request and audit record, then publishes an
authenticated mission event. Emon validates current revision, authority,
approval semantics, and transition legality. The UI shows `pending`, `applied`,
`rejected`, `expired`, or `superseded`. It never claims the mission changed
until a fresh canonical snapshot proves it.

## Telemetry Boundary

Mission telemetry is a bounded semantic layer, not a copy of mission state.
Allowed dimensions include project class, mission phase, task role, event kind,
transition outcome, traffic source, waiting category, and verification class.
Mission ids and source pointers stay in trace attributes only when backend-safe
and are never metric labels; if the current privacy contract forbids them, a
one-way short-lived correlation token is used only inside the trace backend.

## Migration And Compatibility

1. Preserve exact v1 bytes before migration.
2. Convert task statuses deterministically.
3. Mark historical `done` tasks as `verified` only when existing evidence and
   acceptance state prove verification; otherwise convert to `delivered`.
4. Keep the v1 reader during one rollback window.
5. Export a v2 snapshot only after validation.
6. Never auto-migrate at startup.

## Disable And Rollback

- Disable event wakeups while retaining accepted inbox events.
- Re-enable reconciliation-only steward behavior.
- Stop Backoffice intent publication independently of mission display.
- Restore the exact v1 registry backup and previous skill/runtime revision if
  the v2 migration fails before accepted new transitions exist.
- After accepted v2-only transitions, roll forward from the event archive
  rather than silently discarding state.
