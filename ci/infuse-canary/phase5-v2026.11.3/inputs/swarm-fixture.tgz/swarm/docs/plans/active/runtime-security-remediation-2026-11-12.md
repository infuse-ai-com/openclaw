---
title: Runtime security remediation — 12 November 2026
description: Dependency repairs, scan evidence and continued remediation under the internal swarm's advisory-scan policy.
type: plan
status: active
owner: team:agent-platform
tags: [agents, security, dependencies, release]
---
# Runtime security remediation

The next work is the [13 November phased proposal](runtime-security-phased-plan-2026-11-13.md),
with fresh read-only runtime evidence and P1–P6 authorized for completion by
Fito's subsequent instruction. P6 remains a nonproduction worker prototype.

## 13 November policy and integration update

Fito approved merging source MR !55 and company-docs MR !13; both merged on
13 November after green source CI. He also approved non-blocking scan warnings for the
internal swarm. The [current delivery contract](../../GITLAB_DELIVERY.md#advisory-security-scans-2026-11-13)
supersedes this plan's earlier blocking vulnerability-exception requirements:
full findings remain visible, but finding changes, scan errors, missing reports
and historical exception expiry do not block deployment. Immutable image/source
verification, explicit release selection and manual rollout remain mandatory.
No image rollout or Ramiro mail resumption is included in this change.

The 7 December date remains a remediation review target, not a deployment cutoff.
Local `task verify-ci` passes 470 tests. GitLab CI Lint simulations validate
candidate, delivery and qualification graphs: scans allow failure, delivery
remains manual and depends only on verified image artifacts, and qualification
cannot instantiate deployment. The regression test fails on the former graph's
scan/exception dependencies and passes on the new policy.

The dated qualification evidence below is retained as observed; it is not a new
scan or a claim that native runtime qualification has completed.

## Approved remediation slice

Fito approved implementation of items 1–3 and investigation of item 4.
Dependency/source changes and local scan qualification are complete. Protected
release publication and native runtime qualification remain separate follow-ups.
Satwa is accountable for security evidence and release qualification; Tinus
implements repository fixes. The dependency work changed no production runtime,
credentials or mail schedules. The later CI policy change is recorded above.

## Implementation evidence

- Consumer lock now resolves MCP SDK 1.32.1, body-parser 2.4.0, undici 8.12.2
  and npm 12.2.2. Both npm bundles ship brace-expansion 5.0.12 and undici
  6.29.1; pnpm 12.18.0 ships undici 6.29.1. Bitwarden's existing 2026.10.0
  composition now pins multer 2.5.0 without changing its credential/profile contract.
- All eight Go tools retain their prior CLI source versions. The image builds
  them from checksum-verified sources/modules using pinned Go 1.27.4. The
  observed output modules include x/net 0.62.0, x/text 0.43.0 and go-jose 4.1.6
  where linked. Kubernetes remains 1.35.8; its build explicitly resolves the
  patched module graph instead of reusing vulnerable vendor copies.
- Linux AMD64 and ARM64 builds and all eight version-command smokes passed on
  both architectures in isolated, nonroot containers. Compiler and
  module receipts are retained in the image under
  `/usr/local/share/agent-go-build-info/`.
- The installed dependency gate rejects all 23 recorded vulnerable Node
  occurrences. The real temporary consumer resolves patched packages, constructs
  an MCP server, handles undici HTTP requests and survives a malformed compressed
  request before serving another successful request.
- Canonical `task verify-ci` passed, including 467 Python tests. Initial runs
  exposed stale assertions for the renamed glab architecture variable; those
  assertions were updated, retaining both architecture checksums. A host npm
  prefix-based install failed lock validation; the exact npm 12.2.2 installation
  in the consumer directory passed. The Linux image's normal `npm ci` also passed.
- [MR !55](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-k8s-swarm/-/merge_requests/55)
  contains the source changes. [Pipeline 1746](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-k8s-swarm/-/pipelines/1746)
  passed at `6b2bbef3c237cc1725486fe6b2b2a790f375dd43`. The first pipeline
  was rejected by runner admission because the repo's Playwright CI image was
  stale; the three CI uses now select the already-admitted 1.65 image/digest.
  No runner access policy or runtime Playwright version changed.
- Build context now excludes nested host `node_modules`; the behavioral plugin
  uses `npm ci` and its committed lock. This prevents local verification
  dependencies from entering the image and makes plugin installation consistent
  with a clean checkout.
- The final local image build and complete scan passed the remediation checks
  below. All 18 targeted HIGH IDs / 68 occurrences are gone, with no added
  finding tuples. The prior approved image and exception remain the production
  release; this source change grants no new digest acceptance.

## Local candidate qualification

The local AMD64 image was built from implementation commit
`6b2bbef3c237cc1725486fe6b2b2a790f375dd43`. Its OCI index is
`sha256:813eeb148bd8d887015535ef0f3c32224e2d03c31392d63b828c39a4ed4c2dee`
and image/config ID is
`sha256:c0cf5466a7936e6b2c12aa47d6ad1ab60152c2b890803faac6584681b7c23209`.
This is local qualification evidence, not a protected registry release.

[Download full qualification evidence](https://gitlab.infuse-ai-tech.party/-/project/70/uploads/640e8c69e0e3294693e15f6c486cbe15/runtime-security-qualification-20261112.zip)
(SHA256 `345e55c1979ffe79546632d4343e1ade5bb19464d9c50550c4a9c976589ff6ef`).
The bundle includes both raw HIGH/CRITICAL scans, comparison script and results,
source/image identity, binary receipts, verification logs and failed browser
diagnostics. No finding suppression was applied.

Both scans used Trivy 0.74.0, scanner image digest
`sha256:62b1e65e8869bc4b4c6aa4fa2b21595256c7c2f6018a9d9ad61caf87187c1969`,
offline scanning with database updates disabled, and byte-identical database
copies updated at `2026-11-12T18:57:38.498853214Z`. Database SHA256:
`024e3e42822e93b63a119eae8997d24425a8703b7bb463e5afc1bcec92da2e67`.

| Same-database comparison | Deployed baseline | Local candidate |
| --- | ---: | ---: |
| Distinct CRITICAL / occurrences | 16 / 34 | 16 / 34 |
| Distinct HIGH / occurrences | 477 / 832 | 459 / 764 |
| Fixable CRITICAL | 0 | 0 |
| Fixable HIGH / occurrences | 18 / 68 | 0 / 0 |
| Distinct finding tuples | 837 | 798 |

All 39 removed tuples are the targeted Node/Go findings. No tuple or ID was
added; all remaining detections are Debian packages without reported fixes in
this database. The fresh baseline has 58 more HIGH IDs than the historical
419-ID report, with the same image ID and no removed IDs. That is database
drift, not a candidate regression. CRITICAL IDs are unchanged.

The baseline and candidate raw-report SHA256 values are respectively
`805a1bf1b74d2822a5ff76b66f8e000ea5fe253e5d178fc8869bfeac47c4ef07` and
`3e8b131a649a21309c6647a553f399ca794244e6aaa943c4b61563a4c2a37361`.
Full-tuple SHA256 values are respectively
`0e32e2868243ef786a849eac6b9225f138904c8d5750686d5d34c23fbef6fbe4` and
`e91f86119ddc6185eae94a3e35355bc073db893fc55619eeafc1695619054e8f`.

Compatibility checks passed for actual installed dependencies, MCP construction,
HTTP parsing/error recovery, all eight Go CLI versions, npm/pnpm offline installs,
Bitwarden version, Compose configuration, Helm rendering and client-only kubectl
creation. The installed-tree gate rejects the deployed baseline's MCP SDK 1.31.0.
The Bitwarden version command's public configuration fetch was blocked by the
test container's disabled network; live cached-session sync was not tested.

The full offline smoke **failed at the browser step**. Both baseline and candidate
reproduce GPU process failures, QEMU signal 5 and `TargetClosedError` on this ARM64
Mac running AMD64 containers; their actual headless-browser executables match.
This comparison does not qualify native AMD64 browser behavior or sandboxing.
Before production rollout, publish a protected candidate, rescan that exact
registry digest and qualify native browser/plugin/auth flows. Retain residual
findings for remediation under the advisory policy. No production rollout or
new image approval is implied by this local qualification.

## Evidence and limits

- Source reviewed: swarm main `35a2dc9525bceb3c9f13eb01026212ad05c03375`.
- Image source: `5489df67301699056c91325fdfc79fe8519d5c56`.
- Image: `registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4`.
- On 12 November, a read-only query of the five deployments in context
  `infuseai-k8s`, namespace `agents-swarm`, returned this configured image and
  one ready replica each. This was deployment metadata, not an exploit test.
- Trivy 0.74.0 report created at `2026-11-12T15:19:16.303846856Z`, retained in
  [scan job 7433](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-k8s-swarm/-/jobs/7433).
  This is the historical baseline; the replacement is being compared with a
  fresh scan of that same image using one frozen scanner database.
- The [release qualification](agent-system-renewal-qualification-2026-11-12.md)
  owns scan hashes and approval evidence. The exception expires
  **2026-12-07T23:59:59Z**; this is historical acceptance evidence, not a current
  deployment gate under the 13 November policy.

| Report slice | Distinct CRITICAL | Distinct HIGH | Interpretation |
| --- | ---: | ---: | --- |
| Debian packages | 16 | 401 | No fixes reported by this scan; requires distro and runtime applicability review |
| Go binaries | 0 | 7 | 45 occurrences; fixes require rebuilt or replaced binaries |
| Node packages | 0 | 11 | 23 occurrences; fixes span the consumer and bundled CLI dependencies |
| Total | 16 | 419 | 18 fixable HIGH IDs / 68 occurrences; no fixable CRITICAL in this report |

These are package detections, not 435 demonstrated attack paths. The previously
fixable certifi and uv CRITICAL findings were already removed. A newer database
may change findings or fix availability; compare baseline and candidate with
the same scanner/database when qualifying the replacement.

## First fix: stop restoring vulnerable dependency versions

The baseline consumer lock recorded OpenClaw's dependency requests as MCP SDK **1.32.1**,
undici **8.12.2** and npm **12.2.0**. Its consumer overrides resolved older
MCP **1.31.0**, undici **8.11.2** and npm **12.1.0**. The image scan confirms
vulnerable installed copies. This is a local composition problem even though
the upstream package requests patched MCP and undici versions.

Inspect why each override exists, remove or update the downgrades, and regenerate
the sealed consumer package/lock through a reviewed change. Preserve the Core
archive checksum, source identity, lifecycle/native dependency handling and
Studio compatibility contract in [the runbook](../../RUNBOOK.md). If Core itself
must change, update the complete artifact/manifest contract. Never patch an
installed production dependency tree or substitute an unverified archive.

| Owning surface | Baseline installed evidence | Remediation contract | Required proof |
| --- | --- | --- | --- |
| `images/openclaw-agent/openclaw-consumer/package.json` and `package-lock.json` | `@modelcontextprotocol/sdk` 1.31.0 at `/opt/openclaw-consumer/node_modules/@modelcontextprotocol/sdk` | At least 1.32.0; prefer the package's requested compatible 1.32.1 after testing | Actual installed version; MCP HTTP validation and session/task isolation where enabled |
| Same consumer | `body-parser` 2.3.0 at `/opt/openclaw-consumer/node_modules/body-parser` | 2.4.0 or compatible newer release; reconcile version-specific override entries | Gateway/HTTP parsing, including malformed compressed requests in isolated tests |
| Same consumer | undici 8.11.2 under `node_modules/openclaw/node_modules/undici` | At least 8.12.2 on the existing major; align with the package requirement | Installed nested version; TLS/proxy, HTTP streaming and connection-error handling |
| Consumer npm plus global npm in `images/openclaw-agent/Dockerfile` | Both contain brace-expansion 5.0.9 and undici 6.28.0 | Select npm releases whose shipped bundles contain fixed dependencies: brace-expansion at least 5.0.11 and undici at least 6.29.1 on that major | Inspect both npm bundle trees; install/version smoke with temporary state |
| Global pnpm in Dockerfile | undici 6.28.1 at `/usr/local/lib/node_modules/pnpm/dist/node_modules/undici` | Select a pnpm release shipping fixed undici, at least 6.29.1 if it remains on major 6 | Inspect the packaged nested tree, then package-manager smoke |
| Bitwarden CLI composition in Dockerfile | Explicit `dependencies.multer=2.3.0` at `/usr/local/lib/node_modules/@bitwarden/cli/node_modules/multer` | 2.5.0 or compatible newer release; prefer a vendor release carrying the fix | Existing cached Vaultwarden session/profile migration and sync smoke; no credential rotation |

The baseline top-level brace-expansion override already said **5.0.12**, yet npm's bundled
copies were **5.0.9**. A manifest-only check therefore gave false confidence.
Add an installed-tree regression check for these actual paths, including
bundled packages, alongside the complete image scan. Do not force undici 8 into
consumers built for undici 6 merely to satisfy one global override.

Primary advisories confirm the [MCP session fix](https://github.com/modelcontextprotocol/typescript-sdk/security/advisories/GHSA-22jm-h49p-29qw),
[MCP HTTP validation fix](https://github.com/modelcontextprotocol/typescript-sdk/security/advisories/GHSA-46jr-4wx8-v453),
[body-parser fix](https://github.com/expressjs/body-parser/security/advisories/GHSA-27r3-jxmh-p828),
[undici TLS fix](https://github.com/nodejs/undici/security/advisories/GHSA-2m5v-pch6-74hx)
and [multer fix](https://github.com/expressjs/multer/security/advisories/GHSA-q7qp-rjg7-q26m).
Exposure still needs code/configuration evidence: MCP task isolation applies
when a server uses `taskStore`; the HTTP issue does not affect stdio-only
servers; the cited undici bypass affects custom TLS verification callbacks;
the multer issue involves asynchronous file filtering. Package presence alone
does not prove those conditions in the deployed agent.

## Rebuild or replace the Go tools

| Baseline ownership in `images/openclaw-agent/Dockerfile` | Affected tools | Change and verification |
| --- | --- | --- |
| `go-toolbox-builder` | Task, kubectl, Kustomize | Raise the pinned compiler/base digest; update module or vendored inputs; inspect each output with `go version -m` |
| Downloaded releases and architecture-specific checksums | crane, Docker CLI, gog, Helm, Docker Compose | Select verified releases built with patched Go/modules, or review reproducible source builds; a builder-stage bump cannot repair downloaded binaries |

The scan's minimum compiler fixes are **Go 1.26.10 / 1.27.3**. The official
[release history](https://go.dev/doc/devel/release) now lists **1.26.11 / 1.27.4**
with additional security fixes. Evaluate the current patch release on the
compatible supported line, not the scan's older minimum alone.

Module floors from the recorded advisories:

- `golang.org/x/net` **0.62.0**: gog, Helm, kubectl, Task and Compose.
  [HTML parser advisory](https://pkg.go.dev/vuln/GO-2026-6860).
- `golang.org/x/text` **0.41.0**: kubectl and Kustomize.
  [Nickname profile advisory](https://pkg.go.dev/vuln/GO-2026-6629).
- `github.com/go-jose/go-jose/v4` **4.1.6**: Task.
  [JWK parsing advisory](https://github.com/go-jose/go-jose/security/advisories/GHSA-mgcc-cww5-fp2q).

The baseline Kustomize build explicitly pinned x/text 0.39.0. kubectl built Kubernetes
1.35.8 with `-mod=vendor`, so changing a separate module requirement is
insufficient: select a compatible Kubernetes source patch with fixed vendor
contents, or review a source/vendor patch and checksum. Confirm client/server
compatibility before selecting a Kubernetes minor version. Preserve provenance
for every output and verify actual compiler/module versions after the build.

Use offline/local smoke coverage for CLI behavior and read-only runtime checks
where needed. A Go module detection does not establish vulnerable symbol
reachability; use symbol/call-path evidence to refine residual risk.

## Reduce the shared image and triage the critical findings

The persistent image installs `build-essential`, `ruby-full`, distro Chromium,
Xvfb and ImageMagick, and separately installs Playwright Chromium. This is at
odds with the preferred [separate browser/build workers](../../SECURITY.md).
Recommendation: retain the core runtime and proven everyday tool requirements;
move heavy or role-specific capabilities to explicit workers after validating
their callers. Do not remove capabilities solely to lower the scan count.

Measured concentration in this report:

- `linux-libc-dev`: **190 HIGH + 1 CRITICAL occurrences**. These are container
  development headers; this image scan does not establish the host kernel's
  patch level or exploitability. Check actual runtime compilation needs and
  host-kernel posture separately.
- `chromium` and `chromium-common`: **90 HIGH occurrences each**, with the
  same IDs repeated across the two packages. Confirm which browser the native
  browser tool and Python/Node Playwright paths actually launch before removing
  either distribution. Scan the retained browser/worker independently.
- Ruby 3.1 runtime/dev/docs packages repeat **six CRITICAL IDs** across four
  packages, accounting for **24 of 34 CRITICAL occurrences**. Establish which
  agent workflows need Ruby/Bundler; isolate or upgrade that capability.
- Other CRITICAL package families: libaom3, GLib, LMDB, SQLite, libxml2,
  OpenSSH client and zlib. Record installed/source versions, distro status,
  reachable functionality and disposition for every ID.

For example, [Debian's CVE-2023-45853 record](https://security-tracker.debian.org/tracker/CVE-2023-45853)
states that the affected MiniZip code is not built from the Bookworm zlib
source package. This supports a package-specific non-applicability candidate,
subject to checking the image's package provenance and other MiniZip copies.
It is not a reason to suppress all zlib findings or claim the image is clean.

Compare a supported newer Debian base in an isolated candidate after the
dependency fixes. Verify Node/native extensions, Python tooling, browser
libraries, UID/permissions and startup. The existing Dockerfile already runs
`apt-get upgrade`; repeating that instruction alone is not a remediation plan
for findings without fixes on the current distribution.

## Execution order and completion evidence

| Step | Owner | Status / exit condition |
| --- | --- | --- |
| R0 — map findings to installed owners | Tinus / Satwa | Assessment complete from job 7433; runtime reachability and fresh scan remain open |
| R1 — consumer and CLI dependency repairs | Tinus | Implemented in MR !55; installed consumer and isolated HTTP/MCP smoke passed; full local image scan removes all targeted Node findings |
| R2 — Go binary repairs | Tinus | All eight AMD64 and ARM64 outputs built and metadata/CLI smoke passed; full local image scan removes all targeted Go findings |
| R3 — critical applicability and image contents | Satwa with Tinus | Investigation below complete to stated bounds; removals, sandbox changes and base migration remain proposed |
| R4 — exact candidate qualification | Satwa | Source CI and local same-database full scans passed; no targeted fixable HIGH or added tuples. Protected registry build/scan and native AMD64 browser/auth qualification remain pending |
| R5 — release decision and staged verification | Satwa; Fito authorizes rollout | Pending: select exact new digest/source; scan warnings remain advisory; Tinus canary then fleet, startup/plugins/auth/browser/memory collector evidence and rollback boundary |

R1/R2 are the approved implementation slice. R3 remains investigation and
recommendations, with no package removals or live sandbox changes. Review the
remaining remediation **by 7 December** under the current advisory-scan policy.

Run the owning repository's verification for implementation, then the protected
candidate build/full scan and mandatory immutable-image verification. A
pipeline with an allowed-failing scan is not evidence of a clean image. Record scanner
and database versions, full and fixable tuple deltas, installed dependency
evidence and every residual disposition. Preserve raw findings; this approval
does not authorize suppression or removal of the scan.

Ramiro's mail remains paused throughout. Do not send messages or resume mail
jobs as a side effect of qualification. The completed memory cleanse and
own-agent credential boundaries remain intact.

## Item 4 investigation and recommendations

Read-only evidence on 12 November covered all five agents' allowlisted browser
settings and browser executable/sandbox flags, plus Tinus's package versions and
installed reverse dependencies. No browser processes were active during that
snapshot. No private session history, URLs, mail or credentials were collected.

### Browser isolation is the first follow-up

Tinus and Emon explicitly configure `browser.noSandbox=true`. Stewie, Satwa and
Ramiro omit that override and have the repository's
[Chromium seccomp profile](../../../k8s/platform/chromium-sandbox/README.md).
Do not infer a successful sandbox launch from those configuration facts alone.
The existing Playwright smoke also launches without an explicit sandbox option;
Playwright's [documented default is disabled](https://playwright.dev/docs/api/class-browsertype).

Recommendation: qualify sandboxed native and Python/Node Playwright launches for
every role, then move untrusted browser work to a worker without the agent's
credential environment or memory PVC. The native browser panel/session contract
must keep working through that worker. These are proposed runtime changes,
not part of the applied dependency remediation.

The pinned OpenClaw resolver tries system Chromium before its Playwright-cache
fallback. The runtime capability contract explicitly requires a `chromium`
command, while Python Playwright uses the managed browser cache. Tinus has
Chromium 156.0.8078.79; the image also installs Playwright's Chromium 153.0.8010.12.
Therefore deleting the distro browser now would change both routing and the
capability contract, and retaining only the older Playwright browser could
reduce patch freshness. Qualify a single supported browser distribution or the
worker contract first; scan that artifact independently.

### Candidate removals and replacements

| Surface | Observed dependency or contract | Recommendation |
| --- | --- | --- |
| Ruby runtime/dev/docs + Bundler | Present in every shared image and toolbox smoke; no Ruby/Bundler invocation found in current startup scripts or installed skill Markdown | Best first removal candidate after a bounded job-usage check; provide a pinned worker for actual Ruby projects. Six CRITICAL IDs repeat across four Ruby packages. Absence in inspected source is not proof of never being used interactively. |
| Compilers/development headers | `build-essential` pulls libc development headers and `linux-libc-dev`; general project/native-extension builds can need them | Keep in build workers and image builder stages; qualify native optional installs and developer workflows before removing from persistent runtime. Header CVEs are not proof of a vulnerable running kernel. |
| System Chromium + Playwright browsers/Xvfb | Distinct current consumers and declared capability checks | Consolidate only after native browser, Python/Node Playwright and headed-debug qualification; prioritize sandbox/credential isolation first. |
| ImageMagick/HEIF/libaom | `libaom3 <- libheif1 <- libmagickcore-6.q16-6`; contact-sheet capability runs convert/identify/montage | Preserve PNG/JPEG/contact sheets; isolate untrusted media conversion or build a bounded codec set. Do not blindly remove libaom while retaining the dependent package graph. |
| LMDB/DNS utilities | `liblmdb0 <- bind9-libs`; the image installs DNS diagnostic tools | Retain diagnostic coverage through a smaller tool or infra worker if removing this chain. No arbitrary LMDB database reader was identified in inspected startup/skill paths. |
| SQLite, XML, SSH | General runtime/tooling libraries | Keep while tracing actual consumers; evaluate distro security status and safe input/auth boundaries. A base upgrade alone does not fix every outstanding finding. |

### All 16 baseline CRITICAL IDs: applicability and disposition

The raw scan remains intact. No VEX assertion, ignore rule or exception expansion
was added. Vendor severity and preconditions differ from the scan classification.

| IDs / package | Verified upstream or distro evidence | Proposed disposition |
| --- | --- | --- |
| CVE-2026-110264, -89078, -93577, -97229 / Ruby regexp | Debian tracks the Ruby interpreter as affected, despite the advisories' GitLab trigger examples; Trixie Ruby 3.3.13 has security fixes ([example](https://security-tracker.debian.org/tracker/CVE-2026-110264)) | Remove/isolate unused Ruby; do not dismiss merely because this image is not a GitLab server |
| CVE-2026-27820 / Ruby zlib | GzipReader buffer handling issue; patched Ruby gem versions are listed in [Debian's record](https://security-tracker.debian.org/tracker/CVE-2026-27820) | Same Ruby removal/isolation path; verify gem version if retaining Ruby |
| CVE-2026-42257 / Ruby net-imap | Raw command arguments can inject IMAP commands; fixed by [Ruby's net-imap update](https://www.ruby-lang.org/en/news/2026/07/16/ruby-3-3-12-released/) | Same Ruby path; no Ruby IMAP workflow found in inspected skills/startup; mail remains paused |
| CVE-2023-6879 / libaom3 | AV1 multithreaded encoder heap overflow; [Trixie fixed, Bookworm unfixed](https://security-tracker.debian.org/tracker/CVE-2023-6879) | Trace media encoding routes; isolate conversion or test newer-base codec stack |
| CVE-2026-58016 / GLib | Malformed D-Bus introspection XML causes OOB-read/DoS; [Trixie fixed, Bookworm postponed](https://security-tracker.debian.org/tracker/CVE-2026-58016) | Browser/desktop dependency review and newer-base comparison; reachable introspection input not established |
| CVE-2019-16224, -16225, -16227 / LMDB | Require attacker-supplied or corrupted database files; Debian still marks LMDB unfixed in both Bookworm and Trixie ([record](https://security-tracker.debian.org/tracker/CVE-2019-16224)) | Review DNS-tool linkage and absence of untrusted LMDB ingestion; replace/remove only with diagnostic coverage |
| CVE-2025-7458 / SQLite | Requires execution of crafted SQL; [Trixie fixed, Bookworm unfixed](https://security-tracker.debian.org/tracker/CVE-2025-7458) | Distinguish trusted application queries from arbitrary SQL ingestion; retain library and test newer base |
| CVE-2026-6653 / libxml2 | Crafted XML/entity handling; [both Bookworm and Trixie remain affected](https://security-tracker.debian.org/tracker/CVE-2026-6653) | Trace XML consumers and isolation; do not claim Trixie alone closes it |
| CVE-2026-99083 / linux-libc-dev | [Kernel ksmbd vulnerability](https://security-tracker.debian.org/tracker/CVE-2026-99083); image package contains development headers | Separate host kernel/ksmbd assessment from image remediation; remove headers only after build capability moves |
| CVE-2026-60002 / openssh-client | Client-side host-key re-exchange UAF; [Bookworm and Trixie affected](https://security-tracker.debian.org/tracker/CVE-2026-60002) | Preserve required SSH workflows; assess patched client/backport and trusted-host boundaries |
| CVE-2023-45853 / zlib1g | [Bookworm zlib does not build vulnerable MiniZip code](https://security-tracker.debian.org/tracker/CVE-2023-45853); installed separate libminizip1 is 1.1-8+deb12u1, Debian's fixed version | Strong package-specific non-applicability evidence; review separately before any suppression |

Recommended follow-up order: sandbox/worker boundary, Ruby and build-tool usage
pilot, browser consolidation and media/DNS dependency review, then a supported
newer-base candidate. Trixie addresses some of these IDs, but XML, SSH and LMDB
still need separate handling. No removals or distro migration were applied.

## Recorded fixable IDs

For reconciliation against job 7433 (not a replacement for a fresh scan):

- Node, 11 IDs: CVE-2026-102276, CVE-2026-102278, CVE-2026-109383,
  CVE-2026-109829, CVE-2026-109869, CVE-2026-111181, CVE-2026-111767,
  CVE-2026-111768, CVE-2026-113872, CVE-2026-19534, CVE-2026-87018.
- Go, 7 IDs: CVE-2026-111943, CVE-2026-116587, CVE-2026-56851,
  CVE-2026-78661, CVE-2026-78667, CVE-2026-78669, CVE-2026-97031.
