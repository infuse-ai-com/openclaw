---
title: Langfuse v4 telemetry cutover
description: Plan the privacy-preserving OpenClaw Collector cutover from Langfuse v3 to a clean Langfuse v4 project.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - observability
  - langfuse
  - opentelemetry
  - kubernetes
---

# Plan: Langfuse v4 telemetry cutover

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


- **Status:** Implemented; live verification pending
- **Prepared:** 2026-10-16
- **Repository:** Azure DevOps `Infuse AI / openclaw-k8s-swarm`
- **Runtime boundary:** OTel Collector destination and aggregate audit only

## Outcome

Move the existing privacy-bounded OpenClaw telemetry pipeline to the fresh
Langfuse v4 project `OpenClaw Agents Swarm` (`openclaw-swarm`) without rolling the
five agents. Only the OTel Collector is rolled for endpoint/key changes.

## Current source coupling

- Collector endpoint:
  `http://langfuse-web.langfuse.svc.cluster.local:3000/api/public/otel`.
- Exporter authentication: Secret
  `agents-swarm/openclaw-observability-exporters`, single key
  `LANGFUSE_OTEL_AUTH_HEADER`.
- The exporter sends `x-langfuse-ingestion-version: "4"`.
- Secret sync requires exact project ID `openclaw-swarm` and name
  `OpenClaw Agents Swarm`.
- Aggregate audit uses `/api/public/v2/observations`, bounded time filters,
  selective fields, and cursor pagination.

The privacy processor, resource allowlist, noise filter, tail sampling,
span-metrics pipeline, queue/retry policy, and fail-open agent behavior are
preserved.

## Required implementation

1. Point `otlp_http/langfuse` at the reviewed internal endpoint
   `http://langfuse-web.langfuse.svc.cluster.local:3000/api/public/otel`,
   subject to rendered Service-name verification.
2. Keep Basic authorization and add
   `x-langfuse-ingestion-version: "4"`.
3. Replace the hard-coded project ID only after the new project's exact ID and
   name are verified through `/api/public/projects`.
4. Keep the Secret's one-key contract and existing Vaultwarden item names;
   write replacement values first and verify exact project scope. Old invalid
   credentials are not reintroduced into Kubernetes.
5. Move the aggregate-only audit to
   `/api/public/v2/observations` with bounded time filters, cursor pagination,
   required field groups only, and strict response-shape checks.
6. Update focused tests for the internal endpoint, ingestion header, v4
   project identity, v2 cursor behavior, privacy fields, and content absence.

The collector currently has no egress-isolating NetworkPolicy, so the internal
`langfuse/langfuse-web` route is reachable without changing the network policy.
Agents continue to send OTLP to the in-cluster collector unchanged.

## Cutover gate

1. Verify the new project-scoped key pair returns only
   `OpenClaw Agents Swarm` (`openclaw-swarm`).
2. Sync the one-key Secret and roll
   `deployment/openclaw-otel-collector` once.
3. Generate one bounded smoke from each of:
   `agent-coordinator`, `agent-developer`, `agent-designer`,
   `agent-infra`, and `agent-intake`.
4. Verify expected turn/model/tool/workflow/skill/wrapper/Knowledge Base
   signals, ancestry, and lifecycle integrity.
5. Verify zero input/output content and zero forbidden attributes.
6. Verify the three healthy Gateway RPC envelope families remain absent.
7. Verify queue drain, zero new refused spans/exporter failures, no cutover
   restart loop, and continuous Prometheus span metrics.
8. Verify the v4 aggregate audit and a 15-minute no-new-observations window in
   the old v3 project.

## Rollback

Restore the previous Collector Deployment revision, which removes the Langfuse
pipeline while preserving Prometheus span metrics. Do not roll back agent
Deployments. A failed privacy gate, project-scope check, queue drain, or
aggregate audit blocks cutover.

## Plan acceptance

- [x] Exact v4 Service endpoint confirmed from the reviewed Langfuse render.
- [x] New project ID recorded without exposing key material.
- [x] Focused unit/render tests and Collector config validation pass.
- [x] Persistent agent Deployments are explicitly preserved for this change.
- [ ] Live Secret sync and Collector rollout complete with v4 observation proof.
