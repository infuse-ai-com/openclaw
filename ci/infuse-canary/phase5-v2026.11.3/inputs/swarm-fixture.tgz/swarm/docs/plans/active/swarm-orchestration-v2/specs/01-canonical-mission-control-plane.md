---
title: Spec 1 - Canonical Mission Control Plane
description: Transition-safe v2 mission registry, task lifecycle, migration, locking, evidence, leases, and snapshots.
type: architecture
status: active
owner: team:agent-platform
tags: [agents, orchestration, missions, registry]
---
# Spec 1 - Canonical Mission Control Plane

## Outcome

Emon has one durable, transition-safe mission registry that survives restarts,
rejects ambiguous lifecycle changes, and produces an honest read-only snapshot.

## Baseline

`infuse.team-missions/v1` already provides atomic JSON replacement, one active
mission per project, task and artifact records, next actions, trigger-aware
steward planning, action fingerprints, explicit migration from unversioned
state, and read-only snapshot export.

## Required Behavior

### Mission lifecycle

Allowed mission states remain:

`planned`, `active`, `blocked`, `waiting_for_human`, `integration_review`,
`ready_to_merge`, `done`, `cancelled`.

Every state change must use an explicit transition table. Terminal missions do
not reopen without a named `reopen` transition, reason, actor, and expected
mission revision. `done` requires all required tasks `verified`, all mandatory
gates resolved, a closeout summary, and at least one closeout evidence record.

### Task lifecycle

```text
planned -> assigned -> acknowledged -> active
assigned -> declined
acknowledged|active -> waiting|blocked
waiting|blocked -> active
active -> delivered -> review -> verified
delivered|review -> active
any non-terminal -> cancelled
```

Direct `assigned -> active`, `active -> verified`, and `delivered -> verified`
transitions are invalid. A task in `declined`, `verified`, or `cancelled` is
terminal unless the transition engine performs an explicit coordinator-owned
replacement or reopen operation.

### Assignment and acknowledgement lease

An assignment records:

- assigned agent and role;
- exact handoff pointer and Mattermost role-channel/thread pointer;
- assignment timestamp;
- acknowledgement deadline;
- optional execution review time, not a hard execution kill deadline;
- capability-preflight revision;
- latest material-event timestamp.

An expired acknowledgement lease creates one actionable state for Emon. It
does not automatically reassign, mention, cancel, or retry the task.

### Requirements and evidence

Each task records observable acceptance criteria, verification expectations,
dependencies, capability requirements, and evidence pointers. Evidence records
contain an allowlisted type, immutable ref, producer, observed timestamp, and
optional independent verifier. Raw logs and private payloads remain outside the
registry.

### Concurrency and idempotency

- Registry mutations take an exclusive lock with bounded wait.
- Every mutation supplies expected mission or registry revision.
- A stale writer receives a conflict without changing state.
- Applied event and transition idempotency keys are recorded in a bounded
  processed-event index or durable event archive.
- Registry replacement remains atomic and fsync-backed.

### Migration

The v1-to-v2 migration:

- requires explicit invocation and an exact backup path;
- refuses invalid v1 data;
- preserves all source, thread, artifact, summary, and timestamp fields;
- maps historical task `done` to `delivered` unless verification is explicit;
- is idempotent on valid v2 data; and
- emits a machine-readable migration report without content-bearing fields.

### Snapshot

The exported snapshot contains schema, registry revision, generated time,
source label, and validated missions. It excludes internal lock, processed
event, credential, and inbox state. Backoffice must render unknown schema,
invalid data, and stale freshness honestly.

## Acceptance Criteria

- Unit tests cover every allowed and forbidden mission/task transition.
- Two concurrent writers cannot silently lose an update.
- A repeated transition or event with the same idempotency key is a no-op.
- Stale expected revision fails with no file change.
- A v1 fixture migrates with byte-exact backup and pointer preservation.
- `done` is rejected when required tasks or gates remain unresolved.
- Snapshot export is deterministic for unchanged canonical state apart from
  the documented generation timestamp.
- Registry and snapshot validation reject secret-shaped and content-bearing
  fields.

## Non-Goals

- Multi-coordinator writes.
- Automatic reassignment.
- A general workflow engine or arbitrary DAG executor.
- Storing complete chat, CI, or runtime logs.

## Owning Repositories

- Primary: `agent-skills`.
- Runtime consumption and validation: `openclaw-k8s-swarm`.
- Projection compatibility: `backoffice`.

## Rollback

Retain the exact v1 registry and previous helper revision. Disable v2 mutation
before restore. Once accepted v2-only events exist, recover by replaying the
bounded event archive into a repaired v2 registry rather than reverting state.
