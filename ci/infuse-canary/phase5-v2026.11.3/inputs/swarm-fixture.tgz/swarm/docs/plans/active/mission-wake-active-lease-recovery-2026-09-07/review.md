---
title: Active-Lease Wake-Ticket Recovery Review
description: Source-bound review and verification evidence for active-lease wake-ticket recovery.
type: evidence
status: active
owner: team:agent-platform
tags: [evidence, agents, mission-continuation, recovery]
---

# Review: Active-Lease Wake-Ticket Recovery

## Source And Boundary

- Base: `origin/main` at `d1af3dbd0e5325a09169353daf56b089f4c2a758`.
- Branch: `fix/mission-wake-active-lease-recovery-20260907`.
- Source-only review; no runtime, canary, policy, credential, or channel mutation.

## Red/Green Evidence

Before the implementation, the late-ticket regression returned
`watcher_pending` and recorded zero status lookups. After moving stable-key
lookup ahead of the watcher short circuit, it records one lookup using the same
wake reference, adopts the late ticket, returns `internal_pending`, performs
only one original submission, and keeps the watcher count at one.

## Verification

- Focused wake suite: 24 tests passed.
- `task verify-ci`: 380 Python tests and 29 Node tests passed, together with
  shell syntax, rendered Kubernetes overlays, policy, skill, persona,
  credential, memory, task-workspace, Artifact Registry, observability, and
  canary checks.
- Changed Python byte-compilation and `git diff --check` passed.

## Review Findings

- Recovery calls only `runner.status`; the active-lease path never calls
  `runner.run`.
- Existing ledger conflict checks reject a different ticket id for the same
  wake reference.
- A recovered queued/started ticket suppresses another watcher. A missing or
  terminal ticket preserves the prior fallback and processing-grace behavior.
- No schema, credential, route, admission, or OpenClaw change is introduced.

## Remaining Gate

Protected Azure PR CI must pass on the exact pushed commit. Merge and deployment
remain separately approval-gated.
