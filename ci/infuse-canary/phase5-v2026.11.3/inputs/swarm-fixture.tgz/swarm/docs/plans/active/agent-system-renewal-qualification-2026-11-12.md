---
title: Agent system renewal qualification — 12 November 2026
description: Exact source, approved candidate, scan comparison, live canaries and staged rollout evidence.
type: plan
status: active
owner: team:agent-platform
tags: [agents, gitlab, operations, assurance, release]
---
# Agent system renewal qualification

The later [memory mirror qualification](agent-memory-mirror-qualification-2026-11-12.md)
owns current memory publishing, retrieval and PVC cleansing. Earlier MR transport
receipts below remain historical evidence.

The [security remediation assessment](runtime-security-remediation-2026-11-12.md)
maps the remaining findings to installed dependency owners and orders the next
fixes. It records a plan, not a replacement image or new risk acceptance.

## Current release

Image source is `5489df67301699056c91325fdfc79fe8519d5c56` (swarm MR !49).
[Pipeline 1666](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-k8s-swarm/-/pipelines/1666)
built it in job 7432 and scanned it in job 7433. Both artifacts identify:

`registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4`

Source qualification passed 456 Python tests plus shell, bundle/catalog,
IKF and runtime contracts. The image retains OpenClaw 2026.11.1. The scan job
fails on unsuppressed findings and is allowed to fail; pipeline status alone
is not security acceptance. The exact policy and local guard match this
report. Protected pipeline 1670 verified registry provenance (job 7437),
rescanned the image (job 7438, visibly failed/allowed on findings) and passed the
blocking exception guard (job 7439). MR !50 merged policy as `e0d306f2a047`.

Fito instructed proceeding with renewal and tracking vulnerability remediation
on 12 November, after reviewing the initial candidate's risk. This final report
is strictly within that reviewed finding set: both fixable CRITICAL findings
are removed, with no added finding tuples. The exception records this authority,
final digest, source and scan; it expires **2026-12-07T23:59:59Z**. It is temporary
acceptance, not a clean-image claim or blanket permission for later rebuilds.

## Scan evidence

Trivy 0.74.0 reports are compared at exact artifacts, not inferred from package
changes. Baseline job 7240 scanned deployed `df3c3b86…`; initial candidate job
7412 scanned `7edfc1db…`; final job 7433 scanned `acf9b596…`.

| HIGH/CRITICAL evidence | Prior deployed report | Initial reviewed candidate | Final candidate |
| --- | --- | --- | --- |
| Distinct CRITICAL / occurrences | 18 / 36 | 18 / 36 | 16 / 34 |
| Distinct HIGH / occurrences | 409 / 698 | 419 / 717 | 419 / 717 |
| Complete finding tuples | 705 | 724 | 722 |
| Fixable CRITICAL / occurrences | 2 / 2 | 2 / 2 | 0 / 0 |
| Fixable HIGH / occurrences | 18 / 68 | 18 / 68 | 18 / 68 |
| Fixable tuples | 41 | 41 | 39 |

Final complete tuple hash:
`44e584a68ccb927ace0454c2de9c32c63324a52a738b19cff03337e30e708eca`.
Final fixable tuple hash:
`05a3736c4f05449229c5cd1e506635523f685c806bd906ca1d78924c02143a2e`.
The ten newly reported HIGH IDs versus the prior deployed report have no fixes
in these reports: six Chromium IDs, three Git IDs and one linux-libc-dev ID.
Newly reported does not establish that this source change introduced them.

The owned Python toolbox updates only certifi (2026.7.22 → 2026.10.19) and uv
(0.12.17 → 0.13.4), with regenerated Python 3.11 hashes; all other versions are
preserved. The final scan proves removal of both fixable CRITICAL findings.
Primary evidence: [certifi advisory](https://github.com/advisories/GHSA-6q48-6c7w-9gw2)
and [uv advisory](https://github.com/advisories/GHSA-hq85-5cpj-mr62).

Satwa owns remaining image findings and the expiry review; Tinus owns bounded
fixes and regression evidence. Before 7 December, inventory the 18 fixable HIGH
IDs by owning dependency, test compatible updates or reduced image contents,
rebuild and rescan, and record each disposition. Track the 16 CRITICAL and
remaining HIGH IDs without fixes for upstream updates. Any continuing exception
needs fresh, exact-image evidence and a new decision before expiry.

### Remaining fixable inventory

This inventory comes from final scan job 7433. Reported fixed versions are
inputs for compatibility review, not approval to override sealed runtime
packages. Upgrade the owning package/binary and regenerate its lock/checksum;
then run contract tests, rebuild and compare the complete scan again.

| Package family | Installed versions reported | Fixed versions reported / next action |
| --- | --- | --- |
| `@modelcontextprotocol/sdk` | 1.31.0 | 1.32.0; two HIGH IDs |
| `body-parser` | 2.3.0 | 2.4.0 on this major; one HIGH ID |
| `brace-expansion` | 5.0.9 | 5.0.11 covers both reported HIGH IDs on this major |
| `multer` | 2.3.0 | 2.5.0; one HIGH ID |
| `undici` | 6.28.0, 6.28.1, 8.11.2 | Five HIGH IDs; reported fixes vary by advisory and major (6.29.1, 7.30.1, 8.12.2); review each consuming dependency |
| Go standard library | 1.26.6, 1.26.8, 1.27.1 | Four HIGH IDs; 1.26.10 or 1.27.3 covers the reported fixes. Replace affected crane, Docker, gog, Helm, kubectl, Kustomize, Task and Compose binaries with verified upstream builds |
| `golang.org/x/net` | 0.56.0–0.59.0 | 0.62.0 covers both reported HIGH IDs; embedded in gog, Helm, kubectl, Task and Compose |
| `golang.org/x/text` | 0.39.0 | 0.41.0; embedded in kubectl and Kustomize |
| `github.com/go-jose/go-jose/v4` | 4.1.4 | 4.1.6; embedded in Task |

IDs overlap between Go package families, so family counts must not be summed
as distinct vulnerabilities. The authoritative total remains 18 HIGH IDs,
68 occurrences and 39 fixable tuples.

## Live qualification before rollout

- All five existing pods are ready on OpenClaw 2026.11.1 (`19818bb`). Their
  GitLab API identity and native Git reads resolve to their own accounts.
- The image-owned native bootstrap passed a Tinus canary without a skills
  checkout. Exact merged skill source `132fb9f8e509` also passed own-identity,
  invalid ambient-token isolation and mismatched-agent rejection checks.
- All fifteen skills/persona/memory checkouts are clean, on known Azure origins
  at ancestors of the reconciled GitLab sources. Exact-origin migration can
  fast-forward without discarding work.
- Model-policy, token-usage and scheduler feeds contain fresh five-agent results.
  The legacy cron-calendar feed is historical. Earlier daily memory sync
  reported five no-change results; those do not prove changed-content writes.
- All five enabled Memory Dreaming Promotion jobs last succeeded at 03:00 UTC
  on 12 November. Retired mission stewards, heartbeats and portfolio review
  remain disabled. Ramiro's triage, prefilter and client-waiting reminders
  remain paused by Fito's decision. Mailbox TLS succeeded but login failed;
  no mail was fetched or sent, and SMTP was not exercised.
- Weekly assurance schedule 27 remains Mondays 05:15 Europe/Madrid. Last run
  1353 failed on 9 November before this runtime. It is historical evidence;
  recovery/restore readiness remains explicitly unqualified.

## Review-only memory decision and canary

Fito chose memory MRs for review for now, with a follow-up to improve the
workflow. The deterministic writer never merges, even if a token could. A
successful exact-head pipeline produces `review_pending`, preserves the branch,
and reuses the same MR. A later run reconciles a reviewer-completed immutable
merge before submitting newer memory. Failed checks and closed/rejected MRs
remain actionable. Protected main and existing Developer access are unchanged.

An isolated Tinus checkout published one factual qualification receipt, no
profiles or private memory, as `agent-developer` (user 16):
[memory MR !5](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory/-/merge_requests/5),
source `e35232ef3a0bfdeefd35398154c4615d8b372d93`, pipeline 1648 passed.
An initial auto-merge attempt was denied; no operator token was substituted.
After the decision, **two live runs** returned `review_pending` for the same MR
and branch with exit zero. Local integration also covers reviewer-merged
reconciliation. MR !5 stays open for review.

Emon owns the future memory acceptance proposal. Preserve own-agent authorship,
CI, auditability and bounded review; broad Maintainer grants are not a shortcut.
The collector allows 420 seconds per agent and a 2400-second Job deadline with
concurrency forbidden. The old 180-second outer bound could kill valid Git/vault
work around the helper's own 180-second MR gate.

## Promotion and recovery contract

1. Merge the exact-image selection through normal CI and pass protected registry
   identity verification. Retain the full rescan as advisory evidence under the
   [13 November policy](../../GITLAB_DELIVERY.md#advisory-security-scans-2026-11-13);
   the former blocking vulnerability-exception guard is retired.
2. Capture five Deployments and five maintenance CronJobs privately. Each own
   PVC already has private recovery copies of Git config, source heads, managed
   skills and installed persona files. MEMORY.md is untouched. These copies
   establish resource/source recovery, not a qualified PVC restore exercise.
3. Server-dry-run the bounded manifest delta: agent and TLS-sidecar image,
   source annotations, canonical source URLs/required-sync flags, reviewed
   skill grants and removal of Azure credential mounts. Preserve PVCs, state,
   models, gateway/TLS configuration and unrelated environment.
4. Drain and promote Tinus first. Verify immutable image/source, live skill
   discovery and bundle parity, persona parity, own API/native Git identity,
   source origins, cron pause state and intended outputs. Promote remaining
   specialists, then Emon. Stop on an unresolved failure.
5. Update the five existing maintenance CronJobs to the same qualified image;
   change only memory timeout/deadline and the proposal review URL otherwise.
   Preserve schedules, identities and pause state. Do not manually invoke
   notifier work that could message others merely to test compatibility.
6. Recovery uses captured same-version `df3c3b86…` configuration. Restore native
   Git helper configuration before that prior image starts, because it lacks
   the new bootstrap executable. Restore source/grant parity deliberately and
   preserve agent work. Do not silently restore Azure consumers.

The generic image-only deploy does not perform this source/config migration.
Use the authorized operator rollout after the protected gate. The historical image-only CI rollback action is retired from new pipelines:
its pre-migration image lacks the new Git bootstrap/source contract. Older
pipelines retain historical actions; do not run them against the renewed fleet.
The separate pre-2026.11 recovery image additionally requires its matching
schema backup. Do not clear state, downgrade schema or claim a PVC restore was
tested. Satwa owns a future validated recovery workflow.

## Superseded build history

Swarm !47 (`580119cb…`) introduced the source migration; candidate pipeline1647
built `7edfc1db…`. Follow-up !48 (`62994c42…`) corrected portable context paths
and toolbox criticals; pipeline1659 built `420327e1…`. Neither was deployed.
Final !49 adds unconditional review-only memory submission. Both earlier images
remain evidence only and must not be promoted under the final exception.

## Observed fleet rollout

All five agents were promoted in drain mode: Tinus first, independent specialist
wave (Stewie, Satwa, Ramiro), then Emon. Each completed startup, immutable
image/source verification, runtime smoke, skill discovery and bundle parity,
installed persona/source hash parity, own GitLab API/native Git checks,
invalid ambient-token isolation, cross-agent selector rejection and company
knowledge-router read. All fifteen source checkouts are clean on canonical
GitLab origins. Observed pins are skills `132fb9f8e509`, personas `9e5828353cf1`
and memory `b18091dc4caf`. Existing MEMORY.md files and PVCs remain present.

All five gateways and TLS sidecars are ready with zero container restarts.
Only Memory Dreaming Promotion is enabled in each OpenClaw instance. Ramiro's
three mail jobs and the retired coordinator/heartbeat jobs remain disabled.
Dreaming's last successful scheduled run precedes this image promotion; the
retained OpenClaw version is unchanged, but no new overnight run is claimed.

This was an operator rollout after protected qualification, not execution of
the generic CI image-only deploy. The dated Deployment annotation
`openclaw.infuse-ai.com/renewal-2026-11-12` records operator/source/verification
provenance. The inherited template's `gitlab.infuse-ai.com/pipeline-id=1618`
identifies the prior CI deployment, not this operator action. Pipeline 1670's
manual deployment remains unused. This distinction avoids treating a passing
image gate as proof that its manual deployment ran.

Maintenance consumers and their actual outputs are qualified below, separately
from fleet readiness.

## Legacy memory reconciliation and deferred Ramiro access

The first full collector failed closed on multiple old recovery refs. Inventory
found 16 August/September refs: eleven represented in main history, five with
older memory content needing review. Exact commits were retained under
`agent-memory-legacy/<agent>/...` with private per-PVC mapping journals; no
branch or content was deleted. Thirteen refs are also preserved remotely.
Draft memory MRs !7 (Stewie), !8 (Satwa), !9 and !10 (Emon) expose four of the
unintegrated snapshots for review, using the owning agents' existing accounts.
These are historical drafts, not CI-qualified current exports or current persona
authority. Ramiro's three refs remain preserved locally, including the fifth
unintegrated snapshot at `bf27640e5681afb4b13596cc6ce760a3bccdb703`.

Ramiro's push was denied because his account is a Reporter and his active token
has only `read_api` and `read_repository`. Fito explicitly deferred granting
write access and requested a memory refactor. No access or token was changed.
The daily collector now explicitly selects only coordinator, developer, designer
and infra; Ramiro's memory publication is paused along with his already-paused
mail workflows. Emon owns the refactor proposal and the future access decision.

## Final maintenance outcomes

All five existing CronJobs use `acf9b596…`; cadences, timezones and service
accounts are retained. Memory has its explicit four-writer selector, 420-second
per-agent budget and 2400-second Job deadline. The other changes are the
canonical GitLab proposal-review URL and qualified image.

| Job evidence | Observed result |
| --- | --- |
| `renewal-model-policy-20261112` | Completed 15:49:52 UTC; five fresh schema-valid records, all matching declared policy |
| `renewal-token-usage-20261112` | Completed 15:50:14 UTC; five valid available/fresh Gateway usage records |
| `renewal-scheduler-20261112` | Completed 15:50:05 UTC; five available Gateway snapshots with complete pagination |
| Scheduled proposal monitor `29908323` | Ran 16:03:00–16:03:05 UTC on the qualified image; checked five pods, found no unnotified proposals, sent no notification |
| `renewal-memory-writers-20261112` | Ran 16:01:26–16:11:36 UTC; four own-agent publications, exact-head CI passed, four `review_pending` receipts, zero merges |

The first two memory qualification Jobs failed on the preserved ambiguous
legacy queues. They are retained as diagnostic history; only the reconciled,
explicitly admitted four-writer run is successful. Its observed run disabled
automatic container retries to retain diagnostics; command, image and identity
matched the scheduled collector. The schedule retains its existing retry policy.

| Own writer | Open MR | Exact source | Passing pipeline |
| --- | --- | --- | --- |
| `agent-coordinator` | [!11](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory/-/merge_requests/11) | `24e6904b5dc91cdb4d46a162acff66f9b90def93` | 1671 |
| `agent-designer` | [!12](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory/-/merge_requests/12) | `4e47f8c60e016e3e851a1edfa19cb69b3e8a5b79` | 1672 |
| `agent-developer` | [!13](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory/-/merge_requests/13) | `ea84518ed37668bf102dd0c66bc6e7ef18886729` | 1674 |
| `agent-infra` | [!14](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory/-/merge_requests/14) | `123ae4b6663eca966c160cae9f240116b941fab8` | 1675 |

Independent API readback confirms all four authors, open MR state, exact pipeline
SHA and success; no automatic merge was requested. The older !7–!10 drafts have
no current pipeline and need deliberate historical review. Review-pending
holds one immutable snapshot: later local notes remain on the PVC until review
resolves and the next export runs. It is not a continuously fresh backup.

Final fleet readback confirms one ready pod per agent, both containers on the
qualified image, zero restarts and no Azure credential envFrom mount. Fresh
model-policy, usage and scheduler records were revalidated after memory
publication. Recovery qualification, remaining vulnerabilities, human Atlas
review, Ramiro mailbox repair and the memory refactor remain explicit follow-ups.
