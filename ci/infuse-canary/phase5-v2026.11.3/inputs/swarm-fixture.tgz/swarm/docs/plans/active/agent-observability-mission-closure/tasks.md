---
title: Agent Observability Mission Closure Tasks
description: Independently reviewable task slices for the six accepted mission-closure iterations.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - observability
  - agents
  - evaluation
  - skills
---

# Agent Observability Mission Closure Tasks

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Story 1: Every agent emits the proven behavioral baseline

- [x] **T1.1 — Render fleet telemetry configuration.** Repo:
  `openclaw-k8s-swarm`. Inspect persistent-agent configuration, all five agent
  overlays, collector allowlists, and observability runtime tests. Enable the
  existing diagnostics and behavioral plugins for the four non-Tinus agents
  without changing images, ServiceAccounts, RBAC, Secrets, PVCs, or OpenClaw/
  Codex artifacts. Verify exact per-agent service/resource attributes and
  manifest tests.
- [x] **T1.2 — Prove the fleet dashboard contract.** Repo: `grafana`. Confirm
  tool, failure, workflow, provenance, and exporter queries separate all five
  agent IDs and do not require high-cardinality labels. Add only missing
  dashboard/test coverage. Verify every PromQL/LogQL expression locally and
  against live bounded series after canary.
- [x] **T1.3 — Canary and promote sequentially.** Repo/runtime:
  `openclaw-k8s-swarm` plus Kubernetes. Reconfirm Tinus, then roll Satwa,
  Stewie, Emon, and Ramiro. Require five successful and two stable failed tool
  events per agent, channel/Gateway health, zero unexplained restarts, privacy
  scans, and a Tinus collector-outage drill. Stop on the first failure.

## Story 2: Wrapper failures cluster without raw diagnostics

- [x] **T2.1 — Freeze wrapper taxonomy and fixtures.** Repos:
  `agent-skills` and `openclaw-k8s-swarm`. Extend the v1 contract only if an
  existing bounded field cannot express the pilot. Add positive/negative
  fixtures for auth, authorization, timeout, dependency, invalid input, parse,
  non-zero exit, and unknown failures. Reject raw error text and output.
- [x] **T2.2 — Instrument three wrapper paths.** Repo: `agent-skills`.
  Implement stable error outputs and fail-open marker instructions for
  knowledge retrieval, Azure DevOps, and runtime status/rollout helpers. Do
  not add separate OTLP clients to scripts or change successful output.
- [x] **T2.3 — Surface and prove clusters.** Repos: `grafana` and
  `openclaw-k8s-swarm`. Add or validate wrapper/operation/revision views. Run
  injected failures with telemetry enabled, disabled, and unavailable; prove
  wrapper output/retry/exit equivalence.

## Story 3: Skill usage has honest no-core attribution

- [x] **T3.1 — Add the skill attribution contract.** Repo:
  `openclaw-k8s-swarm`. Add `infuse.skill.execution` and exact enums for
  `native`, `explicit_wrapper`, and `declared_marker`. Reject inferred,
  content-bearing, secret-bearing, and unbounded attributes.
- [x] **T3.2 — Implement the standalone marker.** Repo:
  `openclaw-k8s-swarm`, `plugins/behavioral-observability`. Add a fail-open,
  metadata-only `skill_execution` marker with strict skill/phase/outcome/
  attribution validation. Do not touch packaged OpenClaw/Codex artifacts.
- [x] **T3.3 — Adopt four pilot skills.** Repo: `agent-skills`. Add explicit
  marker guidance to `knowledge-retrieval`, `azure-devops`,
  `runtime-operations`, and `verify-this`; wrapper-owned paths use
  `explicit_wrapper`, wrapperless paths use `declared_marker`.
- [x] **T3.4 — Prove dashboard and evaluation semantics.** Repo: `grafana`
  plus controlled agent smokes. Display native and explicit attribution
  separately. Prove no task is credited solely from inference.

## Story 4: Opik stores reproducible reviewed evaluations

- [x] **T4.1 — Preview and approve the Fixture V2 dataset.** Repo:
  `knowledge-base`. Re-run exact private artifact privacy/provenance checks and
  produce the deterministic admission preview. Stop before Opik write until
  explicit approval cites the exact dataset revision.
- [x] **T4.2 — Admit and reproduce the retrieval baseline.** Repo/service:
  `knowledge-base` and Opik. Admit only the reviewed 75-case artifact, run the
  baseline experiment, and verify exact metrics and revision identity. No
  production request is automatically admitted.
- [x] **T4.3 — Build the agent evaluation runner.** Repo:
  `openclaw-k8s-swarm`, `tools/agent-evals`. Add 10-20 sanitized fixtures,
  deterministic graders, three-trial support, exact revision envelope,
  read-only/sandbox controls, and supported Gateway invocation. Prove trace
  propagation or report a blocker; do not invent correlation.
- [x] **T4.4 — Reject a degraded candidate.** Use a test-only degraded
  wrapper/skill candidate to prove Opik and deterministic gates reject the
  expected regression without any production deployment.

## Story 5: Retrieval quality improves through controlled evidence

**Status: deferred by Fito on 2026-08-29.** Do not start these tasks until an
explicit reactivation decision. Use `iteration-5-deferred-spec.md` as the
implementation and acceptance authority when work resumes.

- [ ] **T5.1 — Freeze candidates and gates.** Repo: `knowledge-base`. Record
  the four one-variable hypotheses, immutable configuration identifiers, and
  accepted quality/latency/privacy/provenance floors.
- [ ] **T5.2 — Run semantic gating.** Compare typo/exact semantic gating to the
  accepted Fixture V2 baseline and classify every changed case.
- [ ] **T5.3 — Run lexical precedence.** Change only precedence, compare, and
  stop if any critical or provenance gate fails.
- [ ] **T5.4 — Run fusion weighting.** Change only RRF/fusion weighting and
  compare against the same immutable dataset and fixture.
- [ ] **T5.5 — Run query/input formatting.** Change only query or embedding
  input formatting and compare.
- [ ] **T5.6 — Select or reject.** Produce one human review package. Recommend
  at most one winner; if no candidate satisfies every hard floor, explicitly
  recommend no promotion.

## Story 6: One real improvement closes the governed loop

- [ ] **T6.1 — Implement the accepted winner.** Use the owner repository and
  a normal reviewed PR. Keep candidate/evaluation identifiers in the evidence
  package, not runtime labels when cardinality is unbounded.
- [ ] **T6.2 — Canary on Tinus.** For Knowledge Base behavior, deploy an
  internal canary service and point only Tinus at it. For a skill/wrapper,
  build a Tinus-only bundle revision. Prove channel, Gateway, retrieval,
  telemetry, privacy, and rollback before promotion.
- [ ] **T6.3 — Promote and remeasure.** Promote sequentially, run the matching
  fleet smokes, and compare production evidence with the baseline. Stop on the
  first regression.
- [ ] **T6.4 — Produce the first manual review.** Generate one metadata-only
  review with sample thresholds, failure/latency/loop clusters, classifications,
  owner routing, and `insufficient_evidence` behavior. It proposes only.
- [ ] **T6.5 — Schedule only after approval.** After the manual report is
  explicitly accepted, add a weekly schedule with an independent disable path
  and no automatic source or production mutation.

## Review And Delivery

- [ ] **Verify:** run repository-native suites, privacy/cardinality fixtures,
  manifest rendering, dashboard/query parsing, Opik reproduction, protected
  builds, runtime smokes, and post-promotion comparison.
- [ ] **Review:** product fit, no-core boundary, privacy, attribution honesty,
  wrapper compatibility, evaluation validity, Kubernetes/runtime safety, and
  rollback.
- [ ] **Evidence:** PRs, commits, builds, immutable images/revisions, rendered
  manifests, live bounded queries, trace/evaluation IDs, comparison reports,
  canary/fleet health, and manual-review artifact.
- [ ] **Handoff:** update the original program plan, Knowledge Base evaluation
  docs, runtime runbooks, and this Mattermost thread after every completed
  iteration. Do not report mission completion until Story 6 passes.
