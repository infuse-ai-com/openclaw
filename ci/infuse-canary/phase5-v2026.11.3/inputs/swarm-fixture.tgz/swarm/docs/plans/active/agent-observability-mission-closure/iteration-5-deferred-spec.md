---
title: Iteration 5 Deferred Retrieval Experiment Specification
description: Implementation-ready contract for future one-variable retrieval experiments against the accepted Fixture V2 baseline.
type: plan
status: draft
owner: team:agent-platform
tags:
  - observability
  - evaluation
  - retrieval
  - opik
  - deferred
---

# Iteration 5 Deferred Retrieval Experiment Specification

## Decision and reactivation gate

Fito deferred Iteration 5 on 2026-08-29 so the program can return to general
agent monitoring and Langfuse project organization. This document preserves an
implementation-ready contract; it does not authorize an experiment run,
Knowledge Base behavior change, Opik write, canary, or production rollout.

Iteration 5 may restart only after a human explicitly approves reactivation and
the exact baseline identities below still reproduce. Candidate promotion is a
second, separate human decision after all comparisons are complete.

## Problem

The accepted hybrid retrieval profile improves discovery queries but regresses
typo queries and the aggregate ranking metrics relative to lexical retrieval.
We need to learn whether one bounded retrieval decision can retain the discovery
gain without sacrificing typo, aggregate, critical-miss, latency, privacy, or
provenance gates.

## Users and scenarios

- Agent-platform maintainers need reproducible evidence before changing the
  retrieval behavior used by persistent agents.
- Knowledge Base maintainers need one-variable candidates whose code and
  configuration differences are independently reviewable.
- Reviewers need case-level explanations, not only aggregate scores, and must
  be able to choose `no winner` without causing a deployment.

## Accepted baseline identity

| Field | Frozen value |
|---|---|
| Dataset | `kb-retrieval-baseline-v2` |
| Dataset revision | `4bd8bf473802c1155627319b8ae641da3f2131d70c9bb4d3d3d2c48c2ef3170a` |
| Corpus | `library-atlas-v0`, Fixture V2, 75 reviewed cases |
| Retrieval profile | `embeddinggemma-85462619ee721b46-d768-s5baff9d0-postgres-fts-trgm-v2-rrf-v1` |
| Semantic fixture | `4d5a4972094e34bc5eb335fad399f23fdc7282155add844d1fbbcc22b3d6cd9a` |
| Lexical experiment revision | `c26c6078a2cf70c89bbace4a971a4222b01e07d88c95b49c3696c32a018ca7a1` |
| Lexical Recall@5 / MRR | `0.840000000` / `0.817349206` |
| Hybrid Recall@5 / MRR | `0.800000000` / `0.749777777` |
| Critical misses | `0` for both accepted baselines |
| Category evidence | discovery Recall@5 `0.68`; typo Recall@5 `0.5333` hybrid versus `0.8667` lexical |

Before any candidate run, reproduce the baseline from the immutable dataset and
fail closed if an identity, item count, category count, metric, fixture digest,
or privacy scan differs.

## Goals

1. Test four ordered, one-variable retrieval hypotheses against the exact same
   75 reviewed cases.
2. Produce deterministic aggregate and case-level comparison evidence in Opik.
3. Recommend at most one candidate for separate human review.
4. Preserve `no winner` as a valid successful outcome.

## Non-goals

- No production traffic, prompt, response, retrieved passage, Markdown body,
  secret, credential, chain-of-thought, or automatically harvested request is
  admitted to the dataset.
- No OpenClaw, Codex, agent image, skill bundle, ServiceAccount, RBAC, Secret,
  NetworkPolicy, public endpoint, or persistent-agent runtime change.
- No multi-variable tuning sweep, online A/B test, model-assisted grading, or
  automatic promotion.
- No candidate-specific high-cardinality production telemetry labels.

## Candidate order and isolation contract

Candidates run sequentially in this exact order. A later candidate does not
inherit an earlier candidate's change.

1. **Semantic gating.** Change only whether semantic retrieval participates for
   the exact-query and typo categories. Lexical, fusion, limits, corpus, and
   input formatting stay at baseline.
2. **Lexical precedence.** Change only lexical precedence within the accepted
   hybrid path. Semantic eligibility, fusion algorithm/weights, limits, corpus,
   and input formatting stay at baseline.
3. **Fusion weighting.** Change only the RRF/fusion weights or constants.
   Eligibility, source queries, limits, corpus, and input formatting stay at
   baseline.
4. **Query/input formatting.** Change only the query or embedding input
   formatting. Eligibility, source ranking, fusion weights, limits, and corpus
   stay at baseline.

Every candidate must have an immutable candidate ID derived from the baseline
revision, hypothesis name, exact normalized configuration, implementation
revision, evaluator revision, and fixture revision. The report must prove that
only the declared variable differs. If that proof cannot be produced, the run
is invalid rather than merely failing quality.

## Required outputs per candidate

- immutable candidate and experiment revisions;
- exact baseline, dataset, corpus, fixture, service, client, and evaluator
  provenance;
- aggregate Recall@5, MRR, critical misses, and p50/p95 latency;
- Recall@5 and MRR by reviewed category, including discovery and typo;
- a deterministic case-level delta for every changed result, with stable case
  ID, category, expected references, before/after ranks, and gate outcome;
- privacy/provenance scan result and admission visibility/source;
- explicit eligibility decision with every hard gate shown independently.

The evidence package must not contain query text, document content, excerpts,
raw request/response payloads, or credentials. Reviewers resolve stable case and
document identities through the already-governed private review path.

## Hard eligibility gates

A candidate is eligible for human review only when all are true:

- critical misses: exactly `0`;
- Recall@5: at least `0.84`;
- MRR: at least `0.817349206`;
- discovery Recall@5: at least `0.68`;
- typo Recall@5: at least `0.8667`;
- p95 retrieval latency: below `1.5s` under the locked replay profile;
- dataset count and identities: exactly the accepted 75 cases;
- privacy and secret-shape scans: pass;
- candidate, corpus, document, and evaluator provenance: complete;
- one-variable isolation proof: pass;
- deterministic replay: matching results and revisions on a clean rerun.

Meeting these floors does not authorize promotion. When multiple candidates
pass, rank them by the predeclared decision order: critical/category gates,
aggregate MRR, aggregate Recall@5, p95 latency, then smallest implementation
surface. A tie remains a human decision; do not combine candidates.

## Execution plan

1. **Preflight:** verify clean Knowledge Base main, baseline identities, exact
   Opik dataset, private artifact permissions, supported evaluator, and no
   production route or automatic-admission path.
2. **Freeze:** create a candidate manifest for each hypothesis before running
   any candidate. Record normalized config and expected single-variable diff.
3. **Run:** execute one candidate at a time against the immutable Fixture V2
   provider. Stop that candidate immediately on identity, privacy, provenance,
   critical-miss, or isolation failure.
4. **Compare:** write deterministic Opik comparisons and a local metadata-only
   review package. Reproduce every potentially eligible candidate once from a
   clean runner state.
5. **Select or reject:** recommend at most one winner, or explicitly recommend
   no promotion when no candidate clears every hard gate.
6. **Stop:** do not create a production canary or modify agent routing. Hand the
   reviewed result to Iteration 6 only after explicit winner approval.

## Verification gates

- Knowledge Base canonical tests and TypeScript checks pass.
- Candidate-manifest schema accepts exact allowed fields and rejects unknown,
  content-bearing, secret-bearing, mutable, or multi-variable inputs.
- Fixture/provider tests prove all 75 exact identities and reviewed categories.
- Privacy tests scan serialized dataset, experiment, comparison, and report
  payloads before every external write.
- Opik preview and exact-confirmation admission remain fail closed.
- A deliberately mixed-variable candidate and a degraded candidate are both
  rejected by deterministic gates.
- Sink outage or telemetry failure cannot change retrieval results or prevent
  local evidence creation; failed external writes are explicit and retryable.

## Rollback and cleanup

Candidate branches, manifests, and private local evidence are non-production.
Rejecting a candidate requires no runtime rollback. Temporary Jobs, Services,
port-forwards, Secrets, and privileged helpers must be absent at completion.
Superseded Opik experiments are retained or archived according to Opik policy;
the accepted baseline dataset is never deleted or mutated.

## Implementation handoff

- **Owning repo:** `knowledge-base` for candidate code, fixture replay,
  comparison, and Opik writes.
- **Program authority:** this mission folder in `openclaw-k8s-swarm`.
- **Read first:** Knowledge Base `AGENTS.md`, evaluation docs, Fixture V2
  provider/replay contracts, Opik admission adapter, and Iteration 4 acceptance.
- **Branch policy:** one reviewable branch/PR per candidate or one orchestration
  PR whose candidate implementations remain isolated and independently
  revertible. Never stack candidate behavior into production main before the
  comparison decision.
- **Report shape:** baseline identity, candidate identity, exact diff,
  aggregate/category metrics, changed-case classifications, privacy/provenance,
  latency, gate table, recommendation, and explicit non-deployment statement.

## Open questions deferred with implementation

1. Whether the four candidates are implemented as config-only adapters or
   isolated retrieval-provider variants depends on the then-current Knowledge
   Base architecture; the one-variable proof is mandatory either way.
2. The exact Opik experiment naming convention may change, but names must remain
   deterministic and map one-to-one to immutable candidate revisions.
3. Any retention change for private experiment evidence requires a separate
   data-governance decision.

## Source links

- `iteration-4-acceptance.md`
- `plan.md` — Iterations 5 and 6
- `tasks.md` — Story 5
- `requirements-checklist.md`
- `docs/AGENT_EVALUATIONS.md`
