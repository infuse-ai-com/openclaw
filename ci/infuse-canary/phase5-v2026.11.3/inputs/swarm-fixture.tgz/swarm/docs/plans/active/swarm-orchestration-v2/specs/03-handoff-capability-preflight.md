---
title: Spec 3 - Handoff And Capability Preflight
description: Machine-checkable assignments, acknowledgement, evidence handoff, and fail-closed capability checks before agent wake-up.
type: architecture
status: active
owner: team:agent-platform
tags: [agents, orchestration, handoff, capabilities]
---
# Spec 3 - Handoff And Capability Preflight

## Outcome

Every specialist receives one startable assignment. Missing capability is
found before the agent is mentioned, and “delivered” cannot be mistaken for
“verified.”

## Handoff Contract v2

The existing inter-agent Markdown contract remains human-readable. V2 adds a
machine-readable companion record with:

- mission id, task id, sender, target role, exact agent, and resolved handle;
- outcome, scope, non-goals, acceptance criteria, and dependencies;
- repository, target branch, path scope, and isolated workspace requirement;
- required skills and capability assertions;
- credential and access intent references, never secret values;
- verification commands/classes and deployment applicability;
- approval boundaries and stop rules;
- role channel/thread and shared code-ref requirement;
- acknowledgement deadline and reporting contract; and
- immutable Artifact Registry input identities that the recipient must fetch;
- schema version and content hash.

The rendered Mattermost handoff points to the durable record and includes the
one resolved target-agent mention.

## Capability Requirement Classes

- `skill`: installed reviewed skill id and source revision.
- `repository`: allowed repository plus explicit checkout source.
- `credential_intent`: declared Vaultwarden/Kubernetes materialization intent;
  this proves configuration, not successful secret disclosure.
- `tool`: executable/runtime capability with version or bounded probe.
- `workspace`: isolated task workspace availability and concurrency capacity.
- `network`: required internal endpoint class, without exposing addresses in
  public evidence.
- `verification`: ability to run the named test/build/browser/runtime class.
- `approval`: unresolved human or safety gate that must prevent assignment.

## Preflight Rules

1. Resolve the target agent from the canonical role/identity map.
2. Validate the handoff schema and source pointers.
3. Inspect the reviewed runtime bundle and skill catalog.
4. Validate repository policy and task-workspace capacity.
5. Run bounded capability probes where static configuration is insufficient.
   Run immutable-input manifest probes inside the recipient pod.
6. Classify each requirement as `pass`, `blocked`, `approval_required`, or
   `unknown`.
7. Refuse assignment unless every required item is `pass`.
8. Persist only the requirement class, result, source revision, observed time,
   and bounded failure code.

Preflight never reads or prints credential values. A successful credential
intent check means the agent is configured to request the credential through
the approved path; task-time authentication can still fail and must be handled
as a runtime blocker.

## Acknowledgement Contract

The target agent must explicitly acknowledge or decline:

- `acknowledged`: contract understood and startable from the agent's view;
- `declined`: named missing context/capability or ownership conflict;
- no response by deadline: lease expiry routed to Emon once.

Acknowledgement is a dispatch-liveness receipt, not evidence validity or
execution authority. Material source/PR/build/verification progress may
reconcile `assigned -> acknowledged -> active`; expiry never discards it.

Capability snapshots have a bounded TTL and are reusable only while the exact
agent, pod/image, skill bundle, repository, and requirements revision are
unchanged.

## Delivery And Verification Contract

`delivered` requires:

- fetchable shared code/artifact ref;
- changed scope summary;
- verification evidence or explicit failed/inconclusive gates;
- unresolved risks and approval needs; and
- recommended next action.

`verified` requires a verifier other than the delivery claim, acceptance
criteria checked, and applicable PR/CI/deploy/smoke evidence. Self-review may be
the verifier only when the mission contract explicitly allows proportional
self-review.

## Acceptance Criteria

- Invalid or incomplete handoffs cannot be assigned.
- A missing installed skill, denied repo, unavailable workspace slot, or
  unresolved approval blocks the target mention.
- Preflight output contains no secrets, commands, paths, raw errors, or private
  content.
- Acknowledgement, decline, lease expiry, delivery, review, and verification
  map to legal task transitions.
- A PVC-local branch cannot satisfy `delivered` for cross-agent review.
- Failed or inconclusive verification cannot produce `verified`.
- The same handoff hash and task id are idempotent; changed requirements require
  a new revision and acknowledgement.

## Owning Repositories

- Handoff schema, renderer, validator, and static preflight: `agent-skills`.
- Runtime bundle/capability probes and task workspace integration:
  `openclaw-k8s-swarm`.
- Stable company authority/role semantics: `company-docs` only after proof.

## Rollback

Keep the existing Markdown contract accepted while v2 runs in report-only
mode. Do not enable enforcement until fixtures cover every persistent role and
one real handoff passes end to end.
