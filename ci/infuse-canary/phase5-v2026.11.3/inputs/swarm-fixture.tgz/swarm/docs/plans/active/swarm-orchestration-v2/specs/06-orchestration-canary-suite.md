---
title: Spec 6 - Deterministic Orchestration Canary Suite
description: Reproducible scenario suite for ownership, transitions, wakeups, recovery, approval boundaries, and parallel result ordering.
type: architecture
status: active
owner: team:agent-platform
tags: [agents, orchestration, testing, canary]
---
# Spec 6 - Deterministic Orchestration Canary Suite

## Outcome

Prompt, skill, model-policy, runtime, and orchestration changes cannot be
promoted without proving the core ownership and state-machine behaviors that
keep the swarm quiet and accountable.

## Test Layers

1. **Pure fixtures:** transition engine, idempotency, event ordering, leases,
   preflight, and snapshot behavior with no network or model.
2. **Simulated runtime:** fake Mattermost, event intake, wake adapter, CI, and
   Backoffice intent producer with deterministic clocks and failure injection.
3. **Controlled live canary:** dedicated private channel/project, disposable
   mission, real agent turns, metadata-only evidence, and no production product
   mutation.

Pure and simulated layers gate every PR. Live canaries gate runtime or policy
promotion when the changed surface can affect behavior.

## Required Scenarios

### Ownership and mention hygiene

- one assigned specialist acts;
- observers remain silent;
- a wrong-agent mention is corrected and its output remains non-authoritative;
- no speculative multi-agent mention creates work.

### Event behavior

- duplicate event delivery;
- burst coalescing;
- out-of-order delivery;
- unauthorized producer;
- event accepted while wake adapter is unavailable;
- reconciliation recovery without duplicate post.

### Handoff and capability

- incomplete contract rejected;
- missing skill, repo grant, credential intent, workspace capacity, or
  verification capability blocks assignment;
- acknowledgement, decline, and acknowledgement lease expiry;
- local-only code ref rejected as delivered.

### Lifecycle and evidence

- unsupported direct transition rejected;
- delivered claim without evidence stays unverified;
- failed CI/deploy/smoke prevents verification;
- correction returns task to active and later verifies;
- mission cannot close with unresolved required task or gate.

### Recovery and concurrency

- coordinator restart after event acceptance and before registry mutation;
- restart after mutation and before event acknowledgement;
- stale writer conflict;
- two independent task results in either order;
- concurrent steward run lease contention;
- invalid registry or unknown schema fails closed without overwrite.

### Approval boundaries

- pause/resume intent;
- stale gate decision;
- reassignment request does not auto-select an agent;
- secret/RBAC/destructive/external intent is rejected as unsupported;
- Backoffice disabled mode remains read-only.

## Evidence Contract

Each run emits a sanitized result bundle with:

- suite and fixture revision;
- runtime/skill/image/model policy revisions where applicable;
- scenario id and verdict;
- expected and observed bounded transitions;
- wake, event, and message counts;
- privacy scan result;
- rollback/cleanup result; and
- exact code/build/deploy refs for live canaries.

No prompts, outputs, message content, raw errors, tokens, paths, user/channel
ids, mission ids, or chain-of-thought enter the bundle.

## Promotion Gates

- All deterministic scenarios pass.
- Live canary uses one disposable mission and exact expected membership.
- No unexpected agent wakes, posts, state changes, or external mutations.
- Cleanup leaves no active mission, pending event, wake lease, test channel
  artifact, or temporary credential.
- A failed scenario blocks only the dependent promotion and leaves the current
  production path unchanged.

## Acceptance Criteria

- The suite reproduces the previously verified shared-task ownership behavior.
- Mutation tests prove each required scenario can fail the gate.
- Runs are deterministic under a fake clock and seeded event ordering.
- Live output is metadata-only and can be compared across revisions.
- One command runs the PR-safe suite; one separately gated command runs the live
  canary.
- The canary itself cannot merge, deploy, grant access, change secrets, or
  perform destructive actions.

## Owning Repositories

- Primary harness and runtime fixtures: `openclaw-k8s-swarm`.
- Handoff/registry fixtures: `agent-skills`.
- Backoffice intent fixtures: `backoffice`.
- Dashboard/alert test fixtures: `grafana`.

## PR-Safe Harness

The primary harness is `scripts/orchestration_canary.py`. It runs 45 pure or
simulated scenarios under the fixed `2026-09-01T08:00:00Z` clock, advances the
clock by one second per scenario, and uses seed `20260901` for result ordering.
The harness emits only the evidence fields defined above and is part of both
`task verify` and `task verify-ci` through:

```sh
task verify-orchestration-canary
```

The nine mutation modes cover duplicate wake, wrong ownership, unsupported
transition, lost event, stale writer, approval bypass, false verification, and
cross-task preflight reuse, plus specialist mention before an active mission,
exact live assignment, verified neutral root, and durable dispatch intent.
Each mutation must make the suite exit non-zero while the privacy and cleanup
checks remain valid. Owner-repository fixture revisions are recorded in the
bundle; their canonical repository gates remain the implementation-level
authority.

The PR-safe command has no network, model, Kubernetes, Mattermost, wake, or
production-state adapter. After T6.3 received separate activation approval on
2026-09-03, the controlled-live layer was added as a private authenticated
intake, one exact mission-scoped policy, an isolated no-API-token producer Job,
and the existing exact-thread reconciler. These resources remain inert until
the reviewed Secrets and mission-specific ConfigMaps exist and the named
reconciler is explicitly enabled.

The operator commands are:

```sh
task activate-mission-continuation-canary
task run-mission-continuation-producer-job
```

The first command requires one exact mission id plus separately prepared policy
and token-digest files. The second requires bounded event metadata and reads the
producer credential only from its Kubernetes Secret mount. Neither command
creates a mission, channel, bot, credential, or approval.

## Rollback

The suite is non-production and independently disabled. Live canary activation
uses dedicated disposable state and must clean up through normal non-destructive
terminal transitions rather than deleting canonical evidence.
