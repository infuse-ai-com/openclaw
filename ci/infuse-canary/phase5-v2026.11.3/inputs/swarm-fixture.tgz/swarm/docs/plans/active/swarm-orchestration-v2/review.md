---
title: Swarm Orchestration v2 Specification Review
description: Cross-artifact contradiction, completeness, architecture, privacy, and activation review before implementation.
type: report
status: active
owner: team:agent-platform
tags: [agents, orchestration, review]
---
# Swarm Orchestration v2 Specification Review

## Verdict

The six-spec package is startable in the dependency order defined by
`plan.md`. No unresolved product decision blocks Spec 1. Production event
ingress and Backoffice intent activation remain correctly gated.

## Baseline Reconciliation

The initial vision partially overlapped work already merged on 2026-08-31.
The package now treats these as baseline rather than new deliverables:

- Emon-local canonical mission registry and deterministic quiet steward;
- private project-role channels with Emon ambient and one mention-only
  specialist;
- validated read-only Backoffice `/missions` projection;
- canonical Artifact Registry source and clients behind activation gates;
- official/curated telemetry authority, traffic-source contract, trace
  integrity, lifecycle quality, and behavioral dashboards through the current
  Monitoring Truth iteration; and
- one verified shared-task behavior canary.

## Resolved Issues

### Backoffice authority conflict

The conversational vision proposed Backoffice as mission owner, while the
accepted operating model makes Emon's registry canonical. The specs preserve
Emon authority. Future Backoffice controls create bounded operator intents and
wait for a fresh canonical snapshot before showing an applied mission change.

### Polling versus existing quiet steward

The existing steward already avoids broad backlog scans and unchanged posts,
but immediate event wakeup is still deferred. Spec 2 adds durable event intake,
dedupe, coalescing, and on-demand wake while retaining the steward as the
transition owner.

### “Done” ambiguity

Registry v1 task `done` does not distinguish specialist delivery from
independent verification. Spec 1 introduces `delivered`, `review`, and
`verified`; migration maps old `done` conservatively unless verification is
explicit.

### Event concurrency with file-backed state

Direct multi-producer JSON writes would be unsafe. The design separates a
durable per-event inbox from one serialized registry transition engine and
keeps optimistic revisions plus an exclusive lock. A database is deferred
until evidence justifies it.

### Mission correlation and cardinality

Exact mission/task ids cannot become fleet metric labels. The spec uses
bounded metrics plus backend-safe trace correlation or explicit unavailable
state, with exact joins performed against canonical evidence. Timestamp-only
inference is prohibited.

### Controls versus external approval systems

Backoffice gate approval cannot bypass Azure policy, environment approval,
secret provisioning, RBAC, destructive confirmation, or external-communication
approval. The operator intent records only the mission-level decision.

## Hidden External Effects Review

| Effect | Specification treatment |
| --- | --- |
| New event credentials or Secrets | Source implementation may use placeholders; production provisioning is gated. |
| NetworkPolicy, ServiceAccount, or RBAC | Disabled manifests and dry-run tests may proceed; activation is gated. |
| Mission migration | Explicit command, exact backup, no startup migration, rollback/replay path. |
| Backoffice write controls | Disabled by default; operator-role and delivery activation gated. |
| Production agent wake behavior | Fake/simulated tests first, then disposable live canary, then sequential promotion. |
| Telemetry cardinality/privacy | Contract fixtures reject identifiers/content and prove fail-open behavior. |
| Destructive cleanup | Canary closes disposable state through normal transitions; no deletion authorization implied. |

## Non-Blocking Choices To Resolve During Implementation

1. Exact event-ingress repository/deployment placement after inspecting current
   internal-service patterns.
2. Timing defaults for coalescing, acknowledgement, reconciliation, and alerts
   from baseline evidence.
3. Exact backend-safe trace correlation mechanism within the current telemetry
   privacy contract.

Each choice is reversible and has fixed acceptance/security constraints, so it
does not block Spec 1.

## Task Quality Review

- Tasks are grouped by independently testable behavior and owner repository.
- Contract providers merge before consumers.
- Activation is not hidden inside implementation tasks.
- Every task names a verification outcome or explicit live gate.
- No parallel marker is used where dependency or repository overlap would make
  concurrent work unsafe.

## Start Recommendation

Begin with Story 1 in `agent-skills`: transition-safe registry v2, locking,
idempotency, and explicit migration. Do not implement event intake until the
canonical transition engine and event idempotency contract are accepted.
