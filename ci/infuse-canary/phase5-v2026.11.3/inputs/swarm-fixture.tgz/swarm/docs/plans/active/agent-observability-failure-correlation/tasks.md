---
title: Agent Failure Taxonomy and Turn Trace Correlation Tasks
description: Tracks reviewable delivery slices for failure classification, curated traces, operator visibility, and fleet proof.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - agents
  - observability
  - telemetry
---

# Tasks: Agent failure taxonomy and turn trace correlation

## Story 1: Stable remediation-oriented failure categories

- [x] In `openclaw-k8s-swarm/plugins/behavioral-observability`, implement a
  pure bounded classifier for public tool-hook result fields and locally
  inspected dynamic-tool errors. Verify enum members, precedence, truncation,
  and absence of source-text retention with Node tests.
- [x] Extend `config/observability/telemetry-contract.v1.json` and fixtures with
  `infuse.tool.execution`; verify exact fields, enums, labels, and privacy
  rejection.
- [x] Emit one fail-open correlated tool span from every public completion hook;
  preserve official telemetry as the canonical fleet total/failure metrics.

## Story 2: Curated behavioral spans share one turn trace

- [x] Implement bounded run-span state started by public `llm_input`, with
  `model_call_started` as a compatible fallback.
- [x] Parent workflow, skill, wrapper, knowledge, and failure spans through the
  stored curated turn root; close state on run end, shutdown, and eviction.
- [x] Add tests for bounded run identifiers, first-parent retention, capacity,
  take/drain cleanup, and cross-run isolation.

## Story 3: Operator visibility and production proof

- [x] Add reviewed `tool_name`, `failure_category`, and
  `classification_source` collector dimensions and a Grafana classified-tool-
  failure panel.
- [x] Run swarm and Grafana canonical verification, privacy scans, container
  build, and runtime smoke.
- [ ] Open PRs and pass CI. Merge in dependency order when review and pipelines
  are green.
- [x] Canary Tinus, prove one correlated turn and representative failure
  categories in Langfuse/Prometheus, and run collector outage/recovery proof.
- [ ] Roll the exact Tinus-proven digest sequentially across the other four
  agents only if all canary gates pass.

## Review And Delivery

- [x] Verify: focused Node/Python tests, full repository suite, rendered
  manifests, image/runtime smoke, Grafana validator, Langfuse privacy/correlation
  query, and Kubernetes readiness.
- [ ] Review: standard self-review plus deployment/privacy review before merge.
- [ ] Evidence: PRs, CI builds, immutable image digest, Tinus proof, fleet proof,
  and bounded backend aggregates.
- [ ] Handoff: report classified coverage, remaining unknowns, correlation
  coverage, rollback digest, and any follow-up requiring upstream artifacts.
