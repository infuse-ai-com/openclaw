---
title: Swarm Orchestration v2 Proposal
description: Accepted program charter for evolving the Infuse AI agent swarm from capable individual agents into a quiet, event-driven, evidence-governed execution system.
type: plan
status: active
owner: team:agent-platform
tags:
  - agents
  - orchestration
  - missions
  - observability
  - backoffice
---
# Swarm Orchestration v2 Proposal

## Decision

Fito accepted the next evolution of the Infuse AI agent swarm on 2026-08-31:
improve the orchestration control plane before adding more persistent agents.

The existing roster remains sufficient:

- Emon Lusk / `agent-coordinator` owns missions and execution synthesis;
- Tinus Lordvals / `agent-developer` owns implementation engineering;
- Stewie Hobs / `agent-designer` owns product-design and UX review;
- Satwa Nutella / `agent-infra` owns runtime and platform evidence;
- Ramiro Garcia / `agent-intake` owns consulting intake and handoff.

## Why Now

The swarm has strong runtime capability, role separation, isolated workspaces,
reviewed skills, and privacy-safe telemetry. Recent delivery also exposed the
next bottleneck: coordination state and wake-up mechanics. One Backoffice
mission reached 323 posts; Kapiteky authored 74 checkpoint or refresh-style
messages. The failure was not insufficient intelligence. It was polling,
duplicated coordination, weak state transitions, and incomplete end-to-end
mission evidence.

## Program Outcome

Create a mission control plane where:

1. Emon's durable mission registry is the canonical execution state;
2. state transitions and handoffs are validated and idempotent;
3. material events wake Emon without periodic agent-status chasing;
4. assignments fail closed when required capability or access is absent;
5. every accepted mission is traceable from intent through verified outcome;
6. Backoffice projects mission truth and later submits bounded operator intents
   without becoming a second mission writer; and
7. deterministic orchestration canaries prevent prompt, skill, and runtime
   changes from reintroducing ownership or noise regressions.

## Existing Baseline To Reuse

This program extends, rather than replaces:

- `agent-execution-system-v2`, including the canonical Emon registry, quiet
  steward, project-role Mattermost channels, read-only `/missions` projection,
  and Artifact Registry foundation;
- the `infuse.team-missions/v1` lifecycle CLI in `agent-skills`;
- the curated turn trace and official OpenClaw telemetry authority contract;
- the `Monitoring Truth and Alerts` program through Iteration 4; and
- the existing controlled shared-task behavior canary.

## Delivery Boundary

Source, tests, disabled-by-default manifests, and migration tooling are within
the accepted implementation scope. Production credentials, new Secrets, RBAC,
public ingress, destructive migration, and activation of write-capable
Backoffice controls remain explicit gates.

## Completion Definition

The program is complete only when all six specifications are implemented,
reviewed, and verified; production-affecting slices are canaried and promoted;
the old polling path is retired or reduced to reconciliation-only; and a real
mission completes with lower coordination noise and complete evidence.
