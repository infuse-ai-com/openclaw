---
title: Agent Failure Taxonomy and Turn Trace Correlation Specification
description: Defines bounded failure classification and one metadata-only curated trace for each agent turn.
type: standard
status: active
owner: team:agent-platform
tags:
  - standard
  - agents
  - observability
  - telemetry
---

# Feature Spec: Agent failure taxonomy and turn trace correlation

## Problem

The OpenClaw swarm records agent, model, and tool activity, but most tool
failures collapse into `codex_native_tool_error` or
`codex_dynamic_tool_error`. Operators can identify the affected agent and tool
without knowing whether the stable cause was a timeout, missing dependency,
permission denial, invalid input, non-zero exit, protocol conversion, or
another bounded class.

Behavioral spans emitted by the standalone plugin also become isolated traces.
The exact Codex adapter supplies the same `runId` to `llm_input`, tool, and
`agent_end` hooks but does not expose the official diagnostic trace context on
those public hook calls. Langfuse therefore cannot reliably show workflow,
skill, wrapper, and Knowledge Base spans in one navigable turn tree.

## Users And Scenarios

- An operator starts from an alert or dashboard failure cluster and needs a
  stable remediation-oriented category without reading raw error text.
- A skill owner drills into one Langfuse turn and needs the model, tools,
  workflow phases, explicit skills, wrapper failures, and Knowledge Base calls
  in one trace.
- A reviewer must prove that improving diagnosis does not capture prompts,
  tool arguments/results, command output, paths, credentials, or raw errors.

## Goals

1. Emit one metadata-only `infuse.tool.execution` child span for every public
   tool-hook completion, with a closed failure category on errors.
2. Use a closed failure taxonomy and discard source error text after local
   classification.
3. Create one plugin-owned, metadata-only curated trace per public `runId`,
   containing a turn root plus model, tool, workflow, skill, wrapper, and
   Knowledge Base children.
4. Expose classified failure clusters in Grafana while preserving the official
   tool metrics as the source for total calls and failures.
5. Keep all emission fail-open and preserve agent/tool behavior during exporter
   failure.

## Non-Goals

- Rebuilding or changing the custom OpenClaw, Codex, or diagnostics-otel
  bundles.
- Capturing private chain of thought, prompts, responses, tool input/output,
  command output, objectives, references, paths, or raw error messages.
- Claiming a precise category when the public runtime exposes only a generic
  error; such failures remain `unknown` in the official telemetry.
- Replacing official `openclaw.tool.execution` observations as the canonical
  fleet totals. `infuse.tool.execution` is the correlated behavioral view and
  is intentionally separate.
- Reparenting official OpenClaw/Codex diagnostic spans. The exact pinned Codex
  public hooks do not expose their OTel context; changing that boundary would
  require a custom artifact rebuild.
- Cross-service W3C propagation into Knowledge Base internals in this slice;
  the agent-side `infuse.knowledge.retrieve` call is the turn child.

## Domain Language

- **Agent turn/run:** one end-to-end OpenClaw run identified internally by the
  public hook `runId`; the identifier is correlation state and is never emitted
  as an attribute.
- **Official diagnostic trace:** a trace created by OpenClaw and exported by
  diagnostics-otel. It remains the canonical source for native fleet totals.
- **Curated turn trace:** the standalone plugin's metadata-only trace rooted at
  `infuse.agent.turn` for one public hook `runId`.
- **Behavioral span:** an `infuse.*` workflow, skill, wrapper, knowledge, or
  classified-failure span emitted by the standalone plugin.
- **Stable failure category:** a member of the reviewed closed enum, derived
  without exporting source text.
- **Correlation joined:** a curated span whose parent is the plugin-owned turn
  root resolved from the same in-memory `runId`.

## Acceptance Criteria

1. The closed tool-failure enum is exactly:
   `aborted`, `authentication_unavailable`, `authorization_denied`,
   `dependency_unavailable`, `invalid_input`, `nonzero_exit`, `parse_failure`,
   `permission_denied`, `policy_denied`, `protocol_conversion`, `timeout`,
   `upstream_contract_mismatch`, `upstream_unavailable`, `runtime_error`, and
   `unknown`.
2. Structured public result fields distinguish timeout, abort, policy denial,
   unavailable dependency/upstream, invalid input, and non-zero exit before any
   bounded text fallback is considered.
3. Dynamic-tool error/result text is inspected only in process memory, never
   beyond 4096 characters, and never attached to a span, metric, log, or result.
4. `infuse.tool.execution` always contains only `tool_name`, `outcome`, and
   bounded `duration_ms`; errors additionally contain only `failure_category`
   and `classification_source`.
5. Public `llm_input` starts exactly one `infuse.agent.turn` root and one
   `infuse.model.call` child for the internally held `runId`; a public
   `model_call_started` hook is a compatible fallback.
6. Curated model, tool, workflow, skill, wrapper, knowledge, and classified
   failure observations from a controlled Tinus turn share one curated trace
   ID and have the turn root as their direct or transitive parent.
7. `agent_end` closes the model and turn spans with bounded `outcome` and
   `duration_ms`; shutdown and capacity eviction close abandoned state
   fail-open.
8. Contract fixtures reject raw error/content fields, paths, session/run IDs,
   secret-shaped fields, and unapproved attributes.
9. Disabling or interrupting the collector does not change tool results or the
   final agent response; export resumes after recovery without pod restart.
10. Tinus remains Ready with zero unexplained restarts before any fleet
    promotion.

## Constraints

- Exact runtime remains OpenClaw source `3d1a6e4197b2bcce4b90cd3fc5b6de8a5b1f24c0`,
  `@openclaw/codex@2026.8.1-beta.3`, and
  `@openclaw/diagnostics-otel@2026.8.1-beta.3`.
- Use only public plugin SDK hooks. The public `onDiagnosticEvent` API is not a
  source for trusted core events and must not be used for this implementation.
- The exact Codex `llm_input`, `after_tool_call`, and `agent_end` hooks expose
  `runId` but not the official OTel context. The identifier may be used only as
  bounded in-memory state and must never be exported.
- Maps and local inspection must be bounded and cleaned on run completion,
  plugin shutdown, and capacity eviction.
- Metrics dimensions must remain bounded and reviewed.

## Risks And Approval Gates

- The new swarm image is canaried on Tinus first. Fleet rollout stops on trace,
  privacy, exporter, Gateway, channel, skill-provenance, or readiness failure.
- No OpenClaw/Codex artifact rebuild is authorized.
- Existing production credentials and collector Secret are reused unchanged.

## Open Questions

None blocking. Failures that cannot be classified from public safe fields
remain explicitly unknown rather than expanding capture.

## Source Links

- Mattermost mission thread:
  <https://mattermost.infuse-ai.com/ai-lab/pl/c9ksqs66nf8tjdji8new8xxpry>
- `docs/AGENT_OBSERVABILITY_BASELINE_2026-08-27.md`
- `config/observability/telemetry-contract.v1.json`
