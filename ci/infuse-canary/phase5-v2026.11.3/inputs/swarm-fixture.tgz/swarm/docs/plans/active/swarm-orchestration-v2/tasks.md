---
title: Swarm Orchestration v2 Tasks
description: Independently reviewable implementation slices for all accepted orchestration specifications.
type: plan
status: active
owner: team:agent-platform
tags: [agents, orchestration, tasks]
---
# Swarm Orchestration v2 Tasks

## Story 0 - Accepted specification baseline

- [x] **T0.1 — Publish the full specification package.** Repo:
  `openclaw-k8s-swarm`. Add proposal, umbrella spec, design, six component
  specs, plan, decisions, checklist, tasks, and review. Verify Markdown/front
  matter, links, terminology, and no secret-shaped content.
- [x] **T0.2 — Reconcile existing implementations.** Record which
  `agent-execution-system-v2` and Monitoring Truth capabilities are reused,
  superseded, or still pending. Do not recreate merged work.

## Story 1 - Transition-safe mission registry v2

- [x] **T1.1 — Implement schema and transition library.** Repo:
  `agent-skills`. Extend the mission helper with registry/mission revisions,
  explicit mission/task transition tables, gates, evidence, leases, and
  validation. Keep raw content and secrets impossible by schema.
- [x] **T1.2 — Add concurrency and idempotency.** Repo: `agent-skills`. Add an
  exclusive lock, stale-revision conflicts, event/transition idempotency, and
  bounded processed-event storage. Prove atomicity and no lost update.
- [x] **T1.3 — Add explicit v1 migration.** Repo: `agent-skills`. Preserve exact
  bytes, map statuses conservatively, emit a bounded report, and prove
  idempotency/rollback fixtures.
- [x] **T1.4 — Update consumers.** Repos: `openclaw-k8s-swarm`, `backoffice`.
  Promote the merged skill revision, validate v2 snapshots, and preserve v1
  read compatibility for the rollback window.

## Story 2 - Startable handoffs and capability preflight

- [x] **T2.1 — Add handoff v2 artifact contract.** Repo: `agent-skills`. Create
  schema, renderer, validator, revision hash, and fixtures for every persistent
  role.
- [x] **T2.2 — Add static preflight.** Repos: `agent-skills`,
  `openclaw-k8s-swarm`. Validate target identity, installed skill revision,
  repo policy, credential intent, task-workspace capacity, verification class,
  and approval gates.
- [x] **T2.3 — Add bounded runtime probes.** Repo: `openclaw-k8s-swarm`. Reuse
  existing capability and task-workspace helpers; add only missing stable probe
  classes and reject sensitive output.
- [ ] **T2.4 — Report-only dogfood, then enforce.** Run one reviewed handoff per
  role. Enable fail-closed assignment only after false blocks are resolved.

## Story 3 - Event-driven Emon steward

- [x] **T3.1 — Add event envelope and client.** Repo: `agent-skills`. Validate
  producer class, mission/task, kind, bounds, idempotency, and forbidden data.
- [x] **T3.2 — Implement inbox, coalescing, and leases.** Repo:
  `openclaw-k8s-swarm`. Add durable event intake, wake lease, fake wake adapter,
  reconciliation, and bounded operational state.
- [x] **T3.3 — Replace isolated wake with exact-thread continuation.** Repo:
  `openclaw-k8s-swarm`. Target the registered Emon Mattermost thread session,
  add the one-minute Mission Watcher fallback, and retain zero-model
  reconciliation. Route mismatch must fail closed.
- [x] **T3.4 — Add source adapters incrementally.** Start with specialist/
  coordinator events, then one Azure PR/build adapter, then Backoffice intents,
  then deployment/smoke. Each adapter has an independent disable path.
- [ ] **T3.5 — Activate only after approval.** Provision exact production auth,
  Secret, NetworkPolicy, ServiceAccount, and RBAC only after explicit review.

## Story 4 - Mission correlation and outcome observability

- [x] **T4.1 — Extend telemetry contract.** Repo: `openclaw-k8s-swarm`. Add
  mission/task/event semantic signals, bounded enums, correlation states, and
  privacy/cardinality rejection fixtures.
- [x] **T4.2 — Emit and reconcile controlled evidence.** Add fail-open emission
  at transition boundaries and prove one signal per accepted transition.
- [x] **T4.3 — Add dashboards and alerts.** Repo: `grafana`. Add mission-phase,
  handoff-latency, blocked-time, verified-output, noise, wake, and stuck-event
  views using bounded labels and reviewed minimum-volume thresholds.
- [x] **T4.4 — Produce exact mission review.** Add a read-only aggregate join
  that reports verified/inconclusive per outcome without timestamp-only claims.

## Story 5 - Bounded Backoffice operator intents

- [x] **T5.1 — Add intent data/API model behind disabled flags.** Repo:
  `backoffice`. Implement authorization, revision conflicts, idempotency,
  expiry, audit, and lifecycle tests.
- [x] **T5.2 — Add mission controls UX.** Repo: `backoffice`. Add pause, resume,
  gate decision, and reassignment-request controls with honest pending and
  canonical-confirmed state at desktop/mobile widths.
- [x] **T5.3 — Integrate event producer.** Publish only through the reviewed
  event client. Keep read-only missions available when delivery is disabled.
- [ ] **T5.4 — Activate only after approval.** Provision production delivery
  credential and operator role after exact review.

## Story 6 - Deterministic orchestration regression suite

- [x] **T6.1 — Add PR-safe pure and simulated suites.** Repo:
  `openclaw-k8s-swarm`, with owner-repo fixtures. Cover every required scenario
  and deterministic clock/order behavior.
- [x] **T6.2 — Add mutation tests.** Prove the suite rejects duplicate wake,
  wrong ownership, unsupported transition, lost event, stale writer, approval
  bypass, and false verification candidates.
- [ ] **T6.3 — Run disposable live canary.** Use dedicated private surfaces,
  exact revisions, metadata-only evidence, and full cleanup.
- [ ] **T6.4 — Promote sequentially.** Canary Tinus first where fleet runtime
  changes apply, then Satwa, Stewie, Emon, and Ramiro with stop-on-failure.
- [ ] **T6.5 — Complete one real mission review.** Compare coordination noise,
  wakeups, handoff latency, rework, verification, elapsed time, and evidence
  completeness with the accepted baseline.

## Story 7 - Crash-safe continuation and delivery

- [x] **T7.1 — Add durable producer outboxes.** Repo: `agent-skills`. Persist a
  validated event before delivery, retry idempotently, and never expose raw
  event or credential content in status output.
- [x] **T7.2 — Add canonical mission coordination routes.** Repo:
  `agent-skills`. Store the bounded Mattermost peer-kind/channel/thread pointer
  in the mission registry. Runtime-derived session keys and session ids stay
  out of canonical state.
- [x] **T7.3 — Add durable dispatch intent and receipt state.** Repo:
  `openclaw-k8s-swarm`. An event is complete only after the legal registry
  transition and any required dispatch intent are durable; delivery receipts
  are idempotent and recoverable.
- [x] **T7.4 — Prove continuation failures.** Cover active session, session
  reset, missing row, wrong route, internal-wake outage, duplicate watcher
  delivery, gateway restart, stale wake, and acknowledgement without required
  dispatch.

## Review And Delivery

- [ ] Verify every owner repo with its canonical gate.
- [ ] Self-review exact diffs, migration, privacy, security, and rollback.
- [ ] Create fetchable branches/PRs and record exact builds and runtime proofs.
- [ ] Update the canonical task list and Fito only at material milestones.
- [ ] Close no story while an applicable activation, PR, build, deploy, smoke,
  or cleanup remains unresolved.
