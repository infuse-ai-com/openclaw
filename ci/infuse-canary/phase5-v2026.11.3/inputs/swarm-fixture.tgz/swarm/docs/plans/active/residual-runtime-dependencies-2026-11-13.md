---
title: Residual runtime dependencies — P5 disposition
description: Defines maintained SSH and Soup Sieve repairs and explicit XML and DNS containment proposals without suppressing residual findings.
type: plan
status: active
owner: team:agent-platform
tags: [agents, security, dependencies, qualification]
sources:
  - ref: runtime-security-phased-plan-2026-11-13.md
    role: authority
---
# P5 — residual dependencies

Follow-up: the [remaining-CRITICAL investigation](remaining-critical-investigation-2026-11-13.md)
adds a published Ubuntu 2.9.14 XML backport, py-lmdb's maintained C patches and
an LMDB-free BIND-client option. These improve the available remediation paths;
none is implemented or qualified yet. The four unresolved findings below remain
open, with company-docs owning the new decision/work plan.

Source MR !71 is merged. Protected native pipeline 1983 / build 8560 succeeds;
the installed OpenSSH client, retained toolbox/DNS, parser regression and all
three sandboxed browser paths pass. The [P5 receipt](../../evidence/2026-11-13-security-p5-qualification.json)
identifies exact image/source and tests. The frozen comparison is complete; staged runtime
acceptance is complete through the corrected image below. The original P5 image inherits the P4 login-shell toolbox regression and remains rejected. Corrected protected build 8581 passes all 20 Python/pip paths, retained tools, SSH/parser, headless/headed sandbox, isolated worker and synthetic rollback checks. Its [combined receipt](../../evidence/2026-11-13-security-p4-p5-qualification.json) records an identical frozen finding set to original P5: 5 CRITICAL / 278 HIGH IDs. The corrected image has now passed its fresh Tinus canary, all five roles and six maintenance controllers; P5 bounded delivery is complete. Raw scanner reports stay advisory and unmodified.

The protected P4 build 8529 (pipeline 1973, source
`a63af87cefd2b0937f821ed54da22dc552246d7d`) produced
`sha256:2946f21dacd33d700d0a95cbbcfa4709e13590bd229e769cf31785fd820a5154`.
Its complete advisory scan 8530 reports **5 CRITICAL / 279 HIGH distinct IDs**:
the three LMDB IDs, system libxml2 and OpenSSH are the remaining CRITICAL
findings; Soup Sieve 2.9.2 is the one fixable HIGH entry. These findings confirm
the bounded repairs below. A frozen-DB comparison and production acceptance
are separate evidence, not inferred from this CI report.

## SSH client — maintained upstream build

Debian's supported Trixie package remains below the OpenSSH 10.4 fix for
CVE-2026-60002, a client-side use-after-free during host-key re-exchange.
Trixie backports was also below that fix when checked. Use upstream portable
OpenSSH 10.6p2, released 5 November, built on the same pinned Trixie base.
Sources: [Debian](https://security-tracker.debian.org/tracker/CVE-2026-60002),
[upstream release and checksum](https://www.openssh.org/releasenotes.html).

`scripts/build-agent-openssh-client.sh` checks the published SHA-256
`9ae44872090cf2f06b3cf9ff147e7f16f309671340763ed2f99248398ae29d5b`,
builds the client and unprivileged helpers, and creates an auditable local
`openssh-client` Debian package at `1:10.6p2-0infuse1`. The package retains
Kerberos and FIDO support. It installs no server, host keys or setuid helper;
the server used by upstream tests exists only in the build stage. User SSH
configuration, identities and known-hosts files remain on their existing PVCs.

The first local build exposed missing pkg-config discovery for libfido2. Adding
that build dependency preserved FIDO support. Upstream connection, proxy,
keyscan, host-key rotation, scp/sftp and unit tests then passed on local ARM64.
The protected native AMD64 build repeated them successfully; its installed client
version and source receipt match. Recheck own-account HTTPS Git and session continuity
after rollout.

Satwa owns weekly upstream release review and the private package receipt;
Tinus owns rebuilds/tests. Retire the private package when supported Debian
ships a qualified fixed client. No unstable binary repository is introduced.
If Trivy still flags the private package using distro rules, retain the raw
finding and annotate the exact installed upstream source/version; do not add
a blanket ignore or claim the scanner proves source-level coverage.

The complete P5 scan 8561 reports **5 CRITICAL / 278 HIGH IDs**, with no reported
fixable HIGH/CRITICAL entries. It still flags CVE-2026-60002 against our installed
`1:10.6p2-0infuse1` package under Debian's unresolved distro rule. Keep that raw
row: the source/checksum, native upstream tests and installed 10.6p2 binary are
the separate evidence for the upstream-patched client. The other four raw
CRITICAL IDs (system XML and three LMDB findings) remain unresolved. This is not
a claim that the scanner fell to four or that all remaining risks are fixed.

## Soup Sieve — bounded Python update

The fresh 13 November DB reports CVE-2026-126190 on baseline and P1/P2, so it is
new evidence rather than a regression introduced by those candidates. Pin the
published Soup Sieve **4.0** distribution, regenerate hashes while retaining
every unrelated Python package version, and run the upstream regression shape
under a ten-second process limit in an isolated image build/qualification pod.
The normal selector result and safe lxml entity handling are also checked.

The [maintainer advisory](https://github.com/facelessuser/soupsieve/security/advisories/GHSA-mmhr-3c5m-f64f)
states that `NOCACHE` restores the vulnerable matching behavior. Do not use that
fallback on untrusted markup. The test helper refuses a persistent agent
workspace; no regression input is sent to a live agent or external website.

## System XML — containment proposal, finding remains open

[Debian](https://security-tracker.debian.org/tracker/CVE-2026-6653) still marks
Trixie's system libxml2 as affected. The upstream fix is a substantial entity
accounting rewrite: 276 insertions / 227 deletions across seven files, including
public parser/entity structs, rather than a small isolated patch. Applying it
blindly to Debian's older branch or replacing the shared library with a newer
soname would create an ABI and maintenance obligation across ImageMagick,
BIND, LLVM and MIME consumers. Source:
[upstream commit](https://github.com/GNOME/libxml2/commit/463bbeeca1805b5c4828f50d0fefc4eebaf620df).

Proposed disposition: retain the supported system package, keep this finding
open with Satwa and a **7 December** review, and restrict untrusted XML handling
to the newer Python lxml with explicit `resolve_entities=False`, `load_dtd=False`,
`no_network=True`, `huge_tree=False`, input limits and a process deadline.
Avoid untrusted XML/DTD/SVG through system-library consumers until isolated
worker adoption or a maintained distribution fix is qualified. Trusted PNG,
JPEG, PDF and contact-sheet workflows remain tested and available.

This is a consumer policy and a tested safe parser configuration, not a
technical prohibition on arbitrary same-UID subprocesses. The system package
remains installed and affected. The lxml test does not validate every system
consumer or justify changing its raw finding. P6 production isolation is still
a separate adoption decision. Escalate newly required untrusted XML workflows
instead of silently treating this proposal as comprehensive containment.

## DNS / LMDB — retain required DNS, avoid untrusted database input

[Debian's LMDB record](https://security-tracker.debian.org/tracker/CVE-2019-16225)
remains unfixed even on newer releases and identifies attacker-supplied or
corrupted `data.mdb` as the prerequisite. The image carries LMDB through BIND
libraries used by DNS tooling; no LMDB database workload was identified in the
bounded runtime inventory. That is not proof no future task can load one.

Proposed disposition: retain `dig` and its supported library dependencies,
qualify DNS queries, prohibit processing untrusted LMDB databases in the
persistent runtime, and keep the three raw LMDB findings open under Satwa's
**7 December** review. Removing the shared library would break linked tools;
substituting an incomplete `dig` wrapper would silently change required CLI
semantics. A maintained LMDB-free DNS build/replacement can be evaluated if the
exposure or workload changes. No library is deleted or finding suppressed here.

## New Trixie HIGH findings — retained, bounded review

The identical frozen DB comparison removes 223 IDs and adds **15 HIGH IDs**
between the selected Bookworm descendant and P4 (net five CRITICAL and 203 HIGH
removed). P5 removes Soup Sieve's HIGH ID and adds none. The native scan's
current-image positive control exactly matches the full image scan's package
finding tuples and all 794 HIGH/CRITICAL occurrences. Slow local scan attempts
were incomplete; the complete native reports, actual runtime digests and DB
checksum are recorded in the P4/P5 receipts. No incomplete report is counted as
a clean result.

| Added IDs / package | Applicability and interim disposition |
| --- | --- |
| CVE-2024-58015; CVE-2026-23102, -46279, -98118 / linux-libc-dev | Image development-header detections. They do not identify the running host kernel. Keep raw rows and route host assessment separately; no host patch claim. |
| [CVE-2026-15308](https://security-tracker.debian.org/tracker/CVE-2026-15308) / Python 3.13 | Incremental HTML-parser CPU exhaustion; Debian still marks this Trixie package affected. Bound untrusted markup size and execution time; do not treat the new interpreter as universally safer than Bookworm. |
| [CVE-2026-19445](https://security-tracker.debian.org/tracker/CVE-2026-19445) / Python 3.13 | Specific server-side SNI context lifetime. Ordinary TLS clients are outside this precondition. Do not introduce a Python TLS server that drops its original callback context; the platform gateway/TLS sidecar use Node. |
| [CVE-2026-19553](https://security-tracker.debian.org/tracker/CVE-2026-19553) / Python 3.13 | Missing hostname in wrap_bio/async TLS can skip hostname checks. Explicit nonempty server_hostname is required; no TLS-verification bypass is an accepted workaround. |
| [CVE-2026-82049](https://security-tracker.debian.org/tracker/CVE-2026-82049) / Python 3.13; [CVE-2026-23949](https://security-tracker.debian.org/tracker/CVE-2026-23949) / Debian setuptools wheel | Untrusted archive extraction paths. The affected Debian seed wheel is distinct from the hash-locked toolbox. Do not use tarfile filters or jaraco tarball handling as proof of safe arbitrary archive extraction; require bounded, link-rejecting extraction in an isolated environment. |
| [CVE-2026-24882](https://security-tracker.debian.org/tracker/CVE-2026-24882) / GnuPG source-package rows | The isolated installed P5 inventory finds no tpm2daemon package path or TPM device. This narrows the named TPM command prerequisite; it is not a blanket GnuPG or future-image suppression. |
| [CVE-2026-76642](https://security-tracker.debian.org/tracker/CVE-2026-76642), [CVE-2026-78408](https://security-tracker.debian.org/tracker/CVE-2026-78408), [CVE-2026-78409](https://security-tracker.debian.org/tracker/CVE-2026-78409) / util-linux | Privileged mount/cgroup paths. Retain UID 10001, empty effective/bounding capabilities and NoNewPrivs=1, confirmed in the candidate. No privileged host namespace or mount workflow is introduced. These package rows remain visible. |
| [CVE-2026-119741](https://security-tracker.debian.org/tracker/CVE-2026-119741) / rsync | Crafted receiver checksums can exhaust a sender. Retain trusted local sync workflows; avoid untrusted remote delta peers/public daemon use until a maintained fixed package is qualified. |
| [CVE-2026-86139](https://security-tracker.debian.org/tracker/CVE-2026-86139) / system XML | A distinct URI-escaping overflow, not the entity issue above. Keep open. The newer bundled lxml library is not proof of immunity to every XML issue; audit that copy separately even if the package scanner does not enumerate its embedded C library. |

These are scoped consumer rules and prerequisite observations, not claims of
complete isolation or a rewritten scanner severity. Satwa owns maintained
Debian updates/consumer replacements and the **7 December** review, including
the Python, archive and XML cases. Do not mix unstable distribution binaries
into the supported base to make the count disappear. Production worker
adoption remains the separate P6 proposal.

## Acceptance and rollback

Capture exact P4 and P5 image/package inventories, same-database scans, SSH
upstream/native consumer results, safe parser evidence, DNS and media checks,
own-account HTTPS Git, memory and session continuity. Tinus observation precedes
fleet progression. Roll back to the preceding exact image if any retained
capability regresses; no PVC conversion, credential rotation or host change.
Residual XML/LMDB risk and the unrelated host-kernel question remain explicit
after the bounded P5 source repairs are delivered.
