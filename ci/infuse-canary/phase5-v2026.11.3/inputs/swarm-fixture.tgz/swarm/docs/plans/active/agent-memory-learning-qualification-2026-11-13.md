---
title: Tinus conservative memory learning qualification
description: Native source findings, shadow-observation contract and elapsed evidence gates before changing learning admission.
type: evidence
status: active
owner: team:agent-platform
tags: [agents, memory, qualification]
---
# Tinus learning qualification — 13 November 2026

Freshness qualification precedes this work. Learning admission is unchanged.
The accepted gate is three nightly shadow cycles followed by three enabled
Tinus canary cycles. Manual probes and fixtures do not count as nightly cycles.
Ramiro mail remains paused; there is no new purge or backup operation.

## Pinned native findings

Reviewed `aolea/openclaw` source `19818bb59a7bf9d4e9989fb9a4df6f1b4ffe8ca6`,
the fork in the current runtime. Relevant source paths are
`packages/memory-host-sdk/src/host/session-files.ts`, `session-provenance.ts`
and `extensions/memory-core/src/session-ingestion.ts`, `dreaming-phases.ts`.

- Export already excludes heartbeat turns, recalled-memory turns, generated
  dreaming narratives and cron runs. Foreign transcript provenance is untrusted.
- Candidate provenance retains owner/agent/system/untrusted, session kind and
  observation time. It drops finer control-event metadata. Assistant output can
  inherit system origin, so system origin alone cannot justify rejection.
- The scanner supports a provenance callback, but the dreaming ingestion path
  does not currently provide one. An admission change must preserve terminal
  cursor progress and seen hashes; skipping without acknowledgement risks replay.
- A 12-character minimum already exists before candidate creation. A new
  conservative filter must not add another length threshold. Very short human
  decisions need a native regression case because this existing cutoff can
  remove them before the proposed classifier sees them.
- Candidate snippets are capped at 280 characters. Classification cannot certify
  the full message's value from a truncated preview. Ambiguous recovery messages,
  useful failures and repeated decisions remain eligible.

## Qualification contract

The first shadow rule identifies only the exact abort sentinel with canonical
system provenance. Human quotation, unknown provenance, substantive crash reports,
short corrections and decisions remain eligible. Recovery/no-work prose needs
richer native event provenance before exclusion can be justified.

The observer must use the native source selection, exclusion policy, forgotten
session exclusions, lookback, source ordering and candidate caps. It must read
native state and write only its separate private qualification evidence. No
transcript, cursor, recall or learned-Markdown mutation is allowed. Pin native
module hashes and refuse an unqualified runtime revision.

Observe 14–16 November, before the 03:00 UTC native dream and after its normal
completion window. These are pending observations, not three completed cycles.
Before each nightly dream, save candidate hashes, proposed classification and a
bounded private sample. Afterward, compare with actual native consumed hashes and
artifact changes. Record asynchronous dream completion as separate evidence;
cron dispatch success or a changed file alone does not prove a useful dream.
Publish aggregate counts only. A low or zero candidate count is insufficient to
approve filtering. Investigate every proposed rejection before enabling anything.

## Gates

1. Freshness fleet qualification complete.
2. Regression fixtures preserve short decisions, corrections, blockers, useful
   failure lessons, ambiguous chatter, duplicate summaries and historical or
   adversarial quoted material; exclude only authenticated exact control markers.
3. Manual Tinus observer qualification shows unchanged native memory state.
4. Three dated nightly shadow records plus reviewed samples; failures or missing
   asynchronous dream evidence remain explicit. No automatic transition.
5. Implement and review native admission and durable-promotion changes in the fork,
   then package a qualified image and enable only Tinus for three nightly cycles.
6. Expand one agent at a time after useful-learning and mirror checks pass.

The canonical runtime gate passed 487 tests and all remaining checks. Server
admission dry-run passed for the temporary ConfigMap and CronJob.

Freshness fleet qualification completed at 12:23 UTC. Four regression tests cover
14 control/useful-content cases, unknown provenance, duplicate preservation and
finite observation windows. Tinus manual probe at `2026-11-13T12:25:02Z` saw
three pending candidates: all three retained, zero proposed exclusions. Native
workspace-scoped memory-core state and eight persona/memory/diary artifact hashes
were identical before and after the probe. This verifies observation behavior,
not filtering effectiveness or a completed nightly gate.

The separate qualification manifest uses the existing memory collector service
account. It mounts only immutable reviewed probe code, executes only inside a
single ready Tinus pod, caps remote execution and exports only aggregate receipts.
It creates no RBAC, PVC mount, persistent-agent restart or learned-memory write.
Observation windows are 02:50 and 03:50 UTC on 14–16 November 2026; year/date
checks prevent later execution. Remove the temporary CronJob after evidence review.
Private bounded samples and candidate hashes stay under
`/workspace/.agent-memory-quality/tinus-shadow-20261113`, outside native ingestion.

The source defines the observation, not its activation receipt. Track activation
and the dated nightly evidence in the
[company execution tracker](https://gitlab.infuse-ai-tech.party/platform/engineering/company-docs/-/blob/main/docs/40-agent-system/agent-memory-refactor-2026-11-12/tasks.md).
No filter or native patch is included in this slice. Nightly observation count
is 0/3 on 13 November.
