---
title: Agent Observability Iteration 3 Acceptance
description: Acceptance evidence for honest no-core skill attribution across the five-agent fleet.
type: evidence
status: active
owner: team:agent-platform
tags:
  - evidence
  - observability
  - agents
  - skills
---

# Agent Observability Iteration 3 Acceptance

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Scope And Revisions

Iteration 3 adds explicit, metadata-only skill lifecycle evidence without
changing or rebuilding packaged OpenClaw or Codex artifacts.

- `agent-skills` PR 2549 merged as
  `9df829a83bd59341f4e693b9568e9d75e0b51480`.
- `openclaw-k8s-swarm` PR 2550 merged as
  `dbf7204fd16d1187ffc86b3c34ab958890c7e5a2`.
- `grafana` PR 2551 merged as
  `246d2e4bfae44c6852bc68af83ebf46b1924865a`.
- Swarm PR build 5912 and main build/deployment 5913 passed.
- All five agents run immutable image digest
  `sha256:8a854483faad6916a77fdaa815e2648aa38f9d6975df3c3707c415731f23d3d3`.
- Live skill bundle revision is
  `sha256:074f0831eb250c80329e35e9827b9415080a887f336daba5b7bc090b2609d587`.
- The pinned OpenClaw/Codex runtime revision remains
  `3d1a6e4197b2bcce4b90cd3fc5b6de8a5b1f24c0`.

## Contract And Attribution Proof

The schema 1.1.0 contract accepts only `native`, `explicit_wrapper`, and
`declared_marker` attribution. The public marker tool can emit only
`explicit_wrapper` or `declared_marker`; it cannot claim native evidence.
Positive and negative fixtures cover lifecycle, content, secret, inferred,
native-marker, and unbounded-skill cases.

Four actual Tinus pilot executions produced exactly eight bounded lifecycle
series before the outage drill:

| Skill | Attribution | Start | Finish |
|---|---|---|---|
| `azure-devops` | `explicit_wrapper` | `started` | `success` |
| `knowledge-retrieval` | `explicit_wrapper` | `started` | `success` |
| `runtime-operations` | `explicit_wrapper` | `started` | `error` |
| `verify-this` | `declared_marker` | `started` | `success` |

Every series carried `agent-developer`, the exact image digest, and the exact
skill bundle revision. The live label-key scan found no prompt, response,
request, objective, reference, path, content, output, command, argument,
secret, token, credential, stderr, or stdout keys. No custom series claimed
`attribution_method="native"`; a controlled live native-marker request was
rejected with one tool call and one failure.

The Grafana dashboard keeps official OpenClaw native skill metrics separate
from explicit `infuse.skill.execution` evidence and never derives skill usage
from generic tool calls. All 13 PromQL expressions parsed with Prometheus 3.6.
The merged ConfigMap and the mounted Grafana dashboard both matched source hash
`f57b8cab805124d2189a29e299aa0cab288f949ef4d67fa6773edd6449a068d9`.
Grafana 12.1.1 reported database `ok`, Ready state, and zero restarts.

## Fail-Open And Fleet Proof

With the collector scaled to zero, an actual `verify-this` execution returned
`VERIFIED`; both start and finish marker calls succeeded and the agent reported
zero tool failures. After collector restoration, the same bounded proof
exported its two lifecycle spans. The collector accepted and sent 13 of 13
post-recovery spans, refused zero, and remained Ready with zero restarts.

Deep runtime smokes passed for every agent on the final digest:

| Agent | Declared skills | Runtime result |
|---|---:|---|
| `agent-developer` | 25 | Gateway and Mattermost connected |
| `agent-designer` | 16 | Gateway and Mattermost connected |
| `agent-infra` | 17 | Gateway and Mattermost connected |
| `agent-coordinator` | 28 | Gateway and Mattermost connected |
| `agent-intake` | 21 | Gateway and Mattermost connected |

All five Deployments and the collector ended Ready with zero restarts. The
task-scoped Vaultwarden Kubernetes administrator item was used only to apply
and verify the merged monitoring ConfigMap because normal Kapiteky RBAC denies
the monitoring namespace. No Vaultwarden item changed, no credential value was
logged or persisted, and the temporary credential bridge was removed.

## Verdict

Tasks T3.1 through T3.4 pass. Skill attribution is honest, explicit,
privacy-bounded, fail-open, and fleet-compatible without a custom OpenClaw or
Codex rebuild. Iteration 4 may begin; Opik admission remains its separately
approved exact-dataset gate.
