---
title: Swarm Orchestration v2 Requirements Checklist
description: English-level acceptance and safety checks for the complete orchestration specification package.
type: report
status: active
owner: team:agent-platform
tags: [agents, orchestration, requirements]
---
# Swarm Orchestration v2 Requirements Checklist

## Product And Ownership

- [x] Problem is stated from the human and execution-system perspective.
- [x] Fito, Emon, specialists, Kapiteky, and operator responsibilities are
  explicit.
- [x] Emon's registry is the sole canonical mission state.
- [x] Backoffice, Mattermost, Boards, artifacts, and telemetry have non-
  authoritative roles.
- [x] Adding persistent agents is an explicit non-goal.

## Mission And Task Semantics

- [x] Mission and task state values are explicit.
- [x] Allowed and forbidden transitions are observable.
- [x] Assignment, acknowledgement, active work, waiting, blocking, delivery,
  review, and verification are distinct.
- [x] One active mission per project and one owner per task remain invariant.
- [x] Mission completion requires verified tasks, resolved gates, and closeout
  evidence.
- [x] Migration, concurrency, idempotency, leases, and rollback are covered.

## Events And Wakeups

- [x] Material event kinds and non-events are explicit.
- [x] Authentication, authorization, validation, dedupe, coalescing, and wake
  leases are specified.
- [x] Reconciliation is defined as silent recovery.
- [x] Source adapters are independently disabled and cannot mutate the registry
  directly.
- [x] Production credentials, Secrets, NetworkPolicy, ServiceAccount, RBAC, and
  activation remain explicit gates.

## Handoffs And Capability

- [x] Handoff v2 has a machine-readable contract and durable human-readable
  rendering.
- [x] Skills, repos, credential intent, tools, workspace, network,
  verification, and approval classes are covered.
- [x] Preflight occurs before the specialist mention.
- [x] Credential values and sensitive probe output are forbidden.
- [x] Delivered and verified evidence rules are explicit.

## Observability

- [x] Existing official-versus-curated telemetry authority is preserved.
- [x] Mission/task/event signals use bounded dimensions.
- [x] Mission ids, task ids, user ids, channel ids, and source refs are not
  metric labels.
- [x] Traffic source, missing correlation, privacy, cardinality, fail-open, and
  exact join behavior are covered.
- [x] Measures describe outcomes, delay, noise, rework, intervention, and
  evidence—not just activity.
- [x] Currency cost waits for a canonical source.

## Backoffice

- [x] Operator controls are intents, not direct mission writes.
- [x] Pause, resume, gate decision, and reassignment semantics are bounded.
- [x] Authorization, expected revision, idempotency, expiry, audit, and
  canonical-state confirmation are specified.
- [x] Read-only mission display survives control disablement.
- [x] Write-capable production activation remains separately gated.

## Testing And Delivery

- [x] Pure, simulated, and controlled live canary layers are defined.
- [x] Ownership, duplicates, ordering, failures, restart recovery, concurrency,
  approval boundaries, and parallel results have scenarios.
- [x] Every owner repository and canonical verification gate is named.
- [x] Branch, PR, deployment, promotion, rollback, and cleanup expectations are
  explicit.
- [x] Existing merged implementations are reused rather than duplicated.
- [x] Every material open implementation choice is recorded as non-blocking or
  approval-gated.
