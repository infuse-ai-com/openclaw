---
title: Mission Continuation
description: Exact-thread wake, fallback, recovery, and durable-delivery contract for Emon missions.
type: architecture
status: active
owner: team:agent-platform
tags: [agents, orchestration, mattermost, reliability]
---
# Mission Continuation

## Goal

Resume Emon's existing mission context after a material event and prove that the
next legal action became durable. Waking a model without advancing canonical
state is not success.

## Canonical Address

Each mission may register one coordination route containing a Mattermost peer
kind, channel id, and root thread id. Private channels use `group`; public
channels use `channel`. The OpenClaw session key is deterministically derived
at runtime as:

```text
agent:<coordinator>:mattermost:<group|channel>:<channel-id>:thread:<thread-id>
```

The runtime must verify that the key belongs to the declared coordinator,
Mattermost channel, and thread before sending an internal wake. Session ids are
ephemeral implementation detail. Missing, ambiguous, malformed, or mismatched
routes fail closed and never degrade to a main-session wake.

## Normal Path

1. Validate, authorize, and durably accept a metadata-only event.
2. Coalesce pending events by mission and acquire one exclusive wake lease.
3. Resolve and verify the exact mission-thread session.
4. Reserve and enqueue one bounded OpenClaw system event to that session with
   wake mode `now` and the wake lease id as its durable idempotency key.
5. Poll the matching durable ticket. Only `started` or `completed` with one run
   id for the exact coordinator session proves model-run start; terminal
   failure, mismatch, restart-unknown, or a sixty-second timeout fails closed
   into the existing watcher path.
6. Emon reloads the registry and leased inbox batch, applies only legal and
   idempotent changes using each event's idempotency key, persists required
   dispatch intents, and acknowledges the processed event ids. Intake refuses
   a successful acknowledgement unless every processed event has a matching
   durable v2 registry receipt and each declared dispatch key is already
   durable.

The system event contains only mission id, lease id, and reconciliation
instructions. It grants no state-transition, approval, merge, deploy,
reassignment, or external-communication authority.

## Mission Watcher Fallback

If the lease is not durably acknowledged within sixty seconds, a separately
owned Mission Watcher webhook may post exactly one reply to the registered root
thread. The webhook identity is provisioned out of band; its credential is read
only from the runtime secret environment and never passed in argv, state,
telemetry, or logs.

The fixed reply is wake-only:

> Mission events are pending. Reconcile the canonical registry and inbox for
> the referenced mission. This wake grants no approval, merge, deploy,
> reassignment, or state-transition authority.

The post includes one opaque wake reference for deduplication and no source
event data. Mattermost inbound routing may recreate a missing local session row
for the same thread. The watcher never posts outside the registered thread and
never retries a successfully recorded post.

## Durable Outboxes

Producers persist a validated event before attempting intake delivery. Accepted
receipts mark the item delivered; failures remain pending for bounded retry.
Repeated rendering of unchanged source evidence reuses the first sealed event,
and a retry command drains recoverable items without reconstructing source
state. Producer status output contains counters and reason codes only.

Required task handoffs use a dispatch outbox. The transition journal records
the intended dispatch before an inbox event can be completed. Delivery uses a
stable Mattermost pending-post identity and a secure-environment credential;
the exact post receipt is recorded idempotently. A crash between any pair of
steps is recovered from durable state without repeating the logical handoff.

## Recovery And SLOs

- accepted actionable event to Emon run start: at most 1 minute;
- accepted actionable event to durable transition or next handoff receipt: at
  most 20 minutes when a material next action exists;
- unresolved actionable event to one human-facing alert: 1 hour.

A frequent script-only reconciler handles expired leases, pending outboxes,
missed wake/fallback state, and stale acknowledgements. It does not invoke a
model when there is no due action. Recovery before twenty minutes is bounded
and silent; the one-hour alert is deduplicated per unresolved wake reference.

## Required Tests

- event arrives while the mission session is running;
- session id rolls while the thread session key remains stable;
- local session row is absent and Mattermost fallback recreates it;
- route is stale, malformed, or belongs to another agent/thread;
- internal wake is unavailable and fallback succeeds;
- duplicate watcher execution produces one post;
- gateway restarts after event persistence and before wake;
- duplicate wake submission reuses one ticket and cannot enqueue a second run;
- malformed, mismatched, failed, skipped, or restart-unknown wake tickets fail
  closed and never count command acceptance as run start;
- stale wake arrives after the mission advanced;
- Emon responds but does not persist a required dispatch;
- duplicate producer delivery and duplicate dispatch receipt remain one logical
  event and handoff.

## Activation And Canary

Source merges and fake-adapter tests do not activate delivery. Provisioning the
Mission Watcher credential, network access, producer credentials, RBAC, or
production flags requires exact approval. The live sequence is a disposable
private synthetic mission followed by one small reversible Backoffice task.
Eagle Eye is excluded from the canary.

The reviewed live intake is a second unprivileged container in Emon's pod. It
shares only the coordinator workspace, reads token digests and an exact
mission-scoped producer policy from optional ConfigMap volumes, and exposes one
ClusterIP Service. NetworkPolicy admits only pods carrying the synthetic
producer label. The producer ServiceAccount has no API token and no Role or
RoleBinding. Missing config makes the health and event endpoints fail closed;
source deployment alone does not accept events.

Mission Watcher and dispatch use separate Mattermost bot tokens from separate
optional Secret references. The intake never receives either token. The
producer token is mounted only into the short-lived producer Job, while intake
stores only its SHA-256 digest. Live procedure and rollback are in
`../../../../MISSION_CONTINUATION_CANARY.md`.

Controlled acceptance is decided by the read-only
`mission-continuation-evidence-oracle.py`, not manual counting. The oracle
diffs raw private before/after registry, inbox, continuation ledger, outboxes,
Mattermost posts, and the terminal wake-ticket receipt; it rejects any extra
event, turn, transition, root, handoff, watcher reply, or unexpected post and
emits only sanitized revision/count/reason metadata.
