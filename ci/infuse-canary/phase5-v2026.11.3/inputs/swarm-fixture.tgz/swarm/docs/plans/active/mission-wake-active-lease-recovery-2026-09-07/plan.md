---
title: Active-Lease Wake-Ticket Recovery Implementation Plan
description: Implementation plan for recovering delayed wake tickets while the mission continuation lease remains active.
type: plan
status: active
owner: team:agent-platform
tags: [plan, agents, mission-continuation, recovery]
---

# Implementation Plan: Active-Lease Wake-Ticket Recovery

## Approach

1. Add a regression where the first wake result is ambiguous and posts one
   watcher, while stable-key status exposes the ticket only on the next pass.
2. Move eligible stable-key polling ahead of the active-lease watcher short
   circuit.
3. Persist recovered ticket state through the existing conflict-checking ledger
   mutation and preserve normal completion, grace, and watcher behavior.
4. Run the focused wake suite, full `task verify-ci`, diff review, and protected
   Azure PR CI.

## Safety

- Recovery is lookup-only and never calls the wake submission method.
- The existing ledger rejects a conflicting ticket id.
- Existing watcher idempotency remains authoritative.
- This branch remains independent from the assignment-authority branch.

## Rollback

Abandon or revert the source PR before deployment. Runtime state is unchanged by
this implementation work.
