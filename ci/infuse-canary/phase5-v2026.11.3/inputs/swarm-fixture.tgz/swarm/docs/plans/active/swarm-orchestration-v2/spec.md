---
title: Swarm Orchestration v2 Specification
description: Umbrella requirements for canonical mission state, event-driven coordination, handoff governance, capability preflight, mission telemetry, Backoffice operator intents, and orchestration canaries.
type: architecture
status: active
owner: team:agent-platform
tags:
  - agents
  - orchestration
  - missions
  - observability
  - backoffice
---
# Swarm Orchestration v2 Specification

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Problem

Infuse AI's agents can independently plan, implement, review, deploy, and
report. The orchestration layer still relies too heavily on chat interpretation
and periodic coordination runs. Mission truth exists, but its task lifecycle,
event intake, capability checks, operator controls, and outcome-level telemetry
are not yet one complete governed system.

Without that control plane:

- status checks can outnumber material work;
- duplicate or late events can retrigger the same action;
- an agent may receive a task before its access or tools are proven;
- “done” can mean delivered, reviewed, deployed, or verified depending on the
  speaker;
- Backoffice can display state but cannot safely express operator intent; and
- tool-level telemetry cannot answer whether orchestration improved outcomes.

## Users And Scenarios

- **Fito** sees current mission truth, waiting decisions, verified outcomes,
  and bounded operator actions without reading every role thread.
- **Emon** receives one deterministic list of actionable mission events and
  owns all authoritative state transitions.
- **Specialists** accept one startable assignment, report material transitions,
  and provide fetchable evidence without ambient status chatter.
- **Kapiteky** improves the system, reviews sensitive boundaries, and can audit
  mission evidence without becoming a parallel coordinator.
- **Operators and reviewers** can correlate a mission with its role tasks,
  agent turns, pull requests, builds, deploys, smokes, and closeout evidence.

## Goals

1. Evolve `infuse.team-missions/v1` into an explicit transition-safe mission
   and task lifecycle while preserving Emon's registry authority.
2. Replace periodic coordination polling with material-event wakeups and keep
   one low-frequency reconciliation path.
3. Make handoffs machine-checkable and capability-aware before assignment.
4. Add privacy-safe mission correlation and outcome metrics across all
   execution surfaces.
5. Add bounded Backoffice operator intents without direct registry writes.
6. Expand the single behavioral canary into a deterministic orchestration
   regression suite.

## Non-Goals

- Adding another persistent agent identity.
- Allowing specialists to self-assign or mutate mission authority.
- Making Mattermost, Azure Boards, Backoffice, telemetry, or artifacts a second
  mission source of truth.
- Automatically creating work from every artifact or repository event.
- Capturing prompts, responses, raw errors, commands, paths, credentials,
  private message content, or chain-of-thought in telemetry.
- Rebuilding OpenClaw or Codex when public hooks and external services are
  sufficient.
- Activating credentials, RBAC, or production write paths merely because their
  source implementation has passed tests.

## Domain Language

- **Mission registry:** Emon-owned canonical mission lifecycle state.
- **Mission snapshot:** validated read-only projection of registry state.
- **Mission event:** bounded, authenticated fact that may make a mission
  actionable; it is not itself an instruction to mutate external systems.
- **Operator intent:** authenticated human request to pause, resume, approve,
  or request reassignment; Emon validates and applies the resulting transition.
- **Lease:** bounded assignment timing record used for acknowledgement and
  staleness decisions, not a license to retry external effects.
- **Material transition:** state change that affects ownership, blocking,
  evidence, approval, release, or completion.
- **Capability preflight:** deterministic check that the assigned agent has the
  declared skill, repository, credential intent, workspace, and verification
  capability required by the task.
- **Verified outcome:** acceptance evidence independently checked against the
  mission contract; stronger than an agent's delivered claim.
- **Reconciliation:** low-frequency recovery check for missed events or stale
  leases; it must not generate unchanged status chatter.

## System Invariants

1. Emon is the only authoritative mission-transition owner.
2. One project has at most one active autonomous mission.
3. One concrete task has exactly one responsible agent.
4. A task cannot enter `active` before acknowledgement and capability preflight.
5. A task cannot enter `verified` without explicit evidence and a verifier.
6. Event ingestion is idempotent; redelivery does not repeat a transition or
   wake-up.
7. Registry mutation is serialized and atomic.
8. Mattermost posts and external events are evidence pointers, not hidden
   authoritative state.
9. Backoffice never writes the registry directly.
10. Telemetry remains metadata-only, bounded-cardinality, and fail-open.
11. Reconciliation remains silent when no material action exists.
12. Production activation preserves an independent disable and rollback path.

## Component Specifications

1. [Canonical Mission Control Plane](specs/01-canonical-mission-control-plane.md)
2. [Event-Driven Steward](specs/02-event-driven-steward.md)
3. [Handoff And Capability Preflight](specs/03-handoff-capability-preflight.md)
4. [Mission Correlation And Orchestration Metrics](specs/04-mission-correlation-observability.md)
5. [Backoffice Mission Operator Intents](specs/05-backoffice-mission-operator-intents.md)
6. [Deterministic Orchestration Canary Suite](specs/06-orchestration-canary-suite.md)

## Program Acceptance Criteria

- A v1 registry migrates deterministically to v2 with an exact backup and no
  loss of mission, task, artifact, or source pointers.
- Invalid task transitions, duplicate events, concurrent writers, expired
  leases, and unsupported verification claims fail closed.
- One material role event wakes Emon once; redelivery causes no second wake;
  an unchanged reconciliation run sends no message.
- A missing required skill, repo grant, credential intent, isolated workspace,
  or verification capability blocks assignment before the specialist is
  mentioned.
- A controlled mission can be followed from mission id through task events,
  agent turns, PR/build/deploy references, and verified closeout without
  exposing task content.
- Backoffice displays operator-intent state honestly and cannot directly alter
  registry files or bypass Emon's transition rules.
- The canary suite detects wrong ownership, duplicate wakeups, stale leases,
  unsupported completion, restart recovery, approval violations, and parallel
  independent result ordering.
- One real mission demonstrates lower coordination-to-execution chatter than
  the accepted baseline and completes with all evidence gates satisfied.

## Risks And Approval Gates

- Event-ingress credentials, Kubernetes Secrets, NetworkPolicy, ServiceAccount,
  RBAC, and production activation require exact approval.
- Operator intents that can lead to merge, deploy, access, secret, destructive,
  or external actions remain subject to the underlying approval boundary.
- Mission identifiers must never become unbounded Prometheus labels.
- Migration must preserve a rollback copy and cannot run automatically at pod
  startup.
- Existing `agent-execution-system-v2` and monitoring work remain authoritative
  until each replacement slice passes parity.

## Source Links

- Fito's accepted 2026-08-31 Mattermost direction.
- `docs/plans/active/agent-execution-system-v2/`
- `docs/plans/active/agent-monitoring-truth-and-alerts-2026-08-31.md`
- `agent-skills/skills/agentic-product-engineering/`
- `company-docs/docs/40-agent-system/agent-team-mission-workflow.md`
- `backoffice` authenticated `/missions` implementation.
