---
title: Agent Execution System v2 Implementation Plan
description: Cross-repository delivery plan for Emon mission stewardship, role channels, Backoffice mission visibility, and the canonical Artifact Registry.
type: plan
status: active
owner: team:agent-platform
tags:
  - agents
  - artifacts
  - backoffice
  - missions
  - orchestration
---
# Agent Execution System v2 Implementation Plan

## Scope

Deliver the accepted operating model through reviewed changes in
`company-docs`, `agent-skills`, `openclaw-agents-persona`,
`openclaw-k8s-swarm`, `backoffice`, and any existing deployment repository
required by the reviewed runtime contract.

## Current State

- Company and persona sources already say Emon coordinates by default, but
  older runtime text still describes broad role-thread watch loops and direct
  Kapiteky review in ordinary execution.
- `agent-skills` has a basic `mission_create.py` helper but no lifecycle-safe
  mission registry CLI or deterministic steward decision.
- The swarm repo has an `emon-mission-dispatcher` installer, but no dispatcher
  job is currently installed in Emon's live profile.
- Backoffice has no `/missions` page.
- The current artifact system is filesystem/collector/relay based. A complete
  deferred registry design exists and is now reactivated by Fito's decision.
- `ai-lab/kapiteky-emon-coordination` already exists with Fito, Kapiteky, and
  Emon.
- `core/backoffice-dev`, `core/backoffice-design`, and
  `core/backoffice-infra` do not yet exist.

## Proposed Approach

### Slice 1: authority and mission semantics

Update company policy, executable skills, personas, and runtime consumers
together. Introduce a versioned mission schema and CLI in `agent-skills`; keep
the registry in Emon's workspace. Replace generic watch-loop language with
material-event and next-action rules, and make Emon's end-to-end delivery
ownership explicit.

### Slice 2: runtime and channel topology

Create the three private Backoffice role channels with Fito, Emon, and the one
specialist appropriate to each channel. Keep Kapiteky absent. Preserve Emon's
ambient Mattermost mode and specialists' mention-only mode. Install the
reviewed mission steward only after the source revisions are deployed.

### Slice 3: Backoffice Missions read model

Export only the validated mission registry snapshot from Emon's workspace to a
read-only Backoffice source. Add `/missions` with honest freshness and invalid
source states. V1 has no Backoffice write controls.

### Slice 4: canonical Artifact Registry service

Build a separate registry process from the Backoffice repository and deploy it
as an internal service with its own writable canonical PVC. Backoffice web reads
through the service or a read adapter and never receives a writable registry
mount. Add one publish client in `agent-skills`.

### Slice 5: dual-write canaries and cutover

Canary Kapiteky, then one Kubernetes agent. Compare manifest, metadata, HTML,
asset, and bundle hashes against the current feed. Migrate remaining producers
one at a time. Switch Backoffice reads and purge only after parity and rollback
gates pass.

## Data, API, Auth, And Deployment Impact

- Mission registry: versioned JSON in Emon's PVC; snapshot is read-only in
  Backoffice.
- Registry API: internal HTTP service, versioned JSON bundle protocol, exact
  revisions, status/read/list, and admin purge.
- Agent authentication: one reviewed credential per persistent producer,
  mapped server-side to its producer namespace.
- Human authentication: Backoffice OIDC session; server-side proxy uses a
  separate internal registry identity and records the human actor.
- Lifecycle: Backoffice Postgres remains trash/restore/audit/job authority in
  the first cutover. Registry owns canonical content and ordinary tombstones.
- Deployment: new internal service, PVC, health probes, resource bounds,
  NetworkPolicy, Secrets, backup/restore runbook, and rollback switch.

## Alternatives Considered

- Keep polling specialists from Kapiteky: rejected because it duplicates Emon
  and caused the observed noise.
- Keep all role threads in one project channel: rejected because ambient
  context activates unrelated agents and mixes specialist histories.
- Treat the shared feed PVC as the public contract: rejected because paths and
  mounts would remain host-specific.
- Add a Mac-only deletion daemon: rejected because it preserves source-host
  coupling.
- Require object storage immediately: deferred; the storage adapter permits a
  later S3/MinIO migration after the API contract is proven.

## Verification Gates

- Repository-specific full verification for every changed repo.
- Mission schema/CLI unit tests and deterministic steward fixtures.
- Persona and bundle/catalog validation.
- Kustomize render, policy, secret-shape, and channel-routing tests.
- Backoffice lint, typecheck, build, unit/e2e tests, and authenticated browser
  evidence for `/missions` and lifecycle integration.
- Registry contract and hostile-input tests.
- CI/policy builds on exact PR merge refs.
- Canary publish parity from Mac and Kubernetes.
- Production rollout, health, logs, restore, exact purge, tombstone, and
  rollback evidence before retiring current transport.

## Rollback Or Disable Path

- Disable the mission steward without deleting mission state.
- Keep the current channel and task threads readable during migration.
- Disable `/missions` snapshot ingestion while preserving source files.
- Keep current collector/feed reads and source lifecycle worker active during
  registry dual-write.
- Switch Backoffice reads back to the feed and stop registry publication if
  parity, availability, or lifecycle checks fail.

## Decisions

- Emon's local workspace is the v1 mission source; Backoffice is the target
  visibility surface.
- V2 source readiness does not migrate the registry or activate any steward.
- Portfolio review and bounded backlog delivery are distinct: discovery is
  proposal-only, while an approved ticket batch may be one delivery mission.
- Kapiteky remains absent from specialist role channels because read-on-demand
  was live-proven with the system-admin identity.
- Separate Mattermost threads represent distinct tasks.
- Artifact publication does not automatically create an assignment in v1.
- Every authenticated company agent and human may read shared artifacts.
- Trashed artifacts have no automatic retention deadline.

## Known Gaps

- Exact registry bundle/file limits must be chosen during implementation and
  encoded as configuration plus tests.
- Production credential values and Kubernetes activation remain separately
  gated.
- Event-driven immediate steward wake-up is a later enhancement; v1 uses a
  quiet bounded cron over deterministic next-action state.
