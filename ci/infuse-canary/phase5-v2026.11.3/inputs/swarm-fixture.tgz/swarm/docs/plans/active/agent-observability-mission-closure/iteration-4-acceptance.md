---
title: Iteration 4 Opik Evaluation Acceptance
description: Acceptance evidence for the reviewed retrieval dataset, reproducible Opik experiments, deterministic agent runner, and degraded-candidate rejection.
type: evidence
status: active
owner: team:agent-platform
tags:
  - observability
  - evaluation
  - opik
  - acceptance
---

# Iteration 4 Opik Evaluation Acceptance

## Decision

Iteration 4 is accepted. The reviewed Fixture V2 retrieval dataset and two
deterministic baseline experiments are live in self-hosted Opik. The separate
agent-workflow runner is merged, its read-only Tinus baseline is recorded, and
a deliberately degraded replay is rejected. No production request was
harvested, no content sampling was enabled, and no OpenClaw or Codex artifact
was rebuilt.

Fito approved the exact admission in the accepted Mattermost mission thread
after the preview named dataset revision
`4bd8bf473802c1155627319b8ae641da3f2131d70c9bb4d3d3d2c48c2ef3170a`.

## Reviewed retrieval identity

| Field | Accepted value |
|---|---|
| Dataset | `kb-retrieval-baseline-v2` |
| Dataset revision | `4bd8bf473802c1155627319b8ae641da3f2131d70c9bb4d3d3d2c48c2ef3170a` |
| Experiment revision | `c26c6078a2cf70c89bbace4a971a4222b01e07d88c95b49c3696c32a018ca7a1` |
| Corpus | `library-atlas-v0`, Fixture V2, 75 reviewed cases |
| Retrieval profile | `embeddinggemma-85462619ee721b46-d768-s5baff9d0-postgres-fts-trgm-v2-rrf-v1` |
| Semantic fixture | `4d5a4972094e34bc5eb335fad399f23fdc7282155add844d1fbbcc22b3d6cd9a` |
| Dataset visibility/source | private / manual |

The private source artifacts were mode `0600`. Exact forbidden-key and
secret-shape scans passed before admission. The admission contains no
automatically harvested request, Fetch reference, full Markdown, credential,
prompt, model response, or chain-of-thought.

## Opik reproduction

Opik contains exactly one matching private dataset with 75 items. Every live
dataset-item identifier is UUIDv7. Both experiments contain exactly 75 items
and only SDK-sourced `critical_miss`, `recall_at_5`, and `reciprocal_rank`
scores.

| Experiment | Items | Recall@5 | MRR | Critical misses |
|---|---:|---:|---:|---:|
| lexical | 75 | 0.840000000 | 0.817349206 | 0 |
| hybrid | 75 | 0.800000000 | 0.749777777 | 0 |

The first live attempt failed closed before dataset creation because the
Knowledge Base namespace could not reach Opik. The approved loopback frontend
route then created the empty dataset but exposed an Opik 2.0.37 requirement:
dataset-item IDs must be UUIDv7. No item or experiment existed after that
failure. Knowledge Base PR 2557 added a deterministic UUIDv7 wire mapping while
preserving the reviewed dataset revision and content. The idempotent retry
returned dataset `409`, item upsert `204`, and both experiment uploads `204`.

## Agent-workflow suite

Swarm PR 2554 added `tools/agent-evals` with 12 sanitized read-only cases and
20 trials. It records exact image, runtime, skill-bundle, model, runner, suite,
candidate, and report revisions; stores no prompt, response, stdout, stderr,
traceparent, or external-delivery content; and keeps model-assisted grading
disabled.

The live Tinus baseline produced report revision
`ec6dbe47e930256c953721c16bafe749bf81d18b2c4eb0745ab02bd3bd42871e`:

- 12 cases and 20 trials;
- 7 cases passed and 5 were rejected by deterministic gates;
- the known `knowledge_retrieval` dynamic-tool presentation boundary was
  surfaced rather than hidden;
- cold-path/tool-budget variance was recorded for the remaining rejected
  cases; and
- the supported Gateway CLI cannot propagate W3C trace context, so the report
  states `trace_propagation=unsupported_by_gateway_cli` and
  `trace_correlation_claimed=false`.

The separate test-only degraded replay fails with final mismatch, missing
required tool, forbidden external-delivery tool, and tool-call budget blockers.
It exits nonzero and is not eligible for human review. Nothing was deployed for
that candidate.

## Delivery evidence

- Knowledge Base PR 2553 merged as `15a8314d37a70ef02861b22e9b564e570cca1670`.
- Swarm PR 2554 merged as `c02ae4f74d95968b99048831fa6de30e2fcbd706`.
- Knowledge Base compatibility PR 2557 merged as
  `24955bc9b6eb3caf7f5817818435926ef7f6dc8c`.
- PR builds 5917, 5916, and 5922 succeeded.
- Main builds 5918, 5921, and 5923 succeeded.
- Knowledge Base `20260829.5` runs immutable digest
  `sha256:9f39fe2a90e51bc3d412a670b60ded2b0d9f2b308a8a742fc8ea55bc18b347f3`;
  all four workloads are Ready with zero restarts.
- The five agents remain Ready with zero restarts on unchanged immutable digest
  `sha256:8a854483faad6916a77fdaa815e2648aa38f9d6975df3c3707c415731f23d3d3`.

During final verification, source revision
`560786ed2ca0ae6e6431ff61209c7931ced93437` added the role-scoped
`infuse-product-design` skill after the Iteration 4 runner merged. The runtime
catalog now classifies that source entry so catalog parity remains exact. It is
left absent from every persistent bundle in this acceptance change; any future
assignment to the designer remains a separate reviewed bundle decision.

## Iteration 5 handoff

Iteration 5 may use the immutable 75-case dataset and lexical experiment as
its accepted baseline. Each candidate must change one variable only and retain
the accepted privacy, provenance, latency, critical-miss, Recall@5, and MRR
gates. Candidate promotion remains a separate human decision after comparison
evidence.
