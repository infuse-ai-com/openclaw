---
title: Mattermost Interaction Callback Investigation
description: Persistent agents can connect to Mattermost and reply normally, but
  gateway logs warn that interaction callbacks resolve to a loopback URL:.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - mattermost
  - interactions
  - callback
---
# Mattermost Interaction Callback Investigation

## Problem

Persistent agents can connect to Mattermost and reply normally, but gateway logs
warn that interaction callbacks resolve to a loopback URL:

```text
http://localhost:18791/mattermost/interactions/default
```

Mattermost runs outside each agent pod. If a Mattermost button or interactive
action points at `localhost`, the Mattermost server will call itself, not the
agent gateway. Normal text replies are unaffected; native buttons and other
Mattermost interactions are the risky path.

## Current Network Shape

- Agent gateways listen on port `18791` with token auth and `--bind lan`.
- Each agent has a Tailscale-managed dashboard Service, for example
  `agent-developer-dashboard`, targeting gateway port `18791`.
- Dashboard hostnames such as `openclaw-developer.tailc4f8d5.ts.net` are meant
  for trusted tailnet users and OpenClaw Control, not necessarily for the
  Mattermost server.
- Mattermost base API access from agents uses the cluster-local URL
  `http://mattermost.infuseai.svc.cluster.local:8065`.

## Candidate Fixes

### Option A - Cluster-Local Callback URL Per Agent

Set each agent's `channels.mattermost.interactions.callbackBaseUrl` to a
Kubernetes Service DNS name that Mattermost can reach, for example:

```text
http://agent-developer-dashboard.agents-swarm.svc.cluster.local
```

This is the cleanest path if the Mattermost pod can reach `agents-swarm`
Services. It keeps callbacks private to the cluster and avoids sending action
callbacks through Tailscale.

Validation needed:

```bash
kubectl --context infuseai-k8s -n infuseai exec deploy/mattermost -- \
  curl -fsS http://agent-developer-dashboard.agents-swarm.svc.cluster.local/health
```

Use the real Mattermost namespace/deployment name. If Mattermost cannot resolve
or reach cross-namespace Services because of NetworkPolicy, add a narrow ingress
policy from Mattermost to only the agent dashboard Services on port `18791`.

### Option B - Tailnet Callback URL

Set callback URLs to the Tailscale MagicDNS dashboard hostnames, for example:

```text
http://openclaw-developer.tailc4f8d5.ts.net
```

This works only if the Mattermost server is itself on the tailnet and allowed by
Tailscale ACLs to reach those Services. It couples Mattermost actions to the
tailnet service exposure and should not be the first choice if cluster-local
routing works.

### Option C - Shared Callback Proxy

Run a small in-cluster callback proxy with a stable internal URL, such as:

```text
http://openclaw-interactions.agents-swarm.svc.cluster.local
```

The proxy would validate the Mattermost request, route by agent/channel/action
metadata to the correct gateway Service, and centralize NetworkPolicy. This is
heavier but may be best if OpenClaw needs one callback URL per Mattermost app or
if per-agent URLs are awkward to register.

## Recommendation

Investigate Option A first. It is private, simple, and maps naturally to the
existing per-agent dashboard Services. Do not change live config until a real
Mattermost-originated button action is tested end to end.

## Acceptance Criteria

- Mattermost can reach the chosen callback URL from its server pod.
- A harmless signed test button reaches the intended agent gateway.
- Normal Mattermost text replies remain threaded and unchanged.
- The callback URL does not expose gateway action endpoints publicly.
- NetworkPolicy allows only the minimum Mattermost-to-agent callback traffic.
- The chosen config is committed in each active agent's `OPENCLAW_CONFIG_JSON`
  and covered by verifier checks.
