---
title: Decisions
description: Durable decisions for the OpenClaw Kubernetes swarm repo.
type: decision
status: active
owner: team:agent-platform
tags:
  - decision
  - decisions
---
# Decisions

Durable decisions for the OpenClaw Kubernetes swarm repo.

## 2026-09-02 - Emon Owns Mission Delivery End To End

Decision: Emon is accountable for each activated mission from framing through
integration, PR creation, merge, deploy, verification, reconciliation, and
closeout. Kapiteky represents Fito's company direction, advises, challenges
drift, and improves the operating system; Kapiteky is not the routine executor
or merge/deploy backstop for Emon's missions.

Consequences:

- A capability or access gap remains Emon-owned until Emon routes the step to a
  capable approved worker or raises one precise blocker. It does not silently
  transfer work to Kapiteky.
- One project may have one execution-active mission; planned candidates do not
  consume that WIP slot.
- A bounded approved backlog batch may be one delivery-campaign mission. A
  portfolio review is a distinct, low-frequency, proposal-only activity.
- The v2 registry, Backoffice projection, scheduled steward candidate, event
  steward, and portfolio-review candidate encode the same contract.
- The existing v1 registry and steward remain live until a separately approved
  Phase 5 migration and scheduler cutover. Source availability is not
  activation.

This supersedes the 2026-05-27 temporary restriction that kept PR creation and
merge authority Kapiteky/Fito-governed.

## 2026-08-27 - OpenTelemetry Collector Is The Agent Telemetry Policy Boundary

Decision: persistent agents emit metadata-first OpenTelemetry to a collector in
`agents-swarm`. The collector is the only production fan-out and policy
boundary: Langfuse owns per-run trace inspection, Prometheus and Grafana own
fleet metrics, Loki owns sanitized operational failures, and Opik owns datasets
and evaluation experiments rather than a duplicate production trace stream.

Rationale:

- The team needs correlated evidence about skill, tool, knowledge, workflow,
  and wrapper behavior without making each agent aware of backend credentials.
- One collector provides a reviewable place for redaction, bounded resource
  attributes, batching, memory protection, sampling, and backend routing.
- Metadata-first production traces answer the initial operational questions
  without retaining prompts, responses, retrieved passages, command output, or
  hidden provider reasoning.

Consequences:

- Telemetry must fail open and may never change an agent action's result,
  retry, or exit semantics.
- Agent configuration keeps content capture disabled. Controlled evaluations
  may retain explicitly emitted summaries or plans only under a separately
  reviewed policy.
- Collector credentials use Kubernetes Secret references and never enter agent
  configuration, Git, logs, or trace attributes.
- Custom Infuse events follow the versioned contract under
  `config/observability/`; unapproved or high-cardinality metric labels fail
  repository verification.
- Skill changes remain normal human-reviewed source changes. Observability and
  evaluation evidence never mutate skill source automatically.

## 2026-08-27 - Skill IDs Have One Materialization Owner

Decision: every reviewed skill source declares either `managed-copy` or
`runtime-native` materialization. Company skills use distinct IDs and are copied
into agent workspaces; OpenClaw bundled and plugin skills retain their native IDs
and must never be shadowed by workspace copies.

Rationale:

- OpenClaw load-order precedence previously allowed company copies named
  `browser-automation`, `diagram-maker`, and `summarize` to replace different
  bundled or plugin capabilities without the binary matrix showing that fact.
- A skill is installed or absent, but installation mechanics differ: reviewed
  source copies need hashes and synchronization, while runtime-native skills
  need provenance, plugin, eligibility, and dependency evidence.
- Distinct IDs keep company and native capabilities independently reviewable.

Consequences:

- Company bundles use `playwright-browser-evidence`, `text-diagramming`, and
  `source-synthesis` for the existing assignments.
- Native `browser-automation`, `diagram-maker`, and `summarize` remain separate
  bundle decisions and start absent for every persistent agent.
- The installer removes runtime-native workspace shadows even during a
  company-source-scoped startup sync.
- Live runtime smoke verifies that managed copies resolve from
  `openclaw-workspace` and any installed native skill resolves from its declared
  OpenClaw source with required runtime dependencies present.

## 2026-08-03 - Vaultwarden Account Membership Authorizes Direct Lookup

Decision: remove the redundant Git bundle item/field allowlist from direct
Vaultwarden lookup. A persistent agent may retrieve any supported credential
field that its own Vaultwarden account can read through its assigned
organization and collection membership.

Rationale:

- Each persistent agent now has a dedicated Vaultwarden account whose
  membership already defines its intended credential boundary.
- The duplicate static list drifted from those account permissions and blocked
  legitimate task-time access before Vaultwarden was consulted.
- Vaultwarden remains the auditable source of truth for grants and revocation;
  collection removal takes effect without a bundle edit or pod restart.

Consequences:

- `openclaw-agent-secret-get` uses its fixed runtime bundle for caller identity,
  supported-field, and project-materialization validation, then delegates item
  authorization to Vaultwarden.
- Direct-lookup metadata and its item/field validation are removed from all
  persistent-agent bundles.
- Exact bundle allowlists remain for Kubernetes secret sync and project env
  materialization, because those paths create persistent credential copies.
- Direct account/collection assignment changes require Vaultwarden review and
  a smoke that does not print the retrieved value.

## 2026-05-31 - InfuseAI Is The Only Maintained Deployment Target

Decision: retire the old ncase, local/kind, and generic staging deployment
paths from the active repo surface. Keep `k8s/overlays/infuseai/` as the only
maintained Kubernetes deployment overlay.

Rationale:

- The swarm now runs from Azure DevOps into InfuseAI Kubernetes namespace
  `agents-swarm`.
- The ncase deployment proved the runtime shape, but keeping its runnable
  overlays and tasks creates operational noise and increases the chance an
  operator or agent follows an obsolete path.
- Local verification should render the active deployment path and agent overlays,
  not preserve every prototype environment.

Consequences:

- `task render` renders the InfuseAI overlay and active per-agent overlays only.
- Runtime status/smoke tasks default to `KUBE_CONTEXT=infuseai-k8s` and
  `NAMESPACE=agents-swarm`.
- ncase notes remain only as historical context in dated decision/bootstrap
  docs.

## 2026-05-28: Add Emon Lusk As The Swarm Coordinator

Decision: add `agent-coordinator` / Emon Lusk as a fourth persistent OpenClaw swarm agent.

Original rationale: Fito initially asked to replicate part of Kapiteky's coordination function into `openclaw-k8s-swarm`. The role has since been clarified by `company-docs`, `engineering-handbook`, and `agent-skills`: Fito owns company vision, external commitments, and final human judgment when he chooses to intervene; Kapiteky is the advisor/enabler/reviewer who improves Emon's skills, runtime setup, access, harnesses, memory, docs, and guardrails; Emon is the default product/engineering coordinator and scoped delivery executor for the Kubernetes swarm.

Updated rationale: a durable coordinator identity is appropriate because mission intake, task decomposition, one-agent handoffs, role-thread watch loops, PR/build/deploy evidence review, verification synthesis, and swarm follow-through benefit from persistent memory and an auditable Mattermost/Kubernetes identity.

Boundaries:

- Emon may coordinate assigned product/engineering work, create task briefs, inspect PR/build evidence, review outputs, make normal scoped delivery decisions, merge, deploy, and follow through.
- Emon must not change DNS/RBAC/permissions/secrets, expand access, run destructive actions, talk to external clients, make external/client-facing commitments, or use personal inbox/media/Vaultwarden context outside the bundle without explicit approval and a reviewed bundle update.
- Runtime access remains bundle-scoped through Kubernetes Secrets and isolated task workspaces.

## 2026-05-28 - InfuseAI Agents Swarm Target

Decision: move the next deployment target from ncase to InfuseAI Kubernetes namespace `agents-swarm`, with runtime images under Harbor project `agents-swarm`.

Rationale:

- ncase proved the runtime shape; the next risk is production-like delivery through Infuse AI infrastructure.
- A dedicated namespace and Harbor project make ownership, retention, and access review clearer than sharing the initial staging names.
- Azure CI can publish a unique image tag per build and roll that exact tag into Kubernetes.

Consequences:

- `Taskfile.yml` defaults now target `infuseai-k8s`, namespace `agents-swarm`, and Harbor project `agents-swarm`.
- `k8s/overlays/infuseai/` renders Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon together.
- The golden Infuse AI pipeline is reused for PR verify, BuildKit image push, and notifications, while deployment remains a repo-local Kustomize step because the generic Helm web-app chart does not model the three-agent swarm.

## 2026-05-28 - Vaultwarden Is The Agent Secrets Source Of Truth

Decision: Vaultwarden owns durable agent secret values. Git owns reviewable access intent, and Kubernetes owns runtime materialization only.

Rationale:

- Fito wants fast token rotation without secret drift across Kubernetes, Azure, local files, prompts, memory, and docs.
- Per-agent Vaultwarden scoping plus bundle-level item allowlists keeps blast radius small if one agent is compromised.
- Kubernetes Secrets are useful runtime delivery objects, but they should not become the canonical place where secret values are authored or remembered.
- Future hot reload is easier if new credential types prefer mounted files or provider lookups over env-only injection.

Consequences:

- `docs/SECRETS_ARCHITECTURE.md` records the target model and rotation flow.
- `config/agent-skill-bundles/<agent-id>.json` remains the reviewable source of truth for which Vaultwarden item each agent may receive.
- `scripts/sync-agent-credential.sh` must keep enforcing exact item and target allowlists before reading Vaultwarden or writing Kubernetes.
- Normal worker agents should not receive broad Vaultwarden login material.
- Env-backed secrets may still require restarting only the affected agent Deployment until the relevant OpenClaw/runtime consumer supports file reload or lazy reads.

## 2026-06-09 - Expand Agent Vaultwarden And Authentik Bootstrap

> Direct-lookup authorization in the consequences below was superseded by the
> 2026-08-03 account-authoritative decision. Bundle declarations remain in use
> for persistent sync and materialization only.

Decision: expand the direct-account Vaultwarden bootstrap from the original
Emon-only pilot to all persistent agents, and add per-agent Authentik runtime
credentials. Retire Emon's temporary MarkdownGPT dogfood Secret and `mdgpt`
operator RBAC.

Rationale:

- Fito approved using the company Vaultwarden `00-Super-Secret-Tokens`
  collection as the source for each agent's Vaultwarden API client/login and
  Authentik login material.
- All persistent agents need a consistent way to authenticate as their own
  lifecycle-managed identity without becoming copies of Kapiteky.
- The MarkdownGPT dogfood credential was temporary and should no longer be
  mounted into Emon's coordinator runtime.

Consequences:

- Runtime Secrets follow `<agent-id>-vaultwarden` and `<agent-id>-authentik`.
- Direct lookup was bundle-gated by exact item and field at the time of this
  decision; this was superseded on 2026-08-03.
- `agent-developer` also receives the approved Cursor OAuth bridge Secret for
  Cursor/ACPX engineering delegation.

## 2026-06-05 - Pilot Direct Vaultwarden Account For Emon

> The direct-lookup authorization model in this historical pilot was superseded
> by the 2026-08-03 account-authoritative decision.

Decision: pilot a direct Vaultwarden account for `agent-coordinator` only, backed
by Emon-specific Vaultwarden collections and Authentik lifecycle management.

Rationale:

- Fito does not want routine application-secret rotation to require restarting
  agent pods.
- Our self-hosted company endpoint is Vaultwarden Password Manager, not
  Bitwarden Secrets Manager; machine-account access tokens are not available in
  the current deployment.
- Authentik/OIDC is useful for lifecycle and identity, but Vaultwarden still
  needs vault decrypt/unlock material for headless runtime reads.
- An Emon-only pilot lets us validate direct lookup without expanding broad
  Vaultwarden material to the full swarm.

Consequences:

- `docs/AGENT_VAULTWARDEN_ACCESS_PLAN.md` records the Emon direct-account pilot.
- `docs/CREDENTIAL_ACCESS.md` marks Emon as the only approved direct-account
  pilot agent.
- Emon collections should be narrow and agent-specific.
- Direct lookup enforced both Vaultwarden collection access and Git bundle
  item/field allowlists during the pilot; this was superseded on 2026-08-03.
- Other agents remain on bundle-declared Kubernetes Secret or mounted-file
  delivery until the pilot passes smokes and review.

## 2026-05-25 - First Runtime Target Is ncase MicroK8s

Decision: use ncase MicroK8s namespace `openclaw-swarm-staging` as the first live deployment target.

Rationale:

- Full local permissions and fast iteration.
- Good fit for staging an agent runtime before InfuseAI Kubernetes hardening.
- Existing Harbor and homelab routing are already available.

Consequences:

- ncase-specific manifests lived under `k8s/overlays/ncase/` until that active path was retired.
- Runtime checks should default to `KUBE_CONTEXT=ncase-microk8s` unless explicitly overridden.
- Production assumptions must not leak into the ncase overlay.

## 2026-05-25 - Harbor Is The MVP Registry

Decision: push runtime images to Harbor project `openclaw-k8s-swarm`.

Rationale:

- Harbor already serves Infuse AI registry needs.
- It supports the home-cluster workflow without adding another registry.

Consequences:

- Task defaults use `registry.infuse-ai-tech.party/openclaw-k8s-swarm`.
- ncase overlay pins Harbor-hosted images.
- Harbor retention and auth hardening remain follow-up operational work.

## 2026-05-25 - Kubernetes Secrets For MVP Runtime Bootstrap

Decision: use Kubernetes Secrets for the first runtime bootstrap, with Vaultwarden as the source of truth where applicable.

Rationale:

- Simple and available immediately.
- Avoids committing secret material to the repo.
- Keeps later External Secrets/Vaultwarden integration open.

Consequences:

- Secret contracts are documented under `docs/secrets/`.
- Scripts may sync from Vaultwarden to Kubernetes, but must not print secret values.
- Long-term work should replace temporary credential bridges with scoped agent credentials.

## 2026-05-25 - First Persistent Agent Identity Is `agent-developer`

Decision: create `agent-developer` as the first persistent swarm identity.

Rationale:

- Release/QA checks are bounded, evidence-driven, and easy to review.
- Browser smokes, PVC checks, and rollout checks are useful immediately.

Consequences:

- `agent-developer` is scoped to `openclaw-swarm-dev`.
- It requires mention and allowlisted sender policy for group chat handling.
- It cannot merge, alter secrets, change production, or broaden access without approval.

## 2026-05-25 - Temporary Copied OAuth Is An MVP Bridge Only

Decision: Fito approved copying Kapiteky's OpenAI/Codex OAuth profile into the isolated `agent-developer` runtime for the first live reply test.

Rationale:

- It unblocked proof that the Kubernetes-hosted agent could answer.
- It kept the credential outside Git and inside runtime/Kubernetes state.

Consequences:

- This is not the desired long-term model.
- Replace it with a scoped `agent-developer` credential path before increasing autonomy.
- Do not commit auth stores, token JSON, browser cookies, or OAuth blobs.

## 2026-05-26 - Keep Kapiteky OAuth Bridge For Near-Term Agent Experiments

Decision: Fito approved keeping the temporary Kapiteky/OpenAI OAuth bridge for near-term swarm-agent work while we solve scoped model credentials later.

Rationale:

- It keeps iteration moving while the agent runtime topology and onboarding workflow are still being shaped.
- The bridge already works for the first deployed runtime.
- Credential design should be solved deliberately instead of blocking every structure improvement.

Consequences:

- Treat the bridge as accepted debt, not the target architecture.
- Do not broaden agent autonomy just because model auth works.
- Do not commit auth stores, token JSON, browser cookies, or OAuth blobs.
- Keep scoped per-agent model credentials in the backlog before broader or production-like agent access.

## 2026-05-25 - Taskfile Is The Canonical Automation Surface

Decision: use `Taskfile.yml` instead of `Makefile`.

Rationale:

- Fito prefers Task.
- Task gives discoverable commands with descriptions and simple variable overrides.

Consequences:

- New automation should be added to `Taskfile.yml`.
- Docs should use `task verify`, `task image-build`, and related commands.
- The OpenClaw runtime package version is set with `OPENCLAW_VERSION`.

## 2026-05-25 - Use `agent-designer` To Exercise Second-Agent Onboarding

Decision: use `agent-designer` as the worked example for the new-agent onboarding runbook.

Rationale:

- Design/UX review is bounded enough for a draft-only persistent identity.
- It exercises different needs from `agent-developer`: screenshots, visual QA, accessibility, product critique, and design-parity reports.
- It exposes whether the swarm can support specialized roles without copying Kapiteky.

Consequences:

- `docs/NEW_AGENT_RUNBOOK.md` uses `agent-designer` as the concrete example.
- `docs/agents/agent-designer.md` started as a proposed access bundle before activation.
- Superseded status: Fito later approved activation, and Stewie Hobs / `agent-designer` first went live on ncase with a scoped Mattermost token and runtime smoke coverage before the swarm moved to InfuseAI.

## 2026-05-26 - One Deployment Per Persistent Agent

Decision: each persistent agent should run as its own Kubernetes Deployment.

Rationale:

- Agent logs, rollouts, restarts, health, and resource limits stay isolated.
- Secret changes for one agent should not restart or affect unrelated agents.
- The deployment name can map directly to the agent identity, for example `deploy/agent-designer`.
- Offboarding becomes clearer: remove the bot token, secret, deployment, and PVC for that agent.

Consequences:

- Add a per-agent deployment template or overlay before activating `agent-designer`.
- Runtime/status/log helpers should accept `AGENT_ID` and map to the corresponding deployment.
- A shared supervisor may still be useful later, but it is not the default topology for persistent agents.

## 2026-05-26 - Generic Agent Onboarding Tooling

Decision: build generic onboarding tooling before making additional persistent agents routine.

Rationale:

- The `agent-designer` exercise showed that cloning `agent-developer` by hand would create drift.
- Access bundles, persona files, Mattermost secrets, and smoke checks should have one repeatable shape.
- Templates make review easier before any live bot or secret exists.

Consequences:

- Add a generic `bootstrap-agent-profile` path parameterized by `AGENT_ID`.
- Add a generic Vaultwarden-to-Kubernetes Mattermost secret sync path.
- Add access-bundle and persona templates.
- Add verification tasks for profile configuration and Mattermost mention/allowlist behavior.

## 2026-05-26 - Curated Skill Bundles Per Persistent Agent

Historical note: the three-state bundle shape below was superseded by the
2026-08-27 binary installed-skill decision.

Decision: manage skills through a reviewed catalog plus one bundle per persistent agent.

Rationale:

- Fito wants specialist agents with less junk context.
- Skills come from multiple places: OpenClaw core, Kapiteky workspace skills, Infuse AI shared agent skills, and personal skills.
- A persistent agent should not see credentials, infra, personal, or external-communication capabilities unless its role requires them.
- Catalog and bundle files are easier to review than implicit prompt context.

Consequences:

- `config/skill-catalog.json` records approved skill sources and skill metadata.
- `config/agent-skill-bundles/<agent-id>.json` records required, optional, and denied skills.
- `task verify-agent-skills` validates references and overlap before activation.
- Runtime installation uses approved bundle skills only. Required skills are installed by default; optional skills require explicit `INCLUDE_OPTIONAL_SKILLS=true`.

## 2026-05-26 - Shared Runtime Toolbox, Separate Access

Decision: install the common worker CLI toolbox in the shared `openclaw-agent` image, but keep repo checkout, Azure DevOps, Vaultwarden, and Kubernetes access as separate reviewed steps.

Rationale:

- All persistent agents need a baseline set of tools to run useful checks.
- Tool availability is not the same as permission to use company credentials or operational APIs.
- A shared image reduces drift across Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon.
- Separate access declarations keep review and offboarding manageable.

Consequences:

- The image includes Git, Task, kubectl, Helm, kustomize, Docker CLI only, Python/pip/uv plus common Python utility packages, ripgrep, fd, jq, yq, Node/npm/npx/pnpm/yarn, Ruby/gem/bundler, build/patch/archive/sync tools, Git LFS, shellcheck, Chromium, Vaultwarden/BW tooling, gog, ACPX/Cursor agent, and OpenClaw.
- Docker remains CLI-only unless a future task intentionally provides a remote builder or socket.
- Agent repo assignments and credentials must follow `docs/AGENT_WORKER_READINESS_PLAN.md` and bundle-level `credential_access`.
- Runtime smokes must prove tools are present without printing secrets.

## 2026-05-26 - Backoffice Should Become The Agent Command Center

Decision: Backoffice is the intended human-facing command center for agent inventory, status, access review, and eventually human-approved controls.

Rationale:

- Mattermost is good for conversation, but not for scanning fleet state or access posture.
- Kubernetes, Vaultwarden, Azure DevOps, and repo docs each own part of the truth.
- Fito and Kapiteky need a compact cockpit for live agents without exposing secret values.

Consequences:

- The first Backoffice slice should be read-only.
- It should show agent identity, Mattermost handle, Kubernetes readiness, skill bundle, credential access intent, and smoke status.
- It must not display token values, auth JSON, raw env vars, or private memory contents.
- Write controls such as smokes, repo sync, task dispatch, and temporary elevation come later through audited scripts.

## 2026-05-27 - Agent Repo Work Uses Per-Task Checkouts

Decision: persistent agents must use one isolated repo checkout per assigned task instead of editing a shared repo folder in their PVC.

Rationale:

- One agent may have multiple simultaneous tasks against the same repo.
- Kapiteky, Fito, or another agent may also be working in the same repo at the same time.
- Shared working folders caused mixed-scope PR and cleanup mistakes in earlier work.
- Per-task checkouts make branch, diff, verification, and cleanup boundaries explicit.

Consequences:

- Repo access intent lives in `config/agent-skill-bundles/<agent-id>.json` under `repo_access`.
- Editable checkouts live under `/workspace/tasks/<task-id>/repos/<repo-name>`.
- `/workspace/agents/<agent-id>` remains the stable persona/config/memory home, not the editable repo workspace.
- Optional bare mirror caches may live under `/workspace/repo-cache`, but task working trees stay separate.
- `scripts/agent-task-workspace.py` refuses denied repos and refuses to recreate an existing task workspace without explicit resume. With `repo_access.default_policy: "allow"`, the helper permits any non-denied repo name but still requires `--source-url` or `REPO_SOURCE_URL` for the actual checkout URL.
- Starting a task writes `/workspace/tasks/<task-id>/task-brief.md` plus a cross-agent `/workspace/tasks/task-registry.json` entry so Kapiteky can list active work without inspecting every repo checkout.
- Cleanup refuses dirty task workspaces unless the operator passes an explicit force flag.

## 2026-05-27 - Agent Azure Git Credentials Are Runtime-Only

Decision: persistent agents may receive scoped Azure DevOps Git tokens only through bundle-declared Kubernetes Secrets. The runtime image configures a `dev.azure.com`-only Git credential helper when `AZURE_DEVOPS_PAT` is present.

Rationale:

- Agents need to clone assigned repos into isolated task workspaces.
- They should not receive Vaultwarden login material.
- Git config should not persist token values into PVC-backed files.
- Repo access should stay reviewable in `credential_access` and `repo_access`.

Consequences:

- Each agent declares a separate Vaultwarden item and Kubernetes Secret target, for example `Azure DevOps / agent-infra repo token` -> `agent-infra-azure-devops/AZURE_DEVOPS_PAT`.
- Live checkout verification uses `task smoke-agent-repo-checkout`.
- Broader Azure DevOps automation, PR creation, and merge authority remain
  Kapiteky/Fito-governed until a separate reviewed change. **Superseded for
  Emon's approved mission scope by the 2026-09-02 end-to-end ownership
  decision above.**

## 2026-05-27 - Company Skills Sync From agent-skills

Decision: reusable company skills should be installed from the `infuse-ai/agent-skills` repository, with each runtime install recording the source commit.

Rationale:

- `agent-skills` is the source of truth for reusable company agent behavior.
- Persistent agents should not keep stale PVC copies after a skill changes.
- Kapiteky needs a visible, repeatable sync command before any automatic startup pull is added.
- Skill assignment still belongs in per-agent bundles, not in whatever happens to exist in the source repo.

Consequences:

- `config/skill-catalog.json` can mark Git-backed skill sources with a sync policy such as `origin/main`.
- `scripts/install-agent-skills.py` fast-forwards Git-backed sources before copying skills unless `SKILL_SOURCE_SYNC=none` is set.
- Git-backed source caches are passed to the installer with `SKILL_SOURCE_CACHE_ROOT`; the startup wrapper owns the swarm `/workspace/agents/<agent-id>/skill-sources` convention.
- Runtime installs write `skill-bundle-manifest.json` with source branch and commit metadata.
- `task sync-agent-skills-runtime` refreshes approved skills for one live InfuseAI agent without reinstalling persona files.
- Startup sync is enabled for persistent agents. The container clones or fast-forwards the Git-backed `infuse-ai-agent-skills` source into the agent PVC and refreshes only approved skills from that source before OpenClaw starts.
- Host-local and plugin-provided skills remain managed by bootstrap/manual sync because their source paths are not reliably available inside the runtime image.

## 2026-06-20 - Persona Source Split From Runtime Image

Decision: persistent agent persona templates should be sourced from
`Infuse AI / openclaw-agents-persona`, with the image-bundled templates kept as
a fallback.

Rationale:

- Live agent improvements to `AGENTS.md` and `SOUL.md` were lost when a pod
  restarted from stale runtime templates.
- Persona behavior changes should not require a full image rebuild when the
  runtime sync helper is already available.
- Persona wording must stay separate from executable skills and runtime grants.
- `company-docs` now records the broader source-of-truth split for personas,
  memories, skills, and runtime grants.

Consequences:

- `scripts/sync-agent-persona-startup.sh` clones or fast-forwards
  `openclaw-agents-persona`.
- `OPENCLAW_PERSONA_SYNC=true` makes the entrypoint prefer external persona
  templates from `/workspace/openclaw-agents-persona/templates/agent-persona`.
- `OPENCLAW_PERSONA_REQUIRED=true` can later make stale/missing persona source a
  startup blocker; the current default falls back to image-bundled templates.
- `openclaw-k8s-swarm` still owns deployed grants, Kubernetes identity, and
  startup wiring.

## 2026-06-21 - Scoped Shared Memory Runtime Checkout

Decision: persistent agents should sync `openclaw-agents-memory` with a scoped
sparse checkout by default instead of materializing every agent's raw memory.

Rationale:

- The source repo intentionally keeps persona, memory, skills, and runtime
  grants separate, but raw memory still needs a practical runtime visibility
  boundary.
- Agents should always see curated shared and project context, plus their own
  durable memory.
- Cross-agent handoff summaries are useful default context; other agents' raw
  daily notes and `MEMORY.md` files are not.
- Sparse checkout is lighter than per-visibility-class repos or separate volume
  mounts, while giving a real filesystem boundary instead of relying only on
  prompt policy.

Consequences:

- `scripts/sync-shared-agent-memory-startup.sh` now applies a non-cone sparse
  checkout when `OPENCLAW_SHARED_MEMORY_SPARSE_CHECKOUT=true`.
- The default checkout includes repo docs/scripts, `shared/`, `projects/`, the
  current agent's own `agents/<agent-id>/` tree, and
  `agents/*/summaries/`.
- The default checkout excludes other agents' raw `MEMORY.md` and `memory/`
  daily notes.
- `OPENCLAW_SHARED_MEMORY_INCLUDE_AGENT_SUMMARIES=false` can disable
  cross-agent summaries if a role needs a narrower view.
- A future retrieval API can still replace direct filesystem access if memory
  policy needs stronger dynamic enforcement.

## 2026-06-21 - Local Agent Draft Sync Loop

Decision: persistent-agent local edits should be surfaced as draft drift or
controlled memory exports, not silently treated as source-of-truth changes.
This decision is partially superseded by the 2026-06-26 zero-token raw sync
decision for daily memory and profile Markdown.

Rationale:

- Agents can improve their local persona files, copied skills, or daily memory
  while working, but pod-local state is fragile across restarts.
- Persona and skill changes need review because they affect behavior and
  capabilities.
- Own raw daily memory is lower risk and can be synced through the agent's scoped
  memory path.
- Operators need to answer "what changed locally?" without printing private file
  contents into logs or chat.

Consequences:

- Persona installs write `persona-install-manifest.json` with rendered file
  hashes.
- Skill installs record copied file hashes in skill manifests.
- `scripts/agent-local-drift-report.py` reports persona, skill, and local daily
  memory drift without printing file contents.
- `scripts/export-agent-daily-memory.sh` exports one agent's local daily memory
  into `openclaw-agents-memory` and supports explicit commit/push switches.
- Historical note: direct automated pushes were originally kept off by default,
  then allowed on 2026-06-26 only under the syncing agent's own
  `openclaw-agents-memory/agents/<agent-id>/` path. The protected-branch
  decision below supersedes that transport without changing path ownership.
- `docs/AGENT_DRAFT_SYNC.md` records the operator runbooks and first dogfood
  result: `agent-designer` had one real unsynced daily-memory file, the
  stage-only export staged exactly that path, and cleanup returned the memory
  checkout to clean without committing or pushing.

## 2026-06-21 - Per-Agent Persona Folders

Decision: existing persistent agents should use canonical rendered persona
folders in `openclaw-agents-persona/agents/<agent-id>/`; the generic template
pack remains only for scaffolding new agents or fallback.

Rationale:

- Live PVC persona diffs should compare against the exact source for that
  agent, not against a generic template with placeholders.
- Existing agents need room for role-specific wording without making every
  persona change look like a template-wide behavior change.
- Template updates should not silently change live agents; applying them to
  existing agents should be an explicit review step.

Consequences:

- Startup persona install now prefers `agents/<agent-id>/` from the synced
  persona repo and falls back to `templates/agent-persona`.

## 2026-06-26 - Zero-Token Deterministic Agent Memory Sync

Decision: daily agent memory continuity should be a deterministic raw sync, not
an LLM-curated promotion workflow.

Rationale:

- Fito wants this layer to consume zero model tokens.
- Each agent is responsible for curating its own local memory before it is
  synced.
- The curated/project/shared memory layer is deferred until the operating model
  is clearer.
- Success messages, Azure PRs, and LLM-generated summaries add cost and process
  to a workflow that should be boring infrastructure.

Consequences:

- `scripts/sync-agent-memory-repo.sh` copies one agent's own daily memory files,
  root `MEMORY.md`, and key workspace Markdown files into
  `openclaw-agents-memory/agents/<agent-id>/`.
- `scripts/sync-agent-memory-repo-collector.sh` runs that helper across running
  persistent-agent pods.
- `k8s/overlays/infuseai/agent-memory-sync.yaml` adds the
  `openclaw-agent-memory-sync` CronJob at 04:00 Europe/Madrid.
- The sync renders root `MEMORY.md` with deterministic IKF metadata and runs
  the memory repository's complete knowledge-format validator before commit or
  push. Invalid selected content blocks the direct sync.
- The sync still commits directly to `openclaw-agents-memory/main` under the
  agent's own path and does not summarize, open PRs, or post Mattermost success
  messages.
- `persona-install-manifest.json` records `source_kind`, `source_dir`, and Git
  source metadata when available.
- The drift reporter surfaces that source metadata so operators can promote PVC
  persona edits back to the matching per-agent folder.
- `scripts/verify-agent-persona-source.sh` covers per-agent source install,
  memory preservation, manifest metadata, and drift reporting.

The direct-push consequence above was superseded on 2026-08-27 after Azure
repository policy began rejecting writes to `main`.

## 2026-08-27 - Protected-Branch Agent Memory Sync

Decision: preserve the deterministic, zero-token memory workflow while routing
every non-empty sync through a unique Azure PR.

Rationale:

- `openclaw-agents-memory/main` is protected and rejects direct pushes.
- The former helper committed before pushing, so a rejected push left PVC
  checkouts ahead or dirty and made later startup/sync runs fail closed.
- Empty daily-note placeholders carry no durable context and should not create
  archive drift.

Consequences:

- Each agent starts from current `origin/main`, stages only its own profile and
  memory paths, runs the complete IKF gate, and commits on a unique sync branch.
- The runtime PR helper reads the existing agent-scoped Azure credential from
  its environment, creates and squash-completes the PR, deletes the remote
  source branch, and waits for completion.
- The local shared-memory checkout returns to clean `main` after success. If PR
  creation or completion fails, the pushed remote branch is preserved for
  recovery while the checkout is restored to `main`.
- Empty local `memory/*.md` files are skipped.

## 2026-07-16 - OpenAI-Only Coding-Agent Routes

Decision: new swarm coding work routes through Codex, ChatGPT, or other
explicitly OpenAI-backed runtimes. ACPX may remain only as transport for an
OpenAI/Codex agent; legacy provider aliases and Cursor OAuth wiring are retired.

Rationale:

- The active operating model is intentionally focused on OpenAI-backed agents.
- Provider-specific aliases and credentials that are no longer used expand the
  runtime image, secret surface, and failure modes without adding capability.
- Transport names such as ACPX do not identify a model provider, so their
  configured agents must be validated rather than rejected by name alone.

Consequences:

- Coordinator and developer ACPX configuration defaults to Codex and exposes no
  Cursor, Claude, Qwen, Gemini, or OpenCode aliases.
- The shared agent image no longer installs `cursor-agent`, and the entrypoint
  no longer materializes or exports Cursor OAuth credentials.
- Model-policy verification rejects legacy aliases, command specs, runtime
  installation markers, and reintroduction of the retired Cursor sync helper.
- Cursor OAuth Kubernetes secrets can be deleted after the updated workloads
  have rolled out successfully. Historical certification evidence may retain
  references that accurately describe earlier runtime state.

## 2026-08-07 - Skill-Owned Document Normalizer Client

Decision: `agent-skills/skills/document-normalizer/` is the canonical source
for the hardened Document Normalizer client. This runtime repo owns only a thin
launcher, skill synchronization, bundle grants, service URL, and credential
injection.

Rationale:

- The client is reusable agent workflow code, not Kubernetes implementation.
- Keeping the full HTTP client in this repo duplicated the ownership already
  declared by the `document-normalizer` skill and coupled behavior changes to
  an agent image rebuild.
- Startup skill sync completes before OpenClaw starts, so the launcher can
  resolve the reviewed client from the installed skill tree.

Consequences:

- `/usr/local/bin/openclaw-document-normalizer` fails closed when the workspace
  or canonical skill client is unavailable.
- Client behavior and tests move to `agent-skills`; this repo tests launcher and
  runtime-install wiring only.
- The service API and fallback contract remain owned by the
  `document-normalizer` service repository.

## 2026-08-25 - Pinned Internal OpenClaw Runtime Baseline

Decision: promote the verified Mattermost separate-progress runtime from a
branch canary into the `main` deployment baseline for all five persistent
agents, while keeping OpenClaw upstream convergence explicit and manual.

Rationale:

- The separate progress/final lifecycle is wanted operationally before the
  upstream pull request merges.
- Exact-head human canary evidence proved successful and recovered-failure
  lifecycles without stale progress, duplicate finals, or recreated failures.
- All agent PVCs have completed forward-only OpenClaw 2026.8 migrations, so
  restoring the older stable image is unsafe.

Consequences:

- Azure and Task builds pin OpenClaw source `3d1a6e4197b2bcce4b90cd3fc5b6de8a5b1f24c0`,
  exact checksum-verified core/Mattermost/ACPX artifacts, and official Codex
  `2026.8.1-beta.3`.
- `main` deploys one baseline to all five agents; no single deployment is
  preserved on an older runtime lane.
- Upgrades require a branch, exact artifact review, repository verification,
  an isolated image build, a real agent turn, and fleet canary evidence before
  promotion.
- The known-good rollback floor is r20 digest
  `sha256:94a7e87362f5f5c2c8f67ddfd713f854c2f4ccba19fceb1ef25fd98af690b8e9`.
  Rollback preserves PVCs and must not downgrade the state database.

## 2026-08-27 - Binary Installed Skill Bundles

Decision: replace `required`, `optional`, and `denied` skill lists with one
binary `skills.installed` list for every persistent agent.

Rationale:

- Runtime behavior is binary: a skill directory is installed or absent.
- The optional state implied task-time availability that the runtime did not
  reliably materialize.
- Absence is easier to review than a parallel denied inventory and cannot drift
  into an accidental grant.

Consequences:

- Bundle validation rejects any skill key other than `installed` and requires
  dependency closure inside that list.
- Installer, bootstrap, deployment configuration, runtime smoke tests, and
  operator docs all consume the same installed list.
- A task cannot elevate an absent skill through prompt or persona text. Adding
  one requires a reviewed bundle change and runtime refresh.
- Credential and repository policies remain separately explicit and
  default-deny; this decision changes skill installation only.

## 2026-08-27 - Disable Recurring Agent Heartbeats

Decision: disable the 30-minute recurring heartbeat cadence for all five
persistent agents and exclude system-owned `heartbeat-*` rows from the
Backoffice Ritual Calendar.

Rationale:

- The live heartbeat jobs were periodic wake requests rather than Kubernetes
  health checks, memory dreaming, or durable task queues.
- Role monitors instructed agents to act only on concrete assigned work, which
  is already represented by explicit sessions, TaskFlow, and purpose-built
  cron jobs.
- Idle heartbeat model turns can consume full-context model capacity while
  producing no operator-visible outcome.
- Runtime implementation details do not belong beside business and team
  schedules in the Ritual Calendar.

Consequences:

- `agents.defaults.heartbeat.every` is `0m` in every active deployment config;
  model-policy verification rejects a reintroduced recurring cadence.
- Event-driven wake requests remain available for task completion and other
  targeted runtime events.
- Kubernetes probes continue to own workload liveness and readiness.
- The cron calendar exporter counts heartbeats in
  `excludedInternalMaintenanceCount` but never emits them as events.

## 2026-08-30 - Exact-revision Mission Control deletion worker

Status: superseded on 2026-09-01 by the clean-start Artifact Registry cutover.
The worker, its activation flag, and its filesystem authority no longer exist.

Decision: keep Backoffice as the lifecycle control plane and execute permanent
artifact deletion through one dedicated swarm CronJob with scoped pod-read/exec
RBAC. The worker accepts only authenticated jobs for an exact deterministic
content revision.

Rationale:

- Backoffice can own product authorization, shared-bin state, confirmation,
  leases, and audit without receiving broad Kubernetes or filesystem writes.
- Source pods and the private Kapiteky relay remain the authoritative writers;
  deleting there prevents the minute collector from republishing removed data.
- Exact revision validation prevents a stale UI action from deleting newer
  content, while one job per item allows Empty Bin to complete partially.

Consequences:

- The worker rejects malformed identities, path traversal, symlinks,
  unexpected artifact entries, revision drift, and zero/multiple Ready pods.
- Artifacts keep tombstoned identities indefinitely; journals may surface a
  fresh post-deletion revision under the same journal identity.
- Backoffice and the worker share a server-only token from
  `core/secret/backoffice-runtime`; neither repository contains its value.
- Deployment requires explicit secret provisioning and reviewed RBAC. Local
  verification never performs a live permanent deletion.
- Repository merges are safe by default: the deployment script skips the
  lifecycle CronJob and RBAC unless `MISSION_CONTROL_LIFECYCLE_ENABLED=true` is
  supplied during a separately approved activation.

## 2026-09-01 - Clean-start Artifact Registry producer cutover

Decision: switch Kapiteky and all five persistent Kubernetes producers directly
to authenticated Registry publication without importing, backing up, or
preserving the legacy filesystem artifact corpus. Fito explicitly accepted loss
of the current artifacts. Preserve agent workspace PVCs; only their legacy
Mission Control artifact trees are disposable.

Rationale:

- The current artifacts are not valuable enough to justify a migration and
  backup ceremony.
- The canonical service, revision, trust, denial, persistence, and lifecycle
  behavior already passed the isolated T5.1 acceptance matrix.
- A clean start removes dual-authority and parity complexity while retaining
  producer isolation and exact immutable handoffs.

Consequences:

- `ARTIFACT_PUBLISH_MODE=registry` is the reviewed runtime mode for all five
  Kubernetes agents; the local Mission Control tree becomes staging/cache only.
- Backoffice receives separate durable read-only and lifecycle-only identities
  from the Backoffice Vaultwarden collection through one mounted token-file
  Secret. Producer credentials are never reused for Backoffice lifecycle.
- Fresh publications from every producer replace migration parity as the
  acceptance gate before Backoffice read/lifecycle cutover.
- Legacy collector, relay, source-deletion worker, pod-exec RBAC, feed mount,
  central feed PVC, relay PVC, and old per-agent artifact trees are retired only
  after fresh Registry publication and Backoffice lifecycle proof.
- The Registry remains a single RWO hostpath replica without an accepted
  backup. Loss of its PVC can lose all canonical artifacts; Fito accepted that
  risk for this cutover.

## 2026-09-03 - Proposal-first local skill governance

Decision: preserve proactive agent-authored skill drafts, but never activate
or adopt them directly from a runtime PVC. Move unmanaged local skill
directories into a recoverable, non-discovered proposal tree and alert the
`ai-lab/agent-skills` review channel with content-free metadata.

Rationale:

- Proactive discovery is valuable, while self-granted behavior bypasses source
  review, bundle scoping, and role/accountability boundaries.
- Automatically pushing full draft content would give every agent repository
  write authority and could publish unreviewed or sensitive material.
- Existing pod list/exec access and each agent's own PVC are sufficient for a
  deterministic monitor, so no new Kubernetes RBAC or credential mount is
  required.

Consequences:

- Runtime startup and a 15-minute zero-model collector quarantine unmanaged
  skill directories under `skill-proposals/<skill-id>/<digest>/skill/`.
- Successful Mattermost delivery writes a per-proposal marker, preventing
  repeat alerts for the same content digest; failed delivery remains retryable.
- Alerts include only agent ID, skill ID, digest, detection time, proposal
  path, and the review queue. Skill file contents never leave the PVC through
  the monitor.
- Review chooses promote, consolidate, or retire. Only merged source plus an
  explicit reviewed bundle grant can reactivate behavior.

## 2026-09-22 - Lifecycle-safe sequential persistent-agent rollouts

Decision: replace fleet-wide scale-to-zero/apply/restore deployment with a
Gateway-aware, one-agent-at-a-time state machine. Persistent-agent Deployments
use `Recreate`, a 420-second termination grace period, readiness and liveness
probes, and a lifecycle `preStop` drain.

Rationale:

- Each agent has a single ReadWriteOnce workspace containing live OpenClaw
  state; concurrent predecessors and replacements must never write it.
- Ordinary Kubernetes termination cannot prove active Gateway work has drained
  or arrange the exact predecessor handoff required for interrupted work.
- A fleet-wide stop turns one bad image or migration into a five-agent outage
  and removes the healthy peers needed for diagnosis.

Consequences:

- Stable rollout order is developer, designer, infra, intake, coordinator.
- The controller prepares and renews a Gateway suspension lease, stops exactly
  one pod, applies that Deployment held at zero, starts it, and verifies a new
  process identity, readiness, startup evidence, and immutable image identity
  before advancing.
- Normal drain timeout resumes the predecessor and fails closed. Forced
  handoff requires explicit `ALLOW_FORCED_GATEWAY_HANDOFF=true` authorization.
- This timeout policy is historical and is superseded by the 2026-09-26
  bounded-handoff decision below.
- Failure before replacement start restores the prior Deployment revision and
  replica count. Once replacement start is requested, automation never silently
  downgrades; it leaves that revision available for diagnosis and stops the
  remaining fleet rollout.
- Canary/fleet promotion first classifies persistent-state risk. Fresh,
  independently stored, fully extracted and integrity-checked workspace
  recovery artifacts are required when storage layout, data or database
  schemas, state ownership or permissions, migration or deletion behavior, or
  rollback compatibility can change. Routine image, code, or configuration
  releases that keep persistent state backward-compatible rely on lifecycle
  drain and immutable previous-image rollback without a fresh full-PVC backup.
- Recovery artifacts retain runtime state, repositories, Git metadata, and
  uncommitted files while explicitly omitting directory trees named
  `node_modules`; those dependencies are reproducible from retained manifests
  and lockfiles, and the exclusion is recorded in artifact metadata.

## 2026-09-26 - Bounded Gateway handoff and component-scoped delivery

Decision: supersede the rollout timeout policy above with a bounded CI default
and an explicit fail-closed drain mode. Every controller-led stop requires an
exact-predecessor Gateway handoff before the main container exits.

Rationale:

- A ready suspension alone did not affect the Gateway SIGTERM path. Each idle
  predecessor entered a second generic drain and survived until Kubernetes
  exhausted the 420-second grace period.
- The first live canary proved an armed Gateway exits cleanly in 79 ms, but it
  also proved that arming before scaling can leave a legacy `preStop` exec with
  no main container and make the pod consume the entire grace period.
- Waiting for active model/tool work is a release-policy choice. Waiting for
  terminal persistence and preserving the single-writer PVC boundary are
  mandatory safety invariants.
- The shared image contains both persistent-agent and SQL mission platform
  executables, so an image digest change does not by itself prove that every
  persistent agent needs replacement.

Consequences:

- `bounded` is the stable CI default: wait up to 30 seconds; active work may be
  interrupted after the budget.
- `drain` is opt-in: wait up to 300 seconds and resume/fail closed on timeout.
- `preStop` upgrades a valid controller-prepared `ready` lease to `armed`, so an
  interrupted controller cannot reintroduce an unprepared SIGTERM path.
- Controller-led rollouts arm every predecessor while it is still executable
  and send the known-safe 15-second grace in the initial pod delete request.
  Production build 8481 proved this is required for current helpers too:
  OpenClaw closed admission but handled SIGTERM as a restart and otherwise kept
  PID 1 alive under the 420-second Kubernetes ceiling. Attempting to shorten an
  already-started termination is not accepted as a bounded mechanism.
- Pod deletion has a hard 30-second controller SLO and recovery is requested
  asynchronously on failure. The 420-second Kubernetes grace remains an
  emergency ceiling for uncoordinated termination.
- Stable delivery records the Swarm source commit on agent pod templates and
  computes impact from the live fleet revision. SQL-platform-only changes
  preserve all persistent-agent templates; absent or mixed provenance forces a
  full sequential rollout.
- Successful Mattermost notification runs inside the deploy job. The separate
  notification job remains only for failure or cancellation recovery.

## 2026-09-26 - Canary-wave fleet rollout and startup fast path

Decision: keep the developer canary and coordinator-last promotion boundaries,
but advance designer, infra, and intake as one bounded parallel batch. Remove
role-stagger startup sleeps and skip recursive workspace ownership repair when
the PVC root is already owned by the runtime identity. This supersedes only the
inter-agent sequential-order consequence of the lifecycle decisions above;
their per-agent safety and recovery contracts remain active.

Rationale:

- The first bounded-handoff production rollout spent about 197 seconds in
  recursive ownership init and 150 seconds in artificial startup delays.
- Designer, infra, and intake have independent Deployments and independent RWO
  PVCs. Their single-writer safety is enforced inside each rollout controller,
  so serializing those three healthy replacements added latency without
  strengthening their per-PVC invariant.
- Developer remains the immutable-image canary, and coordinator remains last,
  preserving the two meaningful blast-radius gates.

Consequences:

- Stable delivery defaults to `canary-wave`: developer alone, the three leaf
  agents concurrently, then coordinator only after all leaf rollouts pass.
- A failed leaf does not cancel peers already in flight; the batch waits for
  them to settle and then blocks coordinator. The prior behavior remains
  available with `OPENCLAW_FLEET_ROLLOUT_STRATEGY=sequential`.
- Every agent retains its own Gateway drain, exact predecessor handoff,
  single-writer stop/apply/start sequence, readiness, new process identity,
  immutable digest/source, startup, and skill-parity checks.
- Kubernetes uses `fsGroupChangePolicy: OnRootMismatch`. The init container
  performs recursive `chown` only when `/workspace` root ownership differs
  from `10001:10001`; fresh or stale-root volumes still receive the full repair.
  Recovery artifacts with mixed descendant ownership under a correct root must
  be normalized as part of recovery.
- Artificial startup delays are zero because rollout orchestration now owns
  fleet concurrency explicitly.

## 2026-10-06 - Qualify Bitwarden CLI against cached-session sync

Decision: pin the agent image to Bitwarden CLI `2026.4.1` and require the
canonical runtime smoke to run `bw-local-vaultwarden sync` through the persisted
session when Vaultwarden is configured.

Rationale:

- `2026.9.0` and `2026.9.1` fail the deployed Vaultwarden cached-session path
  with `Invalid time value`; `2026.4.1` succeeds against the same disposable
  profile copy.
- A package version check proves installation only and did not catch this
  compatibility regression.

Consequences:

- A future CLI bump must pass image construction plus the live cached-session
  runtime smoke before fleet promotion.
- No credential rotation, cache replacement, or access expansion is part of
  this compatibility repair.

## 2026-10-22 - Requalify Bitwarden CLI 2026.10.0

Decision: advance the agent image and operator fallback to Bitwarden CLI
`2026.10.0`, retaining the identity-encoding transport shim and the live
cached-session runtime smoke as promotion gates.

Rationale:

- Vaultwarden 1.37.4 removes `bw send receive` compatibility for CLI 2026.4.2
  and older, so the prior 2026.4.1 pin is no longer a complete client contract.
- The operator profile successfully unlocked and synchronized through both the
  native 2026.10.0 CLI and the pinned Docker fallback against production
  Vaultwarden 1.37.4.
- Newer CLI name lookup can treat partial matches as ambiguous. Runtime secret
  lookup now resolves exactly one item name to its ID before reading the
  approved field and fails closed on zero or duplicate exact matches.

Consequences:

- Docker fallback caches are version-checked and replaced when their reviewed
  `OPENCLAW_BW_CLI_VERSION` changes; a moving npm tag is not reused silently.
- Production fleet promotion still requires the built-image version check and
  persisted-session `bw-local-vaultwarden sync` smoke.
- The first 2026.10.0 fleet rollout proved the operator profile alone was not
  representative: agent PVCs retained pre-1.37 Vaultwarden policy cache rows
  whose missing dates trigger `Invalid time value` in newer clients. Startup
  now removes only those two derived cache keys atomically, records a one-time
  marker, and re-unlocks a locked profile even when a stale session file exists.
- No Vaultwarden item, account, collection, or credential value changes as part
  of this client upgrade.

## 2026-10-06 - Policy-enforced exact source reads

Decision: persistent agents retrieve an assigned repository file at a full
commit through `openclaw-agent-task-workspace read-source`. The helper applies
the bundle allow/deny policy before invoking Git, refuses credential-bearing
URLs, writes only inside the current agent workspace without overwriting, and
reports the commit, Git blob, byte count, and SHA-256 without printing content.

Rationale:

- Scoped Azure credentials can authorize more repositories than an individual
  agent bundle. Raw Git therefore cannot prove the bundle's denial contract.
- Missions need exact source bytes without relying on an operator to paste a
  file or requiring a full writable task checkout.

Consequences:

- Approved reads are independently hash-verifiable and leave the existing task
  workspace lifecycle unchanged.
- Bundle-denied repositories fail before a Git process or network request is
  started.
- Raw Git remains an implementation detail, not the accepted source-read
  interface for agent verification evidence.
