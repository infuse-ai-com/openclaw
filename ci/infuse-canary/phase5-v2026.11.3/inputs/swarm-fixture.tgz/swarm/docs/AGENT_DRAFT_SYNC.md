---
title: Agent Draft Sync
description: Persistent agent pods have durable PVCs. That is useful for
  continuity, but it also means agents can accumulate local edits that are not
  yet in the source repos. Treat those local edits as drafts until they have
  been reviewed and promoted.
type: guide
status: draft
owner: team:agent-platform
tags:
  - guide
  - agent
  - draft
  - sync
---
# Agent Draft Sync

Persistent agent pods have durable PVCs. That is useful for continuity, but it
also means agents can accumulate local edits that are not yet in the source
repos. Treat those local edits as drafts until they have been reviewed and
promoted.

This document covers the v1 draft-sync model:

- detect local drift without printing file contents;
- sync an agent's own daily memory and key Markdown files into the checked-out
  `openclaw-agents-memory` repo;
- keep persona, skill, shared memory, project memory, and runtime grant changes
  out of the daily raw sync unless they are copied as local profile snapshots.

## Source Of Truth

Use these repos as the durable sources:

- `openclaw-k8s-swarm`: runtime image, Kubernetes manifests, startup sync,
  grants, and operator tooling.
- `openclaw-agents-persona`: canonical per-agent persona folders plus templates
  used to scaffold new agents.
- `agent-skills`: reusable reviewed skill implementations.
- `openclaw-agents-memory`: own-agent daily memory, shared memory, project
  memory, and cross-agent summaries.
- `company-docs`: company operating model and policy context.

Local pod state is operational evidence. It can be useful, but it is not the
source of truth by itself.

## Live Drift Summary

Use this when checking whether any active agent has local persona, skill, or
daily-memory drift:

```bash
for pod in $(kubectl --context infuseai-k8s -n agents-swarm get pods --no-headers \
  | awk '$1 ~ /^agent-/ && $3 == "Running" {print $1}' | sort); do
  echo "== $pod =="
  kubectl --context infuseai-k8s -n agents-swarm exec "$pod" -- sh -lc '
    openclaw-agent-local-drift-report | jq -r "
      [
        .agent_id,
        (.persona.dirty|tostring),
        ([.skills.manifests[]?.dirty] | map(tostring) | join(\",\")),
        (.memory.dirty|tostring),
        (.memory.unsynced|length|tostring),
        (.memory.changed|length|tostring)
      ] | @tsv"
  '
done
```

Column order:

- agent id;
- persona dirty;
- skill manifest dirty flags, usually `false,null` where `null` means a legacy
  bundle manifest without file hashes;
- memory dirty;
- unsynced local daily-memory file count;
- changed local daily-memory file count.

On 2026-06-21 the v1 dogfood check returned:

```text
agent-designer   false   false,null   true    1   0
agent-developer  false   false,null   false   0   0
agent-infra      false   false,null   false   0   0
agent-intake     false   false,null   false   0   0
```

That meant the only real live draft was one unsynced `agent-designer` daily
memory file.

## Inspect One Agent

Use the full report when the summary shows drift:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec deploy/agent-designer -c agent -- \
  openclaw-agent-local-drift-report --pretty
```

The report prints paths and status only. It does not print file contents.

Interpretation:

- `.persona.status == "ok"` and `.persona.dirty == false`: installed persona
  files still match `persona-install-manifest.json`.
- `.persona.source_kind == "agent"`: installed persona came from
  `openclaw-agents-persona/agents/<agent-id>/`.
- `.persona.source_kind == "template"`: installed persona came from the generic
  template fallback.
- `.skills.manifests[].dirty == false`: copied skills still match recorded file
  hashes.
- `.skills.manifests[].status == "superseded"`: a newer source-scoped sync
  replaced every skill owned by the historical manifest; its old hashes are
  retained as provenance and are not current drift evidence.
- `.skills.manifests[].dirty == null` with `missing_file_hashes`: old manifest
  format is visible but not considered dirty.
- `.skills.unmanaged_directories[]`: a materialized skill directory is not
  owned by any current authoritative manifest. The runtime allowlist may still
  filter it, but the proposal monitor moves it out of active discovery into
  `skill-proposals/<skill-id>/<digest>/skill/` for review.
- `.skills.dirty == true`: at least one authoritative skill differs from its
  hashes or an unmanaged skill directory exists.
- `.memory.unsynced[]`: local daily memory file does not exist in
  `openclaw-agents-memory`.
- `.memory.changed[]`: local daily memory exists in the repo but differs by
  hash.

## Sync Own Memory And Key Markdown

The daily zero-token sync copies an agent's own local `memory/*.md`,
`MEMORY.md`, and key workspace Markdown files into `openclaw-agents-memory`.
Agents curate their own local files before sync. The sync itself does not
summarize or post Mattermost success messages. It skips empty daily notes,
validates the complete IKF selection, and uses an automatic PR to enter the
protected memory branch.

Run one agent sync manually:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec deploy/agent-designer -c agent -- \
  openclaw-agent-sync-memory-repo
```

Run the cluster collector manually:

```bash
kubectl --context infuseai-k8s -n agents-swarm create job \
  --from=cronjob/openclaw-agent-memory-sync \
  openclaw-agent-memory-sync-manual-$(date +%Y%m%d%H%M%S)
```

The helper:

- refuses to run if the shared-memory checkout is already dirty;
- fetches and fast-forwards the configured memory branch;
- copies only under `agents/<agent-id>/`;
- commits on a unique `agent-memory-sync/<agent-id>/...` branch when there are
  changes;
- creates and squash-completes an Azure PR into protected `main`;
- restores the local checkout to clean `main` after success, while preserving
  a failed sync branch for recovery.

## Dogfood Result

Superseded historical note: the first live dogfood exercise used
`agent-designer` because it had one real unsynced memory file. That earlier
stage-only export:

- started with a clean `openclaw-agents-memory` checkout;
- fetched `origin/main`;
- staged exactly `agents/agent-designer/memory/2026-05-28.md`;
- created no commit and performed no push;
- returned to clean after `git reset --hard HEAD`.

That validated the original operator loop. The current daily sync copies
agent-owned memory/profile Markdown, commits under `agents/<agent-id>/`, and
merges through an automatic Azure PR. The curated top-level `MEMORY.md` is
rendered with deterministic IKF metadata, and the complete memory repository
selection must pass its knowledge-format validator before a commit or PR is
allowed.

## Common Operations

Before restarting or refreshing a pod:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec deploy/<agent-id> -c agent -- \
  openclaw-agent-local-drift-report --pretty
```

After a rollout:

```bash
AGENT_ID=<agent-id> task smoke-agent-runtime
```

When `.memory.unsynced` or `.memory.changed` is nonempty:

1. Confirm the dates are expected if this is a manual inspection.
2. Run `openclaw-agent-sync-memory-repo` or the cluster collector.
3. Check the memory repo history if needed.

When persona is dirty:

1. Inspect only paths from the report.
2. Decide whether the local change belongs in
   `openclaw-agents-persona/agents/<agent-id>/`.
3. Create a PR in the persona repo. Do not patch the PVC as the durable fix.

When source-synced skills are dirty:

1. Inspect only paths from the report.
2. Decide whether the change belongs in `agent-skills`.
3. Create a PR in the skills repo.
4. Let runtime startup sync or `task sync-agent-skills-runtime` refresh the PVC
   after review.

When a skill manifest is `superseded`:

- Use the newer source-scoped manifest as authority. Do not treat historical
  hash differences as live drift.

When an authoritative skill manifest is `null` / `missing_file_hashes`:

- Treat it as unknown coverage, not active drift.
- Refresh the agent with the current image/startup sync or reinstall skills to
  get hash-backed manifests.

When `.skills.unmanaged_directories` is nonempty:

1. Run `openclaw-agent-skill-proposal scan --quarantine` if the scheduled
   monitor has not already done so. This preserves the candidate outside the
   runtime-discovered `skills/` directory and computes a content digest.
2. The cluster monitor posts a deduplicated, content-free alert to
   `ai-lab/agent-skills` with the agent, skill ID, digest, detection timestamp,
   proposal path, and review queue. It reuses the existing read/exec collector
   service account and sends through Satwa's already-configured Mattermost
   account; it mounts no additional credential.
3. Review the proposal and choose exactly one disposition: promote a reusable
   standalone skill through an `agent-skills` PR, consolidate the durable
   behavior into an existing reviewed skill, or retire it.
4. Only merged source plus an explicit reviewed bundle grant may activate the
   result. A proposal and its alert grant no runtime authority.
5. Remove handled proposal directories after source adoption or retirement,
   then re-run the drift report and `openclaw skills check`.

Run the monitor manually:

```bash
kubectl --context infuseai-k8s -n agents-swarm create job \
  --from=cronjob/openclaw-agent-skill-proposal-monitor \
  openclaw-agent-skill-proposal-monitor-manual-$(date +%Y%m%d%H%M%S)
```

## Known Failure Points

- Concurrent syncs can conflict; the collector runs agents sequentially and
  each sync starts its branch from current `origin/main`.
- Any invalid Atlas-selected document blocks the PR. Repair and verify the
  memory repository before retrying; do not bypass the validator.
- The sync path can copy sensitive notes if an agent writes them locally. Agents
  are responsible for curating local memory before sync.
- Drift is hash-based. It does not decide whether a change is desirable.
- PVCs can retain stale files after image rollouts.
- Legacy manifests without file hashes reduce confidence until refreshed.
- Sparse checkout policy must stay tested so other agents' raw memory remains
  absent from default pod checkouts.

## Next Improvements

1. Add a smoke test for `openclaw-agent-sync-memory-repo`.
2. Persona and skill PR generators for local draft changes.
3. One-time stale-manifest cleanup or migration command.
