---
title: Agent observability baseline 2026-08-27
description: Pre-deployment fleet, access, capacity, package, and collector evidence for the first OpenClaw observability canary.
type: evidence
status: active
owner: team:agent-platform
tags:
  - evidence
  - observability
  - openclaw
  - kubernetes
  - canary
---

# Agent Observability Baseline 2026-08-27

## Scope

This began as the no-write baseline for Iterations 0 and 1 of the agent
behavioral observability plan. Subsequent gate, deployment, correction, and
post-canary audit evidence is appended below. At the initial baseline, the only
Kubernetes write was the masked exporter Secret; later sections explicitly
record the approved Tinus, collector, and ServiceMonitor changes. No custom
OpenClaw core bundle has been rebuilt.

## Live fleet

Fresh `infuseai-k8s` evidence showed:

- Caller identity:
  `system:serviceaccount:oleagut:kapiteky-cluster-operator`.
- Namespace: `agents-swarm`.
- `agent-coordinator`, `agent-designer`, `agent-developer`, `agent-infra`, and
  `agent-intake` were all Ready `1/1` and Available `1`.
- Every Deployment referenced image tag `20260827.24`.
- Every current pod reported zero restarts and immutable image digest
  `sha256:77a705b4b51752a16303a1c78fc22084e44cddef6f635d64a4dbd578c36f6977`.
- Tinus startup logs showed five active plugins—ACPX, browser, Codex,
  Mattermost, and memory-core—and a connected Mattermost channel. No OTel
  plugin was active in the baseline.

This exact digest is the runtime rollback floor for the first Tinus telemetry
canary unless a newer fleet baseline is deliberately accepted before rollout.

## Capacity finding

Earlier namespace Warning events showed 50m collector jobs failing scheduling
because the single node reported `Insufficient cpu`. After Fito removed
unneeded workloads, the approved task-scoped read-only capacity audit proved:

- node `n1.infuse-ai.com` is Ready with `12000m` allocatable CPU;
- all scheduled nonterminal pods request `10611m` in total;
- `1389m` requested-CPU headroom remains;
- there are no Pending pods or current `FailedScheduling` events; and
- the planned OTel Collector requests `25m`.

The capacity gate is therefore satisfied without changing requests, limits, or
existing workloads.

## Access and monitoring findings

- The caller can read and manage ordinary Deployment, ConfigMap, Service, and
  NetworkPolicy resources in `agents-swarm`.
- The caller cannot read Deployments or Services in `monitoring`.
- The caller cannot create `ServiceMonitor` resources in `agents-swarm`.
- The caller can read ordinary workloads and Services in `infuseai`, which
  made live Langfuse and Opik evidence possible without expanding access.
- Fito explicitly approved one task-scoped use of the Vaultwarden-held
  Kubernetes super-access token. A temporary mode-0600 kubeconfig bridge was
  used for this read-only audit and removed immediately afterward; the normal
  local context and RBAC were not changed.
- The approved identity can create the cross-namespace ServiceMonitor after
  deployment. The reviewed source remains in the monitoring repository so the
  privileged write does not become an undocumented one-off.

## Live backend evidence

- Monitoring Helm releases are deployed as kube-prometheus-stack chart
  `77.14.0` / operator app `0.85.0` and loki-stack chart `2.10.2` / declared
  app `2.9.3`.
- The Ready workloads run Grafana `12.1.1`, Prometheus `3.6.0`, Prometheus
  Operator `0.85.0`, promtail `2.9.3`, and Loki `2.6.1`. The Loki workload is
  therefore older than the Helm release's declared app version; treat `2.6.1`
  as runtime truth and retain this drift as a monitoring-maintenance follow-up.
- `Deployment/langfuse-web` and `Deployment/langfuse-worker` were Ready `1/1`
  on version `3.115.0`. The public health endpoint returned HTTP 200 with
  `status=OK` and the same version. A credential-free GET to the configured
  OTLP trace endpoint returned HTTP 405, proving the route exists while not
  attempting authenticated ingestion.
- The Opik frontend, backend, and Python backend Deployments were Ready `1/1`
  on version `2.0.37`; the checked-in deployment repository pins the matching
  Helm chart version. Its unauthenticated public routes redirected to Authentik
  as designed. Opik remains reserved for controlled evaluations rather than
  production trace fan-out.

## Package and image evidence

- Npm metadata resolves `@openclaw/diagnostics-otel@2026.8.1-beta.3` with
  OpenClaw peer/API compatibility `>=2026.8.1-beta.3`.
- The official OpenTelemetry Collector release current on the collection date
  is `0.159.0`, published 2026-08-18. The planned image is pinned to manifest
  digest
  `sha256:1f2c54a30e713fac6b3ae77a1ec84010c2007e29ced8ec666214fc2f6739c1cc`.
- Collector `validate` accepted the checked-in receiver, processor, connector,
  exporter, and pipeline configuration. A credential-free local runtime smoke
  reached the collector's Ready health state and confirmed that the OTLP
  receiver, bounded keep-all tail sampler, span-metrics connector, health
  extension, and Prometheus exporter start together. Both the explicitly
  externalized internal-metrics endpoint
  on `8888` and a span-derived metrics endpoint on `8889` were scrapeable after
  injecting one synthetic metadata-only span. The expected unset-header
  warning confirms that production still requires the hard Secret contract
  below.
- `task verify` passed with 93 tests, including the 10 privacy/cardinality
  fixtures, Tinus-only runtime contract, and Vaultwarden-to-Kubernetes Secret
  parser/shape checks.
- A clean local swarm image build completed successfully. Its image-level
  runtime smoke loaded the diagnostics package as a trusted official npm
  install against the existing custom OpenClaw host; no custom OpenClaw bundle
  rebuild was needed.
- Local image contents: OpenClaw `2026.8.1`, Codex `2026.8.1-beta.3`,
  diagnostics-otel `2026.8.1-beta.3`, ACPX `2026.8.1`, and unchanged source
  revision `3d1a6e4197b2bcce4b90cd3fc5b6de8a5b1f24c0`.

The registry-hosted Linux AMD64 image is now published as
`registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:observability-20260827.1-3d1a6e419`.
The immutable OCI index digest is
`sha256:c04ddba5d94f5ea6a8ba6dce5f126880b8cdcd59ca9ca4c7bfb74f9cb5ebca50`;
its Linux AMD64 image manifest is
`sha256:1d582d3b2b4f3933f177632dd77ebb1c5266ad8b8b9a8909f1b5351222711e3a`.
Registry inspection shows no runnable platform other than Linux AMD64; the
additional `unknown/unknown` manifest is BuildKit provenance attestation.

The normal `main` deployment path applies the shared image tag to all five
agents. The first observability trial must therefore use the reviewed
`deploy-agent-observability-canary` task before merge. It applies only the OTel
Collector and Tinus Deployment, resolves and pins the image digest, verifies
the other four agent pod-template fingerprints remain unchanged, and rolls
Tinus back to the captured Deployment revision if its rollout or runtime smoke
fails.

## Pre-canary gates (closed)

The masked `openclaw-observability-exporters` Secret is now provisioned from
Vaultwarden item `Langfuse / Tracking creds` with exactly the one approved key.
The write used the approved masked Kubernetes credential bridge; no value was
printed or persisted in source.

Capacity, immutable Linux AMD64 image publication, explicit canary approval,
collector deployment, Tinus rollout, and ServiceMonitor discovery are proven.

## First canary evidence and correction

Fito approved the Tinus-only canary. The Collector and Tinus rolled out Ready,
the runtime smoke passed, and the other four agent pod-template fingerprints
remained unchanged. One real model turn called `session_status` successfully.
The Collector accepted and exported all 16 observed spans; Prometheus reported
both ServiceMonitor targets healthy and queried the same span counters;
Langfuse returned 13 recent OpenClaw traces with no trace-level input or output.
Loki indexed both Tinus and Collector logs.

That Loki proof exposed a contract violation in the optional diagnostics
stdout log exporter: duplicated structured log records included absolute
workspace paths. The trace pipeline remained metadata-only, but the duplicate
log stream must not be promoted. The canary correction disables diagnostics
log export while retaining traces and metrics; ordinary pre-existing
application logs remain available through promtail/Loki. A replacement swarm
image and repeated end-to-end proof are required before this iteration closes.

The first replacement restart then exposed a separate idempotency defect: the
canary bootstrap allowlist included diagnostics only after a fresh plugin
install. Once the plugin already existed on the persistent volume, the
bootstrap config temporarily disabled it and trusted-runtime verification
failed. The guarded deployment detected the failed smoke and restored the
previous canary revision. The durable correction conditionally includes
`diagnostics-otel` in the bootstrap allowlist whenever its exact package is in
`OPENCLAW_REQUIRED_PLUGINS`; this keeps non-canary agents unchanged.

The first retry with the corrected image exposed a rollout-smoke race rather
than another runtime failure: the smoke selected the previous ReplicaSet pod
before the controller finished converging and that pod disappeared during the
first exec. The canary deployer now passes the resolved immutable digest into
the runtime smoke, which refuses to select a Ready pod unless its `imageID`
matches that exact digest and the deployment has one active pod.

The corrected runtime then exposed a contract gap in backend verification:
standard OTel process resource attributes included a sensitive Gateway launch
argument. The collector was immediately scaled to zero. The correction keeps
only the seven versioned resource attributes declared by the telemetry
contract before trace or metric export, and the executable contract now rejects
unapproved process resource attributes. Export remained paused until this
configuration was validated and Fito accepted the internal-only exposure risk
without credential or trace remediation.

Local collector proof used the same pinned `0.159.0` image and a synthetic OTLP
span containing the seven approved resource attributes plus dummy process
arguments and a host name. The collector config validated successfully and the
detailed debug exporter retained exactly the seven approved fields; the process
arguments and host name were absent.

Fail-open proof was completed while the production collector was intentionally
at zero replicas for containment. A fresh Tinus turn called `session_status`
once, returned the exact expected response, reported zero tool failures, and
left the pod Ready with zero restarts and no Gateway fatal markers. Telemetry
availability therefore does not block agent work.

After restoration, the first corrected export accepted and sent 16 spans with
zero refused or failed spans and no process/command-line metric labels. It also
surfaced the span-metrics connector's default per-restart
`collector.instance.id` dimension. The single-replica collector now excludes
that dimension to keep metric series stable across restarts.

Applying the cardinality ConfigMap also exposed a rollout-harness gap:
Kubernetes updated the mounted file but did not restart or hot-reload the
collector process. The guarded canary deployer now explicitly restarts the
collector after every reviewed configuration apply and waits for readiness.

## Final corrected canary evidence and next gate

Fito accepted the internal-only exposure risk and declined token rotation and
trace deletion. The existing internal records remain under their configured
backend access and retention controls; the corrected collector prevents new
process or command-line resource export.

The final Tinus image is
`registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:observability-20260827.3-3d1a6e419`
at immutable OCI index digest
`sha256:062910b09a3d10eca5b12058db0eb1afb5d699623069b3d192f4e573fe21ffbf`.
Tinus, the other four agents, and the collector were Ready with zero restarts;
the other four agents remained on their existing fleet image.

After the final collector restart, a fresh model turn called `session_status`
once and returned the expected result. The collector accepted and sent five of
five spans with zero refused or failed spans. Prometheus reported both
ServiceMonitor targets healthy, five span calls, zero sensitive process-label
series, and zero `collector.instance.id` series. Langfuse returned two new
OpenClaw traces with no input, output, affected credential, or forbidden
resource keys. Loki indexed ten Tinus and 31 collector lines in the ten-minute
window with zero duplicate diagnostic records.

The scenario set also proved a successful tool call, one intentional harmless
`bash` failure with exactly one reported tool failure, a `verify-this` skill
activation with successful local evidence, and unchanged agent behavior while
the collector was unavailable. The failed run marker was present once in Loki
without raw command text. It was not visible in the trace-list response queried
during the canary. That trace-level response did not establish whether child
observations carried tool attributes, so it must not be used as evidence that
the official plugin omits tool telemetry.

Iteration 1 therefore completes the safe OTel substrate but does not authorize
fleet promotion. The next useful slice is Tinus-only behavioral instrumentation
for the remaining skill, workflow, and knowledge gaps. Tool telemetry is already
present. Only the Codex-native skill and structured knowledge-access paths reach
the agreed custom artifact rebuild gate.

## Post-canary instrumentation audit — 2026-08-28

The exact deployed OpenClaw source was audited at revision
`3d1a6e4197b2bcce4b90cd3fc5b6de8a5b1f24c0`, together with the matching
installed `@openclaw/codex@2026.8.1-beta.3` and
`@openclaw/diagnostics-otel@2026.8.1-beta.3` bundles. A task-scoped read-only
query of the Tinus collector's Prometheus endpoint corrected the earlier
trace-list inference:

- `openclaw_tool_execution_duration_ms_milliseconds_count` contained successful
  `session_status` and `bash` executions with bounded tool-source labels;
- the intentional `bash` failure was present once with
  `openclaw_errorCategory="codex_native_tool_error"`; and
- no `openclaw_skill_used_total` series was present in the same live snapshot.

The source explains the split. OpenClaw already defines trusted
`tool.execution.started`, `tool.execution.completed`,
`tool.execution.error`, `tool.execution.blocked`, and `skill.used` events. The
official diagnostics plugin records them as `openclaw.tool.execution` and
`openclaw.skill.used` spans and as bounded metrics. The Codex adapter emits the
tool lifecycle for native and dynamic tools. The generic embedded-agent wrapper
also emits `skill.used` when its `read` tool or explicit skill command resolves
a known `SKILL.md`, but the Codex adapter does not project Codex-native skill
invocations into that event.

The controlling source surfaces are `src/infra/diagnostic-events.ts`,
`src/agents/agent-tools.before-tool-call.diagnostics.ts`,
`extensions/codex/src/app-server/`, and
`extensions/diagnostics-otel/src/service-recorders-tools.ts`. The sibling Codex
source confirms that Codex tracks explicit and implicit skill invocation
internally, while the audited app-server protocol exposes no corresponding
skill-invoked notification.

The minimum implementation path is therefore:

| Signal | Verified current state | Minimum next implementation | OpenClaw custom artifact rebuild? |
| --- | --- | --- | --- |
| Tool selection, duration, block, and failure class | Emitted and proven live on Tinus | Query child observations correctly; add Grafana views and any reviewed collector dimensions | No |
| Coarse workflow lifecycle | Public prompt/model/tool/agent hooks carry run and trace context; official exporter currently ignores `run.progress` and `run.execution_phase` | Standalone metadata-only instrumentation plugin using public hooks, packaged in the swarm image | No core or Codex rebuild |
| Knowledge discover/fetch and wrapper failures | No dedicated envelope yet | One fail-open helper in `agent-skills`, preferably exposed through a plugin-owned tool so spans inherit the run trace | No core or Codex rebuild |
| Skill bundle/image revision | Resource contract exists, but live series currently report `dev` | Set immutable runtime resource attributes from the image and skill manifest | No |
| Embedded-agent skill activation | Existing trusted `skill.used` event | Validate with an embedded-agent scenario when that harness is used | No |
| Codex-native skill activation | Codex detects it internally, but its app-server protocol exposes no skill-invoked notification and the OpenClaw Codex adapter emits no `skill.used` event | Prefer an upstream Codex app-server notification, then project it in `@openclaw/codex`; a structured adapter-local fallback requires the same plugin review | **Yes: Codex/OpenClaw plugin artifacts, not OpenClaw core schema** |
| Generic Read/Search/ListFiles knowledge access | Codex sends structured `commandActions`, but public tool hooks expose only the command boundary and not those parsed actions | Project sanitized action classes in `@openclaw/codex` | **Yes: OpenClaw Codex plugin artifact** |
| Per-skill content hash | Existing `skill.used` has name/source/activation but no revision/hash | Resolve from the immutable skill manifest in the instrumentation layer, or add a reviewed event enrichment | Not necessarily; only if enriching the trusted built-in event directly |

This iteration is deliberately source, image, and live-telemetry audit only. No
OpenClaw core, Codex plugin, diagnostics plugin, swarm image, or Kubernetes
runtime was rebuilt or changed. The next no-core slice is to correct revision
attributes and expose the already-live tool telemetry in Grafana/Langfuse,
followed by a standalone workflow/wrapper prototype. Work must stop again before
building either gated Codex artifact path.

## No-core behavioral instrumentation implementation — 2026-08-28

The approved no-core slice now has a reviewable implementation on the
observability branch:

- immutable image attribution comes from the pod-template digest annotation;
- `infuse.skill_bundle.revision` is a stable SHA-256 projection of the
  post-sync runtime skill manifest rather than volatile timestamps or paths;
- the path-installed `behavioral-observability` plugin uses only public
  OpenClaw plugin entrypoints and hook trace contexts;
- the plugin owns a fail-open OTLP trace provider pointed at the same reviewed
  collector endpoint because `diagnostics-otel` intentionally keeps its SDK
  provider private; using the process-global OTel API from another plugin was
  live-proven to create no-op spans;
- its non-bundled conversation hooks are explicitly authorized only for that
  plugin through `hooks.allowConversationAccess`; all emitted fields remain
  constrained by the v1 telemetry contract;
- workflow spans implement the existing `infuse.workflow.phase` v1 contract;
- the plugin-owned `knowledge_retrieval` tool delegates to the installed
  `knowledge-retrieval` skill client, keeping its stdin, validation, rotating
  token, and response boundaries while emitting only operation/mode/outcome,
  bounded duration/count, fallback class, and snapshot hash;
- `wrapper_failure` emits the existing `infuse.wrapper.execution` contract
  only after a failed skill-owned helper, using stable skill/wrapper/operation
  IDs and a bounded error code; and
- collector span metrics expose only the contract's reviewed dimensions.

All custom emission is fail-open. Prompt text, objectives, references,
retrieved Markdown, tool inputs/outputs, error messages, paths, session/user/
channel identifiers, and credentials are excluded. The runtime plugin content
is part of the persistent-PVC install fingerprint, so a changed image copy is
reinstalled without a PVC reset.

The remaining rebuild-gated gaps are unchanged: Codex-native skill activation
and sanitized projection of generic Read/Search/ListFiles actions require a
new Codex/OpenClaw plugin artifact. This branch must stop before building those
artifacts.

### Tinus live proof and knowledge boundary — 2026-08-28

Tinus passed the guarded rollout on immutable image digest
`sha256:16523e4bb4f35aa3ca0eb32ae1eec5cd4053f72693d88b9bbf92c2482c1dec90`.
The Gateway, Mattermost channel, 25-skill provenance check, and plugin-owned
OTLP exporter were healthy with zero container restarts; the other four agent
pod templates were unchanged. Live span metrics proved bounded workflow,
wrapper-failure, knowledge-failure, and official tool signals with exact
image/runtime/skill-bundle revisions. Collector self-metrics proved successful
Langfuse delivery with no failed or dropped span counter.

The same probe exposed one boundary that this no-core slice must not conceal:
the canonical knowledge client and the plugin tool execute successfully when
called directly, but the pinned Codex dynamic-tool path presents the structured
Discover result as an error. An explicit `ok: true` result marker did not change
that behavior. The failure is correctly observable as
`infuse.knowledge.retrieve{operation="discover",outcome="error"}`. Correcting
the dynamic-tool result projection may require a rebuilt Codex/OpenClaw
artifact, so work stops at the approved rebuild gate rather than modifying the
pinned canary bundle.
