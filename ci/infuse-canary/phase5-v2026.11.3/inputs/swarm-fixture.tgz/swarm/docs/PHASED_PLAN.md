---
title: Phased Plan
description: This is the working plan for making Kapiteky/OpenClaw live on
  Kubernetes and grow into an Infuse AI agent swarm.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - phased
---
# Phased Plan

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


This is the working plan for making Kapiteky/OpenClaw live on Kubernetes and grow into an Infuse AI agent swarm.

## Phase 0 - Foundations

Status: in progress

Tasks:

- [x] Create Azure DevOps repo.
- [x] Add architecture, security, and roadmap docs.
- [x] Add conservative Kubernetes base manifests.
- [x] Add executable repo automation.
- [x] Add runtime image scaffold.
- [x] Add first smoke checks.
- [x] Add repo map and decision log.

Exit criteria:

- A new contributor or agent can understand the repo in under 10 minutes.
- `task verify` validates the repo skeleton without cluster write access.

## Phase 1 - Durable OpenClaw Runtime

Status: in progress

Tasks:

- [x] Build an OpenClaw runtime image scaffold.
- [x] Mount `/workspace` from a PVC.
- [x] Start with a non-secret placeholder command until OpenClaw boot is wired.
- [x] Add a persistence smoke test that writes a marker, restarts the pod, and confirms the marker remains.
- [ ] Add log and readiness conventions.

Exit criteria:

- `openclaw-agent` starts in a staging namespace without privileged mode.
- Workspace data survives pod replacement.
- Runtime logs are inspectable through `kubectl`.

## Phase 2 - Browser Smoke Runner

Status: in progress

Tasks:

- [x] Add Playwright runner job.
- [x] Capture screenshot artifact.
- [ ] Capture traces and HTML reports as artifacts.
- [x] Support headed Chromium through Xvfb-capable Playwright image.
- [ ] Add optional noVNC browser desktop for visual debugging.

Exit criteria:

- A sample smoke can load a URL and produce screenshot evidence.
- Rendering-sensitive failures can be debugged visually without changing the main agent pod.

## Phase 3 - Build Runner

Status: planned

Tasks:

- [ ] Choose default build path: rootless BuildKit first unless blocked.
- [ ] Add build-runner manifests.
- [ ] Add image build and push workflow.
- [ ] Document when remote Docker contexts are allowed.

Exit criteria:

- Main agent pod never needs the host Docker socket.
- Image builds are reproducible and auditable.

## Phase 4 - Private Networking

Status: planned

Tasks:

- [ ] Decide Tailscale pattern: operator, sidecar, subnet router, or cluster egress.
- [ ] Define internal services and admin paths.
- [ ] Add network policies for runner traffic.
- [ ] Document ACL and approval expectations.

Exit criteria:

- No public admin surface is needed.
- Runtime can reach approved internal resources through private paths.

## Phase 5 - Agent Swarm

Status: in progress

Tasks:

- [x] Define initial worker roles and permission levels.
- [x] Add per-agent skill bundles and access metadata.
- [x] Deploy Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon as isolated persistent agents on InfuseAI Kubernetes.
- [x] Add shared runtime toolbox.
- [x] Add controlled per-task repo checkout into agent PVCs.
- [ ] Add context-pack templates from `company-docs`.
- [ ] Add scoped task handoff format.
- [ ] Add review and verification protocol.
- [ ] Add worker lifecycle cleanup rules.
- [x] Draft persistent agent identity and Mattermost access model.

Exit criteria:

- Kapiteky can dispatch bounded work to specialized workers.
- Worker outputs are reviewable: files changed, commands run, verification, risks, escalation notes.

Current next-step plan: `docs/AGENT_WORKER_READINESS_PLAN.md`.

## Phase 5.5 - Backoffice Command Center

Status: planned

Tasks:

- [x] Document Backoffice as the intended agent command center.
- [ ] Add read-only agent inventory/status view.
- [ ] Show declared credential-access intent without secret values.
- [ ] Link agents to their docs, Mattermost handles, Kubernetes workload, and smoke status.
- [ ] Add human-triggered smokes only after the read-only view is reviewed.

Exit criteria:

- Fito can inspect Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon from Backoffice.
- Backoffice does not become a secret store.
- Operational writes remain explicit, human-triggered, and audited.

Current plan: `docs/BACKOFFICE_COMMAND_CENTER.md`.

## Phase 6 - Production Hardening

Status: planned

Tasks:

- [x] Add CI verification.
- [x] Add secret contract examples.
- [x] Add local/kind development overlay.
- [ ] Add image scanning and dependency update process.
- [x] Add backup/restore test for the workspace PVC.
- [ ] Add metrics/logging conventions.
- [ ] Add incident and rollback runbook.

Exit criteria:

- Runtime can be upgraded, rolled back, backed up, and audited without guesswork.
