---
title: Harbor Trivy Remediation - 2026-05-28
description: "Status: historical backlog security remediation. The standalone
  browser-runner image/deployment path was later retired when the repo
  standardized on InfuseAI agents-swarm."
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - security
  - harbor
  - trivy
  - remediation
---
# Harbor Trivy Remediation - 2026-05-28

Status: historical backlog security remediation. The standalone
`browser-runner` image/deployment path was later retired when the repo
standardized on InfuseAI `agents-swarm`.
Source: Harbor full vulnerability scan after enabling the built-in Trivy scanner.
Scanner: Trivy via `harbor.infuse-ai-tech.party`, report-only mode.

## Affected images

Current/latest images checked:

- `registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:20260528.32`
- `registry.infuse-ai-tech.party/openclaw-k8s-swarm/openclaw-agent:agent-toolbox-v3-amd64`
- `registry.infuse-ai-tech.party/openclaw-k8s-swarm/browser-runner:c79e1999643b-amd64`

## Scan summary

`openclaw-agent` current image:

- Scan status: `Success`
- Severity: `Critical`
- Critical: 22
- High: 162
- Medium: 201
- Low: 181
- Total: 584
- Fixable: 199

`browser-runner` current image:

- Scan status: `Success`
- Severity: `High`
- Critical: 0
- High: 24
- Medium: 545
- Low: 112
- Total: 681
- Fixable: 287

## Main findings

The agent image is based on `node:22-bookworm-slim` and shows Debian 12 package vulnerabilities, especially:

- `libgnutls30` with fixed versions available.
- Perl packages such as `perl`, `perl-base`, and `libperl5.36`.
- Python 3.11 runtime packages.
- `libsqlite3-0`.

The browser runner image is based on `mcr.microsoft.com/playwright:v1.56.1-noble` and has no Critical findings, but still has many High/Medium base image findings.

## Remediation plan

1. Rebuild both images from fresh base image pulls to pick up upstream patched layers.
2. Add explicit OS package upgrade steps where appropriate, for example after `apt-get update`, while preserving small runtime images.
3. Consider moving the agent image to a newer patched Node base once compatible.
4. Keep `browser-runner` aligned with the latest compatible Playwright image.
5. Re-scan the new Harbor images and compare Critical/High/fixable counts before enabling any blocking gate.

## Acceptance criteria

- Current deployed `openclaw-agent` image has no fixable Critical vulnerabilities, or remaining Critical findings are documented with rationale.
- `browser-runner` has no Critical findings and materially fewer High fixable vulnerabilities.
- CI/CD can surface the Trivy result for the produced image before deploy promotion.
