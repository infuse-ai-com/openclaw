---
title: Security Model
description: "This repo follows the Infuse AI security principle: least
  privilege by default, explicit approval for sensitive write access, and no
  secrets in durable text."
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - security
---
# Security Model

This repo follows the Infuse AI security principle: least privilege by default, explicit approval for sensitive write access, and no secrets in durable text.

## Access Layers

- Company-level context stays in `company-docs` and should not be copied here wholesale.
- Initiative-level context belongs in this repo, the project channel, and scoped board items.
- Tool-level credentials remain in approved secret stores or runtime secrets.

## Runtime Permissions

The main `openclaw-agent` workload should start with:

- no cluster-admin;
- no hostPath mounts;
- no Docker socket mount;
- read/write access only to its PVC;
- minimal service account permissions;
- network policy limiting inbound traffic.

Sensitive capabilities should be split into explicit workers:

- build runner for image builds;
- browser runner for smoke tests;
- mac worker for macOS-only actions;
- DevOps/security worker for controlled operational writes.

## Secrets

Do not commit:

- API keys or PATs;
- kubeconfigs with credentials;
- Tailscale auth keys;
- browser cookies/session stores;
- Vaultwarden exports;
- `.env` files with real values.

Use references and runtime injection instead:

- Kubernetes Secret names;
- External Secrets references;
- Vaultwarden item names and collection names;
- sealed/encrypted secret workflows once chosen.

Agent bundles may declare Vaultwarden item names, collections, and runtime sync targets as metadata. They must not contain secret values or broad unreviewed access. See `docs/CREDENTIAL_ACCESS.md`.

## Tailscale / Private Access

The preferred posture is private by default:

- no public agent admin surface;
- internal Kubernetes services for pod-to-pod traffic;
- Tailscale or equivalent private overlay for operator access;
- explicit ACLs for agent, worker, and admin paths.

OpenClaw Control dashboards are exposed only through the Tailscale Kubernetes
Operator. The dashboard Ingresses use `ingressClassName: tailscale`, gateway
authentication, and NetworkPolicy allowing ingress only from the `tailscale`
namespace. The central Tinus/Stewie path uses exact-source trusted-proxy auth
with a narrow user allowlist and session read/write scope cap; other private
agent dashboards retain token auth. Tailnet ACLs must restrict those HTTPS MagicDNS
hostnames/tags to trusted operators; do not rely on Kubernetes naming secrecy.

## Approval Gates

For the internal swarm, Fito approved advisory image security scans on
13 November 2026. Full findings and scanner failures remain visible as allowed
CI failures, without blocking deployment. Registry identity verification and
manual deployment authorization remain mandatory. Internal exposure reduces
direct ingress risk; agents still process repository/web content and use
credentials, so the [remediation plan](plans/active/runtime-security-remediation-2026-11-12.md)
remains active. The [delivery contract](GITLAB_DELIVERY.md) owns the exact CI behavior.

Fito approval is required before:

- granting production write access;
- creating or rotating privileged credentials;
- changing Tailscale ACLs, DNS, firewall, or ingress exposure;
- deploying persistent privileged workloads;
- deleting runtime PVCs or namespaces.
