---
title: Repo Map
description: This repo hosts the Kubernetes runtime substrate for Infuse AI
  OpenClaw persistent agents. Use this map to pick the right file before
  editing.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - repo
  - map
---
# Repo Map

This repo hosts the Kubernetes runtime substrate for Infuse AI OpenClaw persistent agents.
Use this map to pick the right file before editing.

## Top-Level Files

- `AGENTS.md` - repo-specific operating rules for coding agents.
- `README.md` - high-level purpose, goals, and entry points.
- `Taskfile.yml` - canonical automation surface. Prefer adding tasks here before adding ad hoc commands to docs.
- `.gitlab-ci.yml` - source verification. The release requirements and separate production approval are in `docs/RUNBOOK.md`.

## Current renewal evidence

- `docs/plans/active/remaining-critical-investigation-2026-11-13.md` - current XML/LMDB consumers, maintained patch candidates and qualification requirements; company-docs owns follow-up decisions.

- `docs/GITLAB_AGENT_SOURCE_MIGRATION.md` - current source/credential and job contract.
- `docs/plans/active/agent-system-renewal-qualification-2026-11-12.md` - exact candidate scan, live canary, pending decisions and recovery boundary.
- `docs/plans/active/runtime-security-remediation-2026-11-12.md` - installed dependency ownership, ordered security fixes and residual-risk review before the image exception expires.

## Runtime Images

- `images/openclaw-agent/` - Linux runtime image for OpenClaw agents.
  - `Dockerfile` installs the `openclaw` npm package.
  - `OPENCLAW_VERSION` controls which package version is installed.
  - `CODEX_VERSION` and `ACPX_VERSION` independently pin compatible official
    runtime plugins when their publication versions differ from OpenClaw.
  - `entrypoint.sh` handles default long-running behavior and optional `OPENCLAW_BOOT_COMMAND`.

## Agent Skill Policy

- `config/backoffice-agent-catalog.v1.json` - generated, sanitized configuration
  catalog fetched by Backoffice for agent identity and declared ownership.
- `config/skill-catalog.json` - reviewed skill sources, managed-copy versus
  runtime-native ownership, and individual skill metadata.
- `config/agent-skill-bundles/` - per-agent binary installed skill sets, credential policy, and repo task-workspace deny lists.
- `docs/AGENT_SKILL_MATRIX.md` - generated installed/absent matrix for every
  company skill plus reviewed runtime-native skills; checked against bundles
  during verification.
- `scripts/verify-agent-skill-bundles.py` - validates versioned source-catalog
  metadata alignment, dependency-closed bundles, credentials, repo access,
  active-agent inventory, and runtime patch consistency.

## Kubernetes Manifests

- `k8s/components/persistent-agent/` - reusable Deployment/PVC/NetworkPolicy shape for one persistent agent.
- `k8s/agents/` - per-agent overlays, including active `agent-developer`, `agent-designer`, `agent-infra`, `agent-coordinator`, and `agent-intake`.
- `k8s/platform/artifact-registry/` - gated `core` runtime base for the dedicated authenticated Backoffice Artifact Registry; it contains no credentials and is not applied automatically.
- `k8s/platform/artifact-registry-recovery/` - gated transfer/restore PVCs plus
  suspended, network-isolated recovery Job templates; same-node transfer is not
  accepted disaster recovery until an off-node copy verifies.
- `config/artifact-registry-runtime.v1.json` - typed disabled runtime, exact
  Backoffice image/build, storage/auth references, producer mounts, and
  activation posture for the Artifact Registry.
- `scripts/verify-artifact-registry-runtime.sh` - render the gated service,
  producer, T5.1 canary/verifier, and recovery paths and optionally run
  admission-only server dry-runs
  that persist nothing.
- `k8s/overlays/infuseai/` - InfuseAI Kubernetes overlay for the active persistent agents in namespace `agents-swarm`.
  - `serviceaccount.yaml` owns the five distinct retrieval identities plus the
    bounded shared rollback identity. Per-agent Deployment patches select the
    exact `openclaw-agent-<role>` ServiceAccount without changing images,
    bundles, PVCs, or OpenClaw configuration.
  - `bootstrap-rbac.yaml` is a one-time cluster-admin bootstrap for the CI deploy service account; it is not included in the normal Kustomize overlay.
- `k8s/tailscale/` - Tailscale Operator resources that are applied after the operator CRDs exist, including the shared dashboard ingress `ProxyGroup`.

## Scripts

- `tools/agent-evals/` - sanitized 12-case/20-trial agent workflow suite,
  deterministic metadata-only runner, passing control fixture, and test-only
  degraded candidate used to prove rejection without production deployment.
- `docs/AGENT_EVALUATIONS.md` - replay, live read-only Gateway invocation,
  privacy, trace-correlation limitation, grading, and promotion boundaries.

- `scripts/bootstrap-agent-profile.sh` - parameterized OpenClaw profile bootstrap for one persistent agent.
- `scripts/generate-backoffice-agent-catalog.py` - derives the allowlisted
  Backoffice catalog from active overlay membership, Deployment identity, and
  bundles; `--check` rejects generated drift.
- `scripts/bootstrap-developer-agent-profile.sh` - compatibility wrapper for the first `agent-developer` profile.
- `scripts/render-infuseai-agents.sh` - renders the InfuseAI `agents-swarm` overlay with a supplied image repository/tag.
- `scripts/export-openclaw-cron-calendar.py` - calls the authenticated, paginated OpenClaw `cron.list` Gateway API and exports a complete cron snapshot for Backoffice Ritual Calendar ingestion; legacy `jobs.json` is explicit compatibility input only.
- `scripts/collect-openclaw-cron-calendar-feed.sh` - collects one complete Gateway-backed snapshot from every expected ready agent and updates the Backoffice ConfigMap only when the full fleet succeeds.
- `scripts/export-openclaw-agent-token-usage.py` - calls the authenticated OpenClaw `sessions.usage` Gateway API and exports fresh, sanitized daily/model/four-hour token totals for Backoffice ingestion; never reads private session storage or exports prompts, messages, tool args, session ids, costs, or secrets.
- `scripts/merge-openclaw-cron-calendar.py` - merges per-agent sanitized cron snapshots into one Backoffice-readable catalog when a directory mount is not convenient.
- `scripts/publish-kapiteky-artifact-registry.sh` - publishes Kapiteky artifacts through a short-lived, service-account-free pod with the producer-bound Secret and no public Registry route.
- `scripts/agent-local-drift-report.py` - reports local persona, skill, and daily-memory drift for one persistent agent without printing file contents.
- `scripts/agent-skill-proposal.py` - moves unmanaged local skills into a recoverable, non-discovered proposal tree and records content-free notification state.
- `scripts/collect-agent-skill-proposals.sh` - scans all persistent agents, sends one deduplicated Mattermost review alert through Satwa's configured account, and marks successful notifications.
- `scripts/export-agent-daily-memory.sh` - controlled runtime wrapper that exports one agent's local daily memory file into the `openclaw-agents-memory` checkout.
- `scripts/sync-agent-memory-repo.sh` - runtime helper that directly syncs one agent's own daily memory plus key workspace Markdown files into `openclaw-agents-memory`, normalizes curated `MEMORY.md` metadata, and blocks pushes when the archive IKF gate fails.
- `scripts/render-agent-memory.py` - deterministic IKF renderer for the curated top-level agent `MEMORY.md` selected by Library Atlas.
- `scripts/sync-agent-memory-repo-collector.sh` - cluster collector used by the daily `openclaw-agent-memory-sync` CronJob to run the raw sync helper across all running persistent agents.
- `scripts/install-emon-mission-steward-cron.sh` - idempotently installs Emon's registry-driven, silence-by-default mission steward through the live OpenClaw gateway.
- `scripts/install-emon-mission-steward-v2-candidate-cron.sh` - installs a
  disabled v2 steward candidate without migrating state or replacing the live
  v1 job.
- `scripts/install-emon-portfolio-review-candidate-cron.sh` - installs a
  disabled, allowlisted, proposal-only portfolio review candidate.
- `scripts/install-emon-mission-dispatcher-cron.sh` - compatibility alias for the retired broad dispatcher installer.
- `scripts/install-agent-intake-consulting-crons.sh` - idempotently installs Ramiro's consulting intake cron set through the live OpenClaw gateway: a cheap enabled mail preflight, disabled model triage that the preflight wakes only on change, and enabled client-waiting reminders unless explicitly disabled for soft rollout.
- `scripts/agent-intake-mail-prefilter.sh` - command-only mail preflight that checks unread consulting mail metadata and wakes the disabled model triage cron only when new candidates appear.
- `scripts/install-tailscale-operator.sh` - installs/updates the Tailscale Kubernetes Operator from the official Helm chart using OAuth credentials supplied through environment variables.
- `scripts/ensure-dashboard-gateway-token-secret.sh` - creates the shared OpenClaw gateway credential Secret if it does not already exist; the value is used as a token by ordinary agents and as the private local password fallback by Tinus/Stewie, and is never printed.
- `scripts/deploy-infuseai-agents.sh` - applies shared InfuseAI resources, then delegates persistent-agent promotion to the bounded fleet rollout plan.
- `scripts/rollout-persistent-agent-fleet.sh` - runs the developer canary, bounded parallel leaf wave, and coordinator-last promotion; supports a sequential fallback and preserved deployments.
- `scripts/rollout-and-verify-persistent-agent.sh` - combines one lifecycle-safe rollout with startup-log, immutable image/source, and skill-manifest verification.
- `scripts/rollout-persistent-agent.sh` - drains one live Gateway, preserves its single-writer PVC boundary, applies the target Deployment held at zero, and verifies the replacement before returning.
- `scripts/openclaw_gateway_lifecycle.py` - bounded OpenClaw Gateway prepare/status/renew/resume/handoff client used by deploys, backups, and pod `preStop`.
- `scripts/classify-persistent-agent-impact.py` - conservative changed-path classifier used with live pod-template source provenance to preserve persistent agents for platform-only deliveries.
- `scripts/backup-agent-workspace.sh` - drains and stops one agent, streams its PVC read-only through an isolated no-token pod with one bounded validation retry while omitting reproducible `node_modules` trees, restores the existing Deployment, then performs full extraction and SQLite integrity checks.
- `scripts/install-agent-persona.sh` - installs per-agent persona files into one agent workspace from the external `openclaw-agents-persona` checkout, preferring `agents/<agent-id>/` and then that repo's templates.
- `scripts/install-agent-skills.py` - copies or symlinks approved managed-copy
  skills, records runtime-native declarations, and removes native-ID workspace
  shadows.
- `scripts/verify-agent-runtime-skills.py` - verifies live OpenClaw discovery
  provenance, managed-copy presence, runtime-native eligibility, and absence of
  workspace shadows.
- `scripts/verify-agent-skill-manifest-parity.py` - applies the same fail-closed
  bundle-versus-active provenance contract used by mission capability export;
  live sync, fleet rollout, and runtime smoke all require it.
- `scripts/sync-agent-persona-startup.sh` - runtime entrypoint helper that clones or fast-forwards the `openclaw-agents-persona` checkout into the agent PVC and validates the external persona template pack.
- `scripts/sync-agent-skills-startup.sh` - runtime entrypoint helper that clones or fast-forwards Git-backed company skill sources into the agent PVC and refreshes approved skills at pod start.
- `scripts/sync-shared-agent-memory-startup.sh` - runtime entrypoint helper that clones or fast-forwards a scoped sparse `openclaw-agents-memory` checkout into the agent PVC for local search.
- `scripts/verify-shared-memory-sparse-checkout.sh` - local smoke test proving the shared memory checkout includes shared/project/own-agent memory and excludes other agents' raw memory by default.
- `scripts/sync-agent-skills-runtime.sh` - fast-forwards Git-backed skill sources,
  atomically syncs approved skills into one live InfuseAI agent PVC, verifies
  runtime provenance, and restores the previous directory on failure.
- `scripts/install-agent-runtime-files.sh` - installs persona files, approved skills, and repo task-workspace tools into one live InfuseAI agent PVC.
- `scripts/agent-task-workspace.py` - starts, creates, lists, inspects, and cleans isolated per-task repo checkouts under `/workspace/tasks/<task-id>/repos/<repo-name>`, and reads one exact file from a full commit through the same bundle policy; `repo_access.default_policy: "allow"` enables any non-denied repo name when the caller supplies the checkout URL.
- `scripts/agent-runtime-capabilities.py` - reports Docker/Compose, browser automation, ImageMagick composition, pnpm, and the ambient-runtime-versus-portable-artifact boundary without leaking probe output.
- `scripts/export-agent-capability-snapshot.py` - turns one sealed handoff plus reviewed bundle, exact skill manifest, task-registry capacity, and bounded runtime probe evidence into a task-scoped sanitized capability snapshot; no credential values, paths, commands, or raw errors are emitted.
- `scripts/verify-agent-evidence-package.py` - copies an evidence directory or ZIP into a temporary isolated path, rejects undeclared/unlocked Playwright and ungated pod paths, strips ambient Node resolution, runs ordered verification commands, and emits exact classified command evidence.
- `scripts/document-normalizer-client-launcher.sh` - thin fail-closed runtime
  launcher for the canonical client installed with the `document-normalizer`
  skill from `agent-skills`; this repo does not own the HTTP client logic.
- `scripts/onboard-agent-mattermost-bot.py` - creates/reuses one Mattermost bot, stores its token in Vaultwarden, and adds it to a channel.
- `scripts/render.sh` - renders key kustomize outputs to `/tmp`.
- `scripts/smoke-workspace.sh` - checks that `/workspace` persists across a deployment restart.
- `scripts/smoke-pvc-backup-restore.sh` - creates a tar backup of `/workspace`, deletes a marker, restores the backup, and verifies the marker returns.
- `scripts/smoke-agent-runtime.sh` - verifies one live InfuseAI persistent-agent rollout, PVC, profile, skills, and Mattermost channel status.
- `scripts/smoke-agent-knowledge-retrieval.mjs` - runs a canonical
  Discover-to-Fetch probe while printing only bounded mode/count/size-bucket
  metadata. `scripts/rollout-retrieval-agent-identity.sh` is the explicit,
  one-agent-at-a-time ServiceAccount migration guard with automatic identity
  rollback and peer-template protection.
- `scripts/smoke-agent-cron.sh` - verifies one live persistent-agent OpenClaw cron profile can list jobs through the gateway without auth mismatch failures.
- `scripts/smoke-agent-toolbox.sh` - verifies the shared CLI toolbox, Compose plugin, intentional daemonless container-build classification, real Playwright launch, and real ImageMagick contact-sheet composition inside one live persistent-agent pod.
- `scripts/smoke-agent-repo-checkout.sh` - verifies one live agent can create and clean an isolated GitLab repo checkout with its runtime Git credential.
- `scripts/smoke-agent-infra-kube-access.sh` - verifies Satwa Nutella bounded Kubernetes diagnostics access and denied secret reads from inside the pod.
- `scripts/status-agent.sh` - prints read-only state for one persistent-agent deployment.
- `scripts/review-agent-monitoring-evidence.py` - validates and summarizes the metadata-only, five-agent cross-backend acceptance package with governed claim states, alert-noise classification, drilldown order, and human-review-only recommendations.
- `scripts/agent-secret-get.sh` - source for the runtime
  `openclaw-agent-secret-get` command, delegating direct Vaultwarden item
  access to the agent account while enforcing project env-bootstrap resolver
  grants and supported lookup fields.
- `scripts/sync-agent-credential.sh` - generic bundle-enforced Vaultwarden-to-Kubernetes credential sync for one persistent agent.
- `scripts/sync-agent-mattermost-secret.sh` - Mattermost wrapper around generic credential sync for one persistent agent.
- `scripts/sync-agent-developer-mattermost-secret.sh` - compatibility wrapper for the first `agent-developer` Mattermost secret.
- `scripts/verify-agent-credential-sync.sh` - dry-runs all bundle-declared credential targets and a denied cross-agent sync.
- `scripts/verify-agent-direct-secret-lookup.sh` - verifies direct Vaultwarden lookup delegation and local field/project-grant guards without live secret reads.
- `scripts/verify-agent-task-workspace.sh` - proves two task workspaces for the same repo are isolated, task starts are registered, dirty cleanup is guarded, denied repos are refused, and arbitrary non-denied repos still require an explicit source URL.
- `scripts/verify-openclaw-agent-entrypoint.sh` - verifies startup setup and retirement of the legacy credential helper; GitLab bootstrap identity behavior has dedicated tests.
- `scripts/verify-agent-draft-sync.sh` - verifies local drift reporting and the daily memory export wrapper against a temporary runtime workspace.
- `scripts/verify-agent-persona-source.sh` - verifies per-agent persona source install, manifest metadata, memory preservation, and drift reporting.
- `scripts/verify-agent-skill-bundles.py` - validates the skill catalog, agent skill bundles, active-agent inventory, and bundle-to-runtime patch drift.

## Prompts

- `prompts/emon-mission-steward.md` - cron prompt for Emon's canonical-registry evaluator; it acts only on due or material mission events.
- `prompts/emon-mission-steward-v2.md` - disabled Phase 5 candidate using the
  complete v2 mission and next-action contract.
- `prompts/emon-portfolio-review.md` - disabled low-frequency portfolio
  discovery candidate; it proposes complete briefs and never activates work.
- `prompts/emon-mission-dispatcher.md` - compatibility notice for the retired broad dispatcher contract.
- `prompts/agent-intake-consulting-email-triage.md` - cron prompt for Ramiro's consulting email triage loop; it is strict about read-only intake, draft-only output, and `NO_REPLY` when quiet.
- `prompts/agent-intake-client-waiting-reminders.md` - cron prompt for Ramiro's consulting reminder loop; it surfaces only Infuse AI owed actions.

## Docs

- `docs/ARCHITECTURE.md` - target component model.
- `docs/CURRENT_STATE.md` - compact current truth for live agents, target namespace, verification, and source-of-truth files.
- `docs/SECURITY.md` - access, network, secret, and approval boundaries.
- `docs/SECRETS_ARCHITECTURE.md` - target secrets model: Vaultwarden source of truth, per-agent scoping, Kubernetes runtime materialization, and rotation.
- `docs/CREDENTIAL_ACCESS.md` - per-agent Vaultwarden access intent and runtime sync contract.
- `docs/ACCESS_REVIEW.md` - temporary runtime exceptions and cleanup/review triggers.
- `docs/AGENT_VAULTWARDEN_ACCOUNT_RUNBOOK.md` - manual setup for an agent Authentik user, Vaultwarden account/API client, collections, and Kubernetes bootstrap Secret.
- `docs/ROADMAP.md` - milestone-level plan.
- `docs/PHASED_PLAN.md` - phase tasks and exit criteria.
- `docs/TASKS.md` - lightweight current backlog.
- `docs/RUNBOOK.md` - operator commands.
- `docs/NEW_AGENT_RUNBOOK.md` - process for adding a persistent agent, using `agent-designer` as the example.
- `docs/RUNTIME_BOOTSTRAP.md` - historical ncase runtime boot and agent-developer profile flow.
- `docs/SKILL_MANAGEMENT.md` - skill source, catalog, bundle, and verification policy.
- `docs/AGENT_IDENTITIES.md` - persistent agent identity strategy.
- `docs/AGENT_DRAFT_SYNC.md` - v1 local draft detection, own daily-memory export, dogfood notes, and common operator runbooks.
- `docs/AGENT_PERSONA_DOGFOOD.md` - persona improvement backlog, runtime sync acceptance criteria, role context-pack gaps, and live dogfood loop.
- `docs/agents/README.md` - agent-doc contract, current roster, context-loading
  rule, reporting format, and live core-file sync checklist.
- `docs/AGENT_WORKER_READINESS_PLAN.md` - plan for turning live agents into bounded repo/Kubernetes workers.
- `docs/AGENT_VAULTWARDEN_ACCESS_PLAN.md` - plan for giving agents bounded credential access through Vaultwarden-backed runtime sync, without giving normal agents direct Vaultwarden login material.
- `docs/BACKOFFICE_COMMAND_CENTER.md` - Backoffice command-center plan for swarm status, access review, and human-triggered controls.
- `docs/BACKOFFICE_AGENT_CATALOG_FEED.md` - generated cross-repository agent
  configuration contract, provenance, privacy boundary, and failure behavior.
- `docs/BACKOFFICE_MISSION_CONTROL_FEED.md` - retirement record for the filesystem feed replaced by the authenticated Artifact Registry.
- `docs/TAILSCALE_AGENT_DASHBOARDS.md` - Tailscale-only dashboard exposure runbook and rollback path.
- `docs/MATTERMOST_INTERACTIONS_CALLBACK.md` - investigation notes and candidate fixes for Mattermost button/action callback routing.
- `docs/BACKOFFICE_RITUAL_CALENDAR_EXPORT.md` - sanitized OpenClaw cron snapshot contract for Backoffice Ritual Calendar ingestion.
- `docs/DECISIONS.md` - dated decisions and rationale.
- `docs/agents/` - per-agent access bundle docs; start with `docs/agents/README.md`.
- `docs/secrets/` - example secret contracts only; never commit real values.
- Persona files are intentionally not stored in this repo. The canonical source
  is the sibling `openclaw-agents-persona` repo: use
  `openclaw-agents-persona/agents/<agent-id>/` for existing agents and
  `openclaw-agents-persona/templates/agent-persona/` for new-agent scaffolding.

## Common Changes

- Change OpenClaw package version: use `OPENCLAW_VERSION=... task image-build` or `task image-push-agent`.
- Add a runtime env var: update the relevant secret example in `docs/secrets/`, then wire the Kubernetes env/secret reference.
- Add a new persistent agent: add `docs/agents/<agent>.md`, add `config/agent-skill-bundles/<agent>.json` including `credential_access`, add `docs/secrets/<agent>-mattermost.example.env`, add `k8s/agents/<agent>/` from the persistent-agent component, include it from `k8s/overlays/infuseai/kustomization.yaml`, dry-run `task verify-agent-skills`, `task verify-agent-credential-sync`, `AGENT_ID=<agent> task verify-agent-skill-install`, `AGENT_ID=<agent> task verify-agent-profile`, `AGENT_ID=<agent> task verify-agent-mattermost-secret`, `AGENT_ID=<agent> task verify-agent-persona`, and `AGENT_ID=<agent> task verify-agent-mattermost-bot`, enable `OPENCLAW_AUTO_SYNC_SKILLS=true` for Git-backed company skills, update `docs/AGENT_IDENTITIES.md`, and avoid broad credentials by default.
- Work through a new persistent agent end-to-end: start with `docs/NEW_AGENT_RUNBOOK.md`.
- Add repo, GitLab, Vaultwarden, or Kubernetes worker access to a live agent: start with `docs/GITLAB_AGENT_SOURCE_MIGRATION.md` and `docs/CREDENTIAL_ACCESS.md`, then update the relevant bundle's `repo_access` or `credential_access` section before runtime sync. Editable repo work must use per-task checkouts, not a shared repo folder.
- Add Backoffice visibility or control for agents: start with `docs/BACKOFFICE_COMMAND_CENTER.md`; for journal/artifact publishing also read `docs/BACKOFFICE_MISSION_CONTROL_FEED.md`; keep early slices read-only and never surface secret values.
- Add a verification command: prefer a `task` entry plus a short runbook note.
