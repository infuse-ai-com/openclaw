---
title: Backoffice Agent Model Policy Feed
description: Backoffice reads sanitized model-policy snapshots from a Kubernetes
  ConfigMap. The swarm runtime remains the source of truth for what each
  persistent agent should use by default.
type: policy
status: active
owner: team:agent-platform
tags:
  - policy
  - backoffice
  - agent
  - model
  - feed
---
# Backoffice Agent Model Policy Feed

Backoffice reads sanitized model-policy snapshots from a Kubernetes ConfigMap.
The swarm runtime remains the source of truth for what each persistent agent
should use by default.

## Source Of Truth

Repo policy lives at:

```text
config/agent-model-policies.json
```

Each agent entry declares:

- `model`: primary provider/model id, such as `openai/gpt-5.6-sol`;
- `fallbackModels`: optional ordered fallback list;
- `capacityFailurePolicy`: either one approved fallback or an explicit
  fail-closed decision;
- `thinkingDefault`: default thinking depth for agent runs;
- `reasoningDefault`: default reasoning visibility, currently `on`, `off`, or `stream`;
- `runtime`: OpenClaw agent runtime id, currently `codex`;
- `roleIntent`: human-readable reason for the assignment.

`scripts/verify-agent-model-policies.py` validates the policy and checks that
each Kubernetes `OPENCLAW_CONFIG_JSON` matches it.

## Kubernetes Feed

The InfuseAI overlay creates:

```text
core/configmap/openclaw-agent-model-policy-feed
agents-swarm/cronjob/openclaw-agent-model-policy-collector
```

The collector runs every 15 minutes by default. It execs into each running
persistent-agent pod, runs `openclaw-agent-model-policy-export`, and stores one
JSON snapshot per agent in the ConfigMap.

Backoffice should read the ConfigMap keys as `<agent-id>.json`.

## Snapshot Shape

Each file contains:

```json
{
  "schemaVersion": 1,
  "generatedAt": "2026-07-15T18:00:00+00:00",
  "source": {
    "type": "openclaw_agent_model_policy",
    "agentId": "agent-developer",
    "gatewayLabel": "Tinus Lordvals Gateway",
    "configPath": "~/.openclaw-agent-developer/openclaw.json",
    "status": "matches_declared"
  },
  "modelPolicy": {
    "observed": {
      "model": "openai/gpt-5.6-sol",
      "thinkingDefault": "high",
      "reasoningDefault": "stream",
      "runtime": "codex"
    },
    "declared": {
      "model": "openai/gpt-5.6-sol",
      "thinkingDefault": "high",
      "reasoningDefault": "stream",
      "runtime": "codex",
      "roleIntent": "Implementation, repo-local verification, code review, and release readiness."
    },
    "mismatchFields": []
  }
}
```

Backoffice should show `status=drift_detected` and list `mismatchFields` when
the live pod config does not match the repo-declared policy.

## Guardrails

- The feed is read-only for Backoffice.
- No provider credentials, OAuth profiles, API keys, prompts, memory, sessions,
  or token values are exported.
- Unknown or unsupported model ids are displayed as configured; live provider
  availability is still verified by the existing runtime smoke/model probes.
