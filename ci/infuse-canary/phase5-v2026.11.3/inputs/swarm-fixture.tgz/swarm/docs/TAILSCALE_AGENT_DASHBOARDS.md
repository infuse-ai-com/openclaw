---
title: Tailscale Agent Dashboards
description: This runbook exposes each persistent OpenClaw agent dashboard to
  trusted tailnet devices through the Tailscale Kubernetes Operator.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - tailscale
  - agent
  - dashboards
---
# Tailscale Agent Dashboards

The five persistent agents connect to `https://agents.infuse-ai.com` through
certificate-verified private Tailscale gateways. The central dashboard owns
Fito's OIDC admission; the swarm owns each agent's runtime and existing state.

## Design

- Each gateway listens on port `18791` with `--bind lan` and trusted-proxy
  authentication. Its backend Service is `ClusterIP`; the former direct L3
  token-auth path is retired because it cannot provide authenticated headers.
- The shared Secret `openclaw-agent-dashboard-gateway` is unchanged. Its existing
  `OPENCLAW_GATEWAY_TOKEN` key supplies `OPENCLAW_GATEWAY_PASSWORD` for local
  Studio connections. The browser relay never receives that secret.
- All five L7 Ingresses use `openclaw-agent-dashboard-ingress`. Gateways trust
  only its reviewed immediate source `10.1.42.208`, require forwarding headers,
  admit the dashboard origin and Fito's exact profile `aog.olea@gmail.com`.
  If that proxy source changes, verify its new identity and update the exact
  gateway configs through review; do not widen trust to a cluster CIDR.
- Device auto-approval is limited to `operator.sessions.read`,
  `operator.sessions.write`, `operator.read`, and `operator.write`. Fito's
  verified proxy identity receives `operator.admin` through `identityScopes`
  after browser pairing, subject to the central relay's connection scope cap.
  The separate self-only account relay retains its read/write cap and native
  account ownership checks.
- Dashboard NetworkPolicies allow gateway TCP `18791` only from the Tailscale
  namespace. No Tailscale ACL or public agent endpoint is introduced.
- Studio's four enrolled native roles retain their routes and identities; their
  loopback connections use the password fallback. Intake remains outside that
  Studio enrollment.

| Agent | Private TLS hostname |
| --- | --- |
| Tinus (`agent-developer`) | `openclaw-developer-dashboard.tailc4f8d5.ts.net` |
| Stewie (`agent-designer`) | `openclaw-designer-dashboard.tailc4f8d5.ts.net` |
| Emon Lusk (`agent-coordinator`) | `openclaw-coordinator-dashboard.tailc4f8d5.ts.net` |
| Ramiro Garcia (`agent-intake`) | `openclaw-intake-dashboard.tailc4f8d5.ts.net` |
| Satwa Nutella (`agent-infra`) | `openclaw-infra-dashboard.tailc4f8d5.ts.net` |

The dashboard repository owns the matching egress Services and exact operator
registrations. Its gateway IDs are `tinus`, `stewie`, `emon`, `ramiro`, `satwa`;
Studio's separate `swarm-*` enrollment IDs remain unchanged.

## Tailscale Prerequisites

In the Tailscale admin console:

1. Enable MagicDNS for the tailnet.
2. Add tag ownership for the operator and managed Kubernetes services:

```json
{
  "tagOwners": {
    "tag:k8s-operator": [],
    "tag:k8s": ["tag:k8s-operator"]
  },
  "autoApprovers": {
    "services": {
      "tag:k8s": ["tag:k8s"]
    }
  }
}
```

3. Create an OAuth client with write permissions for devices/auth keys and the
   `tag:k8s-operator` tag.
4. Restrict access to the dashboard service hostnames or `tag:k8s` Services in
   the tailnet policy to Fito's trusted users/devices first. Add collaborators
   only after the dashboard access model is reviewed.

For tailnets using grants, start with a narrow rule like this and replace the
`src` identities with the real trusted users, groups, or device tags:

```json
{
  "grants": [
    {
      "src": ["autogroup:admin"],
      "dst": ["tag:k8s"],
      "ip": ["tcp:80"]
    },
    {
      "src": ["autogroup:admin"],
      "dst": ["tag:k8s:*"],
      "ip": ["icmp:*"]
    }
  ]
}
```

Tailscale HA `ProxyGroup` ingress creates Tailscale Services for the Kubernetes
`LoadBalancer` Services. The dashboard VIPs are tagged as `tag:k8s` unless the
Kubernetes Service or Ingress sets a `tailscale.com/tags` annotation. The ICMP
grant to the ProxyGroup tag is currently required by Tailscale for HA service
access checks.

## Install Operator And Dashboard Secret

Run from the repo root with `KUBE_CONTEXT=infuseai-k8s` selected or exported in
your environment as appropriate.

```bash
export TS_OAUTH_CLIENT_ID='...'
export TS_OAUTH_CLIENT_SECRET='...'

scripts/install-tailscale-operator.sh
scripts/ensure-dashboard-gateway-token-secret.sh
```

The scripts do not print secret values. Do not store Tailscale OAuth client
credentials in this repo.

## Deploy

The normal `k8s/overlays/infuseai` overlay now includes the dashboard Services,
Ingresses, and NetworkPolicies. After the operator and gateway token secret exist, deploy
through the normal Azure pipeline or render/apply flow.

Manual render check:

```bash
kubectl kustomize k8s/overlays/infuseai >/tmp/openclaw-k8s-swarm-infuseai.yaml
```

Live status:

```bash
kubectl -n agents-swarm get ingress,svc '*-dashboard'
kubectl -n tailscale get pod
```

Access all five agents through `https://agents.infuse-ai.com`. Their private TLS
ingresses require the central relay's authenticated identity headers and are
not direct browser entry points.

For the three-agent addition, prepare resource-version-guarded patches against
live Deployments. Change only gateway auth/trust/origin, the gateway password
environment reference, and Studio's loopback auth field where present. Preserve
routes, all other config, replicas and PVCs; roll the three agents one at
a time. Their qualified image must include the five-agent trusted-proxy boot
selection: older images hardcode coordinator/intake/infra to token auth. Keep
the OpenClaw version pinned at 2026.11.1 and leave Tinus/Stewie images unchanged. The image-only GitLab rollout does not materialize these settings.
Qualify the private TLS paths and browser connections before registering the
three agents in the dashboard. Existing Tinus and Stewie workloads are unchanged.

## Fito's My Accounts Pilot

The central dashboard's **My accounts** flow uses a separate, self-only relay
for native personal model-account operations. It needs `operator.read` and
`operator.write` in addition to the two existing session scopes on all five
agents. This relay remains limited to the authenticated person's model
accounts even when their native gateway administration is enabled. Keep
`allowUsers` limited to `aog.olea@gmail.com`.

No `gateway.roles` configuration is needed. Keep it absent: the requested
device scopes and relay cap authorize the self-account operations, while the
authenticated identity and native account ownership checks determine whose
accounts are accessible. Partner admission remains a separate decision.

Verify the repository contract before any rollout:

```bash
python3 -m unittest discover -s tests -p 'test_dashboard_tls_ingress.py'
python3 scripts/verify-agent-skill-bundles.py
```

The scopes are bootstrapped from each Deployment's `OPENCLAW_CONFIG_JSON`.
An in-process gateway configuration update alone is not a durable replacement
for that source change. The current GitLab image rollout patches image and
provenance fields only; it does not apply these configuration values. Prepare
the authorized operator update against the current Deployment resource versions
and prove that only the intended gateway configuration changes. Full-manifest rollout helpers
require a rendered/live comparison because they can replace unrelated settings.
Preserve the live image digests and all other workload settings, then verify
account login separately through `https://agents.infuse-ai.com`.

## Fito's Native Gateway Administration

Fito approved full native OpenClaw administration on all five gateways. Each
Deployment adds this identity-specific grant to its existing gateway auth:

```json
{
  "identityScopes": {
    "aog.olea@gmail.com": ["operator.admin"]
  }
}
```

The exact key is the existing trusted-proxy identity forwarded by the dashboard.
The dashboard continues to admit Fito by the immutable OIDC issuer and subject,
then maps that person to this explicit transport alias. Preserve the alias and
canonical profile IDs during this configuration change. The display name and
verified Mattermost channel-identity link are separate native profile operations;
neither a display-name match nor a Mattermost handle is an authorization grant.

The qualified OpenClaw runtime unions `identityScopes` with the approved browser
device scopes after pairing, then intersects that union with the trusted
`x-openclaw-scopes` header. The dashboard must enable `operator.admin` in the
Fito-only chat/admin connection cap and expose the reviewed native methods and
events. Until that dashboard change is deployed, its existing session-only cap
continues to limit the connection. My accounts keeps its separate read/write
cap. An existing paired browser can keep its present device grant; adding admin
to `deviceAutoApprove.scopes` or requesting a browser-device scope upgrade is not
part of this migration.

Gateway administration covers native configuration, tools/skills, devices and
people. Infrastructure access remains governed by its existing Kubernetes and
credential boundaries. Studio-managed session access stays under the dashboard's
custody checks, and Studio's existing loopback password connections remain
unchanged.

### Configuration migration and verification

1. Run the repository checks below and review the five parsed configuration
   deltas. The only runtime-config delta must be
   `gateway.auth.identityScopes["aog.olea@gmail.com"] = ["operator.admin"]`.
2. Materialize that same delta into each live Deployment's
   `OPENCLAW_CONFIG_JSON` using a fresh resource-version guard. Preserve live
   image digests, other config, replicas, PVCs, the device auto-approval scopes,
   Mattermost sender ownership and Studio local credentials. The image-only
   GitLab rollout does not apply this configuration.
3. Roll the affected gateways one at a time through the authorized runtime
   workflow, then reconnect the dashboard. Verify the existing Fito profile ID,
   effective `hello.auth.scopes` containing `operator.admin` on the chat/admin
   connection, and successful native administration. Verify the separate account
   connection still has only its read/write scope cap and managed sessions stay
   excluded. The configuration checks alone do not prove live relay behavior.

```bash
python3 -m unittest discover -s tests -p 'test_dashboard_tls_ingress.py'
python3 scripts/verify-agent-skill-bundles.py
task render
task knowledge:verify
```

To reverse this grant, remove only the new `identityScopes` mapping through an
MR and apply that exact change to the current live configuration with the same
resource-version guard. Restart the affected gateway through the authorized
workflow so retained privileged connections close, then reconnect and verify
that effective scopes no longer contain `operator.admin`. Keep paired devices,
profile IDs, conversations, Mattermost links and Studio enrollment intact.

## Rollback

To remove dashboard exposure without touching agent PVCs:

```bash
kubectl -n agents-swarm delete ingress \
  agent-developer-dashboard \
  agent-designer-dashboard \
  agent-infra-dashboard \
  agent-intake-dashboard \
  agent-coordinator-dashboard

kubectl -n agents-swarm delete svc \
  agent-developer-dashboard \
  agent-designer-dashboard \
  agent-infra-dashboard \
  agent-intake-dashboard \
  agent-coordinator-dashboard

kubectl -n agents-swarm delete networkpolicy \
  agent-developer-dashboard-ingress \
  agent-designer-dashboard-ingress \
  agent-infra-dashboard-ingress \
  agent-intake-dashboard-ingress \
  agent-coordinator-dashboard-ingress
```

Then revert or redeploy a manifest that binds gateways back to loopback if
tailnet dashboard access is being retired.
