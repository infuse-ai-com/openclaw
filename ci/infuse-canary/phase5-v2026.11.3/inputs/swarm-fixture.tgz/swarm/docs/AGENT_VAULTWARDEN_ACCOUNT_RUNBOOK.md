---
title: Agent Vaultwarden Account Runbook
description: This runbook describes the manual setup needed to give one
  persistent agent a dedicated Vaultwarden account for account-authoritative
  direct lookup. It started with the agent-coordinator pilot and now applies to
  approved persistent agents.
type: runbook
status: active
owner: team:agent-platform
tags:
  - runbook
  - agent
  - vaultwarden
  - account
---
# Agent Vaultwarden Account Runbook

This runbook describes the manual setup needed to give one persistent agent a
dedicated Vaultwarden account for account-authoritative direct lookup. It started with
the `agent-coordinator` pilot and now applies to approved persistent agents.

Use this only for agents explicitly approved for direct Vaultwarden lookup.
Agents still receive startup/bootstrap credentials through bundle-declared
Kubernetes Secrets.

## Target Shape

For agent `<agent-id>`:

- Authentik owns identity lifecycle and app access.
- Vaultwarden owns organization membership, collections, and item access.
- Kubernetes Secret `<agent-id>-vaultwarden` contains only Vaultwarden
  bootstrap material.
- `scripts/agent-secret-get.sh` uses the fixed runtime bundle for agent identity
  and project materialization checks, then delegates direct item authorization
  to the agent's Vaultwarden account and collection membership.

Example:

```text
Agent id: agent-coordinator
Vaultwarden user: agent-emon-lusk@infuse-ai.com
Vaultwarden auth Secret: agents-swarm/agent-coordinator-vaultwarden
API client item: Vaultwarden / agent-coordinator oauth api client
Unlock/login item: Vaultwarden / agent-coordinator login
```

Never paste API client secrets, master passwords, `BW_SESSION`, full item JSON,
or Kubernetes Secret YAML into chat or docs.

## Manual Authentik Setup

1. Create a normal Authentik user for the agent.

   Use a real email claim. Vaultwarden requires an email-bearing user for SSO.
   Do not use an Authentik service account as the Vaultwarden login identity.

   Example:

   ```text
   username: agent-emon-lusk
   email: agent-emon-lusk@infuse-ai.com
   ```

2. Give the user access to the Vaultwarden application.

   Add the user to the same Authentik group or policy path that grants
   Vaultwarden app access. Use a narrow agent-specific group if available.

3. Set or store the login/unlock password.

   Save it in Vaultwarden as an item named:

   ```text
   Vaultwarden / <agent-id> login
   ```

   For Emon:

   ```text
   Vaultwarden / agent-coordinator login
   ```

   The item login username should be the agent email. The item login password is
   the value used by `bw unlock` as `BW_PASSWORD`.

## Manual Vaultwarden Setup

1. Log in as the agent at the company Vaultwarden endpoint.

   ```text
   https://vault.infuse-ai-tech.party
   ```

   Use the Authentik-backed account so Vaultwarden creates the user.

2. Invite or confirm the agent user in the `Infuse AI` organization.

   Confirm the member reaches accepted status before assigning collections.

3. Create narrow agent-only collections.

   Use stable names that match the agent bundle.

   Current persistent-agent collections:

   ```text
   51-Agent-Emon-Lusk
   52-Agent-Stewie-Hobs
   53-Agent-Tinus-Lordvals
   54-Agent-Satwa-Nutella
   55-Agent-Ramiro-Garcia
   ```

4. Assign the agent user to those collections.

   Recommended permissions:

   ```text
   readOnly=true
   hidePasswords=false
   manage=false
   ```

   `hidePasswords=true` is not a reliable automation boundary because the agent
   must retrieve values programmatically. Use narrow collections as the direct
   lookup boundary; Git declarations apply only to persistent sync and project
   materialization.

5. Create the agent's Bitwarden personal API key item.

   Log in as the agent and generate/copy the personal API key. Store it in
   Vaultwarden as:

   ```text
   Vaultwarden / <agent-id> oauth api client
   ```

   For Emon:

   ```text
   Vaultwarden / agent-coordinator oauth api client
   ```

   Store it as a login item:

   ```text
   login.username = Bitwarden client id, usually user.<uuid>
   login.password = Bitwarden client secret
   ```

   Custom fields named `BW_CLIENTID` and `BW_CLIENTSECRET` are also supported,
   but the login username/password shape is preferred for this pilot.

6. Put only approved task items into the agent-only collections.

   Either move the existing item into the agent collection or duplicate the
   access intent through a separate agent-specific item. Do not grant broad
   project collections unless the agent should enumerate/read all items in that
   collection.

## Repo Setup

1. Update the agent bundle.

   Edit:

   ```text
   config/agent-skill-bundles/<agent-id>.json
   ```

   No direct-lookup bundle entry is required. Vaultwarden's account and
   collection membership are authoritative for direct reads. Keep
   `credential_access.vaultwarden.allowed_items` only for runtime secret sync
   and project materialization paths that create persistent copies.

2. Verify the bundle and direct lookup delegation.

   ```bash
   task verify-agent-skills
   task verify-agent-direct-secret-lookup
   ```

3. Update docs if a new agent is enabled.

   At minimum update:

   - `docs/CREDENTIAL_ACCESS.md`
   - `docs/ACCESS_REVIEW.md`
   - `docs/agents/<agent-id>.md`

4. Extend the sync allowlist for a new agent.

   `scripts/sync-agent-vaultwarden-auth.sh` explicitly supports the five
   persistent agents. Before enabling another agent, add it to the script's
   approved list and add or update the corresponding Taskfile wrapper so the
   Kubernetes Secret name is explicit and reviewable.

## Kubernetes Bootstrap Secret

The runtime Secret is env-only bootstrap material. It is not the application
secret being retrieved.

For Emon, the existing deployment consumes:

```text
agents-swarm/agent-coordinator-vaultwarden
```

The expected keys are:

```text
OPENCLAW_BW_SERVER
BW_CLIENTID
BW_CLIENTSECRET
BW_PASSWORD
```

`BW_PASSWORD` is the Vaultwarden unlock password from
`Vaultwarden / <agent-id> login`.

Dry-run render for the approved agent:

```bash
task verify-agent-vaultwarden-auth
```

Live sync for the approved agent:

```bash
task sync-agent-vaultwarden-auth
```

If the agent uses non-default item names:

```bash
VAULTWARDEN_AUTH_ITEM_NAME="Vaultwarden / <agent-id> oauth api client" \
VAULTWARDEN_UNLOCK_ITEM_NAME="Vaultwarden / <agent-id> login" \
task sync-agent-vaultwarden-auth
```

For Emon, defaults are already wired to `Vaultwarden / agent-coordinator oauth
api client` and `Vaultwarden / agent-coordinator login`.

## Rollout

Because the bootstrap Secret is consumed through `envFrom`, changing the
bootstrap Secret requires one pod rollout for the agent to see new env values.
Normal Vaultwarden target item rotations should not require a pod restart;
`scripts/agent-secret-get.sh` runs `bw sync` before each lookup.

On each `openclaw-agent` container start, the entrypoint prewarms the
Bitwarden CLI profile when `OPENCLAW_BW_PREWARM=true` (default): configure the
Vaultwarden server, reuse a persisted session when present, run API-key login
when the profile is unauthenticated, unlock with the approved bootstrap
password, persist only `$OPENCLAW_BW_DATA/session` with `0600`, and run
`bw sync`. Set `OPENCLAW_BW_PREWARM_REQUIRED=true` only for agents that should
fail startup when Vaultwarden cannot be unlocked.

Roll one agent only:

```bash
kubectl --context infuseai-k8s -n agents-swarm rollout restart deployment/<agent-id>
kubectl --context infuseai-k8s -n agents-swarm rollout status deployment/<agent-id> --timeout=180s
```

Verify readiness:

```bash
kubectl --context infuseai-k8s -n agents-swarm get deploy <agent-id>
kubectl --context infuseai-k8s -n agents-swarm logs deployment/<agent-id> --tail=80
```

Do not print Secret values while debugging.

## OpenAI/Codex OAuth Refresh For One Agent

Use this flow when an agent is Mattermost-connected but model-backed turns fail
with OpenAI/Codex OAuth errors such as `refresh_token_reused`, expired OAuth, or
missing bearer auth. This is credential maintenance for one persistent agent,
not a normal image rollout step.

Important model-auth shape:

- Vaultwarden and Kubernetes Secrets can hold bootstrap material and approved
  credential pointers.
- The live OpenAI/Codex OAuth refresh state can also live in the agent's
  per-agent PVC SQLite auth store.
- Replacing a Vaultwarden item or a Kubernetes env Secret alone does not repair
  a stale refresh token already persisted in that SQLite store.
- Do not copy one agent's refreshed OAuth state to another agent. If we keep
  OAuth instead of API keys, treat the auth store as per-agent state.

### Diagnose Without Printing Secrets

Check the target agent first, then compare any "known good" agent with the same
commands. Healthy deployment and Mattermost connection are not enough; run a
model-auth probe.

```bash
agent=agent-coordinator

kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
  sh -lc 'openclaw --profile "${OPENCLAW_AGENT_PROFILE:-$AGENT_ID}" models status'

kubectl --context infuseai-k8s -n agents-swarm logs "deploy/${agent}" --tail=200 | \
  rg 'refresh_token_reused|Missing bearer|OAuth|model auth|models status' || true
```

If a direct probe is needed, run it from the pod/profile and keep the prompt
harmless. Do not paste OAuth URLs, callback URLs, refresh tokens, or SQLite
contents into Mattermost or Git.

### Preserve The Existing Agent Auth Store

Before changing auth state, identify the actual auth database path and copy it
inside the same PVC with a timestamped backup name.

```bash
agent=agent-coordinator
stamp="$(date -u +%Y%m%dT%H%M%SZ)"

kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
  sh -lc '
    set -euo pipefail
    find /workspace -name openclaw-agent.sqlite -type f -print
  '
```

Pick the path for the target agent only, then back it up:

```bash
auth_db=/workspace/.openclaw-state/agents/agent-coordinator/openclaw-agent.sqlite

kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
  sh -lc "cp '${auth_db}' '${auth_db}.backup-${stamp}-oauth-stale'"
```

Keep those backups on the PVC until the refreshed agent has survived at least
one normal scheduled/background turn.

### Refresh Only The Target Agent

Preferred operator shape:

1. Stop or avoid concurrent model turns for the target agent during maintenance.
2. Perform the OpenAI/Codex login against the target agent's profile/auth store,
   not Kapiteky's main profile and not another agent's profile.
3. Use a private/local browser flow, Tailscale path, or `kubectl port-forward`
   only as transport for the auth callback. Transport does not fix stale OAuth;
   it just lets the correct profile complete login.
4. If a maintenance pod or local staging profile is used, copy back only the
   refreshed SQLite auth database for the target agent after backing up the old
   database.
5. Restart only the target deployment.

Example rollout after the auth DB has been refreshed:

```bash
kubectl --context infuseai-k8s -n agents-swarm rollout restart "deployment/${agent}"
kubectl --context infuseai-k8s -n agents-swarm rollout status "deployment/${agent}" --timeout=180s
```

Do not update the shared `openclaw-runtime` auth bridge as part of a one-agent
repair. For the historical Emon fix, `agent-coordinator` stayed isolated through
`agent-coordinator-openclaw-runtime`, and only Emon's PVC auth SQLite was
replaced.

### Verify The Repair

Run the same checks on the repaired agent and one comparison agent:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec "deploy/${agent}" -c agent -- \
  sh -lc 'openclaw --profile "${OPENCLAW_AGENT_PROFILE:-$AGENT_ID}" models status --probe'

AGENT_ID="${agent}" task smoke-agent-runtime

kubectl --context infuseai-k8s -n agents-swarm logs "deploy/${agent}" --since=15m | \
  rg 'refresh_token_reused|Missing bearer|OAuth failure|model auth' && \
  { echo "OAuth errors still present" >&2; exit 1; } || true
```

For `agent-coordinator`, also watch the next scheduled/background turn. The
original failure surfaced there because Emon exercised model auth more often
than quieter worker agents.

## Smoke Test

From a trusted operator shell, prove the path without printing returned values:

```bash
AGENT_ID=<agent-id> \
VAULTWARDEN_ITEM_NAME="<known item visible to this agent account>" \
CREDENTIAL_SOURCE_FIELD=username \
scripts/agent-secret-get.sh >/dev/null
```

Then check the password field similarly:

```bash
AGENT_ID=<agent-id> \
VAULTWARDEN_ITEM_NAME="<known item visible to this agent account>" \
CREDENTIAL_SOURCE_FIELD=password \
scripts/agent-secret-get.sh >/dev/null
```

Also prove a denied field fails:

```bash
if AGENT_ID=<agent-id> \
  VAULTWARDEN_ITEM_NAME="<known item visible to this agent account>" \
  CREDENTIAL_SOURCE_FIELD=totp \
  scripts/agent-secret-get.sh >/tmp/agent-vaultwarden-denied.out 2>&1; then
  echo "Expected denied lookup to fail" >&2
  exit 1
fi
```

For a Docker-fallback smoke, add:

```bash
OPENCLAW_BW_FORCE_DOCKER=1
```

## Cleanup And Narrowing

After the first live proof:

1. Remove the agent from broad project collections if it only needs
   agent-specific collections.
2. Move or duplicate only approved items into the agent-only collections.
3. Rerun the direct lookup smoke.
4. Update `docs/ACCESS_REVIEW.md` with the current exception status.
5. Rotate the API client if the bootstrap material was exposed during setup.

If the pilot is stopped:

1. Disable the Authentik user or remove Vaultwarden app access.
2. Remove the Vaultwarden org member or collection assignments.
3. Delete `agents-swarm/<agent-id>-vaultwarden`.
4. Rotate any item the agent could read.
