---
title: Agent observability runtime
description: Runtime contract, secret boundary, verification, and rollback procedure for the OpenClaw OTel canary.
type: runbook
status: active
owner: team:agent-platform
tags:
  - runbook
  - observability
  - opentelemetry
  - openclaw
  - kubernetes
---

# Agent Observability Runtime

## Fleet scope

The proven runtime slice enables metadata-only diagnostics for all five
persistent agents. Each agent
exports OTLP/HTTP traces and native metrics to `openclaw-otel-collector` in
`agents-swarm`. The diagnostics plugin's duplicate log exporter is disabled;
ordinary application logs continue through the existing promtail/Loki path.
This prevents structured diagnostic copies from introducing absolute paths or
other attributes forbidden by the telemetry contract.

The collector is pinned to the official OpenTelemetry Collector Contrib
`0.159.0` multi-platform digest. It applies memory limiting, explicit content
attribute deletion, an exact allowlist for resource attributes, bounded
tail-sampling state, tool-name normalization, bounded batching,
span-derived metrics, and isolated backend routing. Process, host, command-line,
and other SDK-added resource
attributes are removed before both trace and metric export. The collector keeps
every meaningful trace after the five-second tail decision. The three one-span
Gateway RPC envelope families (`handler`, `dispatch`, and `response`) and the
one-span `openclaw.diagnostic.phase` lifecycle markers are excluded only from
the Langfuse branch; they continue through the independent span-metrics branch
so fleet RPC and diagnostic-phase volume remain available in Prometheus.
Sampling changes beyond this exact noise allowlist require a separate reviewed
rollout.

The span-metrics connector's default `collector.instance.id` dimension is
excluded because this deployment has exactly one collector replica. This
prevents every collector restart from creating a fresh metric series while the
deployment-level single-writer contract is enforced by Kubernetes.

The standalone behavioral plugin creates one curated metadata-only trace for
each agent run. Public `llm_input` starts `infuse.agent.turn` plus an
`infuse.model.call` child; workflow, tool, skill, wrapper, and Knowledge Base
spans use the turn root as parent; `agent_end` closes the tree. The public
`runId` is only a bounded in-memory lookup key and is never exported. Provider
and model are bounded trace attributes and intentionally are not metric labels.

This curated trace is separate from the official OpenClaw diagnostic trace.
The exact pinned Codex adapter does not expose the official OTel context on its
public lifecycle/tool hooks, so reparenting native diagnostic spans would
require a custom artifact change. Official metrics remain canonical for fleet
run/tool count, outcome, and duration; the curated trace is an operational
drilldown and requires no OpenClaw or Codex rebuild. It must never replace an
official total merely because it contains fewer errors. A controlled fleet
acceptance proved a parentless curated root, attached children, one integrity
summary, and no dangling or duplicate child spans. Treat this topology as an
operational drilldown; official run and tool signals remain canonical for
totals.

## Monitoring truth and comparison boundary

`config/observability/telemetry-contract.v1.json` is executable authority for
which signal owns each monitoring claim:

| Claim | Canonical signal | Drilldown signal |
| --- | --- | --- |
| Run count, outcome, duration | `openclaw.run` | `infuse.agent.turn` |
| Tool count, outcome, duration | `openclaw.tool.execution` | `infuse.tool.execution` |
| Workflow lifecycle | `infuse.workflow.phase` | same explicit semantic signal |
| Skill lifecycle | `infuse.skill.execution` | same explicit semantic signal |
| Wrapper lifecycle | `infuse.wrapper.execution` | same explicit semantic signal |
| Knowledge retrieval lifecycle | `infuse.knowledge.retrieve` | same explicit semantic signal |
| Mission transition | `infuse.mission.transition` | same explicit semantic signal |
| Task transition | `infuse.task.transition` | same explicit semantic signal |
| Orchestration event intake/wake | `infuse.orchestration.event` | same explicit semantic signal |

Every comparison must segment by agent, environment, immutable image revision,
OpenClaw runtime revision, skill-bundle revision, rollout boundary, and traffic
source. Use `unavailable` when traffic attribution has not been instrumented;
do not silently combine it with attributed traffic. When official and curated
run/tool signals disagree, surface both values and the discrepancy.

Mission telemetry is intentionally split between bounded operational metrics
and exact durable evidence. Prometheus may label only the reviewed phase,
state, role class, outcome, actor/trigger class, wait/verification category,
event kind, producer class, wake outcome, rejection code, traffic source, and
correlation state enums. Mission, task, event, user, channel, post, repository,
and pull-request identifiers are forbidden attributes and labels. A joined
trace may carry only `correlation_ref`, a one-way 64-character lowercase
SHA-256 reference that is never a metric label. When that value cannot be
propagated safely, emit `correlation_state=unavailable`; never infer a join from
timestamps or agent names. Exact mission review joins the trace reference to
canonical registry/event evidence outside Prometheus.

Contract v1.10.0 declares these three signals and their rejection boundary. The
agent image packages the T4.2 validator/emitter and event intake invokes it only
after a durable outcome. Emission remains inert unless
`OPENCLAW_MISSION_OBSERVABILITY_ENABLED` is exactly `true` and a reviewed OTLP
endpoint is configured. Missing, invalid, slow, or unavailable telemetry never
changes a mission transition or intake result. Until that separate activation,
dashboards must render mission semantics as unavailable rather than infer them
from existing run/tool telemetry.

The packaged read-only T4.4 review joins an exported canonical v2 mission
snapshot to the durable event inbox using exact mission/task identifiers in
memory, then discards those identifiers from its output. It reports only
one-way correlation references, bounded verified/inconclusive reasons, source
revisions/hashes, aggregate lifecycle timings, pending/stuck counts, and
evidence completeness:

```bash
openclaw-mission-outcome-review \
  --mission-snapshot /path/to/team-missions-v2.snapshot.json \
  --event-inbox /path/to/mission-event-inbox/inbox.json \
  --at 2026-09-01T12:00:00Z
```

An outcome is `verified` only when the mission is done, every required task is
verified with independent verification evidence, required gates are resolved,
independently verified closeout evidence exists, the exact task event sequence
is complete, and no accepted event remains pending. Missing or mismatched
evidence is `inconclusive`. Task lifecycle durations pair events only after an
exact task-identity join; timestamp proximity is never correlation proof.
Blocked duration remains unavailable because the v1 event contract does not
record a complete unblock boundary.

The collector projects the bounded official run dimensions `openclaw.outcome`,
`openclaw.errorCategory`, `openclaw.channel`, `openclaw.provider`, and
`openclaw.model` into Prometheus. `openclaw.errorCategory` is the runtime's
low-cardinality JavaScript error class, not a root-cause taxonomy. In the
pinned canary, settled-turn finalization failures therefore appear as the
generic category `Error`; operators must use the bounded Loki count view to
distinguish that stable system failure signature. Dashboards and alerts must
never infer a more specific cause from `Error`.

Reproduce the accepted aggregate-only twelve-hour baseline with:

```bash
task verify-agent-monitoring-baseline
python3 scripts/audit-agent-monitoring-aggregates.py \
  --assert-frozen-baseline
```

The checked-in snapshot contains counts, bounded failure categories, immutable
revision identifiers, and fleet identities only. The audit rejects unexpected
fields, content-shaped keys/values, cross-revision segments, signal-authority
drift, and incomplete fleet segmentation. It deliberately reports missing
official run-by-agent, historical skill-bundle revision, and traffic-source
segmentation as gaps rather than inventing attribution.

For a current bounded Langfuse window, resolve the project-scoped credentials
into environment variables and run:

```bash
task audit-agent-observability-live \
  START=2026-10-08T20:30:00Z \
  END=2026-10-15T20:30:00Z
```

The live command emits aggregate counts only. It discards trace/tool-call
identifiers, status text, inputs, and outputs, and reports any non-empty
observation content as a privacy failure count rather than reproducing it.

Every correlated tool span contains only `tool_name`, `outcome`, and bounded
`duration_ms`. Failed calls add only `failure_category` and
`classification_source`. Structured result fields take precedence; error or
result text is inspected only in process memory, stops at 4096 characters, and
is discarded. The closed categories are `aborted`,
`authentication_unavailable`, `authorization_denied`,
`dependency_unavailable`, `invalid_input`, `nonzero_exit`, `parse_failure`,
`permission_denied`, `policy_denied`, `protocol_conversion`, `runtime_error`,
`timeout`, `unknown`, `upstream_contract_mismatch`, and
`upstream_unavailable`. Official OpenClaw tool metrics remain the canonical
fleet totals; this signal is the trace-correlated behavioral view. Before
Langfuse export and span-metric projection, the collector strips the generated
`openclaw` prefix from dynamic-tool aliases in both official
`openclaw.toolName` and curated `tool_name` attributes. For example,
`openclawmessage` and `message` become one canonical `message` series.
The static shell alias `bash` is then normalized to `exec` on both surfaces so
the official and curated tool populations share one name.
Both canonical attributes are explicit span-metrics dimensions, so official
volume/outcome/duration and curated classification can be reconciled by agent
and tool instead of collapsing official evidence into an unlabeled total.
The standalone behavioral plugin also suppresses repeated public-hook delivery
for the same bounded in-memory `toolCallId` and semantic scope. The identifier
is never exported. Events without a usable call ID fail open and are emitted;
the collector normalization remains a defense-in-depth canonicalization step.

## Curated trace integrity and anomaly contract

The plugin-owned `infuse.agent.turn` root always starts from `ROOT_CONTEXT` and
is therefore parentless. Model, tool, workflow, skill, wrapper, Knowledge Base,
integrity, and anomaly spans are created only beneath that active root. The
official OpenClaw trace stays a separate diagnostic surface; the plugin does
not borrow an official parent context or fabricate cross-trace ancestry.

Each closed curated turn emits one `infuse.trace.integrity` summary with only
bounded enums for integrity, root, parent, child, and closure state. An attempted
child without an active curated root is not exported as a dangling child; a
standalone metadata-only integrity issue records the prevented orphan instead.
Run and tool-call identifiers remain in bounded process memory only and are
never attributes or metric labels. Normal completion, terminal error, eviction,
shutdown, and start failure are distinct closure states.

`infuse.turn.anomaly` is emitted once per qualifying turn/category using these
fixed thresholds:

- slow turn: at least 60,000 ms;
- excessive tools: at least 50 curated tool executions;
- repeated failures: at least 3 failed curated child operations;
- incomplete turn: eviction, shutdown, or start failure; and
- large trace: at least 100 curated child spans before summaries/anomalies.

Prometheus exposes root, valid-summary, missing-parent, orphan-child,
duplicate-child, incomplete-turn, anomaly, and integrity-coverage recording
rules. The span-metrics connector keeps exemplars enabled. Grafana maps only
the exemplar `trace_id` to the approved `openclaw-agents-swarm` Langfuse
project; trace IDs are not time-series labels and no run/session ID is exported.

## Credential contract

The collector exports privacy-filtered spans to the internal Langfuse v4 OTLP
endpoint and continues to project Prometheus span metrics independently. The
Langfuse exporter sends `x-langfuse-ingestion-version: 4`, so observations use
the v4 real-time write/read path rather than the retired legacy ingestion API.

The collector, not the agent, owns backend authentication. Before deployment,
an authorized operator must create or sync this exact runtime contract through
the approved Vaultwarden-to-Kubernetes path:

- Namespace: `agents-swarm`
- Secret name: `openclaw-observability-exporters`
- Key: `LANGFUSE_OTEL_AUTH_HEADER`
- Consumer: `Deployment/openclaw-otel-collector` only
- Vaultwarden public-key source:
  `Langfuse / Openclaw agents swarm project [Public Key]`
- Vaultwarden secret-key source:
  `Langfuse / Openclaw agents swarm project [Secret Key]`
- Required Langfuse project ID: `openclaw-swarm`
- Required Langfuse project name: `OpenClaw Agents Swarm`

Validate and sync the source without exposing either Langfuse key or the
derived authorization header:

```bash
python3 scripts/sync_agent_observability_secret.py verify
python3 scripts/sync_agent_observability_secret.py apply --context infuseai-k8s
```

The helper verifies the project-scoped key pair against Langfuse before
rendering or applying the one-key Kubernetes Secret. A valid pair for another
project fails closed. After changing the Secret, restart only
`Deployment/openclaw-otel-collector`; agent pods do not consume Langfuse
credentials and do not need to roll.

The exporter target is
`http://langfuse-web.langfuse.svc.cluster.local:3000/api/public/otel`; the
collector appends the OTLP trace path. The `agents-swarm` namespace does not
apply an egress-isolating NetworkPolicy to the collector, so no cross-namespace
egress rule is required for this internal Service. If an egress default-deny
policy is introduced later, its reviewed rule must allow DNS plus TCP/3000 to
the `langfuse-web` pods in namespace `langfuse`.

Do not place the value in Git, shell arguments, Mattermost, build variables,
agent configuration, or evidence logs. The Secret must not be mounted into an
agent pod.

## Monitoring ownership boundary

The local Kapiteky identity can manage ordinary workload resources in
`agents-swarm` but cannot create `ServiceMonitor` resources or inspect the
`monitoring` namespace. The Grafana/Prometheus owner must add a reviewed
ServiceMonitor that selects `Service/openclaw-otel-collector` in
`agents-swarm` and scrapes `self-metrics` and `prometheus`.

Do not expand the local identity's RBAC merely to bypass this ownership
boundary. Until the ServiceMonitor is installed, collector health and metrics
may be proven through an explicitly approved in-cluster or port-forward smoke.

## Pre-deployment gates

1. `task verify` passes.
2. The agent image build proves the exact diagnostics plugin is a loaded,
   trusted official npm install.
3. All five agents are Ready on one known rollback digest with no unexplained
   restarts.
4. The exporter Secret contract exists through a masked provisioning path.
5. The node has enough schedulable requested CPU and memory for the collector.
6. The monitoring owner confirms ServiceMonitor discovery and the Langfuse,
   Prometheus, Loki, and collector-compatible endpoint versions.

## Sequential fleet verification

After explicit deployment approval:

1. Apply the collector resources and wait for
   `Deployment/openclaw-otel-collector` to become Ready. Restart the collector
   after applying its ConfigMap because mounted configuration changes do not
   restart or hot-reload the collector process.
2. Use `scripts/rollout-agent-observability.sh` to roll one Deployment at a
   time in this exact order: `agent-developer`, `agent-infra`,
   `agent-designer`, `agent-coordinator`, `agent-intake`. The helper pins the
   reviewed image digest, preserves the ServiceAccount and replicas, verifies
   peers are unchanged, and rolls the target back on failure.
3. Verify the Gateway, trusted diagnostics plugin, Mattermost channel, runtime
   toolbox, and zero unexpected restarts.
4. Exercise at least five successful tool calls and two controlled failures per
   agent. Confirm bounded failure categories and exact agent/resource
   attribution. Run the collector-outage fail-open drill only on Tinus.
5. Prove a correlated Langfuse trace, Prometheus metrics, and sanitized Loki
   failure record without prompt, response, tool argument, command output, or
   retrieved content.
6. Make the collector temporarily unavailable and prove the tool result is
   unchanged; then restore it and prove exporter recovery.

## Fleet acceptance evidence

The first full-fleet proof completed on 2026-08-29. The final accepted rollout
uses immutable image digest
`sha256:afc51a7f3a3ff0d3e7ec77925f02a63d3e47008346ec110192d2fdfd71854753`.
This supersedes the earlier build-tag-derived revision used during canary
proof; the shared pipeline now propagates the registry-published OCI digest
into production telemetry and the renderer rejects mutable production image
revisions.
All five agents stayed Ready with zero restarts and emitted distinct bounded
tool-success, stable tool-failure, workflow-phase, runtime-revision, and skill-
bundle-revision series. The controlled set included at least five successful
tool calls and two failed calls per agent. The failure category was the bounded
`codex_native_tool_error`; no raw error or output label was exported.

The Tinus collector-outage drill preserved the successful tool result and the
collector recovered after restoration. Collector self-metrics reported 110
sent spans, zero refused spans, and no failed-span exporter series. A privacy
scan found no content-bearing label keys. The 12 dashboard expressions parsed
with Prometheus 3.6 and the dynamic agent selector resolved the same exact five
agent identities. During the proof, the collector NetworkPolicy was found to
admit only Tinus; the selector was corrected to the exact five-agent allowlist
before accepting the fleet evidence.

## Wrapper failure acceptance evidence

The bounded three-wrapper pilot completed on 2026-08-29 through
`agent-skills` PR 2544, this repository's PR 2545, and `grafana` PR 2546.
The accepted taxonomy is exactly `authentication_unavailable`,
`authorization_denied`, `timeout`, `dependency_unavailable`, `invalid_input`,
`parse_failure`, `nonzero_exit`, `upstream_contract_mismatch`, and `unknown`.
Positive fixtures cover every value; negative fixtures reject raw stderr and
content-bearing fields.

The Knowledge Base client, GitLab wrapper, and runtime status/rollout
helpers preserve successful output and original exit behavior. On failure they
emit only one final local JSON marker containing bounded wrapper, operation,
and error-code metadata. Repository verification passed 108 `agent-skills`
tests and 117 swarm tests, including exact output, retry, and exit equivalence
with telemetry enabled, disabled, and unavailable.

Live controlled failures on Tinus produced exactly three initial clusters:

- `knowledge-retrieval` / `discover` / `invalid_input`;
- `gitlab-vault-run` / `command` / `invalid_input`; and
- `runtime-operations` / `rollout_status` / `invalid_input`.

All were attributed to `agent-developer`, immutable image digest
`sha256:afc51a7f3a3ff0d3e7ec77925f02a63d3e47008346ec110192d2fdfd71854753`,
and skill-bundle revision
`sha256:fa8c88ea753864d464413ac529f4652703da5ca0f0f240dbe964b955f20e17e5`.
A label-key privacy scan found no prompt, response, request, objective,
reference, path, content, output, command, argument, secret, token,
credential, stderr, or stdout fields. The live Grafana dashboard groups the
same bounded dimensions and its mounted JSON matched the reviewed source.

During a collector outage the direct Knowledge Base failure remained byte-for-
byte identical with exit code 2, and a controlled agent call to the then-current
`wrapper_failure` marker still completed with one successful tool call and zero
tool failures. That historical failure-only marker is superseded by the terminal
`wrapper_execution` contract below. After restoration a recovery marker was
exported, the collector was
Ready with zero restarts, and exporter self-metrics reported sent spans with no
failed or refused span series. Build 5909 (`20260829.10`) passed, and all five
agents then passed the full runtime/channel/skill-provenance smoke on the same
immutable image digest with zero restarts. No OpenClaw or Codex artifact was
rebuilt.

## Failure taxonomy and curated trace acceptance evidence

The Tinus canary completed on 2026-08-30 using immutable image digest
`sha256:c70c011c55a97e49db9653664539da8ddd50faeca5ebcffc4c8f3207d7f3e9d6`.
The image preserves OpenClaw source revision `3d1a6e419`, Codex beta.3, and the
official diagnostics plugin beta.3; only the standalone behavioral plugin and
collector/dashboard contracts changed.

A controlled no-delivery run produced one `infuse.agent.turn` root and 24
children across model, tool, workflow, skill, wrapper, and Knowledge Base span
families. Every child used the turn root as parent. There were 12 successful
tool completions and one controlled Knowledge Base rejection classified as
`invalid_input` from the tool-hook error boundary. No raw error, input/output
payload, run/session identifier, forbidden attribute, or unexpected attribute
was exported. Prometheus projected the matching bounded turn, model, and
classified-tool series. The span-metrics connector keys on all seven immutable
resource attributes, so a rollout cannot reuse an earlier image, runtime, or
skill-bundle revision; the final proof contained no stale curated series.

During a collector outage the controlled tool workflow and final agent result
remained successful. After restoration the collector and Tinus were Ready, a
new complete content-free turn arrived without an agent restart, and collector
self-metrics reported sent spans without failed/refused span series. The four
peer agent pod templates remained unchanged throughout canary.

## Tool reconciliation and wrapper denominator contract

Official `openclaw.tool.execution` spans are the sole authority for tool call
volume, generic outcome, and duration. Curated `infuse.tool.execution` spans
remain classification drilldown only. Prometheus recording rules reconcile the
two signals by normalized `openclaw_agent_name` and canonical tool name over the
same fifteen-minute window:

- `official_tool_failures` is the canonical failed-tool population;
- `classified_tool_failures` is the bounded curated subset;
- `tool_failure_unknown` is the official remainder without a classification;
- `tool_failure_unmatched` is curated classification evidence without a
  corresponding official failed-tool count; and
- `tool_failure_classification_coverage` is one minus the explicit unknown
  fraction.

The public hook exposes no safe common event identifier, so this is bounded
aggregate reconciliation rather than invented event-level correlation. A
failure that lacks trustworthy public cause evidence stays `unknown`; the
runtime category `codex_native_tool_error` is never relabeled as nonzero exit.

The `wrapper_execution` marker replaces the failure-only marker and emits a
bounded `start`/`started` marker immediately before an actual governed wrapper
run plus exactly one terminal `finish` marker with `success`, `error`, or
`skipped`. Non-error outcomes forbid `error_code`; failed markers require a
value from the closed wrapper taxonomy. The Knowledge Retrieval fallback,
GitLab wrapper, and runtime operations helpers use the canonical wrapper
IDs `knowledge-retrieval`, `gitlab-vault-run`, and
`runtime-operations`. Underscores in wrapper and operation IDs are normalized
to hyphens at the source before export.

New paired markers carry `lifecycle_method=explicit_pair`. A terminal marker
from the earlier contract remains accepted as `legacy_terminal` so staggered
skill-bundle and agent-image rollouts fail open, but it is explicitly reported
as `unmatched_finish`; it is never silently counted as a complete pair.
Recording rules expose starts, terminal outcomes, incomplete starts, unmatched
finishes, and paired reliability with identical agent/skill/wrapper/operation
dimensions. Marker or exporter failure remains fail-open and cannot change
wrapper output or exit behavior.

## Skill attribution contract

Native and explicit skill evidence are intentionally separate:

- `openclaw_skill_used_total` is native evidence only when the official runtime
  emits a `skill.used` event;
- `infuse.skill.execution` records an explicit bounded lifecycle marker with
  `skill_name`, `phase`, `outcome`, and `attribution_method`; and
- inferred use from surrounding tools, commands, prompts, or loaded skill lists
  is not emitted and cannot support evaluation or promotion.

The governed attribution enum is exactly `native`, `explicit_wrapper`, and
`declared_marker`. The standalone `skill_execution` tool accepts only
`explicit_wrapper` and `declared_marker`; it cannot claim `native`. A valid
lifecycle is `start`/`started`, followed by `finish` with `success`, `error`, or
`skipped`. The tool is metadata-only and fail-open. Image, runtime, and skill-
bundle revisions remain resource attributes rather than marker-controlled
inputs.

The skill, wrapper, Knowledge Base retrieval, and Knowledge Base decision tools
are `direct-only` catalog entries. This keeps those four high-value attribution
surfaces visible to the Codex harness even when ordinary dynamic tools are
deferred behind tool search. Workflow markers remain deferred to avoid
expanding every turn's direct tool payload. Direct visibility does not change
the evidence rule: a marker is emitted only when the owning skill procedure
actually requires and executes it.

Role-anchor skills emit declared markers only when their own procedure is
actually executing. Absence of a marker is `unknown`, not evidence that a skill
was not used, and no surrounding tool call or prompt may be used to infer skill
credit. Each explicit start is held only in bounded per-turn memory. A matching
finish is `complete`; a finish without a start is `unmatched_finish`; and any
start still open when the turn closes is emitted once as
`infuse.lifecycle.integrity` with `incomplete_start` and a bounded count.

Automatic `plan` and `deliver` hook spans carry
`attribution_method=automatic_hook`. Operator- or skill-declared workflow
transitions carry `explicit_marker`. Workflow review panels filter to explicit
markers by default so automatic boilerplate cannot dominate verify, recover,
or other deliberate lifecycle evidence.

## Governed cross-backend review

The Iteration 6 review boundary is the metadata-only package under
`config/observability/reviews/`. Validate and summarize it without backend
write access:

```bash
task review-agent-monitoring-evidence
```

The package must cover the exact five-agent fleet and the governed run-health,
tool-reliability, trace-integrity, lifecycle, Knowledge Base, alert, privacy,
and provenance claims. Every claim and per-agent score is explicitly
`verified`, `not_verified`, or `inconclusive`; absence never becomes success.
The validator rejects content-shaped fields, credentials, raw correlation
identifiers, cross-revision scope, missing evidence references, and any
recommendation that is not both proposed and human-review gated.

Operational triage follows the ordered package drilldown: owned Prometheus
agent-impact alert, matching Grafana aggregate, bounded Loki diagnostic count,
then a Grafana exemplar into the approved Langfuse project. Generic
`KubeJobFailed` history is classified separately as historical noise and is
retained for audit. It cannot be treated as active persistent-agent impact
without a current owned agent alert or correlated run evidence.

Review output is suitable for a public Mission Control verification artifact,
but it never mutates a skill, runtime, alert, or repository. Recommendations
remain owner-repository proposals until a human reviews the stated evidence.

## Rollback

Roll back only the failing agent to its recorded Deployment revision, or remove
`OPENCLAW_DIAGNOSTICS_OTEL_CANARY`,
`OPENCLAW_BEHAVIORAL_OBSERVABILITY_CANARY`, and the two observability plugins
from that agent's runtime patch. Preserve its ServiceAccount, PVC, and peers.
The collector remains deployed for agents already proven on the fleet contract.
