---
title: Internal Gateway PKI Operations
description: Offline issuance, Vaultwarden custody and monitored operator renewal for the five-agent internal gateway transport.
type: runbook
status: draft
owner: team:agent-platform
tags:
  - openclaw
  - kubernetes
  - certificates
  - operations
---

# Internal gateway PKI

This procedure implements the certificate prerequisite for
[internal gateway transport](INTERNAL_GATEWAY_TRANSPORT.md). The issuer is the
reviewed local `scripts/internal-gateway-pki.mjs` helper and OpenSSL, operated by
the infrastructure owner. It has no network, Vaultwarden, Kubernetes, rollout or
scheduled-job calls. It does not install an issuer service, CRD, ClusterIssuer,
RBAC rule or CI signing credential. Existing reviewed application images remain
unchanged.

The owner is `team:agent-platform`, with infrastructure operations as the
credential custodian and rollout operator. Fito's authorized internal-routing
rollout is the initial activation scope. Future credential rotations and restarts
use the existing approved operations process; this document does not grant agents
or assurance jobs credential write access.

## Issuer and durable custody

Create two separate P-256 self-signed CA identities, each valid for 1,825 days:
`OpenClaw Internal Server CA` and `OpenClaw Internal Client CA`. Both have critical
CA constraints with path length zero and signing-only key usage. Each CA has only
its own serverAuth or clientAuth EKU. The helper issues direct leaves, not
intermediates; it never accepts an arbitrary hostname or a CSR supplied by a
caller. Random positive 159-bit serials avoid a shared mutable serial database.

Use the existing organization `4ee40d24-6f91-4d76-b7c5-f962352e614a`, collection
`02-Kubernetes` (`f07ed0b1-a4ec-46ef-b0da-24d3529a44ae`). Proposed exact item names:

- `OpenClaw Internal TLS - Server CA - v1`
- `OpenClaw Internal TLS - Dashboard Client CA - v1`
- `OpenClaw Internal TLS - <agent-id> - <issuance-UTC>` for each server leaf
- `OpenClaw Internal TLS - Dashboard Client - <issuance-UTC>` for its leaf

Each CA item owns its private key in a protected field, public certificate, role,
SHA256 fingerprint, validity dates and this profile version. Each issuance item
owns that leaf's private key, certificate, public metadata and exact issuer item
reference. Store full `vaultwarden://<organization>/<collection>/<item-id>`
references in protected operations evidence after creation. These names are an
intended contract, not a claim that items already exist. Do not broaden collection
access or reuse existing gateway tokens. Do not rely on Vaultwarden hidden-field
history as a rollback archive: keep each issuance as a distinct item until its
approved retention/retirement decision.

Generate in a new operator-owned mode-0700 directory on a trusted workstation;
all helper files are mode 0600. Never use a repository, shared CI artifact or
shell trace. The helper requires canonical absolute paths without symlinked
parents and refuses existing output directories, even partial ones. It prints
only public metadata; it suppresses OpenSSL diagnostics that could contain input
material. On failure, inspect/delete the protected partial output under the
existing operations process and retry to a new directory. It does not resume or
overwrite. Production keys must be restored successfully from their exact new
Vault items and checked against their public fingerprints **before** provisioning
Kubernetes Secrets or deleting the local working copy. Never put CA private keys
in application Secrets, Pods, CI variables or source.

## Four offline commands

Prerequisites are Node 24, OpenSSL 3 or later, and a private canonical parent
directory that already exists. These examples name protected local paths; they
perform no Vault or Kubernetes writes.

```sh
node scripts/internal-gateway-pki.mjs init-server-ca \
  --output /private/operations/openclaw-pki/server-ca-v1
node scripts/internal-gateway-pki.mjs init-client-ca \
  --output /private/operations/openclaw-pki/client-ca-v1
node scripts/internal-gateway-pki.mjs issue-server \
  --ca-dir /private/operations/openclaw-pki/server-ca-v1 \
  --ca-sha256 '<64-lowercase-hex-from-verified-server-CA-Vault-item>' \
  --agent agent-developer \
  --output /private/operations/openclaw-pki/tinus-issuance-1
node scripts/internal-gateway-pki.mjs issue-client \
  --ca-dir /private/operations/openclaw-pki/client-ca-v1 \
  --ca-sha256 '<64-lowercase-hex-from-verified-client-CA-Vault-item>' \
  --output /private/operations/openclaw-pki/dashboard-issuance-1
```

`init-*-ca` is only for initial provisioning or an explicitly planned CA rotation.
Normal leaf renewal uses `issue-*` with the retained CA, creates a fresh private
key and serial, and leaves that CA unchanged. The CA must have at least 120 days
remaining, be self-signed, match its expected role and pinned fingerprint, and
match its protected key. Issuance always lasts exactly 90 days. Leaves have
CA:FALSE, digitalSignature and a single role-specific EKU. Each output includes
`public-metadata.json`; CA output is `ca.crt`/`ca.key`, leaf output is
`tls.crt`/`tls.key`.

The fixed identity and Secret contract is:

| Identity | Exact DNS SAN | Secret in `agents-swarm` |
| --- | --- | --- |
| Tinus / agent-developer | `agent-developer-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-developer-dashboard-internal-tls` |
| Stewie / agent-designer | `agent-designer-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-designer-dashboard-internal-tls` |
| Emon / agent-coordinator | `agent-coordinator-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-coordinator-dashboard-internal-tls` |
| Ramiro / agent-intake | `agent-intake-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-intake-dashboard-internal-tls` |
| Satwa / agent-infra | `agent-infra-dashboard-internal.agents-swarm.svc.cluster.local` | `agent-infra-dashboard-internal-tls` |
| Dashboard client | `openclaw-dashboard.agents-swarm.svc.cluster.local` | `openclaw-dashboard-gateway-client-tls` |

Server Secrets receive their own `tls.crt`, `tls.key`, and only the public client
CA as `client-ca.crt`. The dashboard receives its own `tls.crt`, `tls.key`, and
only the public server CA as `server-ca.crt`. The short descriptive CN is not a
verification identity. Do not create wildcard, extra-SAN, dual-role, expired or
plaintext-fallback certificates. Trust and leaf roles remain separated during
rotation as well as initial provisioning.

## Public renewal records and existing weekly assurance

After a fresh live handshake proves the installed certificates, attach the
unmodified leaf `public-metadata.json` objects as JSON strings to the selected
agent **Deployment metadata**, not its Pod template:

- `openclaw.infuse-ai.com/internal-tls-server`: that agent's server record.
- `openclaw.infuse-ai.com/internal-tls-dashboard-client`: the dashboard client
  record used to connect to it.

Update these using a fresh UID/resourceVersion-guarded patch that preserves all
other fields. Keep both records on every internally selected agent and update
the repeated client record after client renewal qualification. Deployment metadata
updates do not themselves restart Pods. The ordinary rotation still explicitly
restarts the certificate owner. Retain public issuer/leaf fingerprints, expiry,
the consumed Pod/revision and handshake result in protected operations evidence.

The existing `weekly_live_runtime_assurance` job reads these Deployments using
its existing exact-name, get-only Role. It selects the primary container by the
name `agent`; internally selected agents must also have the reviewed
`gateway-internal-tls` command/name/SAN and the same immutable image. Unexpected
or missing containers, missing/invalid records, identity mismatch, a shared CA
across client/server roles, or inconsistent dashboard client records fail the job.
It fails at **30 days or less remaining for any leaf**, or **180 days or less for
either CA**, through the existing weekly failure notification path. Review the
schedule's actual enabled state and recent successful delivery before activation;
checked-in job definitions alone do not prove that it runs.

These annotations are public, operator-attested rotation records. They are not
cryptographic proof of mounted Secret bytes or a new TLS handshake. A Secret
change without record renewal fails conservatively at the prior recorded expiry;
prematurely publishing a new record could hide a failed rollout, so record updates
must follow handshake qualification. Assurance gets no Secret, exec, mutation,
Vault or signing permission. Read-only monitoring plus operator renewal is the
chosen mode; unattended issuance/renewal is not claimed.

## Initial activation and renewal

1. Qualify this helper and the weekly job in source; confirm the infrastructure
   owner and a recurring operations review at 60 days after issuance. The weekly
   check provides the final 30-day escalation window. Confirm the existing job
   schedule and its failure notification are functioning with a synthetic expiry
   fixture; do not alter live certificate dates to test an alert.
2. Create and durably verify both CA items. For the pilot, issue only Tinus's leaf
   and the dashboard client. Save/restore the exact leaf items and verify their
   keys, fingerprints, role, chain, SAN and validity. Provision only those two
   Secrets through the approved operations path.
3. Follow the guarded transport activation in the parent runbook. Test no-client,
   wrong-client/wrong-name rejection plus HTTP, WebSocket, Fito admin/profile,
   Studio's local password fallback, Mattermost and real Tinus/Stewie switching.
   Record a **new** handshake using the issued fingerprints, then publish the
   two public annotations. Advance other agents one at a time with distinct
   server leaves. Only explicitly selected internal agents require records.
4. At ordinary renewal, use the retained role-specific CA and a new output
   directory/leaf item. Preserve the previous valid leaf item for controlled
   rollback, update the selected leaf Secret with optimistic concurrency, then
   restart the certificate owner through its existing drain/rollout process.
   Reconcile runtime file-only native settings with the Deployment's bootstrap
   configuration before any agent restart, as required by the parent runbook.
5. A projected Secret update does not reload TLS or close persistent WebSockets.
   Verify new handshakes and current Pod/revision before updating public records.
   A server leaf needs only that agent's restart; a client leaf needs the dashboard
   restart/reconnection to all internal agents. Recheck the original boundaries
   and all still-selected agents, then update repeated client records together.
6. For CA rotation, stage the new **public** CA alongside the old in the opposite
   endpoints' trust bundles and restart them first. Rotate leaves/keys and restart
   their owners individually; verify fresh handshakes. Publish new records only
   after that evidence, then remove old trust with controlled restarts. Never mix
   role hierarchies. Emergency revocation also closes existing connections; no
   CRL/OCSP service or automatic live-session revocation is provided.

If new issuance fails, existing valid certificates continue and no live state is
changed. If deployment fails, restore the retained still-valid leaf and restart
its owner, or explicitly select the existing Tailscale transport and verify it.
Do not automatically downgrade, restore whole old Deployments, or change images.
If a CA key is lost, use verified Vault custody; if compromised, rotate the
affected hierarchy and its trust before re-admission. Do not silently create a
replacement root during routine renewal.

## Verification and review boundary

```sh
node --test tests/internal-gateway-pki.test.mjs
python3 -m unittest discover -s tests -p test_internal_gateway_pki.py -v
python3 -m unittest discover -s tests/assurance -p test_swarm_assurance.py -v
python3 scripts/verify_knowledge_format.py --root=.
git diff --check
```

Tests generate only disposable local keys, with no listener or network request.
They verify all six identities, purpose separation, CA pinning, key pairing,
renewal, protected output, and expiry/drift failures. Source tests do not prove
Vault restore, production Secrets, real certificate consumption, job scheduling
or live rollout. Those activation facts remain the delivery owner's evidence.
This draft needs human review before it is treated as the active operations
procedure; no human-review attestation is supplied by the helper or tests.
