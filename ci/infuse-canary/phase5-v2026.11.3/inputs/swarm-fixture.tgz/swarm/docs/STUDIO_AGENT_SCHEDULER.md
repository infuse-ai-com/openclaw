---
title: Agent schedule and usage feeds for Studio
description: Defines the bounded schedule and usage feeds that OpenClaw publishes for Studio observation.
type: runbook
status: active
owner: team:agent-platform
tags:
  - studio
  - scheduling
  - observability
---
# Agent schedule and usage feeds for Studio

Studio observes schedules; OpenClaw owns execution. `openclaw-scheduler-collector`
replaces the legacy Backoffice ritual-calendar collector. Each agent's Gateway
returns a complete paginated snapshot, including disabled and internal schedules.
The producer exports only identity/name, enabled state, schedule, explicit source
timezone, next/last run and bounded last-result status. It exports no task prompt,
delivery destination, session content or raw execution error. An omitted cron
timezone stays unknown; it is never silently replaced with Madrid or UTC.

The feed is `core/openclaw-scheduler-feed`, one `<agent-id>.json` key for each of
the five expected agents. An incomplete fleet or page rejects the update rather
than erasing the last valid snapshot. Studio stores its own scoped observations
and shows their freshness. This is separate from Kubernetes maintenance CronJobs.

## Deployment sequence

1. Review and validate the Swarm and Studio changes together. Render
   `python3 scripts/scheduler-prerequisites.py`; the optional `--apply` creates
   only the new scheduler account/role/binding and dedicated exact-feed writers.
   It preserves existing feed contents and starts no workload. This one-time
   activation is explicit; runtime-only fleet releases do not mutate RBAC.
2. Apply approved prerequisites, then release Swarm through reviewed main. The
   five maintenance CronJobs now include scheduler collection instead of calendar
   collection. Wait for the scheduled run to publish all five valid snapshots.
3. Release Studio's bounded schedules contract/read/UI and named-feed read grant.
   Add one admitted schedules source for each existing telemetry target through
   Studio's protected configuration owner, preserving all unrelated settings.
4. Prove source freshness, stored rows, Company-only admission and actual Agents
   UI before stopping/removing the old calendar CronJob and its exclusive grants.
   The old `openclaw-backoffice-feed-writer` role is shared with token usage: only
   remove it once the dedicated usage writer has been verified. Keep the new
   `openclaw-agent-token-usage-feed-writer`; do not revoke active usage collection.

The old calendar export remains a compatibility transport module for the
paginated Gateway reader and old local callers during this transition. It is not
the scheduler's data/UI schema and is not included as an active CronJob in the
production overlay. Removal of its deployment object is an explicit cutover,
because Kubernetes apply does not prune renamed resources.

## Usage empty-window correction

Installed OpenClaw may omit cache metadata when there are no session entries.
The exporter admits this only when the response explicitly contains an empty
session list, zero token totals, zero aggregate session count, no model totals,
the complete requested date window and a current result timestamp. It reports
`empty_window`, not a fabricated fresh cache. Explicit pending/stale cache states,
missing fields, nonzero totals and stale results still fail. A validated empty
window no longer blocks collection for the other four agents.

## Verification

Run focused scheduler, token exporter, calendar pagination and rollout tests,
then the repository verification suite. Test the producer against the deployed
read-only Gateway contract before changing live feed data. Do not run or mutate
agent schedules as part of qualification.
