---
title: New Agent Runbook
description: This runbook describes how to add a persistent OpenClaw swarm agent.
type: runbook
status: active
owner: team:agent-platform
tags:
  - runbook
  - new
  - agent
---
# New Agent Runbook

This runbook describes how to add a persistent OpenClaw swarm agent.

Use `agent-designer` as the example role. Replace `designer` with the new role slug when creating another agent.

## When To Create A Persistent Agent

Create a persistent agent only when the role needs at least one of:

- durable identity in Mattermost;
- durable memory or runtime state;
- repeated access to the same repos, channels, or cluster namespaces;
- auditable tool use under a scoped identity;
- a clearer permission boundary than a temporary role-hat prompt can provide.

If the work is one-off, use a temporary role hat first and record learnings in the relevant repo docs.

## Inputs

Before starting, write down:

- agent slug: `designer`;
- agent id: `agent-designer`;
- friendly name: `Stewie Hobs`;
- purpose: design review, UX critique, visual QA, prototype feedback;
- owner: Fito;
- coordinator / escalation: Emon Lusk / `agent-coordinator`; Kapiteky only when Emon or Fito explicitly requests advice;
- Mattermost channel(s): for example `openclaw-swarm-dev` at first, then project-specific design channels;
- repo/project scope;
- allowed tools;
- approval boundaries;
- memory path;
- verification checks;
- offboarding condition.

## 1. Decide The Access Bundle

Create `docs/agents/agent-designer.md` from:

```text
docs/agents/TEMPLATE.md
```

Create the enforced skill bundle from the same decision:

```text
config/agent-skill-bundles/agent-designer.json
```

Use the shared catalog:

```text
config/skill-catalog.json
```

Default rule: the reviewed bundle contains one binary `skills.installed` list.
Keep it small and role-shaped; everything else is absent. A task does not make
an absent skill available without a reviewed bundle change and runtime refresh.
Credential access still defaults to deny even when the agent has a runtime bot
token.

Minimum sections:

- purpose;
- default permission level;
- allowed actions;
- actions requiring Fito approval or an explicit recorded mission boundary;
- Mattermost identity;
- secret source;
- credential access metadata from `docs/CREDENTIAL_ACCESS.md`;
- runtime persona files;
- introduction message;
- verification checklist;
- retirement/offboarding condition.
- installed skills.

Example permission stance for `agent-designer`:

Allowed:

- read assigned product/design docs;
- read screenshots, browser-smoke artifacts, and UI diffs;
- draft UX review comments;
- propose CSS/layout/component changes as patches;
- post in assigned design/dev channels when mentioned.

Requires approval:

- merging PRs;
- deploying product changes;
- changing brand direction;
- sending external/client-facing design feedback;
- creating/removing Mattermost members or channels;
- broadening repo, channel, model, or secret access.

Verify the skill bundle:

```bash
task verify-agent-skills
AGENT_ID=agent-designer task verify-agent-skill-install
```

Install the approved binary skill set after persona files exist:

```bash
AGENT_ID=agent-designer task install-agent-skills
```

## 2. Update Agent Identity Docs

Update `docs/AGENT_IDENTITIES.md`:

- add `agent-designer` under persistent candidates or active identities;
- explain why the role deserves persistence;
- list default access;
- link to `docs/agents/agent-designer.md`;
- record current status.

If the role is approved, add a dated decision to `docs/DECISIONS.md`.

## 3. Create The Mattermost Identity

Preferred identity:

```text
username: agent-designer
display name: Stewie Hobs
role: design review / UX QA agent
default channel: openclaw-swarm-dev
```

Use a bot account when possible. Kapiteky can create approved bot accounts and store their tokens in Vaultwarden.

Expected Vaultwarden item naming:

```text
Mattermost / agent-designer BOT token
```

Do not paste the token in Mattermost, Git, shell history snippets, docs, or memory files.

Dry-run the bot onboarding first:

```bash
AGENT_ID=agent-designer \
MATTERMOST_CHANNEL_ID=1k6r6ipd87ry9j59xp8to59rnr \
task verify-agent-mattermost-bot
```

Then create/reuse the bot, create a token, store it in Vaultwarden, and add the bot to the approved channel:

```bash
AGENT_ID=agent-designer \
MATTERMOST_CHANNEL_ID=1k6r6ipd87ry9j59xp8to59rnr \
task onboard-agent-mattermost-bot
```

The helper stores the token in `Mattermost / agent-designer BOT token` by default. It refuses to overwrite an existing Vaultwarden item unless `OVERWRITE_VAULT_ITEM=true` is explicitly set.

## 4. Add The Secret Contract

Create an example-only contract:

```text
docs/secrets/agent-designer-mattermost.example.env
```

Expected keys:

```env
MATTERMOST_BASE_URL=http://mattermost.infuseai.svc.cluster.local:8065
MATTERMOST_ALLOW_PRIVATE_NETWORK=true
MATTERMOST_CHANNEL_ID=replace-with-channel-id
MATTERMOST_BOT_TOKEN=replace-with-vaultwarden-sourced-token
```

Dry-run the Kubernetes Secret shape:

```bash
AGENT_ID=agent-designer \
MATTERMOST_CHANNEL_ID=1k6r6ipd87ry9j59xp8to59rnr \
task verify-agent-mattermost-secret
```

Then sync the real Kubernetes Secret from Vaultwarden after the bot token item exists:

```bash
AGENT_ID=agent-designer \
MATTERMOST_CHANNEL_ID=1k6r6ipd87ry9j59xp8to59rnr \
task sync-agent-mattermost-secret
```

By default the sync helper reads Vaultwarden item `Mattermost / agent-designer BOT token` and writes Kubernetes Secret `agent-designer-mattermost`. It does not print the token value.

## 5. Prepare Runtime Persona Files

Each persistent agent needs a PVC-backed profile area:

```text
/workspace/agents/agent-designer/AGENTS.md
/workspace/agents/agent-designer/SOUL.md
/workspace/agents/agent-designer/IDENTITY.md
/workspace/agents/agent-designer/USER.md
/workspace/agents/agent-designer/TOOLS.md
/workspace/agents/agent-designer/HEARTBEAT.md
/workspace/agents/agent-designer/MEMORY.md
/workspace/agents/agent-designer/memory/
/workspace/agents/agent-designer/state/
/workspace/agents/agent-designer/logs/
```

Use persona templates from the sibling persona repo:

```text
../openclaw-agents-persona/templates/agent-persona/
```

Dry-run persona file installation:

```bash
AGENT_ID=agent-designer \
AGENT_NAME=Stewie Hobs \
AGENT_ROLE="design review / UX QA agent" \
MATTERMOST_CHANNEL=openclaw-swarm-dev \
task verify-agent-persona
```

Install persona files into the prepared runtime workspace:

```bash
AGENT_ID=agent-designer \
AGENT_ROLE="design review / UX QA agent" \
MATTERMOST_CHANNEL=openclaw-swarm-dev \
task install-agent-persona
```

The `openclaw-agent` runtime image also runs this persona installer on startup when `AGENT_ID` is set. This keeps recreated PVCs from falling back into first-run bootstrap mode. Startup refreshes the role/identity files and preserves an existing `MEMORY.md`.

At minimum:

- `IDENTITY.md` names the agent and role.
- `SOUL.md` defines the agent's operating style.
- `AGENTS.md` defines repository/channel/tool boundaries.
- `USER.md` should describe the owner/coordinator relationship, not private human details beyond the approved scope.
- `MEMORY.md` starts nearly empty and scoped to the role.

For `agent-designer`, bias the persona toward:

- visual quality;
- UX consistency;
- accessibility;
- screenshot-based evidence;
- clear distinction between critique, suggested patch, and approved product direction.

## 6. Bootstrap The OpenClaw Profile

Use the generic bootstrap script:

```text
scripts/bootstrap-agent-profile.sh
```

`scripts/bootstrap-developer-agent-profile.sh` remains as a compatibility wrapper for the first live agent.

Dry-run the generated config before mutating a live profile:

```bash
AGENT_ID=agent-designer \
MATTERMOST_CHANNEL_ID=1k6r6ipd87ry9j59xp8to59rnr \
task verify-agent-profile
```

Bootstrap the profile once the access bundle, bot, and secret contract are approved:

```bash
AGENT_ID=agent-designer \
OPENCLAW_AGENT_WORKSPACE=/workspace/agents/agent-designer \
MATTERMOST_CHANNEL_ID=1k6r6ipd87ry9j59xp8to59rnr \
MODEL=openai/gpt-5.5 \
task bootstrap-agent-profile
```

The bootstrap script writes profile config that references `MATTERMOST_BOT_TOKEN` from the environment. It never accepts or writes token values directly.

## 7. Scope Group Handling

For Mattermost group channels:

- keep `dmPolicy` as `allowlist` with only Fito in `allowFrom`;
- keep `groupPolicy` as `open` so Mattermost channel membership is the group access boundary;
- do not set `groupAllowFrom` or `groups` for persistent swarm agents;
- keep `chatmode` as `oncall` for specialist agents;
- use `chatmode` `onmessage` only for Emon / `agent-coordinator`;
- keep `replyToMode` as `all`; this preserves outbound thread placement and is not an inbound wake-up policy;
- enable Mattermost reaction actions explicitly;
- use a 12,000-character outbound text chunk limit and a 1,500 ms Mattermost inbound debounce;
- use typed progress with the `Thinking… please wait` headline and `finalDelivery: "separate"`;
- use `commandText: "raw"` so progress rows show the actual command, while never placing secrets directly in command text;
- require explicit mentions for every specialist agent with `requireMention: true`;
- disable `implicitMentions.replyToBot`, `implicitMentions.quotedBot`, and
  `implicitMentions.threadParticipation` for every specialist so only a literal
  dispatcher mention creates a task-root wake;
- keep Emon / `agent-coordinator` as the only agent allowed to receive ambient group-channel work, using `requireMention: false`;
- manage actual channel scope by adding/removing the Mattermost bot account from channels.

```json
{
  "messages": {
    "inbound": {
      "byChannel": {
        "mattermost": 1500
      }
    }
  },
  "channels": {
    "mattermost": {
      "replyToMode": "all",
      "textChunkLimit": 12000,
      "actions": {
        "reactions": true
      },
      "streaming": {
        "mode": "progress",
        "progress": {
          "label": "Thinking… please wait",
          "finalDelivery": "separate",
          "toolProgress": true,
          "commandText": "raw",
          "maxLines": 8,
          "maxLineChars": 120
        }
      },
      "chatmode": "oncall",
      "dmPolicy": "allowlist",
      "allowFrom": [
        "<fito-user-id>"
      ],
      "groupPolicy": "open",
      "implicitMentions": {
        "replyToBot": false,
        "quotedBot": false,
        "threadParticipation": false
      },
      "requireMention": true
    }
  }
}
```

For specialist agents, `requireMention` should stay `true` and all implicit
mention flags should stay `false`. For the coordinator,
set `chatmode: "onmessage"` and `requireMention: false`. Do not recreate a
channel allowlist in OpenClaw config; Mattermost membership is the allowlist.

## 8. Choose Model/Auth Path

MVP currently uses a temporary copied Kapiteky/OpenAI OAuth profile for `agent-developer`. Fito approved keeping this bridge for near-term swarm-agent experiments while scoped model credentials are designed later.

This means the bridge is allowed for now, but it is still debt. For future hardening, prefer a scoped credential path:

- separate model credential where possible;
- Vaultwarden as source of truth;
- Kubernetes Secret as runtime bridge;
- no committed auth store, token JSON, browser cookie, or OAuth blob.

When using `OPENCLAW_AUTH_PROFILES_JSON` for this temporary bridge, the runtime boot command must seed all auth locations used by the gateway, embedded agent, and PVC-backed cron execution:

- profile root: `$HOME/.openclaw-$profile/auth-profiles.json`;
- embedded agent dir: `$HOME/.openclaw-$profile/agents/$AGENT_ID/agent/auth-profiles.json`;
- state root: `$OPENCLAW_STATE_DIR/auth-profiles.json`;
- state embedded agent dir: `$OPENCLAW_STATE_DIR/agents/$AGENT_ID/agent/auth-profiles.json`.

The embedded agent reads the embedded-agent path for provider auth; cron-triggered agent turns may read the state embedded-agent path. Writing only the profile-root file lets the gateway start and connect to Mattermost, but embedded tasks fail with a missing provider auth error.

For OpenClaw 2026.6.1+, use `openai/gpt-5.5` with the `@openclaw/codex` app-server harness. The runtime boot command must run `openclaw-agent-ensure-plugins "$profile"` after seeding config/auth and before `gateway run`; this installs/indexes `@openclaw/codex` and other required external plugins into the active profile/PVC registry. Reserve `openclaw --profile "$profile" doctor --fix --yes --non-interactive` for manual repair of legacy copied OAuth profiles or stale route pins, not normal startup.

If a temporary auth bridge is approved, record it in `docs/DECISIONS.md` with:

- who approved it;
- why it was needed;
- where it lives;
- what replaces it;
- retirement criteria.

## 9. Deploy Or Restart Runtime

Decision: each persistent agent gets its own Kubernetes Deployment. For `agent-designer`, the target deployment name should be:

```text
deploy/agent-designer
```

The repo includes a reusable per-agent deployment component under:

```text
k8s/components/persistent-agent/
```

Create a concrete overlay under:

```text
k8s/agents/<agent-id>/
```

The `agent-designer` worked example renders `deploy/agent-designer`, `pvc/agent-designer-workspace`, and `networkpolicy/agent-designer-default`.

Once secrets/profile config are ready, deploy and check status through Task:

```bash
TAG="<approved-image-tag>" task deploy-infuseai-agents
AGENT_ID=agent-designer task status-agent
```

Manual fallback shape:

```bash
kubectl --context infuseai-k8s -n agents-swarm rollout status deploy/agent-designer
kubectl --context infuseai-k8s -n agents-swarm logs deploy/agent-designer --tail=120
```

## 10. Verify The Agent

Run read-only/status checks first:

```bash
AGENT_ID=agent-designer task status-agent
kubectl --context infuseai-k8s -n agents-swarm logs deploy/agent-designer --tail=120
```

Then verify from inside the pod:

```bash
openclaw --profile agent-designer config validate
openclaw --profile agent-designer models status
openclaw --profile agent-designer channels status
```

Mattermost checks:

- bot token resolves to `agent-designer`;
- bot is member of approved channel(s);
- outbound message works;
- inbound mention from an allowlisted human gets one relevant reply;
- non-mention group chatter does not trigger a reply;
- non-allowlisted senders do not trigger replies.

For `agent-designer`, first useful task:

```text
@agent-designer review the current openclaw-k8s-swarm README and tell us whether a new designer agent could understand where to start. Draft-only, no edits.
```

## 11. Record Activation

After successful verification:

- update `docs/agents/agent-designer.md` status;
- update `docs/AGENT_IDENTITIES.md`;
- add a decision entry if the agent is now active;
- add any new secret example contracts;
- add verification evidence to the PR or `docs/RUNBOOK.md`;
- record current limitations in `docs/TASKS.md`.

## 12. Offboard Or Pause

Pause or remove the agent if:

- it posts noisy or unsafe replies;
- it cannot explain its scope;
- credentials are suspected compromised;
- it needs broader access than approved;
- the role is not used enough to justify persistence.

Offboarding checklist:

- disable/remove Mattermost bot token;
- remove Kubernetes Secret;
- remove channel memberships;
- archive or delete runtime state according to retention decision;
- update `docs/AGENT_IDENTITIES.md` and `docs/DECISIONS.md`.

## Gaps Found By The `agent-designer` Exercise

These are the current system gaps exposed by walking through a second agent:

- Generic `bootstrap-agent-profile` exists; remaining work is to pair it with persona-file templates and in-cluster profile smoke checks.
- Generic Vaultwarden-to-Kubernetes Mattermost secret sync and bot onboarding exist; remaining work is behavioral smoke checks.
- Decision made and implemented: persistent agents should each have one Kubernetes Deployment.
- Standard persona templates and installer exist; remaining work is in-cluster profile/persona smoke coverage.
- No scoped model credential flow exists yet; `agent-developer` still uses a temporary copied OAuth bridge.
- Automated Mattermost bot onboarding exists; it requires an approved agent id/channel and stores tokens in Vaultwarden.
- No acceptance test exists for inbound Mattermost allowlist/mention behavior.
- No Backoffice/access-bundle UI exists for approving and auditing agent access.

## Recommended Follow-Up Work

Add these as small PRs before creating the third persistent agent:

- Per-agent Kubernetes Deployment template or overlay, with deployment names like `agent-designer`.
- `scripts/bootstrap-agent-profile.sh` parameterized by `AGENT_ID`, mention behavior, model, workspace, and secret names.
- `scripts/sync-agent-mattermost-secret.sh` parameterized by agent slug and Vaultwarden item.
- `docs/agents/TEMPLATE.md` for access bundles.
- Persona template files for `SOUL.md`, `IDENTITY.md`, `USER.md`, `TOOLS.md`, `AGENTS.md`, and scoped `MEMORY.md`.
- `task verify-agent-profile AGENT_ID=agent-designer` for config/model/channel checks.
- `task smoke-agent-mattermost AGENT_ID=agent-designer` for outbound and inbound mention behavior.
- Scoped model credential flow to replace the temporary Kapiteky OAuth bridge when agent autonomy or deployment scope increases.
