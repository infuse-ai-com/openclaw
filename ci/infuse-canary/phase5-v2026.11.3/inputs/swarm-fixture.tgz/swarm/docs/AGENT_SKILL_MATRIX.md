---
title: Persistent Agent Skill Matrix
description: Binary installed or absent assignments for company managed-copy and reviewed runtime-native skills across the persistent swarm.
type: reference
status: active
owner: team:agent-platform
tags:
  - agents
  - skills
  - matrix
---
# Persistent Agent Skill Matrix

This matrix is generated from `config/skill-catalog.json` and
`config/agent-skill-bundles/*.json`. It includes every skill whose source
is `infuse-ai-agent-skills`. **Installed** means the bundle declares the skill and its
managed copy is materialized for that agent; **absent** means it is not installed.
There is no optional state.

| Skill | Emon | Tinus | Stewie | Satwa | Ramiro |
|---|---|---|---|---|---|
| `agent-certification-validation` | Installed | Absent | Absent | Absent | Absent |
| `agent-compatibility-audit` | Installed | Installed | Absent | Absent | Absent |
| `agent-runtime-truth-audit` | Absent | Absent | Absent | Installed | Absent |
| `agentic-product-engineering` | Installed | Absent | Absent | Absent | Absent |
| `authorization-assurance` | Absent | Installed | Installed | Installed | Absent |
| `ci-cd-assurance-audit` | Installed | Absent | Absent | Installed | Absent |
| `coding-agent-routing` | Installed | Installed | Absent | Absent | Absent |
| `consulting-intake-orchestrator` | Absent | Absent | Absent | Absent | Installed |
| `depoisoning-context` | Installed | Installed | Absent | Absent | Installed |
| `document-normalizer` | Installed | Installed | Absent | Absent | Installed |
| `gitlab` | Installed | Installed | Installed | Installed | Installed |
| `grill-project-solution` | Installed | Installed | Installed | Installed | Installed |
| `infuse-knowledge-format` | Installed | Installed | Installed | Installed | Installed |
| `infuse-product-design` | Absent | Absent | Installed | Absent | Absent |
| `initiative-bootstrap` | Absent | Absent | Absent | Absent | Absent |
| `interactive-explainer` | Installed | Installed | Installed | Installed | Installed |
| `knowledge-retrieval` | Installed | Installed | Installed | Installed | Installed |
| `kubernetes-resource-rightsizing` | Absent | Absent | Absent | Installed | Absent |
| `mattermost-channel-management` | Installed | Installed | Installed | Installed | Installed |
| `mission-control-publishing` | Installed | Installed | Installed | Installed | Installed |
| `mission-shaping` | Absent | Absent | Absent | Absent | Absent |
| `operational-assurance` | Installed | Installed | Absent | Installed | Absent |
| `playwright-browser-evidence` | Installed | Installed | Installed | Absent | Absent |
| `project-bootstrap` | Installed | Absent | Absent | Absent | Installed |
| `pull-request-assurance` | Installed | Installed | Absent | Absent | Absent |
| `repository-adoption-assessment` | Absent | Absent | Absent | Absent | Absent |
| `repository-implementation-gap-audit` | Installed | Installed | Absent | Absent | Absent |
| `runtime-operations` | Installed | Installed | Absent | Installed | Absent |
| `scoped-implementation-delivery` | Installed | Installed | Absent | Absent | Absent |
| `shared-agent-memory` | Installed | Installed | Installed | Installed | Installed |
| `sonarqube-assurance` | Absent | Installed | Absent | Installed | Absent |
| `source-synthesis` | Installed | Installed | Installed | Installed | Installed |
| `spec-driven-delivery` | Installed | Installed | Absent | Absent | Installed |
| `studio-mission-control` | Installed | Installed | Installed | Installed | Absent |
| `tech-org` | Installed | Installed | Installed | Installed | Installed |
| `test-audit` | Installed | Installed | Absent | Absent | Absent |
| `text-diagramming` | Installed | Installed | Installed | Installed | Installed |
| `trivy-assurance` | Absent | Installed | Absent | Installed | Absent |
| `vaultwarden-credential-management` | Installed | Installed | Installed | Installed | Installed |
| `verify-this` | Installed | Installed | Installed | Installed | Installed |
| `webs-hustle` | Absent | Absent | Absent | Absent | Absent |
| `workspace-context` | Installed | Installed | Installed | Installed | Installed |
| `workspace-framework` | Installed | Installed | Installed | Installed | Installed |
| `writing-great-skills` | Installed | Installed | Absent | Absent | Installed |

## Runtime-Native Skills

These IDs are owned by the pinned OpenClaw runtime or an enabled plugin.
Installing one grants the native capability; it never creates a workspace copy.

| Skill | Expected source | Emon | Tinus | Stewie | Satwa | Ramiro |
|---|---|---|---|---|---|---|
| `browser-automation` | `openclaw-extra` | Absent | Absent | Absent | Absent | Absent |
| `diagram-maker` | `openclaw-bundled` | Absent | Absent | Absent | Absent | Absent |
| `summarize` | `openclaw-bundled` | Absent | Absent | Absent | Absent | Absent |

## Installed Counts

- Emon: 33 company managed-copy skills; 0 runtime-native skills; 33 installed skills total.
- Tinus: 32 company managed-copy skills; 0 runtime-native skills; 32 installed skills total.
- Stewie: 19 company managed-copy skills; 0 runtime-native skills; 19 installed skills total.
- Satwa: 24 company managed-copy skills; 0 runtime-native skills; 24 installed skills total.
- Ramiro: 21 company managed-copy skills; 0 runtime-native skills; 21 installed skills total.

Regenerate with `task generate-agent-skill-matrix`. Verification fails
when this document drifts from the bundle source of truth.
