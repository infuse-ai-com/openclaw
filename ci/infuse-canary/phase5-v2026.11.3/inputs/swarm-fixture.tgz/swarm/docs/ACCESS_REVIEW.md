---
title: Access Review
description: This file tracks intentional runtime exceptions and temporary
  bridges. It is not a secret store. Never paste token values, session values,
  kubeconfigs, cookies, or exported vault content here.
type: report
status: active
owner: team:agent-platform
tags:
  - report
  - access
  - review
---
# Access Review

This file tracks intentional runtime exceptions and temporary bridges. It is not
a secret store. Never paste token values, session values, kubeconfigs, cookies,
or exported vault content here.

## Review Rules

- Every persistent runtime secret must be declared in the owning agent bundle or
  listed below as a named exception.
- Every exception needs an owner, reason, review trigger, cleanup target, and
  verification command.
- Promote an exception to durable access only through a reviewed bundle update.
- Remove unused Kubernetes Secrets after removing the corresponding bundle entry
  or exception record.

## Active Exceptions

| ID | Owner | Runtime target | Reason | Review trigger | Cleanup / verifier |
| --- | --- | --- | --- | --- | --- |
| `agent-vaultwarden-direct-accounts` | persistent agents | Secrets `agents-swarm/<agent-id>-vaultwarden` | Per-agent Vaultwarden bootstrap for account-and-collection-scoped task lookup without storing app credentials directly in the pod. | Replace with brokered secret-access if this pattern expands beyond the pilot. Review after each account or collection-membership change. | `AGENT_ID=<agent-id> task verify-agent-vaultwarden-auth`; remove a secret if that agent's direct-account path is stopped. |
| `agent-authentik-logins` | persistent agents | Secrets `agents-swarm/<agent-id>-authentik` | Per-agent Authentik service identities for lifecycle-managed SSO/app access. | Review with Vaultwarden direct-account access and after any Authentik group/app-access change. | `AGENT_ID=<agent-id> task verify-agent-authentik-secret`; remove a secret if that agent identity is disabled. |
| `ramiro-role-mailbox-imap-smtp` | `agent-intake` | Vaultwarden item `Email / rmr.g@infuse-ai.com account`, accessed through the role-scoped Vaultwarden runtime helper | Role mailbox access through `mail_intake.py` over IMAP and exact approved sends through `approval_email.py` over SMTP. Ramiro may summarize leads, prepare drafts, and send only the approved artifact/action. | Review after each real intake during the first month; revoke immediately after unrelated-mail browsing, noisy behavior, or unapproved send attempts. | `task smoke-agent-intake-mail-auth`; revoke or rotate the role mailbox item if intake role is paused. |
| `openclaw-runtime-auth-bridge` | active swarm agents | Secret `agents-swarm/openclaw-runtime` | Temporary OpenClaw auth/profile bridge for persistent runtime startup while scoped per-agent model credentials are designed. | Replace with scoped model/provider auth per agent. Review before increasing agent autonomy or adding new long-lived agents. | `task verify-agent-profile`; remove unused keys after replacement rollout. |

## Recently Removed Or Superseded

| ID | Outcome |
| --- | --- |
| `emon-cursor-oauth` | Retired after the swarm standardized new work on Codex/ChatGPT/OpenAI-backed routes; the deployment no longer consumes the Secret or exposes Cursor aliases. |
| `tinus-cursor-oauth` | Retired after the swarm standardized new work on Codex/ChatGPT/OpenAI-backed routes; the deployment no longer consumes the Secret or exposes Cursor aliases. |
| `emon-markdowngpt-app-credentials` | Superseded by the named `emon-markdowngpt-level-3-dogfood` exception for the 2026-06-05 certification attempt. |
| `emon-markdowngpt-level-3-dogfood` | Removed on 2026-06-09 by Fito request; delete Secret `agents-swarm/agent-coordinator-markdowngpt-dogfood` and RoleBinding `mdgpt/agent-coordinator-mdgpt-operator` if present. |

## Add A New Exception

Add one row with:

- stable ID;
- owning agent or runtime;
- runtime target name only, never the value;
- reason and approval context;
- review trigger or expiry;
- cleanup command or verifier.
