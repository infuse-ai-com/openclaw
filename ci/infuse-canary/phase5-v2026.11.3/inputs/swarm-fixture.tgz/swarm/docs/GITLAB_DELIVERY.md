---
title: GitLab delivery
description: Protected GitLab image publication and manual agents-swarm rollout with advisory security scans.
type: runbook
status: active
owner: team:agent-platform
tags:
  - runbook
  - gitlab
  - kubernetes
  - delivery
---
# GitLab delivery

GitLab image identity and rollout authorization remain mandatory. Merge requests
run repository verification only. Image-relevant protected `main` pushes
automatically build and scan a new immutable candidate without deploying it.
`RUN_GITLAB_DELIVERY=1`
verifies/rescans the selected image and exposes manual deployment after image
identity verification. A new digest needs an explicit release selection and
source record. Security scan results are advisory under Fito's 13 November
decision below; they do not require a passing vulnerability exception.

## Advisory security scans, 2026-11-13

Fito approved non-blocking image scans for this internal swarm. Candidate and
delivery pipelines still run the complete HIGH/CRITICAL scan with unfixed
findings included. The scan job retains its failure status with
`allow_failure: true`, which produces GitLab's orange warning indicator; no
`|| true` or finding suppression hides failures. Scanner errors also warn.

The separate `openclaw_image_exception_guard` job is retired. Finding drift,
historical exception expiry and missing scan reports cannot block deployment.
The manual deploy job depends only on `verify_approved_openclaw_image` and its
immutable image/source artifacts; it can become available while the scan is
running. It does not download or require scan/exception artifacts.

Registry digest verification, selected source identity, protected-main rules,
explicit pipeline opt-in, manual deployment, scoped deployer permissions and
runtime compatibility checks remain required. This policy does not approve a
new image, trigger deployment or resume Ramiro's mail. Weekly assurance remains
a separate reporting workflow. Findings remain remediation work, not a claim
that the image is vulnerability-free.

See [GitLab's allowed-failure semantics](https://docs.gitlab.com/ci/yaml/#allow_failure).

## Authority boundary

- GitLab project: `platform/agents/openclaw-k8s-swarm`
- Namespace: `agents-swarm`
- Deployment identity:
  `system:serviceaccount:agents-swarm:gitlab-openclaw-swarm-deployer`
- Mutable resources: exactly `deployment/agent-developer`,
  `deployment/agent-designer`, `deployment/agent-infra`,
  `deployment/agent-intake`, and `deployment/agent-coordinator`
- Denied: Secret reads, pod exec, PVC mutation, RBAC mutation, pod deletion,
  and access outside `agents-swarm`
- Registry publication: the project-scoped `robot$gitlab-openclaw-swarm`
  account may publish only inside the Harbor `agents-swarm` project

## Current release source and historical decisions

`deploy/gitlab/approved-openclaw-image.env` owns the selected all-agent image,
exact source and protected build/scan receipt IDs. GitLab delivery and weekly
runtime assurance read that same selection. It contains no finding thresholds
or expiry gate. `image-risk-exception.env` and the dashboard-fleet exception
retain historical evidence; they no longer select the current all-agent image.
Read the active selection, current pipeline evidence and phase tracker before
release. Selection is not proof that the fleet has already converged. The dated cutover and dashboard decisions
below preserve history; they do not select a new deployment candidate.

## Candidate build cache

The automatic protected-main candidate build imports and exports BuildKit cache records at
`registry.infuse-ai-tech.party/agents-swarm/openclaw-agent-buildcache:buildcache`.
The shared rootless-build component uses the proved `overlayfs` snapshotter
and exports mode-max records after publishing the immutable candidate image.

The mutable cache reference is an optimization only; the scan and any later
delivery remain bound to the candidate image digest. Merge requests remain
credential-free. Protected `main` builds are change-aware and run when the CI
or Docker context contract changes: `.gitlab-ci.yml`, `.dockerignore`, the
OpenClaw image tree, scripts, runtime configuration, prompts, or the bundled
behavioral-observability plugin. Other `main` changes run verification without
accessing Harbor or mutating the cache.

Protected pipeline 1307 built and published the reviewed image at exact digest
`sha256:ff0fac8da285c4b94e1b95ab94b4cbafdd06d10dd161104941894fe6ba4e1ea9`
from source `9995599fbbf2889f1a815c283369b6b012bc239d`. Later delivery pipelines
verify that existing Harbor artifact instead of rebuilding it, because a new
build would produce a different digest outside the reviewed exception.
The exception records both the complete HIGH/CRITICAL finding tuple set and
the fixed-finding subset. The complete set is identical to the previously
approved image and remains visible in delivery evidence.

At the historical cutover, Trivy emitted the unsuppressed report and its
enforcement invocation remained visibly failed/allowed. A blocking guard required the exact
image, source commit, scanner, finding tuple digest, counts, owner, rationale,
and expiry. That cutover result was **not clean**: 2 distinct CRITICAL findings
(2 occurrences) and 23 distinct HIGH findings (73 occurrences), represented
by 46 unique finding tuples. Its recorded expiry is
`2026-12-07T23:59:59Z`. The 13 November advisory policy supersedes that
vulnerability admission gate; historical approvals and raw findings are retained.

After image identity verification, the first manual job advances only Tinus
(`agent-developer`) and proves the four peer Deployment templates were untouched.
The peer-fleet job is unavailable until that same-pipeline Tinus gate succeeds;
it then rechecks Tinus against the exact image digest, source, version, readiness,
zero-restart Pod identity and known regression signatures before advancing the
other four agents. Both jobs validate readiness, immutable identity, known
regression signatures and PVC retention. The
runtime source annotation remains bound to the image's actual source commit,
while the GitLab pipeline annotation records the delivery pipeline.

The historical image-only rollback job is retired from new pipelines. Its old
image lacks the renewed Git credential bootstrap and source/configuration
contract. Existing historical pipelines can still display that old action;
do not use it for the renewed fleet. Renewal recovery requires the privately
captured same-version Deployment, own Git configuration, managed skills and
persona state, with preservation of newer agent work. See the
[renewal recovery contract](plans/active/agent-system-renewal-qualification-2026-11-12.md).
No automated recovery is newly qualified by this removal.

## Dashboard fleet image exception, 2026-11-10

Fito approved the exact image
`sha256:488aaa8ec4c115bb5782f251f8832de1f9beb914e1be3bb35734ad46b25a20fe`
from source `8172b35256dd05b2ead53378c53714e86381a16c` for Emon Lusk
(`agent-coordinator`), Ramiro Garcia (`agent-intake`) and Satwa Nutella
(`agent-infra`) only, through `2026-12-07T23:59:59Z`. Tinus and Stewie retained
their existing image and exception at that decision. The separate
`deploy/gitlab/dashboard-fleet-image-risk-exception.env` records this scope.

Pipeline 1459 built the image in job 6649 and scanned it in job 6650 with
Trivy 0.74.0. The full scan has 18 distinct CRITICAL IDs (36 occurrences) and
406 HIGH IDs (665 occurrences), or 672 unique tuples. The 46 tuples with
available fixes are unchanged: 2 CRITICAL IDs and 23 HIGH IDs. Against the
previous approved scan, the full set adds five HIGH IDs affecting Kerberos
libraries and linux-libc-dev (17 tuples), and removes twenty HIGH rsync IDs
(20 tuples). This is an approved exception, **not a clean scan**.

A protected-main pipeline with `RUN_GITLAB_FLEET_IMAGE_QUALIFICATION=1`
verifies the existing registry digest and rescans it with the same advisory
failure behavior. The historical comparison helper still supports
`--profile dashboard-fleet` for offline analysis. This pipeline cannot instantiate the all-agent deploy
job, even if `RUN_GITLAB_DELIVERY=1` is also set. The all-agent delivery path
selects its separate current exception.

For this approved integration, the operator uses
`rollout-and-verify-persistent-agent.sh` in drain mode for intake, infra, then
coordinator, with captured live Deployments amended only for the qualified
image, gateway authentication, dashboard origin and Studio local password
reference. Preserve PVCs and all unrelated settings. Require fresh image
qualification before rollout; retain the captured prior configuration until
all five dashboard gateways pass browser verification. Retire only these
three agents' direct LoadBalancer Services after their L7 routes are verified.
Weekly assurance checks the per-agent image assignments, private ClusterIP
backends and both deployed image digests; it continues to report findings.

## Recovery decision

Fito explicitly excluded backup and restore work from this authority cutover
on 2026-11-07. No GitLab backup, restore, or PVC-content job is provided. This
deviation must remain visible in the completion evidence and must not be
interpreted as restore qualification.

## Weekly assurance

The read-only weekly schedule is a separate GitLab graph selected only by
`ASSURANCE_MODE=weekly`. It runs repository/application contracts, dependency
and Sonar checks, repository security scanning, exact-name reads of the five
agent Deployments, dashboard Services, OTEL runtime, five workspace PVCs and
five maintenance CronJobs, release-pin checks, the exact deployed-image scan,
and recovery-readiness classification. It emits one structured result per
reported domain and routes only the failure summary through the approved
`nightly-checks` webhook.

Schedule pipelines cannot instantiate image verification, publication,
deployment, or rollback even if `RUN_GITLAB_DELIVERY` is accidentally present.
The assurance Kubernetes identity is exact-name/get-only, the assurance Harbor
robot is pull-only, and the existing deployer/publisher credentials remain
scoped outside assurance environments. The recovery check must remain red
until an explicitly approved, live workspace/PVC restore exercise qualifies
that boundary.

The reviewed RBAC source is
`deploy/gitlab/openclaw-swarm-assurance-rbac.yaml`; it grants only `get` on the
six exact Deployments, six exact Services, five exact workspace PVCs, and five
exact maintenance CronJobs used by the checks. It grants no list/watch, pod,
log, Secret, exec, RBAC, or mutation permission.
