---
title: Current State
description: "Last reviewed: 2026-11-12."
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - current
  - state
---
# Current State

Last reviewed: 2026-11-12.

This file is the short, current truth for the OpenClaw Kubernetes swarm. Longer
plans and decision logs remain useful history, but this file should be updated
whenever the live agent lineup, deployment target, or verification contract
changes.

## Renewal qualification

All five agents run renewal image `acf9b596cd06…` from source `5489df673016`
on OpenClaw 2026.11.1, after protected qualification pipeline 1670 and a staged
operator rollout. Each passed runtime smoke, own GitLab identity/isolation,
skill discovery, persona parity, source migration and cron pause checks, with
zero restarts. The exact scan has zero fixable CRITICAL and 18 fixable HIGH IDs;
Fito's temporary exception expires 7 December, with remediation tracked.
Memory exports from the four admitted writers passed CI in open MRs !11–!14.
Ramiro memory publication is deferred to the memory refactor; his read-only
access and token are unchanged. No memory MR auto-merges.
Ramiro's three mail jobs remain paused; mailbox authentication needs repair.
See [qualification and job evidence](plans/active/agent-system-renewal-qualification-2026-11-12.md).

## Runtime

- Target cluster: InfuseAI Kubernetes.
- Namespace: `agents-swarm`.
- Image: `registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:<build>`.
- Deployment owner: GitLab `.gitlab-ci.yml`. Ordinary main and MR pipelines
  verify source. `RUN_GITLAB_CANDIDATE_BUILD=1` builds/scans a candidate;
  `RUN_GITLAB_DELIVERY=1` verifies the exact approved image and exposes
  manual serialized rollout after the risk guard.
- Release configuration: pinned OpenClaw `2026.11.1` at source
  `19818bb59a7bf9d4e9989fb9a4df6f1b4ffe8ca6`, installed through its sealed
  consumer lock with Codex, Mattermost, ACPX, and diagnostics resolved from the
  Core bundle; Codex CLI is `0.160.0` and ACPX CLI is `0.19.1`. The deployment
  remains unproven until the owning pipeline and per-agent runtime smoke pass.
- Recorded pre-upgrade rollback candidate: OpenClaw 2026.10.3 at Harbor digest
  `sha256:5b660ae33ba1587475fdfc56df989e490ff904f6382d3ea8943a75c3183ecec7`
  from swarm source `b32e131d3413f4869a317264db27e81f76c6f4bc`. Because 2026.11.1 can
  migrate shared state from schema 20 to schema 22, use that image only with the
  matching verified pre-upgrade PVC recovery artifact. Never lower schema
  markers or delete runtime state to force a downgrade.
- Maintained Kubernetes overlay: `k8s/overlays/infuseai/`.
- Local verification path before PR/update: `task verify`.
- CI-safe verification path: `task verify-ci`.
- Persistent-agent rollouts use `Recreate`, a 420-second termination grace
  period, Gateway `/readyz` and `/healthz` probes, and a lifecycle `preStop`
  drain. Stable delivery defaults to a developer-only canary, a bounded
  designer/infra/intake leaf wave, and coordinator-last promotion. Each agent
  retains an independent single-writer stop/apply/start boundary, and every
  replacement must be ready with a new Gateway process identity before its
  batch passes. `OPENCLAW_FLEET_ROLLOUT_STRATEGY=sequential` restores the prior
  one-at-a-time order.
- Stable CI uses a 30-second bounded active-work budget, requires an exact
  Gateway predecessor handoff, and enforces a 30-second pod-deletion SLO.
  Controller-led rollouts arm the exact predecessor before termination and send
  a 15-second grace in the initial pod delete request. This is required because
  OpenClaw treats SIGTERM as a restart; `preStop` remains the safety path for
  uncoordinated termination. The 420-second Kubernetes grace remains an
  emergency ceiling for uncoordinated termination.
  `OPENCLAW_ROLLOUT_MODE=drain` is the opt-in 300-second fail-closed mode.
- Persistent-agent pod templates record the exact Swarm source revision.
  SQL-platform-only changes preserve all five agent deployments; missing or
  mixed live provenance forces the normal full canary-wave rollout.
- Persistent agents have zero artificial startup delay. Workspace mounts use
  `fsGroupChangePolicy: OnRootMismatch`, and recursive ownership repair runs
  only when the workspace root is not owned by `10001:10001`.
- Skill sources declare `managed-copy` or `runtime-native` materialization.
  Runtime-native IDs are never copied into agent workspaces, and live smokes
  reject source-precedence shadows.
- Runtime toolbox discovery: `openclaw-agent-capabilities --json`; schema v2
  distinguishes browser/image capabilities from the portability contract for
  attached evidence packages.
- Portable artifact verification:
  `openclaw-agent-evidence-verify <directory-or-zip> --command '<command>'`.
  It runs from an isolated copy with ambient Node resolution and agent-toolbox
  fallback disabled; pod-local success alone is not portable-package evidence.

Merging source does not deploy by itself. Release activation remains explicit;
see `docs/GITLAB_DELIVERY.md`.

## Mission Execution Contract

- Fito owns company direction and final human decisions. Kapiteky carries that
  direction into coordination with Emon and advises on coherence, priorities,
  constraints, and the operating system.
- Emon owns every activated mission end to end, including integration, PRs,
  merges, deploys, verification, reconciliation, and closeout. Capability gaps
  remain Emon-owned until routed or precisely escalated.
- Studio owns native mission lifecycle for enrolled projects. OpenClaw owns
  sessions and Mattermost transports the managed conversation. Old JSON/SQL
  registry stewards and portfolio candidates remain disabled; do not revive
  them during an upgrade. Source support is distinct from project enrollment.
- Backlog delivery is represented by one bounded mission over the approved
  tickets; portfolio discovery only proposes complete mission briefs.

## Active Persistent Agents

| Agent ID | Name | Role | Mattermost behavior |
| --- | --- | --- | --- |
| `agent-developer` | Tinus Lordvals | Implementation engineer | Mention-only in any Mattermost channel where the bot is a member |
| `agent-designer` | Stewie Hobs | Design and UX review | Mention-only in any Mattermost channel where the bot is a member |
| `agent-infra` | Satwa Nutella | Infra/platform operator | Mention-only in any Mattermost channel where the bot is a member |
| `agent-coordinator` | Emon Lusk | Generalist coordinator | Ambient in any Mattermost channel where the bot is a member |
| `agent-intake` | Ramiro Garcia | Draft-only consulting intake operator | Mention-only in any Mattermost channel where the bot is a member |

## Source Of Truth

- Company-level agent architecture decision: `company-docs/docs/40-agent-system/agent-source-repo-architecture.md`.
- Persona source: GitLab project `platform/agents/openclaw-agents-persona`.
- Memory source: GitLab project `platform/agents/openclaw-agents-memory`.
- Skill source: GitLab project `platform/agents/agent-skills`.
- Deployed skill and access intent: `config/agent-skill-bundles/*.json`.
- Runtime skill registry: `config/skill-catalog.json`.
- The company skill source is pinned to one reviewed `agent-skills` main commit;
  startup sync verifies branch ancestry and materializes that exact revision.
- Agent docs: `docs/agents/*.md`.
- Runtime overlays: `k8s/agents/<agent-id>/`.
- Deployment overlay: `k8s/overlays/infuseai/`.
- Tailscale dashboard exposure: `docs/TAILSCALE_AGENT_DASHBOARDS.md` and
  `k8s/tailscale/openclaw-agent-dashboard-proxygroup.yaml`.
- Runtime exception/access review: `docs/ACCESS_REVIEW.md`.
- Explicit task assignment registry: `/workspace/tasks/task-registry.json`, with
  first-run bootstrap handled by
  `openclaw-agent-task-workspace --agent-id agent-coordinator ensure-registry`.
  A present empty registry means no active task assignment; it is not a
  coordination blocker.

`scripts/verify-agent-skill-bundles.py` must reject drift between active bundle
JSON and the Kubernetes runtime patch values for `AGENT_SKILLS` and
`OPENCLAW_CONFIG_JSON`.

All persistent swarm agents currently share the operating substrate
`tech-org`, `gitlab`, `mattermost-channel-management`, and
`vaultwarden-credential-management`. Role-specific skills stay in each bundle;
credential values remain controlled by explicit bundle targets and approval
boundaries.

Ramiro Garcia / `agent-intake` is intentionally narrower than Emon: he may read
approved consulting email context through the scoped role mailbox IMAP helper,
draft internal briefs/replies/proposals/handoffs, and update assigned
client-project docs. He must not send external email through the SMTP helper,
make pricing/timeline/
legal/commercial commitments, browse unrelated mail/client context, or post
client-facing claims without Fito approval.

All persistent swarm agent profiles set OpenClaw `verboseDefault` to `off` at
the runtime default and agent level. This keeps internal/tool chatter quiet by
default while normal answer length remains driven by the user request and
channel workflow.

All persistent swarm agents use Mattermost `replyToMode: "all"` so provider
thread handling works. This controls outbound thread placement only; inbound
wake-up is controlled by Mattermost channel membership and mention gating. Mattermost
`streaming.mode` is `progress` with `finalDelivery: "separate"`: a bounded typed
progress post is edited in place, the final reply is sent as an ordinary post,
and successful final delivery removes the progress post. The pinned progress
headline is `Thinking… please wait` rather than the ambiguous `|` sentinel.
Progress command rendering uses `commandText: "raw"`, restoring the actual
exec/Bash command text instead of the redacted tool-only label. The existing
120-character per-line bound still compacts exceptionally long commands.
Mattermost reaction actions are explicitly enabled, outbound text uses a
12,000-character chunk limit, and inbound text uses a 1,500 ms per-sender,
per-thread debounce so split replies are collected before dispatch. Control
commands and attachments bypass that debounce. The canonical startup rewrite
sets `surfaces.mattermost.silentReply.group: "allow"` for every persistent
agent. Unmentioned admitted group turns may therefore end silently after a
reaction or other action; explicit mentions and authorized commands still
require a textual response under OpenClaw's reply-obligation policy.
Specialist agents require explicit mentions and disable reply-to-bot,
quoted-bot, and thread-participation implicit mentions. A dispatcher mention
is therefore the only task-root wake; later coordinator or peer replies do not
activate the specialist. Emon /
`agent-coordinator` uses `chatmode: "onmessage"` and is the only agent allowed
to receive ambient group-channel work. Direct messages use
`dmPolicy: "allowlist"` with only Fito allowed. Group handling uses
`groupPolicy: "open"` so Mattermost channel membership is the access boundary:
agents can respond in any channel they are added to. Specialist agents keep
`requireMention: true` plus all three `implicitMentions` flags set to `false`;
Emon keeps `requireMention: false`.

Agent OpenClaw Control dashboards are intended to be private tailnet-only
operator surfaces. Runtime manifests bind the gateway on LAN port `18791` with
token auth and create one Tailscale `LoadBalancer` Service per agent. The
Tailscale Operator, dashboard gateway Secret, and tailnet ACLs must be in place
before relying on the MagicDNS dashboard hostnames.

## Current Debt

- Some temporary runtime access bridges remain while scoped per-agent credential
flows mature. Track them in `docs/ACCESS_REVIEW.md`.
- Agent config is still duplicated between bundle JSON and k8s patches, but the
verification gate now checks the critical runtime fields.
- Several older roadmap/planning docs contain useful history and may mention
earlier three-agent phases. Prefer this file for current-state checks.
- ncase, local/kind, and generic staging deployment overlays were retired after
  the swarm moved to InfuseAI Kubernetes. Treat `docs/RUNTIME_BOOTSTRAP.md` as
  historical reference only.
- The `agent-developer`/`agent-infra` rename keeps a deploy-time compatibility
  shim for old secret names so the first renamed rollout can come up cleanly.
  After the renamed rollout is healthy, the deploy script removes the retired
  old deployments, network policies, Satwa Nutella read-only RBAC, PVCs, and legacy
  secret aliases.
- `agent-infra-kubeconfig` is generated during deploy from the
  `platform-operators/agent-infra-operator` ServiceAccount token. This allows
  Satwa Nutella to run approved pod exec diagnostics while preserving the
  no-Secret-read boundary; the live smoke must show `get secrets: no`.

## Renewal qualification

The 2026-11-12 baseline has five ready agents on OpenClaw 2026.11.1
(`19818bb`). Each API check returns its own active GitLab service account;
native Git reads of the company skill repository also pass in all five pods.
The source migration, new bundle grants and persona revisions still require
their exact-revision rollout. See `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`.

Keep Ramiro’s triage, prefilter and client-waiting reminders paused per Fito’s
2026-11-12 instruction. The own-mailbox credential resolves to the expected
identity, but the read-only IMAP login failed; no messages were fetched or
SMTP mail sent. Repair and qualify the mailbox before proposing resumption.
