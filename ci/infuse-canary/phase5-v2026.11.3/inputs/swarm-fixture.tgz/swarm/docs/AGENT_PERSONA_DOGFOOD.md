---
title: Agent Persona Dogfood
description: Persistent agent personas are now sourced from
  openclaw-agents-persona, while this repo owns the Kubernetes runtime, startup
  sync, PVCs, skill bundles, access grants, and operator runbooks.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - agent
  - persona
  - dogfood
---
# Agent Persona Dogfood

Persistent agent personas are now sourced from `openclaw-agents-persona`, while
this repo owns the Kubernetes runtime, startup sync, PVCs, skill bundles, access
grants, and operator runbooks. This document tracks the v1 dogfood loop for
keeping those layers aligned.

For behavior changes to existing agents, update
`openclaw-agents-persona/agents/<agent-id>/` first. For new-agent scaffolding,
update `openclaw-agents-persona/templates/agent-persona/`. This repo no longer
keeps persona files; it only syncs and installs them into the runtime.

## Goal

Make persona improvements provable in the live swarm, not merely present in a
source repo.

A persona change is done only when:

- `openclaw-agents-persona` contains the reviewed source files;
- the live agent PVCs have synced those files from the reviewed source;
- local PVC drift is understood and either promoted or ignored deliberately;
- each affected agent can explain which version/source it is using;
- common role tasks show the expected behavior in Mattermost or a controlled
  test thread.

## Current Improvement Backlog

### Runtime Sync And Drift

The largest risk is that the repo is good but live PVC state is stale.

Improve the operator loop so a maintainer can routinely:

- compare live PVC core files against `openclaw-agents-persona`;
- see the persona source commit or branch each agent synced;
- report which files differ without printing private contents;
- promote accepted live changes back through `openclaw-agents-persona`;
- restart or resync an agent only after accepted changes are in source control.

Related files:

- `docs/AGENT_DRAFT_SYNC.md`
- `scripts/agent-local-drift-report.py`
- `scripts/sync-agent-persona-startup.sh`
- `scripts/install-agent-runtime-files.sh`
- `scripts/verify-agent-persona-source.sh`

### Golden Handoff Briefs

Personas describe the role, but Emon still needs crisp reusable handoff briefs.

Add copyable examples for:

- Tinus / `agent-developer`: implementation, repo-local verification, browser
  smoke, release-readiness evidence.
- Stewie / `agent-designer`: screenshot critique, UX QA, accessibility,
  design-parity review.
- Satwa / `agent-infra`: rollout triage, logs/events review, Kubernetes smoke,
  next-safe-action recommendation.
- Ramiro / `agent-intake`: lead classification, proposed reply, proposal/SOW
  outline, delivery handoff.

Each brief should include goal, source context, scope, non-goals, acceptance
criteria, verification, approval boundaries, and report thread.

### Authority Examples

The persona files list approval boundaries, but agents need examples.

Add examples such as:

- Tinus may create a branch, commit, PR, and verification report when assigned a
  scoped repo task.
- Emon may complete normal scoped review/merge/deploy loops when evidence is
  clean and no sensitive boundary is crossed.
- Satwa may run read-only Kubernetes diagnostics by default, but must stop
  before scaling, patching, deleting, restarting, or changing RBAC/secrets unless
  explicitly authorized.
- Ramiro may draft external messages and client artifacts, but must not send or
  commit pricing, timelines, legal/commercial terms, or client-facing promises
  without exact approval.

These examples should live near the relevant persona, and runtime docs should
point to them.

### Role Acceptance Tests

Static file validation is useful but not enough. Add small role acceptance tests
that feed sample handoffs into each persona and check whether the expected
behavior appears.

The checks should confirm that the agent:

- loads the right context pack and stops there;
- names the correct approval boundary;
- chooses the correct report thread and recipient;
- asks for missing acceptance criteria instead of guessing;
- reports verification status and residual risk clearly;
- avoids unrelated repo, channel, credential, or namespace expansion.

Start with human-reviewed fixtures before automating model evaluation.

### Context Packs

The source-of-truth map now exists in the personas, but agents still need
task-sized context packs.

Add compact context packs for common surfaces:

- Finaxis delivery.
- MarkdownGPT delivery.
- OpenClaw swarm runtime.
- Consulting intake.
- Infrastructure/CI/CD incident triage.
- New persistent agent onboarding.

Each pack should identify the first 3-6 docs to load and which docs to avoid
unless the task requires them.

### Mattermost Behavior

Persistent agents need very explicit Mattermost expectations.

Clarify examples for:

- when to reply in the assigned thread;
- when to mention another persistent agent by handle;
- when to stay quiet;
- when a plain name is only a reference and not a summon;
- how to report local pod-only observations without implying global swarm state.

### Memory Rules

The current rule is role-scoped, short, and secret-free. Dogfood still needs
examples for what goes where:

- `MEMORY.md`: durable role corrections that should affect future behavior.
- `memory/YYYY-MM-DD.md`: raw daily notes and recent task context.
- `openclaw-agents-memory`: reviewed or exported memory that should survive pod
  rebuilds and be searchable by the right agents.
- Project repos/company docs: durable decisions, runbooks, architecture, or
  product context that should not live as private agent memory.

### Product And Initiative Context

The personas now explain Infuse AI at a company level, but active initiatives
still need narrower context.

Prefer context packs over bloating every persona with details about:

- Finaxis.
- MarkdownGPT.
- consulting/client projects;
- OpenClaw swarm runtime;
- Agentic Kaggle;
- self-hosted LLM work;
- infrastructure/security plans.

## How Fito Can Help

The fastest way to improve the personas is to provide concrete examples.

Useful inputs:

- 2-3 moments where an agent disappointed, hesitated, over-asked, or felt
  confused.
- For each agent, the happy-path actions it should do without asking.
- Decisions Emon can make alone versus decisions that must go to Fito or
  Kapiteky.
- Live PVC snippets or remembered behavior that felt better than the repo
  version.
- One full dogfood scenario per role, with what a good answer should look like.

## Dogfood Loop

Use this loop after persona changes:

1. Merge the persona change in `openclaw-agents-persona`.
2. Deploy or restart the swarm path that syncs personas into live PVCs.
3. Run persona source verification for each active agent.
4. Run local drift report for each active agent.
5. Ask one controlled test task per affected role.
6. Capture failures as either persona fixes, runtime sync fixes, context-pack
   fixes, or skill/runbook fixes.
7. Promote durable improvements through PRs.

## Acceptance For V1

V1 is good enough when:

- all active agents report `source_kind == "agent"` for persona install;
- live persona files are clean against their install manifests;
- the synced persona source is at or after the expected
  `openclaw-agents-persona` commit;
- no active agent depends on an in-repo swarm template fallback;
- Emon can create one correct handoff for each specialist without extra Fito
  explanation;
- each specialist can name the right source docs, stop gates, and report shape
  for its sample task.
