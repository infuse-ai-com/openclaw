---
title: Backoffice Agent Command Center Plan
description: Backoffice should become the human-facing command center for the
  OpenClaw swarm.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - backoffice
  - command
  - center
---
# Backoffice Agent Command Center Plan

Backoffice should become the human-facing command center for the OpenClaw swarm.

The Kubernetes runtime, Mattermost conversations, Vaultwarden items, and repo docs remain the systems of record for their own domains. Backoffice should make the swarm understandable and operable without becoming another secret store or hidden control plane.

## Product Goal

Give Fito and Kapiteky one place to answer:

- Which agents are live?
- What are they allowed to do?
- Which channels and repos are they scoped to?
- Are they healthy?
- What task are they working on?
- What credentials exist for them, without revealing values?
- What needs human approval?

## Scope For V0

V0 should be read-only by default.

Show:

- agent friendly name and runtime slug;
- Mattermost username;
- Kubernetes deployment, namespace, image tag, and readiness;
- PVC name and basic status;
- skill bundle summary;
- default model, thinking depth, reasoning visibility, and runtime;
- declared credential access from `config/agent-skill-bundles/<agent-id>.json`;
- current runtime toolbox image version;
- last smoke result when available;
- links to repo docs, Mattermost channel, and GitLab repo/PRs.

Do not show:

- token values;
- full Kubernetes Secret contents;
- OAuth/auth JSON;
- raw environment variables;
- private memory contents;
- broad Mattermost logs unless explicitly scoped.

## Source Mapping

Backoffice should read or receive summarized data from:

- `openclaw-k8s-swarm` for declared identity, skill bundle, credential access, and runtime docs;
- Kubernetes API for deployment/PVC/image/readiness status;
- `core/openclaw-agent-model-policy-feed` for model/thinking defaults and live drift;
- Mattermost API for bot username, team/channel membership, and recent activity metadata;
- GitLab for repo/PR/build status;
- Vaultwarden metadata for item existence and collection ownership, never secret values;
- OpenClaw runtime smokes for agent health and toolbox readiness.

## Suggested Views

### Agents

One row per persistent agent:

- name: Tinus Lordvals, Stewie Hobs, Satwa Nutella;
- slug: `agent-developer`, `agent-designer`, `agent-infra`;
- Mattermost handle;
- status: ready, degraded, stopped, needs access, needs review;
- current channel scope;
- model and thinking defaults;
- current task or idle;
- last smoke timestamp/result.

### Agent Detail

Sections:

- identity and role;
- active Kubernetes workload;
- skill bundle;
- model policy, including declared vs observed model, thinking depth, reasoning visibility, runtime, and drift status;
- credential access intent;
- current repo assignments;
- Mission Control journal and reviewable artifacts;
- recent handoffs/reports;
- approval history;
- known caveats.

### Mission Control

Show public working state published by each agent:

- current journal status and focus;
- recent highlights and blockers;
- latest human-reviewable HTML artifacts;
- source freshness and missing-publish warnings.

Agents publish immutable bundles through the authenticated Artifact Registry.
Backoffice reads exact Registry revisions and performs lifecycle operations
through its separately scoped Registry clients. The retired filesystem feed is
recorded in `docs/BACKOFFICE_MISSION_CONTROL_FEED.md` only as migration history.

### Access Review

For each agent:

- allowed Vaultwarden item names;
- target Kubernetes Secret name/key;
- visibility rule, such as `runtime-env-only`;
- temporary elevations;
- expiry/review condition;
- stale access warnings.

### Tasks

Show work assigned through Mattermost or future Backoffice actions:

- task title;
- assigned agent;
- source channel/thread;
- repo/path scope;
- status;
- verification command;
- result link.

## Control Progression

Start read-only. Add writes only after the display model is trusted.

1. Read-only inventory and status.
2. Read-only access review.
3. Human-triggered smokes.
4. Human-triggered repo sync for an agent.
5. Human-approved temporary credential elevation.
6. Human-approved task dispatch.

Writes should call existing repo scripts or new small audited scripts. Backoffice should not invent a parallel runtime workflow.

## Approval Boundaries

Backoffice may eventually trigger:

- smoke checks;
- agent restarts;
- repo sync into a PVC;
- task dispatch to Mattermost;
- temporary access requests.

Backoffice must not silently:

- reveal secrets;
- create broad tokens;
- change DNS/firewall/router settings;
- grant cluster-admin;
- merge PRs;
- deploy production changes;
- add agents to external/client channels.

## First Implementation Slice

The first Backoffice slice should be small:

- add an Agents page or section;
- show Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon from a static or API-backed manifest;
- show declared access from the bundle JSONs;
- show live Kubernetes readiness for InfuseAI `agents-swarm`;
- link to `docs/AGENT_WORKER_READINESS_PLAN.md` and each `docs/agents/<agent>.md`;
- include a clear `No secret values are displayed` rule in the UI/API contract.

Acceptance:

- Fito can see all live agents and their runtime status;
- credential access is visible as names and targets only;
- status refresh does not require printing or storing secret values;
- no operational write button exists until the read-only view is reviewed.

## Open Questions

- Should Backoffice read swarm repo JSON directly from Git, from an API, or from a synced internal catalog?
- Should Mattermost task state be inferred from threads or explicitly registered by Kapiteky?
- Should agent smokes write machine-readable result files into the repo/PVC for Backoffice to ingest?
- Which app owns approval buttons: Backoffice, Mattermost, or OpenClaw gateway callbacks?
