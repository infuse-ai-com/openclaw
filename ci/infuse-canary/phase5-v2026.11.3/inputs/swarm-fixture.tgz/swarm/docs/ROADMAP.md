---
title: Roadmap
description: Defines the staged delivery path from repository bootstrap through
  durable, governed Kubernetes-hosted OpenClaw agents.
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - roadmap
---
# Roadmap

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


## Milestone 0 - Repo Bootstrap

- Create Azure DevOps repo under `Infuse AI`.
- Add architecture, security, and Kubernetes skeleton.
- Keep company context referenced, not copied.
- Add repo map, decision log, Taskfile automation, and CI verify gate.

## Milestone 1 - Local Runtime Image

- Define the base OpenClaw runtime image.
- Mount workspace at a stable path.
- Validate startup with a local or staging namespace.
- Add a one-command smoke check.
- Add local/kind overlay for local cluster mechanics.

Acceptance:

- Pod starts without privileged mode.
- PVC persists a workspace marker across restart.
- Logs show a healthy runtime.

## Milestone 2 - Browser Runner

- Add Playwright runner image/job.
- Support headless smoke tests.
- Add headed Xvfb mode.
- Add optional noVNC debugging deployment.

Acceptance:

- A sample app smoke test can capture screenshot and trace artifacts.
- Rendering failures can be inspected in a visual session.

## Milestone 3 - Build Runner

- Choose BuildKit/rootless, Kaniko, or remote Docker context path.
- Add sample image build.
- Push to the chosen registry.

Acceptance:

- Build does not require broad privileges in the main agent pod.
- Image provenance and logs are inspectable.

## Milestone 3.5 - Worker-Ready Agents

- Add controlled per-task repo checkout into agent PVCs.
- Add per-agent Git/Azure DevOps credential flow through declared Vaultwarden items.
- Add Satwa Nutella bounded Kubernetes diagnostics permissions for `agents-swarm`.
- Add repo/toolbox smoke checks that prove agents can inspect assigned repos without leaking secrets or sharing editable working trees.
- Validate one bounded Mattermost task each for Stewie Hobs, Satwa Nutella, and Tinus Lordvals.

Acceptance:

- At least one assigned repo can be checked out into an isolated task workspace in an agent PVC.
- Satwa Nutella can inspect pods/events/logs without secret access or write verbs.
- Agents can report what they inspected, what they did not inspect, and what elevation they need.
- Credential access remains declared in bundle JSON and delivered through runtime sync only.

## Milestone 4 - Private Networking

- Decide Tailscale pattern.
- Wire private access to runtime/admin endpoints.
- Document ACL expectations and operator access.

Acceptance:

- No public admin endpoint is required.
- Runtime can reach approved internal services.

## Milestone 5 - Agent Swarm

- Define worker roles and permission levels.
- Add task handoff templates.
- Add review and verification loop.
- Integrate company-docs context pack rules.
- Update the live agent lineup around the current operating model:
  - keep Stewie Hobs / `agent-designer` as the design and UX review agent;
  - pivot Satwa Nutella / `agent-infra` into the infra/platform operator;
  - pivot Tinus Lordvals / `agent-developer` into the engineer role instead of keeping a separate release-only agent;
  - keep Emon Lusk / `agent-coordinator` as the generalist coordinator with broad company guidance and superpowers.
- Keep Ramiro Garcia / `agent-intake` narrow as the consulting-side intake agent for lead triage, discovery briefs, proposal/SOW drafts, email-context summaries, and delivery handoff.
- Treat release verification as part of the engineer + agentic-product-engineering delivery loop, with Emon reviewing engineering quality and calling in Stewie Hobs/Satwa Nutella when their specialties matter.

Acceptance:

- Kapiteky can dispatch scoped work to agents with bounded context.
- Outputs include changed files, verification, risks, and escalation notes.
- The persistent roles match the team shape Fito wants: designer, engineer, infra, and generalist coordinator.
- The engineer role has the engineering handbook, quality gates, best practices, and implementation/review workflow context needed to own normal delivery work.
- Ramiro Garcia is active as a draft-only consulting agent with explicit approval gates for external sends, pricing, legal/commercial commitments, and client-facing claims.

## Milestone 5.1 - Agent Rituals and Operating Cadence

- Define lightweight daily/weekly agent rituals:
  - morning/project-status sweep for active initiatives;
  - daily task organization and "what should each agent pick up today" summary;
  - project status refresh from Mattermost, boards, repos, builds, deployments, and docs;
  - blocker/decision-needed rollup for Fito;
  - end-of-day or async handoff notes when work is active.
- Decide which rituals are run by Emon directly and which are delegated to Stewie Hobs, Satwa Nutella, and the engineer agent.
- Add ritual outputs to the right place: Mattermost thread, project dev-log, roadmap, board, or docs.
- Keep rituals useful and low-noise: no status spam when nothing changed.
- Make agent rituals visible in Backoffice later as read-only cadence/status cards.

Acceptance:

- Fito can ask "what are the agents doing today?" and get a grounded answer from current projects, not vibes.
- Emon can organize the agent day without starting hidden work or creating token noise.
- Active project status is refreshed from evidence and linked back to channels/repos/boards.
- Rituals have clear stop/ask rules for approval, scope, secrets, infra, external actions, and unclear priorities.

## Milestone 5.5 - Backoffice Command Center

- Add read-only Backoffice view for live agents.
- Show identity, Mattermost handle, deployment/PVC/image status, skill bundle, and credential access intent.
- Link to agent docs, swarm runbooks, Mattermost channel, and Azure DevOps work.
- Keep secret values hidden.

Acceptance:

- Fito can see Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon status in Backoffice.
- Backoffice can show declared access and runtime health without becoming a secret store.
- No write controls exist until the read-only view is reviewed.
