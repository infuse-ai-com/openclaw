---
title: Backoffice Agent Catalog Feed
description: Sanitized, generated configuration catalog for Backoffice agent
  identity and declared ownership.
type: policy
status: active
owner: team:agent-platform
tags:
  - policy
  - agents
  - backoffice
  - privacy
---
# Backoffice Agent Catalog Feed

## Purpose

`config/backoffice-agent-catalog.v1.json` is the fetchable configuration
contract between this runtime repository and Backoffice. It replaces a
manually maintained Backoffice roster without turning repository configuration
into live readiness evidence.

The control-plane consumer fetches the versioned GitLab source, validates the
schema, records the item commit and fetch time as provenance, and joins live
Kubernetes, model-policy, token-usage, and cron evidence by `agentId`.

## Ownership And Freshness

The generator reads:

- active agent identity and order from
  `k8s/overlays/infuseai/kustomization.yaml`;
- sanitized name, description, and Mattermost activation intent from each
  active Deployment patch;
- role and installed skill IDs from
  `config/agent-skill-bundles/<agent-id>.json`.

The catalog changes only when a reviewed repository revision changes one of
those sources. It is declared configuration, not a heartbeat, health check, or
runtime snapshot.

## Schema

Version 1 contains:

- top-level `schemaVersion`, `source`, and `agents`;
- public agent identity and declared ownership;
- active lifecycle membership;
- Mattermost username and mention-versus-all group activation;
- installed skill IDs.

`agentId` is the only live-evidence join key. It is verified against the
active Deployment name but no Deployment, PVC, filesystem, image-repository,
overlay, or documentation path is exported.

The Git Items response supplies the source commit. The file intentionally does
not embed its own commit.

## Privacy Boundary

The catalog must never contain:

- credential or repository-access declarations;
- Secret names, keys, mounts, token references, or Vaultwarden pointers;
- private dashboard hostnames or runtime URLs;
- workload, PVC, image-repository, overlay, filesystem, or repository paths;
- Mattermost allowlists, channel membership, or user IDs;
- raw `OPENCLAW_CONFIG_JSON`;
- prompts, messages, sessions, tasks, memory, or workspace contents;
- live model, token, cron, pod, or readiness state.

Tests enforce the exact allowlisted shape and reject representative private
runtime fields. Backoffice must not infer readiness from declared identity,
lifecycle, workload, or skills.

## Generation And Verification

```bash
task generate-backoffice-agent-catalog
task verify-backoffice-agent-catalog
```

Both `task verify` and `task verify-ci` include the freshness check. A source
change that affects the catalog must update the checked-in JSON in the same
commit.

## Consumer Failure Contract

Backoffice must validate the complete document before use. Missing
authentication, Azure errors, unsupported schema versions, invalid content, or
an empty roster produce a visible catalog-unavailable state. Backoffice must
not fall back to a bundled roster.
