---
title: GitLab agent source and identity migration
description: Current source checkout, per-agent credentials, memory merge safety, and recurring job qualification for the renewal.
type: guide
status: active
owner: team:agent-platform
tags: [gitlab, agents, operations, assurance]
---
# GitLab agent source and identity migration

This contract replaces Azure worker-readiness guidance. Company policy and the
session tracker live in company-docs; executable checks live here and in the
reviewed skill pack. Source changes are not evidence of live adoption.

## Source and identity

- Skills, personas and memory use their `platform/agents/<repo>` GitLab HTTPS
  remotes. Intake documents use `client-technologies/clients-projects`.
- The entrypoint prewarms the own-agent Vaultwarden account, then configures
  GitLab bootstrap before the first skills clone. A fresh PVC does not need an
  existing skills checkout to authenticate.
- Bootstrap resolves one exact `GitLab / <agent-id> service account token`
  item and verifies the active GitLab API username. Native Git helpers reset
  inherited helpers for this host, ignore ambient application tokens, and
  return secret material only through the Git credential protocol.
- The skill-owned glab wrapper binds persistent commands to `AGENT_ID`, rejects
  another CLI identity and resolves the own-account vault item. Operator access
  never becomes a fallback agent credential.
- Clean known Azure source checkouts may retarget the exact canonical remote.
  Unknown origins, local changes and non-fast-forward histories fail closed.
  Skills remain pinned to a reviewed main ancestor; preserve exact provenance.
- Azure skills, token sync targets and env mounts are removed from source.
  Legacy vault memberships and unused Secret objects are not evidence of a
  supported consumer; revocation/deletion is a separately verified access change.

## Memory writer

The deterministic sync touches only the own-agent memory area, validates IKF,
uses attributable commits, and publishes a recovery branch. The MR helper
checks API identity, source/target project, exact branches and SHA. It reuses
an existing MR, rejects ambiguity and requires successful matching CI. Per
Fito on 2026-11-12 it returns `review_pending` and never merges, even if a future
credential permits merging. A later run reads back a reviewer-completed merge
and its immutable revision before clearing the recovery branch.
Missing/failed CI, changed source, unknown outcome or timeout never permits a
direct-main fallback. Preserve the branch/MR and reconcile before retry.

The collector allows 420 seconds per agent within a 2400-second Job deadline:
Git fetch/push and own-vault authentication precede the separately bounded
180-second MR gate. The former 180-second outer timeout could terminate a
changed-content run before its own gate concluded. Keep concurrency forbidden.

A scheduler success requires explicit per-agent no-change, review-pending,
or observed-merged receipts. Review-pending proves submission, not main
publication. Repeated runs retain and reuse the same MR/branch until reviewed;
newer local memory waits safely for that review. A completed Job alone proves
none of these outcomes.
Concurrent agents may encounter changed main; the next run must reconcile
rather than silently drop a recovery branch.

## Job qualification and pause decisions

The observed baseline is OpenClaw 2026.11.1 (`19818bb`) on all five agents.
Kubernetes collectors, OpenClaw crons and GitLab schedules have separate owners.

| Job family | Disposition and evidence |
| --- | --- |
| Daily memory sync | Retain cadence; migrate writer to GitLab. 2026-11-12 recorded five no-change results, so a changed-content GitLab canary is still required. |
| Model-policy / token-usage collectors | Retain; all five sanitized feed entries had current timestamps on 2026-11-12. |
| Scheduler collector | Retain `core/openclaw-scheduler-feed`; all five entries were current. The old cron-calendar feed last updated 2026-10-22 and is historical. |
| Skill proposal monitor | Retain reviewed proposal intake and quarantine; startup source changes must not activate local proposals. |
| Memory Dreaming Promotion | Enabled on all five agents; recorded last status ok, zero errors. This is distinct from deterministic Git sync. |
| Heartbeats and registry mission stewards | Keep disabled. Studio owns native mission continuation; no registry fallback. |
| Portfolio proposal review | Keep disabled until a separately admitted current workflow exists. |
| Intake triage, prefilter, waiting reminders | Keep paused per Fito on 2026-11-12. Mailbox credential resolves to the expected identity, but IMAP login failed. No messages fetched or mail sent. |

For each retained job, verify CLI/schema, own identity, bounded target, result
freshness and expected output on the pinned runtime. Follow
`operational-assurance` for one admitted model-driven run; do not create a new
scheduler or use an audit finding as remediation authority. Intake resumption
requires mailbox repair, read-only preflight, state/recipient review and a new
explicit activation decision. Reinstalling schedules must preserve the pause.

## Verification and promotion

Run `task verify-ci` and source/bundle parity, then normal GitLab MR checks.
Merge source dependencies first, pin the exact skills revision, and build the
runtime with `RUN_GITLAB_CANDIDATE_BUILD=1` on protected main. Inspect the new
immutable digest and full scan before proposing an exact-image risk exception;
the existing approval covers only its recorded digest. `RUN_GITLAB_DELIVERY=1`
verifies the approved image and does not build new source. Verify a developer canary
before leaf agents and coordinator-last promotion. Record source/install
revisions, own API/native Git identity, skill eligibility, persona parity and
job output. Preserve the existing state-schema recovery boundary; do not roll
back 2026.11.1 state to an older runtime without its matching backup.

Remaining Azure strings are limited by meaning: dated evidence, disabled
historical plans, negative tests, exact-origin migration guards and recorded
recovery baseline provenance. Do not translate old work item/build IDs into
invented GitLab identifiers.

## Legacy memory branches discovered during qualification

A clean `main` worktree does not imply an empty recovery queue. Inventory local
`agent-memory-sync/<agent>/...` refs before a source migration, recording exact
SHAs, ancestry and patch/content equivalence to current main. The deterministic
writer correctly refuses multiple pending branches; do not weaken that guard.

On 12 November, 16 August/September refs remained across the five PVCs. Eleven
were represented in main history; five contained older memory snapshots needing
review. Preserve such refs under `agent-memory-legacy/<agent>/...`, retaining
exact commits and an own-PVC private mapping journal. Publish unintegrated
snapshots as explicit draft review MRs using the owning agent's credentials.
Do not delete them, auto-merge them, or use historical exports to overwrite
current personas. Only after preserving and surfacing legacy work should the
current review-only writer use its active recovery queue again. This is an
operator reconciliation step, not permission for a scheduled job to archive
ambiguous new work automatically.

Ramiro is a deliberate exception pending the memory refactor. Fito deferred
new write access on 12 November: `agent-intake` keeps inherited Reporter access
and its read-only token, and is excluded from the memory collector's explicit
writer selector. His three legacy refs remain on his own PVC with a private
mapping journal; one August snapshot needs review and has not been published.
The other four agents retain their existing write permissions. Do not substitute
another identity, silently widen the selector or grant access to make a job green.
