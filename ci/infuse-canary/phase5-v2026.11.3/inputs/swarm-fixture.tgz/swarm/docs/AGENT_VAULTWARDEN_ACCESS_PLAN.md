---
title: Agent Vaultwarden Access Plan
description: "Status (2026-08-03): this document retains the original
  direct-account pilot history and its historical persistent-sync plan."
type: plan
status: active
owner: team:agent-platform
tags:
  - plan
  - agent
  - vaultwarden
  - access
---
# Agent Vaultwarden Access Plan

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


> Status (2026-08-03): this document retains the original direct-account pilot
> history and its historical persistent-sync plan. The current direct-lookup
> policy is account-authoritative: Vaultwarden account and collection membership
> authorize item access. See
> `docs/DECISIONS.md` and `docs/AGENT_VAULTWARDEN_ACCOUNT_RUNBOOK.md` for the
> active contract.

This plan defines how persistent agents should use company credentials without
receiving broad Vaultwarden access.

For the step-by-step manual setup checklist, see
`docs/AGENT_VAULTWARDEN_ACCOUNT_RUNBOOK.md`.

2026-06-09 update: Fito expanded the direct-account bootstrap from the original
Emon-only pilot to all persistent agents. The current runtime source for
per-agent Vaultwarden and Authentik bootstrap credentials is Vaultwarden
collection `00-Super-Secret-Tokens`, and the current agent collections are
`51-Agent-Emon-Lusk` through `55-Agent-Ramiro-Garcia`. Older Emon-only notes
below are historical unless repeated in `docs/CREDENTIAL_ACCESS.md` or the
active bundle JSON.

## Goal

Agents need credentials for bounded work: Mattermost bot tokens, assigned repo
checkout tokens, read-only Kubernetes context files, model credentials, and
task-scoped operational credentials.

The goal is to make that access reviewable, reversible, and auditable while
keeping Vaultwarden as the source of truth.

## Non-Goals

- Do not put a shared Vaultwarden session, API key, master password, or account
  key inside normal agent pods.
- Do not give every agent access to every collection.
- Do not make Backoffice or the swarm repo a secret store.
- Do not let agents enumerate Vaultwarden directly as part of normal work.
- Do not grant long-lived write credentials for temporary tasks.

## Recommended Model For Persistent Sync

Use a control-plane sync pattern:

1. Git stores access intent.
2. Vaultwarden stores secret values.
3. A trusted sync helper reads exact allowed items from Vaultwarden.
4. Kubernetes Secrets or mounted secret files deliver runtime values.
5. Agents receive only the persistent runtime credentials their bundle allows.

This extends the existing Mattermost bot-token sync model instead of adding a
separate ad hoc path for each credential type.

## Historical: 2026-06 Emon Direct-Account Pilot

Fito prefers that normal secret rotation should not require restarting agent
pods. For Emon only, we will pilot a direct Vaultwarden account model instead of
expanding env-only Kubernetes Secret sync.

The pilot does not change the default rule for other agents. Normal agents still
use bundle-declared runtime materialization until this Emon path is proven.

### Findings

Our company vault endpoint identifies as Vaultwarden, not official Bitwarden
Secrets Manager:

```text
server.name: Vaultwarden
server.url: https://github.com/dani-garcia/vaultwarden
```

Vaultwarden supports Bitwarden Password Manager-style organizations,
collections, users, groups, and CLI access. It does not provide Bitwarden
Secrets Manager machine accounts or project-scoped machine-account access
tokens in our current deployment.

Vaultwarden OpenID Connect / Authentik SSO is useful for identity lifecycle, but
it is not sufficient by itself for headless runtime secret access. Vault data
still needs decrypt/unlock material. At the time of this investigation, the
pilot combined Vaultwarden collections with a Git bundle item/field gate; that
direct-lookup design was superseded on 2026-08-03.

### Read-Only Investigation - 2026-06-05

Current company-vault metadata:

- Organization: `Infuse AI`.
- Current organization members visible to Kapiteky: Fito, Kapiteky, and Carlos.
- No `agent-coordinator` Vaultwarden organization member exists yet.
- Current collections are functional/broad, such as `04-Azure-DevOps`,
  `05-Mattermost`, and `07-Project-MarkdownGPT`.
- Initial Emon-only collections were created later in the pilot; see
  "Provisioning Progress".

Current Emon-related Vaultwarden items visible in organization metadata:

- `Mattermost / agent-coordinator BOT token` in `05-Mattermost`.
- `Azure DevOps / agent-coordinator repo token` in `04-Azure-DevOps`.
- `Project MarkdownGPT / dogfood test account` in
  `07-Project-MarkdownGPT`.

The planned item `Kubernetes / agent-coordinator read-only kubeconfig` was not
visible in organization item metadata during the read-only check. Before
provisioning the direct-account pilot, either create that item, rename the
bundle entry to match the actual Vaultwarden item, or document why the mounted
Kubernetes Secret is intentionally sourced elsewhere.

Current Emon runtime wiring still uses Kubernetes bootstrap material:

- Deployment: `agents-swarm/agent-coordinator`.
- Service account: `openclaw-agent`.
- Secret refs: `openclaw-runtime`, `agent-coordinator-mattermost`,
  `agent-coordinator-azure-devops`, `agent-coordinator-vaultwarden`,
  `agent-coordinator-cursor-oauth`, and
  `agent-coordinator-markdowngpt-dogfood`.
- Mounted secret: `agent-coordinator-kubeconfig`.

Kapiteky's current Kubernetes service account cannot list Secrets or RBAC
objects in `agents-swarm`, and cannot impersonate the Emon service account for
`kubectl auth can-i` checks. That is a good default guardrail, but it means
Emon's exact live Kubernetes permissions should be validated from inside Emon or
with an explicitly approved read-only admin context.

Observed config drift to fix before provisioning:

- `config/agent-skill-bundles/agent-coordinator.json` previously listed
  `03-Azure DevOps`, but the live company Vaultwarden collection is
  `04-Azure-DevOps`. The pilot branch updates the bundle metadata to the live
  collection name.
- The direct-account pilot should prefer the new Emon-only collections below
  rather than granting Emon access to the existing broad functional
  collections.

### Pilot Identity

Pilot identity:

```text
Vaultwarden user: agent-coordinator@infuse-ai.com
Authentik identity/group: agent-coordinator / Vaultwarden app access
Vaultwarden organization: Infuse AI
```

Do not commit passwords, client secrets, API keys, recovery codes, or session
keys.

### Provisioning Progress - 2026-06-05

Authentik:

- Fito created an Authentik service account/user for Emon and stored the
  bootstrap value in company Vaultwarden item
  `Authentik / agent-coordinator service account token`.
- When the stored value was an API token, Authentik returned `403` for users,
  groups, applications, providers, tokens, and root config API endpoints, even
  after temporary admin-group changes. Treat that token path as unproven.
- Fito then created a normal Authentik-backed identity with email
  `agent-coordinator@infuse-ai.com`, added Vaultwarden app access, and created
  the matching Vaultwarden account.

Conclusion: use a normal Authentik user with an email claim for the Vaultwarden
SSO identity. Keep Authentik service accounts for provisioning/API work only.
The remaining runtime bootstrap question is how to make `bw` authenticate
headlessly when the account requires SSO.

Vaultwarden:

- Created Emon-only collections in the `Infuse AI` organization:

```text
06794843-66c9-41bb-8f3f-a5cc001624f6  agent-coordinator-kubernetes-readonly
36424098-f41f-4509-a40b-c4620b8c2dcc  agent-coordinator-markdowngpt-dogfood
67d5bb88-51b9-40db-ad57-222557bd0645  agent-coordinator-repo
bff58161-ac21-4f2e-9d66-96599ef69b2f  agent-coordinator-runtime
```

- Confirmed Emon is an accepted organization member:
  `agent-coordinator@infuse-ai.com`, member type `user`, status `accepted`.
- Assigned Emon to all four Emon-only collections with:
  `readOnly=true`, `hidePasswords=false`, `manage=false`.
- Plain CLI password login from an isolated Bitwarden profile failed with
  `SSO sign-in is required`. This is useful: it proves the account is
  SSO-enforced, but also means the runtime cannot use simple
  `bw login <email> --passwordenv ...`.
- No secret values were read or printed.
- Existing Emon-related items were not moved or duplicated into the Emon-only
  collections yet, so collection assignment alone has not exposed those items.
- Next bootstrap options to evaluate:
  a Vaultwarden account API-key path plus approved unlock secret, one-time
  `bw login --sso` profile bootstrap for Emon, or a small broker service that
  authenticates as a controlled Vaultwarden account while preserving its
  account-and-collection authorization boundary. Bitwarden's CLI documentation says
  `--apikey` is still allowed when SSO is required, but vault data still needs
  an unlock secret unless Key Connector is configured.
- Repo support for the API-key path is in place. Live sync of
  `agent-coordinator-vaultwarden` reads API client id/secret from Vaultwarden
  item `Vaultwarden / agent-coordinator oauth api client` and the unlock password
  from `Vaultwarden / agent-coordinator login`.

### Pilot Collections

Create narrow Emon-only collections:

```text
agent-coordinator-runtime
agent-coordinator-repo
agent-coordinator-kubernetes-readonly
agent-coordinator-markdowngpt-dogfood
```

Only place items in these collections that Emon may retrieve directly during a
task. If an item must be shared with another agent, duplicate the access intent
through that agent's own collection or bundle entry instead of widening Emon's
collection access.

### Runtime Lookup Model

The target runtime flow is task-time lookup:

```text
agent request
  -> scripts/agent-secret-get.sh
  -> load config/agent-skill-bundles/agent-coordinator.json
  -> validate the caller bundle and supported lookup field
  -> authenticate/unlock as agent-coordinator using an agent-scoped CLI profile
  -> bw sync
  -> Vaultwarden authorizes and fetches the requested field
  -> return value to the calling process without logging it
```

Changing or rotating an item in Vaultwarden should not require an Emon pod
restart. The next lookup should sync and read the latest value.

Keep Kubernetes Secrets for boot-critical credentials only:

- Emon's Mattermost bot token.
- Emon's Azure DevOps repo token needed before helper code can be fetched.
- Emon's Vaultwarden account bootstrap material or session bootstrap file:
  either an existing `BW_SESSION`, a mounted session file referenced by
  `OPENCLAW_BW_SESSION_FILE`, or personal API-key login env
  `BW_CLIENTID`/`BW_CLIENTSECRET` plus unlock env `BW_PASSWORD` or
  `BW_MASTER_PASSWORD`.

Task/application credentials should prefer direct lookup rather than env-only
sync, because env-only values usually require pod restart to refresh.

### Account-Authoritative Direct Access

For direct reads, Vaultwarden account and collection membership is the only
item-authorization boundary. Git bundle item/field lists are intentionally not
consulted for direct lookup, so access grants and revocations take effect in
Vaultwarden without an unrelated runtime-bundle change.

The helper still validates its caller bundle, supports only `username` and
`password` fields, and fails closed for project env-bootstrap calls that do not
match their explicit project/profile/alias binding. Bundle item allowlists also
remain mandatory for Kubernetes secret sync and other persistent materialization
paths.

### Revocation

If Emon is compromised or the pilot is stopped:

1. Disable the Authentik identity or group membership.
2. Remove the Vaultwarden user from Emon collections.
3. Revoke/rotate Emon's Vaultwarden API key/session/bootstrap material.
4. Rotate items Emon could read directly.
5. Remove runtime bootstrap secrets from Kubernetes.

### Acceptance Criteria

- Emon can retrieve a known-visible non-production test item without pod restart.
- Emon cannot retrieve an item outside Emon's Vaultwarden visibility.
- Emon cannot retrieve an unsupported field.
- Logs, Mattermost posts, and command output never contain secret values.
- A rotated Vaultwarden item is picked up by a later lookup without restarting
  the Emon pod.
- Authentik/Vaultwarden disablement blocks new Emon vault access.

## Source Of Truth

`config/agent-skill-bundles/<agent-id>.json` remains the reviewable source of
truth for persistent sync and materialization intent. Direct lookup grants and
revocations are maintained through Vaultwarden account and collection
membership, not duplicate Git item metadata.

Each persistent sync or materialization declaration must name:

- Vaultwarden organization;
- exact Vaultwarden item name;
- purpose;
- runtime sync target;
- agent visibility;
- review or expiry condition.

The bundle must never contain the secret value or full Vaultwarden item JSON.

## Account Strategy

Use human SSO accounts for humans.

Use a trusted Kapiteky/control-plane account or future secret-broker identity
for sync automation. That account may read Vaultwarden, but the sync tool must
still enforce bundle allowlists before writing runtime secrets.

Under the current policy, approved persistent agents receive only their own
Vaultwarden bootstrap material and use narrow collection scope for direct
lookup. Agents without that explicit approval should receive only persistent
runtime credentials through bundle-enforced sync or a reviewed broker path.

## Runtime Delivery

Supported delivery targets should start narrow:

- Kubernetes Secret environment key for simple tokens.
- Kubernetes Secret mounted file for kubeconfigs, JSON credentials, or config
  blobs that should not be exposed as environment variables.

Do not mount secret values into PVC-backed workspaces unless the credential is
explicitly intended to persist across pod restarts and has a cleanup rule.

## Temporary Elevation

Temporary access should be treated as a named change:

1. Fito or Kapiteky approves the task and credential.
2. For direct lookup, grant the agent's Vaultwarden account narrow collection
   visibility; for persistent copies, add or update the bundle declaration.
3. Run the task through the direct helper or sync the exact declared item to
   its runtime target.
4. Remove direct collection visibility or the runtime Secret/mount when the
   task ends.
5. Remove or downgrade any persistent bundle declaration.
6. Rotate or archive the credential when the task risk justifies it.

Temporary elevation can become persistent only through a reviewed bundle update.

## Implementation Plan

### 1. Generalize The Sync Helper

`scripts/sync-agent-credential.sh` is the generic version of
`scripts/sync-agent-mattermost-secret.sh`.

Required behavior:

- require `AGENT_ID`;
- read `config/agent-skill-bundles/<agent-id>.json`;
- require exact Vaultwarden item name and target match;
- support dry-run output with placeholders;
- fetch only the requested item;
- never print secret values;
- write only the declared Kubernetes Secret target;
- fail closed when bundle metadata is missing or ambiguous.

The Mattermost-specific script is a wrapper around the generic helper.

### 2. Add Target Types Conservatively

Initial target types:

- `kubernetes-secret-env`: simple key/value secret.
- `kubernetes-secret-file`: secret value written as a named data key and mounted
  by the deployment.

`kubernetes-secret` remains a compatibility alias for older entries.

### 3. Extend Bundle Validation

`scripts/verify-agent-skill-bundles.py` validates:

- allowed target types;
- required namespace/name/key fields;
- `agent_visibility` values;
- non-empty `review_or_expiry`;
- no duplicate item names per agent unless target names differ intentionally.
- no duplicate direct-lookup authorization metadata; Vaultwarden is the source
  of truth for agent-visible items.

### 4. Add Runtime Wiring Patterns

Document and template how each delivery type is consumed:

- env-only tokens for Mattermost;
- mounted kubeconfig for Satwa Nutella read-only Kubernetes checks;
- Git credential helper input for assigned Azure DevOps repo checkout;
- model credential path for scoped per-agent model auth.

### 5. Add Smokes

Smokes prove access without leaking values:

- dry-run render for all declared credentials;
- negative smoke: non-declared item cannot be synced.
- direct lookup: a Vaultwarden-visible fixture succeeds, a Vaultwarden-denied
  fixture fails, and unsupported fields remain denied locally.

Next smokes to add when new credential types land:

- Kubernetes Secret exists with expected keys;
- pod can see the expected env key or mounted file path;
- pod can create and clean one isolated repo checkout without printing tokens;
- logs and smoke output do not print secret values;

## First Credentials To Model

Modeled runtime credentials:

- `Mattermost / agent-developer BOT token`
- `Mattermost / agent-designer BOT token`
- `Mattermost / agent-infra BOT token`
- `Azure DevOps / agent-developer repo token`
- `Azure DevOps / agent-designer repo token`
- `Azure DevOps / agent-infra repo token`
- `Project MarkdownGPT / dogfood test account` for the approved Emon Level 3 dogfood attempt

Next candidates:

- `Kubernetes / agent-infra read-only kubeconfig`
- scoped per-agent model credentials to replace the temporary Kapiteky OAuth
  bridge.

Azure DevOps repo-token items are declared as allowed runtime env targets. Keep
the actual token values in Vaultwarden and sync them into optional Kubernetes
Secrets only for agents that need live repo checkout.

## Backoffice Role

Backoffice can show credential access intent and sync status, but never values.

Safe fields:

- agent id and friendly name;
- declared Vaultwarden item names;
- collection names;
- target namespace, Secret name, and key;
- last sync timestamp/status;
- review or expiry text.

Unsafe fields:

- token values;
- session keys;
- full Vaultwarden item JSON;
- generated kubeconfigs;
- API keys or password-derived data.

## Open Questions

- Whether the first generic sync helper should run only from the Mac mini or
  also from a dedicated in-cluster secret-sync job.
- Whether to introduce a dedicated service account for sync automation instead
  of using Kapiteky's SSO-backed CLI profile.
- How long temporary runtime secrets should remain before automated cleanup.
- Which Azure DevOps identity model gives useful repo access without broad
  organization-wide PATs.

## Acceptance Criteria

- Normal worker agents do not contain Vaultwarden login material.
- Every runtime credential is declared in an agent bundle before sync.
- Sync helpers enforce exact item and target allowlists.
- Runtime delivery uses Kubernetes Secrets or mounted files.
- Tests include positive and negative sync checks.
- Documentation tells Fito and Kapiteky how to add, review, and remove access.
