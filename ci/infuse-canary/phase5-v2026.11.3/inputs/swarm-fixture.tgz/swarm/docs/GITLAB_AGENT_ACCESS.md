---
title: GitLab Agent Access
description: "Defines the initial least-privilege GitLab identities, project memberships, token scopes, and runtime credential path for persistent agents."
type: reference
status: active
owner: team:agent-platform
tags:
  - gitlab
  - agents
  - access-control
  - credentials
---

# GitLab agent access

Each agent uses a dedicated GitLab instance service account and one rotatable
personal access token. Project membership is the repository authorization
boundary. Token scope grants only the operation class and never broadens
project visibility.

## Initial membership matrix

| Runtime identity | GitLab username | Finaxis | Hauscraft | CI components | Infrastructure |
| --- | --- | --- | --- | --- | --- |
| `kapiteky` | `kapiteky` | Developer | Developer | Developer | Developer |
| `agent-coordinator` | `agent-coordinator` | Developer | Developer | Developer | Reporter |
| `agent-developer` | `agent-developer` | Developer | Developer | Reporter | None |
| `agent-designer` | `agent-designer` | Developer | Developer | None | None |
| `agent-infra` | `agent-infra` | None | None | Developer | Reporter |
| `agent-intake` | `agent-intake` | None | None | None | None |

Project paths are `finaxis/fnx-poc-monorepo`, `hauscraft/hauscraft-poc`,
`platform/gitlab-ci-components`, and `platform/infrastructure`. Memberships are
project-specific, not inherited from top-level groups. New repositories remain
invisible until a reviewed membership change explicitly adds them.

The runtime identity and GitLab username deliberately match. GitLab's immutable
user ID and `service_account` user type identify these as automation accounts;
no additional username prefix is required.

## Notification identity

| Runtime identity | Display name | Confirmed GitLab primary email |
| --- | --- | --- |
| `kapiteky` | Kapiteky | `kapiteky@agents.infuse-ai.com` |
| `agent-coordinator` | Emon Lusk | `emon.lusk@agents.infuse-ai.com` |
| `agent-developer` | Tinus Lordvals | `tinus.lordvals@agents.infuse-ai.com` |
| `agent-designer` | Stewie Hobs | `stewie.hobs@agents.infuse-ai.com` |
| `agent-infra` | Satwa Nutella | `satwa.nutella@agents.infuse-ai.com` |
| `agent-intake` | Ramiro Garcia | `ramiro.garcia@agents.infuse-ai.com` |

These are literal Cloudflare Email Routing aliases that forward notifications
to the monitored platform owner mailbox. They are not user mailboxes and do
not grant interactive login. The service accounts remain PAT-only automation
identities with no Authentik/OIDC identity. The GitLab-generated no-reply
address remains a confirmed secondary address for each account.

`agent-intake` has an identity and read-only token but no current repository
membership. Add access only when a consulting or client-document repository is
approved for that role.

## Token and Vaultwarden policy

- Write-capable identities use `api` and `write_repository` scopes.
- `agent-intake` uses `read_api` and `read_repository` scopes.
- The initial tokens expire on 2027-02-02 and must be rotated before expiry.
- Item names are `GitLab / <agent-id> service account token`.
- Each swarm item belongs to `09-Gitlab` and that agent's own collection.
  Kapiteky's item belongs to `09-Gitlab`.
- Tokens are resolved from the agent-scoped Vaultwarden account at task time.
  They are not copied into Git, Git remotes, `glab` config, runtime bundles, or
  dedicated Kubernetes Secrets.

## Client boundary

- Use native `git` for clone, fetch, branch, commit, rebase, and push.
- Use checksum-pinned `glab` for merge requests, discussions, pipelines, jobs,
  releases, and API operations.
- Run authenticated operations through the wrappers in the pinned
  `infuse-ai-agent-skills` checkout exposed by `AGENT_SKILLS_ROOT`.
- Do not run `glab auth login` or persist a token in `glab` configuration.

Membership, token availability, and a green pipeline do not authorize a
write, merge, retry, cancellation, setting change, or protected-branch action.
Those effects still require the authority stated by the assigned task and the
agent's runtime policy.

## Change and review procedure

1. Name the agent, project, required role, operation class, and review date.
2. Prefer project membership over group membership.
3. Keep Maintainer exceptional and time-bounded; do not grant routine Owner.
4. Update this matrix and the corresponding Vaultwarden item metadata in the
   same reviewed change.
5. Verify `/user`, every allowed project and access level, at least one denied
   project, and HTTPS clone without printing credentials.
6. Revoke replaced tokens and temporary administrator access, then record only
   sanitized evidence.
