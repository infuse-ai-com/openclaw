---
title: Agent Worker Readiness Plan
description: This plan captures the worker-readiness path after making Tinus
  Lordvals, Stewie Hobs, Satwa Nutella, and Emon live on InfuseAI Kubernetes.
type: plan
status: superseded
superseded_by: plans/active/agent-execution-system-v2/spec.md
owner: team:agent-platform
tags:
  - plan
  - agent
  - worker
  - readiness
---
# Agent Worker Readiness Plan

> Provider migration note (2026-11-12): Azure steps and credentials below are
> historical and must not be executed or activated. Current delivery is owned
> by `docs/GITLAB_DELIVERY.md`; agent source/authentication and job qualification
> are owned by `docs/GITLAB_AGENT_SOURCE_MIGRATION.md`. Preserve old IDs as evidence.


> Superseded on 2026-08-31 by
> `docs/plans/active/agent-execution-system-v2/`. Historical coordinator-thread,
> broad dispatcher, and `i-need-feedback` guidance below is not current policy.

This plan captures the worker-readiness path after making Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon live on InfuseAI Kubernetes.

The agents can already speak in Mattermost and run from isolated Kubernetes Deployments with PVC-backed workspaces. The next goal is to make them useful workers without turning them into broad, unreviewed copies of Kapiteky.

## Current State

Live agents:

- Tinus Lordvals / `agent-developer`
- Stewie Hobs / `agent-designer`
- Satwa Nutella / `agent-infra`
- Emon Lusk / `agent-coordinator`

Shared runtime image:

```text
registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:<build>
```

The shared image includes:

- Git
- Task
- kubectl
- Helm
- Docker CLI and Compose CLI plugin
- Python and pip
- ripgrep
- jq
- Node, npm, and npx
- OpenClaw

The entrypoint sets a default Git identity from `AGENT_NAME` / `AGENT_ID` and marks `/workspace` as a safe Git directory.

Docker is intentionally daemonless. The pods include the Docker and Compose
CLIs so they can run `docker compose config`, but they do not mount a host
Docker socket or run a Docker daemon. `openclaw-agent-capabilities` reports
whether container builds are local or require the PR BuildKit gate.

## What Is Still Missing

The agents are live, but not yet full implementation workers.

Missing capabilities:

- controlled repo checkout/sync into each agent PVC;
- per-agent Azure DevOps Git credential flow;
- per-agent Vaultwarden access delivery beyond the current Mattermost bot-token sync;
- role-specific Kubernetes permissions, especially for Satwa Nutella;
- a way to prove an agent can pick up a bounded task, inspect the right repo, run the right checks, and report back without secret leakage;
- Backoffice visibility into agent identity, status, access, and current task state.

## Credential Model

Agent credential access is declared in:

```text
config/agent-skill-bundles/<agent-id>.json
```

The bundle is the reviewable declaration for persistent credential delivery. It
names the Vaultwarden organization, item names, runtime sync targets, and
visibility rules; it never stores secret values. Direct task-time reads are
authorized by the agent's own Vaultwarden account and collection membership.

The near-term rule is:

- Git records persistent sync/materialization intent.
- Vaultwarden stores secret values and authorizes direct account reads.
- Kubernetes Secrets deliver runtime values.
- Agents see credentials only through runtime env/files when explicitly allowed.
- Temporary Vaultwarden visibility is named in the task and removed through the
  account's collection membership; persistent sync/materialization requires a
  reviewed bundle update.

Tomorrow's Vaultwarden/access work should extend this same pattern instead of adding ad hoc token handling.

The detailed Vaultwarden delivery plan lives in
`docs/AGENT_VAULTWARDEN_ACCESS_PLAN.md`. Only approved persistent agents receive
their own Vaultwarden bootstrap material for account-authoritative direct
lookup. Trusted sync automation still reads exact bundle-declared sync items
and delivers only the resulting runtime credential through Kubernetes Secrets
or mounted files.

## Task Workspace Repo Plan

Agents should not start by cloning everything.

Agents also should not share one editable repo checkout across tasks. A single
agent may be asked to work on two tasks for the same repo while Kapiteky or
another agent is also active. Shared working folders caused cross-task confusion
before, so the invariant is:

```text
one assigned task = one isolated repo checkout
```

The stable agent home remains:

```text
/workspace/agents/<agent-id>/
```

Editable task work happens under:

```text
/workspace/tasks/<task-id>/repos/<repo-name>
```

Task assignment metadata is recorded in:

```text
/workspace/tasks/task-registry.json
```

When a task is started rather than only pre-created, the task directory also
contains:

```text
/workspace/tasks/<task-id>/task-brief.md
```

An optional read-only bare mirror cache can live under:

```text
/workspace/repo-cache/<repo-name>.git
```

For each assignment, record:

- Azure DevOps project and repo;
- target branch;
- read-only or task-branch checkout mode;
- default verification command;
- cleanup/expiry rule;
- who approved the assignment.

The bundle allowlist lives in:

```text
config/agent-skill-bundles/<agent-id>.json
```

The normal assignment path is:

```bash
AGENT_ID=agent-designer \
TASK_ID=task-20260527-muse-readme-review \
REPO_NAME=openclaw-k8s-swarm \
TASK_TITLE="Review worker readiness docs" \
TASK_OBJECTIVE="Review the worker-readiness docs and propose one bounded patch." \
task start-agent-task

AGENT_ID=agent-designer task list-agent-task-workspaces

task list-all-agent-tasks

AGENT_ID=agent-designer \
TASK_ID=task-20260527-muse-readme-review \
task status-agent-task-workspace
```

Acceptance:

- repo checkout appears in a task-specific path in the agent PVC;
- creating the same task workspace twice fails unless the caller explicitly resumes;
- two task workspaces for the same repo can hold different local changes without collision;
- `start-agent-task` writes a task brief and registry entry;
- `list-all-agent-tasks` gives Kapiteky a cross-agent task view;
- cleanup refuses dirty task workspaces unless explicitly forced;
- repos named in the bundle deny list are refused by policy, while other repos require an explicit source URL;
- Git identity is configured;
- safe.directory is configured;
- default branch can be fetched without printing tokens;
- a repo-specific verify command can run or fail with a useful error;
- the smoke output does not print environment secrets.

## Git And Azure Access

Do not give every agent a broad Azure PAT.

Preferred progression:

1. Read-only repo checkout for assigned repos.
2. Branch write for agents that are allowed to propose patches.
3. PR creation through Kapiteky-owned automation or a scoped service identity.
4. Merge remains Kapiteky/Fito-governed unless explicitly changed later.

Credential candidates should be Vaultwarden items with names like:

```text
Azure DevOps / agent-developer repo token
Azure DevOps / agent-designer repo token
Azure DevOps / agent-infra repo token
```

These are now declared in the agent bundles as runtime-env-only targets. The
pods receive only `AZURE_DEVOPS_PAT` from optional Kubernetes Secrets such as
`agent-infra-azure-devops`; they do not receive Vaultwarden login material.
The runtime entrypoint configures a `dev.azure.com`-only Git credential helper
when that env var exists.

Live checkout smoke:

```bash
AGENT_ID=agent-infra \
VAULTWARDEN_ITEM_NAME="Azure DevOps / agent-infra repo token" \
task sync-agent-credential

AGENT_ID=agent-infra task install-agent-runtime-files

AGENT_ID=agent-infra \
TASK_ID=task-20260527-atlas-repo-smoke \
task smoke-agent-repo-checkout
```

Use scoped repo tokens. Do not replace these items with a broad personal PAT
without a clear temporary exception and cleanup plan.

## Team Mission Runtime Pattern

The first autonomous board workflow was single-agent oriented. The runtime should now support team missions without turning the swarm into independent agents racing over the same board.

Canonical operating rule:

```text
one bounded outcome or approved ticket batch = one mission = one coordinator thread = many scoped role tasks when needed
```

Emon remains the accountable coordinator and scoped product-engineering delivery owner. Emon may coordinate, decompose, gather evidence, review outputs, make normal internal delivery decisions, merge, deploy, verify, reconcile, and close. Kapiteky represents Fito's direction and advises on company coherence and the operating system without becoming the routine executor. Capability gaps remain Emon-owned until routed to a capable worker or raised as one precise blocker. Tinus Lordvals, Stewie Hobs, Satwa Nutella, Ramiro Garcia, and transient coding workers receive only the role task they need.

### Mission task IDs

Use stable task IDs that make role tasks traceable back to the same source work item:

```text
mission-<project>-<work-item-id>
mission-<project>-<work-item-id>-agent-developer-impl
mission-<project>-<work-item-id>-agent-designer-review
mission-<project>-<work-item-id>-agent-infra-runtime
mission-<project>-<work-item-id>-emon-coordinate
```

Each role task still gets its own isolated workspace:

```text
/workspace/tasks/<mission-role-task-id>/task-brief.md
/workspace/tasks/<mission-role-task-id>/repos/<repo-name>
```

Do not share one editable checkout across role tasks, even when they belong to the same mission. Shared checkouts blur ownership and make review harder.

### Assignment flow

1. Emon creates the mission record from the approved direction, board items,
   and project context pack.
2. The coordinator identifies role tasks and which ones may run in parallel.
3. Emon starts or routes creation of task workspaces only for the agents that
   need repo access.
4. Each agent receives a compact brief: role, goal, context to read, scope, non-goals, verification, approval boundaries, and report thread.
5. Agents reply in the mission thread with what they inspected, what changed or found, verification, risks, and next action.
6. Emon integrates outputs and owns PR completion, merge, deployment,
   verification, reconciliation, and Done. Ask Fito for decisions or Kapiteky
   for direction/operating-system advice in `kapiteky-emon-coordination` when
   useful; advice does not transfer execution ownership.

### Agent fit

- `agent-coordinator`: mission decomposition, role handoffs, board/thread synthesis, PR/build/deploy evidence gathering, output review, scoped delivery decisions, merges, deploys, and follow-through.
- `agent-developer`: scoped implementation engineering, local verification, browser smoke, release-readiness notes.
- `agent-designer`: UX/design review, screenshot critique, accessibility notes, and design-parity findings.
- `agent-infra`: CI/CD, Kubernetes, logs, rollouts, events, and operational risk.
- `agent-intake`: consulting intake, discovery/proposal drafts, and delivery handoff preparation.
- Transient coding workers: implementation or planning workers under a named mission role; never approvers.

### Reporting and channel boundaries

Normal mission execution belongs in the project developer-log channel, not in `#context-engineering`.

Use one top-level coordinator post plus separate top-level role handoff threads.
The coordinator thread anchors the board item, approval gates, registry pointer,
and synthesis. Each role thread mentions exactly one assigned role agent and
keeps that agent's focused output in one place. `#context-engineering` is for
workflow, harness, cron, routing, dispatcher summaries, stale handoff escalation,
and tooling issues found while running the mission.

Mention hygiene matters. Do not `@mention` possible role agents in the
coordinator thread while describing a plan, because Mattermost will wake those
agents and they may create non-authoritative state. Name possible roles without
`@` until a separate role thread actually assigns the role. If a mistaken
mention wakes the wrong agent, correct the thread and keep the mission registry
under the official coordinator state.

### Proactive coordinator cron

Emon is the proactive coordinator for Finaxis and MarkdownGPT product progress. The production
starting point is the `emon-mission-dispatcher` OpenClaw cron job, installed in
Emon's own gateway profile. It wakes on a 30-minute cadence by default, runs in
Emon's main session, and uses the prompt at
`prompts/emon-mission-dispatcher.md`. Its default Mattermost reporting channel is
`context-engineering` (`otafdg45miy3jc8pgi1djja1ue`) when no more specific
mission thread exists.

The dispatcher may move work forward by shaping Finaxis/MarkdownGPT roadmap and
board context into startable work, picking up eligible `Ready for Agent` items
within WIP limits, creating or updating one focused role handoff thread,
reminding one assigned agent on a stale handoff, summarizing role output back to
the coordinator thread, asking Kapiteky/Fito for feedback in `i-need-feedback`
when useful, or completing normal scoped delivery follow-through. It must stay
silent only when there is no useful Finaxis/MarkdownGPT coordination action.

The dispatcher must not perform broad speculative board sweeps across unrelated
projects, create vague work, mention multiple possible agents in a coordinator
thread, change DNS/RBAC/permissions/secrets, run destructive actions, expand
access, or communicate externally without approval. Certification and
recertification are manual validation lanes, not standing product missions.

### Access boundaries

The bundle deny list still controls repo exclusions. Real project missions may require temporary channel or sensitive repo access beyond the default repo policy. Temporary access must be named in the mission brief, approved when sensitive, and removed or promoted into the bundle after review.

Do not broaden access just because a mission uses multiple roles.

### Worker-ready acceptance addendum

Team-mission readiness is proven when:

- Emon can create or review a mission plan without taking approval authority.
- Tinus Lordvals can complete one scoped implementation or release-readiness role task from a mission brief.
- Stewie Hobs can complete one scoped design/UX role task and report evidence.
- Satwa Nutella can complete one scoped runtime role task with read-only Kubernetes evidence.
- Role outputs remain linked to one board item, one coordinator thread, and
  separate focused role threads recorded in the mission registry.
- Kapiteky can inspect all related task workspaces and final status without reading unrelated agent memory.

## Satwa Nutella Kubernetes Access

Satwa Nutella has Kubernetes access before Stewie Hobs, and it starts read-only.

Initial Satwa Nutella permissions should cover:

- `get`, `list`, and `watch` for pods, deployments, replicasets, events, PVCs, services, ingresses, jobs, and configmaps in `agents-swarm`;
- log reads for scoped agent workloads;
- no secret reads by default;
- no write verbs by default.

Acceptance:

```bash
kubectl auth can-i get pods -n agents-swarm
kubectl auth can-i get secrets -n agents-swarm
kubectl auth can-i patch deployments -n agents-swarm
```

Expected initial result:

- pods/logs/events: yes
- secrets: no
- patch deployments: no

Any write capability should be temporary and task-scoped until the operating pattern is proven.

Live smoke:

```bash
task smoke-agent-infra-kube-access
```

## Mattermost Interaction Plan

Agents can be tested with bounded prompts in `openclaw-swarm-dev` before they receive broader repo credentials.

Good first tasks:

```text
@agent-designer review the OpenClaw swarm README from a new-agent onboarding UX perspective. Draft-only, no edits.
```

```text
@agent-infra inspect the OpenClaw swarm runtime status for Tinus Lordvals, Stewie Hobs, Satwa Nutella, and Emon. Read-only: summarize rollout, PVC, channel connectivity, and risks. Do not change anything.
```

The agent response should show:

- what it inspected;
- what it did not inspect;
- whether it needs elevated access;
- any next command or PR it proposes;
- clear non-action if the task is read-only.

## Acceptance For Worker-Ready V1

Worker-ready v1 is done when:

- each live agent passes `task smoke-agent-runtime`;
- each live agent passes `task smoke-agent-toolbox`;
- at least one assigned repo can be synced into an agent PVC without printing secrets;
- Satwa Nutella can run read-only Kubernetes status checks from inside its pod without secret access;
- Stewie Hobs can complete a bounded docs/design-review task from Mattermost and report useful findings;
- Tinus Lordvals can complete a bounded release/readiness review using supplied or checked-out repo context;
- Backoffice can show at least read-only agent status and declared access intent.

## Non-Goals

- No broad shared PAT for every agent.
- No host Docker socket mount.
- No cluster-admin service account.
- No secret values in Git, memory, Mattermost, logs, or screenshots.
- No autonomous merge/deploy authority until the review loop is proven.
