---
title: Studio floor lifecycle plugin release
description: Pins the floor retirement and restoration contract to the deployed Studio producer.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
---
# Studio floor lifecycle plugin release

Fito approved consolidating the accepted Studio Knowledge pilot on 2026-10-17:
keep original Studio/history and the three pilot repositories, rename Core to
Company under ordinary floor rules, and retire Studio Pilot reversibly. Existing
all-enrolled-agent management permission remains authoritative; no role,
enrollment, network access, credentials or source admission is added here.

Studio PR 3972 merged as `3a8bf219117ae60840e756b4c9f9fcd81286571f`; main build 9764
succeeded. The producer is
`registry.infuse-ai-tech.party/studio/studio@sha256:f84370414dd8c306e4ef4e37c4e163f4594060f3540ce2fe0bb8a525195aa20f`.
The owning image and qualification manifest pin all 43 packaged files from that
live producer, including the updated shared command schema and sole-writer logic.
The qualified OpenClaw 2026.10.3 source/package identity and five tool names stay
unchanged. The image's existing complete-inventory gate checks the copied payload
before dependencies are installed.

`studio_floor_manage` retains create/update/list/source management and actor-owned
receipt recovery, and now accepts `save` commands with `intent: retire` or
`intent: restore`, `floorId`, `expectedRevision` and `commandId`. No floor body is
accepted for lifecycle commands. Retired records are retained; editing requires
explicit restoration. Retirement is blocked while mission execution is connected.
Reconcile the exact receipt after a lost response. The server revalidates enrolled
agent/session/run authority at the writer boundary as before.

Studio verification: check, 573 tests, plugin/web builds and local floor,
project-switching and office browser fixtures pass. Attested-agent retire/restore,
restart/idempotency, in-flight Knowledge denial and whiteboard-socket revocation
are covered. The final restoration edge case was rechecked with the lifecycle
browser and all five management tests.

The local swarm baseline `task verify-ci` encountered a stale host-local skill
catalog and two macOS fixture failures (temporary-path symlink rejection and
browser-cache symlink cleanup). The pin contract tests pass. The required owning
Linux PR verification, image payload check and staged rollout remain release
gates; local adapter tests alone do not establish live host behavior.


## Equal capabilities (October 17 follow-up)

Studio Plan 024 adds automatic private floor channels using the existing enrolled
team. Production native plugin configuration enables floorRuntimeDiscovery;
local-Mac profiles retain static fixture routes. Discovery verifies the enrolled
identity tuple and attests required-owner protection before Studio enables work.
The compatible Studio image pin and inventory must be updated together before
release. Existing static routes, journals, credentials and tools are preserved.

The dedicated Studio image-upload principal uses studioFloors true with producer
studio-whiteboard and only image-upload scope. Rotation retains that scope.
Registry's image storage configuration uses floorFallbackProject studio: existing
Studio keys stay intact and additional floors use isolated project hash prefixes
inside the existing Studio bucket pair. Registry code must support these fields
before this configuration is released. No agent receives the uploader token.

For an existing exact `studio` image publisher, run the reviewed credential helper
with `studio-images --all-studio-floors --approved` only after compatible Registry
code is live. This explicitly migrates that exact principal, preserves its token
and all other principals, and refuses any unexpected scope drift.
