---
title: Agent Credential Access
description: Persistent agents must declare credential access in their agent
  bundle before any runtime sync path is allowed to use Vaultwarden for that
  agent.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - credential
  - access
---
# Agent Credential Access

Persistent agents must declare credential access in their agent bundle before any runtime sync path is allowed to use Vaultwarden for that agent.

This file defines the contract. It does not authorize broad access by itself, and it must never contain secret values.

## Design

`config/agent-skill-bundles/<agent-id>.json` is the per-agent source of truth for access intent:

- `credential_access.default_policy` is always `deny`.
- `credential_access.vaultwarden.organization` names the Vaultwarden organization.
- `credential_access.vaultwarden.allowed_items` lists exact item names and their runtime sync targets.
- `agent_visibility` records whether the agent may ever see the value directly. The default is `runtime-env-only`.
- `temporary_elevation` explains how task-scoped credentials may be granted and removed.

The bundle declares persistent credential materialization targets for automation
and review. It does not authorize direct Vaultwarden reads: the agent's own
Vaultwarden account and collection membership are authoritative there. The
runtime still receives synced credentials only through Kubernetes Secrets,
mounted files, or another approved secret delivery mechanism.

Project env materialization adds one narrower layer under
`credential_access.vaultwarden.env_bootstrap.projects`. Each project grant must
name approved profiles and map stable repo `vaultRef` aliases to exact
Vaultwarden item/field pairs. This is a separate task-time permission lane: it
does not require a Kubernetes Secret sync target and does not grant general
direct-lookup access. Direct reads remain governed by the agent's Vaultwarden
account and collection membership. This is a one-way Vaultwarden-to-local flow;
local `.env` upload is not part of the runtime contract.

The shared env helper passes project, profile, and `vaultRef` authorization
context to `openclaw-agent-secret-get`. The resolver rechecks that context
against its fixed runtime bundle before reading a value; caller-supplied bundle
directory overrides and private bindings files cannot bypass the
project/profile/alias grant.

`scripts/sync-agent-credential.sh` enforces this allowlist before reading Vaultwarden or writing Kubernetes. It requires the exact agent, item name, namespace, target type, Secret name, and key to match one bundle entry. Targets read the Vaultwarden item password by default; login-style test accounts may set `sync_target.source_field` to `username` for a second non-secret-identifying key. `scripts/sync-agent-mattermost-secret.sh` is now only a Mattermost-specific wrapper that adds the extra Mattermost base URL and channel ID keys.

All persistent agents have an approved direct-account Vaultwarden bootstrap.
For on-demand direct lookup, the agent's own Vaultwarden account and collection
membership are the authorization boundary; bundles do not duplicate an
item/field allowlist. The source helper is `scripts/agent-secret-get.sh`;
runtime images install it as `openclaw-agent-secret-get`. It validates the
agent bundle identity, accepts only `username` and `password` lookup fields,
and preserves the narrower project env-bootstrap checks. `task
verify-agent-direct-secret-lookup` proves the helper delegates item access to
Vaultwarden without reading live secret values.

2026-06-09 checkpoint: per-agent Authentik and Vaultwarden bootstrap credentials
live in `00-Super-Secret-Tokens`; agent-scoped collections exist for the direct
lookup path (`51-Agent-Emon-Lusk` through `55-Agent-Ramiro-Garcia`). Runtime
sync must keep using bundle allowlists and must not print secret values.

Supported sync target types:

- `kubernetes-secret-env`: a Kubernetes Secret consumed through environment variables or `envFrom`.
- `kubernetes-secret-file`: a Kubernetes Secret key intended to be mounted as a file by a deployment.
- `kubernetes-secret`: legacy alias kept for older bundle entries.

## What Goes In Git

Allowed:

- Vaultwarden organization name.
- Vaultwarden item names.
- Runtime destination metadata such as Kubernetes Secret name, namespace, and key.
- Purpose, review, and expiry text.

Not allowed:

- Tokens, passwords, session keys, private keys, OAuth JSON, or full Vaultwarden item JSON.
- Unreviewed or cross-role Vaultwarden collection access for an agent account.
- Credentials for another human or agent unless Fito explicitly approves the delegation.

## Current Policy

Tinus Lordvals / `agent-developer`:

- allowed item: `Mattermost / agent-developer BOT token`
- target: `kubernetes-secret-env` `agents-swarm/agent-developer-mattermost`, key `MATTERMOST_BOT_TOKEN`
- visibility: runtime environment only
- allowed item: `Kubernetes / agent-developer platform operator kubeconfig`
- target: `kubernetes-secret-file` `agents-swarm/agent-developer-kubeconfig`, key `kubeconfig`
- mount path: `/var/run/openclaw-agent/secrets/kubeconfig/kubeconfig`
- scope: source-managed agent-developer operator RBAC; never `cluster-admin`

Stewie Hobs / `agent-designer`:

- allowed item: `Mattermost / agent-designer BOT token`
- target: `kubernetes-secret-env` `agents-swarm/agent-designer-mattermost`, key `MATTERMOST_BOT_TOKEN`
- visibility: runtime environment only
- allowed item: `Kubernetes / agent-designer platform operator kubeconfig`
- target: `kubernetes-secret-file` `agents-swarm/agent-designer-kubeconfig`, key `kubeconfig`
- mount path: `/var/run/openclaw-agent/secrets/kubeconfig/kubeconfig`
- scope: source-managed agent-designer operator RBAC; never `cluster-admin`

Satwa Nutella / `agent-infra`:

- allowed item: `Mattermost / agent-infra BOT token`
- target: `kubernetes-secret-env` `agents-swarm/agent-infra-mattermost`, key `MATTERMOST_BOT_TOKEN`
- visibility: runtime environment only
- allowed item: `Kubernetes / agent-infra platform operator kubeconfig`
- target: `kubernetes-secret-file` `agents-swarm/agent-infra-kubeconfig`, key `kubeconfig`
- mount path: `/var/run/openclaw-agent/secrets/kubeconfig/kubeconfig`
- visibility: runtime file only
- scope: non-secret diagnostics plus approved pod exec in `agents-swarm` and product namespaces such as `core`; no Secret read access

Emon Lusk / `agent-coordinator`:

- allowed item: `Mattermost / agent-coordinator BOT token`
- target: `kubernetes-secret-env` `agents-swarm/agent-coordinator-mattermost`, key `MATTERMOST_BOT_TOKEN`
- visibility: runtime environment only
- allowed item: `Kubernetes / agent-coordinator platform operator kubeconfig`
- target: `kubernetes-secret-file` `agents-swarm/agent-coordinator-kubeconfig`, key `kubeconfig`
- mount path: `/var/run/openclaw-agent/secrets/kubeconfig/kubeconfig`
- visibility: runtime file only
- scope: source-managed agent-coordinator operator RBAC in approved namespaces; never `cluster-admin`
- allowed item: `Vaultwarden / agent-coordinator oauth api client`
- target: `kubernetes-secret-env` `agents-swarm/agent-coordinator-vaultwarden`, keys `BW_CLIENTID` and `BW_CLIENTSECRET`
- visibility: runtime environment only
- allowed item: `Vaultwarden / agent-coordinator login`
- target: `kubernetes-secret-env` `agents-swarm/agent-coordinator-vaultwarden`, key `BW_PASSWORD`
- visibility: runtime environment only
- allowed item: `Authentik / agent-coordinator service account login`
- target: `kubernetes-secret-env` `agents-swarm/agent-coordinator-authentik`, keys `AUTHENTIK_USERNAME` and `AUTHENTIK_PASSWORD`
- visibility: runtime environment only
- allowed item: `Project document-normalizer / agent-coordinator pilot token`
- target: `kubernetes-secret-env` `agents-swarm/agent-coordinator-document-normalizer`, key `DOCUMENT_NORMALIZER_API_TOKEN`
- scope: sanitized synthetic documents only; real, private, or client data requires separate approval
- visibility: runtime environment only
- direct-account access: Emon has a dedicated Vaultwarden account and
  agent-specific collections for task-time lookup. Vaultwarden account and
  collection membership authorizes direct lookup; the bundle retains only
  persistent sync and project-materialization declarations.

Ramiro Garcia / `agent-intake`:

- allowed item: `Mattermost / agent-ct BOT token`
- target: `kubernetes-secret-env` `agents-swarm/agent-intake-mattermost`, key `MATTERMOST_BOT_TOKEN`
- visibility: runtime environment only
- allowed item: `Project document-normalizer / agent-intake pilot token`
- target: `kubernetes-secret-env` `agents-swarm/agent-intake-document-normalizer`, key `DOCUMENT_NORMALIZER_API_TOKEN`
- scope: sanitized synthetic documents only; real, private, or client data requires separate approval
- visibility: runtime environment only
- allowed item: `Email / rmr.g@infuse-ai.com account`
- access path: runtime Vaultwarden lookup through `agent-intake-vaultwarden`, then `mail_intake.py` for IMAP read-only intake and `approval_email.py` for exact approved SMTP sends
- visibility: looked up at task time only; do not store the mailbox password in pod env, docs, logs, memory, or chat
- scope: read consulting mail context for `rmr.g@infuse-ai.com`, prepare internal drafts, and send only exactly approved artifacts through the SMTP wrapper; no autonomous external sends or commercial commitments without Fito approval
- allowed item: `Kubernetes / agent-intake platform operator kubeconfig`
- target: `kubernetes-secret-file` `agents-swarm/agent-intake-kubeconfig`, key `kubeconfig`
- mount path: `/var/run/openclaw-agent/secrets/kubeconfig/kubeconfig`
- scope: source-managed agent-intake operator RBAC; never `cluster-admin`

## Verification

Run:

```bash
task verify-agent-credential-sync
```

This dry-runs every bundle-declared credential target with placeholder values and checks a negative case where one agent tries to sync another agent's token. Live sync uses the company Vaultwarden endpoint by default:

```bash
OPENCLAW_BW_SERVER=https://vault.infuse-ai-tech.party
OPENCLAW_BW_DATA=/Users/mac/.openclaw/secure/bitwarden-cli-infuse
```

The helper still honors explicit `OPENCLAW_BW_SERVER` and `OPENCLAW_BW_DATA` overrides for controlled migration or break-glass testing.

Each persistent agent uses its own long-lived `platform-operators` kubeconfig and source-managed scoped RBAC. Only the separate approval credential has `cluster-admin`; agent kubeconfigs are never interchangeable with it. The temporary MarkdownGPT dogfood Secret and `mdgpt` operator RBAC were retired after the Level 3 attempt.

Run the live permission smoke with:

```bash
task smoke-agent-infra-kube-access
task smoke-agent-emon-kube-access
task smoke-agent-intake-mail-auth
```

Expected default result from inside the target agent pod:

- `get pods`: yes
- `get pods/log`: yes
- `get secrets`: no
- `patch deployments`: no

For Emon, `patch deployments`, `create pods/exec`, `get secrets`, and RBAC
changes are expected to remain `no` unless a new named task grants a reviewed
temporary exception.

Every persistent agent uses `GitLab / <agent-id> service account token` through
its own Vaultwarden account. Native Git bootstrap verifies the API identity;
GitLab tokens are not synchronized into Kubernetes Secrets or persisted in
glab configuration. Missing own access fails closed.

## Company Vault Auth Smoke

The active Vaultwarden endpoint for Kapiteky and swarm credential work is:

```bash
OPENCLAW_BW_SERVER=https://vault.infuse-ai-tech.party
```

Each persistent agent has a runtime auth secret named `<agent-id>-vaultwarden`
for the direct-account Vaultwarden path. This is Vaultwarden bootstrap material,
not an application credential bridge. Actual item retrieval goes through
`openclaw-agent-secret-get`, which delegates item authorization to the
agent's Vaultwarden account while keeping project env-bootstrap authorization
and supported-field validation local.

The direct-account path uses agent-specific collections and a runtime lookup
helper so changed Vaultwarden item values are picked up without restarting the
pod. Runtime use should use the approved API-key bootstrap path unless the
pilot later moves to brokered access. The direct lookup helper defaults to an
agent-scoped Bitwarden CLI profile and can bootstrap from
`BW_CLIENTID`/`BW_CLIENTSECRET` plus `BW_PASSWORD` or `BW_MASTER_PASSWORD`. It
also supports an existing `BW_SESSION` or mounted `OPENCLAW_BW_SESSION_FILE`
for recovery/testing. The sync helper sources the API client id/secret from
`Vaultwarden / <agent-id> oauth api client` and the unlock password from
`Vaultwarden / <agent-id> login`.

Historical Azure DevOps bridge, approved 2026-06-11 and retired as an active
consumer in this renewal: the existing company item
`Azure DevOps / infuse-ai PAT for all repos` is assigned to each persistent
agent direct-access collection (`51-Agent-Emon-Lusk` through
`55-Agent-Ramiro-Garcia`) for the former shared helper. This paragraph is retained as an access-review
finding, not permission to use it. The new runtime has no Azure token consumer.
Vault collection membership and token revocation require a separately verified
access change; removing the consumer does not prove those grants were revoked.

The `openclaw-agent` entrypoint prewarms Vaultwarden when
`OPENCLAW_BW_PREWARM=true` (the default): it configures
`OPENCLAW_BW_SERVER`, logs in with the API-key bootstrap when the CLI profile is
cold, unlocks with `BW_PASSWORD` or `BW_MASTER_PASSWORD`, writes only the
resulting session to `$OPENCLAW_BW_DATA/session` with `0600`, and runs
`bw sync`. Agents that require Vaultwarden at boot can set
`OPENCLAW_BW_PREWARM_REQUIRED=true` to fail startup instead of continuing in a
degraded state. For Emon, `OPENCLAW_BW_DATA` is on the workspace PVC at
`/workspace/.openclaw-secure/bitwarden-cli-agent-coordinator`.

Sync the temporary auth secret with:

```bash
AGENT_ID=<agent-id> task sync-agent-vaultwarden-auth
```

Do not print `BW_SESSION`, `BW_CLIENTID`, `BW_CLIENTSECRET`, `BW_PASSWORD`, or
`BW_MASTER_PASSWORD`. Replace the API-key bootstrap with brokered access if the
direct-account path expands beyond approved agent-scoped lookup.

## Review Rules

Review credential access when:

- an agent joins a new channel;
- an agent is promoted from draft/read-only work into write-capable work;
- a token is rotated;
- an incident, noisy behavior, or wrong-channel post occurs;
- the access bundle changes from temporary elevation to persistent access.

If a synced item is no longer needed, remove its bundle declaration first, then
remove the runtime Secret and rotate or archive the Vaultwarden item if
appropriate. Revoke direct lookup by removing the item from the agent's
Vaultwarden visibility.
