---
title: Native Studio lifecycle delivery plugin
description: Promote the qualified native lifecycle plugin without enabling new effects before every enrolled Gateway is ready.
type: report
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - evidence
---
# Native Studio lifecycle delivery plugin

The first real production mission reached autonomous closeout, but its delivery,
revision and closeout updates were not consistently visible in Mattermost.
Studio PR 3713 adds transactional native notifications: specialists post their
own delivery/blocker updates, Emon posts revision/verification in the task thread
and closeout in the coordination thread only after the actual closing run settles.

The plugin advertises lifecycle protocol version 1. Each notice retains exact
assignment, account, thread, action and evidence identity. The durable journal
reconciles uncertain admission/post receipts without replay; echoed lifecycle
posts add context without creating another run. A revision waits for its native
notice receipt and stays in the same task thread/session.

## Qualification

- Studio full suite: 352 tests passed; type/check, plugin and web builds passed.
- Actual browser/OIDC/HTTP/SQLite: eight checks, seven desktop/mobile screenshots.
- Real disposable Mattermost and three actual pinned Gateways: two verified
  tasks, three evidence revisions, ten settled runs, eight lifecycle posts and
  ten ordinary workspace reads. Models and OIDC are deterministic fixtures.
- Exact packaged plugin SHA-256:
  `33229521c3e3fd9b8b664b32711c3db3fd1b8075c870d6faf576b12ee44d7128`.
- Exact full server proof SHA-256:
  `4cf1085166935970ff4d22245dc98e12b89c502c240df353874359b23698a013`.
- Host remains `0fcc9360aa8ea03f61ca6ffd2692995ec74e726c`. Mattermost/Codex,
  skill/persona pins, tools, credentials and native routes stay unchanged.

The durable Studio evidence is
`docs/evidence/2026-10-06-native-lifecycle-verification.md` and
`docs/evidence/2026-10-06-native-lifecycle-server-proof.json`. The live-model
qualification is a separate new production mission; it is not implied by the
fixture run or image build.

## Ordered activation

Deploy the schema-11-compatible backend first with
`nativeMissions.lifecycleNotifications` absent/false. Then deploy this plugin
through normal checks and the unchanged actual AMD64 runtime capability gate.
Verify all 30 installed package files, native service health and seven persisted
required-owner rooms across four enrolled Gateways. Only then enable lifecycle
notifications through Studio's owning configuration pipeline and run the bounded
follow-up pilot described in Studio's native-mission plan.

Rollback keeps the schema-11-compatible writer and disables lifecycle delivery
and, when needed, new execution. Do not downgrade the writer, remove owner rows,
clear journals or blindly resend effects. No historical notification backfill and
no Studio data backup. The separate Mac/Tailscale mission remains pending.

## Backend artifact

Studio PR 3713 merged normally as `853ef3420c436d84c26ff318bf8073365f8f4a2b`
after branch build 8883 and required PR build 8884 passed. Automatic main build
8885 succeeded. At 03:10:32 UTC, both deployed Studio containers were ready with
zero restarts; all 30 qualified package files matched and the lifecycle flag
remained false. Four valid existing enrollments and native cutover were retained.

The plugin source image pinned by this change is
`registry.infuse-ai-tech.party/studio/studio@sha256:f47087abeabe3c3bcfc5a5bf52abe08524ceb6ec0437bc72eb7111d8abd17dc7`.
The Gateway image still requires its own pipeline capability gate and rollout.

## Repository verification

The full `task verify-ci` passed all 585 tests, with the exact pinned
`db1506fc9864a1a5f22403daaf2e344cdaed80e1` skill checkout and canonical macOS
temporary directory. Knowledge-format validation passed 109 documents;
`git diff --check` passed. Review found only the intended immutable Studio image
pin plus rollout/evidence documentation. No host/runtime package, policy,
capability grant or production flag changes are included in this promotion.
