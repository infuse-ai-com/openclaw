---
title: Studio lifecycle plugin rollout
description: Exact producer package and staged Gateway verification for the four Studio lifecycle repairs.
type: report
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - evidence
---
# Studio lifecycle plugin rollout

## Release scope

Studio PR 3870 merged as `e7d50eabb1681728a28fc1e38cb3ad6a6ff00db1`.
Successful main build 9441 published
`registry.infuse-ai-tech.party/studio/studio@sha256:c2631deb0c886ea08f2b4ced50428bdd41b8e2d9fc6957c904e98da40a61ad59`.
That exact image supplies all 40 plugin files. The consumer checksum manifest
records the producer image, source and build. Old README/package overrides are
removed because the owning Studio release now contains the qualified host metadata.

The repairs address cancellation before runtime admission, definite provisioning
refusal recovery, feedback during closing, and root-project legacy admission.
Studio authority changes are already deployed. This update installs the matching
plugin while preserving OpenClaw `2026.10.3` / `877030b3a66bec373d235129919a5a7a964ca07f`,
model settings, grants, native identities, profiles and journals.

## Baseline and local evidence

Live Studio configuration identified exactly four enabled generation-1 Gateways:
`swarm-coordinator`, `swarm-developer`, `swarm-designer`, `swarm-infra`.
All four returned native `studio.identity.active=true`, instruction protocol 1
and findings protocol 1 before rollout. Intake is not enrolled.
The fleet began on image digest
`sha256:77ba02e2c67460c0d8a4e2c4661eeeb8f8d07a805905dcdbe488c5da2d5fcdcd`.

- All 40 files copied from the released producer package pass the strict verifier.
- `AGENT_ID=agent-designer task verify-ci` passes, including 606 tests, with the
  exact pinned agent-skills source supplied locally. The initial sandbox run
  lacked loopback access and selected a stale workstation skill catalog; the
  successful rerun used the pinned source and canonical temporary directory.
- The production native overlay renders five single-replica Recreate agents.
- `git diff --check` passes. No access, credential, network, PVC or schema changes.

## Promotion and live acceptance

Use the owning main pipeline, with its source gate, release lock, runtime-only
upgrade and existing developer-first/coordinator-last drain and handoff sequence.
The common image also refreshes Intake without installing or enabling Studio there.
Retain the production authority selection and disabled legacy SQL workers.

After rollout, match every enrolled Gateway's installed 40-file package to this
manifest, verify the actual host source, new process/pod identity, readiness,
loaded plugin and active Studio service, protected routes and fresh authenticated
polling. Record CI/build identities and live results separately from source readiness.

Bounded functional verification needs explicitly labelled test missions and
native feedback. It must retain exact paper approval, session/action/effect IDs
and real receipts. Do not enable legacy V1 merely to reproduce its admission
case, inject production transport faults, rewrite journals, or delete history.
Readiness and byte identity alone do not prove the repaired race conditions.

## Recovery

If a live gate fails, stop promotion and reconcile exact active work. Preserve
required-owner routes, the schema-compatible Studio writer, journals and native
posts. Never erase uncertain effects or resend with a new identity. The previous
host image is not permission to downgrade persisted state. No Studio backup or
snapshot is part of this rollout.
