---
title: Agent Observability Signal Quality Baseline
description: Aggregate-only seven-day baseline for the 2026-10-15 Langfuse and collector remediation.
type: report
status: active
owner: team:agent-platform
tags:
  - report
  - observability
  - langfuse
  - opentelemetry
---

# Agent Observability Signal Quality Baseline

## Window and provenance

- Window: `2026-10-08T20:30:00Z` through `2026-10-15T20:30:00Z`.
- Source: project-scoped Langfuse public API and the live collector's two local
  metrics endpoints.
- Runtime revision: `877030b3a66bec373d235129919a5a7a964ca07f`.
- Image revision:
  `sha256:bdb180deb44f8e50062bbd444a84b611ce9d3d71a198a86be26ca9772b79d10f`.
- No credential, trace ID, tool-call ID, status text, input, or output is stored
  in this report.

## Aggregate baseline

| Signal | Attempts | Errors | Notes |
| --- | ---: | ---: | --- |
| All Langfuse observations | 66,405 | — | API total for the exact window |
| Gateway RPC `handler` | 17,798 | — | singleton envelope family |
| Gateway RPC `dispatch` | 17,798 | — | singleton envelope family |
| Gateway RPC `response` | 17,798 | — | singleton envelope family |
| Official runs | 271 | 1 | canonical fleet outcome |
| Curated turns | 170 | 9 | 99 coordinator, 35 designer, 35 developer, 1 infra |
| Official tools | 3,017 | 188 | canonical volume/outcome |
| Curated tools | 3,122 | 67 | classification drilldown |
| Skill lifecycle observations | 90 | 2 | no observation newer than the earlier marker cohort |
| Wrapper lifecycle observations | 160 | 1 | coordinator/developer only |
| Knowledge retrieval | 1 | 1 | no successful discover/fetch in the window |
| Knowledge decisions | 10 | 1 | all traffic source unavailable |

The three Gateway RPC families account for 53,394 observations, or 80.4066% of
all observations in the exact window. The earlier trace-level audit found that
the same three one-span families accounted for 53,553 of 58,363 traces
(91.8%). Filtering them only on the Langfuse branch is therefore expected to
clear the 85% trace-reduction gate without removing RPC span metrics.

All 170 curated turns and every reviewed behavioral signal had
`traffic.source=unavailable`. `agent-intake` had no turn in the window and is
classified as expected-idle: the deployment is healthy, but current routing
does not assign it organic work.

## Collector health

- Deployment Ready with zero restarts and an empty exporter queue.
- `otelcol_exporter_send_failed_spans=20` is cumulative since collector start;
  no recent exporter error appeared in the seven-day log review.
- The collector emitted repeated description-conflict logs every 15 seconds for
  `openclaw_gateway_rpc_queue_wait_ms_milliseconds` because two producers used
  different descriptions for the same instrument.
- The live exported metric uses the suffixless collector self-metric names and
  the OpenMetrics queue-wait histogram name observed in this report's runtime
  checks. Prometheus rule evaluation remains owned by the monitoring repo and
  namespace.

## Pinned runtime compatibility

The exact pinned OpenClaw `2026.10.3` package (runtime revision
`877030b3a66bec373d235129919a5a7a964ca07f`) was inspected before enabling
direct attribution tools. Its public plugin declarations accept
`catalogMode: "direct-only"`, and its tool-search implementation explicitly
retains those tools outside the searchable catalog. The four attribution tools
therefore use the supported per-tool mechanism; the fleet-wide
`codexDynamicToolsLoading: "direct"` fallback is not required.

## Privacy

The live audit found zero non-empty input/output values across all reviewed
official and curated run, tool, skill, wrapper, and Knowledge Base
observations. Collector privacy deletion and metadata-only resource allowlists
remain mandatory rollout gates.

## Reproduction

Resolve the two Langfuse project keys from Vaultwarden into
`LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY`, then run:

```bash
python3 scripts/audit-agent-observability-live.py \
  --start 2026-10-08T20:30:00Z \
  --end 2026-10-15T20:30:00Z
```

The command emits aggregate JSON only and never writes credentials or raw
observations.
