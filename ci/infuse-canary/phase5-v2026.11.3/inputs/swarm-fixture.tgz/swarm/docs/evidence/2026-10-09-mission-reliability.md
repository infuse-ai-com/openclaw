---
title: Studio mission reliability promotion
description: Exact plugin and instruction pins for durable feedback and independent review, with explicit rollout gates.
type: report
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - evidence
---
# Studio mission reliability promotion

This source change promotes the compatible Studio plugin and agent instructions.
It is not evidence that the live real-model pilot has passed.

## Exact sources

- Studio PR 3766 merged as `a9433bf27d0ca272cc4b75870134f927194553b6`.
  Main build 9099 succeeded, deploying
  `registry.infuse-ai-tech.party/studio/studio@sha256:2aa27f4f9b29d62ce4b1bf0dd6e9410e31a16ebd3f6c95177f89c0d76272adc5`.
  That immutable image supplies the plugin in this Dockerfile.
- Agent-skills PR 3764 merged as
  `182759b8e1abbf15fe8d2934f88f1118ebb94d67`; the catalog pins that commit.
- Persona PR 3767 merged as `3c8297582eacce05e4f2b5043b8bbe0de33278ee`.
  Startup sync follows persona main; verify the installed Emon manifest and
  approved-scope text at rollout rather than inferring it from the merge.
- The OpenClaw host remains `0fcc9360aa8ea03f61ca6ffd2692995ec74e726c`.
  Host, Mattermost, Codex and Bitwarden package pins are unchanged. There is no
  new fork release, permission grant or channel membership change in this PR.

## Pre-promotion qualification

Studio passed 389 service tests, 250 mission tests, type/build checks, native
workspace UI and multi-project browser checks. The final source and PR builds
9097 and 9098 passed. Agent-skills passed 298 tests and its catalog, secret and
knowledge-format gates; persona validation passed nine tests.

The disposable real-server proof uses actual Mattermost, Studio SQLite/HTTP and
three Gateways on the exact pinned host, with deterministic model responses.
It passed two tasks, clarification, a requested revision, required-finding closure,
two busy human inputs applied in one run, stale-delivery rejection, zero extra
turns for consumed causes and autonomous closeout. Four instruction receipts,
three evidence revisions and 14 settled runs were reconciled. The later
cancelled-run receipt correction has focused and full-suite coverage; it does
not change the successful normal-path fixture. See Studio's
`docs/evidence/2026-10-09-mission-reliability.md` for the exact proof boundaries.

## Required live gates

Local `AGENT_ID=agent-designer task verify-ci` passed, including 600 tests,
using the reviewed agent-skills checkout through
`SKILL_SOURCE_ROOT_INFUSE_AI_AGENT_SKILLS`. Knowledge-format checks passed 112
documents. The image's pinned-host capability probe remains a CI gate.
After ordinary CI and deployment, compare
all enrolled plugin files, skill/persona manifests and live protocol responses.
Verify both services and required-owner route membership before enabling
instruction protocol 1 on one project. Keep other assignments compatible.

The real-model production/Mac pilot and joined receipt/turn measurements remain
required. Do not merge the separate Finaxis feature PR 3760 as part of this
runtime change. Its paper authorized a reviewed PR, not a release. Rollback
retains custody and the schema-compatible writer with execution disabled.

## Artifact-only finding follow-up

The real Mac pilot correctly stopped when a standalone text artifact could not
provide a repository reference for `propose-fix`. Studio PR 3771 merged as `d3dc562e3adcc65e800c22d05ea81d7ebbf05d8c` and adds exact
artifact-content binding while retaining source references for repository work.
Agent-skills PR 3770 merged as `6ccb973eaccc48d3e56ac169511e64ec9d27ef15`;
its guidance requires proposing before delivery and never inventing references.

Promote the matching Studio plugin image and this reviewed skill pin together.
The host/persona pins, grants, native identities and channel bindings stay the
same. Production and Mac admission are disabled; the Mac mission is held and
all current native sessions are settled. The default `preserve` profile must
retain studio-local-mac during repair rollout. Resume the same assignment/thread
after checking installed artifact support, then restore production through the
owning profile pipeline after the pilot settles.

Studio main build 9112 passed and deployed the ready image
`registry.infuse-ai-tech.party/studio/studio@sha256:ca2cb3655d052e708d63d37ec14549543433f4dd9ccfaf694331db42dfc0445f`.
This Dockerfile pins that exact plugin image; the catalog pins skills `6ccb973e`.
Verification passed 600 tests and 112 knowledge documents.
