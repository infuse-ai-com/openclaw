---
title: Native Studio Run Receipt Recovery
description: Promote the qualified pinned-host run reconciliation adapter after the real production mission pilot.
type: report
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - evidence
---
# Native Studio run receipt recovery

The real production pilot closed autonomously with two verified tasks and twelve
settled Studio actions. It used the configured models and real Infuse AI
Mattermost; its record is owned by Studio at
`docs/evidence/2026-10-06-production-native-pilot.md`. Lifecycle notification
visibility and an unenrolled ambient observer remain explicit findings; the Mac
mission is pending. This update does not claim those findings are resolved.

## Repair and qualification

The pinned host rejects a `chat.history` physical-session selector without a
message anchor, while anchored history does not expose input receipts. Ordinary
Codex turns also need not have pending-input receipts. Studio PR 3711 reads
current history by key and verifies the physical session, then requires a
consumed input with actual run evidence or an exact terminal run/session receipt
with a settlement timestamp. Missing or contradictory receipts stay uncertain.
The adapter only reads; it never resends a turn or expands capability.

- Studio PR 3711 normal merge: `61a075fc52b072946bffb92565c3ddd408637b0d`.
- Required PR validation 8875 passed; automatic main build 8876 succeeded.
- 343 tests, workspace checks and plugin build passed.
- Read-only production queries reproduced the original selector error and
  verified exact terminal-run recovery, plus replaced-session rejection.
- Durable journal tests cover lost acknowledgement, restart, later recovery,
  one dispatch and one settlement.
- The final disposable real Mattermost/three-Gateway suite passed against
  unchanged host `0fcc9360aa8ea03f61ca6ffd2692995ec74e726c`: two verified tasks,
  clarification, revision, ten settled runs and ten ordinary workspace reads.
  Its OIDC/model are deterministic fixtures, separate from the live pilot.
- Qualified plugin archive SHA-256:
  `e67fce1552efbe6788b774810bdc6698e1bfd94205c31aafebfd5724189b5259`.
- Full disposable proof SHA-256:
  `732efc2e6d74d4b16d9935c28c8646dc60ddf774833d69a18a21738d83db009f`.
- Sanitized Studio receipts: `docs/evidence/2026-10-06-native-run-recovery.json`
  and `docs/evidence/2026-10-06-native-run-recovery-server-proof.json`.

At 02:14:08 UTC the deployed Studio Pod matched all 29 qualified plugin files,
was ready with zero restarts and retained four valid enrollments plus native
execution/cutover. Pin its exact image:
`registry.infuse-ai-tech.party/studio/studio@sha256:d1dd5810ae8c2b5da3b90655b382b086a958411f23d2c2debba08f5ea1ab1322`.
Host, Mattermost, Codex, skill and persona pins remain unchanged.

## Rollout boundary

Normal repository checks and the unchanged actual AMD64 image capability gate
remain required. Verify the exact deployed plugin files, native service health
and all seven persisted owner routes after rollout. Keep legacy Backoffice
admission/workers retired and the completed pilot's history unchanged. Retain
route ownership and journals on failure; no ordinary dispatch fallback or blind
replay is allowed. No Studio data backup is taken.

## Repository verification

The complete local check passed all 585 tests with the reviewed skill source and
canonical macOS temporary directory:

```sh
TMPDIR=/private/tmp CHECK_SKILL_SOURCE_CATALOGS=true \
  SKILL_SOURCE_ROOT_INFUSE_AI_AGENT_SKILLS=/private/tmp/studio-native-agent-skills \
  task verify-ci
```

The referenced skill checkout is the pinned
`db1506fc9864a1a5f22403daaf2e344cdaed80e1`. Knowledge-format validation passed all
108 documents, and `git diff --check` passed. Earlier attempts exposed two macOS
`/var` alias fixture failures and selected an older local skill catalog; the
unchanged checks passed with the canonical directory and exact reviewed source.
No tests, capability gates or production permissions were weakened.

## Production rollout receipt

Swarm PR 3712 merged normally as `9b515874cbd1d5dbe3bb7763255be33b41069e8e`.
Main build 8879 succeeded and all five agents are ready on image
`sha256:c03ca0527db4d276fa550f83671fc58364eefaf391529a6a4a48441a4fc8ab97`.
The actual AMD64 capability gate passed all seven checks at 02:30:49 UTC
(build log 6, lines 133–135).

At 03:08:18 UTC, a read-only audit of the four enrolled running Gateways
verified active Studio services, readiness 200, all 29 qualified installed plugin
files per Gateway and all seven persisted required-owner rooms with their exact
native identities. Emon retains four rooms; each specialist retains one. No
post, model turn, ownership write or credential change was made by that audit.
The first audit ran before Emon was ready; a later cold CLI inspection exceeded
the audit's local 20-second allowance. The unchanged assertions passed with a
60-second diagnostic allowance; production startup/RPC/test gates were unchanged.
The unprivileged runtime cannot read the image-build receipt directory, so the
capability result above is supported by its original pipeline log.
