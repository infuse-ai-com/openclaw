---
title: Studio Tool Inventory Compatibility Fix
description: Reproduce and correct the pinned OpenClaw model-preview metadata scope without broadening mission permissions.
type: report
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - evidence
---
# Studio tool inventory compatibility fix

## Observed failure

Production mission `3b2dca84-33a5-478d-ba5c-9ddd876d1060` was approved and
started correctly. Its coordinator dispatch
`46e1527d512473457bf8744a822491dd9f9577883cd531623798cdd798e468d6`
stopped with `runtime_identity` before Studio execution admission and
`chat.send`. The exact child incarnation existed, with no transcript messages
and no active run. `tools.catalog` advertised the four Studio tools, while
`tools.effective` returned an empty inventory after the persisted child policy.

The generic error currently conflates identity and tool-policy mismatches.
This case is a tool-inventory mismatch. Keep its journal and uncertain dispatch
as evidence; do not clear the marker or replay the send.

## Cause and correction

The pinned OpenClaw `2026.9.7` package, source
`b498cfc5b8c7862e4d029346dbebc6eabcf179e4`, resolves these Codex model previews
through a read-only prepared model generation. Its implicit metadata snapshot
contains the model provider owners but omits the enabled Studio tool owner.
The nested inventory consequently cannot discover Studio's tools.

`patch-studio-tool-inventory.py` passes the caller's full plugin metadata
snapshot into that read-only acquisition. The existing generation scope,
lease lifetime, tool-owner availability, policy filters and schema projection
remain in place. No permission, model, credential, enrollment or journal
configuration changes are needed. In particular, adding `tools.alsoAllow`
does not repair this metadata omission and is not part of the change.

The patch targets only `dist/tools-effective-inventory-BhPGwXq_.mjs`:

- Original SHA-256: `3ea6c24a725353dbc093c1255bd85ce55ebc7660b1b1983058483191e98b2112`.
- Patched SHA-256: `fad15a01183a26c1c13e409ba6281a638f5653e08ebcb5e5a9b81dfdd8978d9b`.

Unknown versions, changed source bytes and unexpected output fail the build.
Reapplying the exact patch is harmless. The image labels the patch and retains
its public-RPC proof under `/opt/openclaw-artifacts/`. Reassess and remove the
patch when an upstream runtime passes the same probe without it; do not carry
these private bundle filenames forward to another runtime pin blindly.

## Verification

The unmodified installed host reproduced the empty inventory with both the
original configuration and an explicit Studio tool allowlist. Instrumentation
in a disposable runtime copy identified the narrowed metadata snapshot; the
system-installed host and production were not modified by that investigation.

The corrected host's public RPC probe covers `openai/gpt-6-astra`,
`openai/gpt-5.6-sol` and `openai/gpt-5.6-terra`. For each model it creates idle
parent/child sessions, applies the finite inherited child policy and requires
exactly these tools:

- `studio_mission_context`, `studio_mission_command`, `studio_mission_evidence`.
- The same set plus `studio_source_read` for the source-enabled case.

Every child transcript must remain empty; ordinary-session tools must remain
unchanged. Model IDs and provider-selected Codex routing must remain intact.
Disabling Studio must remove its tools even from an otherwise granted child. The environment contains no user credentials, channels and cron are
disabled, and the bridge points to an unused loopback endpoint. The probe never
invokes a tool, `chat.send`, a provider, or a real Studio authority. It removes
disposable state and redacts its generated Gateway token from retained logs.

Run locally against a disposable host copy with the patch applied:

```bash
node scripts/probe-studio-tool-inventory.mjs \
  --host-root /path/to/disposable/openclaw \
  --plugin-root /path/to/complete/studio-plugin \
  --output /tmp/studio-tool-proof
```

The image runs the same probe before publication. This proves tool preview and
policy isolation, not a production model turn or the complete delegation,
delivery and coordinator closeout flow. After rollout, inspect the retained
failed session read-only, then use a fresh bounded mission for execution;
uncertain work must never be automatically resent.

## Native canary pin refresh (2026-10-06)

The first native rollout build, [8847](https://dev.azure.com/infuse-ai/Infuse%20AI/_build/results?buildId=8847),
stopped before deployment because this guard still named the older bundle.
The published `0fcc9360aa8ea03f61ca6ffd2692995ec74e726c` archive contains
`dist/tools-effective-inventory-BK8AELgh.mjs`. Its package SHA-256 is
`82c2ec6af20a5f2c5070ae27884adb7521e866d6eccd0b707693e9b83fb0f88c`.

The reviewed pin now lives in `scripts/studio-tool-inventory-pin.json`, shared by
the checksum guard and real Gateway probe. The correction remains the same
metadata-snapshot argument; runtime archive bytes and tool policies are unchanged.
The probe also checks the embedded build commit. Repository tests bind its version,
source commit, archive checksum and image label to the actual pipeline, so a future
runtime-pin change cannot silently leave this compatibility proof on an older host.
Unknown source bytes still fail before any patch is written.

- Original bundle SHA-256: `ec5a83c64bf756d394652c0560821c8ebe56245660344fb7894dae1dde11552b`.
- Patched bundle SHA-256: `6fe22824fe31e53b4d8a1e093e6909f57d68bb3f7aa8b942967396d3401ac9c1`.
- `task verify-ci`: passed, including 585 unit tests.
- Native Linux ARM64, Node 24.21.0, exact published host and qualified Studio
  plugin archive: unpatched real Gateway reproduced the missing Studio tools;
  patched real Gateway passed all seven checks. Applying the correction again
  was a no-op. Original 45-second startup and 10-second RPC limits were retained.
- Positive proof completed at 2026-10-05T23:54:54.525Z; receipt SHA-256
  `10a8f587ed1e3ec6736db40bfff69e9fa943d1e05f2965fd74955530fc2bbc90`.
- This local proof uses no model turns. The production AMD64 image must still
  pass the same unchanged Gateway gate in its owning BuildKit pipeline.
