---
title: Studio Mac authority profile verification
description: Local checks for explicit, recoverable switching between production and the Mac backend.
type: reference
status: active
owner: team:agent-platform
tags:
  - studio
  - verification
  - tailscale
---
# Studio Mac authority profile verification

The runtime renderer and owning pipeline now support a reviewed `local-mac`
profile alongside production. This is preparation for a live Mac mission, not
proof that such a mission has run. No Gateway profile was changed during these
checks. The production lifecycle pilot remains on `studio-production`.

## Verified locally

The complete `task verify-ci` passed 591 tests with the pinned agent-skills
checkout `db1506fc9864a1a5f22403daaf2e344cdaed80e1`. Six focused profile tests
cover both switch directions, preserving the deployed selection, rejected
identity/destination/channel drift, replacement of all four native Gateways,
partial-rollout retry, and rendering both complete Kustomize overlays. Rendered
ordinary tools, skills, models and native accounts remain byte-equivalent as
parsed configuration; the intake agent deployment remains unchanged.

The Mac test environment requires `TMPDIR=/private/tmp` to avoid symlink aliases
in existing exec-provider and browser-cache fixtures, plus
`SKILL_SOURCE_ROOT_INFUSE_AI_AGENT_SKILLS` pointing at the pinned source rather
than a stale unrelated local catalog. An initial run without those environment
settings failed those checks; no test assertions or production checks were
weakened. After a review fix for interrupted profile switches, the full suite
was rerun successfully.

## Review

Separate correctness/security and maintainability reviews traced the renderer,
credential references, persisted authority marker, source-impact classifier and
staged rollout. One actionable defect was fixed: a failed switch had already
written its desired marker, so a retry could incorrectly preserve partly
switched Gateways. The marker now remains pending until fleet verification;
retries replace every native Gateway. This is tested for both authorities.

Profile selection and identity constraints live in one narrow helper. The
pipeline passes only enumerated choices; it does not accept arbitrary URLs or
credential names. The existing renderer and fleet rollout remain the owners.
No permissions, capabilities, TLS validation, network policies, journals or
PVC contents are changed by this slice.

## Live preparation and remaining proof

Four private local channels were created on 2026-10-06 with Fito, Emon and the
relevant specialist. Their immutable IDs are in the local route contract.
Headers state that local execution is inactive. No mission posts were sent
while creating channels, and the unrelated Kapiteky account was not added.

Before a live switch, configure separate local credentials, verify current
membership and HTTPS identity, disable source admission, and reconcile every
accepted run and effect. The pipeline switch parameter is an operator
attestation, not automated proof of quiescence. Keep both authorities disabled
during a partial rollout. Verify retained inactive route ownership and no
ordinary-chat fallback in both directions. Run the local mission, then return
the fleet to production using the same settlement checkpoint.

See [the operator runbook](../runbooks/studio-mac-profile.md). No local mission,
production-to-Mac switch, or return-to-production success is claimed here.

## Qualified native planning context promotion

The live production mission completed with two verified tasks, 17 settled Studio
actions and nine native lifecycle notices. Its planning phase required an
operator-supplied role/owner map. Studio PR 3716 fixes that by returning exact
configured tuples in the authenticated context. Main build 8892 deployed commit
`24ac2ec342e86a8c9de8410433d07612daadd011`; the actual Studio container matches
all 30 files of qualified plugin archive
`869704070fde1eca74d94f2ecff8408a9a48b1e1b296581844b8063d2d17ce8a`.

The Dockerfile now pins that exact Studio image
`sha256:93426b5f36149513b78d95a2651a6b3a4ed72a9630e24c13f453c045800ce41a`.
The isolated pinned OpenClaw host and existing tools/credentials are unchanged.
Normal default deployment keeps the production profile; it does not select Mac.
The Mac credential creation is prepared separately and awaits specific user
authorization after automatic approval review rejected the new grant. No local
Secret or vault value was created, and no Gateway switched authority.
