---
title: Native Studio Service Health Recovery
description: Promote the verified native pause and outage recovery repair while preserving required-owner routes.
type: report
status: active
owner: team:agent-platform
tags:
  - studio
  - runtime
  - evidence
---
# Native Studio service health recovery

## Observed defect

The initial required-owner swarm deployment (build 8849, source
`cfef397e63abc393499c7152aabcb820d3df2a95`) passed its image capability gate and
rolled out successfully. The actual native Gateway health audit then reported
`service-failed` because the paused Studio authority returned
`EXECUTION_DISABLED`. Successful native polls also lacked health recovery.

Studio PR 3702 retains route ownership during intentional pauses without model
execution. Real transport errors remain visible until a complete successful poll
clears them. A pause does not clear a previously recorded transport error.

## Qualification

The Studio source passed 340 tests, checks and builds. Its opt-in real-server
proof used three actual Gateways and disposable Mattermost on pinned OpenClaw
`0fcc9360aa8ea03f61ca6ffd2692995ec74e726c`. All three remained healthy while
paused, reported an actual Studio backend outage and recovered without restarting
Gateways or creating model turns before intake. The same run completed two tasks,
clarification, a revision, three evidence revisions and ten settled runs.
OIDC and model responses were deterministic fixtures, not a production mission.

- Qualified plugin archive SHA-256:
  `b54101e5b002ba4a9c8b1dc31a7035abd28d56227b84d8d0709cab3a96f87df8`.
- Full private proof SHA-256:
  `fd7c7357c0c883b703227be666b03c00e12199381620d1e01b26d7344a77090e`.
- Sanitized receipt is owned by Studio at
  `docs/evidence/2026-10-06-native-service-health-proof.json`.

Studio PR 3702 merged as `20fafd01b00f96488577ec0683ff579a06a186a6` after
required validation 8852 passed. Automatic main build 8853 deployed image
`registry.infuse-ai-tech.party/studio/studio@sha256:77857b957c578ff7233bf611077872bd2142d19ba569a6bb766c5244c7d40ae7`.
At 00:39:55 UTC the actual Studio Pod matched all 29 files from the qualified
archive, had four valid enrollments, and retained disabled native execution and
cutover. This update pins that exact image. Host, Mattermost and Codex archives
stay pinned to the already qualified canary.

## Deployment cancellation

Manual duplicate build 8850 continued deploying after cancellation because
`BuildAndDeploy` only checked branch/reason flags. Azure's timeline explicitly
reported that its condition re-evaluated to true. The run ultimately recorded
`canceled`; it is not passing qualification evidence. Original build 8849 remains
the successful source deployment.

Add `not(canceled())` to that stage's existing conjunction. This retains the
intentional main-branch behavior when earlier verification stages are skipped,
while rejecting a cancelled run. The required `build_image` dependency and all
existing image, branch and deployment checks remain. This follows the
[Azure job status expression semantics](https://learn.microsoft.com/en-us/azure/devops/pipelines/process/expressions?view=azure-devops#job-status-check-functions).
A live cancellation of a new production deployment is not used as a test.

## Repository verification

`task verify-ci` passes all repository gates, including 585 tests.
Knowledge-format verification passes 107 documents. Standard review found no
blocking findings. The unchanged AMD64 image capability probe and hosted checks
remain required before rollout; successful local checks do not replace them.

## Activation boundary

Native execution stays disabled until all seven route protections and actual
plugin health are confirmed on the promoted image. Keep Backoffice admission
retired, six legacy mission crons disabled and all five SQL workers at zero.
The bounded production pilot and separate Mac/Tailscale mission remain pending.
Rollback stops new execution while retaining route ownership and historical
records. No Studio data backup is required or performed.
