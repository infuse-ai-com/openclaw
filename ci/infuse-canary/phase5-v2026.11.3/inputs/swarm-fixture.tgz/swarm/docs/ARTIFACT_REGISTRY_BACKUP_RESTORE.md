---
title: Artifact Registry Kubernetes Backup And Restore
description: Safe Kubernetes procedure for quiesced Artifact Registry backup transfer, off-node verification, and replacement-PVC restore.
type: runbook
status: active
owner: team:agent-platform
tags:
  - artifacts
  - backup
  - kubernetes
  - recovery
---
# Artifact Registry Kubernetes Backup And Restore

## Current storage decision

The supported v1 path is an offline file-level backup produced by the exact
Studio-owned Registry recovery executable. Live inspection on 2026-09-01 established:

- context: `infuseai-k8s`;
- identity: `system:serviceaccount:platform-operators:kapiteky-cluster-operator`;
- storage: default `microk8s-hostpath`, `WaitForFirstConsumer`, `Delete`;
- snapshot API/Class: absent.

Therefore a VolumeSnapshot is not a supported recovery control. The recovery
base provides a distinct 50 Gi transfer PVC and a distinct empty 20 Gi restore
target, but same-node hostpath remains a transfer mechanism only. A backup is
accepted only after it is exported off the source node/PVC and that copy
verifies.

The detailed backup format and application-level invariants live in Studio’s
`packages/artifact-registry` source and README. Existing service and PVC names
retain their historical Backoffice prefix; they are shared platform resources.

## Source boundary

`k8s/platform/artifact-registry-recovery/` is deliberately absent from every
production overlay. Its Jobs are suspended, deny all ingress/egress, do not
mount service-account tokens, contain a literal deployed-image placeholder,
and contain a literal reviewed-backup-id placeholder. Applying the base as-is
does not execute either Job and is not an activation procedure.

Production credentials are not needed by recovery Jobs. Backup mounts the
canonical source read-only and the transfer target read-write. Restore mounts
the transfer source read-only and a separate empty replacement target
read-write.

## Preflight

Before any Kubernetes write, record fresh identity and authority:

```bash
kubectl --context infuseai-k8s config current-context
kubectl --context infuseai-k8s auth whoami -o json
kubectl --context infuseai-k8s auth can-i create jobs.batch -n core
kubectl --context infuseai-k8s auth can-i create persistentvolumeclaims -n core
kubectl --context infuseai-k8s auth can-i patch deployments.apps -n core
```

Stop if the live identity differs from the canonical operator identity or any
required permission is denied. Runtime activation, PVC creation, scaling, and
Job execution remain explicit reviewed gates.

Render and validate without persistence:

```bash
task verify-artifact-registry-runtime
KUBE_CONTEXT=infuseai-k8s task verify-artifact-registry-server-dry-run
```

The second command submits prefixed copies to server-side dry-run in `oleagut`;
it does not create PVCs or Jobs.

## Materialize one reviewed operation

Do not edit or apply the reusable base. Create a short-lived execution overlay
on a branch that:

1. selects exactly one of the backup or restore Job templates;
2. replaces `REPLACE_WITH_REVIEWED_BACKUP_ID` with a unique lowercase
   identifier containing the UTC timestamp and source revision;
3. replaces `REPLACE_WITH_DEPLOYED_REGISTRY_IMAGE` with the exact digest-pinned
   image read from the current Registry Deployment, never an old Backoffice image;
4. changes `spec.suspend` to `false` only after the relevant preconditions;
5. uses the reviewed PVC names and no other mounts;
6. has an exact rendered diff, source review, server dry-run, and rollback
   record before apply.

Never materialize both Jobs as runnable in the same overlay. Never add network
egress, credentials, a shell wrapper, or a public route.

## Backup execution

The reviewed operator automates the bounded Job/PVC/export sequence without
placing artifact bodies or credential values in logs:

```bash
python3 scripts/artifact-registry-backup.py \
  --approved \
  --off-node-target nas-rpi:/mnt/wds2/infuse-ai-backups/artifact-registry
```

Add `--prove-restore --cleanup-proof-resources` for an isolated restore drill.
The operator uses that same deployed image for create, verify, isolated restore,
export and import helpers. It rejects a mutable tag before quiescing the Registry.
Templates alone are intentionally not runnable; their placeholder cannot select a
retired application image. This source change does not schedule or execute backup
or restore, remove historical failed Jobs, or certify existing backup contents.

The target operating cadence is one off-node backup daily and one isolated
restore proof weekly. Automatic retention is intentionally absent.

Before scheduling, apply the reviewed recovery deny-all NetworkPolicy and its
exact-name read-only Role/RoleBinding through a separately approved elevated
deployment. The normal operator verifies the live policy spec against source
before quiescing and has no NetworkPolicy write authority.

1. Keep Backoffice and every producer in canonical `registry` mode. The
   quiesced backup creates a brief planned Registry outage; clients fail closed
   and never fall back to the retired feed.
2. Record the exact registry image, Deployment revision, source PVC, used
   bytes, free bytes, and reconciliation digest.
3. Require transfer-target free space greater than twice the source used bytes.
   Treat 70% source utilization as warning and 85% as an activation block.
4. Scale the registry Deployment to zero and confirm no running pod mounts the
   source PVC. Do not quiesce by deleting the PVC or Secret.
5. Apply only the reviewed backup execution overlay. Wait for the Job to reach
   `Complete`; collect the bounded receipt and safe resource/log evidence.
6. Run a second verify operation against the transfer bundle.
7. Export the complete bundle off the source node/PVC to the approved healthy
   `/mnt/wds2` path on `nas-rpi`. Require a checksum-clean second rsync pass
   before calling the backup accepted.
8. Delete only the completed Job after evidence capture. Transfer PVC and
   backup deletion are separate reviewed actions; there is no automatic
   retention.
9. Restore the prior Registry replica count and require Deployment readiness.
   A failed backup remains rejected even when service restoration succeeds.

If the source reconciliation, Job, verification, off-node export, or capacity
gate fails, preserve both source and transfer state for diagnosis. The operator
attempts to restore the prior Registry replica count automatically and emits a
critical manual-recovery error if that bounded recovery also fails.

## Restore execution

1. Keep the affected registry scaled to zero. Backoffice and publishers remain
   configured for `registry` and fail closed during the drill; do not mint or
   change credentials.
2. Select a verified off-node backup and record whether it predates any
   approved purge. Restoring purged content to canonical service requires
   explicit recovery authorization.
3. Provision a new empty replacement PVC. Never restore over the affected
   source PVC.
4. Transfer the verified bundle onto the recovery transfer PVC and verify it
   again before the restore Job is unsuspended.
5. Apply only the reviewed restore execution overlay. Wait for `Complete` and
   require the restored root and reconciliation digests to equal the backup
   receipt.
6. Point one disabled registry canary at the replacement PVC. Prove liveness,
   readiness, auth denials, exact current/history/file reads, bin/tombstones,
   NetworkPolicy, and absence of a public route.
7. Compare the recovered state to accepted parity evidence. Do not silently
   promote a stale feed after registry-only publication has begun.
8. Resume writes sequentially only after a reviewed recovery acceptance gate.
   Retain the affected PVC and recovery evidence until closeout.

An interrupted or partial restore is never merged with canonical state.
Discard the replacement PVC only with explicit deletion approval, provision a
new empty target, and repeat from a verified backup.

## Outage, corruption, rotation, and disable

| Condition | Safe state | Next decision |
| --- | --- | --- |
| Registry unavailable | Registry clients fail closed; no feed fallback | Repair runtime or restore verified replacement |
| Reconciliation degraded | Workload quiesced; source PVC preserved | Forward-fix under review or restore last healthy backup |
| Source PVC lost | Registry disabled | Restore off-node verified bundle to new PVC |
| Backup mismatch | Bundle quarantined | Verify another independent copy; never rewrite manifest |
| Restore mismatch | Replacement offline | Retry on a new empty target |
| Capacity at least 70% | Warning and growth review | Expand or replace before 85% |
| Capacity at least 85% | Activation/cutover blocked | Provision reviewed capacity |

Create a fresh verified backup before registry version changes, import/cutover,
lifecycle cutover, storage changes, and approved destructive operations.
Rotation is manual: verify the replacement and preserve required purge/audit
evidence before any older bundle is deleted.

The disable path scales/stops the Registry while preserving Registry-only
client configuration. It does not reactivate the retired feed and does not
delete PVCs, Secrets, backups, or Jobs with needed evidence.

## Credential rotation

The legacy whole-auth `bootstrap`, `cutover`, `rotate` and `finalize` commands
currently refuse to proceed when independently activated Studio lifecycle
clients are present. Production has those project-scoped clients. Do not remove
them or bypass the preflight to use the procedure below: prepare a reviewed
preservation plan for every configured principal before authorizing rotation.
The fixed eight-principal count from the original Backoffice cutover is obsolete.

Rotate every producer, reader, and lifecycle credential at least every 90 days
and immediately after suspected exposure, staff/access change, or scope drift.
Rotate exactly one principal at a time:

```bash
python3 scripts/provision_artifact_registry_credentials.py rotate \
  --approved \
  --principal agent-infra
```

`rotate` first adds a second equivalent digest to server authorization, then
waits for that Secret projection to reach the live Registry pod before it
updates the exact Vaultwarden item and client Secret. The old digest remains
accepted during the verification window. For Kubernetes producers, restart
only the named Deployment because its token uses a `subPath` mount. Kapiteky's
next short-lived publisher pod reads the new Secret directly. Backoffice token
files are projected directory mounts and its clients read them per request.

Prove the rotated principal through its real mounted token path. Then remove
the overlap by reconciling all current Vaultwarden values:

```bash
python3 scripts/provision_artifact_registry_credentials.py finalize --approved
```

Do not start the next rotation until the prior client is verified and
`finalize` has returned the server to the complete reviewed principal set. A
failed rotation restores the prior Vaultwarden/Kubernetes values when safe;
otherwise the overlap remains active and must be diagnosed before proceeding.
`finalize` also waits for the expected server auth projection, so
normal rotation does not require a Registry restart.

## Evidence and cleanup

Record exact source and image revisions, live identity, scoped authorization,
PVC/storage/capacity, zero-writer proof, reconciliation and root digests, Job
identity/result, off-node verify result, health/denial/parity checks, restored
runtime revision, rollback state, and cleanup.

Do not include auth values, artifact bodies, raw backup manifests, or
unnecessary artifact/file names in logs, PR comments, or chat evidence.
