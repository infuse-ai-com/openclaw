---
title: Skill Management
description: Persistent agents should receive a narrow, role-shaped skill set
  instead of the full Kapiteky/OpenClaw context.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
  - management
---
# Skill Management

Persistent agents should receive a narrow, role-shaped skill set instead of the full Kapiteky/OpenClaw context.

The goal is to make each agent a specialist, reduce junk context, and make access reviewable before runtime activation.

## Sources

Use reviewed source classes:

- `openclaw-core`: OpenClaw-bundled runtime-native skills. They are discovered
  from the pinned runtime and are never copied into an agent workspace.
- `openclaw-plugin-skills`: plugin-provided runtime-native skills. Their plugin
  must be enabled and their resolved source must remain `openclaw-extra`, the
  runtime label OpenClaw uses for plugin skill directories loaded outside core.
- `openclaw-workspace`: Kapiteky workspace skills. Many are powerful and should be restricted.
- `infuse-ai-agent-skills`: reusable Infuse AI company/work skills. This should become the preferred source for specialist company agents.
- `personal-skills`: Fito/Kapiteky personal skills. Default deny for company agents.

The enforced source registry lives in:

```text
config/skill-catalog.json
```

Every source declares one materialization mode:

- `managed-copy`: the installer copies the reviewed skill into the agent's
  workspace and records file hashes;
- `runtime-native`: OpenClaw owns discovery and execution. The bundle grants the
  skill, but the installer must not create a workspace copy.

This is runtime catalog schema v2; validation rejects older catalogs that do
not make ownership explicit.

Runtime-native catalog entries declare the expected OpenClaw source
(`openclaw-bundled` or `openclaw-extra`). Runtime verification rejects
workspace shadows and source-precedence drift.

Git-backed sources can declare a sync policy. `infuse-ai-agent-skills` is pinned
to one reviewed commit on `origin/main`; runtime installs fetch the branch,
verify that the pin is its ancestor, and detach the local source clone at that
exact commit before copying skills. A dirty clone or a pin outside the reviewed
branch fails closed rather than hiding drift or silently adopting a later
source revision.

Sources with `catalog_path` also declare their machine-readable source catalog.
They pin `catalog_version` and name the source-owned `contract_fields` that the
runtime catalog must mirror. For `infuse-ai-agent-skills`, that contract covers
portfolio display names, classes, domains, lifecycle stages, owners,
dependencies, runtime requirements, review risk, and declared provenance in
addition to status and default exposure. When that checkout is available,
bundle verification requires exact skill IDs and exact contract fields between
the source and runtime catalogs. Set
`CHECK_SKILL_SOURCE_CATALOGS=true` to make a missing source checkout fail rather
than skip this cross-repository check.

The runtime image also contains the reviewed catalog, per-agent bundles, and a
startup sync helper. When `OPENCLAW_AUTO_SYNC_SKILLS=true`, the entrypoint
refreshes Git-backed company skills from `agent-skills` into the agent PVC
before starting OpenClaw. Startup sync is intentionally scoped to
`infuse-ai-agent-skills` by default. Runtime-native skills remain owned by the
pinned OpenClaw runtime or enabled plugin; other managed-copy sources require a
full reviewed install path.

Skill-local executable helpers remain owned by their source skill. Runtime
images may provide stable launchers and environment wiring, but must resolve the
installed helper instead of maintaining a second implementation. The Document
Normalizer client follows this pattern: `agent-skills` owns the Python client,
while this repo owns the `openclaw-document-normalizer` launcher, skill sync,
service URL, and credential injection.

When `OPENCLAW_SHARED_MEMORY_SYNC=true`, the entrypoint also clones or
fast-forwards `openclaw-agents-memory` into
`OPENCLAW_SHARED_MEMORY_PATH` (default `/workspace/openclaw-agents-memory`).
By default `OPENCLAW_SHARED_MEMORY_SPARSE_CHECKOUT=true` scopes that checkout
to repo docs/scripts, `shared/`, `projects/`, the current agent's own
`agents/<agent-id>/` tree, and cross-agent `agents/*/summaries/` handoff notes.
Other agents' raw `MEMORY.md` and `memory/` daily notes are not present in the
default runtime checkout. Agents use the `shared-agent-memory` skill to search
that checkout; they should treat it as read-only unless a task explicitly grants
memory-write scope.

When `OPENCLAW_PERSONA_SYNC=true`, the entrypoint clones or fast-forwards
`openclaw-agents-persona` into `OPENCLAW_PERSONA_SOURCE_PATH` (default
`/workspace/openclaw-agents-persona`). Runtime install prefers
`agents/<agent-id>/` from that checkout when present, and falls back to
`templates/agent-persona` from that same external checkout only for new or
not-yet-materialized agents. This repo does not ship image-bundled persona
templates; if sync fails and no existing external checkout is available,
persona install cannot refresh. This keeps persona behavior independent from
skill implementation and lets persona refreshes avoid full image rebuilds when
the runtime image already contains the sync helper.

## Agent Bundles

Each persistent agent gets one bundle:

```text
config/agent-skill-bundles/<agent-id>.json
```

The bundle defines:

- allowed source repos/classes;
- one binary `skills.installed` list;
- default context inputs and posting policy;
- credential access metadata for exact Vaultwarden items and runtime sync targets.

There is no optional or denied skill state. A skill is installed or absent. A
task that needs an absent skill requires a reviewed bundle change and runtime
refresh; chat scope or persona text alone cannot install it.

All persistent InfuseAI swarm agents share a small operating substrate:
`gitlab`, `text-diagramming`, `knowledge-retrieval`,
`mattermost-channel-management`, `mission-control-publishing`,
`shared-agent-memory`, `source-synthesis`, `tech-org`,
`vaultwarden-credential-management`, `verify-this`, and `workspace-context`.
These skills make project orientation, evidence, artifacts, channels, repos,
and credential references legible across roles. They do not grant raw secret
visibility or autonomous external effects; credential and repo-access sections
still decide what an agent may actually access or change.

Agents that participate in the certification program should also receive
`agent-certification-validation` from `infuse-ai-agent-skills`. The skill lets an
agent inspect certificate records, identify missing evidence, and report status
or recertification needs. It does not allow the agent to issue or approve its
own certificate.

The `agent-compatibility-audit` skill is a role-scoped harness/readiness
workflow installed for the coordinator and implementation engineer. Other roles
route a harness-readiness audit to Emon or Tinus instead of receiving it.

Use `gitlab` for attributable forge operations and `runtime-operations` for
live evidence. `ci-cd-assurance-audit`, `trivy-assurance` and
`kubernetes-resource-rightsizing` specialize the assigned assurance task.
`operational-assurance` owns one admitted recurring run; it does not create
schedules or authorize remediation. Source catalog availability is distinct
from the installed role bundle.

For example, `agent-designer` receives the shared substrate plus
`infuse-product-design`, `playwright-browser-evidence`, and selected design
support skills. Discovery, specification, general implementation delivery,
consulting, infrastructure delivery, personal operations, and `webs-hustle`
remain absent from that role.

## Policy

The reviewed bundle decides installation. Persona text describes when an
installed skill fits the role; task scope does not create a third grant state.

Default bundle rules:

- Installed skills must be active in the catalog and come from declared sources.
- Every installed skill's declared dependencies must also be installed.
- Skills that do not fit the persistent role remain absent.
- Personal skills remain absent unless the agent's role is personal operations by design.
- Secret, infrastructure, and external-communication skills require explicit approval before persistent access.
- Credential access defaults to deny. Approved credentials must be item-level references with runtime-only delivery unless a separate review allows direct visibility.

Runtime agents should see skill names/descriptions first and read full `SKILL.md` only when the current task matches the skill. This keeps default context small.

## Verification

Run:

```bash
task verify-agent-skills
```

This validates the catalog and all bundle references. It also compares any
available declared source catalogs; CI remains source-checkout independent.

To also verify source paths on a fully provisioned Kapiteky machine:

```bash
CHECK_SKILL_PATHS=true task verify-agent-skills
```

To require source-catalog alignment and fail when the source checkout is
unavailable:

```bash
CHECK_SKILL_SOURCE_CATALOGS=true task verify-agent-skills
```

Dry-run the actual runtime skill install for one agent:

```bash
AGENT_ID=agent-designer task verify-agent-skill-install
```

Install the approved binary skill set into the agent workspace:

```bash
AGENT_ID=agent-designer task install-agent-skills
```

Sync the latest approved skills into one live InfuseAI agent PVC:

```bash
AGENT_ID=agent-designer task sync-agent-skills-runtime
```

The live runtime smoke invokes `openclaw skills list --json` through
`openclaw-agent-runtime-skills-verify`. It requires managed-copy skills to
resolve from `openclaw-workspace`, requires installed runtime-native skills to
resolve from their declared native source, and rejects any runtime-native
workspace shadow. The runtime sync helper restores the previous skills
directory if this provenance gate fails.

The installer copies managed-copy skills by default so runtime PVCs do not
depend on host-only symlink targets. `SKILL_INSTALL_MODE=symlink` is available
for local experiments. Runtime-native skills are declared but never copied.
During a full install it removes catalog-known managed-copy skill directories
that are absent from the bundle. During a source-scoped startup sync it performs
the same pruning only for that source, leaving skills managed by other sources
untouched. Every install also removes workspace directories for runtime-native
IDs so load-order precedence cannot silently replace the reviewed native skill.

Every full install writes `skill-bundle-manifest.json` with the bundle, declared
skills, copied managed skills, runtime-native declarations, sync mode, and
source metadata. For Git sources this includes the branch, commit, remote, and
dirty flag, so the runtime state can be traced back to the exact `agent-skills`
commit.
The manifest also records installed file hashes for copied skills. The runtime
drift reporter uses those hashes to identify local PVC edits without printing
skill file contents.

### Artifact publisher canonical adoption

`mission-control-publishing` is installed for every persistent agent. Its
Swarm catalog entry owns the rollout posture separately from the source-owned
skill contract:

- `runtime_adoption.reviewed_source_commit` identifies the reviewed Agent
  Skills contract baseline;
- `reviewed_files_manifest_digest` records the content-free digest shared by
  all five dry-run installation manifests for that publisher revision;
- `delivery_mode` is `registry` after the owner-approved clean-start cutover;
- every persistent agent receives its own producer-bound read/write token file;
- the runtime URL, mode, and token-file path are injected by the reviewed
  producer component; agents must not hardcode or downgrade them;
- every runtime install records the actual source commit and installed file
  hashes in its skill manifest.

Changing the Registry URL, credential target, or publishing mode remains a
reviewed runtime action. Publication never creates a mission, task, assignment,
or wake. The local Mission Control tree is staging/cache only after cutover and
must not be treated as shared authority.

Startup sync uses the same installer with:

```bash
OPENCLAW_AUTO_SYNC_SKILLS=true
SKILL_SOURCE_IDS=infuse-ai-agent-skills
ALLOW_SKILL_SOURCE_CLONE=true
```

The startup wrapper sets `SKILL_SOURCE_CACHE_ROOT` to `/workspace/agents/<agent-id>/skill-sources`, then clones or fast-forwards the company skills source there. The installer treats that environment variable as the source-cache contract; `/workspace` is a swarm runtime convention, not something the Python resolver guesses on its own.

Startup sync updates only the approved skills from that source and writes
`skill-source-sync-manifest.json` so the full bootstrap manifest is not
overwritten. Capability export requires the full and startup-sync manifests to
agree on the declared inventory and every source-managed skill revision/file
manifest; drift fails closed, and the active startup-sync manifest revision is
sealed into the snapshot. Set `OPENCLAW_SKILL_SYNC_REQUIRED=true` only when a
stale skill set should block the pod from starting.

When running the installer directly, provide one of:

- `SKILL_SOURCE_ROOT_<SOURCE_ID>` for a single explicit source checkout.
- `SKILL_SOURCE_CACHE_ROOT` for Git-backed source caches.
- An existing `local_path` or `container_path` from `config/skill-catalog.json`.

## Adding A Skill

1. Add or update the skill in its real source repo.
2. Add an entry in `config/skill-catalog.json`.
3. Declare whether its source is `managed-copy` or `runtime-native`. A
   runtime-native skill must include its expected OpenClaw source and plugin ID
   when applicable.
4. Mark `default_exposure`:
   - `default`: safe for broad use.
   - `role`: safe for specific specialist roles.
   - `restricted`: powerful; requires explicit approval or a narrow role.
   - `denied`: should not be assigned.
5. Add the skill to one or more agent bundles only when it fits the role.
6. Run `task verify-agent-skills`.

## Adding A Specialist Agent

1. Create `docs/agents/<agent-id>.md`.
2. Create `config/agent-skill-bundles/<agent-id>.json`.
3. Add `credential_access` with `default_policy: deny`, exact Vaultwarden item names, and runtime sync targets.
4. Keep the installed list small and role-shaped; leave everything else absent.
5. Require a reviewed bundle change before making an absent skill available.
6. Run `AGENT_ID=<agent-id> task verify-agent-skill-install`.
7. Update `docs/NEW_AGENT_RUNBOOK.md` and `docs/AGENT_IDENTITIES.md` if the agent becomes active.

Do not solve missing expertise by giving the agent every skill. Prefer creating a better specialist skill in `infuse-ai-agent-skills`, then granting only that skill.

## Local Drafts, Drift, And Memory Sync

Local pod edits are draft state, not source of truth. Use the runtime drift
reporter before restarting or refreshing a pod that may have useful local
changes:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec deploy/agent-developer -c agent -- \
  openclaw-agent-local-drift-report --pretty
```

The report includes:

- persona file changes compared with `persona-install-manifest.json`;
- copied skill changes compared with skill manifest file hashes;
- local daily memory files that are missing or different in
  `openclaw-agents-memory`.

Unmanaged local skill directories are never adopted automatically. Startup
sync and the scheduled proposal monitor quarantine them under the agent's
non-discovered `skill-proposals/` tree, alert `ai-lab/agent-skills` with
content-free identity metadata, and wait for a reviewed promote, consolidate,
or retire decision. Only merged source and an explicit bundle grant can make a
proposal active.

The report prints paths, hashes/state, and counts only; it does not print file
contents.

For persona drift, the report also includes `source_kind`, `source_dir`, and
Git source metadata when available. Existing live agents should normally show
`source_kind: "agent"` after startup has installed from
`openclaw-agents-persona/agents/<agent-id>/`.

For own raw daily memory and key profile Markdown, use the protected-branch sync helper:

```bash
kubectl --context infuseai-k8s -n agents-swarm exec deploy/agent-developer -c agent -- \
  openclaw-agent-sync-memory-repo
```

The daily `openclaw-agent-memory-sync` CronJob runs this helper for every
running persistent agent at 04:00 Europe/Madrid. It commits only under the
agent's own `openclaw-agents-memory/agents/<agent-id>/` path, skips empty daily
notes, validates the complete IKF selection, and squash-merges a unique sync
branch through an exact-source GitLab MR. Agents curate local memory before sync;
the sync does not summarize or post Mattermost success messages.

Operational details, dogfood results, cleanup commands, and common failure
points live in `docs/AGENT_DRAFT_SYNC.md`.
