---
title: Agent Monitoring Traffic, Routing, and KB Acceptance
description: Defines privacy-safe traffic attribution, model-attempt evidence,
  and reviewed Knowledge Base dogfood gates for the persistent agent fleet.
type: runbook
status: active
owner: team:agent-platform
tags:
  - observability
  - agent
  - routing
  - knowledge-base
---

# Agent Monitoring Traffic, Routing, and KB Acceptance

## Scope

This runbook owns Iteration 5 of the agent-monitoring truth program. It uses
only public OpenClaw plugin hooks and the standalone behavioral-observability
plugin. It does not require or authorize a custom OpenClaw or Codex rebuild.

## Traffic-source contract

Every curated `infuse.*` span emitted by a newly started turn carries exactly
one bounded `traffic.source` value:

| Value | Required deterministic evidence |
| --- | --- |
| `human` | `trigger=user`, a channel/provider is present, and the public `before_agent_run` hook reports `senderIsOwner=true`. |
| `automation` | The public hook trigger is exactly `cron` or `heartbeat`. |
| `smoke` | No channel or trusted owner is present and the controlled session-key suffix is exactly `smoke-<bounded-id>`. |
| `startup` | No channel or trusted owner is present and the controlled session-key suffix is exactly `startup-<bounded-id>`. |
| `unavailable` | The evidence does not prove one of the preceding classes. |

Run, session, sender, channel, message, and task identifiers are in-memory
correlation inputs only. They are never exported as span attributes or metric
labels. Bot-originated channel traffic is not classified as human.

Some public hooks expose the controlled session key only when the first model
attempt starts. An `unavailable` source may therefore be upgraded once to
`smoke`, `startup`, or `automation`, and the still-open turn root is updated
before export. A trusted `human` or `automation` classification is never
overridden by later evidence.

The pinned Codex dynamic-tool adapter does not consistently relay tool
completion into `after_tool_call`. Plugin-owned semantic marker tools therefore
emit from their public per-turn tool-factory context and use the same bounded
tool-call deduplicator as the hook path. This closes the semantic signal gap
without reading the transcript or rebuilding OpenClaw/Codex.

The factory context may identify the same turn by either its canonical session
key or its ephemeral session UUID. Both identifiers are bounded in-memory
correlation keys only; neither is exported. This fallback is required so
plugin-owned semantic spans inherit the already classified turn source even
when one public adapter surface omits the canonical key.

Because a semantic marker may execute before a later model hook supplies the
same controlled session evidence, the emission boundary re-evaluates only the
bounded public context and upgrades an open turn from `unavailable` before the
child is created. This cannot override an already trusted `human`,
`automation`, `smoke`, or `startup` value.

Exactly one behavioral-observability plugin instance may be discovered at
runtime. The managed plugin installer removes only abandoned
`.openclaw-install-stage-<alphanumeric>` directories beneath the active
profile's `extensions` directory before discovery. Runtime inspection and the
fleet smoke fail if OpenClaw reports a duplicate plugin ID; split plugin
instances do not share in-memory run context and therefore invalidate semantic
trace parenting and traffic attribution.

Runtime image acceptance uses the exact digest-pinned pod image reference and
matching immutable revision annotation. Kubelet `imageID` must be populated,
but is not required to equal the requested multi-platform index digest:
containerd may reuse an equivalent cached platform image and report the first
index digest that introduced that content. Legacy callers that provide no
exact image reference retain strict `imageID` digest matching.

## Model routing contract

`config/agent-model-policies.json` declares one capacity-failure policy for
every agent:

- `single_approved_fallback`: exactly one ordered alternate model is allowed;
- `fail_closed`: no fallback model is configured and the failed turn remains
  failed.

Each public `model_call_started`/`model_call_ended` pair emits one
`infuse.model.call` child. Attempt 1 is `primary`; later attempts are
`fallback`. Errors collapse to the closed categories `capacity`, `rate_limit`,
`timeout`, `connection`, `aborted`, `upstream`, or `unknown`. Raw provider
errors and call identifiers are discarded.

The contract fixtures prove a primary capacity failure followed by a fallback
success without deliberately exhausting or disrupting production capacity.
Live evidence is accepted only when an organic or safe controlled failure
actually occurs; configuration plus synthetic contract evidence must not be
reported as a live provider fallback.

## Knowledge-decision contract

The canonical `knowledge_retrieval` tool automatically emits:

- `decision=invoked` after a completed Discover or Fetch attempt;
- `decision=failed` after a failed attempt.

If the public dynamic-tool boundary fails but the canonical
`knowledge-retrieval` wrapper subsequently completes, its first terminal
result emits `evidence_method=wrapper_outcome`. This preserves both facts: the
failed tool attempt and the final wrapper-backed `invoked` or `failed`
decision. Duplicate wrapper operations in the same turn do not duplicate the
decision.

The bounded `knowledge_decision` marker may emit only `not_needed` or
`considered_unavailable`, and only when the agent explicitly made that
decision. Absence of a marker remains unknown. The marker never accepts a
rationale, query, path, document identity, or task content.

## Acceptance sequence

1. Deploy the collector/plugin change to Tinus first and verify readiness,
   restart count, one duplicate-free plugin load, tool list, channel health,
   and privacy.
2. Run a channel-free session named `smoke-routing-<id>` and prove every
   curated child uses `traffic.source=smoke`.
3. Run a reviewed read-only company-knowledge task through
   `knowledge_retrieval`: Discover, choose a returned candidate, Fetch its
   immutable reference, and report only bounded acceptance metadata.
4. Prove authenticated Knowledge Base attribution to the intended ServiceAccount
   and zero prompt, response, excerpt, Markdown, reference, sender, session, or
   run identifiers in exported telemetry.
5. Roll out Satwa, Stewie, Emon, and Ramiro in that order only after the Tinus
   gates pass.
6. Ask Fito to send one ordinary routed message to each agent. For each turn,
   verify message receipt, one parentless curated turn, model attempt, terminal
   run outcome, delivery, and `traffic.source=human` in the dedicated Langfuse
   project.

Selected KB dogfood tasks must genuinely require authoritative company
knowledge. Suitable examples include the current deployment-verification
procedure for engineering/operations and the current ownership or consulting
handoff policy for coordination/intake. Do not ask an agent to retrieve KB
content merely to manufacture telemetry.

## Rollback

Rollback only the behavioral plugin image/config, collector dimension, or
dashboard/rule affected by the failed gate. A collector, Langfuse, Prometheus,
or Knowledge Base telemetry outage must never change the agent's task result.
