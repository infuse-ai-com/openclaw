---
title: Hauscraft floor connection repair
description: Dated evidence for the October 20 Studio floor connection repair.
type: guide
status: active
owner: team:agent-platform
tags:
  - guide
---
# Hauscraft floor connection repair — 2026-10-20

The coordinator's Studio plugin was unable to finish startup after new floors
were connected. The configured coordinator membership in the existing Studio
channel was restored first. Dynamic floor discovery then exceeded the host's
five-second plugin startup deadline.

Studio PR 4048 defers dynamic discovery to the regular first tick. Configured
required-owner routes remain protected during startup; new floors stay pending
until every required identity and route-protection receipt is confirmed. The
change neither creates missions nor falls back to ordinary chat.

This runtime pins the complete package from Studio main commit
`0033218a7bb85e7fc892bf656634cb14ecf345e6`, release build `10038`.
The producer image and all 51 package-file hashes are recorded in
`config/qualification/studio-tool-inventory-2026.10.3.json`. Package dependencies,
plugin capabilities, and the exact OpenClaw 2026.10.3 host pin are unchanged.
The package includes the current shared Studio assets; outbound agents retain
no mission-writer authority.

Verification before rollout:

- Studio required PR build 10032 passed; main build 10038 deployed successfully.
- The extracted producer package passed `verify-studio-plugin-package.py`.
- Nine focused Studio pin/native profile tests passed locally.
- Local full verification on macOS encountered three unchanged baseline failures:
  Kubernetes client validation, `/tmp` symlink rejection in the bot fixture, and
  browser cache stale-link cleanup. Required Linux PR verification remains the
  deployment gate; these failures do not justify bypassing it.

After the normal main pipeline's guarded rollout, verify the coordinator's
`infuse-studio` runtime is active and Hauscraft's Setup status shows Team
connection ready. A healthy Gateway alone does not establish floor readiness.
