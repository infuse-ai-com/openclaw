#!/usr/bin/env python3
"""Classify whether changed paths require persistent-agent pod replacement."""

from __future__ import annotations

import json
import sys


PERSISTENT_AGENTS = (
    "agent-developer",
    "agent-designer",
    "agent-infra",
    "agent-intake",
    "agent-coordinator",
)

NON_RUNTIME_PREFIXES = ("docs/", "tests/")
NON_RUNTIME_FILES = {"AGENTS.md", ".gitignore"}
ARTIFACT_PLATFORM_PREFIXES = ("k8s/platform/artifact-image-scanner/", "k8s/platform/artifact-registry-release/")
ARTIFACT_PLATFORM_FILES = {
    "k8s/platform/artifact-registry/deployment.yaml",
    "k8s/platform/artifact-registry/kustomization.yaml",
    "k8s/platform/artifact-registry/images-configmap.yaml",
    "scripts/verify-artifact-registry-runtime.sh",
    "config/artifact-registry-runtime.v1.json",
    "k8s/platform/artifact-registry/networkpolicy.yaml",
    "k8s/platform/artifact-registry/README.md",
    "scripts/provision_artifact_registry_credentials.py",
}
OBSERVABILITY_CONTROL_PLANE_FILES = {
    "k8s/overlays/infuseai/otel-collector.yaml",
    "scripts/audit-agent-observability-live.py",
    "scripts/sync_agent_observability_secret.py",
}


def is_non_runtime(path: str) -> bool:
    return path in NON_RUNTIME_FILES or path.startswith(NON_RUNTIME_PREFIXES)


def is_platform_only(path: str) -> bool:
    return (
        path in ARTIFACT_PLATFORM_FILES
        or path in OBSERVABILITY_CONTROL_PLANE_FILES
        or path.startswith(ARTIFACT_PLATFORM_PREFIXES)
    )


def classify(paths: list[str]) -> dict[str, object]:
    changed_paths = sorted({path.strip() for path in paths if path.strip()})
    if not changed_paths:
        return {
            "scope": "full",
            "preserveDeployments": [],
            "reason": "changed_paths_unavailable",
            "changedPaths": [],
        }

    runtime_paths = [path for path in changed_paths if not is_non_runtime(path)]
    if all(is_platform_only(path) for path in runtime_paths):
        return {
            "scope": "platform",
            "preserveDeployments": list(PERSISTENT_AGENTS),
            "reason": "no_persistent_agent_runtime_change",
            "changedPaths": changed_paths,
        }

    return {
        "scope": "full",
        "preserveDeployments": [],
        "reason": "persistent_agent_runtime_change",
        "changedPaths": changed_paths,
    }


def main() -> int:
    print(json.dumps(classify(sys.stdin.read().splitlines()), separators=(",", ":"), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
