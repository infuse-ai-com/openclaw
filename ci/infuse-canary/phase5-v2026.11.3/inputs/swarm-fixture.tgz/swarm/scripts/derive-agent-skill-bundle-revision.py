#!/usr/bin/env python3
"""Derive a stable, content-addressed revision from a runtime skill manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, NoReturn


def fail(message: str) -> NoReturn:
    raise SystemExit(message)


def load_manifest(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"skill manifest not found: {path}")
    except json.JSONDecodeError as exc:
        fail(f"skill manifest is invalid JSON: {path}: {exc}")
    if not isinstance(value, dict):
        fail("skill manifest must be a JSON object")
    return value


def stable_file(file_entry: Any) -> dict[str, Any]:
    if not isinstance(file_entry, dict) or not isinstance(file_entry.get("path"), str):
        fail("each skill file entry must contain a path")
    stable = {"path": file_entry["path"]}
    for key in ("sha256", "bytes", "kind", "target"):
        if key in file_entry:
            stable[key] = file_entry[key]
    if "sha256" not in stable and stable.get("kind") != "symlink":
        fail(f"skill file entry has no sha256: {file_entry['path']}")
    return stable


def stable_skill(skill: Any) -> dict[str, Any]:
    if not isinstance(skill, dict) or not isinstance(skill.get("id"), str):
        fail("each skill entry must contain an id")
    files = skill.get("files")
    if not isinstance(files, list):
        fail(f"skill entry has no file manifest: {skill['id']}")
    return {
        "id": skill["id"],
        "source": skill.get("source"),
        "source_commit": skill.get("source_commit"),
        "files": sorted((stable_file(entry) for entry in files), key=lambda item: item["path"]),
    }


def stable_source(source_id: str, source: Any) -> dict[str, Any]:
    if not isinstance(source, dict):
        fail(f"source entry must be an object: {source_id}")
    return {
        "id": source_id,
        "repo": source.get("repo"),
        "kind": source.get("kind"),
        "branch": source.get("branch"),
        "commit": source.get("commit"),
        "dirty": source.get("dirty"),
    }


def canonical_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    agent_id = manifest.get("agent_id")
    if not isinstance(agent_id, str) or not agent_id:
        fail("skill manifest has no agent_id")
    skills = manifest.get("skills")
    sources = manifest.get("sources")
    runtime_native = manifest.get("runtime_native_skills", [])
    declared = manifest.get("declared_skills")
    if not isinstance(skills, list) or not isinstance(sources, dict):
        fail("skill manifest must contain skills and sources")
    if not isinstance(runtime_native, list) or not isinstance(declared, list):
        fail("skill manifest must contain declared and runtime-native skill lists")
    return {
        "schema": 1,
        "agent_id": agent_id,
        "source_sync": manifest.get("source_sync"),
        "declared_skills": sorted(declared),
        "sources": [stable_source(key, sources[key]) for key in sorted(sources)],
        "skills": sorted((stable_skill(skill) for skill in skills), key=lambda item: item["id"]),
        "runtime_native_skills": sorted(runtime_native, key=lambda item: json.dumps(item, sort_keys=True)),
    }


def revision(manifest: dict[str, Any]) -> str:
    payload = json.dumps(
        canonical_manifest(manifest),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    print(revision(load_manifest(args.manifest)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
