#!/usr/bin/env python3
"""Render one agent's curated MEMORY.md with deterministic IKF metadata."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import tempfile


AGENT_ID_PATTERN = re.compile(r"^agent-[a-z0-9]+(?:-[a-z0-9]+)*$")


def body_without_frontmatter(source: str) -> str:
    if not source.startswith("---\n"):
        return source
    lines = source.splitlines()
    try:
        closing = lines.index("---", 1)
    except ValueError as exc:
        raise SystemExit("source MEMORY.md has unterminated YAML frontmatter") from exc
    return "\n".join(lines[closing + 1 :]).lstrip("\n")


def render(agent_id: str, source: str) -> str:
    if not AGENT_ID_PATTERN.fullmatch(agent_id):
        raise SystemExit(f"invalid AGENT_ID for memory rendering: {agent_id}")
    body = body_without_frontmatter(source)
    if not body.strip():
        raise SystemExit("source MEMORY.md has no body content")
    role_name = " ".join(part.capitalize() for part in agent_id.split("-"))
    return (
        "---\n"
        f"title: {role_name} Memory\n"
        f"description: Curated durable memory for the {agent_id} OpenClaw role.\n"
        "type: memory\n"
        "status: active\n"
        "owner: team:agent-platform\n"
        "tags:\n"
        "  - agent-memory\n"
        f"  - {agent_id}\n"
        "---\n\n"
        f"{body.rstrip()}\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--agent-id", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--destination", required=True)
    args = parser.parse_args()

    source_path = Path(args.source)
    destination_path = Path(args.destination)
    content = render(args.agent_id, source_path.read_text(encoding="utf-8"))
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=destination_path.parent,
        delete=False,
    ) as handle:
        handle.write(content)
        temporary_path = Path(handle.name)
    os.chmod(temporary_path, 0o600)
    temporary_path.replace(destination_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
