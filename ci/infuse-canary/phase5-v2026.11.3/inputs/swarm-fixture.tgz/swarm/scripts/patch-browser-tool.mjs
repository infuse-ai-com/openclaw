import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const [packageRoot] = process.argv.slice(2);
if (!packageRoot) throw Error('Expected the installed OpenClaw package directory');

async function readChunk(name, sha256) {
  const path = join(packageRoot, 'dist', name);
  const source = await readFile(path, 'utf8');
  if (createHash('sha256').update(source).digest('hex') !== sha256) {
    throw Error('OpenClaw Browser chunk differs from the qualified version: ' + name);
  }
  return { path, source };
}

function replaceOnce(source, before, after) {
  if (source.split(before).length !== 2) throw Error('OpenClaw Browser source contract changed');
  return source.replace(before, after);
}

// This overlay is specific to the pinned OpenClaw 2026.11.3 artifact.
// chat-browser uses native session access for both the viewer and the agent.
const tool = await readChunk('browser-request-DWazsXT0.mjs',
  '11887128e97f7700fbae308c6f4d26b82388805269cb7d03201100dbb2bab846');
const registration = await readChunk('plugin-registration-Btt7c_hU.mjs',
  '78a0fca09f098490ca166f9ad73974781061995f056cdd2f152d3319343520ea');

const scoped = replaceOnce(tool.source,
  'const sessionScoped = operatorScopes !== void 0 && !operatorScopes.includes("operator.admin");',
  'const sessionScoped = dashboardName === "chat-browser" || operatorScopes !== void 0 && !operatorScopes.includes("operator.admin");');
const routedTool = replaceOnce(scoped,
  'const dashboardScopes = sessionScoped ? operatorScopes.includes("operator.write")',
  'const dashboardScopes = sessionScoped && !operatorScopes?.includes("operator.admin") ? operatorScopes?.includes("operator.write")');
// Advertise readiness for mixed-version rollouts. The dashboard uses only the
// presence of this method. It never forwards calls to it.
const anchor = '\tfor (const { path, client, loadUpgrade }';
const registered = replaceOnce(registration.source, anchor,
  '\tapi.registerGatewayMethod("browser.session.panel.ready", ({ respond }) => respond(true, {}), { scope: "operator.admin" });\n' + anchor);

await writeFile(tool.path, routedTool);
await writeFile(registration.path, registered);
