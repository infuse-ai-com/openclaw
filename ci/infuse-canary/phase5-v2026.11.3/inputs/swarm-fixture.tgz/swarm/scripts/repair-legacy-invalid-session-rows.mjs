#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

const agentId = process.argv[2]?.trim();
if (!agentId || !/^[a-z0-9][a-z0-9-]*$/u.test(agentId)) {
  throw new Error("Usage: repair-legacy-invalid-session-rows.mjs <agent-id>");
}

const stateDir = process.env.OPENCLAW_STATE_DIR?.trim();
if (!stateDir || !path.isAbsolute(stateDir)) {
  throw new Error("OPENCLAW_STATE_DIR must be an absolute path");
}

const databasePath = path.join(stateDir, "agents", agentId, "agent", "openclaw-agent.sqlite");
if (!fs.existsSync(databasePath)) {
  console.log(JSON.stringify({ agentId, databasePath, repairedRows: 0, status: "missing" }));
  process.exit(0);
}

const database = new DatabaseSync(databasePath);
database.exec("PRAGMA foreign_keys = ON");
database.exec("PRAGMA wal_checkpoint(TRUNCATE)");

const invalidRows = database
  .prepare(
    `SELECT session_key, current_session_id, entry_json, updated_at, entry_valid
       FROM session_nodes
      WHERE entry_valid = -1
      ORDER BY session_key`,
  )
  .all();

if (invalidRows.length === 0) {
  console.log(JSON.stringify({ agentId, databasePath, repairedRows: 0, status: "clean" }));
  process.exit(0);
}

const retainedWindow = database.prepare(
  `SELECT 1
     FROM session_windows
    WHERE session_id = ? AND session_key = ?
    LIMIT 1`,
);
const repairableRows = [];
let retainedTombstones = 0;
for (const row of invalidRows) {
  if (
    row.entry_json !== "{}" ||
    typeof row.session_key !== "string" ||
    !row.session_key.startsWith(`agent:${agentId}:`) ||
    typeof row.current_session_id !== "string" ||
    row.current_session_id.length === 0 ||
    typeof row.updated_at !== "number" ||
    !Number.isFinite(row.updated_at)
  ) {
    throw new Error(`refusing unsupported invalid session row: ${String(row.session_key)}`);
  }
  if (retainedWindow.get(row.current_session_id, row.session_key)) {
    retainedTombstones += 1;
    continue;
  }
  repairableRows.push(row);
}

if (repairableRows.length === 0) {
  console.log(
    JSON.stringify({
      agentId,
      databasePath,
      repairedRows: 0,
      retainedTombstones,
      status: "retained-history-only",
    }),
  );
  process.exit(0);
}

const backupPath = `${databasePath}.backup-before-2026.8.1-invalid-row-repair`;
if (!fs.existsSync(backupPath)) {
  fs.copyFileSync(databasePath, backupPath, fs.constants.COPYFILE_EXCL);
  fs.chmodSync(backupPath, 0o600);
}

const update = database.prepare(
  `UPDATE session_nodes
      SET entry_json = ?, entry_valid = 1
    WHERE session_key = ?
      AND current_session_id = ?
      AND entry_json = '{}'
      AND updated_at = ?
      AND entry_valid = -1`,
);

let repairedRows = 0;
database.exec("BEGIN IMMEDIATE");
try {
  for (const row of repairableRows) {
    const entryJson = JSON.stringify({
      sessionId: row.current_session_id,
      updatedAt: row.updated_at,
    });
    const result = update.run(
      entryJson,
      row.session_key,
      row.current_session_id,
      row.updated_at,
    );
    if (result.changes !== 1) {
      throw new Error(`guarded repair changed ${result.changes} rows for ${row.session_key}`);
    }
    repairedRows += result.changes;
  }
  database.exec("COMMIT");
} catch (error) {
  database.exec("ROLLBACK");
  throw error;
}

console.log(
  JSON.stringify({
    agentId,
    backupPath,
    databasePath,
    repairedRows,
    retainedTombstones,
    status: "repaired",
  }),
);
