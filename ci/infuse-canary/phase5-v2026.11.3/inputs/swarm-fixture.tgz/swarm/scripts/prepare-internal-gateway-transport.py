#!/usr/bin/env python3
"""Add explicitly selected internal TLS listeners to a disposable render tree."""
from __future__ import annotations

import json
from pathlib import Path
import re
import sys

AGENTS = frozenset(f"agent-{role}" for role in ("developer", "designer", "coordinator", "intake", "infra"))
CONFIG = re.compile(r"(name: OPENCLAW_CONFIG_JSON\n\s+value: )'([^'\n]+)'")


def validate(contract: dict) -> list[str]:
    if not isinstance(contract, dict) or set(contract) != {"version", "enabledAgents"} or type(contract["version"]) is not int or contract["version"] != 1:
        raise ValueError("expected internal gateway transport version 1 and enabledAgents")
    agents = contract["enabledAgents"]
    if not isinstance(agents, list) or any(not isinstance(agent, str) or agent not in AGENTS for agent in agents):
        raise ValueError("internal gateway transport requires explicit known agent IDs")
    if len(set(agents)) != len(agents):
        raise ValueError("internal gateway transport contains duplicate agents")
    return agents


def resources(agent: str) -> list[dict]:
    name = f"{agent}-dashboard-internal"
    labels = {"app.kubernetes.io/name": agent}
    return [{
        "apiVersion": "v1", "kind": "Service", "metadata": {"name": name},
        "spec": {"type": "ClusterIP", "selector": labels,
                 "ports": [{"name": "https", "port": 443, "targetPort": 8443, "protocol": "TCP"}]},
    }, {
        "apiVersion": "networking.k8s.io/v1", "kind": "NetworkPolicy", "metadata": {"name": name},
        "spec": {"podSelector": {"matchLabels": labels}, "policyTypes": ["Ingress"],
                 "ingress": [{"from": [{
                     "namespaceSelector": {"matchLabels": {"kubernetes.io/metadata.name": "agents-swarm"}},
                     "podSelector": {"matchLabels": {"app.kubernetes.io/name": "openclaw-dashboard"}},
                 }], "ports": [{"protocol": "TCP", "port": 8443}]}]},
    }]


def sidecar(agent: str) -> dict:
    return {
        "name": "gateway-internal-tls", "image": "ghcr.io/infuse-ai/openclaw-agent:dev",
        "imagePullPolicy": "IfNotPresent", "workingDir": "/",
        "command": ["/usr/local/bin/node", "/opt/gateway-internal-tls/tunnel.mjs"],
        "env": [{"name": "GATEWAY_TLS_SERVER_NAME", "value": f"{agent}-dashboard-internal.agents-swarm.svc.cluster.local"}],
        "ports": [{"name": "gateway-tls", "containerPort": 8443, "protocol": "TCP"}],
        "readinessProbe": {"tcpSocket": {"port": "gateway-tls"}, "periodSeconds": 5},
        "livenessProbe": {"tcpSocket": {"port": "gateway-tls"}, "periodSeconds": 20},
        "resources": {"requests": {"cpu": "10m", "memory": "32Mi"}, "limits": {"cpu": "200m", "memory": "128Mi"}},
        "securityContext": {"runAsNonRoot": True, "runAsUser": 10001, "runAsGroup": 10001,
                            "allowPrivilegeEscalation": False, "readOnlyRootFilesystem": True,
                            "capabilities": {"drop": ["ALL"]}},
        "volumeMounts": [
            {"name": "gateway-tls-code", "mountPath": "/opt/gateway-internal-tls", "readOnly": True},
            {"name": "gateway-tls-identity", "mountPath": "/var/run/openclaw-gateway-tls", "readOnly": True},
            # A mount at this path suppresses automatic service-account-token
            # injection into this sidecar without changing the agent's mounts.
            {"name": "gateway-tls-no-api-token", "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount", "readOnly": True},
        ],
    }


def prepare(k8s: Path, contract: dict) -> None:
    agents = validate(contract)
    if not agents:
        return
    overlay = k8s / "overlays/infuseai/kustomization.yaml"
    overlay_source = overlay.read_text()
    if "\nnamespace: agents-swarm\n" not in overlay_source or "\ncomponents:\n" not in overlay_source:
        raise ValueError("internal TLS requires the reviewed agents-swarm namespace and overlay")
    component = "  - ../../components/gateway-internal-tls\n"
    if component in overlay_source:
        raise ValueError("internal TLS preparation must run once on a fresh render tree")

    pending: dict[Path, str] = {}
    for agent in agents:
        path = k8s / "agents" / agent / "deployment.yaml"
        source = path.read_text()
        matches = list(CONFIG.finditer(source))
        if len(matches) != 1 or '"name": "gateway-internal-tls"' in source:
            raise ValueError(f"{agent} has no unambiguous unprepared gateway configuration")
        config = json.loads(matches[0][2])
        gateway = config.get("gateway", {})
        auth = gateway.get("auth", {})
        proxy = auth.get("trustedProxy", {})
        trusted = gateway.get("trustedProxies")
        if (gateway.get("bind") != "lan" or gateway.get("port") != 18791 or
                auth.get("mode") != "trusted-proxy" or not isinstance(trusted, list) or
                trusted != ["10.1.42.208"] or proxy.get("userHeader") != "x-forwarded-user" or
                proxy.get("requiredHeaders") != ["x-forwarded-proto", "x-forwarded-host"] or
                auth.get("password") != {"source": "env", "provider": "default", "id": "OPENCLAW_GATEWAY_PASSWORD"}):
            raise ValueError(f"{agent} does not match the existing reviewed gateway transport boundary")
        # Preserve the full phase2 identity/scope mapping and local Studio password.
        gateway["trustedProxies"] = [*trusted, "127.0.0.1"]
        proxy["allowLoopback"] = True
        source = CONFIG.sub(lambda match: match[1] + "'" + json.dumps(config, separators=(",", ":")) + "'", source)
        additions = [{"op": "add", "path": "/spec/template/spec/containers/-", "value": sidecar(agent)}]
        for volume in [
            {"name": "gateway-tls-code", "configMap": {"name": "openclaw-gateway-tls-tunnel", "defaultMode": 292}},
            {"name": "gateway-tls-identity", "secret": {"secretName": f"{agent}-dashboard-internal-tls", "defaultMode": 288,
                "items": [{"key": key, "path": key} for key in ("tls.crt", "tls.key", "client-ca.crt")]}},
            {"name": "gateway-tls-no-api-token", "emptyDir": {"medium": "Memory", "sizeLimit": "1Mi"}},
        ]:
            additions.append({"op": "add", "path": "/spec/template/spec/volumes/-", "value": volume})
        source += "\n" + "\n".join("- " + json.dumps(patch) for patch in additions) + "\n"
        pending[path] = source
        kustomization = path.with_name("kustomization.yaml")
        manifest = kustomization.read_text()
        if "\nresources:\n" not in manifest:
            raise ValueError(f"{agent} has no expected resources boundary")
        pending[kustomization] = manifest.replace("\nresources:\n", "\nresources:\n  - dashboard-internal.json\n", 1)
        pending[path.with_name("dashboard-internal.json")] = json.dumps({"apiVersion": "v1", "kind": "List", "items": resources(agent)}) + "\n"
    pending[overlay] = overlay_source.replace("\ncomponents:\n", "\ncomponents:\n" + component, 1)
    for path, content in pending.items():
        path.write_text(content)


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: prepare-internal-gateway-transport.py <temporary-k8s-tree> <contract.json>", file=sys.stderr)
        return 2
    try:
        prepare(Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text()))
    except (ValueError, KeyError, OSError) as error:
        print(f"internal gateway TLS preparation failed: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
