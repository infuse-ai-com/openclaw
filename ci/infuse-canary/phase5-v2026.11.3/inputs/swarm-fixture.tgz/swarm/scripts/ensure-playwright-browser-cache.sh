#!/usr/bin/env bash
set -euo pipefail

workspace="${OPENCLAW_WORKSPACE:-/workspace}"
cache_path="${PLAYWRIGHT_BROWSERS_PATH:-$workspace/.cache/ms-playwright}"
seed_path="${OPENCLAW_PLAYWRIGHT_SEED_PATH:-/opt/playwright-browsers}"
mkdir -p "$workspace"

resolve_path() {
  python3 - "$1" <<'PY'
from pathlib import Path
import sys

print(Path(sys.argv[1]).resolve(strict=False))
PY
}

workspace="$(resolve_path "$workspace")"
cache_path="$(resolve_path "$cache_path")"
seed_path="$(resolve_path "$seed_path")"

case "$cache_path" in
  "$workspace"/*) ;;
  *)
    echo "ERROR: Playwright browser cache must be inside the workspace PVC: $cache_path" >&2
    exit 2
    ;;
esac

if [[ ! -d "$seed_path" ]]; then
  echo "ERROR: Playwright browser seed is unavailable: $seed_path" >&2
  exit 1
fi

mkdir -p "$cache_path" "$cache_path/.links"

# Remove only stale links previously managed from the immutable image seed.
# Project-installed browser directories and unrelated links remain untouched.
while IFS= read -r -d '' cache_entry; do
  link_target="$(readlink "$cache_entry")"
  case "$link_target" in
    "$seed_path"/*)
      if [[ ! -e "$link_target" ]]; then
        rm -f "$cache_entry"
      fi
      ;;
  esac
done < <(find "$cache_path" -mindepth 1 -maxdepth 1 -type l -print0)

# Expose image-managed browsers through the writable PVC cache without copying
# their roughly 1 GiB payload. Real project-installed directories win when a
# project already owns the same revision.
while IFS= read -r -d '' seed_entry; do
  cache_entry="$cache_path/${seed_entry##*/}"
  if [[ ! -e "$cache_entry" && ! -L "$cache_entry" ]]; then
    ln -s "$seed_entry" "$cache_entry"
  fi
done < <(find "$seed_path" -mindepth 1 -maxdepth 1 -type d ! -name '.*' -print0)

# Preserve Playwright's image-package registry so its own browser garbage
# collection can distinguish the baked revision from project-installed pins.
if [[ -d "$seed_path/.links" ]]; then
  while IFS= read -r -d '' seed_link; do
    cp "$seed_link" "$cache_path/.links/${seed_link##*/}"
  done < <(find "$seed_path/.links" -mindepth 1 -maxdepth 1 -type f -print0)
fi

chromium_ready=false
for chromium_path in "$cache_path"/chromium-*; do
  if [[ -d "$chromium_path" ]]; then
    chromium_ready=true
    break
  fi
done
if [[ "$chromium_ready" != "true" ]]; then
  echo "ERROR: Playwright Chromium was not linked into the workspace cache" >&2
  exit 1
fi
