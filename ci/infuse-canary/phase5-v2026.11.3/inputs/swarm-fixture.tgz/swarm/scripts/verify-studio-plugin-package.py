#!/usr/bin/env python3
"""Verify the qualified Studio plugin payload without importing its code."""

from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path


def fail(message: str) -> None:
    raise SystemExit(f"studio plugin verification failed: {message}")


def regular_file(root: Path, relative: str) -> Path:
    if not relative or relative.startswith("/") or "\\" in relative:
        fail(f"unsafe path {relative!r}")
    parts = Path(relative).parts
    if any(part in {"", ".", ".."} for part in parts):
        fail(f"unsafe path {relative!r}")
    path = root.joinpath(*parts)
    if not path.is_file() or path.is_symlink():
        fail(f"expected regular file {relative}")
    if path.resolve() != path:
        fail(f"file escaped package root: {relative}")
    return path


def load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"cannot read {path}: {exc}")
    if not isinstance(value, dict):
        fail(f"expected object in {path}")
    return value


def main() -> None:
    if len(sys.argv) != 3:
        fail("usage: verify-studio-plugin-package.py PLUGIN_ROOT PIN_JSON")
    root = Path(sys.argv[1]).resolve(strict=True)
    pin = load_json(Path(sys.argv[2]).resolve(strict=True))
    plugin = pin.get("plugin")
    if not isinstance(plugin, dict) or pin.get("schema") != 1:
        fail("unsupported pin schema")
    if pin.get("hostVersion") != "2026.11.3" or pin.get("hostCommit") != "e7d74d56a583e7596977058e7f73c6dc7c959810":
        fail("pin is not bound to the qualified host")
    sources = plugin.get("sources")
    file_count = plugin.get("fileCount")
    if not isinstance(file_count, int) or not 10 <= file_count <= 1000 or not isinstance(sources, dict) or len(sources) != file_count:
        fail("expected the exact qualified Studio inventory count")

    actual: set[str] = set()
    for directory, names, files in os.walk(root, followlinks=False):
        directory_path = Path(directory)
        for name in names:
            if (directory_path / name).is_symlink():
                fail(f"directory symlink is forbidden: {(directory_path / name).relative_to(root)}")
        for name in files:
            path = directory_path / name
            relative = path.relative_to(root).as_posix()
            if relative.startswith("node_modules/"):
                fail("dependencies must not exist before the qualified payload check")
            if path.is_symlink() or not path.is_file():
                fail(f"non-regular inventory entry: {relative}")
            actual.add(relative)
    expected = set(sources)
    if actual != expected:
        fail(f"inventory mismatch: missing={sorted(expected - actual)!r} extra={sorted(actual - expected)!r}")

    for relative, expected_sha in sorted(sources.items()):
        if not isinstance(expected_sha, str) or len(expected_sha) != 64:
            fail(f"invalid digest for {relative}")
        digest = hashlib.sha256(regular_file(root, relative).read_bytes()).hexdigest()
        if digest != expected_sha:
            fail(f"digest mismatch for {relative}: {digest}")

    package = load_json(regular_file(root, "package.json"))
    if package.get("name") != plugin.get("name") or package.get("version") != plugin.get("version"):
        fail("package identity mismatch")
    if package.get("peerDependencies", {}).get("openclaw") != "2026.9.7 || 2026.10.2 || 2026.10.3 || 2026.11.1 || 2026.11.3":
        fail("unexpected OpenClaw peer range")
    if package.get("dependencies", {}).get("@openclaw/gateway-client") != plugin.get("gatewayClientVersion"):
        fail("unexpected Gateway client version")

    print(json.dumps({"schema": 1, "verifiedFiles": len(actual), "plugin": plugin.get("name"), "version": plugin.get("version")}, sort_keys=True))


if __name__ == "__main__":
    main()
