#!/usr/bin/env python3
"""Export one task-scoped, sanitized agent capability snapshot for preflight."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timedelta, timezone
import os
from pathlib import Path
import re
import subprocess
import sys
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = Path(os.environ.get("OPENCLAW_AGENT_SKILL_CONFIG_ROOT", "/opt/openclaw-agent-skill-config"))
if not CONFIG_ROOT.exists():
    CONFIG_ROOT = ROOT
BUNDLE_DIR = CONFIG_ROOT / "config" / "agent-skill-bundles"
CATALOG_PATH = CONFIG_ROOT / "config" / "backoffice-agent-catalog.v1.json"
SNAPSHOT_SCHEMA = "infuse.agent-capability-snapshot/v2"
HANDOFF_SCHEMA = "infuse.agent-handoff/v2"
ACTIVE_TASK_STATES = {"assigned", "acknowledged", "active", "waiting", "blocked", "delivered", "review"}
APPROVAL_STATES = {"pending", "approved", "rejected", "waived"}
SAFE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$")


class SnapshotError(ValueError):
    """Raised when reviewed capability sources are missing or malformed."""


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def load_json(path: Path, label: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SnapshotError(f"missing {label}: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SnapshotError(f"invalid {label} JSON: {exc}") from exc


def slug(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.casefold()).strip("-")
    return normalized[:160]


def requested_requirements(handoff: dict[str, Any]) -> dict[str, set[str]]:
    if handoff.get("schema") != HANDOFF_SCHEMA or not isinstance(handoff.get("requirements"), list):
        raise SnapshotError(f"handoff must use {HANDOFF_SCHEMA}")
    content_sha256 = handoff.get("content_sha256")
    unsigned = {key: value for key, value in handoff.items() if key != "content_sha256"}
    if not isinstance(content_sha256, str) or content_sha256 != sha256(unsigned):
        raise SnapshotError("handoff content_sha256 does not match canonical content")
    target = handoff.get("target")
    repository = handoff.get("repository")
    if not isinstance(target, dict) or not isinstance(repository, dict):
        raise SnapshotError("handoff target and repository must be objects")
    requested = {name: set() for name in ("skill", "repository", "credential_intent", "tool", "workspace", "network", "verification", "approval", "input")}
    for index, requirement in enumerate(handoff["requirements"]):
        if not isinstance(requirement, dict):
            raise SnapshotError(f"requirements[{index}] must be an object")
        requirement_class = requirement.get("class")
        subject = requirement.get("subject")
        if requirement_class not in requested or not isinstance(subject, str) or not SAFE_ID.fullmatch(subject):
            raise SnapshotError(f"requirements[{index}] has an invalid class or subject")
        requested[requirement_class].add(subject)
    requested["repository"].add(str(repository.get("name") or ""))
    return requested


def readable_inputs(args: argparse.Namespace, handoff: dict[str, Any], requested: set[str]) -> list[dict[str, str]]:
    refs = {
        item.get("input_id"): item
        for item in handoff.get("input_refs", [])
        if isinstance(item, dict) and isinstance(item.get("input_id"), str)
    }
    if not requested:
        return []
    if args.artifact_client is None or args.artifact_registry_url is None or args.artifact_registry_token_file is None:
        return []
    result: list[dict[str, str]] = []
    for input_id in sorted(requested):
        item = refs.get(input_id)
        if not isinstance(item, dict):
            continue
        try:
            completed = subprocess.run(
                [
                    str(args.artifact_client), "--base-url", args.artifact_registry_url,
                    "--token-file", str(args.artifact_registry_token_file), "manifest",
                    str(item.get("producer", "")), str(item.get("artifact_id", "")), str(item.get("revision", "")),
                ],
                check=False, text=True, capture_output=True, timeout=20,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        if completed.returncode == 0:
            try:
                payload = json.loads(completed.stdout)
            except json.JSONDecodeError:
                continue
            if (
                isinstance(payload, dict)
                and payload.get("producer") == item.get("producer")
                and payload.get("artifactId") == item.get("artifact_id")
                and payload.get("revision") == item.get("revision")
            ):
                result.append({"input_id": input_id, "source_revision": item["revision"]})
    return result


def catalog_agent(catalog: dict[str, Any], agent_id: str) -> dict[str, Any]:
    for item in catalog.get("agents", []):
        if isinstance(item, dict) and item.get("agentId") == agent_id:
            return item
    raise SnapshotError(f"agent is absent from the sanitized catalog: {agent_id}")


def skill_revisions(manifest: dict[str, Any]) -> dict[str, str | None]:
    result: dict[str, str | None] = {}
    for item in manifest.get("skills", []):
        if isinstance(item, dict) and isinstance(item.get("id"), str):
            revision = item.get("source_commit")
            result[item["id"]] = revision if isinstance(revision, str) and revision else None
    for item in manifest.get("runtime_native_skills", []):
        if isinstance(item, dict) and isinstance(item.get("id"), str):
            result[item["id"]] = None
    return result


def stable_source(source_id: str, value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise SnapshotError(f"skill source must be an object: {source_id}")
    for key in ("id", "repo", "kind", "branch", "commit"):
        if not isinstance(value.get(key), str) or not value[key]:
            raise SnapshotError(f"skill source has no {key}: {source_id}")
    if value["id"] != source_id:
        raise SnapshotError(f"skill source id does not match its manifest key: {source_id}")
    if not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", value["commit"]):
        raise SnapshotError(f"skill source has an invalid commit: {source_id}")
    if value.get("dirty") is not False:
        raise SnapshotError(f"skill source is not clean: {source_id}")
    return {
        "id": value["id"],
        "repo": value["repo"],
        "kind": value["kind"],
        "branch": value["branch"],
        "commit": value["commit"],
        "dirty": value["dirty"],
    }


def stable_skill(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or not isinstance(value.get("id"), str):
        raise SnapshotError("skill manifest entries must contain an id")
    for key in ("source", "source_commit"):
        if not isinstance(value.get(key), str) or not value[key]:
            raise SnapshotError(f"skill manifest entry has no {key}: {value['id']}")
    files = value.get("files", [])
    if not isinstance(files, list) or not files:
        raise SnapshotError(f"skill manifest files must be a non-empty list: {value['id']}")
    stable_files: list[dict[str, Any]] = []
    for item in files:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            raise SnapshotError(f"skill manifest file entries must contain a path: {value['id']}")
        if not isinstance(item.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", item["sha256"]):
            raise SnapshotError(f"skill manifest file entry has an invalid sha256: {value['id']}")
        if not isinstance(item.get("bytes"), int) or item["bytes"] < 0:
            raise SnapshotError(f"skill manifest file entry has invalid bytes: {value['id']}")
        stable_files.append({
            key: item[key]
            for key in ("path", "sha256", "bytes", "kind", "target")
            if key in item
        })
    return {
        "id": value["id"],
        "source": value.get("source"),
        "source_commit": value.get("source_commit"),
        "files": sorted(stable_files, key=lambda item: item["path"]),
    }


def effective_skill_manifest(
    bundle_manifest: dict[str, Any],
    active_manifest: dict[str, Any],
    agent_id: str,
) -> dict[str, Any]:
    """Fail closed on startup-sync drift and return the active installed view."""
    for label, manifest in (("bundle", bundle_manifest), ("active", active_manifest)):
        if manifest.get("agent_id") != agent_id:
            raise SnapshotError(f"{label} skill manifest agent_id does not match the handoff target")
        if manifest.get("source_sync") != "latest":
            raise SnapshotError(f"{label} skill manifest is not a latest-source installation")
        if not isinstance(manifest.get("declared_skills"), list):
            raise SnapshotError(f"{label} skill manifest has no declared skill inventory")
        if any(not isinstance(item, str) or not item for item in manifest["declared_skills"]):
            raise SnapshotError(f"{label} skill manifest has an invalid declared skill inventory")
        if len(set(manifest["declared_skills"])) != len(manifest["declared_skills"]):
            raise SnapshotError(f"{label} skill manifest has duplicate declared skills")
        if not isinstance(manifest.get("sources"), dict) or not isinstance(manifest.get("skills"), list):
            raise SnapshotError(f"{label} skill manifest has no source or skill inventory")

    if sorted(bundle_manifest["declared_skills"]) != sorted(active_manifest["declared_skills"]):
        raise SnapshotError("bundle and active skill manifests differ: declared skill inventory")
    if sorted(bundle_manifest.get("runtime_native_skills", []), key=lambda item: json.dumps(item, sort_keys=True)) != sorted(
        active_manifest.get("runtime_native_skills", []), key=lambda item: json.dumps(item, sort_keys=True)
    ):
        raise SnapshotError("bundle and active skill manifests differ: runtime-native inventory")

    active_sources = active_manifest["sources"]
    bundle_sources = bundle_manifest["sources"]
    active_filter = active_manifest.get("source_filter")
    if not isinstance(active_filter, list) or not active_filter or set(active_filter) != set(active_sources):
        raise SnapshotError("active skill manifest does not identify its synchronized sources")
    for source_id, active_source in active_sources.items():
        if source_id not in bundle_sources or stable_source(source_id, bundle_sources[source_id]) != stable_source(source_id, active_source):
            raise SnapshotError(f"bundle and active skill manifests differ: source {source_id}")

    bundle_skills = {stable_skill(item)["id"]: item for item in bundle_manifest["skills"]}
    active_skills = {stable_skill(item)["id"]: item for item in active_manifest["skills"]}
    if len(bundle_skills) != len(bundle_manifest["skills"]) or len(active_skills) != len(active_manifest["skills"]):
        raise SnapshotError("skill manifest contains duplicate skill ids")
    for label, skills, sources in (("bundle", bundle_skills, bundle_sources), ("active", active_skills, active_sources)):
        for skill_id, item in skills.items():
            source_id = item["source"]
            if source_id not in sources or item["source_commit"] != sources[source_id].get("commit"):
                raise SnapshotError(f"{label} skill manifest has inconsistent source provenance: {skill_id}")
    expected_active_ids = {
        skill_id
        for skill_id, item in bundle_skills.items()
        if item.get("source") in active_sources
    }
    if set(active_skills) != expected_active_ids:
        raise SnapshotError("bundle and active skill manifests differ: source-managed skill inventory")
    for skill_id, active_skill in active_skills.items():
        if stable_skill(bundle_skills[skill_id]) != stable_skill(active_skill):
            raise SnapshotError(f"bundle and active skill manifests differ: skill {skill_id}")

    merged = dict(bundle_manifest)
    merged["skills"] = [
        active_skills.get(item["id"], item)
        for item in bundle_manifest["skills"]
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    ]
    return merged


def repository_allowed(bundle: dict[str, Any], repository: str) -> bool:
    access = bundle.get("repo_access")
    if not isinstance(access, dict):
        return False
    denied = {
        item if isinstance(item, str) else item.get("name")
        for item in access.get("denied_repositories", [])
        if isinstance(item, (str, dict))
    }
    if repository in denied:
        return False
    if access.get("default_policy") == "allow":
        return True
    allowed = access.get("allowed_repositories", [])
    if allowed == ["*"]:
        return True
    return any(isinstance(item, dict) and item.get("name") == repository for item in allowed)


def configured_credential_intents(bundle: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    access = bundle.get("credential_access")
    if not isinstance(access, dict):
        return result
    vaultwarden = access.get("vaultwarden")
    if not isinstance(vaultwarden, dict):
        return result
    for item in vaultwarden.get("allowed_items", []):
        if isinstance(item, dict) and isinstance(item.get("name"), str):
            result.add(slug(item["name"]))
    projects = vaultwarden.get("env_bootstrap", {}).get("projects", {})
    if isinstance(projects, dict):
        for project, definition in projects.items():
            if not isinstance(definition, dict):
                continue
            for profile in definition.get("profiles", []):
                if isinstance(profile, str):
                    result.add(slug(f"{project}-{profile}"))
    return result


def runtime_tools(runtime: dict[str, Any]) -> tuple[dict[str, str | None], set[str], set[str]]:
    tools: dict[str, str | None] = {}
    verification = {"documentation"}
    networks: set[str] = set()

    def version_at(value: Any, *keys: str) -> str | None:
        for key in keys:
            if not isinstance(value, dict):
                return None
            value = value.get(key)
        if not isinstance(value, dict) or not value.get("available"):
            return None
        version = value.get("version") or value.get("backend") or "available"
        return str(version)[:160]

    docker = version_at(runtime, "docker", "cli")
    if docker:
        tools["docker"] = docker
    compose = runtime.get("composeValidation")
    if isinstance(compose, dict) and compose.get("available"):
        tools["docker-compose"] = "available"
    browser = runtime.get("browserAutomation")
    if isinstance(browser, dict) and browser.get("available"):
        tools["browser-automation"] = version_at(runtime, "browserAutomation", "playwrightCli") or "available"
        verification.add("browser")
    image = runtime.get("imageComposition")
    if isinstance(image, dict) and image.get("available"):
        tools["image-composition"] = "available"
    pnpm = version_at(runtime, "nodeWorkspace", "pnpm")
    if pnpm:
        tools["pnpm"] = pnpm
        verification.update({"unit", "integration", "lint", "typecheck", "build"})
    container_build = runtime.get("containerBuild")
    if isinstance(container_build, dict) and container_build.get("mode") == "local":
        tools["container-build"] = "local"
        verification.add("build")
    for item in runtime.get("networkClasses", []):
        if isinstance(item, str) and SAFE_ID.fullmatch(item):
            networks.add(item)
    return tools, verification, networks


def workspace_state(bundle: dict[str, Any], registry: dict[str, Any] | None) -> dict[str, Any]:
    access = bundle.get("repo_access")
    maximum = access.get("max_concurrent_task_workspaces") if isinstance(access, dict) else None
    if not isinstance(maximum, int) or maximum < 1 or not isinstance(registry, dict) or not isinstance(registry.get("tasks"), dict):
        return {"available": False, "capacity_remaining": 0, "source_revision": "unavailable"}
    active = sum(
        1
        for item in registry["tasks"].values()
        if isinstance(item, dict) and item.get("status") in ACTIVE_TASK_STATES
    )
    return {
        "available": True,
        "capacity_remaining": max(0, maximum - active),
        "source_revision": sha256(registry),
    }


def parse_approvals(values: list[str], requested: set[str]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for value in values:
        parts = value.split(":", 2)
        if len(parts) < 2 or parts[1] not in APPROVAL_STATES or not SAFE_ID.fullmatch(parts[0]):
            raise SnapshotError("approval must be <id>:<pending|approved|rejected|waived>[:source-revision]")
        approval_id, status = parts[:2]
        if approval_id in seen:
            raise SnapshotError(f"duplicate approval: {approval_id}")
        seen.add(approval_id)
        if len(parts) == 3 and (not parts[2] or len(parts[2]) > 160):
            raise SnapshotError("approval source revision must be non-empty bounded text")
        if approval_id in requested:
            result.append({"id": approval_id, "status": status, "source_revision": parts[2] if len(parts) == 3 and parts[2] else None})
    return sorted(result, key=lambda item: item["id"])


def build_snapshot(args: argparse.Namespace) -> dict[str, Any]:
    handoff = load_json(args.handoff, "handoff")
    requested = requested_requirements(handoff)
    target = handoff["target"]
    agent_id = args.agent_id or target.get("agent")
    if agent_id != target.get("agent"):
        raise SnapshotError("--agent-id must match handoff target.agent")

    bundle = load_json(args.bundle_dir / f"{agent_id}.json", "agent bundle")
    catalog = load_json(args.catalog, "sanitized agent catalog")
    catalog_entry = catalog_agent(catalog, agent_id)
    if bundle.get("agent_id") != agent_id or bundle.get("role") != catalog_entry.get("role"):
        raise SnapshotError("bundle and sanitized catalog identity do not agree")

    bundle_manifest = load_json(args.skill_manifest, "runtime bundle skill manifest")
    active_manifest = load_json(args.active_skill_manifest, "active source-sync skill manifest")
    manifest = effective_skill_manifest(bundle_manifest, active_manifest, agent_id)
    revisions = skill_revisions(manifest)
    declared_skills = set(bundle.get("skills", {}).get("installed", []))
    skills = [
        {"id": skill_id, "source_revision": revisions.get(skill_id)}
        for skill_id in sorted(requested["skill"])
        if skill_id in declared_skills and skill_id in revisions
    ]

    repositories = sorted(
        repository
        for repository in requested["repository"]
        if repository and repository_allowed(bundle, repository)
    )
    available_intents = configured_credential_intents(bundle)
    credential_intents = sorted(requested["credential_intent"] & available_intents)
    runtime = load_json(args.runtime_capabilities, "runtime capability report") if args.runtime_capabilities else {}
    all_tools, all_verification, all_networks = runtime_tools(runtime)
    tools = [
        {"id": tool_id, "version": all_tools[tool_id]}
        for tool_id in sorted(requested["tool"] & set(all_tools))
    ]
    verification_classes = sorted(requested["verification"] & all_verification)
    network_classes = sorted(requested["network"] & all_networks)
    registry = load_json(args.task_registry, "task registry") if args.task_registry and args.task_registry.exists() else None
    observed_at = args.observed_at or datetime.now(timezone.utc).isoformat()
    try:
        parsed_observed_at = datetime.fromisoformat(observed_at.replace("Z", "+00:00"))
    except ValueError as exc:
        raise SnapshotError("observed-at must be an RFC 3339 timestamp") from exc
    if parsed_observed_at.tzinfo is None:
        raise SnapshotError("observed-at must include a timezone")
    if not 60 <= args.ttl_seconds <= 3600:
        raise SnapshotError("ttl-seconds must be between 60 and 3600")
    pod_uid = args.pod_uid or os.environ.get("OPENCLAW_POD_UID")
    image_revision = args.image_revision or os.environ.get("OPENCLAW_IMAGE_REVISION")
    if not pod_uid or not image_revision:
        raise SnapshotError("pod and image identity are required for a reusable capability snapshot")
    username = catalog_entry.get("mattermost", {}).get("username")
    if not isinstance(username, str) or not username:
        raise SnapshotError("sanitized catalog is missing the Mattermost username")
    approvals = parse_approvals(args.approval, requested["approval"])

    snapshot = {
        "schema": SNAPSHOT_SCHEMA,
        "snapshot_revision": "",
        "observed_at": observed_at,
        "valid_until": (parsed_observed_at.astimezone(timezone.utc) + timedelta(seconds=args.ttl_seconds)).isoformat(),
        "agent_id": agent_id,
        "role": bundle["role"],
        "mattermost_handle": f"@{username}",
        "skills": skills,
        "repositories": repositories,
        "credential_intents": credential_intents,
        "tools": tools,
        "workspace": workspace_state(bundle, registry),
        "network_classes": network_classes,
        "verification_classes": verification_classes,
        "approvals": approvals,
        "runtime_identity": {
            "pod_uid": pod_uid,
            "image_revision": image_revision,
            "skill_bundle_revision": sha256(active_manifest),
            "requirements_revision": handoff["content_sha256"],
            "approval_revision": sha256(approvals),
        },
        "readable_inputs": readable_inputs(args, handoff, requested["input"]),
    }
    snapshot["snapshot_revision"] = sha256({key: value for key, value in snapshot.items() if key != "snapshot_revision"})
    return snapshot


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_bytes(canonical_bytes(value))
    temporary.replace(path)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--handoff", type=Path, required=True)
    parser.add_argument("--agent-id")
    parser.add_argument("--bundle-dir", type=Path, default=BUNDLE_DIR)
    parser.add_argument("--catalog", type=Path, default=CATALOG_PATH)
    parser.add_argument("--skill-manifest", type=Path, required=True)
    parser.add_argument("--active-skill-manifest", type=Path, required=True)
    parser.add_argument("--runtime-capabilities", type=Path)
    parser.add_argument("--task-registry", type=Path)
    parser.add_argument("--approval", action="append", default=[])
    parser.add_argument("--observed-at")
    parser.add_argument("--ttl-seconds", type=int, default=900)
    parser.add_argument("--pod-uid")
    parser.add_argument("--image-revision")
    parser.add_argument("--artifact-client", type=Path)
    parser.add_argument("--artifact-registry-url")
    parser.add_argument("--artifact-registry-token-file", type=Path)
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        snapshot = build_snapshot(args)
        if args.output:
            write_json(args.output, snapshot)
        print(json.dumps(snapshot, indent=2, sort_keys=True))
        return 0
    except SnapshotError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
