#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

workspace="$tmp_dir/workspace"
agent_id="agent-developer"
agent_dir="$workspace/agents/$agent_id"
memory_repo="$workspace/openclaw-agents-memory"
date_value="2026-06-21"

mkdir -p \
  "$agent_dir/memory" \
  "$agent_dir/skills/example-skill" \
  "$agent_dir/skills/unmanaged-local" \
  "$memory_repo/scripts"

printf '# Agent instructions\n' >"$agent_dir/AGENTS.md"
python3 - "$agent_id" "$agent_dir" <<'PY'
import hashlib
import json
import sys
from pathlib import Path

agent_id = sys.argv[1]
agent_dir = Path(sys.argv[2])
path = agent_dir / "AGENTS.md"
manifest = {
    "agent_id": agent_id,
    "files": [
        {
            "path": "AGENTS.md",
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size,
        }
    ],
}
(agent_dir / "persona-install-manifest.json").write_text(json.dumps(manifest) + "\n", encoding="utf-8")
PY

printf '# Skill\n' >"$agent_dir/skills/example-skill/SKILL.md"
printf '# Unmanaged local skill\n' >"$agent_dir/skills/unmanaged-local/SKILL.md"
python3 - "$agent_dir" <<'PY'
import hashlib
import json
import sys
from pathlib import Path

agent_dir = Path(sys.argv[1])
path = agent_dir / "skills/example-skill/SKILL.md"
manifest = {
    "installed_at": "2026-06-21T12:00:00+00:00",
    "source_filter": ["test"],
    "skills": [
        {
            "id": "example-skill",
            "source": "test",
            "source_commit": "abc123",
            "files": [
                {
                    "path": "SKILL.md",
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "bytes": path.stat().st_size,
                }
            ],
        }
    ]
}
(agent_dir / "skills/skill-source-sync-manifest.json").write_text(json.dumps(manifest) + "\n", encoding="utf-8")
(agent_dir / "skills/skill-bundle-manifest.json").write_text(
    json.dumps(
        {
            "installed_at": "2026-06-20T12:00:00+00:00",
            "skills": [{"id": "legacy-skill", "source": "test"}],
        }
    ) + "\n",
    encoding="utf-8",
)
PY

printf '# Agent instructions\nlocal edit\n' >"$agent_dir/AGENTS.md"
printf '# Skill\nlocal edit\n' >"$agent_dir/skills/example-skill/SKILL.md"
printf 'daily note\n' >"$agent_dir/memory/$date_value.md"

git -C "$memory_repo" init -b main >/dev/null
git -C "$memory_repo" config user.email "openclaw@example.invalid"
git -C "$memory_repo" config user.name "OpenClaw Test"
cat >"$memory_repo/scripts/export_daily_memory.py" <<'PY'
#!/usr/bin/env python3
import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--agent-id", required=True)
parser.add_argument("--source", required=True)
parser.add_argument("--repo-root", required=True)
parser.add_argument("--date", required=True)
parser.add_argument("--project", default="")
parser.add_argument("--visibility", default="agent")
parser.add_argument("--summary", default="")
args = parser.parse_args()

destination = Path(args.repo_root) / "agents" / args.agent_id / "memory" / f"{args.date}.md"
destination.parent.mkdir(parents=True, exist_ok=True)
body = Path(args.source).read_text(encoding="utf-8")
destination.write_text(body, encoding="utf-8")
print(destination)
PY
chmod +x "$memory_repo/scripts/export_daily_memory.py"
git -C "$memory_repo" add scripts/export_daily_memory.py
git -C "$memory_repo" commit -m "seed memory repo" >/dev/null
git -C "$memory_repo" remote add origin "$memory_repo"

report="$("$repo_root/scripts/agent-local-drift-report.py" \
  --agent-id "$agent_id" \
  --workspace "$workspace" \
  --memory-repo "$memory_repo")"

printf '%s\n' "$report" | jq -e '.persona.dirty == true' >/dev/null
printf '%s\n' "$report" | jq -e '.skills.manifests[0].dirty == true' >/dev/null
printf '%s\n' "$report" | jq -e '.skills.manifests[1].dirty == null' >/dev/null
printf '%s\n' "$report" | jq -e '.skills.manifests[1].status == "superseded"' >/dev/null
printf '%s\n' "$report" | jq -e '.skills.manifests[1].superseded_skills == ["legacy-skill"]' >/dev/null
printf '%s\n' "$report" | jq -e '.skills.authoritative_skill_ids == ["example-skill"]' >/dev/null
printf '%s\n' "$report" | jq -e '.skills.unmanaged_directories == ["unmanaged-local"]' >/dev/null
printf '%s\n' "$report" | jq -e '.skills.dirty == true' >/dev/null
printf '%s\n' "$report" | jq -e '.memory.dirty == true' >/dev/null
printf '%s\n' "$report" | jq -e '.memory.unsynced[0].date == "2026-06-21"' >/dev/null

# Publication is verified separately by verify-agent-memory-sync.sh.
# Draft inspection must not execute a helper from the writable memory mirror.

echo "Agent draft sync verification passed"
