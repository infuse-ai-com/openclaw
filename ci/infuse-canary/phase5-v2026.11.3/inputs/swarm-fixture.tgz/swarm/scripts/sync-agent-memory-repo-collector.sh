#!/usr/bin/env bash
set -euo pipefail

source_namespace="${SOURCE_NAMESPACE:-agents-swarm}"
selector="${AGENT_SELECTOR:-app.kubernetes.io/component=persistent-agent}"
timeout_seconds="${SYNC_TIMEOUT_SECONDS:-420}"

workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT

kubectl_cmd=(kubectl)
if [[ -n "${KUBE_CONTEXT:-}" ]]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

pods_json_path="$workdir/pods.json"
"${kubectl_cmd[@]}" -n "$source_namespace" get pods -l "$selector" -o json >"$pods_json_path"

pod_rows=()
while IFS= read -r row; do
  pod_rows+=("$row")
done < <(python3 - "$pods_json_path" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    data = json.load(handle)
for item in data.get("items", []):
    metadata = item.get("metadata", {})
    labels = metadata.get("labels", {})
    name = metadata.get("name")
    agent_id = labels.get("app.kubernetes.io/name")
    phase = item.get("status", {}).get("phase")
    if name and agent_id and phase == "Running":
        print(f"{agent_id}\t{name}")
PY
)

if [[ "${#pod_rows[@]}" -eq 0 ]]; then
  echo "No running agent pods matched selector ${selector} in namespace ${source_namespace}." >&2
  exit 0
fi

failed=0
for row in "${pod_rows[@]}"; do
  agent_id="${row%%$'\t'*}"
  pod_name="${row#*$'\t'}"

  echo "Syncing memory state from ${pod_name} (${agent_id})."
  if ! timeout "$timeout_seconds" "${kubectl_cmd[@]}" -n "$source_namespace" exec "pod/$pod_name" -c agent -- \
    bash -lc '
      set -euo pipefail
      agent_id="${AGENT_ID:-'"$agent_id"'}"
      syncer="/usr/local/bin/openclaw-agent-sync-memory-repo"
      if [ ! -x "$syncer" ]; then
        echo "ERROR: $syncer is not executable in $agent_id" >&2
        exit 1
      fi
      "$syncer"
    '; then
    echo "WARNING: failed to sync ${agent_id} from ${pod_name}." >&2
    failed=$((failed + 1))
  fi
done

if [[ "$failed" -gt 0 ]]; then
  echo "Completed agent memory sync with $failed failure(s)." >&2
  exit 1
fi

echo "Completed agent memory sync for ${#pod_rows[@]} running agent pod(s)."
