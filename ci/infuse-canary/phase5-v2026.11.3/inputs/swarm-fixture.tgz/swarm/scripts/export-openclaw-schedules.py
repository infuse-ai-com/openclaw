#!/usr/bin/env python3
"""Publish schedule metadata for Studio; OpenClaw remains execution authority."""
from __future__ import annotations

import argparse
import importlib.machinery
import importlib.util
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import sys


def gateway_module():
    local = Path(__file__).with_name('export-openclaw-cron-calendar.py')
    path = local if local.exists() else Path('/usr/local/bin/openclaw-cron-calendar-export')
    loader = importlib.machinery.SourceFileLoader('scheduler_gateway', str(path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


def text(value, limit=256):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('Invalid schedule metadata text')
    return value


def timestamp(value):
    if value is None:
        return None
    if type(value) is not int or value < 0:
        raise ValueError('Invalid schedule timestamp')
    return datetime.fromtimestamp(value / 1000, timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def snapshot(raw, agent_id, gateway_label):
    jobs = raw.get('jobs')
    if not isinstance(jobs, list) or len(jobs) > 256:
        raise ValueError('Schedule snapshot exceeds 256 tasks or is incomplete')
    revision = raw.get('snapshotRevision')
    if type(revision) not in (str, int) or not str(revision):
        raise ValueError('Missing Gateway snapshot revision')
    tasks = []
    for job in jobs:
        if not isinstance(job, dict) or type(job.get('enabled')) is not bool:
            raise ValueError('Invalid schedule task')
        schedule = job.get('schedule', {})
        kind = schedule.get('kind')
        if kind == 'cron':
            parsed = {'kind': kind, 'expression': text(schedule.get('expr')), 'timezone': text(schedule['tz']) if schedule.get('tz') else None}
        elif kind == 'every':
            interval = schedule.get('everyMs')
            if type(interval) is not int or not 0 < interval <= 9007199254740991:
                raise ValueError('Invalid schedule interval')
            parsed = {'kind': kind, 'everyMs': interval}
        elif kind == 'at':
            at = text(schedule.get('at'), 40)
            parsed_at = datetime.fromisoformat(at.replace('Z', '+00:00'))
            if parsed_at.tzinfo is None:
                raise ValueError('One-off schedule requires an explicit offset')
            parsed = {'kind': kind, 'at': parsed_at.astimezone(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')}
        else:
            raise ValueError('Unsupported schedule kind')
        state = job.get('state') or {}
        status = state.get('lastRunStatus', state.get('lastStatus'))
        tasks.append({'id': text(job.get('id')), 'name': text(job.get('name') or job.get('id')),
                      'enabled': job['enabled'], 'schedule': parsed,
                      'nextRunAt': timestamp(state.get('nextRunAtMs')),
                      'lastRunAt': timestamp(state.get('lastRunAtMs')),
                      'lastStatus': status if status in ('ok', 'error', 'skipped') else 'unknown'})
    if len({t['id'] for t in tasks}) != len(tasks):
        raise ValueError('Duplicate schedule identity')
    result = {'schemaVersion': 1, 'generatedAt': datetime.now(timezone.utc).isoformat(),
              'source': {'type': 'openclaw_schedules', 'agentId': text(agent_id), 'gatewayLabel': text(gateway_label),
                         'backend': 'gateway_cron_list', 'paginationComplete': True,
                         'snapshotRevision': str(revision), 'status': 'available'},
              'tasks': sorted(tasks, key=lambda t: t['id'])}
    if len(json.dumps(result).encode()) > 200000:
        raise ValueError('Schedule snapshot exceeds 200 KB')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--agent-id', default=os.environ.get('AGENT_ID'))
    parser.add_argument('--gateway-label')
    parser.add_argument('--output', default='-')
    args = parser.parse_args()
    try:
        agent_id = text(args.agent_id)
        raw = gateway_module().fetch_gateway_cron_jobs(openclaw_bin='openclaw', profile=None)
        data = snapshot(raw, agent_id, args.gateway_label or f'{agent_id} Gateway')
        encoded = json.dumps(data, sort_keys=True) + '\n'
        if args.output == '-':
            sys.stdout.write(encoded)
        else:
            Path(args.output).write_text(encoded)
    except Exception:
        # Gateway payloads and execution errors may contain private content.
        print('Schedule export failed: no complete sanitized snapshot available', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
