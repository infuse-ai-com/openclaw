#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${2:-${AGENT_ID:-agent-intake}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
profile="${OPENCLAW_AGENT_PROFILE:-$agent_id}"
timezone="${AGENT_INTAKE_CRON_TZ:-Europe/Madrid}"
consulting_channel_id="${CONSULTING_INTAKE_CHANNEL_ID:-9xjoqzfcwigbmbdkhd9j5mhggo}"

email_job_name="${AGENT_INTAKE_EMAIL_TRIAGE_JOB_NAME:-agent-intake-consulting-email-triage}"
email_schedule="${AGENT_INTAKE_EMAIL_TRIAGE_CRON:-*/10 8-23 * * *}"
email_stagger="${AGENT_INTAKE_EMAIL_TRIAGE_STAGGER:-3m}"
email_timeout_seconds="${AGENT_INTAKE_EMAIL_TRIAGE_TIMEOUT_SECONDS:-900}"
email_prefilter_job_name="${AGENT_INTAKE_EMAIL_PREFILTER_JOB_NAME:-agent-intake-consulting-email-triage-prefilter}"
email_prefilter_schedule="${AGENT_INTAKE_EMAIL_PREFILTER_CRON:-$email_schedule}"
email_prefilter_stagger="${AGENT_INTAKE_EMAIL_PREFILTER_STAGGER:-3m}"
email_prefilter_timeout_seconds="${AGENT_INTAKE_EMAIL_PREFILTER_TIMEOUT_SECONDS:-1200}"
email_prefilter_command="${AGENT_INTAKE_EMAIL_PREFILTER_COMMAND:-/usr/local/bin/openclaw-agent-intake-mail-prefilter}"

reminder_job_name="${AGENT_INTAKE_CLIENT_REMINDER_JOB_NAME:-agent-intake-client-waiting-reminders}"
reminder_schedule="${AGENT_INTAKE_CLIENT_REMINDER_CRON:-0 10,14,18,22 * * *}"
reminder_stagger="${AGENT_INTAKE_CLIENT_REMINDER_STAGGER:-5m}"
reminder_timeout_seconds="${AGENT_INTAKE_CLIENT_REMINDER_TIMEOUT_SECONDS:-600}"
reminder_disabled="${AGENT_INTAKE_CLIENT_REMINDER_DISABLED:-true}"
prefilter_disabled="${AGENT_INTAKE_EMAIL_PREFILTER_DISABLED:-true}"
consulting_intake_root="${AGENT_INTAKE_CONSULTING_ROOT:-/workspace/agents/$agent_id/clients-projects/consulting-intake}"
clients_projects_url="${AGENT_INTAKE_CLIENTS_PROJECTS_URL:-https://gitlab.infuse-ai-tech.party/client-technologies/clients-projects.git}"

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s
"${kubectl_base[@]}" wait pod -l "$selector" --for=condition=Ready --timeout=120s >/dev/null

pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

"${kubectl_base[@]}" exec -i "$pod" -c agent -- bash -s -- \
  "$profile" \
  "$agent_id" \
  "$timezone" \
  "$consulting_channel_id" \
  "$email_job_name" \
  "$email_schedule" \
  "$email_stagger" \
  "$email_timeout_seconds" \
  "$email_prefilter_job_name" \
  "$email_prefilter_schedule" \
  "$email_prefilter_stagger" \
  "$email_prefilter_timeout_seconds" \
  "$email_prefilter_command" \
  "$reminder_job_name" \
  "$reminder_schedule" \
  "$reminder_stagger" \
  "$reminder_timeout_seconds" \
  "$reminder_disabled" \
  "$consulting_intake_root" \
  "$clients_projects_url" \
  "$prefilter_disabled" <<'REMOTE'
set -euo pipefail

profile="$1"
agent_id="$2"
timezone="$3"
consulting_channel_id="$4"
email_job_name="$5"
email_schedule="$6"
email_stagger="$7"
email_timeout_seconds="$8"
email_prefilter_job_name="$9"
email_prefilter_schedule="${10}"
email_prefilter_stagger="${11}"
email_prefilter_timeout_seconds="${12}"
email_prefilter_command="${13}"
reminder_job_name="${14}"
reminder_schedule="${15}"
reminder_stagger="${16}"
reminder_timeout_seconds="${17}"
reminder_disabled="${18}"
consulting_intake_root="${19}"
clients_projects_url="${20}"
prefilter_disabled="${21}"

email_prompt_file="/opt/openclaw-agent-skill-config/prompts/agent-intake-consulting-email-triage.md"
reminder_prompt_file="/opt/openclaw-agent-skill-config/prompts/agent-intake-client-waiting-reminders.md"

if [[ "$consulting_intake_root" != */consulting-intake ]]; then
  echo "AGENT_INTAKE_CONSULTING_ROOT must end in /consulting-intake" >&2
  exit 1
fi
clients_projects_checkout="${consulting_intake_root%/consulting-intake}"
if [[ ! -e "$clients_projects_checkout" ]]; then
  git clone --branch main --single-branch \
    "$clients_projects_url" "$clients_projects_checkout" >/dev/null
fi
if [[ ! -d "$clients_projects_checkout" ]] || \
   ! git -C "$clients_projects_checkout" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "Durable clients-projects checkout is missing or invalid: $clients_projects_checkout" >&2
  exit 1
fi
checkout_root="$(git -C "$clients_projects_checkout" rev-parse --show-toplevel)"
if [[ "$checkout_root" != "$clients_projects_checkout" ]]; then
  echo "Durable state parent is not the clients-projects checkout root: $clients_projects_checkout" >&2
  exit 1
fi

for prompt_file in "$email_prompt_file" "$reminder_prompt_file"; do
  if [[ ! -f "$prompt_file" ]]; then
    echo "Missing agent-intake cron prompt at $prompt_file" >&2
    exit 1
  fi
done

remove_existing_job() {
  local job_name="$1"
  local list_json existing_ids existing_id
  list_json="$(openclaw --profile "$profile" cron list --all --json)"
  existing_ids="$(
    JOB_NAME="$job_name" jq -r '
      .jobs // []
      | map(select(.name == env.JOB_NAME))
      | .[].id
    ' <<<"$list_json"
  )"

  while IFS= read -r existing_id; do
    [[ -n "$existing_id" ]] || continue
    openclaw --profile "$profile" cron remove "$existing_id" >/tmp/"$job_name"-cron-removed.txt
  done <<<"$existing_ids"
}

install_agent_turn_job() {
  local job_name="$1"
  local description="$2"
  local schedule="$3"
  local stagger="$4"
  local timeout_seconds="$5"
  local session_key="$6"
  local prompt_file="$7"
  local disabled="${8:-false}"
  local message

  message="$(cat "$prompt_file")"
  remove_existing_job "$job_name"

  local add_args=(
    cron add
    --name "$job_name" \
    --description "$description" \
    --cron "$schedule" \
    --tz "$timezone" \
    --agent "$agent_id" \
    --session isolated \
    --session-key "$session_key" \
    --message "$message" \
    --light-context \
    --thinking low \
    --timeout-seconds "$timeout_seconds" \
    --stagger "$stagger" \
    --announce \
    --channel mattermost \
    --to "channel:$consulting_channel_id" \
    --best-effort-deliver \
    --json
  )
  if [[ "$disabled" == "true" ]]; then
    add_args+=(--disabled)
  fi

  openclaw --profile "$profile" "${add_args[@]}" >/tmp/"$job_name"-cron.json
}

install_prefilter_job() {
  remove_existing_job "$email_prefilter_job_name"
  local disabled_args=()
  if [[ "$prefilter_disabled" == "true" ]]; then
    disabled_args+=(--disabled)
  fi

  openclaw --profile "$profile" cron add \
    --name "$email_prefilter_job_name" \
    --description "Ramiro consulting email preflight: cheaply fingerprint recent inbound/sent consulting mail plus active intake state, then run model triage only when something changed." \
    --cron "$email_prefilter_schedule" \
    --tz "$timezone" \
    --agent "$agent_id" \
    --command "$email_prefilter_command" \
    "${disabled_args[@]}" \
    --command-env "OPENCLAW_AGENT_PROFILE=$profile" \
    --command-env "AGENT_INTAKE_EMAIL_TRIAGE_MODEL_JOB_NAME=$email_job_name" \
    --command-env "CONSULTING_INTAKE_ROOT=$consulting_intake_root" \
    --timeout-seconds "$email_prefilter_timeout_seconds" \
    --stagger "$email_prefilter_stagger" \
    --no-deliver \
    --json >/tmp/"$email_prefilter_job_name"-cron.json
}

install_agent_turn_job \
  "$email_job_name" \
  "Ramiro consulting email triage: read recent consulting mail, update intake records, and notify only when actionable." \
  "$email_schedule" \
  "$email_stagger" \
  "$email_timeout_seconds" \
  "cron:agent-intake:consulting-email-triage" \
  "$email_prompt_file" \
  true

install_prefilter_job

install_agent_turn_job \
  "$reminder_job_name" \
  "Ramiro consulting reminders: inspect intake state and notify only when Infuse AI owes action, preserving the stored Mattermost thread context." \
  "$reminder_schedule" \
  "$reminder_stagger" \
  "$reminder_timeout_seconds" \
  "cron:agent-intake:client-waiting-reminders" \
  "$reminder_prompt_file" \
  "$reminder_disabled"

openclaw --profile "$profile" cron list --all --json >/tmp/openclaw-cron-list.json

EMAIL_JOB_NAME="$email_job_name" PREFILTER_JOB_NAME="$email_prefilter_job_name" REMINDER_JOB_NAME="$reminder_job_name" REMINDER_DISABLED="$reminder_disabled" PREFILTER_DISABLED="$prefilter_disabled" jq -e '
  .jobs // []
  | {
      email_disabled: map(select(.name == env.EMAIL_JOB_NAME and .enabled == false)) | length,
      prefilter_state_ok: (if env.PREFILTER_DISABLED == "true"
        then map(select(.name == env.PREFILTER_JOB_NAME and .enabled == false)) | length
        else map(select(.name == env.PREFILTER_JOB_NAME and .enabled != false)) | length
        end),
      reminder_state_ok: (if env.REMINDER_DISABLED == "true"
        then map(select(.name == env.REMINDER_JOB_NAME and .enabled == false)) | length
        else map(select(.name == env.REMINDER_JOB_NAME and .enabled != false)) | length
        end)
    }
  | .email_disabled == 1 and .prefilter_state_ok == 1 and .reminder_state_ok == 1
' /tmp/openclaw-cron-list.json >/dev/null

EMAIL_JOB_NAME="$email_job_name" PREFILTER_JOB_NAME="$email_prefilter_job_name" REMINDER_JOB_NAME="$reminder_job_name" jq -r '
  .jobs // []
  | map(select(.name == env.EMAIL_JOB_NAME or .name == env.PREFILTER_JOB_NAME or .name == env.REMINDER_JOB_NAME))
  | sort_by(.name)
  | .[]
  | "Installed cron job \(.name) (\(.id)) enabled=\(.enabled != false)"
' /tmp/openclaw-cron-list.json
REMOTE

echo "agent-intake consulting cron jobs installed for $agent_id in $namespace"
