#!/usr/bin/env python3
"""Check the installed native Studio tool surface for the selected runtime profile."""
import argparse
import json
import sys

BASE_TOOLS = {'studio_floor_manage', 'studio_mission_command', 'studio_mission_context',
              'studio_mission_evidence', 'studio_source_read'}
WHITEBOARD_TOOLS = {'studio_whiteboard_' + name for name in
    ['context', 'read', 'search', 'apply', 'receipt', 'changes', 'render', 'presence', 'post_update']}


def verify(value, profile):
    if profile not in {'production', 'local-mac'}:
        raise ValueError('Unknown authority profile')
    tools = BASE_TOOLS | (WHITEBOARD_TOOLS if profile == 'production' else set())
    plugin = value.get('plugin', {})
    actual = plugin.get('toolNames', [])
    if (plugin.get('status') != 'loaded' or sorted(actual) != sorted(tools)
            or value.get('install', {}).get('source') != 'path'
            or any('duplicate plugin id detected' in item.get('message', '') for item in value.get('diagnostics', []))):
        raise ValueError('Installed Studio plugin inventory does not match its runtime profile')
    return {'profile': profile, 'verifiedTools': len(tools), 'rendererActivation': 'independently gated by Studio'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', choices=['production', 'local-mac'], required=True)
    try:
        args = parser.parse_args()
        print(json.dumps(verify(json.load(sys.stdin), args.profile)))
    except (ValueError, KeyError, TypeError):
        raise SystemExit('Studio runtime inventory verification failed') from None
