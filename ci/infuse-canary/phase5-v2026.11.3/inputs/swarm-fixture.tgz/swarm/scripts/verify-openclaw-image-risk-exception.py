#!/usr/bin/env python3
"""Fail closed unless the exact OpenClaw image scan matches its exception."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXCEPTION_PATH = ROOT / "deploy" / "gitlab" / "image-risk-exception.env"


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise SystemExit(f"invalid line {number} in {path}")
        key, value = line.split("=", 1)
        if not key or key in values:
            raise SystemExit(f"invalid or duplicate key {key!r} in {path}")
        values[key] = value
    return values


def parse_utc(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise SystemExit("exception expiry must be an explicit UTC timestamp")
    return parsed


def validate_exception(now: datetime, profile: str = "default") -> dict[str, str]:
    if profile not in {"default", "dashboard-fleet"}:
        raise SystemExit("unknown image exception profile")
    path = (ROOT / "deploy/gitlab/dashboard-fleet-image-risk-exception.env"
            if profile == "dashboard-fleet" else EXCEPTION_PATH)
    exception = read_env(path)
    required = {
        "OPENCLAW_IMAGE",
        "OPENCLAW_IMAGE_DIGEST",
        "IMAGE_SOURCE_COMMIT",
        "SCANNER",
        "ACCEPTED_DISTINCT_CRITICAL",
        "ACCEPTED_DISTINCT_HIGH",
        "ACCEPTED_OCCURRENCES_CRITICAL",
        "ACCEPTED_OCCURRENCES_HIGH",
        "ACCEPTED_TUPLES",
        "ACCEPTED_FINDINGS_SHA256",
        "OBSERVED_DISTINCT_CRITICAL",
        "OBSERVED_DISTINCT_HIGH",
        "OBSERVED_OCCURRENCES_CRITICAL",
        "OBSERVED_OCCURRENCES_HIGH",
        "OBSERVED_TUPLES",
        "OBSERVED_FINDINGS_SHA256",
        "APPROVED_BY",
        "APPROVED_ON",
        "EXPIRES_AT",
        "SOURCE_PIPELINE_ID",
        "SOURCE_BUILD_JOB_ID",
        "SOURCE_SCAN_JOB_ID",
        "RATIONALE",
    }
    if profile == "dashboard-fleet":
        required.add("APPROVED_DEPLOYMENTS")
    if set(exception) != required:
        raise SystemExit(
            "OpenClaw image exception schema drifted: "
            f"missing={sorted(required - set(exception))}, "
            f"extra={sorted(set(exception) - required)}"
        )

    expected = {
        "OPENCLAW_IMAGE": "registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4",
        "OPENCLAW_IMAGE_DIGEST": "sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4",
        "IMAGE_SOURCE_COMMIT": "5489df67301699056c91325fdfc79fe8519d5c56",
        "SCANNER": "Trivy 0.74.0",
        "ACCEPTED_DISTINCT_CRITICAL": "0",
        "ACCEPTED_OCCURRENCES_CRITICAL": "0",
        "ACCEPTED_DISTINCT_HIGH": "18",
        "ACCEPTED_OCCURRENCES_HIGH": "68",
        "ACCEPTED_TUPLES": "39",
        "ACCEPTED_FINDINGS_SHA256": "05a3736c4f05449229c5cd1e506635523f685c806bd906ca1d78924c02143a2e",
        "OBSERVED_DISTINCT_CRITICAL": "16",
        "OBSERVED_OCCURRENCES_CRITICAL": "34",
        "OBSERVED_DISTINCT_HIGH": "419",
        "OBSERVED_OCCURRENCES_HIGH": "717",
        "OBSERVED_TUPLES": "722",
        "OBSERVED_FINDINGS_SHA256": "44e584a68ccb927ace0454c2de9c32c63324a52a738b19cff03337e30e708eca",
        "APPROVED_BY": "Fito",
        "APPROVED_ON": "2026-11-12",
        "EXPIRES_AT": "2026-12-07T23:59:59Z",
        "SOURCE_PIPELINE_ID": "1666",
        "SOURCE_BUILD_JOB_ID": "7432",
        "SOURCE_SCAN_JOB_ID": "7433",
        "RATIONALE": "Fito authorized proceeding with renewal and tracking remediation on 2026-11-12. The final scan removes both fixable CRITICAL findings, adds no fixable HIGH findings, and stays within the reviewed renewal finding set. Memory MRs remain reviewed; the exception is temporary."
    }
    if profile == "dashboard-fleet":
        expected = {
            "OPENCLAW_IMAGE": "registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:488aaa8ec4c115bb5782f251f8832de1f9beb914e1be3bb35734ad46b25a20fe",
            "OPENCLAW_IMAGE_DIGEST": "sha256:488aaa8ec4c115bb5782f251f8832de1f9beb914e1be3bb35734ad46b25a20fe",
            "IMAGE_SOURCE_COMMIT": "8172b35256dd05b2ead53378c53714e86381a16c",
            "SCANNER": "Trivy 0.74.0",
            "ACCEPTED_DISTINCT_CRITICAL": "2",
            "ACCEPTED_DISTINCT_HIGH": "23",
            "ACCEPTED_OCCURRENCES_CRITICAL": "2",
            "ACCEPTED_OCCURRENCES_HIGH": "73",
            "ACCEPTED_TUPLES": "46",
            "ACCEPTED_FINDINGS_SHA256": "d63accfc624cd19ac2183e76527cb7fe17e139c8f6a509c2d5c64d6ca7e3228a",
            "OBSERVED_DISTINCT_CRITICAL": "18",
            "OBSERVED_DISTINCT_HIGH": "406",
            "OBSERVED_OCCURRENCES_CRITICAL": "36",
            "OBSERVED_OCCURRENCES_HIGH": "665",
            "OBSERVED_TUPLES": "672",
            "OBSERVED_FINDINGS_SHA256": "257b4211cc271b94e85964607e4e16a13d1d567cbe1d337b28a6553b87b6255e",
            "APPROVED_BY": "Fito",
            "APPROVED_ON": "2026-11-10",
            "EXPIRES_AT": "2026-12-07T23:59:59Z",
            "SOURCE_PIPELINE_ID": "1459",
            "SOURCE_BUILD_JOB_ID": "6649",
            "SOURCE_SCAN_JOB_ID": "6650",
            "RATIONALE": "Exact image approved for Emon, Ramiro and Satwa dashboard access; fixed-finding tuples unchanged, with five added and twenty removed HIGH IDs in the full scan. Tinus and Stewie keep their current image.",
            "APPROVED_DEPLOYMENTS": "agent-intake,agent-infra,agent-coordinator"
        }
    for key, value in expected.items():
        if exception[key] != value:
            raise SystemExit(
                f"OpenClaw image exception drift for {key}: "
                f"expected {value!r}, got {exception[key]!r}"
            )

    expires = parse_utc(exception["EXPIRES_AT"])
    if now >= expires:
        raise SystemExit(
            f"OpenClaw image exception expired at {exception['EXPIRES_AT']}"
        )
    return exception


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", choices=("default", "dashboard-fleet"), default="default")
    parser.add_argument("--scan", type=Path)
    parser.add_argument("--image-reference", type=Path)
    parser.add_argument("--image-source", type=Path)
    parser.add_argument("--evidence", type=Path)
    parser.add_argument("--policy-only", action="store_true")
    parser.add_argument("--now", help=argparse.SUPPRESS)
    args = parser.parse_args()
    now = (
        parse_utc(args.now)
        if args.now
        else datetime.now(timezone.utc)
    )
    exception = validate_exception(now, args.profile)

    if args.policy_only:
        if any((args.scan, args.image_reference, args.image_source, args.evidence)):
            raise SystemExit("--policy-only does not accept scan or evidence inputs")
        print(
            "OpenClaw image exception policy valid until "
            f"{exception['EXPIRES_AT']}"
        )
        return

    for name in ("scan", "image_reference", "image_source"):
        if getattr(args, name) is None:
            raise SystemExit(f"--{name.replace('_', '-')} is required")

    image_reference = args.image_reference.read_text(encoding="utf-8").strip()
    image_source = args.image_source.read_text(encoding="utf-8").strip()
    if image_reference != exception["OPENCLAW_IMAGE"]:
        raise SystemExit("verified registry image does not match the exception")
    if image_source != exception["IMAGE_SOURCE_COMMIT"]:
        raise SystemExit("verified image source does not match the exception")

    scan = json.loads(args.scan.read_text(encoding="utf-8"))
    if scan.get("Trivy", {}).get("Version") != exception["SCANNER"].removeprefix("Trivy "):
        raise SystemExit("Trivy scanner version does not match the exception")
    if scan.get("ArtifactName") != exception["OPENCLAW_IMAGE"]:
        raise SystemExit("Trivy artifact does not match the exception image")
    if scan.get("ArtifactType") != "container_image":
        raise SystemExit("Trivy artifact type is not container_image")

    findings = [
        vulnerability
        for result in scan.get("Results", [])
        for vulnerability in (result.get("Vulnerabilities") or [])
        if vulnerability.get("Severity") in {"HIGH", "CRITICAL"}
    ]
    observed_tuples = sorted(
        {
            (
                vulnerability.get("VulnerabilityID", ""),
                vulnerability.get("PkgName", ""),
                vulnerability.get("InstalledVersion", ""),
                vulnerability.get("FixedVersion", ""),
                vulnerability.get("Severity", ""),
            )
            for vulnerability in findings
        }
    )
    accepted_findings = [
        vulnerability
        for vulnerability in findings
        if vulnerability.get("FixedVersion")
    ]
    accepted_tuples = sorted(
        {
            (
                vulnerability.get("VulnerabilityID", ""),
                vulnerability.get("PkgName", ""),
                vulnerability.get("InstalledVersion", ""),
                vulnerability.get("FixedVersion", ""),
                vulnerability.get("Severity", ""),
            )
            for vulnerability in accepted_findings
        }
    )
    accepted_counts = {
        "ACCEPTED_DISTINCT_CRITICAL": len(
            {
                vulnerability["VulnerabilityID"]
                for vulnerability in accepted_findings
                if vulnerability["Severity"] == "CRITICAL"
            }
        ),
        "ACCEPTED_DISTINCT_HIGH": len(
            {
                vulnerability["VulnerabilityID"]
                for vulnerability in accepted_findings
                if vulnerability["Severity"] == "HIGH"
            }
        ),
        "ACCEPTED_OCCURRENCES_CRITICAL": sum(
            vulnerability["Severity"] == "CRITICAL"
            for vulnerability in accepted_findings
        ),
        "ACCEPTED_OCCURRENCES_HIGH": sum(
            vulnerability["Severity"] == "HIGH"
            for vulnerability in accepted_findings
        ),
        "ACCEPTED_TUPLES": len(accepted_tuples),
    }
    observed_counts = {
        "OBSERVED_DISTINCT_CRITICAL": len(
            {
                vulnerability["VulnerabilityID"]
                for vulnerability in findings
                if vulnerability["Severity"] == "CRITICAL"
            }
        ),
        "OBSERVED_DISTINCT_HIGH": len(
            {
                vulnerability["VulnerabilityID"]
                for vulnerability in findings
                if vulnerability["Severity"] == "HIGH"
            }
        ),
        "OBSERVED_OCCURRENCES_CRITICAL": sum(
            vulnerability["Severity"] == "CRITICAL" for vulnerability in findings
        ),
        "OBSERVED_OCCURRENCES_HIGH": sum(
            vulnerability["Severity"] == "HIGH" for vulnerability in findings
        ),
        "OBSERVED_TUPLES": len(observed_tuples),
    }
    accepted_findings_sha256 = hashlib.sha256(
        json.dumps(accepted_tuples, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    observed_findings_sha256 = hashlib.sha256(
        json.dumps(observed_tuples, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    for key, actual in {**accepted_counts, **observed_counts}.items():
        if str(actual) != exception[key]:
            raise SystemExit(
                f"scan count drift for {key}: expected {exception[key]}, got {actual}"
            )
    if accepted_findings_sha256 != exception["ACCEPTED_FINDINGS_SHA256"]:
        raise SystemExit("accepted scan finding tuple digest drifted")
    if observed_findings_sha256 != exception["OBSERVED_FINDINGS_SHA256"]:
        raise SystemExit("observed scan finding tuple digest drifted")

    evidence = {
        **exception,
        **{
            key: str(value)
            for key, value in {**accepted_counts, **observed_counts}.items()
        },
        "STATUS": "accepted-not-clean",
        "VERIFIED_AT": now.isoformat().replace("+00:00", "Z"),
    }
    if args.evidence:
        args.evidence.parent.mkdir(parents=True, exist_ok=True)
        args.evidence.write_text(
            json.dumps(evidence, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    print(
        "OpenClaw image accepted, not clean, until "
        f"{exception['EXPIRES_AT']}"
    )


if __name__ == "__main__":
    main()
