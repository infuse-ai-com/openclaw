#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"
kube_context="${KUBE_CONTEXT:-infuseai-k8s}"
agent_id="${1:-}"
image_ref="${2:-}"
image_repository="registry.infuse-ai-tech.party/agents-swarm/openclaw-agent"
agents=(agent-developer agent-infra agent-designer agent-coordinator agent-intake)

if [[ "${CONFIRM_AGENT_OBSERVABILITY_ROLLOUT:-}" != "yes" ]]; then
  echo "Set CONFIRM_AGENT_OBSERVABILITY_ROLLOUT=yes after reviewing the target and image." >&2
  exit 2
fi
if [[ ! " ${agents[*]} " =~ " ${agent_id} " ]] || [[ "$image_ref" != "$image_repository":* ]]; then
  echo "Usage: $0 {agent-developer|agent-infra|agent-designer|agent-coordinator|agent-intake} $image_repository:<reviewed-tag>" >&2
  exit 2
fi

for command in kubectl jq shasum; do
  command -v "$command" >/dev/null 2>&1 || { echo "Missing required command: $command" >&2; exit 1; }
done

if command -v crane >/dev/null 2>&1; then
  digest="$(crane digest "$image_ref")"
elif command -v docker >/dev/null 2>&1; then
  digest="$(docker buildx imagetools inspect "$image_ref" --format '{{json .Manifest.Digest}}' | tr -d '"')"
else
  echo "Missing crane and docker; one registry inspection tool is required." >&2
  exit 1
fi
if [[ ! "$digest" =~ ^sha256:[0-9a-f]{64}$ ]]; then
  echo "Could not resolve an immutable digest for the reviewed image." >&2
  exit 1
fi

immutable_image="$image_repository@$digest"
release_version="${image_ref##*:}"
kubectl_cmd=(kubectl --context "$kube_context")
temporary_root="${TMPDIR:-/tmp}"
temporary_root="${temporary_root%/}"
workdir="$(mktemp -d "$temporary_root/openclaw-observability.XXXXXX")"
target_changed=false
original_revision=""

cleanup() {
  if [[ -d "$workdir" && "$workdir" == "$temporary_root"/openclaw-observability.* ]]; then
    rm -r -- "$workdir"
  fi
}

rollback_on_error() {
  local exit_code=$?
  if [[ "$target_changed" == "true" && -n "$original_revision" ]]; then
    echo "Observability rollout failed; restoring deployment/$agent_id to revision $original_revision." >&2
    "${kubectl_cmd[@]}" -n "$namespace" rollout undo "deployment/$agent_id" --to-revision="$original_revision" >&2 || true
    "${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$agent_id" --timeout=420s >&2 || true
  fi
  cleanup
  exit "$exit_code"
}
trap rollback_on_error ERR
trap cleanup EXIT

identity="$("${kubectl_cmd[@]}" auth whoami -o json | jq -r '.status.userInfo.username // empty')"
if [[ -z "$identity" ]]; then
  echo "Could not resolve the active Kubernetes identity." >&2
  exit 1
fi
echo "Kubernetes identity: $identity"
for permission in "get deployments.apps" "patch deployments.apps" "create deployments.apps"; do
  read -r verb resource <<<"$permission"
  if [[ "$("${kubectl_cmd[@]}" auth can-i "$verb" "$resource" -n "$namespace")" != "yes" ]]; then
    echo "Current identity cannot $verb $resource in $namespace." >&2
    exit 1
  fi
done
if [[ "$("${kubectl_cmd[@]}" auth can-i create pods --subresource=exec -n "$namespace")" != "yes" ]]; then
  echo "Current identity cannot create pods/exec in $namespace." >&2
  exit 1
fi

template_fingerprint() {
  "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$1" -o json \
    | jq -cS '.spec.template' | shasum -a 256 | awk '{print $1}'
}

target_index=0
for index in "${!agents[@]}"; do
  if [[ "${agents[$index]}" == "$agent_id" ]]; then target_index="$index"; fi
done
for ((index = 0; index < target_index; index++)); do
  predecessor="${agents[$index]}"
  predecessor_json="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$predecessor" -o json)"
  predecessor_ready="$(jq -r '.status.readyReplicas == .spec.replicas and .status.updatedReplicas == .spec.replicas' <<<"$predecessor_json")"
  predecessor_digest="$(jq -r '.spec.template.metadata.annotations["openclaw.infuse-ai.com/image-revision"] // ""' <<<"$predecessor_json")"
  predecessor_flag="$(jq -r '[.spec.template.spec.containers[] | select(.name == "agent") | .env[]? | select(.name == "OPENCLAW_DIAGNOSTICS_OTEL_CANARY") | .value] | first // "false"' <<<"$predecessor_json")"
  if [[ "$predecessor_ready" != "true" || "$predecessor_digest" != "$digest" || "$predecessor_flag" != "true" ]]; then
    echo "Refusing out-of-order rollout: $predecessor is not Ready on the reviewed observability image." >&2
    exit 1
  fi
done

for peer in "${agents[@]}"; do
  if [[ "$peer" != "$agent_id" ]]; then template_fingerprint "$peer" >"$workdir/$peer.before"; fi
done

target_json="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent_id" -o json)"
original_revision="$(jq -r '.metadata.annotations["deployment.kubernetes.io/revision"]' <<<"$target_json")"
original_service_account="$(jq -r '.spec.template.spec.serviceAccountName' <<<"$target_json")"
original_replicas="$(jq -r '.spec.replicas' <<<"$target_json")"

kubectl kustomize "k8s/agents/$agent_id" \
  | kubectl apply --dry-run=client -f - -o json \
  | jq --arg name "$agent_id" --arg image "$immutable_image" --arg version "$release_version" --arg digest "$digest" --argjson replicas "$original_replicas" '
      .items[]
      | select(.kind == "Deployment" and .metadata.name == $name)
      | .spec.replicas = $replicas
      | .metadata.annotations["openclaw.infuse-ai.com/version"] = $version
      | .spec.template.metadata.annotations["openclaw.infuse-ai.com/version"] = $version
      | .spec.template.metadata.annotations["openclaw.infuse-ai.com/image-revision"] = $digest
      | .spec.template.spec.containers |= map(if .name == "agent" then .image = $image else . end)
    ' >"$workdir/$agent_id.json"

if [[ "$(jq -r '.spec.template.spec.serviceAccountName' "$workdir/$agent_id.json")" != "$original_service_account" ]]; then
  echo "Rendered deployment would change the ServiceAccount." >&2
  exit 1
fi
"${kubectl_cmd[@]}" -n "$namespace" apply --dry-run=server -f "$workdir/$agent_id.json" >/dev/null

target_changed=true
"${kubectl_cmd[@]}" -n "$namespace" apply -f "$workdir/$agent_id.json"
"${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$agent_id" --timeout=420s
KUBE_CONTEXT="$kube_context" NAMESPACE="$namespace" AGENT_ID="$agent_id" \
  EXPECTED_IMAGE_DIGEST="$digest" EXPECTED_IMAGE_REF="$immutable_image" EXPECTED_OBSERVABILITY=true \
    scripts/smoke-agent-runtime.sh "$namespace" "$agent_id"

actual_json="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent_id" -o json)"
if [[ "$(jq -r '.spec.template.spec.serviceAccountName' <<<"$actual_json")" != "$original_service_account" ]] || \
   [[ "$(jq -r '.spec.template.spec.containers[] | select(.name == "agent") | .image' <<<"$actual_json")" != "$immutable_image" ]]; then
  echo "Deployment identity or image does not match the reviewed rollout contract." >&2
  exit 1
fi
for peer in "${agents[@]}"; do
  if [[ "$peer" != "$agent_id" && "$(template_fingerprint "$peer")" != "$(<"$workdir/$peer.before")" ]]; then
    echo "Observability rollout changed peer deployment/$peer; stop and investigate." >&2
    exit 1
  fi
done

target_changed=false
echo "Verified deployment/$agent_id on $immutable_image with metadata-only telemetry; peer templates are unchanged."
