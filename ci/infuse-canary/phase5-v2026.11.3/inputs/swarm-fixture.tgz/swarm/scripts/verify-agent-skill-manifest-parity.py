#!/usr/bin/env python3
"""Fail closed when the reviewed and active agent skill manifests diverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import runpy
import sys
from typing import Any


MAX_MANIFEST_BYTES = 4 * 1024 * 1024


def load_manifest(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    if not raw or len(raw) > MAX_MANIFEST_BYTES:
        raise ValueError("manifest_size_invalid")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("manifest_shape_invalid")
    return value


def load_effective_manifest_validator():
    candidates = (
        Path(__file__).resolve().with_name("export-agent-capability-snapshot.py"),
        Path("/usr/local/bin/openclaw-agent-capability-snapshot"),
    )
    source = next((candidate for candidate in candidates if candidate.is_file()), None)
    if source is None:
        raise ValueError("validator_unavailable")
    namespace = runpy.run_path(str(source))
    validator = namespace.get("effective_skill_manifest")
    if not callable(validator):
        raise ValueError("validator_unavailable")
    return validator


def verify_pair(*, agent_id: str, bundle_path: Path, active_path: Path) -> dict[str, Any]:
    bundle = load_manifest(bundle_path)
    active = load_manifest(active_path)
    effective = load_effective_manifest_validator()(bundle, active, agent_id)
    sources = active.get("sources", {})
    revisions = sorted(
        {
            value.get("commit")
            for value in sources.values()
            if isinstance(value, dict) and isinstance(value.get("commit"), str)
        }
    )
    return {
        "action": "skill_manifest_parity_verified",
        "agentId": agent_id,
        "declaredSkills": len(effective.get("declared_skills", [])),
        "sourceRevisions": revisions,
    }


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--agent-id", required=True)
    result.add_argument("--bundle", required=True, type=Path)
    result.add_argument("--active", required=True, type=Path)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        result = verify_pair(
            agent_id=args.agent_id,
            bundle_path=args.bundle,
            active_path=args.active,
        )
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError, RuntimeError):
        print(
            json.dumps(
                {"action": "failed_closed", "reasonCode": "skill_manifest_parity_failed"},
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
