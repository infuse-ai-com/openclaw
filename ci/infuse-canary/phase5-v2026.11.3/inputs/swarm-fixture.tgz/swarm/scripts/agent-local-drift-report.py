#!/usr/bin/env python3
"""Report local agent workspace drift without printing file contents."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path


DEFAULT_WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", "/workspace"))
DEFAULT_AGENT_ID = os.environ.get("AGENT_ID", "agent-developer")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {"_invalid_json": True}


def compare_manifest_files(root: Path, manifest_files: list[dict], *, include_added: bool = True) -> dict:
    expected = {
        item["path"]: item
        for item in manifest_files
        if isinstance(item, dict) and isinstance(item.get("path"), str)
    }
    modified: list[str] = []
    missing: list[str] = []

    for relative, item in sorted(expected.items()):
        if relative == "." and item.get("kind") == "symlink":
            if not root.is_symlink() or os.readlink(root) != item.get("target"):
                modified.append(relative)
            continue
        path = root / relative
        if not path.exists():
            missing.append(relative)
            continue
        if path.is_file() and item.get("sha256") and sha256_file(path) != item["sha256"]:
            modified.append(relative)

    added: list[str] = []
    if include_added and root.exists():
        known = set(expected)
        added = [
            path.relative_to(root).as_posix()
            for path in sorted(root.rglob("*"))
            if path.is_file()
            and path.relative_to(root).as_posix() not in known
            and not path.name.endswith("-manifest.json")
        ]

    return {
        "modified": modified,
        "missing": missing,
        "added": added,
        "dirty": bool(modified or missing or added),
    }


def persona_report(agent_dir: Path) -> dict:
    manifest_path = agent_dir / "persona-install-manifest.json"
    manifest = load_json(manifest_path)
    if manifest is None:
        return {"manifest": str(manifest_path), "status": "missing_manifest", "dirty": None}
    if manifest.get("_invalid_json"):
        return {"manifest": str(manifest_path), "status": "invalid_manifest", "dirty": None}
    comparison = compare_manifest_files(agent_dir, manifest.get("files", []), include_added=False)
    return {
        "manifest": str(manifest_path),
        "status": "ok",
        "installed_at": manifest.get("installed_at"),
        "source_kind": manifest.get("source_kind"),
        "source_dir": manifest.get("source_dir"),
        "source_git_commit": manifest.get("source_git_commit"),
        "source_git_relative_dir": manifest.get("source_git_relative_dir"),
        **comparison,
    }


def manifest_installed_at(manifest: dict) -> dt.datetime:
    value = manifest.get("installed_at")
    if not isinstance(value, str):
        return dt.datetime.min.replace(tzinfo=dt.timezone.utc)
    try:
        parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return dt.datetime.min.replace(tzinfo=dt.timezone.utc)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=dt.timezone.utc)
    return parsed.astimezone(dt.timezone.utc)


def manifest_source_filter(manifest: dict) -> set[str]:
    value = manifest.get("source_filter")
    if not isinstance(value, list):
        return set()
    return {item for item in value if isinstance(item, str) and item}


def skill_report(agent_dir: Path) -> dict:
    skills_dir = agent_dir / "skills"
    manifest_paths = [
        skills_dir / "skill-source-sync-manifest.json",
        skills_dir / "skill-bundle-manifest.json",
    ]
    manifests = [(path, load_json(path)) for path in manifest_paths]
    source_claims: dict[str, tuple[dt.datetime, Path]] = {}
    for manifest_path, manifest in manifests:
        if not manifest or manifest.get("_invalid_json"):
            continue
        installed_at = manifest_installed_at(manifest)
        for source_id in manifest_source_filter(manifest):
            current = source_claims.get(source_id)
            if current is None or installed_at > current[0]:
                source_claims[source_id] = (installed_at, manifest_path)

    reports = []
    authoritative_skill_ids: set[str] = set()
    for manifest_path, manifest in manifests:
        if manifest is None:
            reports.append({"manifest": str(manifest_path), "status": "missing_manifest", "dirty": None})
            continue
        if manifest.get("_invalid_json"):
            reports.append({"manifest": str(manifest_path), "status": "invalid_manifest", "dirty": None})
            continue
        skill_entries = []
        superseded_skills = []
        dirty_values = []
        for skill in manifest.get("skills", []):
            skill_id = skill.get("id")
            if not isinstance(skill_id, str):
                continue
            source_id = skill.get("source")
            source_claim = source_claims.get(source_id) if isinstance(source_id, str) else None
            if source_claim and source_claim[1] != manifest_path and source_claim[0] > manifest_installed_at(manifest):
                superseded_skills.append(skill_id)
                continue
            authoritative_skill_ids.add(skill_id)
            file_manifest = skill.get("files")
            if not file_manifest:
                skill_entries.append(
                    {
                        "id": skill_id,
                        "source": source_id,
                        "source_commit": skill.get("source_commit"),
                        "status": "missing_file_hashes",
                        "dirty": None,
                        "modified": [],
                        "missing": [],
                        "added": [],
                    }
                )
                continue
            comparison = compare_manifest_files(skills_dir / skill_id, file_manifest)
            dirty_values.append(comparison["dirty"])
            skill_entries.append(
                {
                    "id": skill_id,
                    "source": source_id,
                    "source_commit": skill.get("source_commit"),
                    "status": "ok",
                    **comparison,
                }
            )
        if superseded_skills and not skill_entries:
            status = "superseded"
        elif superseded_skills:
            status = "partially_superseded"
        else:
            status = "ok"
        reports.append(
            {
                "manifest": str(manifest_path),
                "status": status,
                "installed_at": manifest.get("installed_at"),
                "dirty": any(dirty_values) if dirty_values else None,
                "source_filter": sorted(manifest_source_filter(manifest)) or None,
                "skills": skill_entries,
                "superseded_skills": sorted(superseded_skills),
            }
        )

    installed_directories = {
        path.name
        for path in skills_dir.iterdir()
        if path.is_dir()
    } if skills_dir.exists() else set()
    unmanaged_directories = sorted(installed_directories - authoritative_skill_ids)
    return {
        "directory": str(skills_dir),
        "dirty": bool(unmanaged_directories or any(report.get("dirty") is True for report in reports)),
        "authoritative_skill_ids": sorted(authoritative_skill_ids),
        "unmanaged_directories": unmanaged_directories,
        "manifests": reports,
    }


def memory_report(agent_id: str, agent_dir: Path, memory_repo: Path) -> dict:
    local_dir = agent_dir / "memory"
    repo_dir = memory_repo / "agents" / agent_id / "memory"
    unsynced = []
    changed = []
    for local_path in sorted(local_dir.glob("*.md")):
        repo_path = repo_dir / local_path.name
        item = {
            "date": local_path.stem,
            "local_path": str(local_path),
            "repo_path": str(repo_path),
        }
        if not repo_path.exists():
            unsynced.append(item)
        elif sha256_file(local_path) != sha256_file(repo_path):
            changed.append(item)
    return {
        "local_dir": str(local_dir),
        "repo_dir": str(repo_dir),
        "unsynced": unsynced,
        "changed": changed,
        "dirty": bool(unsynced or changed),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Report local persistent-agent drift.")
    parser.add_argument("--agent-id", default=DEFAULT_AGENT_ID)
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument(
        "--memory-repo",
        type=Path,
        default=Path(os.environ.get("OPENCLAW_SHARED_MEMORY_PATH", DEFAULT_WORKSPACE / "openclaw-agents-memory")),
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON.")
    args = parser.parse_args()

    workspace = args.workspace.expanduser().resolve()
    agent_dir = workspace / "agents" / args.agent_id
    memory_repo = args.memory_repo.expanduser().resolve()
    report = {
        "agent_id": args.agent_id,
        "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "workspace": str(workspace),
        "agent_dir": str(agent_dir),
        "persona": persona_report(agent_dir),
        "skills": skill_report(agent_dir),
        "memory": memory_report(args.agent_id, agent_dir, memory_repo),
    }
    print(json.dumps(report, indent=2 if args.pretty else None, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
