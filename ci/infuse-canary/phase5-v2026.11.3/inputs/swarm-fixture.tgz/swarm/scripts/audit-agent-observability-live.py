#!/usr/bin/env python3
"""Query Langfuse for aggregate-only OpenClaw observability evidence.

Credentials are read from environment variables and are never included in the
report. Observation input/output, trace identifiers, tool call identifiers,
and free-form status messages are deliberately ignored.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any, Iterable


FLEET = {
    "agent-coordinator",
    "agent-developer",
    "agent-designer",
    "agent-infra",
    "agent-intake",
}
TRAFFIC_SOURCES = {"human", "automation", "smoke", "startup", "unavailable"}
NOISE_SPANS = (
    "openclaw.gateway.rpc.handler",
    "openclaw.gateway.rpc.dispatch",
    "openclaw.gateway.rpc.response",
    "openclaw.diagnostic.phase",
    "openclaw.memory.pressure",
    "openclaw.model.usage",
)
SIGNALS = (
    "openclaw.run",
    "openclaw.tool.execution",
    "infuse.agent.turn",
    "infuse.tool.execution",
    "infuse.skill.execution",
    "infuse.wrapper.execution",
    "infuse.knowledge.retrieve",
    "infuse.knowledge.decision",
)
PAGE_LIMIT = 1000
MAX_PAGES = 1000


class AuditError(RuntimeError):
    pass


def parse_utc(value: str) -> str:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise argparse.ArgumentTypeError("timestamps must be RFC3339") from error
    if parsed.tzinfo is None:
        raise argparse.ArgumentTypeError("timestamps must include a timezone")
    return parsed.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace(
        "+00:00", "Z"
    )


class LangfuseClient:
    def __init__(self, base_url: str, public_key: str, secret_key: str) -> None:
        self.endpoint = f"{base_url.rstrip('/')}/api/public/v2/observations"
        encoded = base64.b64encode(f"{public_key}:{secret_key}".encode()).decode()
        self.authorization = f"Basic {encoded}"

    def request(self, query: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.endpoint}?{urllib.parse.urlencode(query)}"
        request = urllib.request.Request(
            url,
            headers={
                "Authorization": self.authorization,
                "Accept": "application/json",
                "User-Agent": "openclaw-observability-audit/1.0",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.load(response)
        except urllib.error.HTTPError as error:
            raise AuditError(f"Langfuse API request failed: HTTP {error.code}") from error
        except (OSError, ValueError) as error:
            raise AuditError(f"Langfuse API request failed: {type(error).__name__}") from error
        if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
            raise AuditError("Langfuse API returned an unexpected response shape")
        return payload

    def observations(
        self,
        *,
        start: str,
        end: str,
        name: str | None = None,
        include_metadata: bool = True,
    ) -> Iterable[dict[str, Any]]:
        cursor: str | None = None
        for _ in range(MAX_PAGES):
            query: dict[str, Any] = {
                "fields": "core,basic,metadata,io,model,usage,trace_context"
                if include_metadata
                else "core,basic",
                "limit": PAGE_LIMIT,
                "fromStartTime": start,
                "toStartTime": end,
            }
            if name:
                query["name"] = name
            if cursor:
                query["cursor"] = cursor
            payload = self.request(query)
            rows = payload["data"]
            for row in rows:
                if isinstance(row, dict):
                    yield row
            meta = payload.get("meta")
            if not isinstance(meta, dict):
                raise AuditError("Langfuse API omitted cursor metadata")
            cursor = meta.get("cursor")
            if cursor is None:
                return
            if not isinstance(cursor, str) or not cursor:
                raise AuditError("Langfuse API returned an invalid cursor")
        raise AuditError(f"observation pagination exceeded {MAX_PAGES} pages for {name or 'all'}")

    def total(self, *, start: str, end: str, name: str | None = None) -> int:
        return sum(
            1
            for _ in self.observations(
                start=start,
                end=end,
                name=name,
                include_metadata=False,
            )
        )


def safe_attributes(observation: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    metadata = observation.get("metadata")
    if not isinstance(metadata, dict):
        return {}, {}
    nested_attributes = metadata.get("attributes")
    nested_resources = metadata.get("resourceAttributes")
    attributes = dict(nested_attributes) if isinstance(nested_attributes, dict) else {}
    resources = dict(nested_resources) if isinstance(nested_resources, dict) else {}
    for key, value in metadata.items():
        if key.startswith("attributes."):
            attributes[key.removeprefix("attributes.")] = value
        elif key.startswith("resourceAttributes."):
            resources[key.removeprefix("resourceAttributes.")] = value
        elif key in {
            "classification_source",
            "failure_category",
            "outcome",
            "pricing_status",
            "tool_name",
            "traffic_source",
        }:
            attributes[key] = value
    return attributes, resources


def is_error(observation: dict[str, Any], attributes: dict[str, Any]) -> bool:
    return (
        observation.get("level") == "ERROR"
        or attributes.get("outcome") == "error"
        or attributes.get("openclaw.outcome") == "error"
    )


def canonical_tool(value: Any) -> str:
    if not isinstance(value, str) or not value:
        return "unknown"
    if value.startswith("openclaw") and len(value) > len("openclaw"):
        value = value[len("openclaw") :]
    return "exec" if value == "bash" else value


def summarize_signal(name: str, observations: Iterable[dict[str, Any]]) -> dict[str, Any]:
    attempts = 0
    errors = 0
    agents: Counter[str] = Counter()
    traffic: Counter[str] = Counter()
    tools: dict[str, Counter[str]] = defaultdict(Counter)
    content_observations = 0
    for observation in observations:
        attempts += 1
        attributes, resources = safe_attributes(observation)
        error = is_error(observation, attributes)
        errors += int(error)
        agent = resources.get("openclaw.agent.name") or attributes.get("openclaw.agent")
        if agent in FLEET:
            agents[agent] += 1
        source = attributes.get("traffic.source", "unavailable")
        traffic[source if source in TRAFFIC_SOURCES else "unavailable"] += 1
        if name == "openclaw.tool.execution":
            tool_name = canonical_tool(attributes.get("openclaw.toolName"))
            tools[tool_name]["attempts"] += 1
            tools[tool_name]["errors"] += int(error)
        elif name == "infuse.tool.execution":
            tool_name = canonical_tool(attributes.get("tool_name"))
            tools[tool_name]["attempts"] += 1
            tools[tool_name]["errors"] += int(error)
        if observation.get("input") not in (None, "", [], {}) or observation.get("output") not in (
            None,
            "",
            [],
            {},
        ):
            content_observations += 1
    result: dict[str, Any] = {
        "attempts": attempts,
        "errors": errors,
        "byAgent": dict(sorted(agents.items())),
        "trafficSource": dict(sorted(traffic.items())),
        "contentObservations": content_observations,
    }
    if tools:
        result["tools"] = {
            tool_name: dict(counts)
            for tool_name, counts in sorted(
                tools.items(), key=lambda item: (-item[1]["attempts"], item[0])
            )
        }
    return result


def nonempty_content(observation: dict[str, Any]) -> bool:
    return observation.get("input") not in (None, "", [], {}) or observation.get(
        "output"
    ) not in (None, "", [], {})


def summarize_window(observations: list[dict[str, Any]]) -> dict[str, Any]:
    traces: dict[str, list[dict[str, Any]]] = defaultdict(list)
    type_counts: Counter[str] = Counter()
    singleton_families: Counter[str] = Counter()
    tool_failures = 0
    actionable_tool_failures = 0
    generations = 0
    generations_with_usage = 0
    generation_cost_state: Counter[str] = Counter()

    for observation in observations:
        trace_id = observation.get("traceId")
        if isinstance(trace_id, str) and trace_id:
            traces[trace_id].append(observation)
        observation_type = observation.get("type")
        if isinstance(observation_type, str) and observation_type:
            type_counts[observation_type.lower()] += 1
        attributes, _ = safe_attributes(observation)
        name = observation.get("name")
        if name in {"openclaw.tool.execution", "infuse.tool.execution"} or (
            isinstance(attributes.get("openclaw.toolName"), str)
            or isinstance(attributes.get("tool_name"), str)
        ):
            if is_error(observation, attributes):
                tool_failures += 1
                if attributes.get("failure_category") not in (None, "", "unknown"):
                    actionable_tool_failures += 1
        if str(observation_type).lower() == "generation":
            generations += 1
            usage = observation.get("usageDetails")
            if isinstance(usage, dict) and usage:
                generations_with_usage += 1
            metadata = observation.get("metadata")
            pricing_status = attributes.get("langfuse.observation.metadata.pricing_status")
            if isinstance(metadata, dict):
                pricing_status = metadata.get("pricing_status", pricing_status)
            try:
                total_cost = float(observation.get("totalCost") or 0)
            except (TypeError, ValueError):
                total_cost = 0
            if total_cost > 0:
                generation_cost_state["priced"] += 1
            elif pricing_status == "unpriced":
                generation_cost_state["unpriced"] += 1
            else:
                generation_cost_state["unresolved"] += 1

    canonical_curated_turn_traces = 0
    mixed_official_curated_traces = 0
    duplicate_curated_turn_traces = 0
    singleton_traces = 0
    for trace_observations in traces.values():
        names = [row.get("name") for row in trace_observations]
        if len(trace_observations) == 1:
            singleton_traces += 1
            singleton_families[str(names[0] or "unknown")] += 1
        curated_turns = names.count("infuse.agent.turn")
        if curated_turns:
            if curated_turns == 1:
                canonical_curated_turn_traces += 1
            if any(str(name or "").startswith("openclaw.") for name in names):
                mixed_official_curated_traces += 1
            if curated_turns > 1:
                duplicate_curated_turn_traces += 1

    return {
        "traces": len(traces),
        "singletonTraces": singleton_traces,
        "multiObservationTraces": len(traces) - singleton_traces,
        "singletonFamilies": dict(singleton_families.most_common()),
        "canonicalCuratedTurnTraces": canonical_curated_turn_traces,
        "mixedOfficialCuratedTraces": mixed_official_curated_traces,
        "duplicateCuratedTurnTraces": duplicate_curated_turn_traces,
        "observationTypes": dict(sorted(type_counts.items())),
        "toolFailureCoverage": {
            "failures": tool_failures,
            "actionable": actionable_tool_failures,
            "actionablePct": round(100 * actionable_tool_failures / tool_failures, 4)
            if tool_failures
            else 100.0,
        },
        "modelUsage": {
            "generations": generations,
            "withUsage": generations_with_usage,
            "costState": dict(sorted(generation_cost_state.items())),
        },
        "contentObservations": sum(nonempty_content(row) for row in observations),
    }


def build_report(client: LangfuseClient, start: str, end: str) -> dict[str, Any]:
    observations = list(client.observations(start=start, end=end))
    by_name: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for observation in observations:
        name = observation.get("name")
        if isinstance(name, str):
            by_name[name].append(observation)
    total_observations = len(observations)
    noise = {name: len(by_name[name]) for name in NOISE_SPANS}
    signals = {
        name: summarize_signal(name, by_name[name])
        for name in SIGNALS
    }
    noise_total = sum(noise.values())
    window_summary = summarize_window(observations)
    return {
        "schemaVersion": "2.0.0",
        "window": {"start": start, "end": end},
        "backend": {
            "observations": total_observations,
            "noiseObservations": noise_total,
            "noiseSharePct": round(100 * noise_total / total_observations, 4)
            if total_observations
            else 0.0,
            "noiseFamilies": noise,
        },
        "signals": signals,
        "traceQuality": window_summary,
        "privacy": {
            "contentObservationsAcrossAllObservations": window_summary[
                "contentObservations"
            ],
            "aggregateOnly": True,
        },
        "provenance": {
            "source": "langfuse-public-api",
            "projectCredentials": "environment",
            "traceIdentifiersIncluded": False,
        },
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Emit aggregate-only live OpenClaw observability evidence"
    )
    parser.add_argument("--start", required=True, type=parse_utc)
    parser.add_argument("--end", required=True, type=parse_utc)
    parser.add_argument(
        "--base-url",
        default=os.environ.get("LANGFUSE_BASE_URL", "https://langfuse.infuse-ai.com"),
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    public_key = os.environ.get("LANGFUSE_PUBLIC_KEY", "")
    secret_key = os.environ.get("LANGFUSE_SECRET_KEY", "")
    if not public_key or not secret_key:
        print(
            "ERROR: LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY are required",
            file=sys.stderr,
        )
        return 2
    if args.end <= args.start:
        print("ERROR: --end must be after --start", file=sys.stderr)
        return 2
    try:
        report = build_report(
            LangfuseClient(args.base_url, public_key, secret_key), args.start, args.end
        )
    except AuditError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
