#!/usr/bin/env python3
"""Synthetic native browser qualification; only for disposable, token-free pods.

Run with a 300-second outer timeout in the runtime security qualification Job.
Never use this helper with a persistent agent profile or a credentialed browser.
"""
import argparse, json, os, re, subprocess, sys, time
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--sandbox', choices=['on','off'], required=True)
parser.add_argument('--headed', action='store_true')
args=parser.parse_args()
if os.environ.get("OPENCLAW_ISOLATED_QUALIFICATION") != "1":
    parser.error("requires an explicitly isolated qualification pod")
if os.environ.get("OPENCLAW_STATE_DIR") != "/tmp/qualification-state" or os.environ.get("OPENCLAW_CONFIG_PATH") != "/tmp/qualification-state/openclaw.json":
    parser.error("refusing to overwrite any non-qualification profile")
if Path("/workspace/agents").exists() or Path("/var/run/secrets/kubernetes.io/serviceaccount/token").exists():
    parser.error("agent workspace or service-account token must not be mounted")
sandbox=args.sandbox=='on'
root=Path('/tmp/native-qualification-'+args.sandbox); root.mkdir(exist_ok=True)
report={'sandboxRequested':sandbox,'headless':not args.headed,'checks':{}}
def run(command, timeout=60, env=None):
    p=subprocess.run(command,capture_output=True,text=True,timeout=timeout,env=env)
    if p.returncode:
        raise RuntimeError(f'{command[:3]} exit {p.returncode}: {(p.stderr or p.stdout)[-3000:]}')
    return p.stdout

def check_sandbox(text):
    if sandbox:
        for field in ['PID namespaces','Network namespaces','Seccomp-BPF sandbox']:
            assert re.search(re.escape(field)+r'\s+Yes',text), text
    return text

try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        # The default headless-shell executable is distinct from full Chromium.
        default_browser=p.chromium.launch(headless=True,chromium_sandbox=sandbox,args=["--enable-automation"])
        default_page=default_browser.new_page()
        default_page.set_content('<title>default headless shell</title>')
        assert default_page.title()=='default headless shell'
        default_page.screenshot(path=str(root/'python-headless-shell.png'))
        cdp=default_browser.new_browser_cdp_session()
        default_arguments=cdp.send('Browser.getBrowserCommandLine')['arguments']
        assert ('--no-sandbox' in default_arguments)==(not sandbox)
        report['checks']['pythonHeadlessShell']={'version':default_browser.version,'screenshot':True,'noSandboxArgument':'--no-sandbox' in default_arguments}
        default_browser.close()
        b=p.chromium.launch(headless=not args.headed,chromium_sandbox=sandbox,channel="chromium")
        page=b.new_page(accept_downloads=True)
        page.goto('chrome://sandbox')
        status=check_sandbox(page.inner_text('body'))
        page.goto('chrome://version')
        command=page.locator('#command_line').inner_text()
        assert ('--no-sandbox' not in command) if sandbox else ('--no-sandbox' in command)
        page.goto('about:blank')
        page.set_content('<title>synthetic browser fixture</title><a href="data:text/plain,fixture-only" download="fixture.txt">download</a>')
        assert page.title()=='synthetic browser fixture'
        page.screenshot(path=str(root/'python.png'))
        with page.expect_download() as download:
            page.get_by_text('download',exact=True).click()
        download.value.save_as(root/'python-download.txt')
        assert (root/'python-download.txt').read_text()=='fixture-only'
        report['checks']['python']={'version':b.version,'sandboxStatus':status,'noSandboxArgument':'--no-sandbox' in command,'screenshot':True,'download':True}
        b.close()
    node_script=r'''
const {chromium}=require('playwright');
(async()=>{
const sandbox=process.argv[1]==='on';
const defaultBrowser=await chromium.launch({headless:true,chromiumSandbox:sandbox,args:["--enable-automation"]});
const defaultPage=await defaultBrowser.newPage();
await defaultPage.setContent('<title>default headless shell</title>');
if(await defaultPage.title()!=='default headless shell')throw Error('headless-shell fixture title');
await defaultPage.screenshot({path:'/tmp/native-qualification-'+process.argv[1]+'/node-headless-shell.png'});
const cdp=await defaultBrowser.newBrowserCDPSession();
const defaultArguments=(await cdp.send('Browser.getBrowserCommandLine')).arguments;
if(defaultArguments.includes('--no-sandbox')===sandbox)throw Error('unexpected headless-shell sandbox flags');
await defaultBrowser.close();
const browser=await chromium.launch({headless:process.argv[2]!=="headed",chromiumSandbox:sandbox,channel:"chromium"});
const page=await browser.newPage({acceptDownloads:true});
await page.goto('chrome://sandbox');const status=await page.innerText('body');
await page.goto('chrome://version');const command=await page.locator('#command_line').innerText();
await page.goto('about:blank');
await page.setContent('<title>synthetic node fixture</title><a href="data:text/plain,fixture-only" download="fixture.txt">download</a>');
if(await page.title()!=='synthetic node fixture')throw Error('fixture title');
await page.screenshot({path:'/tmp/native-qualification-'+process.argv[1]+'/node.png'});
const wait=page.waitForEvent('download');await page.getByText('download',{exact:true}).click();
const download=await wait;await download.saveAs('/tmp/native-qualification-'+process.argv[1]+'/node-download.txt');
console.log(JSON.stringify({version:browser.version(),sandboxStatus:status,noSandboxArgument:command.includes('--no-sandbox'),screenshot:true,download:true,defaultHeadlessShell:{screenshot:true,noSandboxArgument:defaultArguments.includes("--no-sandbox")}}));
await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
'''
    node_result=json.loads(run(['node','-e',node_script,args.sandbox,'headed' if args.headed else 'headless']))
    check_sandbox(node_result['sandboxStatus'])
    assert node_result['noSandboxArgument'] == (not sandbox)
    assert (root/'node-download.txt').read_text()=='fixture-only'
    report['checks']['node']=node_result
    cfg={'gateway':{'mode':'local','bind':'loopback','port':18791,'auth':{'mode':'password','password':'synthetic-qualification-only'}},'browser':{'enabled':True,'headless':not args.headed,'noSandbox':not sandbox,'executablePath':'/usr/bin/chromium','defaultProfile':'openclaw','ssrfPolicy':{'dangerouslyAllowPrivateNetwork':True}},'plugins':{'allow':['browser'],'entries':{'browser':{'enabled':True}}}}
    Path(os.environ['OPENCLAW_CONFIG_PATH']).write_text(json.dumps(cfg))
    gatewaylog=open(root/'gateway.log','w')
    gateway=subprocess.Popen(['openclaw','gateway','run'],stdout=gatewaylog,stderr=subprocess.STDOUT)
    try:
        import socket
        for _ in range(60):
            if gateway.poll() is not None: raise RuntimeError('synthetic gateway exited: '+(root/'gateway.log').read_text()[-3000:])
            try:
                with socket.create_connection(('127.0.0.1',18791),timeout=1):break
            except OSError:time.sleep(1)
        else:raise RuntimeError('gateway not ready')
        cmd=['openclaw','browser','--password','synthetic-qualification-only','--json']
        started=run(cmd+['start'],timeout=90)
        started=json.loads(started)
        with sync_playwright() as p:
            attached=p.chromium.connect_over_cdp(started['cdpUrl'])
            page=attached.contexts[0].new_page()
            page.goto('chrome://sandbox')
            evaluated=check_sandbox(page.inner_text('body'))
            page.goto('chrome://version')
            native_command=page.locator('#command_line').inner_text()
            assert ('--no-sandbox' in native_command)==(not sandbox)
            page.close()
            attached.close()
        import http.server, threading
        class Fixture(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers()
                self.wfile.write(b'<title>openclaw-fixture</title><p>synthetic fixture</p>')
            def log_message(self,*args):pass
        server=http.server.HTTPServer(('127.0.0.1',8099),Fixture)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        run(cmd+['open','http://127.0.0.1:8099/'])
        title=run(cmd+['evaluate','--fn','() => document.title'])
        assert 'openclaw-fixture' in title

        screenshot=run(cmd+['screenshot'])
        report['checks']['openclaw']={'sandboxStatus':evaluated.strip(),'screenshot':True,'running':started['running'],'noSandboxArgument':'--no-sandbox' in native_command}
        run(cmd+['stop'])
    finally:
        gateway.terminate()
        try:gateway.wait(timeout=15)
        except subprocess.TimeoutExpired:gateway.kill();gateway.wait()
        gatewaylog.close()
    print(json.dumps(report,indent=2),flush=True)
except Exception as e:
    report['error']=str(e)
    print(json.dumps(report,indent=2),flush=True)
    sys.exit(1)
