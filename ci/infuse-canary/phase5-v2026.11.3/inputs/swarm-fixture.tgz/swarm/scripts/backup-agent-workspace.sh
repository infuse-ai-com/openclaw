#!/usr/bin/env bash
set -euo pipefail

namespace="${1:?Usage: $0 <namespace> <agent> <absolute-backup-directory>}"
agent="${2:?Usage: $0 <namespace> <agent> <absolute-backup-directory>}"
backup_directory="${3:?Usage: $0 <namespace> <agent> <absolute-backup-directory>}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

case "$agent" in
  agent-developer|agent-designer|agent-infra|agent-intake|agent-coordinator) ;;
  *) echo "Unsupported persistent agent: $agent" >&2; exit 2 ;;
esac
case "$backup_directory" in
  /*) ;;
  *) echo "Backup directory must be an absolute path." >&2; exit 2 ;;
esac
if [ "$backup_directory" = "/" ] || [ "$backup_directory" = "$HOME" ]; then
  echo "Refusing broad backup directory: $backup_directory" >&2
  exit 2
fi

for command in kubectl jq tar gzip shasum sqlite3 file; do
  command -v "$command" >/dev/null 2>&1 || {
    echo "Missing required command: $command" >&2
    exit 2
  }
done

umask 077
mkdir -p "$backup_directory"
backup_directory="$(cd -- "$backup_directory" && pwd -P)"
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
artifact="$backup_directory/${agent}-workspace-${timestamp}.tar.gz"
partial="$artifact.partial"
metadata="$artifact.json"
checksum="$artifact.sha256"
restore_directory="$(mktemp -d "$backup_directory/.${agent}-restore-verify.XXXXXX")"
backup_pod="${agent}-backup-$(date -u +%s)-$$"

kubectl_cmd=(kubectl)
if [ -n "${KUBE_CONTEXT:-}" ]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

prepared=false
pod=""
stopped=false
backup_pod_created=false
original_replicas=""
completed=false

run_helper() {
  if "${kubectl_cmd[@]}" -n "$namespace" exec "$pod" -c agent -- \
      test -x /usr/local/bin/openclaw-gateway-lifecycle >/dev/null 2>&1; then
    "${kubectl_cmd[@]}" -n "$namespace" exec "$pod" -c agent -- \
      /usr/local/bin/openclaw-gateway-lifecycle --profile "$agent" "$@"
  else
    "${kubectl_cmd[@]}" -n "$namespace" exec -i "$pod" -c agent -- \
      python3 - --profile "$agent" "$@" <"$script_dir/openclaw_gateway_lifecycle.py"
  fi
}

cleanup() {
  local exit_code=$?
  trap - EXIT
  set +e
  if [ "$backup_pod_created" = true ]; then
    "${kubectl_cmd[@]}" -n "$namespace" delete "pod/$backup_pod" \
      --ignore-not-found=true --wait=true --timeout=180s >/dev/null 2>&1
  fi
  if [ "$stopped" = true ] && [ -n "$original_replicas" ]; then
    "${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$agent" \
      --replicas="$original_replicas" >/dev/null 2>&1
    "${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$agent" \
      --timeout=600s >/dev/null 2>&1
  elif [ "$prepared" = true ] && [ -n "$pod" ]; then
    run_helper resume >/dev/null 2>&1
  fi
  if [ -d "$restore_directory" ]; then
    find "$restore_directory" -depth -delete >/dev/null 2>&1
  fi
  if [ "$completed" != true ]; then
    for incomplete in "$partial" "$artifact" "$metadata" "$checksum"; do
      if [ -f "$incomplete" ]; then
        find "$incomplete" -delete >/dev/null 2>&1
      fi
    done
  fi
  exit "$exit_code"
}
trap cleanup EXIT

pod_list="$("${kubectl_cmd[@]}" -n "$namespace" get pods \
  -l "app.kubernetes.io/name=$agent" -o json \
  | jq -r '[.items[] | select(.metadata.deletionTimestamp == null and .status.phase == "Running") | .metadata.name] | .[]')"
if [ "$(wc -w <<<"$pod_list" | tr -d ' ')" != "1" ]; then
  echo "Expected exactly one running non-terminating pod for $agent; found: ${pod_list:-none}." >&2
  exit 1
fi
pod="$pod_list"
original_replicas="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent" -o jsonpath='{.spec.replicas}')"
if [ "$original_replicas" != "1" ]; then
  echo "Expected deployment/$agent replicas=1 for an online backup; found $original_replicas." >&2
  exit 1
fi

image="$("${kubectl_cmd[@]}" -n "$namespace" get "pod/$pod" -o jsonpath='{.spec.containers[?(@.name=="agent")].image}')"
image_id="$("${kubectl_cmd[@]}" -n "$namespace" get "pod/$pod" -o jsonpath='{.status.containerStatuses[?(@.name=="agent")].imageID}')"
pod_uid="$("${kubectl_cmd[@]}" -n "$namespace" get "pod/$pod" -o jsonpath='{.metadata.uid}')"

echo "Draining $agent before creating its restricted-permission operator backup artifact."
prepare_result="$(run_helper prepare --drain-seconds "${OPENCLAW_BACKUP_DRAIN_SECONDS:-300}")"
prepared=true
jq -e '.status == "ready"' <<<"$prepare_result" >/dev/null

echo "Stopping deployment/$agent before mounting its single-writer PVC for backup."
"${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$agent" --replicas=0
stopped=true
"${kubectl_cmd[@]}" -n "$namespace" wait --for=delete "pod/$pod" --timeout=480s
prepared=false

backup_pod_created=true
cat <<YAML | "${kubectl_cmd[@]}" -n "$namespace" apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: ${backup_pod}
  labels:
    app.kubernetes.io/name: ${backup_pod}
    app.kubernetes.io/component: recovery-backup
spec:
  restartPolicy: Never
  activeDeadlineSeconds: 7200
  automountServiceAccountToken: false
  securityContext:
    runAsUser: 10001
    runAsGroup: 10001
    fsGroup: 10001
    seccompProfile:
      type: RuntimeDefault
  containers:
    - name: backup
      image: busybox:1.36
      command: ["sh", "-c", "sleep 7200"]
      securityContext:
        runAsNonRoot: true
        allowPrivilegeEscalation: false
        capabilities:
          drop: ["ALL"]
      volumeMounts:
        - name: workspace
          mountPath: /workspace
          readOnly: true
  volumes:
    - name: workspace
      persistentVolumeClaim:
        claimName: ${agent}-workspace
        readOnly: true
YAML
"${kubectl_cmd[@]}" -n "$namespace" wait --for=condition=Ready "pod/$backup_pod" --timeout=180s

transfer_verified=false
for transfer_attempt in 1 2; do
  rm -f "$partial"
  if "${kubectl_cmd[@]}" -n "$namespace" exec "$backup_pod" -c backup -- \
      tar -C /workspace --exclude=node_modules -cf - . \
      | gzip -1 >"$partial" \
    && chmod 600 "$partial" \
    && gzip -t "$partial" \
    && tar -tzf "$partial" >/dev/null; then
    transfer_verified=true
    break
  fi
  echo "Backup transfer attempt $transfer_attempt failed validation for $agent." >&2
done
if [[ "$transfer_verified" != "true" ]]; then
  echo "Backup transfer failed validation twice for $agent." >&2
  exit 1
fi

"${kubectl_cmd[@]}" -n "$namespace" delete "pod/$backup_pod" \
  --wait=true --timeout=180s >/dev/null
backup_pod_created=false
"${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$agent" --replicas="$original_replicas" >/dev/null
"${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$agent" --timeout=600s
stopped=false

tar -xzf "$partial" -C "$restore_directory"
database_count=0
while IFS= read -r -d '' database; do
  if file "$database" | grep -F "SQLite" >/dev/null; then
    sqlite3 "$database" 'PRAGMA quick_check;' | grep -Fx ok >/dev/null
    database_count=$((database_count + 1))
  fi
done < <(find "$restore_directory" -type f \( -name '*.sqlite' -o -name '*.sqlite3' -o -name '*.db' \) -print0)

artifact_sha256="$(shasum -a 256 "$partial" | awk '{print $1}')"
mv "$partial" "$artifact"
jq -n \
  --arg schema "infuse.openclaw-agent-workspace-backup/v1" \
  --arg createdAt "$timestamp" \
  --arg namespace "$namespace" \
  --arg agent "$agent" \
  --arg podUid "$pod_uid" \
  --arg image "$image" \
  --arg imageId "$image_id" \
  --arg sha256 "$artifact_sha256" \
  --argjson sqliteQuickChecks "$database_count" \
  '{schema:$schema,createdAt:$createdAt,namespace:$namespace,agent:$agent,podUid:$podUid,image:$image,imageId:$imageId,sha256:$sha256,scope:{excludedDirectoryBasenames:["node_modules"],rationale:"reproducible_dependencies"},verification:{gzip:true,tarListing:true,fullRestore:true,sqliteQuickChecks:$sqliteQuickChecks}}' \
  >"$metadata"
printf '%s  %s\n' "$artifact_sha256" "$(basename "$artifact")" >"$checksum"
chmod 600 "$artifact" "$metadata" "$checksum"

completed=true
echo "Verified recovery artifact: $artifact"
echo "SHA-256: $artifact_sha256"
