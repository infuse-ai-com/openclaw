#!/usr/bin/env python3
"""Synthetic fixture for the disposable security worker prototype, never a service."""
import argparse
import base64
import hashlib
import http.server
import json
import os
from pathlib import Path
import re
import socket
import stat
import subprocess
import threading

ROOT = Path('/tmp/worker-output')
MAX_BYTES = 1024 * 1024
ALLOWED = {'receipt.json', 'browser.png', 'download.txt', 'build.txt',
           'image.png', 'image.jpg', 'contact.png', 'image.pdf'}


def export_files(root=ROOT):
    """No tar, recursive paths, symlinks, special files, or unbounded payloads."""
    payload = {}
    total = 0
    for p in sorted(root.iterdir()):
        if p.name not in ALLOWED or not stat.S_ISREG(p.lstat().st_mode):
            raise ValueError('unexpected artifact path or type')
        descriptor = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(descriptor, 'rb') as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_BYTES:
                raise ValueError('artifact type or size invalid')
            data = stream.read(MAX_BYTES + 1)
        total += len(data)
        if total > MAX_BYTES:
            raise ValueError('artifact bundle too large')
        payload[p.name] = {'sha256': hashlib.sha256(data).hexdigest(),
                           'base64': base64.b64encode(data).decode('ascii')}
    return payload


def qualify(role):
    assert os.environ.get('OPENCLAW_WORKER_PROTOTYPE') == 'synthetic-only'
    assert os.getuid() == 10001
    assert not Path('/workspace/agents').exists()
    assert not Path('/var/run/secrets/kubernetes.io/serviceaccount/token').exists()
    assert not Path('/var/run/docker.sock').exists()
    assert not Path(os.environ['WORKER_UNMOUNTED_CANARY_PATH']).exists()
    assert not any(re.search(r'(TOKEN|PASSWORD|CREDENTIAL|BW_SESSION|OPERATOR_CANARY)', k)
                   for k in os.environ)
    ROOT.mkdir()
    report = {'role': role, 'syntheticOnly': True, 'checks': {
        'nonroot': True, 'noAgentWorkspace': True, 'noApiToken': True,
        'noDockerSocket': True, 'noCredentialEnvironment': True,
        'operatorCanaryAbsent': True}}
    blocked = []
    for label, host, port in [('control-plane', os.environ['KUBERNETES_SERVICE_HOST'], 443),
                              ('metadata', '169.254.169.254', 80),
                              ('external', '1.1.1.1', 443)]:
        try:
            with socket.create_connection((host, port), timeout=2):
                raise AssertionError('unexpected network connection: ' + label)
        except OSError:
            blocked.append(label)
    report['checks']['blockedTcpDestinations'] = blocked
    if role == 'browser':
        from playwright.sync_api import sync_playwright

        class Fixture(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == '/download':
                    self.send_response(200)
                    self.send_header('Content-Disposition', 'attachment; filename=download.txt')
                    body = b'synthetic worker download'
                else:
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/html')
                    self.send_header('Set-Cookie', 'task-session=synthetic-only; SameSite=Strict')
                    body = b'<title>worker fixture</title><a href="/download">download</a>'
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_args):
                pass

        server = http.server.HTTPServer(('127.0.0.1', 8098), Fixture)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        with sync_playwright() as p:
            browser = p.chromium.launch(channel='chromium', chromium_sandbox=True)
            context = browser.new_context(accept_downloads=True)
            page = context.new_page()
            page.goto('chrome://sandbox')
            status = page.inner_text('body')
            for field in ['PID namespaces', 'Network namespaces', 'Seccomp-BPF sandbox']:
                assert re.search(re.escape(field) + r'\s+Yes', status)
            page.goto('chrome://version')
            assert '--no-sandbox' not in page.locator('#command_line').inner_text()
            page.goto('http://127.0.0.1:8098/')
            assert page.title() == 'worker fixture'
            page.screenshot(path=str(ROOT / 'browser.png'))
            with page.expect_download() as download:
                page.get_by_text('download', exact=True).click()
            download.value.save_as(ROOT / 'download.txt')
            state = context.storage_state()
            assert any(c['name'] == 'task-session' for c in state['cookies'])
            resumed = browser.new_context(storage_state=state)
            assert any(c['name'] == 'task-session' and c['value'] == 'synthetic-only'
                       for c in resumed.cookies('http://127.0.0.1:8098/'))
            resumed.close()
            context.close()
            report['browserVersion'] = browser.version
            browser.close()
        server.shutdown()
        report['checks'].update(sandbox=True, screenshot=True, download=True,
                                syntheticSessionRoundTrip=True)
    elif role == 'build':
        source = Path('/tmp/fixture.c')
        source.write_text('#include <stdio.h>\nint main(void){puts("synthetic-build-ok");return 0;}\n')
        subprocess.run(['cc', '-Werror', '-Wall', str(source), '-o', '/tmp/fixture'], check=True, timeout=30)
        result = subprocess.check_output(['/tmp/fixture'], timeout=5)
        assert result == b'synthetic-build-ok\n'
        (ROOT / 'build.txt').write_bytes(result)
        report['checks']['nativeCompilation'] = True
    elif role == 'media':
        def media(command):
            return subprocess.check_output(command, timeout=20)
        media(['convert', '-size', '128x96', 'xc:#2d78b4', str(ROOT / 'image.png')])
        media(['convert', str(ROOT / 'image.png'), str(ROOT / 'image.jpg')])
        media(['montage', str(ROOT / 'image.png'), str(ROOT / 'image.jpg'),
               '-tile', '2x1', '-geometry', '+0+0', str(ROOT / 'contact.png')])
        assert media(['identify', '-format', '%wx%h', str(ROOT / 'contact.png')]) == b'256x96'
        # Tiny synthetic PDF fixture: exercise the shipped PDF reader without
        # adding an undeclared Python imaging dependency or relaxing IM policy.
        stream = b'BT /F1 12 Tf 20 50 Td (synthetic media fixture) Tj ET'
        objects = [b'<< /Type /Catalog /Pages 2 0 R >>',
                   b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
                   b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 100] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
                   b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
                   b'<< /Length ' + str(len(stream)).encode() + b' >>\nstream\n' + stream + b'\nendstream']
        pdf = b'%PDF-1.4\n'
        offsets = [0]
        for index, body in enumerate(objects, 1):
            offsets.append(len(pdf))
            pdf += str(index).encode() + b' 0 obj\n' + body + b'\nendobj\n'
        xref = len(pdf)
        pdf += b'xref\n0 6\n0000000000 65535 f \n'
        pdf += b''.join(f'{offset:010} 00000 n \n'.encode() for offset in offsets[1:])
        pdf += b'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n' + str(xref).encode() + b'\n%%EOF\n'
        (ROOT / 'image.pdf').write_bytes(pdf)
        media(['pdfinfo', str(ROOT / 'image.pdf')])
        assert b'synthetic media fixture' in media(['pdftotext', str(ROOT / 'image.pdf'), '-'])
        report['checks']['pngJpegPdfContactSheet'] = True
    (ROOT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['browser', 'build', 'media', 'export'])
    args = parser.parse_args()
    if args.action == 'export':
        print(json.dumps(export_files()))
    else:
        qualify(args.action)
