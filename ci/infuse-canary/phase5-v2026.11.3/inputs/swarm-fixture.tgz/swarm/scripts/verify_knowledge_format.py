#!/usr/bin/env python3
"""Dependency-free, read-only validator for Infuse Knowledge Format v1."""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from urllib.parse import unquote as url_unquote, urlparse

FORMAT = "infuse-knowledge/1"
TYPES = {
    "overview", "guide", "reference", "policy", "standard", "decision",
    "architecture", "runbook", "plan", "report", "evidence", "memory",
    "skill", "persona", "template",
}
STATUSES = {"draft", "active", "deprecated", "superseded"}
SLUG = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")
OWNER = re.compile(r"^(?:human|team):[a-z0-9][a-z0-9-]{0,62}$")
TOP_LEVEL = re.compile(r"^([A-Za-z_][A-Za-z0-9_-]*)\s*:\s*(.*?)\s*$")
MANIFEST_KEYS = {
    "version", "displayName", "owner", "defaultBranch", "roots", "include",
    "exclude", "tags", "aliases", "knowledgeFormat",
}


@dataclass(frozen=True)
class Finding:
    path: str
    code: str
    message: str
    line: int | None = None


def unquote(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] == '"':
        try:
            decoded = json.loads(value)
            return decoded if isinstance(decoded, str) else value
        except json.JSONDecodeError:
            return value[1:-1]
    if len(value) >= 2 and value[0] == value[-1] == "'":
        return value[1:-1].replace("''", "'")
    return value


def inline_list(value: str) -> list[str] | None:
    value = value.strip()
    if not (value.startswith("[") and value.endswith("]")):
        return None
    body = value[1:-1].strip()
    if not body:
        return []
    return [unquote(item) for item in body.split(",")]


def top_level_entries(source: str) -> tuple[dict[str, tuple[str, int]], list[Finding]]:
    entries: dict[str, tuple[str, int]] = {}
    findings: list[Finding] = []
    for number, line in enumerate(source.splitlines(), start=1):
        if "\t" in line:
            findings.append(Finding("", "yaml_tab", "YAML must use spaces", number))
        match = TOP_LEVEL.match(line)
        if not match:
            continue
        key, raw = match.groups()
        if key in entries:
            findings.append(Finding("", "duplicate_key", f"duplicate top-level key: {key}", number))
        else:
            entries[key] = (raw, number)
    return entries, findings


def block_list(source: str, key: str) -> list[str]:
    lines = source.splitlines()
    values: list[str] = []
    active = False
    for line in lines:
        match = TOP_LEVEL.match(line)
        if match:
            active = match.group(1) == key and match.group(2) == ""
            continue
        if not active:
            continue
        item = re.match(r"^\s{2}-\s+(.+?)\s*$", line)
        if item:
            values.append(unquote(item.group(1)))
            continue
        if line.strip() and not line.startswith((" ", "\t")):
            break
    return values


def list_value(source: str, entries: dict[str, tuple[str, int]], key: str) -> list[str]:
    raw = entries.get(key, ("", 0))[0]
    parsed = inline_list(raw)
    return parsed if parsed is not None else block_list(source, key)


def scalar_value(source: str, entries: dict[str, tuple[str, int]], key: str) -> str | None:
    entry = entries.get(key)
    if entry is None:
        return None
    raw, line_number = entry
    if raw in {"", "|", "|-", "|+", ">", ">-", ">+"}:
        return None
    lines = source.splitlines()
    continuation: list[str] = []
    for line in lines[line_number:]:
        if line.startswith("  ") and not re.match(r"^\s{2}-\s", line):
            stripped = line.strip()
            if stripped:
                continuation.append(stripped)
                continue
        break
    return unquote(" ".join([raw, *continuation]).strip())


def git_glob(path: str, pattern: str) -> bool:
    expression = ""
    index = 0
    while index < len(pattern):
        character = pattern[index]
        if character == "*":
            if index + 1 < len(pattern) and pattern[index + 1] == "*":
                index += 2
                if index < len(pattern) and pattern[index] == "/":
                    index += 1
                    expression += "(?:.*/)?"
                else:
                    expression += ".*"
                continue
            expression += "[^/]*"
        elif character == "?":
            expression += "[^/]"
        else:
            expression += re.escape(character)
        index += 1
    return re.fullmatch(expression, path) is not None


def selected_files(root: Path, manifest: str, entries: dict[str, tuple[str, int]]) -> list[Path]:
    roots = list_value(manifest, entries, "roots")
    includes = list_value(manifest, entries, "include") or ["README.md", "**/*.md"]
    excludes = list_value(manifest, entries, "exclude")
    files: list[Path] = []
    for path in root.rglob("*.md"):
        relative = path.relative_to(root).as_posix()
        if any(part.startswith(".") for part in Path(relative).parts):
            continue
        if any(part in {".git", "node_modules", "dist", "build", "coverage"} for part in path.parts):
            continue
        if roots and not any(relative == item or relative.startswith(item.rstrip("/") + "/") for item in roots):
            continue
        if not any(git_glob(relative, pattern) for pattern in includes):
            continue
        if any(git_glob(relative, pattern) for pattern in excludes):
            continue
        files.append(path)
    return sorted(files)


def source_entries(frontmatter: str) -> tuple[list[tuple[str, str, int]], list[Finding]]:
    entries: list[tuple[str, str, int]] = []
    findings: list[Finding] = []
    active = False
    current_ref: str | None = None
    current_role: str | None = None
    current_line = 0

    def finish() -> None:
        nonlocal current_ref, current_role, current_line
        if current_ref is not None or current_role is not None:
            if not current_ref or not current_role:
                findings.append(Finding("", "source_invalid", "each source requires ref and role", current_line or None))
            else:
                entries.append((current_ref, current_role, current_line))
        current_ref = None
        current_role = None
        current_line = 0

    for number, line in enumerate(frontmatter.splitlines(), start=2):
        if line == "sources:":
            active = True
            continue
        if active and line and not line.startswith(" "):
            finish()
            break
        if not active:
            continue
        first = re.match(r"^\s{2}-\s+ref\s*:\s*(.+?)\s*$", line)
        if first:
            finish()
            current_ref = unquote(first.group(1))
            current_line = number
            continue
        role = re.match(r"^\s{4}role\s*:\s*(.+?)\s*$", line)
        if role and current_ref is not None:
            current_role = unquote(role.group(1))
            continue
        if line.strip() and not line.startswith("    "):
            findings.append(Finding("", "source_invalid", "sources must use '- ref' followed by 'role'", number))
    if active:
        finish()
    return entries, findings


def validate_ref(root: Path, document: Path, value: str) -> str | None:
    parsed = urlparse(value)
    if parsed.scheme:
        return None if parsed.scheme == "https" and parsed.netloc else "must be repository-relative or HTTPS"
    clean = value.split("#", 1)[0].split("?", 1)[0]
    if "\\" in clean or clean.startswith("/") or "\0" in clean:
        return "must stay within the repository or use HTTPS"
    candidate = (document.parent / url_unquote(clean)).resolve() if clean else document.resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        return "must stay within the repository or use HTTPS"
    return None if candidate.exists() else "does not resolve to an existing repository path"


def review_cadence(frontmatter: str) -> tuple[int | None, int | None]:
    active = False
    for number, line in enumerate(frontmatter.splitlines(), start=2):
        if line == "review:":
            active = True
            continue
        if active and line and not line.startswith(" "):
            break
        if active:
            match = re.match(r"^\s{2}cadence_days\s*:\s*(.+?)\s*$", line)
            if match:
                try:
                    return int(unquote(match.group(1))), number
                except ValueError:
                    return -1, number
    return None, None


def validate_document(root: Path, path: Path) -> list[Finding]:
    relative = path.relative_to(root).as_posix()
    source = path.read_text(encoding="utf-8")
    if not source.startswith("---\n"):
        return [Finding(relative, "frontmatter_missing", "document must start with YAML frontmatter", 1)]
    closing = source.find("\n---\n", 4)
    if closing < 0:
        return [Finding(relative, "frontmatter_unclosed", "frontmatter closing delimiter is missing", 1)]
    frontmatter = source[4:closing]
    entries, findings = top_level_entries(frontmatter)
    findings = [Finding(relative, item.code, item.message, item.line) for item in findings]

    required = ["title", "description", "type", "status", "owner", "tags"]
    for key in required:
        if key not in entries:
            findings.append(Finding(relative, "field_missing", f"required field is missing: {key}"))

    title = scalar_value(frontmatter, entries, "title")
    description = scalar_value(frontmatter, entries, "description")
    document_type = scalar_value(frontmatter, entries, "type")
    status = scalar_value(frontmatter, entries, "status")
    owner = scalar_value(frontmatter, entries, "owner")
    tags = list_value(frontmatter, entries, "tags")

    if title is not None and not 1 <= len(title.strip()) <= 160:
        findings.append(Finding(relative, "title_invalid", "title must contain 1-160 characters"))
    if description is not None and not (20 <= len(description.strip()) <= 240 and re.search(r"[.!?]$", description.strip())):
        findings.append(Finding(relative, "description_invalid", "description must contain 20-240 characters and end with sentence punctuation"))
    if document_type is not None and document_type not in TYPES:
        findings.append(Finding(relative, "type_invalid", f"unsupported document type: {document_type}"))
    if status is not None and status not in STATUSES:
        findings.append(Finding(relative, "status_invalid", f"unsupported document status: {status}"))
    if owner is not None and not OWNER.fullmatch(owner):
        findings.append(Finding(relative, "owner_invalid", "owner must be human:<slug> or team:<slug>"))
    if not 1 <= len(tags) <= 8 or len(tags) != len(set(tags)) or any(not SLUG.fullmatch(tag) for tag in tags):
        findings.append(Finding(relative, "tags_invalid", "tags must contain 1-8 unique lowercase slugs"))

    sources, source_findings = source_entries(frontmatter)
    findings.extend(Finding(relative, item.code, item.message, item.line) for item in source_findings)
    if len(sources) > 32:
        findings.append(Finding(relative, "sources_invalid", "sources may contain at most 32 entries"))
    for reference, role, line in sources:
        if len(reference) > 512 or not SLUG.fullmatch(role):
            findings.append(Finding(relative, "source_invalid", "source ref or role is invalid", line))
            continue
        error = validate_ref(root, path, reference)
        if error:
            findings.append(Finding(relative, "source_reference_invalid", f"{reference}: {error}", line))

    superseded_by = scalar_value(frontmatter, entries, "superseded_by")
    if status == "superseded" and not superseded_by:
        findings.append(Finding(relative, "supersession_missing", "superseded documents require superseded_by"))
    if superseded_by:
        error = validate_ref(root, path, superseded_by)
        if error:
            findings.append(Finding(relative, "supersession_invalid", f"{superseded_by}: {error}"))

    cadence, cadence_line = review_cadence(frontmatter)
    if cadence is not None and not 1 <= cadence <= 3650:
        findings.append(Finding(relative, "review_invalid", "review.cadence_days must be an integer from 1 to 3650", cadence_line))
    return findings


def verify(root: Path) -> tuple[list[Path], list[Finding]]:
    manifest_path = root / ".knowledge-base.yml"
    if not manifest_path.is_file():
        return [], [Finding(".knowledge-base.yml", "manifest_missing", "repository manifest is required")]
    manifest = manifest_path.read_text(encoding="utf-8")
    entries, findings = top_level_entries(manifest)
    output = [Finding(".knowledge-base.yml", item.code, item.message, item.line) for item in findings]
    unknown = sorted(set(entries) - MANIFEST_KEYS)
    if unknown:
        output.append(Finding(".knowledge-base.yml", "manifest_unknown_key", f"unknown manifest keys: {', '.join(unknown)}"))
    if scalar_value(manifest, entries, "version") != "1":
        output.append(Finding(".knowledge-base.yml", "manifest_version_invalid", "version must be 1"))
    if scalar_value(manifest, entries, "knowledgeFormat") != FORMAT:
        output.append(Finding(".knowledge-base.yml", "manifest_format_invalid", f"knowledgeFormat must be {FORMAT}"))
    for field in ("roots", "include", "exclude"):
        values = list_value(manifest, entries, field)
        if len(values) > 100 or any(not value or len(value) > 512 or value.startswith("/") or "\\" in value or ".." in value.split("/") for value in values):
            output.append(Finding(".knowledge-base.yml", f"manifest_{field}_invalid", f"{field} contains an unsafe pattern"))
    files = selected_files(root, manifest, entries) if not output else []
    for path in files:
        output.extend(validate_document(root, path))
    return files, output


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    files, findings = verify(root)
    payload = {"format": FORMAT, "documents": len(files), "findings": [asdict(item) for item in findings]}
    if args.json:
        print(json.dumps(payload, indent=2))
    elif findings:
        for item in findings:
            location = f"{item.path}:{item.line}" if item.line else item.path
            print(f"{location}: {item.code}: {item.message}", file=sys.stderr)
    else:
        print(f"IKF verification passed format={FORMAT} documents={len(files)}")
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
