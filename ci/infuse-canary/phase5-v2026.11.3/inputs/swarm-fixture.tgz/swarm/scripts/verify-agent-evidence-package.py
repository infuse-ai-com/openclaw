#!/usr/bin/env python3
"""Verify that a review artifact is portable outside the producing agent pod."""

from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


MAX_ARCHIVE_FILES = 10_000
MAX_ARCHIVE_BYTES = 2 * 1024 * 1024 * 1024
MAX_SCANNED_FILE_BYTES = 2 * 1024 * 1024
TEXT_SUFFIXES = {
    ".cjs",
    ".css",
    ".html",
    ".js",
    ".json",
    ".md",
    ".mjs",
    ".sh",
    ".ts",
    ".yaml",
    ".yml",
}
HOST_PATH_PATTERNS = {
    "/workspace/agents/": "agent_workspace_path",
}
PLAYWRIGHT_IMPORT_RE = re.compile(
    r"(?:require\s*\(\s*|from\s+|import\s*)['\"](?:playwright|@playwright/test)['\"]"
)
LOCKFILE_NAMES = {
    "npm-shrinkwrap.json",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
}


class PackageError(RuntimeError):
    """Raised when the input artifact is unsafe or unsupported."""


def tail(value: str, limit: int = 40) -> str:
    lines = value.rstrip().splitlines()
    return "\n".join(lines[-limit:])


def safe_extract_zip(archive: Path, destination: Path) -> None:
    with zipfile.ZipFile(archive) as package:
        members = package.infolist()
        if len(members) > MAX_ARCHIVE_FILES:
            raise PackageError(
                f"archive has {len(members)} entries; limit is {MAX_ARCHIVE_FILES}"
            )
        total_bytes = sum(member.file_size for member in members)
        if total_bytes > MAX_ARCHIVE_BYTES:
            raise PackageError(
                f"archive expands to {total_bytes} bytes; limit is {MAX_ARCHIVE_BYTES}"
            )
        for member in members:
            name = PurePosixPath(member.filename)
            if name.is_absolute() or ".." in name.parts:
                raise PackageError(f"archive contains unsafe path: {member.filename}")
            mode = member.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise PackageError(f"archive contains unsupported symlink: {member.filename}")
        package.extractall(destination)


def reject_directory_symlinks(root: Path) -> None:
    for entry in root.rglob("*"):
        if entry.is_symlink():
            relative = entry.relative_to(root)
            raise PackageError(f"directory contains unsupported symlink: {relative}")


def materialize(package_path: Path, destination: Path) -> Path:
    if package_path.is_dir():
        reject_directory_symlinks(package_path)
        copied = destination / "package"
        shutil.copytree(package_path, copied, symlinks=False)
        return copied
    if package_path.is_file() and package_path.suffix.lower() == ".zip":
        safe_extract_zip(package_path, destination)
        entries = [entry for entry in destination.iterdir() if entry.name != "__MACOSX"]
        if len(entries) == 1 and entries[0].is_dir():
            return entries[0]
        return destination
    raise PackageError("package must be a directory or .zip archive")


def load_package_json(root: Path) -> dict[str, Any] | None:
    path = root / "package.json"
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackageError(f"invalid package.json: {exc}") from exc
    if not isinstance(payload, dict):
        raise PackageError("package.json must contain a JSON object")
    return payload


def declared_node_dependencies(package_json: dict[str, Any] | None) -> set[str]:
    if package_json is None:
        return set()
    result: set[str] = set()
    for key in ("dependencies", "devDependencies", "optionalDependencies"):
        values = package_json.get(key, {})
        if isinstance(values, dict):
            result.update(str(name) for name in values)
    return result


def scan_package(root: Path) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    playwright_users: list[str] = []
    verify_path = root / "VERIFY.md"
    verify_text = ""
    if not verify_path.is_file():
        findings.append(
            {
                "code": "missing_verification_instructions",
                "path": "VERIFY.md",
                "message": "executable evidence packages require exact fresh-copy commands in VERIFY.md",
            }
        )
    else:
        verify_text = verify_path.read_text(encoding="utf-8")
    bundled_playwright = any(
        (root / path).is_file()
        for path in (
            "node_modules/playwright/package.json",
            "node_modules/@playwright/test/package.json",
        )
    )
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        relative_path = path.relative_to(root)
        if any(part in {".git", "node_modules", "vendor"} for part in relative_path.parts):
            continue
        try:
            if path.stat().st_size > MAX_SCANNED_FILE_BYTES:
                continue
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        relative = relative_path.as_posix()
        if PLAYWRIGHT_IMPORT_RE.search(content):
            playwright_users.append(relative)
        for needle, code in HOST_PATH_PATTERNS.items():
            if needle in content:
                findings.append(
                    {
                        "code": code,
                        "path": relative,
                        "message": f"host-specific path is not portable: {needle}",
                    }
                )
        if "/opt/agent-node-toolbox" in content and not (
            bundled_playwright
            and "PACKAGED_RUNTIME_ONLY" in content
            and "PACKAGED_RUNTIME_ONLY" in verify_text
        ):
            findings.append(
                {
                    "code": "agent_toolbox_path",
                    "path": relative,
                    "message": "agent-toolbox fallback requires bundled Playwright and a documented PACKAGED_RUNTIME_ONLY gate",
                }
            )
        if (
            "/usr/bin/chromium" in content
            and "CHROMIUM_PATH" not in content
            and "CHROMIUM_PATH" not in verify_text
        ):
            findings.append(
                {
                    "code": "fixed_chromium_path",
                    "path": relative,
                    "message": "fixed Chromium path requires a CHROMIUM_PATH override or managed-browser resolution",
                }
            )

    package_json = load_package_json(root)
    dependencies = declared_node_dependencies(package_json)
    declared_playwright = bool({"playwright", "@playwright/test"} & dependencies)
    if playwright_users and not (bundled_playwright or declared_playwright):
        findings.append(
            {
                "code": "undeclared_playwright_dependency",
                "path": playwright_users[0],
                "message": "Playwright is imported but is neither bundled nor declared in package.json",
            }
        )
    if playwright_users and declared_playwright and not bundled_playwright:
        if not any((root / name).is_file() for name in LOCKFILE_NAMES):
            findings.append(
                {
                    "code": "missing_node_lockfile",
                    "path": "package.json",
                    "message": "declared Playwright requires a checked-in lockfile for reproducible installation",
                }
            )
    return findings


def classify_failure(stderr: str, stdout: str) -> str:
    combined = f"{stderr}\n{stdout}".lower()
    tooling_markers = (
        "cannot find module",
        "command not found",
        "executable doesn't exist",
        "playwright is unavailable",
        "no such file or directory",
    )
    if any(marker in combined for marker in tooling_markers):
        return "tooling_gap"
    return "command_failed"


def packaged_runtime_env_names(root: Path) -> list[str]:
    names: set[str] = set()
    pattern = re.compile(r"process\.env\.([A-Z][A-Z0-9_]*PACKAGED_RUNTIME_ONLY)")
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        relative = path.relative_to(root)
        if any(part in {".git", "node_modules", "vendor"} for part in relative.parts):
            continue
        try:
            if path.stat().st_size <= MAX_SCANNED_FILE_BYTES:
                names.update(pattern.findall(path.read_text(encoding="utf-8")))
        except (OSError, UnicodeDecodeError):
            continue
    return sorted(names)


def isolated_environment(strict_env_names: list[str] | None = None) -> dict[str, str]:
    env = os.environ.copy()
    env.pop("NODE_PATH", None)
    existing_node_options = env.get("NODE_OPTIONS", "").strip()
    if "--no-global-search-paths" not in existing_node_options.split():
        env["NODE_OPTIONS"] = (
            f"{existing_node_options} --no-global-search-paths".strip()
        )
    env["OPENCLAW_AGENT_TOOLBOX_DISABLED"] = "1"
    for name in strict_env_names or []:
        env[name] = "1"
    return env


def run_commands(root: Path, commands: list[str], timeout: int) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    env = isolated_environment(packaged_runtime_env_names(root))
    for command in commands:
        try:
            argv = shlex.split(command)
        except ValueError as exc:
            results.append(
                {
                    "command": command,
                    "exitCode": 2,
                    "classification": "command_failed",
                    "stdoutTail": "",
                    "stderrTail": f"invalid command syntax: {exc}",
                }
            )
            break
        if not argv:
            results.append(
                {
                    "command": command,
                    "exitCode": 2,
                    "classification": "command_failed",
                    "stdoutTail": "",
                    "stderrTail": "empty command",
                }
            )
            break
        try:
            completed = subprocess.run(
                argv,
                cwd=root,
                env=env,
                capture_output=True,
                check=False,
                text=True,
                timeout=timeout,
            )
            classification = (
                "verification_passed"
                if completed.returncode == 0
                else classify_failure(completed.stderr, completed.stdout)
            )
            result = {
                "command": command,
                "exitCode": completed.returncode,
                "classification": classification,
                "stdoutTail": tail(completed.stdout),
                "stderrTail": tail(completed.stderr),
            }
        except FileNotFoundError as exc:
            result = {
                "command": command,
                "exitCode": 127,
                "classification": "tooling_gap",
                "stdoutTail": "",
                "stderrTail": str(exc),
            }
        except subprocess.TimeoutExpired as exc:
            result = {
                "command": command,
                "exitCode": 124,
                "classification": "command_failed",
                "stdoutTail": tail(exc.stdout or ""),
                "stderrTail": tail(exc.stderr or "") or f"timed out after {timeout}s",
            }
        results.append(result)
        if result["exitCode"] != 0:
            break
    return results


def render_human(payload: dict[str, Any]) -> None:
    print(f"package={payload['package']}")
    print(f"isolated_copy={payload['isolatedCopy']}")
    for finding in payload["findings"]:
        print(
            f"finding={finding['code']} path={finding['path']} message={finding['message']}",
            file=sys.stderr,
        )
    for result in payload["commands"]:
        print(
            f"command={result['command']} exit_code={result['exitCode']} "
            f"classification={result['classification']}"
        )
        if result["stdoutTail"]:
            print("stdout_tail:\n" + result["stdoutTail"])
        if result["stderrTail"]:
            print("stderr_tail:\n" + result["stderrTail"], file=sys.stderr)
    print(f"portable_evidence={payload['verdict']}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        epilog=(
            "Example: openclaw-agent-evidence-verify artifact.zip "
            "--command 'node build-native.js' --command 'node verify-native.js'"
        ),
    )
    parser.add_argument("package", help="Artifact directory or ZIP archive")
    parser.add_argument(
        "--command",
        action="append",
        default=[],
        help="Command to run from the isolated package root; repeat in execution order",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Run static portability checks without claiming executable verification",
    )
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    parser.add_argument(
        "--timeout",
        type=int,
        default=120,
        help="Per-command timeout in seconds (default: 120)",
    )
    args = parser.parse_args()
    if not args.command and not args.check_only:
        parser.error("pass at least one --command, or use --check-only")
    if args.timeout < 1 or args.timeout > 1800:
        parser.error("--timeout must be between 1 and 1800 seconds")

    source = Path(args.package).expanduser().resolve()
    try:
        with tempfile.TemporaryDirectory(prefix="openclaw-evidence-") as temp:
            isolated_root = materialize(source, Path(temp))
            findings = scan_package(isolated_root)
            command_results = (
                []
                if findings or args.check_only
                else run_commands(isolated_root, args.command, args.timeout)
            )
            commands_passed = bool(command_results) and all(
                result["exitCode"] == 0 for result in command_results
            )
            if findings:
                verdict = "not_verified"
            elif args.check_only:
                verdict = "static_checks_passed"
            else:
                verdict = "verified" if commands_passed else "not_verified"
            payload = {
                "schemaVersion": 1,
                "package": str(source),
                "isolatedCopy": True,
                "ambientNodePathRemoved": True,
                "globalNodeSearchDisabled": True,
                "agentToolboxFallbackDisabled": True,
                "packageStrictModeVariables": packaged_runtime_env_names(isolated_root),
                "findings": findings,
                "commands": command_results,
                "verdict": verdict,
            }
    except (OSError, PackageError, zipfile.BadZipFile) as exc:
        payload = {
            "schemaVersion": 1,
            "package": str(source),
            "isolatedCopy": False,
            "findings": [
                {
                    "code": "invalid_package",
                    "path": str(source),
                    "message": str(exc),
                }
            ],
            "commands": [],
            "verdict": "not_verified",
        }

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        render_human(payload)
    return 0 if payload["verdict"] in {"verified", "static_checks_passed"} else 1


if __name__ == "__main__":
    sys.exit(main())
