#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"
kube_context="${KUBE_CONTEXT:-infuseai-k8s}"
deployment="agent-developer"
image_repository="registry.infuse-ai-tech.party/agents-swarm/openclaw-agent"
image_ref="${1:?Usage: $0 registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:observability-<build>-3d1a6e419}"
expected_baseline_digest="${EXPECTED_BASELINE_DIGEST:-sha256:77a705b4b51752a16303a1c78fc22084e44cddef6f635d64a4dbd578c36f6977}"
collector_manifest="k8s/overlays/infuseai/otel-collector.yaml"
other_deployments=(agent-coordinator agent-designer agent-infra agent-intake)

if [[ "$image_ref" != "$image_repository":observability-*-3d1a6e419 ]]; then
  echo "Refusing image outside the reviewed observability canary family: $image_ref" >&2
  exit 1
fi

for command in kubectl jq; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "Missing required command: $command" >&2
    exit 1
  fi
done

kubectl_cmd=(kubectl --context "$kube_context")
workdir="$(mktemp -d)"
developer_changed=false
current_revision=""

cleanup() {
  rm -rf "$workdir"
}

rollback_on_error() {
  local exit_code=$?
  if [ "$developer_changed" = true ] && [ -n "$current_revision" ]; then
    echo "Tinus canary failed; rolling deployment/$deployment back to revision $current_revision." >&2
    "${kubectl_cmd[@]}" -n "$namespace" rollout undo "deployment/$deployment" --to-revision="$current_revision" >&2 || true
    "${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$deployment" --timeout=420s >&2 || true
  fi
  cleanup
  exit "$exit_code"
}
trap rollback_on_error ERR
trap cleanup EXIT

if command -v crane >/dev/null 2>&1; then
  digest="$(crane digest "$image_ref")"
elif command -v docker >/dev/null 2>&1; then
  digest="$(docker buildx imagetools inspect "$image_ref" --format '{{json .Manifest.Digest}}' | tr -d '"')"
else
  echo "Missing crane and docker; one registry inspection tool is required." >&2
  exit 1
fi
if [[ ! "$digest" =~ ^sha256:[0-9a-f]{64}$ ]]; then
  echo "Could not resolve an immutable digest for $image_ref." >&2
  exit 1
fi
immutable_image="$image_repository@$digest"
canary_version="${image_ref##*:}"

identity="$("${kubectl_cmd[@]}" auth whoami -o json | jq -r '.status.userInfo.username // empty')"
if [ -z "$identity" ]; then
  echo "Could not resolve the active Kubernetes identity." >&2
  exit 1
fi
echo "Kubernetes identity: $identity"

for permission in \
  "get secrets" \
  "create configmaps" "patch configmaps" \
  "create deployments.apps" "patch deployments.apps" \
  "create services" "patch services" \
  "create networkpolicies.networking.k8s.io" "patch networkpolicies.networking.k8s.io"; do
  read -r verb resource <<<"$permission"
  if [ "$("${kubectl_cmd[@]}" auth can-i "$verb" "$resource" -n "$namespace")" != "yes" ]; then
    echo "Current identity cannot $verb $resource in $namespace." >&2
    exit 1
  fi
done

secret_keys="$("${kubectl_cmd[@]}" -n "$namespace" get secret/openclaw-observability-exporters \
  -o go-template='{{range $key, $value := .data}}{{$key}}{{"\n"}}{{end}}' | sort)"
if [ "$secret_keys" != "LANGFUSE_OTEL_AUTH_HEADER" ]; then
  echo "Exporter Secret does not contain exactly the approved key." >&2
  exit 1
fi

current_revision="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" \
  -o jsonpath='{.metadata.annotations.deployment\.kubernetes\.io/revision}')"
current_pod_digest="$("${kubectl_cmd[@]}" -n "$namespace" get pods \
  -l app.kubernetes.io/name="$deployment" \
  -o json | jq -r '[.items[] | select(.status.phase == "Running") | .status.containerStatuses[] | select(.name == "agent") | .imageID | split("@")[-1]] | unique | if length == 1 then .[0] else empty end')"
if [ "$current_pod_digest" != "$expected_baseline_digest" ]; then
  echo "Refusing rollout: Tinus is not running the reviewed baseline digest." >&2
  exit 1
fi

template_fingerprint() {
  local name="$1"
  "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$name" -o json \
    | jq -cS '.spec.template' \
    | shasum -a 256 \
    | awk '{print $1}'
}

for name in "${other_deployments[@]}"; do
  template_fingerprint "$name" >"$workdir/$name.before"
done

kubectl kustomize k8s/agents/agent-developer \
  | kubectl apply --dry-run=client -f - -o json \
  | jq --arg name "$deployment" --arg image "$immutable_image" --arg version "$canary_version" --arg digest "$digest" '
      .items[]
      | select(.kind == "Deployment" and .metadata.name == $name)
      | .metadata.annotations["openclaw.infuse-ai.com/version"] = $version
      | .spec.template.metadata.annotations["openclaw.infuse-ai.com/version"] = $version
      | .spec.template.metadata.annotations["openclaw.infuse-ai.com/image-revision"] = $digest
      | .spec.template.spec.containers |= map(if .name == "agent" then .image = $image else . end)
    ' >"$workdir/agent-developer.json"

if [ "$(jq -r '.spec.template.spec.containers[] | select(.name == "agent") | .image' "$workdir/agent-developer.json")" != "$immutable_image" ]; then
  echo "Rendered Tinus Deployment is not pinned to the resolved digest." >&2
  exit 1
fi
if [ "$(jq -r '.spec.template.metadata.annotations["openclaw.infuse-ai.com/image-revision"]' "$workdir/agent-developer.json")" != "$digest" ]; then
  echo "Rendered Tinus Deployment is missing the immutable image revision annotation." >&2
  exit 1
fi

"${kubectl_cmd[@]}" -n "$namespace" apply --dry-run=server -f "$collector_manifest" >/dev/null
"${kubectl_cmd[@]}" -n "$namespace" apply --dry-run=server -f "$workdir/agent-developer.json" >/dev/null

echo "Applying the reviewed OTel Collector resources."
"${kubectl_cmd[@]}" -n "$namespace" apply -f "$collector_manifest"
"${kubectl_cmd[@]}" -n "$namespace" rollout restart deployment/openclaw-otel-collector
"${kubectl_cmd[@]}" -n "$namespace" rollout status deployment/openclaw-otel-collector --timeout=300s

echo "Applying Tinus-only canary image $immutable_image."
developer_changed=true
"${kubectl_cmd[@]}" -n "$namespace" apply -f "$workdir/agent-developer.json"
"${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$deployment" --timeout=420s
KUBE_CONTEXT="$kube_context" NAMESPACE="$namespace" AGENT_ID="$deployment" \
  EXPECTED_IMAGE_DIGEST="$digest" EXPECTED_IMAGE_REF="$immutable_image" \
  scripts/smoke-agent-runtime.sh "$namespace" "$deployment"

actual_image="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" \
  -o jsonpath='{.spec.template.spec.containers[?(@.name=="agent")].image}')"
if [ "$actual_image" != "$immutable_image" ]; then
  echo "Tinus Deployment did not retain the immutable canary image." >&2
  exit 1
fi

for name in "${other_deployments[@]}"; do
  if [ "$(template_fingerprint "$name")" != "$(cat "$workdir/$name.before")" ]; then
    echo "Canary rollout changed deployment/$name; stop and investigate." >&2
    exit 1
  fi
  echo "Verified deployment/$name was not changed."
done

developer_changed=false
echo "Tinus observability canary is Ready on $immutable_image; the other four agent pod templates are unchanged."
