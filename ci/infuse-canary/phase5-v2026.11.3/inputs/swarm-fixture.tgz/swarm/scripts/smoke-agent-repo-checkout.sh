#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${2:-${AGENT_ID:-agent-infra}}"
repo_name="${REPO_NAME:-openclaw-k8s-swarm}"
repo_source_url="${REPO_SOURCE_URL:-https://gitlab.infuse-ai-tech.party/platform/agents/$repo_name.git}"
base_branch="${BASE_BRANCH:-main}"
repo_revision="${REPO_REVISION:-}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
task_id="${TASK_ID:-repo-smoke-$(date -u +%Y%m%d%H%M%S)}"

if [[ -n "$repo_revision" && ! "$repo_revision" =~ ^[0-9a-f]{40,64}$ ]]; then
  echo "REPO_REVISION must be an immutable hexadecimal revision." >&2
  exit 1
fi

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s
"${kubectl_base[@]}" wait pod -l "$selector" --for=condition=Ready --timeout=120s >/dev/null

pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  'command -v openclaw-agent-task-workspace >/dev/null'

if [[ "$repo_source_url" == https://gitlab.infuse-ai-tech.party/* ]]; then
  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc '
    set -eu
    "$AGENT_SKILLS_ROOT/scripts/gitlab-vault-run.sh" "$AGENT_ID" -- glab api user | jq -e --arg id "$AGENT_ID" ".username == \$id and .state == \"active\"" >/dev/null
    git config --global credential.https://gitlab.infuse-ai-tech.party.useHttpPath | grep -Fx true >/dev/null
  '
fi

"${kubectl_base[@]}" exec "$pod" -c agent -- env \
  AGENT_ID="$agent_id" \
  TASK_ID="$task_id" \
  REPO_NAME="$repo_name" \
  REPO_SOURCE_URL="$repo_source_url" \
  BASE_BRANCH="$base_branch" \
  openclaw-agent-task-workspace create

if [[ -n "$repo_revision" ]]; then
  "${kubectl_base[@]}" exec "$pod" -c agent -- env \
    REPO_REVISION="$repo_revision" \
    REPO_DIR="/workspace/tasks/$task_id/repos/$repo_name" \
    sh -lc '
      set -eu
      git -C "$REPO_DIR" cat-file -e "${REPO_REVISION}^{commit}"
      git -C "$REPO_DIR" checkout --detach "$REPO_REVISION" >/dev/null
      test "$(git -C "$REPO_DIR" rev-parse HEAD)" = "$REPO_REVISION"
    '
fi

"${kubectl_base[@]}" exec "$pod" -c agent -- env \
  AGENT_ID="$agent_id" \
  TASK_ID="$task_id" \
  openclaw-agent-task-workspace status >/dev/null

"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "test -d '/workspace/tasks/$task_id/repos/$repo_name/.git'"

"${kubectl_base[@]}" exec "$pod" -c agent -- env \
  AGENT_ID="$agent_id" \
  TASK_ID="$task_id" \
  openclaw-agent-task-workspace cleanup --yes >/dev/null

echo "Agent repo checkout smoke passed for $agent_id in $namespace task $task_id"
