#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${2:-${AGENT_ID:-agent-coordinator}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
profile="${OPENCLAW_AGENT_PROFILE:-$agent_id}"
job_name="${EMON_PORTFOLIO_REVIEW_JOB_NAME:-emon-portfolio-review}"
schedule="${EMON_PORTFOLIO_REVIEW_CRON:-0 9 * * 1}"
timezone="${EMON_PORTFOLIO_REVIEW_TZ:-Europe/Madrid}"
timeout_seconds="${EMON_PORTFOLIO_REVIEW_TIMEOUT_SECONDS:-600}"

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s
"${kubectl_base[@]}" wait pod -l "$selector" --for=condition=Ready --timeout=120s >/dev/null
pod="$("${kubectl_base[@]}" get pod -l "$selector" --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}')"
[[ -n "$pod" ]] || { echo "No running pod found for $agent_id in $namespace" >&2; exit 1; }

"${kubectl_base[@]}" exec -i "$pod" -c agent -- bash -s -- \
  "$profile" "$agent_id" "$job_name" "$schedule" "$timezone" "$timeout_seconds" <<'REMOTE'
set -euo pipefail
profile="$1"
agent_id="$2"
job_name="$3"
schedule="$4"
timezone="$5"
timeout_seconds="$6"
prompt_file="/opt/openclaw-agent-skill-config/prompts/emon-portfolio-review.md"

[[ -f "$prompt_file" ]] || { echo "Missing portfolio review candidate prompt" >&2; exit 1; }
message="$(cat "$prompt_file")"
list_json="$(openclaw --profile "$profile" cron list --all --json)"
existing_id="$(JOB_NAME="$job_name" jq -r '.jobs // [] | map(select(.name == env.JOB_NAME)) | .[0].id // empty' <<<"$list_json")"
if [[ -n "$existing_id" ]]; then
  openclaw --profile "$profile" cron remove "$existing_id" >/dev/null
fi

openclaw --profile "$profile" cron add \
  --name "$job_name" \
  --description "Allowlisted proposal-only Emon portfolio review; never activates work." \
  --cron "$schedule" \
  --tz "$timezone" \
  --agent "$agent_id" \
  --session isolated \
  --session-key "cron:emon:portfolio-review" \
  --message "$message" \
  --light-context \
  --thinking low \
  --timeout-seconds "$timeout_seconds" \
  --no-deliver \
  --json >/tmp/emon-portfolio-review-candidate.json

openclaw --profile "$profile" cron list --json | JOB_NAME="$job_name" jq -e '
  .jobs // [] | map(select(.name == env.JOB_NAME and .enabled != false)) | length == 1
' >/dev/null
REMOTE

echo "Emon proposal-only portfolio review installed for $agent_id in $namespace"
