#!/usr/bin/env bash
set -euo pipefail
namespace="${NAMESPACE:-agents-swarm}"
kubectl_cmd=(kubectl)
if [ -n "${KUBE_CONTEXT:-}" ]; then kubectl_cmd+=(--context "$KUBE_CONTEXT"); fi
pod="$("${kubectl_cmd[@]}" -n "$namespace" get pod -l app.kubernetes.io/name=agent-coordinator --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}')"
[ -n "$pod" ] || { echo "No running coordinator pod for mission cron retirement." >&2; exit 1; }
"${kubectl_cmd[@]}" -n "$namespace" exec -i "$pod" -c agent -- bash -s <<'REMOTE'
set -euo pipefail
legacy_names='["emon-mission-continuation-reconciler","emon-mission-event-steward","emon-mission-event-reconciler","emon-mission-steward","emon-mission-dispatcher","emon-mission-steward-v2-candidate"]'
list="$(openclaw --profile agent-coordinator cron list --all --json)"
ids="$(jq -r --argjson names "$legacy_names" '.jobs[]? | select(.name as $name | $names | index($name)) | select(.enabled) | .id' <<<"$list")"
while IFS= read -r id; do
  [ -n "$id" ] || continue
  openclaw --profile agent-coordinator cron disable "$id" >/dev/null
done <<<"$ids"
openclaw --profile agent-coordinator cron list --all --json | jq -e --argjson names "$legacy_names" '[.jobs[]? | select(.name as $name | $names | index($name)) | select(.enabled)] | length == 0' >/dev/null
REMOTE
echo "Legacy mission cron admission disabled; job and run history retained."
