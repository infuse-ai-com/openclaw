#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import process from 'node:process';

const client =
  process.env.KNOWLEDGE_RETRIEVAL_CLIENT ??
  `${process.env.OPENCLAW_AGENT_WORKSPACE ?? ''}/skills/knowledge-retrieval/scripts/knowledge-retrieval.mjs`;
const agentId = process.env.AGENT_ID ?? 'unknown';

function fail(code) {
  process.stderr.write(`${JSON.stringify({ ok: false, error: code })}\n`);
  process.exit(1);
}

function invoke(operation, input) {
  const result = spawnSync(process.execPath, [client, operation], {
    input: JSON.stringify(input),
    encoding: 'utf8',
    maxBuffer: 5 * 1024 * 1024,
    timeout: 20_000,
  });
  if (result.status !== 0) fail(`${operation}_failed`);
  try {
    return JSON.parse(result.stdout);
  } catch {
    fail(`${operation}_response_invalid`);
  }
}

function byteBucket(value) {
  const bytes = Buffer.byteLength(value, 'utf8');
  if (bytes <= 4_096) return 'le_4k';
  if (bytes <= 16_384) return 'le_16k';
  if (bytes <= 65_536) return 'le_64k';
  return 'gt_64k';
}

const discovered = invoke('discover', {
  objective: 'deployment verification procedure',
  limit: 3,
});
const candidate = discovered?.candidates?.[0];
if (!candidate?.fetchReference) fail('discover_empty');
const fetched = invoke('fetch', { reference: candidate.fetchReference });
if (typeof fetched?.markdown !== 'string' || fetched.markdown.length === 0) {
  fail('fetch_empty');
}

process.stdout.write(
  `${JSON.stringify({
    ok: true,
    agentId,
    discover: {
      mode: discovered.mode,
      candidateCount: discovered.candidates.length,
    },
    fetch: { documentBytesBucket: byteBucket(fetched.markdown) },
  })}\n`,
);
