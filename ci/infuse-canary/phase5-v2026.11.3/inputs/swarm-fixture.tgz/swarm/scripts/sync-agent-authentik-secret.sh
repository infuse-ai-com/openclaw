#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-developer}"
secret_name="${AUTHENTIK_SECRET_NAME:-$agent_id-authentik}"
item_name="${VAULTWARDEN_ITEM_NAME:-Authentik / $agent_id service account login}"
bw="${BW_HELPER:-/Users/mac/.openclaw/workspace/scripts/bw-local-vaultwarden.sh}"
dry_run="${DRY_RUN:-false}"
dry_run_output="${DRY_RUN_OUTPUT:-/tmp/openclaw-$agent_id-authentik.yaml}"
bundle_path="config/agent-skill-bundles/$agent_id.json"

case "$agent_id" in
  agent-coordinator|agent-developer|agent-designer|agent-infra|agent-intake)
    ;;
  *)
    echo "Authentik secret sync is not approved for agent: $agent_id" >&2
    exit 2
    ;;
esac

if [[ "$secret_name" != "$agent_id-authentik" ]]; then
  echo "Unexpected Authentik secret name for $agent_id: $secret_name" >&2
  exit 2
fi

python3 - "$bundle_path" "$agent_id" "$item_name" "$namespace" "$secret_name" <<'PY'
import json
import sys
from pathlib import Path

bundle_path = Path(sys.argv[1])
agent_id = sys.argv[2]
item_name = sys.argv[3]
namespace = sys.argv[4]
secret_name = sys.argv[5]

if not bundle_path.exists():
    print(f"Agent bundle not found: {bundle_path}", file=sys.stderr)
    sys.exit(2)

bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
if bundle.get("agent_id") != agent_id:
    print(f"Agent bundle id mismatch: {bundle_path}", file=sys.stderr)
    sys.exit(2)

targets = {}
for item in (
    bundle.get("credential_access", {})
    .get("vaultwarden", {})
    .get("allowed_items", [])
):
    target = item.get("sync_target", {})
    if (
        item.get("name") == item_name
        and target.get("type") == "kubernetes-secret-env"
        and target.get("namespace") == namespace
        and target.get("name") == secret_name
    ):
        targets[target.get("key")] = target.get("source_field", "password")

expected = {
    "AUTHENTIK_USERNAME": "username",
    "AUTHENTIK_PASSWORD": "password",
}
if targets != expected:
    print(
        "Authentik sync target is not allowed by the agent bundle: "
        f"agent={agent_id!r}, item={item_name!r}, targets={targets!r}",
        file=sys.stderr,
    )
    sys.exit(2)
PY

tmp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT
umask 077

write_placeholder_files() {
  printf '%s' "replace-with-authentik-username" >"$tmp_dir/AUTHENTIK_USERNAME"
  printf '%s' "replace-with-authentik-password" >"$tmp_dir/AUTHENTIK_PASSWORD"
}

write_authentik_files() {
  if [[ ! -x "$bw" ]]; then
    echo "Vaultwarden helper not found or not executable: $bw" >&2
    exit 2
  fi

  export OPENCLAW_BW_SERVER="${OPENCLAW_BW_SERVER:-https://vault.infuse-ai-tech.party}"
  export OPENCLAW_BW_DATA="${OPENCLAW_BW_DATA:-/Users/mac/.openclaw/secure/bitwarden-cli-infuse}"

  item_json="$("$bw" get item "$item_name")"
  username="$(printf "%s" "$item_json" | jq -r '.login.username // empty')"
  password="$(printf "%s" "$item_json" | jq -r '.login.password // empty')"

  if [[ -z "$username" || -z "$password" ]]; then
    echo "Authentik item needs login username and password: $item_name" >&2
    exit 2
  fi

  printf '%s' "$username" >"$tmp_dir/AUTHENTIK_USERNAME"
  printf '%s' "$password" >"$tmp_dir/AUTHENTIK_PASSWORD"
}

render_secret_manifest() {
  kubectl -n "$namespace" create secret generic "$secret_name" \
    --from-file=AUTHENTIK_USERNAME="$tmp_dir/AUTHENTIK_USERNAME" \
    --from-file=AUTHENTIK_PASSWORD="$tmp_dir/AUTHENTIK_PASSWORD" \
    --dry-run=client \
    -o yaml
}

if [[ "$dry_run" == "true" ]]; then
  write_placeholder_files
  render_secret_manifest >"$dry_run_output"
  echo "Rendered Authentik secret manifest with placeholder values: $dry_run_output"
  exit 0
fi

write_authentik_files
render_secret_manifest | kubectl --context "$context" apply \
  --server-side \
  --field-manager=openclaw-agent-authentik-sync \
  -f -

echo "Synced Authentik runtime target $namespace/$secret_name for $agent_id"
