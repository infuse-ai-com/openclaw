#!/usr/bin/env python3
"""Stage and enable individual whiteboard MCP credentials after paired reviewed releases."""
from __future__ import annotations

import argparse
import base64
import copy
import hashlib
import json
import re
import secrets
import time
from pathlib import Path

import provision_artifact_registry_credentials as common

ORG = '4ee40d24-6f91-4d76-b7c5-f962352e614a'
COLLECTIONS = {
    'coordinator': 'bf563a18-ac30-4106-becf-4f84ee99512e',
    'designer': '4ee4d40e-5a47-40bd-8a54-67dbb8e39026',
    'developer': 'db05f495-3e4e-409a-bd61-3a1c39d32280',
    'infra': '1bcf00d0-118a-4699-8f72-215051c0c17b',
}
SERVICE_COLLECTION = '8cb748f7-9e7b-4647-a637-c04dd63c03e4'
ISSUER = 'urn:infuse:service:whiteboard-mcp'
KEY_ID = 'whiteboard-read-v1'
RESOURCE = 'https://studio-bridge.core.svc.cluster.local/whiteboard/mcp'
MCP_NAMESPACE = 'infuse-azure-devops-mcp'
MCP_SECRET = 'infuse-whiteboard-mcp-identity'
STUDIO_SECRET = 'studio-whiteboard-mcp'


def reject(message):
    raise common.ProvisioningError(message)


def stored_item(helper, name, collection, create):
    """Reconcile exact item name before creation; verify persisted scope/value before use."""
    common.run_bw(helper, ['sync'], label='Whiteboard vault refresh')
    found = json.loads(common.run_bw(helper, ['list', 'items', '--search', name], label='Whiteboard item lookup'))
    item = common.exact_named(found, name)
    if item is None:
        value, metadata = create()
        item = json.loads(common.run_bw(helper, ['get', 'template', 'item'], label='Whiteboard item template'))
        item.update(type=1, name=name, organizationId=ORG, collectionIds=[collection], favorite=False,
                    notes='Studio whiteboard access. Credential values must never enter logs or model arguments.',
                    fields=[{'name': k, 'value': str(v), 'type': 0} for k, v in metadata.items()],
                    login={'username': metadata.get('clientId', 'whiteboard-mcp-service'), 'password': value,
                           'uris': [{'uri': RESOURCE, 'match': None}], 'totp': None})
        encoded = common.run_bw(helper, ['encode'], input_text=json.dumps(item), label='Whiteboard item encoding').strip()
        # An ambiguous create is reconciled by the exact-name lookup on the next run.
        common.run_bw(helper, ['create', 'item'], input_text=encoded, label='Whiteboard item create')
        common.run_bw(helper, ['sync'], label='Verify persisted whiteboard vault item')
        item = common.lookup_item(helper, name)
        if item.get('login', {}).get('password') != value:
            reject('Persisted whiteboard credential did not match; nothing enabled')
    if item.get('organizationId') != ORG or set(item.get('collectionIds', [])) != {collection}:
        reject('Whiteboard item collection mismatch; no access changed')
    if not item.get('id') or not item.get('login', {}).get('password'):
        reject('Incomplete whiteboard item')
    return item


def secret(context, namespace, name):
    raw = common.run_checked(['kubectl', '--context', context, '-n', namespace, 'get', 'secret', name,
                              '--ignore-not-found', '-o', 'json'], label='Whiteboard Secret lookup')
    return json.loads(raw) if raw.strip() else None


def text_value(value, key):
    if value is None or key not in value.get('data', {}):
        return None
    try:
        return base64.b64decode(value['data'][key], validate=True).decode()
    except (ValueError, UnicodeError):
        reject('Malformed whiteboard Secret')


def update_secret(context, namespace, name, before, updates):
    if before is None:
        common.run_checked(['kubectl', '--context', context, '-n', namespace, 'create', '-f', '-'],
                           input_text=json.dumps(common.opaque_secret(namespace, name, updates)),
                           label='Create scoped whiteboard Secret')
        return
    data = dict(before.get('data', {}))
    data.update({k: base64.b64encode(v.encode()).decode() for k, v in updates.items()})
    if data == before.get('data', {}):
        return
    patch = [{'op': 'test', 'path': '/metadata/resourceVersion', 'value': before['metadata']['resourceVersion']},
             {'op': 'add', 'path': '/data', 'value': data}]
    common.run_checked(['kubectl', '--context', context, '-n', namespace, 'patch', 'secret', name,
                        '--type=json', '--patch-file=/dev/stdin'], input_text=json.dumps(patch),
                       label='Update exact whiteboard Secret with concurrency check')


def require_release(context, namespace, deployment, container, image):
    if not re.fullmatch(r'registry\.infuse-ai-tech\.party/[a-z0-9/-]+@sha256:[a-f0-9]{64}', image or ''):
        reject('Exact reviewed application image digest required')
    d = common.kube_json(context, ['-n', namespace, 'get', 'deployment', deployment], label='Reviewed deployment lookup')
    status = d.get('status', {})
    if ([c['image'] for c in d['spec']['template']['spec']['containers'] if c['name'] == container] != [image]
            or status.get('observedGeneration') != d['metadata']['generation']
            or any(status.get(k) != 1 for k in ['replicas', 'updatedReplicas', 'readyReplicas', 'availableReplicas'])):
        reject('Reviewed application release is not exactly ready')


def service_material(helper):
    def generate():
        pem = common.run_checked(['openssl', 'genpkey', '-algorithm', 'EC', '-pkeyopt', 'ec_paramgen_curve:P-256'],
                                 label='Generate dedicated whiteboard signing key')
        return pem, {'keyId': KEY_ID, 'issuer': ISSUER}
    item = stored_item(helper, 'Studio whiteboard MCP service signer', SERVICE_COLLECTION, generate)
    fields = {f['name']: f.get('value') for f in item.get('fields', [])}
    if fields.get('keyId') != KEY_ID or fields.get('issuer') != ISSUER:
        reject('Service signer metadata differs')
    pem = item['login']['password']
    public = common.run_checked(['openssl', 'pkey', '-pubout'], input_text=pem, label='Read whiteboard public key')
    return pem, public, item['id']


def agent_material(helper, agent):
    name = 'Studio whiteboard MCP / agent-' + agent
    def generate():
        now = int(time.time())
        credential = 'wb-' + agent + '-' + secrets.token_hex(8)
        return 'swb_' + credential + '.' + secrets.token_urlsafe(32), {
            'credentialId': credential, 'clientId': 'studio-whiteboard-agent-' + agent,
            'gatewayId': 'swarm-' + agent, 'agentId': 'agent-' + agent,
            'issuedAt': now, 'expiresAt': now + 90 * 86400}
    item = stored_item(helper, name, COLLECTIONS[agent], generate)
    fields = {f['name']: f.get('value') for f in item.get('fields', [])}
    try:
        metadata = {k: fields[k] for k in ['credentialId', 'clientId', 'gatewayId', 'agentId']}
        metadata.update({k: int(fields[k]) for k in ['issuedAt', 'expiresAt']})
    except (ValueError, KeyError, TypeError):
        reject('Agent credential metadata is incomplete')
    if (metadata['gatewayId'] != 'swarm-' + agent or metadata['agentId'] != 'agent-' + agent
            or metadata['clientId'] != 'studio-whiteboard-agent-' + agent
            or not 0 < metadata['expiresAt'] - metadata['issuedAt'] <= 90 * 86400
            or not metadata['issuedAt'] <= time.time() < metadata['expiresAt']):
        reject('Agent credential is expired or belongs to another identity; explicit rotation required')
    token = item['login']['password']
    if not re.fullmatch(r'swb_' + re.escape(metadata['credentialId']) + r'\.[A-Za-z0-9_-]{43}', token):
        reject('Malformed per-agent credential')
    return token, metadata, item['id']


def stage_admission(studio, verifier, metadata, digest, generation):
    """Retain other grants, reject any credential drift; stage MCP disabled first."""
    result, reads = copy.deepcopy(studio), copy.deepcopy(verifier)
    if result.get('enabled') is not True or reads.get('version') != 1 or reads.get('resource') != RESOURCE:
        reject('Unexpected whiteboard admission configuration')
    expected = dict(metadata, issuer=ISSUER, projectId='studio', enrollmentGeneration=generation, enabled=True)
    existing = [b for b in result['bindings'] if b['credentialId'] == metadata['credentialId'] or b['clientId'] == metadata['clientId']]
    if existing and existing != [expected]:
        reject('Existing Studio grant differs; no widening or replacement allowed')
    if not existing:
        result['bindings'].append(expected)
    credential = dict(metadata, tokenSha256=digest, enabled=False)
    existing = [c for c in reads['credentials'] if c['credentialId'] == metadata['credentialId'] or c['clientId'] == metadata['clientId']]
    if existing and ({**existing[0], 'enabled': False} != credential or len(existing) != 1):
        reject('Existing verifier identity differs')
    if not existing:
        reads['credentials'].append(credential)
    return result, reads


def admission(context, agent):
    raw = secret(context, 'core', 'studio-settings')
    config = json.loads(text_value(raw, 'studio.json') or '{}')
    if config.get('authorityId') != 'studio-production' or config.get('project', {}).get('id') != 'studio':
        reject('Unexpected Studio authority')
    identity = {'gatewayId': 'swarm-' + agent, 'agentId': 'agent-' + agent}
    if not any(all(r.get(k) == v for k, v in identity.items()) for r in config.get('nativeMissions', {}).get('routes', [])):
        reject('Agent has no current configured Studio route')
    enrollment = next((g for g in config.get('bridge', {}).get('gateways', [])
                       if g.get('gatewayId') == identity['gatewayId'] and g.get('enabled')
                       and identity['agentId'] in g.get('agents', [])), None)
    if not config.get('bridge', {}).get('enabled') or not enrollment:
        reject('Agent is not currently enrolled')
    return enrollment['generation']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['plan', 'prepare', 'stage-agent', 'enable-agent'])
    parser.add_argument('--agent', choices=sorted(COLLECTIONS))
    parser.add_argument('--context', default='infuseai-k8s')
    parser.add_argument('--approved', action='store_true')
    parser.add_argument('--studio-image')
    parser.add_argument('--mcp-image')
    parser.add_argument('--bw-helper', default=str(Path.home() / '.codex/skills/vaultwarden-credential-management/scripts/bw-local-vaultwarden.sh'))
    args = parser.parse_args()
    if args.action == 'plan':
        print(json.dumps({'endpoint': RESOURCE, 'agents': sorted(COLLECTIONS), 'projects': ['studio'],
            'catalog': ['context', 'read', 'search'], 'nativeEditing': 'existing attested plugin',
            'intake': 'not enrolled; no grant', 'hostChanges': False, 'credentials': 'Vaultwarden first, enable after verified application release'}));return
    if not args.approved:
        reject('Recorded owner approval required')
    require_release(args.context, 'core', 'studio', 'studio', args.studio_image)
    require_release(args.context, MCP_NAMESPACE, 'infuse-azure-devops-mcp', 'infuse-azure-devops-mcp', args.mcp_image)
    if args.action == 'prepare':
        pem, public, item_id = service_material(args.bw_helper)
        mcp, studio = secret(args.context, MCP_NAMESPACE, MCP_SECRET), secret(args.context, 'core', STUDIO_SECRET)
        existing_key = text_value(mcp, 'signing-key.pem')
        if existing_key is not None and existing_key != pem:
            reject('Existing service key differs; explicit rotation required')
        config = {'enabled': True, 'signers': [{'issuer': ISSUER, 'keyId': KEY_ID, 'enabled': True, 'publicKey': public}], 'bindings': []}
        previous = text_value(studio, 'config.json')
        if previous is not None and json.loads(previous).get('signers') != config['signers']:
            reject('Studio signer drift')
        update_secret(args.context, MCP_NAMESPACE, MCP_SECRET, mcp, {'signing-key.pem': pem,
            'credentials.json': text_value(mcp, 'credentials.json') or json.dumps({'version': 1, 'resource': RESOURCE, 'credentials': []})})
        update_secret(args.context, 'core', STUDIO_SECRET, studio, {'config.json': previous or json.dumps(config)})
        print(json.dumps({'action': 'prepared-disabled', 'serviceVaultItem': item_id, 'agentGrants': 'unchanged', 'hostChanges': False}));return
    if not args.agent:
        reject('Select one admitted agent')
    generation = admission(args.context, args.agent)
    mcp, studio = secret(args.context, MCP_NAMESPACE, MCP_SECRET), secret(args.context, 'core', STUDIO_SECRET)
    if not mcp or not studio:
        reject('Prepare service identity first')
    config, verifier = json.loads(text_value(studio, 'config.json')), json.loads(text_value(mcp, 'credentials.json'))
    token, metadata, item_id = agent_material(args.bw_helper, args.agent)
    digest = hashlib.sha256(token.encode()).hexdigest()
    updated, reads = stage_admission(config, verifier, metadata, digest, generation)
    if args.action == 'stage-agent':
        client_name = 'agent-' + args.agent + '-whiteboard'
        old = secret(args.context, 'agents-swarm', client_name)
        if old is not None and text_value(old, 'token') != token:
            reject('Agent projection differs; no overwrite')
        # Persisted Vault item already verified. Disabled verifier precedes all grants/projections.
        update_secret(args.context, MCP_NAMESPACE, MCP_SECRET, mcp, {'credentials.json': json.dumps(reads)})
        update_secret(args.context, 'agents-swarm', client_name, old, {'token': token})
        update_secret(args.context, 'core', STUDIO_SECRET, studio, {'config.json': json.dumps(updated)})
        print(json.dumps({'action': 'staged', 'agent': args.agent, 'vaultItem': item_id, 'fingerprint': digest[:16],
            'expiresAt': metadata['expiresAt'], 'next': 'reviewed application rollout to admit startup binding, then enable and probe this agent'}));return
    if updated != config or reads != verifier:
        reject('Agent has not been staged unchanged')
    record = next(c for c in reads['credentials'] if c['credentialId'] == metadata['credentialId'])
    record['enabled'] = True
    update_secret(args.context, MCP_NAMESPACE, MCP_SECRET, mcp, {'credentials.json': json.dumps(reads)})
    print(json.dumps({'action': 'verifier-enabled', 'agent': args.agent, 'vaultItem': item_id, 'fingerprint': digest[:16],
        'expiresAt': metadata['expiresAt'], 'qualification': 'run this agents allowed-read and wrong-project probes before proceeding'}))


if __name__ == '__main__':
    try:
        main()
    except (common.ProvisioningError, ValueError, KeyError, TypeError):
        # Deliberately suppress captured CLI responses and secret-shaped exception detail.
        raise SystemExit('Whiteboard provisioning stopped; no broader credentials or host settings changed. Reconcile the scoped stage before retrying.') from None
