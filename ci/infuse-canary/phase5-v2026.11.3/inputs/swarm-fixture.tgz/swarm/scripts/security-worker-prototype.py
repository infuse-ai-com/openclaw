#!/usr/bin/env python3
"""Render or qualify synthetic workers using the operator's existing Kubernetes identity."""
import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

LABEL = 'openclaw.infuse-ai.com/security-worker-prototype'
ROLES = ('browser', 'build', 'media')
ARTIFACTS = {'receipt.json', 'browser.png', 'download.txt', 'build.txt',
             'image.png', 'image.jpg', 'contact.png', 'image.pdf'}
MAX_BYTES = 1024 * 1024


def resources(run_id, image, namespace, node, canary_path='/tmp/operator-only-canary'):
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,30}', run_id):
        raise ValueError('invalid run ID')
    if not re.fullmatch(r'registry\.infuse-ai-tech\.party/agents-swarm/openclaw-agent@sha256:[a-f0-9]{64}', image):
        raise ValueError('exact approved registry digest required')
    labels = {LABEL: run_id}
    name = 'security-worker-' + run_id
    metadata = {'namespace': namespace, 'labels': labels}
    policy = {'apiVersion': 'networking.k8s.io/v1', 'kind': 'NetworkPolicy',
              'metadata': {**metadata, 'name': name},
              'spec': {'podSelector': {'matchLabels': labels},
                       'policyTypes': ['Ingress', 'Egress'], 'ingress': [], 'egress': []}}
    config = {'apiVersion': 'v1', 'kind': 'ConfigMap',
              'metadata': {**metadata, 'name': name},
              'data': {'fixture.py': Path(__file__).with_name('security-worker-fixture.py').read_text()}}
    jobs = []
    for role in ROLES:
        seccomp = {'type': 'RuntimeDefault'}
        if role == 'browser':
            seccomp = {'type': 'Localhost', 'localhostProfile': 'infuse/openclaw-chromium-v1.json'}
        pod = {'restartPolicy': 'Never', 'automountServiceAccountToken': False,
               'enableServiceLinks': False, 'nodeSelector': {'kubernetes.io/hostname': node},
               'imagePullSecrets': [{'name': 'harbor-pull'}],
               'securityContext': {'runAsNonRoot': True, 'runAsUser': 10001,
                                   'runAsGroup': 10001, 'fsGroup': 10001, 'seccompProfile': seccomp},
               'containers': [{'name': 'worker', 'image': image,
                   'command': ['/bin/sh', '-ec', 'mkdir -p /tmp/home; python3 /fixture/fixture.py ' + role + '; sleep 240'],
                   'env': [{'name': 'HOME', 'value': '/tmp/home'},
                           {'name': 'OPENCLAW_WORKER_PROTOTYPE', 'value': 'synthetic-only'},
                           {'name': 'WORKER_UNMOUNTED_CANARY_PATH', 'value': canary_path},
                           {'name': 'PLAYWRIGHT_BROWSERS_PATH', 'value': '/opt/playwright-browsers'}],
                   'securityContext': {'allowPrivilegeEscalation': False, 'readOnlyRootFilesystem': True,
                                       'capabilities': {'drop': ['ALL']}},
                   'resources': {'requests': {'cpu': '100m', 'memory': '128Mi'},
                                 'limits': {'cpu': '2', 'memory': '2Gi'}},
                   'readinessProbe': {'exec': {'command': ['test', '-s', '/tmp/worker-output/receipt.json']},
                                      'periodSeconds': 2, 'failureThreshold': 90},
                   'volumeMounts': [{'name': 'tmp', 'mountPath': '/tmp'},
                                    {'name': 'shm', 'mountPath': '/dev/shm'},
                                    {'name': 'fixture', 'mountPath': '/fixture', 'readOnly': True}]}],
               'volumes': [{'name': 'tmp', 'emptyDir': {'sizeLimit': '256Mi'}},
                           {'name': 'shm', 'emptyDir': {'medium': 'Memory', 'sizeLimit': '256Mi'}},
                           {'name': 'fixture', 'configMap': {'name': name}}]}
        jobs.append({'apiVersion': 'batch/v1', 'kind': 'Job',
                     'metadata': {**metadata, 'name': name + '-' + role},
                     'spec': {'backoffLimit': 0, 'activeDeadlineSeconds': 300,
                              'ttlSecondsAfterFinished': 60,
                              'template': {'metadata': {'labels': labels}, 'spec': pod}}})
    return [policy, config, *jobs]


def decode_artifacts(payload):
    if not isinstance(payload, dict) or 'receipt.json' not in payload:
        raise ValueError('missing receipt')
    result = {}
    total = 0
    for name, item in payload.items():
        if name not in ARTIFACTS:
            raise ValueError('unexpected artifact name')
        if len(item['base64']) > 4 * MAX_BYTES // 3 + 4:
            raise ValueError('oversized encoded artifact')
        data = base64.b64decode(item['base64'], validate=True)
        total += len(data)
        if total > MAX_BYTES or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('artifact size or hash mismatch')
        result[name] = data
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--image', required=True)
    parser.add_argument('--context', default='infuseai-k8s')
    parser.add_argument('--namespace', default='agents-swarm')
    parser.add_argument('--node', default='n1.infuse-ai.com')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--execute', action='store_true', help='create only these temporary synthetic resources')
    args = parser.parse_args()
    os.umask(0o077)
    args.output.mkdir(parents=True, exist_ok=False)
    canary = args.output.resolve() / 'operator-only-canary'
    canary.write_text('synthetic-host-canary-' + args.run_id + '\n')
    objects = resources(args.run_id, args.image, args.namespace, args.node, str(canary))
    (args.output / 'rendered.json').write_text(json.dumps({'apiVersion': 'v1', 'kind': 'List', 'items': objects}, indent=2) + '\n')
    if not args.execute:
        print('Rendered synthetic resources; nothing created.')
        return
    kubectl = ['kubectl', '--context', args.context, '-n', args.namespace]

    def run(extra, **kwargs):
        return subprocess.run(kubectl + extra, check=True, capture_output=True, text=True, timeout=240, **kwargs).stdout

    existing = json.loads(run(['get', 'pods', '-l', LABEL + '=' + args.run_id, '-o', 'json']))
    if existing['items']:
        raise RuntimeError('run label already selects pods; refusing to change their network policy')
    created = []
    results = []
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        for obj in objects[:2]:
            run(['create', '-f', '-'], input=json.dumps(obj))
            created.append(obj)
        for obj, role in zip(objects[2:], ROLES):
            run(['create', '-f', '-'], input=json.dumps(obj))
            created.append(obj)
            name = obj['metadata']['name']
            run(['wait', '--for=condition=Ready', 'pod', '-l', 'job-name=' + name, '--timeout=180s'])
            pods = json.loads(run(['get', 'pods', '-l', 'job-name=' + name, '-o', 'json']))['items']
            if len(pods) != 1:
                raise RuntimeError('expected exactly one worker pod')
            pod = pods[0]
            raw = run(['exec', pod['metadata']['name'], '-c', 'worker', '--',
                       'python3', '/fixture/fixture.py', 'export'])
            if len(raw) > 2 * MAX_BYTES:
                raise ValueError('oversized worker response')
            artifacts = decode_artifacts(json.loads(raw))
            destination = args.output / role
            destination.mkdir()
            for filename, data in artifacts.items():
                (destination / filename).write_bytes(data)
            receipt = json.loads(artifacts['receipt.json'])
            receipt.update(podUid=pod['metadata']['uid'], image=args.image,
                           artifactHashes={n: hashlib.sha256(d).hexdigest() for n, d in artifacts.items()})
            results.append(receipt)
            run(['delete', 'job', name, '--wait=true', '--timeout=60s'])
            created.remove(obj)
    finally:
        cleanup_errors = []
        for obj in reversed(created):
            try:
                run(['delete', obj['kind'], obj['metadata']['name'], '--ignore-not-found=true', '--wait=true', '--timeout=60s'])
            except subprocess.SubprocessError as error:
                cleanup_errors.append(str(error))
        if cleanup_errors:
            raise RuntimeError('Owned resource cleanup incomplete: ' + '; '.join(cleanup_errors))
    report = {'runId': args.run_id, 'startedAt': started,
              'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'context': args.context, 'namespace': args.namespace,
              'control': 'existing authenticated operator Kubernetes API; no new RBAC or service endpoint',
              'productionRoutingChanged': False, 'workers': results, 'ownedResourcesDeleted': True}
    (args.output / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'runId': args.run_id, 'rolesPassed': [r['role'] for r in results], 'cleaned': True}))


if __name__ == '__main__':
    main()
