#!/usr/bin/env python3
"""Refresh the reviewed memory mirror and report remote-check freshness as JSON."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time

ORIGIN = 'https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory.git'
AGENTS = {'agent-developer', 'agent-designer', 'agent-infra', 'agent-coordinator', 'agent-intake'}


class Refused(Exception):
    pass


def git(root, *args, timeout=120):
    command = ['git', '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false']
    if root is not None:
        command += ['-C', str(root)]
    try:
        result = subprocess.run(command + list(args), capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise Refused('git_timeout') from None
    if result.returncode:
        error = result.stderr.lower()
        if any(word in error for word in (b'authentication failed', b'401', b'403', b'access denied')):
            raise Refused('authentication_failed')
        raise Refused('git_operation_failed')
    return result.stdout.decode().strip()


def checked_time():
    return datetime.now(timezone.utc).isoformat()


def read_receipt(state):
    try:
        value = json.loads((state / 'receipt.json').read_text())
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def save_receipt(state, receipt):
    temporary = state / 'receipt.tmp'
    with temporary.open('w') as stream:
        json.dump(receipt, stream, sort_keys=True)
        stream.write('\n')
    temporary.chmod(0o600)
    temporary.replace(state / 'receipt.json')


@contextmanager
def checkout_lock(state, wait_seconds=30):
    if state.is_symlink():
        raise Refused('unsafe_state_path')
    state.mkdir(mode=0o700, parents=True, exist_ok=True)
    for name in ('refresh.lock', 'receipt.json', 'receipt.tmp'):
        if (state / name).is_symlink():
            raise Refused('unsafe_state_path')
    with (state / 'refresh.lock').open('a') as lock:
        deadline = time.monotonic() + wait_seconds
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise Refused('refresh_busy') from None
                time.sleep(0.1)
        yield


def sparse_checkout(root, agent):
    # History and peer raw journals remain opt-in through committed-object reads.
    patterns = ['/.knowledge-base.yml', '/README.md', '/docs/', '/projects/',
                '/schemas/', '/scripts/', '/shared/', '/templates/',
                f'/agents/{agent}/', '/agents/*/summaries/']
    git(root, 'config', 'core.sparseCheckout', 'true')
    git(root, 'config', 'core.sparseCheckoutCone', 'false')
    info = root / '.git/info'
    if info.is_symlink() or (info / 'sparse-checkout').is_symlink():
        raise Refused('unsafe_sparse_checkout_path')
    info.mkdir(exist_ok=True)
    (info / 'sparse-checkout').write_text('\n'.join(patterns) + '\n')
    git(root, 'read-tree', '-mu', 'HEAD')


def refresh_locked(root, state, agent, receipt, *, force, after_commit, max_age, origin):
    if root.is_symlink() or (root / '.git').is_symlink():
        raise Refused('unsafe_checkout')
    if not root.exists():
        root.parent.mkdir(parents=True, exist_ok=True)
        git(None, 'clone', '--quiet', '--no-checkout', '--single-branch', '--branch', 'main', origin, str(root))
        sparse_checkout(root, agent)
    if not (root / '.git').is_dir():
        raise Refused('not_a_checkout')
    if git(root, 'remote', 'get-url', 'origin') != origin:
        raise Refused('unexpected_origin')
    if git(root, 'branch', '--show-current') != 'main':
        raise Refused('unexpected_branch')
    receipt['commit'] = git(root, 'rev-parse', 'HEAD')
    old = read_receipt(state)
    if old.get('repository') == str(root) and old.get('agent') == agent:
        receipt['checked_at'] = old.get('checked_at')
        receipt['remote_commit'] = old.get('remote_commit')
    if git(root, 'status', '--porcelain', '--untracked-files=normal'):
        raise Refused('dirty_checkout')
    if not force and not after_commit and old.get('status') in ('updated', 'unchanged', 'cached') and old.get('commit') == receipt['commit']:
        try:
            age = time.time() - datetime.fromisoformat(receipt['checked_at']).timestamp()
        except (ValueError, TypeError):
            age = -1
        if 0 <= age <= max_age and receipt['remote_commit'] == receipt['commit']:
            receipt['status'] = 'cached'
            return
    # Explicit refspec avoids trusting a stale origin/main under a changed fetch config.
    git(root, 'fetch', '--quiet', '--no-tags', 'origin', 'refs/heads/main:refs/remotes/origin/main')
    remote = git(root, 'rev-parse', 'refs/remotes/origin/main')
    receipt['remote_commit'] = remote
    receipt['checked_at'] = checked_time()
    try:
        git(root, 'merge-base', '--is-ancestor', receipt['commit'], remote)
    except Refused:
        raise Refused('divergent_checkout') from None
    if after_commit:
        try:
            git(root, 'merge-base', '--is-ancestor', after_commit, remote)
        except Refused:
            raise Refused('handoff_not_on_remote_main') from None
    before = receipt['commit']
    git(root, 'merge', '--ff-only', '--no-edit', remote)
    sparse_checkout(root, agent)
    receipt['commit'] = git(root, 'rev-parse', 'HEAD')
    if receipt['commit'] != remote or git(root, 'status', '--porcelain'):
        raise Refused('checkout_changed_during_refresh')
    receipt['status'] = 'updated' if before != remote else 'unchanged'


def refresh(root, state, agent, *, force=False, after_commit=None, max_age=300, origin=ORIGIN, lock_wait=30):
    """Origin injection is for isolated Git fixtures; CLI pins the forge URL."""
    receipt = {'version': 1, 'agent': agent, 'repository': str(root), 'status': 'unavailable',
               'commit': None, 'remote_commit': None, 'checked_at': None,
               'attempted_at': checked_time(), 'reason': None}
    try:
        if agent not in AGENTS:
            raise Refused('unknown_agent')
        with checkout_lock(state, lock_wait):
            try:
                refresh_locked(root, state, agent, receipt, force=force, after_commit=after_commit, max_age=max_age, origin=origin)
            except (Refused, OSError) as exc:
                receipt['status'] = 'stale' if receipt['commit'] else 'unavailable'
                receipt['reason'] = str(exc) if isinstance(exc, Refused) else 'local_io_failed'
            # A failed attempt invalidates cache reuse without discarding its last check time.
            save_receipt(state, receipt)
    except (Refused, OSError) as exc:
        receipt['status'] = 'unavailable'
        receipt['reason'] = str(exc) if isinstance(exc, Refused) else 'local_io_failed'
    return receipt


def own_git_credentials(agent):
    root = os.environ.get('AGENT_SKILLS_ROOT')
    if not root or not (Path(root) / 'scripts/git-credential-gitlab-vault.sh').is_file():
        raise Refused('own_credential_helper_unavailable')
    helper = Path(root) / 'scripts/git-credential-gitlab-vault.sh'
    os.environ.pop('GIT_CONFIG_PARAMETERS', None)
    entries = [('credential.helper', ''),
               ('credential.https://gitlab.infuse-ai-tech.party.helper', '!' + shlex.quote(str(helper)) + ' ' + shlex.quote(agent)),
               ('credential.https://gitlab.infuse-ai-tech.party.useHttpPath', 'true')]
    os.environ['GIT_CONFIG_COUNT'] = str(len(entries))
    os.environ['GIT_TERMINAL_PROMPT'] = '0'
    for number, (key, value) in enumerate(entries):
        os.environ[f'GIT_CONFIG_KEY_{number}'] = key
        os.environ[f'GIT_CONFIG_VALUE_{number}'] = value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--after-commit')
    parser.add_argument('--startup', action='store_true')
    args = parser.parse_args()
    if args.after_commit and not re.fullmatch('[0-9a-f]{40}', args.after_commit):
        parser.error('--after-commit requires a full lowercase Git SHA')
    agent = os.environ.get('AGENT_ID', '')
    workspace = Path(os.environ.get('OPENCLAW_WORKSPACE', '/workspace'))
    root = Path(os.environ.get('OPENCLAW_SHARED_MEMORY_PATH', str(workspace / 'openclaw-agents-memory')))
    try:
        if agent not in AGENTS:
            raise Refused('unknown_agent')
        if os.environ.get('OPENCLAW_SHARED_MEMORY_REPO', ORIGIN) != ORIGIN or os.environ.get('OPENCLAW_SHARED_MEMORY_BRANCH', 'main') != 'main':
            raise Refused('unexpected_source_config')
        own_git_credentials(agent)
        receipt = refresh(root, workspace / '.agent-memory-retrieval' / agent, agent,
                          force=args.force or args.startup, after_commit=args.after_commit)
    except Refused as exc:
        receipt = {'version': 1, 'agent': agent, 'repository': str(root), 'status': 'unavailable',
                   'commit': None, 'remote_commit': None, 'checked_at': None, 'reason': str(exc)}
    print(json.dumps(receipt, sort_keys=True))
    if receipt['status'] in ('updated', 'unchanged', 'cached'):
        return 0
    if args.startup and os.environ.get('OPENCLAW_SHARED_MEMORY_REQUIRED', 'false') != 'true':
        return 0  # Optional startup, never an on-demand freshness assertion.
    return 3 if receipt['status'] == 'stale' else 2


if __name__ == '__main__':
    raise SystemExit(main())
