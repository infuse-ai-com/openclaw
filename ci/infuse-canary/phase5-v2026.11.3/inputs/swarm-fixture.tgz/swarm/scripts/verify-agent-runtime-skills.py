#!/usr/bin/env python3
"""Verify live OpenClaw skill provenance against one reviewed agent bundle."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Callable


DEFAULT_CONFIG_ROOT = Path(
    os.environ.get("OPENCLAW_SKILL_CONFIG_ROOT", "/opt/openclaw-agent-skill-config")
)
DEFAULT_WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", "/workspace"))


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"missing {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path} is invalid JSON: {exc}") from exc


def materialization(skill_id: str, catalog: dict) -> str:
    skill = catalog["skills"][skill_id]
    return catalog["sources"][skill["source"]]["materialization"]


def missing_runtime_requirements(
    skill: dict,
    which: Callable[[str], str | None],
) -> list[str]:
    requirements = skill.get("runtime_requirements", {})
    bins = requirements.get("bins", []) if isinstance(requirements, dict) else []
    return [binary for binary in bins if not which(binary)]


def collect_errors(
    *,
    catalog: dict,
    bundle: dict,
    runtime_payload: dict,
    skills_dir: Path,
    which: Callable[[str], str | None] = shutil.which,
) -> list[str]:
    errors: list[str] = []
    runtime_entries = runtime_payload.get("skills")
    if not isinstance(runtime_entries, list):
        return ["OpenClaw skills JSON must contain a skills list"]

    runtime_by_id: dict[str, dict] = {}
    for entry in runtime_entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("name"), str):
            continue
        skill_id = entry["name"]
        if skill_id in runtime_by_id:
            errors.append(f"OpenClaw returned duplicate runtime skill id {skill_id}")
        runtime_by_id[skill_id] = entry

    installed = bundle.get("skills", {}).get("installed", [])
    if not isinstance(installed, list):
        return errors + ["bundle.skills.installed must be a list"]

    for skill_id, skill in sorted(catalog["skills"].items()):
        if materialization(skill_id, catalog) != "runtime-native":
            continue
        shadow = skills_dir / skill_id
        if shadow.exists() or shadow.is_symlink():
            errors.append(f"runtime-native skill {skill_id} is shadowed at {shadow}")
        runtime_entry = runtime_by_id.get(skill_id)
        if runtime_entry is None:
            continue
        expected_source = skill["runtime_native"]["expected_source"]
        if runtime_entry.get("source") != expected_source:
            errors.append(
                f"runtime-native skill {skill_id} resolved from "
                f"{runtime_entry.get('source')!r}, expected {expected_source!r}"
            )

    for skill_id in installed:
        skill = catalog["skills"].get(skill_id)
        if not isinstance(skill, dict):
            errors.append(f"bundle declares unknown skill {skill_id}")
            continue
        runtime_entry = runtime_by_id.get(skill_id)
        if materialization(skill_id, catalog) == "managed-copy":
            if not (skills_dir / skill_id / "SKILL.md").is_file():
                errors.append(f"managed-copy skill {skill_id} is not materialized in {skills_dir}")
            if runtime_entry is None:
                errors.append(f"managed-copy skill {skill_id} is absent from OpenClaw discovery")
            elif runtime_entry.get("source") != "openclaw-workspace":
                errors.append(
                    f"managed-copy skill {skill_id} resolved from "
                    f"{runtime_entry.get('source')!r}, expected 'openclaw-workspace'"
                )
            if runtime_entry and runtime_entry.get("blockedByAgentFilter") is True:
                errors.append(f"managed-copy skill {skill_id} is blocked by the agent filter")
            continue

        if runtime_entry is None:
            errors.append(f"runtime-native skill {skill_id} is absent from OpenClaw discovery")
            continue
        if runtime_entry.get("eligible") is not True:
            errors.append(f"runtime-native skill {skill_id} is not eligible")
        if runtime_entry.get("disabled") is True:
            errors.append(f"runtime-native skill {skill_id} is disabled")
        if runtime_entry.get("blockedByAgentFilter") is True:
            errors.append(f"runtime-native skill {skill_id} is blocked by the agent filter")
        if runtime_entry.get("blockedByAllowlist") is True:
            errors.append(f"runtime-native skill {skill_id} is blocked by the allowlist")
        missing = runtime_entry.get("missing", {})
        if isinstance(missing, dict):
            missing_items = sorted(
                f"{kind}:{item}"
                for kind, values in missing.items()
                if isinstance(values, list)
                for item in values
            )
            if missing_items:
                errors.append(
                    f"runtime-native skill {skill_id} reports missing requirements: "
                    f"{missing_items}"
                )
        missing_bins = missing_runtime_requirements(skill, which)
        if missing_bins:
            errors.append(
                f"runtime-native skill {skill_id} is missing required binaries: "
                f"{missing_bins}"
            )

    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--agent-id", default=os.environ.get("AGENT_ID"))
    parser.add_argument(
        "--catalog",
        type=Path,
        default=DEFAULT_CONFIG_ROOT / "config" / "skill-catalog.json",
    )
    parser.add_argument("--bundle", type=Path)
    parser.add_argument("--skills-dir", type=Path)
    parser.add_argument(
        "--skills-json",
        type=argparse.FileType("r", encoding="utf-8"),
        default=sys.stdin,
    )
    args = parser.parse_args()

    if not args.agent_id:
        print("ERROR: --agent-id or AGENT_ID is required", file=sys.stderr)
        return 2

    bundle_path = args.bundle or (
        args.catalog.parent / "agent-skill-bundles" / f"{args.agent_id}.json"
    )
    skills_dir = args.skills_dir or DEFAULT_WORKSPACE / "agents" / args.agent_id / "skills"

    try:
        runtime_payload = json.load(args.skills_json)
        catalog = load_json(args.catalog)
        bundle = load_json(bundle_path)
    except (json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    errors = collect_errors(
        catalog=catalog,
        bundle=bundle,
        runtime_payload=runtime_payload,
        skills_dir=skills_dir,
    )
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1

    print(
        f"Verified live skill provenance for {args.agent_id}: "
        f"{len(bundle['skills']['installed'])} declared skill(s)."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
