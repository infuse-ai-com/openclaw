#!/usr/bin/env node
// Offline, fixed-identity PKI preparation. Vault custody and Kubernetes writes
// belong to the operator; this program never calls either service.
import { X509Certificate, createPrivateKey, randomBytes } from 'node:crypto';
import { lstatSync, mkdirSync, readFileSync, realpathSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

export const AGENTS = ['agent-developer', 'agent-designer', 'agent-coordinator', 'agent-intake', 'agent-infra'];
const CLIENT_DNS = 'openclaw-dashboard.agents-swarm.svc.cluster.local';
const DAY = 86400000;
const EKU = { server: '1.3.6.1.5.5.7.3.1', client: '1.3.6.1.5.5.7.3.2' };
const fail = () => { throw new Error('PKI input, profile, custody or output validation failed'); };

function openssl(args) {
  const result = spawnSync('openssl', args, { encoding: 'utf8', timeout: 15000, maxBuffer: 128 * 1024 });
  if (result.error || result.status !== 0) fail();
  return result.stdout;
}

function file(path, privateKey = false) {
  const stat = lstatSync(path);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.uid !== process.getuid() ||
      stat.size > 65536 || (privateKey && (stat.mode & 0o077))) fail();
  return readFileSync(path);
}

function privateDirectory(path, create = false) {
  if (!isAbsolute(path) || resolve(path) !== path || realpathSync(dirname(path)) !== dirname(path)) fail();
  if (create) mkdirSync(path, { mode: 0o700 }); // Exclusive: never reuse partial output.
  const stat = lstatSync(path);
  if (!stat.isDirectory() || stat.isSymbolicLink() || stat.uid !== process.getuid() || (stat.mode & 0o077)) fail();
}

function write(path, value) { writeFileSync(path, value, { mode: 0o600, flag: 'wx' }); }
function sha(certificate) { return certificate.fingerprint256.replaceAll(':', '').toLowerCase(); }
function serial() { const bytes = randomBytes(20); bytes[0] &= 0x7f; bytes[0] |= 1; return `0x${bytes.toString('hex')}`; }
function rootName(role) { return `OpenClaw Internal ${role === 'server' ? 'Server' : 'Client'} CA`; }

function root(options, role) {
  privateDirectory(options.caDir);
  const certPath = join(options.caDir, 'ca.crt');
  const pem = file(certPath);
  if ((pem.toString().match(/BEGIN CERTIFICATE/g) ?? []).length !== 1) fail();
  const certificate = new X509Certificate(pem);
  if (!/^[a-f0-9]{64}$/.test(options.caSha256 ?? '') || sha(certificate) !== options.caSha256 ||
      !certificate.ca || certificate.subject !== `CN=${rootName(role)}` ||
      !certificate.checkIssued(certificate) || !certificate.verify(certificate.publicKey) ||
      certificate.keyUsage?.length !== 1 || certificate.keyUsage[0] !== EKU[role] ||
      Date.parse(certificate.validFrom) > Date.now() || Date.parse(certificate.validTo) - Date.now() < 120 * DAY ||
      Date.parse(certificate.validTo) - Date.parse(certificate.validFrom) > 1825 * DAY ||
      !/CA:TRUE,\s*pathlen:0/.test(openssl(['x509', '-in', certPath, '-noout', '-ext', 'basicConstraints']))) fail();
  const key = file(join(options.caDir, 'ca.key'), true);
  if (!certificate.checkPrivateKey(createPrivateKey(key))) fail();
  return certificate;
}

function identity(role, agent) {
  if (role === 'client') {
    if (agent !== undefined) fail();
    return { role, dns: CLIENT_DNS, commonName: 'openclaw-dashboard', secretName: 'openclaw-dashboard-gateway-client-tls' };
  }
  if (!AGENTS.includes(agent)) fail();
  return { role, agentId: agent, dns: `${agent}-dashboard-internal.agents-swarm.svc.cluster.local`,
    commonName: `${agent}-dashboard`, secretName: `${agent}-dashboard-internal-tls` };
}

function publicCertificate(certificate) {
  return { sha256: sha(certificate), notBefore: new Date(certificate.validFrom).toISOString(),
    notAfter: new Date(certificate.validTo).toISOString() };
}

export function prepare(command, options) {
  const match = /^(init|issue)-(server|client)(-ca)?$/.exec(command);
  if (!match || (match[1] === 'init') !== Boolean(match[3])) fail();
  const [, action, role] = match;
  const keys = action === 'init' ? ['output'] : ['output', 'caDir', 'caSha256', ...(role === 'server' ? ['agent'] : [])];
  if (Object.keys(options).length !== keys.length || keys.some((key) => typeof options[key] !== 'string')) fail();
  const profile = action === 'issue' ? identity(role, options.agent) : null;
  const issuer = action === 'issue' ? root(options, role) : null;
  process.umask(0o077);
  privateDirectory(options.output, true);
  const output = options.output;
  const keyPath = join(output, action === 'init' ? 'ca.key' : 'tls.key');
  const certPath = join(output, action === 'init' ? 'ca.crt' : 'tls.crt');
  openssl(['genpkey', '-algorithm', 'EC', '-pkeyopt', 'ec_paramgen_curve:P-256', '-out', keyPath]);
  const extensions = [
    `basicConstraints=critical,CA:${action === 'init' ? 'TRUE,pathlen:0' : 'FALSE'}`,
    `keyUsage=critical,${action === 'init' ? 'keyCertSign,cRLSign' : 'digitalSignature'}`,
    `extendedKeyUsage=${role}Auth`, 'subjectKeyIdentifier=hash',
    ...(action === 'issue' ? [`subjectAltName=DNS:${profile.dns}`, 'authorityKeyIdentifier=keyid,issuer'] : []),
  ];
  if (action === 'init') {
    openssl(['req', '-x509', '-new', '-sha256', '-key', keyPath, '-subj', `/CN=${rootName(role)}`,
      '-days', '1825', '-set_serial', serial(), '-out', certPath,
      ...extensions.flatMap((value) => ['-addext', value])]);
  } else {
    const csr = join(output, 'request.csr');
    const config = join(output, 'extensions.cnf');
    write(config, `${extensions.join('\n')}\n`);
    openssl(['req', '-new', '-sha256', '-key', keyPath, '-subj', `/CN=${profile.commonName}`, '-out', csr]);
    openssl(['x509', '-req', '-sha256', '-in', csr, '-CA', join(options.caDir, 'ca.crt'),
      '-CAkey', join(options.caDir, 'ca.key'), '-set_serial', serial(), '-days', '90', '-extfile', config, '-out', certPath]);
    openssl(['verify', '-CAfile', join(options.caDir, 'ca.crt'), '-purpose', role === 'server' ? 'sslserver' : 'sslclient', certPath]);
    unlinkSync(csr); unlinkSync(config);
  }
  const certificate = new X509Certificate(file(certPath));
  if (!certificate.checkPrivateKey(createPrivateKey(file(keyPath, true))) || certificate.keyUsage?.length !== 1 ||
      certificate.keyUsage[0] !== EKU[role]) fail();
  const manifest = { version: 1, role, ...publicCertificate(certificate), ...(profile ? {
    dns: profile.dns, ...(profile.agentId ? { agentId: profile.agentId } : {}),
    secretName: profile.secretName, namespace: 'agents-swarm', issuer: publicCertificate(issuer),
  } : { ca: true }) };
  if (profile && (certificate.ca || !certificate.verify(issuer.publicKey) || certificate.subjectAltName !== `DNS:${profile.dns}` ||
      Date.parse(certificate.validTo) - Date.parse(certificate.validFrom) !== 90 * DAY)) fail();
  write(join(output, 'public-metadata.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  // Safe public metadata only. Never log OpenSSL stderr, keys or PEM bodies.
  return manifest;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const options = {};
    const names = { '--output': 'output', '--ca-dir': 'caDir', '--ca-sha256': 'caSha256', '--agent': 'agent' };
    for (let i = 3; i < process.argv.length; i += 2) {
      const key = names[process.argv[i]];
      if (!key || options[key] !== undefined || !process.argv[i + 1]) fail();
      options[key] = process.argv[i + 1];
    }
    process.stdout.write(`${JSON.stringify(prepare(process.argv[2], options))}\n`);
  } catch {
    process.stderr.write('Internal gateway PKI preparation failed; no live systems were changed. Inspect protected inputs and any partial output locally.\n');
    process.exitCode = 1;
  }
}
