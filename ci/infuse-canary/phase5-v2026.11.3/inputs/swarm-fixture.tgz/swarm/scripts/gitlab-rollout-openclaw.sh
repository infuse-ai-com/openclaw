#!/usr/bin/env bash
set -euo pipefail

namespace="${OPENCLAW_NAMESPACE:-agents-swarm}"
expected_identity="${OPENCLAW_EXPECTED_IDENTITY:?OPENCLAW_EXPECTED_IDENTITY is required}"
target_source="${OPENCLAW_TARGET_SOURCE_COMMIT:?OPENCLAW_TARGET_SOURCE_COMMIT is required}"
target_version="${OPENCLAW_TARGET_VERSION:?OPENCLAW_TARGET_VERSION is required}"
evidence_dir="${OPENCLAW_EVIDENCE_DIR:-.gitlab-evidence/openclaw-deploy}"
target_image="${OPENCLAW_TARGET_IMAGE_REFERENCE:-}"
deployment_mode="${OPENCLAW_DEPLOYMENT_MODE:-canary}"
capability_dir=""
mutated_deployments=()

if [[ -z "$target_image" ]]; then
  target_file="${OPENCLAW_TARGET_IMAGE_FILE:?OPENCLAW_TARGET_IMAGE_FILE is required when OPENCLAW_TARGET_IMAGE_REFERENCE is unset}"
  [[ -s "$target_file" ]] || { echo "Target image evidence is missing: $target_file" >&2; exit 2; }
  target_image="$(sed -n '1p' "$target_file")"
fi

image_repository='registry.infuse-ai-tech.party/agents-swarm/openclaw-agent'
if [[ ! "$target_image" =~ ^${image_repository}@sha256:[0-9a-f]{64}$ ]]; then
  echo "Target image is outside the approved immutable repository" >&2
  exit 2
fi
target_digest="${target_image##*@}"
behavioral_observability_archive='/opt/openclaw-plugin-archives/behavioral-observability.tgz'
studio_archive='/opt/openclaw-plugin-archives/infuse-studio.tgz'
[[ "$target_source" =~ ^[0-9a-f]{40}$ ]] || { echo "Target source must be a full Git commit" >&2; exit 2; }
[[ "$target_version" == "2026.11.3" ]] || { echo "This cutover is limited to OpenClaw 2026.11.3" >&2; exit 2; }

all_deployments=(agent-developer agent-designer agent-infra agent-intake agent-coordinator)
case "$deployment_mode" in
  canary) deployments=(agent-developer) ;;
  fleet) deployments=(agent-designer agent-infra agent-intake agent-coordinator) ;;
  *) echo "OPENCLAW_DEPLOYMENT_MODE must be canary or fleet" >&2; exit 2 ;;
esac
mkdir -p "$evidence_dir/logs"

required_plugin_archives_for() {
  case "$1" in
    agent-developer|agent-coordinator)
      printf '%s %s\n' "$behavioral_observability_archive" "$studio_archive"
      ;;
    agent-designer|agent-infra|agent-intake)
      printf '%s\n' "$behavioral_observability_archive"
      ;;
    *)
      echo "Unknown deployment plugin contract: $1" >&2
      return 1
      ;;
  esac
}

get_exact_deployments() {
  for deployment in "${all_deployments[@]}"; do
    kubectl -n "$namespace" get "deployment/$deployment" -o json
  done | jq -s '{apiVersion:"v1",kind:"List",items:.}'
}

restore_previous_contract() {
  local original_status="$1"
  local deployment patch_file current_file attempt restored restoration_failed=0

  trap - EXIT
  if [[ "$original_status" -ne 0 && "${#mutated_deployments[@]}" -gt 0 ]]; then
    set +e
    mkdir -p "$evidence_dir/restore"
    echo "Rollout failed after mutation; restoring the captured Deployment contract." >&2
    for ((attempt = ${#mutated_deployments[@]} - 1; attempt >= 0; attempt--)); do
      deployment="${mutated_deployments[$attempt]}"
      patch_file="$evidence_dir/restore/$deployment-patch.json"
      current_file="$evidence_dir/restore/$deployment-final.json"
      jq -c --arg name "$deployment" '
        {spec:{template:(.items[] | select(.metadata.name == $name) | .spec.template)}}
      ' "$evidence_dir/baseline-deployments.json" >"$patch_file"
      if ! kubectl -n "$namespace" patch "deployment/$deployment" --type=merge \
          --patch-file "$patch_file" >/dev/null; then
        echo "Failed to restore captured template for deployment/$deployment" >&2
        restoration_failed=1
        continue
      fi
      restored=0
      for _ in $(seq 1 120); do
        if kubectl -n "$namespace" get "deployment/$deployment" -o json >"$current_file" &&
          jq -e --slurpfile patch "$patch_file" '
            .spec.template == $patch[0].spec.template
            and (.status.observedGeneration // 0) >= .metadata.generation
            and (.status.updatedReplicas // 0) == .spec.replicas
            and (.status.readyReplicas // 0) == .spec.replicas
            and (.status.availableReplicas // 0) == .spec.replicas
            and (.status.unavailableReplicas // 0) == 0
          ' "$current_file" >/dev/null; then
          restored=1
          echo "Restored deployment/$deployment to its captured ready contract." >&2
          break
        fi
        sleep 5
      done
      if [[ "$restored" -ne 1 ]]; then
        echo "Timed out restoring deployment/$deployment" >&2
        restoration_failed=1
      fi
    done
    jq -n \
      --argjson originalStatus "$original_status" \
      --argjson restorationFailed "$restoration_failed" \
      --argjson targets "$(printf '%s\n' "${mutated_deployments[@]}" | jq -R . | jq -s .)" \
      '{originalStatus:$originalStatus,restorationFailed:($restorationFailed == 1),targets:$targets}' \
      >"$evidence_dir/restore/summary.json"
  fi
  if [[ -n "$capability_dir" && -d "$capability_dir" ]]; then
    rm -rf -- "$capability_dir"
  fi
  exit "$original_status"
}

trap 'restore_previous_contract "$?"' EXIT

wait_for_exact_deployment() {
  local deployment="$1"
  local attempt current required_plugins
  required_plugins="$(required_plugin_archives_for "$deployment")"
  for attempt in $(seq 1 120); do
    current="$(kubectl -n "$namespace" get "deployment/$deployment" -o json)"
    if jq -e --arg image "$target_image" --arg source "$target_source" \
      --arg required_plugins "$required_plugins" '
      (.spec.template.spec.containers[] | select(.name=="agent") | .image) == $image
      and ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
        | select(.name=="OPENCLAW_REQUIRED_PLUGINS") | .value] | first) == $required_plugins
      and ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
        | select(.name=="OPENCLAW_CAPABILITY_CONSENT_PLUGINS") | .value] | first) == $required_plugins
      and .spec.template.metadata.annotations["openclaw.infuse-ai.com/swarm-source-revision"] == $source
      and (.status.observedGeneration // 0) >= .metadata.generation
      and (.status.updatedReplicas // 0) == .spec.replicas
      and (.status.readyReplicas // 0) == .spec.replicas
      and (.status.availableReplicas // 0) == .spec.replicas
      and (.status.unavailableReplicas // 0) == 0
    ' <<<"$current" >/dev/null; then
      echo "deployment/$deployment reached the exact ready generation"
      return 0
    fi
    sleep 5
  done
  echo "Timed out waiting for exact readiness of deployment/$deployment" >&2
  return 1
}

actual_identity="$(kubectl auth whoami -o json | jq -r '.status.userInfo.username')"
[[ "$actual_identity" == "$expected_identity" ]] || { echo "Unexpected Kubernetes identity: $actual_identity" >&2; exit 1; }
printf '%s\n' "$actual_identity" >"$evidence_dir/identity.txt"

for deployment in "${deployments[@]}"; do
  [[ "$(kubectl -n "$namespace" auth can-i get "deployment/$deployment")" == yes ]]
  [[ "$(kubectl -n "$namespace" auth can-i patch "deployment/$deployment")" == yes ]]
done
[[ "$(kubectl -n "$namespace" auth can-i get secrets)" == no ]]
[[ "$(kubectl -n "$namespace" auth can-i create pods/exec)" == no ]]
[[ "$(kubectl -n "$namespace" auth can-i delete persistentvolumeclaims)" == no ]]
[[ "$(kubectl -n default auth can-i patch deployments)" == no ]]

get_exact_deployments >"$evidence_dir/baseline-deployments.json"
kubectl -n "$namespace" get pvc -o json >"$evidence_dir/baseline-pvcs.json"

if [[ "$deployment_mode" == fleet ]]; then
  tinus="$(kubectl -n "$namespace" get deployment/agent-developer -o json)"
  tinus_required_plugins="$(required_plugin_archives_for agent-developer)"
  jq -e --arg image "$target_image" --arg source "$target_source" --arg version "$target_version" \
    --arg required_plugins "$tinus_required_plugins" '
    (.spec.template.spec.containers[] | select(.name=="agent") | .image) == $image
    and ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
      | select(.name=="OPENCLAW_REQUIRED_PLUGINS") | .value] | first) == $required_plugins
    and ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
      | select(.name=="OPENCLAW_CAPABILITY_CONSENT_PLUGINS") | .value] | first) == $required_plugins
    and .spec.template.metadata.annotations["openclaw.infuse-ai.com/swarm-source-revision"] == $source
    and .spec.template.metadata.annotations["openclaw.infuse-ai.com/version"] == $version
    and (.status.observedGeneration // 0) >= .metadata.generation
    and (.status.readyReplicas // 0) == .spec.replicas
    and (.status.availableReplicas // 0) == .spec.replicas
    and (.status.unavailableReplicas // 0) == 0
  ' <<<"$tinus" >/dev/null || {
    echo "Tinus has not passed the exact-image canary gate" >&2
    exit 1
  }
  tinus_pods="$(kubectl -n "$namespace" get pods -l app.kubernetes.io/name=agent-developer -o json)"
  jq -e --arg image "$target_image" --arg digest "$target_digest" '
    [.items[] | select(.metadata.deletionTimestamp == null)] as $active
    | ($active | length) == 1
    and $active[0].status.phase == "Running"
    and any($active[0].spec.containers[]; .name == "agent" and .image == $image)
    and any($active[0].status.containerStatuses[];
      .name == "agent" and .ready == true and .restartCount == 0
      and (.imageID | endswith("@" + $digest)))
  ' <<<"$tinus_pods" >/dev/null || {
    echo "Tinus pod has not passed the exact immutable-image gate" >&2
    exit 1
  }
fi

apply_dashboard_capabilities="${OPENCLAW_APPLY_DASHBOARD_CAPABILITIES:-0}"
dashboard_config_source="${OPENCLAW_DASHBOARD_CONFIG_SOURCE_COMMIT:-$target_source}"
if [[ "$apply_dashboard_capabilities" == 1 ]]; then
  if [[ ! "$dashboard_config_source" =~ ^[0-9a-f]{40}$ ]] ||
    ! git merge-base --is-ancestor "$target_source" "$dashboard_config_source"; then
    echo "Dashboard config source must descend from the approved image source" >&2
    exit 2
  fi
  printf '%s\n' "$dashboard_config_source" >"$evidence_dir/dashboard-config-source.txt"
  umask 077
  capability_dir="$(mktemp -d)"
  for deployment in "${deployments[@]}"; do
    jq -e --arg name "$deployment" '.items[] | select(.metadata.name == $name)' \
      "$evidence_dir/baseline-deployments.json" >"$capability_dir/$deployment.json"
    python3 scripts/prepare-dashboard-capabilities.py "$capability_dir/$deployment.json" \
      "$dashboard_config_source" "$deployment" "$capability_dir/$deployment.preflight"
  done
fi

while IFS= read -r live_source; do
  [[ "$live_source" =~ ^[0-9a-f]{40}$ ]] || { echo "Live source annotation is invalid" >&2; exit 1; }
  git cat-file -e "$live_source^{commit}"
  git merge-base --is-ancestor "$live_source" "$target_source" || {
    echo "Live source $live_source is not an ancestor of target $target_source" >&2
    exit 1
  }
done < <(jq -r '[.items[].spec.template.metadata.annotations["openclaw.infuse-ai.com/swarm-source-revision"]] | unique[]' "$evidence_dir/baseline-deployments.json")

rollout_timestamp="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
changed=0
for deployment in "${deployments[@]}"; do
  live="$(kubectl -n "$namespace" get "deployment/$deployment" -o json)"
  live_image="$(jq -r '.spec.template.spec.containers[] | select(.name=="agent") | .image' <<<"$live")"
  live_source="$(jq -r '.spec.template.metadata.annotations["openclaw.infuse-ai.com/swarm-source-revision"]' <<<"$live")"
  required_plugins="$(required_plugin_archives_for "$deployment")"
  live_plugin_contract=0
  if jq -e --arg required_plugins "$required_plugins" '
    ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
      | select(.name=="OPENCLAW_REQUIRED_PLUGINS") | .value] | first) == $required_plugins
    and ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
      | select(.name=="OPENCLAW_CAPABILITY_CONSENT_PLUGINS") | .value] | first) == $required_plugins
  ' <<<"$live" >/dev/null; then
    live_plugin_contract=1
  fi
  config_changed=0
  tunnel_changed=0
  if [[ "$apply_dashboard_capabilities" == 1 ]]; then
    printf '%s' "$live" >"$capability_dir/$deployment.live"
    python3 scripts/prepare-dashboard-capabilities.py "$capability_dir/$deployment.live" \
      "$dashboard_config_source" "$deployment" "$capability_dir/$deployment.config"
    if jq -e --arg image "$target_image" '
      any(.spec.template.spec.containers[]; .name=="gateway-internal-tls" and .image != $image)
    ' <<<"$live" >/dev/null; then
      tunnel_changed=1
    fi
    if ! jq -e --rawfile desired "$capability_dir/$deployment.config" '
      (.spec.template.spec.containers[] | select(.name=="agent") | .env[]
        | select(.name=="OPENCLAW_CONFIG_JSON") | .value | fromjson) == ($desired | fromjson)
    ' <<<"$live" >/dev/null; then
      config_changed=1
    fi
  fi
  if [[ "$live_image" == "$target_image" && "$live_source" == "$target_source" && "$live_plugin_contract" == 1 && "$config_changed" == 0 && "$tunnel_changed" == 0 ]]; then
    echo "deployment/$deployment is already converged"
  else
    patch="$(jq -cn \
      --arg image "$target_image" \
      --arg digest "$target_digest" \
      --arg source "$target_source" \
      --arg version "$target_version" \
      --arg required_plugins "$required_plugins" \
      --arg pipeline "${CI_PIPELINE_ID:-local}" \
      --arg restarted "$rollout_timestamp" \
      '{spec:{template:{metadata:{annotations:{"openclaw.infuse-ai.com/image-revision":$digest,"openclaw.infuse-ai.com/swarm-source-revision":$source,"openclaw.infuse-ai.com/version":$version,"gitlab.infuse-ai.com/pipeline-id":$pipeline,"kubectl.kubernetes.io/restartedAt":$restarted}},spec:{containers:[{name:"agent",image:$image,env:[{name:"OPENCLAW_REQUIRED_PLUGINS",value:$required_plugins},{name:"OPENCLAW_CAPABILITY_CONSENT_PLUGINS",value:$required_plugins}]}]}}}}')"
    if [[ "$apply_dashboard_capabilities" == 1 ]]; then
      resource_version="$(jq -er .metadata.resourceVersion "$capability_dir/$deployment.live")"
      jq --arg rv "$resource_version" --arg image "$target_image" \
        --argjson tunnel_changed "$tunnel_changed" --rawfile config "$capability_dir/$deployment.config" \
      '        .metadata.resourceVersion = $rv
        | .spec.template.spec.containers[0].env += [{name:"OPENCLAW_CONFIG_JSON",value:$config}]
        | if $tunnel_changed == 1 then
            .spec.template.spec.containers += [{name:"gateway-internal-tls",image:$image}]
          else . end
      ' <<<"$patch" >"$capability_dir/patch.json"
      mutated_deployments+=("$deployment")
      kubectl -n "$namespace" patch "deployment/$deployment" --type=strategic \
        --patch-file "$capability_dir/patch.json" >/dev/null
    else
      mutated_deployments+=("$deployment")
      kubectl -n "$namespace" patch "deployment/$deployment" --type=strategic -p "$patch" >/dev/null
    fi
    changed=$((changed + 1))
  fi

  wait_for_exact_deployment "$deployment"
  current="$(kubectl -n "$namespace" get "deployment/$deployment" -o json)"
  jq -e --arg image "$target_image" --arg source "$target_source" \
    --arg required_plugins "$required_plugins" '
    (.spec.template.spec.containers[] | select(.name=="agent") | .image) == $image
    and ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
      | select(.name=="OPENCLAW_REQUIRED_PLUGINS") | .value] | first) == $required_plugins
    and ([.spec.template.spec.containers[] | select(.name=="agent") | .env[]?
      | select(.name=="OPENCLAW_CAPABILITY_CONSENT_PLUGINS") | .value] | first) == $required_plugins
    and .spec.template.metadata.annotations["openclaw.infuse-ai.com/swarm-source-revision"] == $source
    and (.status.readyReplicas // 0) == .spec.replicas
    and (.status.availableReplicas // 0) == .spec.replicas
  ' <<<"$current" >/dev/null

  pods="$(kubectl -n "$namespace" get pods -l "app.kubernetes.io/name=$deployment" -o json)"
  jq -e --arg image "$target_image" --arg digest "$target_digest" '
    [.items[] | select(.metadata.deletionTimestamp == null)] as $active
    | ($active | length) == 1
    and $active[0].status.phase == "Running"
    and any($active[0].spec.containers[]; .name == "agent" and .image == $image)
    and any($active[0].status.containerStatuses[];
      .name == "agent" and .ready == true and .restartCount == 0
      and (.imageID | endswith("@" + $digest)))
  ' <<<"$pods" >/dev/null

  kubectl -n "$namespace" logs "deployment/$deployment" -c agent --since=20m --tail=800 \
    >"$evidence_dir/logs/$deployment.log"
  if grep -En 'SessionCanonicalKeyMigrationRequiredError|invalid persisted session row requires repair|openChannelIngressQueue is only available for trusted plugins|route conflict at /mattermost/interactions' \
      "$evidence_dir/logs/$deployment.log"; then
    echo "Known fatal runtime regression found in deployment/$deployment logs" >&2
    exit 1
  fi
done

get_exact_deployments >"$evidence_dir/final-deployments.json"
kubectl -n "$namespace" get pvc -o json >"$evidence_dir/final-pvcs.json"
if [[ "$deployment_mode" == canary ]]; then
  for deployment in agent-designer agent-infra agent-intake agent-coordinator; do
    jq -e --arg name "$deployment" '
      (.items[] | select(.metadata.name == $name) | .spec.template)
      == (input.items[] | select(.metadata.name == $name) | .spec.template)
    ' "$evidence_dir/baseline-deployments.json" "$evidence_dir/final-deployments.json" >/dev/null || {
      echo "Tinus canary changed peer deployment/$deployment" >&2
      exit 1
    }
  done
fi
jq -n \
  --arg targetImage "$target_image" \
  --arg targetSource "$target_source" \
  --arg targetVersion "$target_version" \
  --arg deploymentMode "$deployment_mode" \
  --arg identity "$actual_identity" \
  --argjson changed "$changed" \
  --argjson targets "$(printf '%s\n' "${deployments[@]}" | jq -R . | jq -s .)" \
  '{targetImage:$targetImage,targetSource:$targetSource,targetVersion:$targetVersion,deploymentMode:$deploymentMode,targets:$targets,identity:$identity,changedDeployments:$changed,backupRestore:"explicitly-excluded"}' \
  >"$evidence_dir/summary.json"

echo "OpenClaw $deployment_mode rollout qualified: changed=$changed image=$target_image source=$target_source"
