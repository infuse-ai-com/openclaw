#!/usr/bin/env python3
"""Create/reuse an agent Mattermost bot and store its token in Vaultwarden.

This script intentionally never prints token values.
"""
from __future__ import annotations

import base64
import json
import os
import pathlib
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


def env(name: str, default: str | None = None, required: bool = False) -> str:
    value = os.environ.get(name, default)
    if required and not value:
        raise SystemExit(f"{name} is required")
    return value or ""


def load_mm_config() -> tuple[str, str]:
    path = pathlib.Path.home() / ".openclaw" / "openclaw.json"
    with path.open() as f:
        cfg = json.load(f)
    mm = cfg.get("channels", {}).get("mattermost", {})
    base_url = (mm.get("baseUrl") or "").rstrip("/")
    token = resolve_secret_ref(mm.get("botToken"), cfg)
    if not base_url or not token:
        raise SystemExit("Mattermost baseUrl/botToken not found in ~/.openclaw/openclaw.json")
    return base_url, token


def resolve_secret_ref(value: Any, config: dict[str, Any]) -> str:
    """Resolve the OpenClaw string/env/exec SecretRef without printing it."""
    if isinstance(value, str):
        return value
    if not isinstance(value, dict):
        return ""
    source = value.get("source")
    secret_id = value.get("id")
    if not isinstance(secret_id, str) or not secret_id:
        raise SystemExit("Mattermost botToken SecretRef id is invalid")
    if source == "env":
        token = os.environ.get(secret_id)
        if not token:
            raise SystemExit("Mattermost botToken environment SecretRef is unavailable")
        return token
    if source != "exec":
        raise SystemExit("Mattermost botToken SecretRef source is unsupported")

    provider_name = value.get("provider")
    providers = config.get("secrets", {}).get("providers", {})
    provider = providers.get(provider_name) if isinstance(providers, dict) else None
    if not isinstance(provider_name, str) or not isinstance(provider, dict) or provider.get("source") != "exec":
        raise SystemExit("Mattermost botToken exec provider is invalid")
    command = provider.get("command")
    args = provider.get("args", [])
    if not isinstance(command, str) or not pathlib.Path(command).is_absolute():
        raise SystemExit("Mattermost botToken exec provider command is invalid")
    command_path = pathlib.Path(command)
    try:
        resolved_command = command_path.resolve(strict=True)
    except OSError:
        raise SystemExit("Mattermost botToken exec provider command is unavailable") from None
    if command_path != resolved_command and not provider.get("allowSymlinkCommand", False):
        raise SystemExit("Mattermost botToken exec provider command cannot use symlinks")
    if not resolved_command.is_file() or not os.access(resolved_command, os.X_OK):
        raise SystemExit("Mattermost botToken exec provider command is unavailable")
    if not isinstance(args, list) or not all(isinstance(arg, str) for arg in args):
        raise SystemExit("Mattermost botToken exec provider arguments are invalid")

    child_env: dict[str, str] = {}
    pass_env = provider.get("passEnv", [])
    configured_env = provider.get("env", {})
    if not isinstance(pass_env, list) or not all(isinstance(name, str) for name in pass_env):
        raise SystemExit("Mattermost botToken exec provider passEnv is invalid")
    if not isinstance(configured_env, dict) or not all(
        isinstance(key, str) and isinstance(item, str) for key, item in configured_env.items()
    ):
        raise SystemExit("Mattermost botToken exec provider environment is invalid")
    for name in pass_env:
        if name in os.environ:
            child_env[name] = os.environ[name]
    child_env.update(configured_env)
    request = json.dumps({"protocolVersion": 1, "provider": provider_name, "ids": [secret_id]}).encode()
    timeout_ms = provider.get("timeoutMs", 5000)
    max_output_bytes = provider.get("maxOutputBytes", 1024 * 1024)
    if not isinstance(timeout_ms, int) or timeout_ms <= 0:
        timeout_ms = 5000
    if not isinstance(max_output_bytes, int) or max_output_bytes <= 0:
        max_output_bytes = 1024 * 1024
    try:
        result = subprocess.run(
            [str(resolved_command), *args],
            input=request,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=resolved_command.parent,
            env=child_env,
            timeout=timeout_ms / 1000,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        raise SystemExit("Mattermost botToken exec provider failed") from None
    if result.returncode != 0 or len(result.stdout) > max_output_bytes:
        raise SystemExit("Mattermost botToken exec provider failed")
    try:
        response = json.loads(result.stdout.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise SystemExit("Mattermost botToken exec provider response is invalid") from None
    values = response.get("values") if isinstance(response, dict) and response.get("protocolVersion") == 1 else None
    token = values.get(secret_id) if isinstance(values, dict) else None
    if not isinstance(token, str) or not token:
        raise SystemExit("Mattermost botToken exec provider did not return the requested id")
    return token


class Mattermost:
    def __init__(self) -> None:
        self.base_url, self.token = load_mm_config()
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "OpenClaw-Agent-Onboarding/1.0",
        }

    def req(self, method: str, path: str, data: dict[str, Any] | None = None) -> tuple[int, Any]:
        body = None if data is None else json.dumps(data).encode()
        req = urllib.request.Request(self.base_url + path, data=body, headers=self.headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=25) as resp:
                text = resp.read().decode()
                return resp.status, json.loads(text) if text else None
        except urllib.error.HTTPError as e:
            text = e.read().decode(errors="replace")
            try:
                return e.code, json.loads(text)
            except Exception:
                return e.code, {"message": text}

    def ok(self, method: str, path: str, data: dict[str, Any] | None = None) -> Any:
        status, payload = self.req(method, path, data)
        if status < 200 or status >= 300:
            msg = payload.get("message") if isinstance(payload, dict) else payload
            raise SystemExit(f"Mattermost API error {status} {method} {path}: {msg}")
        return payload


def q(value: str) -> str:
    return urllib.parse.quote(value, safe="")


def bw(args: list[str], input_text: str | None = None) -> str:
    helper = env("BW_HELPER", "/Users/mac/.openclaw/workspace/scripts/bw-infuse-vaultwarden.sh")
    proc = subprocess.run(
        [helper, *args],
        input=input_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if proc.returncode != 0:
        raise SystemExit(f"Vaultwarden command failed: {' '.join(args)}\n{proc.stderr.strip()}")
    return proc.stdout


def bw_json(args: list[str], input_text: str | None = None) -> Any:
    output = bw(args, input_text)
    return json.loads(output) if output.strip() else None


def bw_encode(data: dict[str, Any]) -> str:
    raw = json.dumps(data, separators=(",", ":"))
    return bw(["encode"], raw).strip()


def find_collection_id(collection_name: str) -> tuple[str | None, str | None]:
    orgs = bw_json(["list", "organizations"]) or []
    for org in orgs:
        org_id = org.get("id")
        collections = bw_json(["list", "org-collections", "--organizationid", org_id]) or []
        for collection in collections:
            if collection.get("name") == collection_name:
                return org_id, collection.get("id")
    return None, None


def preflight_vault_item(name: str) -> tuple[str | None, str | None]:
    helper = env("BW_HELPER", "/Users/mac/.openclaw/workspace/scripts/bw-infuse-vaultwarden.sh")
    if not pathlib.Path(helper).is_file():
        raise SystemExit(f"Vaultwarden helper not found: {helper}")
    bw(["status"])
    if vault_item_exists(name) and env("OVERWRITE_VAULT_ITEM", "false") != "true":
        raise SystemExit(f"Vaultwarden item already exists, refusing to overwrite: {name}")
    return find_collection_id(env("VAULTWARDEN_COLLECTION", "05-Mattermost"))


def vault_item_exists(name: str) -> bool:
    proc = subprocess.run(
        [env("BW_HELPER", "/Users/mac/.openclaw/workspace/scripts/bw-infuse-vaultwarden.sh"), "get", "item", name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return proc.returncode == 0


def create_vault_item(
    *,
    name: str,
    username: str,
    password: str,
    base_url: str,
    notes: str,
    org_id: str | None,
    collection_id: str | None,
) -> None:
    if vault_item_exists(name) and env("OVERWRITE_VAULT_ITEM", "false") != "true":
        raise SystemExit(f"Vaultwarden item already exists, refusing to overwrite: {name}")

    item: dict[str, Any] = {
        "type": 1,
        "name": name,
        "notes": notes,
        "login": {
            "username": username,
            "password": password,
            "uris": [{"uri": base_url}],
        },
    }
    if org_id:
        item["organizationId"] = org_id
    if collection_id:
        item["collectionIds"] = [collection_id]

    encoded = bw_encode(item)
    if vault_item_exists(name):
        existing = bw_json(["get", "item", name])
        bw(["edit", "item", existing["id"]], encoded + "\n")
    else:
        bw(["create", "item"], encoded + "\n")


def main() -> int:
    agent_id = env("AGENT_ID", required=True)
    username = env("MATTERMOST_BOT_USERNAME", agent_id)
    display_name = env("MATTERMOST_BOT_DISPLAY_NAME", agent_id)
    description = env("MATTERMOST_BOT_DESCRIPTION", f"Scoped OpenClaw persistent agent: {agent_id}")
    channel_id = env("MATTERMOST_CHANNEL_ID", required=True)
    vault_item = env("VAULTWARDEN_ITEM_NAME", f"Mattermost / {agent_id} BOT token")
    dry_run = env("DRY_RUN", "false") == "true"

    mm = Mattermost()
    me = mm.ok("GET", "/api/v4/users/me")
    if "system_admin" not in (me.get("roles") or "").split():
        raise SystemExit("Mattermost bot onboarding requires a system_admin token")

    status, existing_user = mm.req("GET", f"/api/v4/users/username/{q(username)}")
    if status == 200:
        bot_user = existing_user
        bot_action = "reused"
    elif status == 404:
        bot_user = None
        bot_action = "would_create" if dry_run else "created"
    else:
        msg = existing_user.get("message") if isinstance(existing_user, dict) else existing_user
        raise SystemExit(f"Mattermost API error {status} checking user: {msg}")

    if dry_run:
        print(json.dumps({
            "agent_id": agent_id,
            "bot_username": username,
            "bot_action": bot_action,
            "channel_id": channel_id,
            "vault_item": vault_item,
            "will_store_token": True,
        }, indent=2))
        return 0

    org_id, collection_id = preflight_vault_item(vault_item)

    if bot_user is None:
        bot_user = mm.ok("POST", "/api/v4/bots", {
            "username": username,
            "display_name": display_name,
            "description": description,
        })

    bot_id = bot_user["user_id"] if "user_id" in bot_user else bot_user["id"]

    token_payload = mm.ok("POST", f"/api/v4/users/{q(bot_id)}/tokens", {
        "description": f"{agent_id} OpenClaw runtime token",
    })
    bot_token = token_payload.get("token")
    if not bot_token:
        raise SystemExit("Mattermost did not return a bot token")

    create_vault_item(
        name=vault_item,
        username=username,
        password=bot_token,
        base_url=mm.base_url,
        notes=f"Token for {agent_id} Mattermost bot. Created by openclaw-k8s-swarm onboarding helper.",
        org_id=org_id,
        collection_id=collection_id,
    )

    status, _ = mm.req("POST", f"/api/v4/channels/{q(channel_id)}/members", {"user_id": bot_id})
    if status not in (201, 200):
        # Mattermost returns 400 if the user is already a channel member.
        if status != 400:
            raise SystemExit(f"Mattermost API error {status} adding bot to channel")

    print(json.dumps({
        "agent_id": agent_id,
        "bot_username": username,
        "bot_action": bot_action,
        "bot_user_id": bot_id,
        "channel_id": channel_id,
        "vault_item": vault_item,
        "token_stored": True,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
