#!/usr/bin/env bash
set -euo pipefail

context="${KUBE_CONTEXT:-infuseai-k8s}"
namespace="${NAMESPACE:-agents-swarm}"
agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-designer}"
bundle_path="config/agent-skill-bundles/$agent_id.json"

if [[ ! -f "$bundle_path" ]]; then
  echo "Agent skill bundle not found: $bundle_path" >&2
  exit 2
fi

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"
pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

tmp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT

skills_dir="$tmp_dir/skills"
AGENT_SKILLS_DIR="$skills_dir" \
AGENT_ID="$agent_id" \
SKILL_SOURCE_SYNC="${SKILL_SOURCE_SYNC:-latest}" \
scripts/install-agent-skills.py >/dev/null

# Capability preflight intentionally compares the reviewed full bundle with the
# active source-managed view. Materialize both into the candidate directory so
# the atomic swap can never remove or strand either provenance manifest.
AGENT_SKILLS_DIR="$skills_dir" \
AGENT_ID="$agent_id" \
SKILL_SOURCE_SYNC="${SKILL_SOURCE_SYNC:-latest}" \
SKILL_SOURCE_IDS="${SKILL_SOURCE_IDS:-infuse-ai-agent-skills}" \
SKILL_MANIFEST_NAME=skill-source-sync-manifest.json \
scripts/install-agent-skills.py >/dev/null

scripts/verify-agent-skill-manifest-parity.py \
  --agent-id "$agent_id" \
  --bundle "$skills_dir/skill-bundle-manifest.json" \
  --active "$skills_dir/skill-source-sync-manifest.json" >/dev/null

"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "rm -rf '/workspace/agents/$agent_id/skills.tmp' && mkdir -p '/workspace/agents/$agent_id/skills.tmp'"

tar -C "$skills_dir" -cf - . | "${kubectl_base[@]}" exec -i "$pod" -c agent -- \
  tar -C "/workspace/agents/$agent_id/skills.tmp" -xf -

"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "rm -rf '/workspace/agents/$agent_id/skills.prev' && \
   if [ -d '/workspace/agents/$agent_id/skills' ]; then mv '/workspace/agents/$agent_id/skills' '/workspace/agents/$agent_id/skills.prev'; fi && \
   mv '/workspace/agents/$agent_id/skills.tmp' '/workspace/agents/$agent_id/skills' && \
   test -f '/workspace/agents/$agent_id/skills/skill-bundle-manifest.json'"

restore_previous_skills() {
  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
    "rm -rf '/workspace/agents/$agent_id/skills.failed' && \
     mv '/workspace/agents/$agent_id/skills' '/workspace/agents/$agent_id/skills.failed' && \
     if [ -d '/workspace/agents/$agent_id/skills.prev' ]; then mv '/workspace/agents/$agent_id/skills.prev' '/workspace/agents/$agent_id/skills'; fi && \
     rm -rf '/workspace/agents/$agent_id/skills.failed'"
}

if ! "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "openclaw skills list --json | openclaw-agent-runtime-skills-verify --agent-id '$agent_id'"; then
  echo "Runtime skill provenance verification failed for $agent_id; restoring previous skills" >&2
  restore_previous_skills
  exit 1
fi

if ! "${kubectl_base[@]}" exec -i "$pod" -c agent -- \
  python3 - \
    --agent-id "$agent_id" \
    --bundle "/workspace/agents/$agent_id/skills/skill-bundle-manifest.json" \
    --active "/workspace/agents/$agent_id/skills/skill-source-sync-manifest.json" \
  < scripts/verify-agent-skill-manifest-parity.py >/dev/null; then
  echo "Skill manifest parity verification failed for $agent_id; restoring previous skills" >&2
  restore_previous_skills
  exit 1
fi

echo "Synced approved skills for $agent_id into pod $pod"
