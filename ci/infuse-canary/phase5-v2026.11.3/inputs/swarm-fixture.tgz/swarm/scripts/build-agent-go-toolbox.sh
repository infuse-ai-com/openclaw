#!/usr/bin/env bash
set -euo pipefail

# Build the existing CLI versions with a patched toolchain and dependencies.
# Archives are immutable inputs; module verification remains enabled. No host
# credentials or persistent agent state are needed by this build.
export CGO_ENABLED=0 GOTOOLCHAIN=local GOWORK=off GOFLAGS=-mod=mod
export GOOS="${TARGETOS:?}" GOARCH="${TARGETARCH:?}"
mkdir -p /out/build-info /build

source_archive() {
  local name="$1" url="$2" checksum="$3"
  mkdir -p "/build/$name"
  curl -fsSL "$url" -o "/build/$name.tgz"
  printf '%s  %s\n' "$checksum" "/build/$name.tgz" | sha256sum -c -
  tar -xzf "/build/$name.tgz" --strip-components=1 -C "/build/$name"
  printf '%s %s\n' "$checksum" "$url" > "/out/build-info/$name.source"
}

build() {
  local name="$1" package="$2" flags="${3:-}"
  go mod verify
  go build -trimpath -ldflags "$flags" -o "/out/$name" "$package"
  go version -m "/out/$name" > "/out/build-info/$name.txt"
  # Retain the resolved dependency graph for the exact binary in the image.
  cp go.mod "/out/build-info/$name.go.mod"
  cp go.sum "/out/build-info/$name.go.sum"
}

mkdir -p /build/task
cd /build/task
go mod init build.local/task
go get "github.com/go-task/task/v3/cmd/task@${TASK_VERSION:?}" \
  google.golang.org/grpc@v1.83.2 golang.org/x/net@v0.62.0 \
  github.com/go-jose/go-jose/v4@v4.1.6
build task github.com/go-task/task/v3/cmd/task

mkdir -p /build/kustomize
cd /build/kustomize
go mod init build.local/kustomize
go get "sigs.k8s.io/kustomize/kustomize/v5@${KUSTOMIZE_VERSION:?}" \
  golang.org/x/text@v0.43.0
build kustomize sigs.k8s.io/kustomize/kustomize/v5

mkdir -p /build/kubernetes
curl -fsSL "https://dl.k8s.io/${KUBECTL_VERSION:?}/kubernetes-src.tar.gz" -o /build/kubernetes.tgz
printf '%s  %s\n' "${KUBERNETES_SOURCE_SHA512:?}" /build/kubernetes.tgz | sha512sum -c -
tar -xzf /build/kubernetes.tgz -C /build/kubernetes
cd /build/kubernetes
# The upstream vendor tree contains vulnerable x/net and x/text. Resolve from
# the checksum-verified module graph with the explicit security updates; do not
# silently continue building the old vendor copies.
go get golang.org/x/net@v0.62.0 golang.org/x/text@v0.43.0
build kubectl ./cmd/kubectl "-X k8s.io/component-base/version.gitVersion=${KUBECTL_VERSION} -X k8s.io/component-base/version.gitMajor=1 -X k8s.io/component-base/version.gitMinor=35"

source_archive helm "https://codeload.github.com/helm/helm/tar.gz/refs/tags/${HELM_VERSION:?}" \
  02a324971cb708b7d32ab751772fb765b81df6d3e93c0c3e845b3f5baaf80c65
cd /build/helm
go get golang.org/x/net@v0.62.0 github.com/go-jose/go-jose/v4@v4.1.6
build helm ./cmd/helm "-X helm.sh/helm/v3/internal/version.version=${HELM_VERSION} -X helm.sh/helm/v3/internal/version.metadata=infuse.security"

source_archive docker "https://codeload.github.com/docker/cli/tar.gz/refs/tags/v${DOCKER_CLI_VERSION:?}" \
  55bcae5053f0914118d229658e2ac3a877dbdead6cb2c322e525d0c1e8bf78d2
cd /build/docker
cp vendor.mod go.mod
cp vendor.sum go.sum
go get golang.org/x/net@v0.62.0 github.com/go-jose/go-jose/v4@v4.1.6
build docker ./cmd/docker "-X github.com/docker/cli/cli/version.Version=${DOCKER_CLI_VERSION} -X github.com/docker/cli/cli/version.GitCommit=infuse-security-rebuild"

source_archive compose "https://codeload.github.com/docker/compose/tar.gz/refs/tags/${DOCKER_COMPOSE_VERSION:?}" \
  311077662698fd8e34769a894f9d5240befb1730990efa8ed58e0fa8725d2d84
cd /build/compose
go get golang.org/x/net@v0.62.0
build docker-compose ./cmd "-X github.com/docker/compose/v5/internal.Version=${DOCKER_COMPOSE_VERSION}"

source_archive gog "https://codeload.github.com/openclaw/gogcli/tar.gz/refs/tags/v${GOGCLI_VERSION:?}" \
  13cc07fe249f9ca2affe9320a96ef8fdee98b64f15a14bc1792ceec59d37774b
cd /build/gog
go get golang.org/x/net@v0.62.0
build gog ./cmd/gog "-X github.com/openclaw/gogcli/internal/cmd.version=v${GOGCLI_VERSION} -X github.com/openclaw/gogcli/internal/cmd.commit=infuse-security-rebuild"

source_archive crane "https://codeload.github.com/google/go-containerregistry/tar.gz/refs/tags/${CRANE_VERSION:?}" \
  a52cc7d61f8b2f043b7f0be1febecead5fceb791543c4790d699440f12d6b370
cd /build/crane
build crane ./cmd/crane "-X github.com/google/go-containerregistry/cmd/crane/cmd.Version=${CRANE_VERSION#v} -X github.com/google/go-containerregistry/pkg/v1/remote/transport.Version=${CRANE_VERSION#v}"
