#!/usr/bin/env bash
set -euo pipefail

source_namespace="${SOURCE_NAMESPACE:-agents-swarm}"
target_namespace="${TARGET_NAMESPACE:-core}"
configmap_name="${CONFIGMAP_NAME:-openclaw-agent-token-usage-feed}"
selector="${AGENT_SELECTOR:-app.kubernetes.io/component=persistent-agent}"
timeout_seconds="${EXPORT_TIMEOUT_SECONDS:-45}"

workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
snapshot_dir="$workdir/snapshots"
mkdir -p "$snapshot_dir"

kubectl_cmd=(kubectl)
if [[ -n "${KUBE_CONTEXT:-}" ]]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

pods_json_path="$workdir/pods.json"
"${kubectl_cmd[@]}" -n "$source_namespace" get pods -l "$selector" -o json >"$pods_json_path"
pod_rows=()
while IFS= read -r row; do
  pod_rows+=("$row")
done < <(python3 - "$pods_json_path" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    data = json.load(handle)
for item in data.get("items", []):
    metadata = item.get("metadata", {})
    labels = metadata.get("labels", {})
    name = metadata.get("name")
    agent_id = labels.get("app.kubernetes.io/name")
    phase = item.get("status", {}).get("phase")
    if name and agent_id and phase == "Running":
        print(f"{agent_id}\t{name}")
PY
)

if [[ "${#pod_rows[@]}" -eq 0 ]]; then
  echo "ERROR: no running agent pods matched selector ${selector} in namespace ${source_namespace}." >&2
  exit 1
fi

failure_count=0
for row in "${pod_rows[@]}"; do
  agent_id="${row%%$'\t'*}"
  pod_name="${row#*$'\t'}"
  output_path="$snapshot_dir/${agent_id}.json"

  echo "Collecting sanitized token usage snapshot from ${pod_name} (${agent_id})."
  if ! timeout "$timeout_seconds" "${kubectl_cmd[@]}" -n "$source_namespace" exec "pod/$pod_name" -c agent -- \
    bash -lc '
      set -euo pipefail
      agent_id="${AGENT_ID:-'"$agent_id"'}"
      agent_name="${AGENT_NAME:-$agent_id}"
      exporter="/usr/local/bin/openclaw-agent-token-usage-export"
      if [ ! -x "$exporter" ]; then
        echo "ERROR: $exporter is not executable in $agent_id" >&2
        exit 1
      fi
      "$exporter" \
        --agent-id "$agent_id" \
        --gateway-label "$agent_name Gateway" \
        --output -
    ' >"$output_path"; then
    echo "ERROR: failed to collect ${agent_id}." >&2
    rm -f "$output_path"
    failure_count=$((failure_count + 1))
    continue
  fi

  if ! python3 - "$output_path" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    snapshot = json.load(handle)
source = snapshot.get("source", {})
usage = snapshot.get("usage", {})
valid = (
    snapshot.get("schemaVersion") == 1
    and source.get("type") == "openclaw_agent_token_usage"
    and source.get("backend") == "gateway_sessions_usage"
    and source.get("status") in {"available", "no_usage_entries"}
    and (source.get("cacheStatus") == "fresh" or (
        source.get("cacheStatus") == "empty_window"
        and source.get("status") == "no_usage_entries"
        and source.get("sessionCount") == 0
    ))
    and isinstance(usage.get("periods4h"), list)
)
if not valid:
    raise SystemExit("invalid or non-fresh token usage snapshot")
PY
  then
    echo "ERROR: rejected invalid or non-fresh snapshot for ${agent_id}." >&2
    rm -f "$output_path"
    failure_count=$((failure_count + 1))
  fi
done

if [[ "$failure_count" -gt 0 ]]; then
  echo "ERROR: Refusing to update configmap/${configmap_name}; ${failure_count} agent snapshot(s) failed." >&2
  exit 1
fi

"${kubectl_cmd[@]}" -n "$target_namespace" create configmap "$configmap_name" \
  --from-file="$snapshot_dir" \
  --dry-run=client \
  -o yaml \
  | "${kubectl_cmd[@]}" apply -n "$target_namespace" -f -

echo "Updated configmap/${configmap_name} in namespace ${target_namespace} with ${#pod_rows[@]} agent snapshots."
