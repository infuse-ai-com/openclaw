#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

source_repo="$tmp_dir/openclaw-agents-memory"
checkout="$tmp_dir/runtime-memory"

mkdir -p \
  "$source_repo/agents/agent-developer/memory" \
  "$source_repo/agents/agent-developer/summaries" \
  "$source_repo/agents/agent-designer/memory" \
  "$source_repo/agents/agent-designer/summaries" \
  "$source_repo/docs" \
  "$source_repo/projects/openclaw-setup" \
  "$source_repo/schemas" \
  "$source_repo/scripts" \
  "$source_repo/shared" \
  "$source_repo/templates"

printf '# memory repo\n' >"$source_repo/README.md"
printf 'version: 1\n' >"$source_repo/.knowledge-base.yml"
printf '# docs\n' >"$source_repo/docs/architecture.md"
printf '# developer\n' >"$source_repo/agents/agent-developer/MEMORY.md"
printf 'developer daily\n' >"$source_repo/agents/agent-developer/memory/2026-06-21.md"
printf 'developer summary\n' >"$source_repo/agents/agent-developer/summaries/week.md"
printf '# designer\n' >"$source_repo/agents/agent-designer/MEMORY.md"
printf 'designer daily\n' >"$source_repo/agents/agent-designer/memory/2026-06-21.md"
printf 'designer summary\n' >"$source_repo/agents/agent-designer/summaries/week.md"
printf '# project\n' >"$source_repo/projects/openclaw-setup/README.md"
printf '{}\n' >"$source_repo/schemas/memory-frontmatter.schema.json"
printf '#!/usr/bin/env python3\n' >"$source_repo/scripts/search_memory.py"
chmod +x "$source_repo/scripts/search_memory.py"
printf '# shared\n' >"$source_repo/shared/README.md"
printf '# daily template\n' >"$source_repo/templates/daily-memory.md"

git -C "$source_repo" init -b main >/dev/null
git -C "$source_repo" config user.email "openclaw@example.invalid"
git -C "$source_repo" config user.name "OpenClaw Test"
git -C "$source_repo" add .
git -C "$source_repo" commit -m "seed memory repo" >/dev/null

python3 - "$repo_root/scripts/refresh-shared-agent-memory.py" "$source_repo" "$checkout" "$tmp_dir/state" <<'PYTEST'
import importlib.util, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location('refresh', sys.argv[1])
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
r = m.refresh(Path(sys.argv[3]), Path(sys.argv[4]), 'agent-developer', origin=sys.argv[2], force=True)
assert r['status'] in ('updated', 'unchanged'), r
PYTEST

required_paths=(
  ".knowledge-base.yml"
  "README.md"
  "docs/architecture.md"
  "projects/openclaw-setup/README.md"
  "schemas/memory-frontmatter.schema.json"
  "scripts/search_memory.py"
  "shared/README.md"
  "templates/daily-memory.md"
  "agents/agent-developer/MEMORY.md"
  "agents/agent-developer/memory/2026-06-21.md"
  "agents/agent-developer/summaries/week.md"
  "agents/agent-designer/summaries/week.md"
)

for path in "${required_paths[@]}"; do
  if [[ ! -e "$checkout/$path" ]]; then
    echo "missing expected sparse checkout path: $path" >&2
    exit 1
  fi
done

denied_paths=(
  "agents/agent-designer/MEMORY.md"
  "agents/agent-designer/memory/2026-06-21.md"
)

for path in "${denied_paths[@]}"; do
  if [[ -e "$checkout/$path" ]]; then
    echo "unexpected cross-agent raw memory path present: $path" >&2
    exit 1
  fi
done

echo "Shared memory sparse checkout verification passed"
