#!/usr/bin/env python3
"""Generate the sanitized Backoffice agent configuration catalog."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OVERLAY_PATH = ROOT / "k8s" / "overlays" / "infuseai" / "kustomization.yaml"
BUNDLE_DIR = ROOT / "config" / "agent-skill-bundles"
OUTPUT_PATH = ROOT / "config" / "backoffice-agent-catalog.v1.json"
SCHEMA_VERSION = 1
SOURCE = {
    "type": "openclaw_agent_catalog",
    "repository": "openclaw-k8s-swarm",
    "branch": "main",
}


class CatalogError(ValueError):
    """Raised when an authoritative source cannot produce a safe catalog."""


def load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise CatalogError(f"missing {path.relative_to(ROOT)}") from exc
    except json.JSONDecodeError as exc:
        raise CatalogError(f"invalid JSON in {path.relative_to(ROOT)}: {exc}") from exc
    if not isinstance(value, dict):
        raise CatalogError(f"{path.relative_to(ROOT)} must contain an object")
    return value


def scalar_after_path(text: str, patch_path: str, label: str) -> str:
    pattern = re.compile(
        rf"^\s*path:\s*{re.escape(patch_path)}\s*$\n"
        r"^\s*value:\s*(?P<value>[^\n]+)\s*$",
        re.MULTILINE,
    )
    match = pattern.search(text)
    if not match:
        raise CatalogError(f"{label} is missing scalar patch {patch_path}")
    return unquote_yaml_scalar(match.group("value").strip(), label)


def env_value(text: str, env_name: str, label: str) -> str:
    pattern = re.compile(
        rf"^\s*name:\s*{re.escape(env_name)}\s*$\n"
        r"(?:[^\n]*\n){0,4}?"
        r"^\s*value:\s*(?P<value>.+)$",
        re.MULTILINE,
    )
    match = pattern.search(text)
    if not match:
        raise CatalogError(f"{label} is missing environment value {env_name}")
    return unquote_yaml_scalar(match.group("value").strip(), label)


def unquote_yaml_scalar(value: str, label: str) -> str:
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1].replace("''", "'")
    if value.startswith('"') and value.endswith('"'):
        try:
            decoded = json.loads(value)
        except json.JSONDecodeError as exc:
            raise CatalogError(f"{label} contains an invalid quoted scalar: {exc}") from exc
        if not isinstance(decoded, str):
            raise CatalogError(f"{label} quoted scalar must decode to a string")
        return decoded
    return value


def active_agent_ids(overlay_text: str) -> list[str]:
    agent_ids = re.findall(r"^\s*-\s+\.\./\.\./agents/(agent-[a-z0-9-]+)\s*$", overlay_text, re.MULTILINE)
    if not agent_ids:
        raise CatalogError("Infuse AI overlay does not declare active agents")
    if len(agent_ids) != len(set(agent_ids)):
        raise CatalogError("Infuse AI overlay declares a duplicate agent")
    return agent_ids


def runtime_agent(config: dict, agent_id: str, label: str) -> dict:
    agents = config.get("agents", {})
    entries = agents.get("entries")
    if isinstance(entries, dict):
        agent = entries.get(agent_id)
    else:
        listed = agents.get("list")
        matches = [
            item
            for item in listed if isinstance(item, dict) and item.get("id") == agent_id
        ] if isinstance(listed, list) else []
        agent = matches[0] if len(matches) == 1 else None
    if not isinstance(agent, dict):
        raise CatalogError(f"{label} must declare runtime agent {agent_id}")
    return agent


def build_agent(agent_id: str) -> dict:
    bundle_path = BUNDLE_DIR / f"{agent_id}.json"
    deployment_path = ROOT / "k8s" / "agents" / agent_id / "deployment.yaml"
    if not deployment_path.is_file():
        raise CatalogError(f"missing {deployment_path.relative_to(ROOT)}")

    bundle = load_json(bundle_path)
    if bundle.get("agent_id") != agent_id or bundle.get("status") != "active":
        raise CatalogError(f"{bundle_path.relative_to(ROOT)} must describe active {agent_id}")
    display_name = bundle.get("friendly_name")
    role = bundle.get("role")
    skills = bundle.get("skills", {}).get("installed")
    if not isinstance(display_name, str) or not display_name:
        raise CatalogError(f"{bundle_path.relative_to(ROOT)} is missing friendly_name")
    if not isinstance(role, str) or not role:
        raise CatalogError(f"{bundle_path.relative_to(ROOT)} is missing role")
    if (
        not isinstance(skills, list)
        or not skills
        or not all(isinstance(skill, str) and skill for skill in skills)
        or len(skills) != len(set(skills))
    ):
        raise CatalogError(f"{bundle_path.relative_to(ROOT)} has invalid installed skills")

    deployment_text = deployment_path.read_text(encoding="utf-8")
    deployment_label = str(deployment_path.relative_to(ROOT))
    config_raw = env_value(deployment_text, "OPENCLAW_CONFIG_JSON", deployment_label)
    try:
        config = json.loads(config_raw)
    except json.JSONDecodeError as exc:
        raise CatalogError(f"{deployment_label} contains invalid OPENCLAW_CONFIG_JSON") from exc
    runtime = runtime_agent(config, agent_id, deployment_label)
    description = env_value(deployment_text, "AGENT_DESCRIPTION", deployment_label)
    if env_value(deployment_text, "AGENT_NAME", deployment_label) != display_name:
        raise CatalogError(f"{deployment_label} AGENT_NAME does not match bundle friendly_name")
    if runtime.get("name") != display_name or runtime.get("description") != description:
        raise CatalogError(f"{deployment_label} runtime identity does not match sanitized fields")
    if runtime.get("skills") != skills:
        raise CatalogError(f"{deployment_label} runtime skills do not match the bundle")

    mattermost = config.get("channels", {}).get("mattermost")
    if not isinstance(mattermost, dict) or mattermost.get("enabled") is not True:
        raise CatalogError(f"{deployment_label} does not enable Mattermost")
    require_mention = mattermost.get("requireMention")
    if not isinstance(require_mention, bool):
        raise CatalogError(f"{deployment_label} Mattermost requireMention must be boolean")

    deployment_name = scalar_after_path(
        deployment_text,
        "/metadata/name",
        deployment_label,
    )
    if deployment_name != agent_id:
        raise CatalogError(f"{deployment_label} workload name must be {agent_id}")

    return {
        "agentId": agent_id,
        "displayName": display_name,
        "role": role,
        "description": description,
        "lifecycle": "active",
        "mattermost": {
            "username": agent_id,
            "groupActivation": "mention" if require_mention else "all",
        },
        "skills": {"installed": skills},
    }


def build_catalog() -> dict:
    overlay_text = OVERLAY_PATH.read_text(encoding="utf-8")
    return {
        "schemaVersion": SCHEMA_VERSION,
        "source": SOURCE,
        "agents": [build_agent(agent_id) for agent_id in active_agent_ids(overlay_text)],
    }


def render_catalog() -> str:
    return json.dumps(build_catalog(), indent=2, ensure_ascii=False) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    try:
        expected = render_catalog()
    except (CatalogError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    if args.check:
        if not OUTPUT_PATH.is_file() or OUTPUT_PATH.read_text(encoding="utf-8") != expected:
            print(
                f"ERROR: {OUTPUT_PATH.relative_to(ROOT)} is stale; regenerate it",
                file=sys.stderr,
            )
            return 1
        print("Backoffice agent catalog is current.")
        return 0
    OUTPUT_PATH.write_text(expected, encoding="utf-8")
    print(f"Generated {OUTPUT_PATH.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
