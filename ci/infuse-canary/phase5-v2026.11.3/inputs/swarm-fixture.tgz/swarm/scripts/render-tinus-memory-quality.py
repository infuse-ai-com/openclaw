#!/usr/bin/env python3
"""Render a finite Tinus-only shadow observation, separate from normal releases."""
import hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'k8s/qualification/memory-learning-shadow'
files = {n:(ROOT/'scripts'/n).read_text() for n in ('observe-tinus-memory-quality.mjs','collect-tinus-memory-quality.py')}
digest = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
name = 'tinus-memory-shadow-' + digest[:12]
cm = {'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':name,'namespace':'agents-swarm','annotations':{'infuse.ai/content-sha256':digest}},'immutable':True,'data':files}
job = {'apiVersion':'batch/v1','kind':'CronJob','metadata':{'name':'tinus-memory-learning-shadow','namespace':'agents-swarm'},'spec':{
 'schedule':'50 2,3 14-16 11 *','timeZone':'Etc/UTC','suspend':False,'concurrencyPolicy':'Forbid','startingDeadlineSeconds':300,
 'successfulJobsHistoryLimit':6,'failedJobsHistoryLimit':6,
 'jobTemplate':{'spec':{'backoffLimit':1,'activeDeadlineSeconds':600,'ttlSecondsAfterFinished':604800,'template':{'spec':{
  'serviceAccountName':'openclaw-agent-memory-sync','imagePullSecrets':[{'name':'harbor-pull'}],'restartPolicy':'Never',
  'securityContext':{'runAsUser':10001,'runAsGroup':10001,'fsGroup':10001,'seccompProfile':{'type':'RuntimeDefault'}},
  'containers':[{'name':'observe','image':'registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4',
   'command':['python3','/probe/collect-tinus-memory-quality.py'],
   'env':[{'name':'SOURCE_NAMESPACE','valueFrom':{'fieldRef':{'fieldPath':'metadata.namespace'}}}],
   'volumeMounts':[{'name':'probe','mountPath':'/probe','readOnly':True},{'name':'scratch','mountPath':'/tmp'}],
   'resources':{'requests':{'cpu':'50m','memory':'128Mi'},'limits':{'cpu':'250m','memory':'256Mi'}},
   'securityContext':{'runAsNonRoot':True,'allowPrivilegeEscalation':False,'readOnlyRootFilesystem':True,'capabilities':{'drop':['ALL']}}}],
  'volumes':[{'name':'probe','configMap':{'name':name,'defaultMode':292}},{'name':'scratch','emptyDir':{}}]
 }}}}}}
OUT.mkdir(parents=True,exist_ok=True)
for file,value in [('configmap.json',cm),('cronjob.json',job)]: (OUT/file).write_text(json.dumps(value,indent=2)+'\n')
print(name)
