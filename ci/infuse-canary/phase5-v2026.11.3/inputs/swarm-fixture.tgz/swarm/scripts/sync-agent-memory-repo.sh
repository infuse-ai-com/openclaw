#!/usr/bin/env bash
set -euo pipefail
# ConfigMap delivery and image delivery use the same reviewed Python source.
helper="${OPENCLAW_MEMORY_MIRROR_HELPER:-/opt/openclaw-memory-mirror/mirror-agent-memory.py}"
if [[ ! -f "$helper" ]]; then
  helper="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/mirror-agent-memory.py"
fi
exec python3 "$helper" "$@"
