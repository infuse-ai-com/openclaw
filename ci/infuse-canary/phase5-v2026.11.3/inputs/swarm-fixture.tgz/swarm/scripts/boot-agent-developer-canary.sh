#!/usr/bin/env bash
set -euo pipefail

profile="${OPENCLAW_AGENT_PROFILE:-${AGENT_ID:-agent-developer}}"
agent_id="${AGENT_ID:-agent-developer}"
profile_dir="$HOME/.openclaw-$profile"
agent_dir="$profile_dir/agents/$agent_id/agent"
state_dir="${OPENCLAW_STATE_DIR:-$profile_dir}"
state_agent_dir="$state_dir/agents/$agent_id/agent"
runtime_dir="$state_dir/.openclaw-runtime"
auth_migration_marker="$runtime_dir/doctor-2026.8.1-v17-auth-sqlite"
session_migration_marker="$runtime_dir/doctor-2026.9.7-agent-schema-v24-v1"
session_schema_v27_marker="$runtime_dir/doctor-2026.11.3-agent-schema-v27-v1"
plugin_migration_marker="$runtime_dir/openclaw-2026.11.3-bundled-plugins-v1"
exact_runtime_archive="/opt/openclaw-artifacts/openclaw-runtime.tgz"
exact_runtime_sha256="d2ac347e1bab31316b231f42d3ad1c5aac884f92792a351544432582c069cd22"
doctor_repair_mode="${OPENCLAW_DOCTOR_REPAIR_MODE:-automatic}"
required_behavioral_observability_spec="/opt/openclaw-plugin-archives/behavioral-observability.tgz"
skill_manifest="$OPENCLAW_AGENT_WORKSPACE/skills/skill-source-sync-manifest.json"

replace_otel_resource_attribute() {
  local key="$1"
  local value="$2"
  local current="${OTEL_RESOURCE_ATTRIBUTES:-}"
  local output=""
  local found=false
  local attribute
  IFS=',' read -r -a attributes <<<"$current"
  for attribute in "${attributes[@]}"; do
    if [[ "$attribute" == "$key="* ]]; then
      attribute="$key=$value"
      found=true
    fi
    if [[ -n "$output" ]]; then
      output+=","
    fi
    output+="$attribute"
  done
  if [[ "$found" != true ]]; then
    if [[ -n "$output" ]]; then
      output+=","
    fi
    output+="$key=$value"
  fi
  export OTEL_RESOURCE_ATTRIBUTES="$output"
}

skill_bundle_revision="unavailable"
if [[ -x /usr/local/bin/openclaw-agent-skill-bundle-revision && -f "$skill_manifest" ]]; then
  if ! skill_bundle_revision="$(/usr/local/bin/openclaw-agent-skill-bundle-revision "$skill_manifest" 2>/dev/null)"; then
    skill_bundle_revision="unavailable"
  fi
fi
if [[ "$skill_bundle_revision" == "unavailable" ]]; then
  echo "WARNING: skill bundle revision unavailable; continuing with bounded telemetry attribution" >&2
fi
replace_otel_resource_attribute "infuse.skill_bundle.revision" "$skill_bundle_revision"
if [[ "${OPENCLAW_DIAGNOSTICS_OTEL_CANARY:-false}" == "true" && "${OPENCLAW_IMAGE_REVISION:-dev}" == "dev" ]]; then
  echo "WARNING: immutable image revision unavailable; continuing with bounded telemetry attribution" >&2
fi

mkdir -p \
  "$profile_dir" \
  "$agent_dir" \
  "$state_dir" \
  "$state_agent_dir" \
  "$runtime_dir" \
  "$OPENCLAW_AGENT_WORKSPACE" \
  "$HOME/.acpx"

echo "$exact_runtime_sha256  $exact_runtime_archive" | sha256sum -c - >/dev/null
if [[ "${OPENCLAW_RUNTIME_VERSION:-}" != "2026.11.3" ]]; then
  echo "ERROR: expected OpenClaw runtime 2026.11.3, got ${OPENCLAW_RUNTIME_VERSION:-unset}" >&2
  exit 1
fi
if [[ "$doctor_repair_mode" != "automatic" && "$doctor_repair_mode" != "disabled" ]]; then
  echo "ERROR: OPENCLAW_DOCTOR_REPAIR_MODE must be automatic or disabled" >&2
  exit 2
fi

if [[ -n "${ACPX_CONFIG_JSON:-}" ]]; then
  umask 077
  printf '%s' "$ACPX_CONFIG_JSON" >"$HOME/.acpx/config.json"
fi
canonical_config="$(
  printf '%s' "$OPENCLAW_CONFIG_JSON" \
    | jq \
        --arg diagnostics_otel_canary "${OPENCLAW_DIAGNOSTICS_OTEL_CANARY:-false}" \
        --arg behavioral_observability_canary "${OPENCLAW_BEHAVIORAL_OBSERVABILITY_CANARY:-false}" \
        --arg otel_service_name "${OTEL_SERVICE_NAME:-openclaw-$agent_id}" \
        -ce '
        .update.channel = "beta"
        |
        if (.agents.entries | type) == "object" then .
        elif (.agents.list | type) == "array" then
          .agents.entries = reduce .agents.list[] as $agent
            ({}; .[$agent.id] = ($agent | del(.id)))
          | del(.agents.list)
        else . end
        | .agents.entries |= with_entries(.value |= del(.default))
        | .agents.defaults.modelPolicy.allow =
            ([.agents.defaults.model.primary]
              + (.agents.defaults.model.fallbacks // [])
              + (.agents.defaults.modelPolicy.allow // [])
              | map(select(type == "string" and length > 0))
              | unique)
        | .messages.inbound.byChannel.mattermost = 1500
        | .surfaces.mattermost.silentReply.group = "allow"
        | .surfaces.mattermost.replyCompletion.group = "message-or-reaction"
        | .channels.mattermost.groupAllowFrom = .channels.mattermost.allowFrom
        | .channels.mattermost.textChunkLimit = 12000
        | .channels.mattermost.actions.reactions = true
        | .channels.mattermost.streaming = {
            mode: "progress",
            progress: {
              label: "Thinking… please wait",
              finalDelivery: "separate",
              toolProgress: true,
              commandText: "raw",
              maxLines: 8,
              maxLineChars: 120
            }
          }
        | .plugins.entries.mattermost.enabled = true
        | .plugins.entries.acpx.enabled = true
        | .plugins.entries.codex.config.appServer.command = "/usr/local/bin/codex"
        | .plugins.allow =
            ((.plugins.allow // []) + ["acpx", "codex", "mattermost", "openai", "memory-core"]
              | unique)
        | if $diagnostics_otel_canary == "true" then
            .diagnostics = {
              enabled: true,
              otel: {
                enabled: true,
                endpoint: "http://openclaw-otel-collector:4318",
                protocol: "http/protobuf",
                serviceName: $otel_service_name,
                traces: true,
                metrics: true,
                logs: false,
                sampleRate: 1.0,
                flushIntervalMs: 10000,
                captureContent: false
              }
            }
            | .plugins.entries["diagnostics-otel"].enabled = true
            | .plugins.allow = ((.plugins.allow // []) + ["diagnostics-otel"] | unique)
          else . end
        | if $behavioral_observability_canary == "true" then
            .plugins.entries["behavioral-observability"].enabled = true
            | .plugins.entries["behavioral-observability"].hooks.allowConversationAccess = true
            | .plugins.allow =
                ((.plugins.allow // []) + ["behavioral-observability"] | unique)
          else . end
        | .meta.migrations.modelPolicyAllowlist = true
        | .meta.lastTouchedVersion = "2026.11.3"
      '
)"
unset OPENCLAW_CONFIG_JSON
bootstrap_config='{"update":{"channel":"beta"},"plugins":{"allow":["codex","mattermost","openai","acpx"],"entries":{"codex":{"enabled":true},"mattermost":{"enabled":true},"openai":{"enabled":true},"acpx":{"enabled":true}}}}'
if [[ "${OPENCLAW_DIAGNOSTICS_OTEL_CANARY:-false}" == "true" ]]; then
  bootstrap_config="$(
    printf '%s' "$bootstrap_config" \
      | jq -c '
          .plugins.allow = ((.plugins.allow // []) + ["diagnostics-otel"] | unique)
          | .plugins.entries["diagnostics-otel"].enabled = true
        '
  )"
fi
case " ${OPENCLAW_REQUIRED_PLUGINS:-} " in
  *" $required_behavioral_observability_spec "*)
    bootstrap_config="$(
      printf '%s' "$bootstrap_config" \
        | jq -c '
            .plugins.allow =
              ((.plugins.allow // []) + ["behavioral-observability"] | unique)
            | .plugins.entries["behavioral-observability"].enabled = true
            | .plugins.entries["behavioral-observability"].hooks.allowConversationAccess = true
          '
    )"
    ;;
esac
printf '%s' "$bootstrap_config" >"$profile_dir/openclaw.json"
printf '%s' "$bootstrap_config" >"$state_dir/openclaw.json"

if [[ -n "${OPENCLAW_AUTH_PROFILES_JSON:-}" && ! -f "$auth_migration_marker" ]]; then
  printf '%s' "$OPENCLAW_AUTH_PROFILES_JSON" >"$profile_dir/auth-profiles.json"
  printf '%s' "$OPENCLAW_AUTH_PROFILES_JSON" >"$agent_dir/auth-profiles.json"
  printf '%s' "$OPENCLAW_AUTH_PROFILES_JSON" >"$state_dir/auth-profiles.json"
  printf '%s' "$OPENCLAW_AUTH_PROFILES_JSON" >"$state_agent_dir/auth-profiles.json"
fi

if [[ ! -f "$plugin_migration_marker" ]]; then
  rm -f "$runtime_dir/plugins.fingerprint"
fi
openclaw-agent-ensure-plugins "$profile"

verify_codex_runtime() {
  openclaw --profile "$profile" plugins inspect codex --runtime --json \
    | jq -e '
        .plugin.status == "loaded"
        and .plugin.origin == "bundled"
        and .plugin.version == "2026.11.3"
        and (.plugin.source | contains("/dist/extensions/codex/"))
        and (.plugin.agentHarnessIds | index("codex") != null)
        and .install == null
      ' >/dev/null
}

verify_mattermost_runtime() {
  openclaw --profile "$profile" plugins inspect mattermost --runtime --json \
    | jq -e '
        .plugin.status == "loaded"
        and .plugin.origin == "bundled"
        and .plugin.version == "2026.11.3"
        and (.plugin.source | contains("/dist/extensions/mattermost/"))
        and (.plugin.channelIds | index("mattermost") != null)
        and .install == null
      ' >/dev/null
}

verify_acpx_runtime() {
  openclaw --profile "$profile" plugins inspect acpx --runtime --json \
    | jq -e '
        .plugin.status == "loaded"
        and .plugin.origin == "bundled"
        and .plugin.version == "2026.11.3"
        and (.plugin.source | contains("/dist/extensions/acpx/"))
        and .install == null
      ' >/dev/null
}

verify_diagnostics_otel_runtime() {
  openclaw --profile "$profile" plugins inspect diagnostics-otel --runtime --json \
    | jq -e '
        .plugin.status == "loaded"
        and .plugin.origin == "bundled"
        and .plugin.version == "2026.11.3"
        and (.plugin.source | contains("/dist/extensions/diagnostics-otel/"))
        and .install == null
      ' >/dev/null
}

verify_behavioral_observability_runtime() {
  openclaw --profile "$profile" plugins inspect behavioral-observability --runtime --json \
    | jq -e '
        .plugin.id == "behavioral-observability"
        and .plugin.status == "loaded"
        and ([.diagnostics[]?
          | select(.message | contains("duplicate plugin id detected"))]
          | length) == 0
      ' >/dev/null
}

diagnostics_otel_required() {
  [[ "${OPENCLAW_DIAGNOSTICS_OTEL_CANARY:-false}" == "true" ]]
}

behavioral_observability_required() {
  case " ${OPENCLAW_REQUIRED_PLUGINS:-} " in
    *" $required_behavioral_observability_spec "*) return 0 ;;
    *) return 1 ;;
  esac
}

if [[ "${OPENCLAW_BEHAVIORAL_OBSERVABILITY_CANARY:-false}" == "true" ]] \
  && ! behavioral_observability_required; then
  echo "ERROR: the behavioral observability canary requires $required_behavioral_observability_spec" >&2
  exit 1
fi

retry_check() {
  local label="$1"
  shift
  local attempt
  for attempt in 1 2 3 4 5; do
    if "$@"; then
      return 0
    fi
    echo "WARNING: $label failed on attempt $attempt/5; retrying" >&2
    sleep 3
  done
  echo "ERROR: $label failed after 5 attempts" >&2
  return 1
}

retry_check "Codex runtime verification" verify_codex_runtime
retry_check "exact bundled Mattermost runtime verification" verify_mattermost_runtime
retry_check "exact bundled ACPX runtime verification" verify_acpx_runtime
if diagnostics_otel_required; then
  retry_check "exact bundled diagnostics-otel runtime verification" verify_diagnostics_otel_runtime
fi
if behavioral_observability_required; then
  retry_check "behavioral observability runtime verification" verify_behavioral_observability_runtime
fi
printf '%s' "$canonical_config" >"$profile_dir/openclaw.json"
printf '%s' "$canonical_config" >"$state_dir/openclaw.json"

if [[ ! -f "$auth_migration_marker" \
  || ! -f "$session_migration_marker" \
  || ! -f "$session_schema_v27_marker" ]]; then
  if [[ "$doctor_repair_mode" != "automatic" ]]; then
    echo "ERROR: persisted migration markers are missing; automatic Doctor repair is disabled for this rollout" >&2
    exit 1
  fi
  doctor_log="$(mktemp)"
  node --no-warnings /usr/local/bin/openclaw-agent-repair-legacy-invalid-session-rows \
    "$agent_id"
  node --no-warnings /usr/local/bin/openclaw-agent-migrate-schema-v27 \
    "$agent_id" \
    "$state_agent_dir/openclaw-agent.sqlite"
  if ! openclaw --profile "$profile" doctor --fix --non-interactive --yes \
    >"$doctor_log" 2>&1; then
    echo "WARNING: OpenClaw doctor returned nonzero during the one-time state migration; repairing the known beta Codex route before validation" >&2
  fi
  rm -f "$runtime_dir/plugins.fingerprint"
  if ! openclaw-agent-ensure-plugins "$profile"; then
    echo "WARNING: runtime plugin convergence remained nonzero after state migration; continuing to exact runtime admission checks" >&2
  fi
  printf '%s' "$canonical_config" >"$profile_dir/openclaw.json"
  printf '%s' "$canonical_config" >"$state_dir/openclaw.json"
  retry_check "Codex runtime verification after state migration" verify_codex_runtime
  retry_check "exact bundled Mattermost runtime verification after state migration" verify_mattermost_runtime
  retry_check "exact bundled ACPX runtime verification after state migration" verify_acpx_runtime
  if diagnostics_otel_required; then
    retry_check "exact bundled diagnostics-otel runtime verification after state migration" verify_diagnostics_otel_runtime
  fi
  if behavioral_observability_required; then
    retry_check "behavioral observability runtime verification after state migration" verify_behavioral_observability_runtime
  fi
  rm -f "$doctor_log"
fi

verify_agent_database_schema_v27() {
  node --no-warnings - "$state_agent_dir/openclaw-agent.sqlite" <<'NODE'
const { DatabaseSync } = require("node:sqlite");

const databasePath = process.argv[2];
const database = new DatabaseSync(databasePath, { readOnly: true });
try {
  const row = database.prepare("PRAGMA user_version").get();
  const version = row.user_version ?? Object.values(row)[0];
  if (version !== 27) {
    console.error(`expected OpenClaw agent database schema version 27, got ${version}`);
    process.exit(1);
  }
} finally {
  database.close();
}
NODE
}

retry_check "agent database schema v27" verify_agent_database_schema_v27

verify_models_status() {
  openclaw --profile "$profile" models status --json \
    | jq -e '
        (.auth.storePath | type == "string" and endswith("/openclaw-agent.sqlite"))
        and (.auth.missingProvidersInUse == [])
        and (.auth.unusableProfiles == [])
      ' >/dev/null
}

retry_check "model credential status" verify_models_status

verify_session_store() {
  openclaw --profile "$profile" sessions --agent "$agent_id" --limit 1 --json >/dev/null
}

retry_check "canonical session store validation" verify_session_store

touch \
  "$auth_migration_marker" \
  "$session_migration_marker" \
  "$session_schema_v27_marker" \
  "$plugin_migration_marker"
chmod 600 \
  "$auth_migration_marker" \
  "$session_migration_marker" \
  "$session_schema_v27_marker" \
  "$plugin_migration_marker" \
  2>/dev/null || true

# Launch the Gateway with the auth mode reviewed for this fleet.
if [[ "$agent_id" == "agent-developer" || "$agent_id" == "agent-designer" ||
      "$agent_id" == "agent-coordinator" || "$agent_id" == "agent-intake" ||
      "$agent_id" == "agent-infra" ]]; then
  exec openclaw --profile "$profile" gateway run \
    --auth trusted-proxy \
    --bind lan \
    --port 18791 \
    --compact \
    --allow-unconfigured
fi

exec openclaw --profile "$profile" gateway run \
  --auth token \
  --token "$OPENCLAW_GATEWAY_TOKEN" \
  --bind lan \
  --port 18791 \
  --compact \
  --allow-unconfigured
