#!/usr/bin/env bash
set -euo pipefail

workspace="${AGENT_INTAKE_WORKSPACE:-/workspace/agents/agent-intake}"
profile="${OPENCLAW_AGENT_PROFILE:-agent-intake}"
model_job_name="${AGENT_INTAKE_EMAIL_TRIAGE_MODEL_JOB_NAME:-agent-intake-consulting-email-triage}"
mailbox="${AGENT_INTAKE_EMAIL_PREFILTER_MAILBOX:-INBOX}"
sent_mailbox="${AGENT_INTAKE_EMAIL_PREFILTER_SENT_MAILBOX:-Sent}"
to_address="${AGENT_INTAKE_EMAIL_PREFILTER_TO_ADDRESS:-rmr.g@infuse-ai.com}"
from_address="${AGENT_INTAKE_EMAIL_PREFILTER_FROM_ADDRESS:-$to_address}"
limit="${AGENT_INTAKE_EMAIL_PREFILTER_LIMIT:-20}"
since_days="${AGENT_INTAKE_EMAIL_PREFILTER_SINCE_DAYS:-3}"
state_dir="${AGENT_INTAKE_EMAIL_PREFILTER_STATE_DIR:-$workspace/consulting-intake/runtime}"
clients_projects_checkout="${AGENT_INTAKE_CLIENTS_PROJECTS_ROOT:-$workspace/clients-projects}"
consulting_intake_root="${CONSULTING_INTAKE_ROOT:-$clients_projects_checkout/consulting-intake}"
intake_state_file="${AGENT_INTAKE_EMAIL_PREFILTER_INTAKE_STATE_FILE:-$consulting_intake_root/state.json}"
active_statuses="${AGENT_INTAKE_EMAIL_PREFILTER_ACTIVE_STATUSES:-needs-reply,waiting-human,qualified,proposal-draft,accepted,handoff-ready,handed-off,revise-handoff}"
fingerprint_file="$state_dir/mail-prefilter-fingerprint.txt"
mail_script="$workspace/skills/consulting-intake-orchestrator/scripts/mail_intake.py"

if [[ ! -f "$mail_script" ]]; then
  echo "agent-intake mail preflight cannot run: missing $mail_script" >&2
  exit 1
fi

mkdir -p "$state_dir"
tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

cd "$workspace"

since_date="$(date -u -d "$since_days days ago" +%d-%b-%Y)"

python3 "$mail_script" \
  --mailbox "$mailbox" \
  --limit "$limit" \
  --to-address "$to_address" \
  --since "$since_date" >"$tmp_dir/recent-inbound.json"

python3 "$mail_script" \
  --mailbox "$sent_mailbox" \
  --limit "$limit" \
  --from-address "$from_address" \
  --since "$since_date" >"$tmp_dir/recent-sent.json"

python3 "$mail_script" \
  --mailbox "$mailbox" \
  --limit "$limit" \
  --unseen \
  --to-address "$to_address" >"$tmp_dir/unseen-inbound.json"

prefilter="$(
  python3 - "$tmp_dir" "$intake_state_file" "$active_statuses" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

tmp_dir = Path(sys.argv[1])
state_file = Path(sys.argv[2])
active_statuses = {item.strip() for item in sys.argv[3].split(",") if item.strip()}

scans = []
stable_messages = []
seen = set()
for path in sorted(tmp_dir.glob("*.json")):
    data = json.loads(path.read_text())
    messages = data.get("messages", []) if isinstance(data, dict) else []
    scans.append({
        "scan": path.stem,
        "mailbox": data.get("mailbox", ""),
        "matched_count": data.get("matched_count", len(messages)),
        "message_count": data.get("message_count", 0),
        "returned_count": len(messages),
    })
    for message in messages:
        if not isinstance(message, dict):
            continue
        stable = {
            "mailbox": message.get("mailbox") or data.get("mailbox", ""),
            "id": message.get("id", ""),
            "message_id": message.get("message_id", ""),
            "date": message.get("date", ""),
            "from_address": message.get("from_address", ""),
            "to": message.get("to", ""),
            "subject": message.get("subject", ""),
            "flags": message.get("flags", ""),
            "in_reply_to": message.get("in_reply_to", ""),
            "references": message.get("references", ""),
        }
        key = (
            stable["mailbox"],
            stable["message_id"],
            stable["id"],
            stable["date"],
            stable["flags"],
        )
        if key in seen:
            continue
        seen.add(key)
        stable_messages.append(stable)

stable_messages.sort(key=lambda item: (
    item["mailbox"],
    item["message_id"],
    item["id"],
    item["date"],
))

active_opportunities = []
if state_file.exists():
    state = json.loads(state_file.read_text())
    opportunities = state.get("opportunities", {}) if isinstance(state, dict) else {}
    for slug, opportunity in sorted(opportunities.items()):
        if not isinstance(opportunity, dict):
            continue
        status = opportunity.get("status", "")
        if status not in active_statuses:
            continue
        mattermost = opportunity.get("mattermost", {}) if isinstance(opportunity.get("mattermost"), dict) else {}
        active_opportunities.append({
            "slug": slug,
            "status": status,
            "next_action": opportunity.get("next_action"),
            "owner": opportunity.get("owner"),
            "due_at": opportunity.get("due_at"),
            "email_message_ids": sorted(opportunity.get("email_message_ids") or []),
            "email_thread_ids": sorted(opportunity.get("email_thread_ids") or []),
            "mattermost_channel_id": mattermost.get("channel_id"),
            "mattermost_root_post_id": mattermost.get("root_post_id"),
        })

payload = {
    "active_opportunities": active_opportunities,
    "messages": stable_messages,
    "scans": scans,
}
fingerprint = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
print(json.dumps({
    "active_count": len(active_opportunities),
    "fingerprint": fingerprint,
    "message_count": len(stable_messages),
    "scans": scans,
}, sort_keys=True))
PY
)"

message_count="$(jq -r '.message_count' <<<"$prefilter")"
active_count="$(jq -r '.active_count' <<<"$prefilter")"
fingerprint="$(jq -r '.fingerprint' <<<"$prefilter")"

if [[ "$message_count" == "0" && "$active_count" == "0" ]]; then
  echo "NO_REPLY"
  exit 0
fi

previous_fingerprint="$(cat "$fingerprint_file" 2>/dev/null || true)"
if [[ "$fingerprint" == "$previous_fingerprint" ]]; then
  echo "NO_REPLY"
  exit 0
fi

model_job_id="$(
  openclaw --profile "$profile" cron list --all --json | jq -r --arg name "$model_job_name" '
    .jobs // []
    | map(select(.name == $name))
    | .[0].id // empty
  '
)"

if [[ -z "$model_job_id" ]]; then
  echo "agent-intake mail preflight found consulting mail/state activity, but model cron '$model_job_name' is missing."
  exit 1
fi

echo "agent-intake mail preflight found $message_count recent consulting message candidate(s) and $active_count active state record(s); running model triage."
model_run_output="$(mktemp)"
cleanup_model_job() {
  openclaw --profile "$profile" cron disable "$model_job_id" >/dev/null 2>&1 || true
  rm -f "$model_run_output"
}
trap cleanup_model_job EXIT

openclaw --profile "$profile" cron enable "$model_job_id" >/dev/null
openclaw --profile "$profile" cron run \
  --wait \
  --expect-final \
  --wait-timeout "${AGENT_INTAKE_MODEL_RUN_WAIT_TIMEOUT:-20m}" \
  "$model_job_id" >"$model_run_output"
printf '%s\n' "$fingerprint" >"$fingerprint_file"
echo "agent-intake mail preflight ran model triage successfully."
