#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -eq 0 ]]; then
  echo "Pass the normal artifact_tool.py publish arguments, including --spec." >&2
  exit 2
fi

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
kube_context="${KUBE_CONTEXT:-infuseai-k8s}"
namespace="${ARTIFACT_REGISTRY_PUBLISHER_NAMESPACE:-agents-swarm}"
publisher_pod="${KAPITEKY_ARTIFACT_REGISTRY_PUBLISHER_POD:-kapiteky-artifact-registry-publisher-$$}"
source_deployment="${KAPITEKY_ARTIFACT_REGISTRY_SOURCE_DEPLOYMENT:-agent-infra}"
workspace_root="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}"
skill_dir="${MISSION_CONTROL_PUBLISHING_SKILL_DIR:-$workspace_root/skills/mission-control-publishing}"
agent_dir="${MISSION_CONTROL_AGENT_DIR:?MISSION_CONTROL_AGENT_DIR must point to the local Kapiteky staging directory}"

if [[ ! -f "$skill_dir/scripts/artifact_tool.py" || ! -f "$skill_dir/scripts/artifact_registry.py" ]]; then
  echo "The reviewed mission-control publishing skill is unavailable." >&2
  exit 2
fi
if [[ ! -d "$agent_dir" || -L "$agent_dir" ]]; then
  echo "Kapiteky's local journal staging directory is missing or symlinked." >&2
  exit 2
fi
agent_dir="$(cd -- "$agent_dir" && pwd -P)"
if [[ "${agent_dir##*/}" != "kapiteky" ]]; then
  echo "MISSION_CONTROL_AGENT_DIR must resolve to a directory named kapiteky." >&2
  exit 2
fi

spec_path=""
publish_args=()
while [[ "$#" -gt 0 ]]; do
  case "$1" in
    --spec)
      shift
      if [[ "$#" -eq 0 ]]; then
        echo "--spec requires a file path." >&2
        exit 2
      fi
      spec_path="$1"
      ;;
    --spec=*) spec_path="${1#--spec=}" ;;
    --agent-dir|--agent-dir=*|--delivery-mode|--delivery-mode=*)
      echo "The Kapiteky Registry wrapper owns agent staging and delivery mode." >&2
      exit 2
      ;;
    *) publish_args+=("$1") ;;
  esac
  shift
done
if [[ -z "$spec_path" || ! -f "$spec_path" || -L "$spec_path" ]]; then
  echo "--spec must identify a regular local file." >&2
  exit 2
fi

# Validate all local inputs before starting a credential-bearing workload.
if ! python3 "$skill_dir/scripts/artifact_tool.py" publish --help | grep -q -- '--studio-origin'; then
  echo "Update mission-control-publishing from reviewed agent-skills main; this installed helper lacks Studio links." >&2
  exit 2
fi
python3 "$skill_dir/scripts/artifact_tool.py" validate --spec "$spec_path" >/dev/null
journal_files=()
for journal_file in journal.json journal.html; do
  if [[ -L "$agent_dir/$journal_file" || ( -e "$agent_dir/$journal_file" && ! -f "$agent_dir/$journal_file" ) ]]; then
    echo "Kapiteky journal staging must use regular files." >&2
    exit 2
  fi
  if [[ -f "$agent_dir/$journal_file" ]]; then journal_files+=("$journal_file"); fi
done
if [[ "${#journal_files[@]}" -eq 1 ]]; then
  echo "Kapiteky's local journal staging pair is incomplete." >&2
  exit 2
fi
# This reviewed rule is staged separately. The publisher cannot create or repair it.
kubectl --context "$kube_context" -n "$namespace" get networkpolicy -o json \
  | python3 "$repo_root/scripts/verify-kapiteky-publisher-policy.py" "$repo_root/config/kapiteky-artifact-publisher-network-policy.json" "$namespace"
existing_pod="$(kubectl --context "$kube_context" -n "$namespace" get pod "$publisher_pod" --ignore-not-found -o name)"
if [[ -n "$existing_pod" ]]; then
  echo "Publisher pod name is already in use; no existing pod was changed." >&2
  exit 1
fi
publisher_uid=""
cleanup() {
  [[ -n "$publisher_uid" ]] || return 0
  # Kubernetes enforces this precondition atomically, even if a same-name Pod replaced ours.
  jq -n --arg uid "$publisher_uid" '{apiVersion:"v1",kind:"DeleteOptions",preconditions:{uid:$uid},gracePeriodSeconds:1}' \
    | kubectl --context "$kube_context" delete --raw "/api/v1/namespaces/$namespace/pods/$publisher_pod" -f - >/dev/null 2>&1 || echo "Publisher cleanup could not confirm removal of $publisher_pod ($publisher_uid); reconcile before retry." >&2
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

publisher_image="$(kubectl --context "$kube_context" -n "$namespace" get "deployment/$source_deployment" -o jsonpath='{.spec.template.spec.containers[0].image}')"
if [[ -z "$publisher_image" ]]; then
  echo "The reviewed agent runtime image is unavailable." >&2
  exit 1
fi

publisher_created="$(jq -n --arg name "$publisher_pod" --arg namespace "$namespace" --arg image "$publisher_image" '{
  apiVersion: "v1", kind: "Pod",
  metadata: {name: $name, namespace: $namespace, labels: {
    "app.kubernetes.io/name": "agent-infra",
    "app.kubernetes.io/component": "kapiteky-artifact-registry-publisher"
  }},
  spec: {
    restartPolicy: "Never", activeDeadlineSeconds: 300, automountServiceAccountToken: false, terminationGracePeriodSeconds: 1,
    imagePullSecrets: [{name: "harbor-pull"}],
    securityContext: {runAsNonRoot: true, runAsUser: 1000, runAsGroup: 1000, fsGroup: 1000, seccompProfile: {type: "RuntimeDefault"}},
    containers: [{
      name: "publisher", image: $image, command: ["sleep", "300"],
      securityContext: {allowPrivilegeEscalation: false, readOnlyRootFilesystem: true, capabilities: {drop: ["ALL"]}},
      volumeMounts: [
        {name: "work", mountPath: "/work"},
        {name: "registry-token", mountPath: "/var/run/artifact-registry/token", subPath: "token", readOnly: true}
      ]
    }],
    volumes: [
      {name: "work", emptyDir: {}},
      {name: "registry-token", secret: {secretName: "artifact-registry-kapiteky", defaultMode: 288, items: [{key: "token", path: "token"}]}}
    ]
  }
}' | kubectl --context "$kube_context" create -f - -o json)"
publisher_uid="$(jq -er '.metadata.uid' <<<"$publisher_created")"
unset publisher_created

kubectl --context "$kube_context" -n "$namespace" wait --for=condition=Ready "pod/$publisher_pod" --timeout=180s >/dev/null
kubectl --context "$kube_context" -n "$namespace" exec "$publisher_pod" -c publisher -- mkdir -p /work/agents/kapiteky /work/tmp
tar -C "${skill_dir%/*}" -cf - "${skill_dir##*/}" \
  | kubectl --context "$kube_context" -n "$namespace" exec -i "$publisher_pod" -c publisher -- tar -C /work -xf -
if [[ "${#journal_files[@]}" -eq 2 ]]; then
  tar -C "$agent_dir" -cf - "${journal_files[@]}" \
    | kubectl --context "$kube_context" -n "$namespace" exec -i "$publisher_pod" -c publisher -- tar -C /work/agents/kapiteky -xf -
fi
kubectl --context "$kube_context" -n "$namespace" exec -i "$publisher_pod" -c publisher -- sh -c 'umask 077; tee /work/spec.json >/dev/null' <"$spec_path"

kubectl --context "$kube_context" -n "$namespace" exec "$publisher_pod" -c publisher -- \
  env TMPDIR=/work/tmp PYTHONDONTWRITEBYTECODE=1 MISSION_CONTROL_ROOT=/work MISSION_CONTROL_AGENT_DIR=/work/agents/kapiteky \
    ARTIFACT_PUBLISH_MODE=registry \
    ARTIFACT_REGISTRY_URL=http://artifact-registry.core.svc.cluster.local:3010 \
    ARTIFACT_REGISTRY_TOKEN_FILE=/var/run/artifact-registry/token \
  python3 /work/mission-control-publishing/scripts/artifact_tool.py publish \
    --delivery-mode registry --spec /work/spec.json --agent-dir /work/agents/kapiteky "${publish_args[@]}"

if kubectl --context "$kube_context" -n "$namespace" exec "$publisher_pod" -c publisher -- test -f /work/agents/kapiteky/journal.json -a -f /work/agents/kapiteky/journal.html; then
  kubectl --context "$kube_context" -n "$namespace" exec "$publisher_pod" -c publisher -- \
    tar -C /work/agents/kapiteky -cf - journal.json journal.html | tar -C "$agent_dir" -xf -
fi
