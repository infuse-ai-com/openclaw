#!/usr/bin/env python3
"""Plan or explicitly provision Studio's two exact-project Registry lifecycle clients."""
from __future__ import annotations
import argparse
import base64
import copy
import hashlib
import json
import re
from pathlib import Path
import sys
import provision_artifact_registry_credentials as credentials

PROJECTS = ('core', 'studio')
CLIENT_SECRET = 'studio-artifact-lifecycle'
CLIENTS = tuple(credentials.ServiceClient(
    'studio-lifecycle-' + project, 'Studio artifact lifecycle / ' + project,
    'Artifact Registry / Studio lifecycle ' + project + ' token', '07-Project-Backoffice', 'lifecycle'
) for project in PROJECTS)


def plan():
    return {'action': 'prepared-only', 'namespace': 'core', 'serverSecret': credentials.SERVER_SECRET,
            'clientSecret': CLIENT_SECRET, 'principals': [
                {'subject': client.subject, 'project': project, 'scopes': ['lifecycle'],
                 'vaultItem': client.item_name, 'collection': client.collection,
                 'tokenFile': '/etc/studio-artifact-lifecycle/' + project}
                for project, client in zip(PROJECTS, CLIENTS)],
            'existingPrincipals': 'preserved', 'humanMemberships': 'unchanged',
            'liveArtifactActions': 'none', 'deployment': 'reviewed Studio and Registry pipelines'}


def add_principals(auth, tokens):
    if not isinstance(auth, dict) or auth.get('schema') != 'infuse.artifact-auth/v1' or not isinstance(auth.get('principals'), dict):
        raise credentials.ProvisioningError('Unexpected Registry authorization schema')
    if set(tokens) != set(PROJECTS):
        raise credentials.ProvisioningError('Only the two reviewed projects are supported')
    result = copy.deepcopy(auth)
    for project, client in zip(PROJECTS, CLIENTS):
        digest = hashlib.sha256(credentials.valid_token(tokens[project]).encode()).hexdigest()
        expected = {'subject': client.subject, 'project': project, 'scopes': ['lifecycle']}
        for key, principal in result['principals'].items():
            if not isinstance(principal, dict) or (key == digest or principal.get('subject') == client.subject) and (key != digest or principal != expected):
                raise credentials.ProvisioningError('Lifecycle credential or scope drift; explicit review required')
        result['principals'][digest] = expected
    if len(result['principals']) > 64:
        raise credentials.ProvisioningError('Registry principal limit reached')
    return result


def provision(context, tokens):
    server = credentials.kube_json(context, ['-n', 'core', 'get', 'secret', credentials.SERVER_SECRET], label='Registry auth lookup')
    try:
        auth = json.loads(base64.b64decode(server['data']['auth.json'], validate=True))
        version = server['metadata']['resourceVersion']
    except (KeyError, ValueError, TypeError) as error:
        raise credentials.ProvisioningError('Registry authorization Secret is malformed') from error
    updated = add_principals(auth, tokens)
    client = credentials.run_checked(['kubectl', '--context', context, '-n', 'core', 'get', 'secret', CLIENT_SECRET, '--ignore-not-found', '-o', 'json'], label='Lifecycle client lookup')
    expected = {p: base64.b64encode(tokens[p].encode()).decode() for p in PROJECTS}
    if client.strip() and json.loads(client).get('data') != expected:
        raise credentials.ProvisioningError('Lifecycle client Secret drift; no changes applied')
    # Prepare the unmounted client before admission. Existing data is never replaced.
    if not client.strip():
        credentials.run_checked(['kubectl', '--context', context, '-n', 'core', 'create', '-f', '-'], input_text=json.dumps(credentials.opaque_secret('core', CLIENT_SECRET, tokens)), label='Create exact lifecycle client Secret')
    body = json.dumps(updated, sort_keys=True, separators=(',', ':'))
    if updated != auth:
        patch = [{'op': 'test', 'path': '/metadata/resourceVersion', 'value': version},
                 {'op': 'replace', 'path': '/data/auth.json', 'value': base64.b64encode(body.encode()).decode()}]
        credentials.run_checked(['kubectl', '--context', context, '-n', 'core', 'patch', 'secret', credentials.SERVER_SECRET, '--type=json', '--patch-file=/dev/stdin'], input_text=json.dumps(patch), label='Admit exact Studio lifecycle projects')
    else:
        body = base64.b64decode(server['data']['auth.json']).decode()
    credentials.wait_for_server_auth_projection(context, 'core', credentials.opaque_secret('core', credentials.SERVER_SECRET, {'auth.json': body}))
    return dict(plan(), action='provisioned', existingPrincipalsPreserved=len(auth['principals']))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'apply'))
    parser.add_argument('--approved', action='store_true')
    parser.add_argument('--expected-image', help='Exact reviewed Studio Registry digest already deployed')
    parser.add_argument('--context', default='infuseai-k8s')
    parser.add_argument('--bw-helper', default=str(Path.home() / '.codex/skills/vaultwarden-credential-management/scripts/bw-local-vaultwarden.sh'))
    args = parser.parse_args(argv)
    if args.action == 'plan':
        print(json.dumps(plan(), indent=2)); return
    if not args.approved:
        raise credentials.ProvisioningError('Exact project credential grants require recorded owner approval')
    if not args.expected_image or not re.fullmatch(r'registry\.infuse-ai-tech\.party/studio/artifact-registry@sha256:[a-f0-9]{64}', args.expected_image):
        raise credentials.ProvisioningError('An exact reviewed Studio Registry image digest is required')
    credentials.preflight_kubernetes(args.context, 'core', None)
    deployment=credentials.kube_json(args.context, ['-n','core','get','deployment',credentials.REGISTRY_DEPLOYMENT], label='Reviewed Registry deployment lookup')
    containers=deployment.get('spec',{}).get('template',{}).get('spec',{}).get('containers',[])
    status = deployment.get('status', {})
    generation = deployment.get('metadata', {}).get('generation')
    if ([c.get('image') for c in containers if c.get('name') == 'registry'] != [args.expected_image]
            or generation is None or status.get('observedGeneration') != generation
            or any(status.get(key) != 1 for key in ('replicas', 'updatedReplicas', 'readyReplicas', 'availableReplicas'))):
        raise credentials.ProvisioningError('The reviewed Studio Registry image must be deployed and ready before adding scoped principals')
    by_client = credentials.load_or_create_service_client_tokens(args.bw_helper, CLIENTS)
    tokens = {project: by_client[client.key] for project, client in zip(PROJECTS, CLIENTS)}
    print(json.dumps(provision(args.context, tokens), indent=2))


if __name__ == '__main__':
    try:
        main()
    except credentials.ProvisioningError as error:
        print(str(error), file=sys.stderr); sys.exit(1)
