#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${2:-${AGENT_ID:-agent-developer}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s
"${kubectl_base[@]}" wait pod -l "$selector" --for=condition=Ready --timeout=120s >/dev/null

pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

"${kubectl_base[@]}" exec -i "$pod" -c agent -- python3 - \
  < "$(dirname "$0")/smoke-python-toolbox-entrypoints.py"

# The single-quoted body is intentionally expanded inside the target pod.
# shellcheck disable=SC2016
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc '
set -eu
for bin in git glab task kubectl helm kustomize docker crane python python3 pip3 uv rg fd jq yq node npm npx pnpm yarn playwright openclaw chromium xvfb-run xauth bw bw-local-vaultwarden openclaw-agent-secret-get openclaw-agent-capabilities openclaw-agent-evidence-verify gog make gcc g++ patch zip rsync curl wget ssh scp openssl git-lfs shellcheck ping dig nc lsof traceroute file less tree pdfinfo pdftotext convert identify montage; do
  command -v "$bin" >/dev/null
done
git --version >/dev/null
glab --version | grep -F "${GLAB_VERSION:?GLAB_VERSION is required}" >/dev/null
git config --global --get user.name >/dev/null
git config --global --get user.email >/dev/null
git config --global --get-all safe.directory | grep -Fx /workspace >/dev/null
task --version >/dev/null
kubectl version --client=true >/dev/null
helm version --short >/dev/null
kustomize version >/dev/null
docker --version >/dev/null
docker compose version >/dev/null
capabilities="$(openclaw-agent-capabilities --json --require-compose --require-browser-automation --require-image-composition)"
printf "%s" "$capabilities" | jq -e "
  .schemaVersion == 2 and
  .docker.cli.available == true and
  .docker.compose.available == true and
  .docker.daemon.available == false and
  .containerBuild.mode == \"ci_required\" and
  .composeValidation.requiresDaemon == false and
  .browserAutomation.available == true and
  .imageComposition.available == true and
  .imageComposition.contactSheet.available == true and
  .imageComposition.contactSheet.backend == \"imagemagick_montage\" and
  .artifactPortability.mode == \"project_declared_or_bundled\" and
  .artifactPortability.ambientRuntimeIsPortable == false
  and .languageRuntimes.ruby.available == false
  and .languageRuntimes.ruby.executionMode == \"project_environment_required\"
" >/dev/null
crane version >/dev/null
python3 --version >/dev/null
python --version >/dev/null
pip3 --version >/dev/null
uv --version >/dev/null
rg --version >/dev/null
fd --version >/dev/null
jq --version >/dev/null
yq --version >/dev/null
node --version >/dev/null
npm --version >/dev/null
npx --version >/dev/null
pnpm --version >/dev/null
yarn --version >/dev/null
playwright --version >/dev/null
chromium --version >/dev/null
xvfb-run --auto-servernum chromium --version >/dev/null
test "$(bw --version)" = "${BITWARDEN_CLI_VERSION:?BITWARDEN_CLI_VERSION is required}"
bw-local-vaultwarden --version >/dev/null
DRY_RUN=true VAULTWARDEN_ITEM_NAME="__toolbox-direct-lookup-probe__" \
  CREDENTIAL_SOURCE_FIELD=password \
  openclaw-agent-secret-get >/dev/null
if DRY_RUN=true VAULTWARDEN_ITEM_NAME="__toolbox-direct-lookup-probe__" \
  CREDENTIAL_SOURCE_FIELD=totp \
  openclaw-agent-secret-get >/dev/null 2>&1; then
  echo "Runtime secret resolver allowed an unsupported lookup field" >&2
  exit 9
fi
gog --version >/dev/null
for removed in ruby gem bundle; do
  if command -v "$removed" >/dev/null; then
    echo "Persistent runtime unexpectedly contains removed Ruby command: $removed" >&2
    exit 10
  fi
done
make --version >/dev/null
gcc --version >/dev/null
g++ --version >/dev/null
patch --version >/dev/null
zip --version >/dev/null
rsync --version >/dev/null
curl --version >/dev/null
wget --version >/dev/null
ssh -V >/dev/null 2>&1
scp -V >/dev/null 2>&1 || true
openssl version >/dev/null
git-lfs --version >/dev/null
shellcheck --version >/dev/null
ping -V >/dev/null 2>&1 || true
dig -v >/dev/null
nc -h >/dev/null 2>&1 || true
lsof -v >/dev/null 2>&1 || true
traceroute --version >/dev/null 2>&1 || true
file --version >/dev/null
less --version >/dev/null
tree --version >/dev/null
pdfinfo -v >/dev/null 2>&1
pdftotext -v >/dev/null 2>&1
convert -version >/dev/null
identify -version >/dev/null
montage -version >/dev/null
openclaw-agent-evidence-verify --help >/dev/null
python3 - <<'"'"'PY'"'"'
import os
from pathlib import Path

for module in ("yaml", "pyaml", "requests", "bs4", "lxml", "pytest", "numpy", "pandas", "playwright"):
    __import__(module)

from playwright.sync_api import sync_playwright

workspace = Path(os.environ.get("OPENCLAW_WORKSPACE", "/workspace")).resolve()
cache_path = Path(os.environ["PLAYWRIGHT_BROWSERS_PATH"]).resolve()
seed_path = Path(os.environ["OPENCLAW_PLAYWRIGHT_SEED_PATH"]).resolve()
assert cache_path == workspace / ".cache" / "ms-playwright"
assert os.access(cache_path, os.W_OK)

with sync_playwright() as playwright_api:
    executable_path = Path(playwright_api.chromium.executable_path)
    assert executable_path.is_relative_to(cache_path)
    assert executable_path.is_file()
    assert os.access(executable_path, os.X_OK)
    resolved_executable_path = executable_path.resolve()
    assert resolved_executable_path.is_relative_to(seed_path)
    browser = playwright_api.chromium.launch(headless=True, chromium_sandbox=True)
    page = browser.new_page()
    page.set_content("<title>OpenClaw toolbox smoke</title>")
    assert page.title() == "OpenClaw toolbox smoke"
    browser.close()
PY
node - <<'"'"'JS'"'"'
const {chromium} = require("playwright");
require("@playwright/test");
(async () => {
  const browser = await chromium.launch({headless: true, chromiumSandbox: true});
  try {
    const page = await browser.newPage();
    await page.setContent("<title>OpenClaw Node toolbox smoke</title>");
    if (await page.title() !== "OpenClaw Node toolbox smoke") throw Error("fixture title");
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error.message); process.exit(1); });
JS
test -w /workspace
'

echo "Agent toolbox smoke passed for $agent_id in $namespace"
