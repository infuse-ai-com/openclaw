#!/usr/bin/env python3
"""Merge the reviewed dashboard settings into one live agent config."""

import argparse
import json
from pathlib import Path
import re
import subprocess
import sys


def source_file(commit, path):
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], text=True)


def named(items, name):
    matches = [item for item in items if item["name"] == name]
    if len(matches) != 1:
        raise ValueError("Missing or duplicate workload setting")
    return matches[0]


def prepare(deployment, commit, agent):
    if deployment["kind"] != "Deployment" or deployment["metadata"]["name"] != agent:
        raise ValueError("Unexpected workload")
    agent_container = named(deployment["spec"]["template"]["spec"]["containers"], "agent")
    env = named(agent_container["env"], "OPENCLAW_CONFIG_JSON")
    if named(agent_container["env"], "AGENT_ID")["value"] != agent:
        raise ValueError("Unexpected agent identity")
    live = json.loads(env["value"])
    policy = json.loads(source_file(commit, "config/agent-model-policies.json"))
    choices = policy["defaults"]["selectableModels"]
    if agent not in policy["agents"] or len(choices) != 5 or len(set(choices)) != 5:
        raise ValueError("Incomplete approved model choices")
    source = source_file(commit, f"k8s/agents/{agent}/deployment.yaml")
    matches = re.findall(r"name: OPENCLAW_CONFIG_JSON\n[ \t]+value: '([^\n]*)'[ \t]*$", source, re.M)
    if len(matches) != 1:
        raise ValueError("Expected one reviewed config value")
    desired = json.loads(matches[0].replace("''", "'"))
    if set(live["agents"]["entries"]) != {agent} or set(desired["agents"]["entries"]) != {agent}:
        raise ValueError("Config identity differs")

    for actual, reviewed in (
        (live["agents"]["defaults"], desired["agents"]["defaults"]),
        (live["agents"]["entries"][agent], desired["agents"]["entries"][agent]),
    ):
        models = actual.setdefault("models", {})
        for ref in choices:
            models.setdefault(ref, reviewed["models"][ref])
        allow = actual.get("modelPolicy", {}).get("allow")
        if allow is not None or actual is live["agents"]["defaults"]:
            actual.setdefault("modelPolicy", {})["allow"] = list(dict.fromkeys([*(allow or []), *choices]))

    browser = live.setdefault("browser", {})
    for key in ("enabled", "headless", "allowSystemProfileImport"):
        browser[key] = desired["browser"][key]
    ssrf_policy = browser.setdefault("ssrfPolicy", {})
    desired_ssrf_policy = desired["browser"]["ssrfPolicy"]
    ssrf_policy["dangerouslyAllowPrivateNetwork"] = desired_ssrf_policy["dangerouslyAllowPrivateNetwork"]
    allowed_hostnames = desired_ssrf_policy.get("allowedHostnames")
    if allowed_hostnames:
        ssrf_policy["allowedHostnames"] = list(dict.fromkeys([
            *ssrf_policy.get("allowedHostnames", []), *allowed_hostnames,
        ]))
    plugins = live["plugins"]
    plugins["allow"] = list(dict.fromkeys([*plugins["allow"], "browser"]))
    plugins["entries"].setdefault("browser", {})["enabled"] = desired["plugins"]["entries"]["browser"]["enabled"]
    return json.dumps(live, ensure_ascii=False, separators=(",", ":"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("deployment", type=Path)
    parser.add_argument("source")
    parser.add_argument("agent")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        config = prepare(json.loads(args.deployment.read_text()), args.source, args.agent)
        with args.output.open("x", encoding="utf-8") as stream:
            stream.write(config)
    except (OSError, TypeError, ValueError, KeyError, subprocess.CalledProcessError):
        print(f"Cannot prepare dashboard capabilities for {args.agent}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
