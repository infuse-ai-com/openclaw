#!/usr/bin/env bash
set -euo pipefail

source_namespace="${SOURCE_NAMESPACE:-agents-swarm}"
target_namespace="${TARGET_NAMESPACE:-core}"
configmap_name="${CONFIGMAP_NAME:-openclaw-agent-model-policy-feed}"
selector="${AGENT_SELECTOR:-app.kubernetes.io/component=persistent-agent}"
timeout_seconds="${EXPORT_TIMEOUT_SECONDS:-30}"

workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
snapshot_dir="$workdir/snapshots"
mkdir -p "$snapshot_dir"

kubectl_cmd=(kubectl)
if [[ -n "${KUBE_CONTEXT:-}" ]]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

run_with_optional_timeout() {
  if command -v timeout >/dev/null 2>&1; then
    timeout "$timeout_seconds" "$@"
  else
    "$@"
  fi
}

pods_json_path="$workdir/pods.json"
"${kubectl_cmd[@]}" -n "$source_namespace" get pods -l "$selector" -o json >"$pods_json_path"
pod_rows=()
while IFS= read -r row; do
  pod_rows+=("$row")
done < <(python3 - "$pods_json_path" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    data = json.load(handle)
for item in data.get("items", []):
    metadata = item.get("metadata", {})
    labels = metadata.get("labels", {})
    name = metadata.get("name")
    agent_id = labels.get("app.kubernetes.io/name")
    phase = item.get("status", {}).get("phase")
    if name and agent_id and phase == "Running":
        print(f"{agent_id}\t{name}")
PY
)

if [[ "${#pod_rows[@]}" -eq 0 ]]; then
  echo "No running agent pods matched selector ${selector} in namespace ${source_namespace}." >&2
fi

for row in "${pod_rows[@]}"; do
  agent_id="${row%%$'\t'*}"
  pod_name="${row#*$'\t'}"
  output_path="$snapshot_dir/${agent_id}.json"

  echo "Collecting sanitized model policy snapshot from ${pod_name} (${agent_id})."
  if ! run_with_optional_timeout "${kubectl_cmd[@]}" -n "$source_namespace" exec "pod/$pod_name" -c agent -- \
    bash -lc '
      set -euo pipefail
      agent_id="${AGENT_ID:-'"$agent_id"'}"
      agent_name="${AGENT_NAME:-$agent_id}"
      exporter="/usr/local/bin/openclaw-agent-model-policy-export"
      declared_policy="/opt/openclaw-agent-skill-config/config/agent-model-policies.json"
      if [ ! -x "$exporter" ]; then
        echo "ERROR: $exporter is not executable in $agent_id" >&2
        exit 1
      fi
      args=(
        --agent-id "$agent_id"
        --gateway-label "$agent_name Gateway"
        --output -
      )
      if [ -r "$declared_policy" ]; then
        args+=(--declared-policy "$declared_policy")
      fi
      "$exporter" "${args[@]}"
    ' >"$output_path"; then
    echo "WARNING: failed to collect ${agent_id}; writing error snapshot." >&2
    python3 - "$agent_id" "$output_path" <<'PY'
from datetime import datetime, timezone
import json
import sys

agent_id = sys.argv[1]
output_path = sys.argv[2]
snapshot = {
    "schemaVersion": 1,
    "generatedAt": datetime.now(timezone.utc).isoformat(),
    "source": {
        "type": "openclaw_agent_model_policy",
        "agentId": agent_id,
        "gatewayLabel": f"{agent_id} Gateway",
        "configPath": "collector error",
        "status": "collection_failed",
    },
    "modelPolicy": {"observed": {}, "declared": {}, "mismatchFields": []},
}
with open(output_path, "w", encoding="utf-8") as handle:
    json.dump(snapshot, handle, indent=2, sort_keys=True)
    handle.write("\n")
PY
  fi
done

"${kubectl_cmd[@]}" -n "$target_namespace" create configmap "$configmap_name" \
  --from-file="$snapshot_dir" \
  --dry-run=client \
  -o yaml \
  | "${kubectl_cmd[@]}" apply -n "$target_namespace" -f -

echo "Updated configmap/${configmap_name} in namespace ${target_namespace} with ${#pod_rows[@]} agent snapshots."
