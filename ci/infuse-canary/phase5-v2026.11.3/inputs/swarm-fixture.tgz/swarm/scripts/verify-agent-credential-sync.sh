#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"

python3 - <<'PY' | while IFS=$'\t' read -r agent_id item_name target_type target_name target_key; do
import json
from pathlib import Path

for path in sorted(Path("config/agent-skill-bundles").glob("*.json")):
    bundle = json.loads(path.read_text(encoding="utf-8"))
    agent_id = bundle["agent_id"]
    for item in bundle["credential_access"]["vaultwarden"]["allowed_items"]:
        target = item["sync_target"]
        print(
            agent_id,
            item["name"],
            target["type"],
            target["name"],
            target["key"],
            sep="\t",
        )
PY
  output="/tmp/openclaw-${agent_id}-${target_name}-${target_key}.yaml"
  AGENT_ID="$agent_id" \
    VAULTWARDEN_ITEM_NAME="$item_name" \
    CREDENTIAL_TARGET_TYPE="$target_type" \
    CREDENTIAL_SECRET_NAME="$target_name" \
    CREDENTIAL_SECRET_KEY="$target_key" \
    MATTERMOST_CHANNEL_ID="${MATTERMOST_CHANNEL_ID:-1k6r6ipd87ry9j59xp8to59rnr}" \
    DRY_RUN=true \
    DRY_RUN_OUTPUT="$output" \
    scripts/sync-agent-credential.sh "$namespace" >/dev/null
  test -s "$output"
done

if AGENT_ID=agent-designer \
  VAULTWARDEN_ITEM_NAME="Mattermost / agent-infra BOT token" \
  CREDENTIAL_TARGET_TYPE=kubernetes-secret-env \
  CREDENTIAL_SECRET_NAME=agent-infra-mattermost \
  CREDENTIAL_SECRET_KEY=MATTERMOST_BOT_TOKEN \
  DRY_RUN=true \
  scripts/sync-agent-credential.sh "$namespace" >/tmp/openclaw-negative-credential-sync.out 2>&1; then
  echo "Negative credential sync unexpectedly succeeded" >&2
  exit 1
fi

echo "Verified bundle-enforced credential sync dry-runs and negative guard."
