#!/usr/bin/env bash
set -euo pipefail

ci=.gitlab-ci.yml
rollout=scripts/gitlab-rollout-openclaw.sh
exception=deploy/gitlab/image-risk-exception.env
exception_guard=scripts/verify-openclaw-image-risk-exception.py

grep -Fq 'RUN_GITLAB_DELIVERY == "1"' "$ci"
test "$(grep -Fc 'CI_PIPELINE_SOURCE != "schedule"' "$ci")" -ge 3
grep -Fq 'CI_PIPELINE_SOURCE == "schedule" && $ASSURANCE_MODE == "weekly"' "$ci"
grep -Fq 'mattermost-assurance-notify@v0.8.4' "$ci"
grep -Fq 'CI_COMMIT_REF_PROTECTED == "true"' "$ci"
grep -Fq 'resource_group: openclaw-swarm-production' "$ci"
grep -Fq 'when: manual' "$ci"
grep -Fq 'deploy_openclaw_tinus_canary:' "$ci"
grep -Fq 'OPENCLAW_DEPLOYMENT_MODE=canary' "$ci"
grep -Fq 'OPENCLAW_DEPLOYMENT_MODE=fleet' "$ci"
grep -Fq 'job: deploy_openclaw_tinus_canary' "$ci"
grep -Fq 'system:serviceaccount:agents-swarm:gitlab-openclaw-swarm-deployer' "$ci"
if grep -Fq 'rollback_openclaw_to_qualified_baseline:' "$ci"; then
  echo 'Historical image-only rollback is incompatible with the renewed source/configuration contract' >&2
  exit 1
fi
grep -Fq 'registry.infuse-ai-tech.party/agents-swarm/openclaw-agent' "$ci"
if grep -Fq 'RUN_GITLAB_CANDIDATE_BUILD' "$ci"; then
  echo 'Permanent protected-main candidate builds must not retain the temporary opt-in switch' >&2
  exit 1
fi
grep -Fq '.automatic_candidate_image_policy:' "$ci"
grep -Fq 'changes: &candidate_image_changes' "$ci"
test "$(grep -Fc 'rules: *automatic_candidate_image_rules' "$ci")" -eq 2
for image_input in \
  '.dockerignore' \
  '.gitlab-ci.yml' \
  'images/openclaw-agent/**/*' \
  'scripts/**/*' \
  'plugins/behavioral-observability/**/*' \
  'prompts/**/*' \
  'config/**/*'
do
  grep -Fq -- "- $image_input" "$ci"
done
grep -Fq 'job-name: build_candidate_openclaw_image' "$ci"
grep -Fq 'cache-reference: registry.infuse-ai-tech.party/agents-swarm/openclaw-agent-buildcache:buildcache' "$ci"
grep -Fq 'job-name: scan_candidate_openclaw_image' "$ci"
grep -Fq 'build-metadata-directory: .gitlab-evidence/candidate-container-build' "$ci"
grep -Fq 'allow-failure: true' "$ci"
grep -Fq 'Candidate jobs cannot deploy.' "$ci"
grep -Fq 'verify_approved_openclaw_image:' "$ci"
grep -Fq 'exception=deploy/gitlab/approved-openclaw-image.env' "$ci"
python3 - <<'PYCODE'
from pathlib import Path
import re
values = dict(line.split('=', 1) for line in Path('deploy/gitlab/approved-openclaw-image.env').read_text().splitlines() if line and not line.startswith('#'))
assert re.fullmatch(r'sha256:[0-9a-f]{64}', values['OPENCLAW_IMAGE_DIGEST'])
assert values['OPENCLAW_IMAGE'] == 'registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@' + values['OPENCLAW_IMAGE_DIGEST']
assert re.fullmatch(r'[0-9a-f]{40}', values['IMAGE_SOURCE_COMMIT'])
assert all(values[k].isdigit() for k in ('SOURCE_PIPELINE_ID', 'SOURCE_BUILD_JOB_ID', 'SOURCE_SCAN_JOB_ID'))
assert 'EXPIRES_AT' not in values and not any(k.startswith('ACCEPTED_') for k in values)
PYCODE
grep -Fq 'allow-failure: true' "$ci"
python3 -m unittest discover -s tests -p test_gitlab_security_scan_policy.py
grep -Fq 'verified-prebuilt' "$ci"
grep -Fq 'image-source-commit.txt' "$ci"
grep -Fq 'unlink "$CI_PROJECT_DIR/.harbor-netrc-$CI_JOB_ID"' "$ci"
grep -Fq 'OPENCLAW_SWARM_ASSURANCE_KUBE_CONFIG_B64' "$ci"
grep -Fq 'OPENCLAW_SWARM_ASSURANCE_HARBOR_USERNAME' "$ci"
grep -Fq 'OPENCLAW_SWARM_ASSURANCE_HARBOR_PASSWORD' "$ci"
grep -Fq 'https://github.com/jqlang/jq/releases/download/jq-1.8.1/jq-linux-amd64' "$ci"
grep -Fq '020468de7539ce70ef1bceaf7cde2e8c4f2ca6c3afb84642aabc5c97d9fc2a0d' "$ci"
grep -Fq 'get secrets)" == no' "$rollout"
grep -Fq 'create pods/exec)" == no' "$rollout"
grep -Fq 'delete persistentvolumeclaims)" == no' "$rollout"
grep -Fq 'get_exact_deployments()' "$rollout"
grep -Fq 'wait_for_exact_deployment()' "$rollout"
grep -Fq 'OPENCLAW_DEPLOYMENT_MODE:-canary' "$rollout"
grep -Fq "behavioral_observability_archive='/opt/openclaw-plugin-archives/behavioral-observability.tgz'" "$rollout"
grep -Fq "studio_archive='/opt/openclaw-plugin-archives/infuse-studio.tgz'" "$rollout"
grep -Fq 'required_plugin_archives_for()' "$rollout"
grep -Fq 'name:"OPENCLAW_REQUIRED_PLUGINS",value:$required_plugins' "$rollout"
grep -Fq 'name:"OPENCLAW_CAPABILITY_CONSENT_PLUGINS",value:$required_plugins' "$rollout"
grep -Fq 'live_plugin_contract' "$rollout"
grep -Fq 'Tinus has not passed the exact-image canary gate' "$rollout"
grep -Fq 'Tinus canary changed peer deployment/$deployment' "$rollout"
grep -Fq 'restore_previous_contract()' "$rollout"
grep -Fq 'Rollout failed after mutation; restoring the captured Deployment contract.' "$rollout"
grep -Fq '.spec.template == $patch[0].spec.template' "$rollout"
grep -Fq 'Restored deployment/$deployment to its captured ready contract.' "$rollout"
grep -Fq 'trap '\''restore_previous_contract "$?"'\'' EXIT' "$rollout"
grep -Fq 'status.observedGeneration' "$rollout"
grep -Fq 'status.updatedReplicas' "$rollout"
grep -Fq 'get "deployment/$deployment" -o json' "$rollout"
grep -Fq "grep -En 'SessionCanonicalKeyMigrationRequiredError" "$rollout"
if grep -Fq 'get deployment "${deployments[@]}"' "$rollout"; then
  echo 'Aggregate Deployment reads would require broader list permission' >&2
  exit 1
fi
if grep -Fq 'rollout status "deployment/$deployment"' "$rollout"; then
  echo 'kubectl rollout status would require broader Deployment list permission' >&2
  exit 1
fi
if grep -Fq "rg -n 'SessionCanonicalKeyMigrationRequiredError" "$rollout"; then
  echo 'Protected deploy must use the portable log scanner available in its image' >&2
  exit 1
fi

if grep -Eq '^[[:alnum:]_.-]*(backup|restore)[[:alnum:]_.-]*:' "$ci"; then
  echo 'Backup/restore jobs are outside the approved cutover boundary' >&2
  exit 1
fi

grep -Fq 'OPENCLAW_IMAGE=registry.infuse-ai-tech.party/agents-swarm/openclaw-agent@sha256:acf9b596cd060d0ff4ea236d23c143b072cfa58b004a69dc272effd7653bfaa4' "$exception"
grep -Fq 'IMAGE_SOURCE_COMMIT=5489df67301699056c91325fdfc79fe8519d5c56' "$exception"
grep -Fq 'ACCEPTED_DISTINCT_CRITICAL=0' "$exception"
grep -Fq 'ACCEPTED_DISTINCT_HIGH=18' "$exception"
grep -Fq 'ACCEPTED_OCCURRENCES_CRITICAL=0' "$exception"
grep -Fq 'ACCEPTED_OCCURRENCES_HIGH=68' "$exception"
grep -Fq 'ACCEPTED_TUPLES=39' "$exception"
grep -Fq 'OBSERVED_DISTINCT_CRITICAL=16' "$exception"
grep -Fq 'OBSERVED_DISTINCT_HIGH=419' "$exception"
grep -Fq 'OBSERVED_OCCURRENCES_CRITICAL=34' "$exception"
grep -Fq 'OBSERVED_OCCURRENCES_HIGH=717' "$exception"
grep -Fq 'OBSERVED_TUPLES=722' "$exception"
grep -Fq 'OBSERVED_FINDINGS_SHA256=44e584a68ccb927ace0454c2de9c32c63324a52a738b19cff03337e30e708eca' "$exception"
grep -Fq 'EXPIRES_AT=2026-12-07T23:59:59Z' "$exception"
grep -Fq 'APPROVED_BY=Fito' "$exception"
# Preserve historical exception receipts; these fixed-date checks do not gate
# deployments on current findings or the old exception's expiry.
python3 "$exception_guard" --policy-only --now 2026-11-07T12:00:00Z
if python3 "$exception_guard" --policy-only --now 2026-12-08T00:00:00Z >/dev/null 2>&1; then
  echo 'Expired OpenClaw image exception was accepted' >&2
  exit 1
fi

python3 "$exception_guard" --profile dashboard-fleet --policy-only --now 2026-11-10T12:00:00Z
if python3 "$exception_guard" --profile dashboard-fleet --policy-only --now 2026-12-08T00:00:00Z >/dev/null 2>&1; then
  echo 'Expired dashboard fleet image exception was accepted' >&2
  exit 1
fi

bash -n "$rollout"
python3 -m unittest discover -s tests -p test_dashboard_capabilities_rollout.py
echo 'GitLab OpenClaw delivery contract verified'
