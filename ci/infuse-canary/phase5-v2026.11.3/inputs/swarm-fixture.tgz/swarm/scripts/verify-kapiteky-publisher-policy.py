#!/usr/bin/env python3
"""Fail closed before mounting the producer credential if isolation has drifted."""
import json
from pathlib import Path
import sys


LABELS = {
    "app.kubernetes.io/name": "agent-infra",
    "app.kubernetes.io/component": "kapiteky-artifact-registry-publisher",
}


def selects_publisher(selector):
    if any(LABELS.get(k) != v for k, v in selector.get("matchLabels", {}).items()):
        return False
    for expression in selector.get("matchExpressions", []):
        key, op = expression["key"], expression["operator"]
        values = expression.get("values", [])
        if op == "In" and LABELS.get(key) not in values:
            return False
        if op == "NotIn" and LABELS.get(key) in values:
            return False
        if op == "Exists" and key not in LABELS:
            return False
        if op == "DoesNotExist" and key in LABELS:
            return False
        if op not in {"In", "NotIn", "Exists", "DoesNotExist"}:
            raise ValueError("unknown selector")
    return True


def verify(expected, live, namespace):
    if namespace != expected["metadata"]["namespace"]:
        return False
    selected = [p for p in live["items"]
                if "Egress" in p["spec"].get("policyTypes", [])
                and selects_publisher(p["spec"]["podSelector"])]
    # NetworkPolicy allows are additive: a second selected egress policy could
    # silently remove isolation even when the expected rule itself is correct.
    return len(selected) == 1 and (
        selected[0].get("metadata", {}).get("namespace") == namespace
        and selected[0].get("metadata", {}).get("name") == expected["metadata"]["name"]
        and selected[0].get("spec") == expected["spec"]
    )


if __name__ == "__main__":
    try:
        expected = json.loads(Path(sys.argv[1]).read_text())
        if not verify(expected, json.load(sys.stdin), sys.argv[2]):
            raise ValueError("policy drift")
    except (ValueError, KeyError, IndexError, OSError):
        sys.exit("Publisher isolation is missing or differs from reviewed source; no Pod was created.")
