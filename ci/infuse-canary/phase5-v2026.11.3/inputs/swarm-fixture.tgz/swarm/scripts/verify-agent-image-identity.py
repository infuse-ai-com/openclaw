#!/usr/bin/env python3
"""Verify an exact immutable Deployment, pod, and runtime image identity."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from typing import Any, Callable


DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
GIT_COMMIT = re.compile(r"^[0-9a-f]{40}$")
Runner = Callable[..., subprocess.CompletedProcess[str]]


class IdentityError(RuntimeError):
    """Raised when runtime identity is absent, mutable, or inconsistent."""


def run_json(command: list[str], *, runner: Runner = subprocess.run) -> Any:
    try:
        result = runner(command, text=True, capture_output=True, timeout=20)
    except subprocess.TimeoutExpired as exc:
        raise IdentityError("runtime identity inspection timed out") from exc
    if result.returncode != 0:
        raise IdentityError("runtime identity inspection failed")
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise IdentityError("runtime identity inspection returned invalid JSON") from exc


def workload_containers(template: dict[str, Any]) -> list[dict[str, Any]]:
    containers = (template.get("spec") or {}).get("containers")
    if not isinstance(containers, list):
        raise IdentityError("deployment containers are invalid")
    selected = [
        container
        for container in containers
        if isinstance(container, dict)
        and container.get("name") == "agent"
    ]
    if not selected or not any(container.get("name") == "agent" for container in selected):
        raise IdentityError("deployment has no agent container")
    return selected


def validate_identity(
    deployment: Any,
    pods: Any,
    *,
    expected_digest: str,
    expected_source_revision: str = "",
) -> dict[str, Any]:
    if DIGEST.fullmatch(expected_digest) is None:
        raise IdentityError("expected image digest is not immutable")
    if not isinstance(deployment, dict) or not isinstance(pods, dict):
        raise IdentityError("runtime identity payload is invalid")
    if expected_source_revision and GIT_COMMIT.fullmatch(expected_source_revision) is None:
        raise IdentityError("expected source revision is not a full Git commit")

    template = ((deployment.get("spec") or {}).get("template") or {})
    annotation = ((template.get("metadata") or {}).get("annotations") or {}).get(
        "openclaw.infuse-ai.com/image-revision"
    )
    if annotation != expected_digest:
        raise IdentityError("deployment image annotation does not match the expected digest")
    source_annotation = ((template.get("metadata") or {}).get("annotations") or {}).get(
        "openclaw.infuse-ai.com/swarm-source-revision"
    )
    if expected_source_revision and source_annotation != expected_source_revision:
        raise IdentityError("deployment source annotation does not match the expected revision")

    containers = workload_containers(template)
    expected_names = {container["name"] for container in containers}
    for container in containers:
        image = container.get("image")
        if not isinstance(image, str) or not image.endswith(f"@{expected_digest}"):
            raise IdentityError("deployment image is not pinned to the expected digest")

    items = pods.get("items")
    if not isinstance(items, list):
        raise IdentityError("pod list is invalid")
    running = [
        pod
        for pod in items
        if isinstance(pod, dict)
        and not (pod.get("metadata") or {}).get("deletionTimestamp")
        and (pod.get("status") or {}).get("phase") == "Running"
    ]
    if len(running) != 1:
        raise IdentityError("runtime identity requires exactly one running pod")

    pod = running[0]
    pod_annotation = ((pod.get("metadata") or {}).get("annotations") or {}).get(
        "openclaw.infuse-ai.com/image-revision"
    )
    if pod_annotation != expected_digest:
        raise IdentityError("pod image annotation does not match the expected digest")
    pod_source_annotation = ((pod.get("metadata") or {}).get("annotations") or {}).get(
        "openclaw.infuse-ai.com/swarm-source-revision"
    )
    if expected_source_revision and pod_source_annotation != expected_source_revision:
        raise IdentityError("pod source annotation does not match the expected revision")
    statuses = {
        status.get("name"): status
        for status in ((pod.get("status") or {}).get("containerStatuses") or [])
        if isinstance(status, dict) and isinstance(status.get("name"), str)
    }
    if not expected_names.issubset(statuses):
        raise IdentityError("runtime container status is incomplete")
    for name in expected_names:
        status = statuses[name]
        image_id = status.get("imageID")
        if status.get("ready") is not True:
            raise IdentityError("runtime container is not ready")
        if not isinstance(image_id, str) or not image_id.endswith(f"@{expected_digest}"):
            raise IdentityError("runtime image id does not match the expected digest")

    return {
        "status": "ready",
        "image_identity_verified": True,
        "source_identity_verified": bool(expected_source_revision),
        "container_count": len(expected_names),
    }


def kubectl_base(context: str, namespace: str) -> list[str]:
    command = ["kubectl"]
    if context:
        command.extend(["--context", context])
    return [*command, "-n", namespace]


def verify_deployment(
    *,
    context: str,
    namespace: str,
    deployment_name: str,
    expected_digest: str,
    expected_source_revision: str = "",
    runner: Runner = subprocess.run,
) -> dict[str, Any]:
    command = kubectl_base(context, namespace)
    deployment = run_json([*command, "get", f"deployment/{deployment_name}", "-o", "json"], runner=runner)
    pods = run_json(
        [
            *command,
            "get",
            "pods",
            "-l",
            f"app.kubernetes.io/name={deployment_name}",
            "-o",
            "json",
        ],
        runner=runner,
    )
    return validate_identity(
        deployment,
        pods,
        expected_digest=expected_digest,
        expected_source_revision=expected_source_revision,
    )


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--context", default="")
    result.add_argument("--namespace", default="agents-swarm")
    result.add_argument("--deployment", action="append", required=True)
    result.add_argument("--expected-digest", required=True)
    result.add_argument("--expected-source-revision", default="")
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if DIGEST.fullmatch(args.expected_digest) is None:
        print("ERROR: agent_image_identity_invalid_expected_digest", file=sys.stderr)
        return 2
    try:
        results = [
            verify_deployment(
                context=args.context,
                namespace=args.namespace,
                deployment_name=name,
                expected_digest=args.expected_digest,
                expected_source_revision=args.expected_source_revision,
            )
            for name in args.deployment
        ]
    except IdentityError:
        print("ERROR: agent_image_identity_verification_failed_closed", file=sys.stderr)
        return 3
    print(
        json.dumps(
            {
                "status": "ready",
                "image_identity_verified": True,
                "deployment_count": len(results),
            },
            separators=(",", ":"),
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
