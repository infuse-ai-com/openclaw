#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-agents-swarm}"
deployment="${2:-openclaw-agent}"
selector="${3:-app.kubernetes.io/name=openclaw-agent}"
context="${KUBE_CONTEXT:-}"
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
marker="backup-restore-smoke-$stamp"
marker_path="/workspace/.backup-restore-smoke"
backup_path="/workspace/.backup-restore-smoke-$stamp.tar"

kubectl_cmd=(kubectl)
if [[ -n "$context" ]]; then
  kubectl_cmd+=(--context "$context")
fi
kubectl_ns=("${kubectl_cmd[@]}" -n "$namespace")

current_pod() {
  "${kubectl_ns[@]}" wait pod \
    -l "$selector" \
    --for=condition=Ready \
    --timeout=120s >/dev/null

  "${kubectl_ns[@]}" get pod \
    -l "$selector" \
    --field-selector=status.phase=Running \
    -o jsonpath='{.items[0].metadata.name}'
}

"${kubectl_ns[@]}" rollout status "deployment/$deployment" --timeout=120s

pod="$(current_pod)"
if [[ -z "$pod" ]]; then
  echo "No pod found for selector $selector in namespace $namespace" >&2
  exit 1
fi

"${kubectl_ns[@]}" exec "$pod" -- sh -lc "echo '$marker' >'$marker_path' && tar -C /workspace -cf '$backup_path' .backup-restore-smoke"
"${kubectl_ns[@]}" exec "$pod" -- sh -lc "rm -f '$marker_path' && test ! -e '$marker_path'"
"${kubectl_ns[@]}" exec "$pod" -- sh -lc "tar -C /workspace -xf '$backup_path' && rm -f '$backup_path'"

actual="$("${kubectl_ns[@]}" exec "$pod" -- sh -lc "cat '$marker_path'")"
if [[ "$actual" != "$marker" ]]; then
  echo "PVC backup/restore smoke failed: expected '$marker', got '$actual'" >&2
  exit 1
fi

echo "PVC backup/restore smoke passed in $namespace"
