#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${2:-${AGENT_ID:-agent-coordinator}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
profile="${OPENCLAW_AGENT_PROFILE:-$agent_id}"

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s
"${kubectl_base[@]}" wait pod -l "$selector" --for=condition=Ready --timeout=120s >/dev/null

pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

"${kubectl_base[@]}" exec "$pod" -c agent -- bash -lc "
  set -euo pipefail
  profile='$profile'
  config=\"\$HOME/.openclaw-\$profile/openclaw.json\"
  test -f \"\$config\"
  jq -e '.gateway.auth.mode == \"none\"' \"\$config\" >/dev/null
  openclaw --profile \"\$profile\" cron list --json >/tmp/openclaw-cron-list.json
  jq -e 'type == \"object\" and has(\"jobs\")' /tmp/openclaw-cron-list.json >/dev/null
"

echo "Agent cron smoke passed for $agent_id in $namespace"
