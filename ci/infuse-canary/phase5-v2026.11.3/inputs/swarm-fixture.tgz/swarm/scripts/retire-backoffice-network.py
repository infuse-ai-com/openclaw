#!/usr/bin/env python3
"""Remove only Backoffice's Registry peer after its approved shutdown."""
import copy
import json
import os
import subprocess
import urllib.parse
import urllib.request

POLICY = 'backoffice-artifact-registry'
BO_PEER = {'namespaceSelector': {'matchLabels': {'kubernetes.io/metadata.name': 'core'}},
           'podSelector': {'matchLabels': {'app.kubernetes.io/name': 'backoffice'}}}
CRONS = {'backoffice-agent-token-usage-import', 'backoffice-azure-delivery-pulse',
         'backoffice-contributions-sync', 'backoffice-health-probes',
         'backoffice-ops-data-retention', 'backoffice-ops-runtime-snapshot'}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def cmd(args, body=None):
    r = subprocess.run(args, input=body, capture_output=True, text=True, timeout=45)
    require(r.returncode == 0, 'Scoped command failed: ' + args[0])
    return r.stdout


def read(kind, name=None):
    raw = cmd(['kubectl', '-n', 'core', 'get', kind] +
              ([name, '--ignore-not-found'] if name else []) + ['-o', 'json'])
    return json.loads(raw) if raw.strip() else None


def azure(path):
    token = os.environ.get('SYSTEM_ACCESSTOKEN', '')
    require(bool(token), 'Pipeline token missing')
    url = 'https://dev.azure.com/infuse-ai/Infuse%20AI/' + path
    request = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + token})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)


def target_spec(live, desired):
    """Reject any drift beyond removal of the one exact retired peer."""
    if live == desired:
        return False
    trimmed = copy.deepcopy(live)
    count = 0
    for rule in trimmed.get('ingress', []):
        peers = rule.get('from', [])
        count += peers.count(BO_PEER)
        rule['from'] = [peer for peer in peers if peer != BO_PEER]
    require(count == 1 and trimmed == desired, 'Policy drift exceeds the approved Backoffice peer removal')
    return True


def stopped(deployment, crons, pods):
    require(deployment is None or
            (deployment['metadata']['uid'] == '384c5a06-5d35-450e-9113-272077f083c4'
             and deployment['spec']['replicas'] == 0), 'Backoffice app is not stopped')
    selected = [c for c in crons if c['metadata']['name'] in CRONS]
    require(len(selected) in (0, 6) and all(c['spec'].get('suspend') is True for c in selected),
            'Backoffice collector state is incomplete or active')
    require(not any(p['spec'].get('serviceAccountName') == 'backoffice'
                    and p.get('status', {}).get('phase') not in ('Succeeded', 'Failed') for p in pods),
            'A Backoffice pod remains active')


def main():
    require(os.environ.get('BUILD_REASON') == 'Manual'
            and os.environ.get('BUILD_SOURCEBRANCH') == 'refs/heads/main'
            and os.environ.get('SYSTEM_DEFINITIONID') == '56', 'Manual Swarm main only')
    require(os.environ.get('STUDIO_PROFILE') == 'preserve', 'Preserve the Studio profile')
    for definition in (49, 108):
        require(azure(f'_apis/build/definitions/{definition}?api-version=7.1')['queueStatus'] == 'disabled',
                'Backoffice queues must remain disabled')
        for status in ('inProgress', 'notStarted', 'postponed'):
            query = urllib.parse.urlencode({'definitions': definition, 'statusFilter': status,
                                            '$top': 100, 'api-version': '7.1'})
            require(not azure('_apis/build/builds?' + query)['value'], 'A Backoffice run remains active')
    stopped(read('deployment', 'backoffice'), read('cronjobs')['items'], read('pods')['items'])
    for name in ('studio', POLICY, 'artifact-image-scanner'):
        workload = read('deployment', name)
        require(workload and workload.get('status', {}).get('readyReplicas', 0) >= 1,
                'A preserved service is not ready')
    desired = json.loads(cmd(['kubectl', '-n', 'core', 'create', '--dry-run=client', '--validate=false',
                              '-f', 'k8s/platform/artifact-registry/networkpolicy.yaml', '-o', 'json']))
    require(desired['metadata']['name'] == POLICY and desired['kind'] == 'NetworkPolicy', 'Wrong policy source')
    live = read('networkpolicy', POLICY)
    require(live is not None, 'Existing shared policy is missing; never create a replacement')
    changed = target_spec(live['spec'], desired['spec'])
    if changed:
        patch = [{'op': 'test', 'path': '/metadata/uid', 'value': live['metadata']['uid']},
                 {'op': 'test', 'path': '/metadata/resourceVersion', 'value': live['metadata']['resourceVersion']},
                 {'op': 'replace', 'path': '/spec', 'value': desired['spec']}]
        cmd(['kubectl', '-n', 'core', 'patch', 'networkpolicy', POLICY, '--type=json',
             '--patch-file=/dev/stdin'], json.dumps(patch))
    after = read('networkpolicy', POLICY)
    require(after['metadata']['uid'] == live['metadata']['uid'] and after['spec'] == desired['spec'],
            'Policy readback differs from reviewed source')
    print(json.dumps({'event': 'backoffice-network-retired', 'namespace': 'core', 'policy': POLICY,
                      'uid': after['metadata']['uid'], 'changed': changed, 'studioAndSharedPeersPreserved': True}))


if __name__ == '__main__':
    try:
        main()
    except RuntimeError as error:
        # All RuntimeError messages above are static, sanitized scope diagnostics.
        raise SystemExit(str(error))
    except Exception:
        raise SystemExit('Retirement network step stopped; inspect scope/access before retry')
