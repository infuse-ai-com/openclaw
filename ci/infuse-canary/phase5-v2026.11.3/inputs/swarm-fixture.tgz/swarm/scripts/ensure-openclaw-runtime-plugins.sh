#!/usr/bin/env bash
set -euo pipefail

profile="${1:-${OPENCLAW_AGENT_PROFILE:-${AGENT_ID:-openclaw-agent}}}"
runtime_version="${OPENCLAW_RUNTIME_VERSION:-}"
if [[ -n "$runtime_version" ]]; then
  default_plugins="@openclaw/codex@${runtime_version} @openclaw/mattermost@${runtime_version}"
else
  default_plugins="@openclaw/codex @openclaw/mattermost"
fi
required_plugins="${OPENCLAW_REQUIRED_PLUGINS-$default_plugins}"
capability_consent_plugins="${OPENCLAW_CAPABILITY_CONSENT_PLUGINS:-}"
bundled_plugin_migrations="${OPENCLAW_BUNDLED_PLUGIN_MIGRATIONS:-}"
marker_root="${OPENCLAW_STATE_DIR:-$HOME/.openclaw-$profile}"
marker_dir="$marker_root/.openclaw-runtime"
marker_file="$marker_dir/plugins.fingerprint"
config_path="${OPENCLAW_CONFIG_PATH:-$marker_root/openclaw.json}"

cleanup_abandoned_install_stages() {
  local extensions_dir="$marker_root/extensions"
  local staging_dir
  local staging_name
  [[ -d "$extensions_dir" ]] || return 0
  for staging_dir in "$extensions_dir"/.openclaw-install-stage-*; do
    [[ -d "$staging_dir" ]] || continue
    staging_name="${staging_dir##*/}"
    [[ "$staging_name" =~ ^\.openclaw-install-stage-[A-Za-z0-9]+$ ]] || continue
    rm -rf -- "$staging_dir"
  done
}

print_local_plugin_fingerprint_inputs() {
  local plugin
  local file
  local relative
  for plugin in $required_plugins; do
    if [[ -f "$plugin" ]]; then
      printf 'local_plugin_archive=%s:%s\n' \
        "$plugin" \
        "$(sha256sum "$plugin" | awk '{print $1}')"
      continue
    fi
    if [[ ! -d "$plugin" ]]; then
      continue
    fi
    printf 'local_plugin=%s\n' "$plugin"
    while IFS= read -r -d '' file; do
      relative="${file#"$plugin"/}"
      printf 'local_plugin_file=%s:%s\n' \
        "$relative" \
        "$(sha256sum "$file" | awk '{print $1}')"
    done < <(find "$plugin" -type f ! -path '*/node_modules/*' -print0 | sort -z)
  done
}

if [[ -z "$profile" ]]; then
  echo "ERROR: OpenClaw profile is required to install runtime plugins" >&2
  exit 2
fi

if ! command -v openclaw >/dev/null 2>&1; then
  echo "ERROR: openclaw CLI is not available" >&2
  exit 2
fi

mkdir -p "$marker_dir"
cleanup_abandoned_install_stages
fingerprint="$(
  {
    openclaw --version
    printf 'required_plugins=%s\n' "$required_plugins"
    printf 'capability_consent_plugins=%s\n' "$capability_consent_plugins"
    printf 'bundled_plugin_migrations=%s\n' "$bundled_plugin_migrations"
    print_local_plugin_fingerprint_inputs
  } | sha256sum | awk '{print $1}'
)"

if [[ "${OPENCLAW_FORCE_PLUGIN_INSTALL:-false}" != "true" && -f "$marker_file" ]]; then
  if [[ "$(cat "$marker_file")" == "$fingerprint" ]]; then
    exit 0
  fi
fi

for plugin in $bundled_plugin_migrations; do
  origin="$(
    openclaw --profile "$profile" plugins inspect "$plugin" --runtime --json 2>/dev/null \
      | jq -er '.plugin.origin' \
      || true
  )"
  if [[ -n "$origin" && "$origin" != "bundled" ]]; then
    if [[ ! -f "$config_path" ]]; then
      echo "ERROR: cannot preserve config while migrating bundled plugin $plugin: $config_path is missing" >&2
      exit 1
    fi
    saved_config="$(cat "$config_path")"
    openclaw --profile "$profile" plugins uninstall "$plugin" --force >/dev/null
    printf '%s' "$saved_config" >"$config_path"
  fi
  openclaw --profile "$profile" plugins inspect "$plugin" --runtime --json \
    | jq -e '.plugin.status == "loaded" and .plugin.origin == "bundled" and .install == null' >/dev/null
done

for plugin in $required_plugins; do
  install_args=(plugins install --force)
  case " $capability_consent_plugins " in
    *" $plugin "*) install_args+=(--accept-capabilities) ;;
  esac
  openclaw --profile "$profile" "${install_args[@]}" "$plugin" >/dev/null
done

cleanup_abandoned_install_stages

printf '%s\n' "$fingerprint" >"$marker_file"
chmod 600 "$marker_file" 2>/dev/null || true
echo "Ensured OpenClaw runtime plugins for profile $profile: $required_plugins"
