#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"
kube_context="${KUBE_CONTEXT:-infuseai-k8s}"
image_ref="${1:?Usage: $0 registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:<canary-tag> sha256:<digest> [--canary|--fleet|--agent=<peer-agent>]}"
digest="${2:?Usage: $0 registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:<canary-tag> sha256:<digest> [--canary|--fleet|--agent=<peer-agent>]}"
mode="${3:---canary}"
image_repository="registry.infuse-ai-tech.party/agents-swarm/openclaw-agent"
exact_image_ref="$image_ref@$digest"
peer_agents=(agent-designer agent-infra agent-intake agent-coordinator)
workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! "$image_ref" =~ ^${image_repository}:gitlab-candidate-[0-9a-f]{40}$ ]]; then
  echo "Refusing image outside the reviewed v2026.11.3 GitLab candidate family: $image_ref" >&2
  exit 1
fi
source_revision="${image_ref##*:gitlab-candidate-}"
if [[ ! "$digest" =~ ^sha256:[0-9a-f]{64}$ ]]; then
  echo "Invalid immutable digest supplied for $image_ref: $digest" >&2
  exit 1
fi
case "$mode" in
  --canary)
    mode_kind="canary"
    agents=(agent-developer)
    ;;
  --fleet)
    mode_kind="fleet"
    agents=("${peer_agents[@]}")
    ;;
  --agent=*)
    mode_kind="agent"
    requested_agent="${mode#--agent=}"
    if [[ " ${peer_agents[*]} " != *" $requested_agent "* ]]; then
      echo "Single-agent mode requires one of: ${peer_agents[*]}" >&2
      exit 1
    fi
    agents=("$requested_agent")
    ;;
  *)
    echo "Mode must be --canary, --fleet, or --agent=<peer-agent>" >&2
    exit 1
    ;;
esac

for command in kubectl jq shasum; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "Missing required command: $command" >&2
    exit 1
  fi
done

kubectl_cmd=(kubectl --context "$kube_context")

template_fingerprint() {
  local name="$1"
  "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$name" -o json \
    | jq -cS '.spec.template' \
    | shasum -a 256 \
    | awk '{print $1}'
}

if [[ "$mode_kind" == "canary" ]]; then
  echo "Deploying exact-head Tinus canary image: $exact_image_ref"
  echo "Only Deployment/agent-developer will be applied; peer agents remain untouched."
  for name in "${peer_agents[@]}"; do
    template_fingerprint "$name" >"$workdir/$name.before"
  done
else
  echo "Verifying Tinus on the exact immutable canary before peer promotion."
  KUBE_CONTEXT="$kube_context" NAMESPACE="$namespace" AGENT_ID=agent-developer \
    EXPECTED_IMAGE_DIGEST="$digest" EXPECTED_IMAGE_REF="$exact_image_ref" \
    scripts/smoke-agent-runtime.sh "$namespace" agent-developer
  echo "Promoting peer target(s): ${agents[*]}"
fi

for agent in "${agents[@]}"; do
  current_image="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent" -o jsonpath='{.spec.template.spec.containers[0].image}')"
  current_replicas="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent" -o jsonpath='{.spec.replicas}')"
  current_revision="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent" -o jsonpath='{.metadata.annotations.deployment\.kubernetes\.io/revision}')"
  echo "$agent before: image=$current_image replicas=$current_replicas revision=$current_revision"
  if [[ "$current_replicas" != "1" ]]; then
    echo "Refusing deployment/$agent with unexpected replica count $current_replicas" >&2
    exit 1
  fi

  kubectl kustomize "k8s/agents/$agent" \
    | kubectl create --dry-run=client -f - -o json \
    | jq -sc '{apiVersion:"v1",kind:"List",items:.}' \
    | jq -c \
        --arg agent "$agent" \
        --arg image "$exact_image_ref" \
        --arg image_repository "$image_repository" \
        --arg digest "$digest" \
        --arg source_revision "$source_revision" '
          .items[]
          | select(.kind == "Deployment" and .metadata.name == $agent)
          | .spec.template.spec.containers |= map(
              if (.image | startswith($image_repository + ":"))
              then .image = $image
              else .
              end
            )
          | .spec.template.metadata.annotations["openclaw.infuse-ai.com/image-revision"] = $digest
          | .spec.template.metadata.annotations["openclaw.infuse-ai.com/swarm-source-revision"] = $source_revision
          | .spec.template.metadata.annotations["openclaw.infuse-ai.com/version"] = "2026.11.3"
        ' \
    >"$workdir/$agent.json"

  KUBE_CONTEXT="$kube_context" \
  OPENCLAW_ROLLOUT_MODE="${OPENCLAW_ROLLOUT_MODE:-bounded}" \
  OPENCLAW_DEPLOY_DRAIN_SECONDS="${OPENCLAW_DEPLOY_DRAIN_SECONDS:-}" \
    "$script_dir/rollout-persistent-agent.sh" "$namespace" "$agent" "$workdir/$agent.json"
  KUBE_CONTEXT="$kube_context" NAMESPACE="$namespace" AGENT_ID="$agent" \
    EXPECTED_IMAGE_DIGEST="$digest" EXPECTED_IMAGE_REF="$exact_image_ref" \
    scripts/smoke-agent-runtime.sh "$namespace" "$agent"
done

if [[ "$mode_kind" == "canary" ]]; then
  for name in "${peer_agents[@]}"; do
    if [[ "$(template_fingerprint "$name")" != "$(cat "$workdir/$name.before")" ]]; then
      echo "Canary rollout changed deployment/$name; stop and investigate." >&2
      exit 1
    fi
    echo "Verified deployment/$name was not changed."
  done
fi

"${kubectl_cmd[@]}" -n "$namespace" get deploy \
  -o custom-columns='NAME:.metadata.name,REPLICAS:.spec.replicas,READY:.status.readyReplicas,REVISION:.metadata.annotations.deployment\.kubernetes\.io/revision,IMAGE:.spec.template.spec.containers[0].image'
"${kubectl_cmd[@]}" -n "$namespace" get pods \
  -l app.kubernetes.io/component=persistent-agent \
  -o custom-columns='NAME:.metadata.name,READY:.status.containerStatuses[0].ready,RESTARTS:.status.containerStatuses[0].restartCount,IMAGE:.spec.containers[0].image'

if [[ "$mode_kind" == "canary" ]]; then
  echo "Tinus canary deployment completed: $exact_image_ref"
elif [[ "$mode_kind" == "agent" ]]; then
  echo "Single-peer promotion completed for ${agents[0]}: $exact_image_ref"
else
  echo "Sequential peer promotion completed: $exact_image_ref"
fi
