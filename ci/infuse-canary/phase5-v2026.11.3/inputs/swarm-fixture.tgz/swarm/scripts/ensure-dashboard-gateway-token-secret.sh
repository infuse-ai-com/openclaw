#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"
secret_name="${OPENCLAW_DASHBOARD_GATEWAY_SECRET:-openclaw-agent-dashboard-gateway}"

if kubectl -n "$namespace" get secret "$secret_name" >/dev/null 2>&1; then
  echo "Secret $namespace/$secret_name already exists; leaving it unchanged."
  exit 0
fi

if ! command -v openssl >/dev/null 2>&1; then
  echo "ERROR: openssl is required to generate the gateway token" >&2
  exit 2
fi

token="$(openssl rand -base64 48)"
kubectl -n "$namespace" create secret generic "$secret_name" \
  --from-literal="OPENCLAW_GATEWAY_TOKEN=${token}" >/dev/null
unset token

echo "Created secret $namespace/$secret_name with OPENCLAW_GATEWAY_TOKEN."
