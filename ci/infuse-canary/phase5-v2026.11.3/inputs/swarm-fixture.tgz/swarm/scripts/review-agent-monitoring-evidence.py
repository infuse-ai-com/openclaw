#!/usr/bin/env python3
"""Validate and summarize a governed cross-backend agent-monitoring review."""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = (
    ROOT
    / "config"
    / "observability"
    / "reviews"
    / "agent-monitoring-cross-backend-acceptance-2026-09-01.json"
)
EXPECTED_AGENTS = {
    "agent-coordinator",
    "agent-developer",
    "agent-infra",
    "agent-designer",
    "agent-intake",
}
EXPECTED_CLAIMS = {
    "run_health",
    "tool_reliability",
    "trace_integrity",
    "lifecycle_coverage",
    "knowledge_base_use",
    "alert_state",
    "privacy",
    "provenance",
}
SCORE_KEYS = EXPECTED_CLAIMS | {"traffic_attribution", "model_routing"}
STATUSES = {"verified", "not_verified", "inconclusive"}
BACKENDS = {
    "prometheus",
    "grafana",
    "loki",
    "langfuse",
    "kubernetes",
    "knowledge_base",
    "repository",
}
REVIEW_KEYS = {
    "id",
    "windowStart",
    "windowEnd",
    "environment",
    "release",
    "containerImageRevision",
    "openclawRuntimeRevision",
}
ROOT_KEYS = {
    "schemaVersion",
    "review",
    "claims",
    "alertClassification",
    "drilldown",
    "agents",
    "recommendations",
}
CLAIM_KEYS = {"id", "status", "summary", "evidence"}
EVIDENCE_KEYS = {"backend", "surface", "pointer"}
ALERT_GROUP_KEYS = {"activeAgentImpact", "historicalNoise"}
ALERT_KEYS = {"name", "class", "status", "scope", "reason"}
DRILLDOWN_KEYS = {"order", "backend", "surface", "pointer", "instruction"}
AGENT_KEYS = {"agent", "scores"}
RECOMMENDATION_KEYS = {
    "id",
    "ownerRepository",
    "status",
    "evidenceClaimIds",
    "summary",
    "requiresHumanReview",
}
REVISION_RE = re.compile(r"^(?:sha256:[0-9a-f]{64}|[0-9a-f]{40})$")
TOKEN_RE = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,127}$")
FORBIDDEN_KEY_RE = re.compile(
    r"^(?:prompt|response|content|document|body|message|session_id|run_id|trace_id)$",
    re.IGNORECASE,
)
FORBIDDEN_VALUE_RES = (
    re.compile(r"(?:bearer|basic)\s+[A-Za-z0-9._~+/=-]{8,}", re.IGNORECASE),
    re.compile(r"\b[0-9a-f]{16,32}\b", re.IGNORECASE),
    re.compile(r"-----BEGIN [A-Z ]+PRIVATE KEY-----"),
)


class ReviewError(ValueError):
    """Raised when a monitoring review violates the governed contract."""


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ReviewError("review package must be an object")
    return value


def exact_object(value: Any, keys: set[str], path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ReviewError(f"{path} must be an object")
    if set(value) != keys:
        raise ReviewError(f"{path} keys must be exactly {sorted(keys)}")
    return value


def bounded_text(value: Any, path: str, maximum: int = 320) -> str:
    if not isinstance(value, str) or not value or len(value) > maximum:
        raise ReviewError(f"{path} must be non-empty and at most {maximum} characters")
    if any(pattern.search(value) for pattern in FORBIDDEN_VALUE_RES):
        raise ReviewError(f"{path} contains a forbidden identifier or credential shape")
    return value


def timestamp(value: Any, path: str) -> datetime:
    text = bounded_text(value, path, 32)
    if not text.endswith("Z"):
        raise ReviewError(f"{path} must be UTC RFC3339")
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as error:
        raise ReviewError(f"{path} must be UTC RFC3339") from error


def validate_privacy(value: Any, path: str = "$") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if FORBIDDEN_KEY_RE.search(key):
                raise ReviewError(f"{path}.{key} uses a forbidden field name")
            validate_privacy(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            validate_privacy(child, f"{path}[{index}]")
    elif isinstance(value, str):
        bounded_text(value, path)


def validate_evidence(value: Any, path: str) -> None:
    rows = value
    if not isinstance(rows, list) or not rows:
        raise ReviewError(f"{path} must contain at least one evidence reference")
    for index, raw in enumerate(rows):
        row = exact_object(raw, EVIDENCE_KEYS, f"{path}[{index}]")
        if row["backend"] not in BACKENDS:
            raise ReviewError(f"{path}[{index}].backend is not approved")
        for key in ("surface", "pointer"):
            bounded_text(row[key], f"{path}[{index}].{key}")


def validate_review(package: dict[str, Any]) -> None:
    exact_object(package, ROOT_KEYS, "$")
    if package["schemaVersion"] != "1.0.0":
        raise ReviewError("schemaVersion must be 1.0.0")
    validate_privacy(package)

    review = exact_object(package["review"], REVIEW_KEYS, "$.review")
    if timestamp(review["windowEnd"], "$.review.windowEnd") <= timestamp(
        review["windowStart"], "$.review.windowStart"
    ):
        raise ReviewError("review window must have positive duration")
    for key in ("id", "environment", "release"):
        if TOKEN_RE.fullmatch(review[key]) is None:
            raise ReviewError(f"$.review.{key} is not a bounded token")
    for key in ("containerImageRevision", "openclawRuntimeRevision"):
        if REVISION_RE.fullmatch(review[key]) is None:
            raise ReviewError(f"$.review.{key} is not an immutable revision")

    claims = package["claims"]
    if not isinstance(claims, list) or len(claims) != len(EXPECTED_CLAIMS):
        raise ReviewError("claims must contain the exact governed claim set")
    seen_claims: set[str] = set()
    for index, raw in enumerate(claims):
        claim = exact_object(raw, CLAIM_KEYS, f"$.claims[{index}]")
        claim_id = claim["id"]
        if claim_id not in EXPECTED_CLAIMS or claim_id in seen_claims:
            raise ReviewError(f"$.claims[{index}].id is unexpected or duplicated")
        seen_claims.add(claim_id)
        if claim["status"] not in STATUSES:
            raise ReviewError(f"$.claims[{index}].status is not governed")
        bounded_text(claim["summary"], f"$.claims[{index}].summary")
        validate_evidence(claim["evidence"], f"$.claims[{index}].evidence")
    if seen_claims != EXPECTED_CLAIMS:
        raise ReviewError("claims do not cover the exact governed claim set")

    alert_groups = exact_object(
        package["alertClassification"], ALERT_GROUP_KEYS, "$.alertClassification"
    )
    expected_classes = {
        "activeAgentImpact": "active_agent_impact",
        "historicalNoise": "historical_noise",
    }
    seen_alerts: set[str] = set()
    for group_name, expected_class in expected_classes.items():
        rows = alert_groups[group_name]
        if not isinstance(rows, list) or not rows:
            raise ReviewError(f"$.alertClassification.{group_name} must not be empty")
        for index, raw in enumerate(rows):
            row = exact_object(
                raw, ALERT_KEYS, f"$.alertClassification.{group_name}[{index}]"
            )
            if row["class"] != expected_class:
                raise ReviewError(f"alert class disagrees with {group_name}")
            if row["status"] not in {"active", "inactive", "stale", "resolved"}:
                raise ReviewError("alert status is not bounded")
            if row["name"] in seen_alerts:
                raise ReviewError("alert names must be unique")
            seen_alerts.add(row["name"])
            for key in ("name", "scope", "reason"):
                bounded_text(row[key], f"$.alertClassification.{group_name}[{index}].{key}")

    drilldown = package["drilldown"]
    expected_path = ["prometheus", "grafana", "loki", "langfuse"]
    if not isinstance(drilldown, list) or len(drilldown) != len(expected_path):
        raise ReviewError("drilldown must contain alert, aggregate, diagnostic, and trace steps")
    for index, raw in enumerate(drilldown):
        row = exact_object(raw, DRILLDOWN_KEYS, f"$.drilldown[{index}]")
        if row["order"] != index + 1 or row["backend"] != expected_path[index]:
            raise ReviewError("drilldown backend order must be Prometheus, Grafana, Loki, Langfuse")
        for key in ("surface", "pointer", "instruction"):
            bounded_text(row[key], f"$.drilldown[{index}].{key}")

    agents = package["agents"]
    if not isinstance(agents, list) or len(agents) != len(EXPECTED_AGENTS):
        raise ReviewError("agents must contain the exact persistent fleet")
    seen_agents: set[str] = set()
    for index, raw in enumerate(agents):
        row = exact_object(raw, AGENT_KEYS, f"$.agents[{index}]")
        if row["agent"] not in EXPECTED_AGENTS or row["agent"] in seen_agents:
            raise ReviewError(f"$.agents[{index}].agent is unexpected or duplicated")
        seen_agents.add(row["agent"])
        scores = exact_object(row["scores"], SCORE_KEYS, f"$.agents[{index}].scores")
        if any(status not in STATUSES for status in scores.values()):
            raise ReviewError(f"$.agents[{index}].scores contains an ungoverned status")

    recommendations = package["recommendations"]
    if not isinstance(recommendations, list) or not recommendations:
        raise ReviewError("at least one evidence-backed recommendation is required")
    for index, raw in enumerate(recommendations):
        row = exact_object(raw, RECOMMENDATION_KEYS, f"$.recommendations[{index}]")
        if row["status"] != "proposed" or row["requiresHumanReview"] is not True:
            raise ReviewError("recommendations must remain proposed and human-reviewed")
        for key in ("id", "ownerRepository"):
            if TOKEN_RE.fullmatch(row[key]) is None:
                raise ReviewError(f"$.recommendations[{index}].{key} is not bounded")
        bounded_text(row["summary"], f"$.recommendations[{index}].summary")
        claim_ids = row["evidenceClaimIds"]
        if not isinstance(claim_ids, list) or not claim_ids:
            raise ReviewError("recommendation evidenceClaimIds must not be empty")
        if any(claim_id not in EXPECTED_CLAIMS for claim_id in claim_ids):
            raise ReviewError("recommendation references an unknown claim")


def build_report(package: dict[str, Any]) -> dict[str, Any]:
    validate_review(package)
    status_counts = {status: 0 for status in sorted(STATUSES)}
    for claim in package["claims"]:
        status_counts[claim["status"]] += 1
    return {
        "schemaVersion": "1.0.0",
        "review": package["review"],
        "claimStatusCounts": status_counts,
        "claims": {claim["id"]: claim["status"] for claim in package["claims"]},
        "fleetScorecard": {
            row["agent"]: row["scores"] for row in package["agents"]
        },
        "alertClassification": {
            "activeAgentImpact": len(package["alertClassification"]["activeAgentImpact"]),
            "historicalNoise": len(package["alertClassification"]["historicalNoise"]),
        },
        "drilldownBackends": [row["backend"] for row in package["drilldown"]],
        "recommendations": package["recommendations"],
        "mutationPolicy": "human_review_required",
        "privacy": "metadata_only",
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate and summarize governed cross-backend monitoring evidence"
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        report = build_report(load_json(args.input))
    except (ReviewError, OSError, json.JSONDecodeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
