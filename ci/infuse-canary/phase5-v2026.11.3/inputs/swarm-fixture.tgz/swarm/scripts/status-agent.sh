#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-agents-swarm}"
agent_id="${2:?Usage: scripts/status-agent.sh <namespace> <agent-id>}"
context="${KUBE_CONTEXT:-infuseai-k8s}"

kubectl_base=(kubectl --context "$context" -n "$namespace")

echo "Context: $context"
echo "Namespace: $namespace"
echo "Agent: $agent_id"
echo

echo "Deployment:"
"${kubectl_base[@]}" get deployment "$agent_id" -o wide
echo

echo "Pods:"
"${kubectl_base[@]}" get pods -l "app.kubernetes.io/name=$agent_id" -o wide
echo

echo "PVC:"
"${kubectl_base[@]}" get pvc "$agent_id-workspace" -o wide
echo

echo "Runtime image:"
"${kubectl_base[@]}" get deployment "$agent_id" \
  -o jsonpath='{.spec.template.spec.containers[?(@.name=="agent")].image}{"\n"}'
echo

echo "Recent logs:"
"${kubectl_base[@]}" logs "deploy/$agent_id" --tail=80
