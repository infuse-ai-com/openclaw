#!/usr/bin/env bash
set -euo pipefail

agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-coordinator}"
item_name="${VAULTWARDEN_ITEM_NAME:?Set VAULTWARDEN_ITEM_NAME to a Vaultwarden item name}"
source_field="${CREDENTIAL_SOURCE_FIELD:-password}"
bw="${BW_HELPER:-bw-local-vaultwarden}"
dry_run="${DRY_RUN:-false}"
runtime_bundle_dir="/opt/openclaw-agent-skill-config/config/agent-skill-bundles"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -d "$runtime_bundle_dir" ]]; then
  bundle_dir="$runtime_bundle_dir"
else
  bundle_dir="$script_dir/../config/agent-skill-bundles"
fi
bundle_path="$bundle_dir/$agent_id.json"

python3 - \
  "$bundle_path" \
  "$agent_id" \
  "$item_name" \
  "$source_field" \
  "${PROJECT_ENV_BOOTSTRAP_PROJECT:-}" \
  "${PROJECT_ENV_BOOTSTRAP_PROFILE:-}" \
  "${PROJECT_ENV_BOOTSTRAP_VAULT_REF:-}" <<'PY'
import json
import sys
from pathlib import Path

bundle_path = Path(sys.argv[1])
agent_id = sys.argv[2]
item_name = sys.argv[3]
source_field = sys.argv[4] or "password"
env_project = sys.argv[5]
env_profile = sys.argv[6]
env_vault_ref = sys.argv[7]

if source_field not in {"password", "username"}:
    print(f"Unsupported direct lookup field: {source_field}", file=sys.stderr)
    sys.exit(2)
if not bundle_path.exists():
    print(f"Agent bundle not found: {bundle_path}", file=sys.stderr)
    sys.exit(2)

bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
if bundle.get("agent_id") != agent_id:
    print(f"Agent bundle id mismatch: {bundle_path}", file=sys.stderr)
    sys.exit(2)

env_context = (env_project, env_profile, env_vault_ref)
if any(env_context):
    if not all(env_context):
        print("Incomplete project env-bootstrap authorization context", file=sys.stderr)
        sys.exit(2)
    grant = (
        bundle.get("credential_access", {})
        .get("vaultwarden", {})
        .get("env_bootstrap", {})
        .get("projects", {})
        .get(env_project, {})
    )
    binding = grant.get("vault_refs", {}).get(env_vault_ref, {})
    if (
        env_profile not in grant.get("profiles", [])
        or binding.get("item") != item_name
        or binding.get("field") != source_field
    ):
        print(
            "Project env bootstrap is not allowed by the agent bundle: "
            f"agent={agent_id!r}, project={env_project!r}, "
            f"profile={env_profile!r}, vault_ref={env_vault_ref!r}",
            file=sys.stderr,
        )
        sys.exit(2)
    sys.exit(0)

PY

if [[ "$dry_run" == "true" ]]; then
  echo "Direct lookup will defer authorization to Vaultwarden: agent=$agent_id field=$source_field"
  exit 0
fi

if [[ "$bw" == */* ]]; then
  bw_path="$bw"
else
  bw_path="$(command -v "$bw" || true)"
fi
if [[ -z "$bw_path" || ! -x "$bw_path" ]]; then
  echo "Vaultwarden helper not found or not executable: $bw" >&2
  exit 2
fi

export OPENCLAW_BW_SERVER="${OPENCLAW_BW_SERVER:-https://vault.infuse-ai-tech.party}"
export OPENCLAW_BW_DATA="${OPENCLAW_BW_DATA:-$HOME/.openclaw/secure/bitwarden-cli-$agent_id}"

config_error="$(mktemp)"
if ! "$bw_path" config server "$OPENCLAW_BW_SERVER" >/dev/null 2>"$config_error"; then
  if ! grep -q "Logout required before server config update" "$config_error"; then
    cat "$config_error" >&2
    rm -f "$config_error"
    exit 2
  fi
fi
rm -f "$config_error"

if [[ -z "${BW_SESSION:-}" && -n "${OPENCLAW_BW_SESSION_FILE:-}" && -r "$OPENCLAW_BW_SESSION_FILE" ]]; then
  BW_SESSION="$(<"$OPENCLAW_BW_SESSION_FILE")"
  export BW_SESSION
fi

status="$("$bw_path" status 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status", "unknown"))')"

if [[ "$status" == "unauthenticated" && -n "${BW_CLIENTID:-}" && -n "${BW_CLIENTSECRET:-}" ]]; then
  "$bw_path" login --apikey >/dev/null
  status="$("$bw_path" status 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status", "unknown"))')"
fi

if [[ "$status" == "locked" && -z "${BW_SESSION:-}" ]]; then
  if [[ -n "${BW_PASSWORD:-}" ]]; then
    BW_SESSION="$("$bw_path" unlock --passwordenv BW_PASSWORD --raw)"
    export BW_SESSION
  elif [[ -n "${BW_MASTER_PASSWORD:-}" ]]; then
    BW_SESSION="$("$bw_path" unlock --passwordenv BW_MASTER_PASSWORD --raw)"
    export BW_SESSION
  else
    echo "Vaultwarden profile is locked and no unlock environment was provided" >&2
    exit 2
  fi
fi

"$bw_path" sync >/dev/null
item_id="$("$bw_path" list items --search "$item_name" | python3 -c '
import json
import sys

name = sys.argv[1]
matches = [item.get("id") for item in json.load(sys.stdin) if item.get("name") == name]
if len(matches) != 1:
    print(
        "Vaultwarden exact item lookup failed: "
        + ("no match" if not matches else "duplicate matches"),
        file=sys.stderr,
    )
    raise SystemExit(1)
print(matches[0])
' "$item_name")"
"$bw_path" get "$source_field" "$item_id"
