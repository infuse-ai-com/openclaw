#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

export AGENT_ID="${AGENT_ID:-agent-developer}"
export MATTERMOST_SECRET_NAME="${MATTERMOST_SECRET_NAME:-agent-developer-mattermost}"
export VAULTWARDEN_ITEM_NAME="${VAULTWARDEN_ITEM_NAME:-Mattermost / agent-developer BOT token}"
export MATTERMOST_CHANNEL_ID="${MATTERMOST_CHANNEL_ID:-1k6r6ipd87ry9j59xp8to59rnr}"

exec "$script_dir/sync-agent-mattermost-secret.sh" "$@"
