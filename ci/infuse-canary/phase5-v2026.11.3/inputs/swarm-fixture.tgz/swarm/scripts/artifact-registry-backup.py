#!/usr/bin/env python3
"""Create, export, and optionally restore-prove one Artifact Registry backup."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import time
from typing import Any


EXPECTED_IDENTITY = (
    "system:serviceaccount:platform-operators:kapiteky-cluster-operator"
)
LEGACY_EXPECTED_IDENTITY = "system:serviceaccount:oleagut:kapiteky-cluster-operator"
DEPLOYMENT = "backoffice-artifact-registry"
SOURCE_PVC = "backoffice-artifact-registry"
TRANSFER_PVC = "backoffice-artifact-registry-backup-transfer"
ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")
REMOTE = re.compile(r"^[A-Za-z0-9_.-]+$")
REMOTE_PATH = re.compile(r"^/[A-Za-z0-9._/-]+$")
SHA256 = re.compile(r"^[a-f0-9]{64}$")
JOB_POLL_SECONDS = 2
JOB_TIMEOUT_SECONDS = 30 * 60


class BackupError(RuntimeError):
    pass


def run(
    command: list[str],
    *,
    input_text: str | None = None,
    label: str,
    capture: bool = True,
) -> str:
    result = subprocess.run(
        command,
        input=input_text,
        text=True,
        stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        check=False,
    )
    if result.returncode != 0:
        raise BackupError(f"{label} failed with exit code {result.returncode}")
    return result.stdout if capture else ""


def kube(context: str, namespace: str, *arguments: str, input_text: str | None = None, label: str) -> str:
    return run(
        ["kubectl", "--context", context, "-n", namespace, *arguments],
        input_text=input_text,
        label=label,
    )


def preflight(context: str, namespace: str) -> None:
    current = run(["kubectl", "--context", context, "config", "current-context"], label="Kubernetes context").strip()
    if current != context:
        raise BackupError(f"unexpected Kubernetes context: {current or 'unknown'}")
    identity = json.loads(run(["kubectl", "--context", context, "auth", "whoami", "-o", "json"], label="Kubernetes identity"))
    username = identity.get("status", {}).get("userInfo", {}).get("username")
    if username not in {EXPECTED_IDENTITY, LEGACY_EXPECTED_IDENTITY}:
        raise BackupError(f"unexpected Kubernetes identity: {username or 'unknown'}")
    checks = (
        ("get", "deployments.apps"),
        ("patch", "deployments.apps"),
        ("create", "jobs.batch"),
        ("delete", "jobs.batch"),
        ("create", "pods"),
        ("delete", "pods"),
        ("create", "pods/exec"),
        ("create", "persistentvolumeclaims"),
        ("get", "persistentvolumeclaims"),
        ("delete", "persistentvolumeclaims"),
    )
    for verb, resource in checks:
        allowed = run(
            ["kubectl", "--context", context, "auth", "can-i", verb, resource, "-n", namespace],
            label=f"Kubernetes {verb} {resource} authorization",
        ).strip()
        if allowed != "yes":
            raise BackupError(f"Kubernetes identity cannot {verb} {resource} in {namespace}")
    kube(
        context,
        namespace,
        "rollout",
        "status",
        f"deployment/{DEPLOYMENT}",
        "--timeout=2m",
        label="verify Registry readiness before backup",
    )
    kube(
        context,
        namespace,
        "exec",
        f"deployment/{DEPLOYMENT}",
        "--",
        "tar",
        "--help",
        label="verify Registry image transfer tooling",
    )


def load_recovery_objects(repo_root: Path) -> dict[tuple[str, str], dict[str, Any]]:
    rendered = run(
        ["kubectl", "kustomize", str(repo_root / "k8s/platform/artifact-registry-recovery")],
        label="Artifact Registry recovery render",
    )
    normalized = run(
        ["kubectl", "create", "--dry-run=client", "--validate=false", "-f", "-", "-o", "json"],
        input_text=rendered,
        label="Artifact Registry recovery client-side normalization",
    )
    objects: dict[tuple[str, str], dict[str, Any]] = {}
    decoder = json.JSONDecoder()
    cursor = 0
    while cursor < len(normalized):
        while cursor < len(normalized) and normalized[cursor].isspace():
            cursor += 1
        if cursor >= len(normalized):
            break
        resource, cursor = decoder.raw_decode(normalized, cursor)
        if isinstance(resource, dict):
            objects[(resource.get("kind", ""), resource.get("metadata", {}).get("name", ""))] = resource
    required = {
        ("PersistentVolumeClaim", TRANSFER_PVC),
        ("PersistentVolumeClaim", "backoffice-artifact-registry-restore-target"),
        ("Job", "backoffice-artifact-registry-backup-template"),
        ("Job", "backoffice-artifact-registry-restore-template"),
        ("NetworkPolicy", "backoffice-artifact-registry-recovery-deny-all"),
        ("Role", "artifact-registry-recovery-policy-reader"),
        ("RoleBinding", "artifact-registry-recovery-policy-reader"),
    }
    missing = sorted(required - objects.keys())
    if missing:
        raise BackupError(f"recovery render is missing {len(missing)} required resources")
    return objects


def validate_recovery_network_policy(live: dict[str, Any], expected: dict[str, Any], namespace: str) -> None:
    identity = (
        live.get("apiVersion"),
        live.get("kind"),
        live.get("metadata", {}).get("namespace"),
        live.get("metadata", {}).get("name"),
    )
    expected_identity = (
        expected.get("apiVersion"),
        expected.get("kind"),
        namespace,
        expected.get("metadata", {}).get("name"),
    )

    def normalized_spec(resource: dict[str, Any]) -> dict[str, Any]:
        spec = json.loads(json.dumps(resource.get("spec", {})))
        # Kubernetes omits empty ingress/egress arrays from the stored object.
        # For an explicitly selected policy type, omitted and empty both mean
        # that no traffic rules are allowed. Preserve strict comparison for
        # every other field and for any non-empty rule.
        spec.setdefault("ingress", [])
        spec.setdefault("egress", [])
        policy_types = spec.get("policyTypes")
        if isinstance(policy_types, list):
            spec["policyTypes"] = sorted(policy_types)
        return spec

    if identity != expected_identity or normalized_spec(live) != normalized_spec(expected):
        raise BackupError("live recovery NetworkPolicy does not match reviewed source")


def verify_recovery_network_policy(
    context: str,
    namespace: str,
    expected: dict[str, Any],
) -> None:
    name = expected["metadata"]["name"]
    live = json.loads(kube(
        context,
        namespace,
        "get",
        "networkpolicy",
        name,
        "-o",
        "json",
        label="verify live recovery NetworkPolicy",
    ))
    validate_recovery_network_policy(live, expected, namespace)


def apply_object(context: str, namespace: str, resource: dict[str, Any], *, label: str) -> None:
    kube(
        context,
        namespace,
        "apply",
        "--server-side",
        "--field-manager=artifact-registry-backup-operator",
        "-f",
        "-",
        input_text=json.dumps(resource),
        label=label,
    )


def sanitized_job(template: dict[str, Any], *, name: str, backup_id: str, action: str, image: str) -> dict[str, Any]:
    if not re.fullmatch(r"[^\s]+@sha256:[a-f0-9]{64}", image):
        raise BackupError("recovery requires the exact deployed Registry image digest")
    job = json.loads(json.dumps(template))
    job["metadata"]["name"] = name
    job["metadata"].pop("annotations", None)
    job["spec"]["suspend"] = False
    container = job["spec"]["template"]["spec"]["containers"][0]
    container["image"] = image
    env = {entry["name"]: entry for entry in container.get("env", [])}
    env["ARTIFACT_REGISTRY_BACKUP_PATH"]["value"] = f"/backup/{backup_id}"
    if action == "verify":
        container["command"][-1] = "verify"
        container["env"] = [env["ARTIFACT_REGISTRY_BACKUP_PATH"]]
        container["volumeMounts"] = [
            mount for mount in container["volumeMounts"] if mount["name"] in {"backup", "tmp"}
        ]
        job["spec"]["template"]["spec"]["volumes"] = [
            volume for volume in job["spec"]["template"]["spec"]["volumes"] if volume["name"] in {"backup", "tmp"}
        ]
    elif action == "restore":
        restore_env = {entry["name"]: entry for entry in container.get("env", [])}
        restore_env["ARTIFACT_REGISTRY_BACKUP_PATH"]["value"] = f"/backup/{backup_id}"
    elif action != "create":
        raise BackupError("unsupported recovery action")
    return job


def wait_job(context: str, namespace: str, name: str) -> dict[str, Any]:
    deadline = time.monotonic() + JOB_TIMEOUT_SECONDS
    while True:
        job = json.loads(kube(
            context,
            namespace,
            "get",
            "job",
            name,
            "-o",
            "json",
            label=f"inspect {name}",
        ))
        conditions = {
            condition.get("type"): condition.get("status")
            for condition in job.get("status", {}).get("conditions", [])
            if isinstance(condition, dict)
        }
        if conditions.get("Failed") == "True":
            raise BackupError(f"{name} failed before producing a receipt")
        if conditions.get("Complete") == "True":
            break
        if time.monotonic() >= deadline:
            raise BackupError(f"{name} did not complete within 30 minutes")
        time.sleep(JOB_POLL_SECONDS)
    receipt = json.loads(kube(context, namespace, "logs", f"job/{name}", label=f"read {name} receipt").strip())
    if receipt.get("schema") != "infuse.artifact-registry-backup-receipt/v1":
        raise BackupError(f"{name} returned an invalid receipt")
    return receipt


def helper_pod(
    *,
    namespace: str,
    name: str,
    image: str,
    claim_name: str,
    read_only: bool,
) -> dict[str, Any]:
    return {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": name,
            "namespace": namespace,
            "labels": {
                "app.kubernetes.io/name": "backoffice-artifact-registry-recovery",
                "app.kubernetes.io/component": "artifact-registry-recovery",
            },
        },
        "spec": {
            "automountServiceAccountToken": False,
            "restartPolicy": "Never",
            "imagePullSecrets": [{"name": "harbor-pull"}],
            "securityContext": {
                "runAsNonRoot": True,
                "runAsUser": 1001,
                "runAsGroup": 1001,
                "fsGroup": 1001,
                "seccompProfile": {"type": "RuntimeDefault"},
            },
            "containers": [{
                "name": "transfer",
                "image": image,
                "command": ["sh", "-c", "trap : TERM INT; sleep 3600 & wait"],
                "resources": {
                    "requests": {"cpu": "25m", "memory": "32Mi"},
                    "limits": {"cpu": "100m", "memory": "128Mi"},
                },
                "securityContext": {
                    "allowPrivilegeEscalation": False,
                    "readOnlyRootFilesystem": True,
                    "capabilities": {"drop": ["ALL"]},
                },
                "volumeMounts": [
                    {"name": "backup", "mountPath": "/backup", "readOnly": read_only},
                    {"name": "tmp", "mountPath": "/work"},
                ],
                "env": [{"name": "TMPDIR", "value": "/work"}],
            }],
            "volumes": [
                {"name": "backup", "persistentVolumeClaim": {"claimName": claim_name, "readOnly": read_only}},
                {"name": "tmp", "emptyDir": {}},
            ],
        },
    }


def verify_local_bundle(bundle: Path) -> dict[str, Any]:
    try:
        manifest = json.loads((bundle / "backup-manifest.json").read_text(encoding="utf-8"))
    except Exception as error:
        raise BackupError("off-node backup manifest is unreadable") from error
    if manifest.get("schema") != "infuse.artifact-registry-backup/v1":
        raise BackupError("off-node backup manifest has an invalid schema")
    files = manifest.get("files")
    if not isinstance(files, list):
        raise BackupError("off-node backup manifest has no file inventory")
    total = 0
    for item in files:
        relative = item.get("path") if isinstance(item, dict) else None
        if not isinstance(relative, str) or PurePosixPath(relative).is_absolute() or ".." in PurePosixPath(relative).parts:
            raise BackupError("off-node backup contains an unsafe path")
        target = bundle / "payload" / Path(*PurePosixPath(relative).parts)
        if not target.is_file() or target.is_symlink():
            raise BackupError("off-node backup inventory is incomplete")
        body = target.read_bytes()
        if len(body) != item.get("bytes") or hashlib.sha256(body).hexdigest() != item.get("sha256"):
            raise BackupError("off-node backup file verification failed")
        total += len(body)
    if len(files) != manifest.get("fileCount") or total != manifest.get("totalBytes"):
        raise BackupError("off-node backup inventory totals do not match")
    if not SHA256.fullmatch(str(manifest.get("rootDigest", ""))):
        raise BackupError("off-node backup root digest is invalid")
    return {
        "rootDigest": manifest["rootDigest"],
        "reconciliationDigest": manifest["sourceReconciliationDigest"],
        "fileCount": manifest["fileCount"],
        "totalBytes": manifest["totalBytes"],
    }


def remote_target(value: str) -> tuple[str, str]:
    host, separator, path = value.partition(":")
    posix_path = PurePosixPath(path)
    if (
        not separator
        or not REMOTE.fullmatch(host)
        or not REMOTE_PATH.fullmatch(path)
        or path == "/"
        or ".." in posix_path.parts
    ):
        raise BackupError("off-node target must be a safe host:/absolute/path below a named directory")
    return host, path.rstrip("/")


def delete_resource(context: str, namespace: str, kind: str, name: str) -> None:
    kube(context, namespace, "delete", kind, name, "--ignore-not-found", label=f"delete {kind}/{name}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--context", default="infuseai-k8s")
    parser.add_argument("--namespace", default="core")
    parser.add_argument("--backup-id")
    parser.add_argument("--off-node-target", required=True)
    parser.add_argument("--prove-restore", action="store_true")
    parser.add_argument("--cleanup-proof-resources", action="store_true")
    parser.add_argument("--approved", action="store_true")
    args = parser.parse_args(argv)
    if not args.approved:
        raise BackupError("backup execution requires --approved and recorded owner approval")
    backup_id = args.backup_id or datetime.now(timezone.utc).strftime("registry-%Y%m%d-%H%M%S")
    if not ID.fullmatch(backup_id):
        raise BackupError("backup id must be lowercase alphanumeric/hyphen and at most 63 characters")
    resource_suffix = backup_id.removeprefix("registry-")
    if len(resource_suffix) > 37:
        raise BackupError("backup id is too long for Kubernetes recovery resource names")
    host, remote_root = remote_target(args.off_node_target)
    repo_root = Path(__file__).resolve().parents[1]
    preflight(args.context, args.namespace)
    objects = load_recovery_objects(repo_root)
    verify_recovery_network_policy(
        args.context,
        args.namespace,
        objects[("NetworkPolicy", "backoffice-artifact-registry-recovery-deny-all")],
    )

    deployment = json.loads(kube(
        args.context,
        args.namespace,
        "get",
        "deployment",
        DEPLOYMENT,
        "-o",
        "json",
        label="read Registry Deployment",
    ))
    original_replicas = int(deployment.get("spec", {}).get("replicas", 0))
    image = deployment["spec"]["template"]["spec"]["containers"][0]["image"]
    if not re.fullmatch(r"[^\s]+@sha256:[a-f0-9]{64}", image):
        raise BackupError("recovery requires the exact deployed Registry image digest")
    backup_name = f"artifact-registry-backup-{resource_suffix}"
    verify_name = f"artifact-registry-verify-{resource_suffix}"
    export_pod = f"artifact-registry-export-{resource_suffix}"
    import_pvc = f"artifact-registry-import-{resource_suffix}"
    restore_pvc = f"artifact-registry-restore-{resource_suffix}"
    import_pod = f"artifact-registry-import-{resource_suffix}"
    restore_name = f"artifact-registry-restore-{resource_suffix}"
    remote_path = f"{remote_root}/{backup_id}"
    completed = False
    registry_quiesced = False
    registry_restored = False
    safe_receipts: dict[str, Any] = {}

    try:
        kube(args.context, args.namespace, "scale", f"deployment/{DEPLOYMENT}", "--replicas=0", label="quiesce Registry")
        registry_quiesced = True
        kube(
            args.context,
            args.namespace,
            "wait",
            "--for=delete",
            "pod",
            "-l",
            f"app.kubernetes.io/name={DEPLOYMENT}",
            "--timeout=5m",
            label="wait for Registry quiescence",
        )

        apply_object(args.context, args.namespace, objects[("PersistentVolumeClaim", TRANSFER_PVC)], label="apply backup transfer PVC")
        backup_job = sanitized_job(
            objects[("Job", "backoffice-artifact-registry-backup-template")],
            name=backup_name,
            backup_id=backup_id,
            action="create",
            image=image,
        )
        apply_object(args.context, args.namespace, backup_job, label="apply backup Job")
        safe_receipts["created"] = wait_job(args.context, args.namespace, backup_name)

        verify_job = sanitized_job(
            objects[("Job", "backoffice-artifact-registry-backup-template")],
            name=verify_name,
            backup_id=backup_id,
            action="verify",
            image=image,
        )
        apply_object(args.context, args.namespace, verify_job, label="apply verify Job")
        safe_receipts["verified"] = wait_job(args.context, args.namespace, verify_name)

        export = helper_pod(
            namespace=args.namespace,
            name=export_pod,
            image=image,
            claim_name=TRANSFER_PVC,
            read_only=True,
        )
        apply_object(args.context, args.namespace, export, label="apply backup export pod")
        kube(args.context, args.namespace, "wait", "--for=condition=ready", f"pod/{export_pod}", "--timeout=5m", label="wait for export pod")

        with tempfile.TemporaryDirectory(prefix="artifact-registry-backup-") as temporary:
            local_root = Path(temporary)
            local_bundle = local_root / backup_id
            run(
                [
                    "kubectl", "--context", args.context, "-n", args.namespace,
                    "cp", f"{export_pod}:/backup/{backup_id}", str(local_bundle),
                ],
                label="export backup from Kubernetes",
            )
            local_receipt = verify_local_bundle(local_bundle)
            if local_receipt["rootDigest"] != safe_receipts["verified"]["rootDigest"]:
                raise BackupError("exported backup root digest does not match Kubernetes verification")
            run(["ssh", host, "mkdir", "-p", remote_path], label="create off-node backup directory")
            run(["rsync", "-a", "--checksum", f"{local_bundle}/", f"{host}:{remote_path}/"], label="copy backup off-node")
            drift = run(
                ["rsync", "-a", "--checksum", "--dry-run", "--itemize-changes", f"{local_bundle}/", f"{host}:{remote_path}/"],
                label="verify off-node backup copy",
            )
            if drift.strip():
                raise BackupError("off-node backup copy does not match the verified export")

            if args.prove_restore:
                import_claim = json.loads(json.dumps(objects[("PersistentVolumeClaim", TRANSFER_PVC)]))
                import_claim["metadata"]["name"] = import_pvc
                import_claim["spec"]["resources"]["requests"]["storage"] = "20Gi"
                restore_claim = json.loads(json.dumps(objects[("PersistentVolumeClaim", "backoffice-artifact-registry-restore-target")]))
                restore_claim["metadata"]["name"] = restore_pvc
                apply_object(args.context, args.namespace, import_claim, label="apply restore import PVC")
                apply_object(args.context, args.namespace, restore_claim, label="apply isolated restore PVC")
                importer = helper_pod(
                    namespace=args.namespace,
                    name=import_pod,
                    image=image,
                    claim_name=import_pvc,
                    read_only=False,
                )
                apply_object(args.context, args.namespace, importer, label="apply backup import pod")
                kube(args.context, args.namespace, "wait", "--for=condition=ready", f"pod/{import_pod}", "--timeout=5m", label="wait for import pod")
                run(
                    [
                        "kubectl", "--context", args.context, "-n", args.namespace,
                        "cp", str(local_bundle), f"{import_pod}:/backup/{backup_id}",
                    ],
                    label="import off-node backup for restore proof",
                )
                restore_template = json.loads(json.dumps(objects[("Job", "backoffice-artifact-registry-restore-template")]))
                restore_template["spec"]["template"]["spec"]["volumes"][0]["persistentVolumeClaim"]["claimName"] = import_pvc
                restore_template["spec"]["template"]["spec"]["volumes"][1]["persistentVolumeClaim"]["claimName"] = restore_pvc
                restore_job = sanitized_job(
                    restore_template,
                    name=restore_name,
                    backup_id=backup_id,
                    action="restore",
                    image=image,
                )
                apply_object(args.context, args.namespace, restore_job, label="apply isolated restore Job")
                safe_receipts["restored"] = wait_job(args.context, args.namespace, restore_name)
                if safe_receipts["restored"]["rootDigest"] != local_receipt["rootDigest"]:
                    raise BackupError("isolated restore root digest does not match off-node backup")

        if original_replicas > 0:
            kube(args.context, args.namespace, "scale", f"deployment/{DEPLOYMENT}", f"--replicas={original_replicas}", label="restore Registry replicas")
            kube(
                args.context,
                args.namespace,
                "rollout",
                "status",
                f"deployment/{DEPLOYMENT}",
                "--timeout=10m",
                label="wait for Registry readiness",
            )
        registry_restored = True
        completed = True

        if args.cleanup_proof_resources:
            for kind, name in (
                ("pod", export_pod),
                ("pod", import_pod),
                ("job", backup_name),
                ("job", verify_name),
                ("job", restore_name),
                ("pvc", TRANSFER_PVC),
                ("pvc", import_pvc),
                ("pvc", restore_pvc),
            ):
                delete_resource(args.context, args.namespace, kind, name)

        print(json.dumps({
            "status": "accepted",
            "backupId": backup_id,
            "offNodeTarget": f"{host}:{remote_path}",
            "restoreProved": args.prove_restore,
            "receipts": safe_receipts,
            "cleanupCompleted": args.cleanup_proof_resources,
        }, sort_keys=True))
        return 0
    finally:
        if registry_quiesced and not registry_restored and original_replicas > 0:
            try:
                kube(
                    args.context,
                    args.namespace,
                    "scale",
                    f"deployment/{DEPLOYMENT}",
                    f"--replicas={original_replicas}",
                    label="restore Registry replicas after failed backup",
                )
                kube(
                    args.context,
                    args.namespace,
                    "rollout",
                    "status",
                    f"deployment/{DEPLOYMENT}",
                    "--timeout=10m",
                    label="wait for Registry recovery after failed backup",
                )
                registry_restored = True
            except BackupError:
                print(
                    "critical: Registry replicas could not be restored automatically; manual recovery is required",
                    file=sys.stderr,
                )
        if not completed:
            print(
                "backup did not complete; recovery resources are preserved for diagnosis",
                file=sys.stderr,
            )


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BackupError as error:
        print(f"artifact registry backup failed safely: {error}", file=sys.stderr)
        raise SystemExit(2)
