#!/usr/bin/env bash
set -euo pipefail

repo_url="${OPENCLAW_PERSONA_REPO:-https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-persona.git}"
branch="${OPENCLAW_PERSONA_BRANCH:-main}"
target="${OPENCLAW_PERSONA_SOURCE_PATH:-${OPENCLAW_WORKSPACE:-/workspace}/openclaw-agents-persona}"
required="${OPENCLAW_PERSONA_REQUIRED:-false}"
template_rel="${OPENCLAW_PERSONA_TEMPLATE_REL:-templates/agent-persona}"

warn_or_fail() {
  local message="$1"
  if [[ "$required" == "true" ]]; then
    echo "ERROR: $message" >&2
    exit 1
  fi
  echo "WARNING: $message" >&2
  exit 0
}

if ! command -v git >/dev/null 2>&1; then
  warn_or_fail "persona sync requested but git is not installed"
fi

mkdir -p "$(dirname "$target")"

if [[ -d "$target/.git" ]]; then
  current_branch="$(git -C "$target" rev-parse --abbrev-ref HEAD 2>/dev/null || true)"
  if [[ "$current_branch" != "$branch" ]]; then
    warn_or_fail "persona checkout at $target is on $current_branch, expected $branch"
  fi
  if [[ -n "$(git -C "$target" status --porcelain 2>/dev/null)" ]]; then
    warn_or_fail "persona checkout at $target has local changes"
  fi
  origin_url="$(git -C "$target" remote get-url origin)"
  if [[ "$origin_url" == "https://dev.azure.com/infuse-ai/Infuse%20AI/_git/openclaw-agents-persona" && "$repo_url" == "https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-persona.git" ]]; then
    git -C "$target" remote set-url origin "$repo_url"
  elif [[ "$origin_url" != "$repo_url" ]]; then
    warn_or_fail "checkout origin differs from the reviewed source; reconcile before sync"
  fi
  if ! git -C "$target" fetch origin "$branch" >/dev/null; then
    warn_or_fail "failed to fetch persona branch $branch"
  fi
  if ! git -C "$target" merge --ff-only "origin/$branch" >/dev/null; then
    warn_or_fail "failed to fast-forward persona checkout at $target"
  fi
else
  if [[ -e "$target" ]]; then
    warn_or_fail "persona target exists but is not a git checkout: $target"
  fi
  if ! git clone --branch "$branch" --single-branch "$repo_url" "$target" >/dev/null; then
    warn_or_fail "failed to clone persona repo into $target"
  fi
fi

git config --global --add safe.directory "$target" >/dev/null 2>&1 || true

if [[ ! -d "$target/$template_rel" ]]; then
  warn_or_fail "persona checkout is missing $template_rel"
fi

if [[ -x "$target/scripts/validate_persona.py" ]]; then
  if ! "$target/scripts/validate_persona.py" >/dev/null; then
    warn_or_fail "persona validation failed"
  fi
fi

echo "Agent persona source ready at $target"
