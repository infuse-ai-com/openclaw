#!/usr/bin/env bash
set -euo pipefail

# Maintainer: team:agent-platform (Satwa). Recheck upstream security releases
# weekly and retire this private package when supported Debian ships the fix.
version="${OPENSSH_VERSION:?}"
checksum="${OPENSSH_SOURCE_SHA256:?}"
[[ "$version" == 10.6p2 ]]
[[ "$checksum" =~ ^[a-f0-9]{64}$ ]]
workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
cd "$workdir"
curl --fail --location --silent --show-error \
  "https://cdn.openbsd.org/pub/OpenBSD/OpenSSH/portable/openssh-${version}.tar.gz" -o source.tgz
printf '%s  source.tgz\n' "$checksum" | sha256sum --check -
tar -xzf source.tgz
cd "openssh-$version"
./configure --prefix=/usr --sysconfdir=/etc/ssh --libexecdir=/usr/lib/openssh \
  --with-privsep-user=nobody --with-privsep-path=/var/empty \
  --with-kerberos5 --with-security-key-builtin
make -j2
mkdir -p /var/empty
chmod 0755 /var/empty
# Upstream fixtures use isolated local/proxy servers and synthetic keys. The
# server and fixture keys are build-only; neither ships in the runtime package.
timeout 600 make t-exec LTESTS='connect proxy-connect keyscan hostkey-rotate scp sftp'
timeout 300 make unit

package="$workdir/package"
mkdir -p "$package"/{DEBIAN,usr/bin,usr/lib/openssh,etc/ssh/ssh_config.d,usr/share/doc/openssh-client,usr/share/agent-openssh-build-info} /out
for binary in ssh scp sftp ssh-add ssh-agent ssh-keygen ssh-keyscan; do
  install -m 0755 "$binary" "$package/usr/bin/$binary"
done
install -m 0755 contrib/ssh-copy-id "$package/usr/bin/ssh-copy-id"
for helper in ssh-pkcs11-helper ssh-sk-helper; do
  install -m 0755 "$helper" "$package/usr/lib/openssh/$helper"
done
install -m 0644 LICENCE "$package/usr/share/doc/openssh-client/copyright"
cat > "$package/etc/ssh/ssh_config" <<'CONFIG'
Include /etc/ssh/ssh_config.d/*.conf
Host *
    HashKnownHosts yes
    SendEnv LANG LC_*
    GSSAPIAuthentication yes
CONFIG
printf '/etc/ssh/ssh_config\n' > "$package/DEBIAN/conffiles"
cat > "$package/DEBIAN/control" <<CONTROL
Package: openssh-client
Version: 1:${version}-0infuse1
Source: openssh (1:${version}-0infuse1)
Architecture: $(dpkg --print-architecture)
Maintainer: Infuse AI Agent Platform <kapiteky@infuse-ai.com>
Depends: libc6, libssl3t64, zlib1g, libgssapi-krb5-2, libfido2-1
Section: net
Priority: optional
Homepage: https://www.openssh.com/
Description: Maintained upstream OpenSSH client built for the Infuse Trixie runtime
 Client-only security backport with upstream regression and unit tests.
 No SSH server, host keys or setuid helper is installed.
CONTROL
cat > "$package/usr/share/agent-openssh-build-info/source.json" <<RECEIPT
{"version":"$version","sourceUrl":"https://cdn.openbsd.org/pub/OpenBSD/OpenSSH/portable/openssh-$version.tar.gz","sourceSha256":"$checksum","owner":"team:agent-platform","upstreamTests":["connect","proxy-connect","keyscan","hostkey-rotate","scp","sftp","unit"],"serverInstalled":false}
RECEIPT
find "$package" -type f -perm /6000 -print -quit | grep -q . && exit 1
dpkg-deb --root-owner-group --build "$package" /out/openssh-client.deb
printf 'Maintained client package built; no server or setuid binaries installed.\n'
