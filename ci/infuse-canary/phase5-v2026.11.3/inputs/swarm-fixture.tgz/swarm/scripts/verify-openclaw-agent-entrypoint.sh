#!/usr/bin/env bash
set -euo pipefail

tmp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT
mkdir -p "$tmp_dir/home"
mkdir -p "$tmp_dir/bin" "$tmp_dir/bw-mock-state" "$tmp_dir/playwright-seed/chromium-verify" "$tmp_dir/playwright-seed/.links"
printf 'seeded-browser\n' >"$tmp_dir/playwright-seed/chromium-verify/browser"
printf '/opt/image-package\n' >"$tmp_dir/playwright-seed/.links/image-package"

cat >"$tmp_dir/bin/bw" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

state_dir="${BW_MOCK_STATE:?Set BW_MOCK_STATE}"
log_file="${BW_MOCK_LOG:?Set BW_MOCK_LOG}"
printf '%s\n' "$*" >>"$log_file"

case "${1:-}" in
  config)
    [[ "${2:-}" == "server" ]]
    printf '%s' "${3:-}" >"$state_dir/server"
    ;;
  status)
    if [[ ! -f "$state_dir/logged-in" ]]; then
      printf '{"status":"unauthenticated"}\n'
    elif [[ -n "${BW_SESSION:-}" ]]; then
      printf '{"status":"unlocked"}\n'
    else
      printf '{"status":"locked"}\n'
    fi
    ;;
  login)
    [[ "${2:-}" == "--apikey" ]]
    [[ -n "${BW_CLIENTID:-}" && -n "${BW_CLIENTSECRET:-}" ]]
    : >"$state_dir/logged-in"
    ;;
  unlock)
    [[ "${2:-}" == "--passwordenv" ]]
    password_env="${3:-}"
    [[ -n "$password_env" && -n "${!password_env:-}" ]]
    printf 'mock-session-token'
    ;;
  sync)
    [[ -n "${BW_SESSION:-}" ]]
    : >"$state_dir/synced"
    ;;
  *)
    echo "Unexpected bw mock command: $*" >&2
    exit 2
    ;;
esac
EOF
chmod 700 "$tmp_dir/bin/bw"

env -i \
  PATH="$tmp_dir/bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_WORKSPACE="$tmp_dir/workspace" \
  OPENCLAW_PLAYWRIGHT_CACHE_HELPER="$PWD/scripts/ensure-playwright-browser-cache.sh" \
  OPENCLAW_PLAYWRIGHT_SEED_PATH="$tmp_dir/playwright-seed" \
  PLAYWRIGHT_BROWSERS_PATH="$tmp_dir/workspace/.cache/ms-playwright" \
  OPENCLAW_AUTO_INSTALL_PERSONA=false \
  OPENCLAW_BW_SERVER="https://vault.infuse-ai-tech.party" \
  OPENCLAW_BW_DATA="$tmp_dir/home/.config/Bitwarden CLI" \
  OPENCLAW_BW_PROFILE_MIGRATION_HELPER="$PWD/scripts/migrate-bitwarden-cli-profile.py" \
  OPENCLAW_BW_PREWARM_REQUIRED=true \
  BW_CLIENTID="placeholder-client-id" \
  BW_CLIENTSECRET="placeholder-client-secret" \
  BW_PASSWORD="placeholder-unlock-password" \
  BW_MOCK_STATE="$tmp_dir/bw-mock-state" \
  BW_MOCK_LOG="$tmp_dir/bw-mock.log" \
  AGENT_ID="agent-verify" \
  AGENT_NAME="Verify Agent" \
  bash images/openclaw-agent/entrypoint.sh true

test ! -e "$tmp_dir/home/.git-credential-dev-azure.sh"
if HOME="$tmp_dir/home" git config --global credential.https://dev.azure.com.helper >/dev/null; then
  echo "Legacy credential helper must remain retired" >&2
  exit 1
fi
HOME="$tmp_dir/home" git config --global user.name | grep -Fx "Verify Agent" >/dev/null
HOME="$tmp_dir/home" git config --global user.email | grep -Fx "verify.agent@infuse-ai.com" >/dev/null

test -f "$tmp_dir/workspace/.openclaw-runtime-info"
test -f "$tmp_dir/workspace/.cache/ms-playwright/chromium-verify/browser"
test -L "$tmp_dir/workspace/.cache/ms-playwright/chromium-verify"
playwright_seed_target="$(cd "$tmp_dir/playwright-seed" && pwd -P)/chromium-verify"
test "$(readlink "$tmp_dir/workspace/.cache/ms-playwright/chromium-verify")" = "$playwright_seed_target"
grep -Fx '/opt/image-package' "$tmp_dir/workspace/.cache/ms-playwright/.links/image-package" >/dev/null
test -x scripts/ensure-openclaw-runtime-plugins.sh
grep -F 'OPENCLAW_RUNTIME_VERSION=${OPENCLAW_VERSION}' images/openclaw-agent/Dockerfile >/dev/null
grep -F '@openclaw/codex@${runtime_version} @openclaw/mattermost@${runtime_version}' scripts/ensure-openclaw-runtime-plugins.sh >/dev/null
mkdir -p "$tmp_dir/plugin-bin" "$tmp_dir/plugin-state"
cat >"$tmp_dir/plugin-bin/openclaw" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == "--version" ]]; then
  printf 'OpenClaw mock\n'
  exit 0
fi
printf '%s\n' "$*" >>"${OPENCLAW_PLUGIN_MOCK_LOG:?Set OPENCLAW_PLUGIN_MOCK_LOG}"
EOF
chmod 700 "$tmp_dir/plugin-bin/openclaw"
mkdir -p \
  "$tmp_dir/plugin-state/extensions/.openclaw-install-stage-AbC123" \
  "$tmp_dir/plugin-state/extensions/.openclaw-install-stage-invalid_name" \
  "$tmp_dir/plugin-state/extensions/behavioral-observability"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.7.2-beta.7" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
test ! -e "$tmp_dir/plugin-state/extensions/.openclaw-install-stage-AbC123"
test -d "$tmp_dir/plugin-state/extensions/.openclaw-install-stage-invalid_name"
test -d "$tmp_dir/plugin-state/extensions/behavioral-observability"
grep -Fx -- '--profile agent-verify plugins install --force @openclaw/codex@2026.7.2-beta.7' "$tmp_dir/plugin-install.log" >/dev/null
grep -Fx -- '--profile agent-verify plugins install --force @openclaw/mattermost@2026.7.2-beta.7' "$tmp_dir/plugin-install.log" >/dev/null
test "$(wc -l <"$tmp_dir/plugin-install.log" | tr -d ' ')" = "2"
rm -rf "$tmp_dir/plugin-state"
: >"$tmp_dir/plugin-install.log"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.9.4" \
  OPENCLAW_REQUIRED_PLUGINS="" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
test ! -s "$tmp_dir/plugin-install.log"
test -f "$tmp_dir/plugin-state/.openclaw-runtime/plugins.fingerprint"
rm -rf "$tmp_dir/plugin-state"
: >"$tmp_dir/plugin-install.log"
mkdir -p "$tmp_dir/plugin-migration-bin" "$tmp_dir/plugin-state"
cat >"$tmp_dir/plugin-migration-bin/openclaw" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == "--version" ]]; then
  printf 'OpenClaw 2026.11.3 mock\n'
  exit 0
fi
printf '%s\n' "$*" >>"${OPENCLAW_PLUGIN_MOCK_LOG:?Set OPENCLAW_PLUGIN_MOCK_LOG}"
if [[ "$*" == *"plugins inspect codex --runtime --json"* ]]; then
  if [[ -f "${OPENCLAW_PLUGIN_MIGRATED:?Set OPENCLAW_PLUGIN_MIGRATED}" ]]; then
    printf '%s\n' '{"plugin":{"status":"loaded","origin":"bundled"},"install":null}'
  else
    printf '%s\n' '{"plugin":{"status":"loaded","origin":"global"},"install":{"source":"npm"}}'
  fi
elif [[ "$*" == *"plugins uninstall codex --force"* ]]; then
  : >"$OPENCLAW_PLUGIN_MIGRATED"
  printf '%s' '{"mutated":true}' >"${OPENCLAW_CONFIG_PATH:?Set OPENCLAW_CONFIG_PATH}"
fi
EOF
chmod 700 "$tmp_dir/plugin-migration-bin/openclaw"
migration_config='{"plugins":{"allow":["codex"],"entries":{"codex":{"enabled":true}}}}'
printf '%s' "$migration_config" >"$tmp_dir/plugin-state/openclaw.json"
PATH="$tmp_dir/plugin-migration-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_CONFIG_PATH="$tmp_dir/plugin-state/openclaw.json" \
  OPENCLAW_RUNTIME_VERSION="2026.11.3" \
  OPENCLAW_REQUIRED_PLUGINS="" \
  OPENCLAW_BUNDLED_PLUGIN_MIGRATIONS="codex" \
  OPENCLAW_PLUGIN_MIGRATED="$tmp_dir/plugin-migrated" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
grep -Fx -- '--profile agent-verify plugins uninstall codex --force' "$tmp_dir/plugin-install.log" >/dev/null
test "$(cat "$tmp_dir/plugin-state/openclaw.json")" = "$migration_config"
rm -rf "$tmp_dir/plugin-state" "$tmp_dir/plugin-migrated"
: >"$tmp_dir/plugin-install.log"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.9.4" \
  OPENCLAW_REQUIRED_PLUGINS="@openclaw/codex@2026.9.4 @openclaw/diagnostics-otel@2026.9.4" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
grep -Fx -- '--profile agent-verify plugins install --force @openclaw/codex@2026.9.4' "$tmp_dir/plugin-install.log" >/dev/null
grep -Fx -- '--profile agent-verify plugins install --force @openclaw/diagnostics-otel@2026.9.4' "$tmp_dir/plugin-install.log" >/dev/null
test "$(wc -l <"$tmp_dir/plugin-install.log" | tr -d ' ')" = "2"
rm -rf "$tmp_dir/plugin-state"
: >"$tmp_dir/plugin-install.log"
mkdir -p "$tmp_dir/local-observability-plugin"
printf '%s\n' '{"version":1}' >"$tmp_dir/local-observability-plugin/package.json"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.9.4" \
  OPENCLAW_REQUIRED_PLUGINS="$tmp_dir/local-observability-plugin" \
  OPENCLAW_CAPABILITY_CONSENT_PLUGINS="$tmp_dir/local-observability-plugin" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
grep -Fx -- "--profile agent-verify plugins install --force --accept-capabilities $tmp_dir/local-observability-plugin" "$tmp_dir/plugin-install.log" >/dev/null
: >"$tmp_dir/plugin-install.log"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.9.4" \
  OPENCLAW_REQUIRED_PLUGINS="$tmp_dir/local-observability-plugin" \
  OPENCLAW_CAPABILITY_CONSENT_PLUGINS="$tmp_dir/local-observability-plugin" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
test ! -s "$tmp_dir/plugin-install.log"
printf '%s\n' '{"version":2}' >"$tmp_dir/local-observability-plugin/package.json"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.9.4" \
  OPENCLAW_REQUIRED_PLUGINS="$tmp_dir/local-observability-plugin" \
  OPENCLAW_CAPABILITY_CONSENT_PLUGINS="$tmp_dir/local-observability-plugin" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
grep -Fx -- "--profile agent-verify plugins install --force --accept-capabilities $tmp_dir/local-observability-plugin" "$tmp_dir/plugin-install.log" >/dev/null
rm -rf "$tmp_dir/plugin-state"
: >"$tmp_dir/plugin-install.log"
printf '%s\n' 'archive-version-1' >"$tmp_dir/local-observability-plugin.tgz"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.11.3" \
  OPENCLAW_REQUIRED_PLUGINS="$tmp_dir/local-observability-plugin.tgz" \
  OPENCLAW_CAPABILITY_CONSENT_PLUGINS="$tmp_dir/local-observability-plugin.tgz" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
grep -Fx -- "--profile agent-verify plugins install --force --accept-capabilities $tmp_dir/local-observability-plugin.tgz" "$tmp_dir/plugin-install.log" >/dev/null
: >"$tmp_dir/plugin-install.log"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.11.3" \
  OPENCLAW_REQUIRED_PLUGINS="$tmp_dir/local-observability-plugin.tgz" \
  OPENCLAW_CAPABILITY_CONSENT_PLUGINS="$tmp_dir/local-observability-plugin.tgz" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
test ! -s "$tmp_dir/plugin-install.log"
printf '%s\n' 'archive-version-2' >"$tmp_dir/local-observability-plugin.tgz"
PATH="$tmp_dir/plugin-bin:$PATH" \
  HOME="$tmp_dir/home" \
  OPENCLAW_STATE_DIR="$tmp_dir/plugin-state" \
  OPENCLAW_RUNTIME_VERSION="2026.11.3" \
  OPENCLAW_REQUIRED_PLUGINS="$tmp_dir/local-observability-plugin.tgz" \
  OPENCLAW_CAPABILITY_CONSENT_PLUGINS="$tmp_dir/local-observability-plugin.tgz" \
  OPENCLAW_PLUGIN_MOCK_LOG="$tmp_dir/plugin-install.log" \
  scripts/ensure-openclaw-runtime-plugins.sh agent-verify >/dev/null
grep -Fx -- "--profile agent-verify plugins install --force --accept-capabilities $tmp_dir/local-observability-plugin.tgz" "$tmp_dir/plugin-install.log" >/dev/null
test -f "$tmp_dir/bw-mock-state/synced"
test -f "$tmp_dir/home/.config/Bitwarden CLI/session"
grep -Fx "mock-session-token" "$tmp_dir/home/.config/Bitwarden CLI/session" >/dev/null
session_mode="$(stat -c '%a' "$tmp_dir/home/.config/Bitwarden CLI/session" 2>/dev/null || stat -f '%Lp' "$tmp_dir/home/.config/Bitwarden CLI/session")"
test "$session_mode" = "600"
grep -Fx "config server https://vault.infuse-ai-tech.party" "$tmp_dir/bw-mock.log" >/dev/null
grep -Fx "login --apikey" "$tmp_dir/bw-mock.log" >/dev/null
grep -Fx "unlock --passwordenv BW_PASSWORD --raw" "$tmp_dir/bw-mock.log" >/dev/null
grep -Fx "sync" "$tmp_dir/bw-mock.log" >/dev/null

bash -n images/openclaw-agent/bw
bash -n scripts/boot-agent-developer-canary.sh
bash -n scripts/deploy-mattermost-canary-fleet.sh
node --check images/openclaw-agent/bw-force-identity-fetch.js >/dev/null
test -x images/openclaw-agent/bw
grep -F 'bw-force-identity-fetch.js' images/openclaw-agent/bw >/dev/null
grep -F '/usr/local/lib/node_modules/@bitwarden/cli/build/bw.js' images/openclaw-agent/bw >/dev/null
grep -F 'accept-encoding", "identity"' images/openclaw-agent/bw-force-identity-fetch.js >/dev/null
grep -F 'FROM node:24.21.0-trixie-slim@sha256:' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'golang:1.27.4-bookworm@sha256:' images/openclaw-agent/Dockerfile >/dev/null
grep -F '/usr/bin/python3 -m venv /opt/agent-python-toolbox' images/openclaw-agent/Dockerfile >/dev/null
grep -F '/opt/agent-python-toolbox/bin/python -m pip install --no-cache-dir --require-hashes' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'requirements-toolbox.lock' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'ARG OPENCLAW_VERSION=2026.11.3' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'ARG CODEX_CLI_VERSION=0.160.0' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'openclaw-2026.11.3-e7d74d56a5.tgz' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'npm ci --omit=dev --no-audit --no-fund' images/openclaw-agent/Dockerfile >/dev/null
grep -F '@openai/codex@${CODEX_CLI_VERSION}' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'plugins install --force --accept-capabilities /opt/openclaw-plugin-archives/behavioral-observability.tgz' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'acpx@${ACPX_CLI_VERSION}' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'for plugin in codex mattermost acpx diagnostics-otel' images/openclaw-agent/Dockerfile >/dev/null
grep -F '.plugin.origin == "bundled"' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'verify-canary-package-metadata.mjs' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'verify-studio-plugin-package.py' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'openclaw-agent-developer-canary-boot' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'OPENCLAW_BOOT_SCRIPT' images/openclaw-agent/entrypoint.sh >/dev/null
grep -F 'bootstrap_config=' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'unset OPENCLAW_CONFIG_JSON' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.agents.entries |= with_entries(.value |= del(.default))' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.messages.inbound.byChannel.mattermost = 1500' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.surfaces.mattermost.silentReply.group = "allow"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.channels.mattermost.textChunkLimit = 12000' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.channels.mattermost.actions.reactions = true' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.plugins.entries.codex.config.appServer.command = "/usr/local/bin/codex"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'label: "Thinking… please wait"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'commandText: "raw"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'openclaw-2026.11.3-bundled-plugins-v1' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'retry_check "Codex runtime verification"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.plugin.origin == "bundled"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'plugins uninstall "$plugin" --force' scripts/ensure-openclaw-runtime-plugins.sh >/dev/null
grep -F 'retry_check "exact bundled Mattermost runtime verification"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'retry_check "exact bundled ACPX runtime verification"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'retry_check "exact bundled diagnostics-otel runtime verification"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'retry_check "model credential status"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'doctor --fix --non-interactive --yes' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'OPENCLAW_DOCTOR_REPAIR_MODE' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'name: OPENCLAW_DOCTOR_REPAIR_MODE' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F 'doctor-2026.9.7-agent-schema-v24-v1' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'doctor-2026.11.3-agent-schema-v27-v1' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'retry_check "agent database schema v27" verify_agent_database_schema_v27' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'value: automatic' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F 'sessions --agent "$agent_id" --limit 1 --json' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'openclaw-agent-repair-legacy-invalid-session-rows' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'openclaw-agent-migrate-schema-v27' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'migrate-openclaw-agent-schema-v27.mjs /usr/local/bin/openclaw-agent-migrate-schema-v27' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'openclaw-2026.11.3-bundled-plugins-v1' scripts/smoke-agent-runtime.sh >/dev/null
grep -F '.plugin.origin == \"bundled\"' scripts/smoke-agent-runtime.sh >/dev/null
grep -F 'repair-legacy-invalid-session-rows.mjs /usr/local/bin/openclaw-agent-repair-legacy-invalid-session-rows' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'openclaw_gateway_lifecycle.py /usr/local/bin/openclaw-gateway-lifecycle' images/openclaw-agent/Dockerfile >/dev/null

session_repair_root="$tmp_dir/session-repair-state"
session_repair_agent="agent-verify"
session_repair_db="$session_repair_root/agents/$session_repair_agent/agent/openclaw-agent.sqlite"
mkdir -p "$(dirname "$session_repair_db")"
SESSION_REPAIR_DB="$session_repair_db" node --no-warnings - <<'NODE'
const { DatabaseSync } = require("node:sqlite");
const db = new DatabaseSync(process.env.SESSION_REPAIR_DB);
db.exec(`
  CREATE TABLE session_nodes (
    session_key TEXT PRIMARY KEY,
    current_session_id TEXT NOT NULL,
    entry_json TEXT NOT NULL,
    updated_at INTEGER NOT NULL,
    entry_valid INTEGER NOT NULL
  ) STRICT;
  CREATE TABLE session_windows (
    session_id TEXT NOT NULL,
    session_key TEXT NOT NULL,
    PRIMARY KEY (session_id)
  ) STRICT;
  INSERT INTO session_nodes VALUES (
    'agent:agent-verify:mattermost:default:direct:user',
    'session-verify',
    '{}',
    1234,
    -1
  );
  INSERT INTO session_nodes VALUES (
    'agent:agent-verify:cron:retained:run:history',
    'session-retained',
    '{}',
    5678,
    -1
  );
  INSERT INTO session_windows VALUES (
    'session-retained',
    'agent:agent-verify:cron:retained:run:history'
  );
`);
NODE
OPENCLAW_STATE_DIR="$session_repair_root" node --no-warnings \
  scripts/repair-legacy-invalid-session-rows.mjs "$session_repair_agent" >/dev/null
SESSION_REPAIR_DB="$session_repair_db" node --no-warnings - <<'NODE'
const fs = require("node:fs");
const { DatabaseSync } = require("node:sqlite");
const dbPath = process.env.SESSION_REPAIR_DB;
const db = new DatabaseSync(dbPath, { readOnly: true });
const repaired = db
  .prepare("SELECT entry_json, entry_valid FROM session_nodes WHERE session_key = ?")
  .get("agent:agent-verify:mattermost:default:direct:user");
if (repaired.entry_valid !== 1) {
  throw new Error("guarded session repair did not validate the orphan row");
}
const entry = JSON.parse(repaired.entry_json);
if (entry.sessionId !== "session-verify" || entry.updatedAt !== 1234) {
  throw new Error("guarded session repair wrote an unexpected canonical entry");
}
const retained = db
  .prepare("SELECT entry_json, entry_valid FROM session_nodes WHERE session_key = ?")
  .get("agent:agent-verify:cron:retained:run:history");
if (retained.entry_valid !== -1 || retained.entry_json !== "{}") {
  throw new Error("guarded session repair modified a retained-history tombstone");
}
if (!fs.existsSync(`${dbPath}.backup-before-2026.8.1-invalid-row-repair`)) {
  throw new Error("guarded session repair did not preserve a backup");
}
NODE
OPENCLAW_STATE_DIR="$session_repair_root" node --no-warnings \
  scripts/repair-legacy-invalid-session-rows.mjs "$session_repair_agent" >/dev/null
grep -F 'endswith("/openclaw-agent.sqlite")' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F '.surfaces.mattermost.replyCompletion.group = "message-or-reaction"' scripts/boot-agent-developer-canary.sh >/dev/null
grep -F 'finalDelivery: "separate"' scripts/boot-agent-developer-canary.sh >/dev/null
if grep -F '.plugin.origin == "global"' images/openclaw-agent/Dockerfile >/dev/null; then
  echo 'Core plugins must not be qualified as global installs' >&2
  exit 1
fi
grep -F '(.plugin.agentHarnessIds | index("codex")) != null' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'gitlab-candidate-[0-9a-f]{40}' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'exact_image_ref="$image_ref@$digest"' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'source_revision="${image_ref##*:gitlab-candidate-}"' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F '.spec.template.metadata.annotations["openclaw.infuse-ai.com/swarm-source-revision"] = $source_revision' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F '.spec.template.metadata.annotations["openclaw.infuse-ai.com/version"] = "2026.11.3"' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'EXPECTED_IMAGE_REF="$exact_image_ref"' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'peer_agents=(agent-designer agent-infra agent-intake agent-coordinator)' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'mode="${3:---canary}"' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F -- '--agent=*)' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'Single-agent mode requires one of:' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'startswith($image_repository + ":")' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F '"$script_dir/rollout-persistent-agent.sh"' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'OPENCLAW_ROLLOUT_MODE="${OPENCLAW_ROLLOUT_MODE:-bounded}"' scripts/deploy-mattermost-canary-fleet.sh >/dev/null
grep -F 'OPENCLAW_POD_DELETION_SLO_SECONDS' scripts/rollout-persistent-agent.sh >/dev/null
grep -F -- '--arm-handoff' scripts/rollout-persistent-agent.sh >/dev/null
grep -F 'preserve_deployments_csv="${PRESERVE_DEPLOYMENTS-}"' scripts/deploy-infuseai-agents.sh >/dev/null
grep -F 'deployments=(agent-developer agent-designer agent-infra agent-intake agent-coordinator)' scripts/deploy-infuseai-agents.sh >/dev/null
grep -F '"$script_dir/rollout-persistent-agent-fleet.sh"' scripts/deploy-infuseai-agents.sh >/dev/null
grep -F '"$script_dir/rollout-and-verify-persistent-agent.sh"' scripts/deploy-infuseai-agents.sh >/dev/null
grep -F 'OPENCLAW_FLEET_ROLLOUT_STRATEGY="${OPENCLAW_FLEET_ROLLOUT_STRATEGY:-canary-wave}"' scripts/deploy-infuseai-agents.sh >/dev/null
grep -F 'leaf_wave=(agent-designer agent-infra agent-intake)' scripts/rollout-persistent-agent-fleet.sh >/dev/null
grep -F 'rollout_agent agent-developer' scripts/rollout-persistent-agent-fleet.sh >/dev/null
grep -F 'rollout_agent agent-coordinator' scripts/rollout-persistent-agent-fleet.sh >/dev/null
grep -F 'fsGroupChangePolicy: OnRootMismatch' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F 'stat -c '\''%u:%g'\'' /workspace' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F -- '--mode shared' scripts/deploy-infuseai-agents.sh >/dev/null
grep -F 'type: Recreate' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F 'terminationGracePeriodSeconds: 420' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F '/usr/local/bin/openclaw-gateway-lifecycle' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F 'path: /readyz' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F 'path: /healthz' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F 'startupProbe:' k8s/components/persistent-agent/deployment.yaml >/dev/null
grep -F "OPENCLAW_VERSION: '{{default \"2026.11.3\" .OPENCLAW_VERSION}}'" Taskfile.yml >/dev/null
grep -F "CODEX_CLI_VERSION: '{{default \"0.160.0\" .CODEX_CLI_VERSION}}'" Taskfile.yml >/dev/null
grep -F "ACPX_CLI_VERSION: '{{default \"0.19.1\" .ACPX_CLI_VERSION}}'" Taskfile.yml >/dev/null
grep -F 'e7d74d56a583e7596977058e7f73c6dc7c959810' Taskfile.yml >/dev/null
grep -F 'd2ac347e1bab31316b231f42d3ad1c5aac884f92792a351544432582c069cd22' Taskfile.yml >/dev/null
grep -F '4bd517b31954039c8e3ac5cf00f89b9908ad38ee1da4c46f64fa151f97102ca7' Taskfile.yml >/dev/null
grep -F 'openclaw.infuse-ai.com/swarm-source-revision' scripts/render-infuseai-agents.sh >/dev/null
grep -F -- '--build-arg OPENCLAW_PACKAGE_URL={{.OPENCLAW_PACKAGE_URL}}' Taskfile.yml >/dev/null
grep -F -- '--build-arg CODEX_CLI_VERSION={{.CODEX_CLI_VERSION}}' Taskfile.yml >/dev/null
grep -F -- '--build-arg OPENCLAW_CANDIDATE_MANIFEST_SHA256={{.OPENCLAW_CANDIDATE_MANIFEST_SHA256}}' Taskfile.yml >/dev/null
grep -F 'ARG BITWARDEN_CLI_VERSION=2026.10.0' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'ARG GLAB_VERSION=1.128.0' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'glab_${GLAB_VERSION}_linux_${arch}.tar.gz' images/openclaw-agent/Dockerfile >/dev/null
grep -F '@bitwarden/cli@${BITWARDEN_CLI_VERSION}' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'COPY scripts/migrate-bitwarden-cli-profile.py /usr/local/bin/openclaw-agent-migrate-bitwarden-profile' images/openclaw-agent/Dockerfile >/dev/null
grep -F 'if [[ "$status" == "locked" ]]; then' images/openclaw-agent/entrypoint.sh >/dev/null
if grep -F 'if [[ "$status" == "locked" && -z "${BW_SESSION:-}" ]]; then' images/openclaw-agent/entrypoint.sh >/dev/null; then
  echo 'stale Bitwarden sessions must not prevent password re-unlock' >&2
  exit 1
fi
grep -F "BITWARDEN_CLI_VERSION: '{{default \"2026.10.0\" .BITWARDEN_CLI_VERSION}}'" Taskfile.yml >/dev/null
grep -F "GLAB_VERSION: '{{default \"1.128.0\" .GLAB_VERSION}}'" Taskfile.yml >/dev/null

echo "Verified OpenClaw agent entrypoint startup setup."
