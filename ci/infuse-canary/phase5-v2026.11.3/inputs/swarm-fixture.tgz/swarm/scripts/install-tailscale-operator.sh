#!/usr/bin/env bash
set -euo pipefail

namespace="${TAILSCALE_OPERATOR_NAMESPACE:-tailscale}"
release="${TAILSCALE_OPERATOR_RELEASE:-tailscale-operator}"

if [[ -z "${TS_OAUTH_CLIENT_ID:-}" || -z "${TS_OAUTH_CLIENT_SECRET:-}" ]]; then
  cat >&2 <<'EOF'
ERROR: TS_OAUTH_CLIENT_ID and TS_OAUTH_CLIENT_SECRET are required.

Create a Tailscale OAuth client with the operator tag permissions described in
docs/TAILSCALE_AGENT_DASHBOARDS.md, then export the values for this shell only.
Do not commit or print those values.
EOF
  exit 2
fi

if ! command -v helm >/dev/null 2>&1; then
  echo "ERROR: helm is required to install the Tailscale Kubernetes Operator" >&2
  exit 2
fi

helm repo add tailscale https://pkgs.tailscale.com/helmcharts >/dev/null
helm repo update tailscale >/dev/null

helm upgrade --install "$release" tailscale/tailscale-operator \
  --namespace "$namespace" \
  --create-namespace \
  --set-string "oauth.clientId=${TS_OAUTH_CLIENT_ID}" \
  --set-string "oauth.clientSecret=${TS_OAUTH_CLIENT_SECRET}" \
  --wait

operator_deployment="$(
  kubectl -n "$namespace" get deploy \
    -l app.kubernetes.io/name=tailscale-operator \
    -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true
)"
operator_deployment="${operator_deployment:-operator}"

kubectl -n "$namespace" rollout status deploy/"$operator_deployment" --timeout=180s
kubectl apply -f k8s/tailscale/openclaw-agent-dashboard-proxygroup.yaml
