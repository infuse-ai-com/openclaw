#!/usr/bin/env bash
set -euo pipefail

evidence_dir="${1:-assurance-evidence/dependencies}"
mkdir -p "$evidence_dir"

npm_exit=0
npm audit \
  --omit=dev \
  --audit-level=high \
  --json \
  --prefix plugins/behavioral-observability \
  >"$evidence_dir/npm-audit.json" || npm_exit=$?

npm sbom \
  --omit=dev \
  --package-lock-only \
  --sbom-format=cyclonedx \
  --prefix plugins/behavioral-observability \
  >"$evidence_dir/npm-sbom.cdx.json"

python_exit=0
uvx --from pip-audit==2.10.1 pip-audit \
  --requirement images/openclaw-agent/requirements-toolbox.lock \
  --require-hashes \
  --disable-pip \
  --format json \
  --output "$evidence_dir/python-audit.json" \
  --progress-spinner off || python_exit=$?

python3 - "$evidence_dir" "$npm_exit" "$python_exit" <<'PY'
import json
import sys
from pathlib import Path

evidence = Path(sys.argv[1])
npm_exit = int(sys.argv[2])
python_exit = int(sys.argv[3])
npm = json.loads((evidence / "npm-audit.json").read_text(encoding="utf-8"))
python = json.loads((evidence / "python-audit.json").read_text(encoding="utf-8"))
npm_findings = list(npm.get("vulnerabilities", {}).values())
npm_high = sum(item.get("severity") == "high" for item in npm_findings)
npm_critical = sum(item.get("severity") == "critical" for item in npm_findings)
python_vulnerabilities = sum(
    len(item.get("vulns", [])) for item in python.get("dependencies", [])
)
summary = {
    "schema": "infuse.dependency-assurance/v1",
    "npm": {
        "exitCode": npm_exit,
        "high": npm_high,
        "critical": npm_critical,
    },
    "python": {
        "exitCode": python_exit,
        "vulnerabilities": python_vulnerabilities,
    },
}
(evidence / "summary.json").write_text(
    json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(json.dumps(summary, indent=2, sort_keys=True))
raise SystemExit(
    1
    if any(
        (npm_exit, python_exit, npm_high, npm_critical, python_vulnerabilities)
    )
    else 0
)
PY
