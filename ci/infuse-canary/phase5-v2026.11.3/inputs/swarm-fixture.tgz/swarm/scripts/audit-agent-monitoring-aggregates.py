#!/usr/bin/env python3
"""Validate and summarize privacy-safe aggregate agent-monitoring evidence."""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONTRACT = ROOT / "config" / "observability" / "telemetry-contract.v1.json"
DEFAULT_INPUT = (
    ROOT
    / "config"
    / "observability"
    / "baselines"
    / "agent-monitoring-dogfood-2026-08-31.json"
)
EXPECTED_AGENTS = {
    "agent-coordinator",
    "agent-developer",
    "agent-infra",
    "agent-designer",
    "agent-intake",
}
SNAPSHOT_KEYS = {"schemaVersion", "window", "scope", "signals", "aggregates", "segments"}
WINDOW_KEYS = {"start", "end", "durationHours"}
SCOPE_KEYS = {
    "environment",
    "containerImageRevision",
    "openclawRuntimeRevision",
    "rolloutBoundary",
    "trafficSource",
}
SIGNAL_KEYS = {"officialRun", "curatedTurn", "officialTool", "curatedTool"}
AGGREGATE_KEYS = {
    "langfuseObservations",
    "langfuseTraces",
    "run",
    "tool",
    "officialRunFailureCauses",
    "curatedAliasDuplicatesEstimated",
    "curatedTurnRoots",
    "curatedTurnRootsWithMissingParent",
    "privacyForbiddenContentMatches",
}
FAMILY_KEYS = {"official", "curated"}
COUNT_KEYS = {"attempts", "failures"}
SEGMENT_KEYS = {
    "agent",
    "environment",
    "containerImageRevision",
    "openclawRuntimeRevision",
    "skillBundleRevision",
    "rolloutBoundary",
    "trafficSource",
    "curatedTurnAttempts",
    "officialToolAttempts",
    "officialToolFailures",
}
REVISION_RE = re.compile(r"^(?:sha256:[0-9a-f]{64}|[0-9a-f]{40}|unavailable)$")
TOKEN_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]{0,95}$")


class AuditError(ValueError):
    """Raised when an aggregate snapshot violates the review contract."""


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise AuditError("aggregate snapshot must be an object")
    return value


def require_exact_keys(value: Any, expected: set[str], path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise AuditError(f"{path} must be an object")
    actual = set(value)
    if actual != expected:
        raise AuditError(
            f"{path} keys must be exactly {sorted(expected)}; got {sorted(actual)}"
        )
    return value


def require_count(value: Any, path: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise AuditError(f"{path} must be a non-negative integer")
    return value


def parse_timestamp(value: Any, path: str) -> datetime:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise AuditError(f"{path} must be a UTC RFC3339 timestamp")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise AuditError(f"{path} must be a UTC RFC3339 timestamp") from error


def validate_privacy_shape(value: Any, contract: dict[str, Any], path: str = "$") -> None:
    forbidden_names = [
        re.compile(pattern, re.IGNORECASE)
        for pattern in contract["forbiddenFieldPatterns"]
    ]
    forbidden_values = [
        re.compile(pattern, re.IGNORECASE)
        for pattern in contract["forbiddenValuePatterns"]
    ]
    max_length = int(contract["maxAttributeStringLength"])
    if isinstance(value, dict):
        for key, child in value.items():
            if any(pattern.search(key) for pattern in forbidden_names):
                raise AuditError(f"{path}.{key} uses a forbidden field name")
            validate_privacy_shape(child, contract, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            validate_privacy_shape(child, contract, f"{path}[{index}]")
    elif isinstance(value, str):
        if len(value) > max_length:
            raise AuditError(f"{path} exceeds the approved string bound")
        if any(pattern.search(value) for pattern in forbidden_values):
            raise AuditError(f"{path} matches a forbidden value shape")


def validate_snapshot(snapshot: dict[str, Any], contract: dict[str, Any]) -> None:
    require_exact_keys(snapshot, SNAPSHOT_KEYS, "$")
    if snapshot["schemaVersion"] != "1.0.0":
        raise AuditError("schemaVersion must be 1.0.0")
    validate_privacy_shape(snapshot, contract)

    window = require_exact_keys(snapshot["window"], WINDOW_KEYS, "$.window")
    start = parse_timestamp(window["start"], "$.window.start")
    end = parse_timestamp(window["end"], "$.window.end")
    duration = require_count(window["durationHours"], "$.window.durationHours")
    if end <= start or (end - start).total_seconds() != duration * 3600:
        raise AuditError("window duration does not match start/end")
    if duration == 0 or duration > 168:
        raise AuditError("window duration must be between 1 and 168 hours")

    scope = require_exact_keys(snapshot["scope"], SCOPE_KEYS, "$.scope")
    for key in ("containerImageRevision", "openclawRuntimeRevision"):
        if not isinstance(scope[key], str) or REVISION_RE.fullmatch(scope[key]) is None:
            raise AuditError(f"$.scope.{key} is not a bounded revision")
    for key in ("environment", "rolloutBoundary"):
        if not isinstance(scope[key], str) or TOKEN_RE.fullmatch(scope[key]) is None:
            raise AuditError(f"$.scope.{key} is not a bounded token")
    traffic_sources = set(contract["comparisonBoundaries"]["trafficSourceEnum"])
    if scope["trafficSource"] not in traffic_sources:
        raise AuditError("$.scope.trafficSource is outside the approved enum")

    signals = require_exact_keys(snapshot["signals"], SIGNAL_KEYS, "$.signals")
    authorities = contract["signalAuthorities"]
    expected_signals = {
        "officialRun": authorities["run"]["canonicalSignal"],
        "curatedTurn": authorities["run"]["drilldownSignal"],
        "officialTool": authorities["tool"]["canonicalSignal"],
        "curatedTool": authorities["tool"]["drilldownSignal"],
    }
    if signals != expected_signals:
        raise AuditError("snapshot signal identities disagree with the telemetry authority contract")

    aggregates = require_exact_keys(snapshot["aggregates"], AGGREGATE_KEYS, "$.aggregates")
    for key in AGGREGATE_KEYS - {"run", "tool", "officialRunFailureCauses"}:
        require_count(aggregates[key], f"$.aggregates.{key}")
    for family in ("run", "tool"):
        rows = require_exact_keys(aggregates[family], FAMILY_KEYS, f"$.aggregates.{family}")
        for source in ("official", "curated"):
            counts = require_exact_keys(
                rows[source], COUNT_KEYS, f"$.aggregates.{family}.{source}"
            )
            attempts = require_count(
                counts["attempts"], f"$.aggregates.{family}.{source}.attempts"
            )
            failures = require_count(
                counts["failures"], f"$.aggregates.{family}.{source}.failures"
            )
            if failures > attempts:
                raise AuditError(f"{family}.{source} failures exceed attempts")

    causes = aggregates["officialRunFailureCauses"]
    if not isinstance(causes, dict) or not causes:
        raise AuditError("officialRunFailureCauses must be a non-empty object")
    if any(not TOKEN_RE.fullmatch(key) for key in causes):
        raise AuditError("officialRunFailureCauses contains an unbounded key")
    if sum(require_count(value, f"$.aggregates.officialRunFailureCauses.{key}") for key, value in causes.items()) != aggregates["run"]["official"]["failures"]:
        raise AuditError("official run failure causes do not sum to official failures")
    if aggregates["curatedTurnRootsWithMissingParent"] > aggregates["curatedTurnRoots"]:
        raise AuditError("missing-parent roots exceed curated roots")

    segments = snapshot["segments"]
    if not isinstance(segments, list) or len(segments) != len(EXPECTED_AGENTS):
        raise AuditError("segments must contain exactly the five persistent agents")
    observed_agents: set[str] = set()
    for index, raw_segment in enumerate(segments):
        segment = require_exact_keys(raw_segment, SEGMENT_KEYS, f"$.segments[{index}]")
        agent = segment["agent"]
        if agent not in EXPECTED_AGENTS or agent in observed_agents:
            raise AuditError(f"$.segments[{index}].agent is unexpected or duplicated")
        observed_agents.add(agent)
        for key in ("containerImageRevision", "openclawRuntimeRevision", "skillBundleRevision"):
            if not isinstance(segment[key], str) or REVISION_RE.fullmatch(segment[key]) is None:
                raise AuditError(f"$.segments[{index}].{key} is not a bounded revision")
        for key in ("environment", "rolloutBoundary"):
            if not isinstance(segment[key], str) or TOKEN_RE.fullmatch(segment[key]) is None:
                raise AuditError(f"$.segments[{index}].{key} is not a bounded token")
        if segment["trafficSource"] not in traffic_sources:
            raise AuditError(f"$.segments[{index}].trafficSource is outside the enum")
        for key in ("environment", "containerImageRevision", "openclawRuntimeRevision", "rolloutBoundary", "trafficSource"):
            if segment[key] != scope[key]:
                raise AuditError(f"$.segments[{index}].{key} crosses the declared scope")
        for key in ("curatedTurnAttempts", "officialToolAttempts", "officialToolFailures"):
            require_count(segment[key], f"$.segments[{index}].{key}")
        if segment["officialToolFailures"] > segment["officialToolAttempts"]:
            raise AuditError(f"$.segments[{index}] tool failures exceed attempts")
    if observed_agents != EXPECTED_AGENTS:
        raise AuditError("segments do not cover the exact persistent-agent fleet")
    if sum(row["curatedTurnAttempts"] for row in segments) != aggregates["run"]["curated"]["attempts"]:
        raise AuditError("per-agent curated turns do not sum to the curated aggregate")
    if sum(row["officialToolAttempts"] for row in segments) != aggregates["tool"]["official"]["attempts"]:
        raise AuditError("per-agent official tools do not sum to the official aggregate")
    if sum(row["officialToolFailures"] for row in segments) != aggregates["tool"]["official"]["failures"]:
        raise AuditError("per-agent official tool failures do not sum to the official aggregate")


def percentage(numerator: int, denominator: int) -> float:
    return round(100 * numerator / denominator, 4) if denominator else 0.0


def build_report(snapshot: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    validate_snapshot(snapshot, contract)
    aggregates = snapshot["aggregates"]
    run_official = aggregates["run"]["official"]
    run_curated = aggregates["run"]["curated"]
    tool_official = aggregates["tool"]["official"]
    tool_curated = aggregates["tool"]["curated"]
    segments = snapshot["segments"]
    return {
        "schemaVersion": "1.0.0",
        "window": snapshot["window"],
        "canonicalTruth": {
            "run": {
                "signal": contract["signalAuthorities"]["run"]["canonicalSignal"],
                "attempts": run_official["attempts"],
                "failures": run_official["failures"],
                "failureRatePct": percentage(run_official["failures"], run_official["attempts"]),
            },
            "tool": {
                "signal": contract["signalAuthorities"]["tool"]["canonicalSignal"],
                "attempts": tool_official["attempts"],
                "failures": tool_official["failures"],
                "failureRatePct": percentage(tool_official["failures"], tool_official["attempts"]),
            },
        },
        "curatedDrilldown": {
            "turn": {
                "signal": contract["signalAuthorities"]["run"]["drilldownSignal"],
                "attempts": run_curated["attempts"],
                "failures": run_curated["failures"],
                "failureCoveragePct": percentage(run_curated["failures"], run_official["failures"]),
            },
            "tool": {
                "signal": contract["signalAuthorities"]["tool"]["drilldownSignal"],
                "attempts": tool_curated["attempts"],
                "failures": tool_curated["failures"],
                "failureCoveragePct": percentage(tool_curated["failures"], tool_official["failures"]),
            },
        },
        "disagreement": {
            "officialMinusCuratedRunFailures": run_official["failures"] - run_curated["failures"],
            "officialMinusCuratedToolFailures": tool_official["failures"] - tool_curated["failures"],
            "curatedMinusOfficialToolAttempts": tool_curated["attempts"] - tool_official["attempts"],
            "policy": "surface",
        },
        "failureCauses": aggregates["officialRunFailureCauses"],
        "traceIntegrity": {
            "curatedTurnRoots": aggregates["curatedTurnRoots"],
            "rootsWithMissingParent": aggregates["curatedTurnRootsWithMissingParent"],
            "missingParentRatePct": percentage(
                aggregates["curatedTurnRootsWithMissingParent"],
                aggregates["curatedTurnRoots"],
            ),
            "estimatedAliasDuplicates": aggregates["curatedAliasDuplicatesEstimated"],
        },
        "provenance": {
            "agents": sorted(row["agent"] for row in segments),
            "environment": snapshot["scope"]["environment"],
            "containerImageRevisions": sorted({row["containerImageRevision"] for row in segments}),
            "openclawRuntimeRevisions": sorted({row["openclawRuntimeRevision"] for row in segments}),
            "skillBundleRevisions": sorted({row["skillBundleRevision"] for row in segments}),
            "rolloutBoundaries": sorted({row["rolloutBoundary"] for row in segments}),
            "trafficSources": sorted({row["trafficSource"] for row in segments}),
        },
        "segmentationGaps": [
            "official_run_counts_by_agent",
            "skill_bundle_revision",
            "traffic_source",
        ],
        "privacy": {
            "forbiddenContentMatches": aggregates["privacyForbiddenContentMatches"],
            "aggregateOnly": True,
        },
    }


def assert_frozen_baseline(report: dict[str, Any]) -> None:
    expected = {
        "window": {
            "start": "2026-08-30T23:12:19Z",
            "end": "2026-08-31T11:12:19Z",
            "durationHours": 12,
        },
        "run": (575, 30, 545, 4),
        "tool": (1073, 63, 1245, 2),
    }
    if report["window"] != expected["window"]:
        raise AuditError("frozen baseline window drifted")
    if (
        report["canonicalTruth"]["run"]["attempts"],
        report["canonicalTruth"]["run"]["failures"],
        report["curatedDrilldown"]["turn"]["attempts"],
        report["curatedDrilldown"]["turn"]["failures"],
    ) != expected["run"]:
        raise AuditError("frozen baseline run evidence drifted")
    if (
        report["canonicalTruth"]["tool"]["attempts"],
        report["canonicalTruth"]["tool"]["failures"],
        report["curatedDrilldown"]["tool"]["attempts"],
        report["curatedDrilldown"]["tool"]["failures"],
    ) != expected["tool"]:
        raise AuditError("frozen baseline tool evidence drifted")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Emit aggregate-only agent monitoring truth evidence"
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--assert-frozen-baseline", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        snapshot = load_json(args.input)
        contract = load_json(args.contract)
        report = build_report(snapshot, contract)
        if args.assert_frozen_baseline:
            assert_frozen_baseline(report)
    except (AuditError, OSError, json.JSONDecodeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
