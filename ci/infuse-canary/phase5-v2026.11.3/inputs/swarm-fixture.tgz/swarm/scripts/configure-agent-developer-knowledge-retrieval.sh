#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"
deployment="agent-developer"
expected_image="${EXPECTED_AGENT_DEVELOPER_IMAGE:-registry.infuse-ai-tech.party/agents-swarm/openclaw-agent:canary-20260811.4-010d5554-r1@sha256:ba34b769a58c3ee525fac4a85cf9e055d4fe4c6405c511e7e2addea310a063a6}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
patch_file="$script_dir/../k8s/canary/agent-developer-knowledge-retrieval-patch.yaml"

kubectl_cmd=(kubectl)
if [ -n "${KUBE_CONTEXT:-}" ]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

actual_image="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" -o jsonpath='{.spec.template.spec.containers[?(@.name=="agent")].image}')"
if [ "$actual_image" != "$expected_image" ]; then
  echo "Refusing to configure $deployment: live image is not the reviewed immutable canary." >&2
  exit 1
fi

if [ "$("${kubectl_cmd[@]}" auth can-i patch "deployment/$deployment" -n "$namespace")" != "yes" ]; then
  echo "Current Kubernetes identity cannot patch deployment/$deployment in $namespace." >&2
  exit 1
fi

echo "Applying the retrieval-only pod-template patch to the reviewed agent-developer canary."
"${kubectl_cmd[@]}" -n "$namespace" patch "deployment/$deployment" \
  --type=strategic \
  --patch-file "$patch_file"
"${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$deployment" --timeout=300s

actual_image="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" -o jsonpath='{.spec.template.spec.containers[?(@.name=="agent")].image}')"
if [ "$actual_image" != "$expected_image" ]; then
  echo "Canary image changed while configuring retrieval; stop and investigate." >&2
  exit 1
fi

"${kubectl_cmd[@]}" -n "$namespace" exec "deployment/$deployment" -c agent -- \
  test -r /var/run/openclaw-agent/tokens/knowledge-retrieval/token
echo "Verified agent-developer retained the immutable canary and can read the projected retrieval token."
