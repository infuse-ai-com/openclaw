#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-agents-swarm}"
deployment="${2:-openclaw-agent}"
selector="${3:-app.kubernetes.io/name=openclaw-agent}"
marker="workspace-smoke-$(date -u +%Y%m%dT%H%M%SZ)"
context="${KUBE_CONTEXT:-}"

kubectl_cmd=(kubectl)
if [[ -n "$context" ]]; then
  kubectl_cmd+=(--context "$context")
fi
kubectl_ns=("${kubectl_cmd[@]}" -n "$namespace")

current_pod() {
  "${kubectl_ns[@]}" wait pod \
    -l "$selector" \
    --for=condition=Ready \
    --timeout=120s >/dev/null

  "${kubectl_ns[@]}" get pod \
    -l "$selector" \
    --field-selector=status.phase=Running \
    -o jsonpath='{.items[0].metadata.name}'
}

"${kubectl_ns[@]}" rollout status "deployment/$deployment" --timeout=120s

pod="$(current_pod)"
if [[ -z "$pod" ]]; then
  echo "No pod found for selector $selector in namespace $namespace" >&2
  exit 1
fi

"${kubectl_ns[@]}" exec "$pod" -- sh -lc "echo '$marker' >/workspace/.persistence-smoke"
"${kubectl_ns[@]}" rollout restart "deployment/$deployment"
"${kubectl_ns[@]}" rollout status "deployment/$deployment" --timeout=120s

pod="$(current_pod)"
actual="$("${kubectl_ns[@]}" exec "$pod" -- sh -lc "cat /workspace/.persistence-smoke")"

if [[ "$actual" != "$marker" ]]; then
  echo "Persistence smoke failed: expected '$marker', got '$actual'" >&2
  exit 1
fi

echo "Workspace persistence smoke passed in $namespace"
