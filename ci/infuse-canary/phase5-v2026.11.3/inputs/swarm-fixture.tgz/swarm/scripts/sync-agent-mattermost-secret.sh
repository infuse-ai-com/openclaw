#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-designer}"
secret_name="${MATTERMOST_SECRET_NAME:-$agent_id-mattermost}"
item_name="${VAULTWARDEN_ITEM_NAME:-}"
base_url="${MATTERMOST_BASE_URL:-http://mattermost.infuseai.svc.cluster.local:8065}"
allow_private_network="${MATTERMOST_ALLOW_PRIVATE_NETWORK:-true}"
channel_id="${MATTERMOST_CHANNEL_ID:-}"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
bundle_path="config/agent-skill-bundles/$agent_id.json"

if [[ -z "$channel_id" ]]; then
  echo "MATTERMOST_CHANNEL_ID is required" >&2
  exit 2
fi

if [[ -z "$item_name" ]]; then
  item_name="$(
    python3 - "$bundle_path" "$secret_name" <<'PY'
import json
import sys
from pathlib import Path

bundle_path = Path(sys.argv[1])
secret_name = sys.argv[2]
fallback = f"Mattermost / {bundle_path.stem} BOT token"

if not bundle_path.exists():
    print(fallback)
    sys.exit(0)

bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
matches = []
for item in bundle.get("credential_access", {}).get("vaultwarden", {}).get("allowed_items", []):
    target = item.get("sync_target", {})
    if (
        target.get("type") == "kubernetes-secret-env"
        and target.get("name") == secret_name
        and target.get("key") == "MATTERMOST_BOT_TOKEN"
    ):
        matches.append(item.get("name"))

if len(matches) == 1 and matches[0]:
    print(matches[0])
else:
    print(fallback)
PY
  )"
fi

export AGENT_ID="$agent_id"
export VAULTWARDEN_ITEM_NAME="$item_name"
export CREDENTIAL_TARGET_TYPE="${CREDENTIAL_TARGET_TYPE:-kubernetes-secret-env}"
export CREDENTIAL_SECRET_NAME="$secret_name"
export CREDENTIAL_SECRET_KEY="MATTERMOST_BOT_TOKEN"
export EXTRA_SECRET_LITERALS
EXTRA_SECRET_LITERALS=$(
  printf 'MATTERMOST_BASE_URL=%s\nMATTERMOST_ALLOW_PRIVATE_NETWORK=%s\nMATTERMOST_CHANNEL_ID=%s\n' "$base_url" "$allow_private_network" "$channel_id"
)

exec "$script_dir/sync-agent-credential.sh" "$namespace"
