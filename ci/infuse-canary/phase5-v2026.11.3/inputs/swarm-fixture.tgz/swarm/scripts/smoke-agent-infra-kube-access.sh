#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${2:-${AGENT_ID:-agent-infra}}"
target_namespace="${3:-${TARGET_NAMESPACE:-$namespace}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"

case "$agent_id" in
  agent-infra|agent-coordinator) ;;
  *)
    echo "This smoke is scoped to agent-infra and agent-coordinator" >&2
    exit 2
    ;;
esac

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s
"${kubectl_base[@]}" wait pod -l "$selector" --for=condition=Ready --timeout=120s >/dev/null

pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

"${kubectl_base[@]}" exec "$pod" -c agent -- env \
  AGENT_ID="$agent_id" \
  TARGET_NAMESPACE="$target_namespace" \
  sh -lc '
set -eu
test -s "${KUBECONFIG:?KUBECONFIG is not set}"

can_get_pods="$(kubectl auth can-i get pods -n "$TARGET_NAMESPACE" || true)"
can_get_logs="$(kubectl auth can-i get pods/log -n "$TARGET_NAMESPACE" || true)"
can_get_secrets="$(kubectl auth can-i get secrets -n "$TARGET_NAMESPACE" || true)"
can_patch_deployments="$(kubectl auth can-i patch deployments -n "$TARGET_NAMESPACE" || true)"
can_create_rolebindings="$(kubectl auth can-i create rolebindings -n "$TARGET_NAMESPACE" || true)"

test "$can_get_pods" = "yes"
test "$can_get_logs" = "yes"
test "$can_get_secrets" = "no"
test "$can_create_rolebindings" = "no"

test "$can_patch_deployments" = "no"

kubectl get pods -n "$TARGET_NAMESPACE" >/dev/null
kubectl get deployments -n "$TARGET_NAMESPACE" >/dev/null
'

echo "$agent_id Kubernetes access smoke passed for target namespace $target_namespace"
