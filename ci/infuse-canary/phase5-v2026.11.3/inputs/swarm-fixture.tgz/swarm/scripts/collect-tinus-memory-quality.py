#!/usr/bin/env python3
"""Run only Tinus's read-only shadow probe through the existing collector identity."""
import json, os, subprocess
from pathlib import Path
phase = os.environ.get('MEMORY_SHADOW_PHASE', 'auto')
if phase not in ('auto', 'manual'):
    raise SystemExit('unsupported observation phase')
kube = ['kubectl', '-n', os.environ.get('SOURCE_NAMESPACE', 'agents-swarm')]
pods = json.loads(subprocess.run(kube + ['get', 'pods', '-l', 'app.kubernetes.io/name=agent-developer', '-o', 'json'], capture_output=True, text=True, check=True, timeout=30).stdout)
ready = [p for p in pods['items'] if not p['metadata'].get('deletionTimestamp') and p['status']['phase'] == 'Running' and any(c.get('name') == 'agent' and c.get('ready') for c in p['status'].get('containerStatuses', []))]
if len(ready) != 1:
    raise SystemExit('exactly one ready Tinus pod required')
probe = Path('/probe/observe-tinus-memory-quality.mjs').read_text()
r = subprocess.run(kube + ['exec', '-i', ready[0]['metadata']['name'], '-c', 'agent', '--', 'timeout', '--signal=TERM', '--kill-after=10s', '420s', 'node', '--input-type=module', '-', '--phase', phase], input=probe, capture_output=True, text=True, timeout=480)
if r.returncode:
    raise SystemExit('Tinus shadow observation failed; inspect private evidence, no filter enabled')
# Never forward native stderr or unexpected stdout. The last line is our aggregate receipt.
receipt = json.loads(r.stdout.strip().splitlines()[-1])
if receipt.get('version') != 'tinus-shadow-v1' or receipt.get('agent', 'agent-developer') != 'agent-developer':
    raise SystemExit('unexpected observation receipt')
allowed = {'version','agent','phase','at','mode','candidates','would_exclude','retained','excluded_sources','lookback_days','native_state_unchanged','review_required','nightly_gate_passed','status','observed_before','consumed_by_native','would_exclude_consumed','native_state_changed_since_before','dreams_changed','memory_changed','asynchronous_dream_completion','useful_learning'}
if set(receipt) - allowed:
    raise SystemExit('unexpected receipt fields')
print(json.dumps(receipt, sort_keys=True))
