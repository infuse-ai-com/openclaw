#!/usr/bin/env bash
set -euo pipefail

agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-designer}"
profile="${OPENCLAW_AGENT_PROFILE:-$agent_id}"
workspace="${OPENCLAW_WORKSPACE:-/workspace}"
agent_workspace="${OPENCLAW_AGENT_WORKSPACE:-$workspace/agents/$agent_id}"
model="${MODEL:-openai/gpt-5.5}"

bundle_path="config/agent-skill-bundles/$agent_id.json"
if [[ -f "$bundle_path" ]]; then
  default_agent_name="$(jq -r '.friendly_name // .agent_id' "$bundle_path")"
  default_agent_description="$(jq -r '.context_profile.default_repo_access // "Scoped OpenClaw persistent agent: " + .agent_id + "."' "$bundle_path")"
  default_agent_theme="$(jq -r '.role // "Scoped OpenClaw persistent agent"' "$bundle_path")"
else
  default_agent_name="$agent_id"
  default_agent_description="Scoped OpenClaw persistent agent: $agent_id."
  default_agent_theme="Scoped OpenClaw persistent agent"
fi

agent_name="${AGENT_NAME:-$default_agent_name}"
agent_description="${AGENT_DESCRIPTION:-$default_agent_description}"
agent_theme="${AGENT_THEME:-$default_agent_theme}"
# Legacy fallback profile uses OpenClaw-native IDs; reviewed swarm bundles replace it.
default_skills_csv="browser-automation,canvas,diagram-maker,healthcheck,node-connect,python-debugpy,skill-creator,spike,taskflow,weather"

if [[ -n "${AGENT_SKILLS:-}" ]]; then
  skills_csv="$AGENT_SKILLS"
elif [[ -f "$bundle_path" ]]; then
  skills_csv="$(
    jq -r '.skills.installed | join(",")' \
      "$bundle_path"
  )"
else
  skills_csv="$default_skills_csv"
fi

mattermost_enabled="${MATTERMOST_ENABLED:-true}"
mattermost_base_url="${MATTERMOST_BASE_URL:-http://mattermost.infuseai.svc.cluster.local:8065}"
mattermost_allow_private_network="${MATTERMOST_ALLOW_PRIVATE_NETWORK:-true}"
dm_allow_from="${DM_ALLOW_FROM:-qx31qia617r38b4huiyx8jo7de}"
require_mention="${MATTERMOST_REQUIRE_MENTION:-true}"
dry_run="${DRY_RUN:-false}"
dry_run_output="${DRY_RUN_OUTPUT:-/tmp/openclaw-agent-profile-$agent_id.json}"

config_json="$(
  jq -n \
    --arg agent_id "$agent_id" \
    --arg agent_name "$agent_name" \
    --arg agent_description "$agent_description" \
    --arg agent_theme "$agent_theme" \
    --arg agent_workspace "$agent_workspace" \
    --arg model "$model" \
    --arg mattermost_enabled "$mattermost_enabled" \
    --arg mattermost_base_url "$mattermost_base_url" \
    --arg mattermost_allow_private_network "$mattermost_allow_private_network" \
    --arg dm_allow_from "$dm_allow_from" \
    --arg require_mention "$require_mention" \
    --arg skills_csv "$skills_csv" \
    '
    def split_csv($value):
      $value
      | split(",")
      | map(gsub("^\\s+|\\s+$"; ""))
      | map(select(length > 0));

    {
      gateway: {
        bind: "loopback",
        mode: "local",
        port: 18791,
        auth: {
          mode: "none"
        }
      },
      plugins: {
        entries: {
          codex: {
            enabled: true,
            config: {
              codexDynamicToolsLoading: "searchable",
              codexDynamicToolsExclude: []
            }
          },
          openai: {
            enabled: true
          }
        },
        allow: [
          "codex",
          "mattermost",
          "openai"
        ]
      },
      models: {
        mode: "merge",
        providers: {
          openai: {
            agentRuntime: {
              id: "codex"
            }
          }
        }
      },
      agents: {
        defaults: {
          workspace: $agent_workspace,
          model: {
            primary: $model
          },
          verboseDefault: "off",
          models: {
            ($model): {
              agentRuntime: {
                id: "codex"
              }
            }
          }
        },
        list: [
          {
            id: $agent_id,
            name: $agent_name,
            description: $agent_description,
            identity: {
              name: $agent_name,
              theme: $agent_theme
            },
            model: {
              primary: $model
            },
            models: {
              ($model): {
                agentRuntime: {
                  id: "codex"
                }
              }
            },
            verboseDefault: "off",
            skills: split_csv($skills_csv)
          }
        ]
      }
    }
    + if $mattermost_enabled == "true" then
      {
        surfaces: {
          mattermost: {
            silentReply: {
              group: "allow"
            }
          }
        },
        channels: {
          mattermost: {
            enabled: true,
            baseUrl: $mattermost_base_url,
            network: {
              dangerouslyAllowPrivateNetwork: ($mattermost_allow_private_network == "true")
            },
            botToken: { source: "env", provider: "default", id: "MATTERMOST_BOT_TOKEN" },
            replyToMode: "all",
            streaming: { mode: "off" },
            chatmode: "oncall",
            dmPolicy: "allowlist",
            allowFrom: split_csv($dm_allow_from),
            groupPolicy: "open",
            implicitMentions: {
              replyToBot: false,
              quotedBot: false,
              threadParticipation: false
            },
            requireMention: ($require_mention == "true")
          }
        }
      }
    else
      {}
    end
    '
)"

if [[ "$dry_run" == "true" ]]; then
  printf '%s\n' "$config_json" >"$dry_run_output"
  jq empty "$dry_run_output"
  echo "Rendered bootstrap config: $dry_run_output"
  exit 0
fi

mkdir -p "$agent_workspace"/{memory,state,logs}

openclaw --profile "$profile" config patch --stdin <<<"$config_json"
openclaw --profile "$profile" config validate

cat >"$agent_workspace/README.md" <<EOF
# $agent_id runtime state

This directory is the PVC-backed runtime area for $agent_id.

Do not put secrets here. Use Kubernetes Secrets.
EOF

echo "Bootstrapped OpenClaw profile: $profile"
echo "Agent workspace: $agent_workspace"
