#!/usr/bin/env bash
set -euo pipefail

agent_workspace="${OPENCLAW_AGENT_WORKSPACE:-}"
if [[ -z "$agent_workspace" ]]; then
  echo "error: OPENCLAW_AGENT_WORKSPACE is required to locate the Document Normalizer skill" >&2
  exit 2
fi

client="$agent_workspace/skills/document-normalizer/scripts/document-normalizer-client.py"
if [[ ! -f "$client" ]]; then
  echo "error: canonical Document Normalizer client is unavailable; refresh the document-normalizer skill" >&2
  exit 2
fi

python3_bin="$(command -v python3 || true)"
if [[ -z "$python3_bin" ]]; then
  echo "error: required command is unavailable: python3" >&2
  exit 2
fi

exec "$python3_bin" "$client" "$@"
