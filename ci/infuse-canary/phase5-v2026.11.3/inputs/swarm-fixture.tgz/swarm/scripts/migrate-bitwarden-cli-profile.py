#!/usr/bin/env python3
"""Remove legacy Vaultwarden policy cache entries before newer CLI startup."""

from __future__ import annotations

import argparse
import json
import os
import re
import stat
from pathlib import Path


POLICY_CACHE_KEY = re.compile(r"^user_[^_]+_policies_(?:policies|policiesNew)$")


def atomic_write(path: Path, payload: bytes) -> None:
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        os.chmod(path, 0o600)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)


def migrate(data_dir: Path, migration_id: str) -> int:
    if not data_dir.is_dir():
        raise ValueError(f"Bitwarden CLI data directory does not exist: {data_dir}")
    if not re.fullmatch(r"[A-Za-z0-9._-]+", migration_id):
        raise ValueError("migration id contains unsupported characters")

    marker = data_dir / f".profile-migration-{migration_id}"
    if marker.exists() and not stat.S_ISREG(marker.lstat().st_mode):
        raise ValueError(f"migration marker is not a regular file: {marker}")

    data_file = data_dir / "data.json"
    removed = 0
    if data_file.exists():
        if not stat.S_ISREG(data_file.lstat().st_mode):
            raise ValueError(f"Bitwarden CLI data file is not a regular file: {data_file}")
        data = json.loads(data_file.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("Bitwarden CLI data file must contain a JSON object")
        stale_keys = []
        for key, value in data.items():
            if not POLICY_CACHE_KEY.fullmatch(key) or not isinstance(value, dict):
                continue
            if any(isinstance(policy, dict) and "revisionDate" not in policy for policy in value.values()):
                stale_keys.append(key)
        for key in stale_keys:
            del data[key]
        removed = len(stale_keys)
        if removed:
            atomic_write(
                data_file,
                json.dumps(data, separators=(",", ":"), ensure_ascii=False).encode("utf-8"),
            )

    if removed or not marker.exists():
        atomic_write(marker, f"removed-policy-cache-keys={removed}\n".encode("ascii"))
    print(f"Bitwarden CLI profile migration {migration_id}: removed {removed} cached policy key(s).")
    return removed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument(
        "--migration-id",
        default="bitwarden-cli-2026.10.0-policy-cache",
    )
    args = parser.parse_args()
    migrate(args.data_dir, args.migration_id)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
