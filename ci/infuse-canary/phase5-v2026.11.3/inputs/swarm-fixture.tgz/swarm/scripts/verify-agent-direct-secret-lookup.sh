#!/usr/bin/env bash
set -euo pipefail

tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

mkdir -p "$tmp_dir/override-bundles" "$tmp_dir/home"
expected_bw_data="$tmp_dir/home/.openclaw/secure/bitwarden-cli-agent-developer"

python3 - "$tmp_dir/override-bundles/agent-developer.json" <<'PY'
import json
import sys
from pathlib import Path

target = Path(sys.argv[1])
bundle = {
    "agent_id": "agent-developer",
    "credential_access": {
        "vaultwarden": {
            "env_bootstrap": {
                "projects": {
                    "attacker-project": {
                        "profiles": ["attacker-profile"],
                        "vault_refs": {
                            "attacker/fixture": {
                                "item": "Fixture / visible to agent account",
                                "field": "password",
                            }
                        },
                    }
                }
            },
        }
    }
}
target.write_text(json.dumps(bundle), encoding="utf-8")
PY

fake_bw="$tmp_dir/fake-bw"
cat >"$fake_bw" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

if [[ "${OPENCLAW_BW_DATA:-}" != "${FAKE_EXPECTED_BW_DATA:?Set FAKE_EXPECTED_BW_DATA}" ]]; then
  printf '%s\n' "Unexpected Vaultwarden profile for direct lookup" >&2
  exit 2
fi

case "${1:-}" in
  config|sync)
    exit 0
    ;;
  list)
    item="${4:-}"
    if [[ "$item" == "Fixture / visible to agent account" ]]; then
      printf '%s\n' '[{"id":"11111111-1111-4111-8111-111111111111","name":"Fixture / visible to agent account"},{"id":"22222222-2222-4222-8222-222222222222","name":"Fixture / visible to agent account partial"}]'
      exit 0
    fi
    if [[ "$item" == "Fixture / duplicate exact" ]]; then
      printf '%s\n' '[{"id":"33333333-3333-4333-8333-333333333333","name":"Fixture / duplicate exact"},{"id":"44444444-4444-4444-8444-444444444444","name":"Fixture / duplicate exact"}]'
      exit 0
    fi
    printf '%s\n' '[]'
    ;;
  status)
    printf '%s\n' '{"status":"unlocked"}'
    ;;
  get)
    field="${2:?missing source field}"
    item="${3:?missing item id}"
    if [[ "$item" == "11111111-1111-4111-8111-111111111111" && ( "$field" == "password" || "$field" == "username" ) ]]; then
      printf '%s\n' "fixture-value"
      exit 0
    fi
    printf '%s\n' "Vaultwarden denied requested item for this account" >&2
    exit 1
    ;;
  *)
    printf '%s\n' "Unexpected fake Vaultwarden command: $*" >&2
    exit 2
    ;;
esac
EOF
chmod +x "$fake_bw"

OPENCLAW_BW_DATA="" \
AGENT_ID=agent-developer \
  HOME="$tmp_dir/home" \
  FAKE_EXPECTED_BW_DATA="$expected_bw_data" \
  VAULTWARDEN_ITEM_NAME="Fixture / visible to agent account" \
  CREDENTIAL_SOURCE_FIELD=password \
  BW_HELPER="$fake_bw" \
  scripts/agent-secret-get.sh >/dev/null

AGENT_ID=agent-developer \
  VAULTWARDEN_ITEM_NAME="Project MarkdownGPT / local-minimal MongoDB URI" \
  CREDENTIAL_SOURCE_FIELD=password \
  PROJECT_ENV_BOOTSTRAP_PROJECT=md-poc-monorepo \
  PROJECT_ENV_BOOTSTRAP_PROFILE=local-minimal \
  PROJECT_ENV_BOOTSTRAP_VAULT_REF=mdgpt/local/MONGODB_URI \
  DRY_RUN=true \
  scripts/agent-secret-get.sh >/dev/null

if OPENCLAW_BW_DATA="" \
  AGENT_ID=agent-developer \
  AGENT_SKILL_BUNDLE_DIR="$tmp_dir/override-bundles" \
  VAULTWARDEN_ITEM_NAME="Fixture / visible to agent account" \
  CREDENTIAL_SOURCE_FIELD=password \
  PROJECT_ENV_BOOTSTRAP_PROJECT=attacker-project \
  PROJECT_ENV_BOOTSTRAP_PROFILE=attacker-profile \
  PROJECT_ENV_BOOTSTRAP_VAULT_REF=attacker/fixture \
  DRY_RUN=true \
  scripts/agent-secret-get.sh >/tmp/openclaw-agent-direct-secret-override.out 2>&1; then
  echo "Expected caller-supplied bundle override to be ignored" >&2
  exit 1
fi

if AGENT_ID=agent-developer \
  VAULTWARDEN_ITEM_NAME="Fixture / visible to agent account" \
  CREDENTIAL_SOURCE_FIELD=totp \
  DRY_RUN=true \
  scripts/agent-secret-get.sh >/tmp/openclaw-agent-direct-secret-negative-field.out 2>&1; then
  echo "Expected unsupported direct lookup field to be denied" >&2
  exit 1
fi

if AGENT_ID=agent-developer \
  VAULTWARDEN_ITEM_NAME="Fixture / visible to agent account" \
  CREDENTIAL_SOURCE_FIELD=username \
  PROJECT_ENV_BOOTSTRAP_PROJECT=md-poc-monorepo \
  PROJECT_ENV_BOOTSTRAP_PROFILE=local-minimal \
  PROJECT_ENV_BOOTSTRAP_VAULT_REF=mdgpt/local/TEST_USERNAME \
  DRY_RUN=true \
  scripts/agent-secret-get.sh >/tmp/openclaw-agent-direct-secret-negative-env-bootstrap.out 2>&1; then
  echo "Expected undeclared project env bootstrap to be denied" >&2
  exit 1
fi

if OPENCLAW_BW_DATA="" \
  AGENT_ID=agent-developer \
  HOME="$tmp_dir/home" \
  FAKE_EXPECTED_BW_DATA="$expected_bw_data" \
  VAULTWARDEN_ITEM_NAME="Fixture / denied by Vaultwarden" \
  CREDENTIAL_SOURCE_FIELD=password \
  BW_HELPER="$fake_bw" \
  scripts/agent-secret-get.sh >/dev/null 2>"$tmp_dir/vaultwarden-denied.out"; then
  echo "Expected Vaultwarden-denied direct lookup to fail" >&2
  exit 1
fi

if ! grep -q "Vaultwarden exact item lookup failed: no match" "$tmp_dir/vaultwarden-denied.out"; then
  echo "Expected direct lookup failure to come from exact Vaultwarden item resolution" >&2
  exit 1
fi

if OPENCLAW_BW_DATA="" \
  AGENT_ID=agent-developer \
  HOME="$tmp_dir/home" \
  FAKE_EXPECTED_BW_DATA="$expected_bw_data" \
  VAULTWARDEN_ITEM_NAME="Fixture / duplicate exact" \
  CREDENTIAL_SOURCE_FIELD=password \
  BW_HELPER="$fake_bw" \
  scripts/agent-secret-get.sh >/dev/null 2>"$tmp_dir/vaultwarden-duplicate.out"; then
  echo "Expected duplicate exact Vaultwarden items to fail closed" >&2
  exit 1
fi

if ! grep -q "Vaultwarden exact item lookup failed: duplicate matches" "$tmp_dir/vaultwarden-duplicate.out"; then
  echo "Expected duplicate exact Vaultwarden item resolution failure" >&2
  exit 1
fi

echo "Verified direct lookup uses the agent-scoped profile, delegates item authorization to Vaultwarden, and rejects unsupported fields, caller bundle overrides, and unauthorized env-bootstrap contexts."
