#!/usr/bin/env python3
"""Sync the Langfuse OTel authorization header from Vaultwarden to Kubernetes."""

from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path


PUBLIC_KEY_ITEM_NAME = "Langfuse / Openclaw agents swarm project [Public Key]"
SECRET_KEY_ITEM_NAME = "Langfuse / Openclaw agents swarm project [Secret Key]"
LANGFUSE_BASE_URL = "https://langfuse.infuse-ai.com"
EXPECTED_PROJECT_ID = "openclaw-swarm"
EXPECTED_PROJECT_NAME = "OpenClaw Agents Swarm"
NAMESPACE = "agents-swarm"
SECRET_NAME = "openclaw-observability-exporters"
SECRET_KEY = "LANGFUSE_OTEL_AUTH_HEADER"
DEFAULT_BW_HELPER = Path("/Users/mac/.openclaw/workspace/scripts/bw-infuse-vaultwarden.sh")


def validate_project_keys(public_key: str, secret_key: str) -> tuple[str, str]:
    if not public_key.startswith("pk-lf-") or not secret_key.startswith("sk-lf-"):
        raise ValueError("project items do not contain a Langfuse key pair")
    return public_key, secret_key


def build_secret_manifest(public_key: str, secret_key: str) -> dict[str, object]:
    encoded_pair = base64.b64encode(f"{public_key}:{secret_key}".encode()).decode("ascii")
    return {
        "apiVersion": "v1",
        "kind": "Secret",
        "metadata": {"name": SECRET_NAME, "namespace": NAMESPACE},
        "type": "Opaque",
        "stringData": {SECRET_KEY: f"Basic {encoded_pair}"},
    }


def run(args: list[str], *, input_text: str | None = None) -> str:
    completed = subprocess.run(
        args,
        input=input_text,
        text=True,
        check=True,
        capture_output=True,
    )
    return completed.stdout


def load_project_keys(bw_helper: Path) -> tuple[str, str]:
    if not bw_helper.is_file() or not os.access(bw_helper, os.X_OK):
        raise RuntimeError(f"Vaultwarden helper is unavailable: {bw_helper}")
    run([str(bw_helper), "ensure-unlocked"])
    public_key = run([str(bw_helper), "get", "password", PUBLIC_KEY_ITEM_NAME]).strip()
    secret_key = run([str(bw_helper), "get", "password", SECRET_KEY_ITEM_NAME]).strip()
    return validate_project_keys(public_key, secret_key)


def verify_project_scope(
    public_key: str,
    secret_key: str,
    *,
    base_url: str = LANGFUSE_BASE_URL,
) -> tuple[str, str]:
    encoded_pair = base64.b64encode(f"{public_key}:{secret_key}".encode()).decode("ascii")
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/api/public/projects",
        headers={
            "Authorization": f"Basic {encoded_pair}",
            "User-Agent": "openclaw-observability-secret-sync/1.0",
        },
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        payload = json.load(response)
    projects = payload.get("data", [])
    observed = [(project.get("id"), project.get("name")) for project in projects]
    expected = [(EXPECTED_PROJECT_ID, EXPECTED_PROJECT_NAME)]
    if observed != expected:
        raise ValueError("Langfuse keys are not scoped to the approved agent project")
    return observed[0]


def apply_secret(context: str, manifest: dict[str, object]) -> str:
    identity = json.loads(run(["kubectl", "--context", context, "auth", "whoami", "-o", "json"]))
    username = identity["status"]["userInfo"]["username"]
    for verb in ("create", "patch"):
        allowed = run(
            ["kubectl", "--context", context, "auth", "can-i", verb, "secrets", "-n", NAMESPACE]
        ).strip()
        if allowed != "yes":
            raise PermissionError(f"identity cannot {verb} Secrets in {NAMESPACE}")

    run(
        [
            "kubectl",
            "--context",
            context,
            "apply",
            "--server-side",
            "--field-manager=openclaw-agent-observability-sync",
            "-f",
            "-",
        ],
        input_text=json.dumps(manifest),
    )
    observed = json.loads(
        run(
            [
                "kubectl",
                "--context",
                context,
                "-n",
                NAMESPACE,
                "get",
                "secret",
                SECRET_NAME,
                "-o",
                "json",
            ]
        )
    )
    if observed.get("type") != "Opaque" or set(observed.get("data", {})) != {SECRET_KEY}:
        raise RuntimeError("runtime Secret does not match the one-key contract")
    return username


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("verify", "apply"))
    parser.add_argument("--context", default="infuseai-k8s")
    parser.add_argument("--bw-helper", type=Path, default=DEFAULT_BW_HELPER)
    args = parser.parse_args()

    try:
        public_key, secret_key = load_project_keys(args.bw_helper)
        project_id, project_name = verify_project_scope(public_key, secret_key)
        if args.operation == "verify":
            print(
                f"Validated Langfuse project {project_name} ({project_id}) "
                f"for {NAMESPACE}/{SECRET_NAME}"
            )
            return 0
        manifest = build_secret_manifest(public_key, secret_key)
        username = apply_secret(args.context, manifest)
        print(f"Synced {NAMESPACE}/{SECRET_NAME} through identity {username}")
        return 0
    except (
        json.JSONDecodeError,
        OSError,
        subprocess.CalledProcessError,
        urllib.error.URLError,
        ValueError,
        RuntimeError,
    ) as exc:
        print(f"Observability Secret sync failed: {type(exc).__name__}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
