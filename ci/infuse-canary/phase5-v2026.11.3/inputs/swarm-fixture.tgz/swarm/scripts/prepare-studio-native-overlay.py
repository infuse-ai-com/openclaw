#!/usr/bin/env python3
"""Apply reviewed native routes only to a disposable cutover render tree."""
from __future__ import annotations
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from studio_native_profiles import ROLES, validate_contract

CONFIG = re.compile(r"(name: OPENCLAW_CONFIG_JSON\n\s+value: )'([^'\n]+)'")
DASHBOARD_TRUSTED_PROXY_AGENTS = {'agent-developer', 'agent-designer', 'agent-coordinator', 'agent-intake', 'agent-infra'}

def prepare(k8s: Path, contract: dict) -> None:
    production = json.loads((Path(__file__).resolve().parents[1] / 'config/studio-native-routes.json').read_text())
    profile_name, profile = validate_contract(contract, production)
    routes = contract['routes']
    if len(routes) != len(ROLES) or {r['role']: r['agentId'] for r in routes} != ROLES:
        raise ValueError('Exactly the four reviewed native roles are required')
    for field in ('channelId', 'nativeBotUserId'):
        if len({r[field] for r in routes}) != len(routes) or any(not re.fullmatch('[a-z0-9]{26}', r[field]) for r in routes):
            raise ValueError('Native identities and channels must be distinct real IDs')
    for route in routes:
        agent = route['agentId']
        if route['gatewayId'] != agent.replace('agent-', 'swarm-') or route['accountId'] != 'default':
            raise ValueError('Gateway and native account do not match the reviewed enrollment')
        path = k8s / 'agents' / agent / 'deployment.yaml'
        source = path.read_text()
        matches = list(CONFIG.finditer(source))
        if len(matches) != 1:
            raise ValueError(f'{agent} has no unambiguous configuration')
        current = json.loads(matches[0][2])
        token = 'STUDIO_' + agent.removeprefix('agent-').upper() + '_BRIDGE_TOKEN'
        native_routes = []
        for project in [{'projectId': contract['projectId'], 'routes': routes}, *contract.get('projects', [])]:
            enrolled = next((r for r in project['routes'] if r['agentId'] == agent), None)
            if enrolled is None:
                continue
            selected = project['routes'] if enrolled['role'] == 'coordinator' else [enrolled]
            native_routes.extend({'projectId': project['projectId'], 'installationId': contract['installationId'],
                'accountId': enrolled['accountId'], 'agentId': agent, 'nativeBotUserId': enrolled['nativeBotUserId'],
                'channelId': target['channelId'], 'role': enrolled['role']} for target in selected)
        plugin = {'enabled': True, 'config': {'mode': 'outbound', 'gatewayId': route['gatewayId'],
            'authorityId': contract['authorityId'], 'enrollmentGeneration': 1,
            'studioUrl': contract['studioUrl'],
            **{key: profile[key] for key in ('studioCaFile', 'studioConnectAddress') if key in profile},
            'journalNamespace': profile['journalNamespace'], 'bridgeTokenEnv': token, 'agents': [agent],
            'pollIntervalMs': 2000, 'nativeEnabled': True, 'nativeRoutes': native_routes,
            **({'floorRuntimeDiscovery': True, 'whiteboardEnabled': True, 'companionEnabled': True} if profile_name == 'production' else {}),
            'localConnection': {'url': 'ws://127.0.0.1:18791',
                ('passwordEnv' if agent in DASHBOARD_TRUSTED_PROXY_AGENTS else 'tokenEnv'):
                    ('OPENCLAW_GATEWAY_PASSWORD' if agent in DASHBOARD_TRUSTED_PROXY_AGENTS else 'OPENCLAW_GATEWAY_TOKEN')}}}
        current['plugins']['entries']['infuse-studio'] = plugin
        if 'infuse-studio' not in current['plugins']['allow']:
            current['plugins']['allow'].append('infuse-studio')
        source = CONFIG.sub(lambda m: m[1] + "'" + json.dumps(current, separators=(',', ':')) + "'", source)
        for name in ('OPENCLAW_REQUIRED_PLUGINS', 'OPENCLAW_CAPABILITY_CONSENT_PLUGINS'):
            pattern = re.compile(r'(name: ' + name + r"\n\s+value: )'([^'\n]+)'")
            found = pattern.search(source)
            if not found:
                raise ValueError(f'{agent} is missing plugin installation boundary {name}')
            if '/opt/openclaw-plugin-archives/infuse-studio.tgz' not in found[2].split():
                source = pattern.sub(lambda m: m[1] + "'" + m[2] + " /opt/openclaw-plugin-archives/infuse-studio.tgz'", source)
        secret_name = agent + profile['secretSuffix']
        if 'name: '+token in source:
            pattern = re.compile(r'(name: ' + token + r'\n\s+valueFrom:\n\s+secretKeyRef:\n\s+name: )' + re.escape(agent + '-studio') + r'(?=\n)')
            source, count = pattern.subn(lambda m: m[1] + secret_name, source)
            if count != 1:
                raise ValueError(f'{agent} has no unambiguous existing Studio credential reference')
        else:
            source += f'''- op: add
  path: /spec/template/spec/containers/0/env/-
  value:
    name: {token}
    valueFrom:
      secretKeyRef:
        name: {secret_name}
        key: {token}
'''
        if profile_name == 'local-mac':
            # The Mac HTTPS listener uses ordinary system trust, not the private
            # intra-cluster service CA. Never mount a production credential here.
            source = ''.join(block for block in re.split(r'(?=^- op: )', source, flags=re.M)
                             if '\n    name: studio-trust\n' not in block and '\n    name: whiteboard-mcp\n' not in block)
        elif '\n    name: studio-trust\n' not in source:
            source += f'''
- op: add
  path: /spec/template/spec/containers/0/volumeMounts/-
  value:
    name: studio-trust
    mountPath: /var/run/studio
    readOnly: true
- op: add
  path: /spec/template/spec/volumes/-
  value:
    name: studio-trust
    secret:
      secretName: {agent}-studio
      defaultMode: 0440
      items:
        - key: ca.crt
          path: ca.crt
'''
        path.write_text(source)
    marker = k8s / 'overlays/studio-mission-cutover/authority.yaml'
    text = marker.read_text()
    if text.count('  authority: studio\n') != 1:
        raise ValueError('Unrecognized Studio authority marker template')
    marker.write_text(text.replace('  authority: studio\n',
        f"  authority: {profile['markerAuthority']}\n  nativeProfile: {profile_name}\n  nativeProfileState: pending\n"))

if __name__ == '__main__':
    prepare(Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text()))
