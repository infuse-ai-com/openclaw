#!/usr/bin/env python3
"""Read Studio whiteboards through this agent's private MCP connection; never print credentials."""
import argparse
import json
from pathlib import Path
import ssl
import sys
import urllib.error
import urllib.request

URL = 'https://studio-bridge.core.svc.cluster.local/whiteboard/mcp'
TOKEN = Path('/var/run/studio-whiteboard/token')
CA = '/var/run/studio/ca.crt'
TOOLS = {'context', 'read', 'search'}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def call(operation, arguments):
    if operation not in TOOLS or not isinstance(arguments, dict):
        raise ValueError('Unsupported read')
    with TOKEN.open() as stream:
        credential = stream.read(181).strip()
    if len(credential) > 180 or not credential.startswith('swb_') or any(c.isspace() for c in credential):
        raise ValueError('Invalid private projection')
    payload = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call', 'params': {
        'name': 'studio_whiteboard_' + operation, 'arguments': arguments}}, allow_nan=False).encode()
    if len(payload) > 128 * 1024:
        raise ValueError('Request too large')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
        urllib.request.HTTPSHandler(context=ssl.create_default_context(cafile=CA)))
    request = urllib.request.Request(URL, data=payload, method='POST', headers={
        'Authorization': 'Bearer ' + credential, 'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream'})
    with opener.open(request, timeout=12) as response:
        raw = response.read(64 * 1024 + 1)
    if len(raw) > 64 * 1024:
        raise ValueError('Response too large')
    body = json.loads(raw)
    result = body['result']['structuredContent']
    if result.get('protocol') != 'studio-whiteboard/1':
        raise ValueError('Unexpected protocol')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=sorted(TOOLS | {'probe'}))
    args = parser.parse_args()
    if args.operation == 'probe':
        allowed = call('context', {'project_id': 'studio'})
        denied = call('context', {'project_id': 'whiteboard-denied-probe'})
        if not allowed.get('ok') or denied.get('error', {}).get('code') != 'FORBIDDEN':
            raise ValueError('Access qualification failed')
        value = allowed['result']['value']
        if value.get('access') != 'read' or value['capabilities'].get('imageContent'):
            raise ValueError('Unexpected capabilities')
        print(json.dumps({'status': 'passed', 'project': 'studio', 'access': 'read',
            'wrongProject': 'denied', 'renderer': False, 'actor': value['actor']['id']}))
        return
    raw = sys.stdin.read(128 * 1024 + 1)
    if len(raw.encode()) > 128 * 1024:
        raise ValueError('Request too large')
    print(json.dumps(call(args.operation, json.loads(raw)), ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, urllib.error.URLError):
        raise SystemExit('Studio whiteboard read failed. Check this agent connection, current project access and credential expiry.') from None
