#!/usr/bin/env python3
"""Verify real Python/pip resolution, including login shells that reset PATH."""
import json
import shlex
import subprocess

PREFIX = "/opt/agent-python-toolbox"
CHECK = """
import importlib, json, sys
for name in ('yaml', 'pyaml', 'requests', 'bs4', 'lxml', 'pytest', 'numpy', 'pandas', 'playwright'):
    importlib.import_module(name)
assert sys.prefix == '/opt/agent-python-toolbox', sys.prefix
assert sys.base_prefix != sys.prefix
assert sys.argv[1:] == ['argument with spaces', 'literal;$value'], sys.argv[1:]
print(json.dumps({'prefix': sys.prefix, 'python': sys.version.split()[0], 'imports': True, 'arguments': True}))
"""


def main():
    receipts = []
    for shell in (None, ("/bin/sh", "-c"), ("/bin/sh", "-lc"), ("/bin/bash", "-c"), ("/bin/bash", "-lc")):
        for command in ("python", "python3", "pip", "pip3"):
            args = ([command, "-B", "-I", "-c", CHECK, "argument with spaces", "literal;$value"]
                    if command.startswith("python") else [command, "--version"])
            invocation = args if shell is None else [*shell, shlex.join(args)]
            result = subprocess.run(invocation, capture_output=True, text=True, timeout=30, check=True)
            if command.startswith("python"):
                detail = json.loads(result.stdout.strip())
                assert detail["prefix"] == PREFIX and detail["imports"] and detail["arguments"]
            else:
                assert PREFIX + "/lib/" in result.stdout, result.stdout
                detail = {"toolboxPrefix": True}
            receipts.append({"shell": "direct" if shell is None else " ".join(shell), "command": command, **detail})
    print(json.dumps({"status": "passed", "entrypoints": receipts}, sort_keys=True))


if __name__ == "__main__":
    main()
