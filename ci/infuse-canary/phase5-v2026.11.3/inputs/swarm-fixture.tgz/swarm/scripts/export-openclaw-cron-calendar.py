#!/usr/bin/env python3
"""Export sanitized OpenClaw cron metadata for Backoffice Ritual Calendar."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DEFAULT_TIMEZONE = "Europe/Madrid"
GATEWAY_BACKEND = "gateway_cron_list"
DEFAULT_GATEWAY_PAGE_SIZE = 100
MAX_GATEWAY_PAGES = 100
INTERNAL_MEMORY_ACTIONS = {"backup", "dream", "dreaming", "sync", "synchronization"}


class CronGatewayError(RuntimeError):
    """The Gateway could not provide a complete cron snapshot."""


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Export OpenClaw cron jobs as a sanitized Backoffice calendar snapshot.",
    )
    parser.add_argument(
        "--jobs-file",
        default=os.environ.get("OPENCLAW_CRON_JOBS_FILE"),
        help="Optional legacy OpenClaw jobs.json compatibility input. The authenticated Gateway is the default source.",
    )
    parser.add_argument(
        "--state-file",
        default=None,
        help="Optional jobs-state.json path. Defaults to sibling of --jobs-file when present.",
    )
    parser.add_argument(
        "--agent-id",
        default=os.environ.get("OPENCLAW_AGENT_ID", "kapiteky"),
        help="Agent/profile slug to attach to exported events.",
    )
    parser.add_argument(
        "--profile",
        default=os.environ.get("OPENCLAW_AGENT_PROFILE"),
        help="OpenClaw profile to query when using the runtime cron store.",
    )
    parser.add_argument(
        "--openclaw-bin",
        default=os.environ.get("OPENCLAW_BIN", "openclaw"),
        help="OpenClaw CLI binary to use when querying the runtime cron store.",
    )
    parser.add_argument(
        "--gateway-attempts",
        type=int,
        default=3,
        help="Attempts when the Gateway snapshot changes during pagination or a transient call fails.",
    )
    parser.add_argument(
        "--gateway-retry-delay-seconds",
        type=float,
        default=0.25,
        help="Delay between Gateway retries.",
    )
    parser.add_argument(
        "--gateway-page-size",
        type=int,
        default=DEFAULT_GATEWAY_PAGE_SIZE,
        help="cron.list page size. Defaults to 100.",
    )
    parser.add_argument(
        "--gateway-label",
        default=os.environ.get("OPENCLAW_GATEWAY_LABEL"),
        help="Human-readable gateway/source label. Defaults to '<agent-id> OpenClaw'.",
    )
    parser.add_argument(
        "--system",
        default=os.environ.get("OPENCLAW_CALENDAR_SYSTEM", "openclaw"),
        help="Backoffice system label.",
    )
    parser.add_argument(
        "--source-label",
        default=None,
        help="Safe source label. Defaults to the cron store path with the home directory abbreviated.",
    )
    parser.add_argument(
        "--output",
        default="-",
        help="Output path, or '-' for stdout.",
    )
    parser.add_argument(
        "--allow-missing",
        action="store_true",
        help="Deprecated compatibility flag. Gateway collection failures still exit non-zero.",
    )
    args = parser.parse_args()

    jobs_path = Path(args.jobs_file).expanduser() if args.jobs_file else None
    state_path = (
        Path(args.state_file).expanduser()
        if args.state_file
        else jobs_path.with_name("jobs-state.json") if jobs_path else None
    )

    if jobs_path and jobs_path.exists():
        source_label = args.source_label or abbreviate_home(jobs_path)
        snapshot = build_snapshot(
            jobs_path=jobs_path,
            state_path=state_path if state_path and state_path.exists() else None,
            agent_id=args.agent_id,
            gateway_label=args.gateway_label or f"{args.agent_id} OpenClaw",
            system=args.system,
            source_label=source_label,
        )
    else:
        try:
            raw_jobs = fetch_gateway_cron_jobs(
                openclaw_bin=args.openclaw_bin,
                profile=args.profile,
                page_size=args.gateway_page_size,
                attempts=args.gateway_attempts,
                retry_delay_seconds=args.gateway_retry_delay_seconds,
            )
            snapshot = build_snapshot_from_raw(
                raw_jobs=raw_jobs,
                raw_state={},
                agent_id=args.agent_id,
                gateway_label=args.gateway_label or f"{args.agent_id} OpenClaw",
                system=args.system,
                source_label=args.source_label or "openclaw gateway cron.list",
                state_included=True,
                backend=GATEWAY_BACKEND,
                pagination_complete=True,
                snapshot_revision=revision_value(raw_jobs.get("snapshotRevision")),
            )
        except (CronGatewayError, FileNotFoundError, json.JSONDecodeError, ValueError) as exc:
            print(f"ERROR: cron calendar export failed: {exc}", file=sys.stderr)
            return 1

    output = json.dumps(snapshot, indent=2, sort_keys=True) + "\n"
    if args.output == "-":
        sys.stdout.write(output)
    else:
        output_path = Path(args.output).expanduser()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(output, encoding="utf-8")
    return 0


def default_jobs_file() -> Path:
    profile = os.environ.get("OPENCLAW_AGENT_PROFILE")
    if profile:
        return Path.home() / f".openclaw-{profile}" / "cron" / "jobs.json"
    return Path.home() / ".openclaw" / "cron" / "jobs.json"


def empty_snapshot(*, agent_id: str, gateway_label: str, system: str, source_label: str) -> dict[str, Any]:
    return {
        "schemaVersion": 1,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "source": {
            "type": "openclaw_cron_export",
            "agentId": agent_id,
            "gatewayLabel": gateway_label,
            "jobsFile": source_label,
            "stateIncluded": False,
            "status": "no_cron_jobs",
        },
        "events": [],
    }


def build_snapshot(
    *,
    jobs_path: Path,
    state_path: Path | None,
    agent_id: str,
    gateway_label: str,
    system: str,
    source_label: str,
) -> dict[str, Any]:
    raw_jobs = read_json(jobs_path)
    raw_state = read_json(state_path) if state_path else {}
    return build_snapshot_from_raw(
        raw_jobs=raw_jobs,
        raw_state=raw_state,
        agent_id=agent_id,
        gateway_label=gateway_label,
        system=system,
        source_label=source_label,
        state_included=bool(state_path),
        backend="legacy_jobs_json",
    )


def build_snapshot_from_raw(
    *,
    raw_jobs: Any,
    raw_state: Any,
    agent_id: str,
    gateway_label: str,
    system: str,
    source_label: str,
    state_included: bool,
    backend: str | None = None,
    pagination_complete: bool | None = None,
    snapshot_revision: str | None = None,
) -> dict[str, Any]:
    jobs = raw_jobs.get("jobs", raw_jobs) if isinstance(raw_jobs, dict) else raw_jobs
    if not isinstance(jobs, list):
        raise ValueError("OpenClaw cron source does not contain a jobs array")

    state_by_id = raw_state.get("jobs", raw_state) if isinstance(raw_state, dict) else {}
    if not isinstance(state_by_id, dict):
        state_by_id = {}

    valid_jobs = [job for job in jobs if isinstance(job, dict)]
    included_jobs = [job for job in valid_jobs if not is_internal_calendar_maintenance_job(job)]
    excluded_internal_maintenance_count = len(valid_jobs) - len(included_jobs)

    events = [
        job_to_event(
            job,
            state=state_by_id.get(str(job.get("id")), job.get("state", {})),
            agent_id=agent_id,
            gateway_label=gateway_label,
            system=system,
            source_label=source_label,
        )
        for job in included_jobs
    ]

    source: dict[str, Any] = {
        "type": "openclaw_cron_export",
        "agentId": agent_id,
        "gatewayLabel": gateway_label,
        "jobsFile": source_label,
        "stateIncluded": state_included,
        "status": "available" if events else "no_cron_jobs",
        "excludedInternalMaintenanceCount": excluded_internal_maintenance_count,
    }
    if backend:
        source["backend"] = backend
    if pagination_complete is not None:
        source["paginationComplete"] = pagination_complete
    if snapshot_revision:
        source["snapshotRevision"] = snapshot_revision

    return {
        "schemaVersion": 1,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "source": source,
        "events": events,
    }


def is_internal_calendar_maintenance_job(job: dict[str, Any]) -> bool:
    """Keep system wake loops and model-memory maintenance out of the ritual calendar."""
    name = text_value(job.get("name"))
    if not name:
        return False

    if name.casefold().startswith("heartbeat-"):
        return True

    words = set(re.findall(r"[a-z0-9]+", name.casefold()))
    return "memory" in words and bool(words & INTERNAL_MEMORY_ACTIONS)


def fetch_gateway_cron_jobs(
    *,
    openclaw_bin: str,
    profile: str | None,
    page_size: int = DEFAULT_GATEWAY_PAGE_SIZE,
    attempts: int = 3,
    retry_delay_seconds: float = 0.25,
) -> dict[str, Any]:
    if page_size < 1:
        raise CronGatewayError("Gateway cron.list page size must be positive")
    if attempts < 1:
        raise CronGatewayError("Gateway cron.list attempts must be positive")

    last_error: Exception | None = None
    for attempt in range(attempts):
        try:
            return fetch_gateway_cron_jobs_once(
                openclaw_bin=openclaw_bin,
                profile=profile,
                page_size=page_size,
            )
        except (CronGatewayError, FileNotFoundError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt + 1 < attempts:
                time.sleep(retry_delay_seconds)

    raise CronGatewayError(
        f"Gateway cron.list did not return a complete stable snapshot after {attempts} attempt(s)"
    ) from last_error


def fetch_gateway_cron_jobs_once(
    *,
    openclaw_bin: str,
    profile: str | None,
    page_size: int,
) -> dict[str, Any]:
    jobs: list[dict[str, Any]] = []
    seen_job_ids: set[str] = set()
    offset = 0
    expected_total: int | None = None
    snapshot_revision: str | None = None

    for _ in range(MAX_GATEWAY_PAGES):
        page = call_gateway_cron_list(
            openclaw_bin=openclaw_bin,
            profile=profile,
            limit=page_size,
            offset=offset,
        )
        page_jobs = page.get("jobs")
        if not isinstance(page_jobs, list) or not all(isinstance(job, dict) for job in page_jobs):
            raise CronGatewayError("Gateway cron.list response has an invalid jobs page")

        page_total = page.get("total")
        if not isinstance(page_total, int) or page_total < 0:
            raise CronGatewayError("Gateway cron.list response is missing a valid total")
        if expected_total is None:
            expected_total = page_total
        elif page_total != expected_total:
            raise CronGatewayError("Gateway cron.list total changed during pagination")

        page_revision = revision_value(page.get("snapshotRevision"))
        if offset == 0:
            if not page_revision:
                raise CronGatewayError("Gateway cron.list response is missing snapshotRevision")
            snapshot_revision = page_revision
        elif page_revision != snapshot_revision:
            raise CronGatewayError("Gateway cron.list snapshot revision changed during pagination")

        for job in page_jobs:
            job_id = text_value(job.get("id"))
            if not job_id:
                raise CronGatewayError("Gateway cron.list returned a job without an id")
            if job_id in seen_job_ids:
                raise CronGatewayError("Gateway cron.list returned a duplicate job across pages")
            seen_job_ids.add(job_id)
            jobs.append(job)

        has_more = page.get("hasMore")
        if not isinstance(has_more, bool):
            raise CronGatewayError("Gateway cron.list response is missing hasMore")
        if not has_more:
            if len(jobs) != expected_total:
                raise CronGatewayError(
                    f"Gateway cron.list returned {len(jobs)} of {expected_total} jobs"
                )
            return {
                "jobs": jobs,
                "total": expected_total,
                "offset": 0,
                "limit": page_size,
                "hasMore": False,
                "nextOffset": None,
                "snapshotRevision": snapshot_revision,
            }

        next_offset = page.get("nextOffset")
        if not isinstance(next_offset, int) or next_offset <= offset:
            raise CronGatewayError("Gateway cron.list returned an invalid nextOffset")
        offset = next_offset

    raise CronGatewayError("Gateway cron.list exceeded the pagination safety limit")


def call_gateway_cron_list(
    *,
    openclaw_bin: str,
    profile: str | None,
    limit: int,
    offset: int,
) -> dict[str, Any]:
    command = [openclaw_bin]
    if profile:
        command.extend(["--profile", profile])
    params = json.dumps(
        {"includeDisabled": True, "limit": limit, "offset": offset},
        separators=(",", ":"),
    )
    command.extend(["gateway", "call", "cron.list", "--json", "--params", params])

    result = subprocess.run(command, check=False, capture_output=True, text=True)
    if result.returncode != 0:
        raise CronGatewayError(f"Gateway cron.list exited with status {result.returncode}")
    parsed = json.loads(result.stdout)
    if not isinstance(parsed, dict):
        raise CronGatewayError("Gateway cron.list returned a non-object response")
    return parsed


def read_cron_runtime_store(*, openclaw_bin: str, profile: str | None) -> Any:
    """Compatibility alias for callers that still import the old helper."""
    return fetch_gateway_cron_jobs(openclaw_bin=openclaw_bin, profile=profile)


def job_to_event(
    job: dict[str, Any],
    *,
    state: Any,
    agent_id: str,
    gateway_label: str,
    system: str,
    source_label: str,
) -> dict[str, Any]:
    job_id = safe_slug(str(job.get("id") or job.get("name") or "openclaw-cron"))
    name = str(job.get("name") or job_id)
    schedule = job.get("schedule") if isinstance(job.get("schedule"), dict) else {}
    delivery = job.get("delivery") if isinstance(job.get("delivery"), dict) else {}
    schedule_kind = str(schedule.get("kind") or "cron")
    cron_expr = str(schedule.get("expr") or "") if schedule_kind == "cron" else None
    timezone_name = str(schedule.get("tz") or DEFAULT_TIMEZONE)
    time_parts = time_parts_from_cron(cron_expr or "")
    display_mode = "week_block" if time_parts.get("hour") is not None else "cadence_rail"
    enabled = bool(job.get("enabled", True))
    event_status = "live" if enabled else "installed-but-disabled"

    return {
        "id": f"openclaw-{agent_id}-{job_id}",
        "cronJobId": str(job.get("id") or ""),
        "cronJobName": name,
        "title": humanize_name(name),
        "sourceType": "openclaw_cron",
        "status": event_status,
        "system": system,
        "ownerAgentSlug": agent_id,
        "gatewayLabel": gateway_label,
        "enabled": enabled,
        "sessionTarget": normalize_session_target(job.get("sessionTarget")),
        "deliveryMode": normalize_delivery_mode(delivery.get("mode")),
        "riskLabel": risk_label(schedule=schedule, delivery=delivery),
        "scheduleLabel": schedule_label(schedule),
        "cronExpression": cron_expr,
        "timezone": timezone_name if cron_expr else None,
        "durationMinutes": duration_minutes(schedule=schedule),
        "expectedDurationLabel": "sanitized cron run",
        "loadClass": load_class(schedule=schedule),
        "tags": sorted({agent_id, "openclaw", "cron", schedule_kind}),
        "description": cron_summary(job=job, schedule=schedule),
        "detailText": cron_description(job=job, schedule=schedule, delivery=delivery, state=state),
        "sourceLabel": source_label,
        "displayMode": display_mode,
        **time_parts,
    }


def read_json(path: Path | None) -> Any:
    if path is None:
        return {}
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def cron_description(
    *,
    job: dict[str, Any],
    schedule: dict[str, Any],
    delivery: dict[str, Any],
    state: Any,
) -> str:
    lines: list[str] = []

    job_description = text_value(job.get("description"))
    if job_description:
        lines.append(job_description)

    lines.extend(
        [
            f"Job: {text_value(job.get('name')) or 'unnamed'} ({text_value(job.get('id')) or 'no id'})",
            f"Enabled: {'yes' if bool(job.get('enabled', True)) else 'no'}",
        ]
    )

    status = text_value(job.get("status"))
    if status:
        lines.append(f"Status: {status}")

    agent_id = text_value(job.get("agentId"))
    if agent_id:
        lines.append(f"Agent: {agent_id}")

    lines.append(f"Schedule: {schedule_details(schedule)}")

    session_target = text_value(job.get("sessionTarget"))
    wake_mode = text_value(job.get("wakeMode"))
    session_parts = []
    if session_target:
        session_parts.append(f"target {session_target}")
    if wake_mode:
        session_parts.append(f"wake {wake_mode}")
    if session_parts:
        lines.append(f"Session: {', '.join(session_parts)}")

    payload = job.get("payload") if isinstance(job.get("payload"), dict) else {}
    payload_detail = payload_details(payload)
    if payload_detail:
        lines.append(f"Payload: {payload_detail}")

    delivery_detail = delivery_details(delivery)
    if delivery_detail:
        lines.append(f"Delivery: {delivery_detail}")

    timing_detail = timestamp_details(job)
    if timing_detail:
        lines.append(timing_detail)

    runtime_detail = runtime_state_details(state)
    if runtime_detail:
        lines.append(f"Runtime: {runtime_detail}")

    lines.append("Environment values are intentionally omitted.")
    return "\n".join(lines)


def cron_summary(*, job: dict[str, Any], schedule: dict[str, Any]) -> str:
    job_description = text_value(job.get("description"))
    if job_description:
        return job_description
    return f"{text_value(job.get('name')) or 'OpenClaw cron job'} · {schedule_label(schedule)}"


def text_value(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def revision_value(value: Any) -> str | None:
    if isinstance(value, (str, int)) and not isinstance(value, bool):
        return str(value)
    return None


def schedule_details(schedule: dict[str, Any]) -> str:
    kind = text_value(schedule.get("kind")) or "cron"
    parts = [kind]

    expr = text_value(schedule.get("expr"))
    if expr:
        parts.append(expr)

    tz = text_value(schedule.get("tz"))
    if tz:
        parts.append(f"tz {tz}")

    stagger_ms = schedule.get("staggerMs")
    if isinstance(stagger_ms, int) and stagger_ms > 0:
        parts.append(f"stagger {format_duration_ms(stagger_ms)}")

    interval_ms = schedule.get("ms") or schedule.get("everyMs")
    if isinstance(interval_ms, int):
        parts.append(f"interval {format_duration_ms(interval_ms)}")

    at = text_value(schedule.get("at"))
    if at:
        parts.append(f"at {at}")

    return "; ".join(parts)


def payload_details(payload: dict[str, Any]) -> str | None:
    kind = text_value(payload.get("kind")) or "unknown"
    parts = [kind]

    timeout_seconds = payload.get("timeoutSeconds")
    if isinstance(timeout_seconds, int):
        parts.append(f"timeout {timeout_seconds}s")

    argv = payload.get("argv")
    if isinstance(argv, list) and argv:
        command_parts = [str(part) for part in argv if isinstance(part, (str, int, float))]
        if command_parts:
            parts.append(f"command {command_parts[0]}")
            if len(command_parts) > 1:
                parts.append(f"args {len(command_parts) - 1}")

    env = payload.get("env")
    if isinstance(env, dict) and env:
        safe_names = sorted(str(key) for key in env.keys() if is_safe_env_key(str(key)))
        if safe_names:
            parts.append(f"env keys {', '.join(safe_names)}")
        hidden_count = len(env) - len(safe_names)
        if hidden_count:
            parts.append(f"{hidden_count} sensitive env key(s) hidden")

    return "; ".join(parts) if parts else None


def delivery_details(delivery: dict[str, Any]) -> str | None:
    if not delivery:
        return "none"

    mode = text_value(delivery.get("mode")) or "none"
    parts = [mode]

    channel = text_value(delivery.get("channel"))
    if channel:
        parts.append(f"channel {channel}")

    target = delivery.get("target") or delivery.get("to")
    if isinstance(target, str) and target.strip():
        parts.append("target configured")

    return "; ".join(parts)


def timestamp_details(job: dict[str, Any]) -> str | None:
    parts: list[str] = []
    created_at = iso_from_ms(job.get("createdAtMs"))
    updated_at = iso_from_ms(job.get("updatedAtMs"))
    if created_at:
        parts.append(f"created {created_at}")
    if updated_at:
        parts.append(f"updated {updated_at}")
    return "Timing: " + "; ".join(parts) if parts else None


def runtime_state_details(state: Any) -> str | None:
    if not isinstance(state, dict):
        return None

    state_fields = state.get("state") if isinstance(state.get("state"), dict) else state
    if not isinstance(state_fields, dict) or not state_fields:
        return None

    notes: list[str] = []
    for key, label in [
        ("lastRunStatus", "last run"),
        ("lastStatus", "last status"),
        ("lastDeliveryStatus", "last delivery"),
        ("lastFailureNotificationDeliveryStatus", "last failure notification"),
    ]:
        value = text_value(state_fields.get(key))
        if value:
            notes.append(f"{label} {value}")

    for key, label in [
        ("lastRunAtMs", "last run at"),
        ("nextRunAtMs", "next run at"),
    ]:
        value = iso_from_ms(state_fields.get(key))
        if value:
            notes.append(f"{label} {value}")

    duration = state_fields.get("lastDurationMs")
    if isinstance(duration, int):
        notes.append(f"last duration {format_duration_ms(duration)}")

    for key, label in [
        ("consecutiveErrors", "consecutive errors"),
        ("consecutiveSkipped", "consecutive skips"),
        ("scheduleErrorCount", "schedule errors"),
    ]:
        value = state_fields.get(key)
        if isinstance(value, int):
            notes.append(f"{label} {value}")

    diagnostic = text_value(state_fields.get("lastDiagnosticSummary"))
    if diagnostic:
        notes.append(f"diagnostic {diagnostic}")

    return "; ".join(notes) if notes else None


def iso_from_ms(value: Any) -> str | None:
    if not isinstance(value, int):
        return None
    return datetime.fromtimestamp(value / 1000, timezone.utc).isoformat()


def is_safe_env_key(value: str) -> bool:
    return not re.search(r"(secret|token|password|passwd|credential|pat|key)", value, flags=re.IGNORECASE)


def abbreviate_home(path: Path) -> str:
    home = str(Path.home())
    text = str(path)
    return "~" + text[len(home) :] if text.startswith(home) else text


def safe_slug(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_-]+", "-", value.strip().lower()).strip("-")
    return slug or "openclaw-cron"


def humanize_name(value: str) -> str:
    return re.sub(r"[-_]+", " ", value).strip().capitalize()


def normalize_session_target(value: Any) -> str:
    if value in {"main", "isolated", "current", "custom", "none"}:
        return str(value)
    return "custom" if value else "none"


def normalize_delivery_mode(value: Any) -> str:
    if value in {"announce", "webhook", "none"}:
        return str(value)
    return "none"


def schedule_label(schedule: dict[str, Any]) -> str:
    kind = str(schedule.get("kind") or "cron")
    if kind == "cron":
        expr = str(schedule.get("expr") or "")
        if expr.startswith("*/"):
            minute = expr.split()[0].removeprefix("*/")
            return f"Every {minute} minutes"
        daily = re.fullmatch(r"(\d{1,2})\s+(\d{1,2})\s+\*\s+\*\s+\*", expr)
        if daily:
            return f"Daily {int(daily.group(2)):02d}:{int(daily.group(1)):02d}"
        return expr or "Cron schedule"
    if kind == "every":
        every_ms = schedule.get("ms") or schedule.get("everyMs")
        return f"Every {format_duration_ms(every_ms)}" if isinstance(every_ms, int) else "Recurring interval"
    if kind == "at":
        return f"At {schedule.get('at')}" if schedule.get("at") else "One-time schedule"
    return kind


def time_parts_from_cron(expr: str) -> dict[str, Any]:
    parts = expr.split()
    if len(parts) != 5:
        return {}

    minute_raw, hour_raw, _, _, dow_raw = parts
    if not minute_raw.isdigit() or not hour_raw.isdigit():
        return {}

    result: dict[str, Any] = {"minute": int(minute_raw), "hour": int(hour_raw)}
    if dow_raw != "*":
        days = parse_day_of_week(dow_raw)
        if days:
            result["dayOfWeek"] = days
    return result


def parse_day_of_week(value: str) -> list[int]:
    days: set[int] = set()
    for piece in value.split(","):
        if "-" in piece:
            start, end = piece.split("-", 1)
            if start.isdigit() and end.isdigit():
                days.update(range(int(start), int(end) + 1))
        elif piece.isdigit():
            days.add(int(piece))
    return sorted(day % 7 for day in days)


def format_duration_ms(value: Any) -> str:
    if not isinstance(value, int):
        return "interval"
    minutes = max(1, round(value / 60000))
    return f"{minutes} minutes"


def duration_minutes(*, schedule: dict[str, Any]) -> int:
    expr = str(schedule.get("expr") or "")
    if expr.startswith("*/"):
        return 5
    return 20


def load_class(*, schedule: dict[str, Any]) -> str:
    expr = str(schedule.get("expr") or "")
    if expr.startswith("*/"):
        return "high"
    if "," in expr:
        return "medium"
    return "low"


def risk_label(*, schedule: dict[str, Any], delivery: dict[str, Any]) -> str:
    notes = ["OpenClaw runtime task"]
    if str(schedule.get("expr") or "").startswith("*/"):
        notes.append("high-frequency cadence")
    if delivery.get("mode") and delivery.get("mode") != "none":
        notes.append("external delivery")
    return "; ".join(notes)


if __name__ == "__main__":
    raise SystemExit(main())
