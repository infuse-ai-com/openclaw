#!/usr/bin/env node
// Shadow-only probe: never changes native admission, cursors, recall or Markdown.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';

export const VERSION='tinus-shadow-v1';
export const MODULES={
 'runtime-snapshot-DIGgB9w-.mjs':'d20de852b03d20bd65e14327a87857c82dedb2af411e2ae37a5dc0b5b71488a1',
 'memory-core-host-engine-sessions-CIxPDQTt.mjs':'3120f567a7f38eb0348d9ee40c28716e82df015c91916d8c8c7d090170fcbb4e',
 'session-ingestion-gnSMqrjx.mjs':'1e7e7bfc44adbfcb41273d0e8818b43a09f924d584c4c93057b43f14e1199a97',
 'dreaming-D2xE6WEV.mjs':'5a8397f0586120a952a5a267c4718338bf133e760071422bb5c2cb98157525bf',
 'memory-entry-origins-ISPjhEJE.mjs':'6a04dc85c2df380d990ecd7b9726ac97e4863d4e6e3b80f248a216f4b2a6c452',
};
const hash=x=>createHash('sha256').update(x).digest('hex');
export function classify(candidate){
 // Exact canonical marker only. System origin alone also covers useful work.
 if(candidate.provenance?.originClass==='system' && /^(Assistant|User): ⚙️ Agent was aborted\.$/u.test(candidate.snippet??''))
  return {action:'would_exclude',reason:'system_exact_abort'};
 return {action:'retain',reason:'retain_ambiguous_or_useful'};
}
export function phaseAt(now){
 const day=now.toISOString().slice(0,10),hour=now.getUTCHours();
 if(day<'2026-11-14'||day>'2026-11-16')return 'outside_window';
 if(hour===2 && now.getUTCMinutes()>=50)return 'before';
 if(hour===3 && now.getUTCMinutes()>=50)return 'after';
 return 'outside_window';
}
export function aggregate(rows){
 return {candidates:rows.length,would_exclude:rows.filter(x=>x.action==='would_exclude').length,retained:rows.filter(x=>x.action==='retain').length};
}
function safeDir(dir){
 const absolute=path.resolve(dir);let current='/';
 for(const part of absolute.split('/').filter(Boolean)){
  current=path.join(current,part);
  if(fs.existsSync(current)){if(!fs.lstatSync(current).isDirectory()||fs.lstatSync(current).isSymbolicLink())throw Error('unsafe evidence directory');}
  else fs.mkdirSync(current,{mode:0o700});
 }
 fs.chmodSync(absolute,0o700);
}
function artifact(file){
 if(!fs.existsSync(file))return null;
 const stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>2*1024*1024)throw Error('unsafe native artifact');
 return {sha256:hash(fs.readFileSync(file)),mtime_ms:stat.mtimeMs};
}
export async function main(args=process.argv.slice(2)){
 if(args.length!==2||args[0]!=='--phase'||!['auto','manual'].includes(args[1]))throw Error('usage: --phase auto|manual');
 const now=new Date(),phase=args[1]==='manual'?'manual':phaseAt(now);
 if(phase==='outside_window'){console.log(JSON.stringify({version:VERSION,status:'outside_observation_window'}));return;}
 const agent=process.env.AGENT_ID,workspace=process.env.OPENCLAW_AGENT_WORKSPACE;
 if(agent!=='agent-developer'||workspace!=='/workspace/agents/agent-developer')throw Error('Tinus only');
 const dist='/opt/openclaw-consumer/node_modules/openclaw/dist/';
 for(const [name,expected] of Object.entries(MODULES))if(hash(fs.readFileSync(dist+name))!==expected)throw Error('unqualified native revision');
 const evidence='/workspace/.agent-memory-quality/tinus-shadow-20261113';safeDir(evidence);
 const day=now.toISOString().slice(0,10),key=phase==='manual'?now.toISOString().replaceAll(':','-')+'-manual':day+'-'+phase;
 const target=path.join(evidence,key+'.json');
 if(fs.existsSync(target)){if(fs.lstatSync(target).isSymbolicLink())throw Error('unsafe evidence file');const old=JSON.parse(fs.readFileSync(target,'utf8'));if(old.version!==VERSION)throw Error('evidence revision mismatch');console.log(JSON.stringify({...old.summary,status:'already_recorded'}));return;}
 const {DatabaseSync}=await import('node:sqlite');
 const {O:setConfig}=await import(dist+'runtime-snapshot-DIGgB9w-.mjs');
 const cfg=JSON.parse(fs.readFileSync(path.join(process.env.OPENCLAW_STATE_DIR,'openclaw.json'),'utf8'));setConfig(cfg);
 const {n:list}=await import(dist+'memory-core-host-engine-sessions-CIxPDQTt.mjs');
 const {f:sourceFor,u:scan,s:policyFor,d:exclude,l:fileCapFor}=await import(dist+'session-ingestion-gnSMqrjx.mjs');
 const {t:forgottenFor}=await import(dist+'memory-entry-origins-ISPjhEJE.mjs');
 const {T:resolveLight,E:resolveRem}=await import(dist+'dreaming-D2xE6WEV.mjs');
 const pluginConfig=cfg.plugins?.entries?.[cfg.plugins?.slots?.memory??'memory-core']?.config;
 const phases=[resolveLight({cfg,pluginConfig}),resolveRem({cfg,pluginConfig})].filter(p=>p.enabled&&p.limit>0);
 if(!phases.length)throw Error('no session-ingesting native phase');
 const lookbackDays=Math.max(...phases.map(p=>p.lookbackDays));
 const cutoff=now.getTime()-lookbackDays*86400000;
 const wk=hash(workspace);
 function state(){
  const db=new DatabaseSync(path.join(process.env.OPENCLAW_STATE_DIR,'state/openclaw.sqlite'),{readOnly:true});
  try{
   const rows=db.prepare('select namespace,entry_key,value_json from plugin_state_entries where plugin_id=? and entry_key like ? order by namespace,entry_key').all('memory-core',wk+':%');
   const seen={},files=new Map();
   for(const r of rows){const v=JSON.parse(r.value_json).value;if(r.namespace==='dreaming-session-ingestion-seen')seen[v.scope]=[...(seen[v.scope]??[]),...v.hashes];if(r.namespace==='dreaming-session-ingestion-files')files.set(JSON.parse(r.value_json).key,v);}
   return {seen,files,signature:hash(JSON.stringify(rows))};
  }finally{db.close();}
 }
 const baseline=state();
 const artifacts=()=>Object.fromEntries(['MEMORY.md','DREAMS.md','AGENTS.md','SOUL.md','IDENTITY.md','TOOLS.md','USER.md','HEARTBEAT.md'].map(n=>[n,artifact(path.join(workspace,n))]));
 const beforeArtifacts=artifacts();
 let rows=[],excluded=0;
 if(phase!=='after'){
  const corpus=await list(agent,{config:cfg,includeRetainedSqlite:true});
  const sources=corpus.map(e=>sourceFor(e,'dreaming')).filter(Boolean);
  const forgotten=await forgottenFor({agentId:agent,sessionIds:corpus.map(e=>e.sessionId)});
  const reasons=await exclude(sources,policyFor(pluginConfig),forgotten);
  const eligible=sources.filter(s=>!reasons.has(s)).sort((a,b)=>a.sessionPath.localeCompare(b.sessionPath));excluded=reasons.size;
  let remaining=240;const cap=fileCapFor(eligible.length);
  for(const source of eligible){
   if(remaining<=0)break;
   const result=await scan({source,previous:baseline.files.get(source.stateKey),seenMessages:baseline.seen,timezone:phases[0].timezone,maxCandidates:Math.max(1,Math.min(cap,remaining)),classifyDay:d=>Date.parse(d+'T23:59:59.999Z')>=cutoff?'include':'skip'});
   if(result.status==='unavailable')throw Error('native source unavailable');
   for(const c of result.candidates)rows.push({hash:c.hash,scope:c.scope,provenance:c.provenance,...classify(c),snippet:c.snippet});
   remaining-=result.candidates.length;
  }
 }
 const afterState=state(),afterArtifacts=artifacts();
 if(afterState.signature!==baseline.signature||JSON.stringify(beforeArtifacts)!==JSON.stringify(afterArtifacts))throw Error('native state changed during observation; retry later');
 const summary={version:VERSION,agent,phase,at:now.toISOString(),mode:'shadow',...aggregate(rows),excluded_sources:excluded,lookback_days:lookbackDays,native_state_unchanged:true,review_required:true,nightly_gate_passed:false};
 let comparison=null;
 if(phase==='after'){
  const prePath=path.join(evidence,day+'-before.json');if(!fs.existsSync(prePath)||fs.lstatSync(prePath).isSymbolicLink())throw Error('nightly baseline missing');
  const pre=JSON.parse(fs.readFileSync(prePath,'utf8'));if(pre.version!==VERSION||pre.summary.phase!=='before')throw Error('invalid nightly baseline');
  const consumed=pre.candidates.filter(c=>baseline.seen[c.scope]?.includes(c.hash));
  comparison={observed_before:pre.candidates.length,consumed_by_native:consumed.length,would_exclude_consumed:consumed.filter(c=>c.action==='would_exclude').length,
   native_state_changed_since_before:baseline.signature!==pre.native_state_signature,
   dreams_changed:beforeArtifacts['DREAMS.md']?.sha256!==pre.artifacts['DREAMS.md']?.sha256,
   memory_changed:beforeArtifacts['MEMORY.md']?.sha256!==pre.artifacts['MEMORY.md']?.sha256,
   asynchronous_dream_completion:'requires_review',useful_learning:'requires_private_sample_review'};
  Object.assign(summary,comparison);
 }
 // Raw snippets stay bounded and private on Tinus's PVC, never in logs/mirror.
 const sample=[...rows.filter(c=>c.action==='would_exclude'),...rows.filter(c=>c.action==='retain')].slice(0,12);
 const report={version:VERSION,summary,artifacts:beforeArtifacts,native_state_signature:baseline.signature,candidates:rows.map(({snippet,...c})=>c),private_sample:sample,comparison};
 fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n',{mode:0o600,flag:'wx'});
 console.log(JSON.stringify(summary));
}
if(process.argv[1]==='-'||process.argv[1]===fileURLToPath(import.meta.url))main().catch(()=>{console.error(JSON.stringify({version:VERSION,status:'observation_failed',native_admission_unchanged:true}));process.exitCode=1;});
