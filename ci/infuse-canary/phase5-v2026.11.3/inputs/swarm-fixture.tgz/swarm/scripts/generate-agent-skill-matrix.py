#!/usr/bin/env python3
"""Render the reviewable persistent-agent skill matrix from binary bundles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "config" / "skill-catalog.json"
BUNDLE_DIR = ROOT / "config" / "agent-skill-bundles"
OUTPUT_PATH = ROOT / "docs" / "AGENT_SKILL_MATRIX.md"
SOURCE_ID = "infuse-ai-agent-skills"
AGENT_ORDER = [
    "agent-coordinator",
    "agent-developer",
    "agent-designer",
    "agent-infra",
    "agent-intake",
]


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def render() -> str:
    catalog = load_json(CATALOG_PATH)
    bundles = {
        agent_id: load_json(BUNDLE_DIR / f"{agent_id}.json")
        for agent_id in AGENT_ORDER
    }
    installed = {
        agent_id: set(bundle["skills"]["installed"])
        for agent_id, bundle in bundles.items()
    }
    source_skills = sorted(
        skill_id
        for skill_id, skill in catalog["skills"].items()
        if skill.get("source") == SOURCE_ID
    )
    runtime_native_skills = sorted(
        skill_id
        for skill_id, skill in catalog["skills"].items()
        if catalog["sources"][skill["source"]]["materialization"] == "runtime-native"
    )
    labels = [bundles[agent_id]["friendly_name"].split()[0] for agent_id in AGENT_ORDER]

    lines = [
        "---",
        "title: Persistent Agent Skill Matrix",
        "description: Binary installed or absent assignments for company managed-copy and reviewed runtime-native skills across the persistent swarm.",
        "type: reference",
        "status: active",
        "owner: team:agent-platform",
        "tags:",
        "  - agents",
        "  - skills",
        "  - matrix",
        "---",
        "# Persistent Agent Skill Matrix",
        "",
        "This matrix is generated from `config/skill-catalog.json` and",
        "`config/agent-skill-bundles/*.json`. It includes every skill whose source",
        f"is `{SOURCE_ID}`. **Installed** means the bundle declares the skill and its",
        "managed copy is materialized for that agent; **absent** means it is not installed.",
        "There is no optional state.",
        "",
        "| Skill | " + " | ".join(labels) + " |",
        "|---|" + "---|" * len(labels),
    ]
    for skill_id in source_skills:
        cells = ["Installed" if skill_id in installed[agent_id] else "Absent" for agent_id in AGENT_ORDER]
        lines.append(f"| `{skill_id}` | " + " | ".join(cells) + " |")

    lines.extend(
        [
            "",
            "## Runtime-Native Skills",
            "",
            "These IDs are owned by the pinned OpenClaw runtime or an enabled plugin.",
            "Installing one grants the native capability; it never creates a workspace copy.",
            "",
            "| Skill | Expected source | " + " | ".join(labels) + " |",
            "|---|---|" + "---|" * len(labels),
        ]
    )
    for skill_id in runtime_native_skills:
        skill = catalog["skills"][skill_id]
        expected_source = skill["runtime_native"]["expected_source"]
        cells = ["Installed" if skill_id in installed[agent_id] else "Absent" for agent_id in AGENT_ORDER]
        lines.append(
            f"| `{skill_id}` | `{expected_source}` | " + " | ".join(cells) + " |"
        )

    lines.extend(["", "## Installed Counts", ""])
    for agent_id, label in zip(AGENT_ORDER, labels, strict=True):
        source_count = sum(skill_id in installed[agent_id] for skill_id in source_skills)
        native_count = sum(skill_id in installed[agent_id] for skill_id in runtime_native_skills)
        total_count = len(installed[agent_id])
        lines.append(
            f"- {label}: {source_count} company managed-copy skills; "
            f"{native_count} runtime-native skills; {total_count} installed skills total."
        )
    lines.extend(
        [
            "",
            "Regenerate with `task generate-agent-skill-matrix`. Verification fails",
            "when this document drifts from the bundle source of truth.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    expected = render()
    if args.check:
        if not OUTPUT_PATH.is_file() or OUTPUT_PATH.read_text(encoding="utf-8") != expected:
            print("ERROR: docs/AGENT_SKILL_MATRIX.md is stale; regenerate it", flush=True)
            return 1
        print("Agent skill matrix is current.")
        return 0
    OUTPUT_PATH.write_text(expected, encoding="utf-8")
    print(f"Generated {OUTPUT_PATH.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
