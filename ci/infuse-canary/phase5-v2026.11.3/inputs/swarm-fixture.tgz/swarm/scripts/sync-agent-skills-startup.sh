#!/usr/bin/env bash
set -euo pipefail

agent_id="${AGENT_ID:-}"
workspace="${OPENCLAW_WORKSPACE:-/workspace}"
config_root="${OPENCLAW_SKILL_CONFIG_ROOT:-/opt/openclaw-agent-skill-config}"

if [[ -z "$agent_id" ]]; then
  echo "Skipping startup skill sync: AGENT_ID is not set" >&2
  exit 0
fi

if [[ ! -x "$config_root/scripts/install-agent-skills.py" ]]; then
  echo "Skipping startup skill sync: installer not found at $config_root" >&2
  exit 0
fi

agent_workspace="$workspace/agents/$agent_id"
source_cache_root="${SKILL_SOURCE_CACHE_ROOT:-$agent_workspace/skill-sources}"
skills_dir="${AGENT_SKILLS_DIR:-$agent_workspace/skills}"
source_ids="${SKILL_SOURCE_IDS:-infuse-ai-agent-skills}"

mkdir -p "$agent_workspace" "$source_cache_root" "$skills_dir"

export AGENT_ID="$agent_id"
export AGENT_SKILLS_DIR="$skills_dir"
export ALLOW_SKILL_SOURCE_CLONE="${ALLOW_SKILL_SOURCE_CLONE:-true}"
export SKILL_BUNDLE_DIR="${SKILL_BUNDLE_DIR:-$config_root/config/agent-skill-bundles}"
export SKILL_CATALOG_PATH="${SKILL_CATALOG_PATH:-$config_root/config/skill-catalog.json}"
export SKILL_SOURCE_CACHE_ROOT="$source_cache_root"
export SKILL_SOURCE_SYNC="${SKILL_SOURCE_SYNC:-latest}"

# Rebuild both provenance views from the same exact checkout before OpenClaw
# starts. The full bundle is the reviewed policy view; the source-filtered
# manifest is the active startup-sync view used by recipient preflight.
SKILL_SOURCE_IDS="" \
SKILL_MANIFEST_NAME=skill-bundle-manifest.json \
"$config_root/scripts/install-agent-skills.py"

SKILL_SOURCE_IDS="$source_ids" \
SKILL_MANIFEST_NAME=skill-source-sync-manifest.json \
"$config_root/scripts/install-agent-skills.py"

openclaw-agent-skill-manifest-parity \
  --agent-id "$agent_id" \
  --bundle "$skills_dir/skill-bundle-manifest.json" \
  --active "$skills_dir/skill-source-sync-manifest.json" >/dev/null

proposal_helper="/usr/local/bin/openclaw-agent-skill-proposal"
if [[ -x "$proposal_helper" ]]; then
  "$proposal_helper" scan --agent-id "$agent_id" --quarantine >/dev/null
fi
