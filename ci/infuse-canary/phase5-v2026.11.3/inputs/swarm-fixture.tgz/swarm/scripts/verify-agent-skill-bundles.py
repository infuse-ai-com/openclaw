#!/usr/bin/env python3
"""Validate persistent-agent skill catalog and per-agent bundles."""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "config" / "skill-catalog.json"
BUNDLE_DIR = ROOT / "config" / "agent-skill-bundles"
ACTIVE_STATUSES = {"active"}
COMMAND_OWNER_ALLOW_FROM = "mattermost:qx31qia617r38b4huiyx8jo7de"
COORDINATOR_AGENT_ID = "agent-coordinator"
DASHBOARD_PROXY_AGENTS = {"agent-developer", "agent-designer", "agent-coordinator", "agent-intake", "agent-infra"}
DASHBOARD_PROXY_ORIGIN = "https://agents.infuse-ai.com"
DASHBOARD_PROXY_SOURCE = "10.1.42.208"
ALLOWED_SKILL_STATUSES = {"active", "planned", "retired"}
ALLOWED_EXPOSURE = {"default", "role", "restricted", "denied"}
ALLOWED_CREDENTIAL_POLICIES = {"deny"}
ALLOWED_CREDENTIAL_VISIBILITY = {"runtime-env-only", "runtime-file-only", "sync-only"}
ALLOWED_SYNC_TARGET_TYPES = {
    "kubernetes-secret",
    "kubernetes-secret-env",
    "kubernetes-secret-file",
}
ALLOWED_CREDENTIAL_SOURCE_FIELDS = {"password", "username"}
ALLOWED_REPO_POLICIES = {"allow", "deny"}
ALLOWED_REPO_CHECKOUT_MODES = {"read-only", "task-branch"}
ALLOWED_SKILL_SOURCE_SYNC_STRATEGIES = {"latest", "pinned", "manual"}
ALLOWED_SKILL_MATERIALIZATIONS = {"managed-copy", "runtime-native"}
ALLOWED_RUNTIME_NATIVE_SOURCES = {"openclaw-bundled", "openclaw-extra"}
ALLOWED_RUNTIME_NATIVE_FIELDS = {"expected_source", "plugin_id"}
SKILL_CATALOG_VERSION = 2
INTAKE_CRON_INSTALLER = ROOT / "scripts" / "install-agent-intake-consulting-crons.sh"
EXPECTED_INTAKE_CRON_DEFAULTS = {
    "email_job_name": "agent-intake-consulting-email-triage",
    "email_schedule": "*/10 8-23 * * *",
    "email_prefilter_job_name": "agent-intake-consulting-email-triage-prefilter",
    "email_prefilter_schedule": "$email_schedule",
    "reminder_job_name": "agent-intake-client-waiting-reminders",
    "reminder_schedule": "0 10,14,18,22 * * *",
    "reminder_disabled": "true",
}


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    sys.exit(1)


def load_json(path: Path) -> dict:
    try:
        label = path.relative_to(ROOT)
    except ValueError:
        label = path
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"missing {label}")
    except json.JSONDecodeError as exc:
        fail(f"{label} is invalid JSON: {exc}")


def require_list(value: object, label: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        fail(f"{label} must be a list of strings")
    return value


def validate_catalog(catalog: dict) -> None:
    if catalog.get("version") != SKILL_CATALOG_VERSION:
        fail(
            f"catalog.version must be {SKILL_CATALOG_VERSION}, got "
            f"{catalog.get('version')!r}"
        )
    sources = catalog.get("sources")
    skills = catalog.get("skills")
    if not isinstance(sources, dict) or not sources:
        fail("catalog.sources must be a non-empty object")
    if not isinstance(skills, dict) or not skills:
        fail("catalog.skills must be a non-empty object")

    for source_id, source in sources.items():
        if not isinstance(source, dict):
            fail(f"source {source_id} must be an object")
        if not source.get("description"):
            fail(f"source {source_id} is missing description")
        materialization = source.get("materialization")
        if materialization not in ALLOWED_SKILL_MATERIALIZATIONS:
            fail(
                f"source {source_id}.materialization must be one of "
                f"{sorted(ALLOWED_SKILL_MATERIALIZATIONS)}"
            )
        expected_runtime_source = source.get("expected_runtime_source")
        if materialization == "runtime-native":
            if expected_runtime_source not in ALLOWED_RUNTIME_NATIVE_SOURCES:
                fail(
                    f"source {source_id}.expected_runtime_source must be one of "
                    f"{sorted(ALLOWED_RUNTIME_NATIVE_SOURCES)}"
                )
        elif expected_runtime_source is not None:
            fail(
                f"source {source_id}.expected_runtime_source is valid only for "
                "runtime-native sources"
            )
        catalog_path = source.get("catalog_path")
        if catalog_path is not None and (
            not isinstance(catalog_path, str) or not catalog_path or Path(catalog_path).is_absolute()
        ):
            fail(f"source {source_id}.catalog_path must be a non-empty relative path")
        contract_fields: list[str] = []
        optional_contract_fields: list[str] = []
        if catalog_path is not None:
            catalog_version = source.get("catalog_version")
            if not isinstance(catalog_version, int) or catalog_version < 1:
                fail(f"source {source_id}.catalog_version must be a positive integer")
            contract_fields = require_list(
                source.get("contract_fields"), f"source {source_id}.contract_fields"
            )
            if not contract_fields or len(contract_fields) != len(set(contract_fields)):
                fail(f"source {source_id}.contract_fields must be non-empty and unique")
            if not {"status", "default_exposure"}.issubset(contract_fields):
                fail(
                    f"source {source_id}.contract_fields must include status and "
                    "default_exposure"
                )
            optional_contract_fields = require_list(
                source.get("optional_contract_fields", []),
                f"source {source_id}.optional_contract_fields",
            )
            if not set(optional_contract_fields).issubset(contract_fields):
                fail(
                    f"source {source_id}.optional_contract_fields must be a subset of "
                    "contract_fields"
                )
        sync = source.get("sync")
        if sync is not None:
            if not isinstance(sync, dict):
                fail(f"source {source_id}.sync must be an object")
            strategy = sync.get("strategy")
            if strategy not in ALLOWED_SKILL_SOURCE_SYNC_STRATEGIES:
                fail(
                    f"source {source_id}.sync.strategy must be one of "
                    f"{sorted(ALLOWED_SKILL_SOURCE_SYNC_STRATEGIES)}"
                )
            if strategy in {"latest", "pinned"}:
                for field in ("remote", "branch"):
                    if not isinstance(sync.get(field), str) or not sync[field]:
                        fail(f"source {source_id}.sync.{field} must be a non-empty string")
            if strategy == "pinned":
                pinned_commit = sync.get("commit")
                if not isinstance(pinned_commit, str) or len(pinned_commit) < 7:
                    fail(f"source {source_id}.sync.commit must be a commit SHA")

    for skill_id, skill in skills.items():
        if not isinstance(skill, dict):
            fail(f"skill {skill_id} must be an object")
        source = skill.get("source")
        if source not in sources:
            fail(f"skill {skill_id} references unknown source {source!r}")
        status = skill.get("status")
        if status not in ALLOWED_SKILL_STATUSES:
            fail(f"skill {skill_id} has invalid status {status!r}")
        exposure = skill.get("default_exposure")
        if exposure not in ALLOWED_EXPOSURE:
            fail(f"skill {skill_id} has invalid default_exposure {exposure!r}")
        if not skill.get("summary"):
            fail(f"skill {skill_id} is missing summary")
        materialization = sources[source]["materialization"]
        runtime_native = skill.get("runtime_native")
        if materialization == "runtime-native":
            if not isinstance(runtime_native, dict):
                fail(f"skill {skill_id}.runtime_native must be an object")
            unexpected_fields = set(runtime_native) - ALLOWED_RUNTIME_NATIVE_FIELDS
            if unexpected_fields:
                fail(
                    f"skill {skill_id}.runtime_native has unsupported fields: "
                    f"{sorted(unexpected_fields)}"
                )
            expected_source = runtime_native.get("expected_source")
            if expected_source not in ALLOWED_RUNTIME_NATIVE_SOURCES:
                fail(
                    f"skill {skill_id}.runtime_native.expected_source must be one of "
                    f"{sorted(ALLOWED_RUNTIME_NATIVE_SOURCES)}"
                )
            if expected_source != sources[source]["expected_runtime_source"]:
                fail(
                    f"skill {skill_id}.runtime_native.expected_source must match "
                    f"source {source!r}: {sources[source]['expected_runtime_source']!r}"
                )
            plugin_id = runtime_native.get("plugin_id")
            if source == "openclaw-plugin-skills":
                if not isinstance(plugin_id, str) or not plugin_id:
                    fail(
                        f"skill {skill_id}.runtime_native.plugin_id must be a "
                        "non-empty string for plugin skills"
                    )
            elif plugin_id is not None:
                fail(
                    f"skill {skill_id}.runtime_native.plugin_id is valid only for "
                    "openclaw-plugin-skills entries"
                )
        elif runtime_native is not None:
            fail(
                f"skill {skill_id}.runtime_native is valid only when its source "
                "materialization is runtime-native"
            )
        source_contract = sources[source].get("contract_fields", [])
        optional_contract = set(sources[source].get("optional_contract_fields", []))
        missing_contract = [
            field for field in source_contract
            if field not in skill and field not in optional_contract
        ]
        if missing_contract:
            fail(f"skill {skill_id} is missing source contract fields: {missing_contract}")
        dependencies = skill.get("depends_on", [])
        if not isinstance(dependencies, list) or not all(
            isinstance(item, str) and item for item in dependencies
        ):
            fail(f"skill {skill_id}.depends_on must be a list of non-empty strings")
        if len(dependencies) != len(set(dependencies)):
            fail(f"skill {skill_id}.depends_on must not contain duplicates")
        unknown_dependencies = set(dependencies) - set(skills)
        if unknown_dependencies:
            fail(f"skill {skill_id} depends on unknown skills: {sorted(unknown_dependencies)}")


def validate_source_catalog_alignment(
    catalog: dict,
    source_id: str,
    source_catalog: dict,
) -> None:
    source_definition = catalog["sources"][source_id]
    expected_version = source_definition.get("catalog_version")
    if source_catalog.get("version") != expected_version:
        fail(
            f"source catalog {source_id} version drifted: "
            f"source={source_catalog.get('version')!r}, runtime={expected_version!r}"
        )
    source_skills = source_catalog.get("skills")
    if not isinstance(source_skills, dict) or not source_skills:
        fail(f"source catalog {source_id} must contain a non-empty skills object")

    runtime_skills = {
        skill_id: skill
        for skill_id, skill in catalog["skills"].items()
        if skill.get("source") == source_id
    }
    source_ids = set(source_skills)
    runtime_ids = set(runtime_skills)
    missing = sorted(source_ids - runtime_ids)
    extra = sorted(runtime_ids - source_ids)
    if missing or extra:
        fail(
            f"source catalog {source_id} skill ids drifted: "
            f"missing_from_runtime={missing}, extra_in_runtime={extra}"
        )

    for skill_id in sorted(source_ids):
        source_skill = source_skills[skill_id]
        runtime_skill = runtime_skills[skill_id]
        if not isinstance(source_skill, dict):
            fail(f"source catalog {source_id}.{skill_id} must be an object")
        for field in source_definition["contract_fields"]:
            source_has_field = field in source_skill
            runtime_has_field = field in runtime_skill
            if source_has_field != runtime_has_field:
                fail(
                    f"source catalog {source_id}.{skill_id}.{field} presence drifted: "
                    f"source={source_has_field}, runtime={runtime_has_field}"
                )
            if source_has_field and runtime_skill[field] != source_skill[field]:
                fail(
                    f"source catalog {source_id}.{skill_id}.{field} drifted: "
                    f"source={source_skill[field]!r}, runtime={runtime_skill[field]!r}"
                )


def source_root_env_key(source_id: str) -> str:
    safe = "".join(char if char.isalnum() else "_" for char in source_id).upper()
    return f"SKILL_SOURCE_ROOT_{safe}"


def validate_available_source_catalogs(catalog: dict) -> int:
    strict = os.environ.get("CHECK_SKILL_SOURCE_CATALOGS") == "true"
    checked = 0
    for source_id, source in catalog["sources"].items():
        catalog_path = source.get("catalog_path")
        if not catalog_path:
            continue

        roots: list[Path] = []
        override = os.environ.get(source_root_env_key(source_id))
        if override:
            roots.append(Path(override))
        source_cache_root = os.environ.get("SKILL_SOURCE_CACHE_ROOT")
        if source_cache_root and source.get("repo"):
            roots.append(Path(source_cache_root) / source_id)
        for field in ("local_path", "container_path"):
            value = source.get(field)
            if isinstance(value, str) and value:
                path = Path(value)
                roots.append(path if path.is_absolute() else ROOT / path)

        source_catalog_path = next(
            (root / catalog_path for root in roots if (root / catalog_path).is_file()),
            None,
        )
        if source_catalog_path is None:
            if strict:
                fail(
                    f"source catalog {source_id} is unavailable; set "
                    f"{source_root_env_key(source_id)} to a reviewed source checkout"
                )
            continue

        validate_source_catalog_alignment(catalog, source_id, load_json(source_catalog_path))
        checked += 1
    return checked


def validate_bundle(path: Path, catalog: dict) -> None:
    bundle = load_json(path)
    rel = path.relative_to(ROOT)
    agent_id = bundle.get("agent_id")
    if not isinstance(agent_id, str) or not agent_id:
        fail(f"{rel} missing agent_id")
    if path.stem != agent_id:
        fail(f"{rel} filename must match agent_id {agent_id!r}")

    sources = catalog["sources"]
    skills = catalog["skills"]
    allowed_sources = set(require_list(bundle.get("skill_sources"), f"{rel}.skill_sources"))
    unknown_sources = allowed_sources - set(sources)
    if unknown_sources:
        fail(f"{rel} references unknown skill sources: {sorted(unknown_sources)}")

    skill_section = bundle.get("skills")
    if not isinstance(skill_section, dict):
        fail(f"{rel}.skills must be an object")

    if set(skill_section) != {"installed"}:
        fail(f"{rel}.skills must contain only the binary installed list")
    installed_list = require_list(skill_section.get("installed"), f"{rel}.skills.installed")
    if len(installed_list) != len(set(installed_list)):
        fail(f"{rel}.skills.installed must not contain duplicates")
    installed = set(installed_list)
    unknown = installed - set(skills)
    if unknown:
        fail(f"{rel}.skills.installed references unknown skills: {sorted(unknown)}")

    for skill_id in installed:
        skill = skills[skill_id]
        if skill["status"] not in ACTIVE_STATUSES:
            fail(f"{rel}.skills.installed includes non-active skill {skill_id}")
        source = skill["source"]
        if source not in allowed_sources:
            fail(f"{rel}.skills.installed includes {skill_id} from unlisted source {source}")

    validate_bundle_dependency_closure(rel, skills, installed)

    if not installed:
        fail(f"{rel} must install at least one skill")
    validate_context_profile(bundle, rel)
    validate_credential_access(bundle, rel)
    validate_repo_access(bundle, rel)
    validate_active_runtime_patch(bundle, rel, installed)


def validate_context_profile(bundle: dict, rel: Path) -> None:
    profile = bundle.get("context_profile")
    if not isinstance(profile, dict):
        fail(f"{rel}.context_profile must be an object")
    if "temporary_elevation" in profile:
        fail(
            f"{rel}.context_profile.temporary_elevation is retired; "
            "use binary skills.installed and skill_change_policy"
        )
    docs = profile.get("default_docs")
    if not isinstance(docs, list) or not docs or any(not isinstance(ref, str) for ref in docs):
        fail(f"{rel}.context_profile.default_docs must be a non-empty path list")
    for ref in docs:
        if ".." in Path(ref).parts:
            fail(f"{rel}.context_profile.default_docs contains path traversal")
        if ref.startswith("company-docs/docs/"):
            if re.fullmatch(r"company-docs/docs/[0-9]{2}-[^/]+/[^/]+\.md", ref) is None:
                fail(f"{rel}.context_profile.default_docs requires current company category paths")
        elif ref.startswith("docs/") and (ROOT / ref).is_file():
            continue
        elif ref.startswith(f"/workspace/agents/{bundle['agent_id']}/skills/"):
            suffix = ref.split("/skills/", 1)[1]
            if suffix.split("/", 1)[0] not in bundle["skills"]["installed"]:
                fail(f"{rel}.context_profile.default_docs points to an uninstalled skill")
        else:
            fail(f"{rel}.context_profile.default_docs must use company, repo or own installed-skill paths")
    policy = profile.get("skill_change_policy")
    if not isinstance(policy, str) or not policy:
        fail(f"{rel}.context_profile.skill_change_policy must be a non-empty string")


def validate_bundle_dependency_closure(
    rel: Path,
    skills: dict,
    installed: set[str],
) -> None:
    for skill_id in sorted(installed):
        dependencies = set(skills[skill_id].get("depends_on", []))
        missing = dependencies - installed
        if missing:
            fail(
                f"{rel}.skills.installed includes {skill_id} without installed "
                f"dependencies: {sorted(missing)}"
            )


def validate_credential_access(bundle: dict, rel: Path) -> None:
    access = bundle.get("credential_access")
    if not isinstance(access, dict):
        fail(f"{rel}.credential_access must be an object")

    default_policy = access.get("default_policy")
    if default_policy not in ALLOWED_CREDENTIAL_POLICIES:
        fail(
            f"{rel}.credential_access.default_policy must be one of "
            f"{sorted(ALLOWED_CREDENTIAL_POLICIES)}"
        )

    vaultwarden = access.get("vaultwarden")
    if not isinstance(vaultwarden, dict):
        fail(f"{rel}.credential_access.vaultwarden must be an object")
    if not isinstance(vaultwarden.get("organization"), str) or not vaultwarden["organization"]:
        fail(f"{rel}.credential_access.vaultwarden.organization must be a non-empty string")

    retired_keys = {"allowed_collections", "direct_lookup"}.intersection(vaultwarden)
    if retired_keys:
        fail(
            f"{rel}.credential_access.vaultwarden contains retired keys: "
            f"{sorted(retired_keys)}"
        )

    items = vaultwarden.get("allowed_items")
    if not isinstance(items, list) or not items:
        fail(f"{rel}.credential_access.vaultwarden.allowed_items must be a non-empty list")

    seen_targets = set()
    seen_item_targets = set()
    for index, item in enumerate(items):
        label = f"{rel}.credential_access.vaultwarden.allowed_items[{index}]"
        if not isinstance(item, dict):
            fail(f"{label} must be an object")
        for field in ("name", "purpose", "review_or_expiry"):
            if not isinstance(item.get(field), str) or not item[field]:
                fail(f"{label}.{field} must be a non-empty string")
        visibility = item.get("agent_visibility")
        if visibility not in ALLOWED_CREDENTIAL_VISIBILITY:
            fail(f"{label}.agent_visibility must be one of {sorted(ALLOWED_CREDENTIAL_VISIBILITY)}")

        target = item.get("sync_target")
        if not isinstance(target, dict):
            fail(f"{label}.sync_target must be an object")
        target_type = target.get("type")
        if target_type not in ALLOWED_SYNC_TARGET_TYPES:
            fail(f"{label}.sync_target.type must be one of {sorted(ALLOWED_SYNC_TARGET_TYPES)}")
        for field in ("namespace", "name", "key"):
            if not isinstance(target.get(field), str) or not target[field]:
                fail(f"{label}.sync_target.{field} must be a non-empty string")
        source_field = target.get("source_field", "password")
        if source_field not in ALLOWED_CREDENTIAL_SOURCE_FIELDS:
            fail(
                f"{label}.sync_target.source_field must be one of "
                f"{sorted(ALLOWED_CREDENTIAL_SOURCE_FIELDS)}"
            )
        if target_type == "kubernetes-secret-file":
            mount_path = target.get("mount_path")
            if not isinstance(mount_path, str) or not mount_path.startswith("/"):
                fail(f"{label}.sync_target.mount_path must be an absolute path")
            if visibility != "runtime-file-only":
                fail(f"{label}.agent_visibility must be runtime-file-only for file targets")
        if target_type in {"kubernetes-secret", "kubernetes-secret-env"}:
            if visibility == "runtime-file-only":
                fail(f"{label}.agent_visibility cannot be runtime-file-only for env targets")

        target_tuple = (
            target.get("namespace"),
            target.get("name"),
            target.get("key"),
        )
        if target_tuple in seen_targets:
            fail(f"{label}.sync_target duplicates another credential target")
        seen_targets.add(target_tuple)

        item_target_tuple = (
            item.get("name"),
            target.get("namespace"),
            target.get("name"),
            target.get("key"),
        )
        if item_target_tuple in seen_item_targets:
            fail(f"{label} duplicates an item/target entry")
        seen_item_targets.add(item_target_tuple)

    env_bootstrap = vaultwarden.get("env_bootstrap")
    if env_bootstrap is not None:
        validate_vaultwarden_env_bootstrap(
            env_bootstrap=env_bootstrap,
            rel=rel,
        )

    temporary_elevation = access.get("temporary_elevation")
    if not isinstance(temporary_elevation, str) or not temporary_elevation:
        fail(f"{rel}.credential_access.temporary_elevation must be a non-empty string")


def validate_vaultwarden_env_bootstrap(
    *,
    env_bootstrap: object,
    rel: Path,
) -> None:
    label = f"{rel}.credential_access.vaultwarden.env_bootstrap"
    if not isinstance(env_bootstrap, dict):
        fail(f"{label} must be an object")
    projects = env_bootstrap.get("projects")
    if not isinstance(projects, dict) or not projects:
        fail(f"{label}.projects must be a non-empty object")
    for project, grant in projects.items():
        project_label = f"{label}.projects.{project}"
        if not isinstance(project, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", project):
            fail(f"{label}.projects keys must be stable project slugs")
        if not isinstance(grant, dict):
            fail(f"{project_label} must be an object")
        for field in ("purpose", "review_or_expiry"):
            if not isinstance(grant.get(field), str) or not grant[field]:
                fail(f"{project_label}.{field} must be a non-empty string")
        profiles = require_list(grant.get("profiles"), f"{project_label}.profiles")
        if not profiles or len(profiles) != len(set(profiles)) or any(not profile for profile in profiles):
            fail(f"{project_label}.profiles must contain unique non-empty names")
        refs = grant.get("vault_refs")
        if not isinstance(refs, dict) or not refs:
            fail(f"{project_label}.vault_refs must be a non-empty object")
        for alias, binding in refs.items():
            ref_label = f"{project_label}.vault_refs.{alias}"
            if not isinstance(alias, str) or not alias or "/" not in alias:
                fail(f"{project_label}.vault_refs keys must be stable slash-delimited aliases")
            if not isinstance(binding, dict):
                fail(f"{ref_label} must be an object")
            item = binding.get("item")
            field = binding.get("field")
            if not isinstance(item, str) or not item:
                fail(f"{ref_label}.item must be a non-empty string")
            if field not in ALLOWED_CREDENTIAL_SOURCE_FIELDS:
                fail(f"{ref_label}.field must be one of {sorted(ALLOWED_CREDENTIAL_SOURCE_FIELDS)}")


def validate_repo_access(bundle: dict, rel: Path) -> None:
    access = bundle.get("repo_access")
    if not isinstance(access, dict):
        fail(f"{rel}.repo_access must be an object")

    default_policy = access.get("default_policy")
    if default_policy not in ALLOWED_REPO_POLICIES:
        fail(f"{rel}.repo_access.default_policy must be one of {sorted(ALLOWED_REPO_POLICIES)}")

    workspace_root = access.get("task_workspace_root")
    if not isinstance(workspace_root, str) or not workspace_root.startswith("/"):
        fail(f"{rel}.repo_access.task_workspace_root must be an absolute path")

    cache_root = access.get("repo_cache_root")
    if not isinstance(cache_root, str) or not cache_root.startswith("/"):
        fail(f"{rel}.repo_access.repo_cache_root must be an absolute path")

    max_workspaces = access.get("max_concurrent_task_workspaces")
    if not isinstance(max_workspaces, int) or max_workspaces < 1:
        fail(f"{rel}.repo_access.max_concurrent_task_workspaces must be a positive integer")

    denied_repositories = access.get("denied_repositories", [])
    if not isinstance(denied_repositories, list):
        fail(f"{rel}.repo_access.denied_repositories must be a list")
    seen_denied = set()
    for index, repo in enumerate(denied_repositories):
        label = f"{rel}.repo_access.denied_repositories[{index}]"
        if not isinstance(repo, dict):
            fail(f"{label} must be an object")
        name = repo.get("name")
        if not isinstance(name, str) or not name:
            fail(f"{label}.name must be a non-empty string")
        if name in seen_denied:
            fail(f"{label}.name duplicates another denied repository")
        seen_denied.add(name)
        reason = repo.get("reason")
        if not isinstance(reason, str) or not reason:
            fail(f"{label}.reason must be a non-empty string")

    if default_policy == "allow":
        if "allowed_repositories" in access:
            fail(f"{rel}.repo_access.allowed_repositories must be removed when default_policy is allow")
        return

    repositories = access.get("allowed_repositories")
    if not isinstance(repositories, list) or not repositories:
        fail(f"{rel}.repo_access.allowed_repositories must be a non-empty list")
    if repositories == ["*"]:
        return
    if "*" in repositories:
        fail(f"{rel}.repo_access.allowed_repositories wildcard must be the only entry")

    seen_names = set()
    for index, repo in enumerate(repositories):
        label = f"{rel}.repo_access.allowed_repositories[{index}]"
        if not isinstance(repo, dict):
            fail(f"{label} must be an object")
        for field in (
            "name",
            "provider",
            "organization",
            "project",
            "repository",
            "url",
            "default_branch",
            "purpose",
            "default_verify_command",
            "cleanup_or_expiry",
        ):
            if not isinstance(repo.get(field), str) or not repo[field]:
                fail(f"{label}.{field} must be a non-empty string")
        name = repo["name"]
        if name in seen_names:
            fail(f"{label}.name duplicates another allowed repository")
        seen_names.add(name)
        checkout_mode = repo.get("checkout_mode")
        if checkout_mode not in ALLOWED_REPO_CHECKOUT_MODES:
            fail(f"{label}.checkout_mode must be one of {sorted(ALLOWED_REPO_CHECKOUT_MODES)}")
        if repo.get("provider") != "gitlab":
            fail(f"{label}.provider must be gitlab")
        if not repo["url"].startswith("https://gitlab.infuse-ai-tech.party/"):
            fail(f"{label}.url must be a company GitLab HTTPS URL")


def _find_patch_value(text: str, env_name: str, rel: Path) -> str:
    pattern = re.compile(
        rf"name:\s*{re.escape(env_name)}\n"
        r"(?:[^\n]*\n){0,4}?"
        r"\s*value:\s*(?P<value>.+)$",
        re.MULTILINE,
    )
    match = pattern.search(text)
    if not match:
        fail(f"{rel} is missing env var patch {env_name}")
    value = match.group("value").strip()
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1].replace("''", "'")
    if value.startswith('"') and value.endswith('"'):
        try:
            return json.loads(value)
        except json.JSONDecodeError as exc:
            fail(f"{rel} has invalid quoted value for {env_name}: {exc}")
    return value


def validate_workshop_runtime_config(config: dict, rel: Path) -> None:
    workshop = config.get("skills", {}).get("workshop")
    if not isinstance(workshop, dict):
        fail(f"{rel}.OPENCLAW_CONFIG_JSON skills.workshop must be an object")

    retired_keys = sorted({"approvalPolicy", "maxPending"}.intersection(workshop))
    if retired_keys:
        fail(
            f"{rel}.OPENCLAW_CONFIG_JSON skills.workshop contains retired keys "
            f"{retired_keys}; OpenClaw 2026.11.3 accepts only autonomous.mode"
        )

    autonomous = workshop.get("autonomous")
    mode = autonomous.get("mode") if isinstance(autonomous, dict) else None
    if mode not in {"off", "auto"}:
        fail(
            f"{rel}.OPENCLAW_CONFIG_JSON skills.workshop.autonomous.mode {mode!r} "
            "must be 'off' or 'auto' for OpenClaw 2026.11.3"
        )


def validate_active_runtime_patch(bundle: dict, rel: Path, installed: set[str]) -> None:
    if bundle.get("status") not in ACTIVE_STATUSES:
        return

    agent_id = bundle["agent_id"]
    patch_path = ROOT / "k8s" / "agents" / agent_id / "deployment.yaml"
    if not patch_path.exists():
        fail(f"{rel} is active but missing k8s/agents/{agent_id}/deployment.yaml")

    patch_rel = patch_path.relative_to(ROOT)
    text = patch_path.read_text(encoding="utf-8")

    agent_skills = _find_patch_value(text, "AGENT_SKILLS", patch_rel)
    runtime_skills = [item for item in agent_skills.split(",") if item]
    if set(runtime_skills) != installed:
        fail(
            f"{patch_rel}.AGENT_SKILLS does not match {rel}.skills.installed: "
            f"runtime={runtime_skills}, bundle={sorted(installed)}"
        )

    config_raw = _find_patch_value(text, "OPENCLAW_CONFIG_JSON", patch_rel)
    try:
        config = json.loads(config_raw)
    except json.JSONDecodeError as exc:
        fail(f"{patch_rel}.OPENCLAW_CONFIG_JSON is invalid JSON: {exc}")

    validate_workshop_runtime_config(config, patch_rel)

    agents_config = config.get("agents", {})
    agents = agents_config.get("list")
    if not isinstance(agents, list):
        entries = agents_config.get("entries")
        legacy_default_agents = []
        if isinstance(entries, dict):
            legacy_default_agents = sorted(
                agent_id
                for agent_id, agent_config in entries.items()
                if isinstance(agent_config, dict) and "default" in agent_config
            )
        if legacy_default_agents:
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON contains retired agent default "
                f"markers for {legacy_default_agents}; OpenClaw 2026.11.3 requires "
                "the marker to be removed after ownership migration"
            )
        agents = (
            [{"id": agent_key, **agent_value} for agent_key, agent_value in entries.items()]
            if isinstance(entries, dict)
            else None
        )
    if not isinstance(agents, list) or len(agents) != 1:
        fail(f"{patch_rel}.OPENCLAW_CONFIG_JSON must define exactly one agent")
    gateway_auth_mode = config.get("gateway", {}).get("auth", {}).get("mode")
    expected_gateway_auth_mode = "trusted-proxy" if agent_id in DASHBOARD_PROXY_AGENTS else "token"
    if gateway_auth_mode != expected_gateway_auth_mode:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON gateway.auth.mode {gateway_auth_mode!r} "
            f"must match the runtime gateway run --auth {expected_gateway_auth_mode} setting"
        )
    control_ui_origins = (
        config.get("gateway", {}).get("controlUi", {}).get("allowedOrigins")
    )
    dashboard_slug = agent_id.removeprefix("agent-")
    if not isinstance(control_ui_origins, list) or not any(
        f"openclaw-{dashboard_slug}.tailc4f8d5.ts.net" in str(origin)
        for origin in control_ui_origins
    ):
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON gateway.controlUi.allowedOrigins "
            f"must include the Tailscale dashboard hostname for {agent_id}"
        )
    trusted_proxies = config.get("gateway", {}).get("trustedProxies")
    if agent_id in DASHBOARD_PROXY_AGENTS:
        expected_auth = {
            "mode": "trusted-proxy",
            "password": {"source": "env", "provider": "default", "id": "OPENCLAW_GATEWAY_PASSWORD"},
            "identityScopes": {"aog.olea@gmail.com": ["operator.admin"]},
            "trustedProxy": {
                "userHeader": "x-forwarded-user",
                "requiredHeaders": ["x-forwarded-proto", "x-forwarded-host"],
                "allowUsers": ["aog.olea@gmail.com"],
                "deviceAutoApprove": {
                    "enabled": True,
                    "scopes": [
                        "operator.sessions.read",
                        "operator.sessions.write",
                        "operator.read",
                        "operator.write",
                    ],
                },
            },
        }
        if config.get("gateway", {}).get("auth") != expected_auth:
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON gateway.auth must preserve the "
                "reviewed Fito identity-admin, dashboard trusted-proxy and local-password contract"
            )
        if "roles" in config.get("gateway", {}):
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON gateway.roles must remain absent "
                "for identity-scoped gateway administration and self-only model accounts"
            )
        if trusted_proxies != [DASHBOARD_PROXY_SOURCE]:
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON gateway.trustedProxies "
                f"must contain only the approved dashboard ingress source "
                f"{DASHBOARD_PROXY_SOURCE!r}"
            )
        if DASHBOARD_PROXY_ORIGIN not in control_ui_origins:
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON gateway.controlUi.allowedOrigins "
                f"must include {DASHBOARD_PROXY_ORIGIN!r}"
            )
    elif (
        isinstance(trusted_proxies, list)
        and DASHBOARD_PROXY_SOURCE in trusted_proxies
    ) or DASHBOARD_PROXY_ORIGIN in control_ui_origins:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON central dashboard proxy trust is "
            "limited to agent-developer and agent-designer"
        )
    command_owners = config.get("commands", {}).get("ownerAllowFrom")
    if not isinstance(command_owners, list) or COMMAND_OWNER_ALLOW_FROM not in command_owners:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON commands.ownerAllowFrom must include "
            f"{COMMAND_OWNER_ALLOW_FROM!r}"
        )
    mattermost = config.get("channels", {}).get("mattermost")
    if not isinstance(mattermost, dict) or mattermost.get("enabled") is not True:
        fail(f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost must be enabled")
    expected_mattermost = {
        "replyToMode": "all",
        "dmPolicy": "allowlist",
        "groupPolicy": "open",
    }
    for key, expected in expected_mattermost.items():
        if mattermost.get(key) != expected:
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.{key} "
                f"{mattermost.get(key)!r} must be {expected!r}"
            )
    expected_chatmode = "onmessage" if agent_id == COORDINATOR_AGENT_ID else "oncall"
    if mattermost.get("chatmode") != expected_chatmode:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.chatmode "
            f"{mattermost.get('chatmode')!r} must be {expected_chatmode!r}"
        )
    streaming = mattermost.get("streaming", {})
    streaming_mode = streaming.get("mode")
    if agent_id == "agent-developer":
        expected_progress = {
            "label": "|",
            "toolProgress": True,
            "commandText": "status",
            "maxLines": 8,
            "maxLineChars": 120,
        }
        if streaming_mode != "progress" or streaming.get("progress") != expected_progress:
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.streaming "
                "must use the reviewed separate-progress pinned-runtime contract"
            )
    elif streaming_mode != "off":
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.streaming.mode "
            f"{streaming_mode!r} must be 'off' so non-canary group posts are final-only"
        )
    if "groupAllowFrom" in mattermost and agent_id != "agent-developer":
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.groupAllowFrom "
            "must not be set; Mattermost channel membership is the group boundary"
        )
    if "groups" in mattermost:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.groups must not "
            "be set; agents may respond in any Mattermost channel they are added to"
        )
    expected_require_mention = agent_id != COORDINATOR_AGENT_ID
    if mattermost.get("requireMention") is not expected_require_mention:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.requireMention "
            f"{mattermost.get('requireMention')!r} must be {expected_require_mention!r}"
        )
    if agent_id != COORDINATOR_AGENT_ID:
        expected_implicit_mentions = {
            "replyToBot": False,
            "quotedBot": False,
            "threadParticipation": False,
        }
        if mattermost.get("implicitMentions") != expected_implicit_mentions:
            fail(
                f"{patch_rel}.OPENCLAW_CONFIG_JSON channels.mattermost.implicitMentions "
                "must disable reply-to-bot, quoted-bot, and thread-participation wakes "
                "for mention-only specialists"
            )
    boot_script = _find_patch_value(text, "OPENCLAW_BOOT_SCRIPT", patch_rel)
    expected_boot_script = "/usr/local/bin/openclaw-agent-developer-canary-boot"
    if boot_script != expected_boot_script:
        fail(
            f"{patch_rel}.OPENCLAW_BOOT_SCRIPT must be {expected_boot_script!r} "
            "so pinned fleet startup preserves managed plugin provenance"
        )
    boot_script_source = (
        ROOT / "scripts" / "boot-agent-developer-canary.sh"
    ).read_text(encoding="utf-8")
    for marker in (
        "bootstrap_config=",
        "--auth trusted-proxy",
        'gateway run \\\n  --auth token \\\n  --token "$OPENCLAW_GATEWAY_TOKEN" \\\n  --bind lan \\\n  --port 18791',
        'printf \'%s\' "$canonical_config" >"$state_dir/openclaw.json"',
        'openclaw-agent-ensure-plugins "$profile"',
        'printf \'%s\' "$OPENCLAW_AUTH_PROFILES_JSON" >"$state_agent_dir/auth-profiles.json"',
        "unset OPENCLAW_CONFIG_JSON",
        "elif (.agents.list | type) == \"array\" then",
        ".agents.entries |= with_entries(.value |= del(.default))",
        ".messages.inbound.byChannel.mattermost = 1500",
        '.surfaces.mattermost.silentReply.group = "allow"',
        '.surfaces.mattermost.replyCompletion.group = "message-or-reaction"',
        ".channels.mattermost.textChunkLimit = 12000",
        ".channels.mattermost.actions.reactions = true",
        '.plugins.entries.codex.config.appServer.command = "/usr/local/bin/codex"',
        'label: "Thinking… please wait"',
        'finalDelivery: "separate"',
        'commandText: "raw"',
        "openclaw-2026.11.3-bundled-plugins-v1",
        '.plugin.origin == "bundled"',
        '.plugin.version == "2026.11.3"',
        "openclaw-agent-repair-legacy-invalid-session-rows",
        "openclaw-agent-migrate-schema-v27",
        "doctor --fix --non-interactive --yes",
        "automatic Doctor repair is disabled for this rollout",
        "doctor-2026.9.7-agent-schema-v24-v1",
        "doctor-2026.11.3-agent-schema-v27-v1",
        'retry_check "agent database schema v27" verify_agent_database_schema_v27',
        'database.prepare("PRAGMA user_version").get()',
        'sessions --agent "$agent_id" --limit 1 --json',
        "models status --json",
        'endswith("/openclaw-agent.sqlite")',
        'retry_check "Codex runtime verification"',
        'retry_check "exact bundled Mattermost runtime verification"',
        'retry_check "exact bundled ACPX runtime verification"',
        'retry_check "model credential status"',
    ):
        if marker not in boot_script_source:
            fail(
                "scripts/boot-agent-developer-canary.sh must preserve and verify "
                f"pinned fleet state; missing {marker!r}"
            )
    plugin_load = config.get("plugins", {}).get("load")
    if plugin_load:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON must not use plugins.load; "
            "the pinned Codex artifact must be installed into the managed extension store"
        )
    required_plugins = _find_patch_value(text, "OPENCLAW_REQUIRED_PLUGINS", patch_rel)
    consent_plugins = _find_patch_value(
        text, "OPENCLAW_CAPABILITY_CONSENT_PLUGINS", patch_rel
    )
    expected_plugins = {
        "/opt/openclaw-plugin-archives/behavioral-observability.tgz",
    }
    expected_consent = {"/opt/openclaw-plugin-archives/behavioral-observability.tgz"}
    if agent_id in {"agent-coordinator", "agent-developer"}:
        expected_plugins.add("/opt/openclaw-plugin-archives/infuse-studio.tgz")
        expected_consent.add("/opt/openclaw-plugin-archives/infuse-studio.tgz")
    if set(required_plugins.split()) != expected_plugins:
        fail(
            f"{patch_rel}.OPENCLAW_REQUIRED_PLUGINS must contain only the reviewed "
            f"local plugin payloads {sorted(expected_plugins)!r}; Core owns its bundled plugins"
        )
    if set(consent_plugins.split()) != expected_consent:
        raise ValueError(
            f"{patch_rel}.OPENCLAW_CAPABILITY_CONSENT_PLUGINS must scope consent "
            "to the reviewed plugins for this agent"
        )
    bundled_plugin_migrations = _find_patch_value(
        text, "OPENCLAW_BUNDLED_PLUGIN_MIGRATIONS", patch_rel
    )
    if set(bundled_plugin_migrations.split()) != {
        "codex",
        "mattermost",
        "acpx",
        "diagnostics-otel",
    }:
        fail(
            f"{patch_rel}.OPENCLAW_BUNDLED_PLUGIN_MIGRATIONS must migrate "
            "all stale managed shadows back to the exact trusted bundled runtimes"
        )
    if _find_patch_value(text, "OPENCLAW_DIAGNOSTICS_OTEL_CANARY", patch_rel) != "true":
        fail(
            f"{patch_rel}.OPENCLAW_DIAGNOSTICS_OTEL_CANARY must enable "
            "the fleet diagnostics contract"
        )
    if _find_patch_value(text, "OPENCLAW_BEHAVIORAL_OBSERVABILITY_CANARY", patch_rel) != "true":
        fail(
            f"{patch_rel}.OPENCLAW_BEHAVIORAL_OBSERVABILITY_CANARY must enable "
            "the fleet workflow telemetry contract"
        )
    for marker in (
        'endpoint: "http://openclaw-otel-collector:4318"',
        '--arg otel_service_name "${OTEL_SERVICE_NAME:-openclaw-$agent_id}"',
        "serviceName: $otel_service_name",
        "captureContent: false",
        '.plugins.entries["diagnostics-otel"].enabled = true',
        'retry_check "exact bundled diagnostics-otel runtime verification"',
    ):
        if marker not in boot_script_source:
            fail(
                "scripts/boot-agent-developer-canary.sh must preserve the "
                f"metadata-only diagnostics fleet contract; missing {marker!r}"
            )
    for marker in (
        '.plugins.entries["behavioral-observability"].enabled = true',
        '.plugins.entries["behavioral-observability"].hooks.allowConversationAccess = true',
        'retry_check "behavioral observability runtime verification"',
        'the behavioral observability canary requires $required_behavioral_observability_spec',
    ):
        if marker not in boot_script_source:
            fail(
                "scripts/boot-agent-developer-canary.sh must preserve the "
                f"bounded workflow telemetry fleet contract; missing {marker!r}"
            )
    if config.get("diagnostics") is not None:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON must leave diagnostics injection to the "
            "reviewed boot-time fleet gate"
        )
    runtime_agent = agents[0]
    if runtime_agent.get("id") != agent_id:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON agent id {runtime_agent.get('id')!r} "
            f"does not match {agent_id!r}"
        )
    friendly_name = bundle.get("friendly_name")
    if runtime_agent.get("name") != friendly_name:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON agent name {runtime_agent.get('name')!r} "
            f"does not match {rel}.friendly_name {friendly_name!r}"
        )
    config_skills = runtime_agent.get("skills")
    if not isinstance(config_skills, list) or set(config_skills) != installed:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON skills do not match {rel}.skills.installed: "
            f"runtime={config_skills}, bundle={sorted(installed)}"
        )
    default_workspace = config.get("agents", {}).get("defaults", {}).get("workspace")
    expected_workspace = f"/workspace/agents/{agent_id}"
    if default_workspace != expected_workspace:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON defaults.workspace {default_workspace!r} "
            f"does not match {expected_workspace!r}"
        )
    memory_search_enabled = config.get("memory", {}).get("search", {}).get("enabled")
    if memory_search_enabled is not False:
        fail(
            f"{patch_rel}.OPENCLAW_CONFIG_JSON memory.search.enabled "
            "must be false for persistent agents unless a dedicated semantic memory "
            "credential path is approved"
        )

    for item in bundle["credential_access"]["vaultwarden"]["allowed_items"]:
        target = item["sync_target"]
        if target["type"] not in {"kubernetes-secret-env", "kubernetes-secret-file"}:
            continue
        secret_name = target["name"]
        if secret_name not in text:
            fail(f"{patch_rel} does not reference declared credential target {secret_name!r}")


def check_catalog_paths(catalog: dict) -> None:
    for source_id, source in catalog["sources"].items():
        local_path = source.get("local_path")
        if not local_path:
            continue
        path = Path(local_path)
        if not path.is_absolute():
            path = ROOT / path
        if not path.exists():
            fail(f"source {source_id} local_path does not exist: {local_path}")


def validate_active_agent_inventory(active_agent_ids: list[str]) -> None:
    render_script = ROOT / "scripts" / "render.sh"
    infuseai_overlay = ROOT / "k8s" / "overlays" / "infuseai" / "kustomization.yaml"
    render_text = render_script.read_text(encoding="utf-8")
    overlay_text = infuseai_overlay.read_text(encoding="utf-8")

    for agent_id in active_agent_ids:
        if f"k8s/agents/{agent_id}" not in render_text:
            fail(f"scripts/render.sh does not render active agent {agent_id}")
        if f"../../agents/{agent_id}" not in overlay_text:
            fail(f"k8s/overlays/infuseai/kustomization.yaml does not include active agent {agent_id}")


def _shell_default(text: str, var_name: str) -> str:
    pattern = re.compile(
        rf'^{re.escape(var_name)}="\$\{{[^:}}]+:-(?P<value>.*)\}}"$',
        re.MULTILINE,
    )
    match = pattern.search(text)
    if not match:
        fail(f"{INTAKE_CRON_INSTALLER.relative_to(ROOT)} is missing default for {var_name}")
    return match.group("value")


def validate_agent_intake_cron_contract() -> None:
    rel = INTAKE_CRON_INSTALLER.relative_to(ROOT)
    text = INTAKE_CRON_INSTALLER.read_text(encoding="utf-8")

    for var_name, expected in EXPECTED_INTAKE_CRON_DEFAULTS.items():
        actual = _shell_default(text, var_name)
        if actual != expected:
            fail(f"{rel}.{var_name} default {actual!r} must be {expected!r}")

    expected_install_fragments = [
        '"$email_job_name"',
        '"$email_schedule"',
        '"$email_stagger"',
        '"$email_timeout_seconds"',
        '"cron:agent-intake:consulting-email-triage"',
        '"$email_prompt_file"',
        "true",
        'install_prefilter_job',
        '"$reminder_job_name"',
        '"$reminder_schedule"',
        '"$reminder_stagger"',
        '"$reminder_timeout_seconds"',
        '"cron:agent-intake:client-waiting-reminders"',
        '"$reminder_prompt_file"',
        '"$reminder_disabled"',
    ]
    for fragment in expected_install_fragments:
        if fragment not in text:
            fail(f"{rel} is missing expected intake cron installer fragment {fragment!r}")

    expected_state_check = [
        ".email_disabled == 1",
        ".prefilter_state_ok == 1",
        ".reminder_state_ok == 1",
    ]
    for fragment in expected_state_check:
        if fragment not in text:
            fail(f"{rel} must verify repo-managed intake cron state with {fragment!r}")


def main() -> int:
    catalog = load_json(CATALOG_PATH)
    validate_catalog(catalog)
    checked_source_catalogs = validate_available_source_catalogs(catalog)

    bundle_paths = sorted(BUNDLE_DIR.glob("*.json"))
    if not bundle_paths:
        fail("no agent skill bundles found")
    active_agent_ids = []
    for path in bundle_paths:
        validate_bundle(path, catalog)
        bundle = load_json(path)
        if bundle.get("status") in ACTIVE_STATUSES:
            active_agent_ids.append(bundle["agent_id"])

    validate_active_agent_inventory(sorted(active_agent_ids))
    validate_agent_intake_cron_contract()

    if os.environ.get("CHECK_SKILL_PATHS") == "true":
        check_catalog_paths(catalog)

    print(
        f"Verified {len(bundle_paths)} agent skill bundle(s) and "
        f"{checked_source_catalogs} available source catalog(s)."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
