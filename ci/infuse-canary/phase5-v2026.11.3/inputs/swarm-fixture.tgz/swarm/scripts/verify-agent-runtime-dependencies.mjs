// Inspect installed package metadata and Go build receipts without loading the
// runtime or contacting a service. This gate supplements the complete scan.
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

export function atLeast(actual, minimum) {
  const parse = (value) => {
    const match = /^(?:v|go)?(\d+)\.(\d+)\.(\d+)$/.exec(value);
    if (!match) throw new Error(`Expected stable version, got ${value}`);
    return match.slice(1).map(Number);
  };
  const a = parse(actual), b = parse(minimum);
  for (let i = 0; i < 3; i++) {
    if (a[i] !== b[i]) return a[i] > b[i];
  }
  return true;
}

export function nodeFloor(name, version) {
  if (typeof version !== "string") return false;
  const floors = {
    "@modelcontextprotocol/sdk": { 1: "1.32.0" },
    "body-parser": { 2: "2.4.0" },
    "brace-expansion": { 5: "5.0.11" },
    "undici": { 6: "6.29.1", 7: "7.30.1", 8: "8.12.2" },
    "multer": { 2: "2.5.0" },
  };
  const minimum = floors[name]?.[version.split(".")[0]];
  return Boolean(minimum && atLeast(version, minimum));
}

export function readInstalledPackage(consumer, name) {
  const require = createRequire(path.join(consumer, "package.json"));
  // Some export maps resolve package.json to a dist/cjs metadata stub. Walk
  // upward from the resolved package, retaining the actual resolution owner.
  let directory = path.dirname(require.resolve(`${name}/package.json`));
  while (directory !== path.dirname(directory)) {
    const file = path.join(directory, "package.json");
    if (fs.existsSync(file)) {
      const metadata = JSON.parse(fs.readFileSync(file, "utf8"));
      if (metadata.name === name && typeof metadata.version === "string") return { file, metadata };
    }
    directory = path.dirname(directory);
  }
  throw new Error(`Missing installed metadata for ${name} from ${consumer}`);
}

export function verifyGoReceipt(tool, text) {
  const compiler = /:\s+(go\d+\.\d+\.\d+)\s*$/.exec(text.split("\n")[0])?.[1];
  if (!compiler || !atLeast(compiler, "go1.27.4")) {
    throw new Error(`${tool}: missing or outdated Go compiler ${compiler}`);
  }
  const modules = new Map([...text.matchAll(/^\s+dep\s+(\S+)\s+(v\S+)/gm)].map((m) => [m[1], m[2]]));
  const required = {
    task: ["golang.org/x/net", "github.com/go-jose/go-jose/v4"],
    kubectl: ["golang.org/x/net", "golang.org/x/text"],
    kustomize: ["golang.org/x/text"],
    helm: ["golang.org/x/net"], gog: ["golang.org/x/net"],
    "docker-compose": ["golang.org/x/net"], docker: [], crane: [],
  };
  const floors = { "golang.org/x/net": "v0.62.0", "golang.org/x/text": "v0.41.0", "github.com/go-jose/go-jose/v4": "v4.1.6" };
  if (!Object.hasOwn(required, tool)) throw new Error(`Unexpected Go tool ${tool}`);
  for (const name of required[tool]) {
    if (!modules.has(name)) throw new Error(`${tool}: missing expected module ${name}`);
  }
  for (const [name, floor] of Object.entries(floors)) {
    if (modules.has(name) && !atLeast(modules.get(name), floor)) {
      throw new Error(`${tool}: outdated ${name} ${modules.get(name)}`);
    }
  }
  return { tool, compiler, modules: Object.fromEntries([...modules].filter(([name]) => Object.hasOwn(floors, name))) };
}

export function verifyInstalled(root = "/") {
  const resolveRoot = (relative) => path.join(root, relative);
  const checks = [
    ["opt/openclaw-consumer/node_modules/openclaw", "@modelcontextprotocol/sdk"],
    ["opt/openclaw-consumer/node_modules/express", "body-parser"],
    ["opt/openclaw-consumer/node_modules/openclaw", "undici"],
    ["opt/openclaw-consumer/node_modules/npm", "brace-expansion"],
    ["opt/openclaw-consumer/node_modules/npm", "undici"],
    ["usr/local/lib/node_modules/npm", "brace-expansion"],
    ["usr/local/lib/node_modules/npm", "undici"],
    ["usr/local/lib/node_modules/pnpm/dist", "undici"],
    ["usr/local/lib/node_modules/@bitwarden/cli", "multer"],
  ];
  const packages = checks.map(([consumer, name]) => {
    const { file, metadata } = readInstalledPackage(resolveRoot(consumer), name);
    if (metadata.name !== name || !nodeFloor(name, metadata.version)) {
      throw new Error(`${file}: vulnerable or unreviewed ${name} ${metadata.version}`);
    }
    return { consumer, name, version: metadata.version, file };
  });
  const go = ["task", "kubectl", "kustomize", "helm", "docker", "docker-compose", "gog", "crane"].map((tool) =>
    verifyGoReceipt(tool, fs.readFileSync(resolveRoot(`usr/local/share/agent-go-build-info/${tool}.txt`), "utf8")));
  return { packages, go };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  if (process.argv.length > 3) throw new Error("Usage: verify-agent-runtime-dependencies.mjs [image-root]");
  console.log(JSON.stringify(verifyInstalled(process.argv[2] ?? "/"), null, 2));
}
