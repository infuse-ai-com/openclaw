#!/usr/bin/env bash
set -euo pipefail
helper=/opt/openclaw-memory-mirror/refresh-shared-agent-memory.py
if [[ ! -f "$helper" ]]; then
  helper="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/refresh-shared-agent-memory.py"
fi
exec python3 "$helper" --startup "$@"
