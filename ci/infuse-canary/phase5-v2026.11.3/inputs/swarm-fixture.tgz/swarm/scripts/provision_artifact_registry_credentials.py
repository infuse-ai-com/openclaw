#!/usr/bin/env python3
"""Provision canonical Artifact Registry credentials without exposing token values."""

from __future__ import annotations

import argparse
import base64
import copy
from dataclasses import dataclass
from datetime import date
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import time
from typing import Any


SERVICE_URL = "http://backoffice-artifact-registry.core.svc.cluster.local:3010"
ORG_NAME = "Infuse AI"
SERVER_SECRET = "backoffice-artifact-registry-auth"
REGISTRY_DEPLOYMENT = "backoffice-artifact-registry"
CANARY_CLIENT_SECRET = "artifact-registry-canary-client"
BACKOFFICE_CLIENT_SECRET = "backoffice-artifact-registry-client"
STUDIO_CLIENT_SECRET = "studio-artifact-registry"
STUDIO_IMAGE_SECRET = "studio-whiteboard-upload"
EXPECTED_KUBE_USER = (
    "system:serviceaccount:platform-operators:kapiteky-cluster-operator"
)
LEGACY_EXPECTED_KUBE_USER = "system:serviceaccount:oleagut:kapiteky-cluster-operator"


@dataclass(frozen=True)
class Producer:
    producer: str
    subject: str
    item_name: str
    collection: str | None
    secret_name: str


@dataclass(frozen=True)
class ServiceClient:
    key: str
    subject: str
    item_name: str
    collection: str
    scope: str


PRODUCERS = (
    Producer("kapiteky", "Kapiteky", "Artifact Registry / kapiteky producer token", None, "artifact-registry-kapiteky"),
    Producer("agent-coordinator", "Emon Lusk", "Artifact Registry / agent-coordinator producer token", "51-Agent-Emon-Lusk", "artifact-registry-agent-coordinator"),
    Producer("agent-designer", "Stewie Hobs", "Artifact Registry / agent-designer producer token", "52-Agent-Stewie-Hobs", "artifact-registry-agent-designer"),
    Producer("agent-developer", "Tinus Lordvals", "Artifact Registry / agent-developer producer token", "53-Agent-Tinus-Lordvals", "artifact-registry-agent-developer"),
    Producer("agent-infra", "Satwa Nutella", "Artifact Registry / agent-infra producer token", "54-Agent-Satwa-Nutella", "artifact-registry-agent-infra"),
    Producer("agent-intake", "Ramiro Garcia", "Artifact Registry / agent-intake producer token", "55-Agent-Ramiro-Garcia", "artifact-registry-agent-intake"),
)

STUDIO_CLIENT = ServiceClient(
    "studio-reader", "Studio Artifact Registry reader",
    "Artifact Registry / Studio reader token", "07-Project-Backoffice",
    "read",
)

STUDIO_IMAGE_CLIENT = ServiceClient(
    "studio-image-upload", "Studio whiteboard image uploader",
    "Artifact Registry / Studio image upload token", "07-Project-Backoffice",
    "image-upload",
)

SERVICE_CLIENTS = (
    ServiceClient(
        "reader",
        "Backoffice Artifact Registry reader",
        "Artifact Registry / Backoffice reader token",
        "07-Project-Backoffice",
        "read",
    ),
    ServiceClient(
        "lifecycle",
        "Backoffice Artifact Registry lifecycle",
        "Artifact Registry / Backoffice lifecycle token",
        "07-Project-Backoffice",
        "lifecycle",
    ),
    STUDIO_CLIENT,
    STUDIO_IMAGE_CLIENT,
)


class ProvisioningError(RuntimeError):
    pass


def run_checked(command: list[str], *, input_text: str | None = None, label: str) -> str:
    result = subprocess.run(
        command,
        input=input_text,
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise ProvisioningError(f"{label} failed with exit code {result.returncode}")
    return result.stdout


def run_bw(helper: str, arguments: list[str], *, input_text: str | None = None, label: str) -> str:
    return run_checked([helper, *arguments], input_text=input_text, label=label)


def exact_named(items: list[dict[str, Any]], name: str) -> dict[str, Any] | None:
    matches = [item for item in items if item.get("name") == name]
    if len(matches) > 1:
        raise ProvisioningError(f"Vaultwarden contains duplicate exact items named {name}")
    return matches[0] if matches else None


def valid_token(value: Any) -> str:
    if not isinstance(value, str) or not 32 <= len(value) <= 512 or any(character.isspace() for character in value):
        raise ProvisioningError("a producer credential is missing or malformed")
    return value


def create_item(
    helper: str,
    producer: Producer,
    token: str,
    organization_id: str,
    collection_ids: dict[str, str],
) -> None:
    template = json.loads(run_bw(helper, ["get", "template", "item"], label="Vaultwarden item template lookup"))
    template.update({
        "type": 1,
        "name": producer.item_name,
        "notes": (
            "Producer-bound Backoffice Artifact Registry credential. "
            f"Producer: {producer.producer}. Issued: {date.today().isoformat()}. "
            "Rotation and Kubernetes sync are governed by the Artifact Registry runbook."
        ),
        "favorite": False,
        "fields": [],
        "login": {
            "username": producer.producer,
            "password": token,
            "totp": None,
            "uris": [{"uri": SERVICE_URL, "match": None}],
        },
    })
    if producer.collection is None:
        template["organizationId"] = None
        template["collectionIds"] = []
    else:
        template["organizationId"] = organization_id
        template["collectionIds"] = [collection_ids[producer.collection]]
    encoded = run_bw(helper, ["encode"], input_text=json.dumps(template), label="Vaultwarden item encoding").strip()
    if not encoded:
        raise ProvisioningError("Vaultwarden item encoding returned no data")
    run_bw(helper, ["create", "item"], input_text=encoded, label=f"Vaultwarden create {producer.item_name}")


def create_service_client_item(
    helper: str,
    client: ServiceClient,
    token: str,
    organization_id: str,
    collection_id: str,
) -> None:
    template = json.loads(run_bw(helper, ["get", "template", "item"], label="Vaultwarden item template lookup"))
    template.update({
        "type": 1,
        "name": client.item_name,
        "notes": (
            "Backoffice Artifact Registry service credential. "
            f"Scope: {client.scope}. Issued: {date.today().isoformat()}. "
            "Rotation and Kubernetes sync are governed by the Artifact Registry runbook."
        ),
        "favorite": False,
        "fields": [],
        "organizationId": organization_id,
        "collectionIds": [collection_id],
        "login": {
            "username": client.key,
            "password": token,
            "totp": None,
            "uris": [{"uri": SERVICE_URL, "match": None}],
        },
    })
    encoded = run_bw(helper, ["encode"], input_text=json.dumps(template), label="Vaultwarden item encoding").strip()
    if not encoded:
        raise ProvisioningError("Vaultwarden item encoding returned no data")
    run_bw(helper, ["create", "item"], input_text=encoded, label=f"Vaultwarden create {client.item_name}")


def load_or_create_tokens(helper: str) -> dict[str, str]:
    run_bw(helper, ["sync"], label="Vaultwarden sync")
    organizations = json.loads(run_bw(helper, ["list", "organizations"], label="Vaultwarden organization lookup"))
    organization = exact_named(organizations, ORG_NAME)
    if not organization or not isinstance(organization.get("id"), str):
        raise ProvisioningError(f"Vaultwarden organization {ORG_NAME} is unavailable")
    organization_id = organization["id"]
    collections = json.loads(run_bw(helper, ["list", "collections"], label="Vaultwarden collection lookup"))
    collection_ids = {
        item["name"]: item["id"]
        for item in collections
        if isinstance(item.get("name"), str) and isinstance(item.get("id"), str)
    }
    required_collections = {producer.collection for producer in PRODUCERS if producer.collection}
    missing = sorted(required_collections - collection_ids.keys())
    if missing:
        raise ProvisioningError(f"required Vaultwarden collections are missing: {', '.join(missing)}")

    tokens: dict[str, str] = {}
    for producer in PRODUCERS:
        found = json.loads(run_bw(
            helper,
            ["list", "items", "--search", producer.item_name],
            label=f"Vaultwarden lookup {producer.item_name}",
        ))
        item = exact_named(found, producer.item_name)
        if item is None:
            create_item(helper, producer, secrets.token_urlsafe(48), organization_id, collection_ids)
            run_bw(helper, ["sync"], label="Vaultwarden post-create sync")
            found = json.loads(run_bw(
                helper,
                ["list", "items", "--search", producer.item_name],
                label=f"Vaultwarden re-read {producer.item_name}",
            ))
            item = exact_named(found, producer.item_name)
        if item is None:
            raise ProvisioningError(f"Vaultwarden item {producer.item_name} was not created")
        expected_org = None if producer.collection is None else organization_id
        if item.get("organizationId") != expected_org:
            raise ProvisioningError(f"Vaultwarden item {producer.item_name} is in the wrong organization scope")
        if producer.collection is not None and set(item.get("collectionIds") or []) != {collection_ids[producer.collection]}:
            raise ProvisioningError(f"Vaultwarden item {producer.item_name} is outside its exact agent collection")
        tokens[producer.producer] = valid_token((item.get("login") or {}).get("password"))
    if len(set(tokens.values())) != len(PRODUCERS):
        raise ProvisioningError("producer credentials are not unique")
    return tokens


def load_or_create_service_client_tokens(
    helper: str, clients: tuple[ServiceClient, ...] = SERVICE_CLIENTS,
) -> dict[str, str]:
    run_bw(helper, ["sync"], label="Vaultwarden sync")
    organizations = json.loads(run_bw(helper, ["list", "organizations"], label="Vaultwarden organization lookup"))
    organization = exact_named(organizations, ORG_NAME)
    if not organization or not isinstance(organization.get("id"), str):
        raise ProvisioningError(f"Vaultwarden organization {ORG_NAME} is unavailable")
    organization_id = organization["id"]
    collections = json.loads(run_bw(helper, ["list", "collections"], label="Vaultwarden collection lookup"))
    collection_ids = {
        item["name"]: item["id"]
        for item in collections
        if isinstance(item.get("name"), str) and isinstance(item.get("id"), str)
    }
    missing = sorted({client.collection for client in clients} - collection_ids.keys())
    if missing:
        raise ProvisioningError(f"required Vaultwarden collections are missing: {', '.join(missing)}")

    tokens: dict[str, str] = {}
    for client in clients:
        found = json.loads(run_bw(
            helper,
            ["list", "items", "--search", client.item_name],
            label=f"Vaultwarden lookup {client.item_name}",
        ))
        item = exact_named(found, client.item_name)
        if item is None:
            create_service_client_item(
                helper,
                client,
                secrets.token_urlsafe(48),
                organization_id,
                collection_ids[client.collection],
            )
            run_bw(helper, ["sync"], label="Vaultwarden post-create sync")
            found = json.loads(run_bw(
                helper,
                ["list", "items", "--search", client.item_name],
                label=f"Vaultwarden re-read {client.item_name}",
            ))
            item = exact_named(found, client.item_name)
        if item is None:
            raise ProvisioningError(f"Vaultwarden item {client.item_name} was not created")
        if item.get("organizationId") != organization_id:
            raise ProvisioningError(f"Vaultwarden item {client.item_name} is in the wrong organization scope")
        if set(item.get("collectionIds") or []) != {collection_ids[client.collection]}:
            raise ProvisioningError(f"Vaultwarden item {client.item_name} is outside its exact registry-owner collection")
        tokens[client.key] = valid_token((item.get("login") or {}).get("password"))
    if len(set(tokens.values())) != len(clients):
        raise ProvisioningError("Artifact Registry service credentials are not unique")
    return tokens


def build_server_auth(
    producer_tokens: dict[str, str],
    *,
    reader_token: str | None = None,
    lifecycle_token: str | None = None,
    studio_token: str | None = None,
    studio_image_token: str | None = None,
    overlap_principals: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    supplied = [*producer_tokens.values(), *[v for v in (reader_token, lifecycle_token, studio_token, studio_image_token) if v is not None]]
    if len(set(supplied)) != len(supplied):
        raise ProvisioningError("registry credentials are not unique")
    principals: dict[str, dict[str, Any]] = {}
    for producer in PRODUCERS:
        token = valid_token(producer_tokens[producer.producer])
        principals[hashlib.sha256(token.encode("utf-8")).hexdigest()] = {
            "subject": producer.subject,
            "producer": producer.producer,
            "scopes": ["read", "write"],
        }
    if reader_token is not None:
        principals[hashlib.sha256(valid_token(reader_token).encode("utf-8")).hexdigest()] = {
            "subject": "Backoffice Artifact Registry reader",
            "scopes": ["read"],
        }
    if lifecycle_token is not None:
        principals[hashlib.sha256(valid_token(lifecycle_token).encode("utf-8")).hexdigest()] = {
            "subject": "Backoffice Artifact Registry lifecycle",
            "scopes": ["lifecycle"],
        }
    if studio_token is not None:
        digest = hashlib.sha256(valid_token(studio_token).encode()).hexdigest()
        if digest in principals:
            raise ProvisioningError("Studio credential collides with another principal")
        principals[digest] = {"subject": STUDIO_CLIENT.subject, "scopes": ["read"]}
    if studio_image_token is not None:
        principals[hashlib.sha256(valid_token(studio_image_token).encode()).hexdigest()] = {
            "subject": STUDIO_IMAGE_CLIENT.subject, "scopes": ["image-upload"],
            "producer": "studio-whiteboard", "studioFloors": True,
        }
    for principal in overlap_principals or []:
        token = valid_token(principal.get("token"))
        authorization = {
            "subject": principal["subject"],
            "scopes": principal["scopes"],
        }
        if principal.get("producer") is not None:
            authorization["producer"] = principal["producer"]
        if principal.get("project") is not None:
            authorization["project"] = principal["project"]
        if principal.get("studioFloors") is not None:
            authorization["studioFloors"] = principal["studioFloors"]
        principals[hashlib.sha256(token.encode("utf-8")).hexdigest()] = authorization
    return {"schema": "infuse.artifact-auth/v1", "principals": principals}


def lookup_item(helper: str, item_name: str) -> dict[str, Any]:
    found = json.loads(run_bw(
        helper,
        ["list", "items", "--search", item_name],
        label=f"Vaultwarden lookup {item_name}",
    ))
    item = exact_named(found, item_name)
    if item is None or not isinstance(item.get("id"), str):
        raise ProvisioningError(f"Vaultwarden item {item_name} is unavailable")
    return item


def replace_item_password(helper: str, item: dict[str, Any], token: str) -> None:
    updated = json.loads(json.dumps(item))
    login = updated.get("login")
    if not isinstance(login, dict):
        raise ProvisioningError("Vaultwarden credential item is not a Login item")
    login["password"] = valid_token(token)
    encoded = run_bw(
        helper,
        ["encode"],
        input_text=json.dumps(updated),
        label="Vaultwarden rotation item encoding",
    ).strip()
    if not encoded:
        raise ProvisioningError("Vaultwarden rotation item encoding returned no data")
    run_bw(
        helper,
        ["edit", "item", item["id"]],
        input_text=encoded,
        label=f"Vaultwarden rotate {item['name']}",
    )


def rotation_target(name: str) -> tuple[Producer | None, ServiceClient | None]:
    producer = next((candidate for candidate in PRODUCERS if candidate.producer == name), None)
    client = next((candidate for candidate in SERVICE_CLIENTS if candidate.key == name), None)
    if producer is None and client is None:
        allowed = sorted([candidate.producer for candidate in PRODUCERS] + [candidate.key for candidate in SERVICE_CLIENTS])
        raise ProvisioningError(f"unknown rotation principal; choose one of: {', '.join(allowed)}")
    return producer, client


def rotate_one(
    *,
    helper: str,
    context: str,
    core_namespace: str,
    agent_namespace: str,
    principal_name: str,
    producer_tokens: dict[str, str],
    service_tokens: dict[str, str],
) -> dict[str, Any]:
    producer, client = rotation_target(principal_name)
    replacement = secrets.token_urlsafe(48)
    if replacement in set(producer_tokens.values()) | set(service_tokens.values()):
        raise ProvisioningError("generated replacement credential is not unique")

    if producer is not None:
        item = lookup_item(helper, producer.item_name)
        previous = producer_tokens[producer.producer]
        overlap = [{
            "subject": producer.subject,
            "producer": producer.producer,
            "scopes": ["read", "write"],
            "token": replacement,
        }]
        client_resource = opaque_secret(agent_namespace, producer.secret_name, {"token": replacement})
        workload = producer.producer if producer.producer != "kapiteky" else None
    else:
        assert client is not None
        item = lookup_item(helper, client.item_name)
        previous = service_tokens[client.key]
        overlap = [{
            "subject": client.subject,
            "scopes": [client.scope],
            "token": replacement,
        }]
        if client == STUDIO_IMAGE_CLIENT:
            overlap[0].update(producer="studio-whiteboard", studioFloors=True)
        rotated_clients = dict(service_tokens)
        rotated_clients[client.key] = replacement
        if client in (STUDIO_CLIENT, STUDIO_IMAGE_CLIENT):
            secret_name = STUDIO_CLIENT_SECRET if client == STUDIO_CLIENT else STUDIO_IMAGE_SECRET
            client_resource = opaque_secret(core_namespace, secret_name, {"token": replacement})
            workload = "studio"
        else:
            client_resource = opaque_secret(core_namespace, BACKOFFICE_CLIENT_SECRET, {
                "reader": rotated_clients["reader"],
                "lifecycle": rotated_clients["lifecycle"],
            })
            workload = "backoffice"

    server_resource = opaque_secret(core_namespace, SERVER_SECRET, {
        "auth.json": json.dumps(
            build_server_auth(
                producer_tokens,
                reader_token=service_tokens["reader"],
                lifecycle_token=service_tokens["lifecycle"],
                studio_token=service_tokens.get("studio-reader"),
                studio_image_token=service_tokens.get("studio-image-upload"),
                overlap_principals=overlap,
            ),
            sort_keys=True,
            separators=(",", ":"),
        ),
    })

    apply_resources(context, [server_resource])
    wait_for_server_auth_projection(context, core_namespace, server_resource)
    vault_updated = False
    try:
        replace_item_password(helper, item, replacement)
        vault_updated = True
        run_bw(helper, ["sync"], label="Vaultwarden post-rotation sync")
        apply_resources(context, [client_resource])
    except ProvisioningError as error:
        rollback_errors: list[str] = []
        if vault_updated:
            try:
                replace_item_password(helper, item, previous)
                run_bw(helper, ["sync"], label="Vaultwarden rollback sync")
            except ProvisioningError:
                rollback_errors.append("Vaultwarden")
        try:
            rollback_resources = build_secret_resources(
                producer_tokens,
                core_namespace=core_namespace,
                agent_namespace=agent_namespace,
                reader_token=service_tokens["reader"],
                lifecycle_token=service_tokens["lifecycle"],
                studio_token=service_tokens.get("studio-reader"),
                studio_image_token=service_tokens.get("studio-image-upload"),
                client_secret_name=BACKOFFICE_CLIENT_SECRET,
            )
            apply_resources(context, rollback_resources)
            rollback_server = next(
                resource for resource in rollback_resources
                if resource["metadata"]["name"] == SERVER_SECRET
            )
            wait_for_server_auth_projection(context, core_namespace, rollback_server)
        except ProvisioningError:
            rollback_errors.append("Kubernetes")
        if rollback_errors:
            raise ProvisioningError(
                "rotation failed and rollback was incomplete for: " + ", ".join(rollback_errors)
            ) from error
        raise

    return {
        "status": "overlap-active",
        "principal": principal_name,
        "vaultItem": item["name"],
        "serverSecret": SERVER_SECRET,
        "clientSecret": client_resource["metadata"]["name"],
        "workloadToVerify": workload,
        "nextAction": "verify the rotated client, then run finalize before the next rotation",
    }


def opaque_secret(namespace: str, name: str, string_data: dict[str, str]) -> dict[str, Any]:
    return {
        "apiVersion": "v1",
        "kind": "Secret",
        "metadata": {
            "name": name,
            "namespace": namespace,
            "labels": {
                "app.kubernetes.io/part-of": "backoffice",
                "app.kubernetes.io/managed-by": "artifact-registry-credential-provisioner",
                "infuse.ai/artifact-registry-rollout": "canonical-v1",
            },
        },
        "type": "Opaque",
        "stringData": string_data,
    }


def build_secret_resources(
    producer_tokens: dict[str, str],
    *,
    core_namespace: str,
    agent_namespace: str,
    reader_token: str | None = None,
    lifecycle_token: str | None = None,
    studio_token: str | None = None,
    studio_image_token: str | None = None,
    client_secret_name: str = CANARY_CLIENT_SECRET,
) -> list[dict[str, Any]]:
    resources = [
        opaque_secret(agent_namespace, producer.secret_name, {"token": valid_token(producer_tokens[producer.producer])})
        for producer in PRODUCERS
    ]
    resources.append(opaque_secret(core_namespace, SERVER_SECRET, {
        "auth.json": json.dumps(
            build_server_auth(producer_tokens, reader_token=reader_token, lifecycle_token=lifecycle_token, studio_token=studio_token, studio_image_token=studio_image_token),
            sort_keys=True,
            separators=(",", ":"),
        ),
    }))
    if reader_token is not None and lifecycle_token is not None:
        client_namespace = core_namespace if client_secret_name == BACKOFFICE_CLIENT_SECRET else agent_namespace
        resources.append(opaque_secret(client_namespace, client_secret_name, {
            "reader": valid_token(reader_token),
            "lifecycle": valid_token(lifecycle_token),
        }))
    if studio_token is not None:
        resources.append(opaque_secret(core_namespace, STUDIO_CLIENT_SECRET, {"token": valid_token(studio_token)}))
    if studio_image_token is not None:
        resources.append(opaque_secret(core_namespace, STUDIO_IMAGE_SECRET, {"token": valid_token(studio_image_token)}))
    return resources


def kube_json(context: str, arguments: list[str], *, label: str) -> Any:
    return json.loads(run_checked(["kubectl", "--context", context, *arguments, "-o", "json"], label=label))


def preflight_kubernetes(context: str, core_namespace: str, agent_namespace: str | None) -> None:
    identity = kube_json(context, ["auth", "whoami"], label="Kubernetes identity preflight")
    username = identity.get("status", {}).get("userInfo", {}).get("username")
    if username not in {EXPECTED_KUBE_USER, LEGACY_EXPECTED_KUBE_USER}:
        raise ProvisioningError(f"unexpected Kubernetes identity: {username or 'unknown'}")
    for namespace in dict.fromkeys(n for n in (core_namespace, agent_namespace) if n):
        for verb in ("create", "patch"):
            allowed = run_checked(
                ["kubectl", "--context", context, "auth", "can-i", verb, "secrets", "-n", namespace],
                label=f"Kubernetes {verb} Secret authorization in {namespace}",
            ).strip()
            if allowed != "yes":
                raise ProvisioningError(f"Kubernetes identity cannot {verb} Secrets in {namespace}")
    exec_allowed = run_checked(
        ["kubectl", "--context", context, "auth", "can-i", "create", "pods/exec", "-n", core_namespace],
        label=f"Kubernetes pod exec authorization in {core_namespace}",
    ).strip()
    if exec_allowed != "yes":
        raise ProvisioningError(f"Kubernetes identity cannot create pods/exec in {core_namespace}")


def apply_resources(context: str, resources: list[dict[str, Any]]) -> None:
    manifest = json.dumps({"apiVersion": "v1", "kind": "List", "items": resources})
    run_checked(
        [
            "kubectl", "--context", context, "apply", "--server-side",
            "--field-manager=artifact-registry-credential-provisioner", "-f", "-",
        ],
        input_text=manifest,
        label="Kubernetes Artifact Registry Secret apply",
    )


def server_auth_body(resource: dict[str, Any]) -> str:
    if resource.get("metadata", {}).get("name") != SERVER_SECRET:
        raise ProvisioningError("server auth projection requires the exact server Secret")
    body = resource.get("stringData", {}).get("auth.json")
    if not isinstance(body, str):
        raise ProvisioningError("server auth Secret has no auth.json body")
    return body


def wait_for_server_auth_projection(
    context: str,
    namespace: str,
    server_resource: dict[str, Any],
    *,
    attempts: int = 60,
) -> None:
    expected_digest = hashlib.sha256(server_auth_body(server_resource).encode("utf-8")).hexdigest()
    command = [
        "kubectl", "--context", context, "-n", namespace,
        "exec", f"deployment/{REGISTRY_DEPLOYMENT}", "-c", "registry", "--",
        "node", "-e",
        (
            "const fs=require('fs'),c=require('crypto');"
            "const b=fs.readFileSync('/var/run/artifact-registry-auth/auth.json');"
            "process.stdout.write(c.createHash('sha256').update(b).digest('hex'))"
        ),
    ]
    for attempt in range(attempts):
        observed = run_checked(command, label="Artifact Registry server auth projection").strip()
        if observed == expected_digest:
            return
        if attempt + 1 < attempts:
            time.sleep(2)
    raise ProvisioningError("Artifact Registry server auth projection did not converge")


def delete_canary_client(context: str, namespace: str) -> None:
    run_checked(
        ["kubectl", "--context", context, "-n", namespace, "delete", "secret", CANARY_CLIENT_SECRET, "--ignore-not-found"],
        label="Kubernetes canary client Secret cleanup",
    )


def add_studio_reader(auth: dict[str, Any], token: str, *, image_upload: bool = False, migrate_studio_floors: bool = False) -> dict[str, Any]:
    """Preserve every existing principal; refuse credential or scope drift."""
    if not isinstance(auth, dict) or auth.get("schema") != "infuse.artifact-auth/v1" or not isinstance(auth.get("principals"), dict):
        raise ProvisioningError("unexpected registry authorization schema")
    result = copy.deepcopy(auth)
    digest = hashlib.sha256(valid_token(token).encode()).hexdigest()
    client = STUDIO_IMAGE_CLIENT if image_upload else STUDIO_CLIENT
    expected = {"subject": client.subject, "scopes": [client.scope]}
    if image_upload:
        expected.update(producer="studio-whiteboard", studioFloors=True)
    legacy = {"subject": STUDIO_IMAGE_CLIENT.subject, "scopes": ["image-upload"], "producer": "studio-whiteboard", "project": "studio"}
    if migrate_studio_floors and not image_upload:
        raise ProvisioningError("Floor image migration requires the dedicated image client")
    for key, principal in auth["principals"].items():
        if migrate_studio_floors and key == digest and principal == legacy:
            continue
        if not isinstance(principal, dict):
            raise ProvisioningError("unexpected registry authorization principal")
        if key == digest and principal != expected:
            raise ProvisioningError("Studio credential collides with another authorization")
        if principal.get("subject") == client.subject and (key != digest or principal != expected):
            raise ProvisioningError("Studio reader authorization drift; use explicit rotation")
    result["principals"][digest] = expected
    if len(result["principals"]) > 64:
        raise ProvisioningError("registry authorization principal limit reached")
    return result


def provision_studio_reader(context: str, namespace: str, token: str, *, image_upload: bool = False, migrate_studio_floors: bool = False) -> dict[str, Any]:
    client = STUDIO_IMAGE_CLIENT if image_upload else STUDIO_CLIENT
    secret_name = STUDIO_IMAGE_SECRET if image_upload else STUDIO_CLIENT_SECRET
    server = kube_json(context, ["-n", namespace, "get", "secret", SERVER_SECRET], label="Registry auth lookup")
    try:
        auth = json.loads(base64.b64decode(server["data"]["auth.json"], validate=True))
        version = server["metadata"]["resourceVersion"]
    except (ValueError, KeyError, TypeError) as error:
        raise ProvisioningError("Registry auth Secret is malformed") from error
    updated = add_studio_reader(auth, token, image_upload=image_upload, migrate_studio_floors=migrate_studio_floors)
    # Missing is valid on first activation; every other read error is fatal.
    existing = run_checked(["kubectl", "--context", context, "-n", namespace, "get", "secret",
                            secret_name, "--ignore-not-found", "-o", "json"], label="Studio reader lookup")
    if existing.strip():
        data = json.loads(existing).get("data", {})
        if data != {"token": base64.b64encode(token.encode()).decode()}:
            raise ProvisioningError("Studio reader Secret drift; use explicit rotation")
    body = json.dumps(updated, sort_keys=True, separators=(",", ":"))
    if updated != auth:
        patch = [{"op": "test", "path": "/metadata/resourceVersion", "value": version},
                 {"op": "replace", "path": "/data/auth.json", "value": base64.b64encode(body.encode()).decode()}]
        run_checked(["kubectl", "--context", context, "-n", namespace, "patch", "secret", SERVER_SECRET,
                     "--type=json", "--patch-file=/dev/stdin"], input_text=json.dumps(patch), label="Add Studio read principal")
    else:
        # Compare the actual serialized bytes when no authorization change was needed.
        body = base64.b64decode(server["data"]["auth.json"]).decode()
    wait_for_server_auth_projection(context, namespace, opaque_secret(namespace, SERVER_SECRET, {"auth.json": body}))
    apply_resources(context, [opaque_secret(namespace, secret_name, {"token": token})])
    return {"status": "studio-image-uploader-provisioned" if image_upload else "studio-reader-provisioned", "vaultItem": client.item_name,
            "clientSecret": f"{namespace}/{secret_name}", "scopes": [client.scope],
            "existingPrincipalsPreserved": len(auth["principals"]), "otherClientSecretsChanged": False}


def plan() -> dict[str, Any]:
    return {
        "schema": "infuse.artifact-registry-credential-plan/v1",
        "serverSecret": f"core/{SERVER_SECRET}",
        "temporaryClientSecret": f"agents-swarm/{CANARY_CLIENT_SECRET}",
        "backofficeClientSecret": f"core/{BACKOFFICE_CLIENT_SECRET}",
        "backofficeClients": [
            {
                "key": client.key,
                "item": client.item_name,
                "collection": client.collection,
                "scopes": [client.scope],
            }
            for client in SERVICE_CLIENTS if client not in (STUDIO_CLIENT, STUDIO_IMAGE_CLIENT)
        ],
        "studioImageClient": {
            "item": STUDIO_IMAGE_CLIENT.item_name, "collection": STUDIO_IMAGE_CLIENT.collection,
            "secret": f"core/{STUDIO_IMAGE_SECRET}", "scopes": ["image-upload"],
            "producer": "studio-whiteboard", "studioFloors": True,
        },
        "studioClient": {
            "item": STUDIO_CLIENT.item_name, "collection": STUDIO_CLIENT.collection,
            "secret": f"core/{STUDIO_CLIENT_SECRET}", "key": "token", "scopes": ["read"],
        },
        "producers": [
            {
                "producer": producer.producer,
                "item": producer.item_name,
                "collection": producer.collection or "personal",
                "secret": f"agents-swarm/{producer.secret_name}",
                "scopes": ["read", "write"],
            }
            for producer in PRODUCERS
        ],
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "bootstrap", "cutover", "rotate", "finalize", "studio", "studio-images"))
    parser.add_argument("--principal", help="Exact producer id or Backoffice client key for rotate.")
    parser.add_argument("--approved", action="store_true", help="Confirm the recorded credential-change approval.")
    parser.add_argument("--context", default="infuseai-k8s")
    parser.add_argument("--core-namespace", default="core")
    parser.add_argument("--agent-namespace", default="agents-swarm")
    parser.add_argument(
        "--bw-helper",
        default=os.environ.get(
            "BW_HELPER",
            str(Path.home() / ".openclaw" / "workspace" / "scripts" / "bw-infuse-vaultwarden.sh"),
        ),
    )
    parser.add_argument("--all-studio-floors", action="store_true", help="Explicitly migrate the exact original Studio image principal to all floors")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.action == "plan":
        print(json.dumps(plan(), indent=2))
        return 0
    if not args.approved:
        raise ProvisioningError("credential changes require --approved and a recorded owner approval")
    if args.all_studio_floors and args.action != "studio-images":
        raise ProvisioningError("--all-studio-floors requires studio-images")
    helper = str(Path(args.bw_helper).expanduser())
    if not Path(helper).is_file() or not os.access(helper, os.X_OK):
        raise ProvisioningError("Vaultwarden helper is unavailable")
    preflight_kubernetes(args.context, args.core_namespace, None if args.action in ("studio", "studio-images") else args.agent_namespace)
    if args.action in ("studio", "studio-images"):
        client = STUDIO_IMAGE_CLIENT if args.action == "studio-images" else STUDIO_CLIENT
        token = load_or_create_service_client_tokens(helper, (client,))[client.key]
        print(json.dumps(provision_studio_reader(args.context, args.core_namespace, token, image_upload=args.action == "studio-images", migrate_studio_floors=args.all_studio_floors)))
        return 0
    # Whole-auth legacy reconciliation must not erase independently activated clients.
    existing_auth = run_checked(['kubectl','--context',args.context,'-n',args.core_namespace,'get','secret',SERVER_SECRET,'--ignore-not-found','-o','json'], label='Independent Registry principal preflight')
    if existing_auth.strip():
        try:
            auth = json.loads(base64.b64decode(json.loads(existing_auth)['data']['auth.json'], validate=True))
            if not isinstance(auth, dict) or auth.get('schema') != 'infuse.artifact-auth/v1' or not isinstance(auth.get('principals'), dict) or any(not isinstance(p, dict) or not isinstance(p.get('subject'), str) for p in auth['principals'].values()):
                raise ProvisioningError('Registry authorization could not be verified')
            if any(p['subject'].startswith('Studio artifact lifecycle / ') for p in auth['principals'].values()):
                raise ProvisioningError('Studio lifecycle clients are active; whole-auth reconciliation requires a reviewed preservation plan')
        except (KeyError, ValueError, TypeError) as error:
            raise ProvisioningError('Registry authorization could not be verified') from error
    tokens = load_or_create_tokens(helper)
    if args.action == "rotate":
        if not args.principal:
            raise ProvisioningError("rotate requires --principal")
        service_tokens = load_or_create_service_client_tokens(helper)
        print(json.dumps(rotate_one(
            helper=helper,
            context=args.context,
            core_namespace=args.core_namespace,
            agent_namespace=args.agent_namespace,
            principal_name=args.principal,
            producer_tokens=tokens,
            service_tokens=service_tokens,
        )))
        return 0
    if args.action == "bootstrap":
        reader_token = secrets.token_urlsafe(48)
        lifecycle_token = secrets.token_urlsafe(48)
        resources = build_secret_resources(
            tokens,
            core_namespace=args.core_namespace,
            agent_namespace=args.agent_namespace,
            reader_token=reader_token,
            lifecycle_token=lifecycle_token,
        )
        apply_resources(args.context, resources)
        print(json.dumps({
            "status": "provisioned",
            "vaultItems": [producer.item_name for producer in PRODUCERS],
            "producerSecrets": [producer.secret_name for producer in PRODUCERS],
            "serverSecret": SERVER_SECRET,
            "temporaryClientSecret": CANARY_CLIENT_SECRET,
        }))
    else:
        service_tokens = load_or_create_service_client_tokens(helper)
        resources = build_secret_resources(
            tokens,
            core_namespace=args.core_namespace,
            agent_namespace=args.agent_namespace,
            reader_token=service_tokens["reader"],
            lifecycle_token=service_tokens["lifecycle"],
            studio_token=service_tokens.get("studio-reader"),
            studio_image_token=service_tokens.get("studio-image-upload"),
            client_secret_name=BACKOFFICE_CLIENT_SECRET,
        )
        apply_resources(args.context, resources)
        if args.action == "finalize":
            server_resource = next(
                resource for resource in resources
                if resource["metadata"]["name"] == SERVER_SECRET
            )
            wait_for_server_auth_projection(args.context, args.core_namespace, server_resource)
        delete_canary_client(args.context, args.agent_namespace)
        print(json.dumps({
            "status": "cutover-provisioned" if args.action == "cutover" else "finalized",
            "durablePrincipals": len(PRODUCERS) + len(SERVICE_CLIENTS),
            "backofficeClientSecret": BACKOFFICE_CLIENT_SECRET,
            "temporaryClientSecretRemoved": True,
        }))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ProvisioningError as error:
        print(f"credential provisioning failed safely: {error}", file=sys.stderr)
        raise SystemExit(2)
