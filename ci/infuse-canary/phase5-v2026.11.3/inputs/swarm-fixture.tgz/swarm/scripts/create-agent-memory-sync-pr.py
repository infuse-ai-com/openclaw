#!/usr/bin/env python3
"""Publish one attributable memory-sync MR for review after exact-source gates.

Uses the per-agent skill wrapper. No credential material or raw API errors are
printed. An uncertain write is reconciled by branch/MR identity on the next run.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from urllib.parse import quote, urlencode

HOST = 'gitlab.infuse-ai-tech.party'
PROJECT = 'platform/agents/openclaw-agents-memory'
AGENTS = {'agent-coordinator', 'agent-developer', 'agent-designer', 'agent-infra', 'agent-intake'}
COMMIT = re.compile(r'^[0-9a-f]{40}$')
SAFE_REF = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._/-]{0,240}$')


class SyncError(Exception):
    pass


class GitLab:
    def __init__(self, identity, deadline):
        self.identity, self.deadline = identity, deadline
        root = os.environ.get('AGENT_SKILLS_ROOT', '')
        self.wrapper = Path(root) / 'scripts/gitlab-vault-run.sh'
        if not root or not self.wrapper.is_file():
            raise SyncError('reviewed GitLab wrapper unavailable')

    def request(self, method, path, body=None):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise SyncError('memory sync deadline exceeded; preserve the branch and MR')
        command = [str(self.wrapper), self.identity, '--', 'glab', 'api', '--hostname', HOST, '--method', method, path]
        if body is not None:
            command += ['--input', '-']
        try:
            result = subprocess.run(command, input=None if body is None else json.dumps(body), text=True,
                                    capture_output=True, timeout=min(60, remaining))
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise SyncError('GitLab request unavailable or uncertain; reconcile before retry') from exc
        if result.returncode:
            raise SyncError('GitLab request failed; preserve branch/MR and inspect policy with the owning identity')
        try:
            return json.loads(result.stdout)
        except ValueError as exc:
            raise SyncError('invalid GitLab response') from exc


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--agent-id', required=True)
    parser.add_argument('--source-branch', required=True)
    parser.add_argument('--target-branch', default='main')
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--timeout-seconds', type=int, default=180)
    return parser.parse_args()


def validate_args(args):
    if args.agent_id not in AGENTS or os.environ.get('AGENT_ID', args.agent_id) != args.agent_id:
        raise SyncError('unsupported or mismatched agent identity')
    if os.environ.get('GITLAB_AGENT_ID', args.agent_id) != args.agent_id:
        raise SyncError('mismatched GitLab runtime identity')
    for value in (args.source_branch, args.target_branch):
        if not SAFE_REF.fullmatch(value) or '..' in value or '//' in value or value.endswith(('/', '.', '.lock')):
            raise SyncError('unsafe branch name')
    if not args.source_branch.startswith(f'agent-memory-sync/{args.agent_id}/') or args.target_branch != 'main':
        raise SyncError('memory sync requires the owning agent branch and main target')
    if not COMMIT.fullmatch(args.source_commit) or not 1 <= args.timeout_seconds <= 300:
        raise SyncError('invalid source revision or timeout')


def complete(args, api, deadline):
    user = api.request('GET', 'user')
    if user.get('username') != args.agent_id or user.get('state') != 'active':
        raise SyncError('GitLab API identity mismatch or inactive account')
    base = f'projects/{quote(PROJECT, safe="")}'
    project = api.request('GET', base)
    project_id = project['id']
    query = urlencode({'scope':'all','state':'all','source_branch':args.source_branch,'target_branch':args.target_branch,'per_page':100})
    candidates = api.request('GET', f'{base}/merge_requests?{query}')
    candidates = [m for m in candidates if m.get('source_project_id') == project_id and m.get('target_project_id') == project_id]
    if len(candidates) > 1:
        raise SyncError('ambiguous memory sync MRs; reconcile without creating another')
    if not candidates or candidates[0].get('state') != 'merged':
        branch = api.request('GET', f'{base}/repository/branches/{quote(args.source_branch, safe="")}')
        if branch.get('commit', {}).get('id') != args.source_commit:
            raise SyncError('source branch changed before MR reconciliation')
    if candidates:
        mr = candidates[0]
    else:
        mr = api.request('POST', f'{base}/merge_requests', {
            'source_branch':args.source_branch, 'target_branch':args.target_branch,
            'title':f'memory: sync {args.agent_id} agent state',
            'description':'Deterministic sync of this agent’s own profile and memory. Local IKF passed; exact-source GitLab CI must pass. Fito requires maintainer review; the agent does not merge this MR.',
            'remove_source_branch':True})
    iid = mr['iid']
    resource = f'{base}/merge_requests/{iid}'
    while time.monotonic() < deadline:
        mr = api.request('GET', resource)
        if (mr.get('source_project_id') != project_id or mr.get('target_project_id') != project_id
                or mr.get('source_branch') != args.source_branch or mr.get('target_branch') != args.target_branch):
            raise SyncError('MR scope mismatch')
        if mr.get('sha') != args.source_commit:
            raise SyncError('MR source changed; preserve it for review')
        if mr.get('state') == 'merged':
            merge_commit = mr.get('merge_commit_sha') or mr.get('squash_commit_sha')
            if not merge_commit or not COMMIT.fullmatch(merge_commit):
                raise SyncError('merged MR lacks an immutable result')
            return {'id':iid, 'status':'merged', 'merge_commit':merge_commit,
                    'url':f'https://{HOST}/{PROJECT}/-/merge_requests/{iid}'}
        if mr.get('state') != 'opened' or mr.get('draft') or mr.get('has_conflicts'):
            raise SyncError('MR closed, draft or conflicted; preserve for review')
        pipeline = mr.get('head_pipeline') or {}
        if pipeline.get('status') in {'failed', 'canceled', 'skipped'}:
            raise SyncError('MR pipeline did not pass; no merge attempted')
        if pipeline.get('sha') == args.source_commit and pipeline.get('status') == 'success':
            # Fito's 2026-11-12 decision: publication is automatic, merge is reviewed.
            # Even a future token with merge permission must not bypass this policy.
            return {'id':iid, 'status':'review_pending', 'source_commit':args.source_commit,
                    'pipeline_id':pipeline.get('id'),
                    'url':f'https://{HOST}/{PROJECT}/-/merge_requests/{iid}'}
        time.sleep(min(2, max(0, deadline-time.monotonic())))
    raise SyncError('memory sync gate timed out; preserve branch/MR for reconciliation')


def main():
    args = parse_args()
    validate_args(args)
    deadline = time.monotonic() + args.timeout_seconds
    print(json.dumps(complete(args, GitLab(args.agent_id, deadline), deadline), separators=(',', ':')))

if __name__ == '__main__':
    try:
        main()
    except SyncError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)
