"""Reviewed Studio authority profiles; no arbitrary destination or credential overrides."""
from __future__ import annotations

import argparse
import json
import re
import sys

ROLES = {'coordinator': 'agent-coordinator', 'developer': 'agent-developer',
         'design': 'agent-designer', 'infra': 'agent-infra'}

PROFILES = {
    'production': {
        'authorityId': 'studio-production',
        'studioUrl': 'https://studio-bridge.core.svc.cluster.local',
        'journalNamespace': 'production',
        'secretSuffix': '-studio',
        'markerAuthority': 'studio',
        'studioCaFile': '/var/run/studio/ca.crt',
    },
    'local-mac': {
        'authorityId': 'studio-local-mac',
        'studioUrl': 'https://macs-mac-mini.tailc4f8d5.ts.net:8443',
        'studioConnectAddress': '100.66.41.78',
        'journalNamespace': 'local-mac',
        'secretSuffix': '-studio-local-mac',
        # Older deployers only accept authority=studio. Refuse their implicit
        # production switch while the deliberately selected Mac profile is active.
        'markerAuthority': 'studio-local-mac',
    },
}


def validate_contract(contract: dict, production: dict) -> tuple[str, dict]:
    if set(contract) - {'projects'} != {'authorityId', 'projectId', 'installationId', 'studioUrl', 'routes'}:
        raise ValueError('Unexpected Studio profile fields')
    matches = [(name, value) for name, value in PROFILES.items()
               if value['authorityId'] == contract.get('authorityId')
               and value['studioUrl'] == contract.get('studioUrl')]
    if len(matches) != 1 or contract.get('projectId') != 'studio' or contract.get('installationId') != 'infuse-mattermost':
        raise ValueError('Only the reviewed Studio production and Mac authorities are supported')
    name, profile = matches[0]
    projects = contract.get('projects', [])
    if not isinstance(projects, list) or len(projects) > 1 or name == 'local-mac' and projects:
        raise ValueError('Only the reviewed Finaxis production project may be added')
    occupied = {r['channelId'] for r in contract['routes']}
    baseline = {r['role']: r for r in production['routes']}
    for project in projects:
        if set(project) != {'projectId', 'routes'} or project['projectId'] != 'finaxis':
            raise ValueError('Unknown additional Studio project')
        routes = project['routes']
        if len(routes) != 3 or {r['role'] for r in routes} != {'coordinator', 'developer', 'design'}:
            raise ValueError('Finaxis requires coordinator, developer and design routes')
        for route in routes:
            source = baseline[route['role']]
            if set(route) != set(source) or any(route.get(k) != source[k] for k in ('agentId', 'gatewayId', 'nativeBotUserId', 'accountId')):
                raise ValueError('Additional projects must reuse enrolled native identities')
            if not re.fullmatch('[a-z0-9]{26}', route['channelId']) or route['channelId'] in occupied:
                raise ValueError('Project channels must be distinct real IDs')
            occupied.add(route['channelId'])
    if name == 'local-mac':
        baseline = {route['role']: route for route in production['routes']}
        if len(contract.get('routes', [])) != len(baseline):
            raise ValueError('The Mac profile requires the same four native roles')
        production_channels = {route['channelId'] for route in baseline.values()} | {r['channelId'] for p in production.get('projects', []) for r in p['routes']}
        for route in contract['routes']:
            source = baseline.get(route.get('role'))
            if not source or any(route.get(key) != source[key] for key in ('agentId', 'gatewayId', 'nativeBotUserId', 'accountId')):
                raise ValueError('The Mac profile must preserve every enrolled native identity')
            if route.get('channelId') in production_channels:
                raise ValueError('Production channels cannot be rebound to the Mac authority')
    return name, dict(profile)


def select_profile(marker: dict | None, requested: str, confirmed: bool, preserved: tuple | list = ()) -> dict:
    if requested not in ('preserve', *PROFILES):
        raise ValueError('Unknown Studio runtime profile')
    data = (marker or {}).get('data', {})
    current = data.get('nativeProfile', 'production')
    if current not in PROFILES:
        raise ValueError('Unknown persisted Studio runtime profile')
    if marker and data.get('authority') != PROFILES[current]['markerAuthority']:
        raise ValueError('Studio authority marker and runtime profile disagree')
    rollout_state = data.get('nativeProfileState', 'active')
    if rollout_state not in ('active', 'pending'):
        raise ValueError('Unknown Studio profile rollout state')
    selected = current if requested == 'preserve' else requested
    if not marker and selected == 'local-mac':
        raise ValueError('The Mac profile requires an established Studio authority marker')
    changed = selected != current
    if changed and not confirmed:
        raise ValueError('A profile switch requires operator confirmation that source admission is disabled and all runs/effects are settled')
    if len(set(preserved)) != len(preserved) or any(agent not in {*ROLES.values(), 'agent-intake'} for agent in preserved):
        raise ValueError('Unknown or duplicate preserved deployment')
    # Force replacement of participating Pods on a switch, including when the
    # ordinary source-impact classifier preserved a docs-only deployment. A
    # failed rollout leaves pending custody, so retries cannot preserve a mixed fleet.
    replace_native = changed or rollout_state == 'pending'
    remaining = [agent for agent in preserved if not replace_native or agent not in ROLES.values()]
    return {'profile': selected, 'changed': changed, 'preserveDeployments': remaining}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--requested', choices=['preserve', *PROFILES], default='preserve')
    parser.add_argument('--switch-confirmed', choices=['true', 'false'], default='false')
    parser.add_argument('--preserve-deployments', default='')
    args = parser.parse_args()
    raw = sys.stdin.read().strip()
    try:
        preserved = args.preserve_deployments.split(',') if args.preserve_deployments else []
        print(json.dumps(select_profile(json.loads(raw) if raw else None, args.requested, args.switch_confirmed == 'true', preserved)))
    except (ValueError, TypeError, KeyError) as error:
        raise SystemExit(str(error)) from None


if __name__ == '__main__':
    main()
