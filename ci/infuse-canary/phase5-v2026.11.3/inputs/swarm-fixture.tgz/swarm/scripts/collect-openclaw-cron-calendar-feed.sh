#!/usr/bin/env bash
set -euo pipefail

source_namespace="${SOURCE_NAMESPACE:-agents-swarm}"
target_namespace="${TARGET_NAMESPACE:-core}"
configmap_name="${CONFIGMAP_NAME:-openclaw-cron-calendar-feed}"
selector="${AGENT_SELECTOR:-app.kubernetes.io/component=persistent-agent}"
timeout_seconds="${EXPORT_TIMEOUT_SECONDS:-45}"
expected_agents_csv="${EXPECTED_AGENT_IDS:-}"
dry_run="${DRY_RUN:-false}"

workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
snapshot_dir="$workdir/snapshots"
mkdir -p "$snapshot_dir"

kubectl_cmd=(kubectl)
if [[ -n "${KUBE_CONTEXT:-}" ]]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

pods_json_path="$workdir/pods.json"
"${kubectl_cmd[@]}" -n "$source_namespace" get pods -l "$selector" -o json >"$pods_json_path"
pod_rows_path="$workdir/pod-rows.tsv"
python3 - "$pods_json_path" >"$pod_rows_path" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    data = json.load(handle)

by_agent = {}
for item in data.get("items", []):
    metadata = item.get("metadata", {})
    labels = metadata.get("labels", {})
    name = metadata.get("name")
    agent_id = labels.get("app.kubernetes.io/name")
    phase = item.get("status", {}).get("phase")
    statuses = item.get("status", {}).get("containerStatuses", [])
    ready = any(
        status.get("name") == "agent" and status.get("ready") is True
        for status in statuses
        if isinstance(status, dict)
    )
    if name and agent_id:
        by_agent.setdefault(agent_id, []).append(
            {
                "name": name,
                "phase": phase,
                "ready": ready,
                "created": metadata.get("creationTimestamp") or "",
            }
        )

if not by_agent:
    raise SystemExit("No persistent-agent pods matched the collector selector")

for agent_id in sorted(by_agent):
    ready = [row for row in by_agent[agent_id] if row["phase"] == "Running" and row["ready"]]
    if not ready:
        raise SystemExit(f"No ready agent pod is available for {agent_id}")
    selected = sorted(ready, key=lambda row: (row["created"], row["name"]))[-1]
    print(f"{agent_id}\t{selected['name']}")
PY

pod_rows=()
while IFS= read -r row; do
  pod_rows+=("$row")
done <"$pod_rows_path"

if [[ "${#pod_rows[@]}" -eq 0 ]]; then
  echo "No running agent pods matched selector ${selector} in namespace ${source_namespace}." >&2
  exit 1
fi

if [[ -n "$expected_agents_csv" ]]; then
  actual_agents="$(printf '%s\n' "${pod_rows[@]}" | cut -f1 | sort | paste -sd, -)"
  expected_agents="$(tr ',' '\n' <<<"$expected_agents_csv" | sed '/^[[:space:]]*$/d' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | sort | paste -sd, -)"
  if [[ "$actual_agents" != "$expected_agents" ]]; then
    echo "Refusing to update: expected agents [$expected_agents] but found [$actual_agents]." >&2
    exit 1
  fi
fi

failures=0
for row in "${pod_rows[@]}"; do
  agent_id="${row%%$'\t'*}"
  pod_name="${row#*$'\t'}"
  output_path="$snapshot_dir/${agent_id}.json"

  echo "Collecting sanitized cron calendar snapshot from ${pod_name} (${agent_id})."
  if ! timeout "$timeout_seconds" "${kubectl_cmd[@]}" -n "$source_namespace" exec "pod/$pod_name" -c agent -- \
    bash -lc '
      set -euo pipefail
      agent_id="${AGENT_ID:-'"$agent_id"'}"
      agent_name="${AGENT_NAME:-$agent_id}"
      exporter="/usr/local/bin/openclaw-cron-calendar-export"
      if [ ! -x "$exporter" ]; then
        echo "ERROR: $exporter is not executable in $agent_id" >&2
        exit 1
      fi
      "$exporter" \
        --agent-id "$agent_id" \
        --gateway-label "$agent_name Gateway" \
        --system openclaw-k8s-swarm \
        --output -
    ' >"$output_path"; then
    echo "ERROR: failed to collect ${agent_id}." >&2
    rm -f "$output_path"
    failures=$((failures + 1))
    continue
  fi

  if ! python3 - "$agent_id" "$output_path" <<'PY'
import json
import sys

agent_id = sys.argv[1]
output_path = sys.argv[2]
with open(output_path, "r", encoding="utf-8") as handle:
    snapshot = json.load(handle)

source = snapshot.get("source")
events = snapshot.get("events")
if snapshot.get("schemaVersion") != 1:
    raise SystemExit("invalid schemaVersion")
if not isinstance(source, dict) or source.get("type") != "openclaw_cron_export":
    raise SystemExit("invalid source type")
if source.get("agentId") != agent_id:
    raise SystemExit("agentId mismatch")
if source.get("backend") != "gateway_cron_list":
    raise SystemExit("unexpected cron backend")
if source.get("status") not in {"available", "no_cron_jobs"}:
    raise SystemExit("invalid source status")
if source.get("paginationComplete") is not True:
    raise SystemExit("incomplete Gateway pagination")
if not isinstance(source.get("snapshotRevision"), str) or not source["snapshotRevision"]:
    raise SystemExit("missing Gateway snapshot revision")
if not isinstance(events, list):
    raise SystemExit("events must be an array")
if source.get("status") == "available" and not events:
    raise SystemExit("available snapshot has no events")
if source.get("status") == "no_cron_jobs" and events:
    raise SystemExit("no_cron_jobs snapshot contains events")
PY
  then
    echo "ERROR: invalid cron snapshot for ${agent_id}." >&2
    rm -f "$output_path"
    failures=$((failures + 1))
  fi
done

if [[ "$failures" -ne 0 ]]; then
  echo "Refusing to update configmap/${configmap_name}: ${failures} agent export(s) failed." >&2
  exit 1
fi

if [[ "$dry_run" == "true" ]]; then
  echo "Validated ${#pod_rows[@]} agent snapshots; dry run left configmap/${configmap_name} unchanged."
  exit 0
fi

"${kubectl_cmd[@]}" -n "$target_namespace" create configmap "$configmap_name" \
  --from-file="$snapshot_dir" \
  --dry-run=client \
  -o yaml \
  | "${kubectl_cmd[@]}" apply -n "$target_namespace" -f -

echo "Updated configmap/${configmap_name} in namespace ${target_namespace} with ${#pod_rows[@]} agent snapshots."
