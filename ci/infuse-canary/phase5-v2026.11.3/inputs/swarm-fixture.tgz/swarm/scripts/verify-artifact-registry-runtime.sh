#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
runtime_output="${ARTIFACT_REGISTRY_RUNTIME_RENDER_OUTPUT:-/tmp/backoffice-artifact-registry-runtime.yaml}"
producer_output="${ARTIFACT_REGISTRY_PRODUCER_RENDER_OUTPUT:-/tmp/backoffice-artifact-registry-producers.yaml}"
dry_run_output="${ARTIFACT_REGISTRY_DRY_RUN_RENDER_OUTPUT:-/tmp/backoffice-artifact-registry-server-dry-run.yaml}"
recovery_output="${ARTIFACT_REGISTRY_RECOVERY_RENDER_OUTPUT:-/tmp/backoffice-artifact-registry-recovery.yaml}"
recovery_dry_run_output="${ARTIFACT_REGISTRY_RECOVERY_DRY_RUN_RENDER_OUTPUT:-/tmp/backoffice-artifact-registry-recovery-server-dry-run.yaml}"
canary_output="${ARTIFACT_REGISTRY_CANARY_RENDER_OUTPUT:-/tmp/backoffice-artifact-registry-canary.yaml}"
canary_verifier_output="${ARTIFACT_REGISTRY_CANARY_VERIFIER_RENDER_OUTPUT:-/tmp/backoffice-artifact-registry-canary-verifier.yaml}"

kubectl kustomize "$repo_root/k8s/platform/artifact-registry" >"$runtime_output"
kubectl kustomize "$repo_root/k8s/platform/artifact-registry/producers" >"$producer_output"
kubectl kustomize "$repo_root/k8s/platform/artifact-registry-server-dry-run" >"$dry_run_output"
kubectl kustomize "$repo_root/k8s/platform/artifact-registry-recovery" >"$recovery_output"
kubectl kustomize "$repo_root/k8s/platform/artifact-registry-recovery-server-dry-run" >"$recovery_dry_run_output"
kubectl kustomize "$repo_root/k8s/platform/artifact-registry-canary" >"$canary_output"
kubectl kustomize "$repo_root/k8s/platform/artifact-registry-canary-verifier" >"$canary_verifier_output"

release_output="$(mktemp)"
trap 'rm -f "$release_output"' EXIT
kubectl kustomize "$repo_root/k8s/platform/artifact-registry-release" >"$release_output"
if grep -Eq "^kind: (PersistentVolumeClaim|Job|Role|RoleBinding|Ingress|IngressRoute)$|name: agent-" "$release_output"; then
  echo "Registry release crosses its workload boundary" >&2; exit 1
fi

if [[ "${ARTIFACT_REGISTRY_SERVER_DRY_RUN:-false}" == "true" ]]; then
  kube_context="${KUBE_CONTEXT:?Set KUBE_CONTEXT for Artifact Registry server-side dry-run}"
  kubectl --context "$kube_context" apply --server-side --dry-run=server \
    -k "$repo_root/k8s/platform/artifact-registry-server-dry-run"
  kubectl --context "$kube_context" apply --server-side --dry-run=server \
    -k "$repo_root/k8s/platform/artifact-registry-recovery-server-dry-run"
  kubectl --context "$kube_context" apply --server-side --dry-run=server \
    -k "$repo_root/k8s/platform/artifact-registry-canary-verifier"
fi

echo "Verified Artifact Registry runtime, producer, T5.1 canary, verifier, and recovery renders."
