#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${AGENT_ID:-agent-intake}"
context="${KUBE_CONTEXT:-infuseai-k8s}"

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s
"${kubectl_base[@]}" wait pod -l "$selector" --for=condition=Ready --timeout=120s >/dev/null

pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc '
set -eu
workspace="${OPENCLAW_AGENT_WORKSPACE:-/workspace/agents/agent-intake}"
mail_script="$workspace/skills/consulting-intake-orchestrator/scripts/mail_intake.py"
approval_script="$workspace/skills/consulting-intake-orchestrator/scripts/approval_email.py"
test -x "$mail_script" || test -f "$mail_script"
test -x "$approval_script" || test -f "$approval_script"
python3 "$mail_script" --list-mailboxes >/tmp/agent-intake-imap-mailboxes.json
python3 "$approval_script" --check-mattermost-auth >/tmp/agent-intake-mattermost-auth.json
jq -e ".mattermost_auth == \"ok\"" /tmp/agent-intake-mattermost-auth.json >/dev/null
'

echo "Ramiro Garcia IMAP/Mattermost approval preflight passed for $agent_id in $namespace"
