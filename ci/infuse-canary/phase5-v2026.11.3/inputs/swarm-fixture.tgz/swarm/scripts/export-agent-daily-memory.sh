#!/usr/bin/env bash
set -euo pipefail
# Compatibility entrypoint; there is one own-agent mirror publisher.
exec /usr/local/bin/openclaw-agent-sync-memory-repo "$@"
