#!/usr/bin/env python3
"""Prepare one guarded identity-scope patch; never contact Kubernetes or emit config."""

from __future__ import annotations

import argparse
import copy
import json
import math
import os
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
AGENTS = frozenset(f"agent-{role}" for role in ("developer", "designer", "coordinator", "intake", "infra"))
NAMESPACE = "agents-swarm"
IDENTITY = "aog.olea@gmail.com"
GRANT = ["operator.admin"]
CONFIG_ENV = "OPENCLAW_CONFIG_JSON"
IMAGE = re.compile(r"^[^@\s]+@sha256:[0-9a-f]{64}$")
PASSWORD = {"source": "env", "provider": "default", "id": "OPENCLAW_GATEWAY_PASSWORD"}
TRUSTED_PROXY = {
    "userHeader": "x-forwarded-user",
    "requiredHeaders": ["x-forwarded-proto", "x-forwarded-host"],
    "allowUsers": [IDENTITY],
    "deviceAutoApprove": {
        "enabled": True,
        "scopes": ["operator.sessions.read", "operator.sessions.write", "operator.read", "operator.write"],
    },
}


class PatchError(ValueError):
    """A safe, content-free refusal suitable for operator output."""


def object_value(value: object, label: str) -> dict:
    if not isinstance(value, dict):
        raise PatchError(f"{label} must be an object")
    return value


def unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise PatchError("JSON contains duplicate object keys")
        result[key] = value
    return result


def reject_constant(_value: str) -> None:
    raise PatchError("JSON contains a non-finite number")


def finite_float(raw: str) -> float:
    value = float(raw)
    if not math.isfinite(value):
        raise PatchError("JSON contains a non-finite number")
    return value


def parse_json(raw: str) -> dict:
    try:
        value = json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_constant, parse_float=finite_float)
    except PatchError:
        raise
    except (ValueError, TypeError, RecursionError) as error:
        raise PatchError("Invalid JSON input") from error
    return object_value(value, "JSON input")


def reviewed_config(agent_id: str) -> dict:
    if agent_id not in AGENTS:
        raise PatchError("Agent is outside the reviewed five-agent fleet")
    try:
        source = (ROOT / "k8s" / "agents" / agent_id / "deployment.yaml").read_text(encoding="utf-8")
    except (OSError, UnicodeError) as error:
        raise PatchError("Cannot read reviewed agent source") from error
    # These Kustomize JSON-patch sources deliberately use a single quoted JSON
    # scalar. Refuse another source shape instead of guessing YAML structure.
    matches = re.findall(r"name: OPENCLAW_CONFIG_JSON\n[ \t]+value: '([^\n]*)'[ \t]*$", source, re.MULTILINE)
    if len(matches) != 1:
        raise PatchError("Reviewed source must contain exactly one literal agent config")
    return parse_json(matches[0].replace("''", "'"))


def gateway_baseline(config: dict, agent_id: str) -> tuple[dict, dict]:
    gateway = object_value(config.get("gateway"), "Gateway config")
    auth = object_value(gateway.get("auth"), "Gateway auth")
    proxy = auth.get("trustedProxy")
    if auth.get("mode") != "trusted-proxy" or auth.get("password") != PASSWORD or proxy != TRUSTED_PROXY or proxy["deviceAutoApprove"]["enabled"] is not True:
        raise PatchError("Trusted-proxy, password or device-approval baseline differs")
    if gateway.get("trustedProxies") != ["10.1.42.208"]:
        raise PatchError("Trusted proxy source baseline differs")
    control_ui = object_value(gateway.get("controlUi"), "Control UI config")
    origins = control_ui.get("allowedOrigins")
    if not isinstance(origins, list) or not all(isinstance(origin, str) for origin in origins) or "https://agents.infuse-ai.com" not in origins:
        raise PatchError("Dashboard allowed-origin baseline is unavailable")
    entries = object_value(object_value(config.get("agents"), "Agents config").get("entries"), "Agent entries")
    if set(entries) != {agent_id}:
        raise PatchError("Agent config does not identify the selected persistent agent")
    return gateway, auth


def build_patch(deployment: dict, source_config: dict, *, agent_id: str, expected_image: str) -> list[dict]:
    if agent_id not in AGENTS:
        raise PatchError("Agent is outside the reviewed five-agent fleet")
    if not isinstance(expected_image, str) or IMAGE.fullmatch(expected_image) is None:
        raise PatchError("Expected image must be an exact immutable image reference")
    source_gateway, source_auth = gateway_baseline(source_config, agent_id)
    if source_auth.get("identityScopes") != {IDENTITY: GRANT}:
        raise PatchError("Reviewed source must grant only the exact Fito administration scope")
    deployment = object_value(deployment, "Deployment")
    if deployment.get("apiVersion") != "apps/v1" or deployment.get("kind") != "Deployment":
        raise PatchError("Expected an apps/v1 Deployment")
    metadata = object_value(deployment.get("metadata"), "Deployment metadata")
    if metadata.get("namespace") != NAMESPACE or metadata.get("name") != agent_id:
        raise PatchError("Deployment namespace or workload differs")
    for key in ("uid", "resourceVersion"):
        if not isinstance(metadata.get(key), str) or not metadata[key]:
            raise PatchError("Deployment UID and resourceVersion are required")
    template = object_value(object_value(deployment.get("spec"), "Deployment spec").get("template"), "Pod template")
    containers = object_value(template.get("spec"), "Pod spec").get("containers")
    if not isinstance(containers, list) or any(not isinstance(container, dict) for container in containers):
        raise PatchError("Deployment containers are invalid")
    candidates = [(index, container) for index, container in enumerate(containers) if container.get("name") == "agent"]
    if len(candidates) != 1:
        raise PatchError("Deployment must have exactly one agent container")
    container_index, container = candidates[0]
    if container.get("image") != expected_image:
        raise PatchError("Live agent image differs from the verified immutable image")
    env = container.get("env")
    if not isinstance(env, list) or any(not isinstance(item, dict) or not isinstance(item.get("name"), str) or not item["name"] for item in env):
        raise PatchError("Agent environment is invalid")
    if len({item["name"] for item in env}) != len(env):
        raise PatchError("Agent environment has duplicate names")
    agent_env = next((item for item in env if item["name"] == "AGENT_ID"), None)
    if agent_env != {"name": "AGENT_ID", "value": agent_id}:
        raise PatchError("Agent environment does not identify the selected workload")
    candidates = [(index, item) for index, item in enumerate(env) if item["name"] == CONFIG_ENV]
    if len(candidates) != 1:
        raise PatchError("Agent must have exactly one literal config environment value")
    env_index, config_env = candidates[0]
    if set(config_env) != {"name", "value"} or not isinstance(config_env.get("value"), str):
        raise PatchError("Agent config must be a literal environment value")
    previous = config_env["value"]
    config = parse_json(previous)
    gateway, auth = gateway_baseline(config, agent_id)
    if gateway["controlUi"]["allowedOrigins"] != source_gateway["controlUi"]["allowedOrigins"]:
        raise PatchError("Live allowed origins differ from reviewed source")
    scopes = auth.get("identityScopes", {})
    if not isinstance(scopes, dict):
        raise PatchError("Existing identity scopes must be an object")
    if IDENTITY in scopes:
        if scopes[IDENTITY] != GRANT:
            raise PatchError("Existing Fito identity grant conflicts with the reviewed grant")
        return []
    updated = copy.deepcopy(config)
    updated["gateway"]["auth"].setdefault("identityScopes", {})[IDENTITY] = list(GRANT)
    new_value = json.dumps(updated, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    container_path = f"/spec/template/spec/containers/{container_index}"
    env_path = f"{container_path}/env/{env_index}"
    tests = [
        ("/metadata/name", agent_id), ("/metadata/namespace", NAMESPACE),
        ("/metadata/uid", metadata["uid"]), ("/metadata/resourceVersion", metadata["resourceVersion"]),
        (f"{container_path}/name", "agent"), (f"{container_path}/image", expected_image),
        (f"{env_path}/name", CONFIG_ENV), (f"{env_path}/value", previous),
    ]
    return [{"op": "test", "path": path, "value": value} for path, value in tests] + [
        {"op": "replace", "path": f"{env_path}/value", "value": new_value},
    ]


def write_patch(path: str, patch: list[dict]) -> None:
    if not path or path == "-":
        raise PatchError("Patch output requires a new protected file, never stdout")
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(patch, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
    except OSError as error:
        raise PatchError("Cannot create new protected patch file; existing files and symlinks are refused") from error


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent-id", required=True, choices=sorted(AGENTS))
    parser.add_argument("--expected-image", required=True)
    parser.add_argument("--input", required=True, help="Protected live Deployment JSON file, or - for stdin")
    output = parser.add_mutually_exclusive_group(required=True)
    output.add_argument("--dry-run", action="store_true")
    output.add_argument("--output", help="New protected JSON Patch file; never -")
    args = parser.parse_args()
    try:
        try:
            raw = sys.stdin.read() if args.input == "-" else Path(args.input).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            raise PatchError("Cannot read live Deployment input") from error
        patch = build_patch(parse_json(raw), reviewed_config(args.agent_id), agent_id=args.agent_id, expected_image=args.expected_image)
        if not args.dry_run:
            write_patch(args.output, patch)
        print(json.dumps({"agentId": args.agent_id, "changedGrants": int(bool(patch)), "noop": not patch, "dryRun": args.dry_run}))
        return 0
    except PatchError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
