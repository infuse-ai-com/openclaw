#!/usr/bin/env bash
set -euo pipefail

context="${KUBE_CONTEXT:-infuseai-k8s}"
namespace="${NAMESPACE:-agents-swarm}"
agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-designer}"
bundle_path="config/agent-skill-bundles/$agent_id.json"

if [[ ! -f "$bundle_path" ]]; then
  echo "Agent skill bundle not found: $bundle_path" >&2
  exit 2
fi

agent_name="${AGENT_NAME:-$(jq -r '.friendly_name // .agent_id' "$bundle_path")}"
agent_role="${AGENT_ROLE:-$(jq -r '.role // "persistent OpenClaw agent"' "$bundle_path")}"
mattermost_channel="${MATTERMOST_CHANNEL:-openclaw-swarm-dev}"

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"
pod="$("${kubectl_base[@]}" get pod \
  -l "$selector" \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}')"

if [[ -z "$pod" ]]; then
  echo "No running pod found for $agent_id in $namespace" >&2
  exit 1
fi

tmp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT

persona_dir="$tmp_dir/persona"
runtime_tools_dir="$tmp_dir/runtime-tools"

AGENT_PERSONA_DIR="$persona_dir" \
AGENT_ID="$agent_id" \
AGENT_NAME="$agent_name" \
AGENT_ROLE="$agent_role" \
MATTERMOST_CHANNEL="$mattermost_channel" \
scripts/install-agent-persona.sh >/dev/null

mkdir -p "$runtime_tools_dir/bin" "$runtime_tools_dir/config/agent-skill-bundles"
cp scripts/agent-task-workspace.py "$runtime_tools_dir/bin/agent-task-workspace.py"
chmod 755 "$runtime_tools_dir/bin/agent-task-workspace.py"
cp "$bundle_path" "$runtime_tools_dir/config/agent-skill-bundles/$agent_id.json"

"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "mkdir -p '/workspace/agents/$agent_id' '/workspace/agents/$agent_id/skills'"

tar -C "$persona_dir" -cf - . | "${kubectl_base[@]}" exec -i "$pod" -c agent -- \
  tar -C "/workspace/agents/$agent_id" -xf -

tar -C "$runtime_tools_dir" -cf - . | "${kubectl_base[@]}" exec -i "$pod" -c agent -- \
  tar -C "/workspace/agents/$agent_id" -xf -

AGENT_ID="$agent_id" \
KUBE_CONTEXT="$context" \
NAMESPACE="$namespace" \
scripts/sync-agent-skills-runtime.sh

"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "test -f '/workspace/agents/$agent_id/AGENTS.md' && test -f '/workspace/agents/$agent_id/skills/skill-bundle-manifest.json' && test -x '/workspace/agents/$agent_id/bin/agent-task-workspace.py'"

echo "Installed runtime persona, binary skill set, and repo task tools for $agent_id into pod $pod"
