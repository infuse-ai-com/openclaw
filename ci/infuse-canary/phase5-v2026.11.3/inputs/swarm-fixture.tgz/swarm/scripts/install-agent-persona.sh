#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
persona_repo_dir="${AGENT_PERSONA_REPO_DIR:-$repo_root/../openclaw-agents-persona}"

agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-designer}"
bundle_dir="${AGENT_SKILL_BUNDLE_DIR:-config/agent-skill-bundles}"
bundle_path="$bundle_dir/$agent_id.json"

if [[ -f "$bundle_path" ]]; then
  default_agent_name="$(jq -r '.friendly_name // .agent_id' "$bundle_path")"
  default_agent_role="$(jq -r '.role // "persistent OpenClaw agent"' "$bundle_path")"
  default_agent_coordinator="$(jq -r '.coordinator // "Emon Lusk / agent-coordinator"' "$bundle_path")"
else
  default_agent_name="$agent_id"
  default_agent_role="persistent OpenClaw agent"
  default_agent_coordinator="Emon Lusk / agent-coordinator"
fi

agent_name="${AGENT_NAME:-$default_agent_name}"
agent_role="${AGENT_ROLE:-$default_agent_role}"
agent_coordinator="${AGENT_COORDINATOR:-$default_agent_coordinator}"
mattermost_channel="${MATTERMOST_CHANNEL:-approved-bootstrap-channel}"
workspace="${OPENCLAW_WORKSPACE:-/workspace}"
target_dir="${AGENT_PERSONA_DIR:-$workspace/agents/$agent_id}"
template_dir="${AGENT_PERSONA_TEMPLATE_DIR:-$persona_repo_dir/templates/agent-persona}"
source_dir="${AGENT_PERSONA_SOURCE_DIR:-}"
source_kind="template"
dry_run="${DRY_RUN:-false}"
preserve_memory="${AGENT_PERSONA_PRESERVE_MEMORY:-true}"

if [[ "$dry_run" == "true" ]]; then
  target_dir="${DRY_RUN_OUTPUT_DIR:-/tmp/openclaw-agent-persona-$agent_id}"
fi

if [[ -z "$source_dir" && -d "$persona_repo_dir/agents/$agent_id" ]]; then
  source_dir="$persona_repo_dir/agents/$agent_id"
fi

if [[ -n "$source_dir" ]]; then
  source_kind="agent"
elif [[ -d "$template_dir" ]]; then
  source_dir="$template_dir"
else
  echo "Persona source directory not found: $template_dir" >&2
  exit 2
fi

if [[ ! -d "$source_dir" ]]; then
  echo "Persona source directory not found: $source_dir" >&2
  exit 2
fi

mkdir -p "$target_dir"/{memory,state,logs}

for source_file in "$source_dir"/*.md; do
  file_name="$(basename "$source_file")"
  output="$target_dir/$file_name"
  if [[ "$file_name" == "MEMORY.md" && "$preserve_memory" == "true" && -f "$output" ]]; then
    continue
  fi
  if [[ "$source_kind" == "agent" ]]; then
    cp "$source_file" "$output"
  else
    sed \
      -e "s|__AGENT_ID__|$agent_id|g" \
      -e "s|__AGENT_NAME__|$agent_name|g" \
      -e "s|__AGENT_ROLE__|$agent_role|g" \
      -e "s|__AGENT_COORDINATOR__|$agent_coordinator|g" \
      -e "s|__MATTERMOST_CHANNEL__|$mattermost_channel|g" \
      "$source_file" >"$output"
  fi
done

source_git_root="$(git -C "$source_dir" rev-parse --show-toplevel 2>/dev/null || true)"
source_git_commit=""
source_git_relative_dir=""
if [[ -n "$source_git_root" ]]; then
  source_git_commit="$(git -C "$source_dir" rev-parse HEAD 2>/dev/null || true)"
  source_git_relative_dir="${source_dir#$source_git_root/}"
  if [[ "$source_git_relative_dir" == "$source_dir" ]]; then
    source_git_relative_dir="."
  fi
fi

python3 - "$agent_id" "$agent_name" "$source_kind" "$source_dir" "$template_dir" "$target_dir" "$dry_run" "$source_git_root" "$source_git_commit" "$source_git_relative_dir" <<'PY'
import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

(
    agent_id,
    agent_name,
    source_kind,
    source_dir,
    template_dir,
    target_dir,
    dry_run,
    source_git_root,
    source_git_commit,
    source_git_relative_dir,
) = sys.argv[1:]
target = Path(target_dir)
files = []
for path in sorted(target.glob("*.md")):
    if not path.is_file():
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    files.append(
        {
            "path": path.name,
            "sha256": digest,
            "bytes": path.stat().st_size,
        }
    )

manifest = {
    "agent_id": agent_id,
    "agent_name": agent_name,
    "installed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
    "source_kind": source_kind,
    "source_dir": source_dir,
    "template_dir": template_dir,
    "target_dir": str(target),
    "dry_run": dry_run == "true",
    "files": files,
}
if source_git_root:
    manifest["source_git_root"] = source_git_root
if source_git_commit:
    manifest["source_git_commit"] = source_git_commit
if source_git_relative_dir:
    manifest["source_git_relative_dir"] = source_git_relative_dir
(target / "persona-install-manifest.json").write_text(
    json.dumps(manifest, indent=2) + "\n",
    encoding="utf-8",
)
PY

echo "Installed persona files for $agent_id: $target_dir"
if [[ "$dry_run" == "true" ]]; then
  echo "Dry-run output only; no runtime PVC was modified."
fi
