#!/usr/bin/env python3
"""Validate privacy and cardinality fixtures for Infuse agent telemetry."""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONTRACT = ROOT / "config" / "observability" / "telemetry-contract.v1.json"
DEFAULT_FIXTURES = ROOT / "config" / "observability" / "fixtures"


@dataclass(frozen=True)
class Finding:
    code: str
    path: str
    message: str


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def verify_signal_authorities(contract: dict[str, Any]) -> list[str]:
    """Reject truth-source drift before dashboards or reports can consume it."""
    errors: list[str] = []
    expected = {
        "run": {
            "canonicalSignal": "openclaw.run",
            "canonicalFields": ["count", "outcome", "duration_ms"],
            "drilldownSignal": "infuse.agent.turn",
            "drilldownRole": "turn_scoped_operational_drilldown",
        },
        "tool": {
            "canonicalSignal": "openclaw.tool.execution",
            "canonicalFields": ["count", "outcome", "duration_ms"],
            "drilldownSignal": "infuse.tool.execution",
            "drilldownRole": "turn_scoped_classification_drilldown",
        },
        "workflow": {
            "canonicalSignal": "infuse.workflow.phase",
            "canonicalFields": ["phase", "outcome", "sequence", "attribution_method"],
            "drilldownSignal": "infuse.workflow.phase",
            "drilldownRole": "explicit_semantic_evidence",
        },
        "skill": {
            "canonicalSignal": "infuse.skill.execution",
            "canonicalFields": ["skill_name", "phase", "outcome", "attribution_method", "lifecycle_state"],
            "drilldownSignal": "infuse.skill.execution",
            "drilldownRole": "explicit_semantic_evidence",
        },
        "wrapper": {
            "canonicalSignal": "infuse.wrapper.execution",
            "canonicalFields": [
                "wrapper",
                "operation",
                "phase",
                "outcome",
                "duration_ms",
                "lifecycle_method",
                "lifecycle_state",
            ],
            "drilldownSignal": "infuse.wrapper.execution",
            "drilldownRole": "explicit_semantic_evidence",
        },
        "knowledge": {
            "canonicalSignal": "infuse.knowledge.retrieve",
            "canonicalFields": ["operation", "outcome", "duration_ms", "result_count"],
            "drilldownSignal": "infuse.knowledge.retrieve",
            "drilldownRole": "explicit_semantic_evidence",
        },
        "mission": {
            "canonicalSignal": "infuse.mission.transition",
            "canonicalFields": [
                "phase_before",
                "phase_after",
                "transition_outcome",
                "actor_class",
                "trigger_class",
                "correlation_state",
            ],
            "drilldownSignal": "infuse.mission.transition",
            "drilldownRole": "explicit_semantic_evidence",
        },
        "task": {
            "canonicalSignal": "infuse.task.transition",
            "canonicalFields": [
                "task_role",
                "state_before",
                "state_after",
                "transition_outcome",
                "wait_category",
                "verification_class",
                "correlation_state",
            ],
            "drilldownSignal": "infuse.task.transition",
            "drilldownRole": "explicit_semantic_evidence",
        },
        "orchestration_event": {
            "canonicalSignal": "infuse.orchestration.event",
            "canonicalFields": [
                "event_kind",
                "intake_outcome",
                "producer_class",
                "wake_outcome",
                "correlation_state",
            ],
            "drilldownSignal": "infuse.orchestration.event",
            "drilldownRole": "explicit_semantic_evidence",
        },
    }
    authorities = contract.get("signalAuthorities")
    if not isinstance(authorities, dict):
        return ["signalAuthorities must be an object"]
    if set(authorities) != set(expected):
        errors.append(
            f"signalAuthorities families must be exactly {sorted(expected)}; "
            f"got {sorted(authorities)}"
        )
    for family, required in expected.items():
        actual = authorities.get(family)
        if not isinstance(actual, dict):
            errors.append(f"signalAuthorities.{family} must be an object")
            continue
        for key, value in required.items():
            if actual.get(key) != value:
                errors.append(
                    f"signalAuthorities.{family}.{key} must be {value!r}; "
                    f"got {actual.get(key)!r}"
                )
        if actual.get("disagreementPolicy") != "surface":
            errors.append(
                f"signalAuthorities.{family}.disagreementPolicy must be 'surface'"
            )

    boundaries = contract.get("comparisonBoundaries")
    if not isinstance(boundaries, dict):
        return errors + ["comparisonBoundaries must be an object"]
    expected_dimensions = [
        "openclaw.agent.name",
        "deployment.environment.name",
        "container.image.revision",
        "openclaw.runtime.revision",
        "infuse.skill_bundle.revision",
        "rollout.boundary",
        "traffic.source",
    ]
    if boundaries.get("requiredDimensions") != expected_dimensions:
        errors.append("comparisonBoundaries.requiredDimensions drifted")
    if boundaries.get("trafficSourceEnum") != [
        "human",
        "automation",
        "smoke",
        "startup",
        "unavailable",
    ]:
        errors.append("comparisonBoundaries.trafficSourceEnum drifted")
    if boundaries.get("unknownValue") != "unavailable":
        errors.append("comparisonBoundaries.unknownValue must be 'unavailable'")
    if boundaries.get("crossBoundaryPolicy") != "segment":
        errors.append("comparisonBoundaries.crossBoundaryPolicy must be 'segment'")
    correlation = contract.get("missionCorrelation")
    expected_correlation = {
        "traceReferenceAttribute": "correlation_ref",
        "traceReferencePattern": "^[0-9a-f]{64}$",
        "metricIdentityLabelsForbidden": [
            "mission_id",
            "task_id",
            "event_id",
            "correlation_ref",
        ],
        "unavailableState": "unavailable",
        "timestampOnlyInference": "forbidden",
    }
    if correlation != expected_correlation:
        errors.append("missionCorrelation policy drifted")
    return errors


def matches_type(value: Any, expected: str) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    return False


def validate_event(contract: dict[str, Any], event: Any) -> list[Finding]:
    findings: list[Finding] = []
    if not isinstance(event, dict):
        return [Finding("envelope.type", "$", "event must be an object")]

    allowed_envelope = {"signal", "attributes", "metricLabels", "resourceAttributes"}
    required_envelope = {"signal", "attributes", "metricLabels"}
    for key in sorted(set(event) - allowed_envelope):
        findings.append(Finding("envelope.unexpected_field", f"$.{key}", "unexpected envelope field"))
    for key in sorted(required_envelope - set(event)):
        findings.append(Finding("envelope.missing_field", f"$.{key}", "required envelope field is missing"))

    signal = event.get("signal")
    signals = contract.get("signals", {})
    if not isinstance(signal, str) or signal not in signals:
        findings.append(Finding("signal.unknown", "$.signal", "signal is not declared by the contract"))
        return findings
    signal_contract = signals[signal]

    attributes = event.get("attributes")
    if not isinstance(attributes, dict):
        findings.append(Finding("attributes.type", "$.attributes", "attributes must be an object"))
        return findings
    labels = event.get("metricLabels")
    if not isinstance(labels, dict):
        findings.append(Finding("labels.type", "$.metricLabels", "metricLabels must be an object"))
        return findings

    forbidden_names = [re.compile(pattern, re.IGNORECASE) for pattern in contract["forbiddenFieldPatterns"]]
    forbidden_values = [re.compile(pattern, re.IGNORECASE) for pattern in contract["forbiddenValuePatterns"]]
    max_string_length = int(contract["maxAttributeStringLength"])
    declared_attributes = {
        **contract.get("commonSignalAttributes", {}),
        **signal_contract["attributes"],
    }

    resource_attributes = event.get("resourceAttributes")
    if resource_attributes is not None:
        if not isinstance(resource_attributes, dict):
            findings.append(Finding("resource.type", "$.resourceAttributes", "resourceAttributes must be an object"))
        else:
            approved_resource_attributes = set(contract["resourceAttributes"]["required"])
            for key, value in resource_attributes.items():
                path = f"$.resourceAttributes.{key}"
                if key not in approved_resource_attributes:
                    findings.append(Finding("resource.unapproved", path, "resource attribute is not approved"))
                if any(pattern.search(key) for pattern in forbidden_names):
                    findings.append(Finding("resource.forbidden_name", path, "resource attribute name is forbidden"))
                if not isinstance(value, str):
                    findings.append(Finding("resource.type", path, "resource attribute must be a string"))
                elif any(pattern.search(value) for pattern in forbidden_values):
                    findings.append(Finding("resource.forbidden_value", path, "resource value matches a forbidden content shape"))
            for key in contract["resourceAttributes"]["required"]:
                if key not in resource_attributes:
                    findings.append(Finding("resource.missing", f"$.resourceAttributes.{key}", "required resource attribute is missing"))

    for key in sorted(set(attributes) - set(declared_attributes)):
        findings.append(Finding("attribute.unexpected", f"$.attributes.{key}", "attribute is not declared for this signal"))
    for key in signal_contract["requiredAttributes"]:
        if key not in attributes:
            findings.append(Finding("attribute.missing", f"$.attributes.{key}", "required attribute is missing"))

    for key, value in attributes.items():
        path = f"$.attributes.{key}"
        if any(pattern.search(key) for pattern in forbidden_names):
            findings.append(Finding("attribute.forbidden_name", path, "attribute name is forbidden"))
        field_contract = declared_attributes.get(key)
        if field_contract is None:
            continue
        expected_type = field_contract["type"]
        if not matches_type(value, expected_type):
            findings.append(Finding("attribute.type", path, f"expected {expected_type}"))
            continue
        if isinstance(value, str):
            if len(value) > min(max_string_length, int(field_contract.get("maxLength", max_string_length))):
                findings.append(Finding("attribute.length", path, "string exceeds the approved bound"))
            if any(pattern.search(value) for pattern in forbidden_values):
                findings.append(Finding("attribute.forbidden_value", path, "attribute value matches a forbidden content shape"))
            pattern = field_contract.get("pattern")
            if pattern and re.fullmatch(pattern, value) is None:
                findings.append(Finding("attribute.pattern", path, "attribute does not match the approved stable pattern"))
        if "enum" in field_contract and value not in field_contract["enum"]:
            findings.append(Finding("attribute.enum", path, "attribute is outside the approved enum"))
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if "minimum" in field_contract and value < field_contract["minimum"]:
                findings.append(Finding("attribute.minimum", path, "attribute is below the approved minimum"))
            if "maximum" in field_contract and value > field_contract["maximum"]:
                findings.append(Finding("attribute.maximum", path, "attribute exceeds the approved maximum"))

    allowed_combinations = signal_contract.get("allowedAttributeCombinations")
    if allowed_combinations is not None:
        matches_allowed_combination = any(
            all(attributes.get(key) == value for key, value in combination.items())
            for combination in allowed_combinations
        )
        if not matches_allowed_combination:
            findings.append(
                Finding(
                    "attribute.combination",
                    "$.attributes",
                    "attribute values do not form an approved lifecycle combination",
                )
            )

    for conditional in signal_contract.get("conditionalAttributes", []):
        when = conditional.get("when", {})
        if not all(attributes.get(key) == value for key, value in when.items()):
            continue
        for key in conditional.get("required", []):
            if key not in attributes:
                findings.append(
                    Finding(
                        "attribute.required_for_condition",
                        f"$.attributes.{key}",
                        "attribute is required for the matched condition",
                    )
                )
        for key in conditional.get("forbidden", []):
            if key in attributes:
                findings.append(
                    Finding(
                        "attribute.forbidden_for_condition",
                        f"$.attributes.{key}",
                        "attribute is forbidden for the matched condition",
                    )
                )

    approved_labels = set(signal_contract["metricLabels"]) | set(
        contract.get("commonMetricLabels", [])
    )
    for key, value in labels.items():
        path = f"$.metricLabels.{key}"
        if key not in approved_labels:
            findings.append(Finding("label.unapproved", path, "field is not an approved bounded metric label"))
        if key not in attributes or attributes.get(key) != value:
            findings.append(Finding("label.value_mismatch", path, "label must copy the matching validated attribute"))
        if isinstance(value, (dict, list)):
            findings.append(Finding("label.type", path, "metric label must be scalar"))

    return findings


def verify_fixtures(contract: dict[str, Any], fixtures_dir: Path) -> list[str]:
    errors: list[str] = []
    fixture_paths = sorted(fixtures_dir.glob("*.json"))
    if not fixture_paths:
        return [f"no fixtures found under {fixtures_dir}"]

    for path in fixture_paths:
        fixture = load_json(path)
        expectation = fixture.get("expect")
        expected_codes = set(fixture.get("expectedCodes", []))
        findings = validate_event(contract, fixture.get("event"))
        actual_codes = {finding.code for finding in findings}
        if expectation == "pass" and findings:
            errors.append(f"{path.name}: expected pass, got {sorted(actual_codes)}")
        elif expectation == "fail":
            missing = expected_codes - actual_codes
            if not findings:
                errors.append(f"{path.name}: expected failure, got pass")
            elif missing:
                errors.append(f"{path.name}: missing expected codes {sorted(missing)}; got {sorted(actual_codes)}")
        elif expectation not in {"pass", "fail"}:
            errors.append(f"{path.name}: expect must be pass or fail")
    return errors


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--fixtures-dir", type=Path, default=DEFAULT_FIXTURES)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    contract = load_json(args.contract)
    errors = verify_signal_authorities(contract)
    errors.extend(verify_fixtures(contract, args.fixtures_dir))
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(
        "Verified agent observability contract "
        f"schema={contract['schemaVersion']} signals={len(contract['signals'])} "
        f"fixtures={len(list(args.fixtures_dir.glob('*.json')))}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
