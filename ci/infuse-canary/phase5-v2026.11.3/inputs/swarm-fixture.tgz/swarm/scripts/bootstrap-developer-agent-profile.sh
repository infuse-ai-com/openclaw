#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

export AGENT_ID="${AGENT_ID:-agent-developer}"
export AGENT_NAME="${AGENT_NAME:-Tinus Lordvals}"
export OPENCLAW_AGENT_PROFILE="${OPENCLAW_AGENT_PROFILE:-agent-developer}"
export AGENT_DESCRIPTION="${AGENT_DESCRIPTION:-Scoped OpenClaw engineer for implementation, repo-local verification, engineering quality gates, and release readiness for assigned work.}"
export AGENT_THEME="${AGENT_THEME:-Engineering-minded OpenClaw worker}"
export MATTERMOST_CHANNEL_ID="${MATTERMOST_CHANNEL_ID:-1k6r6ipd87ry9j59xp8to59rnr}"

exec "$script_dir/bootstrap-agent-profile.sh"
