#!/usr/bin/env bash
set -euo pipefail

image_repository="${IMAGE_REPOSITORY:-registry.infuse-ai-tech.party/agents-swarm/openclaw-agent}"
image_tag="${IMAGE_TAG:-dev}"
image_revision="${IMAGE_REVISION:-dev}"
openclaw_version="${OPENCLAW_VERSION:-dev}"
source_revision="${SOURCE_REVISION:-dev}"
namespace="${NAMESPACE:-agents-swarm}"
include_namespace="${INCLUDE_NAMESPACE:-true}"
overlay_name="${OVERLAY_NAME:-infuseai}"
studio_native_profile="${STUDIO_NATIVE_PROFILE:-production}"
case "$studio_native_profile" in
  production|local-mac) ;;
  *) echo "Unsupported STUDIO_NATIVE_PROFILE." >&2; exit 2 ;;
esac
if [ "$studio_native_profile" != production ] && [ "$overlay_name" != studio-mission-cutover ]; then
  echo "The Mac authority requires the explicit Studio cutover overlay." >&2
  exit 2
fi

case "$overlay_name" in
  infuseai|studio-mission-cutover) ;;
  *) echo "Unsupported OVERLAY_NAME." >&2; exit 2 ;;
esac

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd -- "$script_dir/.." && pwd)"
workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT

cp -R "$repo_root/k8s" "$workdir/k8s"

python3 - "$workdir/k8s" "$image_repository" "$image_tag" "$image_revision" "$openclaw_version" "$source_revision" "$namespace" "$include_namespace" "$overlay_name" <<'PY'
from pathlib import Path
import json
import re
import sys

k8s_dir = Path(sys.argv[1])
image_repository = sys.argv[2]
image_tag = sys.argv[3]
image_revision = sys.argv[4]
openclaw_version = sys.argv[5]
source_revision = sys.argv[6]
namespace = sys.argv[7]
include_namespace = sys.argv[8].lower() not in {"0", "false", "no"}
overlay_name = sys.argv[9]

immutable_revision = re.fullmatch(r"sha256:[0-9a-f]{64}", image_revision)
if image_revision != "dev" and immutable_revision is None:
    raise SystemExit("IMAGE_REVISION must be dev or an immutable sha256 digest")
if source_revision != "dev" and re.fullmatch(r"[0-9a-f]{40}", source_revision) is None:
    raise SystemExit("SOURCE_REVISION must be dev or a full lowercase Git commit")

path = k8s_dir / "overlays/infuseai/kustomization.yaml"
text = path.read_text()
replacements = {
    "namespace: agents-swarm": f"namespace: {namespace}",
    "newName: registry.infuse-ai-tech.party/agents-swarm/openclaw-agent": f"newName: {image_repository}",
    "newTag: dev": (
        f"digest: {json.dumps(image_revision)}"
        if immutable_revision is not None
        else f"newTag: {json.dumps(image_tag)}"
    ),
}
for old, new in replacements.items():
    if old not in text:
        raise SystemExit(f"expected marker not found in {path}: {old}")
    text = text.replace(old, new)
if not include_namespace:
    marker = "  - namespace.yaml\n"
    if marker not in text:
        raise SystemExit(f"expected marker not found in {path}: {marker.rstrip()}")
    text = text.replace(marker, "")
path.write_text(text)

namespace_path = path.with_name("namespace.yaml")
namespace_text = namespace_path.read_text()
marker = "  name: agents-swarm"
if marker not in namespace_text:
    raise SystemExit(f"expected marker not found in {namespace_path}: {marker}")
namespace_path.write_text(namespace_text.replace(marker, f"  name: {namespace}"))

deployment_path = k8s_dir / "components/persistent-agent/deployment.yaml"
deployment_text = deployment_path.read_text()
replacements = {
    "openclaw.infuse-ai.com/version: dev":
        f"openclaw.infuse-ai.com/version: {json.dumps(openclaw_version)}",
    "openclaw.infuse-ai.com/image-revision: dev":
        f"openclaw.infuse-ai.com/image-revision: {json.dumps(image_revision)}",
    "openclaw.infuse-ai.com/swarm-source-revision: dev":
        f"openclaw.infuse-ai.com/swarm-source-revision: {json.dumps(source_revision)}",
}
for marker, replacement in replacements.items():
    if marker not in deployment_text:
        raise SystemExit(f"expected marker not found in {deployment_path}: {marker}")
    deployment_text = deployment_text.replace(marker, replacement)
deployment_path.write_text(deployment_text)
PY

if [ "$overlay_name" = studio-mission-cutover ]; then
  studio_route_file="$repo_root/config/studio-native-routes.json"
  if [ "$studio_native_profile" = local-mac ]; then
    studio_route_file="$repo_root/config/studio-native-routes.local-mac.json"
  fi
  python3 "$script_dir/prepare-studio-native-overlay.py" "$workdir/k8s" "$studio_route_file"
fi

python3 "$script_dir/prepare-internal-gateway-transport.py" "$workdir/k8s" \
  "${INTERNAL_GATEWAY_TRANSPORT_CONFIG:-$repo_root/config/internal-gateway-transport.json}"

kubectl kustomize "$workdir/k8s/overlays/$overlay_name"
