#!/usr/bin/env python3
"""Install one agent's binary installed skill set into its runtime workspace."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import hashlib
import re
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "config" / "skill-catalog.json"
BUNDLE_DIR = ROOT / "config" / "agent-skill-bundles"
SKIP_DIRS = {".git", "__pycache__", ".mypy_cache", ".pytest_cache", "node_modules"}


def env_key_for_source(source_id: str) -> str:
    safe = "".join(char if char.isalnum() else "_" for char in source_id).upper()
    return f"SKILL_SOURCE_ROOT_{safe}"


def source_root_hint(source_id: str, source: dict) -> str:
    options = [
        f"set {env_key_for_source(source_id)}",
        "set SKILL_SOURCE_CACHE_ROOT",
    ]
    if source.get("repo"):
        options.append("run through sync-agent-skills-startup.sh")
    local_path = source.get("local_path")
    container_path = source.get("container_path")
    configured = [
        str(path)
        for path in (local_path, container_path)
        if isinstance(path, str) and path
    ]
    if configured:
        options.append(f"make one configured path exist ({', '.join(configured)})")
    return "; ".join(options)


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    sys.exit(1)


def env_bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"missing {path}")
    except json.JSONDecodeError as exc:
        fail(f"{path} is invalid JSON: {exc}")


def run_git(root: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    command = ["git", "-C", str(root), *args]
    result = subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        fail(f"git command failed in {root}: {' '.join(command[3:])}: {detail}")
    return result


def resolve_source_root(source_id: str, source: dict) -> Path:
    override = os.environ.get(env_key_for_source(source_id))
    if override:
        return Path(override)

    source_cache_root = os.environ.get("SKILL_SOURCE_CACHE_ROOT")
    if source_cache_root and source.get("repo"):
        return Path(source_cache_root) / source_id

    local_path = source.get("local_path")
    container_path = source.get("container_path")
    if isinstance(local_path, str) and local_path:
        candidate = Path(local_path)
        if not candidate.is_absolute():
            candidate = ROOT / candidate
        if candidate.exists():
            return candidate

    if isinstance(container_path, str) and container_path:
        path_value = container_path
    elif isinstance(local_path, str) and local_path:
        path_value = local_path
    else:
        fail("skill source is missing local_path")

    path = Path(path_value)
    if not path.is_absolute():
        path = ROOT / path
    return path


def source_label(source_id: str, source: dict) -> str:
    return str(source.get("repo") or source_id)


def ensure_source_checkout(source_id: str, source: dict, root: Path) -> None:
    if root.exists():
        return
    if not env_bool("ALLOW_SKILL_SOURCE_CLONE"):
        return
    clone_url = source.get("clone_url")
    if not isinstance(clone_url, str) or not clone_url:
        return
    sync = source.get("sync") if isinstance(source.get("sync"), dict) else {}
    branch = sync.get("branch", "main")
    root.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["git", "clone", "--branch", str(branch), "--single-branch", clone_url, str(root)],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        fail(f"failed to clone source {source_label(source_id, source)} into {root}: {detail}")


def git_source_metadata(source_id: str, source: dict, root: Path) -> dict:
    if not (root / ".git").exists():
        return {
            "id": source_id,
            "repo": source.get("repo"),
            "path": str(root),
            "kind": "filesystem",
        }

    commit = run_git(root, "rev-parse", "HEAD").stdout.strip()
    branch = run_git(root, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    status = run_git(root, "status", "--porcelain").stdout
    remote = source.get("sync", {}).get("remote", "origin")
    remote_url_result = run_git(root, "remote", "get-url", str(remote), check=False)
    remote_url = remote_url_result.stdout.strip() if remote_url_result.returncode == 0 else None
    return {
        "id": source_id,
        "repo": source.get("repo"),
        "path": str(root),
        "kind": "git",
        "branch": branch,
        "commit": commit,
        "remote": remote,
        "remote_url": remote_url,
        "dirty": bool(status.strip()),
        "sync": source.get("sync"),
    }


def sync_git_source(source_id: str, source: dict, root: Path, sync_mode: str) -> None:
    sync = source.get("sync")
    if sync_mode == "none" or not isinstance(sync, dict):
        return
    strategy = sync.get("strategy")
    if strategy in {None, "manual"}:
        return
    if strategy not in {"latest", "pinned"}:
        fail(f"source {source_id} has unsupported sync strategy {strategy!r}")
    if not (root / ".git").exists():
        fail(f"source {source_label(source_id, source)} is not a git checkout: {root}")

    status = run_git(root, "status", "--porcelain").stdout.strip()
    allow_dirty = env_bool("ALLOW_DIRTY_SKILL_SOURCE")
    if status and not allow_dirty:
        fail(
            f"source {source_label(source_id, source)} has local changes at {root}; "
            "commit/stash them, set SKILL_SOURCE_SYNC=none, or set "
            "ALLOW_DIRTY_SKILL_SOURCE=true"
        )

    remote = sync.get("remote", "origin")
    branch = sync.get("branch", "main")
    if source_id == "infuse-ai-agent-skills":
        expected = source.get("clone_url")
        observed = run_git(root, "remote", "get-url", str(remote)).stdout.strip()
        legacy = "https://dev.azure.com/infuse-ai/Infuse%20AI/_git/agent-skills"
        canonical = "https://gitlab.infuse-ai-tech.party/platform/agents/agent-skills.git"
        if observed == legacy and expected == canonical and not status:
            run_git(root, "remote", "set-url", str(remote), canonical)
        elif observed != expected:
            fail("company skill source origin differs from its reviewed catalog")
    run_git(root, "fetch", str(remote), str(branch))
    if strategy == "latest":
        current_branch = run_git(root, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
        if current_branch != branch:
            run_git(root, "checkout", str(branch))
        run_git(root, "merge", "--ff-only", f"{remote}/{branch}")
        return

    pinned_commit = sync.get("commit")
    if not isinstance(pinned_commit, str) or re.fullmatch(r"[0-9a-f]{40}", pinned_commit) is None:
        fail(f"source {source_id} uses pinned sync but has no exact sync.commit")
    exists = run_git(root, "cat-file", "-e", f"{pinned_commit}^{{commit}}", check=False)
    on_branch = run_git(root, "merge-base", "--is-ancestor", pinned_commit, f"{remote}/{branch}", check=False)
    if exists.returncode != 0 or on_branch.returncode != 0:
        fail(
            f"source {source_label(source_id, source)} pinned commit is not on "
            f"{remote}/{branch}"
        )
    run_git(root, "checkout", "--detach", pinned_commit)
    current_commit = run_git(root, "rev-parse", "HEAD").stdout.strip()
    if current_commit != pinned_commit:
        fail(f"source {source_label(source_id, source)} did not reach its pinned commit")


def prepare_sources(catalog: dict, selected: list[str], sync_mode: str) -> dict:
    source_ids = {
        catalog["skills"][skill_id]["source"]
        for skill_id in selected
        if skill_id in catalog["skills"]
        and skill_materialization(skill_id, catalog) == "managed-copy"
    }
    prepared: dict[str, dict] = {}
    for source_id in sorted(source_ids):
        source = catalog["sources"].get(source_id)
        if not isinstance(source, dict):
            fail(f"selected skill references unknown source {source_id!r}")
        root = resolve_source_root(source_id, source)
        ensure_source_checkout(source_id, source, root)
        if not root.exists():
            fail(
                f"source {source_label(source_id, source)} is missing at {root}; "
                f"{source_root_hint(source_id, source)}"
            )
        sync_git_source(source_id, source, root, sync_mode)
        prepared[source_id] = {
            "definition": source,
            "root": root,
            "metadata": git_source_metadata(source_id, source, root),
        }
    return prepared


def resolve_skill_path(skill_id: str, catalog: dict, prepared_sources: dict) -> Path:
    skill = catalog["skills"].get(skill_id)
    if not isinstance(skill, dict):
        fail(f"unknown skill: {skill_id}")
    source_id = skill.get("source")
    prepared = prepared_sources.get(source_id)
    if not isinstance(prepared, dict):
        fail(f"skill {skill_id} references unknown source {source_id!r}")

    root = prepared["root"]
    candidates = [
        root / skill_id,
        root / "skills" / skill_id,
    ]
    for candidate in candidates:
        if (candidate / "SKILL.md").is_file():
            return candidate
    fail(
        "could not find SKILL.md for "
        f"{skill_id} under source {source_id} ({root})"
    )


def copy_skill(src: Path, dest: Path) -> None:
    if dest.exists() or dest.is_symlink():
        if dest.is_dir() and not dest.is_symlink():
            shutil.rmtree(dest)
        else:
            dest.unlink()

    def ignore(_directory: str, names: list[str]) -> set[str]:
        return {name for name in names if name in SKIP_DIRS}

    shutil.copytree(src, dest, symlinks=True, ignore=ignore)


def symlink_skill(src: Path, dest: Path) -> None:
    if dest.exists() or dest.is_symlink():
        if dest.is_dir() and not dest.is_symlink():
            shutil.rmtree(dest)
        else:
            dest.unlink()
    dest.symlink_to(src, target_is_directory=True)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def installed_file_manifest(root: Path) -> list[dict]:
    files: list[dict] = []
    if root.is_symlink():
        return [
            {
                "path": ".",
                "kind": "symlink",
                "target": os.readlink(root),
            }
        ]
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        files.append(
            {
                "path": relative,
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        )
    return files


def selected_skills(bundle: dict) -> list[str]:
    skills = bundle.get("skills")
    if not isinstance(skills, dict):
        fail("bundle.skills must be an object")
    installed = skills.get("installed")
    if not isinstance(installed, list) or not all(
        isinstance(skill_id, str) and skill_id for skill_id in installed
    ):
        fail("bundle.skills.installed must be a list of non-empty strings")
    return installed


def skill_materialization(skill_id: str, catalog: dict) -> str:
    skill = catalog["skills"].get(skill_id)
    if not isinstance(skill, dict):
        fail(f"unknown skill: {skill_id}")
    source_id = skill.get("source")
    source = catalog["sources"].get(source_id)
    if not isinstance(source, dict):
        fail(f"skill {skill_id} references unknown source {source_id!r}")
    materialization = source.get("materialization")
    if materialization not in {"managed-copy", "runtime-native"}:
        fail(f"source {source_id} has invalid materialization {materialization!r}")
    return materialization


def filter_selected_by_source(
    selected: list[str],
    catalog: dict,
    source_filter: set[str] | None,
) -> list[str]:
    if not source_filter:
        return selected
    filtered = []
    for skill_id in selected:
        skill = catalog["skills"].get(skill_id)
        if skill and skill.get("source") in source_filter:
            filtered.append(skill_id)
    return filtered


def prune_unselected_skills(
    target_dir: Path,
    catalog: dict,
    selected: list[str],
    source_filter: set[str] | None,
) -> None:
    """Remove catalog-known skills that are absent from the selected set."""
    selected_ids = set(selected)
    for skill_id, skill in catalog["skills"].items():
        materialization = skill_materialization(skill_id, catalog)
        stale = target_dir / skill_id
        if materialization == "runtime-native":
            if stale.exists() or stale.is_symlink():
                if stale.is_dir() and not stale.is_symlink():
                    shutil.rmtree(stale)
                else:
                    stale.unlink()
            continue
        if source_filter and skill.get("source") not in source_filter:
            continue
        if skill_id in selected_ids:
            continue
        if stale.exists() or stale.is_symlink():
            if stale.is_dir() and not stale.is_symlink():
                shutil.rmtree(stale)
            else:
                stale.unlink()


def main() -> int:
    agent_id = os.environ.get("AGENT_ID")
    if not agent_id:
        fail("Set AGENT_ID, for example AGENT_ID=agent-designer")

    dry_run = env_bool("DRY_RUN")
    source_sync = os.environ.get("SKILL_SOURCE_SYNC", "latest")
    if source_sync not in {"latest", "none"}:
        fail("SKILL_SOURCE_SYNC must be latest or none")
    install_mode = os.environ.get("SKILL_INSTALL_MODE", "copy")
    if install_mode not in {"copy", "symlink"}:
        fail("SKILL_INSTALL_MODE must be copy or symlink")

    workspace = Path(os.environ.get("OPENCLAW_WORKSPACE", "/workspace"))
    target_dir = Path(
        os.environ.get("AGENT_SKILLS_DIR", str(workspace / "agents" / agent_id / "skills"))
    )
    if dry_run:
        target_dir = Path(
            os.environ.get(
                "DRY_RUN_OUTPUT_DIR",
                str(
                    Path.home()
                    / ".local"
                    / "state"
                    / "openclaw"
                    / "dry-runs"
                    / f"skills-{agent_id}"
                ),
            )
        )

    catalog_path = Path(os.environ.get("SKILL_CATALOG_PATH", str(CATALOG_PATH)))
    bundle_dir = Path(os.environ.get("SKILL_BUNDLE_DIR", str(BUNDLE_DIR)))
    catalog = load_json(catalog_path)
    bundle_path = bundle_dir / f"{agent_id}.json"
    bundle = load_json(bundle_path)
    if bundle.get("agent_id") != agent_id:
        fail(f"{bundle_path} agent_id does not match {agent_id}")

    source_filter_value = os.environ.get("SKILL_SOURCE_IDS", "")
    source_filter = {
        source_id.strip()
        for source_id in source_filter_value.split(",")
        if source_id.strip()
    } or None
    declared = selected_skills(bundle)
    selected = filter_selected_by_source(
        declared,
        catalog,
        source_filter,
    )
    managed_selected = [
        skill_id
        for skill_id in selected
        if skill_materialization(skill_id, catalog) == "managed-copy"
    ]
    runtime_native_selected = [
        skill_id
        for skill_id in declared
        if skill_materialization(skill_id, catalog) == "runtime-native"
    ]
    prepared_sources = prepare_sources(catalog, managed_selected, source_sync)

    target_dir.mkdir(parents=True, exist_ok=True)
    if dry_run:
        target_dir.chmod(0o700)
    prune_unselected_skills(target_dir, catalog, selected, source_filter)

    manifest = {
        "agent_id": agent_id,
        "bundle": str(bundle_path),
        "installed_at": datetime.now(timezone.utc).isoformat(),
        "dry_run": dry_run,
        "install_mode": install_mode,
        "source_sync": source_sync,
        "source_filter": sorted(source_filter) if source_filter else None,
        "declared_skills": declared,
        "sources": {
            source_id: prepared["metadata"]
            for source_id, prepared in sorted(prepared_sources.items())
        },
        "skills": [],
        "runtime_native_skills": [
            {
                "id": skill_id,
                "source": catalog["skills"][skill_id]["source"],
                **catalog["skills"][skill_id]["runtime_native"],
            }
            for skill_id in runtime_native_selected
        ],
    }

    for skill_id in managed_selected:
        src = resolve_skill_path(skill_id, catalog, prepared_sources)
        source_id = catalog["skills"][skill_id]["source"]
        source_metadata = prepared_sources[source_id]["metadata"]
        dest = target_dir / skill_id
        if install_mode == "copy":
            copy_skill(src, dest)
        else:
            symlink_skill(src, dest)
        manifest["skills"].append(
            {
                "id": skill_id,
                "source": source_id,
                "source_commit": source_metadata.get("commit"),
                "source_branch": source_metadata.get("branch"),
                "installed_path": str(dest),
                "files": installed_file_manifest(dest),
            }
        )

    manifest_name = os.environ.get("SKILL_MANIFEST_NAME", "skill-bundle-manifest.json")
    manifest_path = target_dir / manifest_name
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    print(
        f"Materialized {len(manifest['skills'])} managed-copy skill(s) and declared "
        f"{len(manifest['runtime_native_skills'])} runtime-native skill(s) for "
        f"{agent_id}: {target_dir}"
    )
    if dry_run:
        print("Dry-run output only; no runtime PVC was modified.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
