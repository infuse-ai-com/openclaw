#!/usr/bin/env python3
"""Plan/apply a backed-up, offline removal of one workspace's derived dreaming rows.

Native memory reset owns search indexes. Completed ingestion cursors are kept
so old messages are not replayed and new messages remain eligible.
This scoped maintenance helper covers remaining daily-derived recall state only.
The caller must stop the Gateway and all other writers through their owner.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3

NAMESPACES = (
    'dreaming-daily-provenance', 'dreaming-daily-ingestion',
    'dreaming-memory-backups', 'short-term-meta', 'short-term-phase-signals',
    'short-term-recall', 'short-term-locks',
)


def rows_and_plan(db, workspace):
    key = hashlib.sha256(str(workspace).encode()).hexdigest() + ':'
    rows = list(db.execute('SELECT namespace,entry_key,value_json,created_at,expires_at FROM plugin_state_entries WHERE plugin_id=? ORDER BY namespace,entry_key', ('memory-core',)))
    selected = [row for row in rows if row[0] in NAMESPACES and row[1].startswith(key)]
    cursors = [row for row in rows if row[0] in ('dreaming-session-ingestion-files', 'dreaming-session-ingestion-seen') and row[1].startswith(key)]
    partial = sum(json.loads(row[2]).get('value', {}).get('lastContentLine', 0) < json.loads(row[2]).get('value', {}).get('lineCount', 0) for row in cursors if row[0] == 'dreaming-session-ingestion-files')
    counts = {namespace: sum(row[0] == namespace for row in selected) for namespace in NAMESPACES}
    return key, selected, {'workspace': str(workspace), 'counts': counts, 'rows_sha256': hashlib.sha256(json.dumps(selected).encode()).hexdigest(), 'cursor_sha256': hashlib.sha256(json.dumps(cursors).encode()).hexdigest(), 'cursor_rows': len(cursors), 'partial_cursors': partial}


def prune(db, workspace, expected):
    db.execute('BEGIN IMMEDIATE')
    try:
        key, selected, plan = rows_and_plan(db, workspace)
        if plan['partial_cursors']:
            raise ValueError('incomplete ingestion cursors require reconciliation before pruning')
        if plan != expected:
            raise ValueError('derived state changed since the reviewed plan; refusing prune')
        for namespace in NAMESPACES:
            db.execute('DELETE FROM plugin_state_entries WHERE plugin_id=? AND namespace=? AND entry_key LIKE ?', ('memory-core', namespace, key + '%'))
        after = rows_and_plan(db, workspace)[2]
        if after['cursor_sha256'] != plan['cursor_sha256']:
            raise ValueError('ingestion cursors changed')
        if any(after['counts'].values()):
            raise ValueError('derived state was not completely removed')
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ValueError('database integrity check failed')
        db.commit()
        return {'removed_rows': len(selected), 'workspace': str(workspace), 'preserved': 'session ingestion cursors, other plugins/workspaces, memory-host event cursors, sessions and tombstones'}
    except BaseException:
        db.rollback()
        raise


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--state-db', type=Path, required=True)
    p.add_argument('--workspace', type=Path, required=True)
    p.add_argument('--apply-plan', type=Path)
    p.add_argument('--offline-owner-ack', action='store_true', help='Caller has stopped the Gateway and other writers and verified a recoverable backup.')
    a = p.parse_args()
    if not a.workspace.is_absolute() or not a.state_db.is_file(): p.error('existing database and absolute workspace required')
    if a.apply_plan and not a.offline_owner_ack: p.error('application requires explicit offline ownership acknowledgement')
    uri = a.state_db.resolve().as_uri() + ('?mode=rw' if a.apply_plan else '?mode=ro')
    with sqlite3.connect(uri, uri=True) as db:
        result = prune(db, a.workspace, json.loads(a.apply_plan.read_text())) if a.apply_plan else rows_and_plan(db, a.workspace)[2]
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__': main()
