#!/usr/bin/env python3
"""Bounded synthetic parser checks for image builds/disposable qualification pods."""
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import tempfile

if os.environ.get('OPENCLAW_ISOLATED_QUALIFICATION') != '1' or Path('/workspace/agents').exists():
    raise SystemExit('use only an isolated image build or disposable qualification pod')

from bs4 import BeautifulSoup
from lxml import etree
import soupsieve

assert importlib.metadata.version('soupsieve') == '4.0'
signal.alarm(10)
normal = BeautifulSoup('<section><div class="a"><div>expected</div></div></section>', 'html.parser')
assert [node.text for node in normal.select('section div.a > div')] == ['expected']
# Bounded upstream GHSA-mmhr-3c5m-f64f regression shape, run only in isolation.
# Do not opt into NOCACHE, which restores the vulnerable matching behavior.
deep = BeautifulSoup('<div>' * 200, 'html.parser')
assert soupsieve.select('section div div div', deep) == []

with tempfile.TemporaryDirectory() as folder:
    sentinel = Path(folder) / 'synthetic.txt'
    sentinel.write_text('synthetic-file-must-not-expand')
    fixture = f'<!DOCTYPE root [<!ENTITY external SYSTEM "{sentinel.as_uri()}">]><root>&external;</root>'
    parser = etree.XMLParser(resolve_entities=False, load_dtd=False, no_network=True, huge_tree=False)
    document = etree.fromstring(fixture.encode(), parser=parser)
    assert b'synthetic-file-must-not-expand' not in etree.tostring(document)
    assert etree.fromstring(b'<root><value>expected</value></root>', parser=parser).findtext('value') == 'expected'
signal.alarm(0)
print(json.dumps({'soupsieve': importlib.metadata.version('soupsieve'),
                  'selectorRegression': 'passed', 'lxmlSafeEntityHandling': 'passed',
                  'lxmlCompiledLibxml': etree.LIBXML_COMPILED_VERSION,
                  'lxmlRuntimeLibxml': etree.LIBXML_VERSION,
                  'systemLibxmlRemediationClaimed': False}))
