#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"
kube_context="${KUBE_CONTEXT:-infuseai-k8s}"
agent_id="${1:-}"
shared_service_account="openclaw-agent"
service_account_manifest="k8s/overlays/infuseai/serviceaccount.yaml"
allowed_agents=(agent-developer agent-coordinator agent-designer agent-infra agent-intake)

if [ "${CONFIRM_RETRIEVAL_IDENTITY_ROLLOUT:-}" != "yes" ]; then
  echo "Set CONFIRM_RETRIEVAL_IDENTITY_ROLLOUT=yes after the reviewed rollout gate passes." >&2
  exit 2
fi
if [[ ! " ${allowed_agents[*]} " =~ " ${agent_id} " ]]; then
  echo "Usage: $0 {agent-developer|agent-coordinator|agent-designer|agent-infra|agent-intake}" >&2
  exit 2
fi

for command in kubectl jq shasum; do
  command -v "$command" >/dev/null 2>&1 || {
    echo "Missing required command: $command" >&2
    exit 1
  }
done

kubectl_cmd=(kubectl --context "$kube_context")
target_service_account="openclaw-$agent_id"
deployment_changed=false
original_service_account=""
original_image=""
workdir="$(mktemp -d)"

cleanup() {
  rm -rf "$workdir"
}

rollback_on_error() {
  local exit_code=$?
  if [ "$deployment_changed" = true ] && [ -n "$original_service_account" ]; then
    echo "Identity rollout failed; restoring deployment/$agent_id to $original_service_account." >&2
    "${kubectl_cmd[@]}" -n "$namespace" patch "deployment/$agent_id" --type=merge \
      -p "{\"spec\":{\"template\":{\"spec\":{\"serviceAccountName\":\"$original_service_account\"}}}}" >&2 || true
    "${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$agent_id" --timeout=420s >&2 || true
  fi
  cleanup
  exit "$exit_code"
}
trap rollback_on_error ERR
trap cleanup EXIT

identity="$("${kubectl_cmd[@]}" auth whoami -o json | jq -r '.status.userInfo.username // empty')"
if [ -z "$identity" ]; then
  echo "Could not resolve the active Kubernetes identity." >&2
  exit 1
fi
echo "Kubernetes identity: $identity"

for permission in "get deployments.apps" "patch deployments.apps" "create serviceaccounts" "patch serviceaccounts"; do
  read -r verb resource <<<"$permission"
  if [ "$("${kubectl_cmd[@]}" auth can-i "$verb" "$resource" -n "$namespace")" != "yes" ]; then
    echo "Current identity cannot $verb $resource in $namespace." >&2
    exit 1
  fi
done

template_fingerprint() {
  "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$1" -o json \
    | jq -cS '.spec.template' | shasum -a 256 | awk '{print $1}'
}

for peer in "${allowed_agents[@]}"; do
  if [ "$peer" != "$agent_id" ]; then
    template_fingerprint "$peer" >"$workdir/$peer.before"
  fi
done

original_service_account="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent_id" -o jsonpath='{.spec.template.spec.serviceAccountName}')"
if [ "$original_service_account" != "$shared_service_account" ] && [ "$original_service_account" != "$target_service_account" ]; then
  echo "Refusing unexpected current ServiceAccount: $original_service_account" >&2
  exit 1
fi
original_image="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent_id" -o jsonpath='{.spec.template.spec.containers[?(@.name=="agent")].image}')"

"${kubectl_cmd[@]}" -n "$namespace" apply --dry-run=server -f "$service_account_manifest" >/dev/null
"${kubectl_cmd[@]}" -n "$namespace" apply -f "$service_account_manifest" >/dev/null

if [ "$original_service_account" != "$target_service_account" ]; then
  deployment_changed=true
  "${kubectl_cmd[@]}" -n "$namespace" patch "deployment/$agent_id" --type=merge \
    -p "{\"spec\":{\"template\":{\"spec\":{\"serviceAccountName\":\"$target_service_account\"}}}}"
  "${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$agent_id" --timeout=420s
fi

KUBE_CONTEXT="$kube_context" NAMESPACE="$namespace" AGENT_ID="$agent_id" \
  scripts/smoke-agent-runtime.sh "$namespace" "$agent_id"
"${kubectl_cmd[@]}" -n "$namespace" exec -i "deployment/$agent_id" -c agent -- \
  env AGENT_ID="$agent_id" node - <scripts/smoke-agent-knowledge-retrieval.mjs

actual_service_account="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent_id" -o jsonpath='{.spec.template.spec.serviceAccountName}')"
actual_image="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$agent_id" -o jsonpath='{.spec.template.spec.containers[?(@.name=="agent")].image}')"
if [ "$actual_service_account" != "$target_service_account" ]; then
  echo "Deployment did not retain the exact distinct ServiceAccount." >&2
  exit 1
fi
if [ "$actual_image" != "$original_image" ]; then
  echo "Deployment image changed during the identity-only rollout." >&2
  exit 1
fi

for peer in "${allowed_agents[@]}"; do
  if [ "$peer" != "$agent_id" ] && [ "$(template_fingerprint "$peer")" != "$(cat "$workdir/$peer.before")" ]; then
    echo "Identity rollout changed peer deployment/$peer; stop and investigate." >&2
    exit 1
  fi
done

deployment_changed=false
echo "Verified deployment/$agent_id on $target_service_account with runtime and Discover-to-Fetch smokes; peer templates are unchanged."
