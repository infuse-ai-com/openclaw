#!/usr/bin/env python3
"""Split rendered resources from persistent-agent Deployment rollout units."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any


def select_documents(
    documents: list[dict[str, Any]],
    *,
    mode: str,
    agents: set[str],
    deployment: str | None,
) -> list[dict[str, Any]]:
    if mode == "shared":
        return [
            document
            for document in documents
            if not (
                document.get("kind") == "Deployment"
                and document.get("metadata", {}).get("name") in agents
            )
        ]

    if deployment is None or deployment not in agents:
        raise ValueError("deployment mode requires one declared persistent agent")
    selected = [
        document
        for document in documents
        if document.get("kind") == "Deployment"
        and document.get("metadata", {}).get("name") == deployment
    ]
    if len(selected) != 1:
        raise ValueError(f"expected exactly one rendered Deployment/{deployment}, found {len(selected)}")
    selected[0].setdefault("spec", {})["replicas"] = 0
    return selected


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--mode", choices=("shared", "deployment"), required=True)
    value.add_argument("--agent", action="append", default=[])
    value.add_argument("--deployment")
    return value


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        value = json.load(sys.stdin)
        if not isinstance(value, dict):
            raise ValueError("input must be one Kubernetes object or List")
        if value.get("kind") == "List":
            documents = value.get("items")
            if not isinstance(documents, list) or not all(isinstance(item, dict) for item in documents):
                raise ValueError("Kubernetes List items must be objects")
        else:
            documents = [value]
        selected = select_documents(
            documents,
            mode=args.mode,
            agents=set(args.agent),
            deployment=args.deployment,
        )
    except (ValueError, json.JSONDecodeError) as exc:
        print(f"manifest selection failed: {exc}", file=sys.stderr)
        return 2

    if args.mode == "shared":
        json.dump({"apiVersion": "v1", "kind": "List", "items": selected}, sys.stdout, separators=(",", ":"))
    else:
        json.dump(selected[0], sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
