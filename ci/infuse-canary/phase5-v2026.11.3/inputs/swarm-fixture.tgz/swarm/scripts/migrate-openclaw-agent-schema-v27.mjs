#!/usr/bin/env node

import { realpathSync, statSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import { pathToFileURL } from "node:url";

const EXPECTED_RUNTIME_VERSION = "2026.11.3";
const EXPECTED_SCHEMA_VERSION = 27;
const MAINTENANCE_LEASE_MODULE =
  "/usr/local/lib/node_modules/openclaw/dist/" +
  "openclaw-agent-db-maintenance-lease-BnxXacoQ.mjs";
const MAINTENANCE_MODULE =
  "/usr/local/lib/node_modules/openclaw/dist/" +
  "openclaw-agent-db-maintenance-DIdAFgIX.mjs";

function fail(message) {
  console.error(`ERROR: ${message}`);
  process.exit(1);
}

function readSchemaVersion(databasePath) {
  const database = new DatabaseSync(databasePath, { readOnly: true });
  try {
    const row = database.prepare("PRAGMA user_version").get();
    return Number(row.user_version ?? Object.values(row)[0]);
  } finally {
    database.close();
  }
}

const [agentId, requestedDatabasePath] = process.argv.slice(2);
if (process.env.OPENCLAW_RUNTIME_VERSION !== EXPECTED_RUNTIME_VERSION) {
  fail(
    `schema migration helper is pinned to OpenClaw ${EXPECTED_RUNTIME_VERSION}; ` +
      `got ${process.env.OPENCLAW_RUNTIME_VERSION ?? "unset"}`,
  );
}
if (!agentId || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(agentId)) {
  fail("agent id is missing or invalid");
}
const stateDir = path.resolve(
  process.env.OPENCLAW_STATE_DIR ??
    path.join(process.env.HOME ?? "", `.openclaw-${agentId}`),
);
const expectedDatabasePath = path.resolve(
  stateDir,
  "agents",
  agentId,
  "agent",
  "openclaw-agent.sqlite",
);
const databasePath = path.resolve(requestedDatabasePath ?? expectedDatabasePath);
if (databasePath !== expectedDatabasePath) {
  fail(`database path must be ${expectedDatabasePath}`);
}
if (!statSync(databasePath).isFile()) {
  fail(`agent database is not a regular file: ${databasePath}`);
}
if (realpathSync(databasePath) !== databasePath) {
  fail(`agent database must not resolve through a symlink: ${databasePath}`);
}

const beforeVersion = readSchemaVersion(databasePath);
if (beforeVersion === EXPECTED_SCHEMA_VERSION) {
  console.log(
    JSON.stringify({
      agentId,
      databasePath,
      fromVersion: beforeVersion,
      migrated: false,
      toVersion: beforeVersion,
    }),
  );
  process.exit(0);
}
if (!Number.isInteger(beforeVersion) || beforeVersion < 1 || beforeVersion > 26) {
  fail(`unsupported agent database schema version ${beforeVersion}`);
}

const leaseModule = await import(pathToFileURL(MAINTENANCE_LEASE_MODULE).href);
const maintenanceModule = await import(pathToFileURL(MAINTENANCE_MODULE).href);
const withAgentDatabaseMaintenanceLease = leaseModule.t;
const migrateOpenClawAgentDatabaseForMaintenance = maintenanceModule.r;
if (
  typeof withAgentDatabaseMaintenanceLease !== "function" ||
  typeof migrateOpenClawAgentDatabaseForMaintenance !== "function"
) {
  fail("pinned OpenClaw maintenance exports are unavailable");
}

await withAgentDatabaseMaintenanceLease(
  { env: process.env },
  async (maintenance) => {
    await migrateOpenClawAgentDatabaseForMaintenance(
      {
        agentId,
        pathname: databasePath,
        env: process.env,
      },
      maintenance,
    );
  },
);

const afterVersion = readSchemaVersion(databasePath);
if (afterVersion !== EXPECTED_SCHEMA_VERSION) {
  fail(
    `agent database schema migration did not converge: ` +
      `${beforeVersion} -> ${afterVersion}`,
  );
}
console.log(
  JSON.stringify({
    agentId,
    databasePath,
    fromVersion: beforeVersion,
    migrated: true,
    toVersion: afterVersion,
  }),
);
