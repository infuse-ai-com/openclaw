#!/usr/bin/env bash
set -euo pipefail

tmp_root="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_root"
}
trap cleanup EXIT

source_repo="$tmp_root/source/openclaw-k8s-swarm"
mkdir -p "$source_repo"
git -C "$source_repo" init --initial-branch=main >/dev/null
git -C "$source_repo" config user.email "verify-agent-task-workspace@example.invalid"
git -C "$source_repo" config user.name "Agent Workspace Verify"
printf 'initial\n' >"$source_repo/README.md"
git -C "$source_repo" add README.md
git -C "$source_repo" commit -m "seed repo" >/dev/null
source_commit="$(git -C "$source_repo" rev-parse HEAD)"
source_sha256="$(python3 -c 'import hashlib, pathlib, sys; print(hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest())' "$source_repo/README.md")"

workspace="$tmp_root/workspace"
common_base_args=(
  --agent-id agent-infra
  --workspace-root "$workspace"
)
common_create_args=(
  "${common_base_args[@]}"
  create
  --repo-name openclaw-k8s-swarm
  --source-url "$source_repo"
  --allow-source-override
)

scripts/agent-task-workspace.py \
  "${common_base_args[@]}" \
  ensure-registry >/dev/null
test -f "$workspace/tasks/task-registry.json"
grep -q '"tasks": {}' "$workspace/tasks/task-registry.json"

scripts/agent-task-workspace.py "${common_create_args[@]}" --task-id task-alpha >/dev/null
scripts/agent-task-workspace.py "${common_create_args[@]}" --task-id task-beta >/dev/null
scripts/agent-task-workspace.py \
  --agent-id agent-infra \
  --workspace-root "$workspace" \
  start \
  --repo-name openclaw-k8s-swarm \
  --task-id task-gamma \
  --source-url "$source_repo" \
  --allow-source-override \
  --title "Verify task start" \
  --objective "Prove start records a task brief and registry entry." \
  --acceptance "Registry contains task-gamma." >/dev/null

alpha_repo="$workspace/tasks/task-alpha/repos/openclaw-k8s-swarm"
beta_repo="$workspace/tasks/task-beta/repos/openclaw-k8s-swarm"
gamma_dir="$workspace/tasks/task-gamma"
test -d "$alpha_repo/.git"
test -d "$beta_repo/.git"
test -f "$workspace/tasks/task-alpha/task-workspace.json"
test -f "$workspace/tasks/task-beta/task-workspace.json"
test -f "$gamma_dir/task-brief.md"
test -f "$workspace/tasks/task-registry.json"
grep -q '"task-gamma"' "$workspace/tasks/task-registry.json"
grep -q '"status": "assigned"' "$gamma_dir/task-workspace.json"
grep -q '"fresh_checkout": true' "$gamma_dir/task-workspace.json"
grep -q '"required_when_available": true' "$gamma_dir/task-workspace.json"
grep -q 'branch-triggered CI/CD' "$gamma_dir/task-workspace.json"
grep -q '^## Evidence Contract$' "$gamma_dir/task-brief.md"
grep -q 'openclaw-agent-evidence-verify' "$gamma_dir/task-brief.md"
grep -q 'exact command, exit code, short stderr tail' "$gamma_dir/task-brief.md"

source_output="$workspace/source-read/README.md"
source_result="$(scripts/agent-task-workspace.py \
  --agent-id agent-infra \
  --workspace-root "$workspace" \
  read-source \
  --repo-name openclaw-k8s-swarm \
  --source-url "$source_repo" \
  --allow-source-override \
  --commit "$source_commit" \
  --path README.md \
  --expected-sha256 "$source_sha256" \
  --output "$source_output")"
cmp "$source_repo/README.md" "$source_output"
jq -e \
  --arg commit "$source_commit" \
  --arg sha256 "$source_sha256" \
  '.repository == "openclaw-k8s-swarm" and .commit == $commit and .sha256 == $sha256 and .bytes > 0' \
  <<<"$source_result" >/dev/null

wrong_hash_output="$workspace/source-read/wrong-hash.md"
if scripts/agent-task-workspace.py \
  --agent-id agent-infra \
  --workspace-root "$workspace" \
  read-source \
  --repo-name openclaw-k8s-swarm \
  --source-url "$source_repo" \
  --allow-source-override \
  --commit "$source_commit" \
  --path README.md \
  --expected-sha256 "$(printf '0%.0s' {1..64})" \
  --output "$wrong_hash_output" >/dev/null 2>&1; then
  echo "ERROR: read-source should reject a mismatched SHA-256" >&2
  exit 1
fi
test ! -e "$wrong_hash_output"

fake_bin="$tmp_root/fake-bin"
git_called_marker="$tmp_root/git-called"
mkdir -p "$fake_bin"
cat >"$fake_bin/git" <<'EOF'
#!/usr/bin/env bash
touch "${GIT_CALLED_MARKER:?}"
exit 99
EOF
chmod +x "$fake_bin/git"
if PATH="$fake_bin:$PATH" GIT_CALLED_MARKER="$git_called_marker" \
  scripts/agent-task-workspace.py \
  --agent-id agent-infra \
  --workspace-root "$workspace" \
  read-source \
  --repo-name infrastructure \
  --source-url "$source_repo" \
  --commit "$source_commit" \
  --path README.md \
  --output "$workspace/source-read/denied.md" >/dev/null 2>&1; then
  echo "ERROR: denied read-source request should fail" >&2
  exit 1
fi
test ! -e "$git_called_marker"

printf 'alpha\n' >>"$alpha_repo/README.md"
printf 'beta\n' >>"$beta_repo/README.md"
grep -q '^alpha$' "$alpha_repo/README.md"
grep -q '^beta$' "$beta_repo/README.md"
if grep -q '^beta$' "$alpha_repo/README.md"; then
  echo "ERROR: beta task change leaked into alpha checkout" >&2
  exit 1
fi
if grep -q '^alpha$' "$beta_repo/README.md"; then
  echo "ERROR: alpha task change leaked into beta checkout" >&2
  exit 1
fi

if scripts/agent-task-workspace.py "${common_create_args[@]}" --task-id task-alpha >/dev/null 2>&1; then
  echo "ERROR: duplicate task workspace create should fail without --resume" >&2
  exit 1
fi

if scripts/agent-task-workspace.py \
  --agent-id agent-infra \
  --workspace-root "$workspace" \
  create \
  --repo-name infrastructure \
  --task-id task-denied \
  --source-url "$source_repo" \
  >/dev/null 2>&1; then
  echo "ERROR: denied repo should be denied" >&2
  exit 1
fi

default_allow_workspace="$tmp_root/default-allow-workspace"
if scripts/agent-task-workspace.py \
  --agent-id agent-infra \
  --workspace-root "$default_allow_workspace" \
  create \
  --repo-name arbitrary-repo \
  --task-id task-no-url >/dev/null 2>&1; then
  echo "ERROR: default-allow repo access should require --source-url" >&2
  exit 1
fi
scripts/agent-task-workspace.py \
  --agent-id agent-infra \
  --workspace-root "$default_allow_workspace" \
  create \
  --repo-name arbitrary-repo \
  --task-id task-default-allow \
  --source-url "$source_repo" >/dev/null
test -d "$default_allow_workspace/tasks/task-default-allow/repos/arbitrary-repo/.git"
grep -q '"wildcard_repo_access": true' "$default_allow_workspace/tasks/task-default-allow/task-workspace.json"

scripts/agent-task-workspace.py --agent-id agent-infra --workspace-root "$workspace" list >/dev/null
scripts/agent-task-workspace.py --agent-id agent-infra --workspace-root "$workspace" list --all --status assigned >/dev/null
scripts/agent-task-workspace.py --agent-id agent-infra --workspace-root "$workspace" status --task-id task-alpha >/dev/null
if scripts/agent-task-workspace.py --agent-id agent-infra --workspace-root "$workspace" cleanup --task-id task-beta --yes >/dev/null 2>&1; then
  echo "ERROR: dirty task workspace cleanup should fail without --force" >&2
  exit 1
fi
scripts/agent-task-workspace.py --agent-id agent-infra --workspace-root "$workspace" cleanup --task-id task-beta --yes --force >/dev/null
test ! -e "$workspace/tasks/task-beta"
grep -q '"status": "cleaned"' "$workspace/tasks/task-registry.json"

echo "Verified isolated agent task workspaces."
