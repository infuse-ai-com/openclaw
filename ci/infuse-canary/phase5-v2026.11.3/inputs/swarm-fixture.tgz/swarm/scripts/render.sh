#!/usr/bin/env bash
set -euo pipefail

kubectl kustomize k8s/overlays/infuseai >/tmp/openclaw-k8s-swarm-infuseai.yaml
kubectl kustomize k8s/agents/agent-developer >/tmp/openclaw-k8s-swarm-agent-developer.yaml
kubectl kustomize k8s/agents/agent-designer >/tmp/openclaw-k8s-swarm-agent-designer.yaml
kubectl kustomize k8s/agents/agent-infra >/tmp/openclaw-k8s-swarm-agent-infra.yaml
kubectl kustomize k8s/agents/agent-coordinator >/tmp/openclaw-k8s-swarm-agent-coordinator.yaml
kubectl kustomize k8s/agents/agent-intake >/tmp/openclaw-k8s-swarm-agent-intake.yaml

echo "Rendered manifests:"
echo "  /tmp/openclaw-k8s-swarm-infuseai.yaml"
echo "  /tmp/openclaw-k8s-swarm-agent-developer.yaml"
echo "  /tmp/openclaw-k8s-swarm-agent-designer.yaml"
echo "  /tmp/openclaw-k8s-swarm-agent-infra.yaml"
echo "  /tmp/openclaw-k8s-swarm-agent-coordinator.yaml"
echo "  /tmp/openclaw-k8s-swarm-agent-intake.yaml"
