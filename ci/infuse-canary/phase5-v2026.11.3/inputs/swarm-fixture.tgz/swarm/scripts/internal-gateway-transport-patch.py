#!/usr/bin/env python3
"""Prepare one additive, version-guarded transport patch without cluster access."""
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]


def load_owner(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


identity = load_owner("dashboard_identity_scope_patch", "dashboard-identity-scope-patch.py")
transport = load_owner("prepare_internal_gateway_transport", "prepare-internal-gateway-transport.py")
PatchError = identity.PatchError
NAMESPACE = identity.NAMESPACE
VOLUME_NAMES = {"gateway-tls-code", "gateway-tls-identity", "gateway-tls-no-api-token"}


def named(items: object, label: str) -> dict[str, tuple[int, dict]]:
    if not isinstance(items, list) or any(not isinstance(item, dict) or not isinstance(item.get("name"), str) or not item["name"] for item in items):
        raise PatchError(f"{label} must be a list of named objects")
    if len({item["name"] for item in items}) != len(items):
        raise PatchError(f"{label} contains duplicate names")
    return {item["name"]: (index, item) for index, item in enumerate(items)}


def deployment_parts(value: dict, agent_id: str, image: str) -> tuple[dict, dict, dict, int, int, str, dict]:
    value = identity.object_value(value, "Deployment")
    metadata = identity.object_value(value.get("metadata"), "Deployment metadata")
    if (value.get("apiVersion"), value.get("kind"), metadata.get("name"), metadata.get("namespace")) != ("apps/v1", "Deployment", agent_id, NAMESPACE):
        raise PatchError("Expected the selected apps/v1 Deployment in agents-swarm")
    spec = identity.object_value(value.get("spec"), "Deployment spec")
    template = identity.object_value(spec.get("template"), "Pod template")
    labels = identity.object_value(template.get("metadata"), "Pod metadata").get("labels", {})
    selector = identity.object_value(spec.get("selector"), "Deployment selector").get("matchLabels", {})
    if labels.get("app.kubernetes.io/name") != agent_id or selector.get("app.kubernetes.io/name") != agent_id:
        raise PatchError("Deployment and Pod labels do not identify the selected agent")
    pod = identity.object_value(template.get("spec"), "Pod spec")
    if pod.get("hostNetwork", False) is not False or pod.get("securityContext", {}).get("fsGroup") != 10001:
        raise PatchError("Expected isolated Pod networking and the existing TLS volume group")
    containers = named(pod.get("containers"), "Containers")
    named(pod.get("volumes"), "Volumes")
    if "agent" not in containers:
        raise PatchError("Deployment must contain the agent container")
    index, agent = containers["agent"]
    if agent.get("image") != image:
        raise PatchError("Agent image differs from the expected immutable image")
    env = named(agent.get("env"), "Agent environment")
    if env.get("AGENT_ID", (None, None))[1] != {"name": "AGENT_ID", "value": agent_id}:
        raise PatchError("Agent environment does not identify the selected workload")
    env_index, config = env.get(identity.CONFIG_ENV, (None, None))
    if not isinstance(config, dict) or set(config) != {"name", "value"} or not isinstance(config["value"], str):
        raise PatchError("Agent config must be one literal environment value")
    return metadata, pod, agent, index, env_index, config["value"], identity.parse_json(config["value"])


def config_state(config: dict, agent_id: str) -> bool:
    baseline = copy.deepcopy(config)
    gateway = identity.object_value(baseline.get("gateway"), "Gateway config")
    auth = identity.object_value(gateway.get("auth"), "Gateway auth")
    proxy = identity.object_value(auth.get("trustedProxy"), "Trusted proxy config")
    if gateway.get("bind") != "lan" or gateway.get("port") != 18791:
        raise PatchError("Gateway listener differs from the reviewed loopback destination")
    sources = gateway.get("trustedProxies")
    loopback = proxy.get("allowLoopback")
    complete = sources == ["10.1.42.208", "127.0.0.1"] and loopback is True
    absent = sources == ["10.1.42.208"] and "allowLoopback" not in proxy
    if not (complete or absent):
        raise PatchError("Loopback trust is partial or differs from the reviewed transport")
    if complete:
        gateway["trustedProxies"] = ["10.1.42.208"]
        del proxy["allowLoopback"]
    _, baseline_auth = identity.gateway_baseline(baseline, agent_id)
    scopes = identity.object_value(baseline_auth.get("identityScopes"), "Identity scopes")
    if scopes.get(identity.IDENTITY) != identity.GRANT:
        raise PatchError("Verified Fito administration must be present before transport migration")
    return complete


def without_api_defaults(container: dict) -> dict:
    """Only Kubernetes' harmless defaulted fields may differ on an installed sidecar."""
    result = copy.deepcopy(container)
    defaults = {"terminationMessagePath": "/dev/termination-log", "terminationMessagePolicy": "File",
                "stdin": False, "stdinOnce": False, "tty": False}
    for field, value in defaults.items():
        if field in result and type(result[field]) is type(value) and result[field] == value:
            del result[field]
    for field in ("readinessProbe", "livenessProbe"):
        probe = result.get(field, {})
        for key, value in {"failureThreshold": 3, "successThreshold": 1, "timeoutSeconds": 1, "initialDelaySeconds": 0}.items():
            if key in probe and type(probe[key]) is int and probe[key] == value:
                del probe[key]
    return result


def reviewed_additions(rendered: dict, agent_id: str, image: str) -> tuple[dict, list[dict]]:
    rendered = identity.object_value(rendered, "Reviewed render")
    documents = rendered.get("items") if rendered.get("kind") == "List" else [rendered]
    if not isinstance(documents, list) or any(not isinstance(item, dict) for item in documents):
        raise PatchError("Reviewed render must be a Kubernetes object or List")
    selected = [item for item in documents if item.get("kind") == "Deployment" and item.get("metadata", {}).get("name") == agent_id]
    if len(selected) != 1:
        raise PatchError("Reviewed render must contain exactly one selected Deployment")
    _, pod, _, _, _, _, config = deployment_parts(selected[0], agent_id, image)
    if not config_state(config, agent_id):
        raise PatchError("Reviewed agent does not enable the internal transport")
    containers = named(pod["containers"], "Rendered containers")
    sidecar = containers.get("gateway-internal-tls", (None, None))[1]
    expected_sidecar = transport.sidecar(agent_id)
    expected_sidecar["image"] = image
    if sidecar != expected_sidecar:
        raise PatchError("Rendered TLS sidecar differs from the reviewed implementation")
    volumes = named(pod["volumes"], "Rendered volumes")
    if not VOLUME_NAMES <= volumes.keys():
        raise PatchError("Reviewed render lacks the complete TLS volume set")
    code = volumes["gateway-tls-code"][1]
    configmap = code.get("configMap", {}).get("name")
    if not isinstance(configmap, str) or re.fullmatch(r"openclaw-gateway-tls-tunnel-[a-z0-9]{10}", configmap) is None:
        raise PatchError("TLS code must reference a content-hashed ConfigMap")
    expected = [
        {"name": "gateway-tls-code", "configMap": {"name": configmap, "defaultMode": 292}},
        {"name": "gateway-tls-identity", "secret": {"secretName": f"{agent_id}-dashboard-internal-tls", "defaultMode": 288,
            "items": [{"key": key, "path": key} for key in ("tls.crt", "tls.key", "client-ca.crt")]}},
        {"name": "gateway-tls-no-api-token", "emptyDir": {"medium": "Memory", "sizeLimit": "1Mi"}},
    ]
    if any(volumes[item["name"]][1] != item for item in expected):
        raise PatchError("Rendered TLS volumes differ from the reviewed mount contract")
    maps = [item for item in documents if item.get("kind") == "ConfigMap" and item.get("metadata", {}).get("name") == configmap]
    if len(maps) != 1 or maps[0].get("metadata", {}).get("namespace") != NAMESPACE or maps[0].get("binaryData"):
        raise PatchError("Reviewed render must contain the referenced namespaced TLS ConfigMap")
    try:
        code_source = (ROOT / "k8s/components/gateway-internal-tls/tunnel.mjs").read_text(encoding="utf-8")
    except (OSError, UnicodeError) as error:
        raise PatchError("Cannot read the reviewed TLS tunnel source") from error
    if maps[0].get("data") != {"tunnel.mjs": code_source}:
        raise PatchError("Rendered TLS ConfigMap does not match the reviewed tunnel source")
    return copy.deepcopy(sidecar), [copy.deepcopy(volumes[item["name"]][1]) for item in expected]


def build_patch(deployment: dict, rendered: dict, *, agent_id: str, expected_image: str,
                expected_uid: str, expected_resource_version: str) -> list[dict]:
    if agent_id not in identity.AGENTS or not isinstance(expected_image, str) or identity.IMAGE.fullmatch(expected_image) is None:
        raise PatchError("A reviewed agent and exact immutable image are required")
    if not isinstance(expected_uid, str) or not expected_uid.strip() or not isinstance(expected_resource_version, str) or re.fullmatch(r"[1-9][0-9]*", expected_resource_version) is None:
        raise PatchError("Explicit Deployment UID and positive resourceVersion are required")
    sidecar, additions = reviewed_additions(rendered, agent_id, expected_image)
    metadata, pod, _, container_index, env_index, previous, config = deployment_parts(deployment, agent_id, expected_image)
    if metadata.get("uid") != expected_uid or metadata.get("resourceVersion") != expected_resource_version:
        raise PatchError("Live input UID or resourceVersion differs from the selected snapshot")
    enabled = config_state(config, agent_id)
    containers = named(pod["containers"], "Live containers")
    volumes = named(pod["volumes"], "Live volumes")
    present_volumes = VOLUME_NAMES & volumes.keys()
    present_sidecar = containers.get("gateway-internal-tls")
    if any(port.get("containerPort") == 8443 for container in pod["containers"] if container["name"] != "gateway-internal-tls" for port in container.get("ports", [])):
        raise PatchError("Another container already declares the TLS listener port")
    if enabled and present_sidecar and present_volumes == VOLUME_NAMES:
        if without_api_defaults(present_sidecar[1]) != sidecar or any(volumes[item["name"]][1] != item for item in additions):
            raise PatchError("Installed TLS transport has drifted from the reviewed render")
        return []
    if enabled or present_sidecar or present_volumes:
        raise PatchError("Partial internal transport state requires explicit reconciliation")
    updated = copy.deepcopy(config)
    updated["gateway"]["trustedProxies"].append("127.0.0.1")
    updated["gateway"]["auth"]["trustedProxy"]["allowLoopback"] = True
    path = f"/spec/template/spec/containers/{container_index}"
    config_path = f"{path}/env/{env_index}"
    tests = [("/metadata/name", agent_id), ("/metadata/namespace", NAMESPACE), ("/metadata/uid", expected_uid),
             ("/metadata/resourceVersion", expected_resource_version), (f"{path}/name", "agent"),
             (f"{path}/image", expected_image), (f"{config_path}/name", identity.CONFIG_ENV), (f"{config_path}/value", previous)]
    return [{"op": "test", "path": field, "value": value} for field, value in tests] + [
        {"op": "replace", "path": f"{config_path}/value", "value": json.dumps(updated, ensure_ascii=False, separators=(",", ":"), allow_nan=False)},
        {"op": "add", "path": "/spec/template/spec/containers/-", "value": sidecar},
        *[{"op": "add", "path": "/spec/template/spec/volumes/-", "value": volume} for volume in additions],
    ]


def read_input(path: str, label: str) -> dict:
    try:
        return identity.parse_json(sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError) as error:
        raise PatchError(f"Cannot read {label}") from error


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent-id", required=True, choices=sorted(identity.AGENTS))
    parser.add_argument("--expected-image", required=True)
    parser.add_argument("--expected-uid", required=True)
    parser.add_argument("--expected-resource-version", required=True)
    parser.add_argument("--input", required=True, help="Protected live Deployment JSON, or -")
    parser.add_argument("--rendered", required=True, help="Reviewed rendered Kubernetes List JSON including TLS ConfigMap")
    output = parser.add_mutually_exclusive_group(required=True)
    output.add_argument("--dry-run", action="store_true")
    output.add_argument("--output", help="New protected JSON Patch file; never stdout")
    args = parser.parse_args()
    try:
        if args.rendered == "-":
            raise PatchError("Reviewed render requires an explicit file")
        patch = build_patch(read_input(args.input, "live Deployment"), read_input(args.rendered, "reviewed render"),
            agent_id=args.agent_id, expected_image=args.expected_image, expected_uid=args.expected_uid,
            expected_resource_version=args.expected_resource_version)
        if not args.dry_run:
            identity.write_patch(args.output, patch)
        print(json.dumps({"agentId": args.agent_id, "changedTransport": bool(patch), "noop": not patch, "dryRun": args.dry_run}))
        return 0
    except (PatchError, KeyError, TypeError, AttributeError, RecursionError) as error:
        message = str(error) if isinstance(error, PatchError) else "Malformed transport input"
        print(f"ERROR: {message}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
