#!/usr/bin/env python3
"""Create and inspect isolated per-task agent repo workspaces."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit, urlunsplit


ROOT = Path(__file__).resolve().parents[1]
BUNDLE_DIR = Path(
    os.environ.get(
        "AGENT_SKILL_BUNDLE_DIR",
        "/opt/openclaw-agent-skill-config/config/agent-skill-bundles",
    )
)
if not BUNDLE_DIR.exists():
    BUNDLE_DIR = ROOT / "config" / "agent-skill-bundles"
SAFE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,80}$")
FULL_COMMIT_RE = re.compile(r"^[0-9a-fA-F]{40,64}$")
SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
WILDCARD_REPOSITORY_ALLOWLIST = ["*"]


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def run(args: list[str], cwd: Path | None = None) -> None:
    subprocess.run(args, cwd=cwd, check=True)


def output(args: list[str], cwd: Path | None = None) -> str:
    return subprocess.check_output(args, cwd=cwd, text=True).strip()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_bundle(agent_id: str) -> dict:
    path = BUNDLE_DIR / f"{agent_id}.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"unknown agent bundle: {agent_id}")
    except json.JSONDecodeError as exc:
        fail(f"invalid bundle JSON for {agent_id}: {exc}")


def require_safe_id(value: str, label: str) -> None:
    if not SAFE_ID_RE.match(value):
        fail(f"{label} must match {SAFE_ID_RE.pattern}: {value!r}")


def sanitize_branch_part(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip())
    value = re.sub(r"-+", "-", value).strip("-._/")
    return value or "task"


def sanitize_url(url: str) -> str:
    parts = urlsplit(url)
    if "@" not in parts.netloc:
        return url
    host = parts.netloc.rsplit("@", 1)[-1]
    return urlunsplit((parts.scheme, host, parts.path, parts.query, parts.fragment))


def repo_access(bundle: dict) -> dict:
    access = bundle.get("repo_access")
    if not isinstance(access, dict):
        fail(f"{bundle.get('agent_id')} has no repo_access policy")
    return access


def wildcard_repo(repo_name: str) -> dict:
    return {
        "name": repo_name,
        "repository": repo_name,
        "url": None,
        "default_branch": "main",
        "checkout_mode": "task-branch",
        "default_verify_command": "git diff --check",
        "cleanup_or_expiry": (
            "One isolated checkout per assigned task; remove the task workspace "
            "after review or merge."
        ),
        "ci_cd_evidence": {
            "required_when_available": True,
            "notes": "If the assigned repo has branch-triggered CI/CD or deploy previews, report branch/PR/deploy evidence separately from local tests.",
        },
        "wildcard_access": True,
    }


def denied_repo_names(access: dict) -> dict[str, str]:
    denied: dict[str, str] = {}
    for entry in access.get("denied_repositories", []):
        if isinstance(entry, str):
            denied[entry] = "Repo is denied by this agent's repo_access policy."
        elif isinstance(entry, dict):
            denied[entry.get("name")] = entry.get("reason") or "Repo is denied by this agent's repo_access policy."
    return denied


def find_repo(bundle: dict, repo_name: str) -> dict:
    access = repo_access(bundle)
    denied = denied_repo_names(access)
    if repo_name in denied:
        fail(f"{bundle.get('agent_id')} is denied from using repo {repo_name!r}: {denied[repo_name]}")

    if access.get("default_policy") == "allow":
        return wildcard_repo(repo_name)

    repositories = access.get("allowed_repositories", [])
    if repositories == WILDCARD_REPOSITORY_ALLOWLIST:
        return wildcard_repo(repo_name)
    for repo in repositories:
        if repo.get("name") == repo_name:
            return repo
    fail(f"{bundle.get('agent_id')} is not allowed to use repo {repo_name!r}")


def resolve_repo_source(
    bundle: dict,
    repo_name: str,
    source_url_override: str | None,
    allow_source_override: bool,
) -> tuple[dict, str]:
    repo = find_repo(bundle, repo_name)
    source_url = repo.get("url")
    if source_url_override:
        if not repo.get("wildcard_access") and not allow_source_override:
            fail("--source-url requires --allow-source-override")
        source_url = source_url_override
    if not source_url:
        fail(
            f"{bundle.get('agent_id')} has default-allow repo access for {repo_name!r}; "
            "provide --source-url or REPO_SOURCE_URL"
        )
    if re.match(r"^https?://[^/]*:[^/]*@", source_url):
        fail("refusing source URL with embedded credentials")
    return repo, source_url


def resolve_task_root(access: dict, workspace_root: str | None) -> Path:
    if workspace_root:
        return Path(workspace_root) / "tasks"
    return Path(access["task_workspace_root"])


def resolve_cache_root(access: dict, workspace_root: str | None) -> Path:
    if workspace_root:
        return Path(workspace_root) / "repo-cache"
    return Path(access["repo_cache_root"])


def list_task_dirs(task_root: Path, agent_id: str) -> list[Path]:
    if not task_root.exists():
        return []
    dirs: list[Path] = []
    for path in sorted(task_root.iterdir()):
        manifest = path / "task-workspace.json"
        if not manifest.exists():
            continue
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            continue
        if data.get("agent_id") == agent_id:
            dirs.append(path)
    return dirs


def registry_path(task_root: Path) -> Path:
    return task_root / "task-registry.json"


def load_registry(task_root: Path) -> dict:
    path = registry_path(task_root)
    if not path.exists():
        return {"version": 1, "updated_at": None, "tasks": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"invalid task registry JSON: {path}: {exc}")
    if not isinstance(data.get("tasks"), dict):
        fail(f"invalid task registry shape: {path}")
    return data


def save_registry(task_root: Path, registry: dict) -> None:
    task_root.mkdir(parents=True, exist_ok=True)
    registry["version"] = 1
    registry["updated_at"] = utc_now()
    registry_path(task_root).write_text(
        json.dumps(registry, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def ensure_registry_command(args: argparse.Namespace) -> int:
    bundle = load_bundle(args.agent_id)
    task_root = resolve_task_root(repo_access(bundle), args.workspace_root)
    path = registry_path(task_root)
    registry = load_registry(task_root)
    if not path.exists():
        save_registry(task_root, registry)
        print(f"Created empty task registry: {path}")
    else:
        print(f"Task registry exists: {path}")
    return 0


def update_registry(task_root: Path, manifest: dict, status: str, title: str | None = None) -> None:
    registry = load_registry(task_root)
    task_id = manifest["task_id"]
    existing = registry["tasks"].get(task_id, {})
    entry = {
        **existing,
        "agent_id": manifest["agent_id"],
        "friendly_name": manifest.get("friendly_name"),
        "task_id": task_id,
        "title": title if title is not None else existing.get("title"),
        "repo_name": manifest["repo_name"],
        "repo_dir": manifest["repo_dir"],
        "task_branch": manifest.get("task_branch"),
        "base_branch": manifest["base_branch"],
        "base_commit": manifest["base_commit"],
        "default_verify_command": manifest["default_verify_command"],
        "status": status,
        "created_at": existing.get("created_at") or manifest["created_at"],
        "updated_at": utc_now(),
        "manifest_path": str(task_root / task_id / "task-workspace.json"),
    }
    if manifest.get("brief_path"):
        entry["brief_path"] = manifest["brief_path"]
    registry["tasks"][task_id] = entry
    save_registry(task_root, registry)


def enforce_concurrency(task_root: Path, agent_id: str, access: dict, task_id: str, resume: bool) -> None:
    max_workspaces = int(access["max_concurrent_task_workspaces"])
    existing = [path for path in list_task_dirs(task_root, agent_id) if path.name != task_id]
    if not resume and len(existing) >= max_workspaces:
        fail(
            f"{agent_id} already has {len(existing)} task workspace(s); "
            f"limit is {max_workspaces}"
        )


def render_brief(args: argparse.Namespace, manifest: dict) -> str:
    lines = [
        f"# {args.title or args.task_id}",
        "",
        f"- Agent: {manifest['friendly_name'] or manifest['agent_id']} (`{manifest['agent_id']}`)",
        f"- Task ID: `{manifest['task_id']}`",
        f"- Repository: `{manifest['repo_name']}`",
        f"- Checkout: `{manifest['repo_dir']}`",
        f"- Branch: `{manifest.get('task_branch') or 'detached read-only'}`",
        f"- Verify: `{args.verify_command or manifest['default_verify_command']}`",
        "",
        "## Evidence Contract",
        "",
        "- Record every nonzero command with its exact command, exit code, short stderr tail, and one classification: `command_failed`, `tooling_gap`, `access_blocked`, or `verification_inconclusive`.",
        "- Pod-provided Playwright, Chromium, ImageMagick, `NODE_PATH`, and agent toolbox modules prove runtime capability only; they do not make an attached artifact portable.",
        "- Any attached executable evidence package must declare and lock dependencies or bundle them, avoid fixed pod/workspace paths, and pass `openclaw-agent-evidence-verify` from a fresh isolated copy before a package-wide `VERIFIED` claim.",
        "- Keep bounded subcheck verdicts separate from product, implementation-handoff, and human-usability verdicts.",
        "",
    ]
    if args.objective:
        lines.extend(["## Objective", "", args.objective.strip(), ""])
    if args.acceptance:
        lines.extend(["## Acceptance Criteria", ""])
        for item in args.acceptance:
            lines.append(f"- {item.strip()}")
        lines.append("")
    if args.notes:
        lines.extend(["## Notes", "", args.notes.strip(), ""])
    if args.brief_file:
        brief_file = Path(args.brief_file)
        if not brief_file.exists():
            fail(f"brief file does not exist: {brief_file}")
        lines.extend(["## Source Brief", "", brief_file.read_text(encoding="utf-8").strip(), ""])
    return "\n".join(lines).rstrip() + "\n"


def write_start_brief(args: argparse.Namespace, manifest: dict, task_dir: Path) -> dict:
    brief_path = task_dir / "task-brief.md"
    brief_path.write_text(render_brief(args, manifest), encoding="utf-8")
    manifest["title"] = args.title
    manifest["brief_path"] = str(brief_path)
    manifest["status"] = "assigned"
    manifest["started_at"] = utc_now()
    manifest["verify_command"] = args.verify_command or manifest["default_verify_command"]
    (task_dir / "task-workspace.json").write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest


def create_workspace(args: argparse.Namespace, *, status: str = "created") -> dict:
    agent_id = args.agent_id
    repo_name = args.repo_name
    task_id = args.task_id
    require_safe_id(agent_id, "agent id")
    require_safe_id(repo_name, "repo name")
    require_safe_id(task_id, "task id")

    bundle = load_bundle(agent_id)
    access = repo_access(bundle)
    repo, source_url = resolve_repo_source(
        bundle,
        repo_name,
        args.source_url,
        args.allow_source_override,
    )
    task_root = resolve_task_root(access, args.workspace_root)
    cache_root = resolve_cache_root(access, args.workspace_root)
    task_dir = task_root / task_id
    repo_dir = task_dir / "repos" / repo_name
    manifest_path = task_dir / "task-workspace.json"

    if task_dir.exists() and not args.resume:
        fail(f"task workspace already exists: {task_dir}; pass --resume to reuse it")
    enforce_concurrency(task_root, agent_id, access, task_id, args.resume)

    base_branch = args.base_branch or repo["default_branch"]
    task_branch = args.branch or (
        f"agent/{sanitize_branch_part(agent_id)}/"
        f"{sanitize_branch_part(task_id)}/{sanitize_branch_part(repo_name)}"
    )

    if not repo_dir.exists():
        repo_dir.parent.mkdir(parents=True, exist_ok=True)
        fresh_checkout = True
        if args.use_cache:
            cache_root.mkdir(parents=True, exist_ok=True)
            mirror = cache_root / f"{repo_name}.git"
            if mirror.exists():
                run(["git", "remote", "update", "--prune"], cwd=mirror)
            else:
                run(["git", "clone", "--mirror", source_url, str(mirror)])
            run(["git", "clone", str(mirror), str(repo_dir)])
        else:
            run(["git", "clone", "--branch", base_branch, source_url, str(repo_dir)])
    else:
        fresh_checkout = False

    run(["git", "fetch", "--all", "--prune"], cwd=repo_dir)
    if repo["checkout_mode"] == "task-branch":
        run(["git", "checkout", "-B", task_branch], cwd=repo_dir)
    else:
        run(["git", "checkout", "--detach", f"origin/{base_branch}"], cwd=repo_dir)

    base_commit = output(["git", "rev-parse", "HEAD"], cwd=repo_dir)
    manifest = {
        "version": 1,
        "agent_id": agent_id,
        "friendly_name": bundle.get("friendly_name"),
        "task_id": task_id,
        "repo_name": repo_name,
        "repo_url": sanitize_url(source_url),
        "source_url_override_used": bool(args.source_url),
        "wildcard_repo_access": bool(repo.get("wildcard_access")),
        "base_branch": base_branch,
        "base_commit": base_commit,
        "checkout_mode": repo["checkout_mode"],
        "task_branch": task_branch if repo["checkout_mode"] == "task-branch" else None,
        "repo_dir": str(repo_dir),
        "default_verify_command": repo["default_verify_command"],
        "cleanup_or_expiry": repo["cleanup_or_expiry"],
        "fresh_checkout": fresh_checkout,
        "reused_existing_checkout": not fresh_checkout,
        "ci_cd_evidence": repo.get(
            "ci_cd_evidence",
            {
                "required_when_available": repo.get("provider") == "gitlab" or source_url.startswith("https://gitlab.infuse-ai-tech.party/"),
                "notes": (
                    "Record local verification plus pushed-branch CI/CD, PR policy, "
                    "deployment, and smoke evidence when the assigned repo provides it."
                ),
            },
        ),
        "status": status,
        "created_at": utc_now(),
    }
    task_dir.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    update_registry(task_root, manifest, status)
    print(f"Created task workspace: {task_dir}")
    print(f"Repo checkout: {repo_dir}")
    print(f"Branch: {manifest['task_branch'] or 'detached read-only'}")
    return manifest


def create_workspace_command(args: argparse.Namespace) -> int:
    create_workspace(args)
    return 0


def start_workspace(args: argparse.Namespace) -> int:
    manifest = create_workspace(args, status="assigned")
    bundle = load_bundle(args.agent_id)
    task_root = resolve_task_root(repo_access(bundle), args.workspace_root)
    task_dir = task_root / args.task_id
    manifest = write_start_brief(args, manifest, task_dir)
    update_registry(task_root, manifest, "assigned", args.title)
    print(f"Task brief: {manifest['brief_path']}")
    print("Status: assigned")
    return 0


def validate_source_path(value: str) -> PurePosixPath:
    if "\x00" in value:
        fail("source path contains a null byte")
    source_path = PurePosixPath(value)
    if source_path.is_absolute() or not source_path.parts or ".." in source_path.parts:
        fail("source path must be a relative repository path without '..'")
    return source_path


def resolve_source_output(workspace_root: str | None, value: str) -> Path:
    if not workspace_root:
        fail("read-source requires --workspace-root or OPENCLAW_WORKSPACE")
    root = Path(workspace_root).expanduser().resolve()
    output_path = Path(value).expanduser()
    if not output_path.is_absolute():
        fail("--output must be an absolute path")
    resolved = output_path.resolve(strict=False)
    try:
        resolved.relative_to(root)
    except ValueError:
        fail("--output must stay inside the agent workspace")
    if resolved.exists():
        fail(f"refusing to overwrite existing output: {resolved}")
    return resolved


def read_source_command(args: argparse.Namespace) -> int:
    require_safe_id(args.agent_id, "agent id")
    require_safe_id(args.repo_name, "repo name")
    if not FULL_COMMIT_RE.fullmatch(args.commit):
        fail("--commit must be a full 40-64 character hexadecimal commit id")
    if args.expected_sha256 and not SHA256_RE.fullmatch(args.expected_sha256):
        fail("--expected-sha256 must be a 64 character hexadecimal digest")

    source_path = validate_source_path(args.source_path)
    output_path = resolve_source_output(args.workspace_root, args.output)
    bundle = load_bundle(args.agent_id)
    _repo, source_url = resolve_repo_source(
        bundle,
        args.repo_name,
        args.source_url,
        args.allow_source_override,
    )

    git_environment = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    with tempfile.TemporaryDirectory(prefix="openclaw-agent-source-") as directory:
        repository = Path(directory) / "repo"
        try:
            subprocess.run(
                ["git", "init", "--quiet", str(repository)],
                check=True,
                env=git_environment,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            subprocess.run(
                ["git", "remote", "add", "origin", source_url],
                cwd=repository,
                check=True,
                env=git_environment,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            subprocess.run(
                ["git", "fetch", "--quiet", "--no-tags", "--depth=1", "origin", args.commit],
                cwd=repository,
                check=True,
                env=git_environment,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            resolved_commit = subprocess.check_output(
                ["git", "rev-parse", "FETCH_HEAD^{commit}"],
                cwd=repository,
                env=git_environment,
                text=True,
            ).strip()
            if resolved_commit.lower() != args.commit.lower():
                fail("fetched commit does not match the requested full commit id")
            blob = subprocess.check_output(
                ["git", "rev-parse", f"{resolved_commit}:{source_path.as_posix()}"],
                cwd=repository,
                env=git_environment,
                text=True,
            ).strip()
            content = subprocess.check_output(
                ["git", "cat-file", "blob", blob],
                cwd=repository,
                env=git_environment,
            )
        except subprocess.CalledProcessError:
            fail("could not fetch the requested repository source")

    digest = hashlib.sha256(content).hexdigest()
    if args.expected_sha256 and digest != args.expected_sha256.lower():
        fail("fetched source SHA-256 does not match --expected-sha256")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("xb") as stream:
        stream.write(content)
    output_path.chmod(0o600)
    print(
        json.dumps(
            {
                "agent_id": args.agent_id,
                "repository": args.repo_name,
                "commit": resolved_commit,
                "path": source_path.as_posix(),
                "blob": blob,
                "sha256": digest,
                "bytes": len(content),
                "output": str(output_path),
            },
            sort_keys=True,
        )
    )
    return 0


def list_workspaces(args: argparse.Namespace) -> int:
    bundle = load_bundle(args.agent_id)
    task_root = resolve_task_root(repo_access(bundle), args.workspace_root)
    registry = load_registry(task_root)
    if args.all or registry["tasks"]:
        tasks = sorted(registry["tasks"].values(), key=lambda item: (item.get("agent_id", ""), item["task_id"]))
        if not args.all:
            tasks = [task for task in tasks if task.get("agent_id") == args.agent_id]
        if args.status:
            tasks = [task for task in tasks if task.get("status") == args.status]
        elif not args.include_cleaned:
            tasks = [task for task in tasks if task.get("status") != "cleaned"]
        if not tasks:
            target = "all agents" if args.all else args.agent_id
            print(f"No task workspaces for {target}.")
            return 0
        for task in tasks:
            print(
                f"{task['agent_id']}\t{task['task_id']}\t{task.get('status', 'unknown')}\t"
                f"{task['repo_name']}\t{task.get('task_branch') or 'detached'}\t{task['repo_dir']}"
            )
        return 0

    dirs = list_task_dirs(task_root, args.agent_id)
    if not dirs:
        print(f"No task workspaces for {args.agent_id}.")
        return 0
    for path in dirs:
        data = json.loads((path / "task-workspace.json").read_text(encoding="utf-8"))
        print(
            f"{data['task_id']}\t{data['repo_name']}\t"
            f"{data.get('task_branch') or 'detached'}\t{data['repo_dir']}"
        )
    return 0


def status_workspace(args: argparse.Namespace) -> int:
    bundle = load_bundle(args.agent_id)
    task_root = resolve_task_root(repo_access(bundle), args.workspace_root)
    task_dir = task_root / args.task_id
    manifest_path = task_dir / "task-workspace.json"
    if not manifest_path.exists():
        fail(f"missing task workspace manifest: {manifest_path}")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    repo_dir = Path(data["repo_dir"])
    print(json.dumps(data, indent=2))
    if repo_dir.exists():
        run(["git", "status", "--short", "--branch"], cwd=repo_dir)
    return 0


def repo_has_changes(repo_dir: Path) -> bool:
    if not (repo_dir / ".git").exists():
        return False
    return bool(output(["git", "status", "--porcelain"], cwd=repo_dir))


def cleanup_workspace(args: argparse.Namespace) -> int:
    bundle = load_bundle(args.agent_id)
    task_root = resolve_task_root(repo_access(bundle), args.workspace_root)
    task_dir = task_root / args.task_id
    manifest_path = task_dir / "task-workspace.json"
    if not manifest_path.exists():
        fail(f"refusing to remove non-task workspace path without manifest: {task_dir}")
    if not args.yes:
        fail("cleanup requires --yes")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    dirty_repos = [
        repo_dir
        for repo_dir in (task_dir / "repos").iterdir()
        if repo_dir.is_dir() and repo_has_changes(repo_dir)
    ] if (task_dir / "repos").exists() else []
    if dirty_repos and not args.force:
        repo_list = ", ".join(str(path) for path in dirty_repos)
        fail(f"refusing to clean task workspace with uncommitted changes: {repo_list}; pass --force to override")
    update_registry(task_root, data, "cleaned")
    shutil.rmtree(task_dir)
    print(f"Removed task workspace: {task_dir}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent-id", default=os.environ.get("AGENT_ID", "agent-designer"))
    parser.add_argument("--workspace-root", default=os.environ.get("OPENCLAW_WORKSPACE"))
    subparsers = parser.add_subparsers(dest="command", required=True)

    ensure_registry = subparsers.add_parser("ensure-registry")
    ensure_registry.set_defaults(func=ensure_registry_command)

    create = subparsers.add_parser("create")
    create.add_argument("--repo-name", default=os.environ.get("REPO_NAME"))
    create.add_argument("--task-id", default=os.environ.get("TASK_ID"))
    create.add_argument("--base-branch", default=os.environ.get("BASE_BRANCH"))
    create.add_argument("--branch", default=os.environ.get("TASK_BRANCH"))
    create.add_argument("--source-url", default=os.environ.get("REPO_SOURCE_URL"))
    create.add_argument("--allow-source-override", action="store_true")
    create.add_argument("--resume", action="store_true")
    create.add_argument("--use-cache", action="store_true")
    create.set_defaults(func=create_workspace_command)

    start = subparsers.add_parser("start")
    start.add_argument("--repo-name", default=os.environ.get("REPO_NAME"))
    start.add_argument("--task-id", default=os.environ.get("TASK_ID"))
    start.add_argument("--base-branch", default=os.environ.get("BASE_BRANCH"))
    start.add_argument("--branch", default=os.environ.get("TASK_BRANCH"))
    start.add_argument("--source-url", default=os.environ.get("REPO_SOURCE_URL"))
    start.add_argument("--allow-source-override", action="store_true")
    start.add_argument("--resume", action="store_true")
    start.add_argument("--use-cache", action="store_true")
    start.add_argument("--title", default=os.environ.get("TASK_TITLE"))
    start.add_argument("--objective", default=os.environ.get("TASK_OBJECTIVE"))
    start.add_argument("--acceptance", action="append", default=[])
    start.add_argument("--notes", default=os.environ.get("TASK_NOTES"))
    start.add_argument("--brief-file", default=os.environ.get("TASK_BRIEF_FILE"))
    start.add_argument("--verify-command", default=os.environ.get("VERIFY_COMMAND"))
    start.set_defaults(func=start_workspace)

    read_source = subparsers.add_parser("read-source")
    read_source.add_argument("--repo-name", default=os.environ.get("REPO_NAME"))
    read_source.add_argument("--commit", required=True)
    read_source.add_argument("--path", dest="source_path", required=True)
    read_source.add_argument("--output", required=True)
    read_source.add_argument("--expected-sha256")
    read_source.add_argument("--source-url", default=os.environ.get("REPO_SOURCE_URL"))
    read_source.add_argument("--allow-source-override", action="store_true")
    read_source.set_defaults(func=read_source_command)

    list_cmd = subparsers.add_parser("list")
    list_cmd.add_argument("--all", action="store_true")
    list_cmd.add_argument("--status")
    list_cmd.add_argument("--include-cleaned", action="store_true")
    list_cmd.set_defaults(func=list_workspaces)

    status = subparsers.add_parser("status")
    status.add_argument("--task-id", default=os.environ.get("TASK_ID"))
    status.set_defaults(func=status_workspace)

    cleanup = subparsers.add_parser("cleanup")
    cleanup.add_argument("--task-id", default=os.environ.get("TASK_ID"))
    cleanup.add_argument("--yes", action="store_true")
    cleanup.add_argument("--force", action="store_true")
    cleanup.set_defaults(func=cleanup_workspace)
    return parser


def require_command_args(args: argparse.Namespace) -> None:
    if args.command in {"create", "start", "read-source"}:
        if not args.repo_name:
            fail(f"{args.command} requires --repo-name or REPO_NAME")
    if args.command in {"create", "start"}:
        if not args.task_id:
            fail(f"{args.command} requires --task-id or TASK_ID")
    if args.command in {"status", "cleanup"} and not args.task_id:
        fail(f"{args.command} requires --task-id or TASK_ID")


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    require_command_args(args)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
