#!/usr/bin/env python3
"""Render the immutable reviewed memory-publisher overlay (no dependency/image change)."""
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
files = {name: (root / 'scripts' / name).read_text() for name in ('mirror-agent-memory.py', 'sync-agent-memory-repo.sh', 'export-agent-daily-memory.sh', 'refresh-shared-agent-memory.py', 'refresh-shared-agent-memory.sh', 'sync-shared-agent-memory-startup.sh')}
files['skill-catalog.json'] = (root / 'config/skill-catalog.json').read_text()
hash_value = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
name = 'agent-memory-mirror-' + hash_value[:12]
out = root / 'k8s/components/memory-mirror'
out.mkdir(parents=True, exist_ok=True)
def write(file, value):
    (out / file).write_text(json.dumps(value, indent=2) + '\n')
write('configmap.json', {'apiVersion':'v1', 'kind':'ConfigMap', 'metadata':{'name':name,'annotations':{'infuse.ai/content-sha256':hash_value}},'immutable':True,'data':files})
mounts = [ {'name':'memory-mirror-runtime','mountPath':'/opt/openclaw-memory-mirror','readOnly':True}, {'name':'memory-mirror-runtime','mountPath':'/usr/local/bin/openclaw-agent-sync-memory-repo','subPath':'sync-agent-memory-repo.sh','readOnly':True}, {'name':'memory-mirror-runtime','mountPath':'/usr/local/bin/openclaw-agent-export-daily-memory','subPath':'export-agent-daily-memory.sh','readOnly':True}]
mounts.append({'name':'memory-mirror-runtime','mountPath':'/opt/openclaw-agent-skill-config/config/skill-catalog.json','subPath':'skill-catalog.json','readOnly':True})
mounts += [{'name':'memory-mirror-runtime','mountPath':'/usr/local/bin/' + command,'subPath':source,'readOnly':True} for command, source in (
    ('openclaw-agent-refresh-shared-memory', 'refresh-shared-agent-memory.sh'),
    ('openclaw-agent-sync-shared-memory-startup', 'sync-shared-agent-memory-startup.sh'))]
patch = [{'op':'add','path':'/spec/template/spec/volumes/-','value':{'name':'memory-mirror-runtime','configMap':{'name':name,'defaultMode':365}}}]
patch += [{'op':'add','path':'/spec/template/spec/containers/0/volumeMounts/-','value':m} for m in mounts]
write('mounts.json', patch)
write('kustomization.yaml', {'apiVersion':'kustomize.config.k8s.io/v1alpha1','kind':'Component','resources':['configmap.json'],'patches':[{'target':{'kind':'Deployment','labelSelector':'app.kubernetes.io/component=persistent-agent'},'path':'mounts.json'}]})
print(name)
