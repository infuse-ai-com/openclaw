#!/usr/bin/env python3
"""Publish one agent's share-safe native Markdown without executing mirror code."""
from __future__ import annotations
import argparse, fcntl, hashlib, json, os, re, shlex, subprocess, tempfile, time
from pathlib import Path

ORIGIN = 'https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-agents-memory.git'
AGENTS = {'agent-developer', 'agent-designer', 'agent-infra', 'agent-coordinator', 'agent-intake'}
SECRET = re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----|glpat-[A-Za-z0-9_-]{15,}|(?im:^\s*(?:[A-Z_]*(?:TOKEN|PASSWORD|SECRET|API_KEY)[A-Z_]*|authorization)\s*[:=]\s*[^\s`\"\x27]{12,})|(?i:authorization:\s*bearer\s+[A-Za-z0-9._~+/=-]{16,})')


def run(*args, cwd=None):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        # Never echo Git/credential stderr: a remote may include sensitive text.
        raise RuntimeError(f'{args[0]} operation failed (exit {result.returncode})')
    return result.stdout.strip()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(workspace):
    if workspace.is_symlink() or workspace.parent.is_symlink():
        raise ValueError('workspace must not be a symlink')
    paths = [workspace / 'MEMORY.md']
    for folder in ('memory', 'summaries'):
        base = workspace / folder
        if base.is_symlink():
            raise ValueError('memory directory must not be a symlink')
        if base.exists():
            paths.extend(sorted(base.glob('*.md')))
    result = {}
    for path in paths:
        if path.is_symlink() or not path.is_file():
            raise ValueError('memory source must be a regular file')
        rel = path.relative_to(workspace).as_posix()
        if not re.fullmatch(r'(MEMORY\.md|(?:memory|summaries)/[A-Za-z0-9][A-Za-z0-9_.-]*\.md)', rel):
            raise ValueError('unsupported memory path')
        data = path.read_bytes()
        if len(data) > 512 * 1024:
            raise ValueError('memory file exceeds 512 KiB')
        content = data.decode('utf-8')
        if SECRET.search(content):
            raise ValueError(f'possible credential material in {rel}; publication refused')
        result[rel] = data
    if not result['MEMORY.md'].strip():
        raise ValueError('empty MEMORY.md')
    return result


def hashes(files):
    return {p: digest(data) for p, data in files.items()}


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, sort_keys=True) + '\n')
    temp.chmod(0o600)
    temp.replace(path)


def publish(agent, workspace, state, origin=ORIGIN, retries=4, adopt=False):
    if agent not in AGENTS:
        raise ValueError('unknown agent')
    state.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (state / 'sync.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        files = snapshot(workspace)
        time.sleep(0.1)
        if hashes(files) != hashes(snapshot(workspace)):
            raise RuntimeError('memory changed during capture; retry later')
        checkpoint = state / 'baseline.json'
        baseline = json.loads(checkpoint.read_text())['hashes'] if checkpoint.exists() else None
        # Retain the exact attempted snapshot on failure, outside native ingestion.
        with tempfile.TemporaryDirectory(prefix='mirror-', dir=state) as tmp:
            checkout = Path(tmp) / 'repo'
            run('git', 'clone', '--quiet', '--no-checkout', '--single-branch', '--branch', 'main', origin, str(checkout))
            run('git', 'config', 'user.name', agent, cwd=checkout)
            run('git', 'config', 'user.email', agent + '@infuse-ai.com', cwd=checkout)
            prefix = 'agents/' + agent + '/'
            for attempt in range(retries):
                run('git', 'fetch', '--quiet', 'origin', 'main', cwd=checkout)
                run('git', 'checkout', '--quiet', '--detach', '--force', 'origin/main', cwd=checkout)
                head = run('git', 'rev-parse', 'HEAD', cwd=checkout)
                dest = checkout / 'agents' / agent
                remote = snapshot(dest)
                rh, lh = hashes(remote), hashes(files)
                if baseline is None:
                    if rh != lh:
                        raise RuntimeError('initial baseline differs; reconcile and adopt the curated snapshot first')
                    baseline = rh
                changes = {p for p in set(baseline) | set(lh) if baseline.get(p) != lh.get(p)}
                for path in changes:
                    if rh.get(path) not in (baseline.get(path), lh.get(path)):
                        raise RuntimeError(f'same-file remote conflict: {path}; local memory retained')
                if adopt and changes:
                    raise RuntimeError('baseline adoption requires identical local and remote memory')
                if not changes:
                    # Do not silently adopt a remote edit over a differing live workspace.
                    if rh != lh:
                        raise RuntimeError('remote memory changed; reconcile before the next local edit')
                    save(checkpoint, {'commit': head, 'hashes': lh})
                    return {'status': 'unchanged', 'agent': agent, 'commit': head}
                for path in changes:
                    target = dest / path
                    if path in files:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(files[path])
                    elif target.exists():
                        target.unlink()
                run('git', 'add', '--all', '--', prefix, cwd=checkout)
                changed = run('git', 'diff', '--cached', '--name-only', cwd=checkout).splitlines()
                if any(not p.startswith(prefix) or p[len(prefix):] not in changes for p in changed):
                    raise RuntimeError('out-of-scope staged path')
                if not changed:
                    save(checkpoint, {'commit': head, 'hashes': lh})
                    return {'status': 'unchanged', 'agent': agent, 'commit': head}
                run('git', 'commit', '--quiet', '-m', f'memory: mirror {agent}', cwd=checkout)
                commit = run('git', 'rev-parse', 'HEAD', cwd=checkout)
                recovery = state / 'pending'
                recovery.mkdir(exist_ok=True, mode=0o700)
                bundle = recovery / (commit + '.bundle')
                bundle.unlink(missing_ok=True)
                run('git', 'bundle', 'create', str(bundle), 'HEAD', cwd=checkout)
                bundle.chmod(0o600)
                try:
                    run('git', 'push', '--quiet', 'origin', 'HEAD:refs/heads/main', cwd=checkout)
                except RuntimeError:
                    if attempt + 1 == retries:
                        raise RuntimeError('push failed after bounded retry; pending bundles and live memory retained')
                    continue
                save(checkpoint, {'commit': commit, 'hashes': lh})
                bundle.unlink(missing_ok=True)
                return {'status': 'published', 'agent': agent, 'commit': commit, 'files': sorted(changes)}
    raise RuntimeError('mirror did not produce a receipt')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--adopt-baseline', action='store_true')
    args = parser.parse_args()
    agent = os.environ['AGENT_ID']
    wrapper = Path(os.environ['AGENT_SKILLS_ROOT']) / 'scripts/gitlab-vault-run.sh'
    identity = json.loads(run(str(wrapper), agent, '--', 'glab', 'api', 'user'))
    if identity.get('username') != agent or identity.get('state') != 'active':
        raise RuntimeError('own GitLab identity check failed')
    credential = wrapper.with_name('git-credential-gitlab-vault.sh')
    if not credential.is_file():
        raise RuntimeError('reviewed own-identity Git credential helper missing')
    # Override inherited helpers for every Git child, including the initial clone.
    os.environ.pop('GIT_CONFIG_PARAMETERS', None)
    config = [('credential.helper', ''),
              ('credential.https://gitlab.infuse-ai-tech.party.helper', '!' + shlex.quote(str(credential)) + ' ' + shlex.quote(agent)),
              ('credential.https://gitlab.infuse-ai-tech.party.useHttpPath', 'true')]
    os.environ['GIT_CONFIG_COUNT'] = str(len(config))
    for i, (key, value) in enumerate(config):
        os.environ[f'GIT_CONFIG_KEY_{i}'] = key
        os.environ[f'GIT_CONFIG_VALUE_{i}'] = value
    workspace = Path(os.environ.get('OPENCLAW_AGENT_WORKSPACE', '/workspace/agents/' + agent))
    state = Path(os.environ.get('OPENCLAW_WORKSPACE', '/workspace')) / '.agent-memory-mirror' / agent
    print(json.dumps(publish(agent, workspace, state, adopt=args.adopt_baseline), sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, BlockingIOError) as exc:
        raise SystemExit(str(exc)) from None
