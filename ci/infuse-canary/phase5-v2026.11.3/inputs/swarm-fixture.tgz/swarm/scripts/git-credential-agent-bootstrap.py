#!/usr/bin/env python3
"""Git HTTPS bootstrap before the reviewed skills checkout exists.

Reads only the exact runtime identity's Vaultwarden item. Secret stdout is the
Git credential protocol, never an operator diagnostic. Native Git retains this
image-owned helper; the reviewed skill wrapper owns API commands.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HOST = 'gitlab.infuse-ai-tech.party'
AGENTS = {'agent-coordinator', 'agent-developer', 'agent-designer', 'agent-infra', 'agent-intake'}


def capture(command, *, env=None):
    result = subprocess.run(command, env=env, text=True, capture_output=True, timeout=30)
    if result.returncode:
        raise ValueError('credential provider unavailable')
    return result.stdout


def credential(action, fields):
    if action != 'get' or fields.get('protocol') != 'https' or fields.get('host') != HOST:
        return ''
    identity = os.environ.get('AGENT_ID', '')
    if identity not in AGENTS or os.environ.get('GITLAB_AGENT_ID', identity) != identity:
        raise ValueError('unsupported or mismatched runtime identity')
    if os.environ.get('OPENCLAW_BW_SERVER') != 'https://vault.infuse-ai-tech.party':
        raise ValueError('company vault endpoint required')
    name = f'GitLab / {identity} service account token'
    # Reuse the image-owned provider: it loads the per-agent persisted session,
    # bootstraps when needed and enforces exact-name/field lookup. kubectl exec
    # does not inherit exports made by the gateway entrypoint.
    vault_env = {k:v for k,v in os.environ.items() if not k.startswith('PROJECT_ENV_BOOTSTRAP_')}
    vault_env.update(VAULTWARDEN_ITEM_NAME=name, CREDENTIAL_SOURCE_FIELD='password',
                     BW_HELPER='/usr/local/bin/bw-local-vaultwarden', DRY_RUN='false')
    token = capture(['/usr/local/bin/openclaw-agent-secret-get'], env=vault_env).strip()
    if not token or '\n' in token or '\r' in token:
        raise ValueError('invalid service-account credential')
    with tempfile.TemporaryDirectory(prefix='gitlab-bootstrap-') as config:
        Path(config, 'config.yml').write_text('hosts: {}\n')
        Path(config, 'config.yml').chmod(0o600)
        env = {k:v for k,v in os.environ.items() if not k.startswith(('GITLAB_', 'GLAB_'))}
        env.update(GITLAB_HOST=HOST, GITLAB_API_HOST=HOST, GITLAB_TOKEN=token,
                   GLAB_CONFIG_DIR=config, GLAB_API_PROTOCOL='https',
                   GLAB_CHECK_UPDATE='false', GLAB_ENABLE_CI_AUTOLOGIN='false')
        user = json.loads(capture(['glab', 'api', '--hostname', HOST, 'user'], env=env))
        if user.get('username') != identity or user.get('state') != 'active':
            raise ValueError('GitLab credential identity mismatch or inactive account')
    return f'username={identity}\npassword={token}\n'


def main():
    fields = {}
    for line in sys.stdin:
        line = line.rstrip('\n')
        if not line:
            break
        key, sep, value = line.partition('=')
        if sep:
            fields[key] = value
    try:
        sys.stdout.write(credential(sys.argv[1] if len(sys.argv) > 1 else '', fields))
    except (ValueError, KeyError, TypeError, OSError, subprocess.SubprocessError):
        print('GitLab bootstrap credential unavailable; verify the agent vault and identity.', file=sys.stderr)
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
