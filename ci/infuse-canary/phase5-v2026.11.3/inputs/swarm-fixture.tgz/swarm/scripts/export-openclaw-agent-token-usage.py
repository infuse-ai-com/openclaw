#!/usr/bin/env python3
"""Export sanitized OpenClaw Gateway token usage for Studio."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


TOKEN_KEYS = ("input", "output", "cacheRead", "cacheWrite", "totalTokens")
FOUR_HOUR_BUCKET_HOURS = 4
GATEWAY_BACKEND = "gateway_sessions_usage"
DEFAULT_SESSION_LIMIT = 1000


class GatewayUsageError(RuntimeError):
    """The Gateway could not provide a complete, fresh usage result."""


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Export sanitized token usage from the authenticated OpenClaw Gateway.",
    )
    parser.add_argument(
        "--agent-id",
        default=os.environ.get("OPENCLAW_AGENT_ID") or os.environ.get("AGENT_ID") or "kapiteky",
        help="Agent/profile slug attached to the usage snapshot.",
    )
    parser.add_argument(
        "--gateway-label",
        default=os.environ.get("OPENCLAW_GATEWAY_LABEL"),
        help="Human-readable gateway/source label. Defaults to '<agent-id> Gateway'.",
    )
    parser.add_argument("--days", type=int, default=7, help="Rolling day window to include. Defaults to 7.")
    parser.add_argument("--output", default="-", help="Output path, or '-' for stdout.")
    parser.add_argument(
        "--openclaw-command",
        default=os.environ.get("OPENCLAW_COMMAND", "openclaw"),
        help="OpenClaw CLI executable used for the authenticated Gateway call.",
    )
    parser.add_argument(
        "--gateway-attempts",
        type=int,
        default=3,
        help="Attempts while the Gateway usage cache refreshes. Defaults to 3.",
    )
    parser.add_argument(
        "--gateway-retry-delay-seconds",
        type=float,
        default=2.0,
        help="Delay between refreshing-cache attempts. Defaults to 2 seconds.",
    )
    parser.add_argument(
        "--gateway-timeout-seconds",
        type=float,
        default=15.0,
        help="Timeout for each Gateway CLI call. Defaults to 15 seconds.",
    )
    # Retain legacy flags so old Task invocations fail on the backend, not argparse.
    parser.add_argument("--sessions-dir", help=argparse.SUPPRESS)
    parser.add_argument("--allow-missing", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()

    days = max(1, args.days)
    gateway_label = args.gateway_label or f"{args.agent_id} Gateway"
    try:
        raw_usage = fetch_gateway_usage(
            openclaw_command=args.openclaw_command,
            days=days,
            attempts=max(1, args.gateway_attempts),
            retry_delay_seconds=max(0.0, args.gateway_retry_delay_seconds),
            timeout_seconds=max(1.0, args.gateway_timeout_seconds),
        )
        snapshot = build_snapshot_from_gateway_usage(
            raw_usage=raw_usage,
            agent_id=args.agent_id,
            gateway_label=gateway_label,
            days=days,
        )
    except GatewayUsageError as exc:
        print(f"ERROR: token usage export failed: {exc}", file=sys.stderr)
        return 1

    output = json.dumps(snapshot, indent=2, sort_keys=True) + "\n"
    if args.output == "-":
        sys.stdout.write(output)
    else:
        output_path = Path(args.output).expanduser()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(output, encoding="utf-8")
    return 0


def fetch_gateway_usage(
    *,
    openclaw_command: str,
    days: int,
    attempts: int,
    retry_delay_seconds: float,
    timeout_seconds: float,
) -> dict[str, Any]:
    params = gateway_usage_params(days)
    command = [
        openclaw_command,
        "gateway",
        "call",
        "sessions.usage",
        "--json",
        "--params",
        json.dumps(params, separators=(",", ":")),
    ]
    last_cache_status = "missing"

    for attempt in range(1, attempts + 1):
        try:
            completed = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout_seconds,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise GatewayUsageError(f"Gateway CLI invocation failed ({type(exc).__name__})") from exc

        raw = parse_gateway_cli_output(completed)
        last_cache_status = usage_evidence_status(raw, days)
        if last_cache_status in {"fresh", "empty_window"}:
            return raw
        if attempt < attempts:
            time.sleep(retry_delay_seconds)

    raise GatewayUsageError(
        f"Gateway usage cache did not become fresh after {attempts} attempt(s); status={last_cache_status}"
    )


def usage_evidence_status(raw: dict[str, Any], days: int, now: datetime | None = None) -> str:
    """The Gateway omits cache metadata for a successful empty session window.

    Admit only a bounded, current, explicitly empty result. Never turn missing
    fields, a refreshing cache or a partial/non-empty result into zero usage.
    """
    cache = raw.get("cacheStatus")
    if "cacheStatus" in raw:
        return safe_label(cache.get("status") if isinstance(cache, dict) else None, "missing")
    now = now or datetime.now(timezone.utc)
    expected_dates = date_window(now, days)
    updated = raw.get("updatedAt")
    totals = raw.get("totals")
    aggregates = raw.get("aggregates")
    if (
        raw.get("sessions") == []
        and isinstance(totals, dict)
        and all(type(totals.get(key)) in (int, float) and totals[key] == 0 for key in TOKEN_KEYS)
        and isinstance(aggregates, dict)
        and type(aggregates.get("sessionCount")) is int and aggregates["sessionCount"] == 0
        and aggregates.get("byModel") == []
        and raw.get("startDate") == expected_dates[0]
        and raw.get("endDate") == expected_dates[-1]
        and type(updated) in (int, float)
        and abs(now.timestamp() * 1000 - updated) <= 300_000
    ):
        return "empty_window"
    return "missing"


def gateway_usage_params(days: int, now: datetime | None = None) -> dict[str, Any]:
    presets = {7: "7d", 30: "30d", 90: "90d", 365: "1y"}
    if days in presets:
        return {"range": presets[days], "limit": DEFAULT_SESSION_LIMIT}
    now = now or datetime.now(timezone.utc)
    start = now.date() - timedelta(days=days - 1)
    return {
        "startDate": start.isoformat(),
        "endDate": now.date().isoformat(),
        "mode": "utc",
        "limit": DEFAULT_SESSION_LIMIT,
    }


def parse_gateway_cli_output(completed: subprocess.CompletedProcess[str]) -> dict[str, Any]:
    try:
        parsed = json.loads(completed.stdout)
    except (json.JSONDecodeError, TypeError) as exc:
        raise GatewayUsageError(f"Gateway CLI returned invalid JSON (exit {completed.returncode})") from exc
    if not isinstance(parsed, dict):
        raise GatewayUsageError("Gateway CLI returned a non-object result")

    if parsed.get("ok") is False:
        error = parsed.get("error")
        code = safe_label(error.get("code") if isinstance(error, dict) else None, "unknown")
        message = safe_label(error.get("message") if isinstance(error, dict) else None, "request failed")
        raise GatewayUsageError(f"Gateway request rejected ({code}): {message}")
    if completed.returncode != 0:
        raise GatewayUsageError(f"Gateway CLI exited with status {completed.returncode}")

    result = parsed.get("result") if parsed.get("ok") is True else parsed
    if not isinstance(result, dict):
        raise GatewayUsageError("Gateway CLI result is missing")
    if not isinstance(result.get("sessions"), list) or not isinstance(result.get("totals"), dict):
        raise GatewayUsageError("Gateway sessions.usage result is missing sessions or totals")
    return result


def build_snapshot_from_gateway_usage(
    *,
    raw_usage: dict[str, Any],
    agent_id: str,
    gateway_label: str,
    days: int,
    now: datetime | None = None,
) -> dict[str, Any]:
    generated_at = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    dates = date_window(generated_at, days)
    date_set = set(dates)
    today = generated_at.date().isoformat()
    daily: dict[str, dict[str, int]] = {day: empty_totals() for day in dates}
    periods4h: dict[tuple[datetime, str, str], dict[str, Any]] = {}
    quarter_totals = empty_totals()
    usage_entries = 0

    sessions = raw_usage.get("sessions")
    if not isinstance(sessions, list):
        raise GatewayUsageError("Gateway sessions.usage result has an invalid sessions field")

    for session in sessions:
        if not isinstance(session, dict):
            continue
        usage = session.get("usage")
        if not isinstance(usage, dict):
            continue
        provider, model = session_model_attribution(session, usage)
        quarter_rows = usage.get("utcQuarterHourTokenUsage")
        if not isinstance(quarter_rows, list):
            continue
        for quarter in quarter_rows:
            parsed = parse_quarter_hour_row(quarter)
            if parsed is None:
                continue
            timestamp, totals = parsed
            day = timestamp.date().isoformat()
            if day not in date_set:
                continue
            add_totals(quarter_totals, totals)
            add_totals(daily[day], totals)
            period_start = floor_to_four_hour(timestamp)
            period_key = (period_start, provider, model)
            period = periods4h.get(period_key)
            if period is None:
                period = {
                    "periodStart": period_start.isoformat(),
                    "provider": provider,
                    "model": model,
                    **empty_totals(),
                }
                periods4h[period_key] = period
            add_totals(period, totals)
            usage_entries += 1

    gateway_totals = normalize_gateway_totals(raw_usage.get("totals"))
    if gateway_totals != quarter_totals:
        raise GatewayUsageError(
            "Gateway quarter-hour totals do not match the sessions.usage aggregate; refusing a partial export"
        )

    cache = raw_usage.get("cacheStatus")
    cache_status = usage_evidence_status(raw_usage, days, generated_at)
    if cache_status not in {"fresh", "empty_window"}:
        raise GatewayUsageError(f"Gateway usage cache is not fresh: {cache_status}")

    status = "available" if gateway_totals["totalTokens"] > 0 else "no_usage_entries"
    source: dict[str, Any] = {
        "type": "openclaw_agent_token_usage",
        "backend": GATEWAY_BACKEND,
        "agentId": agent_id,
        "gatewayLabel": gateway_label,
        "status": status,
        "cacheStatus": cache_status,
        "sessionCount": len(sessions),
        "usageEntries": usage_entries,
    }
    if isinstance(cache, dict):
        for key in ("cachedFiles", "pendingFiles", "staleFiles"):
            value = token_count(cache.get(key))
            if value is not None:
                source[key] = value

    return {
        "schemaVersion": 1,
        "generatedAt": generated_at.isoformat(),
        "source": source,
        "usage": {
            "today": daily.get(today, empty_totals()),
            "last7d": gateway_totals,
            "daily": [{"date": day, **daily[day]} for day in dates],
            "periods4h": sorted(
                periods4h.values(),
                key=lambda row: (str(row.get("periodStart")), str(row.get("provider")), str(row.get("model"))),
            ),
            "byModel": normalize_model_usage(raw_usage),
        },
    }


def session_model_attribution(session: dict[str, Any], usage: dict[str, Any]) -> tuple[str, str]:
    model_rows = usage.get("modelUsage")
    labels: set[tuple[str, str]] = set()
    if isinstance(model_rows, list):
        for row in model_rows:
            if not isinstance(row, dict):
                continue
            totals = normalize_gateway_totals(row.get("totals"))
            if totals["totalTokens"] <= 0:
                continue
            labels.add((safe_label(row.get("provider"), "unknown"), safe_label(row.get("model"), "unknown")))
    if len(labels) == 1:
        return next(iter(labels))
    if len(labels) > 1:
        return "mixed", "mixed"
    return safe_label(session.get("modelProvider"), "unknown"), safe_label(session.get("model"), "unknown")


def parse_quarter_hour_row(raw: Any) -> tuple[datetime, dict[str, int]] | None:
    if not isinstance(raw, dict):
        return None
    date = raw.get("date")
    quarter_index = raw.get("quarterIndex")
    if not isinstance(date, str) or not isinstance(quarter_index, int) or isinstance(quarter_index, bool):
        return None
    if quarter_index < 0 or quarter_index > 95:
        return None
    try:
        midnight = datetime.fromisoformat(f"{date}T00:00:00+00:00")
    except ValueError:
        return None
    totals = normalize_gateway_totals(raw)
    if totals["totalTokens"] <= 0:
        return None
    return midnight + timedelta(minutes=quarter_index * 15), totals


def normalize_model_usage(raw_usage: dict[str, Any]) -> list[dict[str, Any]]:
    aggregates = raw_usage.get("aggregates")
    rows = aggregates.get("byModel") if isinstance(aggregates, dict) else None
    if not isinstance(rows, list):
        return []
    normalized = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        totals = normalize_gateway_totals(row.get("totals"))
        if totals["totalTokens"] <= 0:
            continue
        normalized.append(
            {
                "provider": safe_label(row.get("provider"), "unknown"),
                "model": safe_label(row.get("model"), "unknown"),
                **totals,
                "count": token_count(row.get("count")) or 0,
            }
        )
    return sorted(
        normalized,
        key=lambda row: (-int(row["totalTokens"]), str(row["provider"]), str(row["model"])),
    )


def normalize_gateway_totals(raw: Any) -> dict[str, int]:
    if not isinstance(raw, dict):
        return empty_totals()
    components = {
        "input": token_count(raw.get("input")) or 0,
        "output": token_count(raw.get("output")) or 0,
        "cacheRead": token_count(raw.get("cacheRead")) or 0,
        "cacheWrite": token_count(raw.get("cacheWrite")) or 0,
    }
    component_total = sum(components.values())
    total = token_count(raw.get("totalTokens"))
    return {**components, "totalTokens": max(total or 0, component_total)}


def empty_totals() -> dict[str, int]:
    return {key: 0 for key in TOKEN_KEYS}


def token_count(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if value <= 0:
        return 0
    return min(int(value), 9_007_199_254_740_991)


def add_totals(target: dict[str, Any], source: dict[str, int]) -> None:
    for key in TOKEN_KEYS:
        target[key] = int(target.get(key, 0)) + int(source.get(key, 0))


def floor_to_four_hour(timestamp: datetime) -> datetime:
    timestamp = timestamp.astimezone(timezone.utc)
    bucket_hour = (timestamp.hour // FOUR_HOUR_BUCKET_HOURS) * FOUR_HOUR_BUCKET_HOURS
    return timestamp.replace(hour=bucket_hour, minute=0, second=0, microsecond=0)


def date_window(now: datetime, days: int) -> list[str]:
    start = now.date() - timedelta(days=days - 1)
    return [(start + timedelta(days=offset)).isoformat() for offset in range(days)]


def safe_label(value: Any, fallback: str) -> str:
    if not isinstance(value, str):
        return fallback
    cleaned = value.strip()
    return cleaned[:128] if cleaned else fallback


if __name__ == "__main__":
    raise SystemExit(main())
