#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python3 -m unittest discover -s "$repo_root/tests" -p test_memory_mirror.py
python3 -m unittest discover -s "$repo_root/tests" -p test_gitlab_memory_sync.py
