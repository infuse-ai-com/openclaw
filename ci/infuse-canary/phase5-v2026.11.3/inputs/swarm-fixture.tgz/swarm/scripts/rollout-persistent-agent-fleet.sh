#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 5 ]; then
  echo "Usage: $0 <namespace> <rendered-manifest> <image-digest> <source-revision> <agent-rollout-helper>" >&2
  exit 2
fi

namespace="$1"
rendered_manifest="$2"
image_revision="$3"
source_revision="$4"
agent_rollout_helper="$5"
strategy="${OPENCLAW_FLEET_ROLLOUT_STRATEGY:-canary-wave}"
deployments=(agent-developer agent-designer agent-infra agent-intake agent-coordinator)
leaf_wave=(agent-designer agent-infra agent-intake)
preserved_deployments=()

if [ ! -x "$agent_rollout_helper" ]; then
  echo "Agent rollout helper is not executable: $agent_rollout_helper" >&2
  exit 2
fi

if [ -n "${PRESERVE_DEPLOYMENTS:-}" ]; then
  IFS=',' read -r -a preserved_deployments <<<"$PRESERVE_DEPLOYMENTS"
fi

deployment_is_preserved() {
  local candidate="$1"
  local preserved

  if [ -z "${PRESERVE_DEPLOYMENTS:-}" ]; then
    return 1
  fi
  for preserved in "${preserved_deployments[@]}"; do
    if [ "$candidate" = "$preserved" ]; then
      return 0
    fi
  done
  return 1
}

validate_preserved_deployments() {
  local preserved
  local known
  local matched

  if [ -z "${PRESERVE_DEPLOYMENTS:-}" ]; then
    return 0
  fi
  for preserved in "${preserved_deployments[@]}"; do
    matched=false
    for known in "${deployments[@]}"; do
      if [ "$preserved" = "$known" ]; then
        matched=true
        break
      fi
    done
    if [ "$matched" != true ]; then
      echo "Unknown preserved deployment: $preserved" >&2
      return 1
    fi
  done
}

validate_canary_boundary() {
  local deployment

  if [ "$strategy" != "canary-wave" ] || ! deployment_is_preserved agent-developer; then
    return 0
  fi
  for deployment in "${deployments[@]:1}"; do
    if ! deployment_is_preserved "$deployment"; then
      echo "Canary-wave rollout cannot preserve agent-developer while advancing deployment/$deployment." >&2
      return 1
    fi
  done
}

rollout_agent() {
  local deployment="$1"

  if deployment_is_preserved "$deployment"; then
    echo "Leaving preserved deployment/$deployment untouched."
    return 0
  fi

  echo "Starting verified rollout for deployment/$deployment."
  "$agent_rollout_helper" \
    "$namespace" \
    "$deployment" \
    "$rendered_manifest" \
    "$image_revision" \
    "$source_revision"
}

rollout_leaf_wave() {
  local deployment
  local index
  local failed=false
  local pids=()
  local active_deployments=()

  for deployment in "${leaf_wave[@]}"; do
    if deployment_is_preserved "$deployment"; then
      echo "Leaving preserved deployment/$deployment untouched."
      continue
    fi
    rollout_agent "$deployment" &
    pids+=("$!")
    active_deployments+=("$deployment")
  done

  if [ "${#pids[@]}" -eq 0 ]; then
    return 0
  fi
  for index in "${!pids[@]}"; do
    if wait "${pids[$index]}"; then
      echo "Leaf-wave rollout passed for deployment/${active_deployments[$index]}."
    else
      echo "Leaf-wave rollout failed for deployment/${active_deployments[$index]}." >&2
      failed=true
    fi
  done

  if [ "$failed" = true ]; then
    echo "Leaf wave failed; coordinator promotion is blocked." >&2
    return 1
  fi
}

validate_preserved_deployments
validate_canary_boundary

case "$strategy" in
  canary-wave)
    echo "Using canary-wave rollout: developer canary, parallel leaf batch, coordinator promotion."
    rollout_agent agent-developer
    rollout_leaf_wave
    rollout_agent agent-coordinator
    ;;
  sequential)
    echo "Using sequential persistent-agent rollout."
    for deployment in "${deployments[@]}"; do
      rollout_agent "$deployment"
    done
    ;;
  *)
    echo "OPENCLAW_FLEET_ROLLOUT_STRATEGY must be canary-wave or sequential." >&2
    exit 2
    ;;
esac
