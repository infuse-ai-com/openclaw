#!/usr/bin/env python3
"""Coordinate a bounded OpenClaw Gateway drain before Kubernetes termination."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from typing import Any, Callable


DEFAULT_DRAIN_SECONDS = 300
DEFAULT_CALL_TIMEOUT_SECONDS = 30
MAX_POLL_SECONDS = 20.0
RENEWAL_MARGIN_MS = 30_000
STATE_SCHEMA = "infuse.openclaw-gateway-lifecycle/v1"
EXIT_DRAIN_TIMEOUT = 10
EXIT_UNSUPPORTED = 11
EXIT_FAILED = 12


class LifecycleError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class GatewayClient:
    def __init__(
        self,
        *,
        profile: str,
        run: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
        timeout_seconds: int = DEFAULT_CALL_TIMEOUT_SECONDS,
    ) -> None:
        self.profile = profile
        self.run = run
        self.timeout_seconds = timeout_seconds

    def call(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        command = [
            "openclaw",
            "--profile",
            self.profile,
            "gateway",
            "call",
            method,
            "--json",
        ]
        if params is not None:
            command.extend(["--params", json.dumps(params, separators=(",", ":"), sort_keys=True)])
        try:
            completed = self.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
            )
        except subprocess.TimeoutExpired as exc:
            raise LifecycleError("gateway_call_timeout", f"Gateway method timed out: {method}") from exc
        except OSError as exc:
            raise LifecycleError("gateway_cli_unavailable", f"Gateway CLI unavailable for method: {method}") from exc

        if completed.returncode != 0:
            combined = f"{completed.stdout}\n{completed.stderr}".lower()
            error_code = (
                "gateway_method_unsupported"
                if "method not found" in combined or "unknown method" in combined or "unsupported" in combined
                else "gateway_call_failed"
            )
            raise LifecycleError(error_code, f"Gateway method failed: {method}")
        try:
            value = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise LifecycleError("gateway_invalid_json", f"Gateway returned invalid JSON: {method}") from exc
        if isinstance(value, dict) and isinstance(value.get("result"), dict):
            value = value["result"]
        if not isinstance(value, dict):
            raise LifecycleError("gateway_invalid_response", f"Gateway returned a non-object: {method}")
        return value


def state_path() -> Path:
    configured = os.environ.get("OPENCLAW_LIFECYCLE_STATE_FILE")
    if configured:
        return Path(configured)
    configured_state_home = os.environ.get("XDG_STATE_HOME")
    state_home = Path(configured_state_home) if configured_state_home else Path.home() / ".local" / "state"
    return state_home / "openclaw" / "gateway-lifecycle.json"


def write_state(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    body = {"schema": STATE_SCHEMA, **value}
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(body, handle, sort_keys=True)
            handle.write("\n")
        os.replace(temporary_name, path)
    except BaseException:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise


def read_state(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None
    if not isinstance(value, dict) or value.get("schema") != STATE_SCHEMA:
        return None
    return value


def gateway_identity(client: GatewayClient) -> dict[str, Any]:
    value = client.call("system.info")
    pid = value.get("pid")
    process_instance_id = value.get("processInstanceId")
    if not isinstance(pid, int) or pid <= 0:
        raise LifecycleError("gateway_identity_invalid", "Gateway PID is missing or invalid")
    if not isinstance(process_instance_id, str) or not process_instance_id.strip():
        raise LifecycleError("gateway_identity_invalid", "Gateway process instance is missing or invalid")
    return {"pid": pid, "processInstanceId": process_instance_id}


def require_lease(value: dict[str, Any], *, expected_id: str | None = None) -> tuple[str, str]:
    status = value.get("status")
    suspension_id = value.get("suspensionId")
    if status not in {"ready", "draining"}:
        raise LifecycleError("gateway_suspend_refused", f"Unexpected suspension status: {status!r}")
    if not isinstance(suspension_id, str) or not suspension_id:
        raise LifecycleError("gateway_suspend_invalid", "Suspension response has no lease id")
    if expected_id is not None and suspension_id != expected_id:
        raise LifecycleError("gateway_suspend_replaced", "Suspension lease identity changed")
    return status, suspension_id


def lease_expiry(value: dict[str, Any]) -> int:
    expires_at_ms = value.get("expiresAtMs")
    if not isinstance(expires_at_ms, (int, float)):
        raise LifecycleError("gateway_suspend_invalid", "Suspension response has no expiry")
    return int(expires_at_ms)


def resume_lease(client: GatewayClient, suspension_id: str) -> dict[str, Any]:
    value = client.call("gateway.suspend.resume", {"suspensionId": suspension_id})
    if value.get("status") != "running":
        raise LifecycleError("gateway_resume_failed", "Gateway did not return to running state")
    return value


def arm_gateway_handoff(
    client: GatewayClient,
    *,
    suspension_id: str,
    target: dict[str, Any],
) -> dict[str, Any]:
    handoff = client.call(
        "gateway.suspend.handoff",
        {"suspensionId": suspension_id, "target": target},
    )
    if handoff.get("status") != "armed" or handoff.get("suspensionId") != suspension_id:
        raise LifecycleError("gateway_handoff_refused", "Gateway restart handoff was not armed")
    return handoff


def prepare_gateway(
    client: GatewayClient,
    *,
    request_id: str,
    drain_seconds: int,
    force_handoff: bool,
    arm_handoff: bool = False,
    lifecycle_state_path: Path,
    sleep: Callable[[float], None] = time.sleep,
    monotonic: Callable[[], float] = time.monotonic,
    wall_time_ms: Callable[[], int] = lambda: int(time.time() * 1000),
    resume_on_failure: bool = True,
) -> tuple[dict[str, Any], int]:
    if drain_seconds < 0:
        raise LifecycleError("invalid_drain_budget", "Drain budget must not be negative")

    target = gateway_identity(client)
    params = {"requestId": request_id, "terminalPolicy": "terminate", "drain": True}
    lease = client.call("gateway.suspend.prepare", params)
    status, suspension_id = require_lease(lease)
    deadline = monotonic() + drain_seconds

    def persist(phase: str, current: dict[str, Any]) -> None:
        write_state(
            lifecycle_state_path,
            {
                "requestId": request_id,
                "suspensionId": suspension_id,
                "phase": phase,
                "target": target,
                "expiresAtMs": current.get("expiresAtMs"),
            },
        )

    persist(status, lease)
    try:
        while status != "ready":
            remaining = deadline - monotonic()
            if remaining <= 0:
                if force_handoff:
                    handoff = arm_gateway_handoff(
                        client,
                        suspension_id=suspension_id,
                        target=target,
                    )
                    persist("armed", handoff)
                    return (
                        {
                            "status": "armed",
                            "requestId": request_id,
                            "suspensionId": suspension_id,
                            "target": target,
                            "expiresAtMs": handoff.get("expiresAtMs"),
                        },
                        0,
                    )
                resumed = resume_lease(client, suspension_id)
                persist("resumed", resumed)
                return (
                    {
                        "status": "drain_timeout",
                        "requestId": request_id,
                        "suspensionId": suspension_id,
                        "resumed": bool(resumed.get("resumed")),
                    },
                    EXIT_DRAIN_TIMEOUT,
                )

            retry_after_ms = lease.get("retryAfterMs", 1_000)
            if not isinstance(retry_after_ms, (int, float)) or retry_after_ms <= 0:
                retry_after_ms = 1_000
            wait_seconds = min(float(retry_after_ms) / 1000.0, MAX_POLL_SECONDS, remaining)
            if lease_expiry(lease) - wall_time_ms() <= max(RENEWAL_MARGIN_MS, int(wait_seconds * 1000) + 10_000):
                renewed = client.call("gateway.suspend.prepare", params)
                status, _ = require_lease(renewed, expected_id=suspension_id)
                lease = renewed
                persist(status, lease)
                if status == "ready":
                    break

            sleep(max(0.0, wait_seconds))
            lease = client.call("gateway.suspend.status", {"suspensionId": suspension_id})
            if lease.get("status") == "running":
                raise LifecycleError("gateway_suspend_lease_lost", "Gateway suspension lease expired")
            status, _ = require_lease(lease, expected_id=suspension_id)
            persist(status, lease)

        if arm_handoff:
            handoff = arm_gateway_handoff(
                client,
                suspension_id=suspension_id,
                target=target,
            )
            persist("armed", handoff)
            return (
                {
                    "status": "armed",
                    "requestId": request_id,
                    "suspensionId": suspension_id,
                    "target": target,
                    "expiresAtMs": handoff.get("expiresAtMs"),
                },
                0,
            )

        result = {
            "status": "ready",
            "requestId": request_id,
            "suspensionId": suspension_id,
            "target": target,
            "expiresAtMs": lease.get("expiresAtMs"),
        }
        persist("ready", lease)
        return result, 0
    except LifecycleError:
        if resume_on_failure:
            try:
                resumed = resume_lease(client, suspension_id)
                persist("resumed", resumed)
            except LifecycleError:
                pass
        raise


def derive_request_id() -> str:
    pod_uid = os.environ.get("OPENCLAW_POD_UID", "").strip()
    if not pod_uid:
        raise LifecycleError("pod_uid_missing", "OPENCLAW_POD_UID is required")
    return f"k8s-stop:{pod_uid}"


def command_prepare(args: argparse.Namespace, client: GatewayClient, path: Path) -> tuple[dict[str, Any], int]:
    return prepare_gateway(
        client,
        request_id=args.request_id or derive_request_id(),
        drain_seconds=args.drain_seconds,
        force_handoff=args.force_handoff,
        arm_handoff=args.arm_handoff,
        lifecycle_state_path=path,
    )


def command_prestop(args: argparse.Namespace, client: GatewayClient, path: Path) -> tuple[dict[str, Any], int]:
    request_id = args.request_id or derive_request_id()
    existing = read_state(path)
    if existing and existing.get("requestId") == request_id and existing.get("phase") in {"ready", "armed"}:
        suspension_id = existing.get("suspensionId")
        if isinstance(suspension_id, str) and suspension_id:
            current = client.call("gateway.suspend.status", {"suspensionId": suspension_id})
            if current.get("status") == "armed":
                if existing.get("phase") != "armed":
                    write_state(
                        path,
                        {
                            **{key: value for key, value in existing.items() if key != "schema"},
                            "phase": "armed",
                            "expiresAtMs": current.get("expiresAtMs"),
                        },
                    )
                return {
                    "status": "armed",
                    "requestId": request_id,
                    "suspensionId": suspension_id,
                    "reused": True,
                }, 0
            target = existing.get("target")
            if current.get("status") in {"ready", "draining"} and isinstance(target, dict):
                handoff = arm_gateway_handoff(
                    client,
                    suspension_id=suspension_id,
                    target=target,
                )
                write_state(
                    path,
                    {
                        **{key: value for key, value in existing.items() if key != "schema"},
                        "phase": "armed",
                        "expiresAtMs": handoff.get("expiresAtMs"),
                    },
                )
                return {
                    "status": "armed",
                    "requestId": request_id,
                    "suspensionId": suspension_id,
                    "reused": True,
                }, 0
    return prepare_gateway(
        client,
        request_id=request_id,
        drain_seconds=args.drain_seconds,
        force_handoff=True,
        arm_handoff=True,
        lifecycle_state_path=path,
        resume_on_failure=False,
    )


def command_resume(client: GatewayClient, path: Path) -> tuple[dict[str, Any], int]:
    existing = read_state(path)
    if not existing or not isinstance(existing.get("suspensionId"), str):
        return {"status": "running", "resumed": False}, 0
    resumed = resume_lease(client, existing["suspensionId"])
    write_state(
        path,
        {
            **{key: value for key, value in existing.items() if key != "schema"},
            "phase": "resumed",
            "expiresAtMs": None,
        },
    )
    return {"status": "running", "resumed": bool(resumed.get("resumed"))}, 0


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--profile", default=os.environ.get("OPENCLAW_AGENT_PROFILE") or os.environ.get("AGENT_ID"))
    value.add_argument("--state-file", type=Path, default=state_path())
    subparsers = value.add_subparsers(dest="command", required=True)

    for name in ("prepare", "prestop"):
        command = subparsers.add_parser(name)
        command.add_argument("--request-id")
        command.add_argument(
            "--drain-seconds",
            type=int,
            default=int(
                os.environ.get(
                    "OPENCLAW_PRESTOP_DRAIN_SECONDS" if name == "prestop" else "OPENCLAW_DEPLOY_DRAIN_SECONDS",
                    DEFAULT_DRAIN_SECONDS,
                )
            ),
        )
        if name == "prepare":
            command.add_argument("--force-handoff", action="store_true")
            command.add_argument("--arm-handoff", action="store_true")
    subparsers.add_parser("resume")
    subparsers.add_parser("identity")
    return value


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if not args.profile:
        print(json.dumps({"status": "failed", "errorCode": "profile_missing"}, sort_keys=True))
        return EXIT_FAILED
    client = GatewayClient(profile=args.profile)
    try:
        if args.command == "prepare":
            result, exit_code = command_prepare(args, client, args.state_file)
        elif args.command == "prestop":
            result, exit_code = command_prestop(args, client, args.state_file)
        elif args.command == "resume":
            result, exit_code = command_resume(client, args.state_file)
        else:
            result, exit_code = {"status": "running", "target": gateway_identity(client)}, 0
        print(json.dumps(result, sort_keys=True))
        return exit_code
    except LifecycleError as exc:
        exit_code = EXIT_UNSUPPORTED if exc.code == "gateway_method_unsupported" else EXIT_FAILED
        print(json.dumps({"status": "failed", "errorCode": exc.code}, sort_keys=True))
        return exit_code


if __name__ == "__main__":
    sys.exit(main())
