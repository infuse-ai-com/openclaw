#!/usr/bin/env python3
"""Acquire a fail-closed deployment mutex using an existing ConfigMap grant."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Callable


DNS_LABEL = re.compile(r"^[a-z0-9](?:[-a-z0-9]{0,61}[a-z0-9])?$")
HOLDER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,253}$")


class LockError(RuntimeError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def timestamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def parse_timestamp(value: object) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def validate(namespace: str, name: str, holder: str) -> None:
    if not DNS_LABEL.fullmatch(namespace):
        raise LockError("namespace_invalid")
    if not DNS_LABEL.fullmatch(name):
        raise LockError("lock_name_invalid")
    if not HOLDER.fullmatch(holder):
        raise LockError("holder_invalid")


@dataclass
class KubectlConfigMapClient:
    namespace: str
    name: str

    def _run(self, *args: str, body: dict | None = None) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["kubectl", "-n", self.namespace, *args],
            input=(json.dumps(body) if body is not None else None),
            text=True,
            capture_output=True,
            check=False,
        )

    def read(self) -> dict | None:
        result = self._run("get", "configmap", self.name, "--ignore-not-found", "-o", "json")
        if result.returncode != 0:
            raise LockError("lock_read_failed")
        if not result.stdout.strip():
            return None
        try:
            value = json.loads(result.stdout)
        except json.JSONDecodeError as error:
            raise LockError("lock_read_invalid") from error
        if not isinstance(value, dict):
            raise LockError("lock_read_invalid")
        return value

    def create(self, body: dict) -> bool:
        result = self._run("create", "-f", "-", body=body)
        if result.returncode == 0:
            return True
        if "AlreadyExists" in result.stderr:
            return False
        raise LockError("lock_create_failed")

    def replace(self, body: dict) -> bool:
        result = self._run("replace", "-f", "-", body=body)
        if result.returncode == 0:
            return True
        if "Conflict" in result.stderr or "the object has been modified" in result.stderr:
            return False
        raise LockError("lock_replace_failed")


def lock_body(
    *,
    namespace: str,
    name: str,
    holder: str,
    duration_seconds: int,
    now: datetime,
    current: dict | None = None,
) -> dict:
    metadata: dict[str, object] = {
        "name": name,
        "namespace": namespace,
        "labels": {"delivery.infuse-ai.com/purpose": "stable-deployment-lock"},
    }
    current_metadata = current.get("metadata", {}) if isinstance(current, dict) else {}
    if isinstance(current_metadata, dict) and current_metadata.get("resourceVersion"):
        metadata["resourceVersion"] = current_metadata["resourceVersion"]
    return {
        "apiVersion": "v1",
        "kind": "ConfigMap",
        "metadata": metadata,
        "data": {
            "holder": holder,
            "renewedAt": timestamp(now),
            "durationSeconds": str(duration_seconds),
        },
    }


def is_available(lock: dict, holder: str, now: datetime) -> bool:
    data = lock.get("data", {})
    if not isinstance(data, dict):
        raise LockError("lock_data_invalid")
    current_holder = data.get("holder")
    if not current_holder or current_holder == holder:
        return True
    try:
        duration = int(data.get("durationSeconds", ""))
    except (TypeError, ValueError) as error:
        raise LockError("lock_duration_invalid") from error
    renewed = parse_timestamp(data.get("renewedAt"))
    if duration <= 0 or renewed is None:
        raise LockError("lock_expiry_invalid")
    return renewed + timedelta(seconds=duration) <= now


def acquire(
    client: KubectlConfigMapClient,
    *,
    namespace: str,
    name: str,
    holder: str,
    duration_seconds: int,
    wait_seconds: int,
    poll_seconds: float,
    now: Callable[[], datetime] = utcnow,
    sleep: Callable[[float], None] = time.sleep,
) -> dict:
    deadline = now() + timedelta(seconds=wait_seconds)
    while True:
        observed_at = now()
        current = client.read()
        body = lock_body(
            namespace=namespace,
            name=name,
            holder=holder,
            duration_seconds=duration_seconds,
            now=observed_at,
            current=current,
        )
        if current is None:
            if client.create(body):
                return {"state": "acquired", "lock": name, "holder": holder}
        elif is_available(current, holder, observed_at) and client.replace(body):
            return {"state": "acquired", "lock": name, "holder": holder}
        if now() >= deadline:
            raise LockError("lock_wait_timeout")
        sleep(poll_seconds)


def renew(
    client: KubectlConfigMapClient,
    *,
    namespace: str,
    name: str,
    holder: str,
    duration_seconds: int,
    now: Callable[[], datetime] = utcnow,
) -> dict:
    current = client.read()
    if current is None:
        raise LockError("lock_missing")
    if current.get("data", {}).get("holder") != holder:
        raise LockError("lock_not_owned")
    body = lock_body(
        namespace=namespace,
        name=name,
        holder=holder,
        duration_seconds=duration_seconds,
        now=now(),
        current=current,
    )
    if not client.replace(body):
        raise LockError("lock_conflict")
    return {"state": "renewed", "lock": name, "holder": holder}


def release(
    client: KubectlConfigMapClient,
    *,
    namespace: str,
    name: str,
    holder: str,
    duration_seconds: int,
    now: Callable[[], datetime] = utcnow,
) -> dict:
    current = client.read()
    if current is None:
        return {"state": "absent", "lock": name, "holder": holder}
    if current.get("data", {}).get("holder") != holder:
        raise LockError("lock_not_owned")
    body = lock_body(
        namespace=namespace,
        name=name,
        holder="",
        duration_seconds=duration_seconds,
        now=now(),
        current=current,
    )
    if not client.replace(body):
        raise LockError("lock_conflict")
    return {"state": "released", "lock": name, "holder": holder}


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser()
    value.add_argument("action", choices=("acquire", "renew", "release"))
    value.add_argument("--namespace", required=True)
    value.add_argument("--name", required=True)
    value.add_argument("--holder", required=True)
    value.add_argument("--duration-seconds", type=int, default=900)
    value.add_argument("--wait-seconds", type=int, default=1200)
    value.add_argument("--poll-seconds", type=float, default=5.0)
    return value


def main() -> int:
    args = parser().parse_args()
    try:
        validate(args.namespace, args.name, args.holder)
        if not 60 <= args.duration_seconds <= 3600:
            raise LockError("lock_duration_invalid")
        if not 0 <= args.wait_seconds <= 3600 or not 0.1 <= args.poll_seconds <= 60:
            raise LockError("lock_wait_invalid")
        client = KubectlConfigMapClient(args.namespace, args.name)
        common = {
            "client": client,
            "namespace": args.namespace,
            "name": args.name,
            "holder": args.holder,
            "duration_seconds": args.duration_seconds,
        }
        if args.action == "acquire":
            result = acquire(
                **common,
                wait_seconds=args.wait_seconds,
                poll_seconds=args.poll_seconds,
            )
        elif args.action == "renew":
            result = renew(**common)
        else:
            result = release(**common)
        print(json.dumps(result, sort_keys=True, separators=(",", ":")))
        return 0
    except LockError as error:
        print(json.dumps({"error": error.code}, separators=(",", ":")), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
