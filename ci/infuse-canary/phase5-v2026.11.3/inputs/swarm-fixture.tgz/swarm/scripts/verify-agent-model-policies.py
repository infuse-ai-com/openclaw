#!/usr/bin/env python3
"""Verify deployment OpenClaw config matches config/agent-model-policies.json."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
POLICY_PATH = REPO_ROOT / "config/agent-model-policies.json"
DEPLOYMENTS_DIR = REPO_ROOT / "k8s/agents"
THINKING_LEVELS = {"off", "minimal", "low", "medium", "high", "xhigh", "adaptive", "max", "ultra"}
REASONING_DEFAULTS = {"on", "off", "stream"}
OPENAI_AGENT_PREFIXES = ("codex", "chatgpt", "openai")
LEGACY_AGENT_MARKERS = ("cursor", "claude", "qwen", "gemini", "opencode")
OPENAI_RUNTIME_SURFACES = (
    REPO_ROOT / "Taskfile.yml",
    REPO_ROOT / "images/openclaw-agent/Dockerfile",
    REPO_ROOT / "images/openclaw-agent/entrypoint.sh",
)
LEGACY_RUNTIME_MARKERS = ("cursor-agent", "cursor_oauth", "cursor-oauth", "cursor_access_token")
MEMORY_DREAMING_MODEL = "openai/gpt-5.6-terra"
HEARTBEAT_INTERVAL = "0m"


def main() -> int:
    policy = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
    defaults = policy.get("defaults", {})
    agents = policy.get("agents", {})
    errors: list[str] = []
    errors.extend(validate_openai_runtime_surfaces())

    if policy.get("schemaVersion") != 2:
        errors.append("config/agent-model-policies.json must use schemaVersion 2")
    selectable_models = defaults.get("selectableModels", [])
    if not isinstance(selectable_models, list) or any(
        not isinstance(model, str) or "/" not in model for model in selectable_models
    ):
        print("ERROR: defaults.selectableModels must be provider/model strings", file=sys.stderr)
        return 1
    if not isinstance(agents, dict) or not agents:
        errors.append("config/agent-model-policies.json must declare agents")

    for agent_id, agent_policy in sorted(agents.items()):
        errors.extend(validate_policy(agent_id, agent_policy, defaults))
        deployment_path = DEPLOYMENTS_DIR / agent_id / "deployment.yaml"
        if not deployment_path.exists():
            errors.append(f"{agent_id}: missing deployment at {deployment_path.relative_to(REPO_ROOT)}")
            continue
        try:
            text = deployment_path.read_text(encoding="utf-8")
            config = extract_openclaw_config(text)
        except Exception as exc:
            errors.append(f"{agent_id}: failed to parse OPENCLAW_CONFIG_JSON: {exc}")
            continue
        errors.extend(validate_deployment_config(agent_id, config, agent_policy, defaults))
        errors.extend(validate_heartbeat_config(agent_id, config))
        errors.extend(validate_memory_dreaming_config(agent_id, config))
        errors.extend(validate_acpx_config(agent_id, text, config))
        errors.extend(validate_boot_command(agent_id, text))

    for deployment_path in sorted(DEPLOYMENTS_DIR.glob("agent-*/deployment.yaml")):
        agent_id = deployment_path.parent.name
        if agent_id not in agents:
            errors.append(f"{agent_id}: deployment exists but no model policy is declared")

    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(f"Verified {len(agents)} agent model policies.")
    return 0


def validate_policy(agent_id: str, agent_policy: dict, defaults: dict) -> list[str]:
    errors: list[str] = []
    model = agent_policy.get("model")
    thinking = agent_policy.get("thinkingDefault", defaults.get("thinkingDefault"))
    reasoning = agent_policy.get("reasoningDefault", defaults.get("reasoningDefault"))
    runtime = agent_policy.get("runtime", defaults.get("runtime"))

    if not isinstance(model, str) or "/" not in model:
        errors.append(f"{agent_id}: model must be a provider/model string")
    if thinking not in THINKING_LEVELS:
        errors.append(f"{agent_id}: thinkingDefault must be one of {sorted(THINKING_LEVELS)}")
    if reasoning not in REASONING_DEFAULTS:
        errors.append(f"{agent_id}: reasoningDefault must be one of {sorted(REASONING_DEFAULTS)}")
    if not isinstance(runtime, str) or not runtime:
        errors.append(f"{agent_id}: runtime must be a non-empty string")
    fallback = agent_policy.get("fallbackModels", [])
    if not isinstance(fallback, list) or any(not isinstance(item, str) or "/" not in item for item in fallback):
        errors.append(f"{agent_id}: fallbackModels must be provider/model strings when set")
        fallback = []
    failure_policy = agent_policy.get("capacityFailurePolicy")
    if failure_policy not in {"single_approved_fallback", "fail_closed"}:
        errors.append(
            f"{agent_id}: capacityFailurePolicy must be single_approved_fallback or fail_closed"
        )
    elif failure_policy == "single_approved_fallback" and len(fallback) != 1:
        errors.append(
            f"{agent_id}: single_approved_fallback requires exactly one fallback model"
        )
    elif failure_policy == "fail_closed" and fallback:
        errors.append(f"{agent_id}: fail_closed must not declare fallback models")
    if isinstance(model, str) and model in fallback:
        errors.append(f"{agent_id}: primary model cannot also be its fallback")
    return errors


def validate_openai_runtime_surfaces() -> list[str]:
    errors: list[str] = []
    for path in OPENAI_RUNTIME_SURFACES:
        text = path.read_text(encoding="utf-8").lower()
        found = sorted(marker for marker in LEGACY_RUNTIME_MARKERS if marker in text)
        if found:
            errors.append(
                f"{path.relative_to(REPO_ROOT)} contains legacy worker runtime markers: {found}"
            )
    retired_helper = REPO_ROOT / "scripts/sync-agent-cursor-oauth.sh"
    if retired_helper.exists():
        errors.append("scripts/sync-agent-cursor-oauth.sh must remain retired")
    return errors


def extract_openclaw_config(text: str) -> dict:
    match = re.search(r"name: OPENCLAW_CONFIG_JSON\n\s+value: '(.*)'", text)
    if not match:
        raise ValueError("OPENCLAW_CONFIG_JSON env var not found")
    return json.loads(match.group(1))


def validate_acpx_agents(agent_id: str, agents: object, location: str) -> list[str]:
    if agents is None:
        return []
    if not isinstance(agents, dict):
        return [f"{agent_id}: {location}.agents must be an object"]
    unsupported = sorted(
        name
        for name in agents
        if not isinstance(name, str) or not name.lower().startswith(OPENAI_AGENT_PREFIXES)
    )
    if unsupported:
        errors = [
            f"{agent_id}: {location}.agents contains non-OpenAI routes: {unsupported}"
        ]
    else:
        errors = []
    legacy_specs = sorted(
        name
        for name, spec in agents.items()
        if any(marker in json.dumps(spec).lower() for marker in LEGACY_AGENT_MARKERS)
    )
    if legacy_specs:
        errors.append(
            f"{agent_id}: {location}.agents contains legacy worker commands: {legacy_specs}"
        )
    return errors


def validate_acpx_config(agent_id: str, text: str, openclaw_config: dict) -> list[str]:
    errors: list[str] = []
    plugin_agents = (
        openclaw_config.get("plugins", {})
        .get("entries", {})
        .get("acpx", {})
        .get("config", {})
        .get("agents")
    )
    errors.extend(validate_acpx_agents(agent_id, plugin_agents, "plugins.entries.acpx.config"))

    match = re.search(r"name: ACPX_CONFIG_JSON\n\s+value: '(.*)'", text)
    if match:
        try:
            acpx_config = json.loads(match.group(1))
        except json.JSONDecodeError as exc:
            return errors + [f"{agent_id}: ACPX_CONFIG_JSON is invalid JSON: {exc}"]
        errors.extend(validate_acpx_agents(agent_id, acpx_config.get("agents"), "ACPX_CONFIG_JSON"))
        default_agent = acpx_config.get("defaultAgent")
        if not isinstance(default_agent, str) or not default_agent.lower().startswith(OPENAI_AGENT_PREFIXES):
            errors.append(f"{agent_id}: ACPX_CONFIG_JSON.defaultAgent must be OpenAI-backed")
    return errors


def validate_memory_dreaming_config(agent_id: str, openclaw_config: dict) -> list[str]:
    plugins = openclaw_config.get("plugins", {})
    entry = plugins.get("entries", {}).get("memory-core")
    if not isinstance(entry, dict):
        return [f"{agent_id}: plugins.entries.memory-core must be configured"]

    errors: list[str] = []
    if "memory-core" not in plugins.get("allow", []):
        errors.append(f"{agent_id}: plugins.allow must include memory-core")
    if entry.get("enabled") is not True:
        errors.append(f"{agent_id}: plugins.entries.memory-core.enabled must be true")

    subagent = entry.get("subagent", {})
    if not isinstance(subagent, dict):
        errors.append(f"{agent_id}: plugins.entries.memory-core.subagent must be an object")
        subagent = {}
    if subagent.get("allowModelOverride") is not True:
        errors.append(
            f"{agent_id}: plugins.entries.memory-core.subagent.allowModelOverride must be true"
        )
    if subagent.get("allowedModels") != [MEMORY_DREAMING_MODEL]:
        errors.append(
            f"{agent_id}: plugins.entries.memory-core.subagent.allowedModels "
            f"must be [{MEMORY_DREAMING_MODEL!r}]"
        )

    plugin_config = entry.get("config", {})
    if not isinstance(plugin_config, dict):
        errors.append(f"{agent_id}: plugins.entries.memory-core.config must be an object")
        plugin_config = {}
    dreaming = plugin_config.get("dreaming", {})
    if not isinstance(dreaming, dict):
        errors.append(f"{agent_id}: plugins.entries.memory-core.config.dreaming must be an object")
        dreaming = {}
    if dreaming.get("model") != MEMORY_DREAMING_MODEL:
        errors.append(
            f"{agent_id}: plugins.entries.memory-core.config.dreaming.model "
            f"must be {MEMORY_DREAMING_MODEL!r}"
        )
    if "thinking" in dreaming:
        errors.append(
            f"{agent_id}: plugins.entries.memory-core.config.dreaming.thinking is unsupported; "
            "use OpenClaw's built-in medium dreaming profile"
        )
    return errors


def validate_heartbeat_config(agent_id: str, openclaw_config: dict) -> list[str]:
    heartbeat = openclaw_config.get("agents", {}).get("defaults", {}).get("heartbeat")
    if not isinstance(heartbeat, dict):
        return [f"{agent_id}: agents.defaults.heartbeat must be configured"]
    if heartbeat.get("every") != HEARTBEAT_INTERVAL:
        return [
            f"{agent_id}: agents.defaults.heartbeat.every must be {HEARTBEAT_INTERVAL!r} "
            "to disable recurring model wakeups"
        ]
    return []


def validate_boot_command(agent_id: str, text: str) -> list[str]:
    match = re.search(r"name: OPENCLAW_BOOT_SCRIPT\n\s+value: ([^\s]+)", text)
    if not match:
        return [f"{agent_id}: OPENCLAW_BOOT_SCRIPT env var not found"]
    if match.group(1) != "/usr/local/bin/openclaw-agent-developer-canary-boot":
        return [f"{agent_id}: unexpected OPENCLAW_BOOT_SCRIPT"]
    command = (REPO_ROOT / "scripts/boot-agent-developer-canary.sh").read_text(encoding="utf-8")
    plugin_marker = 'openclaw-agent-ensure-plugins "$profile"'
    state_rewrite_marker = 'printf \'%s\' "$canonical_config" >"$state_dir/openclaw.json"'
    exec_marker = "exec openclaw "
    plugin_index = command.find(plugin_marker)
    rewrite_index = command.find(state_rewrite_marker, plugin_index + len(plugin_marker))
    exec_index = command.find(exec_marker)
    if plugin_index == -1:
        return [f"{agent_id}: boot script must ensure runtime plugins before gateway start"]
    if rewrite_index == -1:
        return [f"{agent_id}: boot script must rewrite OPENCLAW_STATE_DIR config after plugin ensure"]
    if exec_index == -1 or not (plugin_index < rewrite_index < exec_index):
        return [f"{agent_id}: boot script must rewrite config after plugin ensure and before gateway exec"]
    return []


def validate_deployment_config(agent_id: str, config: dict, agent_policy: dict, defaults: dict) -> list[str]:
    errors: list[str] = []
    agents_config = config.get("agents", {})
    config_defaults = agents_config.get("defaults", {})
    entries = agents_config.get("entries")
    if isinstance(entries, dict):
        entry = entries.get(agent_id)
        matching_agents = [{"id": agent_id, **entry}] if isinstance(entry, dict) else []
        agent_location = f"agents.entries[{agent_id}]"
    else:
        matching_agents = [
            item for item in agents_config.get("list", [])
            if isinstance(item, dict) and item.get("id") == agent_id
        ]
        agent_location = f"agents.list[{agent_id}]"
    if len(matching_agents) != 1:
        return [f"{agent_id}: deployment config must include exactly one matching agent entry"]

    model = agent_policy["model"]
    fallback_models = agent_policy.get("fallbackModels", [])
    thinking = agent_policy.get("thinkingDefault", defaults.get("thinkingDefault"))
    reasoning = agent_policy.get("reasoningDefault", defaults.get("reasoningDefault"))
    runtime = agent_policy.get("runtime", defaults.get("runtime"))
    agent_config = matching_agents[0]

    expected_model = {"primary": model}
    if fallback_models:
        expected_model["fallbacks"] = fallback_models
    selectable_models = defaults.get("selectableModels", [])
    expected_models = sorted({model, *fallback_models, *selectable_models})
    for location, obj in (("agents.defaults", config_defaults), (agent_location, agent_config)):
        if obj.get("model") != expected_model:
            errors.append(f"{agent_id}: {location}.model must be {expected_model!r}")
        if obj.get("thinkingDefault") != thinking:
            errors.append(f"{agent_id}: {location}.thinkingDefault must be {thinking!r}")
        if obj.get("reasoningDefault") != reasoning:
            errors.append(f"{agent_id}: {location}.reasoningDefault must be {reasoning!r}")
        models = obj.get("models", {})
        if sorted(models.keys()) != expected_models:
            errors.append(f"{agent_id}: {location}.models must declare {expected_models!r}")
        else:
            for model_id in expected_models:
                runtime_id = models[model_id].get("agentRuntime", {}).get("id")
                if runtime_id != runtime:
                    errors.append(f"{agent_id}: {location}.models[{model_id}].agentRuntime.id must be {runtime!r}")
        explicit_allowlist = obj.get("modelPolicy", {}).get("allow")
        if explicit_allowlist is not None and any(model_id not in explicit_allowlist for model_id in expected_models):
            errors.append(f"{agent_id}: {location}.modelPolicy.allow must admit the configured models")
    return errors


if __name__ == "__main__":
    raise SystemExit(main())
