#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AGENT_ID="${AGENT_ID:-agent-coordinator}"

echo "Emon certificate runtime smoke"
echo "agent_id=${AGENT_ID}"
echo "repo=${ROOT}"

check_cmd() {
  local name="$1"
  if command -v "$name" >/dev/null 2>&1; then
    printf 'tool.%s=available:%s\n' "$name" "$(command -v "$name")"
  else
    printf 'tool.%s=missing\n' "$name"
  fi
}

check_cmd git
check_cmd task
check_cmd acpx
check_cmd kubectl

if [[ -f "${ROOT}/config/agent-skill-bundles/${AGENT_ID}.json" ]]; then
  echo "bundle=present:config/agent-skill-bundles/${AGENT_ID}.json"
else
  echo "bundle=missing:config/agent-skill-bundles/${AGENT_ID}.json"
fi

if [[ -f "${ROOT}/docs/certification/emon/levels.md" ]]; then
  echo "certification_docs=present"
else
  echo "certification_docs=missing"
fi

if [[ -d "${ROOT}/tests/emon" ]]; then
  echo "certification_tests=present"
else
  echo "certification_tests=missing"
fi

git -C "$ROOT" diff --check
