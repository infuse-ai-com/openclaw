// Offline compatibility checks against the actual consumer dependency tree.
import assert from "node:assert/strict";
import http from "node:http";
import { createRequire } from "node:module";
import { gzipSync } from "node:zlib";
import path from "node:path";

const root = process.argv[2] ?? "/opt/openclaw-consumer";
const host = createRequire(path.join(root, "node_modules/openclaw/package.json"));
const express = host("express");
const parser = createRequire(host.resolve("express/package.json"))("body-parser");
const { request } = host("undici");
const { McpServer } = host("@modelcontextprotocol/sdk/server/mcp.js");
const mcp = new McpServer({ name: "isolated-security-smoke", version: "1.0.0" });
await mcp.close();

const app = express();
app.use(parser.json());
app.post("/echo", (req, res) => res.json(req.body));
app.get("/health", (_req, res) => res.json({ ok: true }));
app.use((error, _req, res, _next) => res.status(error.status ?? 500).json({ rejected: true }));
const server = http.createServer(app);
server.requestTimeout = 3000;
await new Promise((resolve, reject) => {
  server.once("error", reject);
  server.listen(0, "127.0.0.1", resolve);
});
const url = `http://127.0.0.1:${server.address().port}`;
try {
  const normal = await request(`${url}/echo`, {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ ok: true }), bodyTimeout: 3000, headersTimeout: 3000,
  });
  assert.equal(normal.statusCode, 200);
  assert.deepEqual(await normal.body.json(), { ok: true });

  // Regression: errors after a compressed frame must not terminate Node.
  const malformed = await request(`${url}/echo`, {
    method: "POST", headers: { "content-type": "application/json", "content-encoding": "gzip" },
    body: Buffer.concat([gzipSync('{"ok":true}'), Buffer.from("trailing-invalid-gzip")]),
    bodyTimeout: 3000, headersTimeout: 3000,
  });
  await malformed.body.dump();
  assert([200, 400].includes(malformed.statusCode));
  const alive = await request(`${url}/health`, { bodyTimeout: 3000, headersTimeout: 3000 });
  assert.equal(alive.statusCode, 200);
  assert.deepEqual(await alive.body.json(), { ok: true });
  console.log("MCP startup, undici HTTP and compressed-body error recovery passed");
} finally {
  server.closeAllConnections();
  await new Promise((resolve) => server.close(resolve));
}
