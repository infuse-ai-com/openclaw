#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-designer}"
item_name="${VAULTWARDEN_ITEM_NAME:?Set VAULTWARDEN_ITEM_NAME to a bundle-allowed Vaultwarden item name}"
target_name="${CREDENTIAL_SECRET_NAME:-}"
target_key="${CREDENTIAL_SECRET_KEY:-}"
target_type="${CREDENTIAL_TARGET_TYPE:-}"
source_field="${CREDENTIAL_SOURCE_FIELD:-}"
bw="${BW_HELPER:-scripts/bw-local-vaultwarden.sh}"
dry_run="${DRY_RUN:-false}"
dry_run_output="${DRY_RUN_OUTPUT:-/tmp/openclaw-$agent_id-credential.yaml}"
bundle_path="config/agent-skill-bundles/$agent_id.json"
placeholder_value="replace-with-vaultwarden-sourced-secret"

if [[ -z "$target_type" || -z "$target_name" || -z "$target_key" || -z "$source_field" ]]; then
  read -r target_type target_name target_key source_field < <(
    python3 - "$bundle_path" "$item_name" "$namespace" "$target_type" "$target_name" "$target_key" "$source_field" <<'PY'
import json
import sys
from pathlib import Path

bundle_path = Path(sys.argv[1])
item_name = sys.argv[2]
namespace = sys.argv[3]
requested_type = sys.argv[4]
requested_name = sys.argv[5]
requested_key = sys.argv[6]
requested_source_field = sys.argv[7]

if not bundle_path.exists():
    print(f"Agent bundle not found: {bundle_path}", file=sys.stderr)
    sys.exit(2)

bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
items = (
    bundle.get("credential_access", {})
    .get("vaultwarden", {})
    .get("allowed_items", [])
)
matches = []
for item in items:
    target = item.get("sync_target", {})
    if item.get("name") != item_name:
        continue
    if target.get("namespace") != namespace:
        continue
    if requested_type and target.get("type") != requested_type:
        continue
    if requested_name and target.get("name") != requested_name:
        continue
    if requested_key and target.get("key") != requested_key:
        continue
    if requested_source_field and target.get("source_field", "password") != requested_source_field:
        continue
    matches.append(target)

if len(matches) != 1:
    print(
        "Credential sync target must match exactly one bundle entry "
        f"({bundle_path}): item={item_name!r}, namespace={namespace!r}, "
        f"type={requested_type!r}, name={requested_name!r}, key={requested_key!r}, "
        f"matches={len(matches)}",
        file=sys.stderr,
    )
    sys.exit(2)

target = matches[0]
print(target["type"], target["name"], target["key"], target.get("source_field", "password"))
PY
  )
fi

python3 - "$bundle_path" "$item_name" "$namespace" "$target_type" "$target_name" "$target_key" "$source_field" <<'PY'
import json
import sys
from pathlib import Path

bundle_path = Path(sys.argv[1])
item_name = sys.argv[2]
namespace = sys.argv[3]
target_type = sys.argv[4]
target_name = sys.argv[5]
target_key = sys.argv[6]
source_field = sys.argv[7] or "password"

bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
items = (
    bundle.get("credential_access", {})
    .get("vaultwarden", {})
    .get("allowed_items", [])
)
for item in items:
    target = item.get("sync_target", {})
    if (
        item.get("name") == item_name
        and target.get("type") == target_type
        and target.get("namespace") == namespace
        and target.get("name") == target_name
        and target.get("key") == target_key
        and target.get("source_field", "password") == source_field
    ):
        sys.exit(0)

print(
    "Credential sync is not allowed by the agent bundle "
    f"({bundle_path}): item={item_name!r}, namespace={namespace!r}, "
    f"type={target_type!r}, secret={target_name!r}, key={target_key!r}, source_field={source_field!r}",
    file=sys.stderr,
)
sys.exit(2)
PY

case "$source_field" in
  password|username)
    ;;
  *)
    echo "Unsupported Vaultwarden source field: $source_field" >&2
    exit 2
    ;;
esac

case "$target_type" in
  kubernetes-secret|kubernetes-secret-env|kubernetes-secret-file)
    ;;
  *)
    echo "Unsupported credential sync target type: $target_type" >&2
    exit 2
    ;;
esac

target_fields=()
while IFS= read -r target_field; do
  [[ -z "$target_field" ]] && continue
  target_fields+=("$target_field")
done < <(
  python3 - "$bundle_path" "$item_name" "$namespace" "$target_type" "$target_name" <<'PY'
import json
import sys
from pathlib import Path

bundle_path = Path(sys.argv[1])
item_name = sys.argv[2]
namespace = sys.argv[3]
target_type = sys.argv[4]
target_name = sys.argv[5]

bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
items = (
    bundle.get("credential_access", {})
    .get("vaultwarden", {})
    .get("allowed_items", [])
)
for item in items:
    target = item.get("sync_target", {})
    if (
        item.get("name") == item_name
        and target.get("type") == target_type
        and target.get("namespace") == namespace
        and target.get("name") == target_name
    ):
        print(f"{target['key']}\t{target.get('source_field', 'password')}")
PY
)

if [[ "${#target_fields[@]}" -lt 1 ]]; then
  echo "No bundle-declared target fields found for $namespace/$target_name" >&2
  exit 2
fi

create_secret_manifest() {
  local -a args
  local literal
  args=(
    kubectl -n "$namespace" create secret generic "$target_name"
  )

  for literal in "$@"; do
    case "$literal" in
      *=*) args+=("--from-literal=$literal") ;;
      *)
        echo "Invalid secret literal, expected KEY=VALUE" >&2
        exit 2
        ;;
    esac
  done

  if [[ -n "${EXTRA_SECRET_LITERALS:-}" ]]; then
    while IFS= read -r literal; do
      [[ -z "$literal" ]] && continue
      case "$literal" in
        *=*) args+=("--from-literal=$literal") ;;
        *)
          echo "Invalid EXTRA_SECRET_LITERALS entry, expected KEY=VALUE" >&2
          exit 2
          ;;
      esac
    done <<<"$EXTRA_SECRET_LITERALS"
  fi

  "${args[@]}" --dry-run=client -o yaml
}

if [[ "$dry_run" == "true" ]]; then
  placeholder_literals=()
  for field in "${target_fields[@]}"; do
    key="${field%%$'\t'*}"
    placeholder_literals+=("$key=$placeholder_value")
  done
  create_secret_manifest "${placeholder_literals[@]}" >"$dry_run_output"
  echo "Rendered credential secret manifest with placeholder value: $dry_run_output"
  exit 0
fi

if [[ ! -x "$bw" ]]; then
  echo "Vaultwarden helper not found or not executable: $bw" >&2
  exit 2
fi

secret_literals=()
for field in "${target_fields[@]}"; do
  key="${field%%$'\t'*}"
  field_source="${field#*$'\t'}"
  case "$field_source" in
    password|username)
      ;;
    *)
      echo "Unsupported Vaultwarden source field: $field_source" >&2
      exit 2
      ;;
  esac
  secret_value="$(
    OPENCLAW_BW_SERVER="${OPENCLAW_BW_SERVER:-https://vault.infuse-ai-tech.party}" \
    OPENCLAW_BW_DATA="${OPENCLAW_BW_DATA:-/Users/mac/.openclaw/secure/bitwarden-cli-infuse}" \
    "$bw" get "$field_source" "$item_name"
  )"
  if [[ -z "$secret_value" ]]; then
    echo "Vaultwarden item has an empty $field_source field: $item_name" >&2
    exit 2
  fi
  secret_literals+=("$key=$secret_value")
done

create_secret_manifest "${secret_literals[@]}" | kubectl --context "$context" apply \
  --server-side \
  --force-conflicts \
  --field-manager=openclaw-agent-credential-sync \
  -f -

echo "Synced credential target $namespace/$target_name for $agent_id"
