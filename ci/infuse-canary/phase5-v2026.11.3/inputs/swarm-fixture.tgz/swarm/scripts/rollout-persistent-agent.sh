#!/usr/bin/env bash
set -euo pipefail

namespace="${1:?Usage: $0 <namespace> <deployment> <rendered-manifest>}"
deployment="${2:?Usage: $0 <namespace> <deployment> <rendered-manifest>}"
rendered_manifest="${3:?Usage: $0 <namespace> <deployment> <rendered-manifest>}"
rollout_mode="${OPENCLAW_ROLLOUT_MODE:-bounded}"
case "$rollout_mode" in
  bounded)
    default_drain_seconds=30
    force_handoff=true
    ;;
  drain)
    default_drain_seconds=300
    force_handoff=false
    ;;
  *)
    echo "OPENCLAW_ROLLOUT_MODE must be bounded or drain." >&2
    exit 2
    ;;
esac
drain_seconds="${OPENCLAW_DEPLOY_DRAIN_SECONDS:-$default_drain_seconds}"
pod_deletion_slo_seconds="${OPENCLAW_POD_DELETION_SLO_SECONDS:-30}"
forced_pod_grace_seconds="${OPENCLAW_FORCED_POD_GRACE_SECONDS:-15}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! "$drain_seconds" =~ ^[0-9]+$ ]]; then
  echo "OPENCLAW_DEPLOY_DRAIN_SECONDS must be a non-negative integer." >&2
  exit 2
fi
if [[ ! "$pod_deletion_slo_seconds" =~ ^[0-9]+$ ]]; then
  echo "OPENCLAW_POD_DELETION_SLO_SECONDS must be a non-negative integer." >&2
  exit 2
fi
if [[ ! "$forced_pod_grace_seconds" =~ ^[0-9]+$ ]]; then
  echo "OPENCLAW_FORCED_POD_GRACE_SECONDS must be a non-negative integer." >&2
  exit 2
fi
if (( forced_pod_grace_seconds > pod_deletion_slo_seconds )); then
  echo "OPENCLAW_FORCED_POD_GRACE_SECONDS must not exceed OPENCLAW_POD_DELETION_SLO_SECONDS." >&2
  exit 2
fi
if [ ! -r "$rendered_manifest" ]; then
  echo "Rendered manifest is not readable: $rendered_manifest" >&2
  exit 2
fi

kubectl_cmd=(kubectl)
if [ -n "${KUBE_CONTEXT:-}" ]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

agents=(agent-developer agent-designer agent-infra agent-intake agent-coordinator)
selector_args=()
for agent in "${agents[@]}"; do
  selector_args+=(--agent "$agent")
done

prepared=false
termination_requested=false
manifest_replace_attempted=false
target_start_requested=false
completed=false
old_revision=""
old_replicas=""
old_pod=""

pod_json() {
  "${kubectl_cmd[@]}" -n "$namespace" get pods \
    -l "app.kubernetes.io/name=$deployment" -o json
}

single_running_pod() {
  local pods
  pods="$(pod_json | jq -r '[.items[] | select(.metadata.deletionTimestamp == null and .status.phase == "Running") | .metadata.name] | .[]')"
  if [ "$(wc -w <<<"$pods" | tr -d ' ')" != "1" ]; then
    echo "Expected exactly one running non-terminating pod for deployment/$deployment; found: ${pods:-none}." >&2
    return 1
  fi
  printf '%s\n' "$pods"
}

assert_no_agent_pods() {
  local count
  count="$(pod_json | jq '.items | length')"
  if [ "$count" != "0" ]; then
    echo "Refusing to apply deployment/$deployment while $count prior pod object(s) remain." >&2
    return 1
  fi
}

run_helper() {
  local pod="$1"
  shift
  # Run the controller revision inside the predecessor pod. This keeps new
  # lifecycle arguments compatible with an older installed helper while the
  # Gateway process and lifecycle state remain local to that exact pod.
  "${kubectl_cmd[@]}" -n "$namespace" exec -i "$pod" -c agent -- \
    python3 - --profile "$deployment" "$@" <"$script_dir/openclaw_gateway_lifecycle.py"
}

installed_prestop_arms_handoff() {
  local pod="$1"
  "${kubectl_cmd[@]}" -n "$namespace" exec "$pod" -c agent -- \
    /usr/local/bin/openclaw-gateway-lifecycle prepare --help 2>/dev/null \
    | grep -q -- '--arm-handoff'
}

resume_old_gateway() {
  if [ "$prepared" = true ] && [ "$termination_requested" = false ] && [ -n "$old_pod" ]; then
    echo "Resuming the prepared Gateway for deployment/$deployment after a pre-termination failure." >&2
    run_helper "$old_pod" resume >/dev/null 2>&1 || true
  fi
}

recover_pre_start_failure() {
  if [ "$termination_requested" != true ] || [ "$target_start_requested" = true ]; then
    return 0
  fi

  echo "Recovering deployment/$deployment because the old pod stopped before a replacement was requested." >&2
  if [ "$manifest_replace_attempted" = true ] && [ -n "$old_revision" ]; then
    "${kubectl_cmd[@]}" -n "$namespace" rollout undo "deployment/$deployment" \
      --to-revision="$old_revision" >/dev/null 2>&1 || true
  fi
  "${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$deployment" \
    --replicas="$old_replicas" >/dev/null 2>&1 || true
  echo "Requested asynchronous recovery of deployment/$deployment at replicas=$old_replicas." >&2
}

rollout_failed() {
  local exit_code="$1"
  trap - ERR
  set +e
  if [ "$completed" != true ]; then
    resume_old_gateway
    recover_pre_start_failure
    if [ "$target_start_requested" = true ]; then
      echo "Replacement startup for deployment/$deployment was requested; leaving the new revision in place for diagnosis." >&2
      "${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$deployment" \
        --replicas="$old_replicas" >/dev/null 2>&1 || true
    fi
  fi
  exit "$exit_code"
}
trap 'rollout_failed "$?"' ERR

select_deployment_manifest() {
  "$script_dir/select-agent-rollout-manifests.py" \
    --mode deployment "${selector_args[@]}" --deployment "$deployment" \
    <"$rendered_manifest"
}

replace_deployment_manifest() {
  local resource_version

  resource_version="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" \
    -o jsonpath='{.metadata.resourceVersion}')"
  if [ -z "$resource_version" ]; then
    echo "Could not resolve the current resourceVersion for deployment/$deployment." >&2
    return 1
  fi

  # Client-side and server-side apply both preserve list entries owned by a
  # stale field manager. That can leave mutually exclusive gateway auth env
  # variables in place. The old pod is already absent (or replicas are held at
  # zero), so replace the repository-owned Deployment from its exact rendered
  # object and current resourceVersion before starting a writer.
  select_deployment_manifest \
    | jq --arg resource_version "$resource_version" \
        '.metadata.resourceVersion = $resource_version' \
    | "${kubectl_cmd[@]}" -n "$namespace" replace -f -
}

if ! "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" >/dev/null 2>&1; then
  echo "Creating deployment/$deployment from a held-at-zero manifest."
  select_deployment_manifest \
    | "${kubectl_cmd[@]}" -n "$namespace" apply -f -
  "${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$deployment" --replicas=1
  "${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$deployment" --timeout=600s
  completed=true
  exit 0
fi

old_replicas="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" -o jsonpath='{.spec.replicas}')"
old_revision="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" -o jsonpath='{.metadata.annotations.deployment\.kubernetes\.io/revision}')"
if [ "$old_replicas" = "0" ]; then
  echo "Updating deployment/$deployment while preserving replicas=0."
  replace_deployment_manifest || rollout_failed "$?"
  completed=true
  exit 0
fi
if [ "$old_replicas" != "1" ]; then
  echo "Refusing deployment/$deployment with replicas=$old_replicas; persistent agents require exactly one writer." >&2
  exit 1
fi

old_pod="$(single_running_pod)"
if ! old_identity="$(run_helper "$old_pod" identity)"; then
  old_pod_health="$(
    pod_json | jq -cer --arg pod "$old_pod" '
      .items[]
      | select(.metadata.name == $pod)
      | {
          ready: ([.status.containerStatuses[]? | select(.name == "agent") | .ready] | first // false),
          restartCount: ([.status.containerStatuses[]? | select(.name == "agent") | .restartCount] | first // 0)
        }
    '
  )"
  old_pod_ready="$(jq -r '.ready' <<<"$old_pod_health")"
  old_pod_restarts="$(jq -r '.restartCount' <<<"$old_pod_health")"
  if [ "$old_pod_ready" != "false" ] || ! [[ "$old_pod_restarts" =~ ^[1-9][0-9]*$ ]]; then
    echo "Refusing recovery for deployment/$deployment: predecessor identity failed without an unready restarted agent container." >&2
    exit 1
  fi

  echo "Replacing failed-startup predecessor for deployment/$deployment (ready=$old_pod_ready restarts=$old_pod_restarts)."
  termination_requested=true
  deletion_started_seconds=$SECONDS
  "${kubectl_cmd[@]}" -n "$namespace" delete "pod/$old_pod" \
    --grace-period="$forced_pod_grace_seconds" --wait=false --ignore-not-found=true >/dev/null
  "${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$deployment" --replicas=0
  if ! "${kubectl_cmd[@]}" -n "$namespace" wait --for=delete "pod/$old_pod" \
    --timeout="${pod_deletion_slo_seconds}s"; then
    echo "Failed-startup predecessor for deployment/$deployment did not delete within the ${pod_deletion_slo_seconds}s rollout SLO." >&2
    rollout_failed 1
  fi
  deletion_elapsed_seconds=$((SECONDS - deletion_started_seconds))
  echo "Deleted failed-startup predecessor for deployment/$deployment in ${deletion_elapsed_seconds}s (SLO: ${pod_deletion_slo_seconds}s)."
  if (( deletion_elapsed_seconds > pod_deletion_slo_seconds )); then
    echo "Failed-startup predecessor deletion exceeded the ${pod_deletion_slo_seconds}s rollout SLO." >&2
    rollout_failed 1
  fi
  assert_no_agent_pods

  manifest_replace_attempted=true
  replace_deployment_manifest || rollout_failed "$?"

  target_start_requested=true
  "${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$deployment" --replicas="$old_replicas"
  "${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$deployment" --timeout=600s

  new_pod="$(single_running_pod)"
  run_helper "$new_pod" identity >/dev/null
  "${kubectl_cmd[@]}" -n "$namespace" exec "$new_pod" -c agent -- \
    curl -fsS --max-time 5 http://127.0.0.1:18791/readyz >/dev/null

  completed=true
  echo "Completed failed-startup replacement for deployment/$deployment."
  exit 0
fi
old_process_instance_id="$(jq -er '.target.processInstanceId' <<<"$old_identity")"
prestop_can_arm=false
if installed_prestop_arms_handoff "$old_pod"; then
  prestop_can_arm=true
fi

prepare_args=(prepare --drain-seconds "$drain_seconds")
if [ "$force_handoff" = true ]; then
  prepare_args+=(--force-handoff)
fi
echo "Preparing Gateway shutdown for deployment/$deployment (mode: $rollout_mode, drain budget: ${drain_seconds}s)."
prepare_result="$(run_helper "$old_pod" "${prepare_args[@]}")"
prepared=true
prepare_status="$(jq -er 'select(.status == "ready" or .status == "armed") | .status' <<<"$prepare_result")"

# Arm every controller-led rollout before asking Kubernetes to terminate the
# pod. OpenClaw treats SIGTERM as a restart request, so preStop can close
# admission without making PID 1 exit. The explicit arm lets the controller
# send the bounded grace in the initial delete request while the exact
# predecessor remains addressable.
if [ "$prepare_status" = "ready" ]; then
  if [ "$prestop_can_arm" = true ]; then
    echo "Arming the controller handoff for deployment/$deployment before bounded deletion."
  else
    echo "Bootstrapping the controller handoff for an older preStop helper in deployment/$deployment."
  fi
  handoff_result="$(run_helper "$old_pod" prestop --drain-seconds 0)"
  jq -e '.status == "armed"' <<<"$handoff_result" >/dev/null
  prepare_status=armed
fi

echo "Stopping only deployment/$deployment before updating its single-writer workspace owner."
termination_requested=true
deletion_started_seconds=$SECONDS
if [ "$prepare_status" = "armed" ]; then
  # Handoff has already closed admission and persisted the exact predecessor.
  # Make the bounded grace part of the initial delete request: OpenClaw handles
  # SIGTERM as a restart, and Kubernetes does not reliably shorten termination
  # after it has already started with the 420-second emergency ceiling.
  "${kubectl_cmd[@]}" -n "$namespace" delete "pod/$old_pod" \
    --grace-period="$forced_pod_grace_seconds" --wait=false --ignore-not-found=true >/dev/null
fi
"${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$deployment" --replicas=0
if ! "${kubectl_cmd[@]}" -n "$namespace" wait --for=delete "pod/$old_pod" \
    --timeout="${pod_deletion_slo_seconds}s"; then
  echo "Predecessor pod for deployment/$deployment did not delete within the ${pod_deletion_slo_seconds}s rollout SLO." >&2
  rollout_failed 1
fi
deletion_elapsed_seconds=$((SECONDS - deletion_started_seconds))
echo "Deleted predecessor pod for deployment/$deployment in ${deletion_elapsed_seconds}s (SLO: ${pod_deletion_slo_seconds}s)."
if (( deletion_elapsed_seconds > pod_deletion_slo_seconds )); then
  echo "Predecessor pod deletion exceeded the ${pod_deletion_slo_seconds}s rollout SLO." >&2
  rollout_failed 1
fi
assert_no_agent_pods

manifest_replace_attempted=true
replace_deployment_manifest || rollout_failed "$?"

target_start_requested=true
"${kubectl_cmd[@]}" -n "$namespace" scale "deployment/$deployment" --replicas="$old_replicas"
"${kubectl_cmd[@]}" -n "$namespace" rollout status "deployment/$deployment" --timeout=600s

new_pod="$(single_running_pod)"
new_identity="$(run_helper "$new_pod" identity)"
new_process_instance_id="$(jq -er '.target.processInstanceId' <<<"$new_identity")"
if [ "$new_process_instance_id" = "$old_process_instance_id" ]; then
  echo "Replacement Gateway for deployment/$deployment reused the predecessor process identity." >&2
  exit 1
fi
"${kubectl_cmd[@]}" -n "$namespace" exec "$new_pod" -c agent -- \
  curl -fsS --max-time 5 http://127.0.0.1:18791/readyz >/dev/null

completed=true
echo "Completed lifecycle-safe rollout for deployment/$deployment: $old_process_instance_id -> $new_process_instance_id"
