#!/usr/bin/env bash
set -euo pipefail

tmp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT

profile="$tmp_dir/profile"
mkdir -m 700 "$profile"
printf '%s' '{"global_environment_environment":"self-hosted","user_11111111-1111-4111-8111-111111111111_policies_policies":{"legacy":{"data":null,"enabled":false}},"user_11111111-1111-4111-8111-111111111111_policies_policiesNew":{"legacy":{"data":null,"enabled":false}},"user_11111111-1111-4111-8111-111111111111_vaultTimeoutSettings_vaultTimeout":"never","unrelated":{"nested":true}}' >"$profile/data.json"
chmod 600 "$profile/data.json"

scripts/migrate-bitwarden-cli-profile.py --data-dir "$profile" >/dev/null

jq -e '
  (has("user_11111111-1111-4111-8111-111111111111_policies_policies") | not)
  and (has("user_11111111-1111-4111-8111-111111111111_policies_policiesNew") | not)
  and .global_environment_environment == "self-hosted"
  and .["user_11111111-1111-4111-8111-111111111111_vaultTimeoutSettings_vaultTimeout"] == "never"
  and .unrelated.nested == true
' "$profile/data.json" >/dev/null

marker="$profile/.profile-migration-bitwarden-cli-2026.10.0-policy-cache"
test -f "$marker"
test "$(stat -c '%a' "$profile/data.json" 2>/dev/null || stat -f '%Lp' "$profile/data.json")" = "600"
test "$(stat -c '%a' "$marker" 2>/dev/null || stat -f '%Lp' "$marker")" = "600"

first_hash="$(sha256sum "$profile/data.json" 2>/dev/null || shasum -a 256 "$profile/data.json")"
scripts/migrate-bitwarden-cli-profile.py --data-dir "$profile" >/dev/null
second_hash="$(sha256sum "$profile/data.json" 2>/dev/null || shasum -a 256 "$profile/data.json")"
test "$first_hash" = "$second_hash"

jq '. + {"user_11111111-1111-4111-8111-111111111111_policies_policies":{"legacy-again":{"enabled":false}}}' \
  "$profile/data.json" >"$profile/data.json.next"
mv "$profile/data.json.next" "$profile/data.json"
chmod 600 "$profile/data.json"
scripts/migrate-bitwarden-cli-profile.py --data-dir "$profile" >/dev/null
jq -e 'has("user_11111111-1111-4111-8111-111111111111_policies_policies") | not' "$profile/data.json" >/dev/null

compatible="$tmp_dir/compatible"
mkdir -m 700 "$compatible"
printf '%s' '{"user_11111111-1111-4111-8111-111111111111_policies_policies":{"fixed":{"enabled":false,"revisionDate":null}}}' >"$compatible/data.json"
chmod 600 "$compatible/data.json"
scripts/migrate-bitwarden-cli-profile.py --data-dir "$compatible" >/dev/null
jq -e 'has("user_11111111-1111-4111-8111-111111111111_policies_policies")' "$compatible/data.json" >/dev/null

malformed="$tmp_dir/malformed"
mkdir -m 700 "$malformed"
printf '%s' '{invalid' >"$malformed/data.json"
if scripts/migrate-bitwarden-cli-profile.py --data-dir "$malformed" >/dev/null 2>&1; then
  echo "Expected malformed Bitwarden data to fail closed" >&2
  exit 1
fi
test ! -e "$malformed/.profile-migration-bitwarden-cli-2026.10.0-policy-cache"

missing="$tmp_dir/missing"
mkdir -m 700 "$missing"
scripts/migrate-bitwarden-cli-profile.py --data-dir "$missing" >/dev/null
test -f "$missing/.profile-migration-bitwarden-cli-2026.10.0-policy-cache"

echo "Verified atomic one-time Bitwarden CLI policy-cache migration."
