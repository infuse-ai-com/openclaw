#!/usr/bin/env python3
"""Quarantine and report unmanaged agent-authored skill proposals."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


DEFAULT_WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", "/workspace"))
DEFAULT_AGENT_ID = os.environ.get("AGENT_ID", "agent-developer")
SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    if root.is_symlink():
        digest.update(b"symlink\0.\0")
        digest.update(os.readlink(root).encode("utf-8"))
        return digest.hexdigest()
    for directory, dirnames, filenames in os.walk(root, followlinks=False):
        directory_path = Path(directory)
        dirnames.sort()
        filenames.sort()
        for name in list(dirnames):
            path = directory_path / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                digest.update(f"symlink\0{relative}\0".encode("utf-8"))
                digest.update(os.readlink(path).encode("utf-8"))
                dirnames.remove(name)
        for name in filenames:
            path = directory_path / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                digest.update(f"symlink\0{relative}\0".encode("utf-8"))
                digest.update(os.readlink(path).encode("utf-8"))
                continue
            digest.update(f"file\0{relative}\0".encode("utf-8"))
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
    return digest.hexdigest()


def drift_report(agent_id: str, workspace: Path) -> dict:
    configured = os.environ.get("OPENCLAW_AGENT_DRIFT_REPORT")
    if configured:
        executable = configured
    else:
        executable = shutil.which("openclaw-agent-local-drift-report") or str(
            Path(__file__).with_name("agent-local-drift-report.py")
        )
    result = subprocess.run(
        [executable, "--agent-id", agent_id, "--workspace", str(workspace)],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        raise RuntimeError(f"drift reporter failed: {detail}")
    return json.loads(result.stdout)


def remove_duplicate(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink()
    else:
        shutil.rmtree(path)


def proposal_key(skill_id: str) -> str:
    if SAFE_ID.fullmatch(skill_id):
        return skill_id
    digest = hashlib.sha256(skill_id.encode("utf-8", errors="surrogateescape")).hexdigest()
    return f"invalid-name-{digest[:16]}"


def quarantine(
    *,
    agent_id: str,
    workspace: Path,
    proposals_root: Path,
) -> list[dict]:
    report = drift_report(agent_id, workspace)
    skills_dir = workspace / "agents" / agent_id / "skills"
    quarantined: list[dict] = []
    for skill_id in report.get("skills", {}).get("unmanaged_directories", []):
        if not isinstance(skill_id, str) or not skill_id or skill_id in {".", ".."}:
            continue
        source = skills_dir / skill_id
        if not source.exists() and not source.is_symlink():
            continue
        digest = tree_digest(source)
        safe_skill_id = proposal_key(skill_id)
        proposal_dir = proposals_root / safe_skill_id / digest
        preserved = proposal_dir / "skill"
        if preserved.exists() or preserved.is_symlink():
            if tree_digest(preserved) != digest:
                raise RuntimeError(f"proposal digest collision for {agent_id}/{skill_id}/{digest}")
            remove_duplicate(source)
        else:
            proposal_dir.mkdir(parents=True, exist_ok=True)
            source.replace(preserved)
        metadata_path = proposal_dir / "proposal.json"
        metadata = {
            "schema": "infuse.agent-skill-proposal/v1",
            "agent_id": agent_id,
            "skill_id": safe_skill_id,
            "digest": digest,
            "detected_at": utc_now(),
            "status": "pending_review",
            "proposal_path": str(proposal_dir),
            "source_name_sha256": hashlib.sha256(
                skill_id.encode("utf-8", errors="surrogateescape")
            ).hexdigest(),
        }
        if metadata_path.exists():
            existing = json.loads(metadata_path.read_text(encoding="utf-8"))
            metadata["detected_at"] = existing.get("detected_at", metadata["detected_at"])
        atomic_json(metadata_path, metadata)
        quarantined.append(metadata)
    return quarantined


def list_proposals(proposals_root: Path, agent_id: str | None = None) -> list[dict]:
    proposals: list[dict] = []
    if not proposals_root.exists():
        return proposals
    for metadata_path in sorted(proposals_root.glob("*/*/proposal.json")):
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        proposal_dir = metadata_path.parent
        preserved = proposal_dir / "skill"
        if not preserved.exists() and not preserved.is_symlink():
            continue
        skill_id = proposal_dir.parent.name
        digest = proposal_dir.name
        if not SAFE_ID.fullmatch(skill_id) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            continue
        if tree_digest(preserved) != digest:
            continue
        detected_at = metadata.get("detected_at")
        try:
            dt.datetime.fromisoformat(str(detected_at).replace("Z", "+00:00"))
        except ValueError:
            detected_at = "unknown"
        metadata = {
            "schema": "infuse.agent-skill-proposal/v1",
            "agent_id": agent_id or metadata.get("agent_id"),
            "skill_id": skill_id,
            "digest": digest,
            "detected_at": detected_at,
            "status": "pending_review",
            "proposal_path": str(proposal_dir),
        }
        metadata["notified"] = (proposal_dir / "notified.json").exists()
        proposals.append(metadata)
    return proposals


def mark_notified(proposals_root: Path, skill_id: str, digest: str, target: str) -> dict:
    if not SAFE_ID.fullmatch(skill_id) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise RuntimeError("invalid proposal identity")
    proposal_dir = proposals_root / skill_id / digest
    metadata_path = proposal_dir / "proposal.json"
    if not metadata_path.is_file():
        raise FileNotFoundError(f"proposal not found: {skill_id}/{digest}")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if metadata.get("skill_id") != skill_id or metadata.get("digest") != digest:
        raise RuntimeError("proposal metadata does not match the requested identity")
    marker = {
        "schema": "infuse.agent-skill-proposal-notification/v1",
        "agent_id": metadata.get("agent_id"),
        "skill_id": skill_id,
        "digest": digest,
        "notified_at": utc_now(),
        "target": target,
    }
    atomic_json(proposal_dir / "notified.json", marker)
    return marker


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("scan", "mark-notified"), nargs="?", default="scan")
    parser.add_argument("--agent-id", default=DEFAULT_AGENT_ID)
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument("--proposals-root", type=Path)
    parser.add_argument("--quarantine", action="store_true")
    parser.add_argument("--skill-id")
    parser.add_argument("--digest")
    parser.add_argument("--target", default="")
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args()

    workspace = args.workspace.expanduser().resolve()
    proposals_root = (
        args.proposals_root.expanduser().resolve()
        if args.proposals_root
        else workspace / "agents" / args.agent_id / "skill-proposals"
    )
    if args.action == "mark-notified":
        if not args.skill_id or not args.digest or not args.target:
            parser.error("mark-notified requires --skill-id, --digest, and --target")
        output = mark_notified(proposals_root, args.skill_id, args.digest, args.target)
    else:
        quarantined = (
            quarantine(agent_id=args.agent_id, workspace=workspace, proposals_root=proposals_root)
            if args.quarantine
            else []
        )
        proposals = list_proposals(proposals_root, args.agent_id)
        output = {
            "schema": "infuse.agent-skill-proposal-scan/v1",
            "agent_id": args.agent_id,
            "generated_at": utc_now(),
            "proposals_root": str(proposals_root),
            "quarantined": quarantined,
            "proposals": proposals,
            "pending_notifications": [item for item in proposals if not item["notified"]],
        }
    print(json.dumps(output, indent=2 if args.pretty else None, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, RuntimeError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
