#!/usr/bin/env python3
"""Remove explicitly preserved objects from rendered Kubernetes YAML."""

from __future__ import annotations

import argparse
import re
import sys


DOCUMENT_SEPARATOR = re.compile(r"^---\s*$", re.MULTILINE)


def document_identity(document: str) -> tuple[str | None, str | None]:
    kind: str | None = None
    name: str | None = None
    in_metadata = False

    for line in document.splitlines():
        if not line or line.lstrip().startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()
        if indent == 0:
            in_metadata = stripped == "metadata:"
            if stripped.startswith("kind:"):
                kind = stripped.partition(":")[2].strip().strip("'\"")
            continue
        if in_metadata and indent == 2 and stripped.startswith("name:"):
            name = stripped.partition(":")[2].strip().strip("'\"")
            in_metadata = False

    return kind, name


def filter_documents(
    rendered: str,
    preserved: set[str],
    preserved_resources: set[str] | None = None,
    preserved_kinds: set[str] | None = None,
) -> tuple[str, set[str]]:
    documents = [part.strip() for part in DOCUMENT_SEPARATOR.split(rendered) if part.strip()]
    kept: list[str] = []
    found: set[str] = set()
    resources = preserved_resources or set()
    kinds = preserved_kinds or set()

    for document in documents:
        kind, name = document_identity(document)
        if kind == "Deployment" and name in preserved:
            found.add(name)
            continue
        resource_key = f"{kind}/{name}" if kind and name else ""
        if resource_key in resources:
            found.add(resource_key)
            continue
        if kind in kinds:
            found.add(f"kind:{kind}")
            continue
        kept.append(document)

    output = "\n---\n".join(kept)
    if output:
        output += "\n"
    return output, found


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--preserve",
        action="append",
        default=[],
        metavar="DEPLOYMENT",
        help="Deployment name to remove from the rendered stream; repeat as needed.",
    )
    parser.add_argument(
        "--preserve-resource",
        action="append",
        default=[],
        metavar="KIND/NAME",
        help="Exact Kubernetes object to remove from the rendered stream; repeat as needed.",
    )
    parser.add_argument(
        "--preserve-kind",
        action="append",
        default=[],
        metavar="KIND",
        help="Kubernetes kind to remove from the rendered stream; repeat as needed.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    preserved = set(args.preserve)
    preserved_resources = set(args.preserve_resource)
    preserved_kinds = set(args.preserve_kind)
    if any(
        value.count("/") != 1 or not all(value.split("/", 1))
        for value in preserved_resources
    ):
        print("Preserved resources must use exact KIND/NAME syntax.", file=sys.stderr)
        return 2
    rendered = sys.stdin.read()
    if any(not value or "/" in value for value in preserved_kinds):
        print("Preserved kinds must be non-empty Kubernetes kind names.", file=sys.stderr)
        return 2
    output, found = filter_documents(rendered, preserved, preserved_resources, preserved_kinds)
    expected = preserved | preserved_resources | {f"kind:{kind}" for kind in preserved_kinds}
    missing = expected - found
    if missing:
        print(
            "Refusing to continue because preserved Deployment objects were not rendered: "
            + ", ".join(sorted(missing)),
            file=sys.stderr,
        )
        return 2
    for name in sorted(found):
        resource = name.removeprefix("kind:") + "/*" if name.startswith("kind:") else (name if "/" in name else f"Deployment/{name}")
        print(f"Preserving live {resource}; omitted from stable apply.", file=sys.stderr)
    sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
