#!/usr/bin/env bash
set -euo pipefail

source_namespace="${SOURCE_NAMESPACE:-agents-swarm}"
selector="${AGENT_SELECTOR:-app.kubernetes.io/component=persistent-agent}"
notifier_deployment="${NOTIFIER_DEPLOYMENT:-agent-infra}"
notification_target="${NOTIFICATION_TARGET:?Set NOTIFICATION_TARGET to a Mattermost channel target}"
review_url="${REVIEW_URL:-https://gitlab.infuse-ai-tech.party/platform/agents/agent-skills/-/merge_requests}"

workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT

kubectl_cmd=(kubectl)
if [[ -n "${KUBE_CONTEXT:-}" ]]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

pods_json="$workdir/pods.json"
"${kubectl_cmd[@]}" -n "$source_namespace" get pods -l "$selector" -o json >"$pods_json"

mapfile -t pod_rows < <(python3 - "$pods_json" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    data = json.load(handle)
for item in data.get("items", []):
    labels = item.get("metadata", {}).get("labels", {})
    name = item.get("metadata", {}).get("name")
    agent_id = labels.get("app.kubernetes.io/name")
    if name and agent_id and item.get("status", {}).get("phase") == "Running":
        print(f"{agent_id}\t{name}")
PY
)

if [[ "${#pod_rows[@]}" -eq 0 ]]; then
  echo "No running persistent-agent pods matched ${selector}." >&2
  exit 1
fi

scan_files=()
notifier_pod=""
for row in "${pod_rows[@]}"; do
  agent_id="${row%%$'\t'*}"
  pod_name="${row#*$'\t'}"
  if [[ "$agent_id" == "$notifier_deployment" ]]; then
    notifier_pod="$pod_name"
  fi
  scan_file="$workdir/${agent_id}.json"
  "${kubectl_cmd[@]}" -n "$source_namespace" exec "pod/$pod_name" -c agent -- \
    openclaw-agent-skill-proposal scan --agent-id "$agent_id" --quarantine >"$scan_file"
  scan_files+=("$scan_file")
done

if [[ -z "$notifier_pod" ]]; then
  echo "Notifier pod for ${notifier_deployment} is not running." >&2
  exit 1
fi

pending_file="$workdir/pending.json"
message_file="$workdir/message.txt"
python3 - "$pending_file" "$message_file" "$review_url" "${scan_files[@]}" <<'PY'
import json
import sys

pending_path, message_path, review_url, *scan_paths = sys.argv[1:]
pending = []
for scan_path in scan_paths:
    with open(scan_path, "r", encoding="utf-8") as handle:
        report = json.load(handle)
    pending.extend(report.get("pending_notifications", []))
pending.sort(key=lambda item: (item.get("agent_id", ""), item.get("skill_id", ""), item.get("digest", "")))
with open(pending_path, "w", encoding="utf-8") as handle:
    json.dump(pending, handle, indent=2)
    handle.write("\n")
if not pending:
    raise SystemExit(0)
lines = [
    "@fito New agent-authored skill proposal(s) were moved out of active discovery and need review:",
]
for item in pending:
    digest = item["digest"]
    lines.append(
        f"- `{item['agent_id']}` / `{item['skill_id']}` / `{digest[:12]}` / "
        f"detected `{item['detected_at']}` / `{item['proposal_path']}`"
    )
lines.extend(
    [
        "No proposal was activated. Review should promote the reusable behavior, consolidate it into an existing skill, or retire it.",
        f"Review queue: {review_url}",
    ]
)
with open(message_path, "w", encoding="utf-8") as handle:
    handle.write("\n".join(lines) + "\n")
PY

pending_count="$(jq 'length' "$pending_file")"
if [[ "$pending_count" -eq 0 ]]; then
  echo "No unnotified skill proposals found across ${#pod_rows[@]} agent pod(s)."
  exit 0
fi

message="$(<"$message_file")"
"${kubectl_cmd[@]}" -n "$source_namespace" exec "pod/$notifier_pod" -c agent -- \
  openclaw --profile "$notifier_deployment" message send \
  --channel mattermost --target "$notification_target" --message "$message" --json >/dev/null

while IFS=$'\t' read -r agent_id skill_id digest; do
  pod_name=""
  for row in "${pod_rows[@]}"; do
    if [[ "${row%%$'\t'*}" == "$agent_id" ]]; then
      pod_name="${row#*$'\t'}"
      break
    fi
  done
  if [[ -z "$pod_name" ]]; then
    echo "Agent pod disappeared before notification marking: $agent_id" >&2
    exit 1
  fi
  "${kubectl_cmd[@]}" -n "$source_namespace" exec "pod/$pod_name" -c agent -- \
    openclaw-agent-skill-proposal mark-notified --agent-id "$agent_id" \
    --skill-id "$skill_id" --digest "$digest" --target "$notification_target" >/dev/null
done < <(jq -r '.[] | [.agent_id, .skill_id, .digest] | @tsv' "$pending_file")

echo "Posted and marked ${pending_count} agent skill proposal notification(s)."
