#!/usr/bin/env python3
"""Prepare/apply only scheduler prerequisites and dedicated usage feed permission.

No CronJob is started here. Run the reviewed helper before the first scheduler
release. Existing feed data, credentials and old collector resources are kept.
"""
import argparse
import json
import subprocess


def resources():
    result=[]
    def add(kind,name,namespace,**fields):
        result.append({'apiVersion':'rbac.authorization.k8s.io/v1' if kind in ('Role','RoleBinding') else 'v1',
                       'kind':kind,'metadata':{'name':name,'namespace':namespace,
                       'labels':{'app.kubernetes.io/managed-by':'openclaw-k8s-swarm'}},**fields})
    scheduler='openclaw-scheduler-collector'
    add('ServiceAccount',scheduler,'agents-swarm')
    add('Role',scheduler,'agents-swarm',rules=[
        {'apiGroups':[''],'resources':['pods'],'verbs':['get','list']},
        {'apiGroups':[''],'resources':['pods/exec'],'verbs':['create']}])
    add('RoleBinding',scheduler,'agents-swarm',roleRef={'apiGroup':'rbac.authorization.k8s.io','kind':'Role','name':scheduler},
        subjects=[{'kind':'ServiceAccount','name':scheduler,'namespace':'agents-swarm'}])
    for name,account in [('openclaw-scheduler-feed',scheduler),('openclaw-agent-token-usage-feed','openclaw-agent-token-usage-collector')]:
        add('Role',name+'-writer','core',rules=[{'apiGroups':[''],'resources':['configmaps'],
            'resourceNames':[name],'verbs':['get','update','patch']}])
        add('RoleBinding',name+'-writer','core',roleRef={'apiGroup':'rbac.authorization.k8s.io','kind':'Role','name':name+'-writer'},
            subjects=[{'kind':'ServiceAccount','name':account,'namespace':'agents-swarm'}])
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply',action='store_true')
    parser.add_argument('--context',default='infuseai-k8s')
    args=parser.parse_args()
    items=resources()
    if not args.apply:
        print(json.dumps({'apiVersion':'v1','kind':'List','items':items},indent=2));return
    base=['kubectl','--context',args.context]
    def run(argv,body=None):
        p=subprocess.run(base+argv,input=body,text=True,capture_output=True,timeout=45)
        if p.returncode:raise RuntimeError('Scheduler prerequisites operation failed; diagnostics withheld')
        return p.stdout
    for name in ['openclaw-scheduler-feed','openclaw-agent-token-usage-feed']:
        existing=run(['-n','core','get','configmap',name,'--ignore-not-found','-o','name'])
        if not existing.strip():
            # Create only if absent. Never apply an empty data map over a live feed.
            run(['-n','core','create','configmap',name])
    run(['apply','-f','-'],json.dumps({'apiVersion':'v1','kind':'List','items':items}))
    print(json.dumps({'applied':[i['metadata']['namespace']+'/'+i['kind']+'/'+i['metadata']['name'] for i in items],
                      'existingFeedDataPreserved':True,'cronJobsChanged':False}))


if __name__=='__main__':main()
