// Trusted installed-package metadata inspection. Never import compiled entries.
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const PLUGINS = ["mattermost", "codex", "acpx", "diagnostics-otel"];
const SOURCE = "e7d74d56a583e7596977058e7f73c6dc7c959810";
const TIME = "2026-11-14T12:48:55.522Z";

function regularFile(root, relative) {
  const parts = relative.split("/");
  assert(parts.length > 0 && parts.every((part) => part !== "" && part !== "." && part !== ".."), "Unsafe package-relative path");
  assert(!relative.includes("\\") && !path.isAbsolute(relative), "Unsafe package-relative path");
  let parent = root;
  for (const part of parts.slice(0, -1)) {
    parent = path.join(parent, part);
    assert(fs.lstatSync(parent).isDirectory(), "Package entry parent must be a real directory");
  }
  const file = path.join(root, relative);
  assert(fs.lstatSync(file).isFile(), "Package entry must be a regular file");
  assert.equal(fs.realpathSync(file), file, "Package entry escaped its real root");
  return file;
}

function compiledEntry(root, entry) {
  assert(typeof entry === "string" && entry.startsWith("./") && entry.endsWith(".js"), "Expected declared compiled JavaScript entry");
  return regularFile(root, entry.slice(2));
}

export function verifyCanaryPackageMetadata({ hostRoot, version, commit, archiveSha256 }) {
  assert.equal(version, "2026.11.3");
  assert.equal(commit, SOURCE);
  assert.match(archiveSha256, /^[a-f0-9]{64}$/);
  // The conventional global root is intentionally a symlink to the consumer.
  const root = fs.realpathSync(hostRoot);
  assert(fs.lstatSync(root).isDirectory(), "Host root must resolve to a real directory");
  const read = (relative) => JSON.parse(fs.readFileSync(regularFile(root, relative), "utf8"));
  const pkg = read("package.json");
  const build = read("dist/build-info.json");
  assert.equal(pkg.name, "openclaw");
  assert.equal(pkg.version, version);
  assert.equal(build.version, version);
  assert.equal(build.commit, commit);
  assert.equal(build.builtAt, TIME);
  for (const id of PLUGINS) {
    const relative = `dist/extensions/${id}`;
    const plugin = read(`${relative}/package.json`);
    const pluginRoot = path.join(root, relative);
    assert.equal(plugin.name, `@openclaw/${id}`);
    assert.equal(plugin.version, version);
    assert.equal(plugin.type, "module");
    assert.equal(plugin.openclaw?.build?.bundledDist, true);
    assert.equal(plugin.openclaw.build.openclawVersion, version);
    const entries = plugin.openclaw.extensions;
    assert(Array.isArray(entries) && entries.length > 0 && new Set(entries).size === entries.length, `${id} lacks distinct compiled extensions`);
    for (const entry of entries) compiledEntry(pluginRoot, entry);
    if (Object.hasOwn(plugin.openclaw, "setupEntry")) compiledEntry(pluginRoot, plugin.openclaw.setupEntry);
  }
  return { schema: 1, hostVersion: version, hostCommit: commit,
    baseCommit: "847611dcaa3bf0e2783335f961dd1fd0580e4d9f", hostPackageSha256: archiveSha256, buildTimestamp: build.builtAt };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  assert.equal(process.argv.length, 7, "Expected host-root version commit archive-sha256 manifest-output");
  const [hostRoot, version, commit, archiveSha256, output] = process.argv.slice(2);
  const manifest = verifyCanaryPackageMetadata({ hostRoot, version, commit, archiveSha256 });
  const parent = path.dirname(path.resolve(output));
  assert(fs.lstatSync(parent).isDirectory() && fs.realpathSync(parent) === parent, "Manifest output parent must be a real directory");
  fs.writeFileSync(output, `${JSON.stringify(manifest)}\n`, { flag: "wx", mode: 0o644 });
}
