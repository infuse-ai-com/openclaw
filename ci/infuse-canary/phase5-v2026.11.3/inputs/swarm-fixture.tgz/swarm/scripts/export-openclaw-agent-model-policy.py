#!/usr/bin/env python3
"""Export sanitized OpenClaw agent model policy for Backoffice."""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


THINKING_LEVELS = {"off", "minimal", "low", "medium", "high", "xhigh", "adaptive", "max", "ultra"}
REASONING_DEFAULTS = {"on", "off", "stream"}


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Export a sanitized snapshot of one agent's configured model policy.",
    )
    parser.add_argument(
        "--agent-id",
        default=os.environ.get("OPENCLAW_AGENT_ID") or os.environ.get("AGENT_ID", "kapiteky"),
        help="Agent id to export. Defaults to OPENCLAW_AGENT_ID/AGENT_ID.",
    )
    parser.add_argument(
        "--config",
        default=os.environ.get("OPENCLAW_CONFIG_PATH") or default_config_path(),
        help="OpenClaw config path to inspect.",
    )
    parser.add_argument(
        "--declared-policy",
        default=os.environ.get("OPENCLAW_AGENT_MODEL_POLICY_PATH"),
        help="Optional repo policy JSON used to compare desired settings.",
    )
    parser.add_argument(
        "--gateway-label",
        default=os.environ.get("OPENCLAW_GATEWAY_LABEL"),
        help="Human-readable gateway/source label. Defaults to '<agent-id> Gateway'.",
    )
    parser.add_argument(
        "--output",
        default="-",
        help="Output path, or '-' for stdout.",
    )
    args = parser.parse_args()

    agent_id = args.agent_id
    gateway_label = args.gateway_label or f"{agent_id} Gateway"
    config_path = Path(args.config).expanduser()
    config_status = "available"
    config: dict[str, Any] = {}

    if config_path.exists():
        with config_path.open("r", encoding="utf-8") as handle:
            config = json.load(handle)
    else:
        config_status = "missing_config"

    observed = extract_observed_policy(config, agent_id) if config else {}
    declared = extract_declared_policy(Path(args.declared_policy).expanduser(), agent_id) if args.declared_policy else {}
    mismatch_fields = compare_policy(declared, observed)
    status = config_status
    if config_status == "available":
        status = "matches_declared" if declared and not mismatch_fields else "available"
        if mismatch_fields:
            status = "drift_detected"

    snapshot = {
        "schemaVersion": 1,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "source": {
            "type": "openclaw_agent_model_policy",
            "agentId": agent_id,
            "gatewayLabel": gateway_label,
            "configPath": abbreviate_home(config_path),
            "status": status,
        },
        "modelPolicy": {
            "observed": observed,
            "declared": declared,
            "mismatchFields": mismatch_fields,
        },
    }

    output = json.dumps(snapshot, indent=2, sort_keys=True) + "\n"
    if args.output == "-":
        sys.stdout.write(output)
    else:
        output_path = Path(args.output).expanduser()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(output, encoding="utf-8")
    return 0


def default_config_path() -> str:
    profile = os.environ.get("OPENCLAW_AGENT_PROFILE")
    state_dir = os.environ.get("OPENCLAW_STATE_DIR")
    if state_dir:
        return str(Path(state_dir).expanduser() / "openclaw.json")
    if profile:
        return str(Path.home() / f".openclaw-{profile}" / "openclaw.json")
    return str(Path.home() / ".openclaw" / "openclaw.json")


def extract_observed_policy(config: dict[str, Any], agent_id: str) -> dict[str, Any]:
    agents = config.get("agents") if isinstance(config.get("agents"), dict) else {}
    defaults = agents.get("defaults") if isinstance(agents.get("defaults"), dict) else {}
    agent = {}
    entries = agents.get("entries")
    if isinstance(entries, dict) and isinstance(entries.get(agent_id), dict):
        agent = entries[agent_id]
    else:
        for candidate in agents.get("list", []) if isinstance(agents.get("list"), list) else []:
            if isinstance(candidate, dict) and candidate.get("id") == agent_id:
                agent = candidate
                break

    model = coerce_model_ref(agent.get("model", defaults.get("model")))
    thinking = agent.get("thinkingDefault", defaults.get("thinkingDefault"))
    reasoning = agent.get("reasoningDefault", defaults.get("reasoningDefault"))
    fallback = extract_fallbacks(agent.get("model", defaults.get("model")))
    models = agent.get("models") if isinstance(agent.get("models"), dict) else defaults.get("models", {})
    runtime = None
    if isinstance(models, dict) and model in models and isinstance(models[model], dict):
        runtime = (models[model].get("agentRuntime") or {}).get("id")

    return clean_policy(
        {
            "model": model,
            "fallbackModels": fallback,
            "thinkingDefault": thinking,
            "reasoningDefault": reasoning,
            "runtime": runtime,
        }
    )


def extract_declared_policy(path: Path, agent_id: str) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        policy = json.load(handle)
    defaults = policy.get("defaults") if isinstance(policy.get("defaults"), dict) else {}
    agents = policy.get("agents") if isinstance(policy.get("agents"), dict) else {}
    agent = agents.get(agent_id) if isinstance(agents.get(agent_id), dict) else {}
    merged = {
        "model": agent.get("model"),
        "fallbackModels": agent.get("fallbackModels", []),
        "thinkingDefault": agent.get("thinkingDefault", defaults.get("thinkingDefault")),
        "reasoningDefault": agent.get("reasoningDefault", defaults.get("reasoningDefault")),
        "runtime": agent.get("runtime", defaults.get("runtime")),
        "capacityFailurePolicy": agent.get("capacityFailurePolicy"),
        "roleIntent": agent.get("roleIntent"),
    }
    return clean_policy(merged)


def coerce_model_ref(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        primary = value.get("primary")
        return primary if isinstance(primary, str) else None
    return None


def extract_fallbacks(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return []
    fallback = value.get("fallbacks")
    if not isinstance(fallback, list):
        return []
    return [item for item in fallback if isinstance(item, str)]


def clean_policy(policy: dict[str, Any]) -> dict[str, Any]:
    cleaned = {key: value for key, value in policy.items() if value not in (None, [], "")}
    thinking = cleaned.get("thinkingDefault")
    if thinking is not None and thinking not in THINKING_LEVELS:
        cleaned["thinkingDefaultStatus"] = "unsupported"
    reasoning = cleaned.get("reasoningDefault")
    if reasoning is not None and reasoning not in REASONING_DEFAULTS:
        cleaned["reasoningDefaultStatus"] = "unsupported"
    return cleaned


def compare_policy(declared: dict[str, Any], observed: dict[str, Any]) -> list[str]:
    if not declared or not observed:
        return []
    keys = ("model", "fallbackModels", "thinkingDefault", "reasoningDefault", "runtime")
    return [key for key in keys if declared.get(key, [] if key == "fallbackModels" else None) != observed.get(key, [] if key == "fallbackModels" else None)]


def abbreviate_home(path: Path) -> str:
    try:
        return str(path).replace(str(Path.home()), "~", 1)
    except Exception:
        return str(path)


if __name__ == "__main__":
    raise SystemExit(main())
