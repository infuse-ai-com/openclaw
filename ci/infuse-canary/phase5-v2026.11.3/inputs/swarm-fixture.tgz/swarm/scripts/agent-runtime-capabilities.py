#!/usr/bin/env python3
"""Report container-tool capabilities without assuming a local Docker daemon."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


def probe(command: list[str], *, require_output: bool = False) -> dict[str, Any]:
    """Run a bounded capability probe and return sanitized status."""
    executable = shutil.which(command[0])
    if executable is None:
        return {"available": False, "reason": "command_not_found"}
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            check=False,
            text=True,
            timeout=8,
        )
    except subprocess.TimeoutExpired:
        return {"available": False, "reason": "probe_timeout"}
    output = completed.stdout.strip()
    if completed.returncode != 0 or (require_output and not output):
        return {
            "available": False,
            "reason": "probe_failed" if completed.returncode != 0 else "empty_output",
            "exitCode": completed.returncode,
        }
    first_line = output.splitlines()
    return {
        "available": True,
        "version": first_line[0] if first_line else "available",
    }


def probe_contact_sheet() -> dict[str, Any]:
    """Exercise the ImageMagick path that design evidence actually needs."""
    required = ("convert", "montage", "identify")
    missing = [command for command in required if shutil.which(command) is None]
    if missing:
        return {
            "available": False,
            "reason": "command_not_found",
            "missing": missing,
        }
    with tempfile.TemporaryDirectory(prefix="openclaw-image-probe-") as temp:
        root = Path(temp)
        commands = [
            ("create_white", ["convert", "-size", "8x8", "xc:white", str(root / "one.png")]),
            ("create_black", ["convert", "-size", "8x8", "xc:black", str(root / "two.png")]),
            (
                "montage",
                [
                    "montage",
                    str(root / "one.png"),
                    str(root / "two.png"),
                    "-tile",
                    "2x1",
                    "-geometry",
                    "+0+0",
                    str(root / "contact-sheet.png"),
                ],
            ),
            ("identify", ["identify", "-format", "%wx%h", str(root / "contact-sheet.png")]),
        ]
        for index, (stage, command) in enumerate(commands):
            try:
                completed = subprocess.run(
                    command,
                    capture_output=True,
                    check=False,
                    text=True,
                    timeout=8,
                )
            except subprocess.TimeoutExpired:
                return {
                    "available": False,
                    "reason": "probe_timeout",
                    "stage": stage,
                    "stageIndex": index,
                }
            if completed.returncode != 0:
                return {
                    "available": False,
                    "reason": "probe_failed",
                    "stage": stage,
                    "stageIndex": index,
                    "exitCode": completed.returncode,
                }
            if index == len(commands) - 1 and completed.stdout.strip() != "16x8":
                return {
                    "available": False,
                    "reason": "unexpected_dimensions",
                    "stage": stage,
                    "stageIndex": index,
                }
    return {"available": True, "backend": "imagemagick_montage"}


def collect() -> dict[str, Any]:
    """Collect the stable capability contract consumed by repo tooling."""
    docker_cli = probe(["docker", "--version"])
    compose = probe(["docker", "compose", "version", "--short"])
    daemon = probe(
        ["docker", "version", "--format", "{{.Server.Version}}"],
        require_output=True,
    )
    playwright_cli = probe(["playwright", "--version"])
    playwright_node = probe(
        ["node", "-p", "require('playwright/package.json').version"],
        require_output=True,
    )
    chromium = probe(["chromium", "--version"])
    pnpm = probe(["pnpm", "--version"])
    ruby = probe(["ruby", "--version"])
    convert = probe(["convert", "-version"])
    identify = probe(["identify", "-version"])
    montage = probe(["montage", "-version"])
    contact_sheet = probe_contact_sheet()
    local_build = bool(docker_cli["available"] and daemon["available"])
    browser_automation_available = bool(
        playwright_cli["available"]
        and playwright_node["available"]
        and chromium["available"]
    )
    image_composition_available = bool(contact_sheet["available"])
    return {
        "schemaVersion": 2,
        "docker": {
            "cli": docker_cli,
            "compose": compose,
            "daemon": daemon,
        },
        "containerBuild": {
            "mode": "local" if local_build else "ci_required",
            "reason": "docker_daemon_available" if local_build else "docker_daemon_unavailable",
        },
        "composeValidation": {
            "available": bool(docker_cli["available"] and compose["available"]),
            "requiresDaemon": False,
        },
        "browserAutomation": {
            "available": browser_automation_available,
            "playwrightCli": playwright_cli,
            "playwrightNode": playwright_node,
            "chromium": chromium,
            "managedBrowserCache": {
                "seedPath": os.environ.get(
                    "OPENCLAW_PLAYWRIGHT_SEED_PATH", "/opt/playwright-browsers"
                ),
                "workspacePath": os.environ.get(
                    "PLAYWRIGHT_BROWSERS_PATH",
                    "/workspace/.cache/ms-playwright",
                ),
            },
        },
        "imageComposition": {
            "available": image_composition_available,
            "convert": convert,
            "identify": identify,
            "montage": montage,
            "contactSheet": contact_sheet,
        },
        "nodeWorkspace": {
            "pnpm": pnpm,
            "ambientModulePathConfigured": bool(os.environ.get("NODE_PATH")),
        },
        "languageRuntimes": {
            "ruby": {
                **ruby,
                "executionMode": "local" if ruby["available"] else "project_environment_required",
            },
        },
        "artifactPortability": {
            "mode": "project_declared_or_bundled",
            "ambientRuntimeIsPortable": False,
            "verificationCommand": "openclaw-agent-evidence-verify",
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="Print JSON instead of a summary.")
    parser.add_argument(
        "--require-compose",
        action="store_true",
        help="Fail unless Docker CLI and the Compose plugin are available.",
    )
    parser.add_argument(
        "--require-browser-automation",
        action="store_true",
        help="Fail unless Node Playwright and Chromium are available in this runtime.",
    )
    parser.add_argument(
        "--require-image-composition",
        action="store_true",
        help="Fail unless ImageMagick convert, identify, and montage are available.",
    )
    args = parser.parse_args()
    capabilities = collect()
    compose_available = capabilities["composeValidation"]["available"]
    if args.json:
        print(json.dumps(capabilities, sort_keys=True))
    else:
        docker = capabilities["docker"]
        print(f"docker_cli={'available' if docker['cli']['available'] else 'unavailable'}")
        print(f"docker_compose={'available' if docker['compose']['available'] else 'unavailable'}")
        print(f"docker_daemon={'available' if docker['daemon']['available'] else 'unavailable'}")
        print(f"container_build={capabilities['containerBuild']['mode']}")
        print(
            "browser_automation="
            f"{'available' if capabilities['browserAutomation']['available'] else 'unavailable'}"
        )
        print(
            "image_composition="
            f"{'available' if capabilities['imageComposition']['available'] else 'unavailable'}"
        )
        print(f"artifact_portability={capabilities['artifactPortability']['mode']}")
        print(f"ruby_execution={capabilities['languageRuntimes']['ruby']['executionMode']}")
    requirements = (
        (not args.require_compose or compose_available)
        and (
            not args.require_browser_automation
            or capabilities["browserAutomation"]["available"]
        )
        and (
            not args.require_image_composition
            or capabilities["imageComposition"]["available"]
        )
    )
    return 0 if requirements else 1


if __name__ == "__main__":
    sys.exit(main())
