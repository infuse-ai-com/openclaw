#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
agent_id="${2:-${AGENT_ID:-agent-developer}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
profile="${OPENCLAW_AGENT_PROFILE:-$agent_id}"
expected_image_digest="${EXPECTED_IMAGE_DIGEST:-}"
expected_image_ref="${EXPECTED_IMAGE_REF:-}"
expected_observability="${EXPECTED_OBSERVABILITY:-auto}"

if [[ -n "$expected_image_digest" && ! "$expected_image_digest" =~ ^sha256:[0-9a-f]{64}$ ]]; then
  echo "EXPECTED_IMAGE_DIGEST must be an immutable sha256 digest" >&2
  exit 1
fi

if [[ -n "$expected_image_ref" ]]; then
  if [[ ! "$expected_image_ref" =~ @sha256:[0-9a-f]{64}$ ]]; then
    echo "EXPECTED_IMAGE_REF must be pinned to an immutable sha256 digest" >&2
    exit 1
  fi
  if [[ -n "$expected_image_digest" && "${expected_image_ref##*@}" != "$expected_image_digest" ]]; then
    echo "EXPECTED_IMAGE_REF and EXPECTED_IMAGE_DIGEST must identify the same image" >&2
    exit 1
  fi
fi

if [[ ! "$expected_observability" =~ ^(auto|true|false)$ ]]; then
  echo "EXPECTED_OBSERVABILITY must be auto, true, or false" >&2
  exit 1
fi

if [[ "$agent_id" == "agent-developer" && -z "${OPENCLAW_AGENT_PROFILE:-}" ]]; then
  profile="agent-developer"
fi

kubectl_base=(kubectl --context "$context" -n "$namespace")
selector="app.kubernetes.io/name=$agent_id"

"${kubectl_base[@]}" rollout status "deployment/$agent_id" --timeout=180s

pod=""
for _ in $(seq 1 60); do
  pod_snapshot="$("${kubectl_base[@]}" get pod -l "$selector" -o json)"
  active_count="$(jq -r '[.items[] | select(.metadata.deletionTimestamp == null)] | length' <<<"$pod_snapshot")"
  candidate="$(
    jq -r \
      --arg expected_image_digest "$expected_image_digest" \
      --arg expected_image_ref "$expected_image_ref" '
      [.items[]
        | select(.metadata.deletionTimestamp == null)
        | select(.status.phase == "Running")
        | select(
            $expected_image_digest == ""
            or .metadata.annotations["openclaw.infuse-ai.com/image-revision"] == $expected_image_digest)
        | select(any(.spec.containers[]?;
            .name == "agent"
            and ($expected_image_ref == "" or .image == $expected_image_ref)))
        | select(any(.status.containerStatuses[]?;
            .name == "agent"
            and .ready == true
            and (.imageID | type == "string" and length > 0)
            and (
              $expected_image_ref != ""
              or $expected_image_digest == ""
              or (.imageID | endswith("@" + $expected_image_digest)))))]
      | sort_by(.metadata.creationTimestamp)
      | last
      | .metadata.name // empty
    ' <<<"$pod_snapshot"
  )"
  if [[ "$active_count" == "1" && -n "$candidate" ]]; then
    pod="$candidate"
    break
  fi
  sleep 2
done

if [[ -z "$pod" ]]; then
  echo "No uniquely converged Ready pod found for $agent_id in $namespace${expected_image_ref:+ on $expected_image_ref}" >&2
  exit 1
fi

# A running container is not runtime-ready while one-time plugin/session migrations are active.
# Wait only on filesystem/process signals so no OpenClaw CLI can race the exclusive SQLite repair.
runtime_ready=false
for _ in $(seq 1 210); do
  if "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
    "runtime_dir=\"\${OPENCLAW_STATE_DIR:-\$HOME/.openclaw-$profile}/.openclaw-runtime\"; test -f \"\$runtime_dir/doctor-2026.8.1-v17-auth-sqlite\" && test -f \"\$runtime_dir/doctor-2026.9.7-agent-schema-v24-v1\" && test -f \"\$runtime_dir/doctor-2026.11.3-agent-schema-v27-v1\" && test -f \"\$runtime_dir/openclaw-2026.11.3-bundled-plugins-v1\" && ss -ltnH | awk '\$4 ~ /:18791\$/ { found=1 } END { exit(found ? 0 : 1) }'" \
    >/dev/null 2>&1; then
    runtime_ready=true
    break
  fi
  sleep 2
done
if [[ "$runtime_ready" != "true" ]]; then
  echo "OpenClaw gateway did not complete its exclusive startup migrations for $agent_id" >&2
  exit 1
fi

"${kubectl_base[@]}" get pvc "$agent_id-workspace" >/dev/null
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc 'test -w /workspace'
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc "openclaw --profile '$profile' config validate"
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "config_file=\"\${OPENCLAW_STATE_DIR:-\$HOME/.openclaw-$profile}/openclaw.json\"; jq -e '.messages.inbound.byChannel.mattermost == 1500 and .surfaces.mattermost.silentReply.group == \"allow\" and .surfaces.mattermost.replyCompletion.group == \"message-or-reaction\" and .channels.mattermost.textChunkLimit == 12000 and .channels.mattermost.actions.reactions == true and .channels.mattermost.streaming.mode == \"progress\" and .channels.mattermost.streaming.progress.label == \"Thinking… please wait\" and .channels.mattermost.streaming.progress.finalDelivery == \"separate\" and .channels.mattermost.streaming.progress.toolProgress == true and .channels.mattermost.streaming.progress.commandText == \"raw\"' \"\$config_file\" >/dev/null"
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "openclaw --profile '$profile' plugins inspect codex --runtime --json | jq -e '.plugin.status == \"loaded\" and .plugin.origin == \"bundled\" and .plugin.version == \"2026.11.3\" and (.plugin.source | contains(\"/dist/extensions/codex/\")) and (.plugin.agentHarnessIds | index(\"codex\") != null) and .install == null' >/dev/null"
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "openclaw --profile '$profile' plugins inspect mattermost --runtime --json | jq -e '.plugin.status == \"loaded\" and .plugin.origin == \"bundled\" and .plugin.version == \"2026.11.3\" and (.plugin.source | contains(\"/dist/extensions/mattermost/\")) and (.plugin.channelIds | index(\"mattermost\") != null) and .install == null' >/dev/null"
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "openclaw --profile '$profile' plugins inspect acpx --runtime --json | jq -e '.plugin.status == \"loaded\" and .plugin.origin == \"bundled\" and .plugin.version == \"2026.11.3\" and (.plugin.source | contains(\"/dist/extensions/acpx/\")) and .install == null' >/dev/null"

# Verify the installed package after the PVC plugin refresh, not only the image copy.
studio_plugin_enabled="$(
  "${kubectl_base[@]}" get "deployment/$agent_id" -o json \
    | jq -r '[.spec.template.spec.containers[] | select(.name == "agent") | .env[]? | select(.name == "OPENCLAW_REQUIRED_PLUGINS") | .value] | first // ""'
)"
case " $studio_plugin_enabled " in
  *" /opt/openclaw-plugin-archives/infuse-studio.tgz "*)
    studio_profile="$("${kubectl_base[@]}" get configmap studio-mission-authority -o json | jq -er '.data.nativeProfile // "production"')"
    "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
      "openclaw --profile '$profile' plugins inspect infuse-studio --runtime --json" \
      | python3 "$(dirname "$0")/verify-studio-runtime-inventory.py" --profile "$studio_profile"
    ;;
esac

observability_enabled="$(
  "${kubectl_base[@]}" get "deployment/$agent_id" -o json \
    | jq -r '[.spec.template.spec.containers[] | select(.name == "agent") | .env[]? | select(.name == "OPENCLAW_DIAGNOSTICS_OTEL_CANARY") | .value] | first // "false"'
)"
if [[ "$expected_observability" != "auto" && "$observability_enabled" != "$expected_observability" ]]; then
  echo "Observability enablement for $agent_id is $observability_enabled, expected $expected_observability" >&2
  exit 1
fi
if [[ "$observability_enabled" == "true" ]]; then
  expected_service_name="openclaw-$agent_id"
  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
    "openclaw --profile '$profile' plugins inspect diagnostics-otel --runtime --json | jq -e '.plugin.status == \"loaded\" and .plugin.origin == \"bundled\" and .plugin.version == \"2026.11.3\" and (.plugin.source | contains(\"/dist/extensions/diagnostics-otel/\")) and .install == null' >/dev/null"
  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
    "openclaw --profile '$profile' plugins inspect behavioral-observability --runtime --json | jq -e '.plugin.status == \"loaded\" and .plugin.origin == \"global\" and .install.source == \"path\" and ([.diagnostics[]? | select(.message | contains(\"duplicate plugin id detected\"))] | length) == 0' >/dev/null"
  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
    "config_file=\"\${OPENCLAW_STATE_DIR:-\$HOME/.openclaw-$profile}/openclaw.json\"; jq -e --arg service '$expected_service_name' '.diagnostics.enabled == true and .diagnostics.otel.enabled == true and .diagnostics.otel.endpoint == \"http://openclaw-otel-collector:4318\" and .diagnostics.otel.serviceName == \$service and .diagnostics.otel.traces == true and .diagnostics.otel.metrics == true and .diagnostics.otel.logs == false and .diagnostics.otel.captureContent == false and .plugins.entries[\"behavioral-observability\"].enabled == true' \"\$config_file\" >/dev/null"
fi
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "test -x /usr/local/bin/openclaw-agent-local-drift-report && test -x /usr/local/bin/openclaw-agent-skill-proposal && test -x /usr/local/bin/openclaw-agent-export-daily-memory"
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  "openclaw-agent-local-drift-report --agent-id '$agent_id' | jq -e '.agent_id == \"$agent_id\"' >/dev/null"
# shellcheck disable=SC2016 # Expand the Vaultwarden path inside the agent pod.
"${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
  'if test -n "${OPENCLAW_BW_DATA:-}"; then test -s "$OPENCLAW_BW_DATA/session" && bw-local-vaultwarden sync >/dev/null; fi'

bundle_path="config/agent-skill-bundles/$agent_id.json"
if [[ -f "$bundle_path" ]]; then
  expected_skills="$(jq -cr '.skills.installed | sort' "$bundle_path")"
  actual_skills="$(
    "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
      "config_file=\"\${OPENCLAW_STATE_DIR:-\$HOME/.openclaw-$profile}/openclaw.json\"; jq -cr --arg agent_id '$agent_id' '(.agents.entries[\$agent_id].skills // ([.agents.list[]? | select(.id == \$agent_id) | .skills][0]) // []) | sort' \"\$config_file\""
  )"

  if [[ "$actual_skills" != "$expected_skills" ]]; then
    echo "Skill smoke failed for $agent_id" >&2
    echo "expected: $expected_skills" >&2
    echo "actual:   $actual_skills" >&2
    exit 1
  fi

  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
    "openclaw --profile '$profile' skills list --json | openclaw-agent-runtime-skills-verify --agent-id '$agent_id'"
  "${kubectl_base[@]}" exec "$pod" -c agent -- \
    openclaw-agent-skill-manifest-parity \
      --agent-id "$agent_id" \
      --bundle "/workspace/agents/$agent_id/skills/skill-bundle-manifest.json" \
      --active "/workspace/agents/$agent_id/skills/skill-source-sync-manifest.json"
fi

if [[ "${SMOKE_CHANNELS:-true}" == "true" ]]; then
  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc \
    "openclaw --profile '$profile' plugins inspect mattermost --runtime --json | jq -e '.plugin.status == \"loaded\" and .plugin.origin == \"bundled\" and .plugin.version == \"2026.11.3\" and (.plugin.source | contains(\"/dist/extensions/mattermost/\")) and (.plugin.channelIds | index(\"mattermost\") != null)' >/dev/null"
  "${kubectl_base[@]}" exec "$pod" -c agent -- sh -lc "openclaw --profile '$profile' channels status"
fi

if "${kubectl_base[@]}" logs "$pod" -c agent \
  | sed -n '/\[gateway\] loading configuration/,$p' \
  | grep -E 'SessionCanonicalKeyMigrationRequiredError|invalid persisted session row requires repair|openChannelIngressQueue is only available for trusted plugins|route conflict at /mattermost/interactions' >/dev/null; then
  echo "Runtime migration or trusted-channel smoke failed for $agent_id" >&2
  exit 1
fi

echo "Agent smoke passed for $agent_id in $namespace"
