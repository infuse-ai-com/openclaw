#!/usr/bin/env bash
set -euo pipefail

namespace="${NAMESPACE:-agents-swarm}"
image_repository="${IMAGE_REPOSITORY:-registry.infuse-ai-tech.party/agents-swarm/openclaw-agent}"
image_revision="${IMAGE_REVISION:?IMAGE_REVISION must be an immutable sha256 digest}"
source_revision="${SOURCE_REVISION:-dev}"
storage_class="${STORAGE_CLASS:-microk8s-hostpath}"
deployments=(agent-developer agent-designer agent-infra agent-intake agent-coordinator)
pvcs=(agent-developer-workspace agent-designer-workspace agent-infra-workspace agent-coordinator-workspace agent-intake-workspace)
preserve_deployments_csv="${PRESERVE_DEPLOYMENTS-}"
runtime_only_upgrade="${RUNTIME_ONLY_UPGRADE:-false}"
reconcile_observability_collector="${RECONCILE_OBSERVABILITY_COLLECTOR:-false}"
reconcile_maintenance_cronjobs="${RECONCILE_MAINTENANCE_CRONJOBS:-false}"
maintenance_cronjobs=(
  openclaw-agent-memory-sync
  openclaw-agent-model-policy-collector
  openclaw-agent-skill-proposal-monitor
  openclaw-agent-token-usage-collector
  openclaw-scheduler-collector
)
preserved_deployments=()
if [ -n "$preserve_deployments_csv" ]; then
  IFS=',' read -r -a preserved_deployments <<<"$preserve_deployments_csv"
fi
if [[ "$runtime_only_upgrade" != "true" && "$runtime_only_upgrade" != "false" ]]; then
  echo "RUNTIME_ONLY_UPGRADE must be true or false." >&2
  exit 2
fi
if [[ "$reconcile_observability_collector" != "true" && "$reconcile_observability_collector" != "false" ]]; then
  echo "RECONCILE_OBSERVABILITY_COLLECTOR must be true or false." >&2
  exit 2
fi
if [[ "$reconcile_maintenance_cronjobs" != "true" && "$reconcile_maintenance_cronjobs" != "false" ]]; then
  echo "RECONCILE_MAINTENANCE_CRONJOBS must be true or false." >&2
  exit 2
fi
retired_deployments=(agent-release agent-operator agent-emon-lusk)
retired_networkpolicies=(agent-release-default agent-operator-default agent-emon-lusk-default)
retired_pvcs=(agent-release-workspace agent-operator-workspace)
retired_secrets=(
  agent-release-mattermost
  agent-operator-mattermost
  agent-operator-kubeconfig
)
retired_rbac_resources=(
  serviceaccount/agent-operator-readonly
  role.rbac.authorization.k8s.io/agent-operator-readonly
  rolebinding.rbac.authorization.k8s.io/agent-operator-readonly
  serviceaccount/agent-emon-lusk-readonly
  role.rbac.authorization.k8s.io/agent-emon-lusk-readonly
  rolebinding.rbac.authorization.k8s.io/agent-emon-lusk-readonly
)

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
rendered_manifest="$(mktemp)"
filtered_manifest="$(mktemp)"
shared_manifest="$(mktemp)"
cleanup() {
  rm -f "$rendered_manifest" "$filtered_manifest" "$shared_manifest"
}
trap cleanup EXIT

if [[ ! "$image_revision" =~ ^sha256:[0-9a-f]{64}$ ]]; then
  echo "IMAGE_REVISION must be an immutable sha256 digest." >&2
  exit 2
fi

kubectl_cmd=(kubectl)
if [ -n "${KUBE_CONTEXT:-}" ]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

deployment_is_preserved() {
  local candidate="$1"
  local preserved
  for preserved in "${preserved_deployments[@]}"; do
    if [ "$candidate" = "$preserved" ]; then
      return 0
    fi
  done
  return 1
}

validate_preserved_deployments() {
  local preserved
  local known
  local matched
  for preserved in "${preserved_deployments[@]}"; do
    matched=false
    for known in "${deployments[@]}"; do
      if [ "$preserved" = "$known" ]; then
        matched=true
        break
      fi
    done
    if [ "$matched" != true ]; then
      echo "Unknown preserved deployment: $preserved" >&2
      return 1
    fi
    if ! deployment_exists "$preserved"; then
      echo "Preserved deployment/$preserved must already exist before stable deploy." >&2
      return 1
    fi
  done
}

deployment_template_fingerprint() {
  local deployment="$1"
  "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" -o json \
    | python3 -c 'import hashlib, json, sys; value=json.load(sys.stdin)["spec"]["template"]; print(hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest())'
}

preserved_snapshot_names=()
preserved_snapshot_fingerprints=()
preserved_snapshot_replicas=()

capture_preserved_deployments() {
  local preserved
  for preserved in "${preserved_deployments[@]}"; do
    preserved_snapshot_names+=("$preserved")
    preserved_snapshot_fingerprints+=("$(deployment_template_fingerprint "$preserved")")
    preserved_snapshot_replicas+=("$(deployment_replicas "$preserved")")
  done
}

assert_preserved_deployments_unchanged() {
  local index
  local deployment
  local fingerprint
  local replicas
  for index in "${!preserved_snapshot_names[@]}"; do
    deployment="${preserved_snapshot_names[$index]}"
    fingerprint="$(deployment_template_fingerprint "$deployment")"
    replicas="$(deployment_replicas "$deployment")"
    if [ "$fingerprint" != "${preserved_snapshot_fingerprints[$index]}" ]; then
      echo "Stable deploy changed preserved deployment/$deployment pod template." >&2
      return 1
    fi
    if [ "$replicas" != "${preserved_snapshot_replicas[$index]}" ]; then
      echo "Stable deploy changed preserved deployment/$deployment replicas." >&2
      return 1
    fi
    echo "Verified preserved deployment/$deployment pod template and replicas are unchanged."
  done
}

dump_rollout_diagnostics() {
  local exit_code=$?
  echo "Deployment failed; collecting non-secret Kubernetes diagnostics for namespace ${namespace}." >&2
  "${kubectl_cmd[@]}" -n "$namespace" get serviceaccounts,deployments,replicasets,pods,pvc >&2 || true
  "${kubectl_cmd[@]}" -n "$namespace" get events --sort-by=.metadata.creationTimestamp >&2 || true
  for deployment in "${deployments[@]}"; do
    "${kubectl_cmd[@]}" -n "$namespace" describe "deployment/$deployment" >&2 || true
  done
  for replicaset in $("${kubectl_cmd[@]}" -n "$namespace" get replicasets -o name 2>/dev/null); do
    "${kubectl_cmd[@]}" -n "$namespace" describe "$replicaset" >&2 || true
  done
  for pod in $("${kubectl_cmd[@]}" -n "$namespace" get pods -o name 2>/dev/null); do
    "${kubectl_cmd[@]}" -n "$namespace" describe "$pod" >&2 || true
  done
  exit "$exit_code"
}
trap dump_rollout_diagnostics ERR

deployment_exists() {
  local deployment="$1"
  "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" >/dev/null 2>&1
}

deployment_replicas() {
  local deployment="$1"
  local replicas

  replicas="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" -o jsonpath='{.spec.replicas}' 2>/dev/null || true)"
  if [ -z "$replicas" ]; then
    replicas=1
  fi
  printf '%s\n' "$replicas"
}

ensure_secret_alias() {
  local old_name="$1"
  local new_name="$2"

  if "${kubectl_cmd[@]}" -n "$namespace" get secret "$new_name" >/dev/null 2>&1; then
    return 0
  fi
  if ! "${kubectl_cmd[@]}" -n "$namespace" get secret "$old_name" >/dev/null 2>&1; then
    return 0
  fi

  echo "Creating compatibility Secret alias ${new_name} from existing ${old_name}."
  "${kubectl_cmd[@]}" -n "$namespace" get secret "$old_name" -o json \
    | python3 -c '
import json
import sys

new_name = sys.argv[1]
secret = json.load(sys.stdin)
metadata = secret.setdefault("metadata", {})
metadata["name"] = new_name
metadata.pop("uid", None)
metadata.pop("resourceVersion", None)
metadata.pop("creationTimestamp", None)
metadata.pop("managedFields", None)
metadata.pop("annotations", None)
secret.pop("status", None)
print(json.dumps(secret))
' "$new_name" \
    | "${kubectl_cmd[@]}" apply -n "$namespace" -f -
}

reconcile_observability_collector_resources() {
  local manifest="$script_dir/../k8s/overlays/infuseai/otel-collector.yaml"
  local diff_exit=0

  if [ "$reconcile_observability_collector" != "true" ]; then
    echo "Preserving the OpenTelemetry Collector; reconciliation was not requested."
    return 0
  fi

  echo "Validating the reviewed OpenTelemetry Collector manifest."
  "${kubectl_cmd[@]}" -n "$namespace" apply --dry-run=server -f "$manifest" >/dev/null
  if "${kubectl_cmd[@]}" -n "$namespace" diff -f "$manifest"; then
    echo "OpenTelemetry Collector resources already match the reviewed manifest."
  else
    diff_exit=$?
    if [ "$diff_exit" -ne 1 ]; then
      echo "OpenTelemetry Collector diff failed with exit code $diff_exit." >&2
      return "$diff_exit"
    fi
    echo "Applying the reviewed OpenTelemetry Collector resources."
    "${kubectl_cmd[@]}" -n "$namespace" apply -f "$manifest"
    "${kubectl_cmd[@]}" -n "$namespace" rollout restart deployment/openclaw-otel-collector
  fi
  "${kubectl_cmd[@]}" -n "$namespace" rollout status \
    deployment/openclaw-otel-collector --timeout=300s
}

if ! "${kubectl_cmd[@]}" get namespace "$namespace" >/dev/null 2>&1; then
  can_access_target_namespace="$("${kubectl_cmd[@]}" auth can-i get configmaps -n "$namespace" 2>/dev/null || true)"
  if [ "$can_access_target_namespace" = "yes" ]; then
    echo "Cluster-scoped namespace lookup is unavailable; confirmed namespace-scoped access to $namespace."
  else
    can_create_namespace="$("${kubectl_cmd[@]}" auth can-i create namespaces 2>/dev/null || true)"
    if [ "$can_create_namespace" = "yes" ]; then
      "${kubectl_cmd[@]}" create namespace "$namespace"
    else
      echo "Namespace $namespace is absent or inaccessible and this identity cannot create namespaces." >&2
      echo "Apply k8s/overlays/infuseai/bootstrap-rbac.yaml once with a cluster-admin identity, then rerun deploy." >&2
      exit 1
    fi
  fi
fi

if [ "$runtime_only_upgrade" != true ]; then
  ensure_secret_alias agent-release-mattermost agent-developer-mattermost
  ensure_secret_alias agent-operator-mattermost agent-infra-mattermost
else
  echo "Runtime-only upgrade: preserving existing Secrets and access grants."
fi

# Once cut over, ordinary redeploys must not resurrect legacy workers.
mission_authority="$("${kubectl_cmd[@]}" -n "$namespace" get configmap studio-mission-authority --ignore-not-found -o json)"
studio_mission_cutover="${STUDIO_MISSION_CUTOVER:-false}"
case "$studio_mission_cutover" in true|false) ;; *) echo "STUDIO_MISSION_CUTOVER must be true or false." >&2; exit 2 ;; esac
if [ -n "$mission_authority" ]; then
  jq -e '.data.authority == "studio" or .data.authority == "studio-local-mac"' <<<"$mission_authority" >/dev/null || { echo "Unknown mission authority marker." >&2; exit 2; }
  studio_mission_cutover=true
fi
if [ "$studio_mission_cutover" = true ]; then
  studio_profile_selection="$(python3 "$script_dir/studio_native_profiles.py" \
    --requested "${STUDIO_RUNTIME_PROFILE:-preserve}" \
    --switch-confirmed "${STUDIO_PROFILE_SWITCH_CONFIRMED:-false}" \
    --preserve-deployments "$preserve_deployments_csv" <<<"$mission_authority")"
  STUDIO_NATIVE_PROFILE="$(jq -r '.profile' <<<"$studio_profile_selection")"
  export STUDIO_NATIVE_PROFILE
  preserve_deployments_csv="$(jq -r '.preserveDeployments | join(",")' <<<"$studio_profile_selection")"
  preserved_deployments=()
  if [ -n "$preserve_deployments_csv" ]; then
    IFS=',' read -r -a preserved_deployments <<<"$preserve_deployments_csv"
  fi
  echo "Studio runtime profile: $STUDIO_NATIVE_PROFILE"
  export OVERLAY_NAME=studio-mission-cutover
elif [ "${STUDIO_RUNTIME_PROFILE:-preserve}" != preserve ]; then
  echo "A Studio runtime profile requires the existing Studio authority cutover." >&2
  exit 2
fi
validate_preserved_deployments
capture_preserved_deployments

apply_agent_operator_kubeconfig() {
  local service_account="$1"
  local secret_name="$2"
  local context_name="$3"
  local default_namespace="$4"
  local service_account_namespace="${5:-$namespace}"
  local tmp_kubeconfig
  local server
  local certificate_authority_data
  local tls_server_name
  local token

  server="$("${kubectl_cmd[@]}" config view --raw --minify -o jsonpath='{.clusters[0].cluster.server}')"
  certificate_authority_data="$("${kubectl_cmd[@]}" config view --raw --minify -o jsonpath='{.clusters[0].cluster.certificate-authority-data}')"
  tls_server_name="$("${kubectl_cmd[@]}" config view --raw --minify -o jsonpath='{.clusters[0].cluster.tls-server-name}')"

  echo "Regenerating ${secret_name} from serviceaccount/${service_account}."
  token="$("${kubectl_cmd[@]}" -n "$service_account_namespace" create token "$service_account" --duration=8760h)"

  tmp_kubeconfig="$(mktemp)"
  KCFG_SERVER="$server" \
  KCFG_CA_DATA="$certificate_authority_data" \
  KCFG_TLS_SERVER_NAME="$tls_server_name" \
  KCFG_TOKEN="$token" \
  KCFG_NAMESPACE="$default_namespace" \
  KCFG_CONTEXT_NAME="$context_name" \
  python3 - "$tmp_kubeconfig" <<'PY'
import json
import os
import sys

cluster = {
    "server": os.environ["KCFG_SERVER"],
}
if os.environ.get("KCFG_CA_DATA"):
    cluster["certificate-authority-data"] = os.environ["KCFG_CA_DATA"]
if os.environ.get("KCFG_TLS_SERVER_NAME"):
    cluster["tls-server-name"] = os.environ["KCFG_TLS_SERVER_NAME"]

config = {
    "apiVersion": "v1",
    "kind": "Config",
    "clusters": [
        {
            "name": "infuseai",
            "cluster": cluster,
        }
    ],
    "users": [
        {
            "name": os.environ["KCFG_CONTEXT_NAME"],
            "user": {
                "token": os.environ["KCFG_TOKEN"],
            },
        }
    ],
    "contexts": [
        {
            "name": os.environ["KCFG_CONTEXT_NAME"],
            "context": {
                "cluster": "infuseai",
                "namespace": os.environ["KCFG_NAMESPACE"],
                "user": os.environ["KCFG_CONTEXT_NAME"],
            },
        }
    ],
    "current-context": os.environ["KCFG_CONTEXT_NAME"],
}

with open(sys.argv[1], "w", encoding="utf-8") as handle:
    json.dump(config, handle)
    handle.write("\n")
PY

  "${kubectl_cmd[@]}" -n "$namespace" create secret generic "$secret_name" \
    --from-file=kubeconfig="$tmp_kubeconfig" \
    --dry-run=client \
    -o yaml \
    | "${kubectl_cmd[@]}" apply -n "$namespace" -f -
  rm -f "$tmp_kubeconfig"
}

apply_emon_app_readonly_rbac() {
  local app_namespace="${EMON_APP_READONLY_NAMESPACE:-infuseai}"

  echo "Applying agent-coordinator read-only app diagnostics RBAC in ${app_namespace}."
  cat <<YAML | "${kubectl_cmd[@]}" apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: agent-coordinator-app-readonly
  namespace: ${app_namespace}
  labels:
    app.kubernetes.io/name: agent-coordinator
    app.kubernetes.io/component: persistent-agent
rules:
  - apiGroups:
      - ""
    resources:
      - pods
      - pods/log
      - events
      - services
      - configmaps
    verbs:
      - get
      - list
      - watch
  - apiGroups:
      - apps
    resources:
      - deployments
      - replicasets
    verbs:
      - get
      - list
      - watch
  - apiGroups:
      - batch
    resources:
      - jobs
    verbs:
      - get
      - list
      - watch
  - apiGroups:
      - networking.k8s.io
    resources:
      - ingresses
    verbs:
      - get
      - list
      - watch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: agent-coordinator-app-readonly
  namespace: ${app_namespace}
  labels:
    app.kubernetes.io/name: agent-coordinator
    app.kubernetes.io/component: persistent-agent
subjects:
  - kind: ServiceAccount
    name: agent-coordinator-readonly
    namespace: ${namespace}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: agent-coordinator-app-readonly
YAML
}

apply_optional_feed_configmap() {
  local app_namespace="$1"
  local configmap_name="$2"
  local app_name="$3"
  local component="$4"
  local action="create"
  local allowed

  if "${kubectl_cmd[@]}" -n "$app_namespace" get "configmap/$configmap_name" >/dev/null 2>&1; then
    action="patch"
  fi

  allowed="$("${kubectl_cmd[@]}" auth can-i "$action" "configmap/$configmap_name" -n "$app_namespace" 2>/dev/null || true)"
  if [ "$allowed" != "yes" ]; then
    allowed="$("${kubectl_cmd[@]}" auth can-i "$action" configmaps -n "$app_namespace" 2>/dev/null || true)"
  fi

  if [ "$allowed" != "yes" ]; then
    echo "Skipping configmap/${configmap_name} ${action} in ${app_namespace}; current identity is not allowed. Feed writer RBAC was still applied."
    return 0
  fi

  cat <<YAML | "${kubectl_cmd[@]}" apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  name: ${configmap_name}
  namespace: ${app_namespace}
  labels:
    app.kubernetes.io/name: ${app_name}
    app.kubernetes.io/component: ${component}
data: {}
YAML
}

apply_scheduler_feed_writer_rbac() {
  local app_namespace="${SCHEDULER_TARGET_NAMESPACE:-core}"
  local configmap_name="${SCHEDULER_CONFIGMAP_NAME:-openclaw-scheduler-feed}"

  echo "Applying scheduler feed writer RBAC for configmap/${configmap_name} in ${app_namespace}."
  cat <<YAML | "${kubectl_cmd[@]}" apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: openclaw-scheduler-feed-writer
  namespace: ${app_namespace}
  labels:
    app.kubernetes.io/name: openclaw-scheduler-collector
    app.kubernetes.io/component: agent-schedules
rules:
  - apiGroups:
      - ""
    resources:
      - configmaps
    resourceNames:
      - ${configmap_name}
    verbs:
      - get
      - update
      - patch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: openclaw-scheduler-feed-writer
  namespace: ${app_namespace}
  labels:
    app.kubernetes.io/name: openclaw-scheduler-collector
    app.kubernetes.io/component: agent-schedules
subjects:
  - kind: ServiceAccount
    name: openclaw-scheduler-collector
    namespace: ${namespace}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: openclaw-scheduler-feed-writer
YAML
  apply_optional_feed_configmap "$app_namespace" "$configmap_name" "openclaw-scheduler-collector" "agent-schedules"
}

apply_agent_token_usage_feed_writer_rbac() {
  local app_namespace="${AGENT_TOKEN_USAGE_TARGET_NAMESPACE:-core}"
  local configmap_name="${AGENT_TOKEN_USAGE_CONFIGMAP_NAME:-openclaw-agent-token-usage-feed}"

  echo "Applying agent token usage feed writer RBAC for configmap/${configmap_name} in ${app_namespace}."
  cat <<YAML | "${kubectl_cmd[@]}" apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: openclaw-agent-token-usage-feed-writer
  namespace: ${app_namespace}
  labels:
    app.kubernetes.io/name: openclaw-agent-token-usage-collector
    app.kubernetes.io/component: agent-token-usage-feed
rules:
  - apiGroups:
      - ""
    resources:
      - configmaps
    resourceNames:
      - ${configmap_name}
    verbs:
      - get
      - update
      - patch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: openclaw-agent-token-usage-feed-writer
  namespace: ${app_namespace}
  labels:
    app.kubernetes.io/name: openclaw-agent-token-usage-collector
    app.kubernetes.io/component: agent-token-usage-feed
subjects:
  - kind: ServiceAccount
    name: openclaw-agent-token-usage-collector
    namespace: ${namespace}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: openclaw-agent-token-usage-feed-writer
YAML
  apply_optional_feed_configmap "$app_namespace" "$configmap_name" "openclaw-agent-token-usage-collector" "agent-token-usage-feed"
}

retire_legacy_mission_control_resources() {
  local app_namespace="core"

  echo "Retiring all legacy Mission Control proof-of-concept runtime resources."
  for cronjob_name in openclaw-mission-control-collector openclaw-mission-control-lifecycle; do
    if "${kubectl_cmd[@]}" -n "$app_namespace" get "cronjob/$cronjob_name" >/dev/null 2>&1; then
      "${kubectl_cmd[@]}" -n "$app_namespace" patch "cronjob/$cronjob_name" \
        --type=merge -p '{"spec":{"suspend":true}}' >/dev/null
    fi
  done

  "${kubectl_cmd[@]}" -n "$app_namespace" delete job \
    -l app.kubernetes.io/name=openclaw-mission-control-collector \
    --ignore-not-found=true --wait=true --timeout=300s
  "${kubectl_cmd[@]}" -n "$app_namespace" delete job \
    -l app.kubernetes.io/name=openclaw-mission-control-lifecycle \
    --ignore-not-found=true --wait=true --timeout=300s
  "${kubectl_cmd[@]}" -n "$app_namespace" delete cronjob \
    openclaw-mission-control-collector openclaw-mission-control-lifecycle \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$namespace" delete deployment kapiteky-mission-control-relay \
    --ignore-not-found=true --wait=true --timeout=300s
  "${kubectl_cmd[@]}" -n "$namespace" delete networkpolicy kapiteky-mission-control-relay-default-deny \
    --ignore-not-found=true --wait=true --timeout=300s

  for rbac_namespace in "$namespace" "$app_namespace"; do
    "${kubectl_cmd[@]}" -n "$rbac_namespace" delete role \
      openclaw-mission-control-collector openclaw-mission-control-lifecycle \
      --ignore-not-found=true --wait=true --timeout=300s
    "${kubectl_cmd[@]}" -n "$rbac_namespace" delete rolebinding \
      openclaw-mission-control-collector openclaw-mission-control-lifecycle \
      --ignore-not-found=true --wait=true --timeout=300s
  done
  "${kubectl_cmd[@]}" -n "$app_namespace" delete serviceaccount \
    openclaw-mission-control-collector openclaw-mission-control-lifecycle \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$app_namespace" delete pvc openclaw-mission-control \
    --ignore-not-found=true --wait=true --timeout=300s
  "${kubectl_cmd[@]}" -n "$namespace" delete pvc kapiteky-mission-control-relay \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$namespace" delete deployment \
    sql-mission-session-manager \
    sql-mission-coordinator-starter \
    sql-mission-specialist-dispatcher \
    sql-mission-continuation-dispatcher \
    sql-mission-gateway-adapter \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$namespace" delete service \
    emon-mission-event-intake \
    mission-capability-agent-designer \
    mission-capability-agent-developer \
    mission-capability-agent-infra \
    mission-capability-agent-intake \
    sql-mission-capability-agent-designer \
    sql-mission-capability-agent-developer \
    sql-mission-capability-agent-infra \
    sql-mission-capability-agent-intake \
    sql-mission-gateway-adapter \
    sql-mission-session-manager \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$namespace" delete configmap \
    emon-mission-event-producer-policy \
    mission-capability-routes \
    sql-mission-production-capability-routes \
    sql-mission-production-coordinator-routes \
    sql-mission-production-routes \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$namespace" delete networkpolicy \
    agent-coordinator-mission-event-intake \
    mission-capability-responder-ingress \
    sql-mission-capability-responders \
    sql-mission-continuation-dispatcher \
    sql-mission-coordinator-ingress \
    sql-mission-coordinator-starter \
    sql-mission-gateway-adapter \
    sql-mission-session-manager \
    sql-mission-specialist-dispatcher \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$namespace" delete serviceaccount \
    mission-continuation-canary-producer \
    mission-event-azure-delivery \
    mission-event-runtime-delivery \
    --ignore-not-found=true --wait=true --timeout=300s

  "${kubectl_cmd[@]}" -n "$app_namespace" delete networkpolicy \
    sql-mission-specialist-dispatcher-artifact-registry \
    --ignore-not-found=true --wait=true --timeout=300s
}

if [ "$runtime_only_upgrade" != true ]; then
  for pvc in "${pvcs[@]}"; do
    if deployment_is_preserved "${pvc%-workspace}"; then
      echo "Skipping PVC maintenance for preserved deployment/${pvc%-workspace}."
      continue
    fi
    pvc_state="$("${kubectl_cmd[@]}" -n "$namespace" get pvc "$pvc" -o jsonpath='{.status.phase}{" "}{.spec.storageClassName}' 2>/dev/null || true)"
    if [ -z "$pvc_state" ]; then
      continue
    fi
    pvc_phase="${pvc_state%% *}"
    pvc_storage_class="${pvc_state#* }"
    if [ "$pvc_phase" = "Pending" ] && [ "$pvc_storage_class" != "$storage_class" ]; then
      echo "Deleting unbound PVC ${pvc} with stale storageClassName=${pvc_storage_class}; expected ${storage_class}."
      "${kubectl_cmd[@]}" -n "$namespace" delete pvc "$pvc"
    fi
  done
else
  echo "Runtime-only upgrade: preserving all PVCs without maintenance."
fi

filter_args=()
for deployment in "${preserved_deployments[@]}"; do
  filter_args+=(--preserve "$deployment")
done
if [ "$runtime_only_upgrade" = true ]; then
  filter_args+=(--preserve openclaw-otel-collector)
  for kind in ConfigMap CronJob NetworkPolicy PersistentVolumeClaim Role RoleBinding ClusterRole ClusterRoleBinding Service ServiceAccount; do
    if [ "$kind" = CronJob ] && [ "$reconcile_maintenance_cronjobs" = true ]; then
      continue
    fi
    filter_args+=(--preserve-kind "$kind")
  done
fi
IMAGE_REVISION="$image_revision" SOURCE_REVISION="$source_revision" INCLUDE_NAMESPACE=false "$script_dir/render-infuseai-agents.sh" \
  | "$script_dir/filter-preserved-deployments.py" "${filter_args[@]}" >"$filtered_manifest"
# A platform-only change can preserve every rendered object. kubectl rejects an
# empty input stream; keep the explicit empty List for the downstream safeguards.
if [ -s "$filtered_manifest" ]; then
  "${kubectl_cmd[@]}" create -n "$namespace" --dry-run=client -f "$filtered_manifest" -o json \
    | jq -sc '{apiVersion:"v1",kind:"List",items:.}' >"$rendered_manifest"
else
  printf '%s\n' '{"apiVersion":"v1","kind":"List","items":[]}' >"$rendered_manifest"
fi
selector_args=()
for deployment in "${deployments[@]}"; do
  selector_args+=(--agent "$deployment")
done
if [ "$runtime_only_upgrade" = true ]; then
  "$script_dir/select-agent-rollout-manifests.py" \
    --mode shared "${selector_args[@]}" \
    <"$rendered_manifest" >"$shared_manifest"
  if [ "$reconcile_maintenance_cronjobs" = true ]; then
    expected_cronjobs="$(printf '%s\n' "${maintenance_cronjobs[@]}" | jq -Rsc 'split("\n") | map(select(length > 0)) | sort')"
    jq -e --argjson expected "$expected_cronjobs" --arg image "${image_repository}@${image_revision}" '
      .kind == "List"
      and (.items | type == "array")
      and ([.items[] | select(.kind != "CronJob")] | length == 0)
      and ([.items[].metadata.name] | sort == $expected)
      and all(.items[];
        (.spec.jobTemplate.spec.template.spec.containers | length) > 0
        and all(.spec.jobTemplate.spec.template.spec.containers[]; .image == $image)
      )
    ' "$shared_manifest" >/dev/null
    "${kubectl_cmd[@]}" apply -n "$namespace" -f "$shared_manifest"
    echo "Runtime-only upgrade: reconciled five maintenance CronJobs at ${image_repository}@${image_revision}."
  else
    jq -e '
      .kind == "List"
      and (.items | type == "array")
      and (.items | length == 0)
    ' "$shared_manifest" >/dev/null
    echo "Runtime-only upgrade: verified rendered shared manifest is empty; skipping shared apply."
  fi
else
  "$script_dir/select-agent-rollout-manifests.py" \
    --mode shared "${selector_args[@]}" \
    <"$rendered_manifest" \
    | "${kubectl_cmd[@]}" apply -n "$namespace" -f -
fi
if [ "$runtime_only_upgrade" != true ]; then
  apply_emon_app_readonly_rbac
  apply_scheduler_feed_writer_rbac
  apply_agent_token_usage_feed_writer_rbac
  retire_legacy_mission_control_resources
  apply_agent_operator_kubeconfig agent-coordinator-operator agent-coordinator-kubeconfig agent-coordinator-operator "$namespace" platform-operators
  apply_agent_operator_kubeconfig agent-designer-operator agent-designer-kubeconfig agent-designer-operator "$namespace" platform-operators
  apply_agent_operator_kubeconfig agent-developer-operator agent-developer-kubeconfig agent-developer-operator "$namespace" platform-operators
  apply_agent_operator_kubeconfig agent-infra-operator agent-infra-kubeconfig agent-infra-operator "$namespace" platform-operators
  apply_agent_operator_kubeconfig agent-intake-operator agent-intake-kubeconfig agent-intake-operator "$namespace" platform-operators
else
  echo "Runtime-only upgrade: preserving shared RBAC, network, and credential resources."
fi
reconcile_observability_collector_resources
PRESERVE_DEPLOYMENTS="$preserve_deployments_csv" \
KUBE_CONTEXT="${KUBE_CONTEXT:-}" \
OPENCLAW_FLEET_ROLLOUT_STRATEGY="${OPENCLAW_FLEET_ROLLOUT_STRATEGY:-canary-wave}" \
OPENCLAW_ROLLOUT_MODE="${OPENCLAW_ROLLOUT_MODE:-bounded}" \
OPENCLAW_DEPLOY_DRAIN_SECONDS="${OPENCLAW_DEPLOY_DRAIN_SECONDS:-}" \
  "$script_dir/rollout-persistent-agent-fleet.sh" \
    "$namespace" \
    "$rendered_manifest" \
    "$image_revision" \
    "$source_revision" \
    "$script_dir/rollout-and-verify-persistent-agent.sh"
assert_preserved_deployments_unchanged
if [ "$studio_mission_cutover" = true ]; then
  if [ "$runtime_only_upgrade" != true ]; then
    NAMESPACE="$namespace" KUBE_CONTEXT="${KUBE_CONTEXT:-}" "$script_dir/retire-legacy-mission-crons.sh"
    "${kubectl_cmd[@]}" -n "$namespace" patch configmap studio-mission-authority \
      --type merge -p '{"data":{"nativeProfileState":"active"}}' >/dev/null
  else
    echo "Runtime-only upgrade: preserving the active Studio authority marker."
  fi
fi

if [ "$runtime_only_upgrade" != true ]; then
  for deployment in "${retired_deployments[@]}"; do
    if "${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" >/dev/null 2>&1; then
      echo "Deleting retired deployment/$deployment after successful renamed rollout."
      "${kubectl_cmd[@]}" -n "$namespace" delete "deployment/$deployment"
    fi
  done

  for networkpolicy in "${retired_networkpolicies[@]}"; do
    if "${kubectl_cmd[@]}" -n "$namespace" get "networkpolicy/$networkpolicy" >/dev/null 2>&1; then
      echo "Deleting retired networkpolicy/$networkpolicy after successful renamed rollout."
      "${kubectl_cmd[@]}" -n "$namespace" delete "networkpolicy/$networkpolicy"
    fi
  done

  for resource in "${retired_rbac_resources[@]}"; do
    if "${kubectl_cmd[@]}" -n "$namespace" get "$resource" >/dev/null 2>&1; then
      echo "Deleting retired $resource after successful renamed rollout."
      "${kubectl_cmd[@]}" -n "$namespace" delete "$resource"
    fi
  done

  for pvc in "${retired_pvcs[@]}"; do
    if "${kubectl_cmd[@]}" -n "$namespace" get "pvc/$pvc" >/dev/null 2>&1; then
      echo "Deleting retired pvc/$pvc after successful renamed rollout."
      "${kubectl_cmd[@]}" -n "$namespace" delete "pvc/$pvc"
    fi
  done

  for secret in "${retired_secrets[@]}"; do
    if "${kubectl_cmd[@]}" -n "$namespace" get "secret/$secret" >/dev/null 2>&1; then
      echo "Deleting retired secret/$secret after successful renamed rollout."
      "${kubectl_cmd[@]}" -n "$namespace" delete "secret/$secret"
    fi
  done
else
  echo "Runtime-only upgrade: skipping all legacy resource cleanup."
fi

"${kubectl_cmd[@]}" -n "$namespace" get deployments,pods,pvc
echo "Agents swarm deployed with image ${image_repository}@${image_revision} in namespace ${namespace}"
