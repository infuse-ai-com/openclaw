#!/usr/bin/env python3
"""Archive transcript .jsonl files that are not referenced by sessions.json."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path


def referenced_session_files(store: Path) -> set[str]:
    data = json.loads(store.read_text(encoding="utf-8"))
    records = data.values() if isinstance(data, dict) else data
    referenced: set[str] = set()
    for record in records:
        if not isinstance(record, dict):
            continue
        session_file = record.get("sessionFile")
        if isinstance(session_file, str) and session_file:
            referenced.add(Path(session_file).name)
    return referenced


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Rename unreferenced session transcript files to *.deleted.<timestamp>."
    )
    parser.add_argument(
        "sessions_dir",
        type=Path,
        help="Directory containing sessions.json and transcript .jsonl files.",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Apply archive renames. Without this flag, only prints a dry-run report.",
    )
    args = parser.parse_args()

    sessions_dir = args.sessions_dir
    store = sessions_dir / "sessions.json"
    if not store.exists():
        raise SystemExit(f"missing session store: {store}")

    referenced = referenced_session_files(store)
    candidates = [
        path
        for path in sorted(sessions_dir.glob("*.jsonl"))
        if path.name not in referenced
    ]
    timestamp = int(time.time())

    print(
        json.dumps(
            {
                "sessions_dir": str(sessions_dir),
                "referenced": len(referenced),
                "jsonl_total": len(list(sessions_dir.glob("*.jsonl"))),
                "orphaned": len(candidates),
                "apply": args.apply,
            },
            sort_keys=True,
        )
    )
    for path in candidates:
        archived = path.with_name(f"{path.name}.deleted.{timestamp}")
        print(f"{'archive' if args.apply else 'would_archive'} {path.name} -> {archived.name}")
        if args.apply:
            path.rename(archived)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
