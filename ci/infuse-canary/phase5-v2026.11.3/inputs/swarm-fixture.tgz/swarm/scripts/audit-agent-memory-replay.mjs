#!/usr/bin/env node
// Read-only transcript admission probe for the approved OpenClaw 2026.11.3 build.
// Native module names intentionally pin that implementation; update/requalify
// this probe when the runtime changes. No transcript text is emitted or saved.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
const dist='/opt/openclaw-consumer/node_modules/openclaw/dist/';
const {O:setConfig}=await import(dist+'runtime-snapshot-DIGgB9w-.mjs');
const cfg=JSON.parse(fs.readFileSync(path.join(process.env.OPENCLAW_STATE_DIR,'openclaw.json'),'utf8'));setConfig(cfg);
const {n:list}=await import(dist+'memory-core-host-engine-sessions-CIxPDQTt.mjs');
const {f:sourceFor,u:scan}=await import(dist+'session-ingestion-gnSMqrjx.mjs');
const {T:resolveLight,E:resolveRem}=await import(dist+'dreaming-D2xE6WEV.mjs');
const pluginConfig=cfg.plugins?.entries?.[cfg.plugins?.slots?.memory??'memory-core']?.config;
const phases=[resolveLight({cfg,pluginConfig}),resolveRem({cfg,pluginConfig})].filter(p=>p.enabled&&p.limit>0);
if(!phases.length)throw new Error('no enabled session-ingesting dream phase');
const lookbackDays=Math.max(...phases.map(p=>p.lookbackDays));
const cutoff=Date.now()-lookbackDays*86400000;

const agent=process.env.AGENT_ID,w=process.env.OPENCLAW_AGENT_WORKSPACE;
if (!['agent-developer','agent-designer','agent-infra','agent-coordinator','agent-intake'].includes(agent) || w!==`/workspace/agents/${agent}`) throw new Error('explicit own-agent workspace required');
const db=new DatabaseSync(path.join(process.env.OPENCLAW_STATE_DIR,'state/openclaw.sqlite'),{readOnly:true});
const wk=createHash('sha256').update(w).digest('hex');
const seenRows=db.prepare('select value_json from plugin_state_entries where plugin_id=? and namespace=? and entry_key like ?').all('memory-core','dreaming-session-ingestion-seen',wk+':%');
const seen={};for(const row of seenRows){const x=JSON.parse(row.value_json).value;seen[x.scope]=[...(seen[x.scope]??[]),...x.hashes];}
const raw=db.prepare('select entry_key,value_json from plugin_state_entries where plugin_id=? and namespace=? and entry_key like ?').all('memory-core','dreaming-session-ingestion-files',wk+':%');db.close();
const stored=new Map(raw.map(r=>{const x=JSON.parse(r.value_json);return[x.key,x.value]}));
const corpus=await list(agent,{config:cfg,includeRetainedSqlite:true});let checked=0,pending=0,lifecycle=0;const changed=[];
for(const entry of corpus){const source=sourceFor(entry,'dreaming');if(!source)continue;checked++;
const previous=stored.get(source.stateKey);const result=await scan({source,previous,seenMessages:seen,timezone:phases[0].timezone,verifyContent:false,classifyDay:day=>Date.parse(day+'T23:59:59.999Z')>=cutoff?'include':'skip'});
pending+=result.candidates.length;
lifecycle+=result.candidates.filter(c=>/^(Assistant|User): ⚙️ Agent was aborted\.$/.test(c.snippet)).length;
if(!result.fileState||result.fileState.lastContentLine!==result.fileState.lineCount)throw new Error('native scan incomplete');
if(!previous||previous.contentHash!==result.fileState.contentHash||previous.lastContentLine!==result.fileState.lastContentLine)changed.push({key:source.stateKey,previous:previous??null,current:result.fileState});}
const report={agent,eligible:checked,stored:stored.size,lookback_days:lookbackDays,pending_candidates:pending,lifecycle_only_candidates:lifecycle,substantive_pending_candidates:pending-lifecycle,changed_count:changed.length,changed};
const args=process.argv.slice(2);
if(args.length){
 if(args.length!==2||args[0]!=='--report'||!path.isAbsolute(args[1]))throw new Error('usage: audit-agent-memory-replay.mjs [--report /private/absolute/path.json]');
 fs.writeFileSync(args[1],JSON.stringify(report,null,2),{mode:0o600,flag:'wx'});
}
console.log(JSON.stringify({agent,eligible:checked,stored:stored.size,lookback_days:lookbackDays,pending_candidates:pending,lifecycle_only_candidates:lifecycle,substantive_pending_candidates:pending-lifecycle,changed_count:changed.length}));
