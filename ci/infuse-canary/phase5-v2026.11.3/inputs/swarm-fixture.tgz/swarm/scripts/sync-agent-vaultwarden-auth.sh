#!/usr/bin/env bash
set -euo pipefail

namespace="${1:-${NAMESPACE:-agents-swarm}}"
context="${KUBE_CONTEXT:-infuseai-k8s}"
agent_id="${AGENT_ID:?Set AGENT_ID, for example AGENT_ID=agent-coordinator}"
target_name="${VAULTWARDEN_AUTH_SECRET_NAME:-$agent_id-vaultwarden}"
server="${OPENCLAW_BW_SERVER:-https://vault.infuse-ai-tech.party}"
source_data_dir="${SOURCE_OPENCLAW_BW_DATA:-/Users/mac/.openclaw/secure/bitwarden-cli-infuse}"
source_bw="${BW_HELPER:-/Users/mac/.openclaw/workspace/scripts/bw-local-vaultwarden.sh}"
auth_mode="${VAULTWARDEN_AUTH_MODE:-api-key}"
auth_item_name="${VAULTWARDEN_AUTH_ITEM_NAME:-Vaultwarden / $agent_id oauth api client}"
unlock_item_name="${VAULTWARDEN_UNLOCK_ITEM_NAME:-Vaultwarden / $agent_id login}"
data_dir="${OPENCLAW_BW_DATA:-$source_data_dir}"
session_file="${BW_SESSION_FILE:-$data_dir/session}"
data_json_file="${BW_DATA_JSON_FILE:-$data_dir/data.json}"
dry_run="${DRY_RUN:-false}"
dry_run_output="${DRY_RUN_OUTPUT:-/tmp/openclaw-$agent_id-vaultwarden-auth.yaml}"

case "$agent_id" in
  agent-coordinator|agent-developer|agent-designer|agent-infra|agent-intake)
    expected_secret="$agent_id-vaultwarden"
    ;;
  *)
    echo "Vaultwarden auth sync is not approved for agent: $agent_id" >&2
    exit 2
    ;;
esac

if [[ "$target_name" != "$expected_secret" ]]; then
  echo "Vaultwarden auth target must be $expected_secret for $agent_id" >&2
  exit 2
fi

create_secret_manifest() {
  python3 - "$namespace" "$target_name" "$server" "$auth_mode" "${1:-}" "${2:-}" "${3:-}" "${4:-}" <<'PY'
import base64
import sys

namespace, name, server, mode, first, second, third, fourth = sys.argv[1:9]
values = {"OPENCLAW_BW_SERVER": server}
if mode == "api-key":
    values.update({
        "BW_CLIENTID": first,
        "BW_CLIENTSECRET": second,
        "BW_PASSWORD": third,
    })
elif mode == "session":
    values.update({
        "BW_SESSION": first,
        "BW_DATA_JSON": second,
    })
else:
    raise SystemExit(f"unsupported Vaultwarden auth mode: {mode}")

print("apiVersion: v1")
print("kind: Secret")
print("metadata:")
print(f"  name: {name}")
print(f"  namespace: {namespace}")
print("type: Opaque")
print("data:")
for key, value in values.items():
    encoded = base64.b64encode(value.encode("utf-8")).decode("ascii")
    print(f"  {key}: {encoded}")
PY
}

if [[ "$dry_run" == "true" ]]; then
  if [[ "$auth_mode" == "api-key" ]]; then
    create_secret_manifest \
      "replace-with-bitwarden-client-id" \
      "replace-with-bitwarden-client-secret" \
      "replace-with-bitwarden-unlock-password" \
      >"$dry_run_output"
  else
    create_secret_manifest \
      "replace-with-vaultwarden-session" \
      '{"placeholder":"replace-with-bitwarden-cli-state"}' \
      >"$dry_run_output"
  fi
  echo "Rendered Vaultwarden auth secret manifest with placeholder value: $dry_run_output"
  exit 0
fi

if [[ "$auth_mode" == "api-key" ]]; then
  if [[ ! -x "$source_bw" ]]; then
    echo "Vaultwarden helper not found or not executable: $source_bw" >&2
    exit 2
  fi

  export OPENCLAW_BW_SERVER="$server"
  export OPENCLAW_BW_DATA="$source_data_dir"

  item_json="$("$source_bw" get item "$auth_item_name")"
  unlock_item_json="$("$source_bw" get item "$unlock_item_name")"
  client_id="$(
    printf "%s" "$item_json" |
      jq -r '([.fields[]? | select(.name == "BW_CLIENTID" or .name == "client_id") | .value][0] // .login.username // empty)'
  )"
  client_secret="$(
    printf "%s" "$item_json" |
      jq -r '([.fields[]? | select(.name == "BW_CLIENTSECRET" or .name == "client_secret") | .value][0] // .login.password // empty)'
  )"
  unlock_password="$(
    printf "%s" "$unlock_item_json" |
      jq -r '([.fields[]? | select(.name == "BW_PASSWORD" or .name == "BW_MASTER_PASSWORD" or .name == "master_password") | .value][0] // .login.password // empty)'
  )"

  if [[ -z "$client_id" || -z "$client_secret" || -z "$unlock_password" ]]; then
    echo "Vaultwarden auth needs API client id/secret from $auth_item_name and unlock password from $unlock_item_name" >&2
    exit 2
  fi

  create_secret_manifest "$client_id" "$client_secret" "$unlock_password" "" | kubectl --context "$context" apply \
    --server-side \
    --field-manager=openclaw-agent-vaultwarden-auth-sync \
    -f -
elif [[ "$auth_mode" == "session" ]]; then
  if [[ ! -s "$session_file" ]]; then
    echo "Vaultwarden session file is missing or empty: $session_file" >&2
    exit 2
  fi
  if [[ ! -s "$data_json_file" ]]; then
    echo "Vaultwarden CLI data file is missing or empty: $data_json_file" >&2
    exit 2
  fi

  create_secret_manifest "$(cat "$session_file")" "$(cat "$data_json_file")" "" "" | kubectl --context "$context" apply \
    --server-side \
    --field-manager=openclaw-agent-vaultwarden-auth-sync \
    -f -
else
  echo "Unsupported Vaultwarden auth mode: $auth_mode" >&2
  exit 2
fi

echo "Synced Vaultwarden auth target $namespace/$target_name for $agent_id"
