#!/usr/bin/env bash
set -euo pipefail

BW_SERVER="${OPENCLAW_BW_SERVER:-https://vault.infuse-ai-tech.party}"
BW_HOST="${BW_SERVER#https://}"
BW_HOST="${BW_HOST#http://}"
BW_HOST="${BW_HOST%%/*}"
SECURE_DIR="${OPENCLAW_SECURE_DIR:-$HOME/.openclaw/secure}"
BW_DATA="${OPENCLAW_BW_DATA:-$SECURE_DIR/bitwarden-cli-infuse}"
BW_APP="${OPENCLAW_BW_APP:-$SECURE_DIR/bitwarden-cli-app}"
BW_NPM_CACHE="${OPENCLAW_BW_NPM_CACHE:-$SECURE_DIR/bitwarden-cli-npm-cache}"
BW_CLI_VERSION="${OPENCLAW_BW_CLI_VERSION:-2026.10.0}"

mkdir -p "$SECURE_DIR"
mkdir -p "$BW_DATA" "$BW_APP" "$BW_NPM_CACHE"
chmod 700 "$SECURE_DIR" "$BW_DATA" "$BW_APP" "$BW_NPM_CACHE"

if [[ "${OPENCLAW_BW_FORCE_DOCKER:-}" != "1" ]] && command -v bw >/dev/null 2>&1; then
  if curl -fsS --max-time 2 "${BW_SERVER}/api/config" >/dev/null 2>&1; then
    if [[ -f "$BW_DATA/session" && -z "${BW_SESSION:-}" ]]; then
      export BW_SESSION="$(cat "$BW_DATA/session")"
    fi
    export BITWARDENCLI_APPDATA_DIR="$BW_DATA"
    exec bw "$@"
  fi
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "Bitwarden CLI is not installed and Docker fallback is unavailable" >&2
  exit 127
fi

DOCKER_ARGS=()
if docker network inspect traefik >/dev/null 2>&1; then
  DOCKER_ARGS+=(--network traefik)
  if [[ "$BW_HOST" == "vault.oleagut.com" ]]; then
    TRAEFIK_IP="$(docker inspect traefik --format '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}')"
    DOCKER_ARGS+=(--add-host "vault.oleagut.com:${TRAEFIK_IP}")
  fi
fi

exec docker run --rm -i \
  "${DOCKER_ARGS[@]}" \
  -v "$BW_DATA:/root/.config/Bitwarden CLI" \
  -v "$BW_APP:/opt/bitwarden" \
  -v "$BW_NPM_CACHE:/root/.npm" \
  -e npm_config_loglevel=error \
  -e npm_config_update_notifier=false \
  -e NODE_NO_WARNINGS=1 \
  -e BW_CLIENTID="${BW_CLIENTID:-}" \
  -e BW_CLIENTSECRET="${BW_CLIENTSECRET:-}" \
  -e BW_PASSWORD="${BW_PASSWORD:-}" \
  -e BW_MASTER_PASSWORD="${BW_MASTER_PASSWORD:-}" \
  -e BW_SESSION="${BW_SESSION:-}" \
  -e OPENCLAW_BW_CLI_VERSION="$BW_CLI_VERSION" \
  node:22-alpine \
  sh -lc '
    set -eu
    bw_bin="/opt/bitwarden/node_modules/.bin/bw"
    lock_dir="/opt/bitwarden/.install.lock"
    own_lock=0
    installed_version() {
      node -e '\''try { process.stdout.write(require("/opt/bitwarden/node_modules/@bitwarden/cli/package.json").version) } catch (_) {}'\''
    }
    if [ ! -x "$bw_bin" ] || [ "$(installed_version)" != "$OPENCLAW_BW_CLI_VERSION" ]; then
      until mkdir "$lock_dir" 2>/dev/null; do
        if [ -x "$bw_bin" ] && [ "$(installed_version)" = "$OPENCLAW_BW_CLI_VERSION" ]; then
          break
        fi
        sleep 1
      done
      if [ ! -x "$bw_bin" ] || [ "$(installed_version)" != "$OPENCLAW_BW_CLI_VERSION" ]; then
        own_lock=1
        trap '\''rmdir "$lock_dir" 2>/dev/null || true'\'' EXIT
        npm install --prefix /opt/bitwarden "@bitwarden/cli@$OPENCLAW_BW_CLI_VERSION" >/dev/null
        [ "$(installed_version)" = "$OPENCLAW_BW_CLI_VERSION" ]
      fi
      if [ "$own_lock" = "1" ]; then
        rmdir "$lock_dir" 2>/dev/null || true
        trap - EXIT
      fi
    fi
    if [ -f "/root/.config/Bitwarden CLI/session" ] && [ -z "${BW_SESSION:-}" ]; then
      export BW_SESSION="$(cat "/root/.config/Bitwarden CLI/session")"
    fi
    exec "$bw_bin" "$@"
  ' sh "$@"
