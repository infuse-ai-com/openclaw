#!/usr/bin/env python3
"""Merge sanitized OpenClaw cron calendar snapshots into one catalog."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Merge sanitized OpenClaw cron calendar snapshot JSON files.",
    )
    parser.add_argument(
        "--input-dir",
        required=True,
        help="Directory containing per-agent OpenClaw cron calendar *.json snapshots.",
    )
    parser.add_argument(
        "--output",
        default="-",
        help="Output path, or '-' for stdout.",
    )
    args = parser.parse_args()

    input_dir = Path(args.input_dir).expanduser()
    snapshot = build_catalog(input_dir)
    output = json.dumps(snapshot, indent=2, sort_keys=True) + "\n"

    if args.output == "-":
        sys.stdout.write(output)
    else:
        output_path = Path(args.output).expanduser()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(output, encoding="utf-8")

    return 0


def build_catalog(input_dir: Path) -> dict[str, Any]:
    events: list[dict[str, Any]] = []
    sources: list[dict[str, Any]] = []

    for path in sorted(input_dir.glob("*.json")):
        data = read_json(path)
        if not isinstance(data, dict) or data.get("schemaVersion") != 1:
            continue

        raw_events = data.get("events")
        if not isinstance(raw_events, list):
            continue

        source = data.get("source") if isinstance(data.get("source"), dict) else {}
        if source.get("agentId") == "merged-openclaw-cron":
            continue

        sources.append(
            {
                "path": str(path),
                "agentId": source.get("agentId"),
                "gatewayLabel": source.get("gatewayLabel"),
                "generatedAt": data.get("generatedAt"),
                "eventCount": len(raw_events),
            },
        )
        events.extend(event for event in raw_events if isinstance(event, dict))

    return {
        "schemaVersion": 1,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "source": {
            "type": "openclaw_cron_export",
            "agentId": "merged-openclaw-cron",
            "gatewayLabel": "Merged OpenClaw cron exports",
            "jobsFile": str(input_dir),
            "stateIncluded": any(bool(source.get("eventCount")) for source in sources),
        },
        "sources": sources,
        "events": events,
    }


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


if __name__ == "__main__":
    raise SystemExit(main())
