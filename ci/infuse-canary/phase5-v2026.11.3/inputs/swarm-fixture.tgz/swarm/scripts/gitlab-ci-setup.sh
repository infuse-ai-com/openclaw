#!/usr/bin/env bash
set -euo pipefail

mkdir -p .ci-tools .gitlab-evidence /tmp/swarm-home

apt_root="$CI_PROJECT_DIR/.ci-apt"
mkdir -p "$apt_root/lists/partial" "$apt_root/cache/archives/partial"
apt_options=(
  -o "Dir::State::Lists=$apt_root/lists"
  -o "Dir::Cache=$apt_root/cache"
  -o Acquire::Retries=3
)
apt-get "${apt_options[@]}" update -qq
(
  cd "$apt_root"
  apt-get "${apt_options[@]}" download \
    'jq=1.7.1-3build1' \
    'libjq1=1.7.1-3build1' \
    'libonig5=6.9.9-1build1' \
    'python3-yaml=6.0.1-2build2'
)
for package in "$apt_root"/*.deb; do
  dpkg-deb -x "$package" "$apt_root/root"
done
cp "$apt_root/root/usr/bin/jq" .ci-tools/jq.real
cp "$apt_root/root/usr/lib/x86_64-linux-gnu/libjq.so.1" .ci-tools/
cp "$apt_root/root/usr/lib/x86_64-linux-gnu/libonig.so.5" .ci-tools/
mkdir -p .ci-tools/python
cp -R "$apt_root/root/usr/lib/python3/dist-packages/." .ci-tools/python/

cat >.ci-tools/jq <<'SH'
#!/bin/sh
tool_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
LD_LIBRARY_PATH="$tool_dir${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
  exec "$tool_dir/jq.real" "$@"
SH

cat >.ci-tools/yaml-to-json.py <<'PY'
import json
import sys

import yaml

path = sys.argv[1]
source = sys.stdin if path == "-" else open(path, encoding="utf-8")
with source:
    for document in yaml.safe_load_all(source):
        if document is not None:
            json.dump(document, sys.stdout, separators=(",", ":"))
            sys.stdout.write("\n")
PY

python3 - <<'PY'
import shutil
import time
import urllib.error
import urllib.request

url = "https://dl.k8s.io/release/v1.36.1/bin/linux/amd64/kubectl"
for attempt in range(1, 4):
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            with open(".ci-tools/kubectl.real", "wb") as output:
                shutil.copyfileobj(response, output)
        break
    except (TimeoutError, urllib.error.URLError):
        if attempt == 3:
            raise
        time.sleep(2**attempt)
PY

printf '%s  %s\n' \
  '629d3f410e09bf49b64ae7079f7f0bda1191efed311f7d37fdbab0ad5b0ec2b7' \
  '.ci-tools/kubectl.real' | sha256sum -c -
chmod 0755 .ci-tools/jq .ci-tools/jq.real .ci-tools/kubectl.real

cat >.ci-tools/kubectl <<'SH'
#!/bin/sh
if [ "$1" = create ]; then
  dry_run=false
  input=
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --dry-run=client)
        dry_run=true
        shift
        ;;
      -f|--filename)
        input="$2"
        shift 2
        ;;
      *)
        shift
        ;;
    esac
  done
  if [ "$dry_run" = true ] && [ -n "$input" ]; then
    tool_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
    PYTHONPATH="$tool_dir/python${PYTHONPATH:+:$PYTHONPATH}" \
      exec python3 "$tool_dir/yaml-to-json.py" "$input"
  fi
  echo "create is permitted only for credential-free client-side normalization" >&2
  exit 64
fi
exec "$(dirname "$0")/kubectl.real" "$@"
SH
chmod 0755 .ci-tools/kubectl
