#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

agent_id="agent-developer"
workspace="$tmp_dir/workspace"
source_dir="$tmp_dir/persona/agents/$agent_id"
target_dir="$workspace/agents/$agent_id"

mkdir -p "$source_dir" "$target_dir"

for file_name in AGENTS.md HEARTBEAT.md IDENTITY.md MEMORY.md README.md SOUL.md TOOLS.md USER.md; do
  printf '# %s for %s\nfrom per-agent source\n' "$file_name" "$agent_id" >"$source_dir/$file_name"
done

printf '# MEMORY.md for %s\nexisting runtime memory\n' "$agent_id" >"$target_dir/MEMORY.md"

AGENT_ID="$agent_id" \
OPENCLAW_WORKSPACE="$workspace" \
AGENT_PERSONA_SOURCE_DIR="$source_dir" \
AGENT_PERSONA_PRESERVE_MEMORY=true \
"$repo_root/scripts/install-agent-persona.sh" >/tmp/openclaw-agent-persona-source.out

grep -F 'from per-agent source' "$target_dir/AGENTS.md" >/dev/null
grep -F 'existing runtime memory' "$target_dir/MEMORY.md" >/dev/null
jq -e '.source_kind == "agent"' "$target_dir/persona-install-manifest.json" >/dev/null
jq -e --arg source_dir "$source_dir" '.source_dir == $source_dir' "$target_dir/persona-install-manifest.json" >/dev/null
jq -e '.files[] | select(.path == "AGENTS.md")' "$target_dir/persona-install-manifest.json" >/dev/null

report="$("$repo_root/scripts/agent-local-drift-report.py" --agent-id "$agent_id" --workspace "$workspace")"
printf '%s\n' "$report" | jq -e '.persona.source_kind == "agent"' >/dev/null
printf '%s\n' "$report" | jq -e '.persona.dirty == false' >/dev/null

printf '# AGENTS.md for %s\nlocal runtime edit\n' "$agent_id" >"$target_dir/AGENTS.md"
report="$("$repo_root/scripts/agent-local-drift-report.py" --agent-id "$agent_id" --workspace "$workspace")"
printf '%s\n' "$report" | jq -e '.persona.dirty == true' >/dev/null
printf '%s\n' "$report" | jq -e '.persona.modified == ["AGENTS.md"]' >/dev/null

echo "Agent persona source verification passed"
