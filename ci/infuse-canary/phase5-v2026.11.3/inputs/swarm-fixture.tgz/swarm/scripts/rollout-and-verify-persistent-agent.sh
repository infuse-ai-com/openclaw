#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 5 ]; then
  echo "Usage: $0 <namespace> <deployment> <rendered-manifest> <image-digest> <source-revision>" >&2
  exit 2
fi

namespace="$1"
deployment="$2"
rendered_manifest="$3"
image_revision="$4"
source_revision="$5"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

kubectl_cmd=(kubectl)
if [ -n "${KUBE_CONTEXT:-}" ]; then
  kubectl_cmd+=(--context "$KUBE_CONTEXT")
fi

deployment_replicas() {
  local replicas

  replicas="$("${kubectl_cmd[@]}" -n "$namespace" get "deployment/$deployment" -o jsonpath='{.spec.replicas}' 2>/dev/null || true)"
  if [ -z "$replicas" ]; then
    printf '1\n'
  else
    printf '%s\n' "$replicas"
  fi
}

wait_for_startup_log() {
  local expected="Installed persona files for $deployment:"
  local _attempt

  for _attempt in $(seq 1 90); do
    if "${kubectl_cmd[@]}" -n "$namespace" logs "deployment/$deployment" --tail=200 2>/dev/null \
      | grep -F "$expected" >/dev/null; then
      return 0
    fi
    sleep 2
  done

  echo "Timed out waiting for startup log from deployment/$deployment after 180s: $expected" >&2
  "${kubectl_cmd[@]}" -n "$namespace" logs "deployment/$deployment" --tail=200 >&2 || true
  return 1
}

verify_skill_manifest_parity() {
  local pod

  pod="$("${kubectl_cmd[@]}" -n "$namespace" get pod \
    -l "app.kubernetes.io/name=$deployment" \
    --field-selector=status.phase=Running \
    -o jsonpath='{.items[0].metadata.name}')"
  if [ -z "$pod" ]; then
    echo "No running pod found for skill manifest verification: deployment/$deployment" >&2
    return 1
  fi
  "${kubectl_cmd[@]}" -n "$namespace" exec "$pod" -c agent -- \
    openclaw-agent-skill-manifest-parity \
      --agent-id "$deployment" \
      --bundle "/workspace/agents/$deployment/skills/skill-bundle-manifest.json" \
      --active "/workspace/agents/$deployment/skills/skill-source-sync-manifest.json" \
    >/dev/null
}

KUBE_CONTEXT="${KUBE_CONTEXT:-}" \
OPENCLAW_ROLLOUT_MODE="${OPENCLAW_ROLLOUT_MODE:-bounded}" \
OPENCLAW_DEPLOY_DRAIN_SECONDS="${OPENCLAW_DEPLOY_DRAIN_SECONDS:-}" \
  "$script_dir/rollout-persistent-agent.sh" "$namespace" "$deployment" "$rendered_manifest"

if [ "$(deployment_replicas)" = "0" ]; then
  echo "Completed lifecycle-safe rollout for zero-replica deployment/$deployment; runtime verification is not applicable."
  exit 0
fi

wait_for_startup_log
identity_args=(
  --context "${KUBE_CONTEXT:-}"
  --namespace "$namespace"
  --expected-digest "$image_revision"
  --deployment "$deployment"
)
if [ "$source_revision" != "dev" ]; then
  identity_args+=(--expected-source-revision "$source_revision")
fi
"$script_dir/verify-agent-image-identity.py" "${identity_args[@]}" >/dev/null
verify_skill_manifest_parity
echo "Verified startup, immutable identity, and skill parity for deployment/$deployment."
