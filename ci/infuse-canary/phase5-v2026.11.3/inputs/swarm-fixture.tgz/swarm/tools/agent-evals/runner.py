#!/usr/bin/env python3
"""Deterministic, metadata-only OpenClaw agent evaluation runner."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from typing import Any


SCHEMA_VERSION = "1"
STABLE_ID = re.compile(r"^[a-z0-9][a-z0-9._-]{2,127}$")
REVISION = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{6,127}$")
SHA256 = re.compile(r"^[a-f0-9]{64}$")
FORBIDDEN_OUTPUT_KEYS = {
    "final_text",
    "prompt",
    "response",
    "stdout",
    "stderr",
    "traceparent",
}


class EvaluationError(RuntimeError):
    pass


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def exact_keys(value: dict[str, Any], allowed: set[str], code: str) -> None:
    if set(value) != allowed:
        raise EvaluationError(code)


def checked_id(value: Any, code: str) -> str:
    if not isinstance(value, str) or not STABLE_ID.fullmatch(value):
        raise EvaluationError(code)
    return value


def checked_revision(value: Any, code: str) -> str:
    if not isinstance(value, str) or not REVISION.fullmatch(value):
        raise EvaluationError(code)
    return value


def checked_string_list(value: Any, code: str, maximum: int = 32) -> list[str]:
    if (
        not isinstance(value, list)
        or len(value) > maximum
        or any(not isinstance(entry, str) or not STABLE_ID.fullmatch(entry) for entry in value)
        or len(set(value)) != len(value)
    ):
        raise EvaluationError(code)
    return list(value)


def load_suite(path: Path) -> tuple[dict[str, Any], str]:
    source = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(source, dict):
        raise EvaluationError("agent_eval_suite_invalid")
    exact_keys(source, {"schema_version", "suite_name", "cases"}, "agent_eval_suite_unknown_field")
    if source["schema_version"] != SCHEMA_VERSION:
        raise EvaluationError("agent_eval_suite_version_invalid")
    checked_id(source["suite_name"], "agent_eval_suite_name_invalid")
    cases = source["cases"]
    if not isinstance(cases, list) or not 10 <= len(cases) <= 20:
        raise EvaluationError("agent_eval_suite_case_count_invalid")
    case_ids: set[str] = set()
    for case in cases:
        if not isinstance(case, dict):
            raise EvaluationError("agent_eval_case_invalid")
        exact_keys(
            case,
            {
                "id",
                "category",
                "execution_mode",
                "trials",
                "prompt",
                "expected",
                "model_assisted_grader",
            },
            "agent_eval_case_unknown_field",
        )
        case_id = checked_id(case["id"], "agent_eval_case_id_invalid")
        if case_id in case_ids:
            raise EvaluationError("agent_eval_case_duplicate")
        case_ids.add(case_id)
        checked_id(case["category"], "agent_eval_case_category_invalid")
        if case["execution_mode"] != "read_only":
            raise EvaluationError("agent_eval_case_not_read_only")
        if case["trials"] not in {1, 3}:
            raise EvaluationError("agent_eval_case_trials_invalid")
        prompt = case["prompt"]
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= 1_200:
            raise EvaluationError("agent_eval_case_prompt_invalid")
        expected = case["expected"]
        if not isinstance(expected, dict):
            raise EvaluationError("agent_eval_expected_invalid")
        exact_keys(
            expected,
            {
                "status",
                "final_exact",
                "required_tools",
                "forbidden_tools",
                "max_tool_calls",
                "max_tool_failures",
            },
            "agent_eval_expected_unknown_field",
        )
        if expected["status"] not in {"ok", "error"}:
            raise EvaluationError("agent_eval_expected_status_invalid")
        if not isinstance(expected["final_exact"], str) or len(expected["final_exact"]) > 160:
            raise EvaluationError("agent_eval_expected_final_invalid")
        checked_string_list(expected["required_tools"], "agent_eval_required_tools_invalid")
        forbidden = checked_string_list(expected["forbidden_tools"], "agent_eval_forbidden_tools_invalid")
        if "message" not in forbidden:
            raise EvaluationError("agent_eval_external_delivery_not_forbidden")
        for bound in ("max_tool_calls", "max_tool_failures"):
            if not isinstance(expected[bound], int) or not 0 <= expected[bound] <= 64:
                raise EvaluationError("agent_eval_expected_bound_invalid")
        assisted = case["model_assisted_grader"]
        if assisted != {"enabled": False, "sole_promotion_gate": False}:
            raise EvaluationError("agent_eval_model_grader_not_disabled")
    return source, sha256(source)


def load_replay(path: Path, suite_revision: str, case_ids: set[str]) -> dict[str, Any]:
    source = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(source, dict):
        raise EvaluationError("agent_eval_replay_invalid")
    exact_keys(
        source,
        {"schema_version", "suite_revision", "candidate_revision", "trials"},
        "agent_eval_replay_unknown_field",
    )
    if source["schema_version"] != SCHEMA_VERSION or source["suite_revision"] != suite_revision:
        raise EvaluationError("agent_eval_replay_revision_mismatch")
    checked_revision(source["candidate_revision"], "agent_eval_candidate_revision_invalid")
    trials = source["trials"]
    if not isinstance(trials, list):
        raise EvaluationError("agent_eval_replay_trials_invalid")
    for trial in trials:
        if not isinstance(trial, dict):
            raise EvaluationError("agent_eval_trial_invalid")
        exact_keys(
            trial,
            {"case_id", "trial", "status", "final_text", "tool_summary"},
            "agent_eval_trial_unknown_field",
        )
        if trial["case_id"] not in case_ids:
            raise EvaluationError("agent_eval_trial_case_unknown")
        if not isinstance(trial["trial"], int) or trial["trial"] < 1:
            raise EvaluationError("agent_eval_trial_number_invalid")
        if trial["status"] not in {"ok", "error"}:
            raise EvaluationError("agent_eval_trial_status_invalid")
        if not isinstance(trial["final_text"], str) or len(trial["final_text"]) > 2_000:
            raise EvaluationError("agent_eval_trial_text_invalid")
        summary = trial["tool_summary"]
        if not isinstance(summary, dict):
            raise EvaluationError("agent_eval_tool_summary_invalid")
        exact_keys(summary, {"calls", "tools", "failures"}, "agent_eval_tool_summary_unknown_field")
        if any(not isinstance(summary[key], int) or summary[key] < 0 for key in ("calls", "failures")):
            raise EvaluationError("agent_eval_tool_summary_count_invalid")
        checked_string_list(summary["tools"], "agent_eval_tool_summary_tools_invalid")
    return source


def gateway_trial(args: argparse.Namespace, case: dict[str, Any], trial: int) -> dict[str, Any]:
    session_suffix = f"agent-eval-{case['id']}-trial-{trial}"
    command = [
        "kubectl",
        "--context",
        args.kube_context,
        "-n",
        args.namespace,
        "exec",
        f"deployment/{args.deployment}",
        "-c",
        "agent",
        "--",
        "openclaw",
        "--profile",
        args.profile,
        "agent",
        "--agent",
        args.agent_id,
        "--session-key",
        f"agent:{args.agent_id}:{session_suffix}",
        "--message",
        case["prompt"],
        "--json",
        "--timeout",
        str(args.timeout_seconds),
    ]
    try:
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=args.timeout_seconds + 30,
        )
        payload = json.loads(completed.stdout) if completed.stdout.strip() else {}
        result = payload.get("result", {}) if isinstance(payload, dict) else {}
        visible = result.get("payloads", []) if isinstance(result, dict) else []
        final_text = "\n".join(
            entry.get("text", "")
            for entry in visible
            if isinstance(entry, dict) and isinstance(entry.get("text"), str)
        ).strip()
        meta = result.get("meta", {}) if isinstance(result, dict) else {}
        summary = meta.get("toolSummary", {}) if isinstance(meta, dict) else {}
        tools = summary.get("tools", []) if isinstance(summary, dict) else []
        return {
            "case_id": case["id"],
            "trial": trial,
            "status": payload.get("status", "error") if isinstance(payload, dict) else "error",
            "final_text": final_text,
            "tool_summary": {
                "calls": summary.get("calls", 0) if isinstance(summary, dict) else 0,
                "tools": sorted(set(tools)) if isinstance(tools, list) else [],
                "failures": summary.get("failures", 0) if isinstance(summary, dict) else 0,
            },
        }
    except (subprocess.TimeoutExpired, json.JSONDecodeError):
        return {
            "case_id": case["id"],
            "trial": trial,
            "status": "error",
            "final_text": "",
            "tool_summary": {"calls": 0, "tools": [], "failures": 0},
        }


def grade(suite: dict[str, Any], replay: dict[str, Any], envelope: dict[str, str]) -> dict[str, Any]:
    trials_by_case: dict[str, list[dict[str, Any]]] = {}
    for trial in replay["trials"]:
        trials_by_case.setdefault(trial["case_id"], []).append(trial)
    cases: list[dict[str, Any]] = []
    blockers: list[str] = []
    for case in suite["cases"]:
        expected = case["expected"]
        trials = sorted(trials_by_case.get(case["id"], []), key=lambda entry: entry["trial"])
        case_blockers: list[str] = []
        expected_numbers = list(range(1, case["trials"] + 1))
        if [entry["trial"] for entry in trials] != expected_numbers:
            case_blockers.append("trial_set_incomplete")
        trial_results: list[dict[str, Any]] = []
        for trial in trials:
            tools = set(trial["tool_summary"]["tools"])
            failed: list[str] = []
            if trial["status"] != expected["status"]:
                failed.append("status_mismatch")
            if trial["final_text"] != expected["final_exact"]:
                failed.append("final_mismatch")
            if not set(expected["required_tools"]).issubset(tools):
                failed.append("required_tool_missing")
            if set(expected["forbidden_tools"]) & tools:
                failed.append("forbidden_tool_used")
            if trial["tool_summary"]["calls"] > expected["max_tool_calls"]:
                failed.append("tool_call_budget_exceeded")
            if trial["tool_summary"]["failures"] > expected["max_tool_failures"]:
                failed.append("tool_failure_budget_exceeded")
            case_blockers.extend(failed)
            trial_results.append(
                {
                    "trial": trial["trial"],
                    "passed": not failed,
                    "blockers": sorted(set(failed)),
                    "final_sha256": hashlib.sha256(trial["final_text"].encode("utf-8")).hexdigest(),
                    "final_length": len(trial["final_text"]),
                    "tool_calls": trial["tool_summary"]["calls"],
                    "tools": sorted(tools),
                    "tool_failures": trial["tool_summary"]["failures"],
                    "trace_id": None,
                }
            )
        unique_blockers = sorted(set(case_blockers))
        blockers.extend(f"{case['id']}:{entry}" for entry in unique_blockers)
        cases.append(
            {
                "case_id": case["id"],
                "category": case["category"],
                "passed": not unique_blockers,
                "blockers": unique_blockers,
                "trials": trial_results,
            }
        )
    report = {
        "schema_version": SCHEMA_VERSION,
        "suite_name": suite["suite_name"],
        "suite_revision": sha256(suite),
        "candidate_revision": replay["candidate_revision"],
        "revisions": envelope,
        "execution": {
            "mode": "gateway" if replay.get("gateway_run") else "replay",
            "read_only": True,
            "external_delivery": False,
            "model_assisted_grader": "disabled",
            "trace_propagation": "unsupported_by_gateway_cli",
            "trace_correlation_claimed": False,
        },
        "summary": {
            "case_count": len(cases),
            "trial_count": sum(len(entry["trials"]) for entry in cases),
            "passed_cases": sum(1 for entry in cases if entry["passed"]),
            "failed_cases": sum(1 for entry in cases if not entry["passed"]),
            "eligible_for_human_review": not blockers,
            "blockers": sorted(blockers),
        },
        "cases": cases,
    }
    encoded = canonical(report)
    if any(f'"{key}":' in encoded for key in FORBIDDEN_OUTPUT_KEYS):
        raise EvaluationError("agent_eval_report_forbidden_field")
    report["report_revision"] = sha256(report)
    return report


def write_private(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path.parent, 0o700)
    rendered = json.dumps(value, indent=2, sort_keys=True) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != rendered:
            raise EvaluationError("agent_eval_output_conflict")
        os.chmod(path, 0o600)
        return
    with path.open("x", encoding="utf-8") as handle:
        os.chmod(path, 0o600)
        handle.write(rendered)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser()
    result.add_argument("--suite", required=True, type=Path)
    result.add_argument("--output", required=True, type=Path)
    result.add_argument("--runner-revision", required=True)
    result.add_argument("--image-revision", required=True)
    result.add_argument("--runtime-revision", required=True)
    result.add_argument("--skill-bundle-revision", required=True)
    result.add_argument("--model-revision", required=True)
    result.add_argument("--replay", type=Path)
    result.add_argument("--allow-live-gateway", action="store_true")
    result.add_argument("--candidate-revision")
    result.add_argument("--kube-context", default="infuseai-k8s")
    result.add_argument("--namespace", default="agents-swarm")
    result.add_argument("--deployment", default="agent-developer")
    result.add_argument("--profile", default="agent-developer")
    result.add_argument("--agent-id", default="agent-developer")
    result.add_argument("--timeout-seconds", type=int, default=240)
    return result


def main() -> int:
    args = parser().parse_args()
    suite, suite_revision = load_suite(args.suite)
    case_ids = {entry["id"] for entry in suite["cases"]}
    envelope = {
        "runner_revision": checked_revision(args.runner_revision, "agent_eval_runner_revision_invalid"),
        "image_revision": checked_revision(args.image_revision, "agent_eval_image_revision_invalid"),
        "runtime_revision": checked_revision(args.runtime_revision, "agent_eval_runtime_revision_invalid"),
        "skill_bundle_revision": checked_revision(args.skill_bundle_revision, "agent_eval_skill_revision_invalid"),
        "model_revision": checked_revision(args.model_revision, "agent_eval_model_revision_invalid"),
    }
    if bool(args.replay) == bool(args.allow_live_gateway):
        raise EvaluationError("agent_eval_exactly_one_execution_mode_required")
    if args.replay:
        replay = load_replay(args.replay, suite_revision, case_ids)
    else:
        candidate_revision = checked_revision(
            args.candidate_revision, "agent_eval_candidate_revision_invalid"
        )
        if args.timeout_seconds < 30 or args.timeout_seconds > 600:
            raise EvaluationError("agent_eval_timeout_invalid")
        trials = [
            gateway_trial(args, case, trial)
            for case in suite["cases"]
            for trial in range(1, case["trials"] + 1)
        ]
        replay = {
            "schema_version": SCHEMA_VERSION,
            "suite_revision": suite_revision,
            "candidate_revision": candidate_revision,
            "trials": trials,
            "gateway_run": True,
        }
    report = grade(suite, replay, envelope)
    write_private(args.output, report)
    print(
        json.dumps(
            {
                "suite_revision": report["suite_revision"],
                "candidate_revision": report["candidate_revision"],
                "report_revision": report["report_revision"],
                **report["summary"],
                "trace_propagation": report["execution"]["trace_propagation"],
            },
            sort_keys=True,
        )
    )
    return 0 if report["summary"]["eligible_for_human_review"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
