# Contributing

Read AGENTS.md and the relevant contract, make a scoped change, run `task verify`
and review the complete diff. Use `codex/` branches for new work and conventional
commit subjects. Keep unqualified observations separate from successful proofs.
Review pins and generated bindings together. CI is deliberately manual.
