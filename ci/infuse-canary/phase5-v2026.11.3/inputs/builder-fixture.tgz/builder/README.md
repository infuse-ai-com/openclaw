# OpenClaw Canary Builder

Private Infuse AI command-line tooling for engineers and coding agents who
prepare, qualify and publish custom OpenClaw canaries. New canaries are built
from `infuse-ai-com/openclaw`; `aolea/openclaw`, v2026.10.3 and v2026.11.1 are
historical evidence only and never provide a base, branch or receipt for a new
candidate.

The canonical branch model is:

- one fresh `feat/canary/<behavior>/vYYYY.MM.DD` branch per custom behavior,
  created from the peeled upstream release tag;
- one reviewed `canary-openclaw-vYYYY.MM.DD` bundle from the same tag;
- one generated controller branch bound to the exact bundle SHA: the first is
  `build/canary-openclaw-vYYYY.MM.DD`; immutable retries use `-rN` (`N >= 2`);
- one manual default-branch dispatcher on the 32-GB Blacksmith runner.

Prerequisites: Python 3.11+, Node 22+ for policy tests, Git and Task v3. The
retained 10.3 runtime profile uses Node 24.21.0/pnpm 12.5.1; the reviewed 11.1
profile uses Node 24.22.1/pnpm 12.15.0. No Python or npm dependencies are needed
for builder verification.

```sh
task verify                       # Offline checks and regressions
task plan                         # Candidate, phases and evidence limits
python3 -B -m canary_builder doctor --docker --role native
python3 -B -m canary_builder --workspace .canary/10.3 release-verify
```

`release-verify` requires signed-in `gh` read access and curl. It verifies the
existing release ID, tag, remote digests and nine actual public downloads. It
creates no release. State and downloads stay in ignored `.canary/`.

To start the current candidate from a clean reviewed bundle checkout:

```sh
python3 -B -m canary_builder propose --source /absolute/path/to/openclaw \
  --upstream-tag v2026.11.3 --build-attempt 1 \
  --output /absolute/path/to/proposed.json
python3 -B -m canary_builder --manifest /absolute/path/to/proposed.json \
  --workspace .canary/next prepare-hosted --source /absolute/path/to/openclaw
```

Only releases with a reviewed versioned harness profile can be proposed. The
proposal verifies the source package-manager contract and clears prior
CI/run/package/publication evidence. Review the manifest and generated
controller patch before upload, then record the exact build commit and run ID.
If a hosted attempt fails, preserve its branch and run evidence, then propose a
fresh manifest with `--build-attempt 2` (or the next unused integer).
See the [runbook](docs/RUNBOOK.md) for the complete sequence.
Use the [next-canary checklist](docs/runbooks/NEXT_CANARY.md) for the complete
cross-repository, approval, publication, production and branch-closure flow.
Use the [Kapiteky Mac mini runbook](docs/runbooks/KAPITEKY_MAC_MINI_CANARY.md)
to authenticate and stage the package, freeze a matched rollback unit, migrate
the real state under exclusive maintenance, verify, or roll back an already
published canary. Mac promotion is a separate approval and evidence boundary
from swarm production.

After trusted hosted collection, Phase 5 uses a reviewed private fixture-spec
file and flat five-package directory:

```sh
python3 -B -m canary_builder --manifest manifests/v2026.11.1.json \
  --workspace .canary/phase5-plan prepare-phase5 \
  --hosted-receipt /private/path/verified-receipt.json \
  --candidate-manifest /private/path/candidate-manifest.json \
  --package-dir /private/path/packages \
  --fixture-specs /private/path/fixture-specs.json

python3 -B -m canary_builder --manifest manifests/v2026.11.1.json \
  --workspace .canary/phase5-collection collect-phase5 \
  --plan-dir .canary/phase5-plan/prepare-phase5 \
  --evidence-dir /private/path/phase5-evidence
```

These commands prepare and authenticate adapter custody only. The first does
not execute candidate code; neither command publishes or deploys anything.
The external adapter supplies the authenticated plan, package directory,
candidate manifest and selected lane through reserved `PHASE5_*` environment
variables. It re-authenticates the closed plan after the fixture command and
owned cleanup before emitting a receipt.

V1 includes strict manifest/harness preflight, manual hosted recipe generation,
completed-run collection/authentication, exact package verification, stage
resume with byte custody, read-only resource admission, draft-by-ID publication
and portable private handoff packaging/hydration. Publication requires an
explicit execution flag and exact tag confirmation. Its retry journal prevents
duplicate drafts after uncertain responses.

The v2026.11.1 Phase 5 profile now prepares exact package/fixture/controller
custody for seven externally owned disposable lanes and collects their closed
evidence without running candidate code inside the builder. `collect-phase5`
emits `LINUX-QUALIFICATION.json` only when every required lane and cleanup gate
passes; failed and unverified lanes remain explicit collection evidence.
Native Studio/Mattermost and swarm image controllers still execute in their
owning fixtures. The builder does not automate patch porting or turn imported
runtime observations into current proof. See [adapter boundaries](docs/ARCHITECTURE.md).

[OpenClaw fork](https://github.com/infuse-ai-com/openclaw) owns all new custom source/CI branches;
[openclaw-k8s-swarm](https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-k8s-swarm) owns production image delivery and deployment.
The builder has no deployment command. GitLab runs offline verification for
merge requests and the protected default branch; it does not run canary
qualification, publication or deployment.

[Repo map](docs/REPO_MAP.md), [verification](docs/VERIFICATION_GATES.md),
[decisions](docs/DECISIONS.md), [bootstrap brief](docs/PROJECT_BRIEF.md).

Project documentation is in [docs/](docs/README.md), including the
[roadmap](docs/ROADMAP.md), [lessons](docs/LESSONS.md) and [reference](docs/WIKI.md).
