"""Trusted disposable-runner owner. Candidate executables run only inside Docker."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import os
import pathlib
import re
import secrets
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tarfile
import tempfile
import threading

HARNESS = pathlib.Path(__file__).resolve().parent
binding = json.loads((HARNESS / "binding.json").read_text())
assert binding["schemaVersion"] == 3 and binding["harnessProfile"] == "v2026.11.3"
assert binding["repository"] == "infuse-ai-com/openclaw"
assert binding["runnerLabel"] == "blacksmith-16vcpu-ubuntu-2404"
assert binding["compilerGraphs"] == 36
HOSTED_CPUS = binding["hostedCpus"]
HOSTED_MEMORY_GIB = binding["hostedMemoryGiB"]
INNER_TIMEOUT_MINUTES = 690
HEARTBEAT_SECONDS = 30
assert HOSTED_CPUS == 16 and HOSTED_MEMORY_GIB == 47
spec = importlib.util.spec_from_file_location("trusted_identity", HARNESS / "identity.py")
identity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(identity)


def command(*args, capture=False, check=True):
    result = subprocess.run(list(args), check=check, stdout=subprocess.PIPE if capture else None, text=capture)
    return result.stdout.strip() if capture else result.returncode


def firewall(action, *args):
    command("sudo", "iptables", "-w", action, *args)


def sanitize(source, destination):
    """The stopped candidate cannot make an artifact action follow a host symlink."""
    for directory in [source.parent.parent, source.parent, source]:
        assert stat.S_ISDIR(directory.lstat().st_mode), "artifact root/parent is not a real directory"
    destination.mkdir()
    total = 0
    entries = []
    allowed = {".tgz", ".json", ".log", ".md", ".txt", ".tsv"}
    for directory, subdirs, files in os.walk(source, followlinks=False):
        for name in subdirs:
            assert stat.S_ISDIR((pathlib.Path(directory) / name).lstat().st_mode), "artifact directory symlink"
        for name in files:
            path = pathlib.Path(directory) / name
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "artifact is not a regular single-link file"
            assert path.suffix in allowed, "unexpected artifact extension"
            total += info.st_size
            assert total <= 336 * 1024**2, "candidate artifacts exceed 336 MiB ceiling; 64 MiB reserved for trusted failure/output evidence"
            relative = path.relative_to(source)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "rb", opener=lambda p, flags: os.open(p, flags | os.O_NOFOLLOW)) as stream:
                with target.open("xb") as output:
                    digest = hashlib.sha256()
                    while data := stream.read(1024 * 1024):
                        digest.update(data)
                        output.write(data)
            entries.append({"path": str(relative), "bytes": info.st_size, "sha256": digest.hexdigest()})
    (destination / "artifact-index.json").write_text(json.dumps({"totalBytes": total, "files": sorted(entries, key=lambda item: item["path"])}, indent=2) + "\n")


def retain_failure(output, task, error):
    """Retain only trusted-owned bytes when source/collector/package guards refuse."""
    record = {"binding": binding, "passed": False, "errorType": type(error).__name__, "error": str(error)[:4096]}
    (output / "trusted-runner-failure.json").write_text(json.dumps(record, indent=2) + "\n")
    log = task / "docker-output.log" if task is not None else None
    if log is not None and log.exists():
        # Failed collectors never follow candidate paths, and retention stays bounded.
        with log.open("rb") as stream:
            stream.seek(max(0, log.stat().st_size - 4 * 1024**2))
            data = stream.read()
        used = sum(path.stat().st_size for path in output.rglob("*") if path.is_file())
        remaining = max(0, 400 * 1024**2 - used - 32768)
        if remaining:
            (output / "trusted-docker-failure-tail.log").write_bytes(data[-remaining:])


def atomic_json(path, value):
    """Publish one complete trusted binding; never expose a partially written index."""
    data = (json.dumps(value, indent=2) + "\n").encode()
    assert len(data) <= 1024**2, "trusted metrics index exceeds 1 MiB ceiling"
    fd, temporary = tempfile.mkstemp(prefix=".metrics-index-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def trusted_start_receipt(output):
    atomic_json(output / "trusted-runner-start.json", {
        "schemaVersion": 1,
        "binding": binding,
        "bootstrapCommit": os.environ["INFUSE_CANARY_DISPATCH_SHA"],
        "dispatcherCommit": os.environ["GITHUB_SHA"],
        "runId": int(os.environ["GITHUB_RUN_ID"]),
        "runAttempt": int(os.environ["GITHUB_RUN_ATTEMPT"]),
        "runnerName": os.environ.get("RUNNER_NAME", "unknown"),
        "runnerLabels": [binding["runnerLabel"]],
        "candidateResources": {"cpus": HOSTED_CPUS, "memoryGiB": HOSTED_MEMORY_GIB, "swapGiB": 0},
        "innerTimeoutMinutes": INNER_TIMEOUT_MINUTES,
        "outerTimeoutMinutes": 720,
        "startedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "status": "running",
        "passed": False,
    })


def cgroup_heartbeat(container, output, stop):
    """Persist host-owned Docker/cgroup liveness without trusting candidate paths."""
    script = """import json,pathlib
p=pathlib.Path('/sys/fs/cgroup')
events={k:int(v) for k,v in (line.split() for line in (p/'memory.events').read_text().splitlines())}
print(json.dumps({'memoryCurrentBytes':int((p/'memory.current').read_text()),'memoryPeakBytes':int((p/'memory.peak').read_text()),'memoryMaxBytes':int((p/'memory.max').read_text()),'swapMaxBytes':int((p/'memory.swap.max').read_text()),'memoryEvents':events},separators=(',',':')))
"""
    path = output / "trusted-host-heartbeats.jsonl"
    sequence = 0
    while not stop.is_set():
        record = {"schemaVersion": 1, "sequence": sequence,
                  "observedAt": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        try:
            value = subprocess.run(
                ["docker", "exec", container, "/usr/bin/python3", "-I", "-c", script],
                check=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=15,
            )
            counters = json.loads(value.stdout)
            assert counters["memoryMaxBytes"] == HOSTED_MEMORY_GIB * 1024**3
            assert counters["swapMaxBytes"] == 0
            record.update(status="running", cgroup=counters)
        except (AssertionError, json.JSONDecodeError, OSError, subprocess.SubprocessError, KeyError, ValueError) as error:
            record.update(status="unavailable", errorType=type(error).__name__, error=str(error)[:512])
        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, separators=(",", ":")) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        sequence += 1
        stop.wait(HEARTBEAT_SECONDS)


def expire_container(container, expired):
    expired.set()
    command("docker", "kill", "--signal", "TERM", container, check=False)
    try:
        subprocess.run(["docker", "wait", container], check=False, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=30)
    except subprocess.TimeoutExpired:
        command("docker", "kill", "--signal", "KILL", container, check=False)


def index_tsgo_metrics(output, candidate, before, after):
    """Bind stopped compiler-reported JSON bytes to independently verified source identities."""
    directory = candidate / "tsgo-metrics"
    entries = []
    if directory.exists():
        assert stat.S_ISDIR(directory.lstat().st_mode), "metrics root is not a real directory"
        for path in sorted(directory.iterdir()):
            assert re.fullmatch(r"tsgo-[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\.json", path.name), "unexpected metrics filename"
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "metrics entry is not a regular single-link file"
            digest = hashlib.sha256()
            with path.open("rb") as stream:
                while data := stream.read(1024 * 1024):
                    digest.update(data)
            entry = {"path": str(path.relative_to(output)), "bytes": info.st_size, "sha256": digest.hexdigest(), "valid": False}
            try:
                assert info.st_size <= 2 * 1024**2, "metrics metadata exceeds 2 MiB parse ceiling"
                metrics = json.loads(path.read_bytes())
                assert metrics["schemaVersion"] == 1
                assert metrics["revision"] == binding["candidateCommit"]
                assert metrics["trackedDirty"] is False
                assert metrics["lockfileSha256"] == binding["pnpmLockSha256"]
                assert metrics["nodeVersion"] == "v" + binding["nodeVersion"]
                assert metrics["platform"] == "linux" and metrics["arch"] == "x64"
                policy = metrics["resources"]["policy"]
                assert policy["GOGC"] == "30" and policy["GOMEMLIMIT"] == "3GiB" and policy["GOMAXPROCS"] == str(HOSTED_CPUS)
                command = metrics["command"]
                outcome = metrics["outcome"]
                resources = metrics["resources"]
                assert isinstance(command["bin"], str) and isinstance(command["cwd"], str)
                assert isinstance(command["args"], list) and all(isinstance(arg, str) for arg in command["args"])
                outcome_summary = {}
                for key in ["exitCode", "exitSignal", "forwardedSignal", "errorCode"]:
                    value = outcome[key]
                    if key == "exitCode":
                        assert value is None or type(value) is int and 0 <= value <= 255
                    else:
                        assert value is None or isinstance(value, str) and len(value) <= 128
                    outcome_summary[key] = value
                resource_summary = {}
                for key in ["source", "scope", "accuracy", "unavailableReason", "peakRssUnavailableReason"]:
                    value = resources[key]
                    assert value is None or isinstance(value, str) and len(value) <= 128
                    resource_summary[key] = value
                for key in ["intervalMs", "samples", "cpuMs", "peakRssBytes"]:
                    value = resources[key]
                    assert value is None or type(value) in (int, float) and math.isfinite(value) and value >= 0
                    resource_summary[key] = value
                assert type(metrics["wallMs"]) in (int, float) and math.isfinite(metrics["wallMs"]) and metrics["wallMs"] >= 0
                resource_summary["policy"] = {"GOGC": "30", "GOMEMLIMIT": "3GiB", "GOMAXPROCS": str(HOSTED_CPUS)}
                entry.update({"valid": True, "command": {"bin": command["bin"][:512], "cwd": command["cwd"][:512],
                              "argumentCount": len(command["args"]), "argsSha256": hashlib.sha256(json.dumps(command["args"], separators=(",", ":")).encode()).hexdigest()},
                              "outcome": outcome_summary, "wallMs": metrics["wallMs"], "resources": resource_summary})
            except (AssertionError, KeyError, TypeError, ValueError) as error:
                entry["unavailableReason"] = type(error).__name__ + ": " + str(error)[:512]
            entries.append(entry)
    result = {"schemaVersion": 1, "binding": binding, "sourceBefore": before, "sourceAfter": after,
              "scope": "compiler-reported metrics for the existing full candidate check; host verified raw bytes and source identities",
              "allCollectedFilesValid": bool(entries) and all(entry["valid"] for entry in entries), "files": entries}
    atomic_json(output / "trusted-tsgo-metrics-index.json", result)
    return result


def verify_packages(root):
    core = root / "packages/core" / f"openclaw-{binding['version']}-{binding['candidateCommit'][:10]}.tgz"
    with tarfile.open(core, "r:gz") as package:
        manifest = json.load(package.extractfile("package/package.json"))
        info = json.load(package.extractfile("package/dist/build-info.json"))
    assert manifest["name"] == "openclaw" and manifest["version"] == binding["version"]
    assert info["version"] == binding["version"] and info["commit"] == binding["candidateCommit"] and info["builtAt"] == binding["buildTimestamp"]
    for plugin in binding["plugins"]:
        files = list((root / "packages/plugins" / plugin).glob("*.tgz"))
        assert len(files) == 1, "missing or ambiguous plugin tarball: " + plugin
        with tarfile.open(files[0], "r:gz") as package:
            manifest = json.load(package.extractfile("package/package.json"))
            assert manifest["name"] == "@openclaw/" + plugin
            assert manifest["version"] == binding["version"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    args = parser.parse_args()
    assert os.environ["GITHUB_REPOSITORY"] == binding["repository"]
    assert os.environ["GITHUB_REF"] == "refs/heads/main"
    assert os.environ["INFUSE_CANARY_DISPATCH_REF"] == binding["bootstrapBranch"]
    assert os.environ["INFUSE_CANARY_DISPATCH_SHA"] == os.environ["INFUSE_CANARY_BUILD_SHA"]
    assert os.environ["INFUSE_CANARY_CANDIDATE_SHA"] == binding["candidateCommit"]
    event = json.loads(pathlib.Path(os.environ["GITHUB_EVENT_PATH"]).read_text())
    assert event["repository"]["private"] is False
    assert event["repository"]["full_name"] == binding["repository"]
    output = pathlib.Path(os.environ["GITHUB_WORKSPACE"]) / "canary-artifacts"
    assert not output.exists()
    output.mkdir()
    trusted_start_receipt(output)
    source = pathlib.Path(args.source).absolute()
    assert source == pathlib.Path(os.environ["RUNNER_TEMP"]).absolute() / "infuse-canary-candidate"
    assert stat.S_ISDIR(source.lstat().st_mode), "source root is not a real directory"
    assert identity.git(source, "rev-parse", "HEAD").decode().strip() == binding["candidateCommit"]
    assert identity.git(source, "merge-base", binding["baseCommit"], "HEAD").decode().strip() == binding["baseCommit"]
    assert identity.git(source, "status", "--porcelain=v1", "--untracked-files=normal") == b""
    credentials = subprocess.run(["git", "-C", str(source), "config", "--local", "--get-regexp", r"^(http\..*extraheader|credential\..*|core\.sshCommand)$"], stdout=subprocess.DEVNULL)
    assert credentials.returncode == 1, "checkout contains credential/command overrides"
    paths = sorted(os.fsdecode(item) for item in identity.git(source, "ls-files", "-z").split(b"\0") if item)
    before = identity.verify(source, binding, paths)
    task = pathlib.Path(tempfile.mkdtemp(prefix="infuse-canary-", dir=os.environ["RUNNER_TEMP"]))
    work = task / "work"
    work.mkdir()
    command("sudo", "chown", "501:501", str(work))
    name = "infuse-canary-" + secrets.token_hex(6)
    network = name + "-net"
    chain = "IC" + secrets.token_hex(5).upper()
    image = name + ":tools"
    sentinel = None
    container_created = False
    network_created = False
    chain_created = False
    result = 1
    token = secrets.token_hex(24)
    child = None
    heartbeat_stop = threading.Event()
    heartbeat_thread = None
    expired = threading.Event()
    watchdog = None
    def interrupted(signum, _frame):
        raise KeyboardInterrupt("host owner interrupted: " + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    try:
        command("docker", "build", "--platform", "linux/amd64", "--tag", image, str(HARNESS))
        command("docker", "network", "create", "--driver", "bridge", "--subnet", "172.31.253.0/28", "--gateway", "172.31.253.1", "--opt", "com.docker.network.bridge.enable_icc=false", network)
        network_created = True
        network_info = json.loads(command("docker", "network", "inspect", network, capture=True))[0]
        assert network_info["EnableIPv6"] is False
        ipam = network_info["IPAM"]["Config"]
        assert len(ipam) == 1 and ipam[0]["Subnet"] == "172.31.253.0/28" and ipam[0]["Gateway"] == "172.31.253.1"
        sentinel = socket.socket()
        sentinel.bind(("172.31.253.1", 41239))
        sentinel.listen(4)
        def serve():
            while True:
                try:
                    client, _ = sentinel.accept()
                except OSError:
                    return
                with client:
                    client.sendall(b"trusted-host-sentinel\n")
        threading.Thread(target=serve, daemon=True).start()
        with socket.create_connection(("172.31.253.1", 41239), timeout=2) as client:
            assert client.recv(100) == b"trusted-host-sentinel\n"
        firewall("-N", chain)
        chain_created = True
        for destination in ["0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16", "172.16.0.0/12", "192.168.0.0/16", "224.0.0.0/4", "168.63.129.16/32"]:
            firewall("-A", chain, "-d", destination, "-j", "REJECT")
        firewall("-A", chain, "-p", "tcp", "-m", "multiport", "--dports", "80,443", "-j", "RETURN")
        firewall("-A", chain, "-p", "udp", "--dport", "53", "-j", "RETURN")
        firewall("-A", chain, "-p", "tcp", "--dport", "53", "-j", "RETURN")
        firewall("-A", chain, "-j", "REJECT")
        firewall("-I", "DOCKER-USER", "1", "-s", "172.31.253.0/28", "-j", chain)
        firewall("-I", "INPUT", "1", "-s", "172.31.253.0/28", "-j", "REJECT")
        command("docker", "create", "--name", name, "--platform", "linux/amd64", "--init", "--user", "501:501", "--cap-drop", "ALL", "--security-opt", "no-new-privileges=true", "--memory", f"{HOSTED_MEMORY_GIB}g", "--memory-swap", f"{HOSTED_MEMORY_GIB}g", "--cpus", str(HOSTED_CPUS), "--pids-limit", "2048", "--read-only", "--network", network, "--tmpfs", "/tmp:rw,nosuid,nodev,size=1g,uid=501,gid=501", "--mount", "type=bind,src=" + str(source) + ",dst=/input/source,readonly", "--mount", "type=bind,src=" + str(work) + ",dst=/work", image)
        container_created = True
        metadata = json.loads(command("docker", "inspect", name, capture=True))[0]
        assert metadata["Config"]["User"] == "501:501"
        assert metadata["HostConfig"]["CapDrop"] == ["ALL"] and metadata["HostConfig"]["Privileged"] is False
        assert metadata["HostConfig"]["SecurityOpt"] == ["no-new-privileges=true"]
        assert metadata["HostConfig"]["Memory"] == HOSTED_MEMORY_GIB * 1024**3
        assert metadata["HostConfig"]["MemorySwap"] == HOSTED_MEMORY_GIB * 1024**3
        assert metadata["HostConfig"]["NanoCpus"] == HOSTED_CPUS * 10**9
        assert metadata["HostConfig"]["PortBindings"] == {}
        assert sorted((item["Destination"], item["RW"]) for item in metadata["Mounts"] if item["Type"] == "bind") == [("/input/source", False), ("/work", True)]
        endpoint = metadata["NetworkSettings"]["Networks"][network]
        assert endpoint["GlobalIPv6Address"] == ""
        # Disable Actions command interpretation while untrusted candidate stdout is streamed.
        print("::stop-commands::" + token, flush=True)
        try:
            with (task / "docker-output.log").open("wb") as log:
                child = subprocess.Popen(["docker", "start", "--attach", name], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                heartbeat_thread = threading.Thread(target=cgroup_heartbeat, args=(name, output, heartbeat_stop), daemon=True)
                heartbeat_thread.start()
                watchdog = threading.Timer(INNER_TIMEOUT_MINUTES * 60, expire_container, args=(name, expired))
                watchdog.daemon = True
                watchdog.start()
                captured_bytes = 0
                # Bounded binary reads also cover a single huge/no-newline compiler output.
                while data := child.stdout.read1(65536):
                    captured_bytes += len(data)
                    assert captured_bytes <= 64 * 1024**2, "candidate stdout exceeds 64 MiB ceiling"
                    sys.stdout.buffer.write(data)
                    sys.stdout.buffer.flush()
                    log.write(data)
                    log.flush()
                result = child.wait()
                watchdog.cancel()
        finally:
            # Candidate output may end without a newline; resume only on a new trusted line.
            print("\n::" + token + "::", flush=True)
        state = json.loads(command("docker", "inspect", name, capture=True))[0]["State"]
        assert state["Running"] is False
        assert result == state["ExitCode"]
        if expired.is_set():
            raise TimeoutError(f"candidate exceeded trusted {INNER_TIMEOUT_MINUTES}-minute qualification budget")
        # No Git invocation on the mutable execution tree: hashing uses captured trusted paths.
        after = identity.verify(work / "source", binding, paths)
        assert identity.verify(source, binding, paths) == before
        sanitized = output / "candidate"
        sanitize(work / "evidence", sanitized)
        metrics = index_tsgo_metrics(output, sanitized, before, after)
        artifact_bytes = sum(path.stat().st_size for path in output.rglob("*") if path.is_file())
        assert artifact_bytes + (task / "docker-output.log").stat().st_size + 32768 <= 400 * 1024**2, "complete temporary artifact payload exceeds 400 MiB ceiling"
        shutil.copyfile(task / "docker-output.log", output / "docker-output.log")
        (output / "trusted-runner-summary.json").write_text(json.dumps({"binding": binding, "sourceBefore": before, "sourceAfter": after, "containerExitCode": state["ExitCode"], "oomKilled": state["OOMKilled"], "compilerTelemetry": {"allCollectedFilesValid": metrics["allCollectedFilesValid"], "collectedFiles": len(metrics["files"]), "index": "trusted-tsgo-metrics-index.json"}, "hostSentinelPositiveControl": True, "hostFirewall": "container-to-host/private/link-local denied; public HTTP(S)/DNS only", "bootstrapCommit": os.environ["GITHUB_SHA"]}, indent=2) + "\n")
        if result == 0:
            assert metrics["allCollectedFilesValid"], "successful measured qualification requires available, source-bound compiler metrics"
            verify_packages(sanitized)
        else:
            raise RuntimeError("candidate verification failed with exit " + str(result))
        assert sum(path.stat().st_size for path in output.rglob("*") if path.is_file()) <= 400 * 1024**2, "complete temporary artifact payload exceeds 400 MiB ceiling"
    except BaseException as error:
        retain_failure(output, task, error)
        raise
    finally:
        if watchdog is not None:
            watchdog.cancel()
        heartbeat_stop.set()
        if heartbeat_thread is not None:
            heartbeat_thread.join(timeout=20)
        if container_created:
            command("docker", "rm", "--force", name, check=False)
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=10)
        if sentinel is not None:
            sentinel.close()
        if chain_created:
            command("sudo", "iptables", "-w", "-D", "INPUT", "-s", "172.31.253.0/28", "-j", "REJECT", check=False)
            command("sudo", "iptables", "-w", "-D", "DOCKER-USER", "-s", "172.31.253.0/28", "-j", chain, check=False)
            command("sudo", "iptables", "-w", "-F", chain, check=False)
            command("sudo", "iptables", "-w", "-X", chain, check=False)
        if network_created:
            command("docker", "network", "rm", network, check=False)


if __name__ == "__main__":
    main()
