"""Read-only verification of the final downloaded hosted canary evidence."""
import argparse
import csv
import hashlib
import json
import pathlib
import sys
import tarfile

def protected_binding(path, expected_sha256):
    data = pathlib.Path(path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected_sha256, "protected binding digest mismatch"
    return json.loads(data)


parser = argparse.ArgumentParser()
parser.add_argument("artifact_root")
parser.add_argument("--binding", required=True)
parser.add_argument("--binding-sha256", required=True)
parser.add_argument("--source-commit", required=True)
parser.add_argument("--ci-commit", required=True)
args = parser.parse_args()
binding = protected_binding(args.binding, args.binding_sha256)
assert binding["schemaVersion"] == 2
assert binding["harnessProfile"] == "v2026.11.1"
assert binding["packageManager"] == "pnpm@12.15.0+sha512.b3951d6d6ff4a9f13dc7cf56cd28d2b8eb37dbcc9c68e52e1e1191873ea9f82a017287ab50baadc5ccc494f036c67c0e47eb13608c2fa36f47711b61ea128e61"
assert binding["compilerGraphs"] == 36
assert binding["hostedCpus"] == 8 and binding["hostedMemoryGiB"] == 23
root = pathlib.Path(args.artifact_root).resolve(strict=True)
source = args.source_commit
assert source == binding["candidateCommit"]
bootstrap = args.ci_commit
snapshot = {"sha256": binding["sourceSha256"], "paths": binding["sourcePaths"], "bytes": binding["sourceBytes"]}
core_name = f"openclaw-{binding['version']}-{source[:10]}.tgz"
def read(path):
    return json.loads(path.read_bytes())
def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()
summary = read(root / "trusted-runner-summary.json")
start = read(root / "trusted-runner-start.json")
assert start["schemaVersion"] == 1 and start["binding"] == binding
assert start["bootstrapCommit"] == bootstrap
assert start["runnerLabels"] == ["self-hosted", "linux", "x64", "infuse-canary-32gb"]
assert start["candidateResources"] == {"cpus": binding["hostedCpus"], "memoryGiB": binding["hostedMemoryGiB"], "swapGiB": 0}
assert start["innerTimeoutMinutes"] == 690 and start["outerTimeoutMinutes"] == 720
assert start["status"] == "running" and start["passed"] is False
heartbeats = [json.loads(line) for line in (root / "trusted-host-heartbeats.jsonl").read_text().splitlines()]
assert heartbeats and [item["sequence"] for item in heartbeats] == list(range(len(heartbeats)))
running_heartbeats = [item for item in heartbeats if item["status"] == "running"]
assert running_heartbeats, "no host-owned cgroup heartbeat was captured"
last_events = None
for heartbeat in running_heartbeats:
    counters = heartbeat["cgroup"]
    assert counters["memoryMaxBytes"] == binding["hostedMemoryGiB"] * 1024**3
    assert counters["swapMaxBytes"] == 0
    assert counters["memoryEvents"]["oom"] == counters["memoryEvents"]["oom_kill"] == 0
    if last_events is not None:
        assert all(counters["memoryEvents"][key] >= value for key, value in last_events.items())
    last_events = counters["memoryEvents"]
assert summary["binding"] == binding
assert summary["bootstrapCommit"] == bootstrap
assert summary["binding"]["candidateCommit"] == source
assert summary["sourceBefore"] == summary["sourceAfter"] == snapshot
assert summary["containerExitCode"] == 0 and summary["oomKilled"] is False
assert summary["hostSentinelPositiveControl"] is True
candidate = root / "candidate"
index = read(candidate / "artifact-index.json")
paths = set()
total = 0
for entry in index["files"]:
    relative = pathlib.PurePosixPath(entry["path"])
    assert not relative.is_absolute() and ".." not in relative.parts and entry["path"] not in paths
    path = candidate / relative
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(candidate)
    assert path.stat().st_size == entry["bytes"] and digest(path) == entry["sha256"]
    paths.add(entry["path"])
    total += entry["bytes"]
assert total == index["totalBytes"]
assert {str(p.relative_to(candidate)) for p in candidate.rglob("*") if p.is_file()} == paths | {"artifact-index.json"}
steps = list(csv.DictReader((candidate / "steps.tsv").open(), delimiter="\t"))
expected = {"effective-tool-inventory", "install", "check", "sdk-export-map", "sdk-subpath-guard", "sdk-api-diff", "after-tool-call-e2e", "full-package", "sdk-built-exports", "plugin-mattermost", "plugin-codex", "plugin-acpx", "plugin-diagnostics-otel"}
assert len(steps) == len(expected) and {s["step"] for s in steps} == expected
events = {}
for step in steps:
    assert all(step[key] == "0" for key in ["commandExit", "teeExit", "beforeSnapshot", "afterSnapshot", "resultExit"]), step
    before = read(candidate / "cgroup" / (step["step"] + "-before.json"))
    after = read(candidate / "cgroup" / (step["step"] + "-after.json"))
    for phase, record in [("before", before), ("after", after)]:
        assert record["step"] == step["step"] and record["phase"] == phase
        assert record["memoryMaxBytes"] == binding["hostedMemoryGiB"] * 1024**3 and record["swapMaxBytes"] == 0
        assert record["memoryEvents"]["oom"] == record["memoryEvents"]["oom_kill"] == 0
    delta = {k: after["memoryEvents"][k] - v for k, v in before["memoryEvents"].items()}
    assert all(v >= 0 for v in delta.values()) and delta["oom"] == delta["oom_kill"] == 0
    events[step["step"]] = delta
metrics = read(root / "trusted-tsgo-metrics-index.json")
assert metrics["allCollectedFilesValid"] is True and metrics["sourceBefore"] == metrics["sourceAfter"] == snapshot
assert metrics["binding"] == summary["binding"]
assert len(metrics["files"]) == binding["compilerGraphs"] and summary["compilerTelemetry"]["collectedFiles"] == binding["compilerGraphs"]
assert {entry["path"] for entry in metrics["files"]} == {str(p.relative_to(root)) for p in (candidate / "tsgo-metrics").glob("*.json")}
graphs = set()
for entry in metrics["files"]:
    raw = root / entry["path"]
    assert entry["valid"] is True and raw.resolve().is_relative_to(candidate / "tsgo-metrics")
    assert raw.stat().st_size == entry["bytes"] and digest(raw) == entry["sha256"]
    compiler = read(raw)
    assert compiler["revision"] == source and compiler["trackedDirty"] is False
    assert compiler["lockfileSha256"] == summary["binding"]["pnpmLockSha256"]
    assert compiler["nodeVersion"] == "v24.22.1" and compiler["platform"] == "linux" and compiler["arch"] == "x64"
    assert compiler["resources"]["policy"]["GOMEMLIMIT"] == "3GiB" and compiler["resources"]["policy"]["GOGC"] == "30" and compiler["resources"]["policy"]["GOMAXPROCS"] == str(binding["hostedCpus"])
    assert compiler["outcome"] == {"exitCode": 0, "exitSignal": None, "forwardedSignal": None, "errorCode": None}
    args = compiler["command"]["args"]
    project = args[args.index("-p") + 1] if "-p" in args else args[args.index("-b") + 1]
    expected_args = ["-b", project] if project == "tsconfig.extensions.projects.json" else ["-p", project, "--incremental"]
    cache = {"tsconfig.core.json": "core", "tsconfig.ui.json": "ui", "tsconfig.scripts.json": "scripts"}.get(project)
    if cache:
        expected_args += ["--tsBuildInfoFile", f".artifacts/tsgo-cache/{cache}.tsbuildinfo"]
    expected_args += ["--declaration", "false", "--singleThreaded", "--checkers", "1"]
    assert args == expected_args and compiler["command"]["cwd"] == "/work/source"
    assert entry["command"]["argumentCount"] == len(args)
    assert entry["command"]["argsSha256"] == hashlib.sha256(json.dumps(args, separators=(",", ":")).encode()).hexdigest()
    assert entry["outcome"] == compiler["outcome"]
    assert project not in graphs
    graphs.add(project)
core_names = "agents-root agents-other agents-tools gateway-root gateway-server gateway-other infra state-logging commands plugins-platform config-cli messaging services other ui-pages ui-e2e ui-e2e-chat ui-other plugin-sdk commands-doctor cli-update gateway-methods ui-chat agents-sessions services-cron ui-app ui-components".split()
expected_graphs = {f"test/tsconfig/tsconfig.core.test.{name}.json" for name in core_names}
expected_graphs.update({"tsconfig.core.json", "tsconfig.ui.json", "test/tsconfig/tsconfig.test.packages.json", "tsconfig.extensions.projects.json", "tsconfig.scripts.json"})
expected_graphs.update(f"test/tsconfig/tsconfig.test.root.{name}.json" for name in ["tooling", "scripts", "e2e", "other"])
assert len(expected_graphs) == binding["compilerGraphs"] and graphs == expected_graphs
final_events = dict(line.split() for line in (candidate / "memory.events.txt").read_text().splitlines())
assert final_events["oom"] == final_events["oom_kill"] == "0"
packages = []
for path in sorted((candidate / "packages").rglob("*.tgz")):
    with tarfile.open(path, "r:gz") as archive:
        manifest = json.load(archive.extractfile("package/package.json"))
        assert manifest["version"] == binding["version"]
        if manifest["name"] == "openclaw":
            assert path == candidate / "packages/core" / core_name
            build = json.load(archive.extractfile("package/dist/build-info.json"))
            assert build["version"] == binding["version"] and build["commit"] == source and build["builtAt"] == binding["buildTimestamp"]
        else:
            plugin = manifest["name"].removeprefix("@openclaw/")
            assert plugin in {"mattermost", "codex", "acpx", "diagnostics-otel"} and path.parent == candidate / "packages/plugins" / plugin
    packages.append({"path": str(path.relative_to(root)), "name": manifest["name"], "bytes": path.stat().st_size, "sha256": digest(path)})
assert {p["name"] for p in packages} == {"openclaw", "@openclaw/mattermost", "@openclaw/codex", "@openclaw/acpx", "@openclaw/diagnostics-otel"} and len(packages) == 5
print(json.dumps({"schema": 1, "status": "passed", "sourceCommit": source, "bootstrapCommit": bootstrap, "sourceSnapshot": snapshot, "candidateArtifactFiles": len(paths), "candidateArtifactBytes": total, "hostHeartbeats": len(heartbeats), "compilerGraphs": sorted(graphs), "allStepsPassed": True, "stepMemoryEventDeltas": events, "packages": packages}, indent=2))
