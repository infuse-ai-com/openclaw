# Commands

`python3 -B scripts/verify_repo.py` is the offline gate. `Taskfile.yml` wraps it.
`python3 -B -m canary_builder --help` lists stage commands and explicit effects.

`runner_workspace_preflight.py` must run as the dedicated GitHub runner account
before a hosted dispatch. It creates `_diag`, `_work` and `_work/_temp` as that
account, rejects symlinks or foreign-owned residue, exercises the exact
`_github_workflow` write shape and removes its temporary sentinel.
