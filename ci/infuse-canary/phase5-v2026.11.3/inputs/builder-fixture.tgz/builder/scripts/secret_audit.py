#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {
    ".git",
    ".venv",
    ".next",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    "node_modules",
    "__pycache__", ".canary", "artifacts",
}
PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"BEGIN (RSA|OPENSSH|EC) PRIVATE KEY"),
]


def iter_text_files():
    for path in ROOT.rglob("*"):
        if not path.is_file() or SKIP_DIRS.intersection(path.parts):
            continue
        try:
            yield path, path.read_text()
        except UnicodeDecodeError:
            continue


def main() -> int:
    findings: list[str] = []
    for path, text in iter_text_files():
        for pattern in PATTERNS:
            if pattern.search(text):
                findings.append(str(path.relative_to(ROOT)))
                break
    if findings:
        print("Secret-like values found:")
        print("\n".join(findings))
        return 1
    print("secret audit passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
