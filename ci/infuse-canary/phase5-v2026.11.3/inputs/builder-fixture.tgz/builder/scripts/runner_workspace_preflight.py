#!/usr/bin/env python3
"""Prove the GitHub runner's mutable workspace is runner-owned and writable."""

import argparse
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile


def owned_directory(path: Path, uid: int) -> None:
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
        raise ValueError(f"runner workspace path is not a real directory: {path}")
    if info.st_uid != uid:
        raise ValueError(f"runner workspace path has foreign owner: {path}")
    if not info.st_mode & stat.S_IWUSR or not info.st_mode & stat.S_IXUSR:
        raise ValueError(f"runner workspace path is not owner-writable: {path}")
    if not os.access(path, os.W_OK | os.X_OK):
        raise ValueError(f"runner workspace path is not writable by this process: {path}")


def verify_tree(path: Path, uid: int) -> None:
    for current, directories, files in os.walk(path, followlinks=False):
        for name in [*directories, *files]:
            child = Path(current) / name
            info = child.lstat()
            if stat.S_ISLNK(info.st_mode):
                raise ValueError(f"runner mutable tree contains a symlink: {child}")
            if info.st_uid != uid:
                raise ValueError(f"runner mutable tree contains a foreign-owned path: {child}")


def verify(runner_root: Path, *, allow_root_for_tests: bool = False) -> dict:
    uid = os.geteuid()
    if uid == 0 and not allow_root_for_tests:
        raise ValueError("run this preflight as the dedicated runner account, not root")
    if not runner_root.is_absolute():
        raise ValueError("runner root must be absolute")
    if runner_root.resolve() != runner_root:
        raise ValueError("runner root must be canonical and contain no symlink")

    owned_directory(runner_root, uid)
    mutable = [runner_root / "_diag", runner_root / "_work"]
    for path in mutable:
        path.mkdir(mode=0o755, exist_ok=True)
        owned_directory(path, uid)
    temp_root = runner_root / "_work" / "_temp"
    temp_root.mkdir(mode=0o755, exist_ok=True)
    owned_directory(temp_root, uid)
    for path in mutable:
        verify_tree(path, uid)

    sentinel = Path(tempfile.mkdtemp(prefix="runner-workspace-preflight-", dir=temp_root))
    try:
        workflow = sentinel / "_github_workflow"
        workflow.mkdir()
        (workflow / "write-probe").write_text("runner-owned\n")
        candidate = sentinel / "infuse-canary" / "work"
        candidate.mkdir(parents=True)
        (candidate / "write-probe").write_text("runner-owned\n")
    finally:
        shutil.rmtree(sentinel)

    owned_directory(temp_root, uid)
    return {
        "runnerRoot": str(runner_root),
        "runnerUid": uid,
        "tempRoot": str(temp_root),
        "writable": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runner-root", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.runner_root), sort_keys=True))


if __name__ == "__main__":
    main()
