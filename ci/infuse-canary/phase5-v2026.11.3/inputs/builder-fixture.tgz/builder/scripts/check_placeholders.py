#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".git", ".venv", ".next", "node_modules", "__pycache__", ".canary", "artifacts"}
PLACEHOLDERS = [
    "PROJECT" + "_NAME",
    "PROJECT" + "_SLUG",
    "REPO" + "_NAME",
    "PROJECT" + "_NAMESPACE",
    "OWN" + "ER",
    "DEFAULT" + "_BRANCH",
]


def iter_text_files():
    for path in ROOT.rglob("*"):
        if not path.is_file() or SKIP_DIRS.intersection(path.parts):
            continue
        try:
            yield path, path.read_text()
        except UnicodeDecodeError:
            continue


def main() -> int:
    found: list[str] = []
    for path, text in iter_text_files():
        for placeholder in PLACEHOLDERS:
            if placeholder in text:
                found.append(f"{path.relative_to(ROOT)}: {placeholder}")
    if found:
        print("Unreplaced placeholders remain:")
        print("\n".join(found))
        return 1
    print("placeholder audit passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
