#!/usr/bin/env python3
"""Offline verification: contracts, syntax, links, regression tests and audits."""
import ast
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).absolute().parents[1]
sys.path.insert(0, str(ROOT))
from canary_builder.manifest import load, verify_harness
from canary_builder.phase5 import load_profile


def run(*args):
    subprocess.run(args, cwd=ROOT, check=True)


def main():
    required = ("README.md", "AGENTS.md", "Taskfile.yml", ".gitlab-ci.yml", ".gitlab/merge_request_templates/Default.md", "docs/PROJECT_BRIEF.md", "docs/REPO_MAP.md", "docs/DECISIONS.md", "docs/RUNBOOK.md", "docs/VERIFICATION_GATES.md", "docs/README.md", "docs/ROADMAP.md", "docs/LESSONS.md", "docs/WIKI.md", "docs/runbooks/KAPITEKY_MAC_MINI_CANARY.md", "docs/runbooks/NEXT_CANARY.md", "docs/person-trackers/person-tracker-engineering.md", "docs/archive/README.md", "docs/plans/v2026.11.3-canary.md")
    for name in required:
        if not (ROOT / name).is_file():
            raise ValueError("missing repository spine: " + name)
    for group in ("canary_builder", "scripts", "tests", "harness", "harnesses", "phase5-adapters", "phase5-fixtures"):
        for path in (ROOT / group).rglob("*.py"):
            ast.parse(path.read_bytes(), filename=str(path))
    for path in (ROOT / "manifests").glob("*.json"):
        manifest = load(path)
        verify_harness(manifest)
        if manifest["schema"] in (2, 3):
            load_profile(manifest)
    for path in [ROOT / "README.md", ROOT / "AGENTS.md", *(ROOT / "docs").rglob("*.md")]:
        for target in re.findall(r"\]\(([^)]+)\)", path.read_text()):
            if "://" in target or target.startswith("#"):
                continue
            link = target.split("#")[0]
            if link and not (path.parent / link).exists():
                raise ValueError(f"broken link in {path.relative_to(ROOT)}: {target}")
    run(sys.executable, "-B", "scripts/check_placeholders.py")
    run(sys.executable, "-B", "scripts/secret_audit.py")
    run("bash", "-n", "harness/hosted/run-container.sh")
    run("bash", "-n", "harnesses/v2026.11.1/hosted/run-container.sh")
    run("bash", "-n", "harnesses/v2026.11.3/hosted/run-container.sh")
    run(sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-v")
    run("node", "--test", "harness/consumer/actual-graph-contract.test.mjs", "harness/consumer/npm-owned-placement.test.mjs")
    for path in sorted((ROOT / "phase5-fixtures/consumer").glob("*.mjs")):
        run("node", "--check", str(path.relative_to(ROOT)))
    run("git", "diff", "--check")
    print("offline repository verification passed; no Docker, network, candidate execution or deployment")


if __name__ == "__main__":
    main()
