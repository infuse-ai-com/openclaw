#!/usr/bin/env python3
"""Run one reviewed external Phase 5 fixture and emit a standardized receipt."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from canary_builder.io import atomic_json, digest, fingerprint, inventory, read_json, real_directory, relative_path, require
from canary_builder.manifest import load
from canary_builder.phase5 import LANE_STATUSES, expected_candidate, verify_plan_root


def exact_keys(value, names, label):
    require(isinstance(value, dict) and set(value) == set(names.split()), "unexpected fields in " + label)


def command(value, label):
    exact_keys(value, "argv timeoutSeconds", label)
    argv = value["argv"]
    require(isinstance(argv, list) and argv and len(argv) <= 32, "invalid argv in " + label)
    require(all(isinstance(item, str) and item and "\x00" not in item and len(item) <= 1000 for item in argv), "invalid argument in " + label)
    require(type(value["timeoutSeconds"]) is int and 1 <= value["timeoutSeconds"] <= 24 * 60 * 60, "invalid timeout in " + label)
    return argv, value["timeoutSeconds"]


def fixture_inventory(root, path, expected_sha256):
    require(digest(path)["sha256"] == expected_sha256, "fixture inventory pin mismatch")
    value = read_json(path)
    exact_keys(value, "schema files", "fixture inventory")
    require(value["schema"] == 1 and isinstance(value["files"], list), "invalid fixture inventory")
    expected = []
    for row in value["files"]:
        exact_keys(row, "path bytes sha256", "fixture inventory row")
        relative_path(row["path"])
        require(type(row["bytes"]) is int and row["bytes"] >= 0, "invalid fixture file bytes")
        require(isinstance(row["sha256"], str) and len(row["sha256"]) == 64, "invalid fixture file SHA256")
        expected.append(row)
    require(expected == sorted(expected, key=lambda item: item["path"]), "fixture inventory must be sorted")
    require(inventory(root) == expected, "closed fixture inventory differs")
    return expected


def run(command_value, cwd, environment, stdout_path, stderr_path):
    argv, timeout = command(command_value, "fixture command")
    try:
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            result = subprocess.run(argv, cwd=cwd, env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, timeout=timeout, check=False)
        return result.returncode, ""
    except subprocess.TimeoutExpired:
        return 124, "fixture command timed out"
    except OSError as error:
        return 126, "fixture command could not start: " + type(error).__name__


def clean_environment(contract, output, evidence_root, plan_root, lane):
    allowed = contract["environment"]
    require(isinstance(allowed, list) and len(allowed) == len(set(allowed)) and len(allowed) <= 32, "invalid fixture environment allowlist")
    require(all(isinstance(name, str) and name.isascii() and name.replace("_", "").isalnum() and not name[0].isdigit() for name in allowed), "invalid fixture environment name")
    reserved = {"PHASE5_OUTPUT", "PHASE5_PLAN_DIR", "PHASE5_PACKAGE_DIR", "PHASE5_CANDIDATE_MANIFEST", "PHASE5_LANE", "HOME", "TMPDIR"}
    require(not (reserved & set(allowed)), "reserved fixture environment name")
    environment = {name: os.environ[name] for name in allowed if name in os.environ}
    for name in ("PATH", "LANG", "LC_ALL"):
        if name in os.environ:
            environment.setdefault(name, os.environ[name])
    runtime_home = evidence_root / "runtime-home"
    runtime_tmp = evidence_root / "runtime-tmp"
    runtime_home.mkdir(mode=0o700)
    runtime_tmp.mkdir(mode=0o700)
    environment["HOME"] = str(runtime_home)
    environment["TMPDIR"] = str(runtime_tmp)
    environment["PHASE5_OUTPUT"] = str(output)
    environment["PHASE5_PLAN_DIR"] = str(plan_root)
    environment["PHASE5_PACKAGE_DIR"] = str(plan_root / "packages")
    environment["PHASE5_CANDIDATE_MANIFEST"] = str(plan_root / "candidate-manifest.json")
    environment["PHASE5_LANE"] = lane
    return environment


def normalized_result(path, lane, required_checks, command_exit, command_error):
    if path.is_file():
        value = read_json(path)
        exact_keys(value, "schema status checks scopeLimits reason", "fixture result")
        require(value["schema"] == 1 and value["status"] in LANE_STATUSES, "invalid fixture result state")
        require(isinstance(value["checks"], dict) and set(value["checks"]) == set(required_checks), "fixture check closure mismatch")
        for check in value["checks"].values():
            exact_keys(check, "status metrics", "fixture check")
            require(check["status"] in LANE_STATUSES and isinstance(check["metrics"], dict), "invalid fixture check")
        require(isinstance(value["scopeLimits"], list) and len(value["scopeLimits"]) == len(set(value["scopeLimits"])) and all(isinstance(item, str) and item for item in value["scopeLimits"]), "invalid fixture scope limits")
        require(isinstance(value["reason"], str) and len(value["reason"]) <= 1000, "invalid fixture reason")
    else:
        value = {
            "schema": 1,
            "status": "failed",
            "checks": {name: {"status": "failed", "metrics": {}} for name in required_checks},
            "scopeLimits": [],
            "reason": command_error or "fixture did not write its result",
        }
    if command_exit != 0:
        value["status"] = "failed"
        first = required_checks[0]
        value["checks"][first]["status"] = "failed"
        value["reason"] = value["reason"] or command_error or "fixture command exited " + str(command_exit)
    return value


def execute(args):
    manifest = load(args.manifest)
    plan_root, plan, profile, specs = verify_plan_root(manifest, args.plan_dir)
    plan_pin = digest(plan_root / "phase5-plan.json")
    profile_by_name = {lane["name"]: lane for lane in profile["lanes"]}
    specs_by_name = {lane["name"]: lane for lane in specs["lanes"]}
    require(args.lane in profile_by_name, "unknown Phase 5 lane")
    lane = profile_by_name[args.lane]
    spec = specs_by_name[args.lane]
    controller = spec["controller"]
    require(controller["path"] == Path(__file__).resolve().relative_to(ROOT).as_posix(), "fixture spec selects another controller path")
    require(digest(Path(__file__).resolve()) == {key: controller[key] for key in ("bytes", "sha256")}, "adapter controller bytes differ")

    fixture_root = real_directory(args.fixture_root)
    require(subprocess.check_output(["git", "-C", str(fixture_root), "rev-parse", "HEAD"], text=True, timeout=10).strip() == spec["fixture"]["commit"], "fixture Git commit mismatch")
    require(not subprocess.check_output(["git", "-C", str(fixture_root), "status", "--porcelain", "--untracked-files=all"], text=True, timeout=30).strip(), "fixture Git checkout is dirty")
    inventory_path = Path(args.fixture_inventory).absolute()
    fixture_inventory(fixture_root, inventory_path, spec["fixture"]["inventorySha256"])

    contract_path = fixture_root / relative_path(spec["fixture"]["profile"])
    contract = read_json(contract_path)
    exact_keys(contract, "schema lane command cleanup resultFile evidenceDirectory environment cleanupScope", "fixture contract")
    require(contract["schema"] == 1 and contract["lane"] == args.lane, "fixture contract lane mismatch")
    require(contract["cleanupScope"] == "fixture-owned-only", "fixture cleanup scope is too broad")
    result_file = relative_path(contract["resultFile"])
    evidence_directory = relative_path(contract["evidenceDirectory"])
    require("/" not in evidence_directory, "evidence directory must be one top-level component")
    require(result_file.startswith(evidence_directory + "/"), "fixture result must be inside the evidence directory")
    _, command_timeout = command(contract["command"], "fixture command")
    _, cleanup_timeout = command(contract["cleanup"], "fixture cleanup")
    require(max(command_timeout, cleanup_timeout) <= spec["execution"]["timeoutMinutes"] * 60, "fixture command exceeds the reviewed timeout")
    require(spec["execution"]["secretClass"] != "none" or not contract["environment"], "secretless fixture cannot import environment values")

    output = Path(args.output).absolute()
    require(not output.exists() and not output.is_symlink(), "adapter output already exists")
    real_directory(output.parent)
    output.mkdir(mode=0o700)
    evidence_root = output / evidence_directory
    evidence_root.mkdir(parents=True, mode=0o700)
    environment = clean_environment(contract, output, evidence_root, plan_root, args.lane)
    exit_code, command_error = run(contract["command"], fixture_root, environment, evidence_root / "adapter.stdout.log", evidence_root / "adapter.stderr.log")
    cleanup_exit, cleanup_error = run(contract["cleanup"], fixture_root, environment, evidence_root / "cleanup.stdout.log", evidence_root / "cleanup.stderr.log")
    fixture_inventory(fixture_root, inventory_path, spec["fixture"]["inventorySha256"])
    verified_root, _, _, _ = verify_plan_root(manifest, plan_root)
    require(verified_root == plan_root and digest(plan_root / "phase5-plan.json") == plan_pin, "Phase 5 plan changed during fixture execution")
    result = normalized_result(output / result_file, args.lane, lane["requiredChecks"], exit_code, command_error)
    if cleanup_exit != 0:
        result["status"] = "failed"
        result["reason"] = result["reason"] or cleanup_error or "fixture cleanup exited " + str(cleanup_exit)
    evidence_rows = inventory(evidence_root)
    candidate = expected_candidate(plan, plan_pin["sha256"])
    receipt = {
        "schema": 1,
        "lane": args.lane,
        "status": result["status"],
        "candidate": candidate,
        "adapter": controller,
        "fixture": spec["fixture"],
        "resources": spec["resources"],
        "checks": result["checks"],
        "evidence": {"files": len(evidence_rows), "inventorySha256": fingerprint(evidence_rows)},
        "cleanup": {"status": "passed" if cleanup_exit == 0 else "failed", "ownedResourcesOnly": True},
        "scopeLimits": result["scopeLimits"],
        "reason": result["reason"],
    }
    atomic_json(output / "receipt.json", receipt)
    require({path.name for path in output.iterdir()} == {"receipt.json", evidence_directory}, "adapter output root is not closed")
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--plan-dir", required=True)
    parser.add_argument("--lane", required=True)
    parser.add_argument("--fixture-root", required=True)
    parser.add_argument("--fixture-inventory", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    receipt = execute(args)
    print(receipt["status"])
    raise SystemExit(0 if receipt["status"] != "failed" else 1)


if __name__ == "__main__":
    main()
