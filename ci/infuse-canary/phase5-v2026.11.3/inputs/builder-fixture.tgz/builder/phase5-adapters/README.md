# Phase 5 external adapter controller

`run-adapter.py` standardizes one externally owned disposable qualification
lane. It authenticates the prepared Phase 5 plan, its own selected bytes, the
exact fixture Git commit and a closed fixture inventory before execution. It
runs one argv-only fixture command with a clean allowlisted environment, runs
one fixture-owned cleanup command exactly once, rechecks the fixture inventory
and emits the receipt consumed by `collect-phase5`.

The fixture profile path comes from the private fixture-spec record and must be
inside the inventory-bound fixture root. Its JSON shape is:

```json
{
  "schema": 1,
  "lane": "arm64Consumer",
  "command": {"argv": ["python3", "scripts/run-consumer.py"], "timeoutSeconds": 3600},
  "cleanup": {"argv": ["python3", "scripts/cleanup-consumer.py"], "timeoutSeconds": 300},
  "resultFile": "evidence/fixture-result.json",
  "evidenceDirectory": "evidence",
  "environment": [],
  "cleanupScope": "fixture-owned-only"
}
```

The command writes its result under `$PHASE5_OUTPUT/resultFile`, which must be
inside `$PHASE5_OUTPUT/evidenceDirectory` so the raw result is covered by the
closed evidence inventory. The result contains exactly
`schema`, `status`, `checks`, `scopeLimits` and `reason`; its check names must
match the versioned profile. Environment values and command output are never
embedded in the receipt. Secretless lanes cannot import environment values;
all lanes receive isolated `HOME` and `TMPDIR` directories inside the evidence
inventory. Raw logs remain private evidence. Command and cleanup timeouts may
not exceed the reviewed lane timeout.

Every fixture also receives adapter-owned `PHASE5_PLAN_DIR`,
`PHASE5_PACKAGE_DIR`, `PHASE5_CANDIDATE_MANIFEST`, `PHASE5_LANE` and
`PHASE5_OUTPUT` values. Contracts cannot import or override these reserved
names. After command and cleanup, the adapter re-authenticates the closed plan
and requires its original digest before writing a receipt.

This controller does not grant publication, deployment, production credentials
or permission to stop unrelated resources. Fixture contracts must use explicit
disposable profiles and cleanup only resources they created.
