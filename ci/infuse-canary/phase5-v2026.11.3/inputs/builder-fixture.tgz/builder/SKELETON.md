# repo-skeleton-infra

Purpose: infrastructure, platform, deployment, automation, or operations repo.

Required tree:

- `README.md`
- `AGENTS.md`
- `.gitignore`
- `.gitlab/merge_request_templates/Default.md`
- `.gitlab-ci.yml`
- `k8s/`
- `scripts/`
- `config/`
- `docs/security/`
- `docs/runbooks/`
- `docs/rollback/`
- `docs/PROJECT_BRIEF.md`
- `docs/REPO_MAP.md`
- `docs/DECISIONS.md`
- `docs/RUNBOOK.md`
- `docs/VERIFICATION_GATES.md`
- `Taskfile.yml`

Required gates: render, lint, secret scan, server-side dry-run when a context
exists.
