# Configuration

Reviewed candidate data lives in `manifests/`; generated binding data stays under
the ignored workspace. There is no tracked environment file or secret config.
