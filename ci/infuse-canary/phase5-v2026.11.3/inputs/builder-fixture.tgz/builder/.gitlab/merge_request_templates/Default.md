## Summary

## Changes

## Verification

- [ ] `task verify` passes or the gap is explained
- [ ] Browser/device smoke evidence is attached when UI/mobile behavior changed
- [ ] Deployment/runtime evidence is attached when delivery behavior changed
- [ ] No debug logging, secrets, credentials, or private payloads were committed

## Risk / rollback

## Related
