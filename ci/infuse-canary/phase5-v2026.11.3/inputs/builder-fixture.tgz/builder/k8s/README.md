# Runtime boundary

This CLI owns no Kubernetes manifests or namespace. Production image delivery
and swarm deployment belong in openclaw-k8s-swarm.
