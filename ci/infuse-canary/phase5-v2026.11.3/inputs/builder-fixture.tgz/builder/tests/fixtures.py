"""Tiny synthetic packages and private input sets; no real agent state."""
import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile

from canary_builder import assets, phase5
from canary_builder.io import atomic_json, digest, fingerprint, inventory, read_json
from canary_builder.manifest import ROOT, load


def package(path, name, m, extra=None):
    contents = {"package/package.json": json.dumps({"name": name, "version": m["build"]["version"]}).encode()}
    if name == "openclaw":
        contents["package/dist/build-info.json"] = json.dumps({"commit": m["source"]["commit"], "version": m["build"]["version"]}).encode()
    if extra:
        contents.update(extra)
    with tarfile.open(path, "w:gz") as archive:
        for name, data in contents.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            archive.addfile(entry, io.BytesIO(data))


def release_fixture(root):
    m = copy.deepcopy(load(ROOT / "manifests/v2026.10.3.json"))
    m["release"]["id"] = 0
    directory = root / "assets"
    directory.mkdir()
    core_name = assets.core_asset(m)["name"]
    package(directory / core_name, "openclaw", m)
    for plugin in m["build"]["plugins"]:
        package(directory / f"openclaw-{plugin}-{m['build']['version']}.tgz", "@openclaw/" + plugin, m)
    core = digest(directory / core_name)
    candidate = {"hostVersion": m["build"]["version"], "hostCommit": m["source"]["commit"], "baseCommit": m["source"]["upstreamCommit"], "buildTimestamp": m["build"]["timestamp"], "sourceSnapshotSha256": m["source"]["snapshot"]["sha256"], "sourceLockSha256": m["source"]["lockSha256"], "hostPackageSha256": core["sha256"], "hostPackageFile": core_name, "ciCommit": m["ci"]["commit"], "workflowRunId": m["ci"]["runId"], "workflowRunAttempt": 1}
    atomic_json(directory / "candidate-manifest.json", candidate)
    packages = [{"name": p.name, **digest(p)} for p in sorted(directory.glob("*.tgz"))]
    provenance = {"sourceCommit": m["source"]["commit"], "ciCommit": m["ci"]["commit"], "upstreamTag": m["source"]["upstreamTag"], "upstreamCommit": m["source"]["upstreamCommit"], "workflowRun": f"https://github.com/{m['source']['repository']}/actions/runs/{m['ci']['runId']}", "all13StagesPassed": True, "compilerGraphs": m["build"].get("compilerGraphs", 35), "packages": packages}
    provenance.update(sourceSnapshotSha256=m["source"]["snapshot"]["sha256"], candidateManifestSha256=digest(directory / "candidate-manifest.json")["sha256"])
    atomic_json(directory / "BUILD-PROVENANCE.json", provenance)
    qualification = {"sourceCommit": m["source"]["commit"], "ciCommit": m["ci"]["commit"], "coreArchiveSha256": core["sha256"], "candidateManifestSha256": digest(directory / "candidate-manifest.json")["sha256"], "status": "passed-with-declared-scope-limits", "scopeLimits": ["synthetic test data only"], "checks": {s: {"status": "passed"} for s in ("hosted", "arm64Consumer", "publicInventory", "managedNative", "ordinaryMattermost", "amd64", "localImage", "builderBoundary")}}
    atomic_json(directory / "LINUX-QUALIFICATION.json", qualification)
    (directory / "SHA256SUMS").write_text("".join(f"{digest(p)['sha256']}  {p.name}\n" for p in sorted(directory.iterdir())))
    m["assets"] = [{"name": p.name, **digest(p)} for p in sorted(directory.iterdir())]
    notes = root / "notes.md"
    notes.write_text("Synthetic canary. No deployment.\n")
    m["release"]["notesSha256"] = digest(notes)["sha256"]
    return m, directory, notes


def private_fixture(root, m):
    root.mkdir()
    core = assets.core_asset(m)
    data = b"synthetic Core only"
    core.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    slots = ["image-build-context/local-inputs/openclaw-consumer/artifacts/" + core["name"], "consumer-uninstalled/artifacts/" + core["name"]]
    groups = []
    for name in ("swarm-source", "image-build-context", "consumer-uninstalled", "verification-controls"):
        base = root / name
        base.mkdir()
        (base / "check.txt").write_text("synthetic public test source")
        rows = [{"path": "check.txt", "mode": "100644", **digest(base / "check.txt")}]
        for slot in slots:
            if slot.startswith(name + "/"):
                rows.append({"path": slot[len(name) + 1:], "mode": "100644", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        rows.sort(key=lambda r: r["path"])
        h = hashlib.sha256()
        for row in rows:
            content = data if row["path"] != "check.txt" else (base / "check.txt").read_bytes()
            h.update(row["path"].encode() + b"\0" + row["mode"].encode() + b"\0" + content + b"\0")
        name_inventory = name + "-inventory.json"
        atomic_json(root / name_inventory, {"schema": 1, "root": name, "files": rows})
        groups.append({"root": name, "inventory": name_inventory, "inventorySha256": digest(root / name_inventory)["sha256"], "pathCount": len(rows), "fingerprintSha256": h.hexdigest()})
    atomic_json(root / "candidate-manifest.json", {"hostCommit": m["source"]["commit"]})
    h = {"schema": 1, "classification": "private-company-source", "sets": groups, "publicCore": {"file": core["name"], "bytes": core["bytes"], "sha256": core["sha256"], "url": f"https://github.com/{m['source']['repository']}/releases/download/{m['release']['tag']}/{core['name']}", "omittedArchiveSlots": slots}, "candidateManifestSha256": digest(root / "candidate-manifest.json")["sha256"]}
    atomic_json(root / "HYDRATE.json", h)
    return digest(root / "HYDRATE.json")["sha256"], data


def phase5_inputs(root, m):
    root.mkdir()
    package_root = root / "packages"
    package_root.mkdir()
    expected = phase5.expected_package_names(m)
    package_rows = []
    for package_name, filename in expected.items():
        path = package_root / filename
        path.write_bytes(("synthetic " + package_name).encode())
        relative = "candidate/packages/core/" + filename if package_name == "openclaw" else "candidate/packages/plugins/" + package_name.split("/")[-1] + "/" + filename
        package_rows.append({"path": relative, "name": package_name, **digest(path)})
    package_rows.sort(key=lambda item: item["name"])
    hosted = {
        "status": "passed",
        "sourceCommit": m["source"]["commit"],
        "bootstrapCommit": m["ci"]["commit"],
        "allStepsPassed": True,
        "hostHeartbeats": 7,
        "compilerGraphs": [f"graph-{index:02d}" for index in range(m["build"]["compilerGraphs"])],
        "packages": package_rows,
    }
    hosted_path = root / "verified-receipt.json"
    atomic_json(hosted_path, hosted)
    m["referenceEvidence"]["verifiedReceiptSha256"] = digest(hosted_path)["sha256"]
    core = next(item for item in package_rows if item["name"] == "openclaw")
    candidate = {
        "hostVersion": m["build"]["version"],
        "hostCommit": m["source"]["commit"],
        "baseCommit": m["source"]["upstreamCommit"],
        "buildTimestamp": m["build"]["timestamp"],
        "sourceSnapshotSha256": m["source"]["snapshot"]["sha256"],
        "sourceLockSha256": m["source"]["lockSha256"],
        "hostPackageSha256": core["sha256"],
        "hostPackageFile": Path(core["path"]).name,
        "ciCommit": m["ci"]["commit"],
        "workflowRunId": m["ci"]["runId"],
        "workflowRunAttempt": 1,
    }
    candidate_path = root / "candidate-manifest.json"
    atomic_json(candidate_path, candidate)
    profile = phase5.load_profile(m)
    specs = {"schema": 1, "candidateId": m["candidateId"], "lanes": []}
    for index, lane in enumerate(profile["lanes"]):
        specs["lanes"].append({
            "name": lane["name"],
            "controller": {"repository": "example/controller", "commit": f"{index + 1:040x}", "path": "controllers/" + lane["name"] + ".py", "bytes": 100 + index, "sha256": f"{index + 1:064x}"},
            "fixture": {"repository": "example/fixture", "commit": f"{index + 101:040x}", "profile": "synthetic-" + lane["name"], "inventorySha256": f"{index + 101:064x}"},
            "resources": {"platform": lane["platforms"][0], "architecture": lane["architectures"][0], "cpus": lane["minCpus"], "memoryBytes": lane["minMemoryBytes"]},
            "dependencies": [{"name": "synthetic-runtime", "version": "1.0.0", "sha256": f"{index + 201:064x}"}],
            "execution": {"timeoutMinutes": 30, "network": lane["networks"][0], "secretClass": lane["secretClasses"][0], "disposable": True},
        })
    specs_path = root / "fixture-specs.json"
    atomic_json(specs_path, specs)
    return hosted_path, candidate_path, package_root, specs_path


def phase5_evidence(root, m, plan_root, statuses=None):
    root.mkdir()
    plan = read_json(plan_root / "phase5-plan.json")
    profile = phase5.load_profile(m)
    specs = read_json(plan_root / "fixture-specs.json")
    specs_by_name = {item["name"]: item for item in specs["lanes"]}
    candidate = phase5.expected_candidate(plan, digest(plan_root / "phase5-plan.json")["sha256"])
    statuses = statuses or {}
    for lane in profile["lanes"]:
        name = lane["name"]
        status = statuses.get(name, "passed")
        lane_root = root / name
        evidence_root = lane_root / "evidence"
        evidence_root.mkdir(parents=True)
        if status != "unverified":
            atomic_json(evidence_root / "proof.json", {"lane": name, "synthetic": True, "status": status})
        evidence_rows = inventory(evidence_root)
        check_status = status
        checks = {check: {"status": check_status, "metrics": {"synthetic": 1}} for check in lane["requiredChecks"]}
        receipt = {
            "schema": 1,
            "lane": name,
            "status": status,
            "candidate": candidate,
            "adapter": specs_by_name[name]["controller"],
            "fixture": specs_by_name[name]["fixture"],
            "resources": specs_by_name[name]["resources"],
            "checks": checks,
            "evidence": {"files": len(evidence_rows), "inventorySha256": fingerprint(evidence_rows)},
            "cleanup": {"status": "passed", "ownedResourcesOnly": True},
            "scopeLimits": ["synthetic test data only"],
            "reason": "" if status == "passed" else "synthetic " + status,
        }
        atomic_json(lane_root / "receipt.json", receipt)
    return root
