import copy
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

from canary_builder import assets, doctor, handoff, hosted, hydrate, phase5, publish
from canary_builder.io import atomic_json, digest, inventory, read_json
from canary_builder.manifest import HARNESS_PROFILES, ROOT, binding, harness_section, load, validate, verify_harness
from canary_builder.state import Workspace
from fixtures import phase5_evidence, phase5_inputs, private_fixture, release_fixture


class Case(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="canary-test-", dir="/private/tmp" if Path("/private/tmp").exists() else None)
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.manifest = load(ROOT / "manifests/v2026.10.3.json")


class ManifestTests(Case):
    def synthetic_source(self, package_manager, version="2026.11.1"):
        source = self.root / "source"
        source.mkdir()
        (source / "package.json").write_text(json.dumps({"version": version, "packageManager": package_manager}))
        (source / "pnpm-lock.yaml").write_text("synthetic lock")
        def git(*args):
            return subprocess.check_output(["git", "-c", "core.hooksPath=/dev/null", "-c", "user.name=Synthetic", "-c", "user.email=test@example.invalid", "-C", str(source), *args], stderr=subprocess.DEVNULL)
        git("init", "-b", "main")
        git("add", ".")
        git("commit", "-m", "synthetic upstream")
        git("tag", "v" + version)
        return source, git

    def test_reference_has_exact_binding_and_closed_harness(self):
        self.assertEqual(binding(self.manifest)["candidateCommit"], "877030b3a66bec373d235129919a5a7a964ca07f")
        self.assertEqual(len(verify_harness(self.manifest)["files"]), 14)

    def test_stale_branch_and_tag_are_refused(self):
        for part, key in [("source", "branch"), ("source", "upstreamTag"), ("ci", "branch"), ("release", "tag")]:
            m = copy.deepcopy(self.manifest)
            m[part][key] = m[part][key].replace("10.3", "10.2")
            with self.assertRaises(ValueError):
                validate(m)

    def test_unsupported_fields_and_duplicate_keys_refused(self):
        self.manifest["deploy"] = True
        with self.assertRaises(ValueError):
            validate(self.manifest)
        path = self.root / "duplicate.json"
        path.write_text('{"schema":1,"schema":2}')
        with self.assertRaises(ValueError):
            read_json(path)

    def test_changed_controller_cannot_renew_its_own_pin(self):
        shutil.copytree(ROOT / "harness", self.root / "harness")
        shutil.copyfile(ROOT / "harness-lock.json", self.root / "harness-lock.json")
        path = self.root / "harness/hosted/identity.py"
        path.write_text(path.read_text() + "\n# unexpected change\n")
        with self.assertRaises(ValueError):
            verify_harness(self.manifest, self.root)

    def test_extra_controller_refused(self):
        shutil.copytree(ROOT / "harness", self.root / "harness")
        shutil.copyfile(ROOT / "harness-lock.json", self.root / "harness-lock.json")
        (self.root / "harness/unreviewed.py").write_text("pass")
        with self.assertRaises(ValueError):
            verify_harness(self.manifest, self.root)

    def test_unreviewed_cached_bytecode_is_not_a_hidden_controller(self):
        shutil.copytree(ROOT / "harness", self.root / "harness")
        shutil.copyfile(ROOT / "harness-lock.json", self.root / "harness-lock.json")
        cache = self.root / "harness/hosted/__pycache__"
        cache.mkdir()
        (cache / "identity.pyc").write_bytes(b"synthetic unreviewed bytecode")
        with self.assertRaises(ValueError):
            verify_harness(self.manifest, self.root)

    def test_preparation_keeps_manual_boundary_and_generates_binding(self):
        output = self.root / "prepared"
        output.mkdir()
        hosted.prepare(self.manifest, output)
        workflow = (output / ".github/workflows/ci.yml").read_text()
        self.assertIn("workflow_dispatch:", workflow)
        self.assertNotIn("schedule:", workflow)
        self.assertNotIn("contents: write", workflow)
        self.assertIn("runs-on: [ubuntu-24.04]", workflow)
        self.assertIn("timeout-minutes: 240", workflow)
        self.assertEqual(read_json(output / "ci/infuse-canary/binding.json"), binding(self.manifest))
        for path in (ROOT / "harness/hosted").iterdir():
            if path.is_file():
                self.assertEqual(digest(path), digest(output / "ci/infuse-canary" / path.name))

    def test_proposal_from_clean_checkout_invalidates_all_prior_evidence(self):
        source, _ = self.synthetic_source(HARNESS_PROFILES["v2026.11.1"]["packageManager"])
        proposed = validate(hosted.propose(self.manifest, source, "v2026.11.1"))
        self.assertEqual(proposed["assets"], [])
        self.assertEqual(proposed["ci"]["runId"], 0)
        self.assertEqual(proposed["release"]["id"], 0)
        self.assertEqual(proposed["schema"], 2)
        self.assertEqual(proposed["harnessProfile"], "v2026.11.1")
        self.assertEqual(proposed["build"]["compilerGraphs"], 36)
        self.assertEqual((proposed["build"]["hostedCpus"], proposed["build"]["hostedMemoryGiB"]), (8, 23))
        self.assertEqual((binding(proposed)["hostedCpus"], binding(proposed)["hostedMemoryGiB"]), (8, 23))
        workflow = hosted.workflow(proposed)
        self.assertIn("runs-on: [self-hosted, linux, x64, infuse-canary-32gb]", workflow)
        self.assertIn("timeout-minutes: 720", workflow)
        self.assertIn("if-no-files-found: error", workflow)
        self.assertEqual(len(verify_harness(proposed)["files"]), 14)
        self.assertEqual(hosted.source_check(proposed, source)["commit"], proposed["source"]["commit"])
        (source / "package.json").write_text('{"version":"2026.11.2"}')
        with self.assertRaises(ValueError):
            hosted.source_check(proposed, source)

    def test_v2026_11_1_profile_refuses_stale_source_and_manifest_contracts(self):
        source, git = self.synthetic_source("pnpm@12.5.1")
        with self.assertRaisesRegex(ValueError, "packageManager outside reviewed harness profile"):
            hosted.propose(self.manifest, source, "v2026.11.1")
        (source / "package.json").write_text(json.dumps({"version": "2026.11.1", "packageManager": HARNESS_PROFILES["v2026.11.1"]["packageManager"]}))
        git("add", "package.json")
        git("commit", "--amend", "--no-edit")
        git("tag", "-f", "v2026.11.1")
        proposed = validate(hosted.propose(self.manifest, source, "v2026.11.1"))
        for key, stale in [("pnpmVersion", "12.5.1"), ("compilerGraphs", 35), ("packageManager", "pnpm@12.5.1"), ("nodeVersion", "24.21.0"), ("hostedCpus", 4), ("hostedMemoryGiB", 24)]:
            changed = copy.deepcopy(proposed)
            changed["build"][key] = stale
            with self.assertRaisesRegex(ValueError, "reviewed harness profile mismatch|resource policy requires harness review"):
                validate(changed)
        script = (harness_section(proposed, "hosted") / "run-container.sh").read_text()
        self.assertIn("tools-effective-inventory.policy.test.ts", script)
        self.assertNotIn("tools-effective-inventory.plugin-tools.test.ts", script)
        self.assertIn("if ! step check", script)
        self.assertIn("deadline=210m", script)
        self.assertIn("export CI=true", script)
        self.assertNotIn("export CI=1", script)
        self.assertIn('export GOMAXPROCS="${release_values[4]}"', script)
        host = (harness_section(proposed, "hosted") / "run-host.py").read_text()
        self.assertIn("assert HOSTED_CPUS == 8 and HOSTED_MEMORY_GIB == 23", host)
        self.assertIn("INNER_TIMEOUT_MINUTES = 690", host)
        self.assertIn('"outerTimeoutMinutes": 720', host)
        self.assertIn("after-tool-call-e2e|full-package|plugin-*) deadline=660m", script)
        self.assertIn("OPENCLAW_DOCKER_PACKAGE_BUILD_TIMEOUT_MS=39600000", script)
        self.assertIn("trusted-runner-start.json", host)
        self.assertIn("trusted-host-heartbeats.jsonl", host)
        self.assertIn('["docker", "exec", container, "/usr/bin/python3", "-I", "-c", script]', host)
        self.assertNotIn('["docker", "exec", container, "/usr/local/bin/python3"', host)
        verifier = (harness_section(proposed, "collector") / "trusted-verifier.py").read_text()
        self.assertIn("ui-e2e-chat", verifier)
        self.assertNotIn("== 35", verifier)
        installer = (harness_section(proposed, "hosted") / "install-pnpm.py").read_text()
        self.assertIn("402f7045b1e0587acb1542f18d38afbccb6babf3c7451394e6fb3d9f0160c6ca", installer)
        self.assertIn("25056098", installer)
        copied = self.root / "profile-copy"
        shutil.copytree(ROOT / "harness/consumer", copied / "harness/consumer")
        shutil.copytree(ROOT / "harnesses/v2026.11.1", copied / "harnesses/v2026.11.1")
        (copied / "harness-locks").mkdir()
        shutil.copyfile(ROOT / "harness-locks/v2026.11.1.json", copied / "harness-locks/v2026.11.1.json")
        changed = copied / "harnesses/v2026.11.1/hosted/probe.py"
        changed.write_text(changed.read_text() + "\n# unexpected change\n")
        with self.assertRaisesRegex(ValueError, "file pin mismatch"):
            verify_harness(proposed, copied)

    def test_v2026_11_3_schema3_uses_infuse_bundle_and_blacksmith_dispatcher(self):
        profile = HARNESS_PROFILES["v2026.11.3"]
        source, _ = self.synthetic_source(profile["packageManager"], "2026.11.3")
        proposed = validate(hosted.propose(self.manifest, source, "v2026.11.3"))
        self.assertEqual(proposed["schema"], 3)
        self.assertEqual(proposed["source"]["repository"], "infuse-ai-com/openclaw")
        self.assertEqual(proposed["source"]["branch"], "canary-openclaw-v2026.11.3")
        self.assertEqual(proposed["ci"]["branch"], "build/canary-openclaw-v2026.11.3")
        self.assertEqual(proposed["ci"]["buildAttempt"], 1)
        self.assertEqual(proposed["ci"]["workflowId"], 417706371)
        self.assertEqual(binding(proposed)["runnerLabel"], "blacksmith-16vcpu-ubuntu-2404")
        self.assertEqual((proposed["build"]["hostedCpus"], proposed["build"]["hostedMemoryGiB"]), (16, 47))
        self.assertEqual((binding(proposed)["hostedCpus"], binding(proposed)["hostedMemoryGiB"]), (16, 47))
        self.assertEqual(binding(proposed)["workflowId"], 417706371)
        self.assertEqual(binding(proposed)["buildAttempt"], 1)
        self.assertEqual(hosted.execution_policy(proposed)["runnerLabels"], ("blacksmith-16vcpu-ubuntu-2404",))
        with self.assertRaisesRegex(ValueError, "reviewed main-branch dispatcher"):
            hosted.workflow(proposed)
        output = self.root / "schema3-prepared"
        output.mkdir()
        hosted.prepare(proposed, output)
        self.assertFalse((output / ".github").exists())
        self.assertEqual(read_json(output / "ci/infuse-canary/binding.json"), binding(proposed))
        self.assertEqual(hosted.source_check(proposed, source)["commit"], proposed["source"]["commit"])
        script = (harness_section(proposed, "hosted") / "run-container.sh").read_text()
        self.assertIn("--lint-changed", script)
        host = (harness_section(proposed, "hosted") / "run-host.py").read_text()
        self.assertIn("assert HOSTED_CPUS == 16 and HOSTED_MEMORY_GIB == 47", host)
        self.assertNotIn("assert HOSTED_CPUS == 8 and HOSTED_MEMORY_GIB == 23", host)
        collector = (harness_section(proposed, "collector") / "collect-completed.py").read_text()
        verifier = (harness_section(proposed, "collector") / "trusted-verifier.py").read_text()
        self.assertIn("artifact['workflow_run']['head_sha'] == dispatcher", collector)
        self.assertNotIn("artifact['workflow_run']['head_sha'] == ci", collector)
        self.assertIn("'--dispatcher-commit', dispatcher, '--run-id', str(run_id)", collector)
        self.assertIn('start["dispatcherCommit"] == dispatcher', verifier)
        self.assertIn('start["runId"] == run_id and start["runAttempt"] == 1', verifier)
        self.assertIn('summary["bootstrapCommit"] == dispatcher', verifier)
        self.assertNotIn('summary["bootstrapCommit"] == bootstrap', verifier)
        self.assertIn('observed["workflowId"] in (0, protected["workflowId"])', verifier)
        self.assertIn('summary["binding"] == start["binding"]', verifier)
        self.assertNotIn('start["binding"] == binding', verifier)
        self.assertIn('expected_args += ["--declaration", "false"]', verifier)
        self.assertNotIn('expected_args += ["--declaration", "false", "--singleThreaded", "--checkers", "1"]', verifier)

        retry = validate(hosted.propose(self.manifest, source, "v2026.11.3", 2))
        self.assertEqual(retry["ci"]["buildAttempt"], 2)
        self.assertEqual(retry["ci"]["branch"], "build/canary-openclaw-v2026.11.3-r2")
        self.assertEqual(binding(retry)["buildAttempt"], 2)
        with self.assertRaisesRegex(ValueError, "positive integer"):
            hosted.propose(self.manifest, source, "v2026.11.3", 0)


class ResumeTests(Case):
    def operation(self, output):
        (output / "result.txt").write_text("qualified synthetic bytes")
        return {"passed": True}

    def test_identical_run_resumes_without_reexecution(self):
        workspace = Workspace(self.root / "run", self.manifest)
        self.assertFalse(workspace.run("example", {"dependency": "one"}, self.operation)["resumed"])
        self.assertTrue(workspace.run("example", {"dependency": "one"}, lambda _: self.fail("must not execute"))["resumed"])

    def test_changed_dependency_refused(self):
        workspace = Workspace(self.root / "run", self.manifest)
        workspace.run("example", {"dependency": "one"}, self.operation)
        with self.assertRaises(ValueError):
            workspace.run("example", {"dependency": "two"}, self.operation)

    def test_changed_manifest_or_builder_code_invalidates_receipt(self):
        workspace = Workspace(self.root / "run", self.manifest)
        workspace.run("example", {}, self.operation)
        for context in ({"new": "manifest"}, self.manifest):
            with patch("canary_builder.state.controller_identity", return_value=[{"changed": True}]):
                changed = Workspace(self.root / "run", context)
            with self.assertRaises(ValueError):
                changed.run("example", {}, self.operation)

    def test_corrupt_extra_and_symlink_outputs_refused(self):
        for kind in ("corrupt", "extra", "symlink"):
            workspace = Workspace(self.root / kind, self.manifest)
            workspace.run("example", {}, self.operation)
            output = self.root / kind / "example"
            if kind == "corrupt":
                (output / "result.txt").write_text("tampered")
            elif kind == "extra":
                (output / "unreviewed.txt").write_text("extra")
            else:
                (output / "result.txt").unlink()
                (output / "result.txt").symlink_to(ROOT / "README.md")
            with self.assertRaises(ValueError):
                workspace.run("example", {}, self.operation)

    def test_failed_stage_retains_evidence_and_cannot_turn_green(self):
        workspace = Workspace(self.root / "run", self.manifest)
        def fail(output):
            (output / "failure.txt").write_text("failure preserved")
            raise RuntimeError("synthetic failure")
        with self.assertRaises(RuntimeError):
            workspace.run("example", {}, fail)
        self.assertEqual(read_json(self.root / "run/example.json")["status"], "failed")
        with self.assertRaises(ValueError):
            workspace.run("example", {}, self.operation)
        self.assertTrue((self.root / "run/example/failure.txt").exists())


class ResourceTests(Case):
    def test_qualified_docker_desktop_usable_memory_is_admitted(self):
        with patch("canary_builder.doctor.subprocess.check_output", return_value=b'{"NCPU":4,"MemTotal":6210572288}'):
            self.assertEqual(doctor.check("native", True)["status"], "passed")

    def test_two_cpu_vm_and_hosted_memory_shortfall_are_refused(self):
        for role, cpus, memory in [("native", 2, 6210572288), ("native", 4, 4 * 1024**3), ("hosted", 4, 32 * 1024**3), ("hosted", 8, 27 * 1024**3)]:
            with patch("canary_builder.doctor.subprocess.check_output", return_value=json.dumps({"NCPU": cpus, "MemTotal": memory}).encode()):
                with self.assertRaises(ValueError):
                    doctor.check(role, True)

    def test_v2026_11_1_hosted_runner_class_is_admitted(self):
        with patch("canary_builder.doctor.subprocess.check_output", return_value=json.dumps({"NCPU": 8, "MemTotal": 28 * 1024**3}).encode()):
            result = doctor.check("hosted", True)
        self.assertEqual(result["status"], "passed")
        self.assertEqual((result["docker"]["requiredCpus"], result["docker"]["requiredMemoryBytes"]), (8, 28 * 1024**3))


class Phase5Tests(Case):
    def setUp(self):
        super().setUp()
        self.manifest = load(ROOT / "manifests/v2026.11.1.json")

    def prepare(self):
        hosted_receipt, candidate, packages, specs = phase5_inputs(self.root / "inputs", self.manifest)
        output = self.root / "prepared"
        output.mkdir()
        result = phase5.prepare(self.manifest, hosted_receipt, candidate, packages, specs, output)
        self.assertEqual(result["status"], "phase5-adapters-prepared")
        return output

    def test_managed_native_profile_reserves_gateway_peak_memory(self):
        lanes = {lane["name"]: lane for lane in phase5.load_profile(self.manifest)["lanes"]}
        self.assertEqual(lanes["managedNative"]["minMemoryBytes"], 11 * 1024**3)

    def test_prepare_and_collect_all_exact_lanes(self):
        prepared = self.prepare()
        evidence = phase5_evidence(self.root / "evidence", self.manifest, prepared)
        output = self.root / "collected"
        output.mkdir()
        result = phase5.collect(self.manifest, prepared, evidence, output)
        self.assertEqual(result["status"], "phase5-qualified")
        qualification = read_json(output / "LINUX-QUALIFICATION.json")
        self.assertEqual(qualification["sourceCommit"], self.manifest["source"]["commit"])
        self.assertEqual(qualification["checks"]["hosted"]["compilerGraphs"], 36)
        self.assertEqual(qualification["checks"]["hosted"]["hostHeartbeats"], 7)
        self.assertEqual(set(qualification["checks"]), {"hosted", *[lane["name"] for lane in phase5.load_profile(self.manifest)["lanes"]]})
        self.assertFalse(qualification["deployed"])

    def test_failed_or_unverified_lane_is_retained_without_qualification(self):
        prepared = self.prepare()
        evidence = phase5_evidence(self.root / "evidence", self.manifest, prepared, {"managedNative": "failed", "localImage": "unverified"})
        output = self.root / "collected"
        output.mkdir()
        result = phase5.collect(self.manifest, prepared, evidence, output)
        self.assertEqual(result["status"], "phase5-incomplete")
        self.assertFalse((output / "LINUX-QUALIFICATION.json").exists())
        collection = read_json(output / "phase5-collection.json")
        self.assertEqual(collection["lanes"]["managedNative"]["status"], "failed")
        self.assertEqual(collection["lanes"]["localImage"]["status"], "unverified")

    def test_changed_receipt_package_fixture_and_evidence_are_refused(self):
        for kind in ("receipt", "package", "fixture", "evidence"):
            root = self.root / kind
            root.mkdir()
            hosted_receipt, candidate, packages, specs = phase5_inputs(root / "inputs", self.manifest)
            if kind == "receipt":
                hosted_receipt.write_text("{}")
                with self.assertRaisesRegex(ValueError, "trusted hosted receipt changed"):
                    phase5.prepare(self.manifest, hosted_receipt, candidate, packages, specs, root / "missing-output")
                continue
            if kind == "package":
                next(packages.iterdir()).write_text("changed")
                with self.assertRaisesRegex(ValueError, "hosted package bytes differ"):
                    phase5.prepare(self.manifest, hosted_receipt, candidate, packages, specs, root / "missing-output")
                continue
            prepared = root / "prepared"
            prepared.mkdir()
            phase5.prepare(self.manifest, hosted_receipt, candidate, packages, specs, prepared)
            if kind == "fixture":
                value = read_json(prepared / "fixture-specs.json")
                value["lanes"][0]["resources"]["cpus"] += 1
                atomic_json(prepared / "fixture-specs.json", value)
                with self.assertRaisesRegex(ValueError, "fixture specs changed"):
                    phase5.verify_plan_root(self.manifest, prepared)
                continue
            evidence = phase5_evidence(root / "evidence", self.manifest, prepared)
            (evidence / "arm64Consumer/evidence/proof.json").write_text("changed")
            output = root / "collected"
            output.mkdir()
            with self.assertRaisesRegex(ValueError, "lane evidence inventory mismatch"):
                phase5.collect(self.manifest, prepared, evidence, output)

    def test_extra_lane_root_output_is_refused(self):
        prepared = self.prepare()
        evidence = phase5_evidence(self.root / "evidence", self.manifest, prepared)
        (evidence / "arm64Consumer/unreviewed.txt").write_text("extra")
        output = self.root / "collected"
        output.mkdir()
        with self.assertRaisesRegex(ValueError, "lane root inventory mismatch"):
            phase5.collect(self.manifest, prepared, evidence, output)

    def test_profile_requires_disposable_pinned_boundaries(self):
        hosted_receipt, candidate, packages, specs_path = phase5_inputs(self.root / "inputs", self.manifest)
        specs = read_json(specs_path)
        specs["lanes"][0]["execution"]["disposable"] = False
        atomic_json(specs_path, specs)
        output = self.root / "prepared"
        output.mkdir()
        with self.assertRaisesRegex(ValueError, "fixture must be disposable"):
            phase5.prepare(self.manifest, hosted_receipt, candidate, packages, specs_path, output)

    def test_external_adapter_runs_exact_fixture_and_owned_cleanup(self):
        fixture_repo = self.root / "fixture-repo"
        fixture_root = fixture_repo / "fixture"
        fixture_root.mkdir(parents=True)
        checks = phase5.load_profile(self.manifest)["lanes"][0]["requiredChecks"]
        runner = fixture_root / "run.py"
        runner.write_text(
            "import json, os\n"
            "from pathlib import Path\n"
            "root = Path(os.environ['PHASE5_OUTPUT'])\n"
            "plan = Path(os.environ['PHASE5_PLAN_DIR'])\n"
            "packages = Path(os.environ['PHASE5_PACKAGE_DIR'])\n"
            "candidate = Path(os.environ['PHASE5_CANDIDATE_MANIFEST'])\n"
            "assert os.environ['PHASE5_LANE'] == 'arm64Consumer'\n"
            "assert packages == plan / 'packages' and packages.is_dir()\n"
            "assert candidate == plan / 'candidate-manifest.json' and candidate.is_file()\n"
            "assert len(list(packages.iterdir())) == 5\n"
            "(root / 'evidence' / 'fixture.json').write_text(json.dumps({'passed': True, 'candidate': json.loads(candidate.read_text())['hostVersion']}))\n"
            f"checks = {checks!r}\n"
            "(root / 'evidence' / 'fixture-result.json').write_text(json.dumps({'schema': 1, 'status': 'passed', 'checks': {name: {'status': 'passed', 'metrics': {'synthetic': 1}} for name in checks}, 'scopeLimits': ['synthetic test data only'], 'reason': ''}))\n"
        )
        cleanup = fixture_root / "cleanup.py"
        cleanup.write_text("raise SystemExit(0)\n")
        contract = {
            "schema": 1,
            "lane": "arm64Consumer",
            "command": {"argv": [sys.executable, "run.py"], "timeoutSeconds": 30},
            "cleanup": {"argv": [sys.executable, "cleanup.py"], "timeoutSeconds": 30},
            "resultFile": "evidence/fixture-result.json",
            "evidenceDirectory": "evidence",
            "environment": [],
            "cleanupScope": "fixture-owned-only",
        }
        atomic_json(fixture_root / "contract.json", contract)
        subprocess.run(["git", "-C", str(fixture_repo), "init", "-b", "main"], check=True, stdout=subprocess.DEVNULL)
        subprocess.run(["git", "-C", str(fixture_repo), "-c", "user.name=Synthetic", "-c", "user.email=test@example.invalid", "add", "."], check=True)
        subprocess.run(["git", "-C", str(fixture_repo), "-c", "user.name=Synthetic", "-c", "user.email=test@example.invalid", "commit", "-m", "fixture"], check=True, stdout=subprocess.DEVNULL)
        fixture_commit = subprocess.check_output(["git", "-C", str(fixture_repo), "rev-parse", "HEAD"], text=True).strip()
        fixture_inventory = self.root / "fixture-inventory.json"
        atomic_json(fixture_inventory, {"schema": 1, "files": inventory(fixture_root)})

        hosted_receipt, candidate, packages, specs_path = phase5_inputs(self.root / "inputs", self.manifest)
        specs = read_json(specs_path)
        controller_path = ROOT / "phase5-adapters/run-adapter.py"
        first = specs["lanes"][0]
        first["controller"] = {"repository": "openclaw-canary-builder", "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(), "path": "phase5-adapters/run-adapter.py", **digest(controller_path)}
        first["fixture"] = {"repository": "synthetic-fixture", "commit": fixture_commit, "profile": "contract.json", "inventorySha256": digest(fixture_inventory)["sha256"]}
        atomic_json(specs_path, specs)
        prepared = self.root / "prepared"
        prepared.mkdir()
        phase5.prepare(self.manifest, hosted_receipt, candidate, packages, specs_path, prepared)
        output = self.root / "adapter-output"
        subprocess.run([
            sys.executable,
            str(controller_path),
            "--manifest", str(ROOT / "manifests/v2026.11.1.json"),
            "--plan-dir", str(prepared),
            "--lane", "arm64Consumer",
            "--fixture-root", str(fixture_root),
            "--fixture-inventory", str(fixture_inventory),
            "--output", str(output),
        ], cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
        receipt = read_json(output / "receipt.json")
        self.assertEqual(receipt["status"], "passed")
        self.assertEqual(receipt["cleanup"], {"status": "passed", "ownedResourcesOnly": True})
        self.assertEqual({path.name for path in output.iterdir()}, {"receipt.json", "evidence"})
        self.assertIn("fixture-result.json", {row["path"] for row in inventory(output / "evidence")})

    def test_external_adapter_refuses_fixture_mutation_of_authenticated_plan(self):
        fixture_repo = self.root / "fixture-repo"
        fixture_root = fixture_repo / "fixture"
        fixture_root.mkdir(parents=True)
        (fixture_root / "run.py").write_text(
            "import json, os\n"
            "from pathlib import Path\n"
            "plan_path = Path(os.environ['PHASE5_PLAN_DIR']) / 'phase5-plan.json'\n"
            "plan = json.loads(plan_path.read_text())\n"
            "plan['hosted']['hostHeartbeats'] += 1\n"
            "plan_path.write_text(json.dumps(plan, sort_keys=True, separators=(',', ':')) + '\\n')\n"
        )
        (fixture_root / "cleanup.py").write_text("raise SystemExit(0)\n")
        atomic_json(fixture_root / "contract.json", {
            "schema": 1,
            "lane": "arm64Consumer",
            "command": {"argv": [sys.executable, "run.py"], "timeoutSeconds": 30},
            "cleanup": {"argv": [sys.executable, "cleanup.py"], "timeoutSeconds": 30},
            "resultFile": "evidence/fixture-result.json",
            "evidenceDirectory": "evidence",
            "environment": [],
            "cleanupScope": "fixture-owned-only",
        })
        subprocess.run(["git", "-C", str(fixture_repo), "init", "-b", "main"], check=True, stdout=subprocess.DEVNULL)
        subprocess.run(["git", "-C", str(fixture_repo), "-c", "user.name=Synthetic", "-c", "user.email=test@example.invalid", "add", "."], check=True)
        subprocess.run(["git", "-C", str(fixture_repo), "-c", "user.name=Synthetic", "-c", "user.email=test@example.invalid", "commit", "-m", "fixture"], check=True, stdout=subprocess.DEVNULL)
        fixture_commit = subprocess.check_output(["git", "-C", str(fixture_repo), "rev-parse", "HEAD"], text=True).strip()
        fixture_inventory = self.root / "fixture-inventory.json"
        atomic_json(fixture_inventory, {"schema": 1, "files": inventory(fixture_root)})

        hosted_receipt, candidate, packages, specs_path = phase5_inputs(self.root / "inputs", self.manifest)
        specs = read_json(specs_path)
        controller_path = ROOT / "phase5-adapters/run-adapter.py"
        first = specs["lanes"][0]
        first["controller"] = {"repository": "openclaw-canary-builder", "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(), "path": "phase5-adapters/run-adapter.py", **digest(controller_path)}
        first["fixture"] = {"repository": "synthetic-fixture", "commit": fixture_commit, "profile": "contract.json", "inventorySha256": digest(fixture_inventory)["sha256"]}
        atomic_json(specs_path, specs)
        prepared = self.root / "prepared"
        prepared.mkdir()
        phase5.prepare(self.manifest, hosted_receipt, candidate, packages, specs_path, prepared)
        output = self.root / "adapter-output"
        result = subprocess.run([
            sys.executable,
            str(controller_path),
            "--manifest", str(ROOT / "manifests/v2026.11.1.json"),
            "--plan-dir", str(prepared),
            "--lane", "arm64Consumer",
            "--fixture-root", str(fixture_root),
            "--fixture-inventory", str(fixture_inventory),
            "--output", str(output),
        ], cwd=ROOT, text=True, capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Phase 5 plan changed during fixture execution", result.stderr)
        self.assertFalse((output / "receipt.json").exists())


class AssetTests(Case):
    def test_complete_synthetic_release_and_declared_limits(self):
        m, directory, _ = release_fixture(self.root)
        result = assets.verify(m, directory)
        self.assertEqual(len(result["archives"]), 5)
        self.assertEqual(result["scopeLimits"], ["synthetic test data only"])

    def test_corrective_release_references_prior_runtime_lanes_without_relabeling_them(self):
        m, directory, _ = release_fixture(self.root)
        correction = {
            "baseSourceCommit": "1" * 40,
            "priorReleaseId": 123,
            "priorReleaseTag": "canary-v2026.10.3-infuse-bundle-1111111111-r1",
            "priorQualificationSha256": "2" * 64,
            "priorCandidateManifestSha256": "3" * 64,
            "priorPhase5PlanSha256": "4" * 64,
            "changedFiles": ["extensions/mattermost/openclaw.channel.json"],
        }
        m["referenceEvidence"]["correction"] = correction
        qualification_path = directory / "LINUX-QUALIFICATION.json"
        qualification = read_json(qualification_path)
        qualification.update(
            status="passed-correction-with-referenced-runtime-lanes",
            correction=correction,
            recordedBeforeReleasePublication=True,
            deployed=False,
            checks={
                "hosted": {"status": "passed"},
                "packagedActivation": {
                    "status": "passed",
                    "metrics": {
                        "generatedMetadataCheck": True,
                        "focusedRegression": True,
                        "releaseCheck": {
                            "status": "build-passed-with-inherited-preflight-drift",
                            "buildPassed": True,
                            "baseSourceCommit": correction["baseSourceCommit"],
                            "candidateSourceCommit": m["source"]["commit"],
                            "failedChecks": ["Control UI locale bundles", "config docs baseline"],
                            "unchangedInputs": [
                                {
                                    "path": "docs/.generated/config-baseline.sha256",
                                    "baseSha256": "5" * 64,
                                    "candidateSha256": "5" * 64,
                                },
                                {
                                    "path": "ui/src/i18n/.i18n/catalog-fallbacks.json",
                                    "baseSha256": "6" * 64,
                                    "candidateSha256": "6" * 64,
                                },
                            ],
                        },
                        "archiveInstall": True,
                        "packedConfigValidation": True,
                        "effectiveFeatureAssertions": True,
                    },
                },
                **{
                    lane: {"status": "referenced", "qualificationSha256": correction["priorQualificationSha256"]}
                    for lane in assets.RUNTIME_LANES
                },
            },
        )
        atomic_json(qualification_path, qualification)
        (directory / "SHA256SUMS").write_text("".join(f"{digest(path)['sha256']}  {path.name}\n" for path in sorted(directory.iterdir()) if path.name != "SHA256SUMS"))
        m["assets"] = [{"name": path.name, **digest(path)} for path in sorted(directory.iterdir())]

        result = assets.verify(m, directory)
        self.assertEqual(result["qualificationOrigin"], "fresh-package-correction-with-referenced-runtime-lanes")

        qualification["checks"]["packagedActivation"]["metrics"]["releaseCheck"]["unchangedInputs"][0]["candidateSha256"] = "7" * 64
        atomic_json(qualification_path, qualification)
        (directory / "SHA256SUMS").write_text("".join(f"{digest(path)['sha256']}  {path.name}\n" for path in sorted(directory.iterdir()) if path.name != "SHA256SUMS"))
        m["assets"] = [{"name": path.name, **digest(path)} for path in sorted(directory.iterdir())]
        with self.assertRaisesRegex(ValueError, "inherited release input changed"):
            assets.verify(m, directory)

        qualification["checks"]["packagedActivation"]["metrics"]["releaseCheck"]["unchangedInputs"][0]["candidateSha256"] = "5" * 64

        qualification["checks"]["amd64"] = {"status": "passed"}
        atomic_json(qualification_path, qualification)
        (directory / "SHA256SUMS").write_text("".join(f"{digest(path)['sha256']}  {path.name}\n" for path in sorted(directory.iterdir()) if path.name != "SHA256SUMS"))
        m["assets"] = [{"name": path.name, **digest(path)} for path in sorted(directory.iterdir())]
        with self.assertRaisesRegex(ValueError, "explicitly referenced: amd64"):
            assets.verify(m, directory)

    def test_corrupted_asset_fails_before_metadata(self):
        m, directory, _ = release_fixture(self.root)
        (directory / "candidate-manifest.json").write_text("invalid JSON")
        with self.assertRaisesRegex(ValueError, "pin mismatch"):
            assets.verify(m, directory)

    def test_rehashed_stale_core_backpointer_still_refused(self):
        m, directory, _ = release_fixture(self.root)
        p = directory / "candidate-manifest.json"
        value = read_json(p)
        value["hostCommit"] = "4e808f634d" + "0" * 30
        atomic_json(p, value)
        next(a for a in m["assets"] if a["name"] == p.name).update(digest(p))
        with self.assertRaisesRegex(ValueError, "dependency pin mismatch"):
            assets.verify(m, directory)

    def test_private_or_extra_public_asset_refused(self):
        m, directory, _ = release_fixture(self.root)
        (directory / "private-company-source.tar.gz").write_text("private")
        with self.assertRaises(ValueError):
            assets.verify(m, directory)

    def test_archive_traversal_duplicate_and_link_refused(self):
        for kind in ("traversal", "duplicate", "link"):
            path = self.root / (kind + ".tgz")
            with tarfile.open(path, "w:gz") as archive:
                entry = tarfile.TarInfo("../outside" if kind == "traversal" else "package/package.json")
                if kind == "link":
                    entry.type = tarfile.SYMTYPE
                    entry.linkname = "/etc/passwd"
                archive.addfile(entry, io.BytesIO(b""))
                if kind == "duplicate":
                    archive.addfile(entry, io.BytesIO(b""))
            with self.assertRaises((ValueError, json.JSONDecodeError)):
                assets.inspect_archive(path, "openclaw", "2026.10.3")


class HandoffTests(Case):
    def test_private_bundle_re_roots_without_mac_paths_and_hydrates_missing_dirs(self):
        sha, core_bytes = private_fixture(self.root / "inputs", self.manifest)
        output = self.root / "packed"
        output.mkdir()
        result = handoff.prepare(self.manifest, self.root / "inputs", sha, output)
        fresh = self.root / "new-machine"
        fresh.mkdir()
        handoff.extract(output / "swarm-upgrade-inputs.tar.gz", result["archive"]["sha256"], fresh)
        root = fresh / "private-inputs"
        def download(command, **_):
            Path(command[command.index("--output") + 1]).write_bytes(core_bytes)
        with patch("canary_builder.hydrate.subprocess.run", side_effect=download):
            receipt = hydrate.hydrate(root, sha)
        self.assertEqual(receipt["files"], 6)
        self.assertFalse(receipt["candidateCodeExecuted"])
        self.assertNotIn("/Users/", (root / "PRIVATE-INPUTS.md").read_text())

    def test_changed_private_input_refused_before_pack(self):
        sha, _ = private_fixture(self.root / "inputs", self.manifest)
        (self.root / "inputs/swarm-source/check.txt").write_text("changed")
        output = self.root / "out"
        output.mkdir()
        with self.assertRaises(ValueError):
            handoff.prepare(self.manifest, self.root / "inputs", sha, output)
        self.assertFalse((output / "swarm-upgrade-inputs.tar.gz").exists())

    def test_symlink_parent_and_wrong_hydration_pin_refused(self):
        sha, _ = private_fixture(self.root / "inputs", self.manifest)
        with self.assertRaises(ValueError):
            hydrate.metadata(self.root / "inputs", "0" * 64)
        base = self.root / "inputs/swarm-source"
        (base / "check.txt").unlink()
        (base / "check.txt").symlink_to(ROOT / "README.md")
        with self.assertRaises(ValueError):
            hydrate.verify(self.root / "inputs", hydrate.metadata(self.root / "inputs", sha), omitted=True)

    def test_unsafe_archive_refused_before_any_member_write(self):
        path = self.root / "bad.tar.gz"
        with tarfile.open(path, "w:gz") as archive:
            entry = tarfile.TarInfo("../escape")
            archive.addfile(entry, io.BytesIO(b""))
        output = self.root / "out"
        output.mkdir()
        with self.assertRaises(ValueError):
            handoff.extract(path, digest(path)["sha256"], output)
        self.assertEqual(list(output.iterdir()), [])


class FakeGitHub:
    def __init__(self, m):
        self.m = m
        self.release = None
        self.creates = self.publishes = self.uploads = 0
        self.fail_upload = self.fail_create = False
        self.tag = None

    def find(self, tag):
        return self.release

    def get(self, release_id):
        if self.release["id"] != release_id:
            raise ValueError("wrong release ID")
        return copy.deepcopy(self.release)

    def create(self, m, notes):
        self.creates += 1
        self.release = {"id": 123, "tag_name": m["release"]["tag"], "target_commitish": m["source"]["commit"], "prerelease": True, "draft": True, "name": m["release"]["title"], "body": notes, "assets": []}
        if self.fail_create:
            self.fail_create = False
            raise OSError("unknown create outcome")
        return copy.deepcopy(self.release)

    def upload(self, release_id, path):
        if self.fail_upload and self.uploads == 1:
            self.fail_upload = False
            raise OSError("unknown upload outcome")
        self.uploads += 1
        pin = digest(path)
        self.release["assets"].append({"name": path.name, "size": pin["bytes"], "digest": "sha256:" + pin["sha256"]})

    def publish(self, release_id):
        self.publishes += 1
        self.release["draft"] = False
        self.tag = self.m["source"]["commit"]
        return copy.deepcopy(self.release)

    def tag_commit(self, tag):
        return self.tag


class PublicationTests(Case):
    def setUp(self):
        super().setUp()
        self.m, self.directory, self.notes = release_fixture(self.root)
        self.api = FakeGitHub(self.m)
        self.journal = self.root / "journal.json"

    def execute(self):
        return publish.execute(self.m, self.directory, self.notes, self.journal, self.api)

    def test_manual_plan_has_only_package_prerelease_effect(self):
        plan = publish.plan(self.m, self.directory, self.notes)
        self.assertFalse(plan["deployment"])
        self.assertFalse(plan["imageRegistryPublication"])
        self.assertEqual(self.api.creates, 0)

    def test_draft_id_upload_checks_and_idempotent_publication(self):
        self.execute()
        self.assertEqual((self.api.creates, self.api.uploads, self.api.publishes), (1, 9, 1))
        self.execute()
        self.assertEqual((self.api.creates, self.api.uploads, self.api.publishes), (1, 9, 1))
        self.assertEqual(read_json(self.journal)["releaseId"], 123)

    def test_unknown_create_outcome_reuses_draft(self):
        self.api.fail_create = True
        with self.assertRaises(OSError):
            self.execute()
        self.execute()
        self.assertEqual(self.api.creates, 1)

    def test_partial_upload_reuses_release_and_uploaded_assets(self):
        self.api.fail_upload = True
        with self.assertRaises(OSError):
            self.execute()
        self.execute()
        self.assertEqual((self.api.creates, self.api.uploads, self.api.publishes), (1, 9, 1))

    def test_remote_mismatched_asset_refuses_publication(self):
        self.api.create(self.m, self.notes.read_text())
        self.api.release["assets"] = [{"name": self.m["assets"][0]["name"], "size": 1, "digest": "sha256:" + "0" * 64}]
        with self.assertRaises(ValueError):
            self.execute()
        self.assertEqual(self.api.publishes, 0)

    def test_existing_wrong_tag_refused_before_external_write(self):
        self.api.tag = "0" * 40
        with self.assertRaises(ValueError):
            self.execute()
        self.assertEqual(self.api.creates, 0)

    def test_changed_reviewed_notes_cannot_resume_an_existing_publication(self):
        self.api.fail_upload = True
        with self.assertRaises(OSError):
            self.execute()
        self.notes.write_text("New reviewed notes.\n")
        self.m["release"]["notesSha256"] = digest(self.notes)["sha256"]
        with self.assertRaisesRegex(ValueError, "publication inputs changed"):
            self.execute()
        self.assertEqual(self.api.publishes, 0)


if __name__ == "__main__":
    unittest.main()
