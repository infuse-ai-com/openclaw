import importlib.util
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "phase5-fixtures/consumer"
SCRIPT = FIXTURE / "run_lane.py"
SPEC = importlib.util.spec_from_file_location("phase5_consumer_run_lane", SCRIPT)
RUN_LANE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUN_LANE)


class Phase5ConsumerFixtureTests(unittest.TestCase):
    def test_candidate_contract_is_candidate_agnostic_and_images_are_pinned(self):
        contract = json.loads((FIXTURE / "candidate-contract.json").read_bytes())
        self.assertEqual((contract["schema"], contract["version"]), (1, "2026.11.3"))
        for field in ("sourceCommit", "sourceLockSha256", "buildTimestamp", "sourcePackageJsonSha256"):
            self.assertNotIn(field, contract)
        self.assertEqual(contract["node"]["version"], "24.22.1")
        self.assertEqual(set(contract["node"]["images"]), {"arm64", "amd64"})
        for image in contract["node"]["images"].values():
            self.assertRegex(image, r"^docker\.io/library/node@sha256:[a-f0-9]{64}$")
        self.assertEqual(contract["workspaceOverrides"], {})

    def test_consumer_uses_the_sealed_candidate_identity_without_stale_literals(self):
        source = (FIXTURE / "run-consumer.mjs").read_text()
        fixture_source = "\n".join(path.read_text() for path in FIXTURE.iterdir() if path.is_file())
        self.assertIn("assert.equal(plan.sourceCommit, candidate.hostCommit)", source)
        self.assertIn("commit: candidate.hostCommit", source)
        self.assertIn("sourcePackageJsonSha256 = createHash", source)
        self.assertNotIn("f5fce6c00efea370749cd56d00c7600048e0e080", fixture_source)

    def test_contracts_close_the_profile_checks_and_import_no_environment(self):
        profile = {lane["name"]: lane for lane in json.loads((ROOT / "phase5-profiles/v2026.11.3.json").read_bytes())["lanes"]}
        files = {
            "arm64Consumer": "arm64-consumer.json",
            "publicInventory": "public-inventory.json",
            "builderBoundary": "builder-boundary.json",
        }
        for lane, filename in files.items():
            with self.subTest(lane=lane):
                contract = json.loads((FIXTURE / "contracts" / filename).read_bytes())
                self.assertEqual(set(contract), {"schema", "lane", "command", "cleanup", "resultFile", "evidenceDirectory", "environment", "cleanupScope"})
                self.assertEqual((contract["schema"], contract["lane"], contract["environment"], contract["cleanupScope"]), (1, lane, [], "fixture-owned-only"))
                self.assertEqual(contract["command"]["argv"][-1], lane)
                self.assertEqual(contract["cleanup"]["argv"], ["python3", "-B", "cleanup.py"])
                self.assertEqual(set(RUN_LANE.LANE_CHECKS[lane]), set(profile[lane]["requiredChecks"]))

    def test_unreviewed_host_environment_is_rejected_before_execution(self):
        values = {
            "PHASE5_OUTPUT": "/missing",
            "PHASE5_PLAN_DIR": "/missing",
            "PHASE5_PACKAGE_DIR": "/missing/packages",
            "PHASE5_CANDIDATE_MANIFEST": "/missing/candidate-manifest.json",
            "PHASE5_LANE": "arm64Consumer",
            "PATH": "/usr/bin",
            "UNREVIEWED_VALUE": "present",
        }
        with patch.dict(os.environ, values, clear=True):
            with self.assertRaisesRegex(ValueError, "unreviewed environment"):
                RUN_LANE.environment()

    def test_known_macos_runtime_injections_are_bounded(self):
        self.assertIn("LC_CTYPE", RUN_LANE.ADAPTER_ENVIRONMENT)
        self.assertIn("__CF_USER_TEXT_ENCODING", RUN_LANE.ADAPTER_ENVIRONMENT)
        values = {"LC_CTYPE": "unexpected", "__CF_USER_TEXT_ENCODING": "unexpected"}
        with patch.dict(os.environ, values, clear=True):
            with self.assertRaisesRegex(ValueError, "locale injection"):
                RUN_LANE.environment()

    def test_owner_labels_are_exact_and_argv_only(self):
        arguments = RUN_LANE.label_arguments("a" * 32, "arm64Consumer")
        self.assertEqual(arguments, ["--label", f"{RUN_LANE.CUSTODY_LABEL}={'a' * 32}", "--label", f"{RUN_LANE.LANE_LABEL}=arm64Consumer"])
        self.assertTrue(all(isinstance(item, str) and "\x00" not in item for item in arguments))

    def test_preflight_selects_the_profile_architecture(self):
        class DockerStub:
            def __init__(self):
                self.image = None

            def json(self, arguments, _label):
                if arguments[0] == "info":
                    return {"NCPU": 8, "MemTotal": 8 * 1024**3}
                self.image = arguments[-1]
                architecture = "amd64" if "e1582112" in self.image else "arm64"
                return [{"Os": "linux", "Architecture": architecture, "Id": "sha256:image"}]

        for lane, architecture in (("arm64Consumer", "arm64"), ("publicInventory", "arm64"), ("builderBoundary", "amd64")):
            with self.subTest(lane=lane):
                docker = DockerStub()
                image, platform, host = RUN_LANE.preflight(docker, lane)
                self.assertEqual((image, platform, host["architecture"]),
                                 (RUN_LANE.CONTRACT["node"]["images"][architecture], f"linux/{architecture}", architecture))


if __name__ == "__main__":
    unittest.main()
