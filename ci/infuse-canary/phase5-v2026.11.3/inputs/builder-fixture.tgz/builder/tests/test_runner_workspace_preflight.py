import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).absolute().parents[1]
SCRIPT = ROOT / "scripts/runner_workspace_preflight.py"

SPEC = importlib.util.spec_from_file_location("runner_workspace_preflight", SCRIPT)
PREFLIGHT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PREFLIGHT)


class RunnerWorkspacePreflightTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(
            prefix="runner-workspace-test-",
            dir="/private/tmp" if Path("/private/tmp").exists() else None,
        )
        self.addCleanup(self.temporary.cleanup)
        self.runner_root = Path(self.temporary.name) / "runner"
        self.runner_root.mkdir()

    def test_runner_owned_workspace_is_writable_and_probe_is_removed(self):
        value = PREFLIGHT.verify(self.runner_root, allow_root_for_tests=True)
        self.assertTrue(value["writable"])
        self.assertEqual(value["runnerUid"], os.geteuid())
        self.assertEqual(list((self.runner_root / "_work" / "_temp").iterdir()), [])
        for path in (self.runner_root / "_diag", self.runner_root / "_work", self.runner_root / "_work" / "_temp"):
            self.assertEqual(path.stat().st_uid, os.geteuid())

    def test_unwritable_temp_parent_is_rejected(self):
        temp_root = self.runner_root / "_work" / "_temp"
        temp_root.mkdir(parents=True)
        temp_root.chmod(0o555)
        try:
            with self.assertRaisesRegex(ValueError, "not owner-writable"):
                PREFLIGHT.verify(self.runner_root, allow_root_for_tests=True)
        finally:
            temp_root.chmod(0o755)

    def test_symlinked_mutable_directory_is_rejected(self):
        target = Path(self.temporary.name) / "outside"
        target.mkdir()
        (self.runner_root / "_work").symlink_to(target, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, "not a real directory"):
            PREFLIGHT.verify(self.runner_root, allow_root_for_tests=True)

    @unittest.skipUnless(os.geteuid() == 0, "root-only CI safety assertion")
    def test_cli_refuses_root(self):
        result = subprocess.run(
            [sys.executable, "-B", str(SCRIPT), "--runner-root", str(self.runner_root)],
            text=True,
            capture_output=True,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("dedicated runner account, not root", result.stderr)


if __name__ == "__main__":
    unittest.main()
