import assert from "node:assert/strict";
import test from "node:test";
import { assertActualGraphContract, assertScopedPolicyProbePassed, prepareScopedPolicyProbe, resolveGraphEdge } from "./actual-graph-contract.mjs";
import { mailauthFixture } from "./graph-fixtures.mjs";

test("discarded marker preserves actual graph and accepts only a no-mutation result", () => {
  const input = mailauthFixture();
  const before = JSON.stringify(input.lock);
  const probe = prepareScopedPolicyProbe(input);
  assert.equal(probe.validationClone.packages["node_modules/openclaw"].hasShrinkwrap, true);
  assert.equal(JSON.stringify(input.lock), before);
  assertScopedPolicyProbePassed({ ...probe, originalLock: input.lock, disabledSources: [] });
  probe.validationClone.packages["node_modules/undici"].version = "8.11.2";
  assert.throws(() => assertScopedPolicyProbePassed({ ...probe, originalLock: input.lock, disabledSources: [] }), /changed more/);
});

for (const field of ["optionalDependencies", "peerDependencies", "devDependencies"]) {
  test(`additional root ${field} refuses the marker equivalence`, () => {
    const input = mailauthFixture();
    input.lock.packages[""][field] = { mailauth: "5.0.3" };
    assert.throws(() => prepareScopedPolicyProbe(input), /additional incoming root edge/);
  });
}
test("another dependency on the consumer root is refused", () => {
  const input = mailauthFixture();
  input.lock.packages[""].dependencies.mailauth = "5.0.3";
  assert.throws(() => prepareScopedPolicyProbe(input));
});
for (const workspacePolicy of [{ openclaw: "2026.10.2" }, { "openclaw@2026.10.2": { undici: "8.10.2" } },
  { mailauth: { openclaw: "2026.10.2" } }, { mailauth: "npm:openclaw@2026.10.2" }]) {
  test(`incoming host policy ${JSON.stringify(workspacePolicy)} is refused`, () => {
    assert.throws(() => prepareScopedPolicyProbe({ ...mailauthFixture(), workspacePolicy }), /synthetic host carrier/);
  });
}
test("host edge drift from the archive is refused", () => {
  const input = mailauthFixture();
  input.lock.packages["node_modules/openclaw"].dependencies = { mailauth: "5.0.4" };
  assert.throws(() => prepareScopedPolicyProbe(input), /authenticated archive/);
});
test("missing required edge and unreachable registry rows are refused", () => {
  const missing = mailauthFixture();
  delete missing.lock.packages["node_modules/undici"];
  assert.throws(() => assertActualGraphContract(missing), /Missing required/);
  const orphan = mailauthFixture();
  orphan.lock.packages["node_modules/orphan"] = { version: "1.0.0" };
  assert.throws(() => assertActualGraphContract(orphan), /effective dependency closure/);
});
test("optional absence is explicit; nearer package occurrence wins resolution", () => {
  const input = mailauthFixture("optionalDependencies");
  delete input.lock.packages["node_modules/undici"];
  assert.equal(assertActualGraphContract(input).optionalMissingEdges, 1);
  const nested = mailauthFixture();
  nested.lock.packages["node_modules/mailauth/node_modules/undici"] = { version: "8.10.2" };
  assert.equal(resolveGraphEdge(nested.lock.packages, "node_modules/mailauth", "undici"), "node_modules/mailauth/node_modules/undici");
});
test("a real conflict source always fails, including a nearer dependency shrinkwrap", () => {
  const input = mailauthFixture("dependencies", "8.11.2", true);
  const probe = prepareScopedPolicyProbe(input);
  assert.throws(() => assertScopedPolicyProbePassed({ ...probe, originalLock: input.lock, disabledSources: ["node_modules/mailauth"] }), /violates full workspace scoped policy/);
});
