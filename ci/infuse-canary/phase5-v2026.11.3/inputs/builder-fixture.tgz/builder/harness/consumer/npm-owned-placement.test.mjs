import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { classifyNpmOwnedPlacement } from "./npm-owned-placement.mjs";

const NPM_ROOT = "node_modules/npm";
const CHALK = `${NPM_ROOT}/node_modules/chalk`;
const AGENT = `${NPM_ROOT}/node_modules/@npmcli/agent`;
const BASE = `${AGENT}/node_modules/agent-base`;
const SCOPED = `${NPM_ROOT}/node_modules/@sigstore/verify`;
// Real hashes of synthetic fixture bytes; no npm archive or candidate code.
const integrity = (bytes) => `sha512-${createHash("sha512").update(bytes).digest("base64")}`;

function finding(path, version, expectedSpec = "7.1.4") {
  const names = path.slice("node_modules/".length).split("/node_modules/");
  const packagePath = [];
  for (const name of names) packagePath.push({ name, path: `${packagePath.length ? `${packagePath.at(-1).path}/` : ""}node_modules/${name}` });
  return { path, packageName: names.at(-1), actualPackageName: names.at(-1), actualVersion: version, expectedSpec, packagePath };
}

function fixture() {
  const npmTarballIntegrity = integrity("trusted synthetic npm inventory bytes");
  return {
    registryLock: { lockfileVersion: 3, packages: {
      [NPM_ROOT]: { version: "12.1.0", integrity: npmTarballIntegrity },
      [CHALK]: { version: "5.6.2", inBundle: true },
      [AGENT]: { version: "4.0.2", inBundle: true },
      [BASE]: { version: "9.0.0", inBundle: true },
      [SCOPED]: { version: "4.0.0", inBundle: true },
    } },
    rawPlacementViolations: [finding(CHALK, "5.6.2", "6.0.0"), finding(BASE, "9.0.0")],
    npmTarballIntegrity,
    authenticatedNpmManifests: new Map([
      [NPM_ROOT, { name: "npm", version: "12.1.0" }],
      [CHALK, { name: "chalk", version: "5.6.2" }],
      [AGENT, { name: "@npmcli/agent", version: "4.0.2" }],
      [BASE, { name: "agent-base", version: "9.0.0" }],
      [SCOPED, { name: "@sigstore/verify", version: "4.0.0" }],
    ]),
  };
}

const snapshot = (input) => JSON.stringify({ ...input, authenticatedNpmManifests: [...input.authenticatedNpmManifests] });
function frozen(input) {
  const freeze = (value) => {
    if (value && typeof value === "object") {
      for (const child of value instanceof Map ? value.values() : Object.values(value)) freeze(child);
      Object.freeze(value);
    }
  };
  freeze(input);
  return input;
}
function classify(input) {
  const before = snapshot(input);
  try { return classifyNpmOwnedPlacement(frozen(input)); }
  finally { assert.equal(snapshot(input), before, "Classifier mutated fixture data"); }
}

test("exact direct, scoped and nested npm-owned findings are admitted, with full inventory custody", () => {
  const input = fixture();
  input.rawPlacementViolations.push(finding(SCOPED, "4.0.0"));
  const result = classify(input);
  assert.deepEqual(result, { admitted: input.rawPlacementViolations, remaining: [], ownedInventoryCount: 4 });
  assert.equal(result.admitted[0], input.rawPlacementViolations[0]);
});

for (const path of ["node_modules/chalk", "node_modules/npm-other/node_modules/chalk", "node_modules/other/node_modules/npm/node_modules/chalk"]) {
  test(`same-name ordinary occurrence remains an error: ${path}`, () => {
    const input = fixture();
    input.registryLock.packages[path] = { version: "5.6.2", inBundle: true };
    const ordinary = finding(path, "5.6.2", "6.0.0");
    input.rawPlacementViolations.splice(1, 0, ordinary);
    const result = classify(input);
    assert.deepEqual(result.remaining, [ordinary]);
    assert.deepEqual(result.admitted, [input.rawPlacementViolations[0], input.rawPlacementViolations[2]]);
    assert.equal(result.remaining[0], ordinary);
  });
}

for (const [name, change, pattern] of [
  ["missing bundle marker", (input) => { delete input.registryLock.packages[CHALK].inBundle; }, /bundle marker/],
  ["false bundle marker", (input) => { input.registryLock.packages[CHALK].inBundle = false; }, /bundle marker/],
  ["string bundle marker", (input) => { input.registryLock.packages[CHALK].inBundle = "true"; }, /bundle marker/],
  ["lock name drift", (input) => { input.registryLock.packages[CHALK].name = "changed-name"; }, /name differs/],
  ["null lock name", (input) => { input.registryLock.packages[CHALK].name = null; }, /name differs/],
  ["lock version drift", (input) => { input.registryLock.packages[CHALK].version = "6.0.0"; }, /version differs/],
  ["link instead of package", (input) => { input.registryLock.packages[CHALK].link = true; }, /cannot be a link/],
  ["unreported descendant drift", (input) => { input.registryLock.packages[AGENT].version = "4.0.3"; }, /version differs/],
  ["unreported missing marker", (input) => { delete input.registryLock.packages[AGENT].inBundle; }, /bundle marker/],
  ["missing lock descendant", (input) => { delete input.registryLock.packages[SCOPED]; }, /inventories differ/],
  ["missing authenticated descendant", (input) => { input.authenticatedNpmManifests.delete(CHALK); }, /inventories differ/],
  ["extra lock descendant", (input) => { input.registryLock.packages[`${NPM_ROOT}/node_modules/extra`] = { version: "1.0.0", inBundle: true }; }, /inventories differ/],
  ["manifest name drift", (input) => { input.authenticatedNpmManifests.get(CHALK).name = "changed-name"; }, /manifest identity differs/],
  ["manifest version drift", (input) => { input.authenticatedNpmManifests.get(CHALK).version = "6.0.0"; }, /version differs/],
  ["escaping manifest path", (input) => { input.authenticatedNpmManifests.set(`${NPM_ROOT}/node_modules/../chalk`, { name: "chalk", version: "5.6.2" }); }, /package path/],
  ["escaping scoped manifest path", (input) => { input.authenticatedNpmManifests.set(`${NPM_ROOT}/node_modules/@scope/..`, { name: "@scope/..", version: "5.6.2" }); }, /package path/],
  ["manifest outside npm ownership", (input) => { input.authenticatedNpmManifests.set("node_modules/chalk", { name: "chalk", version: "5.6.2" }); }, /outside the npm-owned subtree/],
  ["unknown npm version", (input) => { input.registryLock.packages[NPM_ROOT].version = "12.2.0"; }, /Unsupported npm carrier version/],
  ["wrong carrier name", (input) => { input.registryLock.packages[NPM_ROOT].name = "not-npm"; }, /carrier name differs/],
  ["null carrier name", (input) => { input.registryLock.packages[NPM_ROOT].name = null; }, /carrier name differs/],
  ["wrong root manifest", (input) => { input.authenticatedNpmManifests.get(NPM_ROOT).version = "12.2.0"; }, /root manifest differs/],
  ["missing root manifest", (input) => { input.authenticatedNpmManifests.delete(NPM_ROOT); }, /root manifest differs/],
  ["tarball integrity mismatch", (input) => { input.npmTarballIntegrity = integrity("different authenticated fixture bytes"); }, /integrity differs/],
  ["wrong integrity algorithm", (input) => { input.npmTarballIntegrity = `sha256-${createHash("sha256").update("fixture").digest("base64")}`; }, /sha512 integrity/],
  ["noncanonical integrity", (input) => { input.npmTarballIntegrity += " "; }, /Invalid authenticated npm sha512 integrity/],
]) {
  test(`npm ownership refuses ${name} without editing inputs`, () => {
    const input = fixture(); change(input);
    assert.throws(() => classify(input), pattern);
  });
}

for (const field of ["packageName", "actualPackageName", "actualVersion"]) {
  test(`inconsistent raw finding ${field} remains an error`, () => {
    const input = fixture();
    input.rawPlacementViolations[0][field] = "not-the-authenticated-identity";
    const result = classify(input);
    assert.deepEqual(result.remaining, [input.rawPlacementViolations[0]]);
    assert.deepEqual(result.admitted, [input.rawPlacementViolations[1]]);
  });
}
test("inconsistent raw finding ancestry remains an error", () => {
  const input = fixture();
  input.rawPlacementViolations[0].packagePath[0].path = "node_modules/other";
  const result = classify(input);
  assert.deepEqual(result.remaining, [input.rawPlacementViolations[0]]);
});
test("an exact explicit npm carrier name is accepted", () => {
  const input = fixture(); input.registryLock.packages[NPM_ROOT].name = "npm";
  assert.deepEqual(classify(input).remaining, []);
});
