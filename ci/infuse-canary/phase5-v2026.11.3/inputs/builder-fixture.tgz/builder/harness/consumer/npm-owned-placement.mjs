// Pure supplemental placement classification; no archive or candidate imports.
import assert from "node:assert/strict";

const NPM_ROOT = "node_modules/npm";
const NPM_PREFIX = `${NPM_ROOT}/node_modules/`;
const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);

function packagePath(path) {
  assert(typeof path === "string" && path.startsWith("node_modules/"), "Invalid npm-owned package path");
  const names = path.slice("node_modules/".length).split("/node_modules/");
  const result = [];
  for (const name of names) {
    const components = (name.startsWith("@") ? name.slice(1) : name).split("/");
    assert(/^(?:@[^/\\\s]+\/)?[^/\\\s]+$/.test(name) && components.every((part) => part !== "." && part !== ".."),
      `Invalid npm-owned package path: ${path}`);
    result.push({ name, path: `${result.length ? `${result.at(-1).path}/` : ""}node_modules/${name}` });
  }
  assert.equal(result.at(-1).path, path, "Noncanonical npm-owned package path");
  return result;
}

function assertSha512Integrity(integrity) {
  assert(typeof integrity === "string" && integrity.startsWith("sha512-"), "Expected authenticated npm sha512 integrity");
  const encoded = integrity.slice("sha512-".length);
  const bytes = Buffer.from(encoded, "base64");
  assert(bytes.length === 64 && bytes.toString("base64") === encoded, "Invalid authenticated npm sha512 integrity");
}

/**
 * The caller first authenticates actual npm tarball bytes against frozen pnpm
 * membership/integrity, then supplies strict regular, deduplicated manifests at
 * full lock roots (including node_modules/npm). This does not authenticate bytes
 * itself or replace authored workspace, membership, platform or closure guards.
 */
export function classifyNpmOwnedPlacement({ registryLock, rawPlacementViolations, npmTarballIntegrity, authenticatedNpmManifests }) {
  assert(object(registryLock) && registryLock.lockfileVersion === 3 && object(registryLock.packages), "Expected npm v3 registry lock");
  assert(Array.isArray(rawPlacementViolations), "Expected raw placement findings");
  assert(authenticatedNpmManifests instanceof Map, "Expected authenticated npm manifest Map");
  const packages = registryLock.packages;
  const carrier = packages[NPM_ROOT];
  assert(object(carrier) && carrier.version === "12.1.0", "Unsupported npm carrier version");
  assert.equal(carrier.name === undefined ? "npm" : carrier.name, "npm", "Npm carrier name differs");
  assert.equal(carrier.link, undefined, "Npm carrier cannot be a link");
  assertSha512Integrity(npmTarballIntegrity);
  assert.equal(carrier.integrity, npmTarballIntegrity, "Npm carrier integrity differs from authenticated tarball");
  const rootManifest = authenticatedNpmManifests.get(NPM_ROOT);
  assert(object(rootManifest) && rootManifest.name === "npm" && rootManifest.version === "12.1.0",
    "Authenticated npm root manifest differs");

  const owned = new Map();
  for (const [path, manifest] of authenticatedNpmManifests) {
    assert(path === NPM_ROOT || (typeof path === "string" && path.startsWith(NPM_PREFIX)), "Manifest is outside the npm-owned subtree");
    const ancestry = packagePath(path);
    assert(object(manifest) && manifest.name === ancestry.at(-1).name && typeof manifest.version === "string" && manifest.version.length > 0,
      `Authenticated npm manifest identity differs: ${path}`);
    if (path !== NPM_ROOT) owned.set(path, { manifest, ancestry });
  }
  const lockPaths = Object.keys(packages).filter((path) => path.startsWith(NPM_PREFIX)).sort();
  assert.deepEqual(lockPaths, [...owned.keys()].sort(), "Npm-owned lock and authenticated manifest inventories differ");
  for (const path of lockPaths) {
    const metadata = packages[path];
    const { manifest } = owned.get(path);
    assert(object(metadata) && metadata.inBundle === true, `Npm-owned descendant lacks the required bundle marker: ${path}`);
    assert.equal(metadata.link, undefined, `Npm-owned descendant cannot be a link: ${path}`);
    assert.equal(metadata.name === undefined ? packagePath(path).at(-1).name : metadata.name,
      manifest.name, `Npm-owned descendant name differs: ${path}`);
    assert.equal(metadata.version, manifest.version, `Npm-owned descendant version differs: ${path}`);
  }

  const admitted = [];
  const remaining = [];
  for (const finding of rawPlacementViolations) {
    assert(object(finding) && typeof finding.path === "string", "Invalid raw placement finding");
    const entry = owned.get(finding.path);
    const matchingAncestry = entry && Array.isArray(finding.packagePath) && finding.packagePath.length === entry.ancestry.length &&
      finding.packagePath.every((part, index) => object(part) && part.name === entry.ancestry[index].name && part.path === entry.ancestry[index].path);
    if (entry && matchingAncestry && finding.packageName === entry.manifest.name && finding.actualPackageName === entry.manifest.name &&
        finding.actualVersion === entry.manifest.version) admitted.push(finding);
    else remaining.push(finding);
  }
  // Preserve original findings and order: this partitions an additional audit,
  // without editing the lock, manufacturing overrides or dropping ordinary errors.
  return { admitted, remaining, ownedInventoryCount: owned.size };
}
