// Data-only synthetic controls use exact versions/rules from the pinned source.
export function mailauthFixture(field = "dependencies", version = "8.10.2", nearerShrinkwrap = false) {
  const archiveSpec = "file:./artifacts/core-fixture.tgz";
  const archiveIntegrity = "sha512-synthetic-fixture-only";
  const archiveManifest = { name: "openclaw", version: "2026.10.2", dependencies: { mailauth: "5.0.3" } };
  const lock = { lockfileVersion: 3, packages: {
    "": { dependencies: { openclaw: archiveSpec } },
    "node_modules/openclaw": { version: archiveManifest.version, resolved: "file:artifacts/core-fixture.tgz", integrity: archiveIntegrity, dependencies: archiveManifest.dependencies },
    "node_modules/mailauth": { version: "5.0.3", [field]: { undici: "8.11.2" }, ...(nearerShrinkwrap ? { hasShrinkwrap: true } : {}) },
    "node_modules/undici": { version },
  } };
  return { lock, archiveManifest, archiveSpec, archiveIntegrity,
    workspacePolicy: { "mailauth@5.0.3": { undici: "8.10.2" } } };
}

export function weriftFixture(name = "neoip") {
  const value = mailauthFixture();
  value.archiveManifest.dependencies = { "werift-ice": "0.2.2" };
  value.lock.packages["node_modules/openclaw"].dependencies = value.archiveManifest.dependencies;
  delete value.lock.packages["node_modules/mailauth"];
  delete value.lock.packages["node_modules/undici"];
  value.lock.packages["node_modules/werift-ice"] = { version: "0.2.2", dependencies: { ip: "^1.1.9" } };
  value.lock.packages["node_modules/ip"] = { name, version: "3.1.0" };
  value.workspacePolicy = { "werift-ice@0.2.2": { ip: "npm:neoip@3.1.0" } };
  return value;
}
