"""Collect only the completed, exact, manually requested bound run; no publication."""
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys

def protected_binding(path, expected_sha256):
    data = pathlib.Path(path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected_sha256, "protected binding digest mismatch"
    return json.loads(data)


parser = argparse.ArgumentParser()
parser.add_argument('--binding', required=True)
parser.add_argument('--binding-sha256', required=True)
parser.add_argument('--source-commit', required=True)
parser.add_argument('--ci-commit', required=True)
parser.add_argument('--run-id', type=int, required=True)
parser.add_argument('--artifact-name', required=True)
parser.add_argument('--output-root', required=True)
parser.add_argument('--verifier-sha256', required=True)
args = parser.parse_args()
binding = protected_binding(args.binding, args.binding_sha256)
assert binding['schemaVersion'] == 1 and binding['repository'] == 'aolea/openclaw'
source = args.source_commit
assert source == binding['candidateCommit']
ci = args.ci_commit
run_id = args.run_id
assert run_id > 0
artifact_name = args.artifact_name
assert artifact_name == f'infuse-canary-{source[:10]}-{run_id}-1'
root = pathlib.Path(args.output_root).absolute()
assert not root.exists(), 'collection output already exists'

def gh(*args):
    return subprocess.check_output(['gh', *args], timeout=600)

def save(name, data):
    with (root / name).open('xb') as stream:
        stream.write(data)
    (root / name).chmod(0o600)

run_bytes = gh('api', f'repos/aolea/openclaw/actions/runs/{run_id}')
run = json.loads(run_bytes)
assert run['id'] == run_id and run['event'] == 'workflow_dispatch'
assert run['head_sha'] == ci and run['run_attempt'] == 1
assert run['head_branch'] == binding['bootstrapBranch']
assert run['repository']['full_name'] == 'aolea/openclaw'
assert run['status'] == 'completed' and run['conclusion'] == 'success'
assert run['workflow_id'] == 330254341
root.mkdir(mode=0o700)
save('github-run.json', run_bytes)
artifact_bytes = gh('api', f'repos/aolea/openclaw/actions/runs/{run_id}/artifacts')
artifacts = json.loads(artifact_bytes)
assert artifacts['total_count'] == 1 and len(artifacts['artifacts']) == 1
artifact = artifacts['artifacts'][0]
assert artifact['name'] == artifact_name and artifact['expired'] is False
assert artifact['workflow_run']['id'] == run_id
assert artifact['workflow_run']['head_sha'] == ci
assert 0 < artifact['size_in_bytes'] <= 400 * 1024**2
save('github-artifacts.json', artifact_bytes)
download = root / 'download' / artifact_name
assert not download.exists()
subprocess.run(['gh', 'run', 'download', str(run_id), '--repo', 'aolea/openclaw',
                '--name', artifact_name, '--dir', str(download)], check=True, timeout=600)
verifier = pathlib.Path(__file__).resolve().with_name('trusted-verifier.py')
assert hashlib.sha256(verifier.read_bytes()).hexdigest() == args.verifier_sha256
receipt_bytes = subprocess.check_output([sys.executable, '-I', str(verifier), str(download),
    '--binding', args.binding, '--binding-sha256', args.binding_sha256,
    '--source-commit', source, '--ci-commit', ci], timeout=600)
receipt = json.loads(receipt_bytes)
assert receipt['status'] == 'passed' and receipt['sourceCommit'] == source
save('verified-receipt.json', receipt_bytes)
core = next(p for p in receipt['packages'] if p['name'] == 'openclaw')
manifest = dict(schema=1, hostVersion=binding['version'], hostCommit=source,
    baseCommit=binding['baseCommit'],
    buildTimestamp=binding['buildTimestamp'],
    sourceSnapshotSha256=receipt['sourceSnapshot']['sha256'],
    sourceLockSha256=binding['pnpmLockSha256'],
    hostPackageSha256=core['sha256'], hostPackageFile=pathlib.Path(core['path']).name,
    ciCommit=ci, workflowRunId=run_id, workflowRunAttempt=1,
    published=False, deployed=False)
save('candidate-manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())
save('github-log.txt', gh('run', 'view', str(run_id), '--repo', 'aolea/openclaw', '--log'))
print(json.dumps({'status': 'passed', 'manifest': manifest,
    'manifestSha256': hashlib.sha256((root/'candidate-manifest.json').read_bytes()).hexdigest(),
    'coreArchive': str(download / core['path'])}, indent=2))
