# Working in OpenClaw Canary Builder

Own manifests, trusted controllers and private handoff tools. Keep all new
custom OpenClaw source and build branches in `infuse-ai-com/openclaw`; the
`aolea/openclaw` fork is historical input only. Keep production delivery in
openclaw-k8s-swarm. This repository owns both code and project documentation.

Read README, docs/REPO_MAP.md and the relevant runbook/contract before editing.
`task verify` is the offline gate (Python 3.11+, Node 22+, Git, Task v3).
`python3 -B -m canary_builder --help` is the CLI. No setup/install is needed.

Preserve one manifest-to-binding path. Updating source alone is insufficient:
source snapshot, lock, CI, package, provenance, runtime and handoff pins must
form a complete chain. Review the selected harness lock and its manifest pin
together; `harness-lock.json` retains 10.3 while versioned locks live under
`harness-locks/`. Never bless arbitrary current controller bytes to evade a failure.
Any trusted controller, manifest, dependency or output change invalidates resume.

Candidate source/packages are untrusted data here. Candidate executables run
only in independently probed disposable secretless boundaries. Never substitute
personal or production Gateway/Mattermost profiles; never stop foreign containers.
Retained hosted controllers require a fresh Linux runner and must not be run
on a workstation. They manage a scoped disposable Docker/firewall boundary.

Keep run state, artifacts, raw proofs, private company source, auth and model
credentials outside Git. Never put private handoffs on public GitHub. Only the
nine pinned package/metadata assets are publishable. Preserve failed evidence.
Studio's no-backup/snapshot policy until MVP still governs Studio fixtures.

Use stdlib Python with small modules and behavior tests. Preserve retained
controllers byte-for-byte unless a separately reviewed change needs new locks
and execution proof. Document implementation/runtime/publication separately.
Manual CI is deliberate; do not add schedules or automatic build policies.
The only enabled workflow in the Infuse fork is the default-branch manual
dispatcher. It runs `build/canary-openclaw-vYYYY.MM.DD` at an exact reviewed
SHA on `blacksmith-8vcpu-ubuntu-2404`. A failed controller branch is immutable;
the next controller uses `build/canary-openclaw-vYYYY.MM.DD-rN` with `N >= 2`.
Feature branches and the final
`canary-openclaw-vYYYY.MM.DD` bundle always start from the peeled upstream tag,
never from fork `main` or a previous canary branch.

Owner/reviewer: Infuse AI engineering. Project status, roadmap, lessons, reference
notes and technical contracts all belong under docs/ in this repository. Keep
this single-repository model; do not recreate a companion documentation repo.

When project facts change, reconcile docs/ROADMAP.md and the engineering tracker.
Record durable corrections in docs/LESSONS.md. Inspect current code/release,
ownership and decisions before updating status. See docs/README.md for the
project memory map and archive conventions.
