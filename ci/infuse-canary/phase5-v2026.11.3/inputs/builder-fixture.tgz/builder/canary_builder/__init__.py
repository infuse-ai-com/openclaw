"""Deterministic canary preparation; deployment belongs to the swarm repository."""
