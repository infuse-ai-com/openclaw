"""One explicit command surface for preparation, qualification and publication."""
import argparse
import json
from pathlib import Path
import sys

from . import assets, doctor, handoff, hosted, phase5, publish
from .io import atomic_json, digest, inventory, require
from .manifest import ROOT, load, validate, verify_harness
from .state import Workspace


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", default=str(ROOT / "manifests/v2026.10.3.json"))
    p.add_argument("--workspace", default=str(ROOT / ".canary/reference"))
    commands = p.add_subparsers(dest="command", required=True)
    commands.add_parser("plan")
    d = commands.add_parser("doctor")
    d.add_argument("--role", choices=("native", "hosted"), default="native")
    d.add_argument("--docker", action="store_true")
    q = commands.add_parser("propose")
    q.add_argument("--source", required=True)
    q.add_argument("--upstream-tag", required=True)
    q.add_argument("--build-attempt", type=int, default=1)
    q.add_argument("--output", required=True)
    for name in ("preflight", "prepare-hosted"):
        commands.add_parser(name).add_argument("--source", required=True)
    commands.add_parser("collect-hosted")
    commands.add_parser("dispatch-plan")
    dispatch = commands.add_parser("dispatch-hosted")
    dispatch.add_argument("--execute", action="store_true", required=True)
    dispatch.add_argument("--confirm-ci-commit", required=True)
    commands.add_parser("verify-hosted").add_argument("--artifact-root", required=True)
    phase = commands.add_parser("prepare-phase5")
    phase.add_argument("--hosted-receipt", required=True)
    phase.add_argument("--candidate-manifest", required=True)
    phase.add_argument("--package-dir", required=True)
    phase.add_argument("--fixture-specs", required=True)
    phase = commands.add_parser("collect-phase5")
    phase.add_argument("--plan-dir", required=True)
    phase.add_argument("--evidence-dir", required=True)
    commands.add_parser("fetch-assets")
    commands.add_parser("verify-assets").add_argument("--asset-dir", required=True)
    for name in ("release-plan", "release-publish"):
        release = commands.add_parser(name)
        release.add_argument("--asset-dir", required=True)
        release.add_argument("--notes", required=True)
        if name == "release-publish":
            release.add_argument("--execute", action="store_true", required=True)
            release.add_argument("--confirm-tag", required=True)
    commands.add_parser("release-verify")
    h = commands.add_parser("handoff")
    h.add_argument("--inputs", required=True)
    h.add_argument("--hydration-manifest-sha256", required=True)
    h = commands.add_parser("extract-handoff")
    h.add_argument("--archive", required=True)
    h.add_argument("--archive-sha256", required=True)
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    m = load(args.manifest)
    verify_harness(m)
    name = args.command
    if name == "doctor":
        return doctor.check(args.role, args.docker)
    if name == "plan":
        return {"candidate": m["candidateId"], "source": m["source"], "ci": m["ci"], "stages": ["preflight", "prepare-hosted", "manual source/CI upload review", "dispatch-hosted", "collect-hosted", "prepare-phase5", "execute externally owned disposable adapters", "collect-phase5", "freeze reviewed nine-asset manifest", "verify-assets", "release-plan", "release-publish", "release-verify", "handoff"], "referenceEvidence": m["referenceEvidence"], "newExecutionQualified": False, "deploymentOwner": "openclaw-k8s-swarm"}
    if name == "propose":
        result = validate(
            hosted.propose(m, args.source, args.upstream_tag, args.build_attempt)
        )
        target = Path(args.output).absolute()
        require(not target.exists() and not target.is_symlink(), "proposal path already exists")
        atomic_json(target, result)
        return {"status": "proposed-unqualified", "manifest": str(target), "publicUpload": False}
    if name == "dispatch-plan":
        require(m["ci"]["commit"] != "0" * 40, "record the reviewed uploaded CI commit first")
        policy = hosted.execution_policy(m)
        return {"effect": "one hosted qualification run; no publication/deployment", "repository": m["source"]["repository"], "branch": m["ci"]["branch"], "commit": m["ci"]["commit"], "workflowId": m["ci"]["workflowId"], "timeoutMinutes": policy["timeoutMinutes"], "runnerLabels": list(policy["runnerLabels"]), "enabledAutomatically": False}
    if name == "dispatch-hosted":
        require(args.execute and args.confirm_ci_commit == m["ci"]["commit"] and args.confirm_ci_commit != "0" * 40, "exact CI commit confirmation required")
        api = publish.GitHub(m["source"]["repository"])
        branch = api.request(api.prefix + "/branches/" + __import__("urllib.parse", fromlist=["quote"]).quote(m["ci"]["branch"], safe=""))
        require(branch["commit"]["sha"] == m["ci"]["commit"], "remote CI branch moved")
        workflow = api.request(f"{api.prefix}/actions/workflows/{m['ci']['workflowId']}")
        require(workflow["state"] == "active", "workflow disabled: explicitly enable the chosen manual workflow after resolving any repository usage pause")
        # gh returns an empty successful body for dispatch; handle it separately.
        import subprocess
        command = ["gh", "workflow", "run", str(m["ci"]["workflowId"]), "--repo", m["source"]["repository"]]
        if m["schema"] == 3:
            command.extend(["--ref", "main", "-f", "build_ref=" + m["ci"]["branch"], "-f", "build_sha=" + m["ci"]["commit"]])
        else:
            command.extend(["--ref", m["ci"]["branch"]])
        subprocess.run(command, check=True, timeout=30)
        return {"status": "dispatched-only; record exact run ID and collect completion", "commit": m["ci"]["commit"]}
    if name == "release-plan":
        return publish.plan(m, args.asset_dir, args.notes)
    workspace = Workspace(args.workspace, m)
    if name in ("preflight", "prepare-hosted"):
        result = hosted.source_check(m, args.source)
        def preflight(output):
            atomic_json(output / "source.json", result)
            return result
        receipt = workspace.run("preflight", result, preflight)
        if name == "preflight":
            return receipt
        return workspace.run(name, {"preflightKey": receipt["key"], "preflightOutputs": receipt["outputs"]}, lambda output: hosted.prepare(m, output))
    if name == "verify-assets":
        inputs = inventory(args.asset_dir)
        def verify(output):
            result = assets.verify(m, args.asset_dir)
            atomic_json(output / "assets-receipt.json", result)
            return result
        return workspace.run(name, {"assets": inputs}, verify)
    if name == "fetch-assets":
        return workspace.run(name, {"assets": m["assets"], "tag": m["release"]["tag"]}, lambda output: assets.fetch(m, output))
    if name == "verify-hosted":
        return workspace.run(name, {"artifactInventory": inventory(args.artifact_root)}, lambda output: hosted.verify_download(m, args.artifact_root, output))
    if name == "collect-hosted":
        return workspace.run(name, {"ci": m["ci"]}, lambda output: hosted.collect(m, output))
    if name == "prepare-phase5":
        inputs = {
            "hostedReceipt": digest(args.hosted_receipt),
            "candidateManifest": digest(args.candidate_manifest),
            "packages": inventory(args.package_dir),
            "fixtureSpecs": digest(args.fixture_specs),
        }
        return workspace.run(name, inputs, lambda output: phase5.prepare(m, args.hosted_receipt, args.candidate_manifest, args.package_dir, args.fixture_specs, output))
    if name == "collect-phase5":
        inputs = {"plan": inventory(args.plan_dir), "evidence": inventory(args.evidence_dir)}
        return workspace.run(name, inputs, lambda output: phase5.collect(m, args.plan_dir, args.evidence_dir, output))
    if name == "handoff":
        return workspace.run(name, {"inputInventory": inventory(args.inputs), "hydrationManifestSha256": args.hydration_manifest_sha256}, lambda output: handoff.prepare(m, args.inputs, args.hydration_manifest_sha256, output))
    if name == "extract-handoff":
        return workspace.run(name, {"archive": digest(args.archive), "protectedArchiveSha256": args.archive_sha256}, lambda output: handoff.extract(args.archive, args.archive_sha256, output))
    if name == "release-verify":
        return workspace.run(name, {"release": m["release"], "assets": m["assets"]}, lambda output: publish.verify_public(m, output, publish.GitHub(m["source"]["repository"])))
    if name == "release-publish":
        require(args.execute and args.confirm_tag == m["release"]["tag"], "exact tag confirmation required")
        # Preserve a publication journal across partial external effects. Do not use a
        # failed-stage cache, which would prevent reconciling a known release ID.
        with workspace.lock():
            return publish.execute(m, args.asset_dir, args.notes, workspace.root / "publication-journal.json", publish.GitHub(m["source"]["repository"]))
    raise ValueError("unsupported command")


def entrypoint():
    try:
        result = main()
        # Closed inventories remain in receipts; keep interactive CLI output compact.
        print(json.dumps({k: v for k, v in result.items() if k not in ("outputs", "inputs")}, indent=2))
    except (ValueError, OSError, KeyError) as error:
        print("canary: " + str(error), file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    entrypoint()
