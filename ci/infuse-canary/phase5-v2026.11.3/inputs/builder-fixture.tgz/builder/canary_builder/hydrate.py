"""Standalone data-only handoff hydrator; copied into private bundles."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile


def check(ok, message):
    if not ok:
        raise ValueError(message)


def contained(root, relative):
    check(isinstance(relative, str) and relative and "\\" not in relative, "invalid handoff path")
    check(all(p and p not in (".", "..") for p in relative.split("/")), "unsafe handoff path")
    path = root / relative
    check(not Path(relative).is_absolute(), "absolute handoff path")
    for parent in [*reversed(path.parents), path]:
        if parent.exists() or parent.is_symlink():
            check(not parent.is_symlink(), "handoff symlink refused")
    return path


def file_digest(path):
    info = path.lstat()
    check(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "expected regular single-link input")
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while data := stream.read(1024 * 1024):
            h.update(data)
    return {"bytes": info.st_size, "sha256": h.hexdigest()}


def metadata(root, manifest_sha256):
    path = contained(root, "HYDRATE.json")
    check(file_digest(path)["sha256"] == manifest_sha256, "protected hydration manifest mismatch")
    check(path.stat().st_size <= 1024**2, "hydration metadata exceeds ceiling")
    m = json.loads(path.read_bytes())
    check(m["schema"] == 1 and m["classification"] == "private-company-source", "unexpected handoff scope")
    check({g["root"] for g in m["sets"]} == {"swarm-source", "image-build-context", "consumer-uninstalled", "verification-controls"} and len(m["sets"]) == 4, "private input closure mismatch")
    core = m["publicCore"]
    prefixes = tuple("https://github.com/" + repository + "/releases/download/" for repository in ("aolea/openclaw", "infuse-ai-com/openclaw"))
    check(core["url"].startswith(prefixes) and core["url"].endswith("/" + core["file"]), "unexpected public Core URL")
    check(len(core["omittedArchiveSlots"]) == 2 and len(set(core["omittedArchiveSlots"])) == 2, "unexpected Core slots")
    for slot in core["omittedArchiveSlots"]:
        contained(root, slot)
        check(slot.split("/")[0] in ("image-build-context", "consumer-uninstalled") and Path(slot).name == core["file"], "Core slot outside input roots")
    for group in m["sets"]:
        path = contained(root, group["inventory"])
        check(file_digest(path)["sha256"] == group["inventorySha256"], "inventory digest mismatch")
    check(file_digest(contained(root, "candidate-manifest.json"))["sha256"] == m["candidateManifestSha256"], "candidate manifest mismatch")
    return m


def verify(root, m, omitted=False):
    omissions = set(m["publicCore"]["omittedArchiveSlots"]) if omitted else set()
    for group in m["sets"]:
        rows = json.loads(contained(root, group["inventory"]).read_bytes())["files"]
        check(len(rows) == group["pathCount"], "inventory count mismatch")
        base = contained(root, group["root"])
        actual = set()
        for directory, dirs, files in os.walk(base, followlinks=False):
            for name in dirs:
                contained(root, (Path(directory) / name).relative_to(root).as_posix())
            for name in files:
                actual.add((Path(directory) / name).relative_to(base).as_posix())
        expected = set()
        seen = set()
        h = hashlib.sha256()
        for row in rows:
            check(row["path"] not in seen, "duplicate input inventory path")
            seen.add(row["path"])
            slot = group["root"] + "/" + row["path"]
            path = contained(root, slot)
            if slot in omissions:
                check(row["sha256"] == m["publicCore"]["sha256"] and row["bytes"] == m["publicCore"]["bytes"], "omitted Core pin mismatch")
                if path.exists():
                    check(file_digest(path) == {k: row[k] for k in ("bytes", "sha256")}, "present omitted Core corrupt")
                    expected.add(row["path"])
                continue
            expected.add(row["path"])
            check(file_digest(path) == {k: row[k] for k in ("bytes", "sha256")}, "input hash mismatch: " + slot)
            mode = "100755" if path.stat().st_mode & 0o111 else "100644"
            check(mode == row["mode"], "input mode mismatch: " + slot)
            if not omitted:
                h.update(row["path"].encode() + b"\0" + mode.encode() + b"\0" + path.read_bytes() + b"\0")
        check(actual == expected, "closed input inventory mismatch")
        if not omitted:
            check(h.hexdigest() == group["fingerprintSha256"], "input root fingerprint mismatch")
    return {"status": "passed", "sets": 4, "files": sum(g["pathCount"] for g in m["sets"]), "candidateCodeExecuted": False, "omittedCoreAllowed": omitted}


def hydrate(root, manifest_sha256):
    m = metadata(root, manifest_sha256)
    verify(root, m, omitted=True)
    core = m["publicCore"]
    fd, name = tempfile.mkstemp(prefix=".core-download-", dir=root)
    os.close(fd)
    temporary = Path(name)
    try:
        subprocess.run(["curl", "--fail", "--silent", "--show-error", "--location", "--proto", "=https", "--proto-redir", "=https", "--max-time", "600", "--max-filesize", str(core["bytes"]), "--output", str(temporary), core["url"]], check=True, timeout=610)
        check(file_digest(temporary) == {k: core[k] for k in ("bytes", "sha256")}, "public Core size/hash mismatch")
        for slot in core["omittedArchiveSlots"]:
            target = contained(root, slot)
            if target.exists():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            contained(root, slot)
            with target.open("xb") as stream, temporary.open("rb") as source:
                shutil.copyfileobj(source, stream)
            target.chmod(0o644)
    finally:
        temporary.unlink(missing_ok=True)
    return verify(root, m)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(Path(__file__).absolute().parent))
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).absolute()
    result = verify(root, metadata(root, args.manifest_sha256)) if args.verify_only else hydrate(root, args.manifest_sha256)
    print(json.dumps(result, indent=2))
