"""Manual prerelease publication, addressed by ID and safe to resume."""
import json
from pathlib import Path
import subprocess
from urllib.parse import quote

from . import assets
from .io import atomic_json, digest, fingerprint, read_json, require
from .state import controller_identity


class GitHub:
    def __init__(self, repository):
        require(repository in {"aolea/openclaw", "infuse-ai-com/openclaw"}, "unreviewed GitHub repository")
        self.prefix = "repos/" + repository

    def request(self, path, method="GET", body=None, file=None, missing=False):
        command = ["gh", "api", path, "--method", method]
        data = None
        if body is not None:
            command.extend(["--input", "-"])
            data = json.dumps(body).encode()
        if file is not None:
            command.extend(["--input", str(file), "--header", "Content-Type: application/octet-stream"])
        completed = subprocess.run(command, input=data, capture_output=True, timeout=610, check=False)
        if missing and completed.returncode != 0 and b"HTTP 404" in completed.stderr:
            return None
        require(completed.returncode == 0, "GitHub request failed; inspect gh authentication/repository access separately")
        return json.loads(completed.stdout)

    def find(self, tag):
        # Drafts can be absent from tag lookup. Walk the authenticated list instead.
        found = []
        for page in range(1, 101):
            rows = self.request(f"{self.prefix}/releases?per_page=100&page={page}")
            found.extend(r for r in rows if r["tag_name"] == tag)
            if len(rows) < 100:
                break
        else:
            raise ValueError("release pagination ceiling exceeded; refusing ambiguous create")
        require(len(found) <= 1, "multiple releases with target tag")
        return found[0] if found else None

    def get(self, release_id):
        return self.request(f"{self.prefix}/releases/{release_id}")

    def create(self, m, notes):
        return self.request(self.prefix + "/releases", "POST", dict(tag_name=m["release"]["tag"], target_commitish=m["source"]["commit"], name=m["release"]["title"], body=notes, draft=True, prerelease=True, make_latest="false"))

    def upload(self, release_id, path):
        # Use the ID directly; never rely on finding a draft by tag.
        return self.request(f"https://uploads.github.com/{self.prefix}/releases/{release_id}/assets?name={quote(path.name)}", "POST", file=path)

    def publish(self, release_id):
        return self.request(f"{self.prefix}/releases/{release_id}", "PATCH", dict(draft=False, prerelease=True, make_latest="false"))

    def tag_commit(self, tag):
        response = self.request(f"{self.prefix}/git/ref/tags/{quote(tag, safe='')}", missing=True)
        if response is None:
            return None
        ref = response["object"]
        for _ in range(5):
            if ref["type"] == "commit":
                return ref["sha"]
            require(ref["type"] == "tag", "unexpected tag object")
            ref = self.request(f"{self.prefix}/git/tags/{ref['sha']}")["object"]
        raise ValueError("tag indirection exceeds ceiling")


def identity(m, release):
    r = m["release"]
    require(release["tag_name"] == r["tag"] and release["target_commitish"] == m["source"]["commit"], "release target/source mismatch")
    require(release["prerelease"] is True, "release is not a canary prerelease")
    require(release["name"] == r["title"], "release title mismatch")
    require(isinstance(release.get("body"), str) and __import__("hashlib").sha256(release["body"].encode()).hexdigest() == r["notesSha256"], "release notes mismatch")


def remote_assets(m, release, complete=True):
    actual = {}
    expected = {a["name"]: a for a in m["assets"]}
    for a in release["assets"]:
        require(a["name"] not in actual and a["name"] in expected, "unexpected/duplicate remote asset")
        pin = expected[a["name"]]
        require(a["size"] == pin["bytes"] and a.get("digest") == "sha256:" + pin["sha256"], "remote asset digest mismatch: " + a["name"])
        actual[a["name"]] = a
    if complete:
        require(set(actual) == set(expected), "remote asset set incomplete")
    return actual


def plan(m, directory, notes):
    result = assets.verify(m, directory)
    require(digest(notes)["sha256"] == m["release"]["notesSha256"], "release notes pin mismatch")
    return {"schema": 1, "effect": "GitHub package prerelease only", "repository": m["source"]["repository"], "tag": m["release"]["tag"], "targetCommit": m["source"]["commit"], "assets": result["assets"], "notesSha256": m["release"]["notesSha256"], "prerelease": True, "markLatest": False, "imageRegistryPublication": False, "deployment": False}


def verify_public(m, output, api):
    assets.complete(m)
    release = api.get(m["release"]["id"]) if m["release"]["id"] else api.find(m["release"]["tag"])
    require(release is not None and release["draft"] is False, "public release not found")
    identity(m, release)
    remote_assets(m, release)
    require(api.tag_commit(m["release"]["tag"]) == m["source"]["commit"], "published tag commit mismatch")
    downloaded = assets.fetch(m, output)
    receipt = {"schema": 1, "status": "public-downloads-verified", "releaseId": release["id"], "sourceCommit": m["source"]["commit"], "assets": downloaded["assets"], "deployed": False}
    atomic_json(output / "publication-receipt.json", receipt)
    return receipt


def execute(m, directory, notes_path, journal_path, api):
    reviewed = plan(m, directory, notes_path)
    tag_commit = api.tag_commit(m["release"]["tag"])
    require(tag_commit in (None, m["source"]["commit"]), "existing tag points at a different source; refusing publication")
    key = fingerprint({"plan": reviewed, "manifest": m, "controllers": controller_identity()})
    journal_path = Path(journal_path)
    if journal_path.exists():
        journal = read_json(journal_path)
        require(journal["planSha256"] == key, "publication inputs changed; retain journal and reconcile explicitly")
        release = api.get(journal["releaseId"])
    else:
        release = api.get(m["release"]["id"]) if m["release"]["id"] else api.find(m["release"]["tag"])
        if release is None:
            # Retry after an unknown create outcome discovers the same draft via find().
            release = api.create(m, Path(notes_path).read_text())
        identity(m, release)
        atomic_json(journal_path, {"schema": 1, "planSha256": key, "releaseId": release["id"], "status": "draft-or-existing"})
    identity(m, release)
    existing = remote_assets(m, release, complete=False)
    if release["draft"] is False:
        remote_assets(m, release)
        require(api.tag_commit(m["release"]["tag"]) == m["source"]["commit"], "published tag mismatch")
        return {"status": "already-published; use release-verify for public downloads", "releaseId": release["id"]}
    for asset in m["assets"]:
        if asset["name"] not in existing:
            api.upload(release["id"], Path(directory) / asset["name"])
    release = api.get(release["id"])
    identity(m, release)
    remote_assets(m, release)
    atomic_json(journal_path, {"schema": 1, "planSha256": key, "releaseId": release["id"], "status": "uploads-verified"})
    release = api.publish(release["id"])
    require(release["draft"] is False, "publication outcome uncertain; reconcile using retained ID")
    identity(m, release)
    remote_assets(m, release)
    require(api.tag_commit(m["release"]["tag"]) == m["source"]["commit"], "published tag mismatch")
    atomic_json(journal_path, {"schema": 1, "planSha256": key, "releaseId": release["id"], "status": "published; public-download verification still required"})
    return {"status": "published; public-download verification still required", "releaseId": release["id"]}
