"""Read-only resource admission, before creating any runtime fixture."""
import json
import os
import platform
import shutil
import subprocess

from .io import require


def check(role, docker=False):
    result = {"platform": platform.system(), "machine": platform.machine(), "hostCpus": os.cpu_count(),
              "python": platform.python_version(), "tools": {tool: shutil.which(tool) is not None for tool in ("git", "node", "gh", "curl", "docker")},
              "role": role, "mutations": False}
    if docker:
        data = subprocess.check_output(["docker", "info", "--format", "{{json .}}"], timeout=30)
        info = json.loads(data)
        # Docker Desktop's configured 6 GiB is larger than the usable Linux
        # MemTotal (the qualified Mac reports 6,210,572,288 bytes). Native
        # admission reserves up to 1 GiB for VM overhead. The v2026.11.1
        # remediation uses a 32 GiB runner class: admit at least 28 GiB usable
        # for the 23 GiB candidate cgroup plus 5 GiB host/Docker headroom.
        cpus, memory = (8, 28 * 1024**3) if role == "hosted" else (4, 5 * 1024**3)
        result["docker"] = {"cpus": info["NCPU"], "memoryBytes": info["MemTotal"], "requiredCpus": cpus, "requiredMemoryBytes": memory}
        require(info["NCPU"] >= cpus and info["MemTotal"] >= memory, f"Docker resource admission failed: got {info['NCPU']} CPUs/{info['MemTotal']} usable bytes; require {cpus} CPUs/{memory} usable bytes before freezing fixture proofs")
    result["status"] = "passed" if docker else "host-only; Docker admission not checked"
    return result
