"""One protected manifest generates all release and hosted binding data."""
from datetime import datetime
from pathlib import Path
import re

from .io import checked_file, digest, read_json, relative_path, require

ROOT = Path(__file__).resolve().parents[1]

HARNESS_PROFILES = {
    "v2026.11.1": {
        "schema": 2,
        "root": "harnesses/v2026.11.1",
        "lock": "harness-locks/v2026.11.1.json",
        "nodeImage": "docker.io/library/node:24.22.1-bookworm@sha256:6449e19d8184d84062525b6a7524def03146c2cb04a7f08b076680d0e8e4240a",
        "nodeVersion": "24.22.1",
        "packageManager": "pnpm@12.15.0+sha512.b3951d6d6ff4a9f13dc7cf56cd28d2b8eb37dbcc9c68e52e1e1191873ea9f82a017287ab50baadc5ccc494f036c67c0e47eb13608c2fa36f47711b61ea128e61",
        "pnpmVersion": "12.15.0",
        "compilerGraphs": 36,
        "hostedCpus": 8,
        "hostedMemoryGiB": 23,
        "nativeCpus": 4,
        "nativeMemoryGiB": 6,
        "hostedRunnerLabels": ["self-hosted", "linux", "x64", "infuse-canary-32gb"],
        "hostedTimeoutMinutes": 720,
    },
    "v2026.11.3": {
        "schema": 3,
        "root": "harnesses/v2026.11.3",
        "lock": "harness-locks/v2026.11.3.json",
        "nodeImage": "docker.io/library/node:24.22.1-bookworm@sha256:6449e19d8184d84062525b6a7524def03146c2cb04a7f08b076680d0e8e4240a",
        "nodeVersion": "24.22.1",
        "packageManager": "pnpm@12.15.0+sha512.b3951d6d6ff4a9f13dc7cf56cd28d2b8eb37dbcc9c68e52e1e1191873ea9f82a017287ab50baadc5ccc494f036c67c0e47eb13608c2fa36f47711b61ea128e61",
        "pnpmVersion": "12.15.0",
        "compilerGraphs": 36,
        "hostedCpus": 8,
        "hostedMemoryGiB": 23,
        "nativeCpus": 4,
        "nativeMemoryGiB": 6,
        "hostedRunnerLabels": ["blacksmith-8vcpu-ubuntu-2404"],
        "hostedTimeoutMinutes": 720,
    },
}


def keys(value, names, label):
    require(isinstance(value, dict) and set(value) == set(names.split()), "unexpected fields in " + label)


def pattern(value, regex, label):
    require(isinstance(value, str) and re.fullmatch(regex, value) is not None, "invalid " + label)


def integer(value, low, label):
    require(type(value) is int and value >= low, "invalid " + label)


def profile_for_tag(tag):
    require(tag in HARNESS_PROFILES, "no reviewed harness profile for " + str(tag))
    return HARNESS_PROFILES[tag]


def validate(m):
    require(isinstance(m, dict), "manifest must be an object")
    schema = m.get("schema")
    require(type(schema) is int and schema in (1, 2, 3), "unsupported manifest schema")
    manifest_keys = "schema candidateId source build ci harnessLockSha256 release assets referenceEvidence"
    if schema in (2, 3):
        manifest_keys += " harnessProfile"
    keys(m, manifest_keys, "manifest")
    pattern(m["candidateId"], r"[a-zA-Z0-9][a-zA-Z0-9.-]{1,99}", "candidate ID")
    s, b, ci, release = (m[k] for k in ("source", "build", "ci", "release"))
    keys(s, "repository upstreamTag upstreamCommit branch commit snapshot lockSha256", "source")
    expected_repository = "infuse-ai-com/openclaw" if schema == 3 else "aolea/openclaw"
    require(s["repository"] == expected_repository, "repository outside reviewed fork")
    for k in ("commit", "upstreamCommit"):
        pattern(s[k], r"[0-9a-f]{40}", k)
    for value in (s["lockSha256"], m["harnessLockSha256"]):
        pattern(value, r"[0-9a-f]{64}", "SHA256")
    keys(s["snapshot"], "sha256 paths bytes", "source snapshot")
    pattern(s["snapshot"]["sha256"], r"[0-9a-f]{64}", "snapshot SHA256")
    integer(s["snapshot"]["paths"], 1, "source paths")
    integer(s["snapshot"]["bytes"], 1, "source bytes")
    build_keys = "version timestamp nodeImage nodeVersion pnpmVersion plugins hostedCpus hostedMemoryGiB nativeCpus nativeMemoryGiB"
    if schema in (2, 3):
        build_keys += " packageManager compilerGraphs"
    keys(b, build_keys, "build")
    pattern(b["version"], r"[0-9]{4}\.[0-9]{1,2}\.[0-9]{1,2}", "version")
    require(s["upstreamTag"] == "v" + b["version"], "upstream tag/version mismatch")
    expected_source_branch = "canary-openclaw-v" + b["version"] if schema == 3 else "codex/v" + b["version"] + "-infuse-canary"
    require(s["branch"] == expected_source_branch, "source branch/version mismatch")
    pattern(b["timestamp"], r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z", "build timestamp")
    datetime.strptime(b["timestamp"], "%Y-%m-%dT%H:%M:%S.%fZ")
    # Each retained boundary profile deliberately binds one reviewed toolchain.
    if schema == 1:
        require(b["nodeImage"] == "node@sha256:51b1100cc2a83d370c6a60952e3f2989c8a43159d0e38586e090f3b3326efefd", "toolchain image requires harness review")
        require((b["nodeVersion"], b["pnpmVersion"]) == ("24.21.0", "12.5.1"), "toolchain requires harness review")
    else:
        require(m["harnessProfile"] == s["upstreamTag"], "harness profile/tag mismatch")
        profile = profile_for_tag(m["harnessProfile"])
        for key in ("nodeImage", "nodeVersion", "packageManager", "pnpmVersion", "compilerGraphs"):
            require(b[key] == profile[key], "reviewed harness profile mismatch: " + key)
    require(b["plugins"] == ["mattermost", "codex", "acpx", "diagnostics-otel"], "plugin scope requires harness review")
    if schema == 1:
        resources = (4, 13, 4, 6)
    else:
        resources = tuple(profile[key] for key in ("hostedCpus", "hostedMemoryGiB", "nativeCpus", "nativeMemoryGiB"))
    require((b["hostedCpus"], b["hostedMemoryGiB"], b["nativeCpus"], b["nativeMemoryGiB"]) == resources, "resource policy requires harness review")
    ci_keys = "branch commit workflowId runId runAttempt"
    if schema == 3:
        ci_keys += " buildAttempt"
    keys(ci, ci_keys, "CI")
    if schema == 3:
        integer(ci["buildAttempt"], 1, "build attempt")
        expected_ci_branch = "build/" + s["branch"]
        if ci["buildAttempt"] > 1:
            expected_ci_branch += "-r" + str(ci["buildAttempt"])
    else:
        expected_ci_branch = s["branch"] + "-build"
    require(ci["branch"] == expected_ci_branch, "CI branch/version mismatch")
    pattern(ci["commit"], r"[0-9a-f]{40}", "CI commit")
    integer(ci["workflowId"], 0 if schema == 3 else 1, "workflow ID")
    integer(ci["runId"], 0, "run ID (zero while proposed)")
    if schema == 3:
        require(ci["runAttempt"] == 1, "collector contract requires workflow/attempt review")
    else:
        require(ci["workflowId"] == 330254341 and ci["runAttempt"] == 1, "collector contract requires workflow/attempt review")
    keys(release, "tag title prerelease markLatest id notesSha256", "release")
    pattern(release["tag"], r"canary-v" + re.escape(b["version"]) + r"-[a-z0-9-]+-" + s["commit"][:10] + r"-r[1-9][0-9]*", "release tag/source binding")
    require(isinstance(release["title"], str) and 0 < len(release["title"]) < 200, "invalid release title")
    require(release["prerelease"] is True and release["markLatest"] is False, "only canary prereleases supported")
    integer(release["id"], 0, "release ID (zero before creation)")
    pattern(release["notesSha256"], r"[0-9a-f]{64}", "notes SHA256")
    require(isinstance(m["assets"], list) and len(m["assets"]) in (0, 9), "zero pending or nine frozen public assets required")
    expected = {"BUILD-PROVENANCE.json", "LINUX-QUALIFICATION.json", "SHA256SUMS", "candidate-manifest.json", f"openclaw-{b['version']}-{s['commit'][:10]}.tgz"}
    expected.update(f"openclaw-{p}-{b['version']}.tgz" for p in b["plugins"])
    require(all(isinstance(a, dict) for a in m["assets"]), "invalid asset record")
    require(not m["assets"] or {a.get("name") for a in m["assets"]} == expected, "public asset closure mismatch")
    for a in m["assets"]:
        keys(a, "name bytes sha256", "asset")
        relative_path(a["name"])
        require("/" not in a["name"], "asset must be a basename")
        integer(a["bytes"], 1, "asset bytes")
        require(a["bytes"] <= 336 * 1024**2, "asset exceeds bound")
        pattern(a["sha256"], r"[0-9a-f]{64}", "asset SHA256")
    require(isinstance(m["referenceEvidence"], dict), "reference evidence must be descriptive data")
    return m


def load(path):
    return validate(read_json(path))


def binding(m):
    s, b = m["source"], m["build"]
    result = dict(schemaVersion=m["schema"], repository=s["repository"], bootstrapBranch=m["ci"]["branch"],
                candidateBranch=s["branch"], candidateCommit=s["commit"], baseCommit=s["upstreamCommit"],
                sourceSha256=s["snapshot"]["sha256"], sourcePaths=s["snapshot"]["paths"],
                sourceBytes=s["snapshot"]["bytes"], pnpmLockSha256=s["lockSha256"],
                buildTimestamp=b["timestamp"], version=b["version"], plugins=b["plugins"],
                nodeImage=b["nodeImage"], nodeVersion=b["nodeVersion"], pnpmVersion=b["pnpmVersion"])
    if m["schema"] in (2, 3):
        result.update(harnessProfile=m["harnessProfile"], packageManager=b["packageManager"], compilerGraphs=b["compilerGraphs"],
                      hostedCpus=b["hostedCpus"], hostedMemoryGiB=b["hostedMemoryGiB"])
    if m["schema"] == 3:
        labels = profile_for_tag(m["harnessProfile"])["hostedRunnerLabels"]
        require(len(labels) == 1, "schema-3 dispatcher requires one reviewed runner label")
        result["runnerLabel"] = labels[0]
        result["workflowId"] = m["ci"]["workflowId"]
        result["buildAttempt"] = m["ci"]["buildAttempt"]
    return result


def harness_layout(m, root=ROOT):
    if m["schema"] == 1:
        return {
            "lock": root / "harness-lock.json",
            "roots": [root / "harness"],
            "profileRoot": root / "harness",
        }
    profile = profile_for_tag(m["harnessProfile"])
    return {
        "lock": root / profile["lock"],
        "roots": [root / "harness/consumer", root / profile["root"]],
        "profileRoot": root / profile["root"],
    }


def harness_section(m, section, root=ROOT):
    require(section in ("collector", "hosted"), "invalid harness section")
    return harness_layout(m, root)["profileRoot"] / section


def verify_harness(m, root=ROOT):
    layout = harness_layout(m, root)
    lock_path = layout["lock"]
    require(digest(lock_path)["sha256"] == m["harnessLockSha256"], "reviewed harness lock changed")
    lock = read_json(lock_path)
    require(lock["schema"] == 1, "unsupported harness lock")
    expected = set()
    allowed = [path.relative_to(root).as_posix() + "/" for path in layout["roots"]]
    for item in lock["files"]:
        relative_path(item["path"])
        require(any(item["path"].startswith(prefix) for prefix in allowed), "lock outside harness profile")
        require(item["path"] not in expected, "duplicate harness path")
        expected.add(item["path"])
        checked_file(root, item["path"], item)
    actual = {p.relative_to(root).as_posix() for profile_root in layout["roots"] for p in profile_root.rglob("*") if p.is_file()}
    require(actual == expected, "reviewed harness file closure changed")
    return lock
