"""Portable data-only file custody shared by stages and handoffs."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def relative_path(value):
    require(isinstance(value, str) and value and "\\" not in value, "invalid relative path")
    parts = value.split("/")
    require(all(p and p not in (".", "..") for p in parts), "unsafe relative path")
    require(not PurePosixPath(value).is_absolute(), "absolute path refused")
    return value


def real_directory(path):
    path = Path(path).absolute()
    for parent in [*reversed(path.parents), path]:
        require(stat.S_ISDIR(parent.lstat().st_mode), "directory symlink or missing parent: " + str(parent))
    return path


def regular_file(path):
    path = Path(path).absolute()
    real_directory(path.parent)
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "expected regular single-link file: " + str(path))
    return info


def digest(path):
    info = regular_file(path)
    hasher = hashlib.sha256()
    with open(path, "rb", opener=lambda p, flags: os.open(p, flags | os.O_NOFOLLOW)) as stream:
        opened = os.fstat(stream.fileno())
        require((opened.st_dev, opened.st_ino) == (info.st_dev, info.st_ino), "file changed during open")
        while chunk := stream.read(1024 * 1024):
            hasher.update(chunk)
        require(os.fstat(stream.fileno()).st_size == info.st_size, "file changed during read")
    return {"bytes": info.st_size, "sha256": hasher.hexdigest()}


def read_json(path, limit=4 * 1024 * 1024):
    require(regular_file(path).st_size <= limit, "JSON exceeds size ceiling")
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def fingerprint(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    real_directory(path.parent)
    if path.exists() or path.is_symlink():
        regular_file(path)
    fd, name = tempfile.mkstemp(prefix=".canary-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def inventory(root):
    root = real_directory(root)
    files = []
    for directory, subdirs, names in os.walk(root, followlinks=False):
        for name in subdirs:
            real_directory(Path(directory) / name)
        for name in names:
            path = Path(directory) / name
            files.append({"path": path.relative_to(root).as_posix(), **digest(path)})
    return sorted(files, key=lambda item: item["path"])


def verify_inventory(root, expected):
    require(inventory(root) == expected, "closed file inventory differs")


def checked_file(root, name, expected):
    path = real_directory(root) / relative_path(name)
    require(digest(path) == {k: expected[k] for k in ("bytes", "sha256")}, "file pin mismatch: " + name)
    return path
