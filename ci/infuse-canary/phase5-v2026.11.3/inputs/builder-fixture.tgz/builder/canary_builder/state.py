"""Atomic, serialized stage receipts; cached success never outlives its bytes."""
from contextlib import contextmanager
import fcntl
import os
from pathlib import Path
from datetime import datetime, timezone

from .io import atomic_json, digest, fingerprint, inventory, read_json, real_directory, require, verify_inventory
from .manifest import ROOT


def controller_identity():
    return [{"path": p.relative_to(ROOT).as_posix(), **digest(p)}
            for p in sorted((ROOT / "canary_builder").glob("*.py"))]


class Workspace:
    def __init__(self, path, manifest):
        self.root = Path(path).absolute()
        if not self.root.exists():
            missing = []
            parent = self.root
            while not parent.exists() and not parent.is_symlink():
                missing.append(parent)
                parent = parent.parent
            real_directory(parent)
            for directory in reversed(missing):
                directory.mkdir(mode=0o700)
        real_directory(self.root)
        self.context = fingerprint({"manifest": manifest, "controllers": controller_identity()})

    @contextmanager
    def lock(self):
        fd = os.open(self.root / ".lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            yield
        finally:
            os.close(fd)

    def run(self, stage, inputs, operation):
        require(stage.isascii() and stage.replace("-", "").isalnum(), "invalid stage")
        receipt_path = self.root / (stage + ".json")
        output = self.root / stage
        key = fingerprint({"context": self.context, "stage": stage, "inputs": inputs})
        with self.lock():
            if receipt_path.exists():
                old = read_json(receipt_path)
                require(old["key"] == key, "stale stage: inputs/controllers changed; use a fresh workspace")
                require(old["status"] == "passed", "failed/interrupted stage retained; use a fresh workspace")
                verify_inventory(output, old["outputs"])
                return {**old, "resumed": True}
            require(not output.exists() and not output.is_symlink(), "unreceipted output retained; use a fresh workspace")
            output.mkdir(mode=0o700)
            record = {"schema": 1, "stage": stage, "key": key, "status": "running", "inputs": inputs,
                      "startedAt": datetime.now(timezone.utc).isoformat()}
            atomic_json(receipt_path, record)
            try:
                result = operation(output)
                record.update(status="passed", result=result, outputs=inventory(output))
            except BaseException as error:
                record.update(status="failed", errorType=type(error).__name__)
                atomic_json(receipt_path, record)
                raise
            record["finishedAt"] = datetime.now(timezone.utc).isoformat()
            atomic_json(receipt_path, record)
            return {**record, "resumed": False}
