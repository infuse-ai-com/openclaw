"""Hash and inspect packages as data; candidate executables never run here."""
import json
from pathlib import Path
import subprocess
import tarfile

from .io import checked_file, digest, read_json, real_directory, relative_path, require


def core_asset(m):
    name = f"openclaw-{m['build']['version']}-{m['source']['commit'][:10]}.tgz"
    return next(a for a in m["assets"] if a["name"] == name)


def complete(m):
    require(len(m["assets"]) == 9, "public artifacts are pending; freeze reviewed package/qualification metadata first")
    require(m["ci"]["commit"] != "0" * 40 and m["ci"]["runId"] > 0, "CI identity is pending")


def inspect_archive(path, expected_name, version, source_commit=None):
    count = total = 0
    seen = set()
    metadata = {}
    with tarfile.open(path, "r:gz") as archive:
        for entry in archive:
            name = entry.name.rstrip("/")
            relative_path(name)
            require(name == "package" or name.startswith("package/"), "archive outside package root")
            require(name not in seen, "duplicate archive member")
            seen.add(name)
            require(entry.isdir() or entry.isfile(), "archive link/special member refused")
            count += 1
            total += entry.size
            require(count <= 100000 and total <= 1024**3, "package expansion exceeds ceiling")
            if name in ("package/package.json", "package/dist/build-info.json"):
                require(entry.isfile() and entry.size <= 2 * 1024**2, "invalid package metadata")
                metadata[name] = json.load(archive.extractfile(entry))
    package = metadata.get("package/package.json", {})
    require(package.get("name") == expected_name and package.get("version") == version, "package identity mismatch")
    if source_commit:
        info = metadata.get("package/dist/build-info.json", {})
        require(info.get("commit") == source_commit and info.get("version") == version, "Core build-info mismatch")
    return {"name": expected_name, "version": version, "members": count, "expandedBytes": total}


def verify(m, directory, inspect_packages=True):
    complete(m)
    root = real_directory(directory)
    assets = {a["name"]: a for a in m["assets"]}
    require({p.name for p in root.iterdir()} == set(assets), "release asset directory must contain exactly the nine frozen assets")
    for name, a in assets.items():
        checked_file(root, name, a)
    s, b, ci = m["source"], m["build"], m["ci"]
    core = core_asset(m)
    candidate = read_json(root / "candidate-manifest.json")
    expected = dict(hostVersion=b["version"], hostCommit=s["commit"], baseCommit=s["upstreamCommit"],
                    buildTimestamp=b["timestamp"], sourceSnapshotSha256=s["snapshot"]["sha256"],
                    sourceLockSha256=s["lockSha256"], hostPackageSha256=core["sha256"], hostPackageFile=core["name"],
                    ciCommit=ci["commit"], workflowRunId=ci["runId"], workflowRunAttempt=1)
    require(all(candidate.get(k) == v for k, v in expected.items()), "candidate manifest dependency pin mismatch")
    provenance = read_json(root / "BUILD-PROVENANCE.json")
    require(provenance.get("sourceCommit") == s["commit"] and provenance.get("ciCommit") == ci["commit"], "build provenance pin mismatch")
    require(provenance.get("upstreamTag") == s["upstreamTag"] and provenance.get("upstreamCommit") == s["upstreamCommit"], "upstream provenance pin mismatch")
    require(provenance.get("sourceSnapshotSha256") == s["snapshot"]["sha256"] and provenance.get("candidateManifestSha256") == assets["candidate-manifest.json"]["sha256"], "provenance dependency hash mismatch")
    require(provenance.get("workflowRun") == f"https://github.com/{s['repository']}/actions/runs/{ci['runId']}", "provenance run mismatch")
    compiler_graphs = b.get("compilerGraphs", 35)
    require(provenance.get("all13StagesPassed") is True and provenance.get("compilerGraphs") == compiler_graphs, "hosted package qualification incomplete")
    packages = sorted((a for a in m["assets"] if a["name"].endswith(".tgz")), key=lambda a: a["name"])
    require(sorted(provenance.get("packages", []), key=lambda a: a["name"]) == packages, "package provenance closure mismatch")
    qualification = read_json(root / "LINUX-QUALIFICATION.json")
    require(qualification.get("sourceCommit") == s["commit"] and qualification.get("ciCommit") == ci["commit"], "runtime qualification source/CI mismatch")
    require(qualification.get("coreArchiveSha256") == core["sha256"] and qualification.get("candidateManifestSha256") == assets["candidate-manifest.json"]["sha256"], "runtime qualification artifact mismatch")
    require(qualification.get("status") == "passed-with-declared-scope-limits" and isinstance(qualification.get("scopeLimits"), list), "runtime qualification status/limits missing")
    for stage in ("hosted", "arm64Consumer", "publicInventory", "managedNative", "ordinaryMattermost", "amd64", "localImage", "builderBoundary"):
        require(qualification.get("checks", {}).get(stage, {}).get("status") == "passed", "required runtime proof missing: " + stage)
    sums = (root / "SHA256SUMS").read_text().splitlines()
    parsed = {}
    for line in sums:
        value, name = line.split("  ", 1)
        require(name not in parsed, "duplicate checksum filename")
        parsed[name] = value
    require(parsed == {name: a["sha256"] for name, a in assets.items() if name != "SHA256SUMS"}, "checksum closure mismatch")
    archives = []
    if inspect_packages:
        archives.append(inspect_archive(root / core["name"], "openclaw", b["version"], s["commit"]))
        for p in b["plugins"]:
            archives.append(inspect_archive(root / f"openclaw-{p}-{b['version']}.tgz", "@openclaw/" + p, b["version"]))
    return {"status": "assets-authenticated", "sourceCommit": s["commit"], "assets": list(assets.values()), "archives": archives, "qualificationOrigin": "reviewed imported metadata; candidate code not executed", "scopeLimits": qualification["scopeLimits"]}


def fetch_file(url, destination, expected, repository):
    require(repository in {"aolea/openclaw", "infuse-ai-com/openclaw"}, "unreviewed public release namespace")
    require(url.startswith(f"https://github.com/{repository}/releases/download/"), "download outside reviewed public release namespace")
    require(not Path(destination).exists(), "refusing to overwrite download")
    subprocess.run(["curl", "--fail", "--silent", "--show-error", "--location", "--proto", "=https", "--proto-redir", "=https", "--max-time", "600", "--max-filesize", str(expected["bytes"]), "--output", str(destination), url], check=True, timeout=610)
    require(digest(destination) == {k: expected[k] for k in ("bytes", "sha256")}, "public download digest/size mismatch")


def fetch(m, output):
    complete(m)
    root = output / "assets"
    root.mkdir(mode=0o700)
    base = f"https://github.com/{m['source']['repository']}/releases/download/{m['release']['tag']}/"
    for a in m["assets"]:
        fetch_file(base + a["name"], root / a["name"], a, m["source"]["repository"])
    return verify(m, root)
