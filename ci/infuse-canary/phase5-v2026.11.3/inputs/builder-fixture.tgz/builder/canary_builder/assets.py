"""Hash and inspect packages as data; candidate executables never run here."""
import json
from pathlib import Path
import subprocess
import tarfile

from .io import checked_file, digest, read_json, real_directory, relative_path, require


RUNTIME_LANES = (
    "arm64Consumer",
    "publicInventory",
    "managedNative",
    "ordinaryMattermost",
    "amd64",
    "localImage",
    "builderBoundary",
)


def core_asset(m):
    name = f"openclaw-{m['build']['version']}-{m['source']['commit'][:10]}.tgz"
    return next(a for a in m["assets"] if a["name"] == name)


def complete(m):
    require(len(m["assets"]) == 9, "public artifacts are pending; freeze reviewed package/qualification metadata first")
    require(m["ci"]["commit"] != "0" * 40 and m["ci"]["runId"] > 0, "CI identity is pending")


def inspect_archive(path, expected_name, version, source_commit=None):
    count = total = 0
    seen = set()
    metadata = {}
    with tarfile.open(path, "r:gz") as archive:
        for entry in archive:
            name = entry.name.rstrip("/")
            relative_path(name)
            require(name == "package" or name.startswith("package/"), "archive outside package root")
            require(name not in seen, "duplicate archive member")
            seen.add(name)
            require(entry.isdir() or entry.isfile(), "archive link/special member refused")
            count += 1
            total += entry.size
            require(count <= 100000 and total <= 1024**3, "package expansion exceeds ceiling")
            if name in ("package/package.json", "package/dist/build-info.json"):
                require(entry.isfile() and entry.size <= 2 * 1024**2, "invalid package metadata")
                metadata[name] = json.load(archive.extractfile(entry))
    package = metadata.get("package/package.json", {})
    require(package.get("name") == expected_name and package.get("version") == version, "package identity mismatch")
    if source_commit:
        info = metadata.get("package/dist/build-info.json", {})
        require(info.get("commit") == source_commit and info.get("version") == version, "Core build-info mismatch")
    return {"name": expected_name, "version": version, "members": count, "expandedBytes": total}


def verify_qualification(m, qualification, core, candidate_sha256):
    s, ci = m["source"], m["ci"]
    require(qualification.get("sourceCommit") == s["commit"] and qualification.get("ciCommit") == ci["commit"], "runtime qualification source/CI mismatch")
    require(qualification.get("coreArchiveSha256") == core["sha256"] and qualification.get("candidateManifestSha256") == candidate_sha256, "runtime qualification artifact mismatch")
    require(isinstance(qualification.get("scopeLimits"), list), "runtime qualification scope limits missing")

    if qualification.get("status") == "passed-with-declared-scope-limits":
        for stage in ("hosted", *RUNTIME_LANES):
            require(qualification.get("checks", {}).get(stage, {}).get("status") == "passed", "required runtime proof missing: " + stage)
        return "fresh-full-qualification"

    require(qualification.get("status") == "passed-correction-with-referenced-runtime-lanes", "runtime qualification status missing")
    correction = m["referenceEvidence"].get("correction")
    require(isinstance(correction, dict) and qualification.get("correction") == correction, "corrective qualification reference mismatch")
    expected_correction_keys = {
        "baseSourceCommit",
        "priorReleaseId",
        "priorReleaseTag",
        "priorQualificationSha256",
        "priorCandidateManifestSha256",
        "priorPhase5PlanSha256",
        "changedFiles",
    }
    require(set(correction) == expected_correction_keys, "corrective qualification reference fields changed")
    require(isinstance(correction["baseSourceCommit"], str) and len(correction["baseSourceCommit"]) == 40 and correction["baseSourceCommit"] != s["commit"], "invalid corrective base source")
    require(type(correction["priorReleaseId"]) is int and correction["priorReleaseId"] > 0, "invalid prior release ID")
    require(isinstance(correction["priorReleaseTag"], str) and correction["priorReleaseTag"], "invalid prior release tag")
    for name in ("priorQualificationSha256", "priorCandidateManifestSha256", "priorPhase5PlanSha256"):
        value = correction[name]
        require(isinstance(value, str) and len(value) == 64 and all(character in "0123456789abcdef" for character in value), "invalid corrective SHA256: " + name)
    changed_files = correction["changedFiles"]
    require(isinstance(changed_files, list) and changed_files == sorted(set(changed_files)) and changed_files, "invalid corrective changed-file closure")
    require(all(isinstance(path, str) and relative_path(path) == path for path in changed_files), "invalid corrective changed file")

    checks = qualification.get("checks", {})
    require(checks.get("hosted", {}).get("status") == "passed", "fresh corrective hosted proof missing")
    activation = checks.get("packagedActivation", {})
    require(activation.get("status") == "passed", "corrective packaged activation proof missing")
    metrics = activation.get("metrics", {})
    expected_metrics = {
        "generatedMetadataCheck",
        "focusedRegression",
        "releaseCheck",
        "archiveInstall",
        "packedConfigValidation",
        "effectiveFeatureAssertions",
    }
    require(set(metrics) == expected_metrics, "corrective packaged activation closure incomplete")
    for name in expected_metrics - {"releaseCheck"}:
        require(metrics[name] is True, "corrective packaged activation metric failed: " + name)
    release_check = metrics["releaseCheck"]
    if release_check is not True:
        require(isinstance(release_check, dict), "corrective release check evidence invalid")
        require(set(release_check) == {
            "status",
            "buildPassed",
            "baseSourceCommit",
            "candidateSourceCommit",
            "failedChecks",
            "unchangedInputs",
        }, "corrective release check evidence fields changed")
        require(release_check["status"] == "build-passed-with-inherited-preflight-drift" and release_check["buildPassed"] is True,
                "corrective release build did not pass")
        require(release_check["baseSourceCommit"] == correction["baseSourceCommit"] and release_check["candidateSourceCommit"] == s["commit"],
                "corrective release check source mismatch")
        failed_checks = release_check["failedChecks"]
        require(isinstance(failed_checks, list) and failed_checks == sorted(set(failed_checks)) and failed_checks and
                all(isinstance(name, str) and name for name in failed_checks), "corrective inherited release failures invalid")
        unchanged_inputs = release_check["unchangedInputs"]
        require(isinstance(unchanged_inputs, list) and unchanged_inputs, "corrective inherited release inputs missing")
        paths = []
        for item in unchanged_inputs:
            require(isinstance(item, dict) and set(item) == {"path", "baseSha256", "candidateSha256"},
                    "corrective inherited release input invalid")
            path = item["path"]
            require(isinstance(path, str) and relative_path(path) == path and path not in changed_files,
                    "corrective inherited release input overlaps correction")
            require(item["baseSha256"] == item["candidateSha256"] and isinstance(item["baseSha256"], str) and
                    len(item["baseSha256"]) == 64 and all(character in "0123456789abcdef" for character in item["baseSha256"]),
                    "corrective inherited release input changed")
            paths.append(path)
        require(paths == sorted(set(paths)), "corrective inherited release inputs are not sorted and unique")
    for lane in RUNTIME_LANES:
        carried = checks.get(lane, {})
        require(carried == {"status": "referenced", "qualificationSha256": correction["priorQualificationSha256"]}, "corrective lane must be explicitly referenced: " + lane)
    require(qualification.get("recordedBeforeReleasePublication") is True and qualification.get("deployed") is False, "corrective qualification effect boundary changed")
    return "fresh-package-correction-with-referenced-runtime-lanes"


def verify(m, directory, inspect_packages=True):
    complete(m)
    root = real_directory(directory)
    assets = {a["name"]: a for a in m["assets"]}
    require({p.name for p in root.iterdir()} == set(assets), "release asset directory must contain exactly the nine frozen assets")
    for name, a in assets.items():
        checked_file(root, name, a)
    s, b, ci = m["source"], m["build"], m["ci"]
    core = core_asset(m)
    candidate = read_json(root / "candidate-manifest.json")
    expected = dict(hostVersion=b["version"], hostCommit=s["commit"], baseCommit=s["upstreamCommit"],
                    buildTimestamp=b["timestamp"], sourceSnapshotSha256=s["snapshot"]["sha256"],
                    sourceLockSha256=s["lockSha256"], hostPackageSha256=core["sha256"], hostPackageFile=core["name"],
                    ciCommit=ci["commit"], workflowRunId=ci["runId"], workflowRunAttempt=1)
    require(all(candidate.get(k) == v for k, v in expected.items()), "candidate manifest dependency pin mismatch")
    provenance = read_json(root / "BUILD-PROVENANCE.json")
    require(provenance.get("sourceCommit") == s["commit"] and provenance.get("ciCommit") == ci["commit"], "build provenance pin mismatch")
    require(provenance.get("upstreamTag") == s["upstreamTag"] and provenance.get("upstreamCommit") == s["upstreamCommit"], "upstream provenance pin mismatch")
    require(provenance.get("sourceSnapshotSha256") == s["snapshot"]["sha256"] and provenance.get("candidateManifestSha256") == assets["candidate-manifest.json"]["sha256"], "provenance dependency hash mismatch")
    require(provenance.get("workflowRun") == f"https://github.com/{s['repository']}/actions/runs/{ci['runId']}", "provenance run mismatch")
    compiler_graphs = b.get("compilerGraphs", 35)
    require(provenance.get("all13StagesPassed") is True and provenance.get("compilerGraphs") == compiler_graphs, "hosted package qualification incomplete")
    packages = sorted((a for a in m["assets"] if a["name"].endswith(".tgz")), key=lambda a: a["name"])
    require(sorted(provenance.get("packages", []), key=lambda a: a["name"]) == packages, "package provenance closure mismatch")
    qualification = read_json(root / "LINUX-QUALIFICATION.json")
    qualification_origin = verify_qualification(m, qualification, core, assets["candidate-manifest.json"]["sha256"])
    sums = (root / "SHA256SUMS").read_text().splitlines()
    parsed = {}
    for line in sums:
        value, name = line.split("  ", 1)
        require(name not in parsed, "duplicate checksum filename")
        parsed[name] = value
    require(parsed == {name: a["sha256"] for name, a in assets.items() if name != "SHA256SUMS"}, "checksum closure mismatch")
    archives = []
    if inspect_packages:
        archives.append(inspect_archive(root / core["name"], "openclaw", b["version"], s["commit"]))
        for p in b["plugins"]:
            archives.append(inspect_archive(root / f"openclaw-{p}-{b['version']}.tgz", "@openclaw/" + p, b["version"]))
    return {"status": "assets-authenticated", "sourceCommit": s["commit"], "assets": list(assets.values()), "archives": archives, "qualificationOrigin": qualification_origin, "scopeLimits": qualification["scopeLimits"]}


def fetch_file(url, destination, expected, repository):
    require(repository in {"aolea/openclaw", "infuse-ai-com/openclaw"}, "unreviewed public release namespace")
    require(url.startswith(f"https://github.com/{repository}/releases/download/"), "download outside reviewed public release namespace")
    require(not Path(destination).exists(), "refusing to overwrite download")
    subprocess.run(["curl", "--fail", "--silent", "--show-error", "--location", "--proto", "=https", "--proto-redir", "=https", "--max-time", "600", "--max-filesize", str(expected["bytes"]), "--output", str(destination), url], check=True, timeout=610)
    require(digest(destination) == {k: expected[k] for k in ("bytes", "sha256")}, "public download digest/size mismatch")


def fetch(m, output):
    complete(m)
    root = output / "assets"
    root.mkdir(mode=0o700)
    base = f"https://github.com/{m['source']['repository']}/releases/download/{m['release']['tag']}/"
    for a in m["assets"]:
        fetch_file(base + a["name"], root / a["name"], a, m["source"]["repository"])
    return verify(m, root)
