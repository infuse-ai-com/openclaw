"""Retain the qualified secretless boundary and generate only candidate data."""
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import ModuleType

from .io import atomic_json, digest, inventory, require
from .manifest import ROOT, binding, harness_section, profile_for_tag, verify_harness


LEGACY_RUNNER_LABELS = ("ubuntu-24.04",)
LEGACY_TIMEOUT_MINUTES = 240


def execution_policy(m):
    if m["schema"] == 1:
        return {"runnerLabels": LEGACY_RUNNER_LABELS, "timeoutMinutes": LEGACY_TIMEOUT_MINUTES}
    profile = profile_for_tag(m["harnessProfile"])
    return {"runnerLabels": tuple(profile["hostedRunnerLabels"]),
            "timeoutMinutes": profile["hostedTimeoutMinutes"]}


def identity_module(manifest):
    path = harness_section(manifest, "hosted") / "identity.py"
    module = ModuleType("trusted_source_identity")
    # Execute authenticated source bytes directly, bypassing cached bytecode.
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


def source_check(manifest, source):
    verify_harness(manifest)
    inspector = identity_module(manifest)
    root = Path(source).absolute()
    actual_commit = inspector.git(root, "rev-parse", "HEAD").decode().strip()
    require(actual_commit == manifest["source"]["commit"], "candidate checkout commit mismatch")
    base = manifest["source"]["upstreamCommit"]
    require(inspector.git(root, "merge-base", base, "HEAD").decode().strip() == base, "upstream not an ancestor")
    require(inspector.git(root, "rev-parse", manifest["source"]["upstreamTag"] + "^{commit}").decode().strip() == base, "upstream tag commit mismatch")
    require(inspector.git(root, "status", "--porcelain=v1", "--untracked-files=normal") == b"", "candidate source is dirty")
    package_mode, package_bytes = inspector.safe_bytes(root, "package.json")
    require(package_mode in ("100644", "100755"), "source package manifest must be a regular file")
    package = json.loads(package_bytes)
    require(package["version"] == manifest["build"]["version"], "source package/manifest version mismatch")
    if manifest["schema"] in (2, 3):
        require(package.get("packageManager") == manifest["build"]["packageManager"], "source packageManager/manifest mismatch")
    paths = sorted(item.decode() for item in inspector.git(root, "ls-files", "-z").split(b"\0") if item)
    snapshot = inspector.verify(root, binding(manifest), paths)
    require(inspector.git(root, "rev-parse", "HEAD").decode().strip() == actual_commit and inspector.git(root, "status", "--porcelain=v1", "--untracked-files=normal") == b"", "source changed during inspection")
    return {"commit": actual_commit, "snapshot": snapshot, "lock": digest(root / "pnpm-lock.yaml"), "tagSignature": "not reverified by this command"}


def propose(reference, source, upstream_tag, build_attempt=1):
    """Produce reviewable input data, never an approval or qualification verdict."""
    verify_harness(reference)
    require(upstream_tag.startswith("v"), "expected upstream version tag")
    require(type(build_attempt) is int and build_attempt >= 1, "build attempt must be a positive integer")
    import copy
    m = copy.deepcopy(reference)
    inspector = identity_module(reference)
    root = Path(source).absolute()
    require(inspector.git(root, "status", "--porcelain=v1", "--untracked-files=normal") == b"", "candidate source is dirty")
    commit = inspector.git(root, "rev-parse", "HEAD").decode().strip()
    base = inspector.git(root, "rev-parse", upstream_tag + "^{commit}").decode().strip()
    require(inspector.git(root, "merge-base", base, commit).decode().strip() == base, "upstream not an ancestor")
    version = upstream_tag[1:]
    package_mode, package_bytes = inspector.safe_bytes(root, "package.json")
    require(package_mode in ("100644", "100755"), "source package manifest must be a regular file")
    package = json.loads(package_bytes)
    require(package["version"] == version, "source package/tag version mismatch")
    profile = profile_for_tag(upstream_tag)
    require(package.get("packageManager") == profile["packageManager"], "source packageManager outside reviewed harness profile")
    paths = sorted(item.decode() for item in inspector.git(root, "ls-files", "-z").split(b"\0") if item)
    snapshot = inspector.snapshot(root, paths)
    m["schema"] = profile["schema"]
    m["harnessProfile"] = upstream_tag
    m["harnessLockSha256"] = digest(ROOT / profile["lock"])["sha256"]
    m["candidateId"] = f"{upstream_tag}-infuse-{commit[:10]}"
    source_branch = f"canary-openclaw-{upstream_tag}" if m["schema"] == 3 else f"codex/{upstream_tag}-infuse-canary"
    repository = "infuse-ai-com/openclaw" if m["schema"] == 3 else "aolea/openclaw"
    m["source"].update(repository=repository, upstreamTag=upstream_tag, upstreamCommit=base, branch=source_branch, commit=commit, snapshot=snapshot, lockSha256=digest(root / "pnpm-lock.yaml")["sha256"])
    m["build"].update(version=version, timestamp=datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                      nodeImage=profile["nodeImage"], nodeVersion=profile["nodeVersion"], packageManager=profile["packageManager"],
                      pnpmVersion=profile["pnpmVersion"], compilerGraphs=profile["compilerGraphs"],
                      hostedCpus=profile["hostedCpus"], hostedMemoryGiB=profile["hostedMemoryGiB"],
                      nativeCpus=profile["nativeCpus"], nativeMemoryGiB=profile["nativeMemoryGiB"])
    if m["schema"] == 3:
        ci_branch = "build/" + m["source"]["branch"]
        if build_attempt > 1:
            ci_branch += f"-r{build_attempt}"
        m["ci"]["buildAttempt"] = build_attempt
    else:
        require(build_attempt == 1, "versioned build attempts require schema 3")
        ci_branch = m["source"]["branch"] + "-build"
    m["ci"].update(branch=ci_branch, commit="0" * 40, workflowId=0 if m["schema"] == 3 else m["ci"]["workflowId"], runId=0)
    m["assets"] = []
    release_slug = "infuse-bundle" if m["schema"] == 3 else "studio-required-owner"
    m["release"].update(id=0, tag=f"canary-{upstream_tag}-{release_slug}-{commit[:10]}-r1", title=f"{version} Infuse custom canary ({commit[:10]})", notesSha256="0" * 64)
    m["referenceEvidence"] = {"origin": "proposed-unqualified", "limitations": ["Review upstream signature and patch applicability", "Record the exact uploaded CI commit/run before collecting", "Freeze package/runtime/image proof and release notes before publication"]}
    verify_harness(m)
    return m


def workflow(m):
    require(m["schema"] != 3, "schema-3 uses the reviewed main-branch dispatcher")
    source = m["source"]
    policy = execution_policy(m)
    return f'''name: Infuse custom canary build and qualification

on:
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: infuse-{m['candidateId']}-${{{{ github.sha }}}}
  cancel-in-progress: false

env:
  FORCE_JAVASCRIPT_ACTIONS_TO_NODE24: "true"

jobs:
  qualify:
    if: github.repository == '{source['repository']}' && github.event.repository.private == false && github.ref == 'refs/heads/{m['ci']['branch']}'
    runs-on: [{', '.join(policy['runnerLabels'])}]
    timeout-minutes: {policy['timeoutMinutes']}
    steps:
      - name: Checkout reviewed bootstrap
        uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1
        with:
          ref: ${{{{ github.sha }}}}
          persist-credentials: false
          fetch-depth: 1
      - name: Checkout exact frozen candidate and stable base
        uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1
        with:
          ref: {source['commit']}
          path: candidate-source
          persist-credentials: false
          fetch-depth: 5
      - name: Qualify only inside secretless Docker
        shell: bash
        run: |
          set -euo pipefail
          /usr/bin/python3 -I ci/infuse-canary/run-host.py --source "${{GITHUB_WORKSPACE}}/candidate-source"
      - name: Retain temporary sanitized build evidence
        if: always()
        uses: actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a
        with:
          name: infuse-canary-{source['commit'][:10]}-${{{{ github.run_id }}}}-${{{{ github.run_attempt }}}}
          path: canary-artifacts/
          if-no-files-found: error
          retention-days: 1
          compression-level: 0
'''


def prepare(m, output):
    verify_harness(m)
    destination = output / "ci/infuse-canary"
    destination.mkdir(parents=True)
    for p in harness_section(m, "hosted").iterdir():
        if p.is_file():
            shutil.copyfile(p, destination / p.name)
    atomic_json(destination / "binding.json", binding(m))
    if m["schema"] != 3:
        (output / ".github/workflows").mkdir(parents=True)
        (output / ".github/workflows/ci.yml").write_text(workflow(m))
    atomic_json(output / "preparation.json", {"schema": 1, "status": "prepared-only", "sourceCommit": m["source"]["commit"], "binding": digest(destination / "binding.json"), "harnessLock": m["harnessLockSha256"], "uploaded": False, "dispatched": False})
    return {"status": "prepared-only", "files": len(inventory(output)), "branch": m["ci"]["branch"]}


def verify_download(m, artifact_root, output):
    verify_harness(m)
    require(m["ci"]["commit"] != "0" * 40 and m["ci"]["runId"] > 0, "CI identities still pending")
    binding_path = output / "binding.json"
    atomic_json(binding_path, binding(m))
    result = subprocess.check_output([sys.executable, "-I", str(harness_section(m, "collector") / "trusted-verifier.py"), str(artifact_root), "--binding", str(binding_path), "--binding-sha256", digest(binding_path)["sha256"], "--source-commit", m["source"]["commit"], "--ci-commit", m["ci"]["commit"]], timeout=600)
    receipt = json.loads(result)
    require(receipt["status"] == "passed", "hosted evidence failed")
    atomic_json(output / "verified-receipt.json", receipt)
    return receipt


def collect(m, output):
    verify_harness(m)
    require(m["ci"]["commit"] != "0" * 40 and m["ci"]["runId"] > 0, "CI identities still pending")
    bp = output / "binding.json"
    atomic_json(bp, binding(m))
    collector = harness_section(m, "collector")
    artifact_identity = m["ci"]["commit"] if m["schema"] == 3 else m["source"]["commit"][:10]
    command = [sys.executable, "-I", str(collector / "collect-completed.py"), "--binding", str(bp), "--binding-sha256", digest(bp)["sha256"], "--source-commit", m["source"]["commit"], "--ci-commit", m["ci"]["commit"], "--run-id", str(m["ci"]["runId"]), "--artifact-name", f"infuse-canary-{artifact_identity}-{m['ci']['runId']}-1", "--output-root", str(output / "collected"), "--verifier-sha256", digest(collector / "trusted-verifier.py")["sha256"]]
    # Credentials enter the trusted gh collector, never the candidate Docker boundary.
    completed = subprocess.run(command, check=True, capture_output=True, timeout=1800)
    (output / "collector-result.json").write_bytes(completed.stdout)
    return {"status": "hosted-package-qualified", "runId": m["ci"]["runId"]}
