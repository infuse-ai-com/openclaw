"""Package only explicitly inventory-bound private inputs; never upload them."""
import shutil
import tarfile
from pathlib import Path

from . import hydrate
from .assets import complete, core_asset
from .io import atomic_json, digest, read_json, real_directory, relative_path, require


def prepare(m, inputs, hydration_sha256, output):
    complete(m)
    root = real_directory(inputs)
    h = hydrate.metadata(root, hydration_sha256)
    hydrate.verify(root, h, omitted=True)
    candidate = read_json(root / "candidate-manifest.json")
    require(candidate["hostCommit"] == m["source"]["commit"], "private handoff belongs to a different candidate")
    core = core_asset(m)
    require({k: h["publicCore"][k] for k in ("bytes", "sha256")} == {k: core[k] for k in ("bytes", "sha256")}, "handoff Core mismatch")
    require(h["publicCore"]["url"] == f"https://github.com/{m['source']['repository']}/releases/download/{m['release']['tag']}/{core['name']}", "handoff release mismatch")
    bundle = output / "private-inputs"
    bundle.mkdir(mode=0o700)
    omissions = set(h["publicCore"]["omittedArchiveSlots"])
    copied = []
    for group in h["sets"]:
        shutil.copyfile(root / group["inventory"], bundle / group["inventory"])
        (bundle / group["root"]).mkdir()
        rows = read_json(root / group["inventory"])["files"]
        for row in rows:
            slot = group["root"] + "/" + row["path"]
            if slot in omissions:
                continue
            target = bundle / relative_path(slot)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(root / slot, target)
            target.chmod(0o755 if row["mode"] == "100755" else 0o644)
            copied.append(slot)
    for name in ("HYDRATE.json", "candidate-manifest.json"):
        shutil.copyfile(root / name, bundle / name)
    shutil.copyfile(Path(hydrate.__file__), bundle / "hydrate.py")
    (bundle / "PRIVATE-INPUTS.md").write_text(f"Private company source. Do not attach this archive to public GitHub.\n\nAuthenticate the bundle SHA256 from the sender, then run:\n\npython3 -B -I hydrate.py --manifest-sha256 {hydration_sha256}\n\nHydration downloads the public Core and checks four complete file inventories.\nNo candidate code executes. This is a reference/recipe; production delivery\nremains owned by openclaw-k8s-swarm. No deployment is authorized by this bundle.\n")
    hydrate.verify(bundle, hydrate.metadata(bundle, hydration_sha256), omitted=True)
    archive_path = output / "swarm-upgrade-inputs.tar.gz"
    with tarfile.open(archive_path, "w:gz") as archive:
        for path in sorted(bundle.rglob("*")):
            if path.is_file():
                archive.add(path, arcname=path.relative_to(bundle).as_posix(), recursive=False)
    receipt = {"schema": 1, "classification": "private-company-source", "status": "prepared-only", "sourceCommit": m["source"]["commit"], "archive": digest(archive_path), "hydrationManifestSha256": hydration_sha256, "filesCopied": len(copied), "coreCopiesOmitted": 2, "uploaded": False, "deployed": False}
    atomic_json(output / "handoff-receipt.json", receipt)
    return receipt


def extract(path, sha256, output):
    require(digest(path)["sha256"] == sha256, "private archive digest mismatch")
    # Validate the entire table before writing any archive member.
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        require(0 < len(members) < 10000 and sum(e.size for e in members) <= 400 * 1024**2, "private archive exceeds ceiling")
        names = set()
        for entry in members:
            relative_path(entry.name)
            require(entry.isfile() and entry.name not in names, "archive link, special entry or duplicate")
            require(entry.mode & 0o7000 == 0, "privileged archive mode refused")
            names.add(entry.name)
        require({"HYDRATE.json", "candidate-manifest.json", "hydrate.py"} <= names, "handoff metadata incomplete")
        for entry in members:
            require(not any(parent.as_posix() in names for parent in Path(entry.name).parents if parent.as_posix() != "."), "archive file/directory collision")
        root = output / "private-inputs"
        root.mkdir(mode=0o700)
        for entry in members:
            target = root / entry.name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream, archive.extractfile(entry) as source:
                shutil.copyfileobj(source, stream)
            target.chmod(0o755 if entry.mode & 0o111 else 0o644)
    return {"status": "extracted-only", "members": len(members), "candidateCodeExecuted": False}
