"""Prepare and authenticate externally owned Phase 5 runtime adapters."""
import copy
from pathlib import Path
import re
import shutil

from .io import atomic_json, digest, fingerprint, inventory, read_json, real_directory, relative_path, require
from .manifest import ROOT


PROFILE_ROOT = ROOT / "phase5-profiles"
LANE_STATUSES = {"passed", "failed", "unverified"}


def keys(value, names, label):
    require(isinstance(value, dict) and set(value) == set(names.split()), "unexpected fields in " + label)


def text(value, label, maximum=500):
    require(isinstance(value, str) and value and len(value) <= maximum, "invalid " + label)
    return value


def sha256(value, label):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None, "invalid " + label)
    return value


def commit(value, label):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{40}", value) is not None, "invalid " + label)
    return value


def positive(value, label):
    require(type(value) is int and value > 0, "invalid " + label)
    return value


def profile_path(m):
    return PROFILE_ROOT / (m["source"]["upstreamTag"] + ".json")


def load_profile(m, root=ROOT):
    path = root / "phase5-profiles" / (m["source"]["upstreamTag"] + ".json")
    profile = read_json(path)
    keys(profile, "schema version lanes", "Phase 5 profile")
    require(profile["schema"] == 1 and profile["version"] == m["build"]["version"], "Phase 5 profile/version mismatch")
    require(isinstance(profile["lanes"], list) and profile["lanes"], "Phase 5 profile has no lanes")
    seen = set()
    for lane in profile["lanes"]:
        keys(lane, "name platforms architectures minCpus minMemoryBytes networks secretClasses requiredChecks cleanupRequired", "Phase 5 lane")
        name = text(lane["name"], "lane name", 80)
        require(name not in seen and re.fullmatch(r"[a-zA-Z][a-zA-Z0-9]+", name), "duplicate or invalid Phase 5 lane")
        seen.add(name)
        for field, allowed in (
            ("platforms", {"linux", "darwin"}),
            ("architectures", {"arm64", "amd64"}),
            ("networks", {"offline", "public-proxy", "disposable-private"}),
            ("secretClasses", {"none", "disposable-fixture"}),
        ):
            values = lane[field]
            require(isinstance(values, list) and values and len(values) == len(set(values)) and set(values) <= allowed, "invalid " + field + " for " + name)
        positive(lane["minCpus"], "minimum CPUs")
        positive(lane["minMemoryBytes"], "minimum memory")
        checks = lane["requiredChecks"]
        require(isinstance(checks, list) and checks and len(checks) == len(set(checks)), "invalid required checks for " + name)
        require(all(isinstance(item, str) and re.fullmatch(r"[a-zA-Z][a-zA-Z0-9]+", item) for item in checks), "invalid check name for " + name)
        require(lane["cleanupRequired"] is True, "Phase 5 adapters require cleanup")
    return profile


def expected_package_names(m):
    version = m["build"]["version"]
    names = {"openclaw": f"openclaw-{version}-{m['source']['commit'][:10]}.tgz"}
    names.update({"@openclaw/" + plugin: f"openclaw-{plugin}-{version}.tgz" for plugin in m["build"]["plugins"]})
    return names


def verify_hosted_receipt(m, path):
    require(digest(path)["sha256"] == m["referenceEvidence"]["verifiedReceiptSha256"], "trusted hosted receipt changed")
    receipt = read_json(path)
    require(receipt.get("status") == "passed", "hosted receipt did not pass")
    require(receipt.get("sourceCommit") == m["source"]["commit"], "hosted source mismatch")
    require(receipt.get("bootstrapCommit") == m["ci"]["commit"], "hosted CI mismatch")
    require(receipt.get("allStepsPassed") is True, "hosted steps incomplete")
    positive(receipt.get("hostHeartbeats"), "host heartbeat count")
    graphs = receipt.get("compilerGraphs")
    require(isinstance(graphs, list) and len(graphs) == m["build"]["compilerGraphs"] and len(graphs) == len(set(graphs)), "hosted compiler graph closure mismatch")
    packages = receipt.get("packages")
    expected = expected_package_names(m)
    require(isinstance(packages, list) and len(packages) == len(expected), "hosted package closure mismatch")
    actual = {}
    for package in packages:
        keys(package, "path name bytes sha256", "hosted package")
        name = text(package["name"], "hosted package name", 120)
        require(name in expected and name not in actual and Path(relative_path(package["path"])).name == expected[name], "unexpected hosted package")
        positive(package["bytes"], "hosted package bytes")
        sha256(package["sha256"], "hosted package SHA256")
        actual[name] = package
    require(set(actual) == set(expected), "hosted package names incomplete")
    return receipt


def verify_candidate_manifest(m, path, packages):
    candidate = read_json(path)
    core = next(package for package in packages if package["name"] == "openclaw")
    expected = {
        "hostVersion": m["build"]["version"],
        "hostCommit": m["source"]["commit"],
        "baseCommit": m["source"]["upstreamCommit"],
        "buildTimestamp": m["build"]["timestamp"],
        "sourceSnapshotSha256": m["source"]["snapshot"]["sha256"],
        "sourceLockSha256": m["source"]["lockSha256"],
        "hostPackageSha256": core["sha256"],
        "hostPackageFile": Path(core["path"]).name,
        "ciCommit": m["ci"]["commit"],
        "workflowRunId": m["ci"]["runId"],
        "workflowRunAttempt": 1,
    }
    require(all(candidate.get(key) == value for key, value in expected.items()), "candidate manifest dependency pin mismatch")
    return candidate


def verify_packages(m, package_dir, packages):
    root = real_directory(package_dir)
    expected = expected_package_names(m)
    require({path.name for path in root.iterdir()} == set(expected.values()) and all(path.is_file() for path in root.iterdir()), "package directory must contain exactly five flat archives")
    by_name = {package["name"]: package for package in packages}
    result = []
    for package_name, filename in sorted(expected.items()):
        pin = digest(root / filename)
        require(pin == {key: by_name[package_name][key] for key in ("bytes", "sha256")}, "hosted package bytes differ: " + filename)
        result.append({"name": package_name, "file": filename, **pin})
    return result


def verify_fixture_specs(m, profile, path):
    specs = read_json(path)
    keys(specs, "schema candidateId lanes", "fixture specs")
    require(specs["schema"] == 1 and specs["candidateId"] == m["candidateId"], "fixture specs belong to another candidate")
    expected = {lane["name"]: lane for lane in profile["lanes"]}
    require(isinstance(specs["lanes"], list) and len(specs["lanes"]) == len(expected), "fixture lane closure mismatch")
    seen = set()
    for spec in specs["lanes"]:
        keys(spec, "name controller fixture resources dependencies execution", "fixture lane")
        name = spec["name"]
        require(name in expected and name not in seen, "unexpected or duplicate fixture lane")
        seen.add(name)
        lane = expected[name]
        controller = spec["controller"]
        keys(controller, "repository commit path bytes sha256", "adapter controller")
        text(controller["repository"], "controller repository", 240)
        commit(controller["commit"], "controller commit")
        relative_path(controller["path"])
        positive(controller["bytes"], "controller bytes")
        sha256(controller["sha256"], "controller SHA256")
        fixture = spec["fixture"]
        keys(fixture, "repository commit profile inventorySha256", "adapter fixture")
        text(fixture["repository"], "fixture repository", 240)
        commit(fixture["commit"], "fixture commit")
        text(fixture["profile"], "fixture profile", 160)
        relative_path(fixture["profile"])
        sha256(fixture["inventorySha256"], "fixture inventory SHA256")
        resources = spec["resources"]
        keys(resources, "platform architecture cpus memoryBytes", "adapter resources")
        require(resources["platform"] in lane["platforms"] and resources["architecture"] in lane["architectures"], "adapter platform outside profile: " + name)
        require(type(resources["cpus"]) is int and resources["cpus"] >= lane["minCpus"], "adapter CPU budget too small: " + name)
        require(type(resources["memoryBytes"]) is int and resources["memoryBytes"] >= lane["minMemoryBytes"], "adapter memory budget too small: " + name)
        dependencies = spec["dependencies"]
        require(isinstance(dependencies, list) and dependencies, "adapter dependencies missing: " + name)
        dependency_names = set()
        for dependency in dependencies:
            keys(dependency, "name version sha256", "adapter dependency")
            dependency_name = text(dependency["name"], "dependency name", 160)
            require(dependency_name not in dependency_names, "duplicate adapter dependency")
            dependency_names.add(dependency_name)
            text(dependency["version"], "dependency version", 240)
            sha256(dependency["sha256"], "dependency SHA256")
        execution = spec["execution"]
        keys(execution, "timeoutMinutes network secretClass disposable", "adapter execution")
        positive(execution["timeoutMinutes"], "adapter timeout")
        require(execution["network"] in lane["networks"] and execution["secretClass"] in lane["secretClasses"], "adapter execution boundary outside profile: " + name)
        require(execution["disposable"] is True, "Phase 5 fixture must be disposable: " + name)
    require(seen == set(expected), "fixture specs incomplete")
    return specs


def prepare(m, hosted_receipt_path, candidate_manifest_path, package_dir, fixture_specs_path, output):
    profile = load_profile(m)
    hosted = verify_hosted_receipt(m, hosted_receipt_path)
    verify_candidate_manifest(m, candidate_manifest_path, hosted["packages"])
    packages = verify_packages(m, package_dir, hosted["packages"])
    specs = verify_fixture_specs(m, profile, fixture_specs_path)

    shutil.copyfile(profile_path(m), output / "phase5-profile.json")
    shutil.copyfile(fixture_specs_path, output / "fixture-specs.json")
    shutil.copyfile(candidate_manifest_path, output / "candidate-manifest.json")
    package_output = output / "packages"
    package_output.mkdir(mode=0o700)
    for package in packages:
        shutil.copyfile(Path(package_dir) / package["file"], package_output / package["file"])

    profile_pin = digest(output / "phase5-profile.json")
    spec_pin = digest(output / "fixture-specs.json")
    candidate_pin = digest(output / "candidate-manifest.json")
    package_set_sha256 = fingerprint(packages)
    plan = {
        "schema": 1,
        "status": "prepared-only",
        "candidateId": m["candidateId"],
        "sourceCommit": m["source"]["commit"],
        "ciCommit": m["ci"]["commit"],
        "workflowRunId": m["ci"]["runId"],
        "hosted": {
            "receipt": digest(hosted_receipt_path),
            "hostHeartbeats": hosted["hostHeartbeats"],
            "compilerGraphs": len(hosted["compilerGraphs"]),
            "allStepsPassed": hosted["allStepsPassed"],
        },
        "candidateManifest": candidate_pin,
        "packages": packages,
        "packageSetSha256": package_set_sha256,
        "phase5Profile": profile_pin,
        "fixtureSpecs": spec_pin,
        "lanes": [lane["name"] for lane in profile["lanes"]],
        "candidateCodeExecuted": False,
        "published": False,
        "deployed": False,
    }
    atomic_json(output / "phase5-plan.json", plan)
    return {"status": "phase5-adapters-prepared", "lanes": len(profile["lanes"]), "packageSetSha256": package_set_sha256, "candidateCodeExecuted": False}


def verify_plan_root(m, plan_dir):
    root = real_directory(plan_dir)
    require({path.name for path in root.iterdir()} == {"phase5-plan.json", "phase5-profile.json", "fixture-specs.json", "candidate-manifest.json", "packages"}, "Phase 5 plan root inventory changed")
    plan = read_json(root / "phase5-plan.json")
    keys(plan, "schema status candidateId sourceCommit ciCommit workflowRunId hosted candidateManifest packages packageSetSha256 phase5Profile fixtureSpecs lanes candidateCodeExecuted published deployed", "Phase 5 plan")
    require(plan["schema"] == 1 and plan["status"] == "prepared-only", "unexpected Phase 5 plan state")
    require((plan["candidateId"], plan["sourceCommit"], plan["ciCommit"], plan["workflowRunId"]) == (m["candidateId"], m["source"]["commit"], m["ci"]["commit"], m["ci"]["runId"]), "Phase 5 plan candidate mismatch")
    require(plan["candidateCodeExecuted"] is False and plan["published"] is False and plan["deployed"] is False, "Phase 5 preparation claimed an external effect")
    require(digest(root / "phase5-profile.json") == plan["phase5Profile"], "Phase 5 profile changed")
    require(digest(root / "fixture-specs.json") == plan["fixtureSpecs"], "fixture specs changed")
    require(digest(root / "candidate-manifest.json") == plan["candidateManifest"], "candidate manifest changed")
    profile = load_profile(m)
    require(read_json(root / "phase5-profile.json") == profile, "Phase 5 profile content mismatch")
    specs = verify_fixture_specs(m, profile, root / "fixture-specs.json")
    require(plan["lanes"] == [lane["name"] for lane in profile["lanes"]], "Phase 5 lane order mismatch")
    package_root = real_directory(root / "packages")
    require({path.name for path in package_root.iterdir()} == {item["file"] for item in plan["packages"]}, "prepared package closure changed")
    for package in plan["packages"]:
        require(digest(package_root / package["file"]) == {key: package[key] for key in ("bytes", "sha256")}, "prepared package changed: " + package["file"])
    require(fingerprint(plan["packages"]) == plan["packageSetSha256"], "package-set fingerprint mismatch")
    return root, plan, profile, specs


def expected_candidate(plan, plan_sha256):
    core = next(package for package in plan["packages"] if package["name"] == "openclaw")
    return {
        "sourceCommit": plan["sourceCommit"],
        "ciCommit": plan["ciCommit"],
        "workflowRunId": plan["workflowRunId"],
        "coreArchiveSha256": core["sha256"],
        "candidateManifestSha256": plan["candidateManifest"]["sha256"],
        "packageSetSha256": plan["packageSetSha256"],
        "phase5PlanSha256": plan_sha256,
    }


def verify_lane_receipt(lane_profile, lane_spec, lane_root, candidate):
    lane_root = real_directory(lane_root)
    require({path.name for path in lane_root.iterdir()} == {"receipt.json", "evidence"}, "lane root inventory mismatch: " + lane_profile["name"])
    receipt = read_json(lane_root / "receipt.json")
    keys(receipt, "schema lane status candidate adapter fixture resources checks evidence cleanup scopeLimits reason", "Phase 5 lane receipt")
    name = lane_profile["name"]
    require(receipt["schema"] == 1 and receipt["lane"] == name and receipt["status"] in LANE_STATUSES, "invalid lane receipt identity: " + name)
    require(receipt["candidate"] == candidate, "lane candidate mismatch: " + name)
    require(receipt["adapter"] == lane_spec["controller"] and receipt["fixture"] == lane_spec["fixture"], "lane adapter/fixture mismatch: " + name)
    require(receipt["resources"] == lane_spec["resources"], "lane resources mismatch: " + name)
    checks = receipt["checks"]
    require(isinstance(checks, dict) and set(checks) == set(lane_profile["requiredChecks"]), "lane check closure mismatch: " + name)
    for check_name, check in checks.items():
        keys(check, "status metrics", "lane check")
        require(check["status"] in LANE_STATUSES and isinstance(check["metrics"], dict), "invalid lane check: " + name + "/" + check_name)
    evidence_root = real_directory(lane_root / "evidence")
    evidence_rows = inventory(evidence_root)
    keys(receipt["evidence"], "files inventorySha256", "lane evidence")
    require(receipt["evidence"] == {"files": len(evidence_rows), "inventorySha256": fingerprint(evidence_rows)}, "lane evidence inventory mismatch: " + name)
    keys(receipt["cleanup"], "status ownedResourcesOnly", "lane cleanup")
    require(receipt["cleanup"]["status"] in LANE_STATUSES and receipt["cleanup"]["ownedResourcesOnly"] is True, "invalid lane cleanup: " + name)
    require(isinstance(receipt["scopeLimits"], list) and len(receipt["scopeLimits"]) == len(set(receipt["scopeLimits"])) and all(isinstance(item, str) and item for item in receipt["scopeLimits"]), "invalid lane scope limits: " + name)
    require(isinstance(receipt["reason"], str) and len(receipt["reason"]) <= 1000, "invalid lane reason: " + name)
    if receipt["status"] == "passed":
        require(all(check["status"] == "passed" for check in checks.values()), "passed lane has an incomplete check: " + name)
        require(receipt["cleanup"]["status"] == "passed", "passed lane cleanup incomplete: " + name)
        require(evidence_rows, "passed lane has no evidence: " + name)
    elif receipt["status"] == "unverified":
        require(receipt["reason"], "unverified lane requires a reason: " + name)
    else:
        require(receipt["reason"] and (any(check["status"] != "passed" for check in checks.values()) or receipt["cleanup"]["status"] != "passed"), "failed lane requires failed evidence: " + name)
    return receipt


def qualification(m, plan, plan_sha256, profile, receipts, scope_limits):
    core = next(package for package in plan["packages"] if package["name"] == "openclaw")
    checks = {
        "hosted": {
            "status": "passed",
            "stages": 13,
            "compilerGraphs": plan["hosted"]["compilerGraphs"],
            "packages": len(plan["packages"]),
            "hostHeartbeats": plan["hosted"]["hostHeartbeats"],
        }
    }
    by_name = {lane["name"]: lane for lane in profile["lanes"]}
    for name, receipt in receipts.items():
        checks[name] = {
            "status": receipt["status"],
            "adapter": receipt["adapter"],
            "fixture": receipt["fixture"],
            "resources": receipt["resources"],
            "checks": receipt["checks"],
            "evidence": receipt["evidence"],
            "cleanup": receipt["cleanup"],
        }
        require(name in by_name, "unexpected qualification lane")
    return {
        "schema": 1,
        "version": m["build"]["version"],
        "sourceCommit": m["source"]["commit"],
        "ciCommit": m["ci"]["commit"],
        "workflowRun": f"https://github.com/{m['source']['repository']}/actions/runs/{m['ci']['runId']}",
        "coreArchiveSha256": core["sha256"],
        "candidateManifestSha256": plan["candidateManifest"]["sha256"],
        "phase5PlanSha256": plan_sha256,
        "phase5ProfileSha256": plan["phase5Profile"]["sha256"],
        "fixtureSpecsSha256": plan["fixtureSpecs"]["sha256"],
        "checks": checks,
        "scopeLimits": scope_limits,
        "status": "passed-with-declared-scope-limits",
        "recordedBeforeReleasePublication": True,
        "deployed": False,
    }


def collect(m, plan_dir, evidence_dir, output):
    plan_root, plan, profile, specs = verify_plan_root(m, plan_dir)
    plan_pin = digest(plan_root / "phase5-plan.json")
    evidence_root = real_directory(evidence_dir)
    lane_names = [lane["name"] for lane in profile["lanes"]]
    require({path.name for path in evidence_root.iterdir()} == set(lane_names) and all(path.is_dir() for path in evidence_root.iterdir()), "Phase 5 evidence must contain exactly the lane directories")
    spec_by_name = {spec["name"]: spec for spec in specs["lanes"]}
    candidate = expected_candidate(plan, plan_pin["sha256"])
    receipts = {}
    for lane in profile["lanes"]:
        receipts[lane["name"]] = verify_lane_receipt(lane, spec_by_name[lane["name"]], real_directory(evidence_root / lane["name"]), candidate)
    qualified = all(receipt["status"] == "passed" for receipt in receipts.values())
    scope_limits = sorted({item for receipt in receipts.values() for item in receipt["scopeLimits"]})
    collection = {
        "schema": 1,
        "status": "passed" if qualified else "incomplete",
        "candidate": candidate,
        "lanes": {name: {key: copy.deepcopy(receipt[key]) for key in ("status", "checks", "evidence", "cleanup", "scopeLimits", "reason")} for name, receipt in receipts.items()},
        "scopeLimits": scope_limits,
        "qualificationWritten": qualified,
        "published": False,
        "deployed": False,
    }
    atomic_json(output / "phase5-collection.json", collection)
    if qualified:
        atomic_json(output / "LINUX-QUALIFICATION.json", qualification(m, plan, plan_pin["sha256"], profile, receipts, scope_limits))
    return {"status": "phase5-qualified" if qualified else "phase5-incomplete", "lanes": len(receipts), "qualificationWritten": qualified, "published": False, "deployed": False}
