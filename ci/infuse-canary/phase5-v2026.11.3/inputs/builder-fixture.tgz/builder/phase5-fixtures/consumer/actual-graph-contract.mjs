// Candidate-independent installed-lock closure checks. Keep behavior aligned
// with the retained pure controller without modifying its reviewed harness lock.
import assert from "node:assert/strict";

export const HOST_PATH = "node_modules/openclaw";
const fields = ["peerDependencies", "dependencies", "optionalDependencies"];
const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const edges = (metadata, field) => {
  const value = metadata[field] ?? {};
  assert(object(value), `Invalid ${field} metadata`);
  for (const [name, spec] of Object.entries(value)) {
    assert(typeof spec === "string" && spec.length > 0, `Invalid edge spec: ${name}`);
    assert(/^(?:@[^/\\\s]+\/)?[^/\\\s]+$/.test(name) && name !== "." && name !== "..", `Invalid dependency name: ${name}`);
  }
  return value;
};

export function packageAncestors(path) {
  if (path === "") return [];
  assert(path.startsWith("node_modules/"), `Unsupported package path: ${path}`);
  const names = path.slice("node_modules/".length).split("/node_modules/");
  const result = [];
  for (const name of names) {
    assert(/^(?:@[^/\\\s]+\/)?[^/\\\s]+$/.test(name) && name !== "." && name !== "..", `Unsupported package path: ${path}`);
    result.push(`${result.length ? `${result.at(-1)}/` : ""}node_modules/${name}`);
  }
  assert.equal(result.at(-1), path);
  return result;
}

export function resolveGraphEdge(packages, path, dependency) {
  const search = [...packageAncestors(path).reverse(), ""];
  return search.map((root) => `${root ? `${root}/` : ""}node_modules/${dependency}`).find((candidate) => Object.hasOwn(packages, candidate)) ?? null;
}

function rejectsHostPolicy(policy) {
  assert(object(policy), "Workspace override policy must be a normalized object");
  for (const [selector, value] of Object.entries(policy)) {
    assert(!/^openclaw(?:@|$)/.test(selector), "Workspace policy can select the synthetic host carrier");
    if (object(value)) rejectsHostPolicy(value);
    else {
      assert(typeof value === "string", "Normalized workspace override must be a string or object");
      assert(!/^npm:openclaw(?:@|$)/.test(value), "Workspace policy aliases an incoming edge to the synthetic host carrier");
    }
  }
}

export function assertActualGraphContract({ lock, archiveManifest, archiveSpec, archiveIntegrity, workspacePolicy }) {
  assert.equal(lock.lockfileVersion, 3);
  assert(object(lock.packages));
  const root = lock.packages[""];
  assert(object(root));
  assert.deepEqual(edges(root, "dependencies"), { openclaw: archiveSpec });
  for (const field of ["optionalDependencies", "peerDependencies", "devDependencies"]) assert.deepEqual(root[field] ?? {}, {}, `Unsupported additional incoming root edge: ${field}`);
  assert.equal(root.link, undefined);
  const host = lock.packages[HOST_PATH];
  assert(object(host));
  assert.equal(host.name ?? "openclaw", "openclaw");
  assert.equal(host.version, archiveManifest.version);
  assert.equal(host.resolved, archiveSpec.replace("file:./", "file:"));
  assert.equal(host.integrity, archiveIntegrity);
  assert.equal(host.link, undefined);
  assert.equal(host.hasShrinkwrap, undefined, "Host must not own a real shrinkwrap");
  for (const field of fields) assert.deepEqual(edges(host, field), archiveManifest[field] ?? {}, `Host ${field} differs from authenticated archive`);
  rejectsHostPolicy(workspacePolicy);
  const packages = lock.packages;
  for (const [path, metadata] of Object.entries(packages)) {
    assert(object(metadata), `Invalid package metadata: ${path}`);
    if (path === "") continue;
    packageAncestors(path);
    assert(typeof metadata.version === "string" && metadata.version.length > 0, `Missing concrete package identity: ${path}`);
    assert.equal(metadata.link, undefined, `Package links are unsupported: ${path}`);
    assert(metadata.extraneous !== true, `Extraneous package is unsupported: ${path}`);
    for (const field of fields) edges(metadata, field);
  }
  const pending = [""];
  const reached = new Set();
  let declaredEdges = 0;
  let optionalMissingEdges = 0;
  while (pending.length > 0) {
    const path = pending.pop();
    if (reached.has(path)) continue;
    reached.add(path);
    const metadata = packages[path];
    for (const field of fields) {
      for (const name of Object.keys(edges(metadata, field))) {
        const target = resolveGraphEdge(packages, path, name);
        const optional = field === "optionalDependencies" || Object.hasOwn(metadata.optionalDependencies ?? {}, name) ||
          (field === "peerDependencies" && metadata.peerDependenciesMeta?.[name]?.optional === true);
        assert(target !== null || optional, `Missing required ${field} edge: ${path} -> ${name}`);
        if (target === null) optionalMissingEdges += 1;
        declaredEdges += 1;
      }
    }
    const effective = Object.assign({}, ...fields.map((field) => edges(metadata, field)));
    for (const name of Object.keys(effective)) {
      const target = resolveGraphEdge(packages, path, name);
      if (target !== null) pending.push(target);
    }
  }
  assert.deepEqual([...reached].sort(), Object.keys(packages).sort(), "A package occurrence is outside the canonical effective dependency closure");
  return {
    packageCount: reached.size,
    declaredEdges,
    optionalMissingEdges,
    prerequisites: {
      rootHasOnlyCoreCarrier: true,
      noRootOptionalPeerOrDevIncoming: true,
      hostEdgesAuthenticated: true,
      noHostWorkspaceSelectorOrAlias: true,
      fullEffectiveClosure: true,
    },
  };
}
