import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";
import { access, cp, lstat, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { assertActualGraphContract } from "./actual-graph-contract.mjs";

const lane = process.argv[2];
assert(["arm64Consumer", "publicInventory"].includes(lane));
assert.equal(process.platform, "linux");
assert.equal(process.arch, "arm64");

const work = "/work";
const fixture = "/fixture";
const packagesRoot = "/phase5/packages";
const planPath = "/phase5/phase5-plan.json";
const candidatePath = "/phase5/candidate-manifest.json";
const contract = JSON.parse(await readFile(join(fixture, "candidate-contract.json"), "utf8"));
const plan = JSON.parse(await readFile(planPath, "utf8"));
const candidate = JSON.parse(await readFile(candidatePath, "utf8"));

assert.equal(contract.schema, 1);
assert.equal(candidate.schema, 1);
assert.equal(candidate.hostVersion, contract.version);
assert.equal(candidate.hostCommit, contract.sourceCommit);
assert.equal(candidate.sourceLockSha256, contract.sourceLockSha256);
assert.equal(candidate.buildTimestamp, contract.buildTimestamp);
assert.equal(plan.sourceCommit, contract.sourceCommit);
assert.deepEqual(contract.workspaceOverrides, {});
assert.equal(process.version.slice(1), contract.node.version);
assert.match(contract.sourcePackageJsonSha256, /^[a-f0-9]{64}$/);

const sha256 = async (path) => createHash("sha256").update(await readFile(path)).digest("hex");
const sha512Integrity = async (path) => `sha512-${createHash("sha512").update(await readFile(path)).digest("base64")}`;
const run = (command, args, options = {}) => new Promise((resolvePromise, rejectPromise) => {
  const child = spawn(command, args, { cwd: options.cwd ?? work, env: options.env ?? process.env, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [];
  const stderr = [];
  let bytes = 0;
  const append = (target) => (chunk) => {
    bytes += chunk.length;
    if (bytes > 64 * 1024 * 1024) child.kill("SIGKILL");
    target.push(chunk);
  };
  child.stdout.on("data", append(stdout));
  child.stderr.on("data", append(stderr));
  const timer = setTimeout(() => child.kill("SIGKILL"), options.timeout ?? 900_000);
  child.once("error", rejectPromise);
  child.once("close", async (code, signal) => {
    clearTimeout(timer);
    const out = Buffer.concat(stdout);
    const err = Buffer.concat(stderr);
    if (options.record) {
      await writeFile(join(work, `${options.record}.stdout.log`), out, { mode: 0o600 });
      await writeFile(join(work, `${options.record}.stderr.log`), err, { mode: 0o600 });
    }
    if (code !== 0) rejectPromise(Error(`${command} exited ${code ?? signal}: ${err.toString().slice(-1000)}`));
    else resolvePromise(out);
  });
});

const inputBefore = {};
for (const item of plan.packages) {
  const path = join(packagesRoot, item.file);
  assert.equal(await sha256(path), item.sha256);
  inputBefore[item.file] = item.sha256;
}
assert.equal(await sha256(candidatePath), plan.candidateManifest.sha256);

const core = plan.packages.find((item) => item.name === "openclaw");
assert(core);
assert.equal(core.file, candidate.hostPackageFile);
assert.equal(core.sha256, candidate.hostPackageSha256);
const localArchive = join(work, core.file);
await cp(join(packagesRoot, core.file), localArchive);

const packageMetadata = [];
const packageManifests = new Map();
for (const item of plan.packages) {
  const output = await run("tar", ["-xOzf", join(packagesRoot, item.file), "package/package.json"], { timeout: 60_000 });
  const metadata = JSON.parse(output.toString());
  assert.equal(metadata.name, item.name);
  assert.equal(metadata.version, contract.version);
  packageManifests.set(metadata.name, metadata);
  packageMetadata.push({ name: metadata.name, version: metadata.version, file: item.file, sha256: item.sha256 });
}

const consumerManifest = { private: true, name: "phase5-normal-consumer", version: "1.0.0", dependencies: { openclaw: `file:./${core.file}` } };
await writeFile(join(work, "package.json"), `${JSON.stringify(consumerManifest, null, 2)}\n`, { mode: 0o600 });
await writeFile(join(work, ".npmrc"), "audit=false\nfund=false\npackage-lock=true\nregistry=https://registry.npmjs.org/\n", { mode: 0o600 });
await mkdir(join(work, "home"), { mode: 0o700 });
const npmEnvironment = { ...process.env, HOME: join(work, "home"), npm_config_userconfig: join(work, ".npmrc"), npm_config_globalconfig: join(work, "empty-global-npmrc") };
await writeFile(npmEnvironment.npm_config_globalconfig, "", { mode: 0o600 });
const npmVersion = (await run("npm", ["--version"], { env: npmEnvironment, timeout: 30_000 })).toString().trim();
await run("npm", ["install", "--foreground-scripts", "--no-audit", "--no-fund"], { env: npmEnvironment, timeout: 1_800_000, record: "npm-install" });

const host = join(work, "node_modules/openclaw");
const hostManifest = JSON.parse(await readFile(join(host, "package.json"), "utf8"));
const buildInfo = JSON.parse(await readFile(join(host, "dist/build-info.json"), "utf8"));
assert.equal(hostManifest.name, "openclaw");
assert.equal(hostManifest.version, contract.version);
assert.deepEqual(buildInfo, { version: contract.version, commit: contract.sourceCommit, builtAt: contract.buildTimestamp,
  buildId: `${contract.version}-${contract.sourceCommit.slice(0, 12)}-${contract.buildTimestamp.replaceAll(":", "-")}` });
await assert.rejects(access(join(host, ".openclaw-lifecycle-pending")));

const unpack = join(work, "unpacked");
await mkdir(unpack, { mode: 0o700 });
await run("tar", ["-xzf", localArchive, "-C", unpack], { timeout: 300_000, record: "archive-extract" });
const packedRoot = join(unpack, "package");
let archiveFiles = 0;
let privateAiFiles = 0;
const verifyTree = async (directory, relative = "") => {
  for (const name of await readdir(directory)) {
    const archivePath = join(directory, name);
    const child = relative ? `${relative}/${name}` : name;
    const info = await lstat(archivePath);
    assert(!info.isSymbolicLink(), `Archive path is a symlink: ${child}`);
    if (info.isDirectory()) {
      await verifyTree(archivePath, child);
      continue;
    }
    assert(info.isFile(), `Archive path is not regular: ${child}`);
    archiveFiles += 1;
    if (child === ".openclaw-lifecycle-pending") {
      assert.equal(await sha256(archivePath), "52d26753462488ad21852bc6718e21b84835f53765304d0a1e1b89d05a2a71b1");
      continue;
    }
    const installed = join(host, child);
    const installedInfo = await lstat(installed);
    assert(installedInfo.isFile() && !installedInfo.isSymbolicLink(), `Installed path differs: ${child}`);
    assert.equal(await sha256(installed), await sha256(archivePath), `Installed bytes differ: ${child}`);
    if (child.startsWith("node_modules/@openclaw/ai/")) privateAiFiles += 1;
  }
};
await verifyTree(packedRoot);
assert(archiveFiles > 10_000);
assert(privateAiFiles > 0);

const normalizeBundledManifest = (value) => {
  if (Array.isArray(value)) return value.map(normalizeBundledManifest);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, normalizeBundledManifest(item)]));
  }
  if (typeof value === "string" && value.startsWith("./dist/")) return `./${value.slice("./dist/".length)}`;
  return value;
};
const pluginOrigins = [];
const pluginNames = ["@openclaw/acpx", "@openclaw/codex", "@openclaw/diagnostics-otel", "@openclaw/mattermost"];
for (const name of pluginNames) {
  const item = plan.packages.find((entry) => entry.name === name);
  const externalPackage = packageManifests.get(name);
  assert(item && externalPackage, `Missing plugin archive: ${name}`);
  const slug = name.slice("@openclaw/".length);
  const bundledRoot = join(host, "dist/extensions", slug);
  const bundledPackage = JSON.parse(await readFile(join(bundledRoot, "package.json"), "utf8"));
  const externalManifestBytes = await run("tar", ["-xOzf", join(packagesRoot, item.file), "package/openclaw.plugin.json"], { timeout: 60_000 });
  const externalManifest = JSON.parse(externalManifestBytes.toString());
  const bundledManifestBytes = await readFile(join(bundledRoot, "openclaw.plugin.json"));
  const bundledManifest = JSON.parse(bundledManifestBytes.toString());
  assert.equal(bundledPackage.name, name);
  assert.equal(bundledPackage.version, contract.version);
  assert.equal(externalPackage.openclaw.build.openclawVersion, contract.version);
  assert.equal(bundledPackage.openclaw.build.openclawVersion, contract.version);
  assert.deepEqual(externalPackage.openclaw.compat, bundledPackage.openclaw.compat);
  assert.deepEqual(externalPackage.openclaw.install, bundledPackage.openclaw.install);
  assert.deepEqual(externalPackage.openclaw.release, bundledPackage.openclaw.release);
  assert.deepEqual(externalPackage.openclaw.extensions, ["./index.ts"]);
  assert.deepEqual(externalPackage.openclaw.runtimeExtensions, ["./dist/index.js"]);
  assert.equal(bundledPackage.openclaw.build.bundledDist, true);
  assert.deepEqual(bundledPackage.openclaw.extensions, ["./index.js"]);
  assert.equal(Object.hasOwn(bundledPackage.openclaw, "runtimeExtensions"), false);
  assert.deepEqual(normalizeBundledManifest(externalManifest), bundledManifest);
  pluginOrigins.push({
    name,
    archive: item.file,
    archiveSha256: item.sha256,
    externalManifestSha256: createHash("sha256").update(externalManifestBytes).digest("hex"),
    bundledManifestSha256: createHash("sha256").update(bundledManifestBytes).digest("hex"),
    pluginId: bundledManifest.id,
    externalEntry: externalPackage.openclaw.runtimeExtensions[0],
    bundledEntry: bundledPackage.openclaw.extensions[0],
  });
}

const lock = JSON.parse(await readFile(join(work, "package-lock.json"), "utf8"));
const rootSpec = lock.packages[""].dependencies.openclaw;
const hostLock = lock.packages["node_modules/openclaw"];
const graph = assertActualGraphContract({
  lock,
  archiveManifest: hostManifest,
  archiveSpec: rootSpec,
  archiveIntegrity: hostLock.integrity,
  workspacePolicy: contract.workspaceOverrides,
});
assert.equal(hostLock.integrity, await sha512Integrity(localArchive));
const graphEvidence = { ...graph, policy: { sourcePackageJsonSha256: contract.sourcePackageJsonSha256, workspaceOverrides: 0 } };

const npmLsOutput = await run("npm", ["ls", "--all", "--json"], { env: npmEnvironment, timeout: 300_000, record: "npm-ls" });
const npmLs = JSON.parse(npmLsOutput.toString());
const countDependencies = (value) => 1 + Object.values(value.dependencies ?? {}).reduce((total, item) => total + countDependencies(item), 0);
const effectiveInventoryCount = countDependencies(npmLs) - 1;

const hostRequire = createRequire(join(host, "package.json"));
const pty = hostRequire("@lydell/node-pty");
const nativeOutput = await new Promise((resolvePromise, rejectPromise) => {
  const child = pty.spawn(process.execPath, ["-e", "process.stdout.write(process.platform + '/' + process.arch)"], { cwd: work, env: npmEnvironment, cols: 80, rows: 24 });
  let output = "";
  const timer = setTimeout(() => { child.kill(); rejectPromise(Error("native binding timed out")); }, 30_000);
  child.onData((value) => { output += value; });
  child.onExit(({ exitCode }) => {
    clearTimeout(timer);
    if (exitCode === 0) resolvePromise(output);
    else rejectPromise(Error(`native binding exited ${exitCode}`));
  });
});
assert(nativeOutput.includes("linux/arm64"));

const cliVersion = (await run(process.execPath, [join(host, "openclaw.mjs"), "--version"], { env: npmEnvironment, timeout: 60_000, record: "openclaw-version" })).toString().trim();
assert(cliVersion.includes(contract.version));
const protocolModules = [
  "dist/gateway/protocol/index.js",
  "dist/extensions/mattermost/api.js",
  "dist/extensions/mattermost/channel-plugin-api.js",
  "dist/extensions/mattermost/runtime-api.js",
];
const protocolExports = {};
for (const module of protocolModules) {
  const loaded = await import(pathToFileURL(join(host, module)));
  protocolExports[module] = Object.keys(loaded).sort();
  assert(protocolExports[module].length > 0, `Protocol module has no exports: ${module}`);
}

const inputAfter = {};
for (const item of plan.packages) inputAfter[item.file] = await sha256(join(packagesRoot, item.file));
assert.deepEqual(inputAfter, inputBefore);
assert.equal(await sha256(candidatePath), plan.candidateManifest.sha256);

const metrics = lane === "arm64Consumer" ? {
  construction: { platform: process.platform, architecture: process.arch, nodeVersion: process.version.slice(1), packages: plan.packages.length },
  normalInstall: { npmVersion, cliVersion, lockfileVersion: lock.lockfileVersion, lifecycleMarkerRemoved: true },
  nativeBinding: { module: "@lydell/node-pty", output: nativeOutput.trim() },
  beforeAfterCustody: { archiveFiles, privateAiFiles, packageInputsUnchanged: true, candidateManifestUnchanged: true },
  actualGraphPolicy: graphEvidence,
} : {
  packageMetadata: { packages: packageMetadata, buildInfo },
  bundledOrigins: { coreBundleDependencies: hostManifest.bundleDependencies, privateAiFiles, archiveFiles, plugins: pluginOrigins },
  effectiveInventory: { packageLockOccurrences: graphEvidence.packageCount, declaredEdges: graphEvidence.declaredEdges, npmLsOccurrences: effectiveInventoryCount },
  protocolClosures: { cliVersion, modules: protocolExports },
};

await writeFile(join(work, "phase5-proof.json"), `${JSON.stringify({ schema: 1, lane, metrics }, null, 2)}\n`, { mode: 0o600 });
