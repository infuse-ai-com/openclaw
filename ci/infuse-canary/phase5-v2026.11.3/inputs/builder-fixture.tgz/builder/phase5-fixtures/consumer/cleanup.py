#!/usr/bin/env python3
"""Remove only resources carrying the exact owner token written by run_lane.py."""
import json
from pathlib import Path

from run_lane import CUSTODY_LABEL, Docker, LANE_LABEL, atomic_json, environment, require, state_path


def labels(value):
    return value or {}


def execute():
    _, evidence, _, _, _ = environment()
    docker = Docker(evidence)
    path = state_path(evidence)
    if not path.is_file():
        atomic_json(evidence / "cleanup-proof.json", {"schema": 1, "status": "passed", "resources": 0, "reason": "no owned resources were created"})
        return
    state = json.loads(path.read_bytes())
    require(set(state) == {"schema", "owner", "lane", "consumer", "proxy", "network", "volume"} and state["schema"] == 1, "owned resource state differs")
    owner = state["owner"]
    lane = state["lane"]
    expected = {CUSTODY_LABEL: owner, LANE_LABEL: lane}
    removed = []

    for name in (state["consumer"], state["proxy"]):
        if not name:
            continue
        result = docker.run(["container", "inspect", name], "cleanup-inspect-" + name, check=False)
        if result.returncode != 0:
            continue
        values = json.loads(result.stdout)
        require(len(values) == 1 and all(labels(values[0]["Config"]["Labels"]).get(key) == value for key, value in expected.items()), "refusing foreign container cleanup")
        if name == state["proxy"] and not (evidence / "registry-proxy-cleanup.jsonl").exists():
            logs = docker.run(["logs", name], "cleanup-proxy-log", check=False)
            (evidence / "registry-proxy-cleanup.jsonl").write_bytes(logs.stdout)
        docker.run(["rm", "--force", name], "cleanup-remove-" + name)
        removed.append({"kind": "container", "name": name})

    if state["volume"]:
        result = docker.run(["volume", "inspect", state["volume"]], "cleanup-inspect-volume", check=False)
        if result.returncode == 0:
            values = json.loads(result.stdout)
            require(len(values) == 1 and all(labels(values[0]["Labels"]).get(key) == value for key, value in expected.items()), "refusing foreign volume cleanup")
            docker.run(["volume", "rm", state["volume"]], "cleanup-remove-volume", 120)
            removed.append({"kind": "volume", "name": state["volume"]})

    if state["network"]:
        result = docker.run(["network", "inspect", state["network"]], "cleanup-inspect-network", check=False)
        if result.returncode == 0:
            values = json.loads(result.stdout)
            require(len(values) == 1 and all(labels(values[0]["Labels"]).get(key) == value for key, value in expected.items()), "refusing foreign network cleanup")
            docker.run(["network", "rm", state["network"]], "cleanup-remove-network", 120)
            removed.append({"kind": "network", "name": state["network"]})

    remaining = {}
    for kind, command in (
        ("containers", ["ps", "-aq", "--filter", f"label={CUSTODY_LABEL}={owner}"]),
        ("volumes", ["volume", "ls", "-q", "--filter", f"label={CUSTODY_LABEL}={owner}"]),
        ("networks", ["network", "ls", "-q", "--filter", f"label={CUSTODY_LABEL}={owner}"]),
    ):
        result = docker.run(command, "cleanup-remaining-" + kind)
        remaining[kind] = [line for line in result.stdout.decode().splitlines() if line]
    require(not any(remaining.values()), "owned Docker resources remain after cleanup")
    atomic_json(evidence / "cleanup-proof.json", {"schema": 1, "status": "passed", "removed": removed, "remaining": remaining})


if __name__ == "__main__":
    execute()
