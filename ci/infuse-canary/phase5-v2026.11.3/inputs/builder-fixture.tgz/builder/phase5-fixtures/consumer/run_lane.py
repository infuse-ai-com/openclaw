#!/usr/bin/env python3
"""Run one inventory-bound Phase 5 consumer fixture through owned Docker resources."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid


FIXTURE_ROOT = Path(__file__).resolve().parent
CONTRACT = json.loads((FIXTURE_ROOT / "candidate-contract.json").read_bytes())
CUSTODY_LABEL = "infuse.phase5.consumer-owner"
LANE_LABEL = "infuse.phase5.consumer-lane"
LANE_CHECKS = {
    "arm64Consumer": ["construction", "normalInstall", "nativeBinding", "beforeAfterCustody", "actualGraphPolicy"],
    "publicInventory": ["packageMetadata", "bundledOrigins", "effectiveInventory", "protocolClosures"],
    "builderBoundary": ["unprivileged", "secretless", "networkPolicy", "inputReadback", "ownedCleanup"],
}
ADAPTER_ENVIRONMENT = {"PHASE5_OUTPUT", "PHASE5_PLAN_DIR", "PHASE5_PACKAGE_DIR", "PHASE5_CANDIDATE_MANIFEST", "PHASE5_LANE", "HOME", "TMPDIR", "PATH", "LANG", "LC_ALL", "LC_CTYPE", "__CF_USER_TEXT_ENCODING"}


def require(value, reason):
    if not value:
        raise ValueError(reason)


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    os.chmod(temporary, 0o600)
    temporary.replace(path)


class Docker:
    def __init__(self, evidence):
        self.evidence = evidence
        self.count = 0

    def run(self, arguments, label, timeout=60, check=True):
        self.count += 1
        name = f"{self.count:02d}-{label}"
        try:
            result = subprocess.run(["docker", *arguments], stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout, check=False)
        except subprocess.TimeoutExpired as error:
            (self.evidence / (name + ".stdout.log")).write_bytes(error.stdout or b"")
            (self.evidence / (name + ".stderr.log")).write_bytes(error.stderr or b"")
            raise ValueError("Docker operation timed out: " + label) from error
        (self.evidence / (name + ".stdout.log")).write_bytes(result.stdout)
        (self.evidence / (name + ".stderr.log")).write_bytes(result.stderr)
        atomic_json(self.evidence / (name + ".json"), {
            "argv": ["docker", *arguments],
            "returnCode": result.returncode,
            "stdoutBytes": len(result.stdout),
            "stderrBytes": len(result.stderr),
        })
        if check:
            require(result.returncode == 0, "Docker operation failed: " + label)
        return result

    def json(self, arguments, label, timeout=60):
        result = self.run(arguments, label, timeout)
        return json.loads(result.stdout)


def label_arguments(owner, lane):
    return ["--label", f"{CUSTODY_LABEL}={owner}", "--label", f"{LANE_LABEL}={lane}"]


def state_path(evidence):
    return evidence / "owned-resources.json"


def write_state(evidence, state):
    atomic_json(state_path(evidence), state)


def environment():
    require(set(os.environ) <= ADAPTER_ENVIRONMENT, "adapter imported an unreviewed environment value")
    require(os.environ.get("LC_CTYPE") in (None, "UTF-8"), "unexpected macOS locale injection")
    require(os.environ.get("__CF_USER_TEXT_ENCODING") is None or re.fullmatch(r"0x[0-9A-Fa-f]+:0x[0-9A-Fa-f]+:0x[0-9A-Fa-f]+", os.environ["__CF_USER_TEXT_ENCODING"]), "unexpected macOS text-encoding injection")
    for name in os.environ:
        require(re.search(r"TOKEN|SECRET|PASSWORD|COOKIE|CREDENTIAL", name, re.I) is None, "secret-shaped adapter environment name")
    output = Path(os.environ["PHASE5_OUTPUT"]).resolve(strict=True)
    evidence = output / "evidence"
    require(evidence.is_dir() and not evidence.is_symlink(), "missing adapter evidence directory")
    plan = Path(os.environ["PHASE5_PLAN_DIR"]).resolve(strict=True)
    packages = Path(os.environ["PHASE5_PACKAGE_DIR"]).resolve(strict=True)
    candidate = Path(os.environ["PHASE5_CANDIDATE_MANIFEST"]).resolve(strict=True)
    require(packages == plan / "packages" and candidate == plan / "candidate-manifest.json", "adapter input paths are inconsistent")
    return output, evidence, plan, packages, candidate


def preflight(docker, lane):
    info = docker.json(["info", "--format", "{{json .}}"], "docker-info")
    required_cpus = 4 if lane != "builderBoundary" else 2
    required_memory = 5 * 1024**3 if lane != "builderBoundary" else 2 * 1024**3
    require(info["NCPU"] >= required_cpus and info["MemTotal"] >= required_memory, "Docker resources are below the lane contract")
    architecture = "amd64" if lane == "builderBoundary" else "arm64"
    platform = "linux/" + architecture
    image = CONTRACT["node"]["images"][architecture]
    inspected = docker.json(["image", "inspect", image], "node-image-inspect")
    require(isinstance(inspected, list) and len(inspected) == 1, "pinned Node image is not locally available")
    require((inspected[0]["Os"], inspected[0]["Architecture"]) == ("linux", architecture), "pinned Node image platform differs")
    return image, platform, {"cpus": info["NCPU"], "memoryBytes": info["MemTotal"], "architecture": architecture, "imageId": inspected[0]["Id"]}


def inspect_container_contract(info, owner, lane, network, work_volume=None):
    labels = info["Config"]["Labels"]
    require(labels.get(CUSTODY_LABEL) == owner and labels.get(LANE_LABEL) == lane, "container ownership differs")
    host = info["HostConfig"]
    require(host["ReadonlyRootfs"] is True and host["Privileged"] is False, "container filesystem or privilege boundary differs")
    require(host["CapDrop"] == ["ALL"] and host["SecurityOpt"] == ["no-new-privileges"], "container capability boundary differs")
    require(host["NetworkMode"] == network, "container network boundary differs")
    read_only = {mount["Destination"] for mount in info["Mounts"] if mount["Type"] == "bind" and mount["RW"] is False}
    require({"/fixture", "/phase5/phase5-plan.json", "/phase5/candidate-manifest.json", "/phase5/packages"} <= read_only, "authenticated input mount differs")
    if work_volume:
        require(any(mount["Type"] == "volume" and mount["Name"] == work_volume and mount["Destination"] == "/work" and mount["RW"] is True for mount in info["Mounts"]), "owned work volume differs")


def wait_proxy(docker, proxy):
    for _ in range(50):
        result = docker.run(["logs", proxy], "proxy-readiness", check=False)
        if b'"kind":"ready"' in result.stdout:
            return
        time.sleep(0.2)
    raise ValueError("owned registry proxy did not become ready")


def consumer_lane(docker, lane, evidence, plan, packages, candidate, image, platform, state):
    owner = state["owner"]
    network = state["network"]
    volume = state["volume"]
    proxy = state["proxy"]
    consumer = state["consumer"]
    docker.run(["network", "create", "--internal", *label_arguments(owner, lane), network], "network-create")
    docker.run(["volume", "create", *label_arguments(owner, lane), volume], "volume-create")
    docker.run(["run", "--rm", "--pull", "never", "--platform", platform, "--network", "none", *label_arguments(owner, lane),
                "--cap-drop", "ALL", "--cap-add", "CHOWN", "--security-opt", "no-new-privileges", "--mount", f"source={volume},target=/work", image,
                "sh", "-c", "chown 1000:1000 /work"], "volume-owner", 120)
    docker.run(["create", "--name", proxy, "--pull", "never", "--platform", platform, "--network", network, "--network-alias", "proxy",
                *label_arguments(owner, lane), "--user", "1000:1000", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                "--pids-limit", "128", "--memory", "256m", "--memory-swap", "256m", "--cpus", "0.5", "--tmpfs", "/tmp:rw,noexec,nosuid,size=32m",
                "--mount", f"type=bind,src={FIXTURE_ROOT},dst=/fixture,readonly", image, "node", "/fixture/proxy.mjs"], "proxy-create")
    docker.run(["network", "connect", "bridge", proxy], "proxy-public-connect")
    docker.run(["start", proxy], "proxy-start")
    wait_proxy(docker, proxy)
    create = ["create", "--name", consumer, "--pull", "never", "--platform", platform, "--network", network,
              *label_arguments(owner, lane), "--user", "1000:1000", "--read-only", "--init", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
              "--pids-limit", "2048", "--memory", "5g", "--memory-swap", "5g", "--cpus", "4", "--tmpfs", "/tmp:rw,noexec,nosuid,size=256m",
              "--mount", f"source={volume},target=/work", "--mount", f"type=bind,src={FIXTURE_ROOT},dst=/fixture,readonly",
              "--mount", f"type=bind,src={plan / 'phase5-plan.json'},dst=/phase5/phase5-plan.json,readonly",
              "--mount", f"type=bind,src={candidate},dst=/phase5/candidate-manifest.json,readonly",
              "--mount", f"type=bind,src={packages},dst=/phase5/packages,readonly",
              "--env", "npm_config_proxy=http://proxy:3128", "--env", "npm_config_https_proxy=http://proxy:3128",
              "--env", "npm_config_noproxy=", image, "node", "/fixture/run-consumer.mjs", lane]
    docker.run(create, "consumer-create", 120)
    inspected = docker.json(["container", "inspect", consumer], "consumer-inspect")
    require(isinstance(inspected, list) and len(inspected) == 1, "consumer inspect shape differs")
    inspect_container_contract(inspected[0], owner, lane, network, volume)
    docker.run(["start", "--attach", consumer], "consumer-run", 3300)
    for source, destination in (("/work/phase5-proof.json", "lane-proof.json"), ("/work/package-lock.json", "package-lock.json"),
                                ("/work/npm-install.stdout.log", "npm-install.stdout.log"), ("/work/npm-install.stderr.log", "npm-install.stderr.log"),
                                ("/work/npm-ls.stdout.log", "npm-ls.stdout.log"), ("/work/npm-ls.stderr.log", "npm-ls.stderr.log")):
        docker.run(["cp", f"{consumer}:{source}", str(evidence / destination)], "copy-" + destination.replace(".", "-"), 120)
    proxy_logs = docker.run(["logs", proxy], "proxy-final-log")
    (evidence / "registry-proxy.jsonl").write_bytes(proxy_logs.stdout)
    proof = json.loads((evidence / "lane-proof.json").read_bytes())
    require(proof["schema"] == 1 and proof["lane"] == lane and set(proof["metrics"]) == set(LANE_CHECKS[lane]), "consumer proof closure differs")
    checks = {name: {"status": "passed", "metrics": proof["metrics"][name]} for name in LANE_CHECKS[lane]}
    return checks, ["No model, Mattermost or production credentials were present", "Public package traffic was restricted to registry.npmjs.org through an owned proxy"]


def boundary_lane(docker, evidence, plan, packages, candidate, image, platform, state):
    lane = "builderBoundary"
    owner = state["owner"]
    container = state["consumer"]
    docker.run(["create", "--name", container, "--pull", "never", "--platform", platform, "--network", "none",
                *label_arguments(owner, lane), "--user", "65532:65532", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                "--pids-limit", "64", "--memory", "256m", "--memory-swap", "256m", "--cpus", "0.5",
                "--tmpfs", "/tmp:rw,noexec,nosuid,size=32m,mode=700,uid=65532,gid=65532",
                "--mount", f"type=bind,src={FIXTURE_ROOT},dst=/fixture,readonly",
                "--mount", f"type=bind,src={plan / 'phase5-plan.json'},dst=/phase5/phase5-plan.json,readonly",
                "--mount", f"type=bind,src={candidate},dst=/phase5/candidate-manifest.json,readonly",
                "--mount", f"type=bind,src={packages},dst=/phase5/packages,readonly",
                "--env", "HOME=/tmp", image, "node", "/fixture/boundary-probe.mjs"], "boundary-create", 120)
    inspected = docker.json(["container", "inspect", container], "boundary-inspect")
    require(isinstance(inspected, list) and len(inspected) == 1, "boundary inspect shape differs")
    inspect_container_contract(inspected[0], owner, lane, "none")
    require(inspected[0]["Config"]["User"] == "65532:65532", "boundary container is not unprivileged")
    result = docker.run(["start", "--attach", container], "boundary-run", 120)
    proof = json.loads(result.stdout)
    atomic_json(evidence / "boundary-proof.json", proof)
    docker.run(["rm", container], "boundary-remove")
    remaining = docker.run(["ps", "-aq", "--filter", f"label={CUSTODY_LABEL}={owner}"], "boundary-remaining")
    require(not remaining.stdout.strip(), "owned boundary container remains")
    checks = {
        "unprivileged": {"status": "passed", "metrics": {"uid": proof["uid"], "gid": proof["gid"], "readOnlyRoot": True, "capabilitiesDropped": True}},
        "secretless": {"status": "passed", "metrics": {"environmentNames": proof["environmentNames"]}},
        "networkPolicy": {"status": "passed", "metrics": {"networkMode": "none"}},
        "inputReadback": {"status": "passed", "metrics": {"candidate": proof["candidate"], "packages": len(proof["packages"])}},
        "ownedCleanup": {"status": "passed", "metrics": {"remainingContainers": 0}},
    }
    return checks, ["The boundary probe authenticated inputs without installing or executing candidate code"]


def execute(lane):
    require(lane in LANE_CHECKS, "unknown consumer fixture lane")
    output, evidence, plan, packages, candidate = environment()
    require(os.environ["PHASE5_LANE"] == lane, "adapter lane differs from fixture argv")
    docker = Docker(evidence)
    image, platform, host = preflight(docker, lane)
    owner = uuid.uuid4().hex
    stem = "phase5-" + re.sub(r"[^a-z0-9]", "", lane.lower()) + "-" + owner[:12]
    state = {
        "schema": 1,
        "owner": owner,
        "lane": lane,
        "consumer": stem + "-consumer",
        "proxy": stem + "-proxy" if lane != "builderBoundary" else None,
        "network": stem + "-network" if lane != "builderBoundary" else None,
        "volume": stem + "-work" if lane != "builderBoundary" else None,
    }
    write_state(evidence, state)
    if lane == "builderBoundary":
        checks, limits = boundary_lane(docker, evidence, plan, packages, candidate, image, platform, state)
    else:
        checks, limits = consumer_lane(docker, lane, evidence, plan, packages, candidate, image, platform, state)
    atomic_json(evidence / "host-admission.json", {"schema": 1, "lane": lane, **host})
    atomic_json(output / "evidence/fixture-result.json", {
        "schema": 1,
        "status": "passed",
        "checks": checks,
        "scopeLimits": limits,
        "reason": "",
    })


if __name__ == "__main__":
    require(len(sys.argv) == 2, "pass exactly one Phase 5 lane")
    execute(sys.argv[1])
