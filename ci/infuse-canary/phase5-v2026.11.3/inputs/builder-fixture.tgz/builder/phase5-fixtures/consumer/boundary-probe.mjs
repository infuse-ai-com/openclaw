import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";

assert.equal(process.platform, "linux");
assert.equal(process.arch, "x64");
assert.equal(process.getuid(), 65532);
assert.equal(process.getgid(), 65532);

const allowedEnvironment = new Set(["HOME", "HOSTNAME", "NODE_VERSION", "PATH", "PWD", "YARN_VERSION"]);
assert.deepEqual(Object.keys(process.env).filter((name) => !allowedEnvironment.has(name)), []);
for (const name of Object.keys(process.env)) {
  assert(!/(TOKEN|SECRET|PASSWORD|KEY|COOKIE|AUTH|CREDENTIAL)/i.test(name), `Secret-shaped environment name: ${name}`);
}

const digest = async (path) => createHash("sha256").update(await readFile(path)).digest("hex");
const plan = JSON.parse(await readFile("/phase5/phase5-plan.json", "utf8"));
const candidate = JSON.parse(await readFile("/phase5/candidate-manifest.json", "utf8"));
assert.equal(plan.sourceCommit, candidate.hostCommit);
const packageNames = (await readdir("/phase5/packages")).sort();
assert.deepEqual(packageNames, plan.packages.map((item) => item.file).sort());
for (const item of plan.packages) assert.equal(await digest(join("/phase5/packages", item.file)), item.sha256);

process.stdout.write(`${JSON.stringify({
  schema: 1,
  platform: process.platform,
  architecture: process.arch,
  uid: process.getuid(),
  gid: process.getgid(),
  environmentNames: Object.keys(process.env).sort(),
  candidate: { sourceCommit: candidate.hostCommit, manifestSha256: await digest("/phase5/candidate-manifest.json") },
  packages: plan.packages.map(({ name, file, bytes, sha256 }) => ({ name, file, bytes, sha256 })),
})}\n`);
