# v2026.11.1 consumer fixtures

This directory owns three disposable external Phase 5 fixture contracts:

- `arm64Consumer`: normal Linux ARM64 npm installation, native PTY binding,
  exact archive-to-installed custody and actual lock-graph closure.
- `publicInventory`: all five package identities, bundled origins, effective
  installed inventory and importable protocol surfaces.
- `builderBoundary`: an unprivileged, read-only, capability-free and offline
  authenticated-input readback. It does not install or execute candidate code.

The two consumer lanes run in the pinned Node 24.22.1 ARM64 image on an internal
Docker network. An owned proxy is the only member also attached to the public
bridge, and it permits only npm registry HTTP/CONNECT destinations. The Node
image must already exist locally at the exact platform-manifest digest; fixture
execution never performs an implicit image pull.

The offline builder-boundary lane uses the separately pinned AMD64 platform
manifest required by its profile, including when Docker Desktop emulates AMD64
on an ARM64 host.

`run_lane.py` labels every container, volume and network with a random owner
token and records exact names before creation. `cleanup.py` verifies each label
before removal, refuses foreign resources and proves that no resource with the
owner token remains. Adapter post-run custody independently re-authenticates the
fixture and protected Phase 5 plan before a receipt can pass.

The contracts import no host environment values. They receive only the reserved
adapter `PHASE5_*` paths plus isolated runtime home/temp directories. Raw logs,
locks and summarized proofs remain in the private evidence directory.
