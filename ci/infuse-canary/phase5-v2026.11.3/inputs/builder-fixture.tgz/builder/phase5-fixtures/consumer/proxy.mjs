import { createServer, request } from "node:http";
import { connect } from "node:net";

const allowedHost = "registry.npmjs.org";
const sockets = new Set();
const log = (event) => process.stdout.write(`${JSON.stringify({ at: new Date().toISOString(), ...event })}\n`);
const track = (socket) => {
  sockets.add(socket);
  socket.once("close", () => sockets.delete(socket));
  socket.setTimeout(60_000, () => socket.destroy());
  return socket;
};

const server = createServer((incoming, outgoing) => {
  let target;
  try {
    target = new URL(incoming.url);
  } catch {
    outgoing.writeHead(400).end();
    return;
  }
  if (target.protocol !== "http:" || target.hostname !== allowedHost || !["", "80"].includes(target.port)) {
    log({ kind: "refused-http", target: incoming.url });
    outgoing.writeHead(403).end();
    return;
  }
  const headers = { ...incoming.headers, host: target.host };
  delete headers["proxy-connection"];
  log({ kind: "http", method: incoming.method, host: target.hostname });
  const upstream = request(target, { method: incoming.method, headers }, (response) => {
    outgoing.writeHead(response.statusCode, response.headers);
    response.pipe(outgoing);
  });
  track(upstream);
  upstream.on("error", () => outgoing.destroy());
  incoming.on("error", () => upstream.destroy());
  incoming.pipe(upstream);
});

server.on("connect", (incoming, downstream, head) => {
  const separator = incoming.url.lastIndexOf(":");
  const host = incoming.url.slice(0, separator);
  const port = Number(incoming.url.slice(separator + 1));
  if (separator < 1 || host !== allowedHost || port !== 443) {
    log({ kind: "refused-connect", target: incoming.url });
    downstream.end("HTTP/1.1 403 Forbidden\r\n\r\n");
    return;
  }
  log({ kind: "connect", host, port });
  const upstream = track(connect(port, host));
  track(downstream);
  upstream.once("connect", () => {
    downstream.write("HTTP/1.1 200 Connection Established\r\n\r\n");
    if (head.length) upstream.write(head);
    upstream.pipe(downstream);
    downstream.pipe(upstream);
  });
  upstream.on("error", () => downstream.destroy());
  downstream.on("error", () => upstream.destroy());
});

server.listen(3128, "0.0.0.0", () => log({ kind: "ready", host: allowedHost, port: 3128 }));
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.once(signal, () => {
    server.close(() => process.exit(0));
    for (const socket of sockets) socket.destroy();
    setTimeout(() => process.exit(1), 5_000).unref();
  });
}
