# Production Readiness Review

Scope:
Readiness classification:
Owner:
Verification:
Config/secrets:
Auth/privacy/data:
Runtime/observability:
Support path:
Rollback/disable path:
Launch window:
Accepted gaps:
Decision:
