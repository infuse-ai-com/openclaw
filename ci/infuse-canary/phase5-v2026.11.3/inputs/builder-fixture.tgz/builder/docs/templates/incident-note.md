# Incident Note

Incident:
Detected:
Impact:
Current status:
Mitigation:
Root cause or hypothesis:
Verification:
Follow-up:
Docs/runbook updates:
Owner:
