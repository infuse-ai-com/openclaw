# Verification gates

`task verify` (or `python3 -B scripts/verify_repo.py`) runs without Docker or
network: repository spine, syntax, local links, manifest/harness closure,
placeholder/secret audit, shell syntax, consolidated project-document presence,
adversarial builder tests, retained
consumer-policy tests and Git diff hygiene. Install no dependencies.

Phase 5 regressions additionally prove that changed package bytes, fixture
specs, evidence inventories, non-disposable execution boundaries and incomplete
lanes fail closed. Synthetic all-pass evidence must produce one bound
`LINUX-QUALIFICATION.json`; failed or unverified lanes must remain visible and
must not produce qualification metadata. These tests validate adapter custody,
not the external Studio/Mattermost/image behavior itself.

Before accepting a builder change run this gate and review the full diff.
Publication controller tests use a fake GitHub adapter: uncertain draft creation,
partial upload, repeat publication, wrong remote digest and conflicting tag.
They do not prove a new real publication. Live publication remains explicit.

For the 10.3 extraction, additionally verify the real frozen source, generated
recipe, downloaded full hosted evidence (13 stages, 35 graphs, five packages),
all nine existing public downloads, and a freshly re-rooted private handoff with
actual Core hydration and all four inventories. Keep raw evidence private;
commit only sanitized findings. Imported runtime summaries retain their limits.

Future canary qualification requires the fresh full hosted run and all approved
consumer/runtime/image lanes. The new builder cannot convert a locked historical
receipt into a new runtime proof. Record missing lanes as unverified.

Before that expensive run, the exact bundle must pass a secretless packaged-
activation gate: deterministic generated-file checks, focused changed-feature
tests, `pnpm release:check`, clean installation of the produced archive and
validation of the sanitized production configuration through the packed CLI.
This gate exists to fail stale generated schemas and configuration drift early;
it is not qualification and produces no publishable release verdict.

A live bundled-plugin hot patch may add focused provider-side acceptance before
the package build. It is valid only for the one tested agent and exact override
digest. It does not qualify package bytes or an immutable image and cannot be
carried to peer agents as release evidence. Runtime-behavior changes still need
the full current qualification after the exact bundle is rebuilt.

An eligible corrective rebuild may reference the prior full qualification only
for unchanged boundaries. Its evidence must name the prior release and hashes,
inventory every changed file, record focused package/configuration checks and
label carried lanes as referenced rather than freshly executed. The current
full-qualification receipt must never be copied or rewritten as if it covered
new package bytes. Any changed runtime behavior, dependency, toolchain,
credential path, migration, plugin API or platform boundary requires the full
gate again.

The corrective asset verifier accepts only one explicit representation: fresh
hosted and packaged-activation checks, seven `referenced` runtime lanes bound to
one prior qualification hash, and an exact manifest-owned correction object.
The release check normally passes. Its only exception is an explicit
`build-passed-with-inherited-preflight-drift` record naming the failed checks
and equal base/candidate hashes for sorted, unchanged inputs outside the
correction closure. It rejects a carried lane marked `passed`, an incomplete
activation metric set, changed inherited input, or a changed
prior-release/hash/changed-file backpointer.

Production promotion is a separate gate. A passing swarm pipeline proves the
new canary only when the reviewed change updates the runtime package/version pin
and the live workload reports the expected source and immutable image digest.
Before merge, require target-schema upgrade against a copied real database,
idempotent second run and SQLite `quick_check=ok`. After rollout, require all
five agents Ready with zero restart growth, exact version/source, migration
markers, exact plugin status/origin/version/source, Mattermost connected, and
bounded health/log/event evidence.

Required-owner Studio verification must cover service activation, not only
plugin inventory. Every configured native route must resolve the intended bot,
channel and current membership. A loaded `infuse-studio` plugin with a failed
`studio-missions` service is a production failure until membership/admission is
repaired and the exact runtime smoke passes.

The reviewed v2026.11.1 profile is separate from the immutable 10.3 controller
closure. Before proposal, it must authenticate Node 24.22.1, pnpm 12.15.0, the
exact source `packageManager`, 36 compiler graphs and the current five-file
effective-tool-inventory test set. Negative controls must reject the 10.3 pnpm,
35-graph count, removed `plugin-tools` test path and mismatched package manager.

GitLab runs the offline command for merge requests and the protected default
branch. Its source-gate status does not prove OpenClaw candidate or production
behavior.

Branch closure uses GitLab merge-request state, not Git ancestry alone. A
squash-merged branch may remain outside `main` ancestry. Merge only open merge
requests whose exact head passed the required gate; never re-merge a completed
source branch.
