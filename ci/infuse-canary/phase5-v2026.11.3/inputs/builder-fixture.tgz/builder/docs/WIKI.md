# Reference

Canary: a custom candidate pinned to one upstream tag and reviewed patch stack.
Qualification: evidence for exact source, harness, packages and runtime scope.
Publication: a GitHub package prerelease; distinct from image delivery/deployment.
Resume: reuse of a stage receipt only when all bound bytes still match.

Infuse AI engineering owns the builder. The human repo owner approves changes
in publication/deployment scope. Studio owns its integration and native proofs;
openclaw-k8s-swarm owns image registry and production pipeline delivery.
