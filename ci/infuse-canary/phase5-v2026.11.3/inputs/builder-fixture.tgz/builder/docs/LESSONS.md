# Lessons

2026-10-14: validate the full pin dependency chain before expensive work; a
fresh Core pin alone did not fix stale verifier/context pins in the last build.

Configure fixture resources before freezing proofs. Docker's 2 CPUs caused
native admission to exceed Studio's unchanged 10-second deadline; 4 CPUs passed.

Receipts must identify exact candidate and trusted controller bytes. A previous
successful run cannot qualify changed inputs. Preserve failed evidence.

GitHub draft releases are addressed by ID; tag lookup can return 404 while draft.
Verify every upload before publication and actual downloads afterward.

Use portable Python hashing and create omitted hydration directories. Keep
private source bundles away from public GitHub release assets.

Keep this small builder's code and project documentation in one repository,
as requested by its owner. The initial companion repo added no useful boundary.

2026-10-19: retain canary build/qualification history in this repository, rather
than Studio plans. Keep Studio integration contracts in Studio and production
release evidence in openclaw-k8s-swarm. Label historical no-deployment verdicts
by their original scope/date so they cannot overwrite later deployment records.

2026-11-05: a new release toolchain must not rebind the authenticated historical
harness. Keep the old closure immutable and add a versioned hosted/collector
profile whose lock, package-manager contract, compiler graphs and inventory-test
selection fail closed before candidate proposal or costly hosted execution.

2026-11-05: a successful older canary duration is not a safe timeout for a new
compiler/package graph. The v2026.11.1 attempt exhausted 240 minutes after a
`tsgolint` child `SIGKILL` and then continued packaging. Create trusted evidence
before candidate execution, sample cgroup memory counters from the host, keep an
inner watchdog below the platform timeout, and stop after a gating check fails.

2026-11-06: resource thresholds are behavioral inputs, not only ceilings. The
frozen candidate treats memory strictly below 24 GiB as constrained; binding an
exact 24-GiB cgroup therefore selected one unbounded type-aware Oxlint core
program and OOM-killed at the ceiling even though Oxlint already used one thread.
Lock boundary values in tests and use the candidate's deterministic serial
shards before buying memory, adding swap or weakening type-aware lint.

2026-11-06: a generated binding can be internally correct while a retained host
controller still rejects it before execution. When a resource contract changes,
bind every independently asserted boundary—including the host owner—to the same
profile value, add a regression for the complete controller closure, and
reconcile exact remote bytes before enabling an expensive manual workflow. The
regression must inspect the generated profile-specific host controller, assert
the new boundary, and reject the previous profile literal; validating only the
manifest, binding and inner probes is insufficient.

2026-11-06: raising only a workflow timeout does not help when candidate-owned
or harness-owned subprocess guards are lower. Run 42203414152 had a six-hour
outer budget but active TypeScript builds were terminated twice by independent
45-minute guards, with zero cgroup pressure or OOM events. Review and test the
complete nested timeout chain, preserve cleanup/evidence buffers, and keep a
new costly dispatch behind a separate owner gate.

2026-11-06: a capacity preflight can poison the runner it is meant to admit.
Creating a nested probe with root-owned `install -d` left the intermediate
`_work/_temp` parent owned by root even though the leaf was assigned to the
runner. GitHub job setup then could not create `_github_workflow`, so run
42233473076 failed before checkout. Create every mutable parent as the runner
account, limit privileged ownership changes to an explicit leaf, and reproduce
the platform's first write before dispatch.

2026-11-06: a green workflow and successful candidate summary do not satisfy a
trusted-evidence gate. Run 42240118430 completed every candidate stage, but all
418 host heartbeats failed because the controller assumed
`/usr/local/bin/python3` while Debian installed `/usr/bin/python3`. Exercise
controller-to-image executable paths against the exact locked image and keep
the collector fail-closed when independent telemetry is absent.

2026-11-07: do not extend a successfully qualified hosted harness lock merely
to add later runtime adapters. Bind Phase 5 through a separate release profile
and exact private controller/fixture/dependency specs, then authenticate closed
lane evidence. This preserves hosted provenance while still making changed or
unverified runtime/image fixtures fail closed.

2026-11-07: a successful production deployment pipeline does not prove that a
new canary was promoted when the merged change does not update the runtime pin.
Record source revision, immutable live image and configured OpenClaw version
separately; fixture-only PR 4456 rebuilt and rolled out the still-pinned 10.3
runtime even though the 11.1 prerelease had been published successfully.

2026-11-07: a loaded plugin is not proof that its registered service started.
The coordinator loaded `infuse-studio` while `studio-missions` failed closed on
one missing private-channel membership. Preflight every configured native route
with current bot/channel/membership evidence, then require absence of service
startup failure plus an exact runtime smoke after rollout.

2026-11-07: state-schema repair and plugin convergence are separate admission
phases. Doctor can commit an idempotent database upgrade before a later plugin
repair exits nonzero. Preserve the migration, make at most one bounded
best-effort post-Doctor convergence attempt, and let exact enabled/status/origin/
version/source checks decide final admission. Prove the migration offline on a
copy of a real database, including second-run idempotence and `quick_check=ok`.

2026-11-07: `unknown_after_send` is a safety state, not a failed-send verdict.
The provider may have accepted the post before acknowledgment was lost. Retain
the record and reconcile provider evidence before retrying; blind replay risks a
duplicate message.

2026-11-07: Git ancestry is not Azure PR state after squash merge. A completed
source branch may remain in `git branch -r --no-merged` because its exact commit
was replaced by the squash commit. Query active PRs first, verify exact-head CI
and merge state, and never re-merge a completed branch merely to clean ancestry.

2026-11-07: a personal macOS Gateway is not another swarm lane. Authenticate
and stage the published core archive without state access, then preserve the
global packages, executable links, durable state, configured workspaces/stores
and LaunchAgent definition as one verified rollback unit before migrating real
state under exclusive maintenance. `OPENCLAW_STATE_DIR` does not redirect
explicit external paths; copied-state Doctor is unsafe unless every such path is
copied and rewritten. Restoring only the package can run an old binary against a
newly migrated database. The standalone plugin archives are release artifacts,
not duplicate Mac plugin installation inputs.

2026-11-07: Mattermost streaming drafts and `progress_card` are independent
surfaces. Streaming configuration can show transient activity without a plan;
the model still has to call `progress_card`. In v2026.11.1 the prompt reminder
is conditional on compatible paired-renderer context, so verify a real paired
Control UI/mobile client rather than looking for a force-enable setting or
creating a fake pairing.

2026-11-13: keep historical evidence but remove historical execution plans from
the active documentation graph. A completed recovery sequence with old branch
names, runners and approval states can poison the next cycle even when every
individual fact is true. One current runbook, one active version plan and an
explicit historical-only boundary make authority unambiguous.

2026-11-14: retain merged feature branches instead of deleting them after the
bundle squash. The bundle proves the integrated result, while each feature ref
preserves behavior-specific authorship, focused tests and reconciliation
history. Keep the branch append-only and version-specific: a same-version defect
may add a reviewed commit and bundle PR without rewriting earlier heads. Use a
new branch from the next peeled upstream tag rather than merging upstream into
the old ref.

2026-11-14: per-feature green checks are necessary but not sufficient. The
assembled bundle exposed interactions that only repository-wide formatting,
changed-file lint, corrective regression suites and a full build could close.
Run focused checks on each feature, then repeat combined gates on the exact
bundle SHA before generating any controller.

2026-11-14: hosted artifact packaging is part of the trust boundary. GitHub's
artifact uploader omitted hidden evidence files until `include-hidden-files`
was explicit, so a green runner could still produce an incomplete downloadable
inventory. Authenticate the uploaded file count and inventory against the
runner receipt before accepting a lane or publication input.

2026-11-14: cross-repository fixtures must not assume the host runner uses UID
1000. A fixed container identity made valid Blacksmith evidence unwritable.
Resolve the actual unprivileged host UID/GID, create owned evidence directories,
and prove write/readback plus owned cleanup on every runner class.

2026-11-14: production promotion is a separate compatibility project, not a
package-pin edit. The swarm intentionally binds the runtime through its
Dockerfile, candidate manifest, consumer lock, migrations, plugin markers,
smokes, telemetry annotations and deployment guards. Inventory that full set
while the candidate is being qualified, then promote one immutable digest to
Tinus first and only continue to the fleet after exact runtime conformance.

2026-11-14: a protected deployment environment name is part of the credential
contract. Introducing `production/tinus-canary` caused the first canary job to
lose a variable scoped to exact environment `production`; it failed before
mutation. Before a rollout, prove that the exact job environment can resolve
every required protected variable, or keep the existing reviewed environment
name and express canary scope in the rollout controller instead.

2026-11-14: a plugin that installs from a source directory in an image build can
still fail when OpenClaw stages it on a persistent runtime volume. Package
runtime plugins as immutable archives, then prove install and reinstall twice
against the same disposable persistent state. A fresh-state smoke alone does
not exercise replacement, stale install metadata or convergence fingerprints.

2026-11-14: an image-only rollout can leave reviewed configuration behind. The
first corrected image still received live directory-valued plugin environment
variables because the deployment controller patched only image and annotations.
The rollout must reconcile the complete reviewed runtime contract—including
plugin archive paths—and postchecks must compare the live values exactly before
admitting the workload.

2026-11-14: image rollback is insufficient after a failed startup mutates
persistent convergence state. The v2026.11.3 canary removed the previous plugin
fingerprint before failing, so the old image also crash-looped until the exact
prior fingerprint was restored. Capture rollback-relevant persistent markers
before mutation and test their restoration together with the old image. The
Tinus-first gate contained both failures to one agent and prevented peer impact.

2026-11-14: the v2026.11.3 production path was overengineered in representation,
not in safety gates. Immutable image identity, least-privilege deployment,
Tinus-first admission, sequential peers and exact postchecks all paid for
themselves. The avoidable complexity came from encoding canary scope in both an
environment name and a rollout mode, expressing the same plugin intent as image
directories, archives and independently patched environment values, and
capturing image rollback without the persistent convergence state that made the
old image runnable. Count independent authorities, not checks: keep the checks,
but drive build smoke, desired configuration, rollout admission and rollback
capture from one reviewed release contract.

2026-11-14: production evidence should be complete without becoming another
orchestrator. Retain one normalized summary plus the raw before/after snapshots
and logs from each gate. The version evidence owns the release-specific story;
`LESSONS.md` owns reusable corrections; `NEXT_CANARY.md` owns procedure. Do not
copy a completed timeline into plans, trackers, decisions and runbooks merely to
make each page self-contained.

2026-11-14: feature implementation and feature activation are separate release
gates. The v2026.11.3 Mattermost extension accepted separate final delivery in
its direct schema and runtime code, but its generated bundled channel metadata
was stale; the packaged CLI therefore rejected the documented production config
before readiness. Classify each feature as opt-in or intrinsic, run generated
metadata checks for channel-schema changes, and validate the exact effective
configuration through the packaged artifact before building a production image.

2026-11-14: Tinus-first containment needs an automatic restoration contract, not
only a peer dependency. The activation canary correctly blocked all four peers,
but the failed deployment job timed out after mutation and left Tinus on the
rejected, unready image until the prior Deployment revision was restored. Every
post-mutation failure path must restore the captured image, configuration and
persistent convergence markers, wait for readiness, and retain both failure and
restoration evidence before the job exits.

2026-11-14: disabled workflow state is remote repository state, not a property
fully preserved by Git history. Upstream reconciliation introduced new workflow
files that GitHub activated by default even though the previously inherited
workflows remained disabled. Reconcile the active-workflow allowlist before and
after every canary build; the only permitted active entry is the manual Infuse
canary dispatcher.

2026-11-14: the default-branch dispatcher workflow ID is stable controller
input, not post-run evidence. Clearing it while preparing an immutable build
branch produced a fully valid package whose trusted receipt carried a zero
placeholder, then made collection reject the same run after the manifest was
updated with GitHub's real workflow ID. New proposals bind the reviewed workflow
ID before dispatch. The collector admits the historical zero placeholder only
when every other controller field matches and completed-run metadata separately
binds the exact non-zero workflow, dispatcher commit, run ID and attempt.

2026-11-14: do not instantiate the full Phase 5 fixture graph for an eligible
generated-metadata correction. Frozen fixtures intentionally pin the original
source and will reject the corrected commit; rebuilding those fixtures merely
to accept unchanged runtime behavior turns provenance into ceremony. Keep the
fresh package and packed-activation proof, reference each unchanged lane by the
prior qualification hash, and make the public asset verifier reject any claim
that a referenced lane freshly passed.

2026-11-14: a successful provider action is not automatically terminal reply
evidence. Mattermost added the requested reaction, but its adapter returned an
empty text-result detail object, so Core could not mark the source reply as
delivered and the normal finalizer posted fallback text. Configuration already
admitted reaction completion and could not repair missing adapter evidence. The
adapter must return structured success/action details; acceptance must cover DM
and group-thread requests with one reaction and zero new posts.

2026-11-14: live bundled-plugin overrides are useful for one-agent validation,
but are not durable fleet delivery. Build the override from the exact deployed
bundle plus the reviewed feature fix, stage it on persistent state, and use the
supported plugin reload without restarting the Gateway or weakening Pod
security. An isolated feature artifact may omit other bundle behavior, and a
`/tmp` override may disappear while its persisted config remains. After focused
acceptance, classify the source delta normally: changed runtime behavior needs
a new fully qualified canary and immutable image; peers must not converge by
copying mutable overrides.
