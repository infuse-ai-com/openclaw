# Recovery

Revert a builder commit to recover tooling. Preserve failed workspaces and
publication journals. Controller/manifest changes require fresh stage state.
Package publication has external effects: reconcile the retained draft/release
ID instead of deleting it or creating a duplicate. The builder never rolls back
production; that procedure belongs in openclaw-k8s-swarm.
