# Repository map

- `canary_builder/`: manifest, source/hosted preparation, assets, stage receipts,
  read-only doctor, publication and private handoff/hydration.
- `manifests/`: reviewed candidate input records, starting with 2026.10.3.
- `harness/hosted/`, `harness/collector/`: immutable retained 10.3 controllers.
- `harness/consumer/`: two immutable pure policy controllers, fixture and 47
  regressions retained by the reviewed harness lock.
- `phase5-fixtures/consumer/`: disposable 11.1 ARM64 consumer, public inventory
  and secretless builder-boundary contracts, separate from the retained lock.
- `phase5-profiles/`: release-specific lane, resource, network, secret-class,
  required-check and cleanup contracts for externally owned runtime adapters.
- `phase5-adapters/`: standalone reviewed argv-only controller that authenticates
  a fixture checkout/inventory, exposes only reserved authenticated plan inputs,
  executes one disposable lane and its owned cleanup, re-authenticates the plan,
  then emits the standardized private receipt.
- `harnesses/vYYYY.M.D/`: reviewed release-specific hosted/collector profiles.
- `harness-lock.json`, `harness-locks/`: historical and versioned complete
  14-file controller closures, independently pinned by each candidate manifest.
- `tests/`: tiny synthetic adversarial builder tests; no real agent state.
- `scripts/verify_repo.py`: single offline gate and scaffold audits.
- `docs/`: technical contracts and project documentation in one repository.
- `docs/ROADMAP.md`, `docs/LESSONS.md`, `docs/WIKI.md`: status, corrections and reference.
- `docs/person-trackers/`, `docs/archive/`, `docs/plans/`: current ownership,
  sanitized historical evidence and the active version plan. Historical plans
  are not retained as executable instructions.
- `docs/runbooks/NEXT_CANARY.md`: repeatable cross-repository release and production sequence.
- `docs/runbooks/LIVE_PLUGIN_HOTPATCH.md`: bounded one-agent bundled-plugin validation and rollback.
- `docs/runbooks/KAPITEKY_MAC_MINI_CANARY.md`: published-canary promotion and rollback on the personal Apple-silicon Gateway.
- `docs/reference/`: sanitized immutable public release metadata/provenance.
- `.canary/`: ignored atomic receipts, downloads, generated forks and handoffs.

Technical boundaries: [architecture](ARCHITECTURE.md). Commands:
[runbook](RUNBOOK.md). Project documentation: [index](README.md).
