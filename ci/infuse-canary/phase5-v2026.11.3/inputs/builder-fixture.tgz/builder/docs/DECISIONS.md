# Technical decisions

2026-10-14 (bootstrap; documentation split superseded below): Select
infra-platform + internal-tool overlay and companion docs workspace. Prefer Python stdlib CLI; no service, database or frontend is needed.

2026-10-14: Preserve 14 qualified controller sources exactly and pin their full
closure independently. Generate candidate data separately. Do not promote
legacy temporary packet READMEs or embedded provisional identities as authority.

2026-10-14: Resume requires unchanged manifest/controllers/inputs/outputs. A
failed/interrupted run is retained and cannot be made green by retrying in place.
External publication instead has a reconciliation journal keyed to the exact
reviewed plan and release ID, because a network failure can leave remote effects.

2026-10-14: Manual Azure verification with no schedules/automatic triggers or PR
build policy, per the user's session preference. Use the existing self-hosted
pool. A small self-contained YAML avoids cross-repo resource authorization.

2026-10-14: Docker Desktop's configured 6 GiB differs from Linux usable MemTotal.
Native doctor requires 4 CPUs and at least 5 GiB usable memory; hosted doctor
requires 4 CPUs, 13 GiB candidate budget and 1 GiB headroom. These are admission
floors; actual fresh boundary probes/runtime outcomes remain mandatory.

2026-10-14: The qualified 10.3 reference is imported evidence. Builder tests and
read-only evidence verification do not qualify a new runtime or deployed swarm.

2026-10-14: At the repository owner's request, consolidate the companion project
memory into this repository's docs/. Preserve the imported Git history; use one
root AGENTS.md, one documentation index and the existing verification command.
This supersedes the bootstrap's two-repository split for this project. The former
docs repository becomes a redirect after the consolidated main is pushed.

2026-10-14 (cleanup): At the repository owner's explicit request, delete the
retired openclaw-canary-builder-docs repository from Azure DevOps after verifying
the consolidated documentation and original Git history in this repository.
Deletion was verified by the Azure repository inventory; the builder remains
available. This supersedes retaining the former repository as a redirect.

2026-11-05: Preserve the authenticated 10.3 harness and manifest unchanged.
Future releases select a versioned hosted/collector profile and lock while
sharing the pure consumer-policy controllers. A proposal fails when its release
has no reviewed profile or its source package-manager contract differs. This
prevents a new toolchain from retroactively rebinding historical evidence.

2026-11-05: The v2026.11.1 hosted profile uses a dedicated ephemeral Linux x64
runner labeled `infuse-canary-32gb`, admits at least 8 CPUs and 28 GiB usable
Docker memory, and gives the candidate 8 CPUs/24 GiB with zero swap. The outer
job budget is 360 minutes; a trusted 330-minute inner watchdog preserves a
30-minute evidence-upload window. This supersedes the 4-CPU/13-GiB/240-minute
budget only for v2026.11.1; historical 10.3 evidence remains unchanged.

2026-11-06: The v2026.11.1 candidate cgroup is reduced from 24 GiB to 23 GiB
and its retained environment exports literal `CI=true`. The second hosted run
proved all 36 compiler graphs but OOM-killed the single type-aware Oxlint core
shard at the exact 24-GiB ceiling. The frozen candidate's existing constrained
policy activates below 24 GiB and deterministically splits core lint into five
serial stripes plus bounded extension chunks. This preserves the frozen source
and full type-aware gate instead of adding unbounded memory or weakening lint.

2026-11-06: The v2026.11.1 hosted timeout contract is raised to a 720-minute
outer job, a trusted 690-minute container watchdog and 660-minute long-step
ceilings. The package builder receives the same 660-minute ceiling through
`OPENCLAW_DOCKER_PACKAGE_BUILD_TIMEOUT_MS`. This supersedes the profile's
360/330-minute budget after run 42203414152 proved that independent 45-minute
E2E and package-build guards killed active compiler work without cgroup memory
pressure. The nested buffers preserve 30 minutes for cleanup and evidence at
each trusted boundary. A new dispatch still requires separate owner approval.

2026-11-06: The ephemeral runner workspace is admitted only after the
checked-in preflight runs as the dedicated runner account and proves `_diag`,
`_work`, `_work/_temp` and the `_github_workflow` write shape are runner-owned,
writable and free of symlinks or foreign-owned residue. Root may modify only an
explicit candidate-boundary leaf after runner-owned parents exist; the
preflight must pass again before service start. This replaces ad-hoc privileged
directory probes after run 42233473076 failed before checkout on a root-owned
`_work/_temp` parent.

2026-11-07: Keep Phase 5 adapter custody separate from the already-qualified
v2026.11.1 hosted harness lock. A release-specific Phase 5 profile defines the
seven required lanes and their resource/network/secret/cleanup contracts;
private fixture specs pin the exact external controller, fixture and dependency
bytes. The builder prepares protected inputs and authenticates returned closed
evidence but does not execute Studio, Mattermost or swarm image controllers.
Only an all-pass collection may emit `LINUX-QUALIFICATION.json`; failed and
unverified lanes remain explicit evidence. Publication and deployment remain
separate owner gates.

2026-11-07: Treat published candidate manifests, provenance and qualification
as immutable creation-time evidence. Their `published=false` and
`deployed=false` fields are not rewritten after later effects. Append
publication and production truth to the version evidence/closeout record with
exact release, swarm source, pipeline and image identities.

2026-11-07: Production admission requires more than a loaded plugin and a green
Deployment. The swarm owner must prove database upgrade/idempotence/integrity,
exact post-Doctor plugin convergence, every required-owner Studio native-route
membership, service startup, Mattermost connectivity, health and bounded
post-ready stability. These are release-specific deployment gates and do not
change the retained builder controller closures.

2026-11-08: GitLab is the repository and source-verification authority. Preserve
the historical Azure build records as evidence, but retire the Azure pipeline
definition and PR template. GitLab merge requests and protected-main pipelines
run the offline verification command; canary qualification, publication and
deployment remain separate, explicitly approved workflows.

2026-11-13: `infuse-ai-com/openclaw` is the sole authority for all new custom
source, bundle, build-controller and prerelease branches. `aolea/openclaw` is
historical archaeology only. Each behavior lives on a fresh versioned feature
branch from the peeled upstream tag and enters a same-base bundle only after
review. This supersedes the old flattened `codex/v*-infuse-canary` branch model.

2026-11-13: New canaries use manifest/binding schema 3. The default branch owns
one manual dispatcher; build branches contain only the exact generated
controller. The dispatcher binds the exact build branch/SHA, bundle branch/SHA,
repository and `blacksmith-8vcpu-ubuntu-2404` runner. Every inherited upstream
workflow remains disabled. This supersedes generated `.github/workflows/ci.yml`
and the self-hosted `ncase`/`infuse-canary-32gb` procedure for future releases;
historical schema-1/schema-2 evidence remains immutable.

2026-11-14: Schema-3 hosted retries never move a failed build-controller
branch. Attempt 1 uses `build/canary-openclaw-vYYYY.MM.DD`; each later attempt
uses the next immutable `-rN` branch and records `buildAttempt` in the manifest
and binding. Frozen-base qualification lints only changed canonical source files
while the complete delta ratchets and repository-wide formatting remain active;
this prevents unrelated upstream lint debt from being misclassified as a
custom-canary regression.

2026-11-14: The same-version v2026.11.3 reaction-completion revision moves the
manual hosted controller to `blacksmith-16vcpu-ubuntu-2404`. The trusted
candidate boundary receives 16 CPUs and 47 GiB with zero swap, leaving host
capacity for Docker, Actions and evidence upload. The runner label, manifest,
host controller, in-container probes, collector and regression tests change as
one reviewed lock update; historical controller branches and their 8-vCPU
evidence remain immutable.

2026-11-14: Schema-3 collection distinguishes the protected default-branch
dispatcher from the reviewed build controller. GitHub run and artifact metadata
must agree on the dispatcher SHA; the artifact name and trusted bootstrap
receipt must agree on the controller SHA; the binding, snapshot and packages
must agree on the candidate SHA. A dispatcher workflow run is never expected to
report the controller SHA as its `head_sha`. The frozen v2026.11.3 r2 host
summary's legacy `bootstrapCommit` field was populated from `GITHUB_SHA` and is
therefore cross-checked against the dispatcher; its start receipt remains the
authoritative controller/dispatcher split.

2026-11-14: Preserve every merged versioned feature branch in
`infuse-ai-com/openclaw` as an append-only historical ref. Merge its reviewed
change into the bundle with source-branch deletion disabled and deny force
pushes, rebases and deletion. A defect found against the same selected version
may advance the branch through a new reviewed commit and bundle PR while the
earlier head remains in history. Create a fresh branch from the next peeled
upstream tag for future reconciliation. This intentionally differs from the
normal delete-after-squash policy: the feature ref preserves behavior-specific
provenance and gives the next canary a reviewable comparison point without
making an old branch an executable base.

2026-11-14: Production plugin inputs are immutable archives, and production
rollout admission covers the complete reviewed runtime configuration rather
than image identity alone. Before mutation, prove archive replacement twice on
persistent state and capture rollback-relevant convergence markers. The rollout
must reconcile exact archive-valued environment variables; rollback restores
the prior image and persistent markers together. Tinus remains the mandatory
first production target before any peer mutation.

2026-11-14: Split future work into full canary qualification and bounded
corrective rebuilds. Every exact bundle first passes a cheap secretless packed-
activation gate before Blacksmith full qualification, so stale generated
metadata fails before the expensive ceremony. A corrective rebuild is eligible
only after a fully qualified release and only when the reviewed package delta
does not alter runtime behavior, dependencies, toolchain, credentials,
migrations, plugin APIs or supported platforms. Unchanged lanes may be cited by
exact prior evidence but never relabeled as freshly executed; Tinus-first and
automatic restoration remain mandatory. This reduces repeated work without
weakening package identity or production containment.
