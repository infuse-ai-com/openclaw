# Engineering tracker

Owner: Infuse AI engineering. Last updated: 2026-11-14.

## Active

No canary version is currently active. Select and peel a new upstream tag before
creating any source branch or controller. Follow only the
[canonical next-canary runbook](../runbooks/NEXT_CANARY.md); completed plans and
evidence do not carry approval into the next cycle.

## Historical closeout

v2026.11.3 completed four independent feature reconciliations, schema-3
Blacksmith qualification, seven Phase-5 lanes, prerelease publication and a
Tinus-first production rollout to all five agents. Its immutable identities,
failed canary attempts, recoveries and bounded residual warning are recorded in
the [v2026.11.3 evidence](../evidence/2026-11-14-v2026.11.3-canary.md).

v2026.11.1 completed hosted qualification, seven Phase-5 lanes, prerelease and
production promotion. Its detailed timeline remains in immutable evidence and
Git history. It is intentionally absent from this active tracker so old recovery
steps cannot be mistaken for current work.
