# Documentation consolidation

Source: former openclaw-canary-builder-docs main at
`e8e7d0a88e90599113952501d16525d20052a9e1`. Its complete Git history is retained
as ancestry of this merge. The project owner requested one repository.

| Former path | Consolidated owner |
| --- | --- |
| WIKI.md | docs/WIKI.md |
| lessons.md | docs/LESSONS.md |
| status/project-roadmap.md | docs/ROADMAP.md |
| person-trackers/person-tracker-engineering.md | docs/person-trackers/person-tracker-engineering.md |
| archive/README.md | docs/archive/README.md |
| docs/plans/archive/001-initial-delivery-plan.md | Same path |
| README.md | docs/README.md documentation index |
| AGENTS.md | Root AGENTS.md and docs/README.md synchronization rules |
| Taskfile.yml | Existing task verify, extended to require consolidated documents |
| .gitignore | Existing builder ignore rules already include every source rule |

The archived V1 plan remains historical. Current ownership and priorities live
in the consolidated documentation. Runtime/controllers/manifests and the manual
CI policy are unchanged. Consolidation initially retained the former repository
as a redirect with its history; deletion was a separate follow-up request below.

Follow-up cleanup, 2026-10-14: The owner explicitly requested deletion of the
retired Azure repository. Repository `44e3eef1-c413-4797-a174-576bfdc18beb` was
deleted and verified absent from the Infuse AI repository inventory; builder
`c1c853d3-2d75-464c-887d-f7dc267dcf96` remains. Consolidated documentation and the
original companion history at `e8e7d0a88e90599113952501d16525d20052a9e1` were
verified in builder main `22bb736ee53ec035d1286e1997595654eeb15c24` before deletion.
