# Canary builder command workflow

Use this command-level procedure together with
[Next OpenClaw canary](runbooks/NEXT_CANARY.md). Historical evidence is never an
active procedure.

All commands run from this repository. Use absolute source/input paths and keep
raw/private evidence outside Git. Builder commands do not deploy production.

## Prepare

1. Add and review the version-specific profile and harness lock.
2. Start every feature and bundle branch from the peeled upstream tag.
3. Run `propose` against the clean final bundle checkout. It observes source
   identity and clears all prior CI, package and publication evidence.
4. Run `prepare-hosted` in a fresh workspace. For schema 3 it produces only the
   reviewed `ci/infuse-canary/` controller tree plus preparation receipt; the
   manual dispatcher remains on fork `main`.
5. Commit the generated controller to
   `build/canary-openclaw-vYYYY.MM.DD` for attempt 1, or the next unused
   immutable `build/canary-openclaw-vYYYY.MM.DD-rN` branch after a failed
   attempt. Record its exact SHA and update the manifest CI identity.

## Dispatch and collect

1. Confirm the fork workflow allowlist: only `.github/workflows/infuse-canary.yml`
   is active and every inherited upstream workflow is disabled.
2. Confirm the build branch and bundle branch resolve to the exact binding SHAs.
3. Dispatch the manual workflow on `main` with the exact build branch and SHA.
4. Record the exact run ID and attempt. Collect only that completed run into a
   fresh workspace. Preserve all failed evidence. The schema-3 collector binds
   GitHub run/artifact metadata to the dispatcher SHA, internal bootstrap
   evidence to the controller SHA, and package evidence to the candidate SHA.
5. Require source custody, locked controller closure, compiler/package proof,
   trusted cgroup evidence and zero OOM kills.

## Runtime qualification and publication

Use `prepare-phase5` and `collect-phase5` with current, exact external fixture
specs. Every required lane must pass before `LINUX-QUALIFICATION.json` exists.
Then authenticate the nine-asset closure, review `release-plan`, publish by exact
release ID and verify actual downloads. Publication does not imply deployment.

## Recovery

Never edit an embedded hash, failed controller branch or stale receipt to bypass
a failed gate. Change the canonical manifest/controller, increment
`--build-attempt`, regenerate all dependent bindings and start a fresh workspace.
Reconcile uncertain GitHub effects by exact remote identity before retrying.
