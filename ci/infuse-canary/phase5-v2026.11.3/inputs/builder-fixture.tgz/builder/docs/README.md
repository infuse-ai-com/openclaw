# Project documentation

Project status, lessons, references and technical contracts live together in
OpenClaw Canary Builder. The repository owns both code and project memory.

- [Roadmap](ROADMAP.md): delivered work and next milestones.
- [Lessons](LESSONS.md): durable corrections from canary qualification.
- [Reference](WIKI.md): glossary, systems and ownership.
- [Engineering tracker](person-trackers/person-tracker-engineering.md): support and follow-ups.
- [Completed v2026.11.3 plan](plans/v2026.11.3-canary.md): historical approved
  scope and gates; it is not authority for a later canary.
- [Next-canary runbook](runbooks/NEXT_CANARY.md): version-neutral checklist from
  signed release freeze through production verification and branch closure.
- [Live bundled-plugin hot-patch runbook](runbooks/LIVE_PLUGIN_HOTPATCH.md):
  one-agent validation of a reviewed plugin source fix without weakening Pod
  security or turning mutable overrides into fleet state.
- [Kapiteky Mac mini canary runbook](runbooks/KAPITEKY_MAC_MINI_CANARY.md):
  authenticate and stage, snapshot, install, migrate, verify and roll back a
  published canary on the personal Apple-silicon Gateway without importing
  swarm-only machinery.
- [Archive conventions](archive/README.md): sanitized meeting notes and reference material.
- [Architecture](ARCHITECTURE.md), [decisions](DECISIONS.md), [runbook](RUNBOOK.md)
  and [verification](VERIFICATION_GATES.md): technical authority.

The root AGENTS.md governs all work. Keep roadmap, tracker and lessons consistent
with code releases, ownership and decisions; inspect current code state before
updating project facts. Archive note names use YYYY-MM-DD-topic.md. Trackers use
person-tracker-<name>.md. Add project pages only when needed for distinct work.
Additional project pages use project-<name>.md. Use the workspace-framework
workflow when maintaining substantial project memory.

- Historical qualification records are evidence only. They are never current
  runbooks, branch bases or approval records for a later canary.
