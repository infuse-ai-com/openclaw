# Security and access

The private GitLab builder repository inherits the existing private Infuse
project access model; no grants or credential changes are part of this
migration.
GitHub credentials belong only in trusted gh operations. Candidate code runs
inside fresh independently probed secretless Docker, never this Python process.

Manifests contain public identities. Hash pins authenticate observations against
reviewed inputs, not against whatever bytes happen to be current. Review changes
to manifests and harness locks. Reject symlinks, special files and path escapes
in builder artifacts and private transfer inputs. Private raw proofs/handoffs
stay outside Git and must never be uploaded as public release assets.
