# Contracts and scope

The candidate manifest is reviewed input, not an auto-generated verdict. Its
source snapshot uses the retained OpenClaw inspector's ordered path/mode/byte
fingerprint. Its harness lock authenticates the complete retained controller
closure before import/execution. Proposals observe new source and clear old
verdicts; review the proposed data and upstream tag signature independently.

Hosted preparation selects the manifest's authenticated versioned harness,
copies its controller bytes and generates binding JSON plus manual workflow
YAML. The immutable 10.3 profile remains bound to 35 compiler graphs and its
original toolchain. The 11.1 profile binds the exact source `packageManager`,
Node 24.22.1, pnpm 12.15.0 and 36 compiler graphs. Source/lock/branch/version
pins derive once from the manifest. The Linux host controller supplies a fresh
immutable secretless boundary; each package verifier requires all 13 stages,
its exact graph closure, source-before/after, container/cgroup/exit custody and
five exact packages.
A data-only local source check does not replace canonical lint or runtime proof.
Run canonical affected-file format/lint and pin guards in the approved build
fixture before dispatching expensive full qualification.

Stage receipts bind manifest, all current builder modules, explicit inputs and
closed output inventories. Atomic writes and an exclusive workspace lock keep
parallel commands from accepting partial results. Identical stages resume;
changed/failed/interrupted stages require a fresh workspace. Preserve old
receipts. This caches controller stages, not partial compiler success. Never
reuse one of the 13 qualification stages independently of the full bound run.

Package verification checks all nine reviewed hashes/sizes, candidate source,
lock, timestamp, Core, CI and run backpointers, hosted provenance, runtime
summary/limits, checksum closure, and bounded tar metadata without extraction or
candidate execution. A frozen runtime summary is a reviewed external evidence
record; the builder does not independently reproduce all runtime claims.

Publication uses a retained release ID, validates draft identity and existing
asset digests, uploads missing exact assets, verifies the complete set and then
publishes a prerelease with Latest disabled. It rejects an existing conflicting
tag before writes. A separate read-only gate verifies tag and actual public
downloads. Private source bundles cannot be selected as public assets.

Private handoffs authenticate an externally reviewed HYDRATE.json digest, four
inventory hashes, exact Core pin and candidate. Package only those inventories,
omit the two public Core copies, and include a standalone stdlib hydrator.
Extraction validates all archive paths/types before writes. Hydration downloads
one pinned Core, creates missing directories, and checks all four fingerprints.
The bundle is private and supplies a reference/recipe, not deployment authority.

## Phase 5 adapter boundary

The hosted and pure consumer-policy controllers remain extracted. Phase 5 adds
a separate release-specific profile rather than changing the already-qualified
hosted harness lock. `prepare-phase5` authenticates the successful hosted
receipt, exact candidate manifest, five flat package archives and a reviewed
private fixture-spec file. Every external lane pins its controller repository,
commit, path, bytes and SHA-256; fixture repository, commit, profile and closed
inventory; dependency digests; platform/architecture/resources; network and
secret class; timeout and disposable cleanup boundary.

The external adapter passes the authenticated plan root, package directory,
candidate manifest and selected lane through adapter-owned `PHASE5_*`
variables. Fixture contracts cannot import those names from the host. After the
fixture command and owned cleanup, the adapter re-verifies the closed plan and
its original plan digest before it can write a standardized receipt.

The builder does not run those external controllers. Their owning disposable
fixtures execute canonical normal consumer construction, installed custody,
public inventory, native Studio/Mattermost lifecycle, AMD64 runtime, image and
builder-boundary probes. `collect-phase5` then verifies each exact adapter and
fixture backpointer, required check closure, evidence inventory and owned
cleanup. It preserves `failed` and `unverified` lanes but writes
`LINUX-QUALIFICATION.json` only when all seven lanes pass. This prevents an
imported 10.2/10.3 verdict, a package-only proof or a changed fixture from being
promoted to current runtime/image qualification.

Private handoff hydration remains the next data-only boundary after successful
collection. Production remains in openclaw-k8s-swarm. An affected-file style
guard inside the secretless build lane remains separate future work.
