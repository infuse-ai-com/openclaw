# Internal tool overlay

Owner/support: Infuse AI engineering and repository owner. Access: existing
private Infuse project membership. Rollout: CLI checkout, no service deployment.
Fallback: retain frozen original qualification/private handoff inputs and their
owning contracts. No publication or deployment without explicit session scope.
Smoke: offline gate and exact source/hosted/public data checks.
