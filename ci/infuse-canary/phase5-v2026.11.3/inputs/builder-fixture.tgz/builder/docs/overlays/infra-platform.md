# Infrastructure overlay

Owner: Infuse AI engineering. Blast radius: local generated artifacts and explicit
manual fork package effects only. No running service/maintenance window.
Access: inherited private Infuse repositories; no grants/secret changes.
Recovery: preserve failed state/journals and revert tooling; no production rollback.
Observability: stage receipts, sanitized hosted metrics and GitLab source verification.
Evidence: offline controls, exact reference preflight, public reads and portable
handoff. See [runbook](../RUNBOOK.md) and [verification](../VERIFICATION_GATES.md).
