# Project brief

Owner: Infuse AI engineering. Primary type: infra-platform; internal-tool overlay.
Skeleton: repo-skeleton-infra. Code and project documentation share this repository.

The 10.2 and 10.3 canaries required repeated recovery from stale input pins,
resource pressure and temporary orchestration scripts. Build a maintained CLI
that catches these problems before expensive verification and preserves exact
inputs across retries. Users are Infuse engineers and their coding agents.

Initial acceptance:

- Import the published 2026.10.3 source/CI/package identities as a locked reference.
- Authenticate source and the complete reviewed harness closure before preparation.
- Resume only when manifest, harness, commands, dependencies and output bytes match.
- Fetch/verify public release assets without executing candidate code.
- Generate portable private handoffs with checked archive paths and hashes.
- Prepare and verify manual GitHub prerelease publication by release ID.
- Fail negative controls for changed pins, corrupted outputs and unsafe archives.
- Provide one offline verification command and explicit phase/evidence semantics.

Non-goals: automatic patch selection, recurring builds, credential expansion
and public private-source uploads. Source patches stay in the Infuse fork;
swarm delivery stays in its owning repo. Manual paid Blacksmith qualification
and production work occur only under the active version plan and explicit owner
approval.
No service/database/runtime namespace is required for this command-line tool.
Support/reviewer: Infuse AI engineering and repository owner. Azure Boards: N/A.
Risk: untrusted package/source bytes and stale qualification receipts. Trusted
controllers stay separate from candidate inputs; fixtures remain disposable.

Project documentation: [docs index](README.md).
Code repo: https://gitlab.infuse-ai-tech.party/platform/agents/openclaw-canary-builder
