# Kapiteky Mac mini canary promotion

Use this runbook to promote an already published and qualified Infuse OpenClaw
canary onto Kapiteky's Apple-silicon Mac mini. Building, qualification,
publication, swarm deployment and Mac promotion are separate gates. This
procedure does not authorize a host change by itself.

Run the live sections from a local macOS Terminal, outside the Gateway process
tree. The Gateway is deliberately stopped during the mutation window, so do
not try to execute the upgrade through Kapiteky or an OpenClaw tool call.

The historical workspace runbook records the exact 2026.8.1 → 2026.9.7
migration. It is valuable evidence but is release-specific and must not be
rerun. This file is the canonical procedure for later canaries.

## Authority and boundaries

- `openclaw-canary-builder` authenticates the public release and owns this
  procedure.
- `infuse-ai-com/openclaw` owns new source and published prerelease assets.
  `aolea/openclaw` is historical evidence only.
- `openclaw-k8s-swarm` supplies migration lessons, not Mac installation input.
- The Mac uses durable personal state, paired clients, macOS integrations and a
  user LaunchAgent. Do not copy Kubernetes entrypoints, container-only repair
  helpers or swarm configuration onto it.
- The four standalone plugin archives in the v2026.11.1 release are
  distribution artifacts. The core archive already contains the matching
  bundled plugins. Do not install duplicate global or workspace shadows.

The package, all mutable state, configured workspaces/stores, relevant global
packages, executable links and LaunchAgent definition form one rollback unit.
Never restore an old package while retaining databases migrated by the canary.

## Stop conditions

Stop immediately when any of these checks fails:

- public release, package hash, version, commit, build ID or timestamp differs;
- Node does not satisfy the authenticated package's engine range;
- the existing Gateway cannot be stopped and its listener/LaunchAgent absence
  cannot be proved;
- a pre-upgrade or rollback-copy database fails `PRAGMA integrity_check`;
- a configured writable workspace/store is outside the captured state tree and
  has no reviewed rollback treatment;
- package installation, Doctor, config validation or plugin Doctor exits
  nonzero;
- target state or agent schema differs from the package-declared schema;
- a required plugin is missing, duplicated, shadowed or loaded from an
  unexpected origin;
- credentials, sessions, channel routing, Mattermost, paired clients or clean
  foreground shutdown cannot be verified;
- the managed Gateway restarts or bounded logs contain a recurring failure.

Do not use `openclaw update`, `sudo npm`, an npm registry version, a source
checkout or an asset from another canary as a substitute. Do not run plugin
uninstall commands to remove shadows: they may delete configuration and channel
state. Quarantine only exact reviewed paths after the rollback unit exists.

## 1. Initialize one operator attempt

Use Bash so arrays, `PIPESTATUS` and `pipefail` behave as documented. Keep one
Terminal open. A resumed attempt reuses the same private directory and rollback
unit; it never creates a second snapshot over the first.

```bash
bash
set -euo pipefail
umask 077

REPO_ROOT="/absolute/path/to/openclaw-canary-builder"
MANIFEST="$REPO_ROOT/manifests/vYYYY.M.D.json"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
PRIVATE_ROOT="$HOME/Library/Application Support/OpenClaw/canary-$STAMP"
VERIFY_ROOT="$PRIVATE_ROOT/release-verification"
ROLLBACK_ROOT="$PRIVATE_ROOT/rollback"
STAGE_HOME="$PRIVATE_ROOT/stage-home"
STAGE_PREFIX="$PRIVATE_ROOT/stage-prefix"

install -d -m 700 "$PRIVATE_ROOT" "$STAGE_HOME" "$STAGE_PREFIX"
test ! -e "$ROLLBACK_ROOT"
```

The private directory contains package bytes, host inventories and potentially
sensitive state. Keep it mode `0700`, outside `~/.openclaw`, and never commit it.

## 2. Authenticate and stage the exact release

Start from a clean builder checkout and use the reviewed manifest:

```bash
cd "$REPO_ROOT"
python3 -B -m canary_builder \
  --manifest "$MANIFEST" \
  --workspace "$VERIFY_ROOT" \
  release-verify

ASSET_DIR="$VERIFY_ROOT/release-verify/assets"
CANDIDATE_MANIFEST="$ASSET_DIR/candidate-manifest.json"
CORE_FILE="$(jq -r '.hostPackageFile' "$CANDIDATE_MANIFEST")"
CORE_TGZ="$ASSET_DIR/$CORE_FILE"
CORE_VERSION="$(jq -r '.hostVersion' "$CANDIDATE_MANIFEST")"
CORE_COMMIT="$(jq -r '.hostCommit' "$CANDIDATE_MANIFEST")"
CORE_SHA256="$(jq -r '.hostPackageSha256' "$CANDIDATE_MANIFEST")"
RELEASE_TAG="$(jq -r '.release.tag' "$MANIFEST")"

EXPECTED_BUILD_ID="$(tar -xOf "$CORE_TGZ" package/dist/build-info.json | jq -r '.buildId')"
EXPECTED_BUILT_AT="$(tar -xOf "$CORE_TGZ" package/dist/build-info.json | jq -r '.builtAt')"
TARGET_STATE_SCHEMA="$(tar -xOf "$CORE_TGZ" package/package.json | jq -r '.openclaw.schemaVersions.state')"
TARGET_AGENT_SCHEMA="$(tar -xOf "$CORE_TGZ" package/package.json | jq -r '.openclaw.schemaVersions.agent')"

test -f "$CORE_TGZ"
test "$(shasum -a 256 "$CORE_TGZ" | awk '{print $1}')" = "$CORE_SHA256"
tar -xOf "$CORE_TGZ" package/package.json \
  | jq -e --arg version "$CORE_VERSION" \
    '.name == "openclaw" and .version == $version and
     (.openclaw.schemaVersions.state | type == "number") and
     (.openclaw.schemaVersions.agent | type == "number")'
tar -xOf "$CORE_TGZ" package/dist/build-info.json \
  | jq -e --arg version "$CORE_VERSION" --arg commit "$CORE_COMMIT" \
    --arg buildId "$EXPECTED_BUILD_ID" --arg builtAt "$EXPECTED_BUILT_AT" \
    '.version == $version and .commit == $commit and
     .buildId == $buildId and .builtAt == $builtAt'
```

Install the archive into an isolated prefix to exercise its lifecycle scripts
and verify package layout without reading live OpenClaw state:

```bash
HOME="$STAGE_HOME" npm install \
  --prefix "$STAGE_PREFIX" \
  --foreground-scripts --no-audit --no-fund \
  "$CORE_TGZ"

STAGE_CORE="$STAGE_PREFIX/node_modules/openclaw"
STAGE_OPENCLAW="$STAGE_PREFIX/node_modules/.bin/openclaw"

"$STAGE_OPENCLAW" --version | rg -q "^OpenClaw ${CORE_VERSION//./\\.} "
jq -e --arg version "$CORE_VERSION" --arg commit "$CORE_COMMIT" \
  --arg buildId "$EXPECTED_BUILD_ID" --arg builtAt "$EXPECTED_BUILT_AT" \
  '.version == $version and .commit == $commit and
   .buildId == $buildId and .builtAt == $builtAt' \
  "$STAGE_CORE/dist/build-info.json"

for plugin_id in codex mattermost; do
  jq -e --arg version "$CORE_VERSION" \
    '.version == $version and
     .openclaw.build.openclawVersion == $version and
     .openclaw.build.bundledDist == true' \
    "$STAGE_CORE/dist/extensions/$plugin_id/package.json"
done

node - "$STAGE_CORE" <<'NODE'
const path = require("node:path");
const core = process.argv[2];
const pkg = require(path.join(core, "package.json"));
const semver = require(path.join(core, "node_modules/semver"));
if (!semver.satisfies(process.version, pkg.engines.node)) {
  throw new Error(`Node ${process.version} does not satisfy ${pkg.engines.node}`);
}
console.log("NODE_ENGINE_OK", process.version, pkg.engines.node);
NODE

printf 'export %s=%q\n' \
  REPO_ROOT "$REPO_ROOT" MANIFEST "$MANIFEST" STAMP "$STAMP" \
  PRIVATE_ROOT "$PRIVATE_ROOT" VERIFY_ROOT "$VERIFY_ROOT" \
  ROLLBACK_ROOT "$ROLLBACK_ROOT" STAGE_HOME "$STAGE_HOME" \
  STAGE_PREFIX "$STAGE_PREFIX" ASSET_DIR "$ASSET_DIR" \
  CANDIDATE_MANIFEST "$CANDIDATE_MANIFEST" CORE_FILE "$CORE_FILE" \
  CORE_TGZ "$CORE_TGZ" CORE_VERSION "$CORE_VERSION" \
  CORE_COMMIT "$CORE_COMMIT" CORE_SHA256 "$CORE_SHA256" \
  RELEASE_TAG "$RELEASE_TAG" EXPECTED_BUILD_ID "$EXPECTED_BUILD_ID" \
  EXPECTED_BUILT_AT "$EXPECTED_BUILT_AT" \
  TARGET_STATE_SCHEMA "$TARGET_STATE_SCHEMA" \
  TARGET_AGENT_SCHEMA "$TARGET_AGENT_SCHEMA" \
  > "$PRIVATE_ROOT/operator-env.sh"
chmod 600 "$PRIVATE_ROOT/operator-env.sh"
```

Do **not** run staged `doctor`, `config validate`, `plugins inspect`, `status` or
another state-reading command. `OPENCLAW_STATE_DIR` redirects the default state
root, but Doctor follows explicitly configured workspace and store paths. A
copied config can therefore mutate live external paths unless every such path is
copied and rewritten. The safe default is package-only staging, then real-state
migration under exclusive maintenance after the rollback unit is verified.

If Terminal exits, start Bash, restore `set -euo pipefail` and `umask 077`,
source the existing `operator-env.sh`, and redefine the documented shell
functions/arrays needed by the next gate. Resume after diagnosis; do not create
a new timestamp, rerun initialization or merge a new snapshot into an existing
rollback unit.

For the completed v2026.11.1 release, the immutable values are:

- tag `canary-v2026.11.1-studio-required-owner-19818bb59a-r1`;
- core `openclaw-2026.11.1-19818bb59a.tgz`;
- source `19818bb59a7bf9d4e9989fb9a4df6f1b4ffe8ca6`;
- build ID `2026.11.1-19818bb59a7b-2026-11-06T19-07-01.312Z`;
- core SHA-256
  `b2e075590f665f6440854c3c0d43052a5dee2f748fe3051a6b122813fdff2d8a`;
- target schemas: shared state `22`, agent `27`.

## 3. Capture the live baseline

Run read-only checks before approval or mutation:

```bash
uname -m | tee "$PRIVATE_ROOT/pre-architecture.txt"
sw_vers > "$PRIVATE_ROOT/pre-macos.txt"
node --version | tee "$PRIVATE_ROOT/pre-node.txt"
npm --version | tee "$PRIVATE_ROOT/pre-npm.txt"
npm root -g | tee "$PRIVATE_ROOT/global-root.txt"
command -v openclaw | tee "$PRIVATE_ROOT/pre-openclaw-path.txt"
openclaw --version | tee "$PRIVATE_ROOT/pre-openclaw-version.txt"
openclaw gateway status > "$PRIVATE_ROOT/pre-gateway-status.txt"
openclaw plugins list --json > "$PRIVATE_ROOT/pre-plugins.json"
openclaw channels status --json > "$PRIVATE_ROOT/pre-channels.json"
openclaw devices list --json > "$PRIVATE_ROOT/pre-devices.json"
openclaw sessions --agent main --limit 1 --json >/dev/null

jq -S '{
  bindings,
  mattermost: {
    streaming: .channels.mattermost.streaming,
    finalDelivery: .channels.mattermost.finalDelivery,
    groupPolicy: .channels.mattermost.groupPolicy,
    groups: .channels.mattermost.groups
  },
  telegram: {
    enabled: .channels.telegram.enabled,
    accounts: (.channels.telegram.accounts // {} | keys)
  }
}' "$HOME/.openclaw/openclaw.json" | shasum -a 256 \
  > "$PRIVATE_ROOT/pre-routing-config.sha256"

test "$(uname -m)" = "arm64"
test "$(npm root -g)" = "/opt/homebrew/lib/node_modules"
test "$(command -v openclaw)" = "/opt/homebrew/bin/openclaw"
```

Verify Node against `package/package.json` `engines.node`; do not infer support
from the current runtime. Record the existing LaunchAgent label/path, Gateway
PID, channel health, paired clients and plugin origins privately.

Create reusable database inventory functions in the operator shell:

```bash
shopt -s nullglob

check_database() {
  local identity="$1"
  local database_file="$2"
  local schema_value integrity_value
  schema_value="$(sqlite3 "$database_file" 'PRAGMA user_version;')"
  integrity_value="$(sqlite3 "$database_file" 'PRAGMA integrity_check;')"
  test "$integrity_value" = "ok"
  jq -nc --arg identity "$identity" --arg file "$database_file" \
    --argjson schema "$schema_value" --arg integrity "$integrity_value" \
    '{identity:$identity,file:$file,schema:$schema,integrity:$integrity}'
}

write_database_inventory() {
  local state_root="$1"
  local output_file="$2"
  {
    check_database state "$state_root/state/openclaw.sqlite"
    local database_file agent_id
    for database_file in "$state_root"/agents/*/agent/openclaw-agent.sqlite; do
      agent_id="$(basename "$(dirname "$(dirname "$database_file")")")"
      check_database "agent:$agent_id" "$database_file"
    done
  } > "$output_file"
}

write_database_inventory "$HOME/.openclaw" \
  "$PRIVATE_ROOT/pre-databases.jsonl"
jq -se 'length > 1 and all(.integrity == "ok")' \
  "$PRIVATE_ROOT/pre-databases.jsonl" >/dev/null
```

Inventory configured local paths before the backup. The first file lists known
agent workspaces; the second is a broader private review aid and may include
non-writable executable paths:

```bash
jq -r '[.agents.defaults.workspace?, (.agents.entries[]?.workspace?)]
  | map(select(type == "string")) | unique[]' \
  "$HOME/.openclaw/openclaw.json" \
  > "$PRIVATE_ROOT/configured-workspaces.txt"
jq -r '.. | strings | select(startswith("/"))' \
  "$HOME/.openclaw/openclaw.json" | sort -u \
  > "$PRIVATE_ROOT/configured-absolute-paths.txt"

while IFS= read -r workspace_path; do
  case "$workspace_path" in
    "$HOME/.openclaw"/*) ;;
    *)
      printf 'External workspace needs an explicit backup/restore plan: %s\n' \
        "$workspace_path" >&2
      exit 1
      ;;
  esac
done < "$PRIVATE_ROOT/configured-workspaces.txt"
```

Review the absolute-path inventory. If a mutable workspace, database or plugin
store lives outside `~/.openclaw`, stop and extend both backup and rollback
before continuing. Merely copying `openclaw.json` does not redirect it.

Mattermost streaming drafts and `progress_card` plans are separate. Streaming
configuration renders transient activity; the model still has to call
`progress_card`. In v2026.11.1 the prompt reminder depends on compatible paired
renderer context. Record a real paired Control UI/mobile renderer when plan
cards are part of acceptance; never create a fake pairing.

## 4. Stop the Gateway and freeze one rollback unit

Define a hard stop check, then stop only the OpenClaw Gateway:

```bash
require_gateway_stopped() {
  if lsof -nP -iTCP:18789 -sTCP:LISTEN >/dev/null 2>&1; then
    echo "TCP 18789 is still listening" >&2
    return 1
  fi
  if launchctl print "gui/$(id -u)/ai.openclaw.gateway" >/dev/null 2>&1; then
    echo "ai.openclaw.gateway remains loaded" >&2
    return 1
  fi
  echo "GATEWAY_STOPPED_AND_UNLOADED"
}

openclaw gateway stop
require_gateway_stopped
```

Create a matched, copy-on-write APFS snapshot. Capture the complete state tree
instead of a release-specific list so newly added state directories are not
silently omitted. Preserve the existing standalone plugin/Codex packages and
binary links because an earlier canary may have installed them globally.

```bash
install -d -m 700 \
  "$ROLLBACK_ROOT/global-node-modules" \
  "$ROLLBACK_ROOT/bin" \
  "$ROLLBACK_ROOT/launchagents"

cp -ac "$HOME/.openclaw" "$ROLLBACK_ROOT/state"

GLOBAL_ROOT="$(npm root -g)"
GLOBAL_RELATIVE_PATHS=(
  openclaw
  @openclaw/codex
  @openclaw/mattermost
  @openai/codex
)
for relative_path in "${GLOBAL_RELATIVE_PATHS[@]}"; do
  source_path="$GLOBAL_ROOT/$relative_path"
  if [ -e "$source_path" ]; then
    destination="$ROLLBACK_ROOT/global-node-modules/$relative_path"
    mkdir -p "$(dirname "$destination")"
    cp -ac "$source_path" "$destination"
  fi
done

for binary_path in /opt/homebrew/bin/openclaw /opt/homebrew/bin/codex; do
  if [ -e "$binary_path" ] || [ -L "$binary_path" ]; then
    cp -a "$binary_path" "$ROLLBACK_ROOT/bin/"
  fi
done

cp -p "$HOME/Library/LaunchAgents/ai.openclaw.gateway.plist" \
  "$ROLLBACK_ROOT/launchagents/"
```

Authenticate the rollback copy before installing anything:

```bash
test -x "$ROLLBACK_ROOT/global-node-modules/openclaw/openclaw.mjs"
test -f "$ROLLBACK_ROOT/state/openclaw.json"
test -f "$ROLLBACK_ROOT/state/state/openclaw.sqlite"

write_database_inventory "$ROLLBACK_ROOT/state" \
  "$ROLLBACK_ROOT/verified-databases.jsonl"
jq -se 'length > 1 and all(.integrity == "ok")' \
  "$ROLLBACK_ROOT/verified-databases.jsonl" >/dev/null

diff -u \
  <(jq -sr 'map({identity,schema,integrity}) | sort_by(.identity)' \
    "$PRIVATE_ROOT/pre-databases.jsonl") \
  <(jq -sr 'map({identity,schema,integrity}) | sort_by(.identity)' \
    "$ROLLBACK_ROOT/verified-databases.jsonl")

shasum -a 256 "$ROLLBACK_ROOT/state/openclaw.json" \
  > "$ROLLBACK_ROOT/openclaw-config.sha256"
echo "MATCHED_ROLLBACK_UNIT_OK $ROLLBACK_ROOT"
```

Keep the Gateway stopped through installation and migration. Do not run Doctor
against the rollback copy; it is recovery evidence, not a rehearsal target.

## 5. Install the core and migrate real state

Reconfirm explicit approval for the exact `RELEASE_TAG` and this Mac mini.
Install as the normal user, then verify installed package identity **before** a
target CLI reads mutable state:

```bash
npm install -g \
  --foreground-scripts --no-audit --no-fund \
  "$CORE_TGZ"

OPENCLAW_CORE="$(npm root -g)/openclaw"
openclaw --version | tee "$ROLLBACK_ROOT/installed-version.txt"
rg -q "^OpenClaw ${CORE_VERSION//./\\.} " \
  "$ROLLBACK_ROOT/installed-version.txt"
jq -e --arg version "$CORE_VERSION" --arg commit "$CORE_COMMIT" \
  --arg buildId "$EXPECTED_BUILD_ID" --arg builtAt "$EXPECTED_BUILT_AT" \
  '.version == $version and .commit == $commit and
   .buildId == $buildId and .builtAt == $builtAt' \
  "$OPENCLAW_CORE/dist/build-info.json"

for plugin_id in codex mattermost; do
  jq -e --arg version "$CORE_VERSION" \
    '.version == $version and
     .openclaw.build.openclawVersion == $version and
     .openclaw.build.bundledDist == true' \
    "$OPENCLAW_CORE/dist/extensions/$plugin_id/package.json"
done
require_gateway_stopped
```

This is the first candidate command allowed to migrate real state. Capture the
actual Doctor exit code. Even when Doctor fails, check whether it loaded or
restarted the service and return the host to verified maintenance state before
making a decision:

```bash
set +e
openclaw doctor --fix --non-interactive --yes --no-workspace-suggestions \
  2>&1 | tee "$ROLLBACK_ROOT/doctor.log"
DOCTOR_EXIT="${PIPESTATUS[0]}"
set -e

if launchctl print "gui/$(id -u)/ai.openclaw.gateway" >/dev/null 2>&1 \
  || lsof -nP -iTCP:18789 -sTCP:LISTEN >/dev/null 2>&1; then
  openclaw gateway stop || true
fi
require_gateway_stopped
test "$DOCTOR_EXIT" -eq 0

openclaw config validate
openclaw plugins doctor 2>&1 | tee "$ROLLBACK_ROOT/plugin-doctor.txt"
```

A Doctor failure is not permission to continue or to run broad repair/update
commands. Preserve its verified backups and refusal chain. Apply only a bounded,
reviewed correction or roll back.

If ACPX capability consent is reported, inspect the existing plugin and its
deliberate permission posture separately. Do not blanket-approve unrelated
plugins. Any new capability acceptance requires explicit owner approval.

## 6. Prove migration, plugin origin and preserved state

Verify every database, full inventory and the package-declared schemas:

```bash
write_database_inventory "$HOME/.openclaw" \
  "$ROLLBACK_ROOT/post-databases.jsonl"

diff -u \
  <(jq -sr 'map(.identity) | sort' "$PRIVATE_ROOT/pre-databases.jsonl") \
  <(jq -sr 'map(.identity) | sort' "$ROLLBACK_ROOT/post-databases.jsonl")

jq -se --argjson state_schema "$TARGET_STATE_SCHEMA" \
  --argjson agent_schema "$TARGET_AGENT_SCHEMA" '
    (map(select(.identity == "state")) | length == 1) and
    (map(select(.identity == "state"))[0].schema == $state_schema) and
    (map(select(.identity | startswith("agent:"))) | length > 0) and
    (map(select(.identity | startswith("agent:"))) |
      all(.schema == $agent_schema and .integrity == "ok"))
  ' "$ROLLBACK_ROOT/post-databases.jsonl" >/dev/null
```

Require exact bundled plugins and no external install record for Codex or
Mattermost:

```bash
for plugin_id in codex mattermost; do
  openclaw plugins inspect "$plugin_id" --runtime --json \
    > "$ROLLBACK_ROOT/final-$plugin_id.json"
  jq -e --arg id "$plugin_id" --arg version "$CORE_VERSION" \
    --arg core "$OPENCLAW_CORE" '
      .plugin.id == $id and .plugin.version == $version and
      .plugin.status == "loaded" and .plugin.origin == "bundled" and
      (.plugin.source | startswith($core + "/dist/extensions/" + $id + "/")) and
      (.install == null)
    ' "$ROLLBACK_ROOT/final-$plugin_id.json" >/dev/null
done

openclaw plugins list --json > "$ROLLBACK_ROOT/post-plugins.json"
openclaw models status --json > "$ROLLBACK_ROOT/post-models.json"
openclaw sessions --agent main --limit 1 --json >/dev/null

jq -S '{
  bindings,
  mattermost: {
    streaming: .channels.mattermost.streaming,
    finalDelivery: .channels.mattermost.finalDelivery,
    groupPolicy: .channels.mattermost.groupPolicy,
    groups: .channels.mattermost.groups
  },
  telegram: {
    enabled: .channels.telegram.enabled,
    accounts: (.channels.telegram.accounts // {} | keys)
  }
}' "$HOME/.openclaw/openclaw.json" | shasum -a 256 \
  > "$ROLLBACK_ROOT/post-routing-config.sha256"
diff -u "$PRIVATE_ROOT/pre-routing-config.sha256" \
  "$ROLLBACK_ROOT/post-routing-config.sha256"
```

Review model/auth status without printing credential values. A healthy profile
with a degraded plugin route is a plugin/runtime failure, not evidence that the
credential should be deleted or recreated.

## 7. Prove foreground lifecycle, then managed service

Start the Gateway in the foreground while the LaunchAgent is absent:

```bash
require_gateway_stopped
openclaw gateway run
```

Wait for readiness and all configured channels to connect. Require no migration,
schema, plugin, trust, duplicate-origin, session or Control UI build error.
Press Ctrl-C once and require a clean shutdown plus a returned prompt. Then:

```bash
require_gateway_stopped
POST_UPGRADE_STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf '%s\n' "$POST_UPGRADE_STARTED_AT" \
  > "$ROLLBACK_ROOT/post-upgrade-started-at.txt"
openclaw gateway start
```

After bounded warm-up, collect one coherent snapshot:

```bash
openclaw gateway status --deep --require-rpc \
  | tee "$ROLLBACK_ROOT/post-gateway-status.txt"
openclaw gateway health | tee "$ROLLBACK_ROOT/post-gateway-health.txt"
openclaw status > "$ROLLBACK_ROOT/post-status.txt"
openclaw channels status --probe --json \
  > "$ROLLBACK_ROOT/post-channels.json"
openclaw logs --json --limit 5000 --max-bytes 1000000 \
  > "$ROLLBACK_ROOT/post-upgrade-logs.jsonl"
```

Record the managed PID/launch count, wait through the agreed stability window,
then collect status again. Require the same PID, no restart growth and no
recurring error in logs since `POST_UPGRADE_STARTED_AT`. Review warnings rather
than hiding them; classify a warning as pre-existing or non-blocking only with
concrete evidence.

## 8. Prove real delivery and paired-client behavior

Process health is insufficient. With explicit approval for test messages:

1. Send a unique inbound Mattermost message to Kapiteky and require a reply.
2. Confirm the transient progress draft and final ordinary post follow the
   configured delivery semantics.
3. Run a substantial multi-step task whose model calls `progress_card`; confirm
   a compatible paired renderer displays the plan. A streaming draft alone is
   not progress-card proof.
4. Verify every other configured channel/account that the upgrade could affect.
5. Confirm paired Control UI/mobile clients reconnect and display the exact
   Gateway version/build.
6. Recheck Gateway PID, health, channel probes and the bounded log window.

Keep the authenticated assets and rollback unit through the soak period.

## 9. Roll back as one transaction

Rollback when the candidate is abandoned or a failed gate cannot be corrected
safely. Stop and unload the candidate Gateway first:

```bash
if ! openclaw gateway stop; then
  launchctl bootout "gui/$(id -u)" \
    "$HOME/Library/LaunchAgents/ai.openclaw.gateway.plist" || true
fi
require_gateway_stopped

FAILED_ROOT="$PRIVATE_ROOT/failed-candidate-$(date -u +%Y%m%dT%H%M%SZ)"
install -d -m 700 \
  "$FAILED_ROOT/global-node-modules" "$FAILED_ROOT/bin" "$FAILED_ROOT/state"
```

Move the candidate aside, then restore all captured global packages and links:

```bash
GLOBAL_ROOT="$(npm root -g)"
for relative_path in "${GLOBAL_RELATIVE_PATHS[@]}"; do
  live_path="$GLOBAL_ROOT/$relative_path"
  backup_path="$ROLLBACK_ROOT/global-node-modules/$relative_path"
  failed_path="$FAILED_ROOT/global-node-modules/$relative_path"
  if [ -e "$live_path" ]; then
    mkdir -p "$(dirname "$failed_path")"
    mv "$live_path" "$failed_path"
  fi
  if [ -e "$backup_path" ]; then
    mkdir -p "$(dirname "$live_path")"
    cp -ac "$backup_path" "$live_path"
  fi
done

for binary_name in openclaw codex; do
  live_binary="/opt/homebrew/bin/$binary_name"
  backup_binary="$ROLLBACK_ROOT/bin/$binary_name"
  if [ -e "$live_binary" ] || [ -L "$live_binary" ]; then
    mv "$live_binary" "$FAILED_ROOT/bin/$binary_name"
  fi
  if [ -e "$backup_binary" ] || [ -L "$backup_binary" ]; then
    cp -a "$backup_binary" "$live_binary"
  fi
done
```

Restore the complete pre-migration state and LaunchAgent definition:

```bash
mv "$HOME/.openclaw" "$FAILED_ROOT/state/openclaw"
cp -ac "$ROLLBACK_ROOT/state" "$HOME/.openclaw"
cp -p "$ROLLBACK_ROOT/launchagents/ai.openclaw.gateway.plist" \
  "$HOME/Library/LaunchAgents/ai.openclaw.gateway.plist"

write_database_inventory "$HOME/.openclaw" \
  "$ROLLBACK_ROOT/restored-databases.jsonl"
diff -u \
  <(jq -sr 'map({identity,schema,integrity}) | sort_by(.identity)' \
    "$ROLLBACK_ROOT/verified-databases.jsonl") \
  <(jq -sr 'map({identity,schema,integrity}) | sort_by(.identity)' \
    "$ROLLBACK_ROOT/restored-databases.jsonl")

openclaw --version | tee "$ROLLBACK_ROOT/restored-version.txt"
openclaw gateway start
openclaw gateway status --deep --require-rpc
openclaw gateway health
openclaw channels status --probe --json \
  > "$ROLLBACK_ROOT/restored-channels.json"
```

Repeat real channel and paired-client checks. Preserve the failed candidate for
diagnosis; never mix its files back into the restored installation.

## 10. Close the host promotion

Record privately:

- release tag, package hash, source, build ID and timestamp;
- old/new CLI and Gateway versions;
- pre/backup/post database inventories and integrity results;
- target schema result and Doctor receipt/log;
- exact plugin origins and any reviewed capability decision;
- foreground shutdown, managed PID/restart stability and bounded logs;
- Mattermost, other configured channels, paired clients and progress-card proof;
- rollback result, if used.

Mac success does not change the swarm verdict, and swarm success does not prove
the Mac. Keep their approvals, evidence and rollback boundaries separate. Do
not rewrite immutable release assets after promotion.
