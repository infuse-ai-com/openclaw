# Live bundled-plugin hot patch

Use this procedure to validate a narrow bundled-plugin source fix against one
already deployed canary agent before paying for another package build. It is a
bounded validation or emergency bridge, not a production distribution method.
The source fix, durable package and production image still follow their normal
review and release workflows.

## Boundaries

- Patch one agent first. Use the agent that reproduces the defect; otherwise use
  the normal Tinus canary target.
- Fix and test the versioned feature branch before touching a running agent.
- Build the override from the **exact deployed bundle plus the fix**. A single
  feature branch may omit other canary behaviors and can therefore expose an
  incompatible schema or runtime when loaded by itself.
- Store the temporary override on the agent's persistent OpenClaw state volume,
  never only under `/tmp`. A persisted `plugins.load.paths` entry must not point
  at files that disappear with the Pod.
- Use the supported `openclaw plugins reload <id> --json --wait` lifecycle. Do
  not kill the Gateway process, weaken the Pod security context, add a privileged
  debugger or edit root-owned image files.
- Do not fan the override out as durable fleet state. A plugin override is
  mutable code outside the immutable image and becomes configuration drift.
- A successful live reproduction is focused acceptance evidence. It is not a
  hosted build, Phase-5 qualification, publication or production promotion.

## 1. Freeze identities and the rollback point

Record privately:

- deployed OpenClaw version, source commit and immutable image digest;
- target Pod, container, readiness, restart counts and plugin runtime source;
- exact feature branch and reviewed fix commit;
- active configuration file and the authored `plugins.load.paths` value; and
- bounded logs from before the change.

Stop if the target is not healthy, the deployed source cannot be resolved, the
plugin already has an unexplained override, or the fix is not committed and
tested. Preserve the pre-change configuration bytes or exact authored value as
the rollback input; never print secrets while capturing it.

## 2. Build the exact composite plugin

Create a disposable detached worktree at the deployed bundle commit, apply the
reviewed feature fix, install the frozen lockfile and build the normal external
plugin distribution. For the Mattermost bundle used in v2026.11.3, the proven
build command was:

```sh
node --import ./scripts/tsx.mjs scripts/build-all.mts gatewayWatch
```

Verify before staging:

1. the worktree starts at the deployed bundle and contains only the reviewed
   fix on top;
2. focused source tests, formatting and lint passed on the feature branch;
3. the built plugin reports the deployed OpenClaw version and
   `openclaw.build.bundledDist=false`;
4. its generated manifest accepts the target's effective configuration; and
5. the compiled artifact contains the intended fix and every other active
   canary behavior owned by that plugin.

Do not copy the built plugin from the isolated feature branch directly. During
the v2026.11.3 reaction repair that artifact correctly contained the reaction
change but lacked the bundle's separate-progress metadata, so config validation
rejected it before reload.

## 3. Stage a persistent override

Copy the built plugin directory into an explicit directory under the target's
persistent OpenClaw state, for example:

```text
<state-dir>/hotfixes/<plugin-id>-<fix-short-sha>/
```

Resolve runtime dependencies inside that directory. A workspace symlink copied
from a local pnpm checkout is not valid in the container; replace it with the
exact dependency directory already present in the deployed image or install the
frozen package dependencies in the staged directory. Validate the entrypoint and
manifest in the container before changing configuration.

Set `plugins.load.paths` with a conditional config write that expects the
captured old value. Preserve unrelated existing load paths. Run
`openclaw config validate` immediately. If validation fails, restore the exact
old value before continuing.

## 4. Reload only the affected plugin

Apply the change through the running Gateway:

```sh
openclaw plugins reload <plugin-id> --json --wait
```

Require all of the following:

- `ok=true` and `restartRequired=false`;
- a new Gateway plugin generation;
- `selectedEntries.<plugin-id>` equals the persistent override path;
- readiness remains true and restart counts do not grow;
- the channel reconnects for reason `plugin-reload`; and
- bounded post-action logs contain the replacement-applied record and no new
  recurring failure.

A rejected replacement is safe only when the previous generation remains
active. Diagnose the candidate, restore invalid authored configuration, and do
not restart the Gateway to force it through.

## 5. Run the behavior acceptance test

Use the smallest real reproduction and inspect provider-side effects. For
reaction-only completion, test both:

1. a direct message requesting exactly one named emoji reaction and no text;
2. a channel thread requesting exactly one named emoji reaction and no text.

Acceptance is one requested reaction and zero new Mattermost posts in each
case. Correlate source message IDs, reaction records, new post IDs and bounded
Gateway logs. A successful tool call alone is not sufficient.

## 6. Choose the durable path and remove the override

Classify the reviewed source delta, not the apparent size of the hot patch:

- deployment configuration only: change `openclaw-k8s-swarm`, then use its
  Tinus-first rollout;
- deterministic generated/package metadata with no runtime-boundary change:
  use the corrective-rebuild runbook when every eligibility condition passes;
- runtime behavior, dependencies, toolchain, credential handling, migration,
  plugin API or platform support: use the full next-canary workflow.

Keep the one-agent override only until the durable image is ready or the test is
rolled back. After the durable image reaches that agent, remove the exact
hotfix path from `plugins.load.paths`, reload the bundled plugin, prove its
runtime source is back under the immutable image, then remove the staged files.
The peer fleet must converge through the reviewed image and rollout controller,
not by repeating this manual override.
