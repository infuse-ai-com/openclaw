# Runbooks

Use the [canary workflow](../RUNBOOK.md) for command detail and the
[next-canary checklist](NEXT_CANARY.md) for the repeatable end-to-end release,
publication, production and branch-closure sequence. Use the
[corrective-rebuild runbook](CORRECTIVE_REBUILD.md) only for an eligible narrow
correction to an already fully qualified canary. Use the
[live bundled-plugin hot-patch runbook](LIVE_PLUGIN_HOTPATCH.md) only for a
reviewed one-agent behavior validation before rebuilding; it is not a durable
fleet rollout. Use the
[Kapiteky Mac mini runbook](KAPITEKY_MAC_MINI_CANARY.md) only after publication
to promote the authenticated core package on the personal Apple-silicon
Gateway. The builder owns no running service, and Mac promotion has its own
approval, evidence and rollback boundary.

Only these runbooks are active instructions. Files under `docs/archive/` and
`docs/evidence/` are immutable historical evidence, not recovery plans to replay.
