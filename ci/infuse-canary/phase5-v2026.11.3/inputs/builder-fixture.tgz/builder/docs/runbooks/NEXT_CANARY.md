# Next OpenClaw canary

This is the only active cross-repository canary procedure. Historical plans,
branches, manifests, receipts and evidence describe completed releases and must
never be replayed as current instructions.

## Authorities

| Concern | Authority |
| --- | --- |
| New custom source, bundle, build controller and prerelease | `infuse-ai-com/openclaw` |
| Manifest, trusted controllers and qualification custody | `openclaw-canary-builder` |
| Studio native-runtime fixture | Studio repository |
| Production image, rollout and rollback | `openclaw-k8s-swarm` |
| Historical source only | `aolea/openclaw` |

The builder has no deployment command. Build, publication and deployment are
separate evidence boundaries even when the owner has approved the full cycle.

## 0. Choose the path before building

Use this full workflow for a new upstream version, feature, dependency,
toolchain, runtime policy, migration, plugin API, credential/fallback behavior
or platform-support change. Do not call one of those changes a correction to
avoid qualification.

If an already fully qualified canary needs a narrow package-byte repair, apply
the [corrective-rebuild runbook](CORRECTIVE_REBUILD.md). If package bytes do not
change, keep the work in the production owner and do not build another package.
When eligibility is uncertain, use the full workflow.

For a narrow bundled-plugin defect already reproduced in production, the
[live hot-patch runbook](LIVE_PLUGIN_HOTPATCH.md) may validate the reviewed fix
on one agent before rebuilding. That override is temporary acceptance evidence,
not a release or fleet-delivery path. A runtime-behavior fix still requires this
full workflow even when the live patch is only a few lines.

## 1. Freeze one upstream release

1. Verify the annotated upstream tag and record its peeled commit.
2. Inventory custom behaviors from the prior fork; do not replay a flattened
   bundle or use an old canary branch as a base.
3. Create every feature branch directly from the peeled tag:
   `feat/canary/<behavior>/vYYYY.MM.DD`.
4. Create `canary-openclaw-vYYYY.MM.DD` from the same tag.
5. Record acceptance criteria, non-goals, approvals and exact branch names in
   the active version plan.
6. Disable source-branch deletion for feature PRs. A merged feature branch is
   append-only within its selected version: deny force pushes, rebases and
   deletion. A same-version defect may advance it through a new reviewed commit
   and bundle PR; record both reviewed heads. Never append a later release
   reconciliation to it.

## 2. Reconcile each behavior independently

Port one behavior per branch. Each branch gets focused tests and an independent
review before its PR enters the bundle. Reconcile upstream changes inside the
feature branch; never merge fork `main` into feature or bundle branches. Merge
with source-branch deletion disabled, then verify the retained branch still
resolves to the reviewed PR head. A later same-version fix starts from that head,
passes focused review again and enters the same bundle through a new PR. The
squash commits in the bundle and the append-only feature history are
complementary evidence; neither replaces the other.

## 3. Add a reviewed builder profile

1. Add a versioned manifest, hosted/collector tree and complete harness lock.
2. Bind the exact repository, branch grammar, Node image/digest, package manager,
   compiler graph, resource and timeout contracts.
3. New profiles use schema 3, repository `infuse-ai-com/openclaw`, runner label
   `blacksmith-16vcpu-ubuntu-2404`, bundle branch
   `canary-openclaw-vYYYY.MM.DD`, and build branch
   `build/canary-openclaw-vYYYY.MM.DD`. Failed attempts stay immutable and the
   next attempt uses `build/canary-openclaw-vYYYY.MM.DD-rN` (`N >= 2`).
4. Preserve historical schema-1/schema-2 manifests and controller locks
   byte-for-byte.
5. Run `task verify`, obtain exact-head GitLab review and merge only that head.

## 4. Assemble the bundle

Merge reviewed feature PRs into `canary-openclaw-vYYYY.MM.DD` in a recorded
order. Run combined regressions and record the final bundle SHA. Product changes
never enter fork `main`.

Before generating a controller, classify every custom behavior as either
**opt-in configuration** or **intrinsic runtime policy**, then prove its packaged
activation contract. Shipping implementation code is not proof that production
will use it.

For the retained v2026.11.3 behaviors, the contract is:

| Behavior | Activation | Required evidence |
| --- | --- | --- |
| Required managed-conversation ownership | Intrinsic when the owning Studio service is admitted | Studio plugin and required-owner service/routes loaded; fail-closed ownership smoke passes. |
| Mattermost separate progress/final delivery | `channels.mattermost.streaming.mode="progress"` plus `channels.mattermost.streaming.progress.finalDelivery="separate"` | Packaged runtime accepts the effective config; final posts separately and progress cleanup follows confirmed delivery. |
| Reaction reply completion | `surfaces.mattermost.replyCompletion.group="message-or-reaction"` | Effective config matches; the adapter returns structured confirmed-delivery evidence; DM and group-thread requests each produce one reaction and zero posts. |
| Personal-account spending isolation | Intrinsic whenever a personal model credential is selected | Qualification proves credential pinning, retry/fallback denial and auxiliary model-spend suppression; there is no enable flag. |

If a bundled channel schema changes, run `pnpm config:channels:check`, commit the
regenerated metadata, and validate the effective configuration with the built
package. Direct extension-schema tests and a successful compile are insufficient
because startup validation consumes generated bundled metadata.

Before generating or dispatching the expensive controller, run one cheap
secretless packaged-activation gate against the exact bundle:

1. run every deterministic generated-file check, including
   `pnpm config:channels:check` for channel schemas;
2. run the focused feature/configuration regressions;
3. run `pnpm release:check` and install the exact resulting archive in a clean
   disposable directory;
4. validate the sanitized production configuration through the packed CLI; and
5. assert the intended opt-in values from the effective configuration.

A source-level schema test, TypeScript build or unpacked CLI validation cannot
substitute for this gate. Fix failures in the feature/bundle branch before any
Blacksmith full qualification, Phase 5 or publication work begins.

## 5. Generate the build controller

From a clean bundle checkout:

```sh
python3 -B -m canary_builder propose \
  --source /absolute/path/to/openclaw \
  --upstream-tag vYYYY.MM.DD \
  --build-attempt 1 \
  --output /absolute/path/to/proposed.json

python3 -B -m canary_builder \
  --manifest /absolute/path/to/proposed.json \
  --workspace /absolute/path/to/fresh-workspace \
  prepare-hosted --source /absolute/path/to/openclaw
```

Review the manifest, source snapshot, complete controller closure and generated
`ci/infuse-canary/` tree. Commit that tree to the exact build branch. Schema-3
preparation does not generate or replace the default-branch dispatcher.
After a failed hosted run, preserve its controller branch and evidence, choose
the next unused integer, and regenerate with `--build-attempt N`.

## 6. Dispatch the Blacksmith build manually

The only enabled workflow in `infuse-ai-com/openclaw` is
`.github/workflows/infuse-canary.yml` on the default branch. Every inherited
upstream workflow remains `disabled_manually`.

GitHub enables newly introduced workflow files independently of repository
content. After each upstream reconciliation and before dispatch, enumerate all
workflows and disable every active workflow except `Infuse canary build`; verify
the allowlist again after the build. A green source reconciliation does not
prove the fork's workflow activation state.

Dispatch only after independently resolving both heads:

```sh
gh workflow run .github/workflows/infuse-canary.yml \
  --repo infuse-ai-com/openclaw \
  --ref main \
  -f build_ref=<exact-build-branch> \
  -f build_sha=<exact-40-character-build-sha>
```

The dispatcher and schema-3 binding must agree on repository, build branch,
bundle branch, exact bundle SHA and `blacksmith-16vcpu-ubuntu-2404`. Preserve
failed runs. Never mutate a failed controller branch to make its evidence green.

## 7. Collect and qualify

Record the exact run ID/attempt in a new manifest revision and collect into a
fresh workspace. For schema 3, require the run and artifact metadata to agree on
the protected dispatcher SHA, the artifact/bootstrap evidence to agree on the
exact controller SHA, and the binding/packages to agree on the candidate SHA.
Require the complete locked hosted proof and all current Phase-5 lanes. Old
release receipts cannot satisfy any current gate.

## 8. Publish and verify

Freeze the nine public assets, run `verify-assets`, review `release-plan`, then
publish the exact prerelease by ID. Reconcile uncertain remote effects before
retrying. Run a fresh `release-verify` against all public downloads.

## 9. Promote and close

Promote only through `openclaw-k8s-swarm`, with its own exact runtime pin,
schema/plugin admission, immutable image digest, rollout evidence and rollback
contract. Enumerate and reconcile every version-bound swarm surface before
building: Dockerfile/package URL and hash, candidate manifest, consumer lock,
migration and plugin markers, smoke expectations, telemetry annotations and
deployment guards.

### Complexity budget

The minimum production route is deliberately small:

1. one reviewed release contract owned by `openclaw-k8s-swarm`;
2. one immutable-image verification job;
3. one Tinus canary job;
4. one sequential peer-fleet job that depends on the Tinus job;
5. one normalized summary per gate, with raw before/after snapshots and logs.

The release contract must bind version, package/source identity, selected image
digest, schema/migration markers and the per-agent plugin archive contract. The
same contract drives preflight, the Deployment patch, exact postchecks and the
rollback capture. Do not create a second release descriptor or a parallel
rollout script for one canary.

Use the established protected `production` environment for both jobs; canary
scope belongs in the target set and dependency graph, not in a new environment
name. Do not perform out-of-band `kubectl` mutations to compensate for an
incomplete controller. Fix and review the controller, then rerun the Tinus gate.
Any new job, environment, desired-state representation or manual handoff must
name the distinct failure boundary it owns; otherwise it is avoidable
complexity.

Before any workload mutation:

1. Prove that the exact GitLab job environment receives every required
   protected variable; do not invent a nested canary environment name unless
   the variable scopes explicitly admit it.
2. Package required runtime plugins as immutable archives. In a disposable
   persistent state directory, install and reinstall each archive twice and
   require exact plugin ID, version and archive origin after both passes.
3. Capture the current image, configuration, PVC identities and all persistent
   convergence markers needed by the old runtime. A rollback must restore that
   complete contract, not only the image reference.
4. Require the rollout controller to reconcile and postcheck exact image,
   source/version annotations and every reviewed version-bound environment
   value. Configuration drift is a failed canary even when the Pod is Ready.

Deploy the reviewed digest to `agent-developer` (Tinus) first. Require exact
image/source/version, schema/plugin admission, Gateway and Mattermost readiness,
Studio route/service startup, zero unexpected restarts, bounded post-ready logs
and rollback readiness. Any post-mutation failure must restore the captured
prior runtime contract and wait for Tinus readiness before the job terminates;
a failed job that leaves the canary unavailable is not safe containment. Only after Tinus
passes may the same digest roll sequentially to `agent-designer`, `agent-infra`,
`agent-intake` and `agent-coordinator`, with the same post-action checks.

Mac promotion remains a separate host procedure. Close the cycle only after all
PR/MR state, retained feature/build/bundle refs, release evidence, production
evidence and residuals are recorded in current project docs.
