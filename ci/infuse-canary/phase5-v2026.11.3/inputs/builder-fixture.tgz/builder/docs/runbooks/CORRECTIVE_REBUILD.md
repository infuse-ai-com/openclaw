# Corrective OpenClaw rebuild

Use this path only when an already fully qualified canary needs a narrow change
to package bytes. It reduces repeated qualification; it does not weaken package
identity, Tinus-first deployment or rollback.

## 1. Classify before acting

Use no package rebuild when only deployment configuration changes. Keep that
change in `openclaw-k8s-swarm`, run its checks and use Tinus first.

Use the full next-canary workflow when any change affects runtime behavior,
dependencies or lockfiles, toolchain, authentication or credential fallback,
model spending, migrations, plugin APIs, supported platforms, or the selected
upstream/feature set.

A corrective rebuild is eligible only when all of these are true:

1. the exact prior bundle, hosted run, Phase-5 plan, qualification and public
   prerelease are fully identified and passed;
2. the new commit descends from that bundle and retains the same upstream tag,
   toolchain, lockfile and feature set;
3. the diff is limited to deterministic generated/package metadata plus its
   focused tests or documentation;
4. regeneration from the reviewed source of truth reproduces the changed bytes;
5. an explicit self-review confirms that no runtime boundary changed.

If any item is false or uncertain, stop and use the full workflow.

## 2. Prove the delta cheaply

Run inside a disposable secretless boundary:

1. frozen dependency installation;
2. every relevant generated-file check, including
   `pnpm config:channels:check` for channel metadata;
3. focused tests for the corrected schema/configuration path;
4. `pnpm release:check`;
5. clean installation of the exact packed core/plugin archives; and
6. `openclaw config validate` through the packed CLI against the sanitized
   production configuration, followed by assertions for the intended effective
   values.

Record the exact base and correction commits, complete changed-file inventory,
commands, exit status and archive hashes. A green source build is insufficient.

`pnpm release:check` should pass. If its build succeeds but the preflight finds
generated baseline drift already present in the fully qualified base, do not
regenerate unrelated files into the correction. Record the failed check names
and equal base/candidate SHA-256 values for every implicated tracked input. The
asset verifier accepts this only when those inputs are outside the correction's
changed-file closure. A new failure, a changed implicated input, or an
incomplete attribution requires the full workflow.

## 3. Build and publish one immutable correction

Use a fresh immutable controller branch and prerelease tag bound to the
correction commit. Preserve failed attempts. The correction evidence references
the prior full qualification by exact release ID, candidate-manifest hash and
qualification hash, and labels every unchanged lane as referenced. It must not
copy the old qualification file or claim those lanes were freshly executed.

Do not improvise a partial public asset set or bypass the builder's verifier.
Keep the normal nine-asset closure, but record the corrective verdict in
`LINUX-QUALIFICATION.json` with status
`passed-correction-with-referenced-runtime-lanes`. The fresh hosted and
`packagedActivation` checks must pass. Every unchanged Phase 5 lane must have
status `referenced` and carry the exact prior qualification SHA-256; a carried
lane must never be relabeled `passed`.

The manifest's `referenceEvidence.correction` object is the reviewed authority
for the prior release ID/tag, prior source, candidate-manifest, Phase-5 plan and
qualification hashes, plus the complete sorted changed-file closure. The asset
verifier requires the qualification record to match that object byte-for-byte.
If the correction cannot fit this contract, use the full workflow.

## 4. Promote through the unchanged safety boundary

Build one immutable production image from the corrected package. Deploy Tinus
first and require exact image/source/version, packed configuration acceptance,
feature activation, plugin/service readiness, Mattermost and Gateway readiness,
zero unexpected restarts and bounded logs. Any post-mutation failure restores
the captured prior runtime contract automatically.

Only after Tinus passes may the same digest roll sequentially to the four peers.
Record the correction and its referenced-vs-fresh evidence in the version
closeout. Retain the original and correction branches; neither becomes the base
for the next upstream version.
