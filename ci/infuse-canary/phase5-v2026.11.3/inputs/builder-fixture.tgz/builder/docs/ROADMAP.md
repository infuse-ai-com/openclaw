# Project roadmap

Last updated: 2026-11-14. Owner: Infuse AI engineering.

## Delivered historical baselines

- v2026.10.3: retained schema-1 manifest/controller evidence.
- v2026.11.1: retained schema-2 hosted, Phase-5, prerelease and production
  evidence. The exact records live under `manifests/`, `docs/evidence/`,
  `docs/archive/`, `docs/reference/` and the versioned harness directories.
- v2026.11.3: retained schema-3 Blacksmith build, seven-lane qualification,
  prerelease and Tinus-first production evidence. Four append-only versioned
  feature refs retain behavior-specific provenance and same-version correction
  history.

These are immutable evidence, not active plans. The old `aolea/openclaw`
branches, self-hosted `ncase` runner procedure and generated per-build workflow
must not be used for a new canary.

## Next delivery

No new upstream version is selected. Start the next cycle only from a newly
peeled upstream tag and fresh versioned feature branches. Use the
[next-canary runbook](runbooks/NEXT_CANARY.md); the completed
[v2026.11.3 plan](plans/v2026.11.3-canary.md) is historical evidence only.

## Durable backlog

- Consolidate the swarm's version, selected digest, per-agent plugin archives,
  migration markers and rollback markers into one reviewed release contract
  consumed by build smoke, Tinus/peer rollout and exact postchecks. Preserve the
  existing verify -> Tinus -> peers gates while removing duplicate desired-state
  representations.
- Migrate deprecated Plugin SDK calls before the first January 2027 stable
  release.
- Review the deliberate ACPX `approve-all` posture independently of the canary
  lifecycle.
- Reconcile retained uncertain delivery/session records only from provider or
  session evidence; never blind-replay them.

Production remains owned by `openclaw-k8s-swarm`. Raw/private evidence remains
outside Git. Failed hosted runs remain evidence and are never made green in
place.
