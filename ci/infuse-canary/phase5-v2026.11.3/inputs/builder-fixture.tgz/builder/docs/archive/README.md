# Documentation archive

Sanitized meeting notes and reviewed reference material. Name notes
YYYY-MM-DD-topic.md. Keep raw/private proofs and credentials outside tracked Git.
Completed delivery plans are retained under docs/plans/archive/ when needed for
provenance; current priorities belong in docs/ROADMAP.md.
