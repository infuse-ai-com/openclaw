# Historical Studio canary qualification: 2026.10.2 and 2026.10.3

Imported 2026-10-19. Owner: Infuse AI engineering.
Code repo: https://dev.azure.com/infuse-ai/Infuse%20AI/_git/openclaw-canary-builder

## Provenance and status

This curated archive replaces three uncommitted Studio records written during
2026-10-12–14. It retains useful final identities, qualification limits and
handoff lessons without copying temporary workstation paths, private source,
raw receipts or superseded step-by-step progress into current plans.
These are reported historical results, not checks executed during this import.
The builder's current [manifest](../../manifests/v2026.10.3.json), immutable
[release reference](../reference/import.json) and [runbook](../RUNBOOK.md) remain
authoritative for tooling and reference inputs.

The original plans' “no deployment” statements describe their build/publication
scope as of 2026-10-14. Studio main `c763e380faaec844d55a6e172a1c830b4ea1d0eb`
subsequently records the new canary as deployed per Fito's confirmation. This
import neither revalidates that live state nor treats the old handoff as pending
deployment authorization. Production evidence belongs to
[openclaw-k8s-swarm](https://dev.azure.com/infuse-ai/Infuse%20AI/_git/openclaw-k8s-swarm).

Original source records in Studio stash `22c190cb4335bbbe190d71ec86bc4bb45d0e145b`
(parent checkout `34dae09`), identified for provenance rather than retrieval:

| Former Studio path | Original content SHA-256 |
| --- | --- |
| `docs/plans/active/014-openclaw-2026.10.2-canary/plan.md` | `2bd161fb35f4a7b4689d642ceb5edc3154350ae339b3e819734e8ff61a56ba9c` |
| `docs/plans/active/017-openclaw-2026.10.3-canary/plan.md` | `3331b6997a2b9e30a49845db1f0d021032be39814d79d4c60513977dfcb46a26` |
| `docs/plans/active/017-openclaw-2026.10.3-canary/deployment-handoff.md` | `ca9b78d8c5552769d7bd7506a3efdccfb547adfa68c478b9074f6831e93735da` |

## 2026.10.2 C4 final reference

- Core: `cbbcbec54681f54b0cc8fddd78fdc77d01535e42`.
- Build-only CI: `584a784c797b0f5c0b873e4a05d7d4312bcc181c`.
- [Hosted run 38473298501](https://github.com/aolea/openclaw/actions/runs/38473298501):
  all 13 measured stages, 35 compiler graphs and five packages passed;
  unchanged complete source and zero OOM kills were recorded.
- Core archive: 106,295,611 bytes; SHA-256
  `347b2cf8505fe7af497d3b8f4f6e5e8c153cbb40ce8dcb33d4d480c0a37b97c2`.
  Protected manifest SHA-256:
  `010d393a2aebbefd10e2fae8834f07a1b29b9d17e472567ba040c2fada6891ef`.
- Normal ARM64 consumer install/native binding and installed custody passed:
  14,334 retained Core files and 132 private AI files. Eleven policy controls
  passed; the effective graph covered 627 packages and 1,160 declared edges.
- Native Studio used three disposable Gateways/Mattermost, 102 synthetic model
  turns and 14 settled runs, including revision, closeout and outage recovery.
  Ordinary Mattermost progress/final behavior and cleanup also passed.
- Emulated Linux AMD64 install, custody, plugin startup, readiness, owner-binding
  continuity through SIGUSR2 and clean SIGTERM passed. This establishes neither
  native AMD64 performance nor production supervisor behavior.
- Confined Mac offline install, Darwin native binding, CLI and before/after
  custody passed. Doctor exited 1 with fresh-fixture setup warnings; Mac Gateway,
  real Codex authentication/inference and persistent-state migration were unproved.
- Full local ARM64 image passed build, export/load, 39 layer digests, installed
  custody, 82 runtime assets and isolated browser/toolbox checks. Image digest:
  `sha256:96400161e417a5bec7b4a9c67aa7b8b474706855b453607d0adff65233ac9200`.
  Export SHA-256:
  `5111bcf5d66aa3a28d0903e501abeead241e0c7e3043fdd9958deeaa6a850ec2`.
  Swarm CI passed 607 Python and 29 behavioral tests; 22 metadata tests passed.
- C4 recorded no package release, registry publication or deployment. Eight owned
  fixture/build containers were stopped with storage retained. The direct frozen
  BuildKit context qualified; the then-existing Task image wrapper omitted its
  binding argument and correctly refused. Do not reuse it as a qualified wrapper.

SDK reconciliation corrected older counts: OpenClawPluginApi 86→87 (required
`conversationRoutes`), LivePreview 14→15 (required `observeSettlement`), four
optional lifecycle options, unchanged hookRunner count 48. No named-export or
public-entrypoint removals were reported. Complete hand-built implementations
and mocks need the new required members; ordinary factory consumers receive them.

## 2026.10.3 final reference and additional private qualification

The existing [public reference](../reference/release-notes.md) owns the exact
published inputs: Core `877030b3a66bec373d235129919a5a7a964ca07f`, CI
`87f474fa14e1495de84dce8420d189b3e1ab9731`,
[hosted run 38552435362](https://github.com/aolea/openclaw/actions/runs/38552435362)
and [prerelease](https://github.com/aolea/openclaw/releases/tag/canary-v2026.10.3-studio-required-owner-877030b3a6-r1).
All nine public assets were reported verified by remote digests and actual
downloads. The build-time manifest's publication flag is immutable historical
input, not current publication status.

The Studio records additionally report:

- 400 custom regressions and Studio's then-required checks (395 tests) passed.
  ARM64 consumer/native binding, ten public inventory checks, three-Gateway
  Studio/Mattermost (14 settled runs), ordinary Mattermost, emulated AMD64
  runtime and confined Mac installation/CLI custody passed.
- Final local ARM64 image:
  `sha256:bb706f1789176be7488517f99dc2d8f752d27c41683123065dc9e7fe0216bfd8`.
  The 2,518,326,784-byte export SHA-256:
  `ddd0157a9654e5e643b33e355f4746cdd702358eebe925da3aea8f31942c0ffc`.
- Final 181-file context fingerprint:
  `2e5bd3b975c96716d1ca539e8a28fea49a7e42c927b1498cb12beb25a559bae2`;
  image input binding:
  `3170b01b60352397974b1985d6a56eacff8a4a32c3eee4399d35515d5d8fbcda`;
  frozen 634-file swarm source fingerprint:
  `48accde7e1c5e39ec2beef52241fabb4d04d3d3a531f615bb4f5df4b1eaf1cc0`.
- All 39 image layers, 14,381 retained Core / 132 private-AI files and 82 runtime
  assets passed custody. Real Chromium/toolbox smoke and full Swarm CI passed
  607 Python, 29 behavioral and ten bootstrap tests with settled cleanup.
  The image smoke bypassed the startup entrypoint/live credential-vault flow.
- Private transfer omitted duplicate public Core archives and hydrated them by
  checksum. Final extraction and byte/mode inventories passed for 634 source,
  181 context, 657 consumer and 11 control files. The 12,757,043-byte bundle SHA:
  `a983be015645f7fafbc9fb23de789813e77f016aa1fcfd1049a8e65a1fb90645`.
  This identifies a private historical bundle; it is not attached to this repo
  or to the public release and is not a new builder-generated handoff.
- Six owned helpers were stopped, the task-stopped Workbench container restored,
  and user-stopped resources left alone. Raw diagnostics and source stayed private.

These historical proofs do not establish real Codex authentication/inference,
old-to-new state migration, Mac Gateway/restart, a complete AMD64 production image,
a Harbor publication or live rollout. Those require their owning runtime evidence.

## Handoff lessons retained for future releases

Use current swarm main and current production inventory; a qualified frozen
snapshot is a reference, not a production branch or rollback baseline. Reconcile
node architectures, package/plugin origins, actual image digests, active work
and profile/PVC identity through supported reads before changing runtimes.

The historical production pipeline still had package/image placeholders, an old
validation-branch condition and no new local-input binding. These were integration
gaps at handoff time, not claims about the current pipeline. Requalify changed
context/proxy/hash paths and the actual production architecture. Preserve normal
npm scripts/native optional dependencies and the canonical dependency policy.
Do not infer a production image from a package proof or a local ARM64 digest.

Keep one writer per agent, lifecycle-safe admission/drain, Recreate, predecessor
handoff and compatible state. Preserve Studio's writer/schema, exact approvals,
required-owner routes, membership/enrollment and uncertain-send reconciliation.
No ordinary-chat fallback, schema downgrade, PVC reset or unrelated access change
is authorized by this archive. Use the owning swarm main pipeline and current
rollout/rollback runbook; a ready pod alone is not behavior qualification.

Earlier failed runs/transfers remain failed. A 3-hour CI timeout did not qualify
the partial package result; a later complete run used a 240-minute limit.
10.3 image attempts refused stale metadata-commit and dependent inspector hashes;
only the fully reconciled final context passed. Preflight the complete assembled
pin chain before expensive work. Existing [lessons](../LESSONS.md) and builder
resume guards retain these constraints; historical receipts never qualify new bytes.
