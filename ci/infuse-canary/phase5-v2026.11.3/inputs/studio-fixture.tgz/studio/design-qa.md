# Cross-screen refinement QA — dogfood checkpoint, 2026-10-29

Scope: the user-requested steps 1–2, following the selected Neutral Studio light
and Quiet Slate dark pair. This is a local implementation checkpoint before Fito's
feedback, not full product acceptance or release qualification.

Source visual truth remains the selected references recorded below and the
read-only live findings in plan 035. Pre-refinement rendered core screens were
saved under `.studio-local/design-audit/refinement-before/`. Monitoring before/after
were compared together in one input at 1440 × 960 CSS/pixels, scale 1, same empty
fixture and keyboard-focused search. Focused controls were also compared together
as 1180 × 390 crops at x250/y20 (`monitoring-controls.png` in the before directory
and `test-results/design-consistency/`). No density normalization was needed.
The selected dark Activity reference and fresh populated rendered Activity were
compared together again; their 1435 × 1096 versus 1440 × 1100 size difference and
palette-only interpretation remain as documented below.

## Findings, fixes and revised evidence

- Resolved P2: paper bottom margin escaped the themed work surface. The owning
  surface now establishes a formatting context. Fresh `mission-paper-dark.png`
  shows the correct surround; the browser suite checks margin containment.
- Resolved P2: Review/list metadata consumed multiple full-width separator rows.
  The wide-list variant now groups team/date, keeping all content and the same
  link. Fresh `review-dark-1440.png` and `mission-list-dark.png` show the revision.
- Resolved P2: Knowledge search fields retained a separate size/radius/action
  treatment. Shared roles now apply to that dialog; fresh `knowledge-indexing/
  search-dark.png` and `search-mobile-dark.png` show desktop and narrow results.

The initial captures for these findings were inspected in the conversation; the
same output paths now hold the post-fix captures. The revised full views and
narrow Grilling/search views were opened and inspected. One Agents capture caught
a transient loading state; the capture now waits for the actual profile, and the
settled `family-agents-dark.png` was inspected. Loading is not counted as profile
visual proof.

## Fidelity and behavior

- Typography: shared section scale and action weight; operational labels align.
  Actual Studio fonts remain; Knowledge document typography stays independent.
- Layout: common insets and compact filters, flatter Grilling composition,
  compact Review metadata, wrapping mission sections and narrow form/search reflow.
- Colors: selected palette retained, shared field/focus/selection roles extended;
  opposite document/app themes tested without recoloring the surrounding tools.
- Assets: original logo, icons, portraits and artwork retained; no new imagery.
- Copy: literal mission/document content and domain labels preserved; no new
  technical explanations or design-review copy appears in product flows.

Eight focused suites passed (see plan 035 [refinement record](docs/plans/active/035-design-consistency/refinement.md)).
Relevant captures are in `test-results/design-consistency`, `knowledge-indexing`,
`contributions`, `monitoring`, `settings` and `native-workspace`. Page-error checks
reported no errors in the passing runs. Knowledge reads here are synthetic
presentation fixtures, not a companion-service integration pass.

No remaining P0/P1/P2 issue was identified in this scoped review. Full zoom/deep
state coverage and user acceptance remain open. Preview: `http://127.0.0.1:4542/`.
The existing listener is running; refresh to load the latest build. Browser-control
attachment failed in this turn, so rendered verification used the repository harness.

final result: passed

---

# Selected palette implementation QA — 2026-10-29

Scope: Neutral Studio light (displayed option 2) and Quiet Slate dark (displayed
option 3), shared presentation and the adopted surfaces. This is a palette-led
refinement of the real product, not a pixel-for-pixel reconstruction of generated
Activity typography. Full plan acceptance and user experience acceptance remain open.

## Visual truth and rendered evidence

Source references (private, ignored):
- `.studio-local/design-audit/palette-references/selected-light-neutral.png`
- `.studio-local/design-audit/palette-references/selected-dark-slate.png`

Fresh browser-rendered implementation:
- `test-results/contributions/summary-desktop.png`
- `test-results/contributions/summary-desktop-dark.png`
- Local review: `http://127.0.0.1:4542/contributions?project=studio&year=2024`

Both source images are 1435 × 1096 pixels. Captures are 1440 × 1100 pixels at
1440 × 1100 CSS viewport, device scale 1. No density scaling was necessary; the
5px/4px generation difference is acknowledged rather than scored as layout drift.
State: synthetic authenticated Activity, year 2024, all admitted sources, 80
commits, three active days, two repositories and a two-day streak. Both themes
were compared with their source in the same tool input, not from memory.

Focused header/field comparisons use original-resolution crops at x240/y25,
980 × 220 pixels, paired in the same tool input:
`.studio-local/design-audit/palette-references/{light,dark}-{reference,rendered}-controls.png`.
They expose label contrast, field borders, hierarchy and alignment. The full
captures also expose sidebar, chart, repository and contributor sections.

## Findings and iteration history

- **Resolved P2: dark search hints were too dim.** Initial rendered review found
  low-contrast browser-default placeholder text. Shared input/textarea placeholder
  color now uses `--ui-muted` at opacity 1. Fresh Activity captures and
  `test-results/design-consistency/family-{agents,monitoring}-dark.png` show readable
  hints. The consistency suite measures these against their backgrounds (4.5:1
  minimum). Post-fix full and focused comparisons found no remaining P0/P1/P2
  mismatch in the scoped palette adoption.

Intentional deviations, not findings:
- Keep actual StudioPlex typography and compact control sizes. Generated glyphs,
  larger text and altered icon shapes are not a new font/icon specification.
  The real headings, labels and hierarchy remain legible and consistently aligned.
- Keep the real 224px sidebar and existing content geometry rather than the
  approximately 238px generated sidebar. Section rhythm, above-fold content and
  task ordering remain the actual product's; palette alternatives were created
  to choose color direction, not to approve a navigation redesign.
- Control boundaries are stronger than the generated light reference so sampled
  field borders meet 3:1. Readable action orange is distinct from decorative brand
  orange; no artificial texture or gradient is added to flat application surfaces.
- The actual blue Activity scale and its calendar geometry are preserved. The
  generated light image's very pale inactive cells are not a new chart contract.

## Required fidelity surfaces

| Surface | Assessment |
| --- | --- |
| Fonts/typography | Actual product font and fallback retained; shared page-title hierarchy, readable body/labels, literal long strings and wrapping verified. Generated letter shapes are not copied. |
| Spacing/layout | Compact toolbars and readable content; section order and deliberate whitespace retained. No document overflow in tested 320/390/768/1440px layouts; chart/code internal scrolling remains intentional. |
| Colors/tokens | Neutral light, slate dark, raised controls, orange focus/selection and blue data scale align with the chosen directions. Operational routes retain shell colors across forward/reverse lazy navigation. |
| Assets/image quality | Existing INFUSE logo, shared icons and actual portrait/spatial assets retained. No generated image is shipped as UI or substituted for functioning controls. Portrait stages remain bounded exceptions. |
| Copy/content | Actual labels, synthetic historical values and literal long titles remain intact. No prompt or design-review language was added to the product. Long synthetic contributor names remain literal rather than rewritten. |

## Interaction and state evidence

Passed consistency checks cover sampled contrast, focus, Agents keyboard tabs,
Artifacts selected view, long mission titles, Code keyboard scrolling and responsive
layouts. Existing route suites cover populated/error/recovery states within their
own documented fixture scope. Appearance covers real/mockup themes, persistence,
System preference, canvas retention and narrow camera controls. Sidebar covers
rail, expanded and mobile navigation, search, project switching and sign-out.
Whiteboard behavior suite passes. Browser page-error arrays are empty in these
reported suites. The review tab was also opened and switched to Dark through its
actual local Account menu.

Cross-surface visual review included `family-agents-dark.png`,
`family-monitoring-dark.png` and `appearance/real-desk-mobile.png`: shared chrome is
coherent while portraits and the spatial scene keep their own artwork.

## Residual coverage and follow-up

- Full zoom, deep-reader/dialog and remaining route matrix is still open in the
  plan; this report does not certify every app state or WCAG conformance.
- Floor/Knowledge integration cannot be qualified without its separate companion
  fixture. Its attempted run stopped before repository selection.
- Whiteboard comment styling uses semantic roles, but dedicated comment-state
  visual coverage remains open beyond the passing general Whiteboard suite.
- Fito selected the palettes; the implemented experience has not yet been reviewed
  by Fito. No production behavior was changed or deployed.

Implementation checklist: selected pair recorded; owning styles updated; displaced
route palette rules removed; scoped contrast/reflow/interaction checks passed;
post-fix visual evidence inspected; remaining plan tasks named.

final result: passed

---

# Earlier design QA records (historical)

The current scoped result is above. Earlier records retain their original scope and outcomes.

# Floor directory and guided creation — design QA

Date: 2026-10-20. Local implementation; no release or user acceptance claimed.

## Visual truth and evidence

Selected management (option 1):
`/Users/mac/.codex/generated_images/01a15410-75af-75f2-a6b8-223a3474cd48/exec-ebc26e73-62e1-408c-b0fd-6d7d41707a2c.png`

Selected creation (option 3):
`/Users/mac/.codex/generated_images/01a15410-75af-75f2-a6b8-223a3474cd48/exec-44c246d1-572f-46e6-af39-a2bc1f2e6cfc.png`

Combined reference:
`/Users/mac/.codex/generated_images/01a15410-75af-75f2-a6b8-223a3474cd48/exec-98a2092a-8a9f-4e45-8796-01f5d291c9b7.png`

All reference boards are 1536×1024 editorial compositions, not browser viewports.
Compared the selected boards and actual screenshots together in the same image
inspection calls. No pixel-exact overlay claim: the source has multiple framed
screens, annotations and invented data. Compare the app content regions and
hierarchy, excluding the source's presentation framing.

Browser evidence (CUA; local sample catalog):
- `/tmp/studio-floor-directory-office.png`: 1707×960 pixels, 1707×960 CSS viewport.
- `/tmp/studio-floor-directory-light.png`: management with Core selected, light.
- `/tmp/studio-floor-directory-dark.png`: 1707×960 pixels, same CSS viewport, dark.
- `/tmp/studio-floor-create-dark.png`: repositories step, two selected; capture
  normalized by browser tooling to 1687×949 from the 1707×960 CSS viewport.
- Browser device scale was 1.5; delivered captures are approximately CSS-pixel
  normalized, not raw physical-pixel screenshots.
- `test-results/settings/create-repositories-light.png`: 1440×1000 CSS/pixels.
- `test-results/settings/create-repositories-mobile.png`: 390×844 CSS/pixels,
  selected search result and persistent footer, no horizontal overflow.
- `test-results/floor-lifecycle/retired-floor-narrow.png`: 390×844 viewport,
  retired floor and keyboard restoration.

Full-view comparisons assessed Office entry, compact directory, detail tabs,
repository rows, guided progress, selected sources and action footer. Text, icons
and controls are readable at the supplied image resolution; additional crops
were unnecessary for these UI regions. The original source screenshots and
actual full views were inspected together, as was the mobile creation screenshot.

## Findings and fidelity surfaces

No actionable P0/P1/P2 visual findings remain.

- **Typography:** existing StudioPlex is retained with the app's font loading and
  fallbacks. Semibold headings, 13–14px controls, muted 11–12px metadata preserve
  the mock's hierarchy. Mobile headings wrap naturally; source names wrap rather
  than hiding identity. Browser rendering differs from generated raster text.
- **Layout:** compact 250px floor list, flexible detail pane, aligned tabs and
  separated source rows follow option 1. Creation uses a bounded 1000px content
  area, progress row, summary, selectable sources and sticky footer. The wider
  real viewport has more horizontal space than the mock's framed crop. Mobile
  floor selection scrolls locally and fields stack; persistent actions remain
  visible. Actual global sidebar destinations from current main are preserved.
- **Color/tokens:** existing charcoal dark theme, orange selection/action tokens,
  and white light theme are used. Light primary buttons intentionally retain
  the established dark button token. Source status is both text and a colored
  dot; preview sources truthfully show Pending, rather than invented readiness.
- **Assets:** official INFUSE PNGs and bundled Tabler icons are reused. The kiosk
  is an actual selectable mesh in the existing shared Three.js Office scene;
  lighting/camera/materials remain native to the real product. The user requested
  a functional 3D entry, so a raster mock pasted into the scene would not satisfy
  it. The authored scene replaces the conceptual image's illustrative treatment.
- **Copy/content:** Floors, the three sections, guided steps and repository
  prompts follow the chosen direction. Counts and identities come from the
  actual local fixture. Metadata puts branch/documents below each repository
  name for narrow-screen continuity, rather than a separate table column.
  Empty, permission-denied and recovery copy extend states omitted by the mock.

## Comparison and repair history

1. Implemented selected combination and inspected Office, management and creation.
2. Fixed the Description accessible name, misleading unchanged-selection footer
   copy, and source selection cap after onboarding. Rebuilt and reran browser
   checks. No layout change was needed for these functional corrections.
3. Prevented changing the selected floor while its repository setup is open;
   verified return/cancel preserves the wizard. New creation tests confirm back
   navigation, search, member validation and receipt recovery without duplicate
   writes. Desktop/mobile screenshots retain the compared composition.

## Verification and limitations

Passed: workspace check; 836 tests; plugin and web builds; settings browser suite;
floor lifecycle browser suite; Office rendering/keyboard/camera/context-loss and
no-WebGL checks. Settings/lifecycle harnesses report no page errors. Mobile
creation and retirement have no document-level horizontal overflow. A connected
catalog fixture proves selection/persistence only, not real indexing.

The additional atmosphere suite reached its existing hard-coded
`Enter Studio · Floor 02` selector at line 100 after daylight/night/sunset,
storm/motion and mobile-layout assertions. Current fixture order places Studio
on Floor 01, so that selector timed out; the remaining tail of this extra suite
was not exercised. The separate Office suite passed exact Studio Floor 01
navigation and project-isolation checks. This redesign does not change storey
ordering. No unrelated atmosphere test edits were made.

The companion KB onboarding suite was adapted to the new UI but not executed:
its required disposable reader/management fixture is not configured here. The
existing plan 025 records that the local KB checkout lacks its former preview
helper. Repository setup's owning implementation and server protocol are unchanged.

## Implementation checklist

- [x] Office directory plus accessible entry; no dedicated sidebar management tab.
- [x] Compact list/detail management and selectable repository rows.
- [x] Guided creation with no early floor write and recoverable final save.
- [x] Light/dark/mobile and lifecycle evidence.
- [x] Preserve explicit authority, receipts and permissions.
- [ ] Live repository onboarding integration proof when its companion fixture is available.

final result: passed

---

# Earlier design QA records (historical)

# Project-floor selected blue treatment — 2026-10-19

Visual target: the second displayed gradient option, refined at Fito's request
to use a subtle blue portrait background. Source image
`exec-73e2fc27-303d-4cd2-9e96-616bd35ec59a.png` is retained locally as
`test-results/living-floor/selected-blue-card.png`. The selected concept changes
the header surface and portrait backdrop, preserving the existing action orbit.

## Evidence and comparison

Source (1487 × 1058) and both final browser captures were opened in the same
comparison input. `blue-card-light.png` and `blue-card-dark.png` under
`test-results/living-floor/` are 1688 × 1168 native in-app browser captures of
the quiet Emon card. The source is a magnified two-theme component board; its
office crop is not a requested camera change. The actual card remains 404 × 116
CSS px with its existing 112px portrait and 38px overlap. Component proportions
were compared independently of the presentation board's magnification. No
image-density conversion was used. The visible card text and borders are
readable in the full captures, so no extra raster crop was needed.

## Findings and fidelity surfaces

- Typography: Studio Plex, 20px semibold name and 14px role retain the selected
  hierarchy. Literal work text remains readable and long details scroll.
- Layout: the header now owns its gradient and divider. The work row has a flat
  surface; the gradient cannot extend behind it when content wraps. The circular
  rim still aligns with the desktop rectangle. Existing radial pills remain.
- Colors: light header uses #d3e1ed to #eef1f5; dark uses #2c4c63 to #1b2936.
  Portrait backgrounds are #cedeea and #809bad, with matching cool rims.
  Shared panel/text tokens remain in use for the work row and actions.
- Assets: canonical floor character stills, INFUSE assets and Tabler icons are
  reused. The mockup's extra hair geometry is not introduced. No raster mockup
  is shipped as interface content.
- Copy: name, role, project and quiet-state copy match the requested state.
  Actual assignment details remain literal; no illustrative work is invented.

Comparison history: initial inspection found the default dark secondary text
could reach only 4.21:1 against the lighter end of the header. The scoped role
color was raised to #c2cbd4, exceeding 4.5:1 across the gradient. The final dark
capture includes that correction. No remaining actionable P0/P1/P2 finding is
visible in either desktop theme.

## Implementation checklist

- [x] Selected slate-blue header with a separate flat work area.
- [x] Subtle blue portrait backgrounds in both themes.
- [x] Desktop height/overlap and existing actions preserved.
- [x] Dark role text contrast corrected and recaptured.

Mobile inspection: `04-mobile.png` (390 × 844) keeps the blue identity header
separate from wrapped assignment details. `01-selected-sunset.png` (1073 × 973)
shows the active three-action layout. Both were inspected after the final build;
no actionable layout finding remains.

Verification: `npm run check`, all 604 tests, plugin build, web build and all 14
floor browser groups passed. The browser run reported zero page errors and
confirmed the portrait image loaded, closing the preceding run's timeout gap.
Light/dark switching was also exercised in the actual local preview. This is
local synthetic-fixture and visual evidence, not a deployment or live-agent proof.

final result: passed

---

# Project-floor stronger identity gradient — 2026-10-19

Fito requested a stronger distinction. The sage blend is now 30% at the top
and 18% behind the role, increased from 16% and 8%. Role text uses the stronger
theme text color for readability. The work area remains warm paper.
`test-results/living-floor/local-strong-gradient-card.png` captures the local
result at 1688 × 1168. Dimensions and interaction remain unchanged.

---

# Project-floor identity gradient — 2026-10-19

Fito requested a different background for name/role and work status. The card
now fades from a soft sage tint across the upper identity area to warm paper
behind work status. Existing theme colors supply the gradient; dimensions,
portrait overlap and actions are unchanged.

`test-results/living-floor/local-gradient-card.png` (1688 × 1168) shows the
local result. Name, role and status remain legible, with a visible but quiet
background distinction. No actionable visual finding remains in this view.
The 390px fixture capture was also inspected. Repository checks, 604 tests,
plugin/web builds and all 14 local browser groups passed with no page errors.

---

# Project-floor portrait overlap — 2026-10-19

Fito requested a little more overlap beyond the left side of the rectangle.
The desktop portrait now sits 38px outside the card instead of 22px. The text
inset moves left by the same 16px to preserve its spacing from the portrait.
The matching top/bottom edges and compact layout remain intact.

`test-results/living-floor/local-overlap-card.png` (1688 × 1168) shows the
updated local result. Visual inspection found no clipping or text overlap.

Verification passed: repository check, all 604 tests, plugin/web builds and
all 14 local floor browser groups with no page errors.

---

# Project-floor card alignment — 2026-10-19

Fito confirmed that the rectangle's height should match the portrait diameter.
The desktop card now has a 116px height, matching the 112px portrait plus its
2px outer rim on each side. Reduced vertical padding and work-row spacing keep
the normal identity and quiet-state copy visible; unusually long work details
remain scrollable. The compact layout retains its wrapping content height.

Visual evidence: `test-results/living-floor/local-aligned-card.png`, 1688 × 1168.
The rectangle and circular rim align at both edges, with no text overlap or
change to the action orbit. No actionable visual finding remains in this view.

Verification passed: repository check, 604 tests, plugin and web builds, and
all 14 floor browser groups with no page errors. This is local verification.

---

# Project-floor portrait card — 2026-10-19

Follow-up reference: Fito's supplied 480 × 154 portrait-card crop
`codex-clipboard-2b6b5d1b-0796-4b61-9d2a-688a58d1d45a.png`.
The card adds to the previously selected action orbit; it does not replace its
contextual actions. The earlier comparison below records the prior iteration.

## Visual comparison

The reference and the actual local screenshot were opened together for comparison.
`test-results/living-floor/local-portrait-orbit.png` is the full 1688 × 1168
in-app browser capture. The reference is a detail crop, so room framing and
absolute screenshot dimensions are not treated as matching requirements.

- A 112px circular sage portrait overlaps the left edge of a 404px warm paper
  card, with a light rim, sage outline and restrained shadow.
- Name, role/project and document-led work text follow the reference hierarchy.
  The 20px name uses existing Studio Plex; close retains a 44px accessible target.
- Portraits reuse the canonical floor character meshes and appearance mapping.
  Emon therefore retains his existing brown hair and orange uniform instead of
  adopting the illustrative character's black stepped hair. No new identity
  artwork is introduced. Renderers are disposed after each cached still.
- The real quiet state is shown in the local screenshot; the reference's
  illustrative “Reviewing floor interactions” task is not fabricated in the app.
- Radial pills and their behavior remain intact. Narrow cards move the portrait
  inside their bounds, reduce it to 74px, and wrap literal text. The approved
  pixel portrait remains available when WebGL cannot render the still.

The active three-action capture (`01-selected-sunset.png`, 1073 × 973) and narrow
layout (`04-mobile.png`, 390 × 844) were also inspected. Text and actions remain
readable and within bounds. No actionable visual P0/P1/P2 finding remains.
The screenshot and fixture evidence are ignored local artifacts under
`test-results/living-floor/`.

## Verification

`npm run check`, all 604 tests, plugin build and web build passed. The focused
floor browser suite passed all 14 groups with no page errors. It additionally
checks that the rendered portrait image loads at its intended 256px source
resolution, alongside keyboard, camera, narrow-screen and no-WebGL behavior.
This verifies local UI behavior only, with no deployment or live agent execution.

final result: passed

---

# Project-floor agent orbit — 2026-10-19

Selected visual truth: option 2 from the October 19 design exploration, generated
image `exec-ad97da76-2390-41f1-b3e8-3c757f1b6233.png`. A local copy is retained at
`test-results/living-floor/selected-concept.png`. Screenshots below are ignored
local verification artifacts, not production data or shipped UI assets.

## Comparison and findings

The selected concept and implementation captures were opened together in the same
comparison input. No actionable P0/P1/P2 visual findings remain.

- **Typography:** existing Studio Plex is retained, with a 16px semibold name,
  12px role, 13px action labels and quieter secondary work text. Actual mission
  titles wrap instead of being replaced with the concept's short sample copy.
- **Spacing/layout:** identity bubble above the selected agent; primary action
  upper-left, conversation upper-right and profile lower-left. The 460px orbit
  contains 46px-high action pills and a 244px identity bubble. The room retains
  its size when opened. The character stays visible between the actions.
- **Colors/tokens:** Studio paper, dark ink, semantic sage and orange action tokens
  are reused. Elevation separates the controls without a modal backdrop.
- **Assets:** the original INFUSE logo, office geometry, furniture and characters
  remain unchanged. Tabler supplies the action, close and selection icons. No
  generated UI screenshot or invented portrait is shipped as application content.
- **Copy/content:** identity and project come from admitted records. Recorded
  assignments replace illustrative copy. Quiet agents show profile/mission board;
  bound assignments show mission/profile and only the exact protected conversation.
  No online state, mood, activity percentage or unbound chat is invented.

Intentional adaptations: the existing character's selection ring is retained;
the overhead marker uses a standard sage diamond icon, with no decorative
connector curves. The card grows for literal titles and recorded state. The
narrow-screen layout groups wrapping pills above the character, because a full
radial menu would clip. Missing/offscreen scene anchors use the same bounded
floating card. These are functional adaptations of the selected design.

## Evidence and viewport

- Source: 1392 × 1130 pixels.
- Same-size full-view comparison: `test-results/living-floor/00-quiet-team.png`,
  1392 × 1130 CSS px/pixels at device scale 1. Emon selected in the lounge, light
  theme. The fixture has eight people and no assignments; the source has two
  people and an illustrative assignment. Clock/lighting are fixture-controlled.
  No density resampling was needed; these content differences are intentional.
- Active three-action state: `test-results/living-floor/01-selected-sunset.png`,
  1073 × 973 CSS px/pixels at scale 1. An assigned Emon is correctly at his desk.
- Narrow layout: `test-results/living-floor/04-mobile.png`, 390 × 844 CSS px/pixels.
- Actual local app, in-app browser: `test-results/living-floor/local-orbit.png`,
  1688 × 1168 pixels. Two admitted people, quiet Emon selected in the lounge.

The name, task copy, icons and action spacing are readable in these native-size
views, so a separate raster crop was unnecessary. The active view provides the
focused three-action comparison; it is not a claim of identical mission data or
camera framing to the generated example.

## Comparison history

1. The initial local render inherited a smaller global icon size, making the
   selection marker too faint. Scoped SVG sizing was corrected without changing
   the shared icon system.
2. The new local capture and same-size fixture capture show the corrected marker
   and readable action icons. No further P0/P1/P2 visual correction is required.

## Verification scope

The floor harness exercises real local OIDC/HTTP/SQLite with synthetic mission
and thread receipts. It verifies unchanged floor bounds, camera tracking, exact
thread URLs, Escape/focus return, outside dismissal, profile/mission routing,
mobile layout, project isolation, state changes, roster overflow and no-WebGL
fallback. It captures page errors; no live agent run or external conversation
send is part of this proof. The in-app browser also displayed the finished
quiet-state interaction. Production rollout and human acceptance remain separate.

Final local checks: `npm run check`, 604 tests in `npm test`, `npm run build:plugin`,
web build and all 14 `test:floor:ui` groups passed. The browser run reported no
page errors. Loopback suites required local server access beyond the shell sandbox.

## Implementation checklist

- [x] Floating orbit replaces the layout-consuming bottom inspector.
- [x] Camera projection anchors the menu without a React render on each frame.
- [x] Contextual actions retain project and assignment identity.
- [x] Literal, stale and uncertain work remain inspectable.
- [x] Mobile/fallback and keyboard controls remain available.
- [x] Visual comparison completed with the selected concept.

final result: passed

---

# My desk: model fidelity refinement — 2026-10-18

Scope: Fito asked for a closer match to the original option 2 models, retaining
both clear screens and the running real-app preview.

## Evidence and matching state

- Source: `/Users/mac/.codex/generated_images/01a14442-acfc-7a60-a45d-9f3313acbf8f/exec-020d70ea-2f03-4e36-bd22-1c1415d2b7d1.png`.
- Before: `/private/tmp/studio-my-desk-maker.jpg`.
- Final: `/private/tmp/studio-my-desk-refined.jpg`.
- Full combined comparison: `/private/tmp/studio-my-desk-refined-comparison.jpg`.
- Original/before/after close-ups: `/private/tmp/studio-my-desk-refined-details.jpg`.
- Live Workbench: `/private/tmp/studio-my-desk-refined-connected.jpg`.
- CSS viewport and implementation capture: 1587 × 1168, 1×. Source: 1462 × 1076.
  Implementation resized proportionally to source dimensions for comparison.
- Same idle monitor, resting 100% seat, light theme and collapsed navigation.
  The tiny aspect difference comes from image generation, not layout drift.

Both full-view and focused comparison images were opened together with their
source content. These are actual 3D meshes, preserving the user's rotatable room.

## Findings and repair history

The preceding pass established the composition. This tighter model comparison
identified the following moderate fidelity gaps and corrected them:

1. Headphones: thin rectangular cups and a heavy smooth arc. Added a stepped
   headband, layered oval voxel cups, thick inner cushions and casing ribs.
2. Robot: exposed neck, thin limbs and flat head/body. Added a stockier beveled
   torso, layered head cap, recessed face, side earpieces, joints and broad boots;
   deepened the orange to match the reference under existing room lighting.
3. Pots/foliage: square pots and sparse oversized leaves. Added tapered octagonal
   hollow vessels with thick lips/feet, visible soil and denser branching foliage.
   The first refinement's flat polygon leaves still differed from the reference;
   the final pass uses small, darker, solid voxel leaves and longer uneven trails.
4. Composition/detail: widened the pegboard and shelf toward their outer edges,
   raised the notes clear of the lamp, and added cover edges, recessed book spines,
   shelf bevels/grain lines, a pen clip and sharpened pencil tips.

Final comparisons show no remaining P0/P1/P2 issue within this refinement scope.
Existing directional lighting has harder shadows than the generated illustration;
that is retained rather than claiming pixel identity. The pencil pot remains on
the actual desk corner instead of extending the furniture to match generated
perspective. These do not hide application content or impede interaction.

## Required fidelity surfaces

- Typography: real Studio fonts and both display textures remain unchanged.
- Spacing: accessory scale/silhouettes are closer; notes and screen faces are clear.
- Color: richer robot orange, darker foliage and cream faceted vessels retain the
  room palette; screen materials and semantic colors are unchanged.
- Assets: volumetric beveled/stepped geometry matches the voxel reference more
  closely. Static details merge into 56 material meshes, 6,824 triangles, and
  share the scene's existing disposal lifecycle. No new raster or brand assets.
- Copy: no invented metrics or new controls; unavailable token usage stays explicit.

## Verification

Required check, 598 tests, plugin/web/mockup builds and diff check passed.
Geometry inspection found finite vertices and zero blocked decoration sightlines
among 861 samples on each main screen. Manual local Workbench connection and Sleep
return to the 100% desk passed; the browser reported no warnings or errors.
Final browser checks passed: 14 real-app desk proof groups and 9 mockup cases,
with one expected desktop skip of the touch-only case.

Self-review: standard. Scope remains local to the existing worktree and preview;
no commit, push or production deployment. The earlier reviews remain below.

final result: passed

---

# My desk: maker's corner visual review

Date: 2026-10-18. Scope: the selected decoration concept in the existing real app.

## Evidence and comparison state

- Source visual truth: `/Users/mac/.codex/generated_images/01a14442-acfc-7a60-a45d-9f3313acbf8f/exec-020d70ea-2f03-4e36-bd22-1c1415d2b7d1.png` (second displayed concept).
- Implementation: `/private/tmp/studio-my-desk-maker.jpg`.
- Full-view comparison: `/private/tmp/studio-my-desk-maker-comparison.jpg`.
- Focused decoration comparison: `/private/tmp/studio-my-desk-maker-detail-comparison.jpg`.
- Connected state: `/private/tmp/studio-my-desk-maker-connected.jpg`.
- Route: `http://127.0.0.1:4326/desk?project=studio`.
- State: light theme, collapsed sidebar, idle monitor, resting camera at 100%.
- Browser viewport: 1587 × 1168 CSS pixels; screenshot 1587 × 1168 (1×).
  Generated source: 1462 × 1076. The implementation was proportionally
  normalized to the source dimensions for the combined comparison. The
  subpixel aspect difference from image generation is immaterial here.

The source is a decoration concept, not a replacement UI or screen asset.
Existing brand assets, font families, readable screen textures, camera controls,
real records and Workbench behavior are retained. The new objects are native 3D
meshes, consistent with the explicitly requested rotatable voxel environment.

## Findings

No actionable P0/P1/P2 differences remain. The pegboard, headphones, pinned
notes, books, orange robot, trailing plant and pencil pot are present. Both main
screen faces remain clear. The shelf and board have clearance around the desktop
monitor; the wall overview retains its full lower status lines.

The initial placement put the smaller note mostly behind the lamp and the pencil
pot over the token meter's right edge. The board and note were raised, and the
pot moved forward along the outer desk corner. The final combined captures above
show the improved separation. The retained lamp can still cover a small portion
of the lower note: a P3 composition refinement only, with no hidden app content.

## Required fidelity surfaces

- Fonts/typography: existing Studio typography and both screen textures remain
  unchanged; the concept's generated lettering is not substituted for app copy.
- Spacing/layout: the concept's left/right composition is retained, adapted to
  the existing furniture. Both display faces and persistent camera/dock controls
  are clear. Zoom and Sleep preserve their original framing behavior.
- Colors/tokens: sage, cream, timber, dark green and restrained orange match the
  room and the selected concept. Existing directional lighting and static shadows
  are retained, so shading is harder than the illustrative concept.
- Asset fidelity: actual perforated pegboard geometry, segmented headphones,
  volumetric books/robot/leaves and hollow pencil pot render with depth and cast
  shadows. Static geometry is batched into 30 material meshes and disposed with
  the scene. Existing INFUSE artwork is unchanged.
- Copy/content: no new claims, simulated metrics, controls or visible copy.
  The current unavailable token feed remains explicit.

## Interaction and verification

- Required check, 598 tests, plugin/web/mockup builds: passed.
- Real-app desk proof: all 14 groups passed, including VNC input projection,
  camera transitions, overlays, mobile layout, reduced motion and WebGL fallback.
- Mockup desk suite: 9 passed, 1 expected desktop skip of the touch-only case.
- Geometry inspection: 0 blocked decoration sightlines at 861 samples on each
  screen. The eye stays fixed when rotating/zooming, so these sightlines remain
  clear through supported camera actions.
- Manual retained local Workbench: connected inside the monitor; Sleep returned
  to the decorated 100% desk view. Browser warnings/errors: none.
- Screenshot comparisons reviewed together at full view and decoration detail.

## Implementation checklist

- [x] Build the selected concept in shared scene sources.
- [x] Preserve both screen faces and existing interactions.
- [x] Correct the initial note and pencil-pot placement.
- [x] Compare the final rendered state with the source.
- [x] Verify real and simulated desk consumers and leave the local preview open.

Self-review: standard; no outstanding blocking findings. Local implementation
only; no commit, push or production deployment in this follow-up.

final result: passed

---

# Header simplification — 2026-10-10

## Integrated Knowledge / icon rail — 2026-10-11

Implemented the approved removal of the nested Knowledge frame, compact title/view
bar, smaller home introduction and Studio navigation tokens. Article typography
remains independent. The 64px desktop rail has labelled controls, a project menu,
an expand/collapse toggle and a preference stored independently of mission data.

Browser evidence on localhost:4317:
- Expanded/collapsed navigation and preference retention through reload and
  navigation. Expanding from Company preserves the building view.
- Rail project menu opens without clipping and Escape closes it while preserving
  the active screen. All destinations retain accessible names.
- Home, Browse, reader, contextual tools and focus mode render successfully.
  Header/article/source action align at the same 760px reading measure.
- Bright and Dark reading keep shared navigation consistent.
- 400px CSS viewport: document width equals viewport width, and the labelled
  mobile drawer opens and closes on selection. Desktop viewport restored.
- Screenshots: `/tmp/studio-knowledge-rail-2026-10-11/` (home, browse, reader,
  context, focus and mobile). Zero observed browser warnings/errors.

Verification: `npm run check`, all 408 tests, plugin/web/mockup builds, and
`git diff --check` pass. Builds retain the existing bundle-size advisory. Full
CLI browser-suite rerun remains outstanding; browser evidence above is manual.
No mission/source semantics changed, and no saved draft content was edited.
Mockup only; not committed, pushed or deployed. Ready for owner design review.


## Knowledge Base mockup — 2026-10-11

Adapted from the current clean local KB checkout at `fe060075`. Source-derived
Library Home, repository browsing, reader and context controls; six authored
synthetic documents per project. Explore uses a small explicit demo link set
and an equivalent HTML list. Review confirmations affect only the exact local
fixture revision in the current browser session.

Verified on the authorized localhost:4317 preview: Home, keyword results,
repository/type filters together, empty results/reset, reader navigation,
review confirmation, contents/history, Explore, Bright/Dark and mobile calm
focus. Home and reader fit a measured 400px CSS viewport without horizontal
content overflow. Screenshots are private temporary evidence under
`/tmp/studio-knowledge-2026-10-11/`.

`npm run check`, all 408 tests, plugin/web/mockup builds and diff checks pass.
Four focused tests cover lookup composition, project/relationship isolation,
exact-version reviews and pinned/unavailable source rendering. Existing reducer
tests cover source selection and stale approval semantics. Browser navigation
expectations were updated for the new browse entry; the full automated browser
suite was not rerun. An isolated preview on port 4318 was blocked by browser
access policy and stopped; no request was made to change the saved draft on
4317. New-revision and source-selection mutations have reducer/render evidence,
not a fresh end-to-end browser proof this turn.

No real KB integration, production frontend change, commit, push or deployment.
Full KB migration parity and owner acceptance remain open.


Removed the desktop global breadcrumb/profile header and generic floor-return
buttons. Page headings start at the top of the right pane. Mobile keeps only the
menu toggle; mission stages, save status, paper download and contextual back
controls remain. Sidebar project/profile access is unchanged.

CUA checks: desktop My desk and mission review; 400×844 CSS mobile menu opens,
selecting Missions closes it and exposes the board. Viewport reset afterward.
Browser console: no errors/warnings observed. Screenshot:
`/tmp/studio-screenshots-2026-10-10/my-desk-no-global-header.jpg`.

`npm run check`, `npm test` (404 passed), plugin/web/mockup builds and
`git diff --check` passed. Existing bundle-size advisories remain. No new full
CLI browser-suite or owner-acceptance claim.

---

# Studio light workspace — visual QA

Date: 2026-10-10. **Result: manual visual checks passed for the surfaces below;
full automated browser rerun and owner acceptance pending.**

Source: four user-provided Louis Dai Nguyen workspace screenshots and the approved
Studio concept. Comparison uses app-content proportions, not the references'
external browser chrome. The implementation is a style adaptation retaining
Studio's existing information and mission states, not a pixel-identical clone.

## Rendered review

Desktop: persistent compact sidebar, white/cool-gray surfaces, thin borders,
restrained orange selection, compact Plex typography. Inspected My desk, Ideas,
People, Operations, Activity, Review, Library, project setup, mission review,
Knowledge and Lab. Duplicate work-navigation bars removed from work screens.
Whiteboard chrome shares the palette; authored notes and embedded previews keep
their colors. Knowledge Bright/Dark reading controls remain independent.

Narrow: requested browser overrides were normalized using measured DOM dimensions;
400×844 CSS pixels was the final narrow check (the browser zoom scales overrides).
My desk, Lab, People and Operations fit; People uses an intentional horizontal
roster. Sidebar opens and closes on selection. Mission review was also inspected
at 520×1125 CSS pixels. Temporary viewport override was reset.

## Fixes from rendered inspection

- Replaced remaining oversized warm page headers with the shared header.
- Unified cards, empty states, tabs, forms and action groups across features.
- Corrected Knowledge dark-theme hovered controls and input contrast.
- Restored the optional Office's original dark navigation palette after tokenization.
- Grouped Review/Library card actions and added readable title/body spacing.

Implementation captures are local in `/tmp/studio-screenshots-2026-10-10/`:
`my-desk-shared.jpg`, `people-shared.jpg`, `operations-shared.jpg`,
`lab-shared.jpg`, and `review-shared.jpg`. They are rendered app evidence,
not generated concepts. Screenshots are not committed.

## Verification limits

404 tests and required builds pass. This pass exercised visual navigation and
reading preferences; it does not claim a new end-to-end mission closeout proof.
The updated CLI browser suite remains unrun. No production/backend deployment
or real frontend theme adoption. R0 still needs Fito's walkthrough.

## Comparison history

The earlier office reviews below are historical evidence only. They do not
establish acceptance of the approved sidebar refresh.

---

# Studio — object-detail refinement

Historical review, 2026-09-29: the scoped object-detail pass below passed.
Current design authority is [DESIGN.md](DESIGN.md); delivery status is in the
[roadmap](docs/ROADMAP.md). The entries below preserve dated observations and
superseded comparisons, not current layout instructions.

Date: 2026-09-29. Scope: the owner's requested comparison and detail pass on
office objects. This result covers the repaired object findings below; it does
not claim pixel identity with the concept or replace Fito's acceptance.

## Current evidence and comparison state

Source: `/var/folders/ql/689_hnhx61z9scknc4bjpsg40000gn/T/codex-clipboard-9c4719a3-3bc7-4da8-ba68-718446b2315c.png`,
1487×1058. Implementation: http://127.0.0.1:4317/#workspace, Studio, shaping,
authored camera. The real configured roster and saved mission replace the
reference's anonymous occupants and decorative board content. Two populated
sections and three required unresolved decisions remain; nothing was launched.

Evidence directory:
`/Users/mac/.codex/visualizations/2026/09/23/01a0cfb5-af08-7f90-9846-62d33bb4278a/`.

- `studio-objects-before.png`: native desktop baseline, 1707×960, DPR 1.5.
- `studio-objects-v1.png`: first object pass, before the final orientation,
  reading-lamp and entrance-indicator corrections.
- `studio-objects-final.png`: final native desktop capture at the same viewport.
- `studio-objects-match.png`: reference-size implementation, CSS 1487×1059,
  reported DPR .75. IAB backing padding was removed from the 1981×1411 raw
  capture by cropping its top-left 991×706 and normalizing density. This softer
  emulated image is for composition; native captures establish fine detail.
- `studio-objects-full-comparison.png`: source and final render together.
- `studio-objects-comparison.png`: original / before / after crops of direction,
  library, entrance and lounge. Crops preserve aspect ratio, but do not claim
  identical object dimensions. Both combined comparisons were opened after
  the final fixes. No scene pixels were painted or recomposed.

## Object findings and repairs

1. **P2, repaired — furniture read as solid generic blocks.** The founder desk
   lacked the reference's cabinet-like body, front fields and asymmetric desktop.
   It now has darker timber, three recessed front panels, trim, a shifted monitor,
   books and a pen cup. Armchairs have separate cushions, narrower arms, raised
   feet and inward-facing seats. Work chairs gain a mechanism and paired wheels.
   Final direction crops show the stronger silhouette without changing the zone.
2. **P2, repaired — shelving was repetitive and the low case was malformed.**
   The low lounge case reused four hardcoded library shelf heights, producing
   books above its top, and faced away from the aisle. Shelf count and spacing
   now follow case height; the low case has two rows and faces the aisle. Varied
   book widths, spines, page blocks and horizontal stacks fill the tall library.
   Final lounge crops verify the height and orientation correction.
3. **P2, repaired — lamps and accessories lacked recognizable construction.**
   Cream lamps now have open tapered shades, rims, stems and bulbs. V1 still
   gave the reading desk a cream lamp, unlike the source; final replaces it with
   a black angled task lamp. Mugs have rims, coffee and handles; books have covers
   and page edges; screens have bezels, tilt, stands and rear vents. The reading
   desk has a pedestal and an open book. Final library crops verify the lamp fix.
4. **P2, repaired — entrance lacked architectural depth.** The elevator now has
   recessed doors, deep jambs, a threshold, separate piers/lintel, roof tiles and
   a triangular indicator. The first comparison exposed a bleached indicator;
   final uses an unlit orange surface and a readable architectural sign. Final
   entrance crops show the door recess, tiled apron and legible orange triangle.
5. **P2, repaired — secondary equipment and planting were too uniform.** Added
   a recognizable scanner/copier with output tray, server handles/rails and
   restrained indicator lights. Operations has glazed infill above its low
   partition. Plant pots taper with a separate rim; trough foliage uses fewer,
   larger clusters. The full comparison verifies these remain subordinate to
   the work zones. Glass retains the operations picking identity.

No remaining blocking finding in this scoped object pass. Smaller differences
in exact prop shapes, indirect illumination and character faces/clothing remain
acceptable for this iteration and visible in the comparisons. Lighting and
character refinement are separate future passes, not completed work here.

## Required fidelity surfaces

- **Fonts/typography:** local Plex, cream heading and orange period retained.
  The architectural Studio sign remains crisp instead of washing out under light.
- **Spacing/layout:** the fixed floor, camera, circulation and eight work zones
  remain. Object-level depth, shelf heights and seating angles are refined.
- **Colors/tokens:** sage seating, warm wood, cream architecture and orange accents
  retained. Founder timber is darker; the source's richer indirect light remains.
- **Image quality:** locally bundled oak/linen/print assets are reused. This pass
  uses real selectable 3D geometry; no new raster asset or external service.
  Native comparisons show page edges, supports, rims and architectural recesses.
- **Copy/content:** roster, mission wording and truthful empty artifact view
  retained. Screen marks are decorative demo content, not execution evidence.

## Current verification

- `npm run check`, `npm run build`, `git diff --check`: passed after final edits.
- `npm test`: all 24 existing state/lifecycle tests passed during this pass.
  Subsequent edits were confined to lamp/indicator/sign appearance.
- Build retains the Three.js chunk advisory: approximately 663 kB minified /
  173 kB gzip. This is a successful build, not a performance benchmark.
- CUA: direct 3D clicks on operations glass and library reach their existing
  activity/artifact surfaces. Library reports the correct empty proposal state.
  Keyboard whiteboard access retains owner wording and required decisions;
  closing restores the floor and focus to its whiteboard label.
- Final browser console: zero errors or warnings. Temporary viewport override
  reset; only the temporary QA tab closed. Owner preview/content preserved.
- Standalone end-to-end tests, narrow viewport, WebGL failure and reduced-motion
  emulation were not rerun in this geometry-only pass. Prior evidence remains
  below. No full network trace or runtime performance benchmark was recorded.

## Implementation checklist

- [x] Compare source and live objects, including focused crops.
- [x] Refine founder furniture, library, accessories and entrance.
- [x] Repair low shelf height/orientation and task-lamp mismatch.
- [x] Recapture after fixes and inspect combined comparisons.
- [x] Verify build, existing lifecycle tests and native object navigation.
- [x] Preserve owner mission state and document remaining artistic differences.

---

# Previous pass — office material, lighting and pose refinement

final result: passed

Date: 2026-09-29. Scope: the improvements explicitly requested after the visual
critique. This replaces the previous report's overly optimistic classification
of material, lighting and pose differences as minor. The selected image remains
the direction; this result verifies the implemented refinement, not pixel
identity with the illustration or Fito's final acceptance of the experience.

## Source, state and evidence

Source visual truth:
`/var/folders/ql/689_hnhx61z9scknc4bjpsg40000gn/T/codex-clipboard-a90e60e6-2d9c-4e65-a167-06ebf47f8191.png`.
Durable copy: `studio-paseo-reference.png` in the evidence directory below.
Source dimensions: 1487×1058.

Implementation: http://127.0.0.1:4317/#workspace, Studio floor, shaping phase,
authored camera framing. Owner content was retained. Two populated sections and
three required unresolved decisions remain; no launch or acceptance was invented.
The reference's anonymous occupants are replaced by the actual configured roster
and mission presence, so character count/placement does not match it literally.

Evidence directory:
`/Users/mac/.codex/visualizations/2026/09/23/01a0cfb5-af08-7f90-9846-62d33bb4278a/`.

- Before: `studio-polish-before.png`, native 1707×960.
- Final: `studio-polish-final.png`, native 1707×960 CSS viewport, DPR 1.5.
- Matched viewport: `studio-polish-match-final.png`, CSS 1487×1059, reported DPR .75.
- Full source/render comparison: `studio-polish-comparison-final.png`.
- Focused source/render comparisons: `studio-polish-details-final.png` (founder,
  entrance, lounge), plus `studio-polish-details-v3.png` (library/shaping).
- Intermediate comparisons: `studio-polish-comparison-v2.png` and `-v3.png`.
- Compact: `studio-polish-mobile-final.png`, CSS 391×844. Native mission content
  scrolls vertically; team and floor navigation have their own horizontal strips.

IAB's emulated screenshot has backing padding: the matched capture is 1981×1411
with content in its top-left 991×706. That region was cropped and density-normalized
to 1487×1059; the compact equivalent was normalized from 261×563 to 391×844.
No scene pixels were painted or recomposed. These captures lose fine detail,
so focused final material comparison uses the native desktop capture. Region
crops are scaled for inspection, not used to claim identical object dimensions.
Source and render were opened together in each combined comparison. All temporary
viewport overrides were reset.

## Findings, fixes and comparison history

1. **P1, repaired — flat material treatment.** Before, floor, wood, cloth and
   elevator largely shared the same matte color treatment. Added locally generated
   oak and linen tiles with restrained bump relief, metre-based furniture UVs,
   satin metal and ceramic/brass surfaces. Desktops, cabinet fronts and the founder
   desk now have grain; rugs and cushions have fabric texture. V2 established the
   difference; V3/final show visible floor joints and material separation. Fixed
   the clipped first plank on alternate rows while checking coverage.
2. **P2, repaired — uniform yellow/olive illumination.** Lowered ambient and cool
   fill, separated the warm key from local fixtures, tightened the floor shadow
   bounds and contact occlusion, and added localized board/library/operations
   light. V2 was still too uniform; V3 increased useful local falloff. Final lowered
   the board/library hotspots. The elevator has an environment reflection and a
   warm practical light. The source's complex indirect bounce remains richer.
3. **P2, repaired — rigid furniture and repeated props.** Added small cushion and
   timber bevels, sloped back cushions, seams, varied chair upholstery, a desk pad
   and pen tray, alternating book stacks and deterministic asymmetric foliage.
   Planters now contain foliage rather than identical miniature pots. V3 showed
   a founder print extending above its support; final raised the display wall and
   mounted the print within it. Focused final crops verify these repairs.
4. **P2, repaired — disconnected poses.** Seated arms now articulate at shoulder
   and elbow with hands at desk height; heads have an independent gaze. Emon faces
   into the room while gesturing toward the board. Quiet agents hold a pose; only
   the active named owner has small working movement. Reduced-motion branches
   remove that movement and immediately settle position. Identity and assignment
   logic were preserved.
5. **P2, repaired — camera recovery was obscure.** Replaced the lone reset glyph
   with visible “Ver planta completa”; company view uses “Ver compañía completa”.
   Keyboard activation restores the authored framing. Tested zoom → fit, board
   → floor focus restoration and company → Studio navigation. Camera changes do
   not modify mission content. Renderer and compositor now also follow density
   changes during resize rather than retaining the previous screen's density.
6. **P2, repaired — compact guide overlapped the title.** The first compact capture
   showed the pre-existing status/guide area crossing the heading. Moved both into
   one unwrapped row alongside the back link. Final DOM measurement: status bottom
   242.7, heading top 255.3, no overlap. Document width stays within the viewport.

No remaining blocking finding in this requested refinement. Native focus outlines
remain visible; camera controls and all eight work surfaces retain HTML access.

## Required fidelity surfaces

- **Fonts/typography:** local IBM Plex, its heading weight, cream text, orange
  period and source wording remain intact. Native controls use readable Plex;
  the new camera action has a text label. Density normalization explains the
  softer emulated lettering; native screenshot is the sharpness evidence.
- **Spacing/layout:** fixed 22×14 layout, elevated orthographic camera, desktop
  rail/header and dominant room composition remain. Display-wall height now
  supports the founder art. Camera reset removes saved pan/zoom from comparison.
  Compact status/heading overlap is repaired.
- **Colors/tokens:** INFUSE branding preserved. Timber, sage cloth, terracotta
  review area and cream architecture remain recognizable. Neutral fill and warm
  fixtures distinguish highlights and shadowed faces. The illustration still has
  more elaborate, artist-directed bounce lighting; exact optical identity is not
  claimed.
- **Image/material quality:** four new 512px WebP material maps are bundled, not
  remote. Their exact ImageGen prompts and processing are recorded in
  `src/assets/provenance.json`. Matching color/relief maps are attached only after
  loading. Furniture remains real, pickable 3D as explicitly required by the user;
  no flat office image replaces it. Fine texture repeat is not noticeable in the
  normal overview. Source props remain somewhat more individually sculpted.
- **Copy/content:** user-approved roster, saved wording, mission state and truthful
  empty artifact state survive. Board paper marks reflect populated content.
  Decorative studies do not claim that a proposal has already been produced.

## Verification

- `npm run check`: passed, including the new material module.
- `npm test`: all 24 state/lifecycle tests passed.
- `npm run build`: passed; existing lazy Three.js chunk size advisory remains
  (about 625 kB minified / 160 kB gzip).
- `git diff --check`: passed.
- CUA browser checks: visible camera fit after zoom; whiteboard opens and closes
  to the same label/focus; owner wording remains; founder label and direct click
  on the 3D desk open the owner surface; review shows the correct empty proposal;
  elevator opens company and Studio reopens; compact primary action opens the
  selected mission section and returns focus to the same action.
- Final browser console: zero errors and warnings. Assets are local and build
  successfully; no new remote service was introduced. A full network trace was
  not recorded in this iteration.
- Browser inspection used CUA. Standalone Playwright, WebGL-failure injection and
  OS reduced-motion emulation were not rerun. Reduced-motion behavior was reviewed
  in code; existing automated scenarios are retained. No acceptance claim is based
  on unexecuted browser tests.

## Follow-up artistic refinement

The authored scene is still simpler than the selected illustration: indirect
lighting, individual prop silhouettes and small character facial/clothing details
can be refined further. These are remaining artistic differences, not claims that
the reference has been reproduced exactly. Fito's judgment of the room's feeling
remains the product acceptance gate.

## Implementation checklist

- [x] Differentiate wood, cloth, metal and lamps.
- [x] Refine founder/arrival, then extend to shared office furniture.
- [x] Ground poses and gestures in mission state.
- [x] Expose camera fit with a clear label.
- [x] Compare reference/render together, including focused regions, and iterate.
- [x] Verify native interactions, compact access, checks and build.
- [x] Preserve existing session and capture final evidence.

## Mission creation flow — 2026-09-29

Implemented after Fito's instruction to create the flow and screens. The office
geometry and materials are unchanged in this slice. New native screens cover
floor mission list → idea → contextual board → plan/squad → complete paper →
approval/hold → named simulated events. The previous mission and its evidence
remain independent and accessible.

Verified: independent state and configuration, literal input/export, explicit
confirmations and deferrals, dependent-decision invalidation, approval snapshots,
no working presence before assignment, reload, keyboard, compact layout, fallback
without WebGL, and preservation of the previous walkthrough. See
[mission verification](docs/plans/archive/002-mission-creation/review.md) for commands,
proof images and limits. Owner experience acceptance remains pending.

## Mission state board — 2026-09-30

Owner-selected direction: replace the first mission-list screen with state
columns ordered by priority, with examples for the joint review. Retained the
existing mission paper palette and typography. Added five states, eight labelled
Studio fixtures, per-card priorities, decision/priority filters, team, next step,
expandable example context and the separate saved-missions view.

Verified in the in-app browser: default view, priority filter (3/8), decision
filter (3/8), changing priority reorders its column, example context expansion,
empty saved collection, wide and compact layouts, Enter on a state jump focuses
the corresponding visible heading, and no document horizontal overflow. The
requested test viewport overrides rendered at 1920 and 520 CSS pixels; the
normal 991px panel was restored for handoff. All five columns fit the wide
view; narrower views scroll horizontally. No console errors were returned.

Screenshots outside the repo: mission-board-desktop.png,
mission-board-compact.png and mission-board-final.png in the current task's
visualizations directory. Syntax, 32 state tests and production build pass.
The existing Three.js bundle-size warning remains. No deployment or real agent
execution. Browser testing used presentation fixtures, without adding or
changing the owner's saved mission records. State tests cover saved priorities,
legacy migration, floor isolation and lifecycle-derived columns. Fito's visual
acceptance is pending as part of the screen-by-screen review.

Self-review: standard. Kept board priorities outside approval snapshots; fixed
preparation cards so only approval and explicit hold count as owner decisions.
Examples cannot become saved execution evidence. Ready for local design review.

## Optional mission name — 2026-09-30

The owner accepted the idea entry: free wording and optional name, followed by
an editable Emon suggestion. Added an explicit optional hint, a local simulated
title suggestion when leaving the idea unnamed, and a title editor in the board.
Authored names are preserved, including when loading the Studio idea example.
The raw thought is unchanged; title edits update the header without rerendering
the focused input. The approval snapshot remains authoritative.

Syntax, 33 state tests and build pass. Tests cover name omission, suggestion,
revision, reload, exact original wording, authored-name preservation and export.
Browser review confirmed the optional hint and existing name preserved when
returning to shaping. The original browser tab stopped responding to control;
a fresh in-app tab recovered the existing saved draft without altering its text.
No live LLM call; arbitrary-text suggestions are first-sentence abbreviations.

## Prefilled shaping canvas and centered chat — 2026-09-30

Replaced the section-question inspector with six editable paper cards and a
centered bottom chat. Reviewed the previous screen and new render in the same
in-app browser. Reduced heading size after finding a cascade conflict with
shared mission styles. The original idea remains literal; blank sections gain
unconfirmed local proposals once. Existing edits, deliberate blank fields and
approved snapshots are preserved.

Browser verification: seeded content, inline edit focus, section-to-chat anchor,
authored feedback preview with before/after, application to scope and exclusions,
and persistence of content/conversation across reload. Responsive views at 992
and 520 CSS pixels retain board scrolling and the composer; the viewport override
was reset. State tests additionally cover exact free-text feedback and export,
stale-change blocking, re-proposal against newer edits, discard, explicit authored
branches, approval guards and saved-state migration. The mission E2E selectors
were updated for inline controls; the CLI browser suite was not run in this pass.

Syntax, all 36 state tests and production build pass. The pre-existing Three.js
chunk-size warning remains. Emon is simulated: free text is stored as a literal
note; only the three labelled example adjustments generate authored refinements.
No backend, permissions or provider calls were added. Self-review: standard;
ready for the owner's continued screen-by-screen UX review.

## Plan-first mission screen — 2026-09-30

Owner direction: show Emon's ordered plan first, a compact recommended team,
expandable configuration and the centered feedback chat. Implemented editable
work/output/verification/owner fields, add/remove/reorder, team changes and
preview/apply/discard adjustments. Existing work and approved legacy records
are preserved. No backend or real agent execution was added.

Browser review through CUA: edited a step without losing focus; opened Tinus's
configuration, changed model and verified the disclosure stayed open; restored
the original preset and step wording. Compared and applied the authored design
review adjustment and verified four steps after reload. Compared and discarded
the smaller-team adjustment without modifying the plan. Narrow review at an
actual 520×840 CSS viewport had no horizontal overflow; titles wrap and the
composer remains usable. Also inspected the 1280×800 laptop layout. Temporary
viewport overrides were reset. Final console error list was empty.

Visual corrections from review: reduced card/composer height, wrapped step
titles on narrow screens, ordered the team by first contribution, and contained
focus-driven scroll inside the plan/chat panes. Opening a comparison now keeps
the header at top=0 and outer scrollTop=0.

Evidence (outside the repository):
- `/Users/mac/.codex/visualizations/2026/09/23/01a0cfb5-af08-7f90-9846-62d33bb4278a/plan-equipo-final.png`
- `/Users/mac/.codex/visualizations/2026/09/23/01a0cfb5-af08-7f90-9846-62d33bb4278a/plan-equipo-compact.png`

Verification: syntax check, all 40 state tests, build and diff whitespace check
pass. Tests cover authored plan preservation, order/owner propagation to approval
and simulation, removed-owner readiness, incomplete steps, conflict protection,
literal feedback, notes/export, persistence and legacy approval evidence.
Browser spec selectors were updated for disclosures; the CLI browser suite was
not rerun. Build retains the pre-existing large Three.js chunk warning.

Self-review: standard. Fixed historical plan/notes rendering so old snapshots
cannot display current planning changes. No external side effects. Remaining
product limitation: authored examples and literal notes simulate Emon; the
review step does not collect a real human execution receipt. Ready for owner
review of this screen; no commit, deployment or acceptance claim.

## Mission review refinement — 2026-09-30

Implemented the approved decision brief after the read-only Backoffice contract
check recorded in `docs/plans/archive/002-mission-creation/context.md`. Outcome,
scope/non-goals and acceptance lead; the ordered plan, owners, configuration,
context and complete paper remain inspectable. Corrections, inline confirmation,
optional deferral and the shared Emon dock work without returning to shaping.

CUA browser checks: edited outcome and observed matching paper content/revision
without focus loss; restored the exact original wording. Confirming keeps the
review stage and moves keyboard focus to the reviewed card. Editing again clears
the relevant confirmations. Commenting on acceptance selects its chat anchor.
Compared an authored feedback adjustment and discarded it, preserving the
encargo; opened the full paper and verified plan/presets. Header stayed at top=0
while comparison expanded. The existing draft remains unapproved.

Reviewed 1280×800 CSS laptop and 520×840 narrow view. Approval actions remain
available beside the brief on laptop; the mobile decision shortcut moves to the
approval section without horizontal overflow. Temporary viewport overrides were
reset. Final screenshots are in the task visualization directory:
- `revisar-mision-final.png`
- `revisar-mision-compact.png`

Verification: syntax checks, all 42 state tests, production build and whitespace
check pass. Added state coverage for review-local correction/confirmation,
feedback blockers, exact revision snapshot and reload/export. Browser specs were
updated for disclosures and the review heading; the CLI browser suite was not
rerun. The existing Three.js chunk-size build warning remains.

Self-review: standard. No backend, SQL writes, real execution, dependencies or
new saved-data format. The model still uses authored examples and literal free
text feedback. Owner acceptance of the new review layout remains pending.

## Company exterior — October 1

Replaced repeated office cutaways with a separate lightweight glass façade in
`src/building.js`. Each project adds a storey and its own clickable lightbox;
Studio uses the existing INFUSE asset, while project wordmarks are provisional.
A continuous elevator shaft and single cab remain subdued behind the glazing.
The office geometry and mission model are unchanged. Arrow buttons expose each
billboard's destination to keyboard and assistive technology; the existing floor
rail remains available independently of WebGL.

Verified in the local browser: clicking the Growth billboard enters Growth;
Enter on the Client project arrow opens the correct office; returning restores
the exterior framing. No warnings or errors were captured during these checks.
Syntax checks, 42 state tests and production build pass. The existing Three.js
chunk-size warning remains. This is a visual mockup, with no project logo upload
or live elevator simulation. Owner visual acceptance remains pending.

### Exterior identity pass — rooftop and street

Added a timber roof garden with an orange pergola, lounge benches, planted edges,
railings and elevator overrun. A bounded street diorama adds raised tiled paving,
curbs, a zebra crossing aligned to the entrance, trees, benches and street lamps.
Decorative geometry has no floor identity and does not act as a navigation target.
The company camera and desktop canvas reserve space for the whole street base
above the existing controls. The floor camera is unchanged.

Verified the default desktop composition and Studio entry/return in the browser;
no browser warnings/errors were captured. Syntax, production build and whitespace
checks pass; the existing bundle-size warning remains. No mission/state changes,
new assets, dependencies or ambient animations were introduced. Screenshot:
`company-rooftop-street.png` in the task visualization directory.

## Free HTML whiteboard prototype — October 1

Implemented native HTML document/note cards, an authored HTML preview, SVG links,
card movement and resizing (pointer and keyboard), pointer-anchored wheel zoom,
pan, fit, outline jumps, anchored comments, local persistence and JSON export.
Entry is the office's whiteboard or “Pizarra libre”; mission navigation remains
separate. Open `/?whiteboard=studio#workspace` for the direct example.

Verified two real local browser tabs: presence, independent zoom, note creation,
literal text propagation, keyboard movement, comments received on the same card,
and same-field conflict notice with the editing field still focused. Reload
replayed the new card/content/comments. Removed the verification-only card via
its UI. Default desktop visual review and return navigation were exercised.
No remote collaborators or simulated agent cursors are claimed.

47 state tests pass (five new tests cover concurrent delivery order, independent
fields, tie-breaking, replay, deletion/recovery, exact comments/anchors, invalid
records, room keys, zoom anchoring and offscreen visibility). Syntax, production
build and whitespace checks pass; the pre-existing Three.js size warning remains.
Browser CLI suite was not run. No server, dependency or external request added.
Owner UX acceptance, remote collaboration and character-level co-editing remain
future work. Self-review: standard. Local prototype ready for owner review.

## Whiteboard tabs and tools — October 2

Added persistent named tabs, per-tab camera restoration, an authored diagram tab,
and a grouped SVG tool palette. Functional tools: selection, hand, notes, text,
rectangles/ellipses/diamonds, documents, attached connectors and anchored comments.
Context options include fill color, shape type, duplication and removal. Tools
support keyboard placement/shortcuts; the tablist supports arrow/Home/End keys.

Browser verification: created and renamed “Próximas ideas”, placed a blue note and
ellipse, edited their text, moved the shape with keyboard, connected the two,
and saw the tab/content/connector in a second browser tab. Exploration remained
independent. Switching restored the Flow camera at 77% and the new tab at 100%;
reload retained tab data. No browser warnings/errors were captured. Same-browser
collaboration remains the prototype boundary; remote rooms are not implemented.

50 tests pass. Three added cases cover legacy tab assignment, tab replay/isolation,
connector movement/deletion/cross-tab exclusion and concurrent style/text edits.
Syntax, production build and whitespace checks pass; existing Three.js size
warning unchanged. Self-review: standard; ready for owner UX review.

## English copy pass — 2026-10-02

- Translated company/floor navigation, mission board and creation stages,
  companion branches, review/activity, Markdown labels, whiteboard tabs/tools,
  comments, example cards and accessibility text.
- Preserved user wording and immutable approval snapshots. Regression checks
  cover Spanish saved branches and completed simulation events, exact custom
  text, English screens and exports, and continued rejection of false evidence.
- Browser reviewed the company, furnished floor, idea, shaping, plan/team,
  review, approval-on-hold and whiteboard. Fixed one untranslated activity label
  found during this review. Custom whiteboard tab names remain unchanged.
- Verification: 53 state/model tests, syntax check, production build and diff
  whitespace check. Existing large Three.js bundle warning remains.

## Workspace restructure — 2026-10-02

The mockup now lives in `apps/mockup`; shared geometry is in `packages/spatial`
and brand/fonts/base UI in `packages/ui`. The office and whiteboard were inspected
after relocation, including restoration of saved tabs. This is architecture
verification, not a new product-design acceptance. See
[the verification record](docs/evidence/2026-10-02-workspace-restructure.md) for
commands, results and outstanding browser-suite maintenance.

## Floor workspaces — 2026-10-02

Verified labelled project identity and workspace shortcuts on the floor,
Mission board opening the status columns, Library and Activity routes,
People navigation, and Library → whiteboard → floor with restored focus.
Studio and Growth show their own saved paper revisions. Narrow-screen floor
and library layouts were inspected with no document-width overflow observed.
The browser's effective narrow width was 520 CSS px; this is not a 390px
acceptance claim. No browser console errors observed in the tested flow.

`npm run check` and the mockup build passed. Three new tests cover
floor-scoped record projections, navigation preserving draft/camera state and
exact delivery wording/mission anchors. The full older browser suite remains
outside this pass; its previously documented selector maintenance is pending.
Owner review of the new navigation is pending. Populated delivery/activity
projections are unit-tested; the live browser session showed draft/empty states.

## Operations scheduled checks — 2026-10-02

Added a floor-scoped scheduled-check list, attention summary, detail/run-history
panel and create/edit controls. Browser verification covered pause/resume,
reload persistence, cadence edits with updated next run, and simulated passed
and failed results updating attention and preserving history. Pausing keeps
failures visible and disables simulated execution. Returned to the floor and
reopened Operations successfully. The stacked layout was visually inspected
at an effective 693 CSS px; no document-width overflow was observed. No console
errors were reported in this tab.

All 63 automated tests, `npm run check` and the mockup production build pass.
Four Operations tests cover local per-floor configuration, literal wording,
saved-state recovery, reset, failure policies and run history. Shared icon
injection also fixes the mission rendering test's unsupported raw-SVG import.
The existing large Three.js bundle warning remains. Full legacy browser-suite
and owner design acceptance remain pending. This is a simulated scheduling
interface, not verification of real monitoring or cron execution.

## Routine Library — selected option 1, 2026-10-02

Source visual truth:
`/Users/mac/.codex/generated_images/01a0cfb5-af08-7f90-9846-62d33bb4278a/exec-03b48ae5-eba3-4393-a6e9-c597d77b342b.png`

Implementation screenshot:
`/Users/mac/.codex/visualizations/2026/09/23/01a0cfb5-af08-7f90-9846-62d33bb4278a/routine-library-desktop.png`

**Comparison evidence and history**
- Source: 1487 × 1058 pixels. Browser: 1488 × 1059 CSS px, devicePixelRatio
  0.75. The browser screenshot API padded its initial full capture; a viewport
  clip of 1116 × 794 produces the 1488 × 1059 content-only comparison image.
  Both images were opened together in the same tool response for comparison.
- Same interaction state: Studio, all categories, backup expanded, run history
  closed. Saved manual simulation results are retained, so exact result wording
  and recorded run counts differ intentionally from the generated concept.
- Initial P2: vertical rhythm put the legend below the reference viewport.
  Reduced header bottom padding, row padding and expanded-detail/footer gaps.
  The post-fix paired comparison shows all four routines and the legend visible.
- Initial P2: sidebar and primary action drift. Matched 246px sidebar, retained
  the selected category tint on focus/hover and set the primary CTA text white.
  Post-fix screenshot confirms the changes.
- Full-size paired images are legible for the catalog, labels, status strips and
  expanded content; a separate focused crop was unnecessary.

**Required fidelity surfaces**
- Typography: existing bundled Plex/mono fonts retained; clear title/section/row
  hierarchy, readable content and no truncated routine names. Small differences
  from generated glyph shapes are P3, not missing fonts.
- Spacing/layout: matches header, shared nav, category rail, grouped rows and
  inline detail arrangement. Four examples and legend fit the comparison frame.
- Colors: warm ivory, muted sage, forest type/navigation and orange CTA; semantic
  failed/passed results remain distinct and labelled.
- Assets: existing Tabler icons; no raster illustrations are present in the
  target. Status squares are data indicators, not substituted decorative assets.
- Copy: preserves saved user content. Corrects concept inconsistencies: paused
  routines have no next run, history never invents successes, and the failure
  policy remains the actual saved policy. Adds explicit pause/resume action and
  replaces decorative ellipses with discoverable inline actions.

**Verification**
- Browser: category filtering, keyboard expand/collapse, inline history,
  pause/resume with disabled simulation while paused, edit/save category with
  updated grouping/counts, new form typing/cancel and return-to-floor/reopen.
- Responsive: inspected at effective 520 × 844 CSS px; document width 500px,
  no horizontal overflow. This is not a claim of 390px verification.
- All 64 automated tests pass, including category persistence independent from
  owner, old saved-check compatibility and grouped rendering/paused state.
- No browser console errors in the tested tab. Existing bundle-size warning
  remains; no real scheduling, notifications or external checks are connected.

**Follow-up polish**
- P3: minor font/icon-shape differences from the generated reference. Owner
  acceptance of the design remains pending.
- Full legacy browser suite was not run; the targeted browser flow above and
  automated model/rendering checks cover this iteration.

**Implementation checklist**
- [x] Category navigation and grouped catalog.
- [x] Inline details, recorded history, editing and pause/resume.
- [x] Literal wording and local saved-state compatibility.
- [x] Desktop visual comparison, compact review and targeted interactions.

final result: passed

## Delivery review iteration — 2026-10-02

Scope: connect completed mission simulations to the floor Review wall, structured
artifact review, correction, revision comparison, explicit acceptance and Library.
Uses the existing native mission UI and INFUSE tokens; no new image reference.

- Browser walkthrough: create a separate Studio example, approve the brief,
  advance named events, open its delivery, record anchored feedback, produce r2,
  compare against r1, verify correction and criteria, and accept r2.
- Source update visibly marks the projection stale and blocks acceptance.
  Refresh creates r3, retaining the exact feedback and earlier acceptance record
  while requiring fresh verification. Reload and Library reopening preserve r3.
- Earlier r1 is read-only; feedback and acceptance controls appear only for the
  latest revision. The user's pre-existing mission drafts were preserved.
- Desktop visual inspection: readable paper sections and companion feedback
  panel, short section comment buttons, clear source and revision controls.
- Compact check: effective 520 × 844 CSS px, document width 500px, no horizontal
  overflow. Sections and feedback stack. This does not claim 390px verification.
- Automated: 69 tests pass, including literal anchors, immutable revisions,
  acceptance gates, source drift, edited-feedback invalidation, export newlines
  and malformed nested-record recovery without losing approved mission data.
- Static/type checks, service build and mockup production build pass. Existing
  Three.js chunk-size warning remains. No browser console errors observed.
- Evidence: delivery-review.png in the task visualization directory.
- Full legacy browser suite was not rerun. User acceptance of this new screen is
  pending; the refreshed example remains awaiting judgment.

final result: passed

## Founder’s desk iteration — 2026-10-02

Implemented the agreed priority inbox using the existing native mission/Operations
visual language. Scope includes failed-check-to-mission provenance, editable Emon
proposal, local delegation/deferral and delivery review/Library connections.

- Desktop browser: inspected priority ordering, source evidence, recommendation,
  action hierarchy and the existing mission and delivery cards.
- Exercised exact delegation notes, deferred filter and reopening, generated a
  linked investigation, inspected Emon/Satwa plan, confirmed required brief
  sections, advanced nine named events and returned to review through the desk.
- Requested a recovery-specific correction, verified r2 and accepted its demo
  result. Desk still shows the failed check and asks for fresh evidence.
- Reload retained the linked mission and result. Existing user drafts preserved.
- Automated checks cover duplicate prevention, floor isolation, literal source
  and note preservation, new evidence resurfacing, unique run IDs after history
  truncation, approval/correction gates, fresh-check closure, independent recovery,
  escaping and camera preservation.
- Local simulation only: no real agent delegation, scheduling or recovery.
- A fresh simulated pass moved the accepted investigation to History. A subsequent
  failed run appeared as a new decision, preserving the previous investigation.
- Compact inspection at effective 520 × 844 CSS px: stacked list/detail layout,
  wrapped navigation and no document overflow (500px document width). Viewport
  override reset afterward; no claim of a 390px-wide test.
- Verification: full 73-test suite passed; focused founder/delivery tests passed
  again after final behavior and copy polish. Type/static checks and mockup build
  pass; existing Three.js chunk-size warning remains. No console errors observed.
- Screenshot: founders-desk.png in the task visualization directory. User design
  acceptance remains pending. No commit, push or deployment performed this turn.

final result: passed

## Library memory and People profiles — 2026-10-02

Both requested surfaces now use the existing cream/forest native workspace UI.

- Library: source creation/editing, explicit owner review and review-due states,
  accepted-result learning with immutable evidence, accepted work and selective
  reuse of context, plan and team. Existing papers/handoffs remain accessible.
- People: shared working styles, assignments, full capability prerequisites and
  boundaries, guest creation/editing, research notes, model/reasoning presets,
  linked Library context and mission creation through the context chooser.
- Browser: saved a source, marked it reviewed, captured a learning from accepted
  backup work, created Mira as a labelled guest example, linked both entries,
  chose one source for a guest mission, and reused accepted plan/team with only
  the selected learning in a separate draft. Reload preserves all saved records.
- Fixed a browser-discovered transition error: Library submission previously
  attempted a quiet update against the old screen after creating the new draft.
  It now renders the destination normally; a second reuse completed successfully.
- Fixed profile selection focus/scroll so the selected person's heading appears
  at the start of the profile, with keyboard focus retained.
- Compact checks: effective 520 × 844 CSS px for Library and People, document
  width 500px, no horizontal document overflow. Viewport reset afterward.
- Automated: all 76 mockup tests pass, including six new knowledge/expert tests.
  Mockup production build passes. Full repository check/test attempt hit an
  unrelated backend TS2550 error at Promise.withResolvers in OpenClaw gateway;
  backend work was preserved. Existing Three.js size warning remains.
- Screenshots: library-reuse.png and guest-expert.png in the task visualization
  directory. Owner acceptance remains pending; no publishing or commit requested.

The separate backend type error cleared during this iteration. A final `npm run
check` now passes; no backend source changes were made as part of this work.
Final clean browser tab has no console errors.

final result: passed

Final repository run: all 93 tests pass, including the 76 mockup tests. The
repository check and final mockup build both pass after the separate backend
blocker cleared. No live provider or research execution was exercised.

## Mockup merge verification — 2026-10-03

Isolated the floor workspaces, Operations, delivery review, founder's desk,
Library memory and guest profiles onto `codex/mockup-company-workflows`, based
on current `origin/main`. Separate coordinator continuation commits are excluded.

- `npm test`: all 96 tests pass on this main-based branch.
- `npm run check`: syntax, dependency boundaries and TypeScript checks pass.
- `npm run build --workspace @studio/mockup`: passes; existing Three.js
  chunk-size warning remains.
- `git diff --check`: passes. Earlier browser evidence above applies; no new
  browser or live-provider verification is claimed by this merge check.


## Sidebar consolidation — 2026-10-12

Implemented in the simulated mockup: Ideas stays primary; Knowledge owns saved
sources and learning; Missions owns Outputs and Activity; Lab owns Whiteboard;
Office contains Building and Project floor. More groups Operations and mission
history, Help holds the Office guide, and account appearance controls share the
existing sidebar preference. Project switching retains the section with a safe
collection fallback for mission details. Removed the unused second Library UI.

Verification on the current local candidate:
- All 411 tests pass; `npm run check`, plugin, web and mockup builds pass.
  Existing large-bundle warnings remain. `git diff --check` passes.
- Browser: Studio/Client project Knowledge isolation, saved sources and learning,
  draft/output labels, pending human review count, logo destination, More Escape
  dismissal, account appearance retaining Knowledge, and both Office scales.
- Whiteboard closes to Lab with unsent feedback intact. Mobile drawer opens,
  selects and closes at 400×844 CSS pixels with no horizontal document overflow.
- Final browser warning/error log is empty. Viewport override was reset.
- Screenshots: `/tmp/studio-sidebar-2026-10-12/01-ideas-sidebar.jpg`,
  `02-knowledge-rail.jpg`, `03-review.jpg`, `04-office-floor.jpg`, and
  `05-office-building.jpg` in the same directory.

The adapted CLI browser suite was not rerun. No real agent dispatch, source-owner
publication, production frontend adoption or deployment is claimed. Owner
acceptance remains open. Existing local records and unrelated edits are preserved.


## Company and project navigation scope — 2026-10-12

Company Office now opens the whole Building. The separately labelled Project
group owns the project picker and all currently project-scoped work screens,
including My desk, Ideas, Review and People. Project floor is in More and the
Office view switch; its active state belongs to project tools. Rail labels and
project-name tooltips preserve the distinction when collapsed.

Browser verified: Company Office destination, Project floor active state, Ideas
remaining open across Studio/Client selection, updated group names/tooltips,
expanded and collapsed layouts, and mobile drawer selection/closure at 400×844
CSS pixels with no horizontal overflow. Final warning/error log empty. Temporary
viewport reset. Screenshots: `/tmp/studio-sidebar-scope-2026-10-12/expanded.jpg`
and `/tmp/studio-sidebar-scope-2026-10-12/rail.jpg`.

Required check, 411 tests, plugin/web/mockup builds and diff check pass. Existing
bundle-size warnings remain; full CLI browser suite not rerun. Self-review found
no remaining scoped implementation issues. Local mockup ready for owner review;
no company-wide aggregation, production adoption or deployment is claimed.


## Global My desk and shared People — 2026-10-12

Supersedes the previous project placement of My desk and People. Company now
contains My desk, People and Office. Project floor, Operations and Mission
history are direct project destinations; More is removed.

My desk aggregates the existing project read models with owner filtering and
project provenance. Opening an item or recording a decision selects its exact
origin before the existing project reducer runs. People reads the shared roster
and open work across projects, labels drafts as proposed teams, retains a selected
profile across project changes, and explicitly scopes configuration/source/new
mission actions. No global write authority or canonical source change added.

Verification:
- Four meaningful regressions: two-project owner-filtered aggregation without
  mutation; originating-project decisions preserve other records; shared work
  distinguishes proposed teams and excludes completed work; a guest outside the
  current project remains visible with literal text escaped and no invalid start.
- All 415 tests pass, plus required check, plugin/web/mockup builds and diff check.
  Existing bundle-size warnings remain. Full CLI browser suite not rerun.
- Browser: Client selected while Studio decisions appear in My desk; open a
  decision into Studio; People work link opens Growth; Mira remains selected
  across Growth/Client project context with unavailable project starts disabled.
- Expanded and rail navigation expose all destinations. Mobile at 400×844 CSS
  pixels opens direct Mission history and closes the drawer without horizontal
  overflow. Temporary viewport reset; final warning/error log empty.
- Screenshots: `/tmp/studio-global-2026-10-12/my-desk.jpg`, `people.jpg`, and
  `rail.jpg` in the same directory. Global desk left open on port 4317.

Self-review: standard; no remaining scoped implementation findings. Ready to
merge for this local mockup change; owner design acceptance remains open.
No deployment, live execution, new access or production frontend adoption.


## Navigation consolidation — 2026-10-13

Supersedes the preceding standalone Mission history navigation entry.
Project navigation starts with Project floor, then Whiteboard, Ideas, Missions,
Review, Knowledge, Lab and Operations. The picker lists Core, Finaxis, Hauscraft;
company navigation remains My desk, People, Office.

Removed older fallback screen renderers and duplicate rail/palette destinations.
Missions → History uses the same project mission records, showing closed/cancelled
work and preserving earlier archived evidence downloads. Existing IDs and stored
mission wording remain unchanged.

Verification: `npm run check`, `npm test` (416 passing), plugin build, web build,
mockup build and `git diff --check` passed. CUA browser checks exercised project
switching with History retained, the Finaxis Whiteboard and focus return, the
Hauscraft floor, all three building labels and the simplified command palette.
At 400 CSS pixels, project navigation and History remained accessible with no
horizontal document overflow. No browser errors were reported. The full CLI
browser suite was not rerun; its changed navigation labels were updated.
Screenshots: `/tmp/studio-clean-navigation-2026-10-13/history-projects.jpg` and
`/tmp/studio-clean-navigation-2026-10-13/building.jpg` (local temporary evidence).
This is local mockup verification, not production deployment or user acceptance.

## English project-floor copy — 2026-10-13

Replaced the remaining building entry label “Planta” with “Floor”. The floor
projects the identified older Studio design demo title and saved status message
in English; it does not rewrite persisted mission text or approved snapshots.
Custom mission titles retain their literal content. The shared presence model
uses the same English display text for station and person tooltips.

Verification: check, 417 tests, plugin/web/mockup builds and diff checks passed;
the final title adjustment also passed the focused mission suite and mockup build.
Browser inspection confirmed English Core floor copy and all three English
building entry labels. Screenshot: `/tmp/studio-project-floor-english.jpg`.
The stopped local Vite preview was restarted on port 4317. No deployment.

## Project-floor navigation cleanup — 2026-10-13

Removed the duplicate workspace navigation block, floor view-switch tabs,
heading guide link, hidden Company return and repeated Missions shortcut from
the office. The floor heading moves up to use the cleared space. Sidebar and
command navigation retain access; room hotspots, camera controls and contextual
mission actions remain.

Verification: check, all 417 tests, plugin/web/mockup builds and diff checks
passed. Browser inspection confirmed the office is unobstructed on desktop,
and the sidebar remains available from the mobile menu. No browser errors.
Screenshot: `/tmp/studio-office-clean-navigation.jpg`. Local mockup only.


## Company Office clarity — 2026-10-13

Removed the company-building footer, preferred Core entry banner, introductory
headline and Building/Project floor tabs. Office now has a compact title and
“Choose a project floor.” Camera controls float at the bottom; movement guidance
is in Help → Office guide. All three lightboxes use their project names. Floor
hover and named HTML entrance focus share a level outline; narrow screens keep
“Enter [project]” captions visible. The camera framing retains the street base.
The shared building renderer owns signs and outlines; mockup source owns its
shell, camera integration and responsive controls. No mission records change.

Verification: `npm run check`, all 417 tests, plugin/web/mockup builds and
`git diff --check` passed. The usual large-bundle warning remains. CUA browser
checks covered Core, Finaxis and Hauscraft entry, keyboard focus and Enter,
Fit, Help instructions, and mobile navigation at 400×844 CSS pixels with no
horizontal document overflow. Desktop size was restored. No browser errors.
Full CLI browser suite was not rerun; its renamed Office heading was updated.
Screenshots: `/tmp/studio-office-simplified.jpg` (desktop focus) and
`/tmp/studio-office-simplified-mobile.jpg` (mobile), inspected as local evidence.
Local mockup implementation only; not deployed or newly committed.

## My screen personal workspace — 2026-10-13

Added My screen to Company navigation and the command palette. The preview owns
per-partner, in-memory desktop state independently of project and mission data.
It demonstrates connect/cancel, disconnect/reconnect, interrupted connection,
Codex/Claude Code/Terminal selection, repository folders and desktop focus mode.
Reset demo clears sessions; reloading starts fresh. Vision, roadmap and decisions
record the selected entry and distinguish it from deferred live desktop delivery.

Verification: `npm run check`, all 420 tests, plugin/web/mockup builds and
`git diff --check` passed. Focused tests cover partner isolation, project-switch
continuity, cancellation/reset races and escaped owner names. Browser checks
covered connection recovery, tool/folder retention, project switching, keyboard
focus, focus mode and a 400×844 CSS-pixel layout without horizontal overflow.
No browser errors were reported. The full CLI browser suite was not rerun.
Screenshot: `/tmp/studio-my-screen-desktop.jpg`, inspected as local evidence.
This is a simulated mockup: no VNC session, machine provisioning, provider
sign-in or command execution. Local changes remain uncommitted and undeployed.

## Office-first Company navigation — 2026-10-13

Office now leads Company navigation, followed by My desk, My screen and People.
The INFUSE logo uses the existing Project floor action and names the selected
project in its accessible label and tooltip. The design contract matches.

Verification: check, all 420 tests, plugin/web/mockup builds and diff checks
passed. Browser checks confirmed Office is first, the logo opens Core from
Missions, and after switching to Finaxis it returns from Office to Finaxis.
No browser errors. Screenshot: `/tmp/studio-office-first-navigation.jpg`.
Local mockup changes only; uncommitted and undeployed.

## Implemented workspace parity — 2026-10-13

Added project Artifacts with standalone examples, published mission outputs,
search/filter, exact revision/page selection, sandboxed preview, provenance and
HTML download. Mission inspection now has Paper, Tasks & owners, Conversations,
Evidence & review and Activity. Instruction/finding history, task dependencies,
owner-bound comment reconciliation, explicit hold/resume/cancel confirmation,
stale-paper review and session/access/delivery recovery use shared inspection
blocks and the existing light style. Existing mission reducers remain authoritative.

Verification: `npm run check`, all 425 tests, plugin/web/mockup builds and
`git diff --check` passed. Five focused tests cover literal comments, deduplicated
owner-bound reconciliation, interrupted transport, instruction/finding history,
project artifact isolation and persisted recovery modes. Browser walkthroughs
covered uncertain comments and reload/reconciliation, stale confirmation,
hold/resume, interrupted delivery, expired-session re-entry, artifact filtering,
revision/page selection and HTML download. The downloaded file SHA-256 matched
the viewer digest. Task and artifact layouts passed at 400×844 CSS pixels with
no horizontal document overflow; the search input remains 348 pixels wide.
Desktop viewport was restored. No browser errors were reported. Existing bundle
size warnings remain. The full CLI browser suite was not rerun; affected mission
inspection selectors were updated, while older suite navigation still needs
separate reconciliation.

Screenshots: `/tmp/studio-artifacts-library.jpg`,
`/tmp/studio-artifact-viewer.jpg`, `/tmp/studio-mission-tasks.jpg`,
`/tmp/studio-mission-conversations.jpg`, `/tmp/studio-session-recovery.jpg`.
These are local simulated flows, not connected authentication, Mattermost,
Registry or VNC. Changes are uncommitted and undeployed.


## Mission navigation and authoring space — 2026-10-13

Consolidated Missions into All missions / Closed / Activity. Removed the duplicate
Outputs renderer and routed evidence actions to the mission’s Evidence & review.
Per-delta adoption, exact revisions, sandbox previews and publication provenance
remain inspectable. Artifacts remains the published-work collection.

Shape, Plan and Review share a compact collapsible Emon conversation drawer.
Context & references is also collapsible; headings and stage spacing are reduced
within the existing style. Comments open and focus their anchored composer;
Escape closes only the drawer and returns focus to its summary. Literal drafts
survive collapse, stage changes and reload. Pending proposals open for review.

Verification: check, all 426 tests and plugin/web/mockup builds passed. A new
routing regression covers retired routes without changing exact mission records
or project scope. Browser checks at 1440×900 and 400×844 CSS pixels covered Shape,
Plan, Review, keyboard opening/closing, anchored focus, literal draft retention,
plan proposal/discard, disabled approval with outstanding confirmations, Closed,
Activity and Review-to-Evidence navigation. Mobile Shape and Plan had no document
horizontal overflow. No runtime errors were reported. Existing build size warnings
remain. Full CLI browser suite was not rerun; affected context and Outputs selectors
were updated, while previously recorded suite drift remains outside this slice.

Screenshots: `/tmp/studio-missions-navigation.jpg`,
`/tmp/studio-paper-more-space.jpg`, `/tmp/studio-plan-more-space.jpg`,
`/tmp/studio-review-more-space.jpg`. Local simulated mockup only; no runtime or
production change. Changes remain uncommitted.


## Grilling — 2026-10-13

Combined Ideas and New mission into the project Grilling entry. New-mission
buttons open Grilling without creating records. Save for later keeps a thought;
Start grilling creates a draft directly in Define the mission. Existing drafts,
including older and MCP drafts, remain resumable. Draft stages select Grilling in
the sidebar and return there; approved work selects Missions. Project switching
from draft definition opens the other project's Grilling collection.

Verification: all 428 tests, check and plugin/web/mockup builds passed. Added
coverage for literal intent, save versus start, repeated continuation, project
isolation, blank input and offline restrictions. Browser walkthrough verified the
Missions entry, save-for-later, saved-thought continuation, return to the draft
collection and 400-pixel responsive layout without horizontal document overflow.
No browser errors. Screenshot: `/tmp/studio-grilling.jpg`. Full CLI browser suite
was not run; older creation selectors need migration to this unified entry.
The assisted flow is simulated, with execution still gated by paper approval.
Local changes are uncommitted and undeployed.


## Knowledge live-reference refinement — 2026-10-13

Compared the signed-in live KB Home, reader, Context and History with Studio's
mockup and the owning `knowledge-base` React components. The real product remains
owned by that repository; this pass changes only Studio's simulated reference.
No live review, source write or private document copy was performed.

Resolved gaps:
1. Search was only discoverable inside Browse. A persistent entry and Cmd/Ctrl+K
   now open the scoped keyword search and focus its input.
2. Document controls crowded the heading. Context, Inspect, Settings and Focus
   now use one labelled tool rail. Context includes owner/type/status, contents,
   relationship counts and fixture history counts.
3. Review desk rows had no connected queue. All pending fixtures are reachable,
   shared standards come first, and Previous/Next retain a fixed order and exact
   revision even after a review. Finish review opens an explicit confirmation;
   review state remains distinct from selecting mission context.

Validation: `npm run check`, all 429 tests, plugin/web/mockup builds and
`git diff --check` pass. Existing bundle-size advisories remain. One added test
covers review priority, exact-version filtering and stable queue positions.
Browser checks on localhost:4317 covered search (including Cmd+K), review
confirmation, 1-of-4 to 2-of-4 navigation, returning to a reviewed item, desk
count reduction, contextual metadata, Focus and Escape. A narrow responsive
check measured 533 CSS pixels at the existing browser zoom, with no horizontal
overflow and accessible tool controls above the reader; the viewport override
was then reset. No browser errors or warnings were observed. This is focused
manual browser evidence; the complete CLI browser suite was not rerun.

Screenshots (temporary, visually inspected): `/tmp/studio-knowledge-home.jpg`,
`/tmp/studio-knowledge-context.jpg`, `/tmp/studio-knowledge-reader.jpg`.
Review/queue state resets on reload as designed. Production KB integration,
full Git history/diff parity and semantic search remain outside this pass.
No commit, push or deployment was performed.

## Direct Prototype view — 2026-10-13

Renamed the visible Lab destination to Prototype across sidebar, palette,
mission reference links and current product guidance. Kept internal `lab`
route/storage keys compatible. Prototype opens the selected exact candidate,
or the current project's first candidate when no reference is selected.
Removed the introductory hero, duplicate Whiteboard tab and permanent review
column. The preview now fills the surface below a compact selector; Details &
feedback reveals source/build metadata, explicit deltas, adoption and feedback.
No selection or execution happens merely by opening the preview.

Verification: check, all 432 tests, plugin/web/mockup builds and diff check pass.
Three focused tests cover pinned defaults, explicit latest browsing, project
isolation, closed disclosure markup and unavailable-preview adoption. Existing
browser workflow selectors now use Prototype and open optional controls when
needed; the full CLI browser suite was not rerun. CUA checked direct entry,
opening/closing details and running both local preview steps. At a measured
400 CSS-pixel viewport the document width remained 400px with no horizontal
overflow; viewport restored. No browser errors/warnings observed. Temporary
screenshots: `/tmp/studio-prototype-direct.jpg`,
`/tmp/studio-prototype-details.jpg`, `/tmp/studio-prototype-mobile.jpg`.
Mockup only; no production integration, commit, push or deployment.

## Agents and Skills directory — 2026-10-13

Renamed the global People destination to Agents, retaining the compatible
`people` route. Added profile covers, individual first-person introductions,
roles, signatures and linked skill chips. The roster contains agents and guest
experts; the human owner remains reachable through My desk. Existing project
configuration and shared assignments remain accessible below each profile.
Skills sits directly beneath Agents in Company navigation. Its 14 entries derive
from the existing authored capability catalogs, with search, agent/discipline
filters, expected outputs and expandable requirements and boundaries. Profile
and glossary links work in both directions. No live inventory or access grant is
implied; this remains a simulated reference.

Verification: `npm run check`, all 436 tests, plugin/web/mockup builds pass.
Four focused tests cover complete catalog ownership, composed filters, global
navigation/project isolation and escaped guest content. Manual browser checks
covered profile-to-skill and skill-to-profile links, combined filters, empty
results/reset and disclosures. Agents and Skills both fit a measured 400px CSS
viewport without document overflow; viewport restored. No browser warnings or
errors observed. The full CLI browser suite was not rerun. Existing bundle-size
advisories remain. Screenshots: `/tmp/studio-agents.jpg`,
`/tmp/studio-skills.jpg`, `/tmp/studio-agents-mobile.jpg` and
`/tmp/studio-skills-mobile.jpg` (temporary, visually inspected).
No commit, push or deployment performed.

## INFUSE dark appearance — 2026-10-13

Added Light/Dark/System to Account → Appearance. The saved preference is separate
from mission/company data, survives reload, and works for the current session
when storage is blocked. Existing light paints remain CSS fallbacks. Dark uses
Foundry Black, carbon surfaces, paper text and orange actions from the brand
repository's approved direction and candidate v1 ramps. Orange buttons have black
text. Knowledge's default now follows Studio, retaining an explicit reader override.
Authored media and embedded previews retain their colors.

Browser checks covered Agents, Skills, Missions, draft plan/team, approved paper,
task inspection, Grilling, Knowledge Home, Review, Artifacts and Operations.
Fixed inherited light controls, named-white inspection panels and low-contrast
labels found during inspection. Verified light/dark switching, System selection,
dark persistence after reload, and a 400px Skills viewport without horizontal
overflow. Viewport reset. Tests cover live system changes, explicit preference
precedence, invalid storage, blocked storage and preference/mission separation.

Validation: check, all 438 tests, plugin/web/mockup builds and diff check pass.
The complete CLI browser suite was not rerun; existing bundle-size advisories
remain. Screenshots: `/tmp/studio-dark-agents.jpg` and
`/tmp/studio-dark-skills.jpg` (temporary). Mockup only; no commit or deployment.

## Authenticated mockup hosting — 2026-10-13

Committed the accumulated mockup work in `94832d3` and pushed it to
`codex/mvp-mockup-reference`. The hosting change builds a separate prefixed bundle
and serves `/prototype-mockup/` through existing Studio authentication. Static
assets require current membership; sign-in accepts only the fixed mockup return
path. The real application's static root, mission writer and dispatch remain
independent of mockup simulation state.

Validation: check, all 440 tests, plugin/web builds, the prefixed mockup build and
diff check pass. Focused integration tests cover anonymous GET/HEAD rejection,
current membership, missing-file isolation, fixed sign-in return and callback
replay rejection. A disposable synthetic-OIDC browser preview on port 4324
completed login and loaded the office and Prototype screen, including the logo
from the prefixed asset URL, with no browser warnings or errors. The fixture was
stopped after verification. Existing bundle-size advisories remain; the complete
CLI browser suite and production image deployment were not run. Publication
requires this branch's reviewed merge to `main` and successful pipeline rollout.

## Whiteboard floating-canvas QA — 2026-10-14

Date: 2026-10-14. Scope: the existing React Flow W2 board, following Fito's
request to keep Studio's sidebar and make the canvas fill the remaining screen.

## Visual truth and evidence

- Source: `/var/folders/ql/689_hnhx61z9scknc4bjpsg40000gn/T/codex-clipboard-64f21b44-cb05-4e4a-a984-82df335b4b1a.png`.
  Supplied image is 974×491 pixels, showing an empty light canvas with floating
  top controls, bottom tool dock and zoom controls. The attachment remains local.
- Implementation: `http://localhost:61573/whiteboard?project=studio`, the
  disposable local preview. Reviewed in the Codex in-app browser with seeded
  blocks, outline/editor open and closed, and the narrow-phone layout.
- Saved implementation evidence: `test-results/whiteboard/reference-size.png`,
  `canvas.png`, `desktop.png`, `dark.png`, `mobile.png` and `evidence.json`.
  These ignored files contain synthetic fixture content only.
- Normalized comparison: browser viewport 1198×491 CSS pixels, device scale
  factor 1. The retained 224-pixel Studio sidebar is excluded from the main-area
  screenshot, giving an unscaled 974×491-pixel canvas. Source and implementation
  were opened together in the same comparison input, at equal pixel dimensions.
- Other states: 1480×1100 desktop; 390×844 mobile editor; layout checks at
  320×720, 600×720 and 974×720. In-app browser additionally inspected at
  1198×491 and 320×720; its surrounding preview surface is not used for pixel
  measurements. Temporary in-app viewport overrides were reset after inspection.

## Findings and comparison history

1. Fito's feedback established the initial mismatch: a padded page, large heading
   and permanent inspector reduced the usable canvas. Replaced with a workspace
   that the canvas fills, compact floating title/status, bottom tool dock and
   contextual panels. Browser assertions prove the canvas and main workspace
   bounds are identical, including when opening and closing the editor.
2. **Resolved P2 — 320-pixel tool collision.** Initial narrow-screen run showed
   zoom overlapping the tool dock (`test-results/whiteboard/failure.png`).
   Reduced narrow dock spacing and control widths, retained zoom and fit, then
   reran the same 320×720 bounds check. It passes; the in-app 320×720 capture
   visibly confirms separate reachable controls. The 390×844 final screenshot
   also shows the editor floating above an unobstructed dock and zoom group.
3. Refined the dot spacing from 16 to 10 pixels after the first comparison.
   The final 974×491 screenshot was reopened alongside the source; the full-view
   layout has no remaining actionable P0/P1/P2 mismatch within the agreed scope.
4. Interaction review caught an editor that could close during an outstanding
   save while leaving its cached draft dirty. Acknowledgement now settles that
   cache. A delayed-request browser check verifies reopening shows saved text
   and a disabled Save button. Status also distinguishes unsaved drafts from
   saved changes, even when the editor is closed.

## Required fidelity surfaces

| Surface | Review |
| --- | --- |
| Typography | Retains the product's IBM Plex/StudioPlex font, with a compact 14-pixel board title and 11–13-pixel controls. Labels remain legible; mobile form fields use 16 pixels. Intentional product font, not a claim of exact Figma typography. |
| Spacing and layout | Canvas touches every workspace edge. Controls sit 12–16 pixels from the edges, with white floating surfaces, subtle shadows and rounded corners. The tool dock is centered on desktop and moves left only when needed to avoid the zoom group. No permanent editor column. |
| Colors and tokens | Uses existing light/dark Studio tokens and INFUSE orange for the active tool. The source's purple and Figma branding are intentionally not copied. Muted dots, neutral controls and warm note surfaces preserve the reference's visual hierarchy. |
| Assets and icons | Uses the existing bundled Tabler icon family for pointer, hand, note, document, outline, history and zoom. No invented SVG art, imitation avatars, decorative assets or fake Share/timer controls. The tool dock is shorter because it contains the working W2 tools. |
| Copy and content | English product labels and literal user text remain. The empty-board hint explains how to start and disappears with content. Saved, Draft and recovery messages reflect actual state. The source's name, plan badge and sharing copy are product-specific and intentionally replaced. |

The full-size 974×491 comparison makes the title and dock icons readable without
extra crops. Focused review also inspected the actual editor, outline, small
zoom controls and mobile dock in the in-app browser. Dark rendering was reviewed
against Studio's existing theme contract; the supplied reference has no dark
or mobile state, so those are usability checks rather than pixel-copy claims.

## Interaction and verification

- Nine browser journeys pass with zero page errors, including hand panning,
  zoom/reset/fit, keyboard focus restoration, contextual editing, pointer and
  keyboard placement, resize, connections, remote updates, conflicts and recovery.
- Drafts survive panel closure and block switching. Save-in-flight closure,
  lost response, lost request and direct project-access revocation are covered.
- Canvas bounds and page overflow checks pass across the tested widths.
- Repository check and production web build pass. The full 457-test suite and
  plugin build pass; no backend behavior changed during this UX revision.
- In-app browser review confirmed the working local route. Actual screen-reader,
  IME, real touch-device and native-agent qualification remain outside this slice.

## Acceptance and follow-up

No open P0/P1/P2 design findings. The sidebar, INFUSE styling, smaller functional
tool set and onboarding hint are intentional adaptations of the provided layout.
No new sharing, drawing, nested-section or realtime presence capability is claimed.
Fito's review of the revised UX is pending; local QA does not constitute user
acceptance. No deployment or production data was used.

Checklist complete: full canvas, floating controls, contextual editor, draft/save
states, responsive layout, reference comparison and browser verification.

final result: passed

---

# Whiteboard drawing and inline notes — 2026-10-14

Scope: Fito's follow-up adds freehand drawing to the retained floating dock,
edits sticky notes directly on their surface, and removes optional React Flow
attribution. This entry supersedes the previous section's freehand exclusion.

## Visual and interaction evidence

- Inspected generated `test-results/whiteboard/drawing.png`,
  `drawing-inline.png` and `mobile-inline.png` from the real web frontend.
  Blue vector ink sits beside HTML cards; the pencil is in the bottom dock.
  Sticky title/body fields keep the note's background and typography with
  compact Save/options controls inside the card. No side panel opens for a note.
- Desktop keeps the full workspace canvas and floating controls. At narrow
  widths, zoom sits above the centered dock so the additional pencil does not
  cause a collision. Bounds checks pass at 320, 390, 600, 974, 1198 and 1480
  CSS-pixel widths. The 390×844 capture confirms direct editing stays in the note.
- Ten browser journeys pass with zero page errors. Drawing is exercised after
  pan/zoom; stored world coordinates are checked, Escape cancels an unfinished
  stroke, reload retains ink, and dragging its actual hit target persists movement.
  Geometry editing and deletion use the same revision-checked commands.
- Inline drafts, remote revision conflict, closing during a pending save,
  receipt recovery and project isolation/revocation continue to pass. React Flow
  attribution is absent through its supported option; upstream license remains.
- Full repository check, 459 tests, plugin build and production web build pass.
  The existing web bundle-size advisory remains.

## Limits and handoff

New in-app browser previews repeatedly returned to synthetic sign-in after
initially loading the workspace, on both loopback host spellings. No browser
page error explained it; the repository's isolated Chromium fixture succeeds.
Manual in-app use is therefore not qualified by this revision. Authentication
policy was preserved. Screenshots use disposable synthetic content only.

The board stores bounded vector JSON, not raster sketches; it has no eraser,
stroke smoothing, pressure support or collaborative undo in this slice. Actual
touch-device and screen-reader qualification remain later work. Fito's acceptance
and deployment are not claimed.

Self-review: standard. No unresolved source correctness finding in the exercised
flows. Needs follow-up: in-app preview session stability and Fito's UX review.

## Sign-in follow-up resolved — 2026-10-14

The previously unresolved in-app sign-in issue is reproduced and fixed. Cookies
are shared across ports on the same host; background polling from an old preview
cleared the active preview's unqualified session cookie. Local HTTP cookies now
include the configured port. Production HTTPS names/protections remain intact.

Two regression tests failed before the fix (session erased by a sibling poll,
and a pending login replaced by another port's login). Both pass after it.
The real whiteboard browser harness now uses two previews in one browser context
and verifies inline sticky-note save, sibling login/logout and retained editing.
All eleven journeys pass, with zero page errors. Full check, 461 tests, plugin/web
builds and the existing project browser suite pass.

Direct in-app verification: signed in, selected the existing note, edited its
body inside the card, saved to revision 2, and reloaded the page. The saved text
remained visible and the session stayed active with an old preview still open.
This resolves the previous manual-preview qualification gap. Fito's wider UX
acceptance remains separate. This was the pre-merge W2 checkpoint; see the release
reconciliation below for current status.

## Whiteboard merge and release reconciliation — 2026-10-14

PR 3830 merged W2 as `9823a1d` after final source `42c7317` passed the root check,
464 tests, plugin/web/mockup builds, eleven whiteboard journeys and six project
browser checks. Required PR build 9336 passed code, image and Helm validation.
These counts supersede the earlier 459/461-test checkpoints above without
changing their recorded scope or historical findings.

Main build 9340 stopped at the newer-source guard; build 9341 deployed the
containing revision `e2eb10d`. Read-only production inspection confirmed health,
one ready replica and the signed-in Whiteboard canvas with floating pencil,
note/document and zoom controls. No live note or drawing was created or changed.
Production write/reload verification and Fito's layout acceptance remain pending.
[W2 results](docs/plans/active/020-collaborative-whiteboard/w2-results.md#merge-and-release)
own the exact release identifiers and limits; [next slices](docs/plans/active/020-collaborative-whiteboard/tasks.md)
remain W3 shared text/presence, W4 nested HTML and W5 native-agent qualification.

---

# Project floor — option 2

Date: 2026-10-16. Local implementation on `codex/studio-living-floor`; not deployed.

## Visual truth and normalization

- Selected source: `/Users/mac/.codex/generated_images/01a14414-acc8-79a0-942b-54444763df1a/exec-b286c77d-2c02-482b-8c46-f6ee7ed1b1db.png` (option 2, 1318 × 1194 raster pixels).
- Implementation: `http://localhost:4912/floor?project=studio`, a disposable preview of the actual app with a clearly prefixed synthetic mission and observed fixture run receipts. The ordinary preview at port 4911 retains its own data.
- Comparison screenshot: `test-results/living-floor/01-selected-sunset.png` (1073 × 973 pixels, CSS viewport 1073 × 973, device scale factor 1).
- Source normalized once to 1073 × 973. Full page, no browser chrome or device frame. State: Studio project, light appearance, 16 October 2026 at 18:20 Europe/Madrid, two assigned agents, Emon selected, bottom inspector open. Reduced motion settles the entrance for a reproducible comparison; arrival is verified separately.
- Exact dynamic strings differ intentionally: the real model keeps canonical identity, full known display names and literal mission titles. The fixture's `[Preview]` prefix identifies sample work. Localized clock formatting is retained.

## Comparison history

### Iteration 1 — blocked

Combined source/implementation evidence:
`/Users/mac/.codex/visualizations/2026/10/16/01a14414-acc8-79a0-942b-54444763df1a/floor-option2-comparison-v1.jpg`

- **P2, desk labels:** full names in the first adjacent back-row desks collided with each other and the Project activity pin. This obscured selection. Fix: fill separated front-row desks first, use known short names on spatial pins, retain full names and recorded state in accessible names and the inspector.
- **P2, lighting:** sunset was too dark and orange, with an early purple night blend. Fix: brighter neutral hemisphere/fill, softer sunlight tint and a later panorama crossfade. Warm lamps and night remain distinct.
- **P2, composition/action:** a redundant desktop agent row reduced the room's space, and the primary inspector action was black. Fix: rely on the equivalent HTML spatial buttons for up to eight desktop desks; keep the list for mobile, overflow and no-WebGL. Enlarge the room framing and use the existing orange primary token.

### Iteration 2 — passed

Post-fix combined full-view evidence (source left, implementation right):
`/Users/mac/.codex/visualizations/2026/10/16/01a14414-acc8-79a0-942b-54444763df1a/floor-option2-comparison-v2.jpg`

Focused inspector evidence (source above, implementation below; both cropped from the normalized images at x=224..1073, y=832..973):
`/Users/mac/.codex/visualizations/2026/10/16/01a14414-acc8-79a0-942b-54444763df1a/floor-option2-inspector-comparison-v2.jpg`

The revised captures resolve the three P2 findings: labels are readable, the timber and furniture remain clear at sunset, the floor gets the main viewport, and the orange mission action anchors the inspector. No actionable P0/P1/P2 findings remain in the exercised states.

## Required fidelity surfaces

- **Fonts/typography:** existing StudioPlex and shared navigation typography retained. Large project heading, tabular clock, compact metadata and readable mission title preserve the target hierarchy. Literal long titles wrap in the inspector. Known agent full names remain inspectable instead of adopting the concept's shortened content everywhere.
- **Spacing/layout:** same sidebar, floor-first composition and bottom horizontal inspector. Camera angle and authored 22 × 14 layout remain fixed. The revised desk positions avoid the observed collision. At 390px the inspector wraps and the equivalent agent controls remain available without horizontal page overflow.
- **Colors/tokens:** existing workspace/panel/ink tokens, orange primary action and green selection state. Warm sunset, neutral day and blue night panorama keep furniture legible. Theme controls were not added.
- **Image quality/assets:** actual shared Three.js furniture and INFUSE assets retained; generated panorama assets are sharp at the window crop and match across day/night. No screen raster is used as the interface. Existing agent portraits replace the concept's letter avatar intentionally. The conceptual painterly render is interpreted through the existing approved geometry, not a replacement scene or layout.
- **Copy/content:** app labels describe real recorded activity and exact destinations. Empty projects show no fabricated people. The concept's “Example activity” copy is confined to fixture semantics rather than appearing in the production interface. Current and stale activity remain distinct.

## Interaction and state evidence

`npm run test:floor:ui` / `scripts/studio-floor-smoke.mjs` exercises the actual disposable OIDC, HTTP, SQLite writer and browser renderer. `test-results/living-floor/proof.json` records eight passing check groups:

- Current assignment selection, inspector keyboard focus and exact mission/project navigation.
- Camera controls, close/focus return and no rendering while the floor is hidden.
- Real clock updates, night and shared hourly storm; reduced-motion arrival/lightning suppression.
- Settled receipts stop working gestures.
- 390px layout and usable mission action.
- Project switch clears previous identities; empty projects invent no work.
- Elevator doors visibly open on first arrival; Escape settles them without blocking navigation.
- No-WebGL fallback retains equivalent HTML selection and mission access.

Screenshots: `01-selected-sunset.png`, `02-night.png`, `03-day.png`, `04-mobile.png`, `05-empty-project.png`, `06-elevator-arrival.png` in `test-results/living-floor/`.

The interactive in-app preview was also opened and Emon selected; the inspector exposed the correct project-scoped mission link. Live capture:
`/Users/mac/.codex/visualizations/2026/10/16/01a14414-acc8-79a0-942b-54444763df1a/floor-option2-live-preview.png` (1422 × 800, actual app pane).
No browser warning/error logs were reported there; automated contexts recorded no page errors.

## Verification and boundaries

- `npm run check`: passed.
- `npm test`: 546 passed, including four new projection tests for identity, current assignment, observed runs, stale/held/uncertain state and project isolation.
- `npm run build:plugin`: passed.
- `npm run build --workspace @studio/web`: passed.
- `npm run build --workspace @studio/mockup`: passed.
- Focused floor browser suite: eight check groups passed again after visual fixes.
- `git diff --check`: passed.

Existing nonblocking bundle-size warnings remain. Fixtures establish UI behavior against synthetic receipts, not real agent execution. No production data, release or deployment was changed. Manual visual comparison covered two occupied desks, empty state, selected inspector, day/night and mobile; larger roster permutations were not exhaustively captured.

## Implementation checklist

- [x] Preserve source geometry and navigation contract.
- [x] Connect the floor to current project assignments and receipts.
- [x] Add automatic atmosphere and nonblocking elevator arrival.
- [x] Provide keyboard/mobile/no-WebGL equivalents.
- [x] Resolve iteration 1 P2 findings and recapture the same comparison state.
- [x] Complete checks and record local-only scope.

final result: passed


# Skills and Tools Field Guide — 2026-10-17

## Scope and source

User-selected option 3, refined with approval to fix cramped categories and make
the title/art compact. Real `apps/web` implementation, current Studio shell and
36-entry Core catalog. No mockup state is imported and no content is regenerated.

Selected image, 1487×1058 pixels:
`/Users/mac/.codex/generated_images/01a14414-acc8-79a0-942b-54444763df1a/exec-b15add81-9134-4d15-9857-868305077186.png`

Final app capture, 1487×1058 CSS viewport at device scale 1:
`test-results/skills/field-guide-reference.png`

Both show dark workspace navigation, Build & deliver selected, Agentic Product
Engineering open and reader at the top. The concept uses illustrative text and
list ordering; implementation retains the published catalog's literal copy/order
and Studio's actual 224px navigation. Synthetic account: Local operator.

Full-view side-by-side, source left and implementation right; unscaled originals
placed together with a 40px caption strip, 2974×1098 pixels:
`/Users/mac/.codex/visualizations/2026/10/16/01a14414-acc8-79a0-942b-54444763df1a/skills-field-guide-comparison.jpg`

Focused comparison, original-size crops (no stretching), source strip above and
implemented discovery below:
`/Users/mac/.codex/visualizations/2026/10/16/01a14414-acc8-79a0-942b-54444763df1a/skills-category-comparison.jpg`

Both combined images were opened and inspected. Full-view review covers layout,
font hierarchy, palette, imagery and content density. Focused review covers the
reported clipping and complete category labels. Extra source crops are not needed
for Tools/mobile because the selected image supplies no corresponding state.

## Iterations and findings

1. Implemented persistent discovery, shared paper reader and compact generated
   editorial motif. A keyboard regression moved focus off a category when it
   cleared an open guide. Fixed by separating filter updates from reader return.
2. Desktop and phone flow passed. Short landscape inspection at 844×400 CSS
   exposed a P2: fixed filter content could leave all results outside the visible
   pane. Below 650px height, discovery now scrolls as one pane. The final 844×390
   browser proof reaches and fully exposes the last filtered result.
3. Added search-focus fallback when returning from a missing guide/tool ID.
   Final browser proof confirms it. Repeated full-view and focused comparison:
   no unresolved P0/P1/P2 findings in the exercised states.

## Fidelity and intentional refinements

- Fonts: existing registered StudioPlex and shared navigation retained. Reader
  title up to 41px, promise 19px, body 14px, compact section labels. Literal long
  names wrap. Smaller title and artwork are explicitly approved refinements.
- Layout: same browse-left / paper-right hierarchy. Discovery is 380px wide on
  desktop, with complete labels in a two-column purpose group and full-width All
  skills. The reader gets remaining width and an independent scroll area. Search,
  app filter, counts and clear controls remain visible during desktop reading.
- Color: shared workspace theme tokens, orange selection accents, ivory paper
  #F2EFE8 and dark readable ink. Paper intentionally remains light in dark mode.
- Assets: shared INFUSE brand and icons unchanged. Generated 2172×724 PNG motif
  is decorative with empty alt; provenance/hash are recorded in the UI package.
  The shallow textured orange strip is crisp at the rendered 88px/66px heights.
- Content/actions: production catalog supplies names, outcomes, steps, examples,
  boundaries and app relationships. Source text and HTML downloads retain their
  exact revisions. No invented install, connected or runtime capability claims.
- Responsive: 390×844 shows a single browse or reader pane with explicit return;
  complete labels, toolbar and long content fit without horizontal page overflow.
  844×390 can scroll through the full result set. Reduced motion disables the
  reader transition. Native buttons and focus return retain keyboard access.

## Evidence and checks

`test-results/skills/proof.json`: six passing groups; 36 skills; zero page errors.
Registry is the disposable wire fixture, not the live Registry. It proves Core
access, catalog and UI behavior against retained source bytes, not publication.

Inspected screenshots: `catalog-desktop.png`, `field-guide-reference.png`,
`catalog-mobile.png`, `guide-mobile.png`, `tool-mobile.png`, `tools-desktop.png`
and `catalog-landscape.png` under `test-results/skills/`.

Repository checks passed: `npm run check`, `npm test` (569/569),
`npm run build:plugin`, web build and the focused Skills browser harness. Existing
bundle-size advisory remains. Final diff and whitespace review passed. No source
regeneration, live publication, merge or deployment performed. Partner acceptance
is pending review of the local preview.

final result: passed


# My Apps — Personal Launchpad design QA

Source visual truth: `/Users/mac/.codex/generated_images/01a16985-0fd9-7ae2-830a-40f775f7aa8b/exec-5ebb0bdd-a947-436e-be3d-1921a2c0ac97.png`

Selected first displayed concept, October 23, 2026. Implemented in the existing
Studio app; no separate prototype or deployment. All preview data is synthetic.

## Comparison history

Initial comparison used the in-app browser at 1487 × 1059 CSS px, light theme,
22 core apps and the six starter pins. Source is 1487 × 1058. The browser reports
devicePixelRatio 0.75; its screenshot contains blank padding outside the rendered
CSS viewport. Cropping that padding and one extra bottom pixel yields a 1487 ×
1058 image without resampling. Paired full-view and focused pin/catalog comparison
images are in the task visualization directory as `launchpad-*-comparison-v1.jpg`.

- [P2] The pinned area begins 22 px too low and its heading has excess vertical
  spacing; this pushes the entire catalog below the selected composition. Reduce
  top content padding and the pinned heading gap.
- [P2] Pinned Company Vaultwarden stays on one line and catalog descriptions are
  too small. Bound the tile label width and increase descriptions to 13 px while
  preserving literal server text.

Post-fix v2 comparison confirms the pinned area, labels and primary catalog
align with the selected hierarchy. A further P2 density issue remained in the
wide Infrastructure group: uniform large rows hid several apps shown in the
reference. Smaller icons and compact supporting text now match that group's
secondary emphasis. Mobile keeps readable 13 px descriptions and larger rows.
The final post-fix full-view and focused comparisons confirm compact secondary
rows, readable descriptions and the selected category hierarchy. No actionable
P0/P1/P2 findings remain.

A separate interaction check added a sticky Done editing pins action so mobile
users can finish editing without returning through the full catalog; it restores
keyboard focus to Edit pins.

Intentional constraints: retain the existing 224 px Studio sidebar, literal
current catalog descriptions and per-app accent colors. Use the real page eyebrow
in place of the design's Concept preview caption. The preview identity/project
labels differ from the reference's synthetic identity.

## Final evidence and fidelity review

Evidence directory: `/Users/mac/.codex/visualizations/2026/10/23/01a16985-0fd9-7ae2-830a-40f775f7aa8b`.

- Implementation: `launchpad-desktop-final.jpg`, 1487 × 1058 px after the
  documented crop; original capture `launchpad-desktop-final-raw.jpg`.
- Combined source-left / implementation-right comparisons:
  `launchpad-comparison-final.jpg`, `launchpad-pinned-comparison-final.jpg`,
  and `launchpad-catalog-comparison-final.jpg`. Opened and reviewed together.
- Mobile: `launchpad-mobile-final.jpg`, 389 × 844 CSS/pixels, cropped from
  the same browser's padded capture without scaling. Two-column pins, full-width
  Quick launch and single-column categories; no horizontal overflow.
- Dark: `test-results/backoffice-apps/dark.png`, 1440 × 1000 CSS viewport,
  full-page capture, inspected for contrast and hierarchy. The reference provides
  no dark or mobile state, so these are responsive adaptations, not exact matches.

Required fidelity surfaces:

- Typography: existing StudioPlex and fallback stack retained; 18 px section
  headings, 14 px primary app names, 13 px descriptions, and 13/12 px compact
  secondary rows. Company Vaultwarden wraps in the pinned tile. The reference
  uses a similar compact sans-serif hierarchy; literal longer descriptions wrap
  naturally instead of clipping or copying generated paraphrases.
- Spacing: six desktop pins, three main category columns, spanning Infrastructure
  group, subtle dividers and consistent row gaps. The corrected top spacing and
  label width track the selected composition. Existing shell width and full
  descriptions account for minor differences in lower section positions.
- Colors: shared light/dark theme tokens, orange edit/pin accents, faint warm
  pinned panel and existing app accent tints. Focus, hover and pressed states are
  visible; no new fixed light colors break dark mode.
- Assets: existing INFUSE mark and bundled Tabler SVGs remain sharp. No remote
  image loads, letter placeholders, custom-drawn logos or generated raster assets.
- Copy: real catalog names/descriptions/counts are retained. Concept-preview
  copy is absent from product UI. Edit pins explains browser-local persistence;
  empty and unavailable-storage states provide actionable messages.

Primary interactions exercised in the in-app browser: enter/leave pin editing,
add/remove Brand Hub, Quick launch search and Escape. The 18-check isolated browser
suite also verifies launch through an intercepted synthetic destination, reload
persistence, empty/malformed/blocked storage, profile isolation, admission changes,
mobile sticky completion and focus return, search keyboard/pointer behavior,
loading/error/retry, sign-out and access expiry. Browser console errors: none.
The narrow sticky completion control is an intentional usability refinement
because the reference does not depict editing a long mobile catalog.

Remaining P3: the bundled outline pin is visually lighter than the reference's
filled pin. Keep the coherent library treatment unless a future visual revision
calls for changing the action icon weight across the page.

Implementation checklist: selected layout implemented; P2 findings fixed and
recaptured; desktop/mobile/dark reviewed; primary flows verified; frontend typecheck,
web build, 18 focused browser checks and `task verify:lightly` passed. No production
or user-acceptance claim. Earlier QA reports are preserved above.

final result: passed


## My Apps follow-up — Document Normalizer

The user explicitly moved Document Normalizer to Internal tools after selecting
the launchpad. The refreshed 1487 × 1059 CSS preview shows five Internal tools
entries and omits the now-empty AI & automations group. Infrastructure flows
into the next available catalog row. Source layout and styling are unchanged.

Inspected screenshot: `/Users/mac/.codex/visualizations/2026/10/23/01a16985-0fd9-7ae2-830a-40f775f7aa8b/normalizer-internal-tools.jpg`
(1487 × 1058 after the previously documented padding crop; DPR 0.75). The changed
grouping is an explicit user refinement to the selected source, not visual drift.
No clipping or new layout finding. All 18 focused browser checks passed.

final result: passed
