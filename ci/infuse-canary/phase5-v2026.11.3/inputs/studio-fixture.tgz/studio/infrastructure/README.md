# Infrastructure boundary

The [standalone deployment preparation](standalone/README.md) packages the real
Studio frontend and Fastify authority in one non-root Node container. Its
reviewable Kubernetes example uses a same-Pod TLS proxy, one persistent SQLite
volume and external OIDC configuration. Remote dispatch and Gateway enrollments
are disabled in the example.

The container and templates create no remote infrastructure. Hostname, TLS,
identity registration, image publication, secret provisioning, private routing
and live rollout remain explicit deployment work. Persistent agent runtime and
plugin installation changes belong in `openclaw-k8s-swarm`; the frontend and
mission authority remain owned by this repository.
