# Registry release inputs

The canonical service and antivirus deployment definitions now live in
[artifact-services](../artifact-services/README.md). This folder redirects
Kustomize consumers there instead of retaining a second stale manifest owner.

`Dockerfile.registry` defines the independent Registry image build. The GitLab
pipeline verifies it for merge requests; delivery is blocked until release
qualification is reviewed.
`scripts/registry-release.mjs`
prepares a local review bundle from the canonical manifests; it does not deploy.
Use the artifact-services handoff procedure for activation. Existing storage and
credentials stay intact; no backup, restore or purge is included.
