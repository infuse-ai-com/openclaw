# Artifact services release and recovery

GitLab delivery and the old artifact-service handoff/release command-line paths
are disabled until a replacement is reviewed and qualified. Do not run a handoff,
cleanup or release from the historical instructions in Git history.

The Registry and scanner are separate workloads. Registry state has one writer;
any future replacement must preserve claim and deployment identity, validate
publisher and monitoring access, quiesce every pod mounting the claim before a
writer starts, and fail closed if quiescence cannot be proved. Recovery must stop
the failed writer before restarting any previous writer. Never delete a PVC,
secret or compatibility service as an incidental release action.

A new delivery path must enforce current reviewed source, exclusive deployment
ownership, a lock, immutable images, source and image acceptance, readiness and
consumer verification. The retired pipeline and its ownership gate are not a
substitute for those checks. A successful build is not production activation.

## Registry image updates

After the ownership handoff, pipeline 117's `release` action updates only the
Registry container image through `scripts/artifact-services-release.py`. First
publish a green reviewed-main image through pipeline 124. In a reviewed PR, pin
its immutable digest in `registry.json` and put the exact image source commit in
the Deployment annotation `infuse.ai/studio-source-revision`; record the expected
currently deployed digest in `infuse.ai/registry-previous-image`.

Run `release` from that reviewed current main. The existing source/owner gate and
deployment lock apply. It verifies the current image, bound volume identity,
single ready writer, service selectors and auth reference before any mutation.
It stops that writer, waits for every Pod mounting its claim to disappear,
changes only the image/source annotation, then starts and qualifies one writer.
An unsuccessful rollout restores the previous image only after proving the
failed writer has stopped. Failure to prove quiescence leaves the workload
stopped for diagnosis. This introduces a brief Registry read/write interruption.
No PVC, Secret, scanner, Service, data or credential update is part of release.

Additive Registry APIs must be deployed and checked before merging dependent
Studio reader changes. Record image and source, pipeline receipts, readiness and
exact API acceptance; a successful image publication alone is not activation.

## Preserved internal identifiers

The bound 20Gi `backoffice-artifact-registry` claim has UID
`6547b88a-ff6c-438c-9993-37dc07619084`; the handoff refuses a different volume.
The existing auth Secret and 50Gi backup-transfer claim retain their names.
Kubernetes cannot rename a bound claim in place. No volume recreation, data copy,
Secret read/rotation or claim deletion is part of this change. Bastion/Kopia is a
separate future backup design, not an operation in this handoff.


Test the retained safety logic with `python3 -m unittest discover -s tests/operations -p 'test_artifact_services*.py'` and inspect `kubectl kustomize infrastructure/artifact-services`. These checks do not authorize deployment.
