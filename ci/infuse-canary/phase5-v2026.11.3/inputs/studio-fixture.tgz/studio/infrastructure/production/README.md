# Studio at studio.infuse-ai.com

The production workspace uses Harbor images and Traefik HTTPS. The checked-in
GitLab delivery pipeline defines deployment patch jobs. Studio remains the
mission authority and owns its dedicated PostgreSQL database. The original SQLite
PVC remains retained but unused for authority. No Backoffice database,
credentials or worker is used by Studio.

Historical deployment evidence, 2026-10-06: native V2 production and
isolated Mac pilots completed; production was restored and enabled, with Mac
execution disabled. Source-access repair, scoped task instructions and HTML
artifact acceptance are recorded in the [roadmap](../../docs/ROADMAP.md).
For the current storage cutover, see plan026 below. This historical record is not
a fresh live-health check. Use the
[native contract](../../docs/architecture/native-missions.md) for current behavior
and the [rollout sequence](../../docs/plans/archive/010-native-mattermost-missions/rollout.md)
for staged enrollment and required-owner protection. The first-release record
below describes the earlier disabled bootstrap.

Initial release on 2026-10-04: deployed with real Google/Authentik login. Azure pipeline `studio` (114),
variable group `studio-production` (92), private Harbor project `studio` and
Authentik provider `Studio` (45) are provisioned. Discovery/JWKS and the pilot
subject preview are verified. Mission creation, paper approval and authenticated
reload passed on the public site. The private bridge transport deployed in build
8773. At that checkpoint Emon and Tinus ran the exact plugin, with authenticated polling,
advancing PVC journals and local Gateway RPC verified. Releases and checks are
recorded in the [Gateway connection evidence](../../docs/evidence/2026-10-04-gateway-connectivity.md).
That connection-only verification did not start a live mission or Mattermost integration.
See the [first-release evidence](../../docs/evidence/2026-10-04-production-workspace.md).

## Release ownership

| Item | Value |
| --- | --- |
| Pipeline | [`../../.gitlab-ci.yml`](../../.gitlab-ci.yml) |
| Backoffice reference | `origin/main` at `7815207` |
| Shared infrastructure pin | `04a5c4071db0794b06aae5fb548fc52623477e14` |
| Namespace/release | `core/studio` |
| Image | `registry.infuse-ai-tech.party/studio/studio` |
| Origin | `https://studio.infuse-ai.com` |
| Central state | Dedicated `core/studio-postgresql`, PostgreSQL17.11; `studio-postgresql-studio-postgresql-data` PVC,10GiB hostpath, retained on Helm deletion |
| Registry checkpoint state | `studio-studio-data` PVC,2GiB hostpath; preserves Documentation, Code and Contributions anti-replay checkpoints. Original central SQLite files were deleted. |

GitLab merge requests run source checks and verify three image builds. Delivery
is blocked at workflow admission, including protected `main`, until replacement
qualification and release safety gates are implemented and reviewed. The dormant
delivery job definitions are not authorization or proof of a safe release.
The former Azure-baseline rollback jobs have been retired. Recovery requires a
reviewed compatible release and must preserve the data and one-writer constraints
below. This pipeline does not establish parity with every earlier release check.
One replica and `Recreate` prevent two concurrent authority writers. Never scale
this release above one or share its state volume with another authority.

The detailed configuration and acceptance procedures below include steps from the
previous Azure delivery path. Confirm current ownership and GitLab parity before
using them to change production; retain their safety and recovery constraints.

## Authentik registration

Studio uses a distinct application/provider with this contract:

| Setting | Required value |
| --- | --- |
| Application slug | `studio` |
| Provider | Native OIDC, confidential client, authorization code with PKCE/S256 |
| Callback | `https://studio.infuse-ai.com/api/auth/callback` (exact match) |
| Scope | `openid` |
| Token endpoint authentication | `client_secret_basic` |
| Signing | Asymmetric key published in JWKS; use the approved RSA pattern |
| Issuer | Verify discovery; expected `https://auth.infuse-ai.com/application/o/studio/` |
| Initial access | Existing `infuse-core` audience at Authentik; only the pilot operator in Studio membership |

Do not reuse Backoffice's OIDC client or callback. Obtain the operator's actual
OIDC `sub` for this provider; display name, email and Authentik numeric user ID
are not substitutes. Use an immutable subject mode and verify its emitted value.

Use [`studio.native.example.json`](studio.native.example.json) for the native
mission rollout. [`studio.example.json`](studio.example.json) records the earlier
two-agent transport setup. Replace placeholders in approved runtime
configuration and add the verified member:

```json
{
  "issuer": "https://auth.infuse-ai.com/application/o/studio/",
  "subject": "VERIFIED_OIDC_SUB",
  "profileId": "fito",
  "displayName": "Fito",
  "approver": true
}
```

The empty example member list grants nobody access. Preserve exact issuer
spelling, including its trailing slash. Keep native execution and cutover disabled
while provisioning all four role enrollments, scoped credentials, native
Mattermost identities and project channels. Enable enrollments and execution in
the order specified by the native rollout. Preserve authority/project IDs once
state exists.

The earlier Azure release stored `STUDIO_CONFIG_JSON` and `STUDIO_OIDC_CLIENT_SECRET`
in variable group `studio-production` and created `core/studio-settings`
(mounted configuration) and `core/studio-runtime` (secret environment).
The earlier shared renderer resolved these values through explicit `envFrom` process
environment references, preserving JSON without macro-escaping it. Confirm current
secret ownership and projection before changing production configuration; the
GitLab deployment YAML alone does not establish equivalent secret provisioning.
Full-directory mounting supports revocation after Kubernetes projection delay.
Secret values never belong in source, Helm values, screenshots or command logs.

The OpenClaw dashboard integration adds one independently generated
`STUDIO_DASHBOARD_CUSTODY_TOKEN` value to `core/studio-runtime`. It is a
dedicated 256-bit credential for the custody reader and must not reuse a
Gateway enrollment token. Rotation requires coordinated Studio and dashboard
rollouts; either side fails closed while the values differ.

Workbench uses a separate configured file alongside its mTLS and signing
material. The earlier release used `STUDIO_WORKBENCH_CONFIG_JSON`; current secret
ownership and projection need qualification before delivery is enabled. Studio
parses configured files as one fail-closed configuration and watches the Workbench
file for grant/revision withdrawal.

Before enabling an enrollment, build the backend with `npm run build:services`
and run `node scripts/validate-standalone-config.mjs` with `STUDIO_CONFIG` and the
same credential environment intended for the backend. This checks both the
configuration shape and actual enabled Gateway tokens without printing them.
Each token must encode exactly 32 random bytes as 64 hex characters or 43
unpadded base64url characters. A parsed configuration alone does not validate
environment-backed credentials. When a qualified delivery path changes secret
environment values, a controlled rollout and bridge admission check are required;
an unchanged process can otherwise retain the old environment.

## Initial bootstrap and verification

These steps describe provisioning a new, disabled environment and the historical
first release. They are not the status of the enabled production workspace.
Use the native rollout for changes to existing enrollments.

1. Complete Authentik registration and verified initial membership.
2. Provision the dedicated Harbor `studio` project and approved push/pull access
   if absent. Use the existing shared cache and pull-secret path.
3. The historical pipeline provisioning and Azure branch-policy steps are retired.
   GitLab delivery is blocked until a replacement release path is qualified.
4. Any future release requires a reviewed current source, exact deployment identity,
   qualification and access boundaries. Do not bypass the delivery block.
5. Check `/api/health` reports standalone mode and `dispatch: false`. Check the
   root displays the real sign-in page, complete enrolled-user login, and deny
   an unlisted identity. Create/approve a paper and verify reload and an approved
   Pod restart retain the mission and session. Record source/build/image/release
   IDs with the browser results.

At the historical checkpoint, the workstation role could create Deployments in
`core` but could not create/read its IngressRoutes. Verify current scoped access;
do not bypass an access denial. External HTTPS success
alone does not prove the origin route or its certificate configuration.

## Authenticated prototype mockup

The image includes a separate `apps/mockup/dist` build at
`https://studio.infuse-ai.com/prototype-mockup/`. The route requires a qualified release; GitLab delivery is currently blocked. Opening the
route uses the existing Studio sign-in and returns to this fixed path. Every
HTML and asset request requires current Studio membership and uses `no-store`.
Missing files return 404 rather than the real application's SPA fallback.

The mockup remains a design reference with browser-local simulated state. Its
build is separate from `apps/web/dist`; real application code does not import
mockup state. No mission API, writer, membership or dispatch behavior changes.
Build the prefixed bundle with:

```sh
STUDIO_MOCKUP_BASE=/prototype-mockup/ npm run build --workspace @studio/mockup
```

The default `npm run dev` still serves the mockup at `/` on port 4317.

After deployment, verify an enrolled-user visit loads the office, Prototype
screen and brand assets, an anonymous asset request is denied, and the real
Studio root still loads. Local synthetic OIDC tests establish the route and
sign-in behavior; they do not establish production publication.

## Gateway transport

The backend now binds loopback. A hardened Caddy sidecar uses the same immutable
Studio image and exposes two listeners: browser HTTP on 4320 behind the existing
Traefik HTTPS route, and private bridge TLS on 8443. The browser listener rejects
`/api/bridge/*`, `/api/dashboard/*` and other machine-only paths. The private
listener exposes only the exact machine routes, dashboard custody endpoint and
health. The private `studio-bridge` ClusterIP Service uses port 443. Its ingress
policy admits the enrolled coordinator, developer, designer and infra Pods plus
the exact `openclaw-dashboard` Pod label in `agents-swarm`; application-layer
credentials remain mandatory.
The current `core/studio` release and retained PVC remain the authority.

See [Gateway connection profiles](gateway-connectivity.md) for certificates,
secret ownership, the packaged plugin, Tailscale local testing and verification.

## Data policy until MVP and rollback

Production and Mac authorities keep separate state. Follow the
[database policy](../../database/README.md#data-policy-until-mvp), confirmed on
2026-10-08: **no Studio backups until MVP**. Pre-MVP breakage and data loss are
acceptable; backups, snapshots and restore rehearsals are not rollout gates.
Do not stop the writer for a backup.
Reconcile execution before schema changes and retain a single writer. In-place
schema downgrade is unsupported; an application revert must remain compatible
with the current schema. Preserve the PVC and Authentik registration during
diagnosis.

## First-release verification record

- `npm run check` and all 305 tests passed on the deployment branch.
- Shared infrastructure `task verify` passed, including five new file-secret
  boundary tests. The dependency merged in infrastructure PR #3674.
- Helm lint and full production rendering passed: retained PVC, Recreate,
  non-root/read-only container, exact host/service and executable probes.
- The existing final Studio image passed an isolated Linux arm64 smoke with
  `HOST=0.0.0.0`, no external network, read-only root, UID 1000 and synthetic
  OIDC: 28 static files served; mission and session survived process restart.
- Live Authentik audit confirms only the expected `infuse-core` Studio binding.
  The global audit still reports the pre-existing unclassified `mi-finca` app;
  no existing bindings or audience memberships were changed.
- Build 8767 deployed successfully after the probe fix: the Pod was ready with
  zero restarts and the image digest matched the Deployment. Public HTTPS health,
  anonymous mission denial, OIDC/PKCE redirect and protected cookies passed.
- The existing Google session completed real Authentik login. The enrolled
  operator created and approved a production smoke-test paper; a browser reload
  retained both identity and paper version 2, with Start disabled and no browser
  warnings or errors. This is separate from the earlier synthetic local proof.

The first rollout (build 8764, source `3383cd6`) pulled the image and started
the backend, but its startup probe failed and Helm rolled the release back.
Node's Fetch client replaced the probe's custom Host with its loopback
destination. The probe now uses the native HTTP client to preserve the public
Host. A real-socket regression covers a public hostname distinct from the
loopback destination, plus unhealthy and invalid responses. The retained PVC
and separately managed login configuration survive the failed first install.

## Core Knowledge admission

The first reader release adds an explicit non-executable company workspace:
`{id: "core", name: "Core", kind: "company", memberProfileIds: [...]}`. Populate
its membership only from the existing enrolled Studio/`infuse-core` cohort. Preserve
the root Studio identity, existing projects, role grants and native routes. An
empty membership list admits nobody; the frontend fabricates no floor.

Configure the private origin
`http://knowledge-base-studio-reader.knowledge-base.svc.cluster.local` and rotating
token file `/run/studio-knowledge/token`. Reviewed values project a ten-minute
`knowledge-studio-reader` token for `system:serviceaccount:core:studio`, mounted
only in the primary backend. The transport sidecar receives no KB credential.

Deploy KB's reviewed private reader release first. Then update the existing
secret `STUDIO_CONFIG_JSON` in the production variable group without printing its
contents and let Studio's reviewed main pipeline publish that configuration with
the new image. Keep one replica and `Recreate`; Core addition/configuration needs
a restart, while current membership guards remain live. Verify actual admission,
internal service health and workload/audience denial alongside authenticated
Core-only reading. Main merge/deployment does not imply human acceptance.

The old KB website remains available. Mission-source attachment, review writes,
agent/runtime activation, history/diff and old-site retirement stay deferred.
Explore graph/neighborhood and native option 2 are released read extensions. See
[read contract](../../docs/plans/active/014-knowledge-integration/contracts.md) and
[current delivery](../../docs/plans/active/014-knowledge-integration/plan.md#delivered-and-verified).


## Floor Knowledge release and activation

[Plan 022 K3](../../docs/plans/active/022-floor-knowledge/k3-release.md) owns the
approved pilot and live evidence. Release the compatible KB reader/management
service first. Studio projects a separate `knowledge-studio-management` token at
`/run/studio-knowledge-management/token`, mounted only into the backend.
The configured private management origin is
`http://knowledge-base-studio-management.knowledge-base.svc.cluster.local:8080`.

For the confirmed all-member policy use `floorManagement` with empty explicit
lists and `allMembers: true`, `allEnrolledAgents: true`. Both switches continue
to require current membership or attested Gateway enrollment. Keep credentials
in the deployment-owned settings. Store `floorManagement`, `knowledgeManagement`, optional `floorRuntime` and
optional `artifacts` in the separate secret variable `STUDIO_FLOORS_CONFIG_JSON`;
the reviewed pipeline creates `core/studio-floors`, mounted at
`/etc/studio-floors/config.json` through `STUDIO_FLOORS_CONFIG`. Preserve the existing
`STUDIO_CONFIG_JSON`, which is already close to Azure's 4,096-character limit.
The loader rejects duplicate or unknown fields and unreadable files. Policy
withdrawal remains live after projection; endpoint changes require a restart.
The transport container receives neither the floor file nor either KB token. Source curation happens through Studio's durable commands, not
by rewriting SQLite or adding another registry writer.

Before schema 21, reconcile active native runs and preserve a compatible writer.
Verify the actual manager service and scope-v2 acknowledgement before the first
floor/source command. A source is not Meaning-ready merely because Git indexing
succeeded. The matching agent plugin must reach enrolled hosts before claiming
agent management is live. Human UX acceptance is a separate final K3 gate.


## Equal floor capability release

Before schema 22 deployment, reconcile active runs and retain a schema-22 writer.
Release the compatible Registry image handler, then Studio, then the matching
Swarm plugin with production-only `floorRuntimeDiscovery: true`. Configure
`floorRuntime` in `STUDIO_FLOORS_CONFIG_JSON` with enabled true and templateProjectId
`studio`. Existing native routes are preserved; Finaxis gains the missing shared
role and Company gains the complete team. Retired floors remain excluded. A floor with
existing channels keeps their Mattermost team; only newly connected floors inherit
the template channel team. After projecting settings with an unchanged image,
verify that the Studio process restarted: these flags are startup bounds. If the
main rollout reused the existing Pod, complete the approved activation with a
controlled restart of `deployment/studio` and verify readiness before admission.

For image parity, move the existing `artifacts` object from the near-limit root
settings to the floor settings file (one source only). Preserve its Registry URL,
reader token path and per-project uploader paths; add imageUpload.floorTokenFile
pointing to the existing dedicated image token mount. Registry must first admit
that image-only principal with producer `studio-whiteboard` and studioFloors true.
The Swarm-owned image storage configuration sets floorFallbackProject to `studio`,
using separate project hash prefixes in the existing Studio bucket pair. Existing
Studio object keys remain unchanged; no object copies or bucket permission changes
are required. Do not later move a used floor between exact and fallback storage
without a reviewed object-location migration.

Verify all three active floors, preserved sources/history, private channel
membership, current host protection and image publication. Disable automatic
setup to stop new reconciliation; do not downgrade the writer or remove retained
channel protections. Report backend deployment, host installation and enabled
floor readiness independently.

## R4 machine access (disabled)

The read-only API is opt-in and loads no machine keys/routes by default.
[Plan 016 activation](../../docs/plans/active/016-mcp-access/read-only.md) owns
signer, human binding, cursor key, fixed origin and ingress/network prerequisites.
Do not infer new machine exposure or identity grants from deploying the code.
Enable only after the exact first human/client/floor enrollment is reviewed.
The existing one-writer, protected-main and no-backup rules still apply.


### Read-only Infuse MCP connection

`STUDIO_MACHINE_CONFIG` mounts `/etc/studio-machine/config.json` from the
`STUDIO_MACHINE_CONFIG_JSON` protected variable; start with `{"enabled":false}`.
Store its distinct cursor secret in `STUDIO_MACHINE_CURSOR_KEY`. Machine settings
cannot also appear in root `STUDIO_CONFIG_JSON`; changes require a main-pipeline
restart. Never store the MCP private signing key in Studio.

Caddy denies `/api/machine/*` on the public listener and exposes only the four
fixed POST reads on the existing private TLS listener. Only the MCP namespace's
`app=infuse-azure-devops-mcp` workload joins existing agent access on port 8443.
MCP receives the listener's public certificate as its CA trust, not its private
key. See [activation record](../../docs/plans/active/016-mcp-access/read-only.md).


## P7 operational configuration file

The optional `STUDIO_OPERATIONS_CONFIG` environment reference names one absolute
protected JSON file (at most 1 MiB) containing any of `apps`, `agentTelemetry`,
`contributions`, `monitoring` and `artifacts`. Use the same file with
`node scripts/validate-standalone-config.mjs` and the offline import CLI's
`--operations-config`. The runtime rereads it through all current-config/member/
bridge guards and retains existing restart requirements for operational changes.
Kubernetes projected symlinks work; invalid/missing/oversized/nonregular files
fail closed. Leaving the reference unset preserves existing configuration.

This is an independently reviewed protected-file owner, not another large Azure
variable. P7's live root was 3,835 bytes and its 89 repositories/55 checks exceed
that owner's capacity. Prepare the exact operator-owned file/Secret projection,
minimal credentials-by-reference and disabled/shadow configuration before adding
its environment/mount through the owning release. Never put raw credentials in
this file, logs or evidence. No mount/Secret/source is created by adding support.
The operations file mounts at `/etc/studio-operations/config.json`, alongside a
short-lived API token and CA at `/run/studio-operations`. The independently owned
`studio-operations-runtime` Secret supplies the Harbor and Grafana read credentials
for Floor Setup. The GitLab Contributions reader has its own credential. Main
delivery consumes these references and does not replace their contents.

The Studio ServiceAccount can get only the two named agent feed ConfigMaps in
core and the four enrolled agent Deployments plus the read-only Intake
Deployment in agents-swarm. It can list Pods
in agents-swarm because Kubernetes RBAC cannot restrict list by label; the
adapter uses each Deployment's selector and refuses truncated results. It has
no operational Secret read, exec, workload write or cluster-wide grant. The
transport sidecar receives neither the operational config/credential nor token.

Collection and the existing Backoffice app continue side by side during P7
comparison. Studio monitoring delivery stays `shadow` with no webhook credential
or ownership epoch. Never activate a second alert emitter. The independent
configuration owner and exact parsed digest must be revalidated before offline
imports, source changes or subsequent restarts.

A complete setting has one owner across root, floor and operations files. If
relocating existing `artifacts`, move its entire unchanged object out of the floor
file; do not split or overwrite reader/lifecycle/retained settings. Compare the
parsed configuration digest before/after pure relocation. Enable sources only
under the separate reviewed P7 scope; missing data remains unknown.
See [P7 live record](../../docs/plans/active/025-backoffice-consolidation/p7-live.md).


## Floor setup checks

The protected operations file may contain `floorSetup`. Its `floors` entries
map floor IDs explicitly to namespace, private Harbor project ID/name, and
Grafana dashboard/datasource/namespace/deployment. Setup also reports team
connection and knowledge indexing from the floor’s saved repository selection.
Providers carry approved origins and credential environment references only;
Harbor uses a `username:secret` read-only credential and Grafana a Viewer token. Never use an administrator credential
in Studio. Kubernetes may use the existing Operations cluster reader, or the
explicit Grafana datasource's recent `kube_namespace_status_phase` metric.
The latter requires no additional Kubernetes permissions.

Only floor managers can read `/api/studio/floors/:floorId/setup`. Checks create
nothing, follow no redirects, bound response size/time, and never expose provider
bodies or credentials. A refresh can reuse a provider observation for 30 seconds;
its timestamp remains visible. The browser refreshes every minute. Missing
metrics, forbidden reads and paused workloads are not inferred healthy.
Grafana readiness means its dashboard and datasource are accessible with recent
project deployment samples; it does not mean the application has running pods.

The `floorSetup` map can reload from the existing protected configuration owner;
every request rechecks the map and floor admission before returning. Other
Operations and execution settings retain their existing restart contracts.
Prepare credentials before enabling a map. Withdraw a map to disable its checks;
no mission writer, stored lifecycle state or external infrastructure is changed.


## Monitoring system labels

`STUDIO_MONITORING_SYSTEMS` is bounded non-secret JSON in reviewed Helm values:
an array of `{id, name, resources}` groups over already configured resource IDs.
The October 20 mapping preserves all 55 checks in Backoffice's 13 topmost systems.
It contains no targets, credentials, grants, notification settings or extra checks.
Unknown/repeated resources and conflicting inline system labels fail closed.
The normal main pipeline activates labels with the matching application build;
existing protected operations settings are untouched. Remove the optional value
with the code revert if rolling back to a build before label support.


### Observation-only agent activation

`agentTelemetry.observedAgents` is separate from mission `targets`. Each entry
requires an exact Gateway/agent pair and non-empty `floorIds`; overlap with
execution targets is rejected. Source mappings can use these identities without
a bridge enrollment, native route, machine ingress or dispatch grant. The
session exposes them separately and the current floor guard controls reads.

For the approved P7 Intake activation, the immutable configuration version
`core/studio-operations-intake` preserves the prior settings and adds only
`swarm-intake` / `agent-intake` on `core`, with the existing sanitized usage/model
ConfigMap keys and named Deployment GET. Stage and validate this version before
merging its values reference. Main delivery activates code and configuration in
one Recreate rollout; never update the mounted old configuration to a shape the
running version cannot parse. Rollback restores the previous image **and**
`studio-operations` reference through reviewed delivery, retaining the writer and
recorded telemetry. Neither config version contains a new credential. The older
Secret is retained as a configuration reference; it is not a database backup.


### Expiring human pilots

A root `members` entry may set `validUntil` to an exact UTC timestamp and
`canManageFloors: false`. Expiry is checked for new and existing browser sessions,
machine-owner admission and effective floor membership. The management ceiling
overrides both the all-member policy and an explicit manager allowlist; omission
preserves existing behavior. My Apps has its own explicit audience and expiry: an
expiring workspace pilot must use the same deadline in both records.

Before adding a Company-only member, explicitly retain the intended membership
of the root Studio floor; an omitted `project.memberProfileIds` defaults to all
enrolled members. Saved floor membership takes precedence and must be changed
through the supported floor command. A `nativeMember: false` entry explicitly excludes a browser-only member from
automatic Mattermost channel membership while retaining floor access in Studio.
Existing native members still require verified identities; false cannot coexist
with a configured Mattermost/native mapping. The native audience stays unchanged
when such a partner is added or expires. Keep machine/native mappings unchanged
unless separately approved. Do not infer admin rights from directory groups. Deploy the
compatible parser before introducing new member fields, preserve the production
variable-group owner, and keep its JSON within the 4,096-character limit.

The approved P7 pilot uses immutable `core/studio-operations-p7-pilot`, copied
from the reviewed Intake configuration with only Kapiteky’s `infuse-core` app
grant added. Deploy the compatible pilot code/operations mount first. After
that release is healthy, update the existing secret `STUDIO_CONFIG_JSON` through
its Azure owner and project the identical root membership settings to
`core/studio-settings`; these membership-only settings support live reload.
Then use the supported Company floor command. This ordering avoids presenting
new member fields to older code and never requires a second database writer.

### Company runtime sources

The [source manifest](company-signals.p7.json) defines three Company-only runtime
sources for Studio, Artifact Registry and Files antivirus. Existing RBAC
allows GET of the three named deployments and LIST of core pod specs/status.
The adapter selects exact deployment labels.

The cleanup operations revision is `core/studio-operations-gitlab-cleanup-v1`.
Derive it from the mounted GitLab expansion settings by removing the retired
Azure pipeline sources, legacy Floor Setup mappings and per-repository Azure
credential references. Check that the GitLab
bindings, live runtime sources and other settings match before switching the
mount. Verify fresh runtime observations and non-Company direct-request denial.
The previously mounted revision can still be used to recover configuration.
See the [release and qualification record](../../docs/plans/active/025-backoffice-consolidation/p7-release-source-access-proof.md).

### Approved Fito admin qualification

The October 21 owner approval adds `infuse-admins` to Fito's existing trusted
Studio policy and retains `infuse-core`, the exact identity binding and expiry
**2026-10-27 at 12:00 UTC**. The [bounded mapping](p7-fito-admin.json) identifies
both protected configuration digests; no subject, token or raw settings are
tracked. Stage immutable `core/studio-operations-p7-fito-admin` from the exact
seven-source `studio-operations-p7-swarm` settings, changing only Fito's groups.
The values mount activates it through reviewed main delivery. Do not renew the
pilot, change other identities or infer further directory-group grants.

This enables the existing artifact audit/purge and Monitoring admin controls
within current project admission, plus the Authentik launcher. Verification is
read-only: inspect the existing recovery artifact and its original two receipts.
Do not purge, release alerts or switch the sender. Preserve all seven sources,
shadow delivery, project-scoped lifecycle credentials and Backoffice jobs.
Rollback only this mapping through a reviewed release restoring
`studio-operations-p7-swarm`; retain the sole writer and all content/observations.
See [P7 admin/publisher qualification](../../docs/plans/active/025-backoffice-consolidation/p7-admin-publisher-qualification.md).

## Whiteboard agent MCP access (disabled until activation)

The optional `studio-whiteboard-mcp` Secret mounts public signer keys and exact
agent/project bindings at `/etc/studio-whiteboard-mcp/config.json`. The protected `STUDIO_FLOORS_CONFIG` file may own `whiteboardAgents` and the
`whiteboardMcpConfigFile` reference, avoiding the full Azure root variable. Root
and floor files cannot both own either setting; inline MCP configuration cannot
coexist with the file reference. A configured reference enables the three private machine read routes;
there is no default grant. Added bindings require application restart, while
revocation is checked live. Preserve existing human machine configuration.

POST `/whiteboard/mcp` on the existing private Studio TLS listener proxies only
that exact path to the separate Infuse MCP composition. The public listener denies
it explicitly; the human MCP catalog is not exposed. This reuses enrolled agents'
existing TLS trust and requires the MCP-side paired NetworkPolicy/service release.
See [activation order and qualification](../../docs/plans/active/020-collaborative-whiteboard/agent-access-rollout.md).
The Chromium renderer and all shared-VM host changes remain deferred.


## October 22: P7 live monitoring handoff

The owner approved enabling Studio delivery and waived historical reconciliation.
The source now selects `studio-operations-p7-live-delivery` and the dedicated
`studio-monitoring-delivery-runtime` environment reference. Stage them only after
the paired reviewed Backoffice release removes the health-alert credential binding
and no active old job/pod retains it. The configuration changes only
`monitoring.delivery`: `live`, destination `monitoring`, environment reference
`STUDIO_MONITORING_WEBHOOK_URL`, a fresh ownership epoch/receipt and the actual
verified Backoffice grant-removal instant. Preserve all other settings exactly.

Reuse the existing protected monitoring webhook; keep its value in memory and
Kubernetes Secret storage, never in source/evidence/logs. Removal of Backoffice's
runtime binding is the grant revocation; the webhook itself is not rotated.
All six Backoffice schedules remain running, with its health webhook explicitly
empty. The old unused Secret is retained pending approved retirement cleanup.

Do not release, dismiss or manufacture coverage for historical shadow records.
New incidents and their recoveries follow normal live delivery; an old shadow
incident and its recovery remain unsent without an explicit later disposition.
Re-read live config/parser, check membership/expiry/source equality, inspect
Backoffice credential bindings and verify transport outcome before claiming
activation. A successful pipeline alone is insufficient. Roll back to the prior
shadow configuration through reviewed main, then settle in-flight sends before
any Backoffice sender restoration. See the
[retirement execution plan](../../docs/plans/active/025-backoffice-consolidation/p7-retirement-execution.md).


## PostgreSQL selection

The protected `STUDIO_STORAGE_CONFIG` file is a separate configuration source;
root `storage` and this file cannot coexist. Production requires explicit
PostgreSQL selection; an absent or empty selector fails before opening central
files. Only non-production development and synthetic fixtures retain SQLite.
Production selects PostgreSQL with `backend`,
`connectionEnv: STUDIO_POSTGRESQL_URL` and `caFile: /etc/studio-storage/ca.crt`.
The app receives only its runtime role and public CA. Missing/invalid settings
fail closed; changing storage on a running process requires restart. The source
writer must be stopped and whole-store import/parity verified before activation.
After PostgreSQL accepts writes, never restore the SQLite configuration.
The October22 cutover is active; see the [cutover review](../../docs/plans/active/026-postgresql-migration/review-p3-cutover.md).
The migration role is disabled for login after import. A future schema migration
requires its reviewed operator procedure; the runtime role cannot perform DDL.

P4 retained `studio-studio-data` with `helm.sh/resource-policy: keep` and
`persistence.enabled: true`, but removed its backend mount. The October24 Knowledge
repair restores `mountPrimary: true`: the three registry consumers still require
their durable anti-replay checkpoints. The October28 remediation mounts the same
retained claim at `/var/lib/studio-policy`, with all three consumer paths changed
together. This changes only the mount destination: no file copy, bootstrap, new
epoch, history import or checkpoint reset occurs. Keep the
existing claim and checkpoint bytes; a fresh volume, `emptyDir` or `/tmp` would
lose replay protection. The transport sidecar must not mount this state. See the
[repair evidence and release checks](../../docs/evidence/2026-10-24-floor-knowledge-storage.md)
for local verification and the separate deployment status. Do not disable
persistence or remove the claim implicitly. After retirement, the user explicitly
authorized deletion of only `missions.sqlite` and `sessions.sqlite`; both were
hash-verified and deleted without a restart. Migration and registry files on the
claim remain untouched; see the [cleanup receipt](../../docs/plans/active/026-postgresql-migration/retired-sqlite-deletion-2026-10-22.json). No source copy/backup was created. Raw
legacy path keys can remain inert in the protected root configuration for an
older compatible PostgreSQL rollback binary. They are absent from the current
effective configuration. Never clear the PostgreSQL selector, change production
to a development environment, or use those paths as a fallback.

Rollback retains the current PostgreSQL schema, realm, credentials and one
writer. P4's historically verified schema32 application image was
`registry.infuse-ai-tech.party/studio/studio@sha256:ca4075d0e2df457a1f14c447fc0df7197098f5e3ffaa5974cb5c623a00d4870a`
(PR4131/main10380); assess compatibility with the deployed schema before selecting
any rollback. Prefer a reviewed application revert that retains the registry
checkpoint mount. Reconcile uncertain command/transport receipts before any
retry; do not rerun the importer. Backups, snapshots and restore rehearsals remain
paused. See the [P4 review](../../docs/plans/active/026-postgresql-migration/review-p4-retirement.md)
for exact qualification and release status.

The October 23 review repair prepares schema 33 locally. Before publishing that
writer, complete the separately reviewed [forward release prerequisites](../../docs/plans/active/032-review-repairs/schema33-rollout.md).
The schema 32 image above is a **pre-upgrade** rollback reference only; after schema 33,
retain a schema 33-compatible writer or make a reviewed application revert that still
supports schema 33. Never downgrade the schema or remove the new control projection.


### Backoffice retirement continuity (October 22)

The owner approved retiring the Backoffice application and its six collectors,
deleting its dedicated data, and preserving the repository with deployment disabled.
`studio-operations-p7-backoffice-retired` supersedes the live-delivery reference.
The only semantic difference is `enabled: false` for check
`cmpzd4r45000hwi15lx6pq6cq`, the Backoffice `/login` probe. The exact digest is
`55d97ebd3acb24ee8f9b1e5fd11d36433fc1d29402730bd267716c3cf9409af0`.
All other 54 checks, seven Company sources, agent telemetry, scopes, pilot expiry,
and live delivery ownership remain unchanged. Roll this reference out before
stopping Backoffice, and verify the canonical runtime parser and actual UI/API.
This change does not remove imported/native Studio data or shared Registry data.

### Monitoring catalog cleanup (October 22)

After Backoffice retirement, the catalog is reconciled against current runtime
metadata rather than treating old DNS failures as current service incidents.
The [follow-up record](../../docs/plans/active/027-platform-service-ownership/monitoring-cleanup.md)
lists exact removals, replacement health coverage, disabled checks and preserved
storage/compatibility names. The immutable reference
`studio-operations-monitoring-catalog-v1` is prepared by
`scripts/prepare-monitoring-catalog.py` against its pinned base/candidate digest.
Stage only that reviewed reference before the main release; no database or alert
receipt mutation is involved. Backoffice/Oleagut groups are absent from the
current catalog, while disabled source history remains inspectable. The earlier
55-check/system mapping above records the original migration, not this catalog.


### Ongoing member apps and registry release acceptance (October 28)

Regular member entitlements use explicit `access: "ongoing"` and no `validUntil`.
They require current workspace membership plus the exact issuer/subject/profile
and app groups. Removing membership, entitlement or groups takes effect on guarded
reads; malformed policy fails closed. Legacy dated launcher/guest grants still
expire. Login sessions, credential rotation and registry leases retain their normal
expiry. App grants are reloadable protected policy, alongside membership.

`infrastructure/production/ongoing-app-access.json` pins the prior operations digest,
exact Fito identity, existing groups and proposed immutable candidate. Run
`python3 scripts/prepare-ongoing-app-access.py` to prepare and validate in memory;
`--stage` creates only `studio-operations-ongoing-members-v1`. The reviewed main
Helm values select that reference. Do not mutate the previous immutable reference
or change Kapiteky's expired pilot. The source manifest and immutable Kubernetes
reference own this change; root `STUDIO_CONFIG_JSON` does not own `apps`.

Before merge run `task verify`, the Activity/My Apps browser suites, and
`node scripts/registry-storage-container-proof.mjs`. The last proof uses synthetic
policies, UID1000, read-only root, a persistent directory, independent container
starts and rejection of older revisions. The standard Helm gate must retain
`studio-studio-data` with a writable backend-only `/var/lib/studio-policy` mount.
Startup in bindings-only mode refuses missing, unreadable or invalid retained
checkpoints before opening the writer; it never bootstraps an empty replacement.

The earlier Azure release pipeline ran `scripts/registry-capability-check.mjs`
inside the ready Studio container under its deployment lock after checking the
exact image digest. The checked-in GitLab pipeline does not establish that this
acceptance check runs; verify it separately before accepting a release. It uses
the existing workload network identity;
no separate pod, network permission or credential grant is created. The script
reads only consumer policies, bindings and checkpoints, never database credentials.
Failure blocks release acceptance and leaves the ready workload for diagnosis. Operators can repeat `node scripts/registry-capability-check.mjs`
inside Studio, then verify signed-in Activity/My Apps flows. The canary authenticates all three registry consumers, validates policies
against retained checkpoints and checks contribution bindings without installing
policies, changing receipts or opening another mission writer. It emits only safe
status categories and returns nonzero on failure. This is a release acceptance
check, never a liveness probe that restarts the writer during upstream outages.
Runtime warnings use bounded `registry_policy_failed` / `contributions_policy_failed`
categories; investigate the protected configuration and mount rather than exposing
credentials or raw provider responses in logs.

Rollback must keep matching image/config paths on the same retained claim and the
current PostgreSQL writer/schema. Reverting the app-access parser also requires a
reviewed compatible configuration reference; it cannot parse ongoing grants.
