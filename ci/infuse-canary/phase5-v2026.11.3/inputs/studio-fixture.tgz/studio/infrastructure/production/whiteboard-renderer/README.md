# Whiteboard renderer production release

October 22 scope: **both Chromium and the proposed SVG-to-PNG agent renderer are deferred**.
Prioritize structured board data and companion dogfood. Retained setup/qualification
instructions below are conditional reference; they do not authorize host changes
or renderer activation. [Current decision](../../../docs/plans/active/020-collaborative-whiteboard/renderer-options.md).

Status: **Deferred by Fito; do not execute host setup or register/deploy this pipeline.** Updated 2026-10-21.
The shared VM must remain untouched. [Decision and alternatives](../../../docs/plans/active/020-collaborative-whiteboard/renderer-options.md)
supersede the earlier setup approval; the procedure below is retained design material.
This is a separate stateless release in `core`, not a Studio sidecar.
[Renderer contract](../../../apps/whiteboard-renderer/README.md) is located at
`apps/whiteboard-renderer/README.md` from the repository root.

## Reviewed application package

- The earlier renderer pipeline has been retired. No replacement release path is
  configured; any future delivery requires a separately reviewed pipeline and
  host qualification below.
- `values.yaml` uses one non-root container, `Recreate`, a private ClusterIP,
  zero egress and only same-namespace Studio ingress. It mounts only a 512 MiB
  memory-backed temporary directory. No database, Registry/native credentials,
  service-account token, public ingress or host mount is present.
- The image supplies its own init process to reap terminated Chromium children.
  The listener refuses missing no-new-privileges, seccomp filtering, zero effective
  capabilities, UID 10001 or a visible cgroup PID ceiling between 32 and 256.
  Startup failure is intentional; do not disable these checks to make it ready.
- The node selector `studio.infuse-ai.com/whiteboard-renderer-sandbox=v1` is an
  operator qualification marker, not a substitute for those checks. No current
  production node has been qualified or labeled by this work.

## Platform prerequisite and maintenance boundary

The operator inspected `n1.infuse-ai.com`: Ubuntu 24.04.3, Linux 6.8.0-85,
MicroK8s 1.34.9, containerd 1.7.29 and cgroup v2. The actual kubelet root is
`/var/snap/microk8s/common/var/lib/kubelet` (`/var/lib/kubelet` is a symlink).
The default `cri-containerd.apparmor.d` profile is enforcing. The earlier
approval for a renderer-specific runtime and possible containerd restart was
superseded by the October 21 deferral. No host commands are to be run under the
current decision. These observations are not an actual renderer sandbox proof.

Kubernetes [does not support a per-Pod PID field](https://kubernetes.io/docs/concepts/policy/pid-limiting/).
Infrastructure's prepared `scripts/studio_renderer_runtime.py` clones existing
runc settings into `studio-whiteboard-renderer-v1` with a container-level PID
ceiling of 256. It preserves the default runtime, global limits and AppArmor.
The infrastructure branch `codex/studio-renderer-runtime` owns the helper,
rollback, RuntimeClass and opt-in chart support; its
`k8s/studio-whiteboard-renderer/README.md` gives the operator procedure.

**Release remains blocked:** a future renderer delivery must use reviewed
RuntimeClass support and assert the rendered Deployment contains
`runtimeClassName: studio-whiteboard-renderer-v1`. The startup guard remains the
fail-closed check.

Prepare with the infrastructure owner, following its
`docs/runbooks/kubernetes-lifecycle-and-certificates.md` maintenance contract:

1. Inspect the node's actual kubelet/containerd version, cgroup mode, seccomp root,
   current runtime configuration, process capacity and affected workloads through
   the approved host access path. An API permission denial is not permission to
   install a privileged host-reading pod or change RBAC.
2. Select a narrowly scoped runtime or dedicated-node configuration, record the
   exact files and restart requirement, assess the shared-node interruption, and
   obtain infrastructure-owner approval and a maintenance window before changes.
   Do not apply an arbitrary global `podPidsLimit=256` to existing workloads.
3. Install the compiled OCI profile `seccomp-amd64.json` in this directory at
   the node's kubelet seccomp root under `profiles/studio-whiteboard-renderer-v1.json`.
   SHA-256: `15d73567dda5c61d3fd50d8a80b14db7535034961179048270f314633306503c`.
   Generate it with `node scripts/export-whiteboard-seccomp.mjs amd64 6.8
   infrastructure/production/whiteboard-renderer/seccomp-amd64.json`.
   Never install the Docker fixture directly: containerd does not evaluate Docker
   capability/architecture conditions. This export resolves them for amd64,
   Linux 6.8 and zero outer capabilities, preserving syscall argument constraints.
   Preserve the provenance and license in `tests/fixtures/whiteboard-renderer-seccomp.md`
   and its adjacent license file. Use RuntimeDefault AppArmor; an actual pod proof
   must establish Chromium user-namespace support without weakening that policy.
4. Run a disposable exact-image proof: sandbox enabled, startup guard passes,
   benign render returns PNG, CPU/deadline and cancellation leave no children,
   subsequent render succeeds, and outbound DNS/network access fails. Qualify on
   production's amd64 architecture; the local ARM image is not that evidence.
5. Label only the proven node, then use a separately reviewed renderer
   delivery path. Confirm the immutable image, single ready replica, absence of secret
   and host mounts, actual NetworkPolicy enforcement, and Studio-only ingress.
6. Set `whiteboardAgents.rendererUrl` only after that release succeeds and recheck
   exact-revision rendering through Studio. Keep agent access disabled until the
   plugin, delegation and credential gates also pass.

Rollback removes the qualification label and disables the renderer URL/access
before reverting the stateless renderer release. Platform configuration rollback
uses the approved exact configuration revision and maintenance procedure. No
Studio database backup, snapshot, restore or schema downgrade is involved.

## Local verification

Render these values using the pending infrastructure chart with RuntimeClass
support, then inspect ServiceAccount, Deployment, Service and NetworkPolicy
alongside the platform-owned RuntimeClass. The earlier pipeline pin does not
include that support. Run:

```sh
node --test tests/whiteboard/renderer-runtime.test.mjs tests/whiteboard/renderer-seccomp.test.mjs
docker build --target whiteboard-renderer -t studio-whiteboard-renderer:w53 .
node scripts/studio-whiteboard-renderer-http-smoke.mjs
node scripts/studio-whiteboard-renderer-abuse.mjs
```

The HTTP smoke uses the image's own init. Also verify that missing PID limits or
no-new-privileges prevent the listener from starting. Local fixtures do not prove
production network policy, node admission or deployment.

The two disposable suites also accept `STUDIO_RENDERER_SECCOMP_PROFILE` to test
the compiled OCI policy. On an ARM development machine, generate an ARM policy
with the same exporter (`arm64 6.8`) and use that absolute path. ARM qualification
proves only local behavior; the committed amd64 profile still needs the host proof.
