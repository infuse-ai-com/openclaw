# Studio Gateway connection profiles

The production authority stays in `core/studio`. Emon, Tinus, Stewie and Satwa
retain their own `agents-swarm` Pods, PVCs, ordinary tools and native Mattermost
connections. Connection direction is **Gateway plugin → Studio**; no new inbound
Gateway RPC port is exposed. The
[native rollout](../../docs/plans/archive/010-native-mattermost-missions/rollout.md)
owns activation order and required-owner protection. This document describes
transport profiles; earlier two-Gateway connectivity evidence does not prove
four-role native execution.

## Production: same-cluster TLS

`https://studio-bridge.core.svc.cluster.local/api/bridge/v2` resolves through
Kubernetes DNS to the private `studio-bridge:443` Service and proxy port 8443.
Caddy verifies the incoming hostname and forwards to `127.0.0.1:4321` with the
public Studio Host. Browser HTTPS remains `https://studio.infuse-ai.com` through
Traefik and proxy port 4320. The browser proxy rejects machine paths; the private
proxy rejects browser API paths. Neither transport supplies human identity.

The Studio NetworkPolicy permits 8443 only from `agent-coordinator`,
`agent-developer`, `agent-designer` and `agent-infra` in `agents-swarm`.
Existing Gateway policies restrict ingress;
no broad agent egress, Tailscale ACL, cluster DNS or Gateway ingress change is
needed for the production path. Workstation RBAC cannot inspect core policies;
the normal Studio pipeline owns policy application. Actual Pod requests must
prove the rendered policy works before declaring the Gateways connected.

`studio-bridge-tls` holds a certificate with the exact Service DNS SAN and its
private key. The private key is mounted only in Caddy. Each Gateway gets the
public certificate in its own `agent-*-studio` Secret and configures
`studioCaFile: /var/run/studio/ca.crt`. Trust is restricted to the Studio HTTP
client, without `NODE_EXTRA_CA_CERTS` or disabling certificate verification.
Use a 90-day certificate; replace the trust bundle with old+new certificates,
roll the enrolled clients, replace the server certificate/restart Studio, verify, then
remove the old trust. Alert/renew before expiry; do not silently rotate it during
an unrelated deploy.

Azure variable group `studio-production` retains the existing configuration and
OIDC client secret, and adds `STUDIO_BRIDGE_TLS_CERT`, `STUDIO_BRIDGE_TLS_KEY`,
`STUDIO_COORDINATOR_BRIDGE_TOKEN`, `STUDIO_DEVELOPER_BRIDGE_TOKEN`,
`STUDIO_DESIGNER_BRIDGE_TOKEN` and `STUDIO_INFRA_BRIDGE_TOKEN`. The pipeline
creates its TLS Secret and puts the four distinct random 256-bit tokens only in
the backend environment. Each Gateway receives only its own bridge token.
No private material is checked in.

Studio's immutable image also contains the built plugin at `/opt/studio-plugin`.
The swarm image copies that directory from an exact Studio image digest to
`/opt/openclaw-plugins/infuse-studio`. Its package manifest and built workers are
retained. The image installs the package's runtime dependencies before the swarm's
managed installer fingerprints and copies the complete directory. Only
the four enrolled roles add the plugin to required packages, scoped capability
consent, and OpenClaw configuration through the native cutover overlay.
The local Gateway connection stays authenticated `ws://127.0.0.1:18791`.

## Local: Studio backend on the Mac through Tailscale

Use a separate authority `studio-local-mac`, separate SQLite files, separate
bridge tokens, and `journalNamespace: local-mac`. Production uses
`journalNamespace: production`. Journals remain fenced by exact origin,
authority, Gateway ID and enrollment generation; namespace selection never
makes a journal valid for another authority. Do not copy production databases
or discard a journal to switch environments.

The intended local origin is `https://macs-mac-mini.tailc4f8d5.ts.net:8443`.
Run a real OIDC-backed Studio backend on loopback behind Tailscale Serve on that
port. Register its exact `/api/auth/callback` URI with the development OIDC
client. Keep the synthetic `workspace:preview` service on localhost separate.
Tailscale Serve provides HTTPS; Funnel/public exposure is not required.

After creating the real local OIDC configuration and supplying its credential
references to the backend process, the run commands are:

```sh
HOST=127.0.0.1 PORT=4324 STUDIO_CONFIG=/absolute/path/to/local-studio.json \
  node apps/backend/dist/main.js
tailscale serve --bg --https=8443 http://127.0.0.1:4324
# Remove only this binding after the local session:
tailscale serve --https=8443 off
```

The commands do not create the OIDC client, tokens, databases or Gateway profile.
Keep those explicit and use the local profile's distinct identity before enabling
admission. The existing localhost preview on 4322 is not this environment.

The current Mac Tailscale address is `100.66.41.78`; re-resolve it from Tailscale
status before use. Cluster DNS does not currently resolve the Mac's MagicDNS
name. A Gateway can set `studioConnectAddress` to the verified tailnet IP while
keeping `studioUrl` at the HTTPS MagicDNS origin: the client retains the original
Host, TLS SNI and certificate identity. This is a route override, not an identity
or TLS-verification override. No cluster DNS changes are required. If direct
Pod-to-tailnet routing is unavailable, use a narrowly scoped
[Tailscale operator egress Service](https://tailscale.com/docs/kubernetes-operator/egress/access-tailnet-service)
and preserve the same TLS identity. An ingress/dashboard ProxyGroup is not proof
of a reverse route.

On 2026-10-04 both actual Gateway Pods reached a temporary Tailscale Serve
endpoint on 8443, validated its certificate, and returned the exact distinctive
health response from this Mac. The temporary Serve binding and probe were then
removed. TCP 443 had returned an unrelated self-signed certificate and was not
used. On 2026-10-05, the separate real OIDC backend was prepared and Fito signed
in successfully. All four actual agent Pods passed TLS, anonymous-access denial,
disabled-bridge and exact local OIDC/PKCE redirect checks. The browser session
survived a controlled backend restart. See the
[Mac authentication and transport evidence](../../docs/evidence/2026-10-05-local-mac-authentication.md).
The isolated local enrollment and mission pilot subsequently completed on
2026-10-06. See the [Mac pilot and restoration proof](../../docs/evidence/2026-10-06-mac-tailscale-pilot.md).
Production was restored and enabled, and Mac execution disabled. A future local
session still requires the distinct authority, routes and controlled profile
switch described here; the earlier authentication checkpoint alone was not
mission-execution proof.

One outbound profile is active per Gateway. To switch production ↔ local:
stop admission and settle/reconcile all active Studio runs first, then update
the deployment-owned plugin configuration/Secret references and restart the
affected Gateways through the swarm rollout. Keep both journal directories. Other agents'
ordinary sessions remain independent. Concurrent enrollment in both authorities
is not implemented by this slice.

## Acceptance and stop conditions

1. Render/lint the complete Studio release and run the TLS/journal tests.
2. Test the actual hardened proxy image: browser health succeeds, public bridge
   fails, private bridge forwards, private browser API fails, untrusted TLS fails.
3. Deploy Studio, preserve the production mission/session and verify all enrolled Gateway
   Pods get an authenticated empty claim from the private endpoint without models.
4. Deploy the exact plugin on the enrolled Gateways. Confirm actual pinned OpenClaw build,
   service startup, polling journal progress and authenticated local RPC without
   `chat.send`. Retain source/image/plugin hashes and Pod identities.
5. Verify an unenrolled Pod cannot reach bridge 8443 and public machine requests
   remain denied. Do not start a mission just because health is green.
6. Separately prove the Mac route using real OIDC/TLS and distinct credentials.
   Any ACL, route or identity prerequisite remains explicit until evidenced.

To stop, revoke the enrollment or disable admission in Studio's mounted config,
then reconcile/abort exact active runs before stopping the plugin. Keep the
backend loopback bound; rollback must retain the public machine-path denial and
must not expose the raw backend. Retain PVCs and both profile journals. Once
native routes are registered, retain the patched host and required-owner records;
disabling execution must never restore ordinary-chat dispatch for those routes.
