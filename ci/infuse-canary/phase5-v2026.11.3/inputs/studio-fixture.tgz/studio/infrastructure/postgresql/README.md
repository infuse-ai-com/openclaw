# Dedicated Studio PostgreSQL (P3 hosting)

Current local preparation targets schema 33 and creates the exact migration ledger.
Existing installations need the reviewed [forward release procedure](../../docs/plans/active/032-review-repairs/schema33-rollout.md). The historical qualification below does not prove a schema 33 production upgrade.

This release provisions only Studio's database. The user chose a dedicated
instance, with possible consolidation later. The subsequent C4 cutover retired
central SQLite; PostgreSQL is now the app/auth authority. No Sourcebot or
Backoffice database is used, and no backup/snapshot/restore automation is enabled.

The former database pipeline is retired. GitLab verifies the PostgreSQL image
in merge requests; delivery is blocked until the release path and its database
hosting, TLS, grants, migration and recovery qualifications are reviewed.

PostgreSQL17.11 runs as one non-root replica with Recreate, a distinct retained
10GiB PVC, a private ClusterIP service and no public ingress. Request250m/256Mi,
limit1CPU/1GiB,20 connections. The existing cluster reported12 allocatable CPUs,
about126GiB memory and407GB free on Studio's storage filesystem; those are capacity
observations, not reserved quota or HA. Hostpath storage survives pod restarts but
remains tied to its node. Helm retains the PVC; operators must not delete it.

`studio` is the only application database. `studio_owner` has no login;
`studio_migrator` owns migration through membership and has no cluster-wide role
administration; `studio_runtime` gets only current domain DML, auth session/login
DML, realm reads and writer-epoch columns. It cannot alter schema, authority,
activation mode or import receipts. There is one runtime writer connection.
The PostgreSQL administrator authenticates only through the pod-local Unix socket.
Network HBA permits only TLS/SCRAM connections to Studio by the two scoped roles.
NetworkPolicy accepts database traffic only from Studio and its import job.

Provision passwords and a Studio-only TLS CA/server certificate through the
approved secret owners before pipeline execution. The certificate SAN must match
`studio-postgresql.core.svc.cluster.local` (and any explicitly used shorter service
names). Keep the CA private key in Vaultwarden; only the server key reaches the
database pod. Mount only the CA certificate and runtime connection environment
into the application at cutover. The migration credential belongs only to the
one-shot operator job; disable its login after acceptance until an approved future
migration. Record certificate expiry/rotation ownership in the live receipt.

`init-studio.sh` runs only for an empty PGDATA. It creates the schema and an inactive
authority ledger bound to `studio-production`; upgrades never rerun bootstrap or
adopt unknown data. Existing data requires explicit versioned migration. The
hosting proof uses the same init/HBA/config/grants with ephemeral credentials and
certificates, denies unauthorized access, provisions synthetic PostgreSQL state and
verifies exact command replay and browser auth using the restricted runtime role.

Historical P3 cutover gates, completed by C4 in plan026: current runs and
uncertain effects reconciled, maintenance window recorded, source writers stopped,
direct import and whole-store parity verified, target activated exactly once.
After PostgreSQL accepts writes, rollback uses a compatible PostgreSQL release.
Retain the original SQLite source without restarting it or calling it a recovery
point. P4 records production behavior and retires central production compatibility.

Schema32 refresh: the prepared init schema and explicit role grants cover all67
central stores, including companion conversations/turns and agent updates. The
required hosting proof exercises exact imported records and new writes under the
restricted runtime role. This was the pre-cutover hosting qualification; the C4 receipt supersedes its hold.

Historical P3 live qualification on2026-10-22: dedicated pipeline125/build10368, Helm revision1,
reviewed main6a6698b. TLS/roles, allowed/denied networking and retained-volume pod
replacement passed. At that time the database was empty and inactive at epoch0, before the PostgreSQL cutover. Read [the live receipt](../../docs/plans/active/026-postgresql-migration/p3-live-qualification-2026-10-22.json)
for exact image, Vaultwarden references, certificate renewal and storage limits.
Helm metadata uses `HELM_DRIVER=configmap`. No backups, source copy or activation
was performed by that P3 qualification. See [C4](../../docs/plans/active/026-postgresql-migration/review-p4-retirement.md) for the later cutover and retirement.
