#!/usr/bin/env bash
set -euo pipefail
# Called only by the official entrypoint on a fresh, empty Studio data directory.
# Credentials are mounted files; do not echo them or enable shell tracing.
export STUDIO_RUNTIME_PASSWORD="$(cat /run/studio-postgresql-secrets/runtime-password)"
export STUDIO_MIGRATION_PASSWORD="$(cat /run/studio-postgresql-secrets/migration-password)"
: "${STUDIO_RUNTIME_PASSWORD:?runtime password is required}"
: "${STUDIO_MIGRATION_PASSWORD:?migration password is required}"
: "${STUDIO_AUTHORITY_ID:?authority identity is required}"
psql --username "$POSTGRES_USER" --dbname postgres --no-psqlrc --quiet --set ON_ERROR_STOP=1 <<'SQL'
\getenv runtime_password STUDIO_RUNTIME_PASSWORD
\getenv migration_password STUDIO_MIGRATION_PASSWORD
\getenv authority_id STUDIO_AUTHORITY_ID
CREATE ROLE studio_owner NOLOGIN;
CREATE ROLE studio_runtime LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 4 PASSWORD :'runtime_password';
CREATE ROLE studio_migrator LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 2 PASSWORD :'migration_password';
GRANT studio_owner TO studio_migrator;
CREATE DATABASE studio OWNER studio_owner TEMPLATE template0 ENCODING 'UTF8' LC_COLLATE 'C' LC_CTYPE 'C';
REVOKE ALL ON DATABASE studio FROM PUBLIC;
GRANT CONNECT ON DATABASE studio TO studio_runtime,studio_migrator;
\connect studio
REVOKE ALL ON SCHEMA public FROM PUBLIC;
SET ROLE studio_owner;
\i /opt/studio/032-studio.sql
\i /opt/studio/033-literal-controls.sql
INSERT INTO studio_storage(singleton,authority_id,schema_version,mode) VALUES(true,:'authority_id',33,'inactive');
CREATE TABLE studio_schema_migrations(version integer PRIMARY KEY,file text NOT NULL,sha256 text NOT NULL,applied_at timestamptz NOT NULL DEFAULT clock_timestamp());
INSERT INTO studio_schema_migrations(version,file,sha256) VALUES(32,'032-studio.sql','066f82e8e0d28dc35598581d90edfc3833bfae7a9d2597b108ec00abfb65bef6');
INSERT INTO studio_schema_migrations(version,file,sha256) VALUES(33,'033-literal-controls.sql','68cb638cc63338cc5f6681c98cc110e2802874fd3016a17c9d514cccbcb0262a');
\i /opt/studio/032-runtime-grants.sql
SQL
unset STUDIO_RUNTIME_PASSWORD STUDIO_MIGRATION_PASSWORD
