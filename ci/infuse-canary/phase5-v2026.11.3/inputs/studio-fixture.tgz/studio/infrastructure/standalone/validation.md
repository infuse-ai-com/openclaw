# Local deployment-package validation — 2026-10-04

Validated the deployment files in this change against application source
`c4f4a6009d0b1efc0600732ed2f885ae7d6bfef2`. Docker Desktop 4.93.0 / Engine
29.8.1 built and ran **Linux arm64** containers locally. Nothing was published
or deployed; the existing Studio preview on port 4322 was untouched.

| Local artifact | Digest reported by Docker |
| --- | --- |
| `studio:deployment-validation` | `sha256:0fcfa7aba4cdb98ce3241d2bff835577278d05bf708a0759681b5613e1bd9336` |
| `studio-proxy:deployment-validation` | `sha256:c51d6bec703e51931a2ff4393681213fc36dae4b43eff9f6a0cf44947f643ada` |

Both Dockerfiles pin their upstream base-image digests. These local validation
image references are evidence, not published release images.

## Checks and results

- Both images built successfully. The production npm workspace installation
  resolved `@studio/contracts` and `@studio/server` correctly without dev packages.
- The actual `apps/backend/dist/main.js` entrypoint ran as UID 1000, with external
  networking disabled, a read-only root filesystem, all Linux capabilities
  dropped and privilege escalation disabled. Its sole writable state was
  disposable tmpfs, not a production volume.
- A mounted test-only OIDC issuer completed signed code/PKCE login. The container
  created one synthetic draft; mission and browser session survived an authority
  process restart. Dispatch stayed disabled, and both SQLite files had mode 0600.
- All **28** built frontend files were requested over HTTP and matched their
  on-disk bytes, including regenerated fonts and assets. HTML SHA-256:
  `d39902bda10aa924499adbd479d69640674124c001a29582576563cadf0d4294`.
- Caddy 2.11.6 validated the checked-in configuration with a disposable certificate
  under the same UID/read-only/capability restrictions. A second proof ran proxy
  and test upstream in one externally isolated network namespace: HTTPS
  certificate/hostname verification succeeded, the upstream saw peer
  `127.0.0.1` and Host `studio.example.invalid`, and returned 200. No TLS bypass
  was used. Both disposable containers were removed afterwards.
- Local `kubectl kustomize`, configuration parsing, plugin-manifest schema checks,
  enrollment/target matching, disabled-default checks, JavaScript syntax and
  `git diff --check` passed.

The proxy proof found and fixed two packaging faults: the upstream image has no
`ENTRYPOINT`, and its binary's `cap_net_bind_service` file capability prevents
execution with the capability bounding set empty. The deployment now specifies
`command: [caddy]`; `Dockerfile.proxy` removes the unnecessary file capability.

## Reproduce the application container smoke

From the repository root, with Docker Desktop running:

```sh
docker build --tag studio:deployment-validation --file Dockerfile .
docker build --tag studio-proxy:deployment-validation --file infrastructure/standalone/Dockerfile.proxy .
docker run --rm --network none --read-only --cap-drop ALL \
  --security-opt no-new-privileges \
  --tmpfs /tmp:uid=1000,gid=1000,mode=700 \
  --tmpfs /var/lib/studio:uid=1000,gid=1000,mode=700 \
  --mount "type=bind,source=$(pwd)/infrastructure/standalone/container-smoke.mjs,target=/app/validation/container-smoke.mjs,readonly" \
  --mount "type=bind,source=$(pwd)/tests/fixtures/standalone-oidc.mjs,target=/app/validation/standalone-oidc.mjs,readonly" \
  studio:deployment-validation node /app/validation/container-smoke.mjs
kubectl kustomize infrastructure/standalone
```

The fixture and smoke script are mounted only for this test; neither enters the
production build context. They do not use real accounts, Gateway credentials,
model APIs or saved local Studio state. The checked-in smoke prints only a compact
result, never cookies or tokens.

For the proxy configuration check, create a disposable certificate for
`studio.example.invalid`, then run the built proxy with the checked-in Caddyfile
and that certificate directory mounted read-only at `/etc/caddy/Caddyfile` and
`/etc/studio-tls`. Use the same restrictions above, omit the Studio state tmpfs,
and run `validate --config /etc/caddy/Caddyfile --adapter caddyfile`. The private
test key is intentionally not retained in this repository.

## Evidence identifiers and limits

Relevant file SHA-256 values:

```text
b0e7f048ddf6cef6529ee30fcfac6a31ac2fee93dbed0b74fb165059a3105d34  Dockerfile
f2860fed18cda81c0a6a9bc4c261c36b5f3c25d181ddcf99b69fce6864d36bf4  .dockerignore
3cf002daaa057f5d987a563b370dc6aecdda3b48fcce41aa2e96d3db0bc4d462  infrastructure/standalone/Dockerfile.proxy
8a0732e872a80ecb6fe3eb61f4134567f5109b66887bc93dafdd53ad09eb5379  infrastructure/standalone/Caddyfile.example
d33338d0f9e8509b563f565ee6730b2c4f1987129e7d67a0b63640c4b387b537  infrastructure/standalone/deployment.yaml
f3c1d5065df122905fc72381ef3e8a1a296914f8b19a162a37e244a6ade61bd6  infrastructure/standalone/healthcheck.mjs
d72415fcfb1dee16d9ff29ea9c1afb3f1c35ece9dd08ba4f2098f1f7c9e40c72  infrastructure/standalone/container-smoke.mjs
```

Local working evidence is under `/tmp/studio-container-validation/`:
`studio-build.log`, `studio-smoke.json`, `proxy-validation.log` and `rendered.yaml`.
It is disposable supplementary evidence; this record contains the retained
results. The separate proxy HTTP proof used a synthetic upstream, not a real
production authority.

This does **not** verify amd64 execution, Kubernetes admission/scheduling, PVC
ownership or rescheduling durability, production OIDC, real DNS/certificates,
Gateway-Pod-to-Studio routing, fleet plugin enrollment or remote mission
execution. Those remain explicit rollout checks in the [runbook](README.md).
