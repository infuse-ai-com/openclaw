import { readFileSync } from 'node:fs';
import { get } from 'node:http';

try {
  const config = JSON.parse(readFileSync(process.env.STUDIO_CONFIG, 'utf8'));
  const origin = new URL(config.origin);
  const port = Number(process.env.PORT || 4321);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw Error('Invalid port');
  // Fetch replaces Host with the loopback destination. The native client keeps
  // the configured public Host required by Studio's origin validation.
  const health = await new Promise((resolve, reject) => {
    const request = get({ hostname: '127.0.0.1', port, path: '/api/health',
      headers: { host: origin.host }, signal: AbortSignal.timeout(4000) }, response => {
      let body = '';
      response.setEncoding('utf8');
      response.on('data', chunk => {
        body += chunk;
        if (body.length > 8192) request.destroy(Error('Health response too large'));
      });
      response.on('error', reject);
      response.on('end', () => {
        try {
          if (response.statusCode !== 200) throw Error('Not ready');
          resolve(JSON.parse(body));
        } catch (error) { reject(error); }
      });
    });
    request.on('error', reject);
  });
  if (health.service !== 'studio' || health.status !== 'ok' || health.mode !== 'standalone') throw Error('Not ready');
} catch {
  // Health output must not expose configuration, cookies or credentials.
  process.exitCode = 1;
}
