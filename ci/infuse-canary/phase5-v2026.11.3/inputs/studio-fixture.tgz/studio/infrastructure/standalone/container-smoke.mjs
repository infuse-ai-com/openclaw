import assert from 'node:assert/strict';
import { readFile, writeFile, readdir, stat } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createHash } from 'node:crypto';
import { createOidcFixture } from './standalone-oidc.mjs';
const origin = 'http://127.0.0.1:4321';
const issuer = await createOidcFixture({ subject: 'container-operator' });
issuer.allowRedirect(`${origin}/api/auth/callback`);
const config = { authorityId: 'container-proof', origin,
 databasePath: '/var/lib/studio/missions.sqlite', authDatabasePath: '/var/lib/studio/sessions.sqlite',
 project: { id: 'studio', name: 'Container validation' },
 targets: [{ gatewayId: 'swarm-coordinator', agentId: 'agent-coordinator' }, { gatewayId: 'swarm-developer', agentId: 'agent-developer' }],
 oidc: { issuer: issuer.issuer, clientId: issuer.clientId, allowInsecureLoopback: true },
 members: [{ issuer: issuer.issuer, subject: 'container-operator', profileId: 'container-operator', approver: true }], bridge: { enabled: false, gateways: [] } };
await writeFile('/tmp/studio.json', JSON.stringify(config));
let child;
let logs = '';
const env = { ...process.env, STUDIO_CONFIG: '/tmp/studio.json', HOST: '127.0.0.1', PORT: '4321' };
async function start() {
 child = spawn(process.execPath, ['apps/backend/dist/main.js'], { cwd: '/app', env, stdio: ['ignore', 'pipe', 'pipe'] });
 child.stdout.on('data', d => logs += d); child.stderr.on('data', d => logs += d);
 for (let n = 0; n < 100; n++) {
  if (child.exitCode !== null) throw Error(`Backend exited ${child.exitCode}: ${logs}`);
  try { const h = await fetch(`${origin}/api/health`); if (h.ok) return; } catch {}
  await new Promise(r => setTimeout(r, 100));
 }
 throw Error(`Backend did not start: ${logs}`);
}
async function stop() { if (!child || child.exitCode !== null) return; child.kill('SIGTERM'); await once(child, 'exit'); }
async function checkHealth() {
 const health = await (await fetch(`${origin}/api/health`)).json();
 assert.equal(health.mode, 'standalone'); assert.equal(health.capabilities.dispatch, false);
 const check = spawn(process.execPath, ['/app/healthcheck.mjs'], { env, stdio: 'ignore' });
 const [code] = await once(check, 'exit'); assert.equal(code, 0);
}
try {
 assert.equal(process.getuid(), 1000);
 await start(); await checkHealth();
 const jar = new Map();
 async function request(path, options = {}) {
  const result = await fetch(new URL(path, origin), { redirect: 'manual', ...options,
   headers: { cookie: [...jar].map(([k,v]) => `${k}=${v}`).join('; '), ...options.headers } });
  for (const item of result.headers.getSetCookie()) { const [key, ...parts] = item.split(';')[0].split('='); const value = parts.join('='); if (value) jar.set(key,value); else jar.delete(key); }
  return result;
 }
 const login = await request('/api/auth/login'); assert.equal(login.status, 302);
 const authorize = await fetch(login.headers.get('location'), { redirect: 'manual' }); assert.equal(authorize.status, 302);
 const callback = await request(authorize.headers.get('location')); assert.equal(callback.status, 302);
 const session = await (await request('/api/session')).json(); assert.equal(session.authenticated, true);
 const paper = { title: 'Container persistence proof', objective: 'Verify the built runtime persists a synthetic draft', acceptance: 'Draft and session survive restart', coordinator: config.targets[0], specialist: config.targets[1] };
 const command = { type: 'create', commandId: 'container-create', missionId: 'container-proof', expectedVersion: 0, paper };
 const created = await request('/api/studio/commands', { method: 'POST', headers: { origin, 'content-type': 'application/json', 'x-csrf-token': session.csrfToken }, body: JSON.stringify(command) });
 assert.equal(created.status, 200, await created.text());
 let staticFiles = 0;
 async function verifyFiles(directory, relative = '') {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
   const childRelative = `${relative}/${entry.name}`;
   if (entry.isDirectory()) await verifyFiles(`${directory}/${entry.name}`, childRelative);
   else { const bytes = await readFile(`${directory}/${entry.name}`); const response = await request(childRelative); assert.equal(response.status, 200, childRelative); assert.deepEqual(Buffer.from(await response.arrayBuffer()), bytes, childRelative); staticFiles++; }
  }
 }
 await verifyFiles('/app/apps/web/dist');
 for (const file of ['missions.sqlite', 'sessions.sqlite']) assert.equal((await stat(`/var/lib/studio/${file}`)).mode & 0o777, 0o600);
 await stop(); await start(); await checkHealth();
 const resumed = await (await request('/api/session')).json(); assert.equal(resumed.authenticated, true); assert.equal(resumed.csrfToken, session.csrfToken);
 const missions = await (await request('/api/studio/missions')).json(); assert.equal(missions.missions.length, 1); assert.equal(missions.missions[0].id, 'container-proof');
 const web = await readFile('/app/apps/web/dist/index.html');
 console.log(JSON.stringify({ status: 'pass', uid: process.getuid(), node: process.version, network: 'none', rootFilesystem: 'read-only', syntheticOidc: true, dispatch: false, staticFiles, persistedMissionAndSessionAcrossProcessRestart: true, htmlSha256: createHash('sha256').update(web).digest('hex') }));
} finally { await stop(); await issuer.close(); }
