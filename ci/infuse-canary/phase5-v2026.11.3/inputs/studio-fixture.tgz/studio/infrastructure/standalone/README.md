# Standalone Studio deployment preparation

For `studio.infuse-ai.com`, use the [production pipeline handoff](../production/README.md).
It follows Backoffice's Traefik pattern and documents the deployed private bridge.
This directory retains the initial, disabled loopback/TLS proxy deployment template.

This directory is a reviewable deployment handoff, not a deployed environment.
All `.invalid` hostnames and `REPLACE_WITH_...` image/client references must be
resolved before rollout. Both bridge enrollment and dispatch start disabled;
the example admits no human members. No Secret values or synthetic OIDC issuer
are included.

The optional [Mattermost fragment](mattermost.example.json) is also disabled.
It supports explicitly bound mission threads and attributed Studio comments;
see [the conversation checkpoint](../../docs/plans/archive/009-studio-openclaw-interaction/conversations.md)
for dedicated-bot ownership, verified member mappings, recovery and rollout limits.

The [local validation record](validation.md) covers the actual container build,
synthetic login/state/asset smoke and isolated TLS-proxy proof, with their exact
platform and remaining rollout limits.

The initial topology is one Studio Pod in `agents-swarm`, with its own persistent
volume. It contains the real frontend and mission authority, plus a local TLS
proxy. Each enrolled agent keeps its existing OpenClaw Pod and PVC.

```text
Browser (private access) ── HTTPS ──┐
                                 ├─ Studio :443 Service → TLS proxy :8443
Gateway plugin (outbound HTTPS) ──┘                         → 127.0.0.1:4321
                                                            Studio UI/API
                                                            missions.sqlite
                                                            sessions.sqlite

Gateway plugin → local ws://127.0.0.1:18791 → its own OpenClaw agent
              → existing agent PVC / OpenClaw service state / studio-bridge/journal.sqlite
```

The backend deliberately accepts machine bridge traffic only from loopback and
does not trust forwarded identity or transport headers. A normal Kubernetes
Ingress pointing directly to the backend's Pod address does not satisfy this
contract. The sidecar shares the Pod's network namespace and preserves the
configured public Host when forwarding to loopback. Only TLS port 443 is exposed
by the Service. The image itself does not listen on the Pod address.

## Reusable swarm infrastructure and missing inputs

Source inspection used `openclaw-k8s-swarm` commit
`0ac4cac4a7970bf9875511a6f98f749e21409271` (`origin/main`), not its older local
checkout. These are source references, not evidence that a Studio deployment or
identity registration already exists.

| Item | Existing source / required decision |
| --- | --- |
| Runtime | The historical release pinned OpenClaw 2026.9.7 from source `b498cfc5b8c7862e4d029346dbebc6eabcf179e4`; use that exact swarm build for the installed-plugin proof. |
| Namespace and image pull | `agents-swarm`; `harbor-pull`; private registry `registry.infuse-ai-tech.party`. The proposed `studio/studio` and `studio/proxy` image repositories must be provisioned/authorized and published separately. |
| Storage | The production overlay uses `microk8s-hostpath`. The example requests a separate 2 GiB claim. Confirm placement, space and UID 1000 ownership. Studio alpha accepts possible data loss; do not add a backup step. |
| Private operator access | Swarm dashboard Services use the Tailscale operator and `openclaw-agent-dashboard-ingress` ProxyGroup. This proves neither a Studio hostname/certificate nor Gateway Pod egress to a Mac-hosted Studio. |
| Human identity | Swarm docs reference Authentik, but no Studio OIDC client, exact issuer, client ID or enrolled human subjects were found. Register a distinct Studio client; do not reuse an agent's Authentik login credentials. |
| Agent targets | Existing IDs are `agent-coordinator` (Emon) and `agent-developer` (Tinus). `swarm-coordinator` and `swarm-developer` in these examples are proposed Studio enrollment IDs, not discovered Gateway runtime identities. |
| Dispatch ownership | Existing SQL mission session-manager and dispatch components appear in the production overlay. Their presence does not establish whether admissions are enabled. Verify their selectors before reserving Studio mission sessions and Mattermost threads. |

Prefer hosting the authority inside the cluster and providing one private HTTPS
origin reachable by both operators and Gateway Pods. Reuse the selected origin
verbatim in Studio, the plugin and OIDC callback registration. The ClusterIP
Service here is only the internal endpoint; this directory intentionally does
not invent a working DNS, certificate or Tailscale routing configuration.

If the authority remains on the Mac, prove the Pod-to-Mac route separately.
Existing Tailscale dashboard ingress and successful Mac-to-Gateway requests are
insufficient. Never publish the `workspace:preview` synthetic identity service
as the real deployment, weaken TLS verification, or set `allowInsecureLoopback`
for a remote connection.

## Build the standalone image

From the Studio repository root:

```sh
npm run check
npm test
docker build --tag studio:local --file Dockerfile .
docker build --tag studio-proxy:local --file infrastructure/standalone/Dockerfile.proxy .
```

The multistage build compiles services, the standalone web app and the plugin,
installs only backend production dependencies in the runtime stage, and runs as
UID/GID 1000.
It does not build the mockup, install OpenClaw, start workers or contain the local
OIDC fixture. The build-context allowlist excludes runtime JSON, credentials,
SQLite files, local state and generated dependency/build directories.

The Node 26.7.0 and Caddy 2.11.6 base images are digest-pinned. The proxy image
removes the official Caddy binary's low-port file capability so it can run on
8443 with **all** Linux capabilities dropped and privilege escalation disabled.
Using the upstream image directly under this policy fails at process startup.
Record the Studio source SHA, both resulting image digests, dependency lockfile
and validation results together. Image publication is a separate action.

## Prepare identity, TLS and persistent state with execution off

Make a deployment-owned copy of this example directory. Resolve these values:

1. Set the same real origin hostname in `studio.example.json` and both occurrences
   in `Caddyfile.example`. The example assumes external HTTPS port 443.
2. Register authorization-code OIDC with PKCE/S256 and exact callback
   `https://<studio-host>/api/auth/callback`. Set the exact discovery issuer and
   client ID. Confidential clients must support `client_secret_basic`; the
   referenced `studio-oidc` Secret must supply key `client-secret`. Public clients
   must be registered as such and omit both `clientSecretEnv` and that environment
   Secret reference.
3. Add explicit `members` entries with the issuer's exact immutable `sub`, a
   stable Studio `profileId`, display name and an explicit `approver` boolean.
   Email, display name and a guessed IdP database user ID are not substitutes
   for a verified subject claim. An empty list intentionally grants nobody access.
4. Provision a valid certificate and private key for the same Studio hostname
   into the `studio-tls` Secret (`tls.crt`, `tls.key`). Pin the built proxy image
   digest in `deployment.yaml`. Certificate issuance, DNS, private
   ingress and network policy belong to the reviewed environment change.
5. Publish/pin the Studio image digest, confirm access to the existing image-pull
   Secret and verify the new PVC can be written by UID/GID 1000. Keep one replica
   and `Recreate`; two authority processes must not share the SQLite directory.
6. Keep `bridge.enabled` and both Gateway `enabled` values false. The disabled
   process cannot be enabled just by a live configuration edit; activation needs
   an intentional restart.

Non-secret examples can be rendered locally without contacting Kubernetes:

```sh
kubectl kustomize infrastructure/standalone
```

Before any rollout, inspect the rendered manifest for unresolved placeholders,
confirm the private entry route and Pod-to-origin route, and complete the scoped
environment review. The swarm repository's `AGENTS.md` requires Fito's approval
for production secrets, access, DNS, Tailscale ACL and firewall changes. This
preparation performs none of those actions.

After the reviewed deployment, first verify `/api/health` over the actual HTTPS
origin reports `mode: "standalone"` and `capabilities.dispatch: false`. Complete
real OIDC sign-in, explicitly deny an unlisted identity, create a draft and
restart the Pod to check that both mission state and browser-session storage
persist. An internal health check alone does not prove HTTPS, authentication or
the Gateway route.

## Package and configure the fleet plugin

The owning repository for these changes is `openclaw-k8s-swarm`. The JSON files
here are **merge fragments**, not replacement OpenClaw configurations. Preserve
every existing plugin allowlist entry, tool grant, persona and ambient agent
setting. Keep the new plugin disabled until its credentials and transport proof
are ready.

1. Build `npm run build:plugin` from the same reviewed Studio revision, then
   `npm pack --workspace @infuse-ai/openclaw-studio --pack-destination /tmp`.
   Record the archive SHA-256 and inspect its contents. The existing package
   includes the built plugin, SQLite journal worker, manifest and license files.
   A local archive has not been published merely because `npm pack` succeeded.
2. Add that exact package to the agent image as an unpacked directory at
   `/opt/openclaw-plugins/infuse-studio`. Retain its `package.json` and built files,
   then run `npm install --omit=dev --ignore-scripts --prefix /opt/openclaw-plugins/infuse-studio`
   during the image build. OpenClaw's local-directory installer copies runtime
   dependencies with the directory; it does not install missing dependencies.
   The existing `scripts/ensure-openclaw-runtime-plugins.sh` hashes local directory
   contents, but does not content-hash a fixed archive path; the directory route
   ensures a changed package invalidates the persistent install fingerprint.
3. Append the path to `OPENCLAW_REQUIRED_PLUGINS` for the coordinator and developer.
   Preserve the existing required packages and scope any needed
   `OPENCLAW_CAPABILITY_CONSENT_PLUGINS` addition to this reviewed package. Never
   broaden consent globally. Update the exact package/consent-set assertions in
   `scripts/verify-agent-skill-bundles.py` and exercise the plugin-install verifier.
4. Merge `coordinator-plugin.example.json` and `developer-plugin.example.json`
   into each deployment's `OPENCLAW_CONFIG_JSON`. The shared boot script rewrites
   runtime config from that deployment-owned JSON on every restart. Editing only
   `/workspace/.openclaw-state/openclaw.json` is not a durable installation.
5. Supply distinct random 32-byte Studio bridge tokens through Secret environment
   references: `STUDIO_COORDINATOR_BRIDGE_TOKEN` and
   `STUDIO_DEVELOPER_BRIDGE_TOKEN`. Supported encodings are 64 hex characters or
   43 canonical base64url characters. Studio receives both, each Gateway only its
   own. These are separate from `OPENCLAW_GATEWAY_TOKEN`, which remains the local
   Gateway credential. Do not copy token values into the example JSON or logs.
6. Verify the exact host can authenticate the plugin's loopback Gateway client
   and that OpenClaw's service `stateDir` resolves to the agent's existing PVC.
   Outbound mode stores its journal under `studio-bridge/journal.sqlite` there;
   it opens no Studio mission database. Check retention across a Gateway restart.

Keep authority ID, origin, Gateway enrollment ID and generation stable once a
journal exists. Token rotation keeps the same generation and journal. Identity
or generation changes require the retained-journal retirement procedure in the
[outbound bridge checkpoint](../../docs/plans/archive/009-studio-openclaw-interaction/outbound-bridge.md#enrollment-lifecycle).

## Activation proof and recovery

Do not enable real execution merely because the dashboards load or a plugin
installs. The installed-host capability and interrupted-turn proofs must first
pass for the exact fleet runtime. The pilot must preserve the ordinary agents'
broad tools outside Studio sessions while enforcing the approved assignment
policy inside them.

Before activation, add Secret environment references for the two bridge tokens
to the Studio Deployment and matching Gateway deployments; this is intentionally
absent from the execution-disabled manifest. Verify outbound HTTPS from each
actual Gateway Pod and local authenticated RPC without invoking a model. Review
SQL dispatcher selectors and keep the pilot's Studio sessions/threads outside
their activation path. Do not disable unrelated legacy work globally.

Activate only these two enrollments and one approved bounded mission, with a
defined tool bundle and budget. Record actual remote run IDs, session identities,
tool policy, returned artifacts, coordinator verification and settled closeout.
Exercise hold, revocation and restart without duplicate turns before expanding
to Mattermost. A loopback fixture and a production model-quality assessment are
different evidence.

To stop new admission, revoke the affected Gateway enrollment or set
`bridge.enabled` false in the mounted Studio configuration. The full directory
mount permits ConfigMap refresh; confirm the application observes the new value
and `/api/health` reports dispatch false. Allow for Kubernetes projection delay.
Disabling admission does not by itself abort an already running model turn:
use Studio's hold/cancel flow and reconcile exact runtime receipts before
disabling the plugin or restarting a Gateway.

Before schema-changing upgrades, stop admission and reconcile active runs; retain
one authority writer during deployment. Follow the
[data policy until MVP](../../database/README.md#data-policy-until-mvp): no Studio
backups, snapshots or restore rehearsals before MVP; pre-MVP data loss is acceptable.
Restoring an older image against a newer schema is not a supported rollback.
Do not restore or delete live mission state as part of the example deployment.
