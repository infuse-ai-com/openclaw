# Working in Studio

Studio owns the partner workspace and durable mission authority. OpenClaw runs
agent sessions; Mattermost carries conversations. The playable company in
`apps/mockup` is a design reference with simulated state.

## Workflow

1. **Orient.** Inspect the working tree, [README](README.md),
   [repo map](docs/REPO_MAP.md), and the task-specific references below. Use
   [roadmap](docs/ROADMAP.md) and [plan index](docs/plans/README.md) for current
   delivery status; the latest dated [decisions](docs/DECISIONS.md) take precedence
   over older plans. Check implementation and tests when prose conflicts: some
   nested READMEs still describe the initial scaffold. Before editing, identify
   the owning source, applicable contract, and evidence that will prove the change.
2. **Implement.** Keep small work lightweight. For broad, risky or architectural
   work, use the existing `docs/plans/active/` convention with scope, acceptance,
   verification and progress; record durable architectural decisions in
   `docs/DECISIONS.md`. Finish the authorized scope in its owning source and update
   any affected contract or status document.
3. **Verify.** Follow the verification guidance below. Finish when the applicable
   checks pass, or identify an exact failure or environment limitation and its
   effect on the result. Local fixtures establish their documented scope only.
4. **Close.** Inspect the complete diff for unrelated edits, stale pointers,
   generated files and secrets. Report changed behavior, checks and limitations;
   distinguish implemented, deployed, enabled and user-validated outcomes.

## Always preserve

- **One authority, one writer.** The mission persistence worker is the sole central
  writer (PostgreSQL in production, local previews and central tests).
  SQLite belongs only to Gateway-local transport journals; central compatibility
  and the one-off importer were retired in C4.
  `apps/workers` and Gateway journals are not additional mission owners.
  Reconcile active runs before writer/schema changes and retain a compatible
  writer; schema downgrade is unsupported.
- **Dependency direction.** Shared application logic belongs in `packages/server`;
  HTTP and worker entrypoints adapt transports. Browser code cannot import server
  code, packages cannot depend on apps, and real apps cannot import mockup state.
  Workers reuse server modules directly rather than calling backend HTTP.
- **Source ownership.** Edit shared package sources; `public/`, `dist/` and packaged
  copies are generated. Use the owning package/build scripts to regenerate them.
  npm workspaces share the root lockfile. Repositories and governed knowledge
  systems remain canonical; `company-docs` owns cross-company governance.
- **Exact mission decisions.** V2 paper approval authorizes coordination directly;
  scope changes require fresh approval. Same-scope revision preserves the active
  assignment/session/thread. Closeout requires exact evidence review, required
  task verification, settled runs and any explicit human gates.
- **Identity and recovery.** Preserve current membership and role checks, bound
  agent/session/run identity and required-owner routes. Enrollment grants no new
  access. Managed routes must never fall back to ordinary chat; reconcile uncertain
  receipts instead of blindly replaying effects or changing idempotency keys.
- **Private data.** Keep credentials outside tracked source, screenshots and logs.
  [Database policy](database/README.md#data-policy-until-mvp) forbids Studio backups,
  snapshots and restore rehearsals until MVP. Diagnostic mission exports are
  authorized: keep raw exports private, exclude credentials and commit sanitized
  findings. Use supported reads without interrupting the writer.

## Load the contract for the change

| When working on | Read for rules and verification |
| --- | --- |
| Module boundaries, API, persistence or authentication | [Architecture](docs/architecture/README.md), [approved stack](docs/architecture/technology-stack.md), [database contract](database/README.md). |
| Product scope or visible UI, including the mockup | [Product vision](docs/PRODUCT_VISION.md) and [design contract](DESIGN.md): INFUSE assets, inspectable spatial state, English interface copy, literal user content and equivalent accessible HTML controls. |
| Native lifecycle, Gateway integration or Mattermost conversations | [Native missions](docs/architecture/native-missions.md), [task messages](docs/architecture/task-messages.md), [plugin guide](integrations/openclaw-studio/README.md): approval, addressing, session continuity, protected routes and isolated host proofs. |
| Feedback, instruction delivery, evidence or review findings | [Mission reliability](docs/architecture/mission-reliability.md): complete inbox reads, atomic delivery obligations, exact evidence and renewed review. |
| HTML publication, library, previews or downloads | [Artifact contract](docs/ARTIFACTS.md): shared Registry ownership, project isolation, hashes and sandboxed previews. Publication is separate from task verification. |
| Project selection, routing or membership | [Multi-project contract](docs/architecture/multi-project-workspace.md): shared writer, project-scoped reads and commands, global agent serialization and ordered activation. |
| Local setup, deployment or operational diagnosis | [Workspace guide](docs/STANDALONE_WORKSPACE.md) for setup modes; [production runbook](infrastructure/production/README.md) for release ownership, configuration, health and rollback. Use the current multi-project contract for additional projects. |

## Parallel Codex sessions and local servers

- Use a separate worktree for each session running development servers. Keep
  dependencies, generated outputs and local state in that worktree; never share
  a preview state directory or authority database between running servers.
- Ports are machine-wide. Choose unused ports explicitly: `task preview
  PREVIEW_PORT=4422 ISSUER_PORT=4423`, or `task dev MOCKUP_PORT=4417`. Defaults
  remain 4322/4323 for preview and 4317 for mockup; Task does not allocate ports.
- For separate web/backend development, pair `task dev:web WEB_PORT=4420
  API_ORIGIN=http://127.0.0.1:4421` with `task dev:backend BACKEND_PORT=4421
  STUDIO_CONFIG=/absolute/private/session-b.json`. Use session-specific database
  paths and a matching public origin/OIDC callback in the private config.
  Prefer the synthetic `task preview` when configured OIDC is unnecessary.
- If a port is occupied, inspect ownership and select another port. Never kill
  an unknown listener or use broad process-name cleanup. Retain the worktree,
  URLs, state/config paths and owned process/session IDs for servers left running;
  stop only processes started by this session. Resume persistent previews with
  their original state directory and port pair.
- Serialize installs/builds/tests and watchers that write the same worktree
  outputs. Fixed browser/companion fixture ports also need coordination across
  worktrees (mockup browser tests reserve 4318). Do not infer isolation from a
  different Git branch alone. See [parallel-session examples](README.md#parallel-codex-sessions).

## Verification and environments

[package.json](package.json) owns scripts and the Node prerequisite;
[.gitlab-ci.yml](.gitlab-ci.yml) defines GitLab CI. Install dependencies with
`npm ci` when needed. `task verify:lightly` is the fast local commit gate; its
three checks also run in the GitLab merge request source job. It excludes unit,
integration and browser suites. `task verify` is the
complete pre-push/pre-PR gate and includes the normal source/build verification
plus the complete unit/integration suite. `task pr:ready` runs that full gate and
prints exact-commit PR creation guidance. Run focused tests for changed behavior
locally; authorization, persistence and other broad changes require the full gate
before opening the PR.
GitLab merge requests also run verification builds for the Studio, Registry and PostgreSQL images.

Add the focused browser/host suite required by the changed surface, as described
in its contract and package scripts. For documentation-only changes, validate
paths and commands and run `git diff --check`; product tests need no repetition
unless the documentation changes the verification procedure.

Use `npm run dev` for the simulated mockup and `npm run workspace:preview` for
local authentication/storage with dispatch disabled. Native runtime tests require
an explicitly configured disposable Mattermost/Gateway environment. Load the
plugin guide before running host probes or legacy `studio:*` commands; never
substitute personal or production profiles for fixtures. Stop only the processes
started by the current harness and retain evidence of what it actually exercised.

GitLab protected-main delivery is split: the Studio application and Artifact
Registry deploy automatically only after blocking scan, SBOM, provenance
signing and evidence verification, while PostgreSQL, data migration and
recovery remain explicit approval-required actions.
Keep one replica with `Recreate` and separate Mac/production state. Prepare and
verify changes before any live action, and use existing explicit authorization
for deployments, real-data migrations, secrets, access or external sends. When a
task only authorizes local work, leave live actions as reviewable next steps.
