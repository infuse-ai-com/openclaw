# Studio design contract

## Onboarding mockup exploration — 2026-10-29

The mockup Settings page offers Replay onboarding and Edit my appearance.
The five chapters create a personal look, board a reference-inspired white
flying coupe alone and fly to a neighbouring rooftop, teach an isometric example floor,
and hand control to the existing My desk. The glass bridge is an explorable
proposal, not a production architectural decision.

Skin, hair, top, trousers, shoes and accessories use the existing voxel character
language. Explicit save retains a look per demo partner in this browser and
projects it onto the normal mockup floor; Exit discards unsaved edits.
The floor tour has nine selectable lessons, including Operations and project
navigation. Its teaching actions affect only tour-local examples, never saved
missions or assignments. Spatial controls have corresponding HTML controls.

The solo flight supersedes the shared spaceship concept. The car takes its
low white coupe silhouette, curved decks and roof, dark glazing and disc
wheels from the supplied image. Rounded shoulders replace the angular body.
Cinematics show the partner boarding through a side door, closing it, lighting
four downward thrusters and lifting off. A tracking approach ends in touchdown
and thrust shutdown. Directional side/front/rear jets counter acceleration and
braking. Near the ground, exhaust raises soft smoke that spreads in world space
and dissipates after landing; it never follows the car through the air. The
driver faces the steering wheel through an explicit local seated transform.
Entering the example floor opens the car door, walks the
partner across the bridge and follows them before fading into the office.
Agents remain at the office; the travel scene carries only the partner.
Continue during descent queues that walk after touchdown. Pause, skip and replay
remain available; reduced motion settles poses and bypasses the moving handoff.
Ambient movement pauses with the cinematic and while the document is hidden.
Unavailable WebGL leaves the teaching controls and a headquarters illustration
usable. Settings and the `?onboarding` preview entry both open the same modal
journey. This is a mockup design delta; the real login arrival, user profile,
access rules and mission authority remain unchanged.

[Plan and verification](docs/plans/active/035-onboarding-prototype/plan.md)
record prototype scope and acceptance separately from production adoption.

Updated 2026-10-16. [Product vision](docs/PRODUCT_VISION.md) owns intent;
[roadmap](docs/ROADMAP.md) owns delivery status. Fito approved a light sidebar
workspace inspired by his four supplied Louis Dai Nguyen references and the
subsequent Studio concept. This supersedes the earlier office-first layout.
The existing company simulation and rich mission workflows remain the source;
Office and Company are optional spatial views inside the same application.
[Plan 017](docs/plans/active/017-mvp-design-reference/plan.md) owns the
[style refresh](docs/plans/active/017-mvp-design-reference/style-refresh.md).
Fito accepted merged `c4fd261` as the R0 reference on 2026-10-13;
[closure](docs/evidence/2026-10-13-r0-reference-acceptance.md) records scope and limits.
[R0.5](docs/plans/active/018-frontend-design-adoption/plan.md) owns real-frontend
adoption. Future mockup changes remain versioned design deltas selected per slice.

## Experience and authority

Studio should make shared work easy to scan, shape and review. The optional spatial
views retain the feeling of inhabiting a company and working with its people.
The building makes projects legible; the office exposes people, commitments,
decisions and results. Readable work surfaces carry the detail. Spatial presence
must reflect inspectable state, never imply work simply because an agent is enrolled.

Partners enter one shared Infuse team. Emon and the specialists keep their identity
across projects. Joining requires neither a personal agent nor a desktop. The
reference retains the Core, Finaxis and Hauscraft project floors and local project
creation, with a shared agent queue. Account selection, provisioning and private
workspaces are deferred; project/guest setup remains exploratory demo scope.

The [native mission contract](docs/architecture/native-missions.md) owns execution:
exact V2 paper approval authorizes coordination directly, with no separate Start.
Same-scope revision retains assignment/session identity. Emon verifies required
tasks and closes after runs settle, subject only to explicit human gates. The
mockup illustrates these rules; its local reducer is never a production authority.

## Building, office and navigation

The October 16 [Knowledge-per-floor direction](docs/plans/active/022-floor-knowledge/spec.md)
extends Knowledge to the selected floor's explicit repository set, preserving
the existing native reader and Studio shell. The first release includes a
repository picker in both create-floor and edit-floor forms, with source readiness,
explicit save/cancel and durable selection. Connect repository also supports new
sources through guided setup, validation, indexing status and resumable failures;
pending sources do not hide or block ready sources on the floor. Switching must preserve project
context in Library, search, Explore and links. K0–K3 are deployed and accepted. The October 17 consolidation preserves the
original Studio identity, renames Core to Company with ordinary name and ordering
rules, and adds reversible retirement. Retired floors remain inspectable and
restorable in management; connected mission execution blocks retirement.

The standalone login uses the selected living-headquarters illustration, quiet
window lighting, roof movement and an entrance light responding to sign-in focus.
This atmosphere represents no live people, projects or mission activity. Bundled
artwork belongs to `packages/ui/assets`; the React entrance belongs to
`apps/web/src/features/workspace/entrance.tsx`.

Sign-in follows the existing OIDC flow. Only a confirmed authenticated session
after sign-in initiated in this tab can trigger the three-second first-person
room arrival. On the default My desk destination, the real scene starts just
outside the open rear-left door, walks around the desk and settles into the
ordinary seated camera. The door closes behind the visitor; there is no head bob
or visible avatar. The arrival replaces the former elevator overlay.

A short-lived, single-use session-storage marker controls presentation only.
Existing sessions, reloads, explicit desk objects and other destination links
enter directly. The workspace is inert during arrival; desk controls return and
workspace focus is restored when it ends. Clicking anywhere, Skip to workspace,
or Escape finishes immediately. Reduced motion (including a mid-walk change),
paused motion and backgrounding bypass movement. Missing WebGL or scene loading
failure falls back to the usable workspace; a bounded loading timeout also
releases the interface, and late scene loading cannot replay a skipped arrival.
Login artwork remains decorative and cannot block authentication.

`node scripts/studio-entrance-smoke.mjs` verifies sign-in, the actual moving room,
exact seated finish, skip/focus, no replay and failure/reduced-motion cases against
the local synthetic OIDC fixture after building the web app and services. The
broader `npm run test:workspace` suite verifies the authenticated workflow.

The selected exterior is a continuous glass-fronted company with smoked glazing,
restrained metal framing, a faint elevator shaft and a project lightbox per floor.
A timber roof garden and orange pergola define the silhouette. Street scenery is
decorative; floor signs and native entry controls are primary targets. INFUSE
artwork remains unmodified. Stacked furnished cutaways and selectable layouts
are superseded.

The company Office view uses a compact title and “Choose a project floor.”
There are no Building/Project floor tabs, promotional footer or preferred-project
entry banner. Every lightbox shows its literal project name (including Core);
hovering a floor or focusing its named HTML entrance outlines that level and
reveals an “Enter [project]” label. Camera controls float at the bottom; movement
instructions live in Help → Studio onboarding. Narrow screens keep the entry labels
visible without hover. The scene uses the recovered space.

The real Office surrounds the headquarters with decorative neighboring buildings,
tree-lined pavements and six cars on continuous, separated routes. Windows,
streetlights and headlights warm up at night. This scenery represents no real
traffic, occupancy or mission activity. Shared geometry belongs to
`packages/spatial/src/neighborhood.js`; the real scene owns its render lifecycle.

Lighting follows the device's local wall clock, with gradual morning, daytime,
sunset and night palettes. A visible sun follows the daylight arc and shadow
direction; the night sky has a decorative moon and stars. It is not a geolocated
sunrise, moon-phase or weather simulation.
The clock overlay is the only atmosphere UI; it refreshes every thirty seconds
and on returning to the page. Lighting always follows local time. Decorative
weather has a seeded 5% thunderstorm chance per UTC hour, consistent across
refreshes and tabs without location access or preference storage. It is not a
live weather report. Storm clouds dim the sun, and one brief lightning pulse
every thirteen seconds illuminates the city. There are no preview selectors or
motion button. Live device reduced-motion preferences stop traffic and lightning;
camera movement and clock-driven lighting still work. Offscreen and hidden
scenes stop rendering. Existing project admission and HTML entrances remain
unchanged. `npm run test:office:ui` verifies both navigation and atmosphere in
isolated local fixtures. Production publication follows the reviewed main pipeline.

The default entry after sign-in or opening `/` is My desk in the admitted project. Explicit workspace URLs retain their destination and project context. A persistent, collapsible
sidebar separates company-wide and project work. Company contains Office first, followed by My desk,
My Apps, Agents, Skills, Activity and Monitoring. Monitoring uses a radar icon,
distinct from Activity's heartbeat. My desk combines a voxel desk and the partner's personal
Workbench screen in one company-level destination. Its decision tray aggregates the connected partner's decisions across
projects, ordered by priority with project labels; actions route to the item's
originating project. Agents shows the shared company roster and open work across
projects, distinguishes proposed teams from active assignments, and explicitly
labels the project context for configuration, sources and new missions.

The Project group contains the sole project switcher, then Project floor first,
Whiteboard, Grilling, Missions, Review, Knowledge, Artifacts, Prototype and Operations. All destinations
are visible; there is no More menu. Help and the local account sit at the bottom.
Project selection preserves the current section and selected company profile;
mission details fall back to their collection in the new project. The rail keeps
Global / Project labels and scoped tooltips. Office opens Building; the project
floor has its own active navigation entry. Project-floor navigation lives in the
sidebar; the office has no duplicate workspace menu or Building/Project floor
tabs. Its compact heading, spatial hotspots, camera controls and contextual
mission actions remain. Studio onboarding is available under Help. Whiteboard opens the selected project’s
existing canvas and returns to the previous screen without creating a mission.
Mission cards show the literal paper objective, a deduplicated paper team with
shared portraits (initials for unknown identities), and an explicit next decision
when the current mission requires one. Non-approvers see “Decision needed” rather
than a personal approval prompt. Colored status markers supplement the written
lifecycle labels. Empty columns stay compact while the horizontal scrollbar sits
at the bottom of the board page. Legacy list responses optionally include the
objective and public team targets; older responses remain readable without
invented content or per-card detail requests.
Missions contains All missions, Closed and Activity. Closed filters the same
records to closed/cancelled work and retains earlier evidence downloads. Evidence
links open the selected mission’s Evidence & review tab; there is no separate Outputs screen.
The older single-mission board, squad, activity, artifact, duplicate Agents and
placeholder project screens are removed. Board and List
present the same records, filters and six lifecycle states. Example records remain
explicitly separate from saved missions. Existing shaping, plan/team, approval,
evidence and correction screens render inside this navigation. Saved mission
content and simulation authority are unchanged by presentation.

Desktop work starts directly with the screen title and useful actions. Project and
profile navigation live in the sidebar; there is no global breadcrumb/profile
header or generic “Back to floor” action. Mobile retains a compact navigation
toggle. Mission stages, save status and contextual back/review controls remain.

Each optional project office retains **Paseo del proyecto**, the fixed 22×14
layout selected on September 29. Shaping is on the left, workstations in the middle,
review on the right; the founder desk remains in Direction. Existing spatial
controls and accessible HTML equivalents remain available from the office.

The real Project floor connects that layout to the selected project's recorded
work. Large rear windows show a decorative city panorama with daylight, sunset
and night lighting from the device clock. It shares Office's deterministic 5%
chance of a thunderstorm per UTC hour, so moving between views keeps the same
weather. The visible local clock remains; there are no time, weather or motion
preview controls. The elevator doors open briefly on first arrival without
blocking navigation. Pointer interaction or Escape ends the entrance, and the
system reduced-motion preference suppresses arrival, working gestures and
lightning. Hidden floors stop rendering; an idle floor redraws only when needed.

The October 16 [agent-presence slice](docs/plans/active/023-agent-office-presence/plan.md)
extends the floor with quiet representations of its admitted team, including when
no current assignments are visible. This is implemented locally; production release
is separate. Known identities match their established portraits; unknown targets
retain their actual identity with a generic character. Gateway + agent identity
owns the character, not its array index. Regular desk positions survive refresh
and roster ordering; Emon and Stewie also use the existing lounge.

Quiet presence means team membership in this view, never online, idle or available.
“No work shown on this floor” remains qualified by existing stale/coverage notices.
Current assignments move lounge residents to their workstations along authored
routes. Sparse, finite quiet gestures and occasional desk/lounge walks are decorative.
A working gesture still requires a current observed run receipt; stale, held,
uncertain and settled work cannot animate as running. New state updates the inspector
immediately, supersedes travel when needed and never waits for an animation.
The floor reads only its selected project through the existing bounded loader.

Up to eight admitted characters occupy authored places; the complete HTML roster
exposes overflow. Select a character or its named HTML button for canonical identity,
recorded work, literal mission titles and exact project-scoped mission links. Quiet
characters have a profile link and no invented assignment. Mobile and no-WebGL views
retain the same inspector. An empty admitted roster still means an empty floor.
Reduced motion settles characters without travel or gestures; hidden views stop
animation and quiet intervals return to demand-driven drawing. Character positions
are ephemeral presentation state, not an additional runtime or mission authority.

The implementation lives in `apps/web/src/features/workspace/floor.tsx`, its pure
`floor-model.ts` projection and the existing spatial renderer. Shared furniture
stays in `packages/spatial`; generated panorama textures live in
`packages/ui/assets/floor-window-{day,night}.jpg`. The existing mockup and plugin
retain their default furniture mode. `npm run test:floor:ui` verifies the real
local OIDC/HTTP/store/renderer with disposable synthetic mission and run receipts,
including quiet roster/profile inspection, assignment-driven movement, hold/cancel,
overflow, idle rendering, project isolation, mobile, night, reduced motion, arrival
and the no-WebGL fallback. These fixtures do not establish live agent execution.

### Scroll through the office exterior — 2026-10-20

On the real Project floor, scrolling beyond the room's zoom-out boundary reveals
the shared glass-building exterior in the same canvas. Scroll distance controls
the transition, including stopping and reversing. Continuing outward travels
between storeys, wrapping from the top floor to the first so browsing can continue
indefinitely. The full exterior, roof and street remain fitted inside the floor
window, clear of its heading, mission desk and controls. Resizing preserves that
fit; named entrance targets remain separated on narrow screens. Exploration
reclaims the hidden room intro space, placing its heading near the top edge.
The camera fits the actual roof-to-street silhouette into whichever clear area
(beside or above the mission desk) allows the larger view. Scrolling inward
enters the floor under the pointer without a click. Entry locks its destination until completed or reversed. Named HTML floor
buttons, keyboard entry and the existing project selector provide equivalent
navigation.

Only session-admitted projects appear. Entry uses the existing project route;
the previous project's people and papers never stand in for the destination.
The focused floor's mission desk uses bounded authenticated reads with explicit
loading, unavailable and partial-view states. The mockup retains illustrative
status only in its development exploration. This implementation is locally
verified separately from deployment and human acceptance.

### Profile and floor management discovery — 2026-10-19

The signed-in name at the bottom of the sidebar opens Profile & settings.
The adjacent quick account menu retains appearance and sign-out. Settings shows
only session-backed identity, current-floor approval access and admitted floors;
it does not imply editable identity, enrollment or new permissions. Light, Dark
and System apply immediately to the entire shell and persist in this browser.

Managers enter Floors through the freestanding directory beside the 3D Office
entrance, with a 44px circular keyboard button centred just above the kiosk.
The button keeps its screen size as the building zooms, with a Manage floors
accessible name and tooltip. A visible link remains when WebGL is unavailable. Floors remains a separate screen under Office, with no dedicated
sidebar tab or project-selector gear. Command search and Profile & settings keep
accessible shortcuts. The compact directory opens Repositories, Members and
Settings for each floor; repository rows expose status and shared-source options.
Creation follows Details → Repositories → Members, retains choices when going
back, and writes only on final Create floor. Search and selection do not save.
Explicit updates, retirement/restore, revision conflicts and exact receipt recovery
retain the established authority. Non-managers retain route denial. All shortcuts
and floor links preserve project identity. This redesign supersedes the sidebar
entry described in the original discovery work (2026-10-20).
`npm run test:settings:ui` verifies discovery, saved source edits, create shortcuts,
theme synchronization, mobile/keyboard navigation, permission revocation and
sign-out with isolated OIDC, SQLite and repository catalog fixtures.

### Agent action orbit — 2026-10-19

Fito selected the Sims-inspired radial agent interaction during local dogfooding.
The selected slate-blue treatment adds a theme-aware identity card with a large,
overlapping circular blue portrait. Portraits are still renders of each agent’s
existing floor character, cached by artwork variant; they do not keep a second
animation loop alive. The approved pixel portrait remains the no-WebGL fallback.
The desktop rectangle is 116px tall, aligned with the portrait's outer rim;
long work details scroll inside the card without changing that alignment.
The portrait extends 38px past the rectangle's left edge, with text inset to
preserve the gap between portrait and identity.
A diagonal slate-blue gradient belongs to the name/role header. A thin divider
separates it from the flat work-status area. Light and dark themes have dedicated
header, portrait background and rim colors; shared text and panel tokens remain
authoritative. The gradient never crosses the work text.
Narrow cards keep the portrait inside their bounds and allow literal text to wrap.
Selecting a character opens a compact identity/work bubble and floating action
pills around its projected position. Selection never resizes the floor or changes
the camera. The overlay follows pan, zoom and character travel through the existing
scene projection; ordinary work refreshes do not steal focus or reset selection.
The selection marker is decorative, not an online/availability signal.
Spatial destination labels pair their text with existing Tabler icons: mission
board, activity pulse, review checklist and mission document. Icons inherit the
label color in both themes and are hidden from assistive technology; the literal
text remains the accessible name and navigation target.
Agent name pins use slim, translucent theme surfaces with a decorative person
icon. Their full name and current status remain available to assistive technology.

Assigned agents expose their exact project-scoped mission and canonical profile.
Conversation opens the existing Mattermost root only when it belongs to that
current assignment and generation and is protected. Missing bindings never become
ordinary chats. Quiet agents show “No work shown on this floor”, profile and the
project's mission board; they do not gain invented work, mood or availability.
Multiple assignments remain selectable and literal titles/statuses remain visible,
including stale/uncertain/held states. These links neither assign work nor send it.

Close, Escape, selecting the same character again or clicking empty floor space
dismisses the overlay. Close/Escape return keyboard focus to the selection control.
Camera drags keep it open. Narrow layouts, offscreen characters, roster overflow
and unavailable WebGL use a bounded floating card with wrapping action pills;
all actions remain normal accessible HTML links/buttons. Screen-edge clamping
suppresses a marker that would point to the wrong location. Shared Studio tokens,
Plex, Tabler icons, existing scene/character assets and reduced-motion behavior
remain authoritative. `npm run test:floor:ui` covers these local interactions with
synthetic mission/thread records; deployment and human acceptance are separate.

The elevated orthographic camera keeps its angle. Drag or arrow keys pan; scroll
and visible controls zoom; Fit restores framing. Office labels, HTML navigation
and Cmd/Ctrl+P reach the same work. Escape returns to the project floor and its
navigation control. Opening work preserves camera state; surface return preserves
scroll and saved decisions. No included journey depends on canvas interaction.

### My desk and its screens — 2026-10-16

My desk fills the available workspace with a seated perspective on a voxel desk,
widescreen monitor, separate keyboard, token meter, decision tray and mission
notebook. The notebook has a full page block between two covers and sits visibly
on the tabletop. A large, mounted LCD replaces the window behind the desk and presents
the daily overview. Its enlarged face sits above the desk monitor so the full
overview remains unobstructed from the resting seat. The room has no overlaid
“My desk”, “YOUR SPACE” or “Wall display” labels. The daily overview remains
reachable through the display and an equivalent keyboard control in the dock. A sage pegboard with
headphones and pinned notes sits to the left; a timber shelf with books, a voxel
robot and a trailing plant sits to the right. A pencil pot occupies the outer desk
corner. These are static 3D decorations, outside the screens' resting sightlines
and excluded from object picking. The eye stays in the
chair: dragging looks around, wheel or pinch zooms, and Reset view restores the
seat. Zoom and Reset view have HTML buttons; keyboard controls retain arrows
for rotation, plus/minus for zoom and Home to reset. The camera bar has no
directional arrow buttons and sits in the bottom-right corner; narrower rooms
place the object dock above it to keep both usable. The camera bar uses a slim,
translucent blurred surface with 38px desktop controls and 44px controls on narrow
screens or coarse pointers. The object dock sizes to its labels with compact
padding, switching to two columns in narrow rooms instead of stretching across
the desk. The widescreen monitor idles with a gently
moving voxel landscape and an explicit Click to open Workbench cue. Clicking the
screen or its native Widescreen button opens the actual Workbench desktop inside
the real app's 3D monitor. Opening it or choosing Widescreen frames the monitor
with a short camera transition that respects reduced motion. The eye aligns
straight-on with the monitor; its active screen targets 90% of the room width,
limited by the available height so the full desktop and connection controls fit.
Manual camera input interrupts the transition;
Reset view restores the wider desk. The connection toolbar follows the projected
monitor's top edge, with viewport bounds keeping its controls reachable. Its
connection status and actions pair familiar icons with their text labels. Zen and
the flat fallback retain their ordinary toolbar. The monitor’s active screen is
exactly 16:9 with a 1920×1080 texture, matching the Full HD Workbench desktop without cropping, stretching or
black bars. Other desktop sizes retain aspect-fit rendering. Pointer coordinates follow
the screen plane through camera rotation and zoom and exclude letterboxing.
Clicks, drags, right clicks and scrolling enter the existing noVNC canvas; keyboard
focus belongs to that canvas. Dragging outside the desktop still controls the
camera. Sleep monitor restores the screensaver and the exact viewing angle and
zoom from before opening Workbench, without stopping the desktop or reconnecting
the viewer. Repeated monitor focus preserves that previous desk view. The simulated mockup retains its companion preview overlay.
Disconnect, access loss and project/identity changes clear the reflected desktop.

The room has a framed city window on the right wall and tall frosted office
glazing on the left: four full-height panes, slim grey frames and three etched
bands near the top. Soft decorative silhouettes behind the opaque privacy film
suggest interior light without revealing an exterior view. The timber door sits
farther back along the left wall, behind the seated position. A plaster ceiling with slim
perimeter trim closes the room above the wall display. The window and room lighting
share Office’s device-clock daylight, sunset and night palette. A warm desk lamp
keeps objects readable after dark. The scenery is decorative; it introduces no
new navigation or work status. Clock lighting refreshes once per minute while
visible, including under reduced motion, and catches up when the room returns.

The screensaver animates automatically and follows reduced-motion preferences,
including changes while open; there is no pause/resume control. Screen updates are capped at 20 fps;
rendering pauses when the desk is offscreen, the tab is hidden, WebGL fails or the
scene is destroyed. The furniture's static shadows are reused. Reduced motion
stops the decorative screensaver, while requested desktop content still updates.

The room opens without a content overlay. Selecting a non-monitor object opens a
centered, nonmodal card above the desk on desktop and mobile. The room, canvas,
camera and object dock keep their size and position; longer content scrolls inside
the card with its close control retained. Close or Escape dismisses the card and
returns focus to the selected object's button. The monitor has no selection ring;
object selection and keyboard focus use quiet sage accents instead of orange.
Camera and panel state remain per partner through navigation in the mockup; the
real desk keeps camera state while mounted and panel selection in its URL. Opening
details starts at the top of the card. Closing a panel preserves the
desktop session. The object dock remains available without WebGL, and camera
controls are disabled when rendering fails. Graphics resources are released
when leaving. The existing company decision inbox remains reachable through the
tray, with a contextual return to the desk. The notebook is explicitly scoped to
the selected project and uses its existing mission records.

The wall LCD displays example token usage with its input/output split, the
company-wide decision count and the selected project's saved mission count.
Both the 3D display and its equivalent HTML overview use the same mockup summary.
The wall's native button opens that overview, with links to each source panel;
it remains usable without WebGL. Both displays have physical chassis and depth,
while their unlit screen textures stay legible under room lighting.

The token meter is labelled fixed example data: 96,400 input plus 32,000 output
tokens for an illustrative yesterday, compared with 146,000 the example day before.
It has no provider connection, daily refresh or billing claim. The desktop and
decisions retain their existing owners; this iteration changes no live adapter.
`npm run test:e2e -- tests/e2e/mockup/desk.spec.mjs` verifies desktop/mobile layout,
desktop session continuity, inbox navigation, camera gestures and keyboard access,
view reset/retention, unclipped controls and operation without WebGL.

### Personal screen inside My desk

The widescreen monitor in My desk is the entry for the signed-in partner’s own Linux desktop
through VNC, with Codex, Claude Code and a terminal. It is independent of the
selected Studio project and complements the shared agent team. The mockup holds
separate in-memory desktop previews per partner: connection/cancel, disconnect,
interruption/reconnect, app/folder selection and desktop focus. Returning to the
desk or switching project keeps the preview; reload resets it. The old My screen
surface resolves to My desk and has no duplicate sidebar entry. App output is
labelled read-only example content and no remote commands or model calls run.
Live desktop provisioning, authenticated owner-bound VNC access, persistent
storage and tool sign-in are separate implementation work. Disconnecting the
viewer should leave a live desktop running; the mockup proves only UI state.

The real app adopts this shared scene at `/desk`, with no mockup imports or simulated records. The decision tray retains the admitted-project inbox and original mission links. The notebook uses the selected project's inspected missions. The LCD and accessible HTML overview share these counts and expose partial, loading, last-known and denied coverage. There is no real token usage endpoint: the LCD and meter show an unavailable value, and the panel explains the missing connection. Shared textures update in place without resetting the camera.

The real monitor reuses the authenticated Workbench adapter. Old `/screen` and `/computer` URLs retain the project and open `/desk?desk=monitor`; no duplicate sidebar entry remains. Sleeping the monitor or choosing another object preserves the viewer canvas and connection. Leaving the desk, changing project/identity, losing session access or signing out releases it. Native controls and the decision inbox remain usable when WebGL fails. If the monitor is open, WebGL failure reveals the same flat viewer; held pointer input is released. Zen also exposes the full-size viewer for direct interaction and accessible controls.

The real Workbench viewer offers an optional Zen mode. It hides Studio’s
navigation, viewer footer and frame spacing, leaving a compact connection/action
top bar and the desktop. Exiting restores navigation without restarting VNC.
Zen is scoped to the open monitor in My desk; desktop keyboard shortcuts remain available and the
exit control is keyboard accessible.

### Real Whiteboard — human refinement, 2026-10-16

The project Whiteboard fills the main workspace beside the retained sidebar.
Opening it defaults to Hand mode for navigation. Dragging over a note or document pans;
clicking it focuses inline writing without changing tools. Titles and text autosave;
Escape, a canvas click or choosing Hand again closes the editor. Select clicks
select without writing; double-click or Enter edits a note/document. Fit selection
frames chosen items. Select enables block movement and resizing; deliberate block deep links, outline/search selections and note creation
can still focus editing. Navigating between sections retains the chosen tool.
Identity/save status, tools and zoom float over the canvas; opening an outline,
history, help or properties panel does not shrink the canvas. Note and document title
and body edit directly inside the card with autosave. Inline undo/redo and options
use aligned icon buttons; saved notes rely on the board-level save indicator,
while saving/recovery messages remain available inside the editor. Section entry
pairs its label with an enter icon. Choosing Note arms placement;
click the canvas to create and focus writing, Enter places at the viewport center,
and Escape cancels. One shared Properties panel handles notes, documents, sections,
HTML, images and drawings. Titles, geometry and drawing styles autosave after a
short pause; Position and size starts collapsed and displays readable precision.
Move to section and Connections are secondary disclosures. Comments, Search,
Outline, History, Help, Properties and the HTML library are mutually exclusive;
switching panels retains drafts. Autosave continues after the editor closes,
accepts typing during a pending save, and pauses on incomplete input or a conflict.
Keep drafts and the camera when selection, polling or panel visibility changes.

The bottom dock includes selection, hand, pencil, shapes, eraser, note and document controls.
Undo/redo sits at the bottom left, aligned with zoom at the bottom right.
Pen settings sit directly above the main toolbar with an 8 px gap.
Selection actions and sticky-note color swatches share one compact rectangular bar
8 px above the selected item or combined selection bounds. The bar follows live
movement, resizing and zoom at a constant readable size. It stays within the
canvas and flips below the selection near the top edge. A single note needs no
selection-count label; multiple notes share one bulk color control with a mixed
state. Color changes never open a side panel. On narrow canvases, the toolbar moves above the corner controls
to keep each action reachable. Presence sits beside the top-left board title,
stacking below it on compact screens before the section breadcrumbs. The save
status sits immediately before Search in the top-right floating controls.
While dragging rectangular blocks in Select, nearby edges and centers show thin
alignment guides and snap within six screen pixels at every zoom level. Notes,
documents, sections, HTML and images can align with visible peers in the current
section. A multi-selection aligns its combined bounds and retains its spacing;
vector drawings, including shape presets, do not act as alignment targets. Alt/Option bypasses guides
and snapping. Guides are transient, announced accessibly and cleared on release;
the final position uses one existing board command and remains undoable. Hand
panning and keyboard/numeric positioning retain free movement.
Shift selects multiple blocks. Right-clicking the selection opens a compact menu
with Create section from selection, Duplicate and Delete. Each menu action pairs its label with the matching selection-toolbar icon.
The selection toolbar also exposes section creation. Creating a section uses one atomic command, keeps
relative positions, nested contents, text/comment identities and internal links,
and leaves the new section selected on the parent board. Undo returns everything
in one action. Connections cannot cross section boundaries: select both endpoints
before grouping. The action admits at most 29 selected elements and internal links
plus the section. Failed or uncertain saves use existing receipt recovery.
The menu stays inside the canvas; arrow keys navigate, Escape dismisses it and
returns focus to the canvas, and outside clicks close it. Ordinary text editing
keeps its native context menu.
Right-click also offers Lock and Unlock for one element or a selection, including
an unselected element in Hand mode. Locks persist on the board and are shared
placement guards; they do not grant or remove access. They prevent dragging,
keyboard nudges, resizing/cropping, deletion/erasing and reparenting. A mixed
selection stays together instead of moving only its unlocked members. Attempted
movement offers Unlock; Escape dismisses that prompt. The selection toolbar has
an equivalent lock control, and multi-lock/unlock is one undoable action, bounded
to 30 elements. Text, discussions and navigation remain available; a section lock
protects its tile without recursively locking its contents. Duplicates start
unlocked. Newer shared changes and uncertain receipts retain the existing guards.
⌘/Ctrl Z and Shift Z undo/redo board actions outside
text fields; while typing they retain native/CRDT text behavior. ⌘/Ctrl D duplicates
and Delete/Backspace deletes a selection outside text fields. Undo must refuse
conflicting shared work. Deleted note IDs, text identity and comment anchors can
be restored. History is local to a browser session/section and bounded on the server.
[Human core plan](docs/plans/active/020-collaborative-whiteboard/human-core-plan.md)
records local verification; deployment and human acceptance remain separate.
Drawing creates durable vector strokes with color/thickness, movement, resizing
and deletion; visual swatches/line samples show the pen choices. Shapes opens a
floating strip above the dock with lines, straight/curved/elbow arrows, rectangles,
ellipses, diamonds, triangles, pills and cylinders. More shapes adds rounded
rectangles, pentagons, hexagons, stars and speech bubbles. Click places a default
size, drag chooses the bounds, and Enter places at the viewport center. Shift
constrains equal sides or 45-degree line angles; Escape discards the gesture.
The style dropdown shares the pen color/thickness controls. Saving returns to
Select, selects the new vector and returns keyboard focus to the canvas. These
outline presets use the existing stroke representation and actions, including
resize, duplicate, delete, undo, section thumbnails and overview rendering; there
is no separate SQL shape schema. New shapes include optional preset metadata and
bounded literal labels. Double-click or Enter edits the label inline; Properties
uses the same autosave queue. Labels wrap at word boundaries and fit within the
shape, including thumbnails and the deterministic SVG overview. Drawn arrow
presets remain independent; connection handles or the accessible Connections
control create attached arrows between notes, documents, shapes, images, HTML
or sections. Those arrows follow endpoints when moved or resized.
Selection controls offer alignment, equal spacing and matching dimensions as a
single undoable action. Sticky notes share six named colors with bulk styling.
Copy/Paste uses validated, bounded board data scoped to the current project and
user, creates independent identities, and preserves relative geometry, internal
links and exact artifact references. Text-editor clipboard behavior remains
native. Sections must be copied by selecting their contents; descendants are
never silently dropped. Browser clipboard denial offers keyboard-paste guidance.

The outline includes the section tree and rename/move actions. Dragging selected
items over a section for 550 ms shows a deliberate release cue. A successful move
retains item/text/comment identities and internal links; the cluster is placed
below existing destination content. Cycles, locked placements and connections
with an unselected endpoint are rejected. Undo on the source board restores the
entire action. See [six-slice qualification](docs/plans/active/020-collaborative-whiteboard/human-six-slices.md).

The eraser removes whole loaded strokes in one reversible action. Escape cancels an unfinished stroke
or erasing gesture. In Select mode, HTML tiles move by dragging the title, cover
or non-interactive preview; in Hand mode these surfaces pan the canvas. Buttons
and interactive HTML retain their own input, while the title remains draggable.
Adding or replacing HTML opens a centered library dialog with a searchable file
list, one large selected-file preview, and an explicit Add to board / Replace HTML
action. Choosing or searching files does not edit the board. Search includes titles,
descriptions, publishers and paths across loaded pages, with explicit Load more.
The dialog shows its destination section, preserves the exact Registry reference,
and offers empty, unavailable/retry and save-recovery states. Escape and Cancel
restore focus. Narrow screens stack the list and preview above a reachable footer.
Board frames pause while the library is open, reserving a single sandboxed preview;
closing restores automatic board previews without exceeding the existing budget.
HTML previews appear automatically at readable zoom (45% or above), with at most
two live frames. Visible previews stay stable while panning and refreshing details;
passive frames outside the viewport are released. Additional tiles offer Show
preview, which replaces a passive frame. Interacting or expanded frames retain
their slots; stop interacting before switching when both slots are occupied.
Previews remain passive until Interact is chosen, preserving canvas drag and zoom.
HTML viewing, explicit interaction and expanded reading do not open properties;
exact source details stay in the inspector. Expansion replaces the
inline frame, preserving the two-preview limit and opaque sandbox. Section tiles
show direct item counts and a read-only miniature of the saved direct-child layout.
Notes, documents, drawings, connections and cropped images retain their positions;
nested sections and HTML use labeled covers, without recursively loading boards or
executing HTML. At most four nearby visible section previews load at 45% zoom or above,
each reading the first 12 items through the existing project-scoped manifest/detail
routes and displaying at most two image assets. Additional images use titled covers;
item truncation is labeled Partial preview. Empty, loading and failed states keep
Enter section available. Previews refresh with board revisions, do not mount editors,
and store no extra thumbnail files. Search uses named paths. Small sections frame their
contents on first explicit entry; large sections retain readable scale with explicit Fit.
Returning restores the section camera; Return to previous view reverses framing.
Deliberate zoom-in gestures automatically enter the section under the zoom focus
when it spans at least 70% of either canvas dimension and covers at least 20% of
the view (minimum 125% zoom). The zoom-in button uses the canvas center. Zoom
reaches 800% so small sections remain reachable. Entry happens after the gesture,
with a short guard against cascading through nested sections. Panning, zooming
out, Fit, initial framing and restored views never trigger entry. Drafts, saves,
editing panels, dialogs, interacting or expanded HTML and drawing tools pause
automatic entry. Passive HTML previews do not block section travel.
Deliberate zoom-out gestures and the minus button return one level to the parent
once below 55% of the section's fitted overview scale, capped at 40% and floored at
10%. This leaves room to look around large sections. Empty sections use 40%.
The parent view is restored and may widen to keep travel moving outward; root never exits. At the zoom floor a further
outward wheel gesture or minus click can return. Both directions share draft,
save, tool and dialog guards and the short cooldown. Initial framing, Fit,
restored cameras and panning never exit. Breadcrumbs and Enter section remain available.
Automatic section travel keeps the previous canvas visible until the destination
is ready. Its thumbnail supplies the child coordinate system: zoom-in preserves
the point beneath the gesture and expands the preview into readable content;
zoom-out shrinks the current content into its parent preview. The parent view
widens when needed so leaving a section does not magnify its contents.
A short 420 ms animation blends the two views while the floating controls stay
fixed. Only one inert visual copy is retained; HTML frames never execute in it.
Reduced motion switches directly once ready. Navigation away, lost access and
failed reads clear the visual copy; slow reads cannot leave it stuck indefinitely.
The last readable window (at most 30 items, scoped to the current section and
project) stays loaded below 45% so content does not vanish before the return.
This is a camera/presentation change, with no additional board writes or recursive
section loading.
Open-comment badges and configured participant names make discussion discoverable.
Show in note resolves the current relative anchor without remounting the editor.
Comments frame their subject beside the panel (above it on narrow screens);
documents can edit inline while discussing them. The
[context slice](docs/plans/active/020-collaborative-whiteboard/human-context-plan.md)
records its local checks. Keyboard/outline/geometry
controls remain available, and narrow layouts keep the zoom controls clear of
the dock. The optional React Flow badge is hidden; upstream notices remain.

Image blocks expose Crop image beside viewing and properties. A focused crop dialog
shows the full retained image with a movable crop rectangle and draggable corners;
arrow keys and precise percentage inputs provide equivalent controls. Apply crop
saves once, Cancel leaves the board unchanged, and Restore full image resets the
draft before applying. Crops retain the immutable source and participate in guarded
board undo/redo and duplication. A newer shared image revision prevents applying
an older crop draft. Viewing a cropped block offers View full image.

This implements Fito's floating-canvas reference and follow-up requests. It does
not record final UX acceptance. [Plan 020](docs/plans/active/020-collaborative-whiteboard/plan.md)
owns the current contract. Collaboration/nested work and the selected human
refinements are deployed through [PR 4046/build 10054](docs/evidence/2026-10-20-whiteboard-roadmap-reconciliation.md);
human acceptance and native W5 work remain open.
The mockup's locally stored canvas remains a separate design reference.

## Visual and accessibility rules

- Use unmodified bundled INFUSE assets. Work surfaces use white and cool gray,
  hairline borders, modest 6–9px radii, shallow shadows and compact Plex typography.
  Foundry Black anchors primary actions; INFUSE Orange marks selected emphasis.
  The retained office uses its existing timber and muted greens.
- Desktop navigation is approximately 224px expanded or a 64px icon rail.
  The current destination uses a soft rounded fill and stronger text, without
  an orange edge stripe. Keyboard focus retains its separate visible outline.
  The manual choice is remembered independently of mission state; Knowledge
  defaults to the rail until the user chooses. The redundant desktop top bar is removed. On narrow
  screens, navigation opens from an explicit menu. Work remains readable; board
  columns scroll horizontally while List offers a compact grouped alternative.
- Knowledge occupies the main Studio surface directly, without an enclosing
  application card or duplicate page header. A compact title/view toolbar and
  a small home introduction keep the workspace focused on useful content.
  Navigation uses Studio colors and Plex; articles retain Google Sans Flex,
  source provenance, contents/inspection/settings and calm focus. The source
  tree and reading tools open on demand. Theme controls remain
  local; the shared navigation stays visually consistent. [Provenance](apps/mockup/src/knowledge-reader-assets/README.md) pins the donor source.
- Knowledge sources with excluded documents show the count and an expandable
  path/reason list. Valid documents can refresh while invalid ones are excluded.
  A later refresh failure is identified separately; older Knowledge responses
  without exclusion details retain their existing health display.
- Explain state in text, not only color, avatars or motion. All destinations have
  equivalent HTML controls. Narrow screens stack readable content and decisions.
- Respect reduced motion. WebGL failure leaves navigation and work surfaces usable.
- Preserve keyboard focus after updates. Paper edits autosave and invalidate dependent confirmations. Approval requires
  the current required sections, plan and references to be ready.
  Invalid local fixture data recovers with an explicit notice.
- Authored interface copy is English. Names and user text remain literal in their
  original language; escape display markup without rewriting the stored words.

### Sidebar polish — 2026-10-14

Fito selected the earlier soft selection treatment and five follow-up fixes for
both frontends. Brand/collapse and Go to remain fixed above independently scrolling
navigation; Help and Account remain fixed below it. Rail utility targets do not
overlap. Flyouts stay within the viewport and Escape returns to their named trigger.
The real rail offers a switch-project icon with only admitted projects; expanded
and mobile navigation keep the native selector. The mockup retains its existing
local project picker. My Apps uses the shared server/apps artwork in the real
workspace; the historical mockup uses it for Tools.

Go to opens with focus in destination search. The mockup now filters its existing
local destinations and names an empty result; the real navigator preserves its
Company/project scope and admitted Core Knowledge route. Selection has no orange
edge stripe in either appearance, with keyboard focus retained separately.

`npm run test:sidebar:ui` owns the isolated regression proof. [Evidence](docs/evidence/2026-10-14-sidebar-polish.md)
records the selected delta and its limits; real-app acceptance remains Fito's gate.

### Agents character spotlight prototype — 2026-10-23

The mockup Agents screen now explores the selected character-selection direction:
a compact full-body still render of the existing shared office voxel character,
an About / Work / Telemetry dossier, a team-level Team operations button and the six-person roster. The partner accepted this direction for real-app adoption; the real Agents
screen now follows it using the existing admitted read models (see below). Search filters names, roles and
capabilities. The roster sits directly below the page header, before the spotlight in both
visual and keyboard order. Mobile uses a compact horizontal roster. Tabs support arrow,
Home and End keys. Linked work, capability guides, supporting apps, guest editing,
project defaults and knowledge linking retain their existing simulation owners.
The partner-authorized prototype uses deterministic illustrative missions, health,
model policy, usage, activity and schedules, labelled Mock data. These fixtures
are presentation-only and never inserted into mission state. Portraits render on demand and are cached as still images;
WebGL resources are disposed immediately and the pixel portrait is the fallback.
The portrait is now 240 × 260 px on desktop (about one third of the initial
spotlight), with project coverage and identity below it. A continuous warm background replaces
the gray canvas and white panels; the current mission is visible above the tabs.
Profile, mission and telemetry details use visible sections rather than disclosures.
Shared outline icons mark headings, metrics and tabs; the seven-day total includes
a compact daily chart.
The name, role and signature sit above the portrait. Working style, example
requests and most-used skills are visible alongside the introduction; Supporting
apps and View linked work are omitted. Harness shows an illustrative OpenClaw
version, and skill usage uses mock 30-day counts.
The operational summary links to runtime health, model comparison, token usage,
collector activity, scheduled tasks and freshness. Always-visible mock mission sections show
progress, next steps, deliverables and example decisions; saved simulation missions
remain available separately. Production continues to use observed Gateway data.
See `apps/mockup/agents-data-parity.md` for the comparison with the real Agents view.
Team operations uses the full content width and shows all agents, attention
counts/filtering, health, model policy, usage, observation age and next steps.
Healthy, degraded, model-drift, stale, paused and unconfigured mock states share
one fixture with individual telemetry. Retained observations stay labelled and
unknown usage is never rendered as zero. View telemetry selects the agent and
focuses its Telemetry tab. This is presentation-only; no refresh or recovery action
is dispatched.
`tests/e2e/mockup/agents.spec.mjs` verifies desktop/mobile flows and no-WebGL use.

### Real Agents spotlight — 2026-10-23

The real Agents page adopts the accepted spotlight layout: roster above the
profile, name/role/signature above a compact full-body shared voxel character,
About / Work / Telemetry tabs, and a separate Team operations button beside
Meet the team. The October 30 UX refinement removes the extra title/tagline row:
Meet the team is the page heading, with search, All agents, Team operations and
Refresh sharing its row. Narrow layouts wrap the controls and give search its own
full-width row. A continuous warm surface supports light and dark appearance;
narrow layouts use a horizontal roster and compact portrait. No-WebGL falls back
to the existing pixel portrait only after rendering is unavailable. While artwork
loads, the decorative stage keeps its dimensions without a substitute character;
the full-body image appears after decoding. Rendering reuses the shared character, caches
still images and disposes WebGL resources after each new artwork variant. The dark
character stage, compact metrics strip and icon/description strength rows match
the prototype; small rosters keep compact cells rather than stretching across it.

Selection retains the exact Gateway/agent identity in the URL. Tabs support
arrow/Home/End keys; telemetry drill-down and reload focus the selected evidence.
Team operations is independent of roster search and covers all admitted entries.
It preserves attention filters, refresh, independent source ages and next actions.
Back to profiles retains the previous tab; duplicate names remain distinguishable.

Mission cards and linked-mission counts come from inspected project work, with
proposed/assigned roles, exact action receipts, stale labels and originating links.
Runtime/model summaries, harness/version and the seven-day UTC chart use existing
telemetry reads. Missing days remain unknown, retained observations stay labelled,
and ambiguous multiple sources are not silently combined. No mock usage, health,
progress percentages, missions or skill-use counts enter the real page.

Maintained introductions and Best used for examples are editorial role guidance,
not live persona/installed-skill claims. Most used skills explicitly reports that
usage counts are unavailable; the existing relevant guide links remain separately
labelled as suggestions. Supporting apps and View linked work are omitted.
Profile details, mission receipts, source freshness and project coverage are visible
without disclosures. Loading, incomplete/denied reads and observation-only agents
retain their existing constraints; layout changes grant no access or enrollment.

`npm run test:company:ui`, `npm run test:agents:telemetry:ui` and the telemetry
presentation unit tests own the local proof. Scope and evidence are recorded in
[Agents adoption](docs/plans/active/018-frontend-design-adoption/agents-spotlight.md).
Local implementation is separate from production deployment and partner acceptance.

### Workspace appearance — 2026-10-13

Account → Appearance offers Light, Dark and System. The real account menu pairs
these labels with sun, moon and monitor icons respectively; text and pressed
state remain available to assistive technology. The existing light theme
remains the initial default in both frontends, including when the OS is Dark.
Saved Light, Dark and System choices are preserved in `infuse-studio:appearance`
(real app) and `studio.mockup.theme` (mockup). System follows OS changes while the app is open.
Blocked browser storage does not prevent switching for the current session.

The dark adaptation follows `infuse-ai-brand/INFUSE_BRAND_APPROVED_DIRECTION.md`
and the candidate ramps in `DESIGN_SYSTEM/tokens.css`: Foundry Black `#02080B`,
carbon surfaces `#0B1318` / `#111B21` / `#18232A`, paper text `#F7F5F2`,
secondary text `#AAB2B8`, INFUSE Orange `#FE5600`, and readable orange text/focus
`#FF7A36`. Primary orange buttons use Foundry Black text. IBM Plex and approved
artwork are retained. `appearance.css` owns mockup theme values; presentation
styles consume reusable semantic tokens and preserve existing light fallbacks.

Knowledge's default reading appearance follows Studio; an explicit reader
Light/Dark choice remains available. The furnished scene, portraits, embedded
prototypes/artifacts, remote desktop and authored whiteboard content retain
their own colors. This is mockup presentation only, not production integration.

### Workspace background polish — 2026-10-14

Office and Project floor backgrounds, headings, HTML labels, camera controls and
availability messages follow the selected appearance. The building, furnished
floor, textures, portraits and lighting retain their authored colors. Native
plugin presentation remains separately scoped.

My desk, Agents, Skills and Tools use one page backdrop and raised panel role:
`--ui-workspace` is `#F8F9FB` in Light / `#0B1318` in Dark; `--ui-panel` is white
in Light / `#111B21` in Dark. Headers share the backdrop, while cards, filters,
coverage and reader panels remain distinct. Sidebar and authored embedded
content retain their existing roles. [Verification](docs/evidence/2026-10-14-workspace-background-polish.md).


### Loading refinement — 2026-10-19

The real workspace uses one shared official INFUSE mark with a thin orange
spinner: 96px for pages and spatial canvases, 56px for nested panels, and 24px
for inline waits. Page labels remain available to assistive technology; panel
and inline labels stay visible. Studio and explicit Knowledge reader appearance
control the surrounding surface, and reduced motion stops the ring.

Keep stable headings/navigation and useful loaded content during refresh. Do not
invent records, counts or controls while waiting. A skeleton is appropriate only
when it accurately represents the arriving content; otherwise use the spinner.
Empty, denied, offline and failed states remain distinct. Whiteboard reports
Loading during its initial board read, then Saved only after it has loaded and
has no unsaved changes. Spatial loaders cover module/scene readiness, including
Office fonts, and clear when ready or unavailable. My desk's desktop connection
loader stays visible in both the room and Zen views.
Project floor keeps its canvas and spatial controls hidden until the window and
furniture textures settle and the first complete frame renders. Failed decorative
images are omitted before reveal; a load stalled for 30 seconds uses the existing
HTML fallback. Late responses cannot reveal a failed or disposed scene.

The earlier [loading audit](docs/evidence/2026-10-15-loading-refinement.md)
records the original scope; the shared spinner supersedes its skeleton visuals.


## Connected reference journey

**Grilling** combines the former Ideas and New mission entry points. Save for
later keeps a thought without creating a mission, fetching links or running agents.
Start grilling preserves the original words and opens an unapproved paper directly
in Define the mission. Work with Emon on outcome, scope and acceptance, configure
the plan/team and confirm the required sections in Review. Existing drafts and
MCP arrivals continue through the same flow. Draft authoring keeps Grilling active
in the sidebar; approval returns the record to Missions. **Missions** shows state and next action. Approval commits
that exact paper, the authored plan and selected references; tasks are derived from
the approved plan rather than a separate fixed mission template.

**Knowledge** opens a source-derived Library Home with a review desk, starting
points and repository groups. Browse composes keyword and repository/type filters;
Explore shows authored demo relationships with equivalent HTML document links.
The reader exposes contents, history, exact-version local review and preferences,
and selects a revision. The six-document synthetic corpus is project-scoped;
semantic search, real review writes and live repository integration remain deferred. Draft references can be replaced or removed; Knowledge owns canonical
reading, saved project sources and reusable learning. Mission Paper and Evidence & review retain
papers/results; Missions → Activity shows project history. Pending learning
proposals retain their source-owner review boundary in Knowledge → Learning. **Prototype** opens the selected version immediately (or the project’s current
prototype when none is selected). A compact scenario switcher stays above the
full-width preview. Details & feedback is collapsed by default and contains
source identity, feedback and explicit adoption controls. It offers named runnable
scenarios with exact synthetic repo/PR/build/baseline identity, candidate-specific
feedback and explicitly selected deltas. New versions do not replace selected references. The partner can reopen
the selected version or deliberately view the latest. Unavailable sources/previews
retain identity and block affected decisions. Full KB parity and live preview trust
remain integration work, not claims made by this fixture.

An **MCP-origin draft** joins the same paper flow once per project/receipt. Arrival
saves a draft only. It neither queues an agent run nor bypasses review and approval.
The reference's event control demonstrates arrival; it is not a client integration.
Provenance shows the requesting partner/client/project and receipt. Incoming changes
require review; stale local edits are preserved and can lead to a separate draft.

During work, a busy specialist waits. Partner instructions show receipt separately
from application. Partial prototype adoption opens a finding; revision keeps the
same assignment/session, produces new evidence and requires exact re-review. Hold,
resume and cancellation remain explicit. Named **Reference controls** advance
external fixture events; elapsed animation never completes work.

**Your desk**, **Review**, mission evidence, the mission board and Agents share saved
mission/task projections. Closed work does not need a second acceptance. Fito/Alex
are admitted fixture partners; the named paper owner approves and controls it, while
both can read the shared project and prepare their own work. This demonstrates
decision ownership without changing production role policy.

Clarification records a local mission conversation. Same-scope correction retains
the assignment; changed scope creates a separate paper requiring fresh approval.
Mattermost remains the production conversation owner.

**Evidence & review** shows exact deliveries, selected context and per-delta partial/verified
adoption, with sandboxed concrete HTML fixture previews for each evidence revision.
Publication, evidence review, prototype selection, implementation PR and deployment
are distinct. Emon closes after required verification and settled runs; only a paper
that explicitly asks for a human gate requires acknowledgment. Follow-up creates an
independent unapproved draft with deliberately chosen context. A learning proposal
stays inspectable in Knowledge → Learning, names a pending source-owner destination and never
updates canonical guidance or enters reusable guidance automatically.

Offline mode exposes last-known content with decisions disabled. Loading and denied
modes withhold project content. Empty surfaces explain the next useful action.

## Mission authoring space

Shape, Plan and Review share a compact **Talk with Emon** drawer, collapsed by
default. Contextual comments open it and focus the anchored composer. Enter toggles
the summary; Escape closes the drawer without leaving the mission. Literal drafts
survive collapse, navigation and rerender. Pending proposals open the drawer for
review. Context & references is a separate compact disclosure; selected revision
identity and Knowledge/Prototype actions remain available inside it. The paper and plan
use the recovered space without changing approval or confirmation requirements.

## Owning sources and retired interfaces

`apps/mockup/src/entry.js` imports the original `app.js` for every normal entry.
`/?historical=1` is a harmless bookmark alias to the same interface. `/legacy/` and
the rejected `src/mvp` shell are removed, including their build entries and obsolete
tests. There is no second UI to continue designing.

`simulation/missions.js` owns authoring and approval snapshots. `simulation/connected.js`
extends those same mission records with exact references and task execution, and
owns project ideas, MCP receipts and fixture controls. Existing `mission-ui.js`,
`shaping-ui.js`, `planning-ui.js`, `review-ui.js` and `mission-board.js` remain the
journey's UI. `connected-ui.js`, `connected-controller.js`, `connected-parts.js` and
`knowledge-reader.js` add scoped work surfaces. `world.js` and shared packages own
geometry/assets; `simulation/presence.js` derives inspectable work presence.

The existing `infuse.studio.spatial.v1` store remains authoritative for this local
simulation. Existing saved office/authoring work is preserved; newly approved
missions use connected execution. Previously saved simulation records remain
inspectable with their original semantics; they are not the native lifecycle
reference. Real apps never import mockup state. Reset affects local demo state only.
Broader tools are exploratory, not automatic MVP requirements.

Run `npm run dev`; `/?no3d` exposes equivalent HTML controls. Actual verification
and candidate limits are in plan 017's review. Fixture checks do not establish live
integration correctness or partner acceptance. R0 is closed at the accepted revision; R0.5 adopts existing real features and
R1 is deferred for the new canary. Integration contracts retain their owners.

## Reusable work-surface presentation

`packages/ui/src/workspace.css` owns opt-in workspace tokens, cards, empty states,
page headers, tabs, toolbars and controls. `packages/ui/src/workspace.js` owns
escaped page-header and empty-state markup. Use these blocks when adding a work
screen; feature styles own composition, not a separate palette. See the
[UI package](packages/ui/README.md) for the text/HTML boundary.

The mockup shell and board live in `workspace-theme.css`; feature layout tuning
lives in `workspace-surfaces.css`. Whiteboard controls use the same tokens while
notes retain their selected colors. Knowledge keeps independent reader themes;
prototype/artifact content and spatial artwork retain their own presentation.
The real React workspace now adopts these opt-in tokens and primitives in the
R0.5 main delivery through PRs 3794, 3795, 3796 and 3799. The reviewed main
pipeline owns production rollout; Fito's real-frontend acceptance remains pending;
[engineering proof and intentional differences](docs/evidence/2026-10-13-r05-frontend-review.md)
record the exact current scope. Office uses the shared mockup building exterior with storeys derived solely
from admitted session projects. Named HTML floor entrances remain equivalent to
scene picking; the former card directory is removed, including on scene failure.
Unavailable scenes retain sidebar project/work access; native/legacy commands and production source,
receipt and review controls remain useful differences from the mockup.


## Sidebar hierarchy — 2026-10-12

Grilling replaces Ideas as a primary project destination by explicit owner choice. Review shows a
project-scoped count of pending human paper approvals, legacy result decisions
and explicit closeout gates. Agent verification and past decisions remain
inspectable separately; Knowledge document attestations are not mission approvals.
Prototype contains the optional Whiteboard dialog; closing it restores its underlying
view and unsent form content. The INFUSE logo opens the currently selected project floor. The profile opens a local
account/appearance menu rather than a hard-coded person's capability sheet.

## Implemented-workspace parity in the mockup

Project Artifacts collects standalone authored examples and published local mission
evidence. Mission Paper and Evidence & review retain papers and results, including
unpublished evidence. Artifacts supports search, standalone/mission filters and
an exact-revision viewer with page selection, expanded preview, HTML download and
SHA-256 computed from the same preview/download bytes. Publication remains
independent of verification and deployment. Examples are labelled synthetic.

Approved missions use Paper, Tasks & owners, Conversations, Evidence & review and
Activity tabs. Task inspection projects the existing sequential fixture plan,
acceptance, owners and blockers; instruction receipts and finding histories remain
inspectable across later revisions. Conversations separate coordination and task
threads. Comments retain literal text and owner-bound request identity; uncertain
comments reconcile once without replay. Mattermost handoff explains its deferred
live destination rather than opening a fabricated thread.

Recovery scenarios cover uncertain transport (blocking advancement), stale decision
confirmation, offline state, expired session, sign-in and project access loss.
Session screens are local previews, not authentication. Changed-paper preview
invalidates the review UI without changing approved scope. Reference controls can
create/reopen one named inspection example in the selected project; existing
missions are preserved. Tabs, drafts and viewer preferences are session-local;
comments, histories and transport state use the existing mockup store.


Knowledge reader refinement (2026-10-13): library search is available from every
Knowledge view, including Cmd/Ctrl+K. The reader uses Context, Inspect, Settings
and Focus controls in a compact right rail; narrow layouts place these controls
above the document. Context contains metadata, contents, authored relationships
and fixture history. The review desk opens a stable, revision-pinned queue with
Previous, Next and Back to desk. Finishing a review still requires confirmation
of the exact document and revision; it never selects mission context or approves
execution. The queue and attestations remain session-only simulation.

The live `kb.infuse-ai.com` UI and `knowledge-base/apps/web/src/components/`
(`LibraryHome`, `AtlasToolRail`, `DocumentPanel`, `ReviewFlow`) informed this pass.
The `knowledge-base` repository continues to own the real reader, indexing,
search and attestations; Studio owns its shell and deliberate mission-source
selection. Production integration must reuse that implementation, not promote
these authored fixtures into a second Knowledge Base.


Agents and Skills (2026-10-13) are global Company destinations. Skills sits
immediately below Agents. Agent profiles use authored cover lines, the existing
pixel avatars, first-person introductions, working style, skill links and actual
cross-project mission records. The partner is not listed as an agent. Guest
profiles retain their literal supplied content and existing editing workflow.
Project configuration, source links and mission creation still name their target
project; a shared profile never merges project-owned context.

On October 14, Fito clarified Skills as concise human HTML guides grounded in
canonical `agent-skills` Markdown, already represented in the knowledge base.
Full instructions remain one click away. Purpose, app/tool and agent filters
compose; source provenance and HTML downloads stay inspectable. The mockup uses
pinned source snapshots with explicitly proposed app/person associations.
`SKILLS` and `GUEST_SKILLS` retain their simulation configuration ownership.

The original Tools design followed Skills in Company navigation and presented supporting Infuse apps,
including Backoffice and Sourcebot UX. This real-app directory was removed on
October 23 (see the current My Apps refinement below); it remains a historical
mockup reference, not a runtime executable-tool list.
The current sidebar, agent profiles and knowledge/My screen designs are retained;
there is no separate capability shell or layout selector. [Plan 019](docs/plans/active/019-agent-skills-tools/plan.md)
owns the prototype delta and subsequent real human-guide release. The 36-guide
Core catalog/source/download journeys are now published and live-verified;
installed runtime capabilities, app grants and scheduled refresh are not implied.

## Skills and Tools field guide — 2026-10-17

The real app uses the selected Field Guide direction: workspace discovery on the
left and a theme-aware field guide reader on the right. Purpose controls form two
columns with complete wrapping labels and counts; All skills spans the group. Search and app
filters remain available while reading. Guide headings and decorative artwork
stay compact so the outcome and when-to-use guidance appear early.

Tools originally shared the browse/reader structure and linked to related guides;
its real-app directory and reader were removed on October 23. For Skills, keep
literal published content, exact source instructions, revision-bound downloads
and source-backed versus suggested app relationships. Reading does not imply
installation or grant access. Narrow screens show one pane with a labelled return
that restores selection focus; short screens scroll the entire discovery pane.
Normal desktop discovery scroll survives reader changes. Reader transitions
respect reduced motion. Existing navigation, registered Plex fonts and theme
controls remain. The reader follows Studio's selected appearance for its paper,
text, dividers and accents; decorative artwork also adapts to dark mode.

[Local implementation and proof](docs/plans/active/019-agent-skills-tools/reader-redesign.md)
records the checks and deliberate refinements to the chosen image. This redesign
is locally verified; deployment and final partner acceptance remain separate.

## R0.5 comparison corrections — 2026-10-14

The real shell uses shared Tabler artwork and its registered Plex family;
approved portrait CSS lives in `packages/ui/src/portraits.css` for both frontends.
My desk/profile and task/evidence layouts adapt existing real records; loaded
counts and coverage never imply complete inventory. Current exact evidence,
historical revisions, required findings/inbox and production-specific controls
remain inspectable. Floor Activity/Review preserve the selected project.
This correction slice excluded six integrations. Later selections delivered
Core Knowledge and human Skills/Tools, merged Whiteboard W2 and qualified the
local My screen adapter. Their current limits are in the [roadmap](docs/ROADMAP.md);
Prototype/Operations and broader runtime/write capabilities remain deferred. [Verification and intentional differences](docs/evidence/2026-10-14-r05-comparison-fixes.md)
record the implemented correction scope; Fito acceptance remains pending.

## Core and Knowledge placement — 2026-10-14

Core is the first company floor and the sole native Knowledge workspace. Present
it before the other admitted floors in Office and the floor selector. Preserve
Studio and Finaxis identities and the current working-project default. Knowledge
navigation selects admitted Core explicitly; other floors do not load a local
Knowledge workspace. Equivalent HTML controls and server-side Core/source admission
are required. [Core scope](docs/plans/active/014-knowledge-integration/core-floor.md)
records the first-floor foundation and remaining integration gates.

## Empty floor Knowledge — 2026-10-28

After a successful empty Library read, Explore says “No sources to explore”
and offers Return to library. Loading, failed reads and unadmitted source
selections remain distinct; an empty floor never falls back to company sources.
`npm run test:knowledge:empty:ui` proves this presentation boundary with a local
Studio/OIDC session and synthetic KB responses, including reload and narrow layout.
It does not qualify real KB indexing or source authorization.

## Native Core Knowledge — option 2, 2026-10-14

Fito selected the prototype’s option 2 for real Library, Explore and current
reading. This supersedes the October 13 persistent tree/tool-rail treatment
above for the real Core workspace. One compact Knowledge header uses Studio
identity, Library/Explore and command search. Sources opens the admitted catalog,
tree and facets on demand; its explicit scope follows Library, search and map.
Continue/recent/finding lead the Library, with bounded review metadata secondary.
Explore uses the full stage, named Filters/Documents controls and node preview
on demand; narrow layouts start with the equivalent document list and offer Map.

Ordinary and Explore reading share Contents, Source and Reading controls, compact
exact provenance, sanitized Markdown/pinned assets/Mermaid and reliable return.
Articles retain Google Sans Flex and local Light/Dark/Studio appearance; navigation
uses Studio tokens/Plex. Existing live Meaning readiness, fallback, graph facets,
semantic preview and zoom entry survive beyond the synthetic prototype. Mission
attachment and KB review writes remain deferred. Other integration subsets
retain the distinct states recorded in the roadmap.
[Implementation scope](docs/plans/active/014-knowledge-integration/native-workspace.md)
records verification separately from deployment and Fito acceptance.


## Backoffice dogfood refinement — 2026-10-20

Partners use My Apps inside the ordinary workspace shell, retaining project
selection through internal launch, sign-in and return. Restricted launcher users
retain only their admitted app portal. A navigation hint never grants membership.

Agents presents a team-level operational overview, now opened beside Meet the team:
runtime health, model settings, recorded seven-day UTC tokens and independent
source freshness. Attention and direct telemetry links support triage without
inventing idle/busy state or full policy agreement when intent is unobserved.
Monitoring defaults to attention, preserves filters on reload and offers search,
status and admitted-service selection; current healthy with unresolved incidents
or notifications still needs attention. Exact control confirmations remain.

Contributions keeps coverage warnings visible while detailed source progress is
collapsed; same-name recorded identities remain distinct. Artifact previews
replace an indefinite spinner with a bounded wait and retry option while keeping
the opaque-origin sandbox. [Scope and verification](docs/plans/active/025-backoffice-consolidation/p7-ux-refinement.md)
distinguish local implementation from production retest and product acceptance.


### System triage — approved October 20

Monitoring groups admitted checks by their source-defined parent system, with
compact rows and unresolved counts. System and service filters compose and
survive inspection/reload. Incident inspection leads with unresolved incidents
and notification decisions; observation history starts collapsed. The incident
filter applies before paging so older unresolved incidents remain reachable.
Grouping is display metadata and grants no resource access or sending authority.


### Fleet and discovery — approved October 20

Contributions uses compact repository rows with date-range labels on every
seven-day UTC bucket. Repository search and incremental rows reduce scrolling;
all primary commit dates remain UTC. Commit metadata explicitly labels the
local equivalent with its timezone. Source coverage and author identity stay
visible and separate from presentation filters.

Agent operations retains usage and policy detail while showing relative source
ages, exact UTC timestamp titles and an evidence-derived next action per agent.
Unknown, stale, paused and ambiguous sources never become a healthy conclusion.
My Apps restores the donor catalog's color cues on recognizable initial badges,
keeps category organization, and explains the authorized catalog scope. Styling
never grants access or exposes hidden app destinations.
Artifact browsing uses aligned title, kind, publisher and publication-date rows
with project-wide search and an on-demand exact revision preview. Titles and
summaries retain literal publisher content; revision hashes live in details.
The selected row is visible beside the reader on wide screens. Narrow layouts
give the reader the full width; closing restores the list and keyboard focus.
Escape closes an inline preview or restores an expanded view. The inline reader
groups file selection, version selection and the exact download above its content,
with collapsed provenance and management below. Exact viewer URLs use one slim
row with back, a single-line title and category tag, copy link, details and delete.
A Files picker appears in the header only for multi-file artifacts. Copied links
open the exact version and selected file. Download and focus actions live in the header
on wider screens and in Details on phones. Delete opens a confirmation modal
and moves the current artifact to the bin without requiring text entry. The
library offers Undo after removal; the bin remains available for later recovery.
Back restores filters, loaded results, focused row and scroll position during
the library visit. The artifact fills the remaining viewport without margins or
a footer. The modal details drawer shows the selected file, readable dates,
latest/previous versions and collapsed technical details; closing it returns
focus to its trigger. A single file or version appears as plain text. Focus mode
hides workspace navigation until restored. Pending lifecycle recovery stays reachable in either state. The bin uses the same
collection hierarchy, with explicit restore/delete actions. Only permanent
deletion requires typed confirmation. Lifecycle and revision controls remain shared with exact viewer
URLs, and hidden/stale private responses are removed on failed reads or admission
loss. Authored HTML retains its own appearance inside the isolated preview. In the
collapsed desktop sidebar, icons keep their accessible names and show labels on
hover and keyboard focus without adding a horizontal scrollbar.


## My Apps navigation refinement — 2026-10-23

The real Company sidebar places My Apps directly below My desk, followed by
Agents, Skills, Activity and Monitoring. The Tools tab, supporting-app
directory and dedicated app reader are removed. Skills shows supporting apps
as plain labels, without links to the removed reader. Old
`/tools` URLs redirect to `/apps` with the admitted project; obsolete tool/search
parameters are discarded. Desktop, mobile and Go to use the same navigation order.

My Apps uses bundled SVG icons in cards and Quick launch, replacing letter badges.
Quick launch sits in the main header; the About this catalog disclosure is gone.
Opik, n8n and Knowledge Base / Library Atlas no longer appear in this catalog.
The selected Personal Launchpad places six starter shortcuts in an editable
Pinned section above compact category rows. Desktop shows six pins and three
category columns; mobile uses two pin columns and one catalog column. Pin choices
are browser-local, separated by profile and filtered through current admission.
Users can keep an empty selection; unavailable storage retains edits for the
current visit. Editing exposes accessible pin toggles and a sticky Done action
that restores focus to Edit pins.
The existing workspace shell stays mounted when entering or leaving My Apps.
[Implementation and local checks](docs/plans/active/025-backoffice-consolidation/my-apps-followup.md)
record these changes separately from deployment.

## Activity overview — 2026-10-24

The company Contributions destination is presented as **Activity**, retaining
its existing URL and admitted Git scope. The accepted local overview becomes a
continuous branded surface with summary metrics, annual UTC graph, repository
trends, contributors and latest recorded changes. Orange identifies actions,
blue charts represent activity and semantic states keep their established colors.
The annual graph uses square days with equal horizontal and vertical gaps; cells
grow together on wide screens and retain a scrollable minimum on narrow screens.
Month labels share the week columns. Zero recorded commits use an empty outlined
cell, separated in the legend from the four filled blue activity levels. Even the
lowest nonzero level stays distinct from zero in light and dark appearance.

Commit rows open a side inspector with visible metadata and keyboard return.
Source coverage is a separate screen, with warnings remaining visible in the
overview; this supersedes the collapsed source disclosure described above.
Seven-day repository buckets and all-retained-year contributor totals are labelled
according to the real API. No fabricated prototype values enter the app.
[Adoption scope and verification](docs/plans/active/018-frontend-design-adoption/activity-overview.md)
separate local implementation from production release and user acceptance.


## Cross-route refinement — 2026-10-29, branch implementation

The live audit of eighteen screen states in plan 035 establishes the populated
baseline. Fito authorized implementation on `codex/theme-consistency-audit` with
no merge or deployment. This entry supersedes conflicting header/control sizing
in earlier feature-specific notes. Fito selected neutral light (displayed option
2) and slate dark (displayed dark option 3); human experience acceptance remains
separate from that direction choice.

- Ordinary work headers use the shared 27px title role (24px narrow), a 28px
  content inset (16px narrow), and wrapping actions that retain their space.
  Compact Knowledge navigation and spatial scene headings remain intentional
  exceptions. Activity retains its charts and accent, while its title and refresh
  action follow the common work-screen hierarchy. Skills uses the same title
  scale; Agents uses the compact roster heading described above. Portrait artwork
  remains intact; Skills reader colors follow the selected appearance.
- Desktop controls use a 38px minimum, 6px radius and 13px label role; coarse
  pointers use 44px. Icon buttons use centered 20px artwork and 8px corners.
  Whiteboard icon toolbars pair those corners with 6px edge padding, 4px gaps
  and 14px outer corners. On phone canvases up to 420px, the upper action row
  sits below the title, and compact zoom controls leave room for undo/redo.
  Refresh uses the quiet button treatment. View switches use
  shared `.ui-tabs`; layout and filter choices use `.ui-segmented`. A neutral filled
  background and text weight identify selection, separately from the keyboard
  focus outline.
- Mission card titles have three-line previews, with unchanged full text in the
  mission detail. Identical title/outcome text appears once in the preview.
  No stored title, paper, evidence or approval semantics change. Linked-work
  previews are bounded; the destination remains the full-content owner.
- Code uses the shared content inset, a bounded search row and readable result
  groups. Code preserves whitespace and scrolls inside focusable containers;
  long paths wrap without forcing page overflow.
- Monitoring keeps all filters and operational meanings; a deliberate filter
  grid replaces uneven wrapping. Its final summary sizing has one owning rule.

`packages/ui/src/workspace.css` owns reusable presentation roles; real-app
composition stays in the owning feature styles. No React package dependency or
new component framework is introduced. `test:consistency:ui` verifies long
literal content, selection/focus, Code results and light/dark narrow layouts;
existing route suites remain required for the affected behavior.

### Selected palette pair — 2026-10-29

The neutral-light and slate-dark references in plan 035 supersede older
page-wide warm/green Agents colors, Activity's paper backdrop and shared working
chrome colors. They do not supersede authored content palettes.

| Role | Neutral light | Slate dark |
| --- | --- | --- |
| Work page | `#FFFFFF` | `#171C22` |
| Navigation/canvas surround | `#F5F5F5` | `#12171D` |
| Raised panel / input | `#FFFFFF` | `#252D36` |
| Selected | `#E8E8E8` | `#303A46` |
| Divider | `#DDDDDD` | `#3B4653` |
| Heading | `#252525` | `#EDF0F4` |
| Body | `#474747` | `#CBD2DA` |
| Muted label | `#666666` | `#A5B0BE` |
| Input boundary | `#858585` | `#697786` |
| Action text / focus | `#B83D00` | `#FF8A4C` |

Control boundaries are stronger than decorative dividers. Brand orange is not
automatically a small-text color. Use semantic good/warning/danger roles for
status text, always with a literal label. Active navigation combines fill, weight
and an inset edge; focus has its own outline. Profile tabs reuse the view-switch
presentation while retaining their existing arrow-key/ARIA behavior.

Company pages inherit the shared roles instead of redefining `--ui-*` tokens.
Allowed exceptions are the explicit Knowledge reader appearance, agent portrait
stages/strength imagery, app identity icons,
authored Whiteboard objects, embedded artifacts/desktops and spatial artwork.
Their surrounding controls still follow Studio. My desk's HTML dock and camera
controls use the shared palette with 38px desktop camera targets and 44px targets
on narrow screens or coarse pointers; scene lighting remains
independent. Appearance thumbnails depict the selected pair.

The [component reference](docs/plans/active/035-design-consistency/components.md)
records ownership, interactive states and verification.

### Cross-screen dogfood refinement — 2026-10-29

The selected pair now extends through mission-detail navigation, Grilling,
Review, Settings and Knowledge chrome. Standard section headings use the 20px
role; action labels use medium weight. Agents follows shared page insets and
Monitoring fields follow the shared compact control scale. Mission detail uses
the same view-tab primitive as the board. Review/list cards share metadata rows
while board cards retain their narrow layout. Grilling uses a plain form with a
separated guidance column, rather than nested panel framing.

Knowledge's compact header and independent document appearance are intentional.
Search, Sources and reading tools share Studio's control/focus/selection roles;
changing the document theme never recolors those surrounding controls. Settings
retains its visible choice check as well as the selected outline. Literal mission
content and all approval/command semantics remain unchanged.

[Refinement evidence](docs/plans/active/035-design-consistency/refinement.md)
records local checks. Fito will dogfood this pass before the next iteration;
experience acceptance, merge and deployment remain separate.


### Shared components, layout and readability — 2026-10-29

Reassessment items 1, 4 and 5 extend the same branch. Shared CSS owns ordinary
header, action, field, view-switch and empty-state presentation. The real web
app's `features/workspace/ui.tsx` supplies thin `PageHeader`, `Button`,
`EmptyState` and `ViewSwitch` adapters. Routes still own state, permissions,
commands, labels and navigation. A default button is non-submitting; form submit
buttons opt in explicitly. View switches are pressed-button groups; genuine
ARIA tabs retain their existing keyboard behavior.

Use deliberate width roles with aligned header/content insets: wide (1440px)
for Activity, Monitoring and Agents; list (1200px) for Code, Review and mission
lists; form (960px) for Settings; reading (960px) for mission papers. Grilling
uses the list width to keep its form and guidance together. Mission boards
remain horizontally scrollable. These maxima include the shared page insets;
content reflows to the available width on smaller screens.

Ordinary supporting text uses named caption (12px), label/support (13px) and
body (14px) roles. Status and metadata should not rely on tiny type to establish
hierarchy. Preserve bounded portrait lettering and authored reader typography.
Remove displaced header/control rules when adopting shared patterns; feature
styles should express composition and documented exceptions.

[System refinement evidence](docs/plans/active/035-design-consistency/system-refinement.md)
records this pass. Local fixtures verify presentation and interactions; they do
not establish production deployment or human experience acceptance.

### Complete screen adoption — 2026-10-29

The remaining screen pass adopts the same actions, fields, text roles and empty
states throughout Skills, My Apps, Floors/repository setup, Knowledge controls,
Desk/company panels, Workbench, Whiteboard tools and mission detail panels.
Compact headers preserve embedded heading levels and keep metadata outside the
accessible title. Icon buttons require accessible labels and use the ordinary
38px/44px target scale; My desk's compact camera follows that scale while other
spatial camera groups retain 44px targets. Toolbars are
labelled native-button groups; genuine tabs and menu items retain their keyboard
owners. Crop handles and canvas objects remain geometry-specific controls.

Skills reader content and shared actions follow Studio's selected appearance.
Knowledge's independent document theme, authored content and app
identity colors remain deliberate boundaries. This is branch implementation;
production deployment and partner acceptance remain separate.

### Decorative rails — 2026-10-29

The owner rejected decorative colored edge stripes and accent underlines.
Selection uses neutral filled surfaces and appropriate text weight or neutral
boundaries, without decorative inset bars. This applies to the real app, shared
controls, Skills exports and the embedded prototype. Callouts rely on their
labels and surface hierarchy instead of a colored edge.

Keyboard focus retains a conspicuous complete outline. Added/removed comparison
markers retain their green/red edges and textual semantics; non-text comparison
markers remain distinguishable. Structural dividers, tree/timeline connectors,
loading indicators, chart marks, spatial geometry and authored content are not
decorative callout rails. Selection rings on objects and swatches remain usable
with neutral contrast. See the [accent-rail inventory](docs/plans/active/035-design-consistency/accent-rails.md).
