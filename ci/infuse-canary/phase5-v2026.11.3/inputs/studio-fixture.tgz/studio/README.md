# Infuse AI Studio

Infuse AI Studio is the shared workplace where Infuse AI partners build the
company and their projects with one shared Infuse agentic team. The initial
2–5 partners work with Emon and the specialists, shared knowledge and reusable
working methods in a shared workspace with optional spatial company views.

Partners bring ideas, links and tasks, develop prototypes, and run bounded
missions when work needs coordinated execution. App delivery, QA, research,
client work and company operations share the same environment. Useful outcomes
and reviewed learning improve the capabilities available to the next project.
See the [product vision](docs/PRODUCT_VISION.md) for direction and open choices;
current implementation status is described below.

The working promise is:

> Shape the mission. Assemble the squad. Run the company.

## Product Thesis

Studio makes Infuse AI's way of working accessible to its partners. Partners
work directly with the shared team; an optional personal agent can help prepare
intent. Emon coordinates shared execution through the Infuse AI/OpenClaw harness.
Skills, runbooks, knowledge and infrastructure reduce repeated setup and context
reconstruction. Partners can
inspect plans, artifacts, blockers, approvals and outcome evidence. Private
workspaces are not required for the initial partner experience.

The swarm keeps one persistent company agent per Gateway/pod. A Fito-only managed
company Linux desktop pilot is packaged behind Studio's explicit Workbench access
adapter. Selecting which authorized model account
funds each mission/agent session is planned work; Studio currently uses the
runtime's configured accounts. See the [account-selection boundary](docs/architecture/native-missions.md#model-account-selection-planned).

The spatial model is functional:

- the building represents the company;
- a floor represents an initiative, BET, or project;
- a mission represents one bounded outcome within that initiative;
- agents are persistent identities that can work across floors;
- desks, whiteboards, review walls, and operations areas expose real state.

The mockup's current design direction is a sidebar workspace with light and brand-based dark themes, compact
work surfaces and optional Office/Company views. See the [design contract](DESIGN.md)
and [style refresh status](docs/plans/active/017-mvp-design-reference/style-refresh.md).
R0.5 adoption is implemented, locally verified and merged through PRs 3794,
3795, 3796 and 3799 with Fito's explicit release authorization on 2026-10-13. See
the [engineering review](docs/evidence/2026-10-13-r05-frontend-review.md). The main
pipeline owns production rollout; real-frontend acceptance remains pending.

## Current Stage

Current delivery status and outstanding work live in the [plan index](docs/plans/README.md).
The [roadmap](docs/ROADMAP.md) connects that work to the next product milestones.
R0 is [accepted and closed](docs/evidence/2026-10-13-r0-reference-acceptance.md).
R0.5 and subsequent My desk, living Office/floor, agent presence and Skills/Tools
reader changes are merged and released; broader human experience acceptance is
still open. The [October 29 reconciliation](docs/evidence/2026-10-29-roadmap-reconciliation.md)
checks fetched main `33c4789` and successful release 10871, including later Agents,
Activity, desk/entrance and theme/control adoption. Onboarding remains a mockup-only
design delta; current assurance and acceptance gates are explicit in the roadmap.

[Knowledge per floor](docs/plans/active/022-floor-knowledge/plan.md) K0–K3 is
deployed and accepted: humans and enrolled agents manage floors/repositories,
choose and onboard sources, and use scoped Library, Search/Meaning, Explore and
reading. The October 28 recovery proof covers Company (internal ID `core`),
Finaxis, Studio, Hauscraft and an empty setup-test floor; source counts/readiness
remain dated observations. Studio Pilot is retired with its history retained.
All active and future floors
share the [same capabilities and automatic team connections](docs/plans/active/024-floor-capability-parity/plan.md).
Original source sets and mission histories are preserved. K5 exact mission
sources is a deferred nice-to-have; no K6/K7 is defined.

Human Skills/Tools guides are published, and the field-guide reader is deployed;
final partner acceptance and any scheduled maintenance remain separate. The
OpenClaw 2026.10.3 canary and current shared team are deployed. R1 awaits a selected
additional partner/project/outcome. Workbench's protected MicroK8s human pilot
is deployed and enabled for Fito; provider sign-in and human acceptance remain open.
The native Mattermost rollout and production/Mac pilots are complete; historical
plans are archived. The [source-access repair](docs/evidence/2026-10-06-agent-source-access-repair.md)
is complete on the returned proof. Scoped proactive task instructions are also
deployed and [live-verified](docs/evidence/2026-10-06-native-task-messages.md).
The [Finaxis EUR/USD mission](docs/evidence/2026-10-09-finaxis-mission-retrospective.md)
delivered a reviewed PR and autonomous closeout; merge and deployment were outside
its scope. The [roadmap](docs/ROADMAP.md) tracks remaining daily-operation and
partner-validation work. The [HTML artifact integration](docs/ARTIFACTS.md) reuses the
shared Artifact Registry and is enabled in production. Standalone and
mission-linked publication, preview, history, download and project isolation
passed [live acceptance](docs/evidence/2026-10-06-production-html-artifacts.md).

The standalone Studio workspace now runs on React, TypeScript and Vite, backed
by a Fastify service, OIDC sessions and the central PostgreSQL mission authority.
It reuses the mockup's furnished office, INFUSE brand and cream paper surfaces.
You can create, review, approve, hold, resume and cancel real stored missions.
See the [workspace setup guide](docs/STANDALONE_WORKSPACE.md) and
[approved technology stack](docs/architecture/technology-stack.md).

The real [Whiteboard](docs/plans/active/020-collaborative-whiteboard/plan.md) now
provides a full React Flow canvas with floating tools, inline sticky notes,
freehand vector drawing and durable project storage. W2 merged in PR 3830 and
deployed through main build 9341; live board reading is verified and UX acceptance
remains pending. W3 shared paragraphs, recovery, presence and anchored comments
are enabled across active floors. W4 nested sections, exact Registry HTML tiles, progressive
loading and search merged in PR 3869 and deployed through build 9451; Fito is
dogfooding. Placement/autosave, guarded undo, viewing/navigation, erasing, discussion,
sticky fitting and image input are also released. PR 4046/main build 10054 now
includes the subsequent crop/navigation/HTML/shapes refinements, grouping/locks,
unified autosave and all six human slices, including compact note controls.
[Current release and remaining work](docs/evidence/2026-10-20-whiteboard-roadmap-reconciliation.md)
consolidate human acceptance; these features are not pending implementation.
[W5 architecture and phases](docs/plans/active/020-collaborative-whiteboard/w5-plan.md)
allow agents to read, add/edit, review and accompany humans using their project
access, without requiring a mission. W5.0 qualification and W5.1 native reading,
search and explicit human view sharing are implemented. W5.2 durable native edits,
receipt recovery and attributed changes, plus W5.3 verified visual inspection,
merged in PR 4077. W5.4 adds compact activity, linked updates and Start/Stop
companionship. The [October 21 rollout record](docs/plans/active/020-collaborative-whiteboard/agent-access-rollout.md)
records enabled reading/editing/chat and per-agent reads for four enrolled agents.
The new [agent XML context](docs/plans/active/020-collaborative-whiteboard/agent-xml-context.md)
with bounded spatial relationships is implemented locally and awaits release.
Both agent renderers are deferred; live human acceptance remains open. [Human acceptance and selected refinements](docs/plans/active/020-collaborative-whiteboard/human-refinement.md)
continue alongside this work.
The native whiteboard tools require explicit Studio and plugin enablement; visual
inspection also requires the separately isolated renderer. [Storage format](database/README.md#whiteboard-storage).

Production uses native Mattermost accounts on four enrolled OpenClaw Gateways.
Emon shapes the paper; humans approve its exact revision in either surface;
independent specialists clarify, deliver and revise in their own task threads.
Emon verifies all required tasks and closes after the runs settle. Backoffice's
mission orchestration is retired. The [native operating contract](docs/architecture/native-missions.md)
and [pilot evidence](docs/evidence/2026-10-06-mac-tailscale-pilot.md) document the
current boundary, isolated Mac operation and remaining limitations.

The earlier native OpenClaw Studio page remains available for historical V1
workflows. The local synthetic UI preview keeps execution disabled and is not
the deployed production authority.

The connected **MVP design reference** is available in `apps/mockup` at `/`.
It joins Grilling → mission paper → Knowledge source → Prototype candidate → exact approval
→ specialist revision → evidence → Emon closeout → follow-up. The original company
and project floors share one synthetic team; MCP drafts enter the same review flow.
The built-in projects are Core, Finaxis and Hauscraft. Project floor and Whiteboard
lead project navigation; Closed and Activity live within Missions. Older fallback demo
screens are removed, while existing saved mission evidence remains accessible.
My desk aggregates owned decisions across projects, and Agents shows the shared
team and project-labelled work. Review and mission Outputs share mission state; Knowledge holds saved
sources and learning. Exact HTML results,
partner ownership, selected design deltas and MCP draft conflicts are inspectable.
All state and execution are local fixtures. Fito accepted merged `c4fd261` as
the R0 reference; R0.5 now owns adoption in the real frontend.
[Walkthrough and evidence](docs/plans/active/017-mvp-design-reference/review.md),
[implementation map](docs/plans/active/017-mvp-design-reference/implementation-map.md)
and [DESIGN.md](DESIGN.md) define the accepted reference; the roadmap tracks
remaining production capabilities and acceptance.

Within `apps/mockup`, the original company/office design is the sole app entry. The rejected
replacement shell and `/legacy/` station demo have been removed. `/?historical=1`
opens the same app for old bookmarks. Continue iterating this office and its rich
mission authoring flow; broader demo tools remain outside the MVP delivery scope.

## Workspace

Nix-built work environments and compute infrastructure now belong to the
separate **Infuse Workbench** repository. Studio retains authenticated access
and mission authority; see the [integration boundary](docs/architecture/workbench-integration.md)
and [local extraction proof](docs/plans/active/015-partner-desktop-spike/extraction.md).
My screen's developer preview, Zen, protected company access and persistent local
dogfooding are merged and locally qualified. Production Studio now serves its
pinned noVNC client and issues short-lived, actively renewed gateway/runtime grants
through the explicit internal mTLS configuration. The protected Fito-only MicroK8s
pilot is deployed/enabled; its remaining provider and human acceptance gates are
recorded in the [integration record](docs/architecture/workbench-integration.md).

The repository is a modular monolith with four runnable apps: `apps/web`,
`apps/backend`, `apps/workers`, and `apps/mockup`. HTTP and worker processes
share `packages/server`; contracts and presentation have separate packages.
See the [repository map](docs/REPO_MAP.md) and [architecture](docs/architecture/README.md).

The standalone backend is the configured project's mission authority. The
background worker app remains a foundation and is not required to run the
workspace. The native [OpenClaw plugin](integrations/openclaw-studio/README.md)
uses the same authority application service for human requests. Its session-bound
agent tools, remote bridge and durable coordinator continuations retain their
isolated host fixtures. Each deployment must have one authority owner; the new
workspace does not silently move existing native data.

V2 missions support independently owned tasks, dependencies, immutable evidence
revisions and same-assignment clarification/rework. Task evidence remains bounded
text with immutable source references. The [HTML artifact library](docs/ARTIFACTS.md)
adds shared-registry deliverables without changing mission delivery authority.
V1 single-specialist papers and their explicit acceptance/correction history
remain readable. The mockup's broader company operations remain product backlog.

## Run and Verify

Requires Node.js 22.19+ (or a compatible newer release). The OpenClaw plugin host
has the stricter runtime requirements documented in its README. From the repository root:

```bash
npm ci
npm run dev                 # Connected MVP reference: http://127.0.0.1:4317
STUDIO_PREVIEW_PROFILE=minimal npm run workspace:preview  # Local PostgreSQL UI on 4322
```

For richer missions and canonical synthetic Knowledge, prepare the pinned KB checkout
and select the default demo profile in the [scenario setup](docs/plans/active/026-postgresql-migration/synthetic-scenarios.md#local-startup-prerequisites).
For current native V2 setup, use the [workspace guide](docs/STANDALONE_WORKSPACE.md).
The former Gateway-local V1 launcher is retired; its
[historical reference](docs/LOCAL_DOGFOOD.md) points to the exact pre-retirement commit.

The standalone preview uses a synthetic local OIDC operator with real mission
storage and disabled runtime dispatch. For a real identity provider, configure
`STUDIO_CONFIG` as described in the [workspace guide](docs/STANDALONE_WORKSPACE.md).
That configuration is required by `start:backend` and `dev:backend`. The guide also
covers separate Vite/backend development ports.

```bash
task verify:lightly         # Fast commit/PR checks; no unit, integration or browser suite
task verify                 # Complete source/build and unit/integration gate before push
task pr:ready               # Full verify plus exact-commit PR creation guidance
task verify:full            # Backward-compatible alias for task verify
npm test                    # Unit/integration suite; owns disposable PostgreSQL (Docker + OpenSSL)
npm run build               # All apps; output in each app's dist/
npm run test:workspace      # Standalone browser/auth/recovery proof
npm run start:backend       # Configured API + built web; requires STUDIO_CONFIG
npm run start:workers       # Standalone worker foundation
```

The assurance commands `npm run assurance:functional` and
`npm run assurance:coverage` run the test runner against a fresh PostgreSQL cluster
inside pinned BuildKit stages. Coverage is exported as LCOV and Cobertura evidence;
no Docker socket or persistent database is used.

Install the repository hooks with `pre-commit install --hook-type pre-commit
--hook-type pre-push`. Commits run `task verify:lightly`; pushes run
`task pr:ready`, which requires the complete gate and then prints PR guidance.
The GitLab merge request source job runs the same three checks after `npm ci`.
Separate merge request jobs verify the Studio, Registry and PostgreSQL image builds.

Studio collects Contributions from mapped GitLab repositories through its
existing source and floor bindings. The
[retirement procedure](docs/plans/active/037-studio-gitlab-contributions-pilot/plan.md#azure-contributions-retirement)
removes Azure commit records and recollects reachable history from GitLab.
Repository registration, settings changes, pipeline signals and floor
project/repository checks still need GitLab support.

### Task shortcuts

[Taskfile.yml](Taskfile.yml) collects the repeated local workflows from Studio's
preview/dogfooding, whiteboard and Knowledge refactors, Backoffice consolidation,
and storage/performance work. Install [Go Task v3](https://taskfile.dev/docs/installation)
to use it; `package.json` and the existing scripts remain the command owners.
Run `task` or `task --list` to see the available shortcuts. They also work from
repository subdirectories.

```bash
task setup                  # npm ci for a new worktree
task setup:browser          # Install Chromium once on this machine
task preview                # Real local storage + synthetic login, dispatch disabled
task dev                    # Simulated company reference
task verify:lightly         # Same fast source gate as the PR pipeline
task test:focused -- tests/integration/machine.test.mjs
task test:whiteboard:text:ui # Focused browser/recovery proof
task test:e2e -- tests/e2e/mockup/connected.spec.mjs --workers=2
task verify                 # Full source/build and unit/integration gate before push
```

#### Parallel Codex sessions

Use a separate Git worktree for each session that runs development servers.
Worktrees isolate source, generated assets, dependencies and default preview state;
ports still belong to the whole machine. Choose unused ports for each session:

```bash
# In one worktree (defaults: mockup 4317, preview 4322 + issuer 4323)
task preview

# In another worktree
task preview PREVIEW_PORT=4422 ISSUER_PORT=4423
task dev MOCKUP_PORT=4417
```

The existing `STUDIO_WORKSPACE_PORT` and `STUDIO_WORKSPACE_ISSUER_PORT` environment
settings still supply preview defaults. Each preview stores state under its own
`.studio-local/postgresql`. Never point two running previews at the same
`STUDIO_WORKSPACE_STATE_DIR`; use the same state directory and ports when resuming
one. Ctrl+C stops its servers and owned database container, preserving synthetic data.
`task preview:reset` removes only that marked local PostgreSQL database. Docker
and the pinned PostgreSQL image are required; see the workspace guide for profiles.

For frontend/backend development, run these in separate terminals in the same
session's worktree, using its own private config and database paths:

```bash
task dev:backend STUDIO_CONFIG=/absolute/private/session-b.json BACKEND_PORT=4421
task dev:web WEB_PORT=4420 API_ORIGIN=http://127.0.0.1:4421
```

The private config's public `origin` must be `http://127.0.0.1:4420`, with that
origin's exact `/api/auth/callback` registered at the development OIDC provider.
Changing ports alone does not rewrite OIDC configuration. The
[workspace guide](docs/STANDALONE_WORKSPACE.md) covers configured development;
`task preview` supplies its own synthetic issuer for simpler local exploration.
`STUDIO_API_ORIGIN` and `PORT` remain defaults for `API_ORIGIN` and `BACKEND_PORT`.

Port selection is explicit, not automatic. Vite uses strict ports; an occupied
port must be resolved by choosing another port, never by killing an unknown
listener. Record the worktree, URLs, state/config paths and owned process/session
IDs when leaving a server running. Stop only the processes started by your session.

Run builds, installs and browser suites sequentially within each worktree; do not
run them alongside a watcher writing the same outputs. Separate worktrees do not
isolate fixed fixture ports: mockup browser tests reserve 4318, and companion KB
fixtures have their own configured ports. Coordinate those suites across sessions.
Task does not allocate ports or manage background processes, cache verification
results, or install dependencies implicitly. `test:focused` builds services first;
plugin tests also require `task build:plugin`.

Knowledge and floor browser tasks require the companion KB fixtures described in
the [workspace guide](docs/STANDALONE_WORKSPACE.md) and
[Knowledge fixture verification](docs/plans/active/025-workspace-ui-maintainability/plan.md#verification-gates).
`task test:postgresql` owns a disposable Docker container; it does not take a live
database URL. Native host/model proofs retain the prerequisites in the
[plugin guide](integrations/openclaw-studio/README.md). Other specialized scripts
remain available through npm. Publication, migrations, production diagnostics
and deployment stay in their owning runbooks and reviewed pipelines.

Browser regression tests require Python 3 and Playwright Chromium:

```bash
npx playwright install chromium  # First machine setup only
npm run test:e2e
```

Scheduled assurance has no configured GitLab replacement. GitLab delivery is
blocked at workflow admission until release qualification and its safety gates
are implemented and reviewed. Local assurance commands remain available.

Port 4318 is reserved for browser tests. Desktop/mobile specs are in
`tests/e2e/mockup`; traces and screenshots go to ignored `test-results/`.
The mockup builds one entry at `/`; `/legacy/` is removed. Existing company state
uses `infuse.studio.spatial.v1`, extended with connected feature state. The rejected
shell’s isolated store is not loaded. `/?no3d` exposes the HTML fallback. For focused
checks run `npx playwright test tests/e2e/mockup/connected.spec.mjs --workers=2`.

## Walk the Connected MVP Reference

1. Enter Studio from the company, open Ideas, save a thought and choose **Shape with Emon**.
2. Read Knowledge and **Select this source**. Try Lab, record feedback and **Use as reference**.
3. Return to the mission, shape it with Emon, inspect plan/team, confirm the required
   sections in Review and approve the exact paper. Edits save automatically.
4. Open Reference controls. Advance named work events through busy wait, delivery
   and a partial-adoption finding. Send feedback; advance application, revised
   evidence, review and coordinator closeout.
5. Inspect Outputs, propose a learning update and prepare an independent follow-up.

The controls also demonstrate MCP draft arrival, newer/unavailable references,
loading/offline/denied states and local reset. Check the paper's explicit human gate
to exercise acknowledgment before closeout. Nothing calls live models or services.

## Mockup: Create a Project Floor

These original office tools remain available at `/` as exploratory local demos.

Choose **＋ New floor** in the rail or navigator. Name and describe the project,
choose resident agents, then configure each person's capabilities, LLM preset,
and reasoning level. **Create a guest expert** adds a specialty, working style,
and optional research brief/sources. Review the setup and move into the new floor.

Select a resident to inspect their profile. **Open project brief → Edit project
& team** revisits the setup. Guests share one identity across floors; their
capability/model settings belong to each floor. Research is supplied context,
not an automated research result. Drafts and completed floors survive reload.

## Mockup: Create a Mission

On any floor choose **+ New mission**, or inspect Emon and choose **Create mission
with Emon**. **Missions** lists that floor's drafts and approved work. The original
Studio walkthrough remains a separate entry with its existing evidence intact.

1. Write your idea and an optional working name; an authored Studio example is available.
2. Shape intention, outcome, scope, context, decisions and acceptance beside Emon's
   question. Confirm essential sections; explicitly defer optional ones.
3. Review the plan and squad. Capabilities, model and reasoning inherit floor
   defaults and can be adjusted for this mission; guest research remains unverified.
4. Inspect the complete paper. Missing confirmations or empty capabilities block approval.
5. **Approve and simulate start** prepares the demo. **Approve and put on hold**
   preserves approval without assignments. Advance preparation, activation,
   assignment, delivery and verification as separate named simulation events.
6. Reopen the paper, download Markdown, or create an independent follow-up.
   Approved versions remain inspectable; active missions cannot be overwritten.

The new flow is local authoring and a simulation, without SQL, provider or agent
connections. It does not generate real deliverables. See the
[mission creation contract](docs/plans/archive/002-mission-creation/spec.md).

## Mockup: Play the Original Story

1. Enter Studio. Drag to pan, scroll to zoom, or use the visible controls.
   Select a named person to inspect their role and current work in the room.
2. Meet Emon at the whiteboard. Use suggestions or your own words; edit any
   section, defer optional references, and inspect the same content as a paper.
3. Approve the paper, choose specialists and capabilities, inspect the plan,
   and launch the local simulation.
4. Advance named work steps. The room shows the active person, next output,
   and last handoff. Open the proposal when it arrives on the review wall.
5. Inspect a source update, anchor your correction to a section, record it as
   follow-up work, accept the proposal, and resolve with evidence.
6. Revisit the outcome, download Markdown, or reuse the mission structure.

Cmd/Ctrl+P opens the native navigator; Escape returns from a work surface.
Every floor shares the Project walkthrough layout: mission shaping, eight workstations,
review, direction, library, operations, entrance and lounge. The Office guide
opens these zones through native controls. Mission state is saved locally;
Reset demo clears them. Recovery from invalid saved data is explicit. The
mission remains usable when 3D rendering is unavailable.

This is an authored, editable scenario with simulated agents. Free text is
preserved literally. Model/reasoning choices are labelled demo presets. No
external mission, source change, or agent session is created. Brand artwork
provenance is in `packages/ui/assets/provenance.json`; fonts are bundled locally.

## Mission Operating Loop

1. Capture a raw thought, objective, problem, transcript, or existing spec.
2. Grill it through an adaptive mission-shaping conversation.
3. Produce a canonical mission paper with requirements, decisions, sources,
   phases, acceptance evidence, and approval boundaries.
4. Classify mission complexity so simple work stays simple.
5. Assemble a mission-scoped squad configuration: agents, skills, models,
   reasoning effort, tools, knowledge, permissions, and human operators.
6. Approve and launch through the approved durable mission lifecycle contract.
7. Inspect execution, conversations, artifacts, blockers, costs, and evidence.
8. Turn review feedback into source updates or explicit follow-up work.
9. Close the mission with accepted evidence and reusable learning.

## Product Boundaries

- **Studio** owns the human experience for mission shaping, initiative
  workspaces, squad configuration, review, and spatial navigation, plus the
  authoritative mission/task domain and durable lifecycle state in this repository.
- **OpenClaw and the Infuse AI harness** own agent sessions, models, skills,
  tools, plugins, and execution.
- **Mission hosting** supports the standalone Studio service and the existing
  native OpenClaw plugin. Production uses the standalone authority with outbound
  native Gateway integration. A deployment has one authoritative store owner;
  Backoffice is not that authority.
- **Repositories and governed knowledge systems** remain canonical for code,
  Markdown, decisions, and other source material.
- **Mattermost** is the primary communication channel in the intended
  experience. Its conversations and actions must link to Studio's mission
  authority through the finalized interaction contract linked above.
- **Backoffice/company administration** may retain finance, infrastructure,
  licensing, agreements, and other corporate operations that do not belong in
  Studio.
- **Client-facing rooms or surfaces** may expose approved client materials
  without making all company operations part of Studio.

## Documentation

- [Agent working guide](AGENTS.md)
- [Product vision](docs/PRODUCT_VISION.md)
- [Pitch card](docs/PITCH_CARD.md)
- [End-to-end operating loop](docs/END_TO_END_USER_FLOW.md)
- [Dogfooding strategy](docs/DOGFOODING_STRATEGY.md)
- [Historical first-slice brief](docs/PROJECT_BRIEF.md)
- [Decision log](docs/DECISIONS.md)
- [ADR index and integration direction](docs/architecture/adr/README.md)
- [Standalone workspace setup](docs/STANDALONE_WORKSPACE.md)
- [Technology stack](docs/architecture/technology-stack.md)
- [Repo map](docs/REPO_MAP.md)
- [Selected design contract](DESIGN.md)
- [Native mission contract](docs/architecture/native-missions.md)
- [Data policy until MVP](database/README.md#data-policy-until-mvp)
- [Historical delivery plans](docs/plans/README.md#archive-reconciliation)

## Source of Truth

`company-docs` owns the Infuse AI company operating model, portfolio,
governance, and durable cross-company decisions. This repository owns the
approved Studio product definition and the Studio
application and its local architecture.

Product prose proves definition, not implementation. Current behavior must be
verified against tracked implementation and runtime evidence when those exist.


## Human skill guides

Skills reads the complete published human guide catalog in admitted Core. Source
Markdown remains in `agent-skills`; the shared Artifact Registry owns exact HTML
revisions. The repo-local [maintenance skill](.agents/skills/studio-skill-guides/SKILL.md)
authors/refines guides, preserves accepted feedback and performs manual refreshes
when requested. **Scheduling is disabled.**

After fetching the source branch, inspect and build from its pinned revision:

```sh
npm run skills:plan -- --source /path/to/agent-skills --ref origin/main
npm run skills:build -- --source /path/to/agent-skills --ref <full-commit>
npm run skills:validate
```

Source changes require source-grounded editorial review before the builder will
advance. For authorized production publication using the existing Tinus helper:

```sh
ARTIFACT_PUBLISH_MODE=registry npm run skills:publish -- \
  --source /path/to/agent-skills --runtime agent-developer \
  --context infuseai-k8s --namespace agents-swarm
```

Credentials remain in the publisher runtime. Unchanged publication is a no-op;
failed or conflicting batches retain the last active catalog. See
[plan 019](docs/plans/active/019-agent-skills-tools/plan.md) for delivery evidence.
