import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { ArtifactRegistry, type ArtifactManifest, type ArtifactRecord } from "../dist/registry.js";
import { createArtifactRegistryServer, type ArtifactAuditEvent } from "../dist/http.js";
import { reconcileArtifactRegistry } from "../dist/reconcile.js";

test("artifact registry publishes a multi-file revision idempotently and preserves bin lifecycle", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-"));
  try {
    const registry = new ArtifactRegistry(root);
    const publication = {
      producer: "agent-developer",
      artifactId: "backoffice-ui-review",
      title: "Backoffice UI review",
      kind: "review",
      files: [
        { path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("<h1>Review</h1>").toString("base64") },
        { path: "images/desktop.png", mediaType: "image/png", contentBase64: Buffer.from("png-test").toString("base64") },
      ],
    };
    const first = await registry.publish(publication);
    const second = await registry.publish({ ...publication, revision: first.manifest.revision });
    assert.equal(first.idempotent, false);
    assert.equal(second.idempotent, true);
    assert.equal((await registry.list("active")).length, 1);
    const file = await registry.content("agent-developer", "backoffice-ui-review", first.manifest.revision, "images/desktop.png");
    assert.equal(file?.body.toString(), "png-test");
    await registry.lifecycle("agent-developer", "backoffice-ui-review", first.manifest.revision, "trash");
    assert.equal((await registry.list("active")).length, 0);
    assert.equal((await registry.list("bin")).length, 1);
    await registry.lifecycle("agent-developer", "backoffice-ui-review", first.manifest.revision, "restore");
    assert.equal((await registry.list("active")).length, 1);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("ordinary artifacts retain immutable history and require the expected current revision", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-versioned-"));
  try {
    const registry = new ArtifactRegistry(root);
    const first = await registry.publish({
      producer: "agent-developer",
      artifactId: "implementation-review",
      title: "Implementation review",
      kind: "review",
      files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("first").toString("base64") }],
    });
    await assert.rejects(() => registry.publish({
      producer: "agent-developer",
      artifactId: "implementation-review",
      title: "Implementation review",
      kind: "review",
      files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("second").toString("base64") }],
    }), /expectedCurrentRevision is required/);

    const second = await registry.publish({
      producer: "agent-developer",
      artifactId: "implementation-review",
      title: "Implementation review",
      kind: "review",
      expectedCurrentRevision: first.manifest.revision,
      files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("second").toString("base64") }],
    });

    assert.notEqual(second.manifest.revision, first.manifest.revision);
    assert.equal((await registry.list("active"))[0].revision, second.manifest.revision);
    assert.deepEqual((await registry.history("agent-developer", "implementation-review")).map((item) => item.revision), [
      first.manifest.revision,
      second.manifest.revision,
    ]);
    assert.equal((await registry.content("agent-developer", "implementation-review", first.manifest.revision, "review.md"))?.body.toString(), "first");
    await assert.rejects(() => registry.publish({
      producer: "agent-developer",
      artifactId: "implementation-review",
      title: "Implementation review",
      kind: "review",
      expectedCurrentRevision: second.manifest.revision,
      files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("first").toString("base64") }],
    }), /historical revision cannot become current/);
    assert.equal((await registry.list("active"))[0].revision, second.manifest.revision);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("a rejected first publication does not leave an empty malformed identity", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-rejected-first-"));
  try {
    const registry = new ArtifactRegistry(root);
    await assert.rejects(() => registry.publish({
      producer: "agent-infra",
      artifactId: "rotation-proof-missing",
      title: "Rejected rotation proof",
      kind: "evidence",
      expectedCurrentRevision: "a".repeat(64),
      files: [{ path: "evidence.txt", mediaType: "text/plain", contentBase64: Buffer.from("bounded fixture").toString("base64") }],
    }), /expected current revision conflict/);

    await assert.rejects(
      stat(path.join(root, "objects", "agent-infra", "rotation-proof-missing")),
      (error: NodeJS.ErrnoException) => error.code === "ENOENT",
    );
    assert.equal((await reconcileArtifactRegistry(root)).status, "healthy");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("existing one-revision lifecycle state upgrades compatibly on the first new revision", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-legacy-state-"));
  try {
    const registry = new ArtifactRegistry(root);
    const first = await registry.publish({
      producer: "agent-designer",
      artifactId: "design-review",
      title: "Design review",
      kind: "review",
      files: [{ path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("first").toString("base64") }],
    });
    const statePath = path.join(root, "objects", "agent-designer", "design-review", "state.json");
    const legacyState = JSON.parse(await readFile(statePath, "utf8")) as Record<string, unknown>;
    delete legacyState.revisions;
    delete legacyState.generation;
    await writeFile(statePath, `${JSON.stringify(legacyState, null, 2)}\n`, { mode: 0o600 });

    const second = await registry.publish({
      producer: "agent-designer",
      artifactId: "design-review",
      title: "Design review",
      kind: "review",
      expectedCurrentRevision: first.manifest.revision,
      files: [{ path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("second").toString("base64") }],
    });

    assert.equal((await registry.list("active"))[0].revision, second.manifest.revision);
    assert.equal((await registry.history("agent-designer", "design-review")).length, 2);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("concurrent stale writers serialize and cannot lose the winning update", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-concurrent-"));
  try {
    const registry = new ArtifactRegistry(root);
    const initial = await registry.publish({
      producer: "agent-infra",
      artifactId: "runtime-evidence",
      title: "Runtime evidence",
      kind: "evidence",
      files: [{ path: "evidence.txt", mediaType: "text/plain", contentBase64: Buffer.from("initial").toString("base64") }],
    });
    const update = (value: string) => registry.publish({
      producer: "agent-infra",
      artifactId: "runtime-evidence",
      title: "Runtime evidence",
      kind: "evidence",
      expectedCurrentRevision: initial.manifest.revision,
      files: [{ path: "evidence.txt", mediaType: "text/plain", contentBase64: Buffer.from(value).toString("base64") }],
    });
    const outcomes = await Promise.allSettled([update("writer-a"), update("writer-b")]);
    assert.equal(outcomes.filter((item) => item.status === "fulfilled").length, 1);
    const rejection = outcomes.find((item): item is PromiseRejectedResult => item.status === "rejected");
    assert.match(String(rejection?.reason), /expected current revision conflict/);
    const current = (await registry.list("active"))[0];
    const history = await registry.history("agent-infra", "runtime-evidence");
    assert.equal(history.length, 2);
    assert.equal(history[1].revision, current.revision);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("journal revisions remain hidden while binned and restore the newest exact revision", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-binned-journal-"));
  try {
    const registry = new ArtifactRegistry(root);
    const first = await registry.publish({
      producer: "agent-coordinator",
      artifactId: "journal",
      title: "Journal",
      kind: "journal",
      files: [{ path: "journal.html", mediaType: "text/html", contentBase64: Buffer.from("first").toString("base64") }],
    });
    await registry.lifecycle("agent-coordinator", "journal", first.manifest.revision, "trash");
    const second = await registry.publish({
      producer: "agent-coordinator",
      artifactId: "journal",
      title: "Journal",
      kind: "journal",
      expectedCurrentRevision: first.manifest.revision,
      files: [{ path: "journal.html", mediaType: "text/html", contentBase64: Buffer.from("second").toString("base64") }],
    });
    assert.equal((await registry.list("active")).length, 0);
    assert.equal((await registry.list("bin"))[0].revision, second.manifest.revision);
    assert.equal((await registry.history("agent-coordinator", "journal")).length, 2);
    await registry.lifecycle("agent-coordinator", "journal", second.manifest.revision, "restore");
    assert.equal((await registry.list("active"))[0].revision, second.manifest.revision);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("purge requires bin state and tombstones ordinary artifact identity", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-"));
  try {
    const registry = new ArtifactRegistry(root);
    const publication = { producer: "agent-designer", artifactId: "ux", title: "UX", kind: "review", files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("review").toString("base64") }] };
    const { manifest } = await registry.publish(publication);
    await assert.rejects(() => registry.lifecycle("agent-designer", "ux", manifest.revision, "purge"), /only a binned/);
    await registry.lifecycle("agent-designer", "ux", manifest.revision, "trash");
    await registry.lifecycle("agent-designer", "ux", manifest.revision, "purge");
    await assert.rejects(() => registry.publish(publication), /tombstoned/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("journal identity can publish a fresh revision after purge", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-journal-"));
  try {
    const registry = new ArtifactRegistry(root);
    const first = await registry.publish({ producer: "agent-coordinator", artifactId: "journal", title: "Journal", kind: "journal", files: [{ path: "journal.html", mediaType: "text/html", contentBase64: Buffer.from("first").toString("base64") }] });
    await registry.lifecycle("agent-coordinator", "journal", first.manifest.revision, "trash");
    await registry.lifecycle("agent-coordinator", "journal", first.manifest.revision, "purge");
    const second = await registry.publish({ producer: "agent-coordinator", artifactId: "journal", title: "Journal", kind: "journal", files: [{ path: "journal.html", mediaType: "text/html", contentBase64: Buffer.from("second").toString("base64") }] });
    assert.notEqual(second.manifest.revision, first.manifest.revision);
    assert.equal((await registry.list("active"))[0].revision, second.manifest.revision);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("artifact bundle rejects traversal", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-"));
  try {
    const registry = new ArtifactRegistry(root);
    await assert.rejects(() => registry.publish({ producer: "agent-infra", artifactId: "bad", title: "Bad", kind: "report", files: [{ path: "../secret", mediaType: "text/plain", contentBase64: Buffer.from("x").toString("base64") }] }), /escapes/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("artifact bundle rejects unsupported media types", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-mime-"));
  try {
    const registry = new ArtifactRegistry(root);
    await assert.rejects(() => registry.publish({ producer: "agent-infra", artifactId: "binary", title: "Binary", kind: "report", files: [{ path: "tool.exe", mediaType: "application/x-msdownload", contentBase64: Buffer.from("x").toString("base64") }] }), /unsupported mediaType/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("artifact bundle accepts zip files as opaque content", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-zip-"));
  try {
    const registry = new ArtifactRegistry(root);
    const result = await registry.publish({ producer: "agent-designer", artifactId: "design-bundle", title: "Design bundle", kind: "handoff", files: [{ path: "design.zip", mediaType: "application/zip", contentBase64: Buffer.from("zip-test").toString("base64") }] });
    assert.equal(result.manifest.files[0].mediaType, "application/zip");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("artifact bundle rejects non-canonical base64", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-base64-"));
  try {
    const registry = new ArtifactRegistry(root);
    await assert.rejects(() => registry.publish({ producer: "agent-infra", artifactId: "bad-base64", title: "Bad", kind: "report", files: [{ path: "report.txt", mediaType: "text/plain", contentBase64: "====" }] }), /invalid base64/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("HTTP service enforces per-producer writes and shared authenticated reads", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-http-"));
  const authPath = path.join(root, "auth.json");
  const writerToken = "writer-test-token-0123456789abcdef";
  const readerToken = "reader-test-token-0123456789abcdef";
  const lifecycleToken = "lifecycle-test-token-0123456789abc";
  const auditEvents: ArtifactAuditEvent[] = [];
  await writeFile(authPath, JSON.stringify({
    schema: "infuse.artifact-auth/v1",
    principals: {
      [createHash("sha256").update(writerToken).digest("hex")]: { subject: "Tinus", producer: "agent-developer", scopes: ["read", "write"] },
      [createHash("sha256").update(readerToken).digest("hex")]: { subject: "Fito", scopes: ["read"] },
      [createHash("sha256").update(lifecycleToken).digest("hex")]: { subject: "Backoffice", scopes: ["lifecycle"] },
    },
  }));
  const server = createArtifactRegistryServer({ root: path.join(root, "store"), authPath, audit: (event) => auditEvents.push(event) });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  const base = `http://127.0.0.1:${address.port}`;
  try {
    const ready = await fetch(`${base}/ready`);
    assert.equal(ready.status, 200);
    const unauthorized = await fetch(`${base}/v1/artifacts`, { headers: { authorization: "Bearer short" } });
    assert.equal(unauthorized.status, 401);
    assert.equal((await unauthorized.json() as { errorCode: string }).errorCode, "unauthorized");
    const mismatched = await fetch(`${base}/v1/artifacts`, { method: "POST", headers: { authorization: `Bearer ${writerToken}`, "content-type": "application/json" }, body: JSON.stringify({ producer: "agent-designer", artifactId: "bad", title: "Bad", kind: "review", files: [{ path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("bad").toString("base64") }] }) });
    assert.equal(mismatched.status, 403);
    const published = await fetch(`${base}/v1/artifacts`, { method: "POST", headers: { authorization: `Bearer ${writerToken}`, "content-type": "application/json" }, body: JSON.stringify({ producer: "agent-developer", artifactId: "good", title: "Good", kind: "review", missionId: "mission-1", taskId: "task-1", sourceRef: "azure:backoffice:2722", files: [{ path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("good").toString("base64") }] }) });
    assert.equal(published.status, 201);
    assert.match(published.headers.get("x-request-id") ?? "", /^[a-f0-9-]{36}$/);
    const firstReceipt = await published.json() as { manifest: ArtifactManifest };
    assert.equal(firstReceipt.manifest.missionId, "mission-1");
    assert.equal(firstReceipt.manifest.taskId, "task-1");
    assert.equal(firstReceipt.manifest.sourceRef, "azure:backoffice:2722");
    const mutationAuditCount = auditEvents.filter((event) => event.action === "publish" && event.outcome === "succeeded").length;
    const idempotent = await fetch(`${base}/v1/artifacts`, { method: "POST", headers: { authorization: `Bearer ${writerToken}`, "content-type": "application/json" }, body: JSON.stringify({ producer: "agent-developer", artifactId: "good", title: "Good", kind: "review", missionId: "mission-1", taskId: "task-1", sourceRef: "azure:backoffice:2722", revision: firstReceipt.manifest.revision, files: [{ path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("good").toString("base64") }] }) });
    assert.equal(idempotent.status, 200);
    assert.equal(auditEvents.filter((event) => event.action === "publish" && event.outcome === "succeeded").length, mutationAuditCount);
    const updated = await fetch(`${base}/v1/artifacts`, { method: "POST", headers: { authorization: `Bearer ${writerToken}`, "content-type": "application/json" }, body: JSON.stringify({ producer: "agent-developer", artifactId: "good", title: "Good", kind: "review", missionId: "mission-1", taskId: "task-1", sourceRef: "azure:backoffice:2722", expectedCurrentRevision: firstReceipt.manifest.revision, files: [{ path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("better").toString("base64") }] }) });
    assert.equal(updated.status, 201);
    const secondReceipt = await updated.json() as { manifest: ArtifactManifest };
    const stale = await fetch(`${base}/v1/artifacts`, { method: "POST", headers: { authorization: `Bearer ${writerToken}`, "content-type": "application/json" }, body: JSON.stringify({ producer: "agent-developer", artifactId: "good", title: "Good", kind: "review", expectedCurrentRevision: firstReceipt.manifest.revision, files: [{ path: "index.html", mediaType: "text/html", contentBase64: Buffer.from("stale").toString("base64") }] }) });
    assert.equal(stale.status, 409);
    const stalePayload = await stale.json() as { errorCode: string; requestId: string };
    assert.equal(stalePayload.errorCode, "revision_conflict");
    assert.equal(stalePayload.requestId, stale.headers.get("x-request-id"));
    const listed = await fetch(`${base}/v1/artifacts`, { headers: { authorization: `Bearer ${readerToken}` } });
    assert.equal(listed.status, 200);
    const listedPayload = (await listed.json()) as { artifacts: ArtifactRecord[] };
    assert.equal(listedPayload.artifacts.length, 1);
    assert.notEqual(listedPayload.artifacts[0].revision, firstReceipt.manifest.revision);
    const history = await fetch(`${base}/v1/artifacts/agent-developer/good/revisions`, { headers: { authorization: `Bearer ${readerToken}` } });
    assert.equal(history.status, 200);
    const historyPayload = await history.json() as { revisions: ArtifactManifest[] };
    assert.deepEqual(historyPayload.revisions.map((item) => item.revision), [firstReceipt.manifest.revision, secondReceipt.manifest.revision]);
    const deniedTrash = await fetch(`${base}/v1/artifacts/agent-developer/good/actions/trash`, { method: "POST", headers: { authorization: `Bearer ${readerToken}`, "content-type": "application/json" }, body: JSON.stringify({ revision: secondReceipt.manifest.revision }) });
    assert.equal(deniedTrash.status, 403);
    const trashed = await fetch(`${base}/v1/artifacts/agent-developer/good/actions/trash`, { method: "POST", headers: { authorization: `Bearer ${lifecycleToken}`, "content-type": "application/json" }, body: JSON.stringify({ revision: secondReceipt.manifest.revision }) });
    assert.equal(trashed.status, 200);
    const auditJson = JSON.stringify(auditEvents);
    assert.equal(auditJson.includes(writerToken), false);
    assert.equal(auditJson.includes("index.html"), false);
    assert.equal(auditJson.includes("better"), false);
    assert.equal(auditEvents.some((event) => event.action === "publish" && event.errorCode === "revision_conflict"), true);
    assert.equal(auditEvents.some((event) => event.action === "trash" && event.outcome === "denied"), true);
    assert.equal(auditEvents.some((event) => event.action === "trash" && event.outcome === "succeeded"), true);
    assert.deepEqual(Object.keys(auditEvents[0]).sort(), ["action", "artifactId", "errorCode", "outcome", "producer", "requestId", "revision", "schema", "subject", "timestamp"]);
  } finally {
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    await rm(root, { recursive: true, force: true });
  }
});

test("HTTP service fails closed without exposing an unavailable auth path", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-auth-"));
  const missingAuthPath = path.join(root, "private", "missing-auth.json");
  const server = createArtifactRegistryServer({ root: path.join(root, "store"), authPath: missingAuthPath, audit: () => undefined });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  try {
    const live = await fetch(`http://127.0.0.1:${address.port}/live`);
    assert.equal(live.status, 200);
    const ready = await fetch(`http://127.0.0.1:${address.port}/ready`);
    assert.equal(ready.status, 503);
    assert.equal((await ready.json() as { errorCode: string }).errorCode, "authentication_unavailable");
    const response = await fetch(`http://127.0.0.1:${address.port}/v1/artifacts`, { headers: { authorization: "Bearer test-token" } });
    assert.equal(response.status, 503);
    const payload = await response.text();
    assert.equal(payload.includes(missingAuthPath), false);
  } finally {
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    await rm(root, { recursive: true, force: true });
  }
});

test("HTTP trust boundary rejects hostile metadata and malformed auth without leaking content", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-trust-"));
  const authPath = path.join(root, "auth.json");
  const writerToken = "writer-trust-token-0123456789abcdef";
  await writeFile(authPath, JSON.stringify({
    schema: "infuse.artifact-auth/v1",
    principals: {
      [createHash("sha256").update(writerToken).digest("hex")]: { subject: "Tinus", producer: "agent-developer", scopes: ["write"] },
    },
  }));
  const auditEvents: ArtifactAuditEvent[] = [];
  const server = createArtifactRegistryServer({ root: path.join(root, "store"), authPath, audit: (event) => auditEvents.push(event) });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  const base = `http://127.0.0.1:${address.port}`;
  const headers = { authorization: `Bearer ${writerToken}`, "content-type": "application/json" };
  try {
    const secretShaped = await fetch(`${base}/v1/artifacts`, { method: "POST", headers, body: JSON.stringify({ producer: "agent-developer", artifactId: "unsafe", title: "Unsafe", kind: "review", summary: "token=do-not-store-this", files: [{ path: "private.txt", mediaType: "text/plain", contentBase64: Buffer.from("sensitive-body").toString("base64") }] }) });
    assert.equal(secretShaped.status, 400);
    assert.equal((await secretShaped.json() as { errorCode: string }).errorCode, "invalid_request");
    const unsupported = await fetch(`${base}/v1/artifacts`, { method: "POST", headers, body: JSON.stringify({ producer: "agent-developer", artifactId: "unsafe", title: "Unsafe", kind: "review", unsupported: true, files: [{ path: "private.txt", mediaType: "text/plain", contentBase64: Buffer.from("sensitive-body").toString("base64") }] }) });
    assert.equal(unsupported.status, 400);
    const auditJson = JSON.stringify(auditEvents);
    assert.equal(auditJson.includes(writerToken), false);
    assert.equal(auditJson.includes("do-not-store-this"), false);
    assert.equal(auditJson.includes("private.txt"), false);
    assert.equal(auditJson.includes("sensitive-body"), false);
  } finally {
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    await rm(root, { recursive: true, force: true });
  }
});

test("readiness rejects malformed principal scope configuration", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-malformed-auth-"));
  const authPath = path.join(root, "auth.json");
  await writeFile(authPath, JSON.stringify({
    schema: "infuse.artifact-auth/v1",
    principals: { ["a".repeat(64)]: { subject: "Tinus", scopes: ["write"] } },
  }));
  const server = createArtifactRegistryServer({ root: path.join(root, "store"), authPath, audit: () => undefined });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");
  try {
    const response = await fetch(`http://127.0.0.1:${address.port}/health`);
    assert.equal(response.status, 503);
    assert.equal((await response.json() as { errorCode: string }).errorCode, "authentication_unavailable");
  } finally {
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    await rm(root, { recursive: true, force: true });
  }
});

test("stored manifest corruption fails closed as an integrity error", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-registry-corrupt-manifest-"));
  try {
    const registry = new ArtifactRegistry(root);
    const result = await registry.publish({ producer: "agent-infra", artifactId: "evidence", title: "Evidence", kind: "report", files: [{ path: "evidence.txt", mediaType: "text/plain", contentBase64: Buffer.from("verified").toString("base64") }] });
    const manifestPath = path.join(root, "objects", "agent-infra", "evidence", "revisions", result.manifest.revision, "manifest.json");
    await writeFile(manifestPath, "{not-json");
    await assert.rejects(() => registry.manifest("agent-infra", "evidence", result.manifest.revision), (error: unknown) => {
      return typeof error === "object" && error !== null && "code" in error && error.code === "integrity_failure";
    });
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
