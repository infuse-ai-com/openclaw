import {fail} from './errors.js';
import type {ArtifactManifest} from './registry.js';
const ID=/^[a-z0-9][a-z0-9._-]{0,127}$/;
const KEYS=new Set(['project','state','cursor','q','scope','mission']);
export interface LibraryQuery {project:string;state:'active'|'bin';cursor:number;q:string;scope:'all'|'mission'|'standalone';mission?:string}
export interface LibraryPage {artifacts:ArtifactManifest[];nextCursor:string|null}
/** Reject duplicate/unknown controls instead of silently broadening a read. */
export function parseLibraryQuery(params:URLSearchParams):LibraryQuery {
 for(const key of params.keys())if(!KEYS.has(key)||params.getAll(key).length!==1)fail('invalid_request','Invalid library query');
 const project=params.get('project')??'',state=params.get('state')??'active',cursor=params.get('cursor')??'0',q=params.get('q')??'',scope=params.get('scope')??'all',mission=params.get('mission')??undefined;
 if(!ID.test(project)||!['active','bin'].includes(state)||!/^(0|[1-9][0-9]{0,3})$/.test(cursor)||Number(cursor)>1000||q.length>200||/[\u0000-\u001f\u007f]/.test(q)||!['all','mission','standalone'].includes(scope)||mission!==undefined&&!ID.test(mission))fail('invalid_request','Invalid library query');
 return {project,state:state as 'active'|'bin',cursor:Number(cursor),q:q.trim().toLowerCase(),scope:scope as LibraryQuery['scope'],...(mission?{mission}:{})};
}
export function matchesLibrary(m:ArtifactManifest,q:LibraryQuery):boolean {
 return m.project===q.project&&(!q.mission||m.missionId===q.mission)&&(q.scope==='all'||(q.scope==='mission'?!!m.missionId:!m.missionId))&&`${m.title} ${m.summary} ${m.producer} ${m.kind}`.toLowerCase().includes(q.q);
}
export function libraryPage(manifests:ArtifactManifest[],cursor:number):LibraryPage {
 // Retain the existing client bound, but fail instead of silently hiding records.
 if(manifests.length>1000)fail('storage_unavailable','Library exceeds the supported record bound');
 manifests.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)||`${a.producer}/${a.artifactId}`.localeCompare(`${b.producer}/${b.artifactId}`));
 const artifacts=manifests.slice(cursor,cursor+24);
 return {artifacts,nextCursor:cursor+artifacts.length<manifests.length?String(cursor+artifacts.length):null};
}
