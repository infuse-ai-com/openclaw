import { readFile } from "node:fs/promises";
import { parseImageStorageConfig, S3ImageStorage } from "./image-storage.js";
import { createArtifactRegistryServer } from "./http.js";

const root = process.env.ARTIFACT_REGISTRY_ROOT;
const authPath = process.env.ARTIFACT_REGISTRY_AUTH_FILE;
const port = Number(process.env.ARTIFACT_REGISTRY_PORT ?? "3010");
const host = process.env.ARTIFACT_REGISTRY_HOST ?? "0.0.0.0";

if (!root || !authPath) throw new Error("ARTIFACT_REGISTRY_ROOT and ARTIFACT_REGISTRY_AUTH_FILE are required");
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("ARTIFACT_REGISTRY_PORT is invalid");

const configuredRoot=root,configuredAuthPath=authPath;
async function main() {
  const images = process.env.ARTIFACT_REGISTRY_IMAGES_CONFIG ? new S3ImageStorage(parseImageStorageConfig(JSON.parse(await readFile(process.env.ARTIFACT_REGISTRY_IMAGES_CONFIG,"utf8")))) : undefined;
  createArtifactRegistryServer({images, root:configuredRoot, authPath:configuredAuthPath }).listen(port, host, () => {
    console.log(`Artifact Registry listening on ${host}:${port}`);
  });
}
void main().catch(()=>{console.error("Artifact Registry startup failed");process.exitCode=1;});
