// Offline only: a review reference attests that every writer of this Registry root is stopped.
import {createHash} from 'node:crypto';
import {lstat,readFile,readdir,rmdir} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {atomicJson,syncDirectory} from './registry.js';
import {fail} from './errors.js';
const ID=/^[a-z0-9][a-z0-9._-]{0,127}$/,DIGEST=/^[a-f0-9]{64}$/;
export interface LockRecoveryPlan {schema:'infuse.registry-lock-recovery-plan/v1';producer:string;artifactId:string;lockIdentity:string;stateDigest:string|null;pendingDigest:string|null;digest:string}
const hash=(v:string|Buffer)=>createHash('sha256').update(v).digest('hex');
async function fileDigest(path:string,max:number):Promise<string|null>{try{const s=await lstat(path);if(!s.isFile()||s.size>max)fail('integrity_failure','Invalid recovery metadata');return hash(await readFile(path));}catch(e){if((e as NodeJS.ErrnoException).code==='ENOENT')return null;throw e;}}
function artifactRoot(root:string,producer:string,artifactId:string){if(!ID.test(producer)||!ID.test(artifactId))fail('invalid_request','Invalid lock identity');return join(resolve(root),'objects',producer,artifactId);}
async function safeDirectory(path:string){const s=await lstat(path);if(!s.isDirectory()||s.isSymbolicLink())fail('integrity_failure','Unsafe recovery directory');return s;}
function planHash(plan:Omit<LockRecoveryPlan,'digest'>){return hash(JSON.stringify(plan));}
export async function planIdentityLockRecovery(root:string,producer:string,artifactId:string):Promise<LockRecoveryPlan>{
 const base=resolve(root),target=artifactRoot(base,producer,artifactId);for(const path of [base,join(base,'objects'),join(base,'objects',producer),target])await safeDirectory(path);
 const lock=await safeDirectory(join(target,'.lock'));if((await readdir(join(target,'.lock'))).length)fail('integrity_failure','Lock recovery requires an empty identity lock');
 const plan:Omit<LockRecoveryPlan,'digest'>={schema:'infuse.registry-lock-recovery-plan/v1',producer,artifactId,lockIdentity:hash(JSON.stringify([lock.dev,lock.ino,lock.birthtimeMs,lock.mtimeMs])),stateDigest:await fileDigest(join(target,'state.json'),1024*1024),pendingDigest:await fileDigest(join(target,'.lifecycle-pending.json'),16384)};
 return {...plan,digest:planHash(plan)};
}
export async function applyIdentityLockRecovery(root:string,producer:string,artifactId:string,expectedDigest:string,quiescedReference:string):Promise<{state:'unlocked';planDigest:string;quiescedReference:string}>{
 if(!DIGEST.test(expectedDigest)||!/^[a-zA-Z0-9][a-zA-Z0-9:._-]{0,159}$/.test(quiescedReference))fail('invalid_request','Exact plan and quiesced review reference are required');
 const target=artifactRoot(root,producer,artifactId),audit=join(target,'.lifecycle-lock-recovery'),receiptPath=join(audit,expectedDigest+'.json');
 const saved=await readFile(receiptPath,'utf8').then(s=>JSON.parse(s)).catch(e=>{if(e.code==='ENOENT')return null;throw e;});
 if(saved){if(saved.planDigest!==expectedDigest||saved.quiescedReference!==quiescedReference)fail('revision_conflict','Lock recovery receipt conflict');if(saved.state==='unlocked')return {state:'unlocked',planDigest:expectedDigest,quiescedReference};}
 let plan:LockRecoveryPlan;
 try{plan=await planIdentityLockRecovery(root,producer,artifactId);}catch(e){
  // A crash between unlink and receipt finalization can be settled only against unchanged metadata.
  if((e as NodeJS.ErrnoException).code!=='ENOENT'||!saved?.plan||await fileDigest(join(target,'state.json'),1024*1024)!==saved.plan.stateDigest||await fileDigest(join(target,'.lifecycle-pending.json'),16384)!==saved.plan.pendingDigest)throw e;
  const receipt={state:'unlocked' as const,planDigest:expectedDigest,quiescedReference};await atomicJson(receiptPath,receipt);return receipt;
 }
 if(plan.digest!==expectedDigest)fail('revision_conflict','Lock or lifecycle state changed since review');
 if((await readdir(audit).catch(()=>[])).length>=1000)fail('storage_unavailable','Lock recovery audit quota requires reconciliation');
 await atomicJson(receiptPath,{state:'prepared',planDigest:expectedDigest,quiescedReference,plan});
 // Recheck the exact filesystem identity immediately before removing only this empty directory.
 if((await planIdentityLockRecovery(root,producer,artifactId)).digest!==expectedDigest)fail('revision_conflict','Lock changed before recovery');
 await rmdir(join(target,'.lock'));await syncDirectory(target);
 const receipt={state:'unlocked' as const,planDigest:expectedDigest,quiescedReference};await atomicJson(receiptPath,receipt);return receipt;
}
