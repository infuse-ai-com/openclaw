import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import {
  createArtifactRegistryBackup,
  restoreArtifactRegistryBackup,
  verifyArtifactRegistryBackup,
} from "../dist/backup.js";
import { reconcileArtifactRegistry } from "../dist/reconcile.js";
import { ArtifactRegistry } from "../dist/registry.js";

async function fixture(root: string): Promise<void> {
  const registry = new ArtifactRegistry(root);
  const first = await registry.publish({
    producer: "agent-developer",
    artifactId: "delivery",
    title: "Delivery",
    kind: "report",
    files: [
      { path: "report.md", mediaType: "text/markdown", contentBase64: Buffer.from("accepted report").toString("base64") },
      { path: "evidence/data.json", mediaType: "application/json", contentBase64: Buffer.from("{}\n").toString("base64") },
    ],
  });
  await registry.publish({
    producer: "agent-developer",
    artifactId: "delivery",
    title: "Delivery v2",
    kind: "report",
    expectedCurrentRevision: first.manifest.revision,
    files: [{ path: "report.md", mediaType: "text/markdown", contentBase64: Buffer.from("accepted report v2").toString("base64") }],
  });
  const purged = await registry.publish({
    producer: "agent-designer",
    artifactId: "retired",
    title: "Retired",
    kind: "review",
    files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("retired review").toString("base64") }],
  });
  await registry.lifecycle("agent-designer", "retired", purged.manifest.revision, "trash", "2026-09-01T08:00:00.000Z");
  await registry.lifecycle("agent-designer", "retired", purged.manifest.revision, "purge", "2026-09-01T08:01:00.000Z");
}

test("backup verifies and restores exact canonical bytes and reconciliation evidence", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-backup-exact-"));
  const source = path.join(root, "source");
  const backup = path.join(root, "backup");
  const restored = path.join(root, "restored");
  try {
    await fixture(source);
    await mkdir(path.join(source, ".readiness"), { recursive: true });
    const sourceReport = await reconcileArtifactRegistry(source);
    const created = await createArtifactRegistryBackup({ sourceRoot: source, backupPath: backup, createdAt: "2026-09-01T09:00:00.000Z" });
    const verified = await verifyArtifactRegistryBackup(backup);
    const result = await restoreArtifactRegistryBackup({ backupPath: backup, destinationRoot: restored });
    const restoredReport = await reconcileArtifactRegistry(restored);
    assert.equal(created.status, "created");
    assert.equal(verified.status, "verified");
    assert.equal(result.status, "restored");
    assert.equal(result.rootDigest, created.rootDigest);
    assert.equal(result.reconciliationDigest, sourceReport.reportDigest);
    assert.equal(restoredReport.reportDigest, sourceReport.reportDigest);
    const manifest = await readFile(path.join(backup, "backup-manifest.json"), "utf8");
    assert.equal(manifest.includes("accepted report"), false);
    assert.equal(manifest.includes("retired review"), false);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("backup fails closed when reconciliation detects corruption or transient residue", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-backup-degraded-"));
  try {
    const source = path.join(root, "source");
    await fixture(source);
    await mkdir(path.join(source, ".readiness"), { recursive: true });
    await writeFile(path.join(source, ".readiness", "stale.probe"), "incomplete readiness probe");
    await assert.rejects(
      createArtifactRegistryBackup({ sourceRoot: source, backupPath: path.join(root, "readiness-backup") }),
      /not quiescent/,
    );
    await rm(path.join(source, ".readiness"), { recursive: true, force: true });
    await mkdir(path.join(source, ".staging", "interrupted"), { recursive: true });
    await assert.rejects(
      createArtifactRegistryBackup({ sourceRoot: source, backupPath: path.join(root, "backup") }),
      /not quiescent/,
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("backup rejects unsafe source entries and nested backup targets", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-backup-unsafe-"));
  try {
    const source = path.join(root, "source");
    await fixture(source);
    await assert.rejects(
      createArtifactRegistryBackup({ sourceRoot: source, backupPath: path.join(source, "backup") }),
      /outside the source root/,
    );
    await symlink("state.json", path.join(source, "objects", "agent-developer", "delivery", "unsafe-link"));
    await assert.rejects(
      createArtifactRegistryBackup({ sourceRoot: source, backupPath: path.join(root, "backup") }),
      /unsafe file type/,
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("verification detects changed and unexpected payload files without exposing content", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-backup-tamper-"));
  try {
    const source = path.join(root, "source");
    const backup = path.join(root, "backup");
    await fixture(source);
    await createArtifactRegistryBackup({ sourceRoot: source, backupPath: backup });
    const manifest = JSON.parse(await readFile(path.join(backup, "backup-manifest.json"), "utf8")) as { files: Array<{ path: string }> };
    const target = path.join(backup, "payload", ...manifest.files[0].path.split("/"));
    await writeFile(target, "private changed content");
    await assert.rejects(verifyArtifactRegistryBackup(backup), (error: Error) => {
      assert.equal(error.message, "artifact registry backup verification failed");
      assert.equal(error.message.includes("private changed content"), false);
      return true;
    });
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("restore requires an empty independent target and never overwrites it", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-backup-target-"));
  try {
    const source = path.join(root, "source");
    const backup = path.join(root, "backup");
    const target = path.join(root, "target");
    await fixture(source);
    await createArtifactRegistryBackup({ sourceRoot: source, backupPath: backup });
    await mkdir(target);
    await writeFile(path.join(target, "keep.txt"), "keep");
    await assert.rejects(
      restoreArtifactRegistryBackup({ backupPath: backup, destinationRoot: target }),
      /must be empty/,
    );
    assert.equal(await readFile(path.join(target, "keep.txt"), "utf8"), "keep");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
