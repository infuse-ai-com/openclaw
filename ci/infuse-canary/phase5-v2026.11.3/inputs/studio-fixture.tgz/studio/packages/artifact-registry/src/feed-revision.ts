import { createHash } from "node:crypto";

export function computeMissionControlContentRevision(
  entries: Array<{ label: string; body: Uint8Array }>,
): string {
  const hash = createHash("sha256");
  for (const entry of [...entries].sort((a, b) => a.label.localeCompare(b.label))) {
    hash.update(entry.label);
    hash.update("\0");
    hash.update(String(entry.body.byteLength));
    hash.update("\0");
    hash.update(entry.body);
  }
  hash.update(`files:${entries.length}`);
  return `sha256:${hash.digest("hex")}`;
}
