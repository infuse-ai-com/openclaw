import {matchesLibrary,libraryPage,type LibraryQuery,type LibraryPage} from './library.js';
import {parseExactCommand,parseExactReceipt,type ExactLifecycleCommand,type ExactLifecycleReceipt,type ExactLifecycleView} from './lifecycle.js';
import { createHash, randomUUID } from "node:crypto";
import { mkdir, open, readFile, readdir, rename, rm, rmdir, stat } from "node:fs/promises";
import path from "node:path";
import { fail } from "./errors.js";
import type { ImageStorage } from "./image-storage.js";

const ID = /^[a-z0-9][a-z0-9._-]{0,127}$/;
const MAX_FILES = 100;
const MAX_BYTES = 25 * 1024 * 1024;
const LOCK_WAIT_MS = 5_000;
const LOCK_RETRY_MS = 25;
const PUBLICATION_KEYS = new Set([
  "producer", "artifactId", "title", "kind", "summary", "project", "tags",
  "intendedConsumer", "missionId", "taskId", "sourceRef",
  "expectedCurrentRevision", "revision", "files",
]);
const FILE_KEYS = new Set(["path", "mediaType", "contentBase64"]);
const MANIFEST_KEYS = new Set([
  "schema", "producer", "artifactId", "title", "kind", "summary", "project", "tags",
  "intendedConsumer", "missionId", "taskId", "sourceRef", "revision", "createdAt", "files",
]);
const MANIFEST_FILE_KEYS = new Set(["path", "mediaType", "bytes", "sha256"]);
const TOMBSTONE_KEYS = new Set(["schema", "producer", "artifactId", "kind", "revision", "sourceRevision", "purgedAt"]);
const SENSITIVE_METADATA = /(?:\b(?:authorization|cookie|password|secret|token)\s*[:=]|https?:\/\/[^/\s:@]+:[^/\s@]+@)/i;
const ALLOWED_MEDIA_TYPES = new Set([
  "application/javascript", "application/json", "application/pdf", "application/zip",
  "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp",
  "text/css", "text/html", "text/javascript", "text/markdown", "text/plain",
]);

export type ArtifactFileInput = { path: string; mediaType: string; contentBase64: string };
export type ArtifactPublication = {
  producer: string;
  artifactId: string;
  title: string;
  kind: string;
  summary?: string;
  project?: string;
  tags?: string[];
  intendedConsumer?: string;
  missionId?: string;
  taskId?: string;
  sourceRef?: string;
  expectedCurrentRevision?: string | null;
  revision?: string;
  files: ArtifactFileInput[];
};
export type ArtifactManifest = {
  schema: "infuse.artifact/v1";
  producer: string;
  artifactId: string;
  title: string;
  kind: string;
  summary: string;
  project: string | null;
  tags: string[];
  intendedConsumer: string | null;
  missionId: string | null;
  taskId: string | null;
  sourceRef: string | null;
  revision: string;
  createdAt: string;
  files: Array<{ path: string; mediaType: string; bytes: number; sha256: string }>;
};
export type ArtifactRecord = {
  producer: string;
  artifactId: string;
  revision: string;
  state: "active" | "bin" | "purged";
  title: string;
  kind: string;
  createdAt: string;
  trashedAt: string | null;
};
export type ArtifactTombstone = {
  schema: "infuse.artifact-tombstone/v1";
  producer: string;
  artifactId: string;
  kind: string;
  revision: string;
  sourceRevision: string;
  purgedAt: string;
};

function normalizeTombstone(value: unknown): ArtifactTombstone {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("integrity_failure", "artifact tombstone is invalid");
  if (Object.keys(value).some((key) => !TOMBSTONE_KEYS.has(key))) fail("integrity_failure", "artifact tombstone contains unsupported fields");
  const candidate = value as Partial<ArtifactTombstone>;
  if (candidate.schema !== "infuse.artifact-tombstone/v1") fail("integrity_failure", "artifact tombstone schema is invalid");
  if (typeof candidate.producer !== "string" || !ID.test(candidate.producer)) fail("integrity_failure", "artifact tombstone producer is invalid");
  if (typeof candidate.artifactId !== "string" || !ID.test(candidate.artifactId)) fail("integrity_failure", "artifact tombstone identity is invalid");
  if (typeof candidate.kind !== "string" || !ID.test(candidate.kind)) fail("integrity_failure", "artifact tombstone kind is invalid");
  if (typeof candidate.revision !== "string" || !/^[a-f0-9]{64}$/.test(candidate.revision)) fail("integrity_failure", "artifact tombstone revision is invalid");
  if (typeof candidate.sourceRevision !== "string" || !/^(?:sha256:)?[a-f0-9]{64}$/.test(candidate.sourceRevision)) fail("integrity_failure", "artifact tombstone source revision is invalid");
  if (typeof candidate.purgedAt !== "string" || !Number.isFinite(Date.parse(candidate.purgedAt))) fail("integrity_failure", "artifact tombstone timestamp is invalid");
  return candidate as ArtifactTombstone;
}
type LifecycleState = {
  state: "active" | "bin" | "purged";
  revision: string;
  revisions: string[];
  generation: number;
  kind: string;
  trashedAt: string | null;
  updatedAt: string;
};

function validateId(value: string, label: string): void {
  if (!ID.test(value)) fail("invalid_request", `${label} has an invalid format`);
}

function exactKeys(value: object, allowed: Set<string>, label: string): void {
  const unexpected = Object.keys(value).filter((key) => !allowed.has(key));
  if (unexpected.length > 0) fail("invalid_request", `${label} contains unsupported fields`);
}

function boundedText(value: unknown, label: string, maximum: number, required = false): string {
  if (value === undefined || value === null) {
    if (required) fail("invalid_request", `${label} is required`);
    return "";
  }
  if (typeof value !== "string") fail("invalid_request", `${label} must be text`);
  const normalized = value.trim();
  if ((required && !normalized) || normalized.length > maximum || /[\u0000-\u001f\u007f]/.test(normalized)) {
    fail("invalid_request", `${label} is invalid`);
  }
  if (SENSITIVE_METADATA.test(normalized)) fail("invalid_request", `${label} contains prohibited secret-shaped metadata`);
  return normalized;
}

export function validateArtifactPublication(publication: ArtifactPublication): void {
  if (!publication || typeof publication !== "object" || Array.isArray(publication)) fail("invalid_request", "publication must be an object");
  exactKeys(publication, PUBLICATION_KEYS, "publication");
  validateId(publication.producer, "producer");
  validateId(publication.artifactId, "artifactId");
  publication.title = boundedText(publication.title, "title", 160, true);
  publication.kind = boundedText(publication.kind, "kind", 64, true);
  validateId(publication.kind, "kind");
  if (publication.summary !== undefined) publication.summary = boundedText(publication.summary, "summary", 1_000);
  if (publication.project !== undefined) publication.project = boundedText(publication.project, "project", 128);
  if (publication.sourceRef !== undefined) publication.sourceRef = boundedText(publication.sourceRef, "sourceRef", 512);
  if (publication.intendedConsumer) validateId(publication.intendedConsumer, "intendedConsumer");
  if (publication.missionId) validateId(publication.missionId, "missionId");
  if (publication.taskId) validateId(publication.taskId, "taskId");
  if (publication.expectedCurrentRevision) validateId(publication.expectedCurrentRevision, "expectedCurrentRevision");
  if (publication.revision) validateId(publication.revision, "revision");
  if (publication.tags !== undefined) {
    if (!Array.isArray(publication.tags) || publication.tags.length > 16) fail("invalid_request", "tags must contain at most 16 entries");
    const tags = publication.tags.map((tag) => boundedText(tag, "tag", 63, true));
    tags.forEach((tag) => validateId(tag, "tag"));
    if (new Set(tags).size !== tags.length) fail("invalid_request", "tags must be unique");
    publication.tags = tags;
  }
}

function integrity(condition: unknown, message: string): asserts condition {
  if (!condition) fail("integrity_failure", message);
}

function validStoredFilePath(value: unknown): value is string {
  if (typeof value !== "string") return false;
  try {
    return safeRelativeFile(value) === value;
  } catch {
    return false;
  }
}

function validStoredMetadata(value: unknown, maximum: number, required = false): value is string {
  return typeof value === "string"
    && value === value.trim()
    && (!required || value.length > 0)
    && value.length <= maximum
    && !/[\u0000-\u001f\u007f]/.test(value)
    && !SENSITIVE_METADATA.test(value);
}

function normalizeManifest(value: unknown, expected: { producer: string; artifactId: string; revision: string }): ArtifactManifest {
  integrity(value && typeof value === "object" && !Array.isArray(value), "artifact manifest is invalid");
  const candidate = value as Partial<ArtifactManifest>;
  const unexpected = Object.keys(candidate).filter((key) => !MANIFEST_KEYS.has(key));
  integrity(unexpected.length === 0, "artifact manifest contains unsupported fields");
  integrity(candidate.schema === "infuse.artifact/v1", "artifact manifest schema is invalid");
  integrity(candidate.producer === expected.producer && candidate.artifactId === expected.artifactId && candidate.revision === expected.revision, "artifact manifest identity is invalid");
  integrity(validStoredMetadata(candidate.title, 160, true), "artifact manifest title is invalid");
  integrity(typeof candidate.kind === "string" && ID.test(candidate.kind), "artifact manifest kind is invalid");
  integrity(validStoredMetadata(candidate.summary, 1_000), "artifact manifest summary is invalid");
  integrity(candidate.project === null || validStoredMetadata(candidate.project, 128), "artifact manifest project is invalid");
  integrity(Array.isArray(candidate.tags) && candidate.tags.length <= 16 && candidate.tags.every((tag) => typeof tag === "string" && ID.test(tag)), "artifact manifest tags are invalid");
  integrity(candidate.intendedConsumer === null || (typeof candidate.intendedConsumer === "string" && ID.test(candidate.intendedConsumer)), "artifact manifest consumer is invalid");
  integrity(candidate.missionId === undefined || candidate.missionId === null || (typeof candidate.missionId === "string" && ID.test(candidate.missionId)), "artifact manifest mission is invalid");
  integrity(candidate.taskId === undefined || candidate.taskId === null || (typeof candidate.taskId === "string" && ID.test(candidate.taskId)), "artifact manifest task is invalid");
  integrity(candidate.sourceRef === undefined || candidate.sourceRef === null || validStoredMetadata(candidate.sourceRef, 512), "artifact manifest source reference is invalid");
  integrity(typeof candidate.createdAt === "string" && Number.isFinite(Date.parse(candidate.createdAt)), "artifact manifest timestamp is invalid");
  integrity(Array.isArray(candidate.files) && candidate.files.length > 0 && candidate.files.length <= MAX_FILES, "artifact manifest files are invalid");
  const seen = new Set<string>();
  for (const file of candidate.files) {
    integrity(file && typeof file === "object" && !Array.isArray(file), "artifact manifest file is invalid");
    integrity(Object.keys(file).every((key) => MANIFEST_FILE_KEYS.has(key)), "artifact manifest file contains unsupported fields");
    integrity(validStoredFilePath(file.path) && !seen.has(file.path), "artifact manifest file path is invalid");
    seen.add(file.path);
    integrity(typeof file.mediaType === "string" && ALLOWED_MEDIA_TYPES.has(file.mediaType), "artifact manifest media type is invalid");
    integrity(Number.isSafeInteger(file.bytes) && file.bytes >= 0 && file.bytes <= MAX_BYTES, "artifact manifest file size is invalid");
    integrity(typeof file.sha256 === "string" && /^[a-f0-9]{64}$/.test(file.sha256), "artifact manifest digest is invalid");
  }
  integrity(candidate.files.reduce((sum, file) => sum + file.bytes, 0) <= MAX_BYTES, "artifact manifest total size is invalid");
  integrity(new Set(candidate.tags).size === candidate.tags.length, "artifact manifest tags are invalid");
  return {
    ...(candidate as ArtifactManifest),
    missionId: candidate.missionId ?? null,
    taskId: candidate.taskId ?? null,
    sourceRef: candidate.sourceRef ?? null,
  };
}

function safeRelativeFile(value: string): string {
  if (typeof value !== "string" || !value || value.includes("\\") || path.isAbsolute(value)) fail("invalid_request", "file path must be relative");
  const normalized = path.posix.normalize(value);
  if (normalized === "." || normalized.startsWith("../") || normalized.includes("/../") || normalized.startsWith("/")) {
    fail("invalid_request", "file path escapes the artifact bundle");
  }
  return normalized;
}

function decodeBase64(value: string, relativePath: string): Buffer {
  const compact = value.replace(/\s/g, "");
  const canonical = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
  if (compact.length % 4 !== 0 || !canonical.test(compact)) {
    fail("invalid_request", `invalid base64 content for ${relativePath}`);
  }
  const content = Buffer.from(compact, "base64");
  if (content.toString("base64") !== compact) {
    fail("invalid_request", `invalid base64 content for ${relativePath}`);
  }
  return content;
}

async function exists(filePath: string): Promise<boolean> {
  try { await stat(filePath); return true; } catch { return false; }
}

function errorCode(error: unknown): string | undefined {
  return error && typeof error === "object" && "code" in error
    ? String((error as { code?: unknown }).code)
    : undefined;
}

function sha256Text(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export async function syncDirectory(directory: string): Promise<void> {
  let handle: Awaited<ReturnType<typeof open>> | undefined;
  try {
    handle = await open(directory, "r");
    await handle.sync();
  } catch (error) {
    if (!new Set(["EINVAL", "ENOTSUP", "EISDIR"]).has(errorCode(error) ?? "")) throw error;
  } finally {
    await handle?.close();
  }
}

async function durableFile(filePath: string, content: string | Buffer): Promise<void> {
  await mkdir(path.dirname(filePath), { recursive: true });
  const handle = await open(filePath, "w", 0o600);
  try {
    await handle.writeFile(content);
    await handle.sync();
  } finally {
    await handle.close();
  }
  await syncDirectory(path.dirname(filePath));
}

export async function atomicJson(filePath: string, value: unknown): Promise<void> {
  await mkdir(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.${randomUUID()}.tmp`;
  await durableFile(temporary, `${JSON.stringify(value, null, 2)}\n`);
  await rename(temporary, filePath);
  await syncDirectory(path.dirname(filePath));
}

function normalizeState(value: unknown): LifecycleState {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("integrity_failure", "artifact lifecycle state is invalid");
  const candidate = value as Partial<LifecycleState>;
  if (!candidate.state || !(["active", "bin", "purged"] as string[]).includes(candidate.state)) fail("integrity_failure", "artifact lifecycle state is invalid");
  if (typeof candidate.revision !== "string" || !ID.test(candidate.revision)) fail("integrity_failure", "artifact lifecycle revision is invalid");
  if (typeof candidate.kind !== "string" || !ID.test(candidate.kind)) fail("integrity_failure", "artifact lifecycle kind is invalid");
  const legacyRevisions = candidate.state === "purged" ? [] : [candidate.revision];
  const revisions = candidate.revisions ?? legacyRevisions;
  if (!Array.isArray(revisions) || revisions.some((revision) => typeof revision !== "string" || !ID.test(revision))) {
    fail("integrity_failure", "artifact lifecycle revisions are invalid");
  }
  if (new Set(revisions).size !== revisions.length) fail("integrity_failure", "artifact lifecycle revisions must be unique");
  if (candidate.state !== "purged" && !revisions.includes(candidate.revision)) fail("integrity_failure", "current artifact revision is missing from history");
  if (candidate.state === "purged" && revisions.length > 0) fail("integrity_failure", "purged artifact revisions must be empty");
  if (candidate.generation !== undefined && (!Number.isSafeInteger(candidate.generation) || Number(candidate.generation) <= 0)) {
    fail("integrity_failure", "artifact lifecycle generation is invalid");
  }
  if (candidate.trashedAt !== null && candidate.trashedAt !== undefined && (typeof candidate.trashedAt !== "string" || !Number.isFinite(Date.parse(candidate.trashedAt)))) {
    fail("integrity_failure", "artifact lifecycle trash timestamp is invalid");
  }
  if (candidate.state === "active" && candidate.trashedAt !== null && candidate.trashedAt !== undefined) fail("integrity_failure", "active artifact cannot have a trash timestamp");
  if ((candidate.state === "bin" || candidate.state === "purged") && !candidate.trashedAt) fail("integrity_failure", "inactive artifact requires a trash timestamp");
  if (typeof candidate.updatedAt !== "string" || !Number.isFinite(Date.parse(candidate.updatedAt))) fail("integrity_failure", "artifact lifecycle update timestamp is invalid");
  return {
    state: candidate.state,
    revision: candidate.revision,
    revisions,
    generation: Number.isSafeInteger(candidate.generation) && Number(candidate.generation) > 0 ? Number(candidate.generation) : 1,
    kind: candidate.kind,
    trashedAt: candidate.trashedAt ?? null,
    updatedAt: candidate.updatedAt,
  };
}

async function loadState(filePath: string): Promise<LifecycleState> {
  try {
    return normalizeState(JSON.parse(await readFile(filePath, "utf8")));
  } catch (error) {
    if (error instanceof SyntaxError) fail("integrity_failure", "artifact lifecycle state is invalid JSON");
    throw error;
  }
}

export type ArtifactRevisionMetadata = {
  producer: string;
  artifactId: string;
  title: string;
  kind: string;
  summary?: string | null;
  project?: string | null;
  tags?: string[] | null;
  intendedConsumer?: string | null;
  missionId?: string | null;
  taskId?: string | null;
  sourceRef?: string | null;
};

export function computeArtifactRevision(
  publication: ArtifactRevisionMetadata,
  files: Array<{ path: string; mediaType: string; bytes: number; sha256: string }>,
): string {
  const canonical = JSON.stringify({
    producer: publication.producer,
    artifactId: publication.artifactId,
    title: publication.title,
    kind: publication.kind,
    summary: publication.summary ?? "",
    project: publication.project ?? null,
    tags: [...(publication.tags ?? [])].sort(),
    intendedConsumer: publication.intendedConsumer ?? null,
    missionId: publication.missionId ?? null,
    taskId: publication.taskId ?? null,
    sourceRef: publication.sourceRef ?? null,
    files: [...files].sort((a, b) => a.path.localeCompare(b.path)),
  });
  return createHash("sha256").update(canonical).digest("hex");
}

export class ArtifactRegistry {
  constructor(private readonly root: string, private readonly images?: ImageStorage) {}

  private artifactRoot(producer: string, artifactId: string): string {
    validateId(producer, "producer");
    validateId(artifactId, "artifactId");
    return path.join(this.root, "objects", producer, artifactId);
  }

  private tombstonePath(producer: string, artifactId: string): string {
    return path.join(this.root, "tombstones", producer, `${artifactId}.json`);
  }

  private async withIdentityLock<T>(producer: string, artifactId: string, operation: () => Promise<T>): Promise<T> {
    const artifactRoot = this.artifactRoot(producer, artifactId);
    const artifactRootExisted = await exists(artifactRoot);
    await mkdir(artifactRoot, { recursive: true });
    const lockPath = path.join(artifactRoot, ".lock");
    const deadline = Date.now() + LOCK_WAIT_MS;
    while (true) {
      try {
        await mkdir(lockPath);
        break;
      } catch (error) {
        if (errorCode(error) === "ENOENT") {
          await mkdir(artifactRoot, { recursive: true });
          continue;
        }
        if (errorCode(error) !== "EEXIST") throw error;
        if (Date.now() >= deadline) fail("storage_unavailable", "artifact identity is busy");
        await new Promise((resolve) => setTimeout(resolve, LOCK_RETRY_MS));
      }
    }
    try {
      return await operation();
    } finally {
      await rm(lockPath, { recursive: true, force: true });
      if (!artifactRootExisted) {
        await rmdir(artifactRoot).catch((error: NodeJS.ErrnoException) => {
          if (error.code !== "ENOENT" && error.code !== "ENOTEMPTY" && error.code !== "EEXIST") throw error;
        });
      }
    }
  }

  async publish(publication: ArtifactPublication): Promise<{ manifest: ArtifactManifest; idempotent: boolean }> {
    validateArtifactPublication(publication);
    if (!Array.isArray(publication.files) || publication.files.length === 0 || publication.files.length > MAX_FILES) {
      fail("invalid_request", `files must contain 1-${MAX_FILES} entries`);
    }
    const seen = new Set<string>();
    let totalBytes = 0;
    const decoded = publication.files.map((file) => {
      if (!file || typeof file !== "object" || Array.isArray(file)) fail("invalid_request", "file entry must be an object");
      exactKeys(file, FILE_KEYS, "file entry");
      const relativePath = safeRelativeFile(file.path);
      if (seen.has(relativePath)) fail("invalid_request", `duplicate file path: ${relativePath}`);
      seen.add(relativePath);
      if (typeof file.mediaType !== "string" || !ALLOWED_MEDIA_TYPES.has(file.mediaType)) fail("invalid_request", `unsupported mediaType for ${relativePath}`);
      if (typeof file.contentBase64 !== "string") fail("invalid_request", `contentBase64 is required for ${relativePath}`);
      const content = decodeBase64(file.contentBase64, relativePath);
      totalBytes += content.length;
      if (totalBytes > MAX_BYTES) fail("invalid_request", `bundle exceeds ${MAX_BYTES} bytes`);
      return { relativePath, mediaType: file.mediaType, content, sha256: createHash("sha256").update(content).digest("hex") };
    });
    const fileMetadata = decoded.map((file) => ({ path: file.relativePath, mediaType: file.mediaType, bytes: file.content.length, sha256: file.sha256 }));
    const revision = computeArtifactRevision(publication, fileMetadata);
    if (publication.revision && publication.revision !== revision) fail("invalid_request", "supplied revision does not match bundle content");

    return this.withIdentityLock(publication.producer, publication.artifactId, async () => {
      const artifactRoot = this.artifactRoot(publication.producer, publication.artifactId);
      await this.assertNoPending(artifactRoot);
      const statePath = path.join(artifactRoot, "state.json");
      const previousState = await exists(statePath)
        ? await loadState(statePath)
        : null;
      const isJournal = publication.kind === "journal";
      if (publication.kind === "whiteboard-image" && (!this.images || !publication.project)) fail("storage_unavailable", "Image storage is not configured");
      if (publication.kind === "whiteboard-image" && previousState && previousState.revision !== revision) fail("revision_conflict", "An image identity is immutable");
      if (previousState?.state === "purged" && previousState.kind !== "journal") fail("tombstoned", "artifact identity is permanently tombstoned");
      if (previousState && previousState.kind !== publication.kind) fail("revision_conflict", "artifact kind cannot change across revisions");

      const revisionRoot = path.join(artifactRoot, "revisions", revision);
      const manifestPath = path.join(revisionRoot, "manifest.json");
      const storedManifest = await exists(manifestPath)
        ? await this.manifest(publication.producer, publication.artifactId, revision)
        : null;
      if (storedManifest && previousState?.revision === revision) {
        return { manifest: storedManifest, idempotent: true };
      }
      if (storedManifest && previousState?.revisions.includes(revision)) fail("revision_conflict", "a historical revision cannot become current through publication");

      if (previousState?.state === "bin" && !isJournal) fail("revision_conflict", "restore the artifact before publishing a new revision");
      if (previousState && previousState.state !== "purged") {
        if (!publication.expectedCurrentRevision) fail("revision_conflict", "expectedCurrentRevision is required when advancing an artifact");
        if (publication.expectedCurrentRevision !== previousState.revision) fail("revision_conflict", "expected current revision conflict");
      } else if (previousState?.state === "purged" && publication.expectedCurrentRevision && publication.expectedCurrentRevision !== previousState.revision) {
        fail("revision_conflict", "expected current revision conflict");
      } else if (!previousState && publication.expectedCurrentRevision) {
        fail("revision_conflict", "expected current revision conflict");
      }

      let manifest = storedManifest;
      if (!manifest) {
        const stagingRoot = path.join(this.root, ".staging", `${publication.producer}-${publication.artifactId}-${revision}-${process.pid}-${randomUUID()}`);
        await rm(stagingRoot, { recursive: true, force: true });
        try {
          await mkdir(path.join(stagingRoot, "files"), { recursive: true });
          for (const file of decoded) {
            const target = path.join(stagingRoot, "files", ...file.relativePath.split("/"));
            if (publication.kind === "whiteboard-image") {
              await atomicJson(path.join(artifactRoot,"image-storage.json"),{schema:"infuse.image-storage/v1",project:publication.project});
              await this.images!.put(publication.project!, publication.producer + '/' + publication.artifactId, revision, file.sha256, file.content);
            } else await durableFile(target, file.content);
          }
          manifest = {
            schema: "infuse.artifact/v1",
            producer: publication.producer,
            artifactId: publication.artifactId,
            title: publication.title,
            kind: publication.kind,
            summary: publication.summary ?? "",
            project: publication.project ?? null,
            tags: publication.tags ?? [],
            intendedConsumer: publication.intendedConsumer ?? null,
            missionId: publication.missionId ?? null,
            taskId: publication.taskId ?? null,
            sourceRef: publication.sourceRef ?? null,
            revision,
            createdAt: new Date().toISOString(),
            files: fileMetadata,
          };
          await atomicJson(path.join(stagingRoot, "manifest.json"), manifest);
          await mkdir(path.dirname(revisionRoot), { recursive: true });
          await rename(stagingRoot, revisionRoot);
          await syncDirectory(path.dirname(revisionRoot));
        } finally {
          await rm(stagingRoot, { recursive: true, force: true });
        }
      }

      const resetAfterJournalPurge = previousState?.state === "purged" && isJournal;
      const revisions = previousState && !resetAfterJournalPurge
        ? [...previousState.revisions, ...(!previousState.revisions.includes(revision) ? [revision] : [])]
        : [revision];
      const nextState: LifecycleState = {
        state: previousState?.state === "bin" && isJournal ? "bin" : "active",
        revision,
        revisions,
        generation: (previousState?.generation ?? 0) + 1,
        kind: publication.kind,
        trashedAt: previousState?.state === "bin" && isJournal ? previousState.trashedAt : null,
        updatedAt: new Date().toISOString(),
      };
      await atomicJson(statePath, nextState);
      return { manifest, idempotent: Boolean(storedManifest) };
    });
  }

  private async *entries(stateFilter: "active" | "bin" | "all") {
    const objectsRoot = path.join(this.root, "objects");
    const producers = await readdir(objectsRoot, { withFileTypes: true }).catch(() => []);
    for (const producerEntry of producers.filter((entry) => entry.isDirectory())) {
      const artifactEntries = await readdir(path.join(objectsRoot, producerEntry.name), { withFileTypes: true }).catch(() => []);
      for (const artifactEntry of artifactEntries.filter((entry) => entry.isDirectory())) {
        const artifactRoot = this.artifactRoot(producerEntry.name, artifactEntry.name);
        try {
          const state = await loadState(path.join(artifactRoot, "state.json"));
          if (stateFilter !== "all" && state.state !== stateFilter) continue;
          const manifest = await this.manifest(producerEntry.name, artifactEntry.name, state.revision);
          const record: ArtifactRecord = { producer: producerEntry.name, artifactId: artifactEntry.name, revision: state.revision, state: state.state, title: manifest?.title ?? artifactEntry.name, kind: manifest?.kind ?? "artifact", createdAt: manifest?.createdAt ?? state.updatedAt, trashedAt: state.trashedAt };
          yield { record, manifest };
        } catch { /* fail closed on malformed entries */ }
      }
    }
  }

  async list(stateFilter: "active" | "bin" | "all" = "active"): Promise<ArtifactRecord[]> {
    const records: ArtifactRecord[] = [];
    for await (const {record} of this.entries(stateFilter)) records.push(record);
    return records.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  /** Exact active metadata without walking other identities or revision history. */
  async current(producer: string, artifactId: string, project: string): Promise<ArtifactManifest | null> {
    validateId(project, "project");
    const statePath = path.join(this.artifactRoot(producer, artifactId), "state.json");
    try {
      const state = await loadState(statePath);
      if (state.state !== "active") return null;
      const manifest = await this.manifest(producer, artifactId, state.revision);
      if (!manifest) fail("integrity_failure", "current artifact manifest is missing");
      return manifest.project === project ? manifest : null;
    } catch (error) {
      if (errorCode(error) === "ENOENT") return null;
      throw error;
    }
  }

  /** One scan yields verified current metadata; filtering precedes pagination. */
  async library(query: LibraryQuery): Promise<LibraryPage> {
    const manifests: ArtifactManifest[] = [];
    for await (const {manifest} of this.entries(query.state)) {
      if (manifest && matchesLibrary(manifest, query)) manifests.push(manifest);
    }
    return libraryPage(manifests, query.cursor);
  }

  async manifest(producer: string, artifactId: string, revision: string): Promise<ArtifactManifest | null> {
    validateId(revision, "revision");
    try {
      const parsed = JSON.parse(await readFile(path.join(this.artifactRoot(producer, artifactId), "revisions", revision, "manifest.json"), "utf8"));
      return normalizeManifest(parsed, { producer, artifactId, revision });
    } catch (error) {
      if (errorCode(error) === "ENOENT") return null;
      if (error instanceof SyntaxError) fail("integrity_failure", "artifact manifest is invalid JSON");
      throw error;
    }
  }

  async readiness(): Promise<void> {
    const readinessRoot = path.join(this.root, ".readiness");
    const probePath = path.join(readinessRoot, `${process.pid}-${randomUUID()}.probe`);
    const expected = randomUUID();
    try {
      await durableFile(probePath, expected);
      const actual = await readFile(probePath, "utf8");
      if (actual !== expected) fail("integrity_failure", "artifact storage readiness probe failed");
    } catch (error) {
      if (error && typeof error === "object" && "code" in error && String(error.code) === "integrity_failure") throw error;
      fail("storage_unavailable", "artifact storage is unavailable");
    } finally {
      await rm(probePath, { force: true }).catch(() => undefined);
      await syncDirectory(readinessRoot).catch(() => undefined);
    }
  }

  async history(producer: string, artifactId: string): Promise<ArtifactManifest[]> {
    const statePath = path.join(this.artifactRoot(producer, artifactId), "state.json");
    try {
      const state = await loadState(statePath);
      const manifests = await Promise.all(state.revisions.map((revision) => this.manifest(producer, artifactId, revision)));
      if (manifests.some((manifest) => !manifest)) fail("integrity_failure", "artifact revision history is incomplete");
      return manifests as ArtifactManifest[];
    } catch (error) {
      if (errorCode(error) === "ENOENT") return [];
      throw error;
    }
  }

  async content(producer: string, artifactId: string, revision: string, filePath: string): Promise<{ body: Buffer; mediaType: string } | null> {
    const manifest = await this.manifest(producer, artifactId, revision);
    if (!manifest) return null;
    const relativePath = safeRelativeFile(filePath);
    const metadata = manifest.files.find((file) => file.path === relativePath);
    if (!metadata) return null;
    if (manifest.kind === "whiteboard-image" && (!this.images || !manifest.project)) fail("storage_unavailable", "Image storage is not configured");
    const body = manifest.kind === "whiteboard-image"
      ? await this.images!.get(manifest.project!, producer + '/' + artifactId, revision, metadata.sha256)
      : await readFile(path.join(this.artifactRoot(producer, artifactId), "revisions", revision, "files", ...relativePath.split("/")));
    if (createHash("sha256").update(body).digest("hex") !== metadata.sha256) fail("integrity_failure", "stored artifact content failed integrity verification");
    return { body, mediaType: metadata.mediaType };
  }

  async importPurgedIdentity(input: {
    producer: string;
    artifactId: string;
    kind: string;
    sourceRevision: string;
    purgedAt: string;
  }): Promise<{ tombstone: ArtifactTombstone | null; idempotent: boolean }> {
    validateId(input.producer, "producer");
    validateId(input.artifactId, "artifactId");
    validateId(input.kind, "kind");
    if (!/^(?:sha256:)?[a-f0-9]{64}$/.test(input.sourceRevision)) fail("invalid_request", "sourceRevision is invalid");
    if (!Number.isFinite(Date.parse(input.purgedAt))) fail("invalid_request", "purgedAt is invalid");
    const purgedAt = new Date(input.purgedAt).toISOString();
    return this.withIdentityLock(input.producer, input.artifactId, async () => {
      const artifactRoot = this.artifactRoot(input.producer, input.artifactId);
      await this.assertNoPending(artifactRoot);
      const statePath = path.join(artifactRoot, "state.json");
      const previousState = await exists(statePath) ? await loadState(statePath) : null;
      if (previousState && (previousState.state !== "purged" || previousState.kind !== input.kind)) {
        fail("revision_conflict", "cannot import a tombstone over an existing artifact");
      }
      const revision = sha256Text(JSON.stringify({ producer: input.producer, artifactId: input.artifactId, kind: input.kind, sourceRevision: input.sourceRevision }));
      const tombstone: ArtifactTombstone | null = input.kind === "journal" ? null : {
        schema: "infuse.artifact-tombstone/v1",
        producer: input.producer,
        artifactId: input.artifactId,
        kind: input.kind,
        revision,
        sourceRevision: input.sourceRevision,
        purgedAt,
      };
      const tombstonePath = this.tombstonePath(input.producer, input.artifactId);
      let existingTombstone: ArtifactTombstone | null = null;
      if (tombstone && await exists(tombstonePath)) {
        try {
          existingTombstone = normalizeTombstone(JSON.parse(await readFile(tombstonePath, "utf8")));
        } catch (error) {
          if (error instanceof SyntaxError) fail("integrity_failure", "artifact tombstone is invalid JSON");
          throw error;
        }
        if (JSON.stringify(existingTombstone) !== JSON.stringify(tombstone)) fail("integrity_failure", "artifact tombstone conflicts with imported evidence");
        if (!previousState) fail("integrity_failure", "artifact tombstone has no canonical lifecycle state");
      }
      if (previousState && (!tombstone || existingTombstone)) {
        return { tombstone, idempotent: true };
      }
      await rm(path.join(artifactRoot, "revisions"), { recursive: true, force: true });
      await atomicJson(statePath, {
        state: "purged",
        revision,
        revisions: [],
        generation: (previousState?.generation ?? 0) + 1,
        kind: input.kind,
        trashedAt: purgedAt,
        updatedAt: purgedAt,
      } satisfies LifecycleState);
      if (tombstone) await atomicJson(tombstonePath, tombstone);
      return { tombstone, idempotent: false };
    });
  }

  /** Additive exact lifecycle protocol. Old v1 clients retain their wire format. */
  private async assertNoPending(artifactRoot: string): Promise<void> {
    if (await exists(path.join(artifactRoot, '.lifecycle-pending.json'))) fail('revision_conflict', 'An exact lifecycle command requires reconciliation');
  }

  async lifecycleView(producer: string, artifactId: string, project: string): Promise<ExactLifecycleView> {
    validateId(project, 'project');
    return this.withIdentityLock(producer, artifactId, async () => {
      const root = this.artifactRoot(producer, artifactId), state = await loadState(path.join(root, 'state.json'));
      const manifest = await this.manifest(producer, artifactId, state.revision);
      const context = manifest ? {project:manifest.project} : await readJsonOptional(path.join(root, '.lifecycle-context.json'));
      if (context?.project !== project) fail('not_found', 'Artifact is outside this project');
      return {project,producer,artifactId,revision:state.revision,generation:state.generation,state:state.state,updatedAt:state.updatedAt,trashedAt:state.trashedAt,pending:await exists(path.join(root,'.lifecycle-pending.json'))};
    });
  }

  async lifecycleAudit(producer: string, artifactId: string, project: string, before?: string): Promise<{receipts:ExactLifecycleReceipt[];nextCursor:string|null}> {
    await this.lifecycleView(producer,artifactId,project);
    if(before!==undefined&&!/^[a-f0-9]{64}$/.test(before))fail('invalid_request','Invalid receipt cursor');
    const root=path.join(this.artifactRoot(producer,artifactId),'.lifecycle-receipts');
    const names=(await readdir(root).catch(()=>[])).filter(n=>/^[a-f0-9]{64}\.json$/.test(n)).sort().filter(n=>before===undefined||n<before+'.json').reverse().slice(0,51);
    const receipts:ExactLifecycleReceipt[]=[];
    for(const name of names.slice(0,50)){
      const value=await readJsonOptional(path.join(root,name));
      if(value){const receipt=checkedReceipt(value);if(receipt.project===project)receipts.push(receipt);}
    }
    return {receipts,nextCursor:names.length>50?names[49].slice(0,-5):null};
  }

  async exactLifecycle(command: ExactLifecycleCommand, clientId = 'registry-local'): Promise<ExactLifecycleReceipt> {
    command=parseExactCommand(command);
    const {producer,artifactId,project,revision,generation,action}=command;
    return this.withIdentityLock(producer,artifactId,async()=>{
      const root=this.artifactRoot(producer,artifactId), receiptRoot=path.join(root,'.lifecycle-receipts');
      const key=createHash('sha256').update(command.commandId).digest('hex'), fingerprint=createHash('sha256').update(JSON.stringify([command,clientId])).digest('hex');
      const receiptPath=path.join(receiptRoot,key+'.json'),pendingPath=path.join(root,'.lifecycle-pending.json');
      const saved=await readJsonOptional(receiptPath),pending=await readJsonOptional(pendingPath);
      if(saved){
        if(saved.fingerprint!==fingerprint)fail('revision_conflict','Command ID content conflict');
        const receipt=checkedReceipt(saved);
        assertReceiptCommand(receipt,command);
        if(pending?.fingerprint===fingerprint){await rm(pendingPath);await syncDirectory(root);}
        return receipt;
      }
      if(pending&&pending.fingerprint!==fingerprint)fail('revision_conflict','Another exact lifecycle command requires reconciliation');
      let receipt:ExactLifecycleReceipt;
      if(pending){
        receipt=checkedReceipt(pending);
        assertReceiptCommand(receipt,command);
        if(JSON.stringify(pending.command)!==JSON.stringify(command)||receipt.generation!==generation+1||receipt.revision!==revision||receipt.project!==project)fail('integrity_failure','Invalid lifecycle intent');
      }else{
        const state=await loadState(path.join(root,'state.json'));
        if(state.revision!==revision||state.generation!==generation)fail('revision_conflict','Lifecycle generation changed');
        if(action==='trash'?state.state!=='active':state.state!=='bin')fail('revision_conflict','Lifecycle state changed');
        const manifest=await this.manifest(producer,artifactId,revision);
        if(!manifest||manifest.project!==project)fail('not_found','Artifact is outside this project');
        if((await readdir(receiptRoot).catch(()=>[])).length>=10000)fail('storage_unavailable','Lifecycle receipt quota requires reconciliation');
        receipt={schema:'infuse.artifact-lifecycle-receipt/v1',...command,generation:generation+1,state:action==='trash'?'bin':action==='restore'?'active':'purged',occurredAt:new Date().toISOString()};
        await atomicJson(path.join(root,'.lifecycle-context.json'),{project});
        await atomicJson(pendingPath,{schema:'infuse.artifact-lifecycle-intent/v1',command,fingerprint,receipt,receiptDigest:receiptHash(receipt)});
      }
      const current=await loadState(path.join(root,'state.json'));
      if(current.revision!==revision)fail('integrity_failure','Pending lifecycle revision changed');
      if(current.generation===generation){
        await this.applyLifecycle(producer,artifactId,revision,action,receipt.occurredAt);
      }else if(current.generation!==receipt.generation||current.state!==receipt.state||current.updatedAt!==receipt.occurredAt){
        fail('integrity_failure','Pending lifecycle generation changed');
      }
      // Complete a purge tombstone even if the process stopped after state commit.
      const complete=await loadState(path.join(root,'state.json'));
      if(action==='purge'&&complete.kind!=='journal')await atomicJson(this.tombstonePath(producer,artifactId),{schema:'infuse.artifact-tombstone/v1',producer,artifactId,kind:complete.kind,revision,sourceRevision:revision,purgedAt:receipt.occurredAt} satisfies ArtifactTombstone);
      await atomicJson(receiptPath,{fingerprint,receipt,receiptDigest:receiptHash(receipt)});
      await rm(pendingPath);await syncDirectory(root);
      return receipt;
    });
  }

  async lifecycle(producer: string, artifactId: string, revision: string, action: "trash" | "restore" | "purge", occurredAt?: string): Promise<LifecycleState> {
    return this.withIdentityLock(producer,artifactId,async()=>{
      await this.assertNoPending(this.artifactRoot(producer,artifactId));
      return this.applyLifecycle(producer,artifactId,revision,action,occurredAt);
    });
  }

  private async applyLifecycle(producer: string, artifactId: string, revision: string, action: "trash" | "restore" | "purge", occurredAt?: string): Promise<LifecycleState> {
    if (occurredAt !== undefined && !Number.isFinite(Date.parse(occurredAt))) fail("invalid_request", "lifecycle timestamp is invalid");
    const operationTime = occurredAt === undefined ? new Date().toISOString() : new Date(occurredAt).toISOString();
      const artifactRoot = this.artifactRoot(producer, artifactId);
      const statePath = path.join(artifactRoot, "state.json");
      const state = await loadState(statePath);
      if (state.revision !== revision) fail("revision_conflict", "revision conflict");
      if (action === "trash") {
        if (state.state !== "active") fail("revision_conflict", "only an active artifact can be trashed");
        state.state = "bin";
        state.trashedAt = operationTime;
      } else if (action === "restore") {
        if (state.state !== "bin") fail("revision_conflict", "only a binned artifact can be restored");
        state.state = "active";
        state.trashedAt = null;
      } else {
        if (state.state !== "bin") fail("revision_conflict", "only a binned artifact can be permanently purged");
        if (state.kind === "whiteboard-image") {
          const stored = JSON.parse(await readFile(path.join(artifactRoot,"image-storage.json"),"utf8"));
          if (!this.images || stored.schema!=="infuse.image-storage/v1" || typeof stored.project!=="string") fail("storage_unavailable", "Image storage is required to purge all versions");
          await this.images.purge(stored.project, producer + '/' + artifactId);
        }
        await rm(path.join(artifactRoot, "revisions"), { recursive: true, force: true });
        await syncDirectory(artifactRoot);
        state.state = "purged";
        state.revisions = [];
      }
      state.generation += 1;
      state.updatedAt = operationTime;
      await atomicJson(statePath, state);
      if (action === "purge" && state.kind !== "journal") {
        await atomicJson(this.tombstonePath(producer, artifactId), {
          schema: "infuse.artifact-tombstone/v1",
          producer,
          artifactId,
          kind: state.kind,
          revision: state.revision,
          sourceRevision: state.revision,
          purgedAt: state.updatedAt,
        } satisfies ArtifactTombstone);
      }
      return state;
  }
}

async function readJsonOptional(file: string): Promise<any> {
  try{return JSON.parse(await readFile(file,'utf8'));}catch(error){if(errorCode(error)==='ENOENT')return null;fail('integrity_failure','Lifecycle metadata is unavailable');}
}

function receiptHash(receipt: ExactLifecycleReceipt): string {return createHash('sha256').update(JSON.stringify(receipt)).digest('hex');}
function checkedReceipt(envelope: any): ExactLifecycleReceipt {
  const receipt=parseExactReceipt(envelope.receipt);
  if(typeof envelope.fingerprint!=='string'||!/^[a-f0-9]{64}$/.test(envelope.fingerprint)||envelope.receiptDigest!==receiptHash(receipt))fail('integrity_failure','Lifecycle receipt integrity failed');
  return receipt;
}
function assertReceiptCommand(receipt: ExactLifecycleReceipt,command: ExactLifecycleCommand): void {
  for(const key of ['commandId','actorId','project','producer','artifactId','revision','action'] as const)if(receipt[key]!==command[key])fail('integrity_failure','Lifecycle receipt identity changed');
  if(receipt.generation!==command.generation+1)fail('integrity_failure','Lifecycle receipt generation changed');
}
