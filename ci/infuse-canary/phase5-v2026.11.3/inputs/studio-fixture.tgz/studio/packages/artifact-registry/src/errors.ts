export type ArtifactRegistryErrorCode =
  | "invalid_request"
  | "unauthorized"
  | "forbidden"
  | "not_found"
  | "revision_conflict"
  | "tombstoned"
  | "integrity_failure"
  | "storage_unavailable"
  | "authentication_unavailable"
  | "internal_error";

const STATUS_BY_CODE: Record<ArtifactRegistryErrorCode, number> = {
  invalid_request: 400,
  unauthorized: 401,
  forbidden: 403,
  not_found: 404,
  revision_conflict: 409,
  tombstoned: 409,
  integrity_failure: 500,
  storage_unavailable: 503,
  authentication_unavailable: 503,
  internal_error: 500,
};

export class ArtifactRegistryError extends Error {
  readonly code: ArtifactRegistryErrorCode;
  readonly status: number;

  constructor(code: ArtifactRegistryErrorCode, message: string) {
    super(message);
    this.name = "ArtifactRegistryError";
    this.code = code;
    this.status = STATUS_BY_CODE[code];
  }
}

export function fail(code: ArtifactRegistryErrorCode, message: string): never {
  throw new ArtifactRegistryError(code, message);
}

function systemErrorCode(error: unknown): string | undefined {
  return error && typeof error === "object" && "code" in error
    ? String((error as { code?: unknown }).code)
    : undefined;
}

export function publicRegistryError(error: unknown): ArtifactRegistryError {
  if (error instanceof ArtifactRegistryError) return error;
  if (error instanceof SyntaxError) return new ArtifactRegistryError("invalid_request", "request body is not valid JSON");
  const code = systemErrorCode(error);
  if (code === "ENOENT") return new ArtifactRegistryError("not_found", "artifact state was not found");
  if (new Set(["EACCES", "EDQUOT", "EIO", "ENOSPC", "EROFS"]).has(code ?? "")) {
    return new ArtifactRegistryError("storage_unavailable", "artifact storage is unavailable");
  }
  return new ArtifactRegistryError("internal_error", "artifact registry request failed");
}
