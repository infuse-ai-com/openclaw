import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { reconcileArtifactRegistry } from "../dist/reconcile.js";
import { ArtifactRegistry } from "../dist/registry.js";

test("reconciliation is deterministic and emits exact healthy evidence", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-reconcile-healthy-"));
  try {
    const registry = new ArtifactRegistry(root);
    const published = await registry.publish({
      producer: "agent-developer",
      artifactId: "review",
      title: "Review",
      kind: "review",
      files: [
        { path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("accepted").toString("base64") },
        { path: "evidence/data.json", mediaType: "application/json", contentBase64: Buffer.from("{}\n").toString("base64") },
      ],
    });

    const first = await reconcileArtifactRegistry(root);
    const second = await reconcileArtifactRegistry(root);
    assert.deepEqual(second, first);
    assert.equal(first.status, "healthy");
    assert.deepEqual(first.summary, { identities: 1, revisions: 1, errors: 0, warnings: 0, truncated: false });
    assert.equal(first.evidence[0].revision, published.manifest.revision);
    assert.equal(first.evidence[0].fileCount, 2);
    assert.equal(first.evidence[0].files.length, 2);
    assert.equal(first.evidence[0].files.every((file) => /^[a-f0-9]{64}$/.test(file.pathHash) && /^[a-f0-9]{64}$/.test(file.sha256)), true);
    assert.match(first.evidence[0].manifestSha256, /^[a-f0-9]{64}$/);
    assert.match(first.reportDigest, /^[a-f0-9]{64}$/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("reconciliation reports corruption and residue without repairing either", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-reconcile-corrupt-"));
  try {
    const registry = new ArtifactRegistry(root);
    const published = await registry.publish({
      producer: "agent-infra",
      artifactId: "runtime-evidence",
      title: "Runtime evidence",
      kind: "evidence",
      files: [{ path: "evidence.txt", mediaType: "text/plain", contentBase64: Buffer.from("original").toString("base64") }],
    });
    const artifactRoot = path.join(root, "objects", "agent-infra", "runtime-evidence");
    const contentPath = path.join(artifactRoot, "revisions", published.manifest.revision, "files", "evidence.txt");
    await writeFile(contentPath, "corrupt");
    await mkdir(path.join(artifactRoot, "revisions", "b".repeat(64)), { recursive: true });
    await mkdir(path.join(root, ".staging", "abandoned"), { recursive: true });

    const report = await reconcileArtifactRegistry(root);
    const codes = report.findings.map((finding) => finding.code);
    assert.equal(report.status, "degraded");
    assert.equal(codes.includes("file_digest_mismatch"), true);
    assert.equal(codes.includes("orphan_revision"), true);
    assert.equal(codes.includes("staging_residue"), true);
    assert.equal(await readFile(contentPath, "utf8"), "corrupt");
    assert.equal((await reconcileArtifactRegistry(root)).reportDigest, report.reportDigest);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("reconciliation fails closed on malformed lifecycle state", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-reconcile-state-"));
  try {
    const registry = new ArtifactRegistry(root);
    await registry.publish({
      producer: "agent-designer",
      artifactId: "ux",
      title: "UX",
      kind: "review",
      files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("review").toString("base64") }],
    });
    await writeFile(path.join(root, "objects", "agent-designer", "ux", "state.json"), "{bad-json");
    const report = await reconcileArtifactRegistry(root);
    assert.equal(report.status, "degraded");
    assert.deepEqual(report.findings.map((finding) => finding.code), ["malformed_state"]);
    assert.equal(report.evidence.length, 0);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("reconciliation degrades on warning-only residue", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-reconcile-warning-"));
  try {
    await mkdir(path.join(root, ".staging", "abandoned"), { recursive: true });
    const report = await reconcileArtifactRegistry(root);
    assert.equal(report.status, "degraded");
    assert.deepEqual(report.findings.map((finding) => finding.code), ["staging_residue"]);
    assert.deepEqual(report.summary, { identities: 0, revisions: 0, errors: 0, warnings: 1, truncated: false });
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("reconciliation reports malformed tombstones without exposing their body", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-reconcile-tombstone-"));
  try {
    const registry = new ArtifactRegistry(root);
    await registry.importPurgedIdentity({
      producer: "agent-designer",
      artifactId: "retired-review",
      kind: "review",
      sourceRevision: `sha256:${"a".repeat(64)}`,
      purgedAt: "2026-09-01T00:00:00.000Z",
    });
    const tombstonePath = path.join(root, "tombstones", "agent-designer", "retired-review.json");
    await writeFile(tombstonePath, JSON.stringify({ hostile: "private tombstone body" }));
    const report = await reconcileArtifactRegistry(root);
    assert.equal(report.status, "degraded");
    assert.equal(report.findings.some((finding) => finding.code === "malformed_tombstone"), true);
    assert.equal(JSON.stringify(report).includes("private tombstone body"), false);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
