import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import os from 'node:os';import path from 'node:path';import test from 'node:test';
import {ArtifactRegistry} from '../dist/registry.js';
import {createArtifactRegistryServer} from '../dist/http.js';
import {parseLibraryQuery} from '../dist/library.js';
test('project library filters before paging and searches current metadata across all records',async()=>{
 const root=await mkdtemp(path.join(os.tmpdir(),'registry-library-'));const registry=new ArtifactRegistry(root);
 try{
  for(let i=0;i<28;i++)await registry.publish({producer:'agent-developer',artifactId:`other-${i}`,title:'Private other floor',kind:'report',project:'other',files:[{path:'index.html',mediaType:'text/html',contentBase64:Buffer.from('other').toString('base64')}]});
  for(let i=0;i<26;i++)await registry.publish({producer:'agent-developer',artifactId:`report-${i}`,title:i===0?'Find this report':'Studio report',kind:'report',project:'studio',...(i===0?{missionId:'mission-one'}:{}),files:[{path:'index.html',mediaType:'text/html',contentBase64:Buffer.from('studio').toString('base64')}]});
  const first=await registry.library(parseLibraryQuery(new URLSearchParams({project:'studio'})));
  assert.equal(first.artifacts.length,24);assert.equal(first.nextCursor,'24');assert.ok(first.artifacts.every(m=>m.project==='studio'));
  const second=await registry.library(parseLibraryQuery(new URLSearchParams({project:'studio',cursor:'24'})));
  assert.equal(second.artifacts.length,2);assert.equal(second.nextCursor,null);assert.equal(new Set([...first.artifacts,...second.artifacts].map(m=>m.artifactId)).size,26);
  const find=await registry.library(parseLibraryQuery(new URLSearchParams({project:'studio',q:'Find this',scope:'mission',mission:'mission-one'})));
  assert.deepEqual(find.artifacts.map(m=>m.artifactId),['report-0']);
  for(const changed of [{scope:'standalone'},{mission:'mission-other'}]){
   const excluded=await registry.library(parseLibraryQuery(new URLSearchParams({project:'studio',q:'Find this',scope:'mission',mission:'mission-one',...changed})));
   assert.deepEqual(excluded.artifacts,[],JSON.stringify(changed));
  }
  const linked=await registry.library(parseLibraryQuery(new URLSearchParams({project:'studio',scope:'mission'})));
  assert.deepEqual(linked.artifacts.map(m=>m.artifactId),['report-0']);
  await registry.lifecycle('agent-developer','report-0',find.artifacts[0].revision,'trash');
  assert.equal((await registry.library(parseLibraryQuery(new URLSearchParams({project:'studio',q:'Find this'})))).artifacts.length,0);
  assert.equal((await registry.library(parseLibraryQuery(new URLSearchParams({project:'studio',state:'bin'})))).artifacts.length,1);
  assert.equal((await registry.list()).length,53); // Legacy record contract is unchanged.
 }finally{await rm(root,{recursive:true,force:true});}
});
test('library endpoint requires a read principal and rejects ambiguous queries',async()=>{
 const root=await mkdtemp(path.join(os.tmpdir(),'registry-library-http-')),token='reader-fixture-'.repeat(4),writer='writer-fixture-'.repeat(4),authPath=path.join(root,'auth.json');
 await writeFile(authPath,JSON.stringify({schema:'infuse.artifact-auth/v1',principals:{[createHash('sha256').update(token).digest('hex')]:{subject:'reader',scopes:['read']},[createHash('sha256').update(writer).digest('hex')]:{subject:'publisher',producer:'agent-developer',scopes:['write']}}}));
 const server=createArtifactRegistryServer({root:path.join(root,'store'),authPath,audit:()=>{}});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));
 try{
  const address=server.address();assert.ok(address&&typeof address==='object');const url=`http://127.0.0.1:${address.port}/v1/library`;
  assert.equal((await fetch(url+'?project=studio')).status,401);
  assert.equal((await fetch(url+'?project=studio',{headers:{authorization:`Bearer ${writer}`}})).status,403);
  for(const query of ['','?project=studio&project=other','?project=studio&state=all','?project=studio&cursor=1001','?project=studio&extra=true','?project=../other'])assert.equal((await fetch(url+query,{headers:{authorization:`Bearer ${token}`}})).status,400);
  const valid=await fetch(url+'?project=studio',{headers:{authorization:`Bearer ${token}`}});assert.equal(valid.status,200);assert.deepEqual(await valid.json(),{artifacts:[],nextCursor:null});
  const registry = new ArtifactRegistry(path.join(root, 'store'));
  const { manifest } = await registry.publish({ producer: 'agent-developer', artifactId: 'exact', title: 'Exact report', kind: 'report', project: 'studio',
    files: [{ path: 'index.html', mediaType: 'text/html', contentBase64: Buffer.from('exact').toString('base64') }] });
  const current = url.replace('/v1/library', '/v1/artifacts/agent-developer/exact/current');
  assert.equal((await fetch(current + '?project=studio')).status, 401);
  assert.equal((await fetch(current + '?project=studio', { headers: { authorization: `Bearer ${writer}` } })).status, 403);
  for (const query of ['', '?project=studio&project=other', '?project=studio&extra=true', '?project=../other']) {
    assert.equal((await fetch(current + query, { headers: { authorization: `Bearer ${token}` } })).status, 400);
  }
  assert.equal((await fetch(current + '?project=other', { headers: { authorization: `Bearer ${token}` } })).status, 404);
  const exact = await fetch(current + '?project=studio', { headers: { authorization: `Bearer ${token}` } });
  assert.equal(exact.status, 200);
  assert.equal((await exact.json()).revision, manifest.revision);
 }finally{await new Promise<void>((resolve,reject)=>server.close(e=>e?reject(e):resolve()));await rm(root,{recursive:true,force:true});}
});

test('exact current reads preserve lifecycle and project isolation without inventory scans', async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'registry-current-'));
  const registry = new ArtifactRegistry(root);
  const input = { producer: 'agent-developer', artifactId: 'report', title: 'Report', kind: 'report', project: 'studio',
    files: [{ path: 'index.html', mediaType: 'text/html', contentBase64: Buffer.from('exact content').toString('base64') }] };
  try {
    const { manifest: first } = await registry.publish(input);
    const { manifest: second } = await registry.publish({ ...input, title: 'Revised', expectedCurrentRevision: first.revision });
    assert.equal((await registry.current(input.producer, input.artifactId, 'studio'))?.revision, second.revision);
    assert.equal(await registry.current(input.producer, input.artifactId, 'other'), null);
    assert.equal(await registry.current(input.producer, 'missing', 'studio'), null);
    await registry.lifecycle(input.producer, input.artifactId, second.revision, 'trash');
    assert.equal(await registry.current(input.producer, input.artifactId, 'studio'), null);
    await registry.lifecycle(input.producer, input.artifactId, second.revision, 'restore');
    assert.equal((await registry.current(input.producer, input.artifactId, 'studio'))?.revision, second.revision);
    assert.equal((await registry.manifest(input.producer, input.artifactId, first.revision))?.revision, first.revision);
    await rm(path.join(root, 'objects', input.producer, input.artifactId, 'revisions', second.revision, 'manifest.json'));
    await assert.rejects(registry.current(input.producer, input.artifactId, 'studio'), { code: 'integrity_failure' });
  } finally { await rm(root, { recursive: true, force: true }); }
});
