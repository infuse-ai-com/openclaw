import {
  createArtifactRegistryBackup,
  restoreArtifactRegistryBackup,
  verifyArtifactRegistryBackup,
} from "./backup.js";

const SAFE_ERRORS = new Set([
  "action must be create, verify, or restore",
  "ARTIFACT_REGISTRY_RESTORE_CONFIRM must equal restore-empty-target",
  "artifact registry backup destination already exists",
  "artifact registry backup must be stored outside the source root",
  "artifact registry backup requires a healthy quiesced source",
  "artifact registry backup source contains an unsafe file type",
  "artifact registry backup source contains an unsupported top-level entry",
  "artifact registry backup source is not quiescent",
  "artifact registry backup source must be a directory",
  "artifact registry backup timestamp is invalid",
  "artifact registry backup verification failed",
  "artifact registry restore reconciliation failed",
  "artifact registry restore target must be empty",
  "artifact registry restore target must be separate from the backup",
  "artifact registry restore verification failed",
]);

function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is required`);
  return value;
}

async function main(): Promise<void> {
  const action = process.argv[2];
  if (action === "create") {
    const result = await createArtifactRegistryBackup({
      sourceRoot: required("ARTIFACT_REGISTRY_ROOT"),
      backupPath: required("ARTIFACT_REGISTRY_BACKUP_PATH"),
    });
    process.stdout.write(`${JSON.stringify(result)}\n`);
    return;
  }
  if (action === "verify") {
    const result = await verifyArtifactRegistryBackup(required("ARTIFACT_REGISTRY_BACKUP_PATH"));
    process.stdout.write(`${JSON.stringify(result)}\n`);
    return;
  }
  if (action === "restore") {
    if (process.env.ARTIFACT_REGISTRY_RESTORE_CONFIRM !== "restore-empty-target") {
      throw new Error("ARTIFACT_REGISTRY_RESTORE_CONFIRM must equal restore-empty-target");
    }
    const result = await restoreArtifactRegistryBackup({
      backupPath: required("ARTIFACT_REGISTRY_BACKUP_PATH"),
      destinationRoot: required("ARTIFACT_REGISTRY_RESTORE_ROOT"),
    });
    process.stdout.write(`${JSON.stringify(result)}\n`);
    return;
  }
  throw new Error("action must be create, verify, or restore");
}

void main().catch((error: unknown) => {
  const rawMessage = error instanceof Error ? error.message : "";
  const message = SAFE_ERRORS.has(rawMessage) || /^[A-Z0-9_]+ is required$/.test(rawMessage)
    ? rawMessage
    : "artifact registry recovery failed";
  process.stderr.write(`${message}\n`);
  process.exitCode = 1;
});
