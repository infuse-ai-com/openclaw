import { createHash } from "node:crypto";
import { lstat, readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { computeMissionControlContentRevision } from "./feed-revision.js";
import { ArtifactRegistryError } from "./errors.js";
import { ArtifactRegistry, validateArtifactPublication, type ArtifactPublication } from "./registry.js";

const ID = /^[a-z0-9][a-z0-9._-]{0,127}$/;
const SOURCE_REVISION = /^sha256:[a-f0-9]{64}$/;
const LIFECYCLE_KEYS = new Set(["agentSlug", "itemKind", "itemId", "state", "revision", "trashedAt", "purgedAt"]);
const LIFECYCLE_STATES = new Set(["active", "trashed", "purge_pending", "purge_failed", "purged"]);
const MAX_SOURCE_BYTES = 25 * 1024 * 1024;
const MAX_IMPORT_BYTES = 100 * 1024 * 1024;
const MAX_IMPORT_ITEMS = 1_000;

export type FeedLifecycleRecord = {
  agentSlug: string;
  itemKind: "artifact" | "journal";
  itemId: string;
  state: "active" | "trashed" | "purge_pending" | "purge_failed" | "purged";
  revision: string | null;
  trashedAt?: string | null;
  purgedAt?: string | null;
};

export type FeedImportItem = {
  producer: string;
  artifactId: string;
  itemKind: "artifact" | "journal";
  sourceRevision: string | null;
  canonicalRevision: string | null;
  desiredState: "active" | "bin" | "purged" | "blocked";
  action: "planned" | "imported" | "idempotent" | "tombstoned" | "blocked";
  errorCode: string | null;
  files: Array<{ path: string; bytes: number; sha256: string }>;
};

export type FeedImportReport = {
  schema: "infuse.artifact-feed-import/v1";
  mode: "plan" | "apply";
  summary: { discovered: number; imported: number; idempotent: number; tombstoned: number; blocked: number };
  items: FeedImportItem[];
  reportDigest: string;
};

type FeedBundle = {
  producer: string;
  artifactId: string;
  itemKind: "artifact" | "journal";
  sourceRevision: string;
  publication: ArtifactPublication;
  fileEvidence: Array<{ path: string; bytes: number; sha256: string }>;
};

function sha256(value: string | Buffer): string {
  return createHash("sha256").update(value).digest("hex");
}

async function entries(directory: string) {
  return readdir(directory, { withFileTypes: true }).catch(() => []);
}

async function unsafeSourcePath(filePath: string): Promise<boolean> {
  try {
    const sourceStat = await lstat(filePath);
    return !sourceStat.isFile() || sourceStat.size > MAX_SOURCE_BYTES;
  } catch {
    return false;
  }
}

async function regularFile(filePath: string): Promise<Buffer | null> {
  try {
    const sourceStat = await lstat(filePath);
    if (!sourceStat.isFile() || sourceStat.size > MAX_SOURCE_BYTES) return null;
    return await readFile(filePath);
  } catch {
    return null;
  }
}

function object(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function text(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function optionalText(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value : undefined;
}

function tags(value: unknown): string[] | undefined {
  return Array.isArray(value) && value.every((item) => typeof item === "string") ? value : undefined;
}

function validArtifactMetadata(data: Record<string, unknown> | null): boolean {
  if (!data) return true;
  for (const key of ["id", "agentSlug", "title", "kind", "project", "status", "createdAt", "updatedAt", "summary"]) {
    if (data[key] !== undefined && typeof data[key] !== "string") return false;
  }
  return data.tags === undefined || (Array.isArray(data.tags) && data.tags.every((item) => typeof item === "string"));
}

function validLifecycleRecord(value: unknown): value is FeedLifecycleRecord {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !LIFECYCLE_KEYS.has(key))) return false;
  const candidate = value as Partial<FeedLifecycleRecord>;
  if (typeof candidate.agentSlug !== "string" || !ID.test(candidate.agentSlug) || typeof candidate.itemId !== "string" || !ID.test(candidate.itemId)) return false;
  if (candidate.itemKind !== "artifact" && candidate.itemKind !== "journal") return false;
  if (candidate.itemKind === "journal" && candidate.itemId !== "journal") return false;
  if (typeof candidate.state !== "string" || !LIFECYCLE_STATES.has(candidate.state)) return false;
  if (candidate.revision !== null && (typeof candidate.revision !== "string" || !SOURCE_REVISION.test(candidate.revision))) return false;
  if (candidate.state !== "active" && !candidate.revision) return false;
  for (const timestamp of [candidate.trashedAt, candidate.purgedAt]) {
    if (timestamp !== undefined && timestamp !== null && (typeof timestamp !== "string" || !Number.isFinite(Date.parse(timestamp)))) return false;
  }
  if (candidate.state === "active" && (candidate.trashedAt || candidate.purgedAt)) return false;
  if (candidate.state !== "active" && !candidate.trashedAt && !candidate.purgedAt) return false;
  if (candidate.state !== "purged" && candidate.purgedAt) return false;
  return true;
}

function lifecycleIdentity(value: unknown): { agentSlug: string; itemKind: "artifact" | "journal"; itemId: string; revision: string | null } | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value as Record<string, unknown>;
  if (typeof candidate.agentSlug !== "string" || !ID.test(candidate.agentSlug) || typeof candidate.itemId !== "string" || !ID.test(candidate.itemId)) return null;
  if (candidate.itemKind !== "artifact" && candidate.itemKind !== "journal") return null;
  if (candidate.itemKind === "journal" && candidate.itemId !== "journal") return null;
  return {
    agentSlug: candidate.agentSlug,
    itemKind: candidate.itemKind,
    itemId: candidate.itemId,
    revision: typeof candidate.revision === "string" && SOURCE_REVISION.test(candidate.revision) ? candidate.revision : null,
  };
}

async function jsonMetadata(filePath: string): Promise<{ body: Buffer | null; data: Record<string, unknown> | null; malformed: boolean }> {
  const body = await regularFile(filePath);
  if (!body) return { body: null, data: null, malformed: false };
  try {
    const data = object(JSON.parse(body.toString("utf8")));
    return { body, data, malformed: !data };
  } catch {
    return { body, data: null, malformed: true };
  }
}

function bundleFiles(files: Array<{ path: string; mediaType: string; body: Buffer }>) {
  return {
    publicationFiles: files.map((file) => ({ path: file.path, mediaType: file.mediaType, contentBase64: file.body.toString("base64") })),
    evidence: files.map((file) => ({ path: file.path, bytes: file.body.length, sha256: sha256(file.body) })),
    sourceRevision: computeMissionControlContentRevision(files.map((file) => ({ label: file.path, body: file.body }))),
  };
}

async function readJournal(feedRoot: string, producer: string): Promise<FeedBundle | null | "malformed"> {
  const agentRoot = path.join(feedRoot, "agents", producer);
  const profile = await jsonMetadata(path.join(agentRoot, "profile.json"));
  const metadata = await jsonMetadata(path.join(agentRoot, "journal.json"));
  if (metadata.malformed || !validArtifactMetadata(metadata.data) || await unsafeSourcePath(path.join(agentRoot, "journal.json")) || await unsafeSourcePath(path.join(agentRoot, "journal.html"))) return "malformed";
  const html = await regularFile(path.join(agentRoot, "journal.html"));
  const files = [
    ...(metadata.body ? [{ path: "journal.json", mediaType: "application/json", body: metadata.body }] : []),
    ...(html ? [{ path: "journal.html", mediaType: "text/html", body: html }] : []),
  ];
  if (files.length === 0) return null;
  if (metadata.data?.agentSlug !== undefined && metadata.data.agentSlug !== producer) return "malformed";
  const prepared = bundleFiles(files);
  return {
    producer,
    artifactId: "journal",
    itemKind: "journal",
    sourceRevision: prepared.sourceRevision,
    publication: {
      producer,
      artifactId: "journal",
      title: `${text(profile.data?.displayName, producer)} Journal`,
      kind: "journal",
      sourceRef: `feed:${prepared.sourceRevision}`,
      files: prepared.publicationFiles,
    },
    fileEvidence: prepared.evidence,
  };
}

async function readArtifact(feedRoot: string, producer: string, directory: string): Promise<FeedBundle | null | "malformed"> {
  const artifactRoot = path.join(feedRoot, "agents", producer, "artifacts", directory);
  const metadata = await jsonMetadata(path.join(artifactRoot, "artifact.json"));
  if (metadata.malformed || !validArtifactMetadata(metadata.data) || await unsafeSourcePath(path.join(artifactRoot, "artifact.json")) || await unsafeSourcePath(path.join(artifactRoot, "index.html"))) return "malformed";
  const html = await regularFile(path.join(artifactRoot, "index.html"));
  const files = [
    ...(metadata.body ? [{ path: "artifact.json", mediaType: "application/json", body: metadata.body }] : []),
    ...(html ? [{ path: "index.html", mediaType: "text/html", body: html }] : []),
  ];
  if (files.length === 0) return null;
  if (metadata.data?.agentSlug !== undefined && metadata.data.agentSlug !== producer) return "malformed";
  const artifactId = text(metadata.data?.id, directory);
  if (!ID.test(artifactId)) return "malformed";
  const prepared = bundleFiles(files);
  return {
    producer,
    artifactId,
    itemKind: "artifact",
    sourceRevision: prepared.sourceRevision,
    publication: {
      producer,
      artifactId,
      title: text(metadata.data?.title, artifactId),
      kind: text(metadata.data?.kind, "artifact"),
      summary: text(metadata.data?.summary),
      project: optionalText(metadata.data?.project),
      tags: tags(metadata.data?.tags),
      sourceRef: `feed:${prepared.sourceRevision}`,
      files: prepared.publicationFiles,
    },
    fileEvidence: prepared.evidence,
  };
}

function identityKey(input: { producer: string; itemKind: string; artifactId: string }): string {
  return `${input.producer}\0${input.itemKind}\0${input.artifactId}`;
}

function desiredState(bundle: FeedBundle, lifecycle: FeedLifecycleRecord | undefined): "active" | "bin" | "purged" | "blocked" {
  if (!lifecycle || lifecycle.state === "active") return "active";
  if (lifecycle.state === "purge_pending") return "blocked";
  if (bundle.itemKind === "journal" && lifecycle.revision && lifecycle.revision !== bundle.sourceRevision) return "active";
  if (lifecycle.state === "purged") return "purged";
  return "bin";
}

function blockedItem(input: {
  producer: string;
  artifactId: string;
  itemKind: "artifact" | "journal";
  sourceRevision?: string | null;
  files?: Array<{ path: string; bytes: number; sha256: string }>;
  errorCode: string;
}): FeedImportItem {
  return {
    producer: input.producer,
    artifactId: input.artifactId,
    itemKind: input.itemKind,
    sourceRevision: input.sourceRevision ?? null,
    canonicalRevision: null,
    desiredState: "blocked",
    action: "blocked",
    errorCode: input.errorCode,
    files: input.files ?? [],
  };
}

export async function importMissionControlFeed(options: {
  registry: ArtifactRegistry;
  feedRoot: string;
  lifecycle?: unknown[];
  apply?: boolean;
}): Promise<FeedImportReport> {
  const apply = options.apply === true;
  const lifecycleByIdentity = new Map<string, FeedLifecycleRecord>();
  const invalidLifecycleByIdentity = new Map<string, { agentSlug: string; itemKind: "artifact" | "journal"; itemId: string; revision: string | null; errorCode: "invalid_lifecycle_record" | "duplicate_lifecycle_record" }>();
  const items: FeedImportItem[] = [];
  const bundles: FeedBundle[] = [];

  for (const recordValue of options.lifecycle ?? []) {
    if (!validLifecycleRecord(recordValue)) {
      const invalidIdentity = lifecycleIdentity(recordValue);
      if (invalidIdentity) {
        const invalidKey = identityKey({ producer: invalidIdentity.agentSlug, itemKind: invalidIdentity.itemKind, artifactId: invalidIdentity.itemId });
        lifecycleByIdentity.delete(invalidKey);
        invalidLifecycleByIdentity.set(invalidKey, { ...invalidIdentity, errorCode: "invalid_lifecycle_record" });
      }
      else items.push(blockedItem({ producer: "invalid", artifactId: "invalid", itemKind: "artifact", errorCode: "invalid_lifecycle_record" }));
      continue;
    }
    const record = recordValue;
    const key = identityKey({ producer: record.agentSlug, itemKind: record.itemKind, artifactId: record.itemId });
    if (lifecycleByIdentity.has(key) || invalidLifecycleByIdentity.has(key)) {
      lifecycleByIdentity.delete(key);
      invalidLifecycleByIdentity.set(key, { ...record, errorCode: "duplicate_lifecycle_record" });
      continue;
    }
    lifecycleByIdentity.set(key, record);
  }

  const agentsRoot = path.join(options.feedRoot, "agents");
  const agentEntries = await readdir(agentsRoot, { withFileTypes: true }).catch(() => null);
  if (!agentEntries) {
    items.push(blockedItem({ producer: "invalid", artifactId: "invalid", itemKind: "artifact", errorCode: "feed_unavailable" }));
    lifecycleByIdentity.clear();
    invalidLifecycleByIdentity.clear();
  }
  for (const agentEntry of (agentEntries ?? []).sort((a, b) => a.name.localeCompare(b.name))) {
    if (!agentEntry.isDirectory() || !ID.test(agentEntry.name)) {
      items.push(blockedItem({ producer: "invalid", artifactId: "invalid", itemKind: "artifact", errorCode: "invalid_feed_identity" }));
      continue;
    }
    const producer = agentEntry.name;
    const journal = await readJournal(options.feedRoot, producer);
    if (journal === "malformed") items.push(blockedItem({ producer, artifactId: "journal", itemKind: "journal", errorCode: "malformed_feed_metadata" }));
    else if (journal) bundles.push(journal);
    for (const artifactEntry of (await entries(path.join(options.feedRoot, "agents", producer, "artifacts"))).sort((a, b) => a.name.localeCompare(b.name))) {
      if (!artifactEntry.isDirectory()) {
        items.push(blockedItem({ producer, artifactId: "invalid", itemKind: "artifact", errorCode: "unsafe_feed_entry" }));
        continue;
      }
      const artifact = await readArtifact(options.feedRoot, producer, artifactEntry.name);
      if (artifact === "malformed") items.push(blockedItem({ producer, artifactId: ID.test(artifactEntry.name) ? artifactEntry.name : "invalid", itemKind: "artifact", errorCode: "malformed_feed_metadata" }));
      else if (artifact) bundles.push(artifact);
    }
  }

  const discoveredBytes = bundles.reduce((sum, bundle) => sum + bundle.fileEvidence.reduce((fileSum, file) => fileSum + file.bytes, 0), 0);
  if (bundles.length > MAX_IMPORT_ITEMS || discoveredBytes > MAX_IMPORT_BYTES) {
    items.push(blockedItem({ producer: "invalid", artifactId: "invalid", itemKind: "artifact", errorCode: "feed_limit_exceeded" }));
    bundles.length = 0;
    lifecycleByIdentity.clear();
    invalidLifecycleByIdentity.clear();
  }

  const seen = new Set<string>();
  const bundleCounts = new Map<string, number>();
  bundles.forEach((bundle) => bundleCounts.set(identityKey(bundle), (bundleCounts.get(identityKey(bundle)) ?? 0) + 1));
  for (const bundle of bundles.sort((a, b) => identityKey(a).localeCompare(identityKey(b)))) {
    const key = identityKey(bundle);
    if ((bundleCounts.get(key) ?? 0) > 1) {
      if (!seen.has(key)) items.push(blockedItem({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, files: bundle.fileEvidence, errorCode: "duplicate_feed_identity" }));
      seen.add(key);
      lifecycleByIdentity.delete(key);
      invalidLifecycleByIdentity.delete(key);
      continue;
    }
    if (invalidLifecycleByIdentity.has(key)) {
      items.push(blockedItem({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, files: bundle.fileEvidence, errorCode: invalidLifecycleByIdentity.get(key)?.errorCode ?? "invalid_lifecycle_record" }));
      invalidLifecycleByIdentity.delete(key);
      continue;
    }
    if (seen.has(key)) {
      items.push(blockedItem({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, files: bundle.fileEvidence, errorCode: "duplicate_feed_identity" }));
      continue;
    }
    seen.add(key);
    const lifecycle = lifecycleByIdentity.get(key);
    lifecycleByIdentity.delete(key);
    const desired = desiredState(bundle, lifecycle);
    try {
      const beforeValidation = JSON.stringify({ title: bundle.publication.title, kind: bundle.publication.kind, summary: bundle.publication.summary, project: bundle.publication.project, tags: bundle.publication.tags });
      validateArtifactPublication(bundle.publication);
      const afterValidation = JSON.stringify({ title: bundle.publication.title, kind: bundle.publication.kind, summary: bundle.publication.summary, project: bundle.publication.project, tags: bundle.publication.tags });
      if (beforeValidation !== afterValidation) throw new Error("feed metadata is not canonical");
    } catch {
      items.push(blockedItem({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, files: bundle.fileEvidence, errorCode: "invalid_feed_metadata" }));
      continue;
    }
    if (desired === "blocked") {
      items.push(blockedItem({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, files: bundle.fileEvidence, errorCode: "purge_in_progress" }));
      continue;
    }
    if (lifecycle?.revision && lifecycle.revision !== bundle.sourceRevision && !(bundle.itemKind === "journal" && desired === "active")) {
      items.push(blockedItem({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, files: bundle.fileEvidence, errorCode: "source_revision_conflict" }));
      continue;
    }
    if (!apply) {
      items.push({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, canonicalRevision: null, desiredState: desired, action: "planned", errorCode: null, files: bundle.fileEvidence });
      continue;
    }
    try {
      if (desired === "purged") {
        const purgedAt = lifecycle?.purgedAt ?? lifecycle?.trashedAt;
        if (!lifecycle?.revision || !SOURCE_REVISION.test(lifecycle.revision) || !purgedAt) throw new ArtifactRegistryError("invalid_request", "purged lifecycle evidence is incomplete");
        const result = await options.registry.importPurgedIdentity({ producer: bundle.producer, artifactId: bundle.artifactId, kind: bundle.publication.kind, sourceRevision: lifecycle.revision, purgedAt });
        items.push({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, canonicalRevision: result.tombstone?.revision ?? null, desiredState: desired, action: result.idempotent ? "idempotent" : "tombstoned", errorCode: null, files: bundle.fileEvidence });
        continue;
      }
      const beforePublish = (await options.registry.list("all")).find((record) => record.producer === bundle.producer && record.artifactId === bundle.artifactId);
      const published = await options.registry.publish({
        ...bundle.publication,
        ...(beforePublish ? { expectedCurrentRevision: beforePublish.revision } : {}),
      });
      const current = (await options.registry.list("all")).find((record) => record.producer === bundle.producer && record.artifactId === bundle.artifactId);
      let lifecycleMutated = false;
      if (desired === "bin" && current?.state === "active") {
        await options.registry.lifecycle(bundle.producer, bundle.artifactId, published.manifest.revision, "trash", lifecycle?.trashedAt ?? undefined);
        lifecycleMutated = true;
      }
      if (desired === "active" && current?.state === "bin") {
        await options.registry.lifecycle(bundle.producer, bundle.artifactId, published.manifest.revision, "restore");
        lifecycleMutated = true;
      }
      items.push({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, canonicalRevision: published.manifest.revision, desiredState: desired, action: published.idempotent && !lifecycleMutated ? "idempotent" : "imported", errorCode: null, files: bundle.fileEvidence });
    } catch (error) {
      items.push(blockedItem({ producer: bundle.producer, artifactId: bundle.artifactId, itemKind: bundle.itemKind, sourceRevision: bundle.sourceRevision, files: bundle.fileEvidence, errorCode: error instanceof ArtifactRegistryError ? error.code : "import_failed" }));
    }
  }

  for (const lifecycle of invalidLifecycleByIdentity.values()) {
    items.push(blockedItem({ producer: lifecycle.agentSlug, artifactId: lifecycle.itemId, itemKind: lifecycle.itemKind, sourceRevision: lifecycle.revision, errorCode: lifecycle.errorCode }));
  }

  for (const lifecycle of [...lifecycleByIdentity.values()].sort((a, b) => identityKey({ producer: a.agentSlug, itemKind: a.itemKind, artifactId: a.itemId }).localeCompare(identityKey({ producer: b.agentSlug, itemKind: b.itemKind, artifactId: b.itemId })))) {
    if (lifecycle.state !== "purged") {
      items.push(blockedItem({ producer: lifecycle.agentSlug, artifactId: lifecycle.itemId, itemKind: lifecycle.itemKind, sourceRevision: lifecycle.revision, errorCode: lifecycle.state === "purge_pending" ? "purge_in_progress" : "missing_source_bundle" }));
      continue;
    }
    const purgedAt = lifecycle.purgedAt ?? lifecycle.trashedAt;
    if (!lifecycle.revision || !SOURCE_REVISION.test(lifecycle.revision) || !purgedAt) {
      items.push(blockedItem({ producer: lifecycle.agentSlug, artifactId: lifecycle.itemId, itemKind: lifecycle.itemKind, sourceRevision: lifecycle.revision, errorCode: "incomplete_tombstone_evidence" }));
      continue;
    }
    if (!apply) {
      items.push({ producer: lifecycle.agentSlug, artifactId: lifecycle.itemId, itemKind: lifecycle.itemKind, sourceRevision: lifecycle.revision, canonicalRevision: null, desiredState: "purged", action: "planned", errorCode: null, files: [] });
      continue;
    }
    try {
      const result = await options.registry.importPurgedIdentity({ producer: lifecycle.agentSlug, artifactId: lifecycle.itemId, kind: lifecycle.itemKind, sourceRevision: lifecycle.revision, purgedAt });
      items.push({ producer: lifecycle.agentSlug, artifactId: lifecycle.itemId, itemKind: lifecycle.itemKind, sourceRevision: lifecycle.revision, canonicalRevision: result.tombstone?.revision ?? null, desiredState: "purged", action: result.idempotent ? "idempotent" : "tombstoned", errorCode: null, files: [] });
    } catch (error) {
      items.push(blockedItem({ producer: lifecycle.agentSlug, artifactId: lifecycle.itemId, itemKind: lifecycle.itemKind, sourceRevision: lifecycle.revision, errorCode: error instanceof ArtifactRegistryError ? error.code : "import_failed" }));
    }
  }

  items.sort((a, b) => identityKey(a).localeCompare(identityKey(b)) || a.action.localeCompare(b.action));
  const summary = {
    discovered: items.length,
    imported: items.filter((item) => item.action === "imported").length,
    idempotent: items.filter((item) => item.action === "idempotent").length,
    tombstoned: items.filter((item) => item.action === "tombstoned").length,
    blocked: items.filter((item) => item.action === "blocked").length,
  };
  return {
    schema: "infuse.artifact-feed-import/v1",
    mode: apply ? "apply" : "plan",
    summary,
    items,
    reportDigest: sha256(JSON.stringify({ mode: apply ? "apply" : "plan", summary, items })),
  };
}
