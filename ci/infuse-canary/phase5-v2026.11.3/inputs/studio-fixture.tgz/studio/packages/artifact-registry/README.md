# Shared Artifact Registry

Studio owns this independent service's source, build and tests. The initial core,
image/S3 adapter, reconciliation, filesystem recovery and bounded legacy feed
importer come from Backoffice `53eae474edcdf603b4defdb689f46b0315589711`.
NodeNext import paths and the independent feed hash helper replace BO imports.
The package retains its existing compiler indexing policy; Studio's stricter
package settings remain unchanged. Original compatibility tests are preserved.

The canonical filesystem store, S3 keys/buckets, immutable manifests and v1
protocol stay compatible. This service never opens the Studio SQLite database.
Live service/PVC/auth/scanner names remain stable until reviewed cutover. Shipping
this source does not mean the live Registry image has changed.

```sh
npm run build:services
npm run test:registry
# Require protected operator-owned root/auth configuration:
npm run start:registry
# Build the independent service; no Backoffice checkout:
docker build -f Dockerfile.registry -t studio-registry-p5-local:20261020 .
npm run test:registry:container
```

`ARTIFACT_REGISTRY_ROOT` and `ARTIFACT_REGISTRY_AUTH_FILE` are required. Optional
`ARTIFACT_REGISTRY_IMAGES_CONFIG` retains the existing exact S3/scanner configuration.
The old `/app/artifact-registry.cjs` and recovery entrypoints work in the independent
image as well as the package commands. The image retains UID/GID 1001 and no Next,
Prisma or Backoffice runtime. It has its own lifecycle; do not merge it into the
Studio backend process or copy its content into the mission database.

## Exact lifecycle extension

The read-only `GET /v1/artifacts/:producer/:artifactId/current?project=...`
returns one hash-verified current manifest using the existing `read` scope.
It reads only the requested identity, and returns 404 for missing, non-active
or foreign-project artifacts. Duplicate/unknown query parameters are rejected.
It does not enumerate inventory or history, acquire writer locks, or change
publication/lifecycle credentials. Deploy this additive API before dependent
Studio readers; old read endpoints retain their existing contracts.

Old `/v1/artifacts/.../actions/{trash,restore,purge}` clients keep their wire format.
New scoped lifecycle credentials use `/v1/artifacts/:producer/:artifactId/lifecycle`:

- GET with exact `project` returns state, revision, generation and pending status.
- POST takes commandId (UUID), actorId (hash), project, producer, artifactId,
  revision, generation and action. The authenticated client identity also binds
  the durable command. Reuse the same envelope to recover an uncertain response.
- GET `/audit?project=...&before=...` returns at most 50 content-free receipts in
  stable ID order. Retained audit survives content purge; cursor is opaque to UI.

A write-ahead intent precedes effects. Pending commands fence new publication,
legacy lifecycle and other exact commands. Same-command retries can finish an
interrupted version purge or recover a response after state commit; changed
content/client conflicts. Hash-checked receipts bind the entire command and next
generation. Old content revisions cannot address later lifecycle generations.
Preserve the authenticated client subject through credential rotation until all
its uncertain receipts are reconciled.

Studio's native adapter enforces current membership/project, CSRF/Origin, typed
confirmation and trusted admin-only purge/audit around asynchronous work. Reader,
uploader and lifecycle credentials remain separate. Existing global v1 grants are
compatible; new project/floor-scoped lifecycle-only grants cannot use unscoped v1
actions. Registry credentials confer no Studio mission or human-role membership.

## Hard process death

Identity locks have no automatic expiry. A hard crash may leave `.lock` plus an
exact intent. Stop **all writers of this root**, record independent evidence of
quiescence, prepare an exact lock plan and review its digest before applying:

```sh
npm run artifact-registry:locks -- plan --producer agent-designer --artifact report
npm run artifact-registry:locks -- apply --producer agent-designer --artifact report \
  --expected-plan <reviewed-digest> --quiesced-reference <review-record-id>
```

The explicit root comes from `ARTIFACT_REGISTRY_ROOT`. Apply rechecks the lock and
state/intent digests, removes only that empty identity lock and records durable
recovery audit. It does not decide or replay a lifecycle effect. Then resume the
same exact lifecycle command through its currently authorized client. A supplied
reference attests operator review; this offline tool cannot independently prove
Kubernetes is stopped. Never run it against an active writer or apply a stale plan.

## Reconciliation and legacy tools

`artifact-registry:reconcile`, `artifact-registry:import-feed` and
`artifact-registry:recovery` preserve their bounded original contracts. Import is
plan-only unless `--apply` is supplied. Registry filesystem recovery is independent
of Studio DB policy and does not cover S3 image disaster recovery. Tests use only
synthetic disposable stores; no live recovery or import has run.

Release ownership and exact preserved runtime resources are in
[infrastructure/registry](../../infrastructure/registry/README.md). The P5 contract
records qualification and remaining retained audit/purge reconciliation.
