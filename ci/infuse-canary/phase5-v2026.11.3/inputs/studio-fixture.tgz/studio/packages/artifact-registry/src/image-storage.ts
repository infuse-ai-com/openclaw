import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { connect } from 'node:net';
import { S3Client, PutObjectCommand, GetObjectCommand, ListObjectVersionsCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import sharp from 'sharp';
import { fail } from './errors.js';

export const IMAGE_LIMIT = 10 * 1024 * 1024;
const hash = (value: string | Buffer) => createHash('sha256').update(value).digest('hex');
export interface ImageStorage {
  put(project: string, identity: string, revision: string, digest: string, bytes: Buffer): Promise<void>;
  get(project: string, identity: string, revision: string, digest: string): Promise<Buffer>;
  purge(project: string, identity: string): Promise<void>;
  prepare(project: string, identity: string, bytes: Buffer): Promise<{ bytes: Buffer; width: number; height: number }>;
}
export type ImageStorageConfig = {
  endpoint: string; region: string; credentialsFile: string;
  projects: Record<string, { intake: string; trusted: string }>;
  floorFallbackProject?: string;
  scanner: { host: string; port: number };
};
/** Exact endpoint/tenant configuration is operator-owned, never supplied by uploads. */
export function parseImageStorageConfig(value: unknown): ImageStorageConfig {
  const c = value as ImageStorageConfig;
  if (!c || Object.keys(c).some(k => !['endpoint','region','credentialsFile','projects','scanner','floorFallbackProject'].includes(k))) fail('invalid_request','Invalid image storage configuration');
  const url = new URL(c.endpoint);
  if (!['http:','https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== '/' || !/^(localhost|127\.0\.0\.1|[a-z0-9.-]+\.svc(?:\.cluster\.local)?)$/.test(url.hostname)) fail('invalid_request','Image storage must use an internal endpoint');
  if (!c.credentialsFile?.startsWith('/') || !c.region || !c.projects || !Object.keys(c.projects).length || !c.scanner?.host || !Number.isInteger(c.scanner.port) || c.scanner.port < 1 || c.scanner.port > 65535) fail('invalid_request','Incomplete image storage configuration');
  const buckets = new Set<string>();
  for (const [project, pair] of Object.entries(c.projects)) {
    if (!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(project) || !pair || Object.keys(pair).sort().join(',') !== 'intake,trusted') fail('invalid_request','Invalid image storage tenant');
    for (const bucket of [pair.intake,pair.trusted]) {
      if (!/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(bucket) || buckets.has(bucket)) fail('invalid_request','Image buckets must be distinct and exact');
      buckets.add(bucket);
    }
  }
  if (c.floorFallbackProject !== undefined && (typeof c.floorFallbackProject !== 'string' || !Object.hasOwn(c.projects, c.floorFallbackProject))) fail('invalid_request','Floor image storage needs an exact configured bucket pair');
  return c;
}

/** ClamAV INSTREAM: fail closed on timeout, unavailable, malformed reply or a finding. */
export async function scanImage(bytes: Buffer, scanner: ImageStorageConfig['scanner']): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const socket = connect(scanner.port, scanner.host);
    let reply = ''; let finished = false;
    const finish = (ok: boolean) => { if (finished) return; finished = true; socket.destroy(); if (ok) resolve(); else reject(new Error('Image scan failed')); };
    socket.setTimeout(30_000, () => finish(false)); socket.on('error', () => finish(false));
    socket.on('data', chunk => { reply += chunk.toString('utf8'); if (reply.length > 1024) finish(false); else if (reply.includes('\0')) finish(reply === 'stream: OK\0'); });
    socket.on('end', () => finish(false)); socket.on('close',()=>finish(false));
    socket.on('connect', async () => {
      socket.write('zINSTREAM\0');
      try {
        for (let offset = 0; offset < bytes.length; offset += 65536) {
          const part = bytes.subarray(offset, offset + 65536), size = Buffer.alloc(4); size.writeUInt32BE(part.length);
          if (!socket.write(Buffer.concat([size, part]))) await new Promise<void>((resolve, reject) => { const closed=()=>{socket.off('drain',drained);reject(Error('closed'));};const drained=()=>{socket.off('close',closed);resolve();};socket.once('drain',drained);socket.once('close',closed); });
        }
        socket.write(Buffer.alloc(4));
      } catch { finish(false); }
    });
  }).catch(() => fail('storage_unavailable','Image scanning did not accept this upload'));
}

export class S3ImageStorage implements ImageStorage {
  private client: S3Client;
  constructor(private config: ImageStorageConfig) {
    this.client = new S3Client({ endpoint: config.endpoint, region: config.region, forcePathStyle: true, maxAttempts: 2,
      requestChecksumCalculation: 'WHEN_REQUIRED', responseChecksumValidation: 'WHEN_REQUIRED',
      credentials: async () => {
        const c = JSON.parse(await readFile(config.credentialsFile,'utf8'));
        if (typeof c.accessKeyId !== 'string' || typeof c.secretAccessKey !== 'string') throw Error('Invalid storage credentials');
        return {accessKeyId:c.accessKeyId,secretAccessKey:c.secretAccessKey};
      } });
  }
  private buckets(project: string) { const pair = Object.hasOwn(this.config.projects,project)?this.config.projects[project]:this.config.floorFallbackProject?this.config.projects[this.config.floorFallbackProject]:undefined; if (!pair) fail('forbidden','Image storage is not configured for this project'); return pair; }
  private prefix(project: string, identity: string) {
    if (!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(project)) fail('forbidden','Invalid image project');
    return (Object.hasOwn(this.config.projects,project) ? '' : 'floors/' + hash(project) + '/') + hash(identity) + '/';
  }
  private key(project: string, identity: string, revision: string, digest: string) { return this.prefix(project,identity) + revision + '/' + digest; }
  private async send<T>(action: () => Promise<T>): Promise<T> { try { return await action(); } catch { return fail('storage_unavailable','Image object storage is unavailable'); } }
  private async read(bucket: string, key: string): Promise<Buffer> {
    const result = await this.client.send(new GetObjectCommand({Bucket:bucket,Key:key}), {abortSignal:AbortSignal.timeout(30_000)});
    if (!result.Body || !result.ContentLength || result.ContentLength > IMAGE_LIMIT) throw Error('Invalid stored image length');
    const chunks: Buffer[] = []; let size = 0;
    for await (const part of result.Body as AsyncIterable<Uint8Array>) { size += part.length; if (size > IMAGE_LIMIT) throw Error('Stored image too large'); chunks.push(Buffer.from(part)); }
    return Buffer.concat(chunks);
  }
  private async immutable(bucket: string, key: string, bytes: Buffer) {
    try { const existing = await this.read(bucket,key); if (hash(existing) !== hash(bytes)) throw Error('Immutable image mismatch'); return; }
    catch (e) { if ((e as {name?:string}).name !== 'NoSuchKey') throw e; }
    await this.client.send(new PutObjectCommand({Bucket:bucket,Key:key,Body:bytes,ContentType:'application/octet-stream'}),{abortSignal:AbortSignal.timeout(30_000)});
  }
  async put(project: string, identity: string, revision: string, digest: string, bytes: Buffer) { await this.send(() => this.immutable(this.buckets(project).trusted,this.key(project,identity,revision,digest),bytes)); }
  async get(project: string, identity: string, revision: string, digest: string) { return this.send(() => this.read(this.buckets(project).trusted,this.key(project,identity,revision,digest))); }
  private async removeVersions(bucket: string, prefix: string) {
    // Enumerate before deleting so pagination cannot skip versions as pages disappear.
    const all: Array<{Key:string;VersionId:string}> = []; let keyMarker: string | undefined, versionMarker: string | undefined;
    do {
      const page = await this.client.send(new ListObjectVersionsCommand({Bucket:bucket,Prefix:prefix,KeyMarker:keyMarker,VersionIdMarker:versionMarker}),{abortSignal:AbortSignal.timeout(30_000)});
      for (const v of [...page.Versions??[],...page.DeleteMarkers??[]]) if (v.Key?.startsWith(prefix) && v.VersionId) all.push({Key:v.Key,VersionId:v.VersionId});
      if (all.length > 10000) throw Error('Image version limit requires operator reconciliation');
      if(page.IsTruncated && !page.NextKeyMarker)throw Error('Incomplete version inventory');
      keyMarker = page.IsTruncated ? page.NextKeyMarker : undefined; versionMarker = page.NextVersionIdMarker;
    } while (keyMarker);
    for (const object of all) await this.client.send(new DeleteObjectCommand({Bucket:bucket,...object}),{abortSignal:AbortSignal.timeout(30_000)});
    const remaining=await this.client.send(new ListObjectVersionsCommand({Bucket:bucket,Prefix:prefix,MaxKeys:1}),{abortSignal:AbortSignal.timeout(30_000)});
    if(remaining.Versions?.length || remaining.DeleteMarkers?.length)throw Error('Image versions remain');
  }
  async purge(project: string, identity: string) { await this.send(async () => { const b = this.buckets(project); await this.removeVersions(b.trusted,this.prefix(project,identity)); await this.removeVersions(b.intake,this.prefix(project,identity)); }); }
  async prepare(project: string, identity: string, bytes: Buffer) {
    if (!bytes.length || bytes.length > IMAGE_LIMIT) fail('invalid_request','Choose an image up to 10 MB');
    const bucket = this.buckets(project).intake, key = this.prefix(project,identity) + hash(bytes);
    await this.send(() => this.immutable(bucket,key,bytes));
    // A fully decoded, reconstructed raster is the only accepted publication. Raw input is never served.
    try {
      await scanImage(bytes,this.config.scanner);
      const raster = bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])) || bytes.subarray(0,3).equals(Buffer.from([255,216,255])) || (bytes.subarray(0,4).toString()==='RIFF' && bytes.subarray(8,12).toString()==='WEBP');
      if (!raster) fail('invalid_request','Choose a PNG, JPEG or WebP image');
      const image = sharp(bytes,{limitInputPixels:40_000_000,failOn:'warning'});
      const metadata = await image.metadata();
      if (!['png','jpeg','webp'].includes(metadata.format??'') || (metadata.pages??1) !== 1) fail('invalid_request','Choose a still PNG, JPEG or WebP image');
      const output = await image.rotate().resize({width:4096,height:4096,fit:'inside',withoutEnlargement:true}).webp({quality:90}).toBuffer({resolveWithObject:true});
      if (output.data.length > IMAGE_LIMIT) fail('invalid_request','This image is too large after processing');
      return {bytes:output.data,width:output.info.width,height:output.info.height};
    } catch (error) {
      if (error && typeof error === 'object' && 'code' in error) throw error;
      fail('invalid_request','This image could not be decoded as a still PNG, JPEG or WebP');
    } finally {
      // Failed clean-up stays in intake for bounded lifecycle cleanup; it never becomes trusted content.
      await this.send(() => this.removeVersions(bucket,key)).catch(() => undefined);
    }
  }
}
