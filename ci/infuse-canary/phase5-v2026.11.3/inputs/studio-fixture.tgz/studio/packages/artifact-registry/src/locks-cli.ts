import {planIdentityLockRecovery,applyIdentityLockRecovery} from './locks.js';
async function main(){
 const [mode,...args]=process.argv.slice(2),values:Record<string,string>={};for(let i=0;i<args.length;i+=2){const key=args[i];if(!['--producer','--artifact','--expected-plan','--quiesced-reference'].includes(key)||!args[i+1]||values[key])throw Error();values[key]=args[i+1];}
 if(!process.env.ARTIFACT_REGISTRY_ROOT||!values['--producer']||!values['--artifact']||!['plan','apply'].includes(mode))throw Error();
 if(mode==='plan'&&(values['--expected-plan']||values['--quiesced-reference']))throw Error();
 const result=mode==='plan'?await planIdentityLockRecovery(process.env.ARTIFACT_REGISTRY_ROOT,values['--producer'],values['--artifact']):await applyIdentityLockRecovery(process.env.ARTIFACT_REGISTRY_ROOT,values['--producer'],values['--artifact'],values['--expected-plan'],values['--quiesced-reference']);
 console.log(JSON.stringify(result));
}
void main().catch(()=>{console.error('Registry lock recovery failed. Review the exact plan with all Registry writers stopped; no automatic lock expiry is supported.');process.exitCode=1;});
