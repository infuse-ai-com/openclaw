import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { mkdir, mkdtemp, rm, symlink, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import test from "node:test";
import { importMissionControlFeed, type FeedLifecycleRecord } from "../dist/import-feed.js";
import { reconcileArtifactRegistry } from "../dist/reconcile.js";
import { ArtifactRegistry } from "../dist/registry.js";

const execFileAsync = promisify(execFile);

test("feed import planning is deterministic, content-free, and non-mutating", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-plan-"));
  try {
    const registry = new ArtifactRegistry(root);
    const feedRoot = path.join(process.cwd(), "packages/artifact-registry/tests/fixtures/mission-control");
    const first = await importMissionControlFeed({ registry, feedRoot });
    const second = await importMissionControlFeed({ registry, feedRoot });
    assert.deepEqual(second, first);
    assert.equal(first.mode, "plan");
    assert.equal(first.summary.discovered, 3);
    assert.equal(first.summary.blocked, 0);
    assert.equal(first.items.every((item) => item.action === "planned" && item.canonicalRevision === null), true);
    const reportJson = JSON.stringify(first);
    assert.equal(reportJson.includes("Building the first filesystem-backed"), false);
    assert.equal(reportJson.includes("<html"), false);
    assert.deepEqual((await reconcileArtifactRegistry(root)).summary, { identities: 0, revisions: 0, errors: 0, warnings: 0, truncated: false });
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("feed import applies exact bundles idempotently and preserves source evidence", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-apply-"));
  try {
    const registry = new ArtifactRegistry(root);
    const feedRoot = path.join(process.cwd(), "packages/artifact-registry/tests/fixtures/mission-control");
    const first = await importMissionControlFeed({ registry, feedRoot, apply: true });
    assert.equal(first.summary.imported, 3);
    assert.equal(first.summary.blocked, 0);
    assert.equal(first.items.every((item) => item.canonicalRevision && item.sourceRevision?.startsWith("sha256:")), true);
    const second = await importMissionControlFeed({ registry, feedRoot, apply: true });
    const third = await importMissionControlFeed({ registry, feedRoot, apply: true });
    assert.equal(second.summary.idempotent, 3);
    assert.deepEqual(third, second);
    const reconciliation = await reconcileArtifactRegistry(root);
    assert.equal(reconciliation.status, "healthy");
    assert.deepEqual(reconciliation.summary, { identities: 3, revisions: 3, errors: 0, warnings: 0, truncated: false });
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("feed import advances a changed source with an exact expected-current revision", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-advance-"));
  const artifactRoot = path.join(root, "feed", "agents", "agent-developer", "artifacts", "review");
  try {
    await mkdir(artifactRoot, { recursive: true });
    await writeFile(path.join(artifactRoot, "artifact.json"), JSON.stringify({ id: "review", agentSlug: "agent-developer", title: "Review", kind: "review" }));
    await writeFile(path.join(artifactRoot, "index.html"), "first");
    const registry = new ArtifactRegistry(path.join(root, "registry"));
    const first = await importMissionControlFeed({ registry, feedRoot: path.join(root, "feed"), apply: true });
    await writeFile(path.join(artifactRoot, "index.html"), "second");
    const second = await importMissionControlFeed({ registry, feedRoot: path.join(root, "feed"), apply: true });
    assert.equal(second.summary.imported, 1);
    assert.notEqual(second.items[0].canonicalRevision, first.items[0].canonicalRevision);
    assert.equal((await registry.history("agent-developer", "review")).length, 2);
    assert.equal((await registry.list("all"))[0].revision, second.items[0].canonicalRevision);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("feed import projects bin state and blocks an in-flight purge", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-lifecycle-"));
  const feedRoot = path.join(root, "feed");
  const agentRoot = path.join(feedRoot, "agents", "agent-developer");
  try {
    await mkdir(path.join(agentRoot, "artifacts", "review"), { recursive: true });
    await writeFile(path.join(agentRoot, "artifacts", "review", "artifact.json"), JSON.stringify({ id: "review", agentSlug: "agent-developer", title: "Review", kind: "review" }));
    await writeFile(path.join(agentRoot, "artifacts", "review", "index.html"), "<h1>Review</h1>");
    const registry = new ArtifactRegistry(path.join(root, "registry"));
    const plan = await importMissionControlFeed({ registry, feedRoot });
    const sourceRevision = plan.items[0].sourceRevision;
    assert.ok(sourceRevision);
    const lifecycle: FeedLifecycleRecord[] = [{ agentSlug: "agent-developer", itemKind: "artifact", itemId: "review", state: "trashed", revision: sourceRevision, trashedAt: "2026-09-01T00:00:00.000Z" }];
    const applied = await importMissionControlFeed({ registry, feedRoot, lifecycle, apply: true });
    assert.equal(applied.items[0].desiredState, "bin");
    assert.equal((await registry.list("bin")).length, 1);
    assert.equal((await registry.list("bin"))[0].trashedAt, "2026-09-01T00:00:00.000Z");
    const transitionRegistry = new ArtifactRegistry(path.join(root, "transition-registry"));
    await importMissionControlFeed({ registry: transitionRegistry, feedRoot, apply: true });
    const transitioned = await importMissionControlFeed({ registry: transitionRegistry, feedRoot, lifecycle, apply: true });
    assert.equal(transitioned.items[0].action, "imported");
    const stable = await importMissionControlFeed({ registry: transitionRegistry, feedRoot, lifecycle, apply: true });
    assert.equal(stable.items[0].action, "idempotent");
    const blocked = await importMissionControlFeed({ registry: new ArtifactRegistry(path.join(root, "blocked")), feedRoot, lifecycle: [{ ...lifecycle[0], state: "purge_pending" }], apply: true });
    assert.equal(blocked.summary.blocked, 1);
    assert.equal(blocked.items[0].errorCode, "purge_in_progress");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("lifecycle-only purged identities import as stable tombstones", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-tombstone-"));
  const emptyFeed = path.join(root, "feed");
  try {
    await mkdir(path.join(emptyFeed, "agents"), { recursive: true });
    const registry = new ArtifactRegistry(path.join(root, "registry"));
    const lifecycle: FeedLifecycleRecord[] = [{
      agentSlug: "agent-designer",
      itemKind: "artifact",
      itemId: "retired-review",
      state: "purged",
      revision: `sha256:${"a".repeat(64)}`,
      purgedAt: "2026-09-01T00:00:00.000Z",
    }];
    const first = await importMissionControlFeed({ registry, feedRoot: emptyFeed, lifecycle, apply: true });
    assert.equal(first.summary.tombstoned, 1);
    assert.equal((await registry.list("all"))[0].state, "purged");
    const second = await importMissionControlFeed({ registry, feedRoot: emptyFeed, lifecycle, apply: true });
    const third = await importMissionControlFeed({ registry, feedRoot: emptyFeed, lifecycle, apply: true });
    assert.equal(second.summary.idempotent, 1);
    assert.deepEqual(third, second);
    const reconciliation = await reconcileArtifactRegistry(path.join(root, "registry"));
    assert.equal(reconciliation.status, "healthy");
    assert.equal(reconciliation.tombstones.length, 1);
    await assert.rejects(() => registry.publish({ producer: "agent-designer", artifactId: "retired-review", title: "Retired review", kind: "review", files: [{ path: "review.md", mediaType: "text/markdown", contentBase64: Buffer.from("recreate").toString("base64") }] }), /tombstoned/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("tombstone re-import fails closed on conflicting stored evidence", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-tombstone-conflict-"));
  try {
    const registry = new ArtifactRegistry(root);
    const input = {
      producer: "agent-designer",
      artifactId: "retired-review",
      kind: "review",
      sourceRevision: `sha256:${"a".repeat(64)}`,
      purgedAt: "2026-09-01T00:00:00.000Z",
    };
    await registry.importPurgedIdentity(input);
    await writeFile(path.join(root, "tombstones", "agent-designer", "retired-review.json"), JSON.stringify({ hostile: true }));
    await assert.rejects(() => registry.importPurgedIdentity(input), /tombstone/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("malformed feed metadata is blocked without partial publication", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-malformed-"));
  const feedRoot = path.join(root, "feed");
  const artifactRoot = path.join(feedRoot, "agents", "agent-infra", "artifacts", "bad");
  try {
    await mkdir(artifactRoot, { recursive: true });
    await writeFile(path.join(artifactRoot, "artifact.json"), JSON.stringify({ id: "bad", agentSlug: "agent-infra", title: { hostile: true }, kind: "report" }));
    await writeFile(path.join(artifactRoot, "index.html"), "sensitive body");
    const registry = new ArtifactRegistry(path.join(root, "registry"));
    const report = await importMissionControlFeed({ registry, feedRoot, apply: true });
    assert.equal(report.summary.blocked, 1);
    assert.equal(report.items[0].errorCode, "malformed_feed_metadata");
    assert.equal((await registry.list("all")).length, 0);
    assert.equal(JSON.stringify(report).includes("sensitive body"), false);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("feed import refuses symlinked source files", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-symlink-"));
  const artifactRoot = path.join(root, "feed", "agents", "agent-infra", "artifacts", "unsafe");
  try {
    await mkdir(artifactRoot, { recursive: true });
    const outside = path.join(root, "outside.json");
    await writeFile(outside, JSON.stringify({ id: "unsafe", agentSlug: "agent-infra", title: "Unsafe", kind: "report" }));
    await symlink(outside, path.join(artifactRoot, "artifact.json"));
    const registry = new ArtifactRegistry(path.join(root, "registry"));
    const report = await importMissionControlFeed({ registry, feedRoot: path.join(root, "feed"), apply: true });
    assert.equal(report.summary.blocked, 1);
    assert.equal(report.items[0].errorCode, "malformed_feed_metadata");
    assert.equal((await registry.list("all")).length, 0);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("unavailable feed blocks lifecycle-only mutation instead of assuming an empty source", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-unavailable-"));
  try {
    const registry = new ArtifactRegistry(path.join(root, "registry"));
    const report = await importMissionControlFeed({
      registry,
      feedRoot: path.join(root, "missing-feed"),
      lifecycle: [{ agentSlug: "agent-designer", itemKind: "artifact", itemId: "retired", state: "purged", revision: `sha256:${"b".repeat(64)}`, purgedAt: "2026-09-01T00:00:00.000Z" }],
      apply: true,
    });
    assert.equal(report.summary.blocked, 1);
    assert.equal(report.items[0].errorCode, "feed_unavailable");
    assert.equal((await registry.list("all")).length, 0);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("duplicate feed or lifecycle identities block every ambiguous mutation", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-duplicates-"));
  const feedRoot = path.join(root, "feed");
  try {
    for (const directory of ["one", "two"]) {
      const artifactRoot = path.join(feedRoot, "agents", "agent-developer", "artifacts", directory);
      await mkdir(artifactRoot, { recursive: true });
      await writeFile(path.join(artifactRoot, "artifact.json"), JSON.stringify({ id: "same-review", agentSlug: "agent-developer", title: "Same", kind: "review" }));
      await writeFile(path.join(artifactRoot, "index.html"), directory);
    }
    const registry = new ArtifactRegistry(path.join(root, "registry"));
    const duplicateFeed = await importMissionControlFeed({ registry, feedRoot, apply: true });
    assert.equal(duplicateFeed.summary.blocked, 1);
    assert.equal(duplicateFeed.items[0].errorCode, "duplicate_feed_identity");
    assert.equal((await registry.list("all")).length, 0);

    const singleFeedRoot = path.join(root, "single-feed");
    const artifactRoot = path.join(singleFeedRoot, "agents", "agent-developer", "artifacts", "review");
    await mkdir(artifactRoot, { recursive: true });
    await writeFile(path.join(artifactRoot, "artifact.json"), JSON.stringify({ id: "review", agentSlug: "agent-developer", title: "Review", kind: "review" }));
    const plan = await importMissionControlFeed({ registry, feedRoot: singleFeedRoot });
    const lifecycle: FeedLifecycleRecord = { agentSlug: "agent-developer", itemKind: "artifact", itemId: "review", state: "trashed", revision: plan.items[0].sourceRevision, trashedAt: "2026-09-01T00:00:00.000Z" };
    const duplicateLifecycle = await importMissionControlFeed({ registry, feedRoot: singleFeedRoot, lifecycle: [lifecycle, lifecycle], apply: true });
    assert.equal(duplicateLifecycle.summary.blocked, 1);
    assert.equal(duplicateLifecycle.items[0].errorCode, "duplicate_lifecycle_record");
    assert.equal((await registry.list("all")).length, 0);
    const invalidLifecycle = await importMissionControlFeed({ registry, feedRoot: singleFeedRoot, lifecycle: [{ ...lifecycle, state: "unknown" }], apply: true });
    assert.equal(invalidLifecycle.summary.blocked, 1);
    assert.equal(invalidLifecycle.items[0].errorCode, "invalid_lifecycle_record");
    assert.equal((await registry.list("all")).length, 0);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("operator import and reconciliation entry points run under the repository module mode", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "artifact-import-cli-"));
  try {
    const environment = {
      ...process.env,
      ARTIFACT_REGISTRY_ROOT: root,
      MISSION_CONTROL_ROOT: path.join(process.cwd(), "packages/artifact-registry/tests/fixtures/mission-control"),
    };
    const planned = await execFileAsync("npm", ["run", "--silent", "artifact-registry:import-feed"], { cwd: process.cwd(), env: environment });
    assert.equal((JSON.parse(planned.stdout) as { summary: { discovered: number } }).summary.discovered, 3);
    const reconciled = await execFileAsync("npm", ["run", "--silent", "artifact-registry:reconcile"], { cwd: process.cwd(), env: environment });
    assert.equal((JSON.parse(reconciled.stdout) as { status: string }).status, "healthy");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
