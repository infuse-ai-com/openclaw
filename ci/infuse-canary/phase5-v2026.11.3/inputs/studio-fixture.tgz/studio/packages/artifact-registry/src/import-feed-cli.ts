import { readFile, realpath } from "node:fs/promises";
import path from "node:path";
import { importMissionControlFeed, type FeedLifecycleRecord } from "./import-feed.js";
import { ArtifactRegistry } from "./registry.js";

const root = process.env.ARTIFACT_REGISTRY_ROOT;
const feedRoot = process.env.MISSION_CONTROL_ROOT;
const lifecyclePath = process.env.ARTIFACT_REGISTRY_LIFECYCLE_FILE;
const argumentsSet = new Set(process.argv.slice(2));
if (!root || !feedRoot) throw new Error("ARTIFACT_REGISTRY_ROOT and MISSION_CONTROL_ROOT are required");
const configuredRoot = root;
const configuredFeedRoot = feedRoot;
if ([...argumentsSet].some((argument) => argument !== "--apply")) throw new Error("only --apply is supported");

async function main(): Promise<void> {
  const resolvedRoot = await realpath(path.resolve(configuredRoot));
  const resolvedFeedRoot = await realpath(path.resolve(configuredFeedRoot));
  if (resolvedRoot === resolvedFeedRoot || !path.relative(resolvedRoot, resolvedFeedRoot).startsWith("..") || !path.relative(resolvedFeedRoot, resolvedRoot).startsWith("..")) {
    throw new Error("artifact registry and Mission Control roots must not overlap");
  }
  let lifecycle: FeedLifecycleRecord[] = [];
  if (lifecyclePath) {
    const parsed: unknown = JSON.parse(await readFile(lifecyclePath, "utf8"));
    if (!Array.isArray(parsed)) throw new Error("ARTIFACT_REGISTRY_LIFECYCLE_FILE must contain an array");
    lifecycle = parsed as FeedLifecycleRecord[];
  }

  const report = await importMissionControlFeed({
    registry: new ArtifactRegistry(resolvedRoot),
    feedRoot: resolvedFeedRoot,
    lifecycle,
    apply: argumentsSet.has("--apply"),
  });
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  if (report.summary.blocked > 0) process.exitCode = 2;
}

void main().catch(() => {
  process.stderr.write("artifact feed import failed\n");
  process.exitCode = 1;
});
