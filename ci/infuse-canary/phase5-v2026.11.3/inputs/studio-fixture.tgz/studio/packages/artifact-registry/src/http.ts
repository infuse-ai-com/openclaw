import {parseLibraryQuery} from './library.js';
import {parseExactCommand} from './lifecycle.js';
import { createHash, randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import http from "node:http";
import { ArtifactRegistryError, fail, publicRegistryError, type ArtifactRegistryErrorCode } from "./errors.js";
import type { ImageStorage } from "./image-storage.js";
const IMAGE_LIMIT=10*1024*1024;
import { ArtifactRegistry, type ArtifactPublication } from "./registry.js";

const ID = /^[a-z0-9][a-z0-9._-]{0,127}$/;
const DIGEST = /^[a-f0-9]{64}$/;
const MAX_PRINCIPALS = 64;
const AUTH_KEYS = new Set(["schema", "principals"]);
const PRINCIPAL_KEYS = new Set(["subject", "producer", "scopes", "project", "studioFloors"]);
const SCOPES = new Set(["read", "write", "lifecycle", "image-upload"]);

type Scope = "read" | "write" | "lifecycle" | "image-upload";
type Principal = { subject: string; producer?: string; project?: string; studioFloors?: boolean; scopes: Scope[] };
type AuthFile = { schema: "infuse.artifact-auth/v1"; principals: Record<string, Principal> };

export type ArtifactAuditAction =
  | "liveness"
  | "readiness"
  | "authenticate"
  | "list"
  | "publish"
  | "history"
  | "read_manifest"
  | "read_content"
  | "trash"
  | "restore"
  | "purge"
  | "unknown";

export type ArtifactAuditEvent = {
  schema: "infuse.artifact-audit/v1";
  timestamp: string;
  requestId: string;
  action: ArtifactAuditAction;
  outcome: "succeeded" | "denied" | "failed";
  subject: string | null;
  producer: string | null;
  artifactId: string | null;
  revision: string | null;
  errorCode: ArtifactRegistryErrorCode | null;
};

type ServerOptions = {
  root: string;
  authPath: string;
  images?: ImageStorage;
  audit?: (event: ArtifactAuditEvent) => void;
};

function exactKeys(value: object, allowed: Set<string>): boolean {
  return Object.keys(value).every((key) => allowed.has(key));
}

function validSubject(value: unknown): value is string {
  return typeof value === "string" && value === value.trim() && value.length > 0 && value.length <= 128 && !/[\u0000-\u001f\u007f]/.test(value);
}

function parseAuthFile(value: unknown): AuthFile {
  if (!value || typeof value !== "object" || Array.isArray(value) || !exactKeys(value, AUTH_KEYS)) {
    fail("authentication_unavailable", "authentication configuration is invalid");
  }
  const candidate = value as Partial<AuthFile>;
  if (candidate.schema !== "infuse.artifact-auth/v1" || !candidate.principals || typeof candidate.principals !== "object" || Array.isArray(candidate.principals)) {
    fail("authentication_unavailable", "authentication configuration is invalid");
  }
  const entries = Object.entries(candidate.principals);
  if (entries.length === 0 || entries.length > MAX_PRINCIPALS) fail("authentication_unavailable", "authentication configuration is invalid");
  for (const [digest, principal] of entries) {
    if (!DIGEST.test(digest) || !principal || typeof principal !== "object" || Array.isArray(principal) || !exactKeys(principal, PRINCIPAL_KEYS)) {
      fail("authentication_unavailable", "authentication configuration is invalid");
    }
    if (!validSubject(principal.subject)) fail("authentication_unavailable", "authentication configuration is invalid");
    if (principal.producer !== undefined && (typeof principal.producer !== "string" || !ID.test(principal.producer))) {
      fail("authentication_unavailable", "authentication configuration is invalid");
    }
    if (!Array.isArray(principal.scopes) || principal.scopes.length === 0 || principal.scopes.length > SCOPES.size) {
      fail("authentication_unavailable", "authentication configuration is invalid");
    }
    if (principal.scopes.some((scope) => typeof scope !== "string" || !SCOPES.has(scope)) || new Set(principal.scopes).size !== principal.scopes.length) {
      fail("authentication_unavailable", "authentication configuration is invalid");
    }
    if (principal.scopes.includes("image-upload") && (!principal.producer || !(typeof principal.project === 'string' && ID.test(principal.project) && principal.studioFloors === undefined || principal.studioFloors === true && principal.producer === 'studio-whiteboard' && principal.project === undefined) || principal.scopes.length !== 1)) fail("authentication_unavailable", "Image upload requires an exact project or the dedicated Studio floor publisher with no other scopes");
    if ((principal.project !== undefined || principal.studioFloors !== undefined) && !principal.scopes.includes("image-upload")) {
      if(principal.scopes.length!==1||principal.scopes[0]!=="lifecycle"||principal.producer!==undefined||!(typeof principal.project==='string'&&ID.test(principal.project)&&principal.studioFloors===undefined||principal.studioFloors===true&&principal.project===undefined))fail("authentication_unavailable","Invalid lifecycle project scope");
    }
    if (principal.scopes.includes("write") && !principal.producer) fail("authentication_unavailable", "authentication configuration is invalid");
  }
  return candidate as AuthFile;
}

async function loadAuthFile(authPath: string): Promise<AuthFile> {
  try {
    return parseAuthFile(JSON.parse(await readFile(authPath, "utf8")));
  } catch (error) {
    if (error instanceof ArtifactRegistryError && error.code === "authentication_unavailable") throw error;
    fail("authentication_unavailable", "authentication configuration is unavailable");
  }
}

async function authenticate(request: http.IncomingMessage, authPath: string): Promise<Principal | null> {
  const auth = await loadAuthFile(authPath);
  const authorization = request.headers.authorization ?? "";
  if (!authorization.startsWith("Bearer ")) return null;
  const token = authorization.slice(7);
  if (token.length < 32 || token.length > 512 || /[\u0000-\u0020\u007f]/.test(token)) return null;
  const digest = createHash("sha256").update(token).digest("hex");
  return Object.prototype.hasOwnProperty.call(auth.principals, digest) ? auth.principals[digest] : null;
}

function json(response: http.ServerResponse, status: number, value: unknown, requestId: string): void {
  const content = Buffer.from(JSON.stringify(value));
  response.writeHead(status, {
    "content-type": "application/json",
    "content-length": content.length,
    "cache-control": "no-store",
    "x-request-id": requestId,
    "x-content-type-options": "nosniff",
  });
  response.end(content);
}

async function body(request: http.IncomingMessage, maximum=35*1024*1024): Promise<unknown> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of request) {
    const value = Buffer.from(chunk);
    size += value.length;
    if (size > maximum) fail("invalid_request", "request body is too large");
    chunks.push(value);
  }
  if (chunks.length === 0) fail("invalid_request", "request body is required");
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function safeAuditId(value: string | undefined): string | null {
  return value && ID.test(value) ? value : null;
}

export function createArtifactRegistryServer(options: ServerOptions): http.Server {
  const registry = new ArtifactRegistry(options.root, options.images);
  let imageUploadInFlight=false;
  const auditSink = options.audit ?? ((event: ArtifactAuditEvent) => console.info(JSON.stringify(event)));

  return http.createServer(async (request, response) => {
    const requestId = randomUUID();
    let action: ArtifactAuditAction = "unknown";
    let subject: string | null = null;
    let producer: string | null = null;
    let artifactId: string | null = null;
    let revision: string | null = null;
    let auditEmitted = false;

    const emitAudit = (outcome: ArtifactAuditEvent["outcome"], errorCode: ArtifactRegistryErrorCode | null = null): void => {
      if (auditEmitted) return;
      auditEmitted = true;
      try {
        auditSink({
          schema: "infuse.artifact-audit/v1",
          timestamp: new Date().toISOString(),
          requestId,
          action,
          outcome,
          subject,
          producer,
          artifactId,
          revision,
          errorCode,
        });
      } catch {
        // Audit transport is intentionally fail-open for registry availability.
      }
    };
    const send = (status: number, value: unknown, outcome: ArtifactAuditEvent["outcome"] = "succeeded"): void => {
      emitAudit(outcome);
      json(response, status, value, requestId);
    };
    const sendError = (error: ArtifactRegistryError): void => {
      emitAudit(error.status === 401 || error.status === 403 ? "denied" : "failed", error.code);
      json(response, error.status, { error: error.message, errorCode: error.code, requestId }, requestId);
    };

    try {
      const url = new URL(request.url ?? "/", "http://registry.internal");
      if (request.method === "GET" && url.pathname === "/live") {
        action = "liveness";
        return send(200, { status: "ok" });
      }
      if (request.method === "GET" && (url.pathname === "/ready" || url.pathname === "/health")) {
        action = "readiness";
        await loadAuthFile(options.authPath);
        await registry.readiness();
        return send(200, { status: "ready" });
      }

      action = "authenticate";
      const principal = await authenticate(request, options.authPath);
      if (!principal) return sendError(new ArtifactRegistryError("unauthorized", "unauthorized"));
      subject = principal.subject;

      if (request.method === "POST" && url.pathname === "/v1/images") {
        action = "publish";
        if (!principal.scopes.includes("image-upload") || !principal.producer || !principal.project && principal.studioFloors !== true) fail("forbidden", "Image upload is not permitted");
        if (!options.images) fail("storage_unavailable", "Image storage is not configured");
        const input = await body(request,14*1024*1024) as {project:string;artifactId:string;contentBase64:string};
        if (!input || typeof input !== 'object' || !exactKeys(input,new Set(['project','artifactId','contentBase64'])) || typeof input.project !== 'string' || !ID.test(input.project) || (principal.studioFloors !== true && input.project !== principal.project) || typeof input.artifactId !== 'string' || !ID.test(input.artifactId) || typeof input.contentBase64 !== 'string' || input.contentBase64.length > Math.ceil(IMAGE_LIMIT/3)*4) fail("invalid_request", "Invalid image upload");
        producer = principal.producer; artifactId = input.artifactId;
        const bytes = Buffer.from(input.contentBase64,'base64');
        if (!bytes.length || bytes.toString('base64') !== input.contentBase64) fail("invalid_request", "Invalid image bytes");
        if(imageUploadInFlight)fail("storage_unavailable","Another image is being processed; retry shortly");
        imageUploadInFlight=true;
        try {
        const image = await options.images.prepare(input.project,producer+'/'+artifactId,bytes);
        const result = await registry.publish({producer,artifactId,title:'Whiteboard image',kind:'whiteboard-image',project:input.project,intendedConsumer:'studio',sourceRef:'sha256:'+createHash('sha256').update(bytes).digest('hex'),files:[{path:'image.webp',mediaType:'image/webp',contentBase64:image.bytes.toString('base64')}]});
        revision = result.manifest.revision;
        return send(result.idempotent?200:201,{...result,width:image.width,height:image.height});
        } finally {imageUploadInFlight=false;}
      }
      if (request.method === "GET" && url.pathname === "/v1/library") {
        action = "list";
        if (!principal.scopes.includes("read")) return sendError(new ArtifactRegistryError("forbidden", "forbidden"));
        return send(200, await registry.library(parseLibraryQuery(url.searchParams)));
      }
      if (request.method === "GET" && url.pathname === "/v1/artifacts") {
        action = "list";
        if (!principal.scopes.includes("read")) return sendError(new ArtifactRegistryError("forbidden", "forbidden"));
        const filter = url.searchParams.get("state");
        if (filter !== null && !["active", "bin", "all"].includes(filter)) fail("invalid_request", "state filter is invalid");
        const state = filter === "bin" || filter === "all" ? filter : "active";
        return send(200, { artifacts: await registry.list(state) });
      }
      if (request.method === "POST" && url.pathname === "/v1/artifacts") {
        action = "publish";
        if (!principal.scopes.includes("write") || !principal.producer) return sendError(new ArtifactRegistryError("forbidden", "forbidden"));
        const publication = await body(request) as ArtifactPublication;
        if (!publication || typeof publication !== "object" || Array.isArray(publication)) fail("invalid_request", "publication must be an object");
        producer = safeAuditId(publication?.producer);
        artifactId = safeAuditId(publication?.artifactId);
        if (publication?.producer !== principal.producer) return sendError(new ArtifactRegistryError("forbidden", "producer identity mismatch"));
        if (publication.kind === "whiteboard-image") fail("forbidden", "Images require the image upload endpoint");
        const result = await registry.publish(publication);
        revision = result.manifest.revision;
        if (result.idempotent) {
          json(response, 200, result, requestId);
          return;
        }
        return send(201, result);
      }

      let segments: string[];
      try {
        segments = url.pathname.split("/").filter(Boolean).map(decodeURIComponent);
      } catch {
        fail("invalid_request", "request path is invalid");
      }
      if (segments.length >= 5 && segments[0] === "v1" && segments[1] === "artifacts") {
        const [, , routeProducer, routeArtifactId, marker, value] = segments;
        producer = safeAuditId(routeProducer);
        artifactId = safeAuditId(routeArtifactId);
        if (marker === 'current' && segments.length === 5 && request.method === 'GET') {
          action = 'read_manifest';
          if (!principal.scopes.includes('read')) return sendError(new ArtifactRegistryError('forbidden', 'forbidden'));
          if (url.searchParams.getAll('project').length !== 1 || [...url.searchParams.keys()].some(key => key !== 'project')) {
            fail('invalid_request', 'An exact project is required');
          }
          const manifest = await registry.current(routeProducer, routeArtifactId, url.searchParams.get('project')!);
          if (!manifest) return sendError(new ArtifactRegistryError('not_found', 'not found'));
          revision = manifest.revision;
          return send(200, manifest);
        }
        if (marker === 'lifecycle' && (segments.length === 5 || segments.length === 6 && value === 'audit')) {
          if(!principal.scopes.includes('lifecycle'))return sendError(new ArtifactRegistryError('forbidden','forbidden'));
          if(request.method==='GET'){
            if([...url.searchParams.keys()].some(k=>!['project','before'].includes(k))||url.searchParams.getAll('project').length!==1||url.searchParams.getAll('before').length>1)fail('invalid_request','Invalid lifecycle filter');
            const project=url.searchParams.get('project')!;
            if(principal.project!==undefined&&principal.project!==project)fail('forbidden','Lifecycle project mismatch');
            action=value==='audit'?'history':'read_manifest';
            return send(200,value==='audit'?await registry.lifecycleAudit(routeProducer,routeArtifactId,project,url.searchParams.get('before')??undefined):await registry.lifecycleView(routeProducer,routeArtifactId,project));
          }
          if(request.method==='POST'&&segments.length===5){
            if(url.search)fail('invalid_request','Invalid lifecycle filter');
            const command=parseExactCommand(await body(request,4096));
            if(command.producer!==routeProducer||command.artifactId!==routeArtifactId)fail('invalid_request','Lifecycle identity mismatch');
            if(principal.project!==undefined&&principal.project!==command.project)fail('forbidden','Lifecycle project mismatch');
            action=command.action;revision=command.revision;
            return send(200,await registry.exactLifecycle(command,principal.subject));
          }
          fail('not_found','Unknown lifecycle route');
        }
        if (marker === "revisions" && request.method === "GET") {
          action = segments.length === 5 ? "history" : segments[6] === "files" ? "read_content" : "read_manifest";
          if (!principal.scopes.includes("read")) return sendError(new ArtifactRegistryError("forbidden", "forbidden"));
          if (segments.length === 5) {
            return send(200, { revisions: await registry.history(routeProducer, routeArtifactId) });
          }
          revision = safeAuditId(value);
          if (segments.length === 6) {
            const manifest = await registry.manifest(routeProducer, routeArtifactId, value);
            if (!manifest) return sendError(new ArtifactRegistryError("not_found", "not found"));
            return send(200, manifest);
          }
          if (segments[6] === "files" && segments.length >= 8) {
            const artifactPath = segments.slice(7).join("/");
            const file = await registry.content(routeProducer, routeArtifactId, value, artifactPath);
            if (!file) return sendError(new ArtifactRegistryError("not_found", "not found"));
            emitAudit("succeeded");
            response.writeHead(200, {
              "content-type": file.mediaType,
              "content-length": file.body.length,
              "cache-control": "private, no-store",
              "content-security-policy": "default-src 'none'; sandbox",
              "x-content-type-options": "nosniff",
              "x-request-id": requestId,
            });
            return response.end(file.body);
          }
        }
        if (marker === "actions" && request.method === "POST") {
          if(principal.project!==undefined||principal.studioFloors!==undefined)fail("forbidden","Scoped lifecycle credentials require the exact protocol");
          if (value === "trash" || value === "restore" || value === "purge") action = value;
          if (!principal.scopes.includes("lifecycle")) return sendError(new ArtifactRegistryError("forbidden", "forbidden"));
          if (value !== "trash" && value !== "restore" && value !== "purge") return sendError(new ArtifactRegistryError("not_found", "unknown action"));
          const payload = await body(request);
          if (!payload || typeof payload !== "object" || Array.isArray(payload) || !exactKeys(payload, new Set(["revision"]))) {
            fail("invalid_request", "lifecycle request is invalid");
          }
          const lifecycleRevision = (payload as { revision?: unknown }).revision;
          if (typeof lifecycleRevision !== "string") fail("invalid_request", "revision is required");
          revision = safeAuditId(lifecycleRevision);
          return send(200, await registry.lifecycle(routeProducer, routeArtifactId, lifecycleRevision, value));
        }
      }
      return sendError(new ArtifactRegistryError("not_found", "not found"));
    } catch (error) {
      return sendError(publicRegistryError(error));
    }
  });
}
