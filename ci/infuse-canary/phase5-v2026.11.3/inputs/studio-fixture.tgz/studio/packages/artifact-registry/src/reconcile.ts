import type { ImageStorage } from "./image-storage.js";
import { createHash } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { ArtifactRegistryError } from "./errors.js";
import { ArtifactRegistry, computeArtifactRevision, type ArtifactManifest } from "./registry.js";

const ID = /^[a-z0-9][a-z0-9._-]{0,127}$/;
const REVISION = /^[a-f0-9]{64}$/;
const MAX_FINDINGS = 10_000;
const MAX_EVIDENCE = 1_000;
const MAX_EVIDENCE_FILES = 10_000;
const TOMBSTONE_KEYS = new Set(["schema", "producer", "artifactId", "kind", "revision", "sourceRevision", "purgedAt"]);

export type ArtifactReconciliationCode =
  | "invalid_identity"
  | "malformed_state"
  | "stale_lock"
  | "staging_residue"
  | "missing_revision_directory"
  | "orphan_revision"
  | "invalid_revision_directory"
  | "missing_manifest"
  | "malformed_manifest"
  | "revision_digest_mismatch"
  | "missing_file"
  | "unexpected_file"
  | "unsafe_file_type"
  | "file_size_mismatch"
  | "file_digest_mismatch"
  | "missing_tombstone"
  | "malformed_tombstone"
  | "orphan_tombstone";

export type ArtifactReconciliationFinding = {
  severity: "error" | "warning";
  code: ArtifactReconciliationCode;
  producer: string | null;
  artifactId: string | null;
  revision: string | null;
  filePathHash: string | null;
};

export type ArtifactReconciliationEvidence = {
  producer: string;
  artifactId: string;
  revision: string;
  manifestSha256: string;
  filesDigest: string;
  fileCount: number;
  totalBytes: number;
  files: Array<{ pathHash: string; bytes: number; sha256: string }>;
};

export type ArtifactTombstoneEvidence = {
  producer: string;
  artifactId: string;
  revision: string;
  tombstoneSha256: string;
};

export type ArtifactReconciliationReport = {
  schema: "infuse.artifact-reconciliation/v1";
  status: "healthy" | "degraded";
  summary: {
    identities: number;
    revisions: number;
    errors: number;
    warnings: number;
    truncated: boolean;
  };
  findings: ArtifactReconciliationFinding[];
  evidence: ArtifactReconciliationEvidence[];
  tombstones: ArtifactTombstoneEvidence[];
  reportDigest: string;
};

type ReconciliationState = {
  state: "active" | "bin" | "purged";
  revision: string;
  revisions: string[];
  generation?: number;
  kind: string;
  trashedAt?: string | null;
  updatedAt: string;
};

function sha256(value: string | Buffer): string {
  return createHash("sha256").update(value).digest("hex");
}

function parseState(value: unknown): ReconciliationState | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value as Partial<ReconciliationState>;
  if (candidate.state !== "active" && candidate.state !== "bin" && candidate.state !== "purged") return null;
  if (typeof candidate.revision !== "string" || !REVISION.test(candidate.revision)) return null;
  if (typeof candidate.kind !== "string" || !ID.test(candidate.kind)) return null;
  if (!Array.isArray(candidate.revisions) || candidate.revisions.some((revision) => typeof revision !== "string" || !REVISION.test(revision))) return null;
  if (new Set(candidate.revisions).size !== candidate.revisions.length) return null;
  if (candidate.state === "purged" && candidate.revisions.length !== 0) return null;
  if (candidate.state !== "purged" && (candidate.revisions.length === 0 || candidate.revisions.at(-1) !== candidate.revision)) return null;
  if (candidate.generation !== undefined && (!Number.isSafeInteger(candidate.generation) || Number(candidate.generation) <= 0)) return null;
  if (candidate.trashedAt !== undefined && candidate.trashedAt !== null && (typeof candidate.trashedAt !== "string" || !Number.isFinite(Date.parse(candidate.trashedAt)))) return null;
  if (candidate.state === "active" && candidate.trashedAt !== undefined && candidate.trashedAt !== null) return null;
  if ((candidate.state === "bin" || candidate.state === "purged") && !candidate.trashedAt) return null;
  if (typeof candidate.updatedAt !== "string" || !Number.isFinite(Date.parse(candidate.updatedAt))) return null;
  return candidate as ReconciliationState;
}

async function directoryEntries(directory: string) {
  return readdir(directory, { withFileTypes: true }).catch(() => []);
}

async function inventoryFiles(root: string, prefix = ""): Promise<Array<{ path: string; kind: "file" | "unsafe" }>> {
  const inventory: Array<{ path: string; kind: "file" | "unsafe" }> = [];
  for (const entry of (await directoryEntries(root)).sort((a, b) => a.name.localeCompare(b.name))) {
    const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      inventory.push(...await inventoryFiles(path.join(root, entry.name), relativePath));
    } else {
      inventory.push({ path: relativePath, kind: entry.isFile() ? "file" : "unsafe" });
    }
  }
  return inventory;
}

function findingSortKey(finding: ArtifactReconciliationFinding): string {
  return [finding.producer, finding.artifactId, finding.revision, finding.filePathHash, finding.code].map((value) => value ?? "").join("\0");
}

export async function reconcileArtifactRegistry(root: string, images?: ImageStorage): Promise<ArtifactReconciliationReport> {
  const registry = new ArtifactRegistry(root, images);
  const findings: ArtifactReconciliationFinding[] = [];
  const evidence: ArtifactReconciliationEvidence[] = [];
  const tombstones: ArtifactTombstoneEvidence[] = [];
  const recognizedTombstones = new Set<string>();
  let identities = 0;
  let revisions = 0;
  let evidenceFiles = 0;
  let truncated = false;

  const add = (finding: ArtifactReconciliationFinding): void => {
    if (findings.length >= MAX_FINDINGS) {
      truncated = true;
      return;
    }
    findings.push(finding);
  };

  for (const stagingEntry of await directoryEntries(path.join(root, ".staging"))) {
    add({ severity: "warning", code: "staging_residue", producer: null, artifactId: null, revision: null, filePathHash: sha256(stagingEntry.name) });
  }

  const objectsRoot = path.join(root, "objects");
  for (const producerEntry of (await directoryEntries(objectsRoot)).sort((a, b) => a.name.localeCompare(b.name))) {
    if (!producerEntry.isDirectory() || !ID.test(producerEntry.name)) {
      add({ severity: "error", code: "invalid_identity", producer: null, artifactId: null, revision: null, filePathHash: sha256(producerEntry.name) });
      continue;
    }
    const producer = producerEntry.name;
    for (const artifactEntry of (await directoryEntries(path.join(objectsRoot, producer))).sort((a, b) => a.name.localeCompare(b.name))) {
      if (!artifactEntry.isDirectory() || !ID.test(artifactEntry.name)) {
        add({ severity: "error", code: "invalid_identity", producer, artifactId: null, revision: null, filePathHash: sha256(artifactEntry.name) });
        continue;
      }
      identities += 1;
      const artifactId = artifactEntry.name;
      const artifactRoot = path.join(objectsRoot, producer, artifactId);
      if ((await directoryEntries(artifactRoot)).some((entry) => entry.name === ".lock")) {
        add({ severity: "warning", code: "stale_lock", producer, artifactId, revision: null, filePathHash: null });
      }

      let state: ReconciliationState | null = null;
      try {
        state = parseState(JSON.parse(await readFile(path.join(artifactRoot, "state.json"), "utf8")));
      } catch {
        state = null;
      }
      if (!state) {
        add({ severity: "error", code: "malformed_state", producer, artifactId, revision: null, filePathHash: null });
        continue;
      }

      const tombstoneKey = `${producer}\0${artifactId}`;
      const tombstonePath = path.join(root, "tombstones", producer, `${artifactId}.json`);
      const rawTombstone = await readFile(tombstonePath).catch(() => null);
      if (rawTombstone) recognizedTombstones.add(tombstoneKey);
      if (state.state === "purged" && state.kind !== "journal") {
        if (!rawTombstone) {
          add({ severity: "error", code: "missing_tombstone", producer, artifactId, revision: state.revision, filePathHash: null });
        } else {
          try {
            const parsed = JSON.parse(rawTombstone.toString("utf8")) as Record<string, unknown>;
            if (Object.keys(parsed).some((key) => !TOMBSTONE_KEYS.has(key)) || parsed.schema !== "infuse.artifact-tombstone/v1" || parsed.producer !== producer || parsed.artifactId !== artifactId || parsed.kind !== state.kind || parsed.revision !== state.revision || typeof parsed.sourceRevision !== "string" || !/^(?:sha256:)?[a-f0-9]{64}$/.test(parsed.sourceRevision) || typeof parsed.purgedAt !== "string" || !Number.isFinite(Date.parse(parsed.purgedAt))) {
              throw new Error("invalid tombstone");
            }
            if (tombstones.length >= MAX_EVIDENCE) truncated = true;
            else tombstones.push({ producer, artifactId, revision: state.revision, tombstoneSha256: sha256(rawTombstone) });
          } catch {
            add({ severity: "error", code: "malformed_tombstone", producer, artifactId, revision: state.revision, filePathHash: null });
          }
        }
      } else if (rawTombstone) {
        add({ severity: "warning", code: "orphan_tombstone", producer, artifactId, revision: state.revision, filePathHash: null });
      }

      const revisionEntries = await directoryEntries(path.join(artifactRoot, "revisions"));
      const storedRevisionDirectories = new Set<string>();
      for (const entry of revisionEntries.sort((a, b) => a.name.localeCompare(b.name))) {
        if (!entry.isDirectory() || !REVISION.test(entry.name)) {
          add({ severity: "error", code: "invalid_revision_directory", producer, artifactId, revision: null, filePathHash: sha256(entry.name) });
          continue;
        }
        storedRevisionDirectories.add(entry.name);
        if (!state.revisions.includes(entry.name)) {
          add({ severity: "warning", code: "orphan_revision", producer, artifactId, revision: entry.name, filePathHash: null });
        }
      }

      for (const revision of state.revisions) {
        revisions += 1;
        if (!storedRevisionDirectories.has(revision)) {
          add({ severity: "error", code: "missing_revision_directory", producer, artifactId, revision, filePathHash: null });
          continue;
        }
        let manifest: ArtifactManifest | null;
        try {
          manifest = await registry.manifest(producer, artifactId, revision);
        } catch (error) {
          const code = error instanceof ArtifactRegistryError && error.code === "integrity_failure" ? "malformed_manifest" : "missing_manifest";
          add({ severity: "error", code, producer, artifactId, revision, filePathHash: null });
          continue;
        }
        if (!manifest) {
          add({ severity: "error", code: "missing_manifest", producer, artifactId, revision, filePathHash: null });
          continue;
        }
        if (computeArtifactRevision(manifest, manifest.files) !== revision) {
          add({ severity: "error", code: "revision_digest_mismatch", producer, artifactId, revision, filePathHash: null });
        }

        const filesRoot = path.join(artifactRoot, "revisions", revision, "files");
        const actualInventory = await inventoryFiles(filesRoot);
        const actualByPath = new Map(actualInventory.map((item) => [item.path, item.kind]));
        const expectedPaths = new Set(manifest.files.map((file) => file.path));
        for (const item of actualInventory) {
          if (item.kind === "unsafe") add({ severity: "error", code: "unsafe_file_type", producer, artifactId, revision, filePathHash: sha256(item.path) });
          if (!expectedPaths.has(item.path)) add({ severity: "warning", code: "unexpected_file", producer, artifactId, revision, filePathHash: sha256(item.path) });
        }
        for (const file of manifest.files) {
          const actualKind = actualByPath.get(file.path);
          if (!actualKind && manifest.kind !== "whiteboard-image") {
            add({ severity: "error", code: "missing_file", producer, artifactId, revision, filePathHash: sha256(file.path) });
            continue;
          }
          if (actualKind !== "file" && manifest.kind !== "whiteboard-image") continue;
          const body = manifest.kind === "whiteboard-image" ? await registry.content(producer,artifactId,revision,file.path).then(result=>result?.body??null).catch(()=>null) : await readFile(path.join(filesRoot, ...file.path.split("/"))).catch(() => null);
          if (!body) {
            add({ severity: "error", code: "missing_file", producer, artifactId, revision, filePathHash: sha256(file.path) });
            continue;
          }
          if (body.length !== file.bytes) add({ severity: "error", code: "file_size_mismatch", producer, artifactId, revision, filePathHash: sha256(file.path) });
          if (sha256(body) !== file.sha256) add({ severity: "error", code: "file_digest_mismatch", producer, artifactId, revision, filePathHash: sha256(file.path) });
        }
        const rawManifest = await readFile(path.join(artifactRoot, "revisions", revision, "manifest.json")).catch(() => null);
        if (!rawManifest) {
          add({ severity: "error", code: "missing_manifest", producer, artifactId, revision, filePathHash: null });
          continue;
        }
        const fileEvidence = [...manifest.files].sort((a, b) => a.path.localeCompare(b.path));
        if (evidence.length >= MAX_EVIDENCE || evidenceFiles + fileEvidence.length > MAX_EVIDENCE_FILES) truncated = true;
        else {
          evidence.push({
            producer,
            artifactId,
            revision,
            manifestSha256: sha256(rawManifest),
            filesDigest: sha256(JSON.stringify(fileEvidence)),
            fileCount: fileEvidence.length,
            totalBytes: fileEvidence.reduce((sum, file) => sum + file.bytes, 0),
            files: fileEvidence.map((file) => ({ pathHash: sha256(file.path), bytes: file.bytes, sha256: file.sha256 })),
          });
          evidenceFiles += fileEvidence.length;
        }
      }
    }
  }

  for (const producerEntry of (await directoryEntries(path.join(root, "tombstones"))).sort((a, b) => a.name.localeCompare(b.name))) {
    if (!producerEntry.isDirectory() || !ID.test(producerEntry.name)) {
      add({ severity: "warning", code: "orphan_tombstone", producer: null, artifactId: null, revision: null, filePathHash: sha256(producerEntry.name) });
      continue;
    }
    for (const entry of (await directoryEntries(path.join(root, "tombstones", producerEntry.name))).sort((a, b) => a.name.localeCompare(b.name))) {
      const artifactId = entry.name.endsWith(".json") ? entry.name.slice(0, -5) : "";
      if (!entry.isFile() || !ID.test(artifactId) || !recognizedTombstones.has(`${producerEntry.name}\0${artifactId}`)) {
        add({ severity: "warning", code: "orphan_tombstone", producer: producerEntry.name, artifactId: ID.test(artifactId) ? artifactId : null, revision: null, filePathHash: null });
      }
    }
  }

  findings.sort((a, b) => findingSortKey(a).localeCompare(findingSortKey(b)));
  evidence.sort((a, b) => `${a.producer}\0${a.artifactId}\0${a.revision}`.localeCompare(`${b.producer}\0${b.artifactId}\0${b.revision}`));
  tombstones.sort((a, b) => `${a.producer}\0${a.artifactId}`.localeCompare(`${b.producer}\0${b.artifactId}`));
  const errors = findings.filter((finding) => finding.severity === "error").length;
  const warnings = findings.length - errors;
  const summary = { identities, revisions, errors, warnings, truncated };
  const reportDigest = sha256(JSON.stringify({ summary, findings, evidence, tombstones }));
  return {
    schema: "infuse.artifact-reconciliation/v1",
    status: findings.length > 0 || truncated ? "degraded" : "healthy",
    summary,
    findings,
    evidence,
    tombstones,
    reportDigest,
  };
}
