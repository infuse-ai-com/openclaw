import { readFile } from "node:fs/promises";
import { S3ImageStorage, parseImageStorageConfig } from "./image-storage.js";
import { reconcileArtifactRegistry } from "./reconcile.js";

const root = process.env.ARTIFACT_REGISTRY_ROOT;
if (!root) throw new Error("ARTIFACT_REGISTRY_ROOT is required");
const configuredRoot = root;

async function main(): Promise<void> {
  const images=process.env.ARTIFACT_REGISTRY_IMAGES_CONFIG?new S3ImageStorage(parseImageStorageConfig(JSON.parse(await readFile(process.env.ARTIFACT_REGISTRY_IMAGES_CONFIG,"utf8")))):undefined;
  const report = await reconcileArtifactRegistry(configuredRoot,images);
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  if (report.status !== "healthy") process.exitCode = 2;
}

void main().catch(() => {
  process.stderr.write("artifact registry reconciliation failed\n");
  process.exitCode = 1;
});
