import {fail} from './errors.js';
const ID=/^[a-z0-9][a-z0-9._-]{0,127}$/,DIGEST=/^[a-f0-9]{64}$/,UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
export interface ExactLifecycleCommand {commandId:string;actorId:string;project:string;producer:string;artifactId:string;revision:string;generation:number;action:'trash'|'restore'|'purge'}
export interface ExactLifecycleReceipt extends ExactLifecycleCommand {schema:'infuse.artifact-lifecycle-receipt/v1';state:'active'|'bin'|'purged';occurredAt:string}
export interface ExactLifecycleView {project:string;producer:string;artifactId:string;revision:string;generation:number;state:'active'|'bin'|'purged';updatedAt:string;trashedAt:string|null;pending:boolean}
const COMMAND_KEYS=['commandId','actorId','project','producer','artifactId','revision','generation','action'];
export function parseExactCommand(value:unknown,receipt=false):ExactLifecycleCommand {
 const c=value as ExactLifecycleCommand;
 if(!c||typeof c!=='object'||Array.isArray(c)||Object.keys(c).some(k=>![...COMMAND_KEYS,...(receipt?['schema','state','occurredAt']:[])].includes(k))||!UUID.test(c.commandId)||!DIGEST.test(c.actorId)||![c.project,c.producer,c.artifactId].every(x=>typeof x==='string'&&ID.test(x))||!DIGEST.test(c.revision)||!Number.isSafeInteger(c.generation)||c.generation<1||c.generation>=Number.MAX_SAFE_INTEGER||!['trash','restore','purge'].includes(c.action))fail('invalid_request','Invalid exact lifecycle command');
 return {commandId:c.commandId,actorId:c.actorId,project:c.project,producer:c.producer,artifactId:c.artifactId,revision:c.revision,generation:c.generation,action:c.action};
}
export function parseExactReceipt(value:unknown):ExactLifecycleReceipt {
 const c=parseExactCommand(value,true),r=value as ExactLifecycleReceipt;
 if(r.schema!=='infuse.artifact-lifecycle-receipt/v1'||r.state!==(c.action==='trash'?'bin':c.action==='restore'?'active':'purged')||typeof r.occurredAt!=='string'||!Number.isFinite(Date.parse(r.occurredAt)))fail('integrity_failure','Invalid lifecycle receipt');
 return {schema:r.schema,...c,state:r.state,occurredAt:r.occurredAt};
}
