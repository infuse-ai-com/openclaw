# Registry test ownership

The Registry owns filtering, immutable content and lifecycle effects. Studio's
wire-fixture adapter tests do not prove this package's matching or persistence.
Keep legacy protocol, exact receipts, lock recovery, filesystem recovery and
image-storage contracts distinct; synthetic filesystem recovery is not S3 proof.

Use discriminating data for filters. An exact mission restriction can hide a
broken mission-only scope filter; exercise the scope without that restriction.
Keep both matching and excluding cases, foreign-project records, pagination and
active/bin transitions. Prefer exact result identities to repeated count checks.

Use disposable stores and the root verification rules. Container, canonical
publisher and real scanner/storage harnesses establish their own limited scope;
do not claim those boundaries from in-memory adapters or ordinary wire fixtures.
