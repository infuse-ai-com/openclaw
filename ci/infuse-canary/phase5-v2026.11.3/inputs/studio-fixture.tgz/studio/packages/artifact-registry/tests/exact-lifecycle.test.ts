import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {mkdtemp,readFile,readdir,rm,writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import test from 'node:test';
import {ArtifactRegistry} from '../dist/registry.js';
import {createArtifactRegistryServer} from '../dist/http.js';
const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
async function fixture(t:any){const root=await mkdtemp(join(tmpdir(),'registry-exact-'));t.after(()=>rm(root,{recursive:true,force:true}));const registry=new ArtifactRegistry(root);const {manifest}=await registry.publish({producer:'agent-designer',artifactId:'report',title:'Private title',project:'studio',kind:'report',files:[{path:'index.html',mediaType:'text/html',contentBase64:Buffer.from('Private contents').toString('base64')}]});const command={commandId:randomUUID(),actorId:hash('human'),project:'studio',producer:manifest.producer,artifactId:manifest.artifactId,revision:manifest.revision,generation:1,action:'trash' as const};return {root,registry,manifest,command};}
test('exact lifecycle deduplicates across restart, rejects changed envelopes and stale same-revision generations',async t=>{
 const f=await fixture(t),first=await f.registry.exactLifecycle(f.command,'studio-client');
 assert.equal(first.generation,2);assert.equal(first.state,'bin');
 const restarted=new ArtifactRegistry(f.root);assert.deepEqual(await restarted.exactLifecycle(f.command,'studio-client'),first);
 await assert.rejects(restarted.exactLifecycle({...f.command,actorId:hash('other')},'studio-client'),/conflict/);
 await assert.rejects(restarted.exactLifecycle(f.command,'different-client'),/conflict/);
 const restore={...f.command,commandId:randomUUID(),generation:2,action:'restore' as const};await restarted.exactLifecycle(restore,'studio-client');
 assert.equal((await restarted.lifecycleView('agent-designer','report','studio')).generation,3);
 assert.deepEqual(await restarted.exactLifecycle(f.command,'studio-client'),first);
 await assert.rejects(restarted.exactLifecycle({...f.command,commandId:randomUUID()},'studio-client'),/generation/);
 assert.equal((await restarted.list('active')).length,1);
 await assert.rejects(restarted.lifecycleView('agent-designer','report','other'),/outside/);
});
test('a write-ahead command fences conflicting legacy/new effects and completes after an interrupted state commit',async t=>{
 const f=await fixture(t),effect=(f.registry as any).applyLifecycle.bind(f.registry);
 (f.registry as any).applyLifecycle=async(...args:any[])=>{await effect(...args);throw Error('simulated response/process boundary');};
 await assert.rejects(f.registry.exactLifecycle(f.command),/simulated/);
 assert.equal((await f.registry.lifecycleView('agent-designer','report','studio')).pending,true);
 await assert.rejects(f.registry.lifecycle('agent-designer','report',f.manifest.revision,'restore'),/reconciliation/);
 await assert.rejects(f.registry.exactLifecycle({...f.command,commandId:randomUUID(),generation:2,action:'restore'}),/reconciliation/);
 await assert.rejects(f.registry.publish({producer:'agent-designer',artifactId:'report',title:'New',kind:'report',project:'studio',expectedCurrentRevision:f.manifest.revision,files:[{path:'index.html',mediaType:'text/html',contentBase64:'bmV3'}]}),/reconciliation/);
 const restarted=new ArtifactRegistry(f.root),receipt=await restarted.exactLifecycle(f.command);assert.equal(receipt.generation,2);assert.equal((await restarted.lifecycleView('agent-designer','report','studio')).pending,false);
 const audit=await restarted.lifecycleAudit('agent-designer','report','studio');assert.equal(audit.receipts.length,1);const text=JSON.stringify(audit);assert.ok(!text.includes('Private'));assert.ok(!text.includes('index.html'));
});
test('partial image purge is resumable under one command, preserves audit and repairs post-state tombstones',async t=>{
 const root=await mkdtemp(join(tmpdir(),'registry-image-exact-'));t.after(()=>rm(root,{recursive:true,force:true}));let failing=true,removed=0;
 const images={prepare:async(_p:string,_i:string,b:Buffer)=>({bytes:b,width:1,height:1}),put:async()=>{},get:async()=>Buffer.from('image'),purge:async()=>{removed++;if(failing)throw Error('interrupted versions');}};
 const r=new ArtifactRegistry(root,images);const {manifest:m}=await r.publish({producer:'studio-whiteboard',artifactId:'image',title:'Image',kind:'whiteboard-image',project:'studio',files:[{path:'image.webp',mediaType:'image/webp',contentBase64:Buffer.from('image').toString('base64')}]});
 const c={commandId:randomUUID(),actorId:hash('human'),project:'studio',producer:m.producer,artifactId:m.artifactId,revision:m.revision,generation:1,action:'trash' as 'trash'|'restore'|'purge'};await r.exactLifecycle(c);
 const purge={...c,commandId:randomUUID(),generation:2,action:'purge' as const};await assert.rejects(r.exactLifecycle(purge),/interrupted/);assert.equal((await r.list('bin')).length,1);
 failing=false;const restarted=new ArtifactRegistry(root,images);const effect=(restarted as any).applyLifecycle.bind(restarted);(restarted as any).applyLifecycle=async(...args:any[])=>{const result=await effect(...args);await rm(join(root,'tombstones',m.producer,m.artifactId+'.json'));throw Error('post-state crash');return result;};
 await assert.rejects(restarted.exactLifecycle(purge),/post-state/);
 const fresh=new ArtifactRegistry(root,images),receipt=await fresh.exactLifecycle(purge);assert.equal(receipt.state,'purged');assert.equal(receipt.generation,3);assert.equal(removed,2);assert.deepEqual(await fresh.exactLifecycle(purge),receipt);
 assert.equal(JSON.parse(await readFile(join(root,'tombstones',m.producer,m.artifactId+'.json'),'utf8')).revision,m.revision);
 assert.equal((await fresh.lifecycleAudit(m.producer,m.artifactId,'studio')).receipts.length,2);assert.equal((await fresh.lifecycleView(m.producer,m.artifactId,'studio')).state,'purged');
 await assert.rejects(fresh.publish({producer:m.producer,artifactId:m.artifactId,title:'Resurrection',kind:'report',project:'studio',files:[{path:'index.html',mediaType:'text/html',contentBase64:'eA=='}]}),/tombstoned/);
});
test('concurrent exact commands produce one transition and complete receipts survive purge',async t=>{
 const f=await fixture(t),other={...f.command,commandId:randomUUID()};const results=await Promise.allSettled([f.registry.exactLifecycle(f.command),f.registry.exactLifecycle(other)]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
 assert.equal((await f.registry.lifecycleAudit('agent-designer','report','studio')).receipts.length,1);
 const bin=await f.registry.lifecycleView('agent-designer','report','studio');const purge={...f.command,commandId:randomUUID(),generation:bin.generation,action:'purge' as const};await f.registry.exactLifecycle(purge);
 assert.equal((await f.registry.lifecycleAudit('agent-designer','report','studio')).receipts.length,2);assert.equal(await f.registry.content('agent-designer','report',f.manifest.revision,'index.html'),null);
});
test('scoped lifecycle credentials cannot bypass project validation through the legacy endpoint',async t=>{
 const f=await fixture(t),token='synthetic-lifecycle-0123456789abcdef',reader='synthetic-reader-0123456789abcdef',authPath=join(f.root,'auth.json');await writeFile(authPath,JSON.stringify({schema:'infuse.artifact-auth/v1',principals:{[hash(token)]:{subject:'studio-lifecycle',project:'studio',scopes:['lifecycle']},[hash(reader)]:{subject:'reader',scopes:['read']}}}));
 const server=createArtifactRegistryServer({root:f.root,authPath,audit:()=>{}});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise<void>(r=>server.close(()=>r())));const base='http://127.0.0.1:'+(server.address() as any).port+'/v1/artifacts/agent-designer/report';
 const post=(path:string,data:any,key=token)=>fetch(base+path,{method:'POST',headers:{authorization:'Bearer '+key,'content-type':'application/json'},body:JSON.stringify(data)});
 assert.equal((await post('/actions/trash',{revision:f.manifest.revision})).status,403);
 assert.equal((await post('/lifecycle',{...f.command,project:'other'})).status,403);
 assert.equal((await post('/lifecycle',f.command,reader)).status,403);
 assert.equal((await post('/lifecycle',{...f.command,unexpected:true})).status,400);
 const receipt=await (await post('/lifecycle',f.command)).json();assert.equal(receipt.state,'bin');assert.deepEqual(await (await post('/lifecycle',f.command)).json(),receipt);
 const view=await fetch(base+'/lifecycle?project=studio',{headers:{authorization:'Bearer '+token}});assert.equal(view.status,200);assert.equal((await view.json()).generation,2);
});

test('corrupt durable receipts fail closed without changing current lifecycle',async t=>{
 const f=await fixture(t);await f.registry.exactLifecycle(f.command);
 const path=join(f.root,'objects',f.command.producer,f.command.artifactId,'.lifecycle-receipts',hash(f.command.commandId)+'.json'),saved=JSON.parse(await readFile(path,'utf8'));saved.receipt.actorId=hash('changed');await writeFile(path,JSON.stringify(saved));
 await assert.rejects(f.registry.exactLifecycle(f.command),/integrity/);await assert.rejects(f.registry.lifecycleAudit(f.command.producer,f.command.artifactId,'studio'),/integrity/);assert.equal((await f.registry.lifecycleView(f.command.producer,f.command.artifactId,'studio')).generation,2);
});
test('bounded audit pages traverse all receipts once without dropping historical transitions',async t=>{
 const f=await fixture(t);for(let i=0;i<53;i++)await f.registry.exactLifecycle({...f.command,commandId:randomUUID(),generation:i+1,action:i%2?'restore':'trash'});
 const first=await f.registry.lifecycleAudit(f.command.producer,f.command.artifactId,'studio');assert.equal(first.receipts.length,50);assert.ok(first.nextCursor);const second=await f.registry.lifecycleAudit(f.command.producer,f.command.artifactId,'studio',first.nextCursor);assert.equal(second.receipts.length,3);assert.equal(second.nextCursor,null);assert.equal(new Set([...first.receipts,...second.receipts].map(r=>r.commandId)).size,53);
});
