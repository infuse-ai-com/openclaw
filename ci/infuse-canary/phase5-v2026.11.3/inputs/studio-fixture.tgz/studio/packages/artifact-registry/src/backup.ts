import { createHash, randomUUID } from "node:crypto";
import { chmod, copyFile, lstat, mkdir, readFile, readdir, rename, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { reconcileArtifactRegistry } from "./reconcile.js";

const SCHEMA = "infuse.artifact-registry-backup/v1" as const;
const CANONICAL_ROOTS = ["audit", "objects", "tombstones"] as const;
const TRANSIENT_ROOTS = new Set([".readiness", ".staging"]);
const SHA256 = /^[a-f0-9]{64}$/;

export type ArtifactRegistryBackupFile = {
  path: string;
  bytes: number;
  sha256: string;
};

export type ArtifactRegistryBackupManifest = {
  schema: typeof SCHEMA;
  createdAt: string;
  consistency: "offline-quiesced";
  sourceReconciliationDigest: string;
  rootDigest: string;
  fileCount: number;
  totalBytes: number;
  files: ArtifactRegistryBackupFile[];
};

export type ArtifactRegistryBackupReceipt = {
  schema: "infuse.artifact-registry-backup-receipt/v1";
  status: "created" | "verified" | "restored";
  rootDigest: string;
  reconciliationDigest: string;
  fileCount: number;
  totalBytes: number;
};

function sha256(value: string | Buffer): string {
  return createHash("sha256").update(value).digest("hex");
}

function safeRelativePath(value: unknown): value is string {
  if (typeof value !== "string" || !value || value.includes("\\") || path.posix.isAbsolute(value)) return false;
  const normalized = path.posix.normalize(value);
  return normalized === value && normalized !== "." && !normalized.startsWith("../") && !normalized.includes("/../");
}

function inside(parent: string, candidate: string): boolean {
  const relative = path.relative(path.resolve(parent), path.resolve(candidate));
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

async function entries(directory: string) {
  return readdir(directory, { withFileTypes: true }).catch((error: NodeJS.ErrnoException) => {
    if (error.code === "ENOENT") return [];
    throw error;
  });
}

async function inventory(directory: string, prefix = ""): Promise<ArtifactRegistryBackupFile[]> {
  const files: ArtifactRegistryBackupFile[] = [];
  for (const entry of (await entries(directory)).sort((a, b) => a.name.localeCompare(b.name))) {
    const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name;
    const absolutePath = path.join(directory, entry.name);
    if (entry.isSymbolicLink() || (!entry.isDirectory() && !entry.isFile())) {
      throw new Error("artifact registry backup source contains an unsafe file type");
    }
    if (entry.isDirectory()) files.push(...await inventory(absolutePath, relativePath));
    else {
      const body = await readFile(absolutePath);
      files.push({ path: relativePath, bytes: body.length, sha256: sha256(body) });
    }
  }
  return files;
}

function rootDigest(files: ArtifactRegistryBackupFile[]): string {
  return sha256(JSON.stringify(files));
}

async function validateSourceRoot(root: string): Promise<void> {
  const source = await lstat(root).catch(() => null);
  if (!source?.isDirectory() || source.isSymbolicLink()) {
    throw new Error("artifact registry backup source must be a directory");
  }
  const rootEntries = await entries(root);
  const allowed = new Set<string>([...CANONICAL_ROOTS, ...TRANSIENT_ROOTS]);
  if (rootEntries.some((entry) => !allowed.has(entry.name))) {
    throw new Error("artifact registry backup source contains an unsupported top-level entry");
  }
  for (const transientRoot of TRANSIENT_ROOTS) {
    if ((await entries(path.join(root, transientRoot))).length > 0) {
      throw new Error("artifact registry backup source is not quiescent");
    }
  }
}

async function canonicalInventory(root: string): Promise<ArtifactRegistryBackupFile[]> {
  const files: ArtifactRegistryBackupFile[] = [];
  for (const canonicalRoot of CANONICAL_ROOTS) {
    files.push(...await inventory(path.join(root, canonicalRoot), canonicalRoot));
  }
  return files.sort((a, b) => a.path.localeCompare(b.path));
}

async function copyInventory(sourceRoot: string, destinationRoot: string, files: ArtifactRegistryBackupFile[]): Promise<void> {
  for (const file of files) {
    const source = path.join(sourceRoot, ...file.path.split("/"));
    const destination = path.join(destinationRoot, ...file.path.split("/"));
    await mkdir(path.dirname(destination), { recursive: true });
    await copyFile(source, destination);
    await chmod(destination, 0o600);
  }
}

function normalizeManifest(value: unknown): ArtifactRegistryBackupManifest {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("artifact registry backup manifest is invalid");
  const candidate = value as Partial<ArtifactRegistryBackupManifest>;
  const keys = new Set(["schema", "createdAt", "consistency", "sourceReconciliationDigest", "rootDigest", "fileCount", "totalBytes", "files"]);
  if (Object.keys(candidate).some((key) => !keys.has(key))) throw new Error("artifact registry backup manifest is invalid");
  if (candidate.schema !== SCHEMA || candidate.consistency !== "offline-quiesced") throw new Error("artifact registry backup manifest is invalid");
  if (typeof candidate.createdAt !== "string" || !Number.isFinite(Date.parse(candidate.createdAt))) throw new Error("artifact registry backup manifest is invalid");
  if (typeof candidate.sourceReconciliationDigest !== "string" || !SHA256.test(candidate.sourceReconciliationDigest)) throw new Error("artifact registry backup manifest is invalid");
  if (typeof candidate.rootDigest !== "string" || !SHA256.test(candidate.rootDigest)) throw new Error("artifact registry backup manifest is invalid");
  if (!Number.isSafeInteger(candidate.fileCount) || Number(candidate.fileCount) < 0) throw new Error("artifact registry backup manifest is invalid");
  if (!Number.isSafeInteger(candidate.totalBytes) || Number(candidate.totalBytes) < 0) throw new Error("artifact registry backup manifest is invalid");
  if (!Array.isArray(candidate.files)) throw new Error("artifact registry backup manifest is invalid");
  const seen = new Set<string>();
  for (const file of candidate.files) {
    if (!file || typeof file !== "object" || Array.isArray(file)) throw new Error("artifact registry backup manifest is invalid");
    if (Object.keys(file).some((key) => !new Set(["path", "bytes", "sha256"]).has(key))) throw new Error("artifact registry backup manifest is invalid");
    if (!safeRelativePath(file.path) || !CANONICAL_ROOTS.some((root) => file.path === root || file.path.startsWith(`${root}/`)) || seen.has(file.path)) {
      throw new Error("artifact registry backup manifest is invalid");
    }
    seen.add(file.path);
    if (!Number.isSafeInteger(file.bytes) || file.bytes < 0 || typeof file.sha256 !== "string" || !SHA256.test(file.sha256)) {
      throw new Error("artifact registry backup manifest is invalid");
    }
  }
  const files = [...candidate.files].sort((a, b) => a.path.localeCompare(b.path));
  if (files.some((file, index) => file.path !== candidate.files?.[index]?.path)) throw new Error("artifact registry backup manifest is invalid");
  if (candidate.fileCount !== files.length || candidate.totalBytes !== files.reduce((sum, file) => sum + file.bytes, 0) || candidate.rootDigest !== rootDigest(files)) {
    throw new Error("artifact registry backup manifest is invalid");
  }
  return candidate as ArtifactRegistryBackupManifest;
}

function receipt(status: ArtifactRegistryBackupReceipt["status"], manifest: ArtifactRegistryBackupManifest): ArtifactRegistryBackupReceipt {
  return {
    schema: "infuse.artifact-registry-backup-receipt/v1",
    status,
    rootDigest: manifest.rootDigest,
    reconciliationDigest: manifest.sourceReconciliationDigest,
    fileCount: manifest.fileCount,
    totalBytes: manifest.totalBytes,
  };
}

export async function createArtifactRegistryBackup(input: {
  sourceRoot: string;
  backupPath: string;
  createdAt?: string;
}): Promise<ArtifactRegistryBackupReceipt> {
  if (inside(input.sourceRoot, input.backupPath) || inside(input.backupPath, input.sourceRoot)) {
    throw new Error("artifact registry backup must be stored outside the source root");
  }
  if (await stat(input.backupPath).then(() => true).catch(() => false)) throw new Error("artifact registry backup destination already exists");
  await validateSourceRoot(input.sourceRoot);
  const reconciliation = await reconcileArtifactRegistry(input.sourceRoot);
  if (reconciliation.status !== "healthy" || reconciliation.summary.truncated) {
    throw new Error("artifact registry backup requires a healthy quiesced source");
  }
  const files = await canonicalInventory(input.sourceRoot);
  const createdAt = input.createdAt ?? new Date().toISOString();
  if (!Number.isFinite(Date.parse(createdAt))) throw new Error("artifact registry backup timestamp is invalid");
  const manifest: ArtifactRegistryBackupManifest = {
    schema: SCHEMA,
    createdAt,
    consistency: "offline-quiesced",
    sourceReconciliationDigest: reconciliation.reportDigest,
    rootDigest: rootDigest(files),
    fileCount: files.length,
    totalBytes: files.reduce((sum, file) => sum + file.bytes, 0),
    files,
  };
  const staging = `${input.backupPath}.${process.pid}.${randomUUID()}.tmp`;
  try {
    await mkdir(path.join(staging, "payload"), { recursive: true, mode: 0o700 });
    await copyInventory(input.sourceRoot, path.join(staging, "payload"), files);
    await writeFile(path.join(staging, "backup-manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o600, flag: "wx" });
    await rename(staging, input.backupPath);
  } catch (error) {
    await rm(staging, { recursive: true, force: true });
    throw error;
  }
  await verifyArtifactRegistryBackup(input.backupPath);
  return receipt("created", manifest);
}

export async function verifyArtifactRegistryBackup(backupPath: string): Promise<ArtifactRegistryBackupReceipt> {
  let manifest: ArtifactRegistryBackupManifest;
  try {
    manifest = normalizeManifest(JSON.parse(await readFile(path.join(backupPath, "backup-manifest.json"), "utf8")));
  } catch {
    throw new Error("artifact registry backup verification failed");
  }
  const actualFiles = await inventory(path.join(backupPath, "payload")).catch(() => []);
  if (actualFiles.length !== manifest.files.length || actualFiles.some((file, index) => {
    const expected = manifest.files[index];
    return !expected || file.path !== expected.path || file.bytes !== expected.bytes || file.sha256 !== expected.sha256;
  })) {
    throw new Error("artifact registry backup verification failed");
  }
  return receipt("verified", manifest);
}

export async function restoreArtifactRegistryBackup(input: {
  backupPath: string;
  destinationRoot: string;
}): Promise<ArtifactRegistryBackupReceipt> {
  if (inside(input.backupPath, input.destinationRoot) || inside(input.destinationRoot, input.backupPath)) {
    throw new Error("artifact registry restore target must be separate from the backup");
  }
  const verified = await verifyArtifactRegistryBackup(input.backupPath);
  const manifest = normalizeManifest(JSON.parse(await readFile(path.join(input.backupPath, "backup-manifest.json"), "utf8")));
  await mkdir(input.destinationRoot, { recursive: true, mode: 0o700 });
  if ((await entries(input.destinationRoot)).length > 0) throw new Error("artifact registry restore target must be empty");
  const stagingName = `.restore-${randomUUID()}`;
  const staging = path.join(input.destinationRoot, stagingName);
  try {
    await mkdir(staging, { recursive: true, mode: 0o700 });
    await copyInventory(path.join(input.backupPath, "payload"), staging, manifest.files);
    const stagedFiles = await canonicalInventory(staging);
    if (rootDigest(stagedFiles) !== manifest.rootDigest) throw new Error("artifact registry restore verification failed");
    const stagedReconciliation = await reconcileArtifactRegistry(staging);
    if (stagedReconciliation.status !== "healthy" || stagedReconciliation.reportDigest !== manifest.sourceReconciliationDigest) {
      throw new Error("artifact registry restore reconciliation failed");
    }
    for (const canonicalRoot of CANONICAL_ROOTS) {
      const source = path.join(staging, canonicalRoot);
      if (await lstat(source).then(() => true).catch(() => false)) await rename(source, path.join(input.destinationRoot, canonicalRoot));
    }
    await rm(staging, { recursive: true, force: true });
  } catch (error) {
    await rm(staging, { recursive: true, force: true });
    throw error;
  }
  const restoredFiles = await canonicalInventory(input.destinationRoot);
  const restoredReconciliation = await reconcileArtifactRegistry(input.destinationRoot);
  if (rootDigest(restoredFiles) !== manifest.rootDigest || restoredReconciliation.status !== "healthy" || restoredReconciliation.reportDigest !== manifest.sourceReconciliationDigest) {
    throw new Error("artifact registry restore verification failed");
  }
  return { ...verified, status: "restored" };
}
