import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdtemp,writeFile,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import test from 'node:test';
import type {ImageStorage} from '../dist/image-storage.js';
import {createArtifactRegistryServer} from '../dist/http.js';
import {ArtifactRegistry} from '../dist/registry.js';
import {reconcileArtifactRegistry} from '../dist/reconcile.js';

test('image-only project principal cannot publish arbitrary bundles; remote bytes, retries and interrupted purge retain ownership',async t=>{
 const root=await mkdtemp(join(tmpdir(),'registry-image-contract-'));t.after(()=>rm(root,{recursive:true,force:true}));
 const objects=new Map<string,Buffer>();let failPurge=false;
 const storage:ImageStorage={prepare:async(_project,_id,bytes)=>({bytes,width:300,height:200}),put:async(p,id,r,h,b)=>{objects.set([p,id,r,h].join('/'),b);},get:async(p,id,r,h)=>{const b=objects.get([p,id,r,h].join('/'));if(!b)throw Error('missing');return b;},purge:async(p,id)=>{if(failPurge)throw Error('offline');for(const key of objects.keys())if(key.startsWith(p+'/'+id+'/'))objects.delete(key);}};
 const token='synthetic-image-contract-0123456789abcdef',normal='synthetic-normal-contract-0123456789abcdef';const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
 const authPath=join(root,'auth.json');await writeFile(authPath,JSON.stringify({schema:'infuse.artifact-auth/v1',principals:{[hash(token)]:{subject:'studio',producer:'studio-whiteboard',project:'studio',scopes:['image-upload']},[hash(normal)]:{subject:'producer',producer:'studio-whiteboard',scopes:['write']}}}));
 const server=createArtifactRegistryServer({root,authPath,images:storage,audit:()=>{}});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise<void>(r=>server.close(()=>r())));
 const origin='http://127.0.0.1:'+(server.address() as {port:number}).port;
 const post=(path:string,body:unknown,key=token)=>fetch(origin+path,{method:'POST',headers:{authorization:'Bearer '+key,'content-type':'application/json'},body:JSON.stringify(body)});
 const upload={project:'studio',artifactId:'image',contentBase64:Buffer.from('synthetic decoded raster').toString('base64')};
 assert.equal((await post('/v1/artifacts',{})).status,403);
 assert.equal((await post('/v1/images',{...upload,project:'other'})).status,400);
 assert.equal((await post('/v1/images',{...upload,artifactId:undefined})).status,400);
 assert.equal((await post('/v1/images',upload,normal)).status,403);
 assert.equal((await post('/v1/artifacts',{producer:'studio-whiteboard',kind:'whiteboard-image'},normal)).status,403);
 const first=await post('/v1/images',upload);assert.equal(first.status,201);const {manifest:m}=await first.json();
 assert.equal((await post('/v1/images',upload)).status,200);assert.equal(objects.size,1);
 const registry=new ArtifactRegistry(root,storage);assert.equal((await reconcileArtifactRegistry(root,storage)).status,'healthy');
 await assert.rejects(readFile(join(root,'objects',m.producer,m.artifactId,'revisions',m.revision,'files','image.webp')));
 const body=await registry.content(m.producer,m.artifactId,m.revision,'image.webp');assert.equal(body!.body.toString(),'synthetic decoded raster');
 await registry.lifecycle(m.producer,m.artifactId,m.revision,'trash');failPurge=true;await assert.rejects(registry.lifecycle(m.producer,m.artifactId,m.revision,'purge'));assert.equal(objects.size,1);
 assert.equal((await registry.list('bin')).length,1);failPurge=false;
 await registry.lifecycle(m.producer,m.artifactId,m.revision,'purge');assert.equal(objects.size,0);assert.equal((await post('/v1/images',upload)).status,409);
});

test('dedicated Studio floor publisher accepts new floor IDs but grants no other Registry capabilities',async t=>{
 const root=await mkdtemp(join(tmpdir(),'registry-floor-images-'));t.after(()=>rm(root,{recursive:true,force:true}));
 const objects=new Map<string,Buffer>();
 const storage:ImageStorage={prepare:async(_p,_id,b)=>({bytes:b,width:1,height:1}),put:async(p,id,r,h,b)=>{objects.set([p,id,r,h].join('/'),b);},get:async()=>Buffer.from('image'),purge:async()=>{}};
 const token='synthetic-floor-publisher-0123456789abcdef',digest=createHash('sha256').update(token).digest('hex');
 const authPath=join(root,'auth.json');const principal={subject:'Studio floors',producer:'studio-whiteboard',studioFloors:true,scopes:['image-upload']};
 const save=async(value:unknown)=>writeFile(authPath,JSON.stringify({schema:'infuse.artifact-auth/v1',principals:{[digest]:value}}));await save(principal);
 const server=createArtifactRegistryServer({root,authPath,images:storage,audit:()=>{}});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise<void>(r=>server.close(()=>r())));
 const origin='http://127.0.0.1:'+(server.address() as {port:number}).port;
 const post=(path:string,body:unknown)=>fetch(origin+path,{method:'POST',headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify(body)});
 for(const project of ['core','finaxis','new-floor']) assert.equal((await post('/v1/images',{project,artifactId:'image-'+project,contentBase64:Buffer.from('raster').toString('base64')})).status,201);
 assert.equal(objects.size,3);
 assert.equal((await post('/v1/images',{project:'../studio',artifactId:'bad',contentBase64:'eA=='})).status,400);
 assert.equal((await post('/v1/artifacts',{})).status,403);
 assert.equal((await fetch(origin+'/v1/artifacts',{headers:{authorization:'Bearer '+token}})).status,403);
 await save({...principal,producer:'another-producer'});assert.equal((await post('/v1/images',{})).status,503);
 await save({...principal,scopes:['image-upload','write']});assert.equal((await post('/v1/images',{})).status,503);
});

test('floor image buckets preserve existing object keys and isolate future floors by project prefix',async()=>{
 const {S3ImageStorage,parseImageStorageConfig}=await import('../dist/image-storage.js');
 const config=parseImageStorageConfig({endpoint:'http://objects.core.svc',region:'us-east-1',credentialsFile:'/unused-fixture',projects:{studio:{intake:'studio-intake',trusted:'studio-trusted'}},floorFallbackProject:'studio',scanner:{host:'scanner.core.svc',port:3310}});
 const storage=new S3ImageStorage(config),keys:string[]=[];
 (storage as unknown as {client:{send:(command:{input:{Key:string}})=>Promise<unknown>}}).client={send:async command=>{keys.push(command.input.Key);return {ContentLength:1,Body:(async function*(){yield Buffer.from('x');})()};}};
 for(const project of ['studio','core','finaxis'])await storage.get(project,'studio-whiteboard/same-image','revision','digest');
 assert.equal(keys[0],createHash('sha256').update('studio-whiteboard/same-image').digest('hex')+'/revision/digest');
 assert.equal(new Set(keys).size,3);assert.ok(keys[1].startsWith('floors/'));
 assert.throws(()=>parseImageStorageConfig({...config,floorFallbackProject:'missing'}));
});
