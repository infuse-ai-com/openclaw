import {randomUUID} from 'node:crypto';
import type {HealthEpisode} from '@studio/contracts';
import type {MissionStore} from '../../persistence/missions/store.js';
import type {OperationJob} from '../../persistence/missions/operations.js';
import type {HealthEmission,StoredCheck,StoredDelivery} from '../../persistence/missions/monitoring.js';
import {healthDefinition,type MonitoringConfig,type HealthCheckConfig,type HealthCheckDefinition} from './monitoring-config.js';
import {runProbe,type ProbeResult} from './health-probes.js';
import {healthAlertPayload,healthWebhookUrl,sendHealthAlert,type HealthSendOutcome,type HealthAlertPayload} from './health-alert.js';
export function monitoringEmission(config:MonitoringConfig):HealthEmission {
 const d=config.delivery,live=config.enabled&&d.mode==='live'&&!!d.ownership&&Date.parse(d.ownership.backofficeGrantRevokedAt)<=Date.now();
 return {mode:live?'live':'shadow',destinationId:d.destinationId,epoch:live?d.ownership!.epoch:''};
}
export interface MonitoringControllerOptions {
 probe?:(check:HealthCheckConfig,signal:AbortSignal)=>Promise<ProbeResult>;
 send?:(payload:HealthAlertPayload,signal:AbortSignal)=>Promise<HealthSendOutcome>;
}
/** Probing and delivery each have a serial bounded loop. Slow targets never block alert delivery or the writer. */
export class MonitoringController {
 private owner=randomUUID();private timer?:ReturnType<typeof setInterval>;private probing?:Promise<void>;private delivering?:Promise<void>;
 private probeAbort?:AbortController;private sendAbort?:AbortController;private stopping=false;
 constructor(private store:MissionStore,private readConfig:()=>MonitoringConfig|undefined,private options:MonitoringControllerOptions={}){}
 start():void {
  if(this.timer)return;this.stopping=false;this.timer=setInterval(()=>{void this.tick().catch(()=>{});},1000);this.timer.unref();void this.tick().catch(()=>{});
 }
 async stop():Promise<void> {
  this.stopping=true;if(this.timer)clearInterval(this.timer);this.timer=undefined;this.probeAbort?.abort();this.sendAbort?.abort();
  await Promise.allSettled([this.probing,this.delivering]);
 }
 async tick():Promise<void> {
  if(this.stopping)return;
  if(!this.probing)this.probing=this.probeOne().finally(()=>{this.probing=undefined;});
  if(!this.delivering)this.delivering=this.deliverOne().finally(()=>{this.delivering=undefined;});
  const results=await Promise.allSettled([this.probing,this.delivering]);const failed=results.find(r=>r.status==='rejected');if(failed?.status==='rejected')throw failed.reason;
 }
 private guard(check:HealthCheckConfig,config:MonitoringConfig):()=>void {
  const fingerprint=JSON.stringify([check,config.delivery]);
  return ()=>{const current=this.readConfig();if(this.stopping||!current?.enabled||JSON.stringify([current.checks.find(c=>c.id===check.id),current.delivery])!==fingerprint)throw Object.assign(Error('Monitoring source ownership changed'),{code:'AUTHORITY_REVOKED'});};
 }
 private async probeOne():Promise<void> {
  const config=this.readConfig();if(!config?.enabled)return;
  const candidates=config.checks.filter(c=>c.enabled);if(!candidates.length)return;
  const snapshot=JSON.stringify(config),guard=()=>{if(this.stopping||JSON.stringify(this.readConfig())!==snapshot)throw Object.assign(Error('Monitoring admission changed'),{code:'AUTHORITY_REVOKED'});};
  const inventory=await this.store.monitoring<(StoredCheck|null)[]>({kind:'inventory',checks:candidates.map(healthDefinition)},guard),now=Date.now();
  const due=candidates.map((check,i)=>({check,next:inventory[i]?.definition.specDigest===check.specDigest?inventory[i]?.nextProbeAt??0:0})).filter(c=>c.next<=now).sort((a,b)=>a.next-b.next||a.check.id.localeCompare(b.check.id))[0];
  if(!due)return;
  const admission=this.guard(due.check,config),id='monitoring-probes';
  const current=await this.store.operations<OperationJob|null>({kind:'get',id},admission);
  if(current?.state==='running'&&(current.leaseUntil??0)>now||current?.nextRunAt&&current.nextRunAt>now)return;
  const running:OperationJob={id,kind:'health-probes',source:'studio-monitoring',revision:(current?.revision??0)+1,state:'running',checkpoint:{checkId:due.check.id},updatedAt:new Date(now).toISOString(),leaseOwner:this.owner,leaseUntil:now+300000};
  await this.store.operations({kind:'save',expectedRevision:current?.revision??0,job:running},admission);
  this.probeAbort=new AbortController();
  const progress=(success:boolean)=>({expectedRevision:running.revision,job:{...running,revision:running.revision+1,state:success?'succeeded' as const:'failed' as const,updatedAt:new Date().toISOString(),leaseUntil:undefined,nextRunAt:Date.now()+250,checkpoint:{checkId:due.check.id,...(success?{lastSuccessAt:new Date().toISOString()}:{})},...(success?{}:{lastError:'COLLECTOR_COMMIT_FAILED'})}});
  try {
   const result=await (this.options.probe??((c,signal)=>runProbe(c.probe,{signal,retries:c.retries,retryDelayMs:c.retryDelayMs})))(due.check,this.probeAbort.signal);
   admission();await this.store.monitoring({kind:'record',check:healthDefinition(due.check),observation:{id:randomUUID(),checkId:due.check.id,specDigest:due.check.specDigest,...result,source:'probe'},emission:monitoringEmission(config),progress:progress(true)},admission);
  } catch(error) {
   admission();await this.store.monitoring({kind:'failure',check:healthDefinition(due.check),progress:progress(false)},admission);throw error;
  } finally{this.probeAbort=undefined;}
 }
 private async deliverOne():Promise<void> {
  const config=this.readConfig();if(!config?.enabled)return;const emission=monitoringEmission(config);if(emission.mode!=='live')return;
  const snapshot=JSON.stringify(config),guard=()=>{if(this.stopping||JSON.stringify(this.readConfig())!==snapshot||monitoringEmission(config).mode!=='live')throw Object.assign(Error('Alert emission ownership changed'),{code:'AUTHORITY_REVOKED'});};
  const item=await this.store.monitoring<{delivery:StoredDelivery;episode:HealthEpisode;check:HealthCheckDefinition}|null>({kind:'queue',checks:config.checks.map(healthDefinition),emission},guard);if(!item)return;
  // Resolve protected configuration before marking a send in flight. No URL is stored or returned.
  const url=this.options.send?undefined:healthWebhookUrl(process.env[config.delivery.webhookEnv!]);
  const sending=await this.store.monitoring<StoredDelivery>({kind:'claim',check:item.check,emission,id:item.delivery.id,revision:item.delivery.revision,owner:this.owner},guard);
  this.sendAbort=new AbortController();let result:HealthSendOutcome;
  try {
   guard();result=await (this.options.send??((payload,signal)=>sendHealthAlert(url!,payload,signal)))(healthAlertPayload(item.check,item.episode,sending),this.sendAbort.signal);
  } catch {result={state:'uncertain',outcome:'TRANSPORT_UNCERTAIN'};}
  finally{this.sendAbort=undefined;}
  // Preserve a receipt even if ownership changed or shutdown began after POST admission.
  await this.store.monitoring({kind:'settle',id:sending.id,revision:sending.revision,owner:this.owner,state:result.state,outcome:result.outcome,retryAfterMs:result.retryAfterMs},()=>{});
 }
}
