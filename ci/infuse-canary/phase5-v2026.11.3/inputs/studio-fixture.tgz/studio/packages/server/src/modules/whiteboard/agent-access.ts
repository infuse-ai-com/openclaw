import { createHash } from 'node:crypto';
import { whiteboardAgentInvocation, whiteboardAgentPolicy, type BridgePrincipal,
  type WhiteboardAgentInvocation, type WhiteboardAgentPolicy } from '@studio/contracts';
import { requireMission } from '../missions/domain.js';
import type { WhiteboardGuard } from './service.js';

/**
 * Trusted adapter projection, NEVER request JSON. The standalone adapter derives
 * this from current enrollment, active floors and connected native routes.
 * Exporting this foundation does not install native admission.
 */
export interface WhiteboardAgentAdmission {
  authorityId: string;
  enrollment: BridgePrincipal;
  projectId: string;
  active: boolean;
  connectedAgents: Array<{ gatewayId: string; agentId: string }>;
  policy: WhiteboardAgentPolicy;
  managedExecutionEnabled?: boolean;
  companionExecutionEnabled?: boolean;
  companionMemberIds?: string[];
  assertInvocationCurrent(invocation: WhiteboardAgentInvocation): void;
}

/** Keep the same actor across runs, sessions and enrollment rotation, without ambiguous concatenation. */
export function whiteboardAgentActorId(authorityId: string, gatewayId: string, agentId: string): string {
  return `agent:${createHash('sha256').update(JSON.stringify([authorityId, gatewayId, agentId])).digest('hex')}`;
}

export function createWhiteboardAgentGuard(
  projectId: string, input: WhiteboardAgentInvocation, current: () => WhiteboardAgentAdmission,
): WhiteboardGuard {
  const invocation = Object.freeze(whiteboardAgentInvocation.parse(input));
  const first = current();
  const binding = { authorityId: first.authorityId, gatewayId: first.enrollment.gatewayId,
    generation: first.enrollment.generation };
  const actor = { kind: 'agent' as const,
    id: whiteboardAgentActorId(binding.authorityId, binding.gatewayId, invocation.agentId) };
  const guard = () => {
    const state = current(), policy = whiteboardAgentPolicy.safeParse(state.policy);
    requireMission(state.authorityId === binding.authorityId && state.enrollment.gatewayId === binding.gatewayId &&
      state.enrollment.generation === binding.generation, 'FORBIDDEN', 'Whiteboard enrollment changed');
    requireMission(state.active && state.projectId === projectId && state.enrollment.agents.includes(invocation.agentId) &&
      state.connectedAgents.some(agent => agent.gatewayId === binding.gatewayId && agent.agentId === invocation.agentId),
    'FORBIDDEN', 'Agent has no current access to this floor');
    requireMission(policy.success && policy.data.access !== 'disabled', 'FORBIDDEN', 'Agent whiteboard access is disabled');
    requireMission(typeof state.assertInvocationCurrent === 'function', 'FORBIDDEN', 'Current runtime custody is required');
    // The host checks invocation liveness here. The writer derives managed
    // origin and cancellation atomically from retained session/run custody.
    state.assertInvocationCurrent(invocation);
    return { projectId, actor, canWrite: policy.data.access === 'edit',
      nativeCustody: { gatewayId: binding.gatewayId, invocation, companionMemberIds:state.companionMemberIds, companionExecutionEnabled:state.companionExecutionEnabled===true, enrollmentGeneration:binding.generation, managedExecutionEnabled: state.managedExecutionEnabled === true } };
  };
  guard();
  return guard;
}
