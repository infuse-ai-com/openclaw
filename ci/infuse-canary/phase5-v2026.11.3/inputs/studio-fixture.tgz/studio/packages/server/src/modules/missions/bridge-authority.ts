import { parseBridgePrincipal, parseBridgeRequest, type BridgePrincipal, type BridgeResponse, type RuntimeTarget, type RuntimeExecutionTarget, type ConversationExecutionScope } from '@studio/contracts';
import { MissionStore } from '../../persistence/missions/store.js';
import { digest, MissionError, requireMission } from './domain.js';

export interface StudioBridgeAuthorityOptions {
  store: MissionStore;
  dispatchEnabled: boolean | (() => boolean);
  executionTargets?: () => RuntimeTarget[];
  executionEnrollment?: (gatewayId: string) => number | undefined;
  leaseMs?: number;
  admissionMs?: number;
  prepareConversation?: (scope: ConversationExecutionScope) => Promise<() => void>;
}
export class StudioBridgeAuthority {
  private readonly leaseMs: number;
  private readonly admissionMs: number;
  constructor(private readonly options: StudioBridgeAuthorityOptions) {
    this.leaseMs = options.leaseMs ?? 30_000; this.admissionMs = options.admissionMs ?? 5_000;
    for (const [value, maximum] of [[this.leaseMs, 120_000], [this.admissionMs, 10_000]])
      requireMission(Number.isSafeInteger(value) && value! >= 10 && value! <= maximum!, 'CONFIGURATION', 'Invalid bridge lifetime');
  }
  private enabled(): boolean { return typeof this.options.dispatchEnabled === 'function' ? this.options.dispatchEnabled() : this.options.dispatchEnabled; }
  async request(input: unknown, principalInput: BridgePrincipal, current: () => BridgePrincipal): Promise<BridgeResponse> {
    let request; let principal: BridgePrincipal;
    try { request = parseBridgeRequest(input); principal = parseBridgePrincipal(principalInput); }
    catch { throw new MissionError('INVALID_INPUT', 'Invalid Studio bridge request'); }
    requireMission(typeof current === 'function', 'FORBIDDEN', 'Live Gateway enrollment is required');
    const guard = () => {
      const live = parseBridgePrincipal(current());
      requireMission(live.gatewayId === principal.gatewayId && live.generation === principal.generation
        && JSON.stringify(live.agents) === JSON.stringify(principal.agents), 'FORBIDDEN', 'Gateway enrollment changed');
    };
    const executionGuard = (targets: RuntimeExecutionTarget[]) => {
      requireMission(this.enabled(), 'DISPATCH_DISABLED', 'Outbound dispatch is disabled');
      const allowed = this.options.executionTargets?.();
      if (allowed) for (const target of targets) requireMission(allowed.some(item => item.gatewayId === target.gatewayId && item.agentId === target.agentId),
        'CONFIGURATION', 'Execution target is no longer enrolled');
      for (const target of targets) if (target.enrollmentGeneration !== undefined) requireMission(
        this.options.executionEnrollment?.(target.gatewayId) === target.enrollmentGeneration, 'CONFIGURATION', 'Execution enrollment has changed');
    };
    guard();
    let conversationGuard: ((scope: ConversationExecutionScope) => void) | undefined;
    const dispatchId = request.op === 'admit' ? request.dispatchId
      : request.op === 'agent' && request.kind === 'conversation-reply' ? request.turn.dispatchId : undefined;
    if (dispatchId && this.options.prepareConversation) {
      const scope = await this.options.store.conversationScope(dispatchId, guard, principal);
      if (scope) {
        requireMission(this.options.prepareConversation, 'CONVERSATION_DISABLED', 'Live conversation admission is unavailable');
        const prepared = await this.options.prepareConversation(scope); guard();
        const identity = (value: ConversationExecutionScope) => digest({ binding: { id: value.binding.id, missionId: value.binding.missionId,
          installationId: value.binding.installationId, origin: value.binding.origin, botUserId: value.binding.botUserId,
          channelId: value.binding.channelId, rootPostId: value.binding.rootPostId }, response: { id: value.response.id,
          missionId: value.response.missionId, bindingId: value.response.bindingId, source: value.response.source,
          requestedBy: value.response.requestedBy, requestedAt: value.response.requestedAt,
          dispatchId: value.response.dispatchId, assignmentId: value.response.assignmentId } });
        const stamp = identity(scope);
        conversationGuard = next => { requireMission(identity(next) === stamp, 'CONVERSATION_CONFLICT', 'Prepared conversation scope changed'); prepared(); };
      }
    }
    const result = await this.options.store.bridge(request, principal, { dispatchEnabled: this.enabled(), leaseMs: this.leaseMs, admissionMs: this.admissionMs }, guard, executionGuard, conversationGuard);
    guard(); return result;
  }
}
