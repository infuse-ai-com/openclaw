import type { StorageDatabase } from './sql.js';
import { parseGitCommit, parseGitRepositoryIdentity, type UsageBucket } from '@studio/contracts';
import {
  importDigest,
  importPayloadSource,
  importPayloadRecords,
  type BackofficeImportPayload,
} from '../../modules/operations/backoffice-import-contract.js';
import { requireMission } from '../../modules/missions/domain.js';
export interface ImportPageVerification {
  sourceKey: string;
  expectedRecords: number;
  matchedRecords: number;
  supersededRecords: number;
  expiredRecords: number;
  missingRecords: number;
  mismatchedRecords: number;
  sourceMissing: boolean;
  verifiedAt: string;
}
/** Bounded supported reads within the sole worker. No mutation, raw source data or external calls. */
export async function verifyImportedPayload(
  db: StorageDatabase,
  p: BackofficeImportPayload,
  now: number,
): Promise<ImportPageVerification> {
  const r: ImportPageVerification = {
    sourceKey: importPayloadSource(p),
    expectedRecords: importPayloadRecords(p),
    matchedRecords: 0,
    supersededRecords: 0,
    expiredRecords: 0,
    missingRecords: 0,
    mismatchedRecords: 0,
    sourceMissing: false,
    verifiedAt: new Date(now).toISOString(),
  };
  const missingSource = () => {
    r.sourceMissing = true;
    r.missingRecords = r.expectedRecords;
    return r;
  };
  const same = (actual: unknown, expected: unknown) => {
    if (importDigest(actual) === importDigest(expected)) r.matchedRecords++;
    else r.mismatchedRecords++;
  };
  if (p.kind === 'agent') {
    const row = (await db
      .prepare('SELECT gateway_id,agent_id,kind,body FROM studio_agent_sources WHERE source_id=?')
      .get(p.input.sourceId));
    if (!row) return missingSource();
    requireMission(
      row.gateway_id === p.input.gatewayId &&
        row.agent_id === p.input.agentId &&
        row.kind === p.input.kind,
      'FORBIDDEN',
      'Imported agent binding changed',
    );
    const actual = JSON.parse(String(row.body));
    if (p.input.kind === 'usage')
      for (const bucket of p.input.data as UsageBucket[]) {
        if (Date.parse(bucket.start) < Math.floor(now / 86400000) * 86400000 - 6 * 86400000) {
          r.expiredRecords++;
          continue;
        }
        const stored = (await db
          .prepare(
            'SELECT generated_at,body FROM studio_agent_usage WHERE source_id=? AND start=? AND minutes=? AND provider=? AND model=?',
          )
          .get(p.input.sourceId, bucket.start, bucket.minutes, bucket.provider, bucket.model));
        if (!stored) r.missingRecords++;
        else if (String(stored.generated_at) > p.input.generatedAt) r.supersededRecords++;
        else if (String(stored.generated_at) !== p.input.generatedAt) r.mismatchedRecords++;
        else same(JSON.parse(String(stored.body)), bucket);
      }
    else if (typeof actual.generatedAt === 'string' && actual.generatedAt > p.input.generatedAt)
      r.supersededRecords++;
    else if (actual.generatedAt !== p.input.generatedAt) r.mismatchedRecords++;
    else
      same(
        [actual.sourceStatus, actual.data, actual.usageSummary ?? null],
        [p.input.sourceStatus, p.input.data, p.input.usageSummary ?? null],
      );
    return r;
  }
  if (p.kind === 'git') {
    const repository = (await db
      .prepare('SELECT body FROM studio_git_repositories WHERE source_id=?')
      .get(p.repository.sourceId));
    if (!repository) return missingSource();
    requireMission(
      importDigest(parseGitRepositoryIdentity(JSON.parse(String(repository.body)))) ===
        importDigest(parseGitRepositoryIdentity(p.repository)),
      'FORBIDDEN',
      'Imported repository binding changed',
    );
    for (const commit of p.commits) {
      const row = (await db
        .prepare('SELECT body FROM studio_git_commits WHERE source_id=? AND sha=?')
        .get(p.repository.sourceId, commit.sha));
      if (!row) {
        r.missingRecords++;
        continue;
      }
      const actual = parseGitCommit(JSON.parse(String(row.body)));
      if (actual.provenance === 'azure' || actual.provenance === 'gitlab') r.supersededRecords++;
      else same(actual, commit);
    }
    return r;
  }
  if (p.kind === 'health') {
    const row = (await db
      .prepare('SELECT resource_id FROM studio_health_checks WHERE check_id=?')
      .get(p.check.id));
    if (!row && p.observations.length) return missingSource();
    requireMission(
      !row || row.resource_id === p.check.resourceId,
      'FORBIDDEN',
      'Imported health resource changed',
    );
    for (const sample of p.observations) {
      if (Date.parse(sample.finishedAt) < now - 7 * 86400000) {
        r.expiredRecords++;
        continue;
      }
      const row = (await db
        .prepare('SELECT body FROM studio_health_observations WHERE check_id=? AND id=?')
        .get(p.check.id, sample.id));
      if (!row) r.missingRecords++;
      else same(JSON.parse(String(row.body)), sample);
    }
    return r;
  }
  if (p.kind === 'company') {
    const row = (await db
      .prepare('SELECT resource_id,kind,body FROM studio_company_sources WHERE source_id=?')
      .get(p.definition.sourceId));
    if (!row) return missingSource();
    requireMission(
      row.resource_id === p.definition.resourceId && row.kind === p.definition.kind,
      'FORBIDDEN',
      'Imported company resource changed',
    );
    const source = JSON.parse(String(row.body)),
      actual = source.input;
    if (!actual) {
      r.missingRecords++;
      return r;
    }
    if (actual.specDigest !== p.definition.specDigest) {
      r.mismatchedRecords++;
      return r;
    }
    const newer =
      (actual.generatedAt &&
        (p.input.generatedAt === null || actual.generatedAt > p.input.generatedAt)) ||
      (actual.generatedAt === null &&
        p.input.generatedAt === null &&
        actual.observedAt > p.input.observedAt);
    if (newer) r.supersededRecords++;
    else if (
      actual.generatedAt !== p.input.generatedAt ||
      (actual.generatedAt === null && actual.observedAt !== p.input.observedAt)
    )
      r.mismatchedRecords++;
    else same([actual.sourceStatus, actual.data], [p.input.sourceStatus, p.input.data]);
    return r;
  }
  const source = (await db
    .prepare('SELECT manifest_digest FROM studio_artifact_retained_sources WHERE source_id=?')
    .get(p.source.sourceId));
  if (!source) return missingSource();
  requireMission(
    source.manifest_digest === p.source.manifestDigest,
    'FORBIDDEN',
    'Retained artifact manifest changed',
  );
  for (const record of p.records) {
    const row = (await db
      .prepare(
        'SELECT body FROM studio_artifact_retained_records WHERE source_id=? AND kind=? AND record_id=?',
      )
      .get(p.source.sourceId, record.kind, record.recordId));
    if (!row) r.missingRecords++;
    else same(JSON.parse(String(row.body)), record);
  }
  return r;
}
