import { floorId, type FloorSetupSnapshot, type FloorSetupCheck } from '@studio/contracts';
import { MissionError } from '../missions/domain.js';
import type { FloorGuard } from './service.js';
import type { FloorManagementService } from './management.js';
import type { FloorSetupConfig } from './setup-config.js';
import { collectFloorSetup, setupIO, type SetupIO } from './setup-provider.js';
export class FloorSetupService {
  private cache = new Map<string, { at: number; result: Promise<FloorSetupCheck[]> }>();
  constructor(private management: FloorManagementService, private config: () => FloorSetupConfig | undefined,
    private team: (id: string) => 'ready' | 'connecting' | 'blocked' | 'unconfigured', private io: SetupIO = setupIO,
    private clock = () => Date.now()) {}
  async read(input: unknown, guard: FloorGuard): Promise<FloorSetupSnapshot> {
    const parsed = floorId.safeParse(input);
    if (!parsed.success) throw new MissionError('INVALID_INPUT', 'Invalid floor address');
    const id = parsed.data, principal = guard();
    const directory = this.management.list(guard), floor = directory.floors.find(f => f.id === id);
    if (!floor || floor.retiredAt) throw new MissionError('NOT_FOUND', 'Active floor unavailable');
    const expected = JSON.stringify(floor), config = this.config(), target = config?.floors.find(f => f.id === id);
    const key = JSON.stringify([id, config]), now = this.clock();
    let cached = this.cache.get(key);
    if (!cached || now - cached.at >= 30000) {
      if (this.cache.size >= 100) this.cache.clear();
      cached = { at: now, result: collectFloorSetup(config, target, this.io, now) }; this.cache.set(key, cached);
    }
    const [checks, catalog] = await Promise.all([cached.result, this.management.catalog(guard).catch(() => null)]);
    const current = guard();
    if (!current.canManage || JSON.stringify(current.actor) !== JSON.stringify(principal.actor)) throw new MissionError('FORBIDDEN', 'Floor management permission changed');
    if (JSON.stringify(this.management.list(guard).floors.find(f => f.id === id)) !== expected || JSON.stringify(this.config()) !== JSON.stringify(config))
      throw new MissionError('VERSION_CONFLICT', 'Floor setup changed. Refresh to check the saved configuration.');
    const at = new Date(this.clock()).toISOString(), state = this.team(id);
    const team: FloorSetupCheck = { id: 'team', label: 'Team connection', target: floor.name, checkedAt: at,
      state: state === 'ready' ? 'verified' : state === 'connecting' ? 'pending' : state === 'blocked' ? 'blocked' : 'unconfigured',
      detail: state === 'ready' ? 'Agent routes and floor members are connected with mission protection in place.' : state === 'connecting' ? 'Studio is connecting channels, agents and floor members.' : state === 'blocked' ? 'The team connection needs an operator check. Missions are not ready yet.' : 'Automatic team connection is not configured.' };
    const sources = floor.legacyCore ? catalog ?? [] : floor.repositories;
    const knowledge: FloorSetupCheck[] = sources.map(source => {
      const repo = catalog?.find(r => r.id === source.id && r.slug === source.slug);
      return { id: `knowledge:${source.id}`, label: 'Knowledge indexing', target: repo?.displayName ?? source.slug, checkedAt: at,
        state: !repo ? 'unverified' : repo.state === 'ready' ? 'verified' : repo.state === 'failed' ? 'blocked' : 'pending',
        detail: !repo ? 'The selected source could not be checked.' : repo.state === 'ready' ? `${repo.documentCount} documents indexed. Meaning and later Git updates are separate checks.` : repo.state === 'failed' ? 'Indexing failed. Open Repositories to inspect the source.' : repo.state === 'stale' ? 'The source index needs an update.' : 'The source is waiting for indexing to finish.',
        href: `/knowledge?${new URLSearchParams({project:id,repo:source.slug})}` };
    });
    if (!sources.length) knowledge.push({id:'knowledge',label:'Knowledge indexing',target:'No sources selected',state:catalog ? 'unconfigured' : 'unverified',detail:catalog ? 'Choose the repositories this floor should use.' : 'The repository catalog could not be checked.',checkedAt:catalog ? null : at});
    return { floorId: id, observedAt: at, checks: [team, ...checks, ...knowledge] };
  }
}
