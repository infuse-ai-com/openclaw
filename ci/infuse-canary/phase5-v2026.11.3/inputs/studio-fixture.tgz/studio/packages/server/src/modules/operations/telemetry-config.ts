import { isAbsolute } from 'node:path';
import { missionIdentifier, telemetryKinds, telemetryObject as obj, telemetryString as text, type TelemetryKind, type RuntimeTarget } from '@studio/contracts';
import type { AgentFeedMapping } from './agent-feeds.js';
export type TelemetryTransport={type:'retained'}|{type:'file';path:string}|{type:'config-map';namespace:string;name:string;key:string}|{type:'runtime';namespace:string;deployment:string};
export interface AgentTelemetrySourceConfig extends AgentFeedMapping { intervalMs:number; staleAfterMs:number; transport:TelemetryTransport }
export interface ObservedAgent extends RuntimeTarget { floorIds:string[] }
export interface AgentTelemetryConfig { observedAgents?:ObservedAgent[]; enabled:boolean; sources:AgentTelemetrySourceConfig[]; cluster?:{origin:string;tokenFile:string;caFile:string} }
function keys(v:Record<string,unknown>,allowed:string[]):void{if(Object.keys(v).some(k=>!allowed.includes(k)))throw Error('Unknown telemetry configuration field');}
function path(v:unknown):string{const s=text(v,4096);if(!isAbsolute(s))throw Error('Telemetry source paths must be absolute');return s;}
function dns(v:unknown):string{const s=text(v,253);if(!/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/.test(s))throw Error('Invalid Kubernetes resource name');return s;}
export function parseAgentTelemetryConfig(value:unknown,targets:RuntimeTarget[]):AgentTelemetryConfig {
  const root=obj(value);keys(root,['enabled','sources','cluster','observedAgents']);
  if(typeof root.enabled!=='boolean'||!Array.isArray(root.sources)||root.sources.length>100)throw Error('Invalid telemetry configuration');
  if(root.observedAgents!==undefined&&(!Array.isArray(root.observedAgents)||root.observedAgents.length>100))throw Error('Invalid observed agents');
  const observedAgents=((root.observedAgents??[]) as unknown[]).map(raw=>{
    const a=obj(raw);keys(a,['gatewayId','agentId','floorIds']);
    const target={gatewayId:missionIdentifier(a.gatewayId),agentId:missionIdentifier(a.agentId)};
    if(targets.some(t=>t.gatewayId===target.gatewayId&&t.agentId===target.agentId))throw Error('Observed agents must be separate from execution targets');
    if(!Array.isArray(a.floorIds)||!a.floorIds.length||a.floorIds.length>100)throw Error('Observed agents require explicit floor admission');
    const floorIds=a.floorIds.map(missionIdentifier);if(new Set(floorIds).size!==floorIds.length)throw Error('Duplicate observed agent floor');
    return {...target,floorIds};
  });
  if(new Set(observedAgents.map(a=>JSON.stringify([a.gatewayId,a.agentId]))).size!==observedAgents.length)throw Error('Duplicate observed agent');
  const telemetryTargets=[...targets,...observedAgents];
  const sources=root.sources.map(raw=>{
    const s=obj(raw);keys(s,['sourceId','gatewayId','agentId','kind','feedAgentId','gatewayLabel','intervalMs','staleAfterMs','transport']);
    if(!telemetryKinds.includes(s.kind as TelemetryKind))throw Error('Unknown telemetry kind');
    const gatewayId=missionIdentifier(s.gatewayId),agentId=missionIdentifier(s.agentId),kind=s.kind as TelemetryKind;
    if(!telemetryTargets.some(t=>t.gatewayId===gatewayId&&t.agentId===agentId))throw Error('Telemetry requires an explicit execution or observation mapping');
    const intervalMs=s.intervalMs??300000,staleAfterMs=s.staleAfterMs??10800000;
    if(typeof intervalMs!=='number'||!Number.isSafeInteger(intervalMs)||intervalMs<30000||intervalMs>3600000
      ||typeof staleAfterMs!=='number'||!Number.isSafeInteger(staleAfterMs)||staleAfterMs<intervalMs||staleAfterMs>86400000)throw Error('Invalid telemetry schedule');
    const transport=obj(s.transport);let parsed:TelemetryTransport;
    if(transport.type==='retained'){keys(transport,['type']);if(kind!=='usage')throw Error('Retained source is usage-only');parsed={type:'retained'};}
    else if(transport.type==='file'){keys(transport,['type','path']);if(kind==='runtime')throw Error('Runtime observations require Kubernetes reads');parsed={type:'file',path:path(transport.path)};}
    else if(transport.type==='config-map'){keys(transport,['type','namespace','name','key']);if(kind==='runtime')throw Error('Wrong runtime transport');parsed={type:'config-map',namespace:dns(transport.namespace),name:dns(transport.name),key:text(transport.key,256)};}
    else if(transport.type==='runtime'){keys(transport,['type','namespace','deployment']);if(kind!=='runtime')throw Error('Wrong feed transport');parsed={type:'runtime',namespace:dns(transport.namespace),deployment:dns(transport.deployment)};}
    else throw Error('Unsupported telemetry transport');
    return {sourceId:missionIdentifier(s.sourceId),gatewayId,agentId,kind,feedAgentId:text(s.feedAgentId),gatewayLabel:text(s.gatewayLabel),intervalMs,staleAfterMs,transport:parsed};
  });
  if(new Set(sources.map(s=>s.sourceId)).size!==sources.length)throw Error('Duplicate telemetry source');
  // A session export has no Gateway field. Its configured transport must belong to exactly one Gateway.
  const sessions=new Map<string,string>();for(const s of sources.filter(s=>s.kind==='collectors')){const key=JSON.stringify(s.transport);if(sessions.has(key)&&sessions.get(key)!==s.gatewayId)throw Error('Ambiguous Gateway for session feed');sessions.set(key,s.gatewayId);}
  let cluster:AgentTelemetryConfig['cluster'];
  if(root.cluster!==undefined){const c=obj(root.cluster);keys(c,['origin','tokenFile','caFile']);const u=new URL(text(c.origin,2048));
    if(u.protocol!=='https:'||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('Kubernetes requires an explicit HTTPS origin');
    cluster={origin:u.origin,tokenFile:path(c.tokenFile),caFile:path(c.caFile)};}
  if(sources.some(s=>!['file','retained'].includes(s.transport.type))&&!cluster)throw Error('Kubernetes telemetry requires explicit cluster and credential files');
  return {enabled:root.enabled,sources,...(observedAgents.length?{observedAgents}:{}),...(cluster?{cluster}:{})};
}
