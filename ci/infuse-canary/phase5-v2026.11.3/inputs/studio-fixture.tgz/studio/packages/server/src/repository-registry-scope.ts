import type { FloorDirectoryPort } from './modules/floors/management.js';
import { policyEnabled, type PolicyConsumer } from '@studio/contracts';
import { configuredRegistryClient } from './repository-registry-policy-client.js';
import { MissionError } from './modules/missions/domain.js';

/** One association resolver for provider reads. Membership is checked by the existing caller guard. */
export async function registryFloorSelection(path: string, consumer: Extract<PolicyConsumer, 'documentation' | 'code'>,
  floorId: string, floors: FloorDirectoryPort, actorGuard: () => void) {
  actorGuard();
  const record = floors.record(floorId);
  if (!record || record.retiredAt) throw new MissionError('STATE_CONFLICT', 'This floor has not transferred its repository association.');
  const fingerprint = JSON.stringify(record);
  const client = await configuredRegistryClient(path, consumer);
  const snapshot = await client.snapshot();
  const repositories = record.repositories.flatMap(binding => {
    const row = snapshot.policy.repositories.find(r => r.id === binding.id && r.slug === binding.slug);
    if (!row) throw new MissionError('STATE_CONFLICT', 'The floor refers to an unknown registry repository.');
    return policyEnabled(row, consumer) ? [{ id: row.id, slug: row.slug }] : [];
  });
  const deadline = performance.now() + 15000;
  const guard = () => {
    actorGuard(); snapshot.guard();
    if (performance.now() >= deadline || JSON.stringify(floors.record(floorId)) !== fingerprint)
      throw new MissionError('AUTHORITY_REVOKED', 'The floor repository scope changed.');
  };
  guard();
  return { repositories, client, floor: { id: floorId, revision: record.revision },
    registry: { epoch: snapshot.policy.epoch, revision: snapshot.policy.revision }, guard };
}
