import {boundedOperationsFile as boundedFile,readOperationsKubernetes as kube,readOperationsDeployment} from './source-io.js';
import { createHash, randomUUID } from 'node:crypto';
import { telemetryObject as obj, type TelemetryInput } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
import type { OperationJob, JobKind } from '../../persistence/missions/operations.js';
import type { AgentTelemetryConfig, AgentTelemetrySourceConfig } from './telemetry-config.js';
import { decodeAgentFeed, decodeRuntime } from './agent-feeds.js';

export type AgentTelemetryReader=(source:AgentTelemetrySourceConfig,config:AgentTelemetryConfig,signal:AbortSignal)=>Promise<TelemetryInput>;
function decoded<T>(read:()=>T):T {try{return read();}catch{throw Object.assign(Error('Invalid sanitized feed'),{code:'SOURCE_INVALID'});}}
export const readAgentTelemetrySource:AgentTelemetryReader=async(source,config,signal)=>{
  const t=source.transport,at=new Date().toISOString();
  try{
    if(t.type==='retained')throw Error('Retained sources are import-only');
    if(t.type==='file'){const raw=JSON.parse(await boundedFile(t.path,1048576,signal));return decoded(()=>decodeAgentFeed(raw,source,at));}
    if(!config.cluster)throw Error('Kubernetes source is unconfigured');
    if(t.type==='config-map'){
      const response=await kube(config.cluster,`/api/v1/namespaces/${encodeURIComponent(t.namespace)}/configmaps/${encodeURIComponent(t.name)}`,signal);
      const data=decoded(()=>obj(obj(response).data));
      const body=data[t.key];if(typeof body!=='string')throw Object.assign(Error('Feed key missing'),{code:'ENOENT'});
      return decoded(()=>decodeAgentFeed(JSON.parse(body),source,at));
    }
    const {deployment,pods}=await readOperationsDeployment(config.cluster,t,signal);
    return decoded(()=>decodeRuntime(deployment,pods,source,new Date().toISOString()));
  }catch(error){
    if(error instanceof SyntaxError)throw Object.assign(Error('Invalid feed JSON'),{code:'SOURCE_INVALID'});
    // Decode errors never leak raw source material. The controller persists a fixed error code.
    throw error;
  }
};
const kinds:Record<AgentTelemetrySourceConfig['kind'],JobKind>={usage:'agent-usage',runtime:'agent-runtime',model:'agent-model',collectors:'agent-collectors',schedules:'agent-schedules'};
/** One bounded sequential collector. Durable leases/checkpoints share the mission worker, never another DB connection. */
export class AgentTelemetryCollector {
  private owner=randomUUID();private timer?:ReturnType<typeof setInterval>;private active?:Promise<void>;private abort?:AbortController;private stopping=false;
  constructor(private store:MissionStore,private readConfig:()=>AgentTelemetryConfig|undefined,private reader:AgentTelemetryReader=readAgentTelemetrySource){}
  start():void{if(this.timer)return;this.stopping=false;this.timer=setInterval(()=>{void this.tick().catch(()=>{});},1000);this.timer.unref();void this.tick().catch(()=>{});}
  async stop():Promise<void>{this.stopping=true;if(this.timer)clearInterval(this.timer);this.timer=undefined;this.abort?.abort();await this.active?.catch(()=>{});}
  tick():Promise<void>{if(this.active)return this.active;if(this.stopping)return Promise.resolve();this.active=this.collect().finally(()=>{this.active=undefined;});return this.active;}
  private async collect():Promise<void>{
    const config=this.readConfig();if(!config?.enabled)return;
    const sources=config.sources.filter(source=>source.transport.type!=='retained');if(!sources.length)return;
    const snapshot=JSON.stringify(config),inventoryGuard=()=>{if(this.stopping||JSON.stringify(this.readConfig())!==snapshot)throw Object.assign(Error('Telemetry inventory authority changed'),{code:'AUTHORITY_REVOKED'});};
    const ids=sources.map(source=>'telemetry-'+createHash('sha256').update(source.sourceId).digest('hex').slice(0,32));
    const jobs=await this.store.operations<(OperationJob|null)[]>({kind:'get-many',ids},inventoryGuard);
    for(const [index,source] of sources.entries()){
      const id=ids[index]!,current=jobs[index],now=Date.now();
      if((current?.nextRunAt??0)>now||current?.state==='running'&&(current.leaseUntil??0)>now)continue;
      if(this.stopping)return;
      const fingerprint=JSON.stringify([source,config.cluster]);
      const guard=()=>{const live=this.readConfig();if(this.stopping||!live?.enabled||JSON.stringify([live.sources.find(s=>s.sourceId===source.sourceId),live.cluster])!==fingerprint)throw Object.assign(Error('Telemetry authority changed'),{code:'AUTHORITY_REVOKED'});};
      guard();
      const running:OperationJob={id,kind:kinds[source.kind],source:source.sourceId,revision:(current?.revision??0)+1,state:'running',checkpoint:current?.checkpoint??{},updatedAt:new Date(now).toISOString(),leaseOwner:this.owner,leaseUntil:now+60000};
      try{await this.store.operations({kind:'save',expectedRevision:current?.revision??0,job:running},guard);}catch(error){if(['VERSION_CONFLICT','BUSY'].includes(String((error as {code?:string}).code)))continue;throw error;}
      this.abort=new AbortController();const timeout=setTimeout(()=>this.abort?.abort(),10000);timeout.unref();
      let input:TelemetryInput|undefined,state:'missing'|'invalid'|'unavailable'='unavailable';
      try{input=await this.reader(source,config,this.abort.signal);}
      catch(error){const code=(error as {code?:string}).code;state=code==='ENOENT'?'missing':code==='SOURCE_INVALID'||error instanceof SyntaxError?'invalid':'unavailable';}
      finally{clearTimeout(timeout);this.abort=undefined;}
      const finished=():OperationJob=>({...running,revision:running.revision+1,state:input?'succeeded':'failed',updatedAt:new Date().toISOString(),leaseUntil:undefined,nextRunAt:Date.now()+source.intervalMs,
        checkpoint:{...(running.checkpoint.lastSuccessAt?{lastSuccessAt:running.checkpoint.lastSuccessAt}:{}),...(input?{lastSuccessAt:new Date().toISOString(),generatedAt:input.generatedAt}:{})},...(input?{}:{lastError:`SOURCE_${state.toUpperCase()}`})});
      if(input){try{await this.store.agentTelemetry({kind:'ingest',input,job:{expectedRevision:running.revision,job:finished()}},guard);continue;}
        catch(error){if(!['INVALID_INPUT','IDEMPOTENCY_CONFLICT'].includes(String((error as {code?:string}).code)))throw error;input=undefined;state='invalid';}}
      await this.store.agentTelemetry({kind:'attempt',source:{sourceId:source.sourceId,kind:source.kind,gatewayId:source.gatewayId,agentId:source.agentId},state,job:{expectedRevision:running.revision,job:finished()}},guard);
    }
  }
}
