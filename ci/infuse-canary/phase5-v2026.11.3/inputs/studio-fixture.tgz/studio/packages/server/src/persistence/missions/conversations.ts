import { randomUUID } from 'node:crypto';
import type { StorageDatabase } from './sql.js';
import {
  missionIdentifier, parseConversationAuthor, parseConversationBind, parseConversationBinding, parseConversationComment,
  parseConversationDelivery, parseConversationPost, parseConversationRead, parseConversationRoute,
  type ConversationAuthor, type ConversationBindInput, type ConversationBinding, type ConversationCommentInput,
  type ConversationDelivery, type ConversationEvent, type ConversationPage, type ConversationPost, type ConversationReadInput,
  type ConversationRoute, type ConversationSyncError, type ConversationResponse, type Mission,
} from '@studio/contracts';
import { digest, requireMission } from '../../modules/missions/domain.js';

export interface ConversationHuman { profileId: string; label: string }
export type ConversationObservation = { state: 'delivered'; post: ConversationPost } | { state: 'uncertain' | 'failed'; reason: string };
export type ConversationOperation =
  | { kind: 'read'; input: ConversationReadInput }
  | { kind: 'bindings' }
  | { kind: 'bind'; input: ConversationBindInput; route: ConversationRoute; root: ConversationPost; actor: ConversationHuman }
  | { kind: 'ingest'; bindingId: string; route: ConversationRoute; posts: Array<{ post: ConversationPost; author: ConversationAuthor }> }
  | { kind: 'comment'; input: ConversationCommentInput; actor: ConversationHuman }
  | { kind: 'next'; bindingId: string; allowedAuthorProfileIds: string[] }
  | { kind: 'observe'; deliveryId: string; attemptId: string; result: ConversationObservation }
  | { kind: 'sync'; bindingId: string; error?: ConversationSyncError };

/** Executed only inside the mission worker's guarded transaction. No network or runtime effects. */
export class ConversationPersistence {
  constructor(private readonly db: StorageDatabase, private readonly mission: (id: string) => Promise<Mission | undefined>,
    private readonly responses: (missionId: string) => Promise<ConversationResponse[]> = async () => []) {}
  private async binding(id: string): Promise<ConversationBinding> {
    const row = (await this.db.prepare('SELECT body FROM conversation_bindings WHERE id=?').get(missionIdentifier(id)));
    requireMission(row, 'NOT_FOUND', 'Conversation binding not found'); return parseConversationBinding(JSON.parse(String(row.body)));
  }
  private async delivery(id: string): Promise<ConversationDelivery> {
    const row = (await this.db.prepare('SELECT body FROM conversation_deliveries WHERE id=?').get(missionIdentifier(id)));
    requireMission(row, 'NOT_FOUND', 'Conversation delivery not found'); return parseConversationDelivery(JSON.parse(String(row.body)));
  }
  private async saveDelivery(value: ConversationDelivery): Promise<ConversationDelivery> {
    (await this.db.prepare("INSERT INTO conversation_deliveries (id,binding_id,state,body) VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET state=excluded.state, body=excluded.body")
      .run(value.id, value.bindingId, value.state, JSON.stringify(value))); return value;
  }
  private async saveBinding(value: ConversationBinding): Promise<ConversationBinding> {
    (await this.db.prepare("INSERT INTO conversation_bindings (id,mission_id,body) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body")
      .run(value.id, value.missionId, JSON.stringify(value))); return value;
  }
  private human(actor: ConversationHuman): ConversationAuthor {
    return parseConversationAuthor({ kind: 'studio', id: actor.profileId, profileId: actor.profileId, label: actor.label });
  }
  private async requireMission(id: string) { requireMission((await this.mission(id)), 'NOT_FOUND', 'Mission not found'); }
  private async receipt<T>(kind: string, commandId: string, actor: ConversationHuman, input: unknown, perform: () => Promise<T>): Promise<T> {
    const id = digest([kind, actor.profileId, commandId]); const fingerprint = digest(input);
    const previous = (await this.db.prepare('SELECT digest,body FROM conversation_requests WHERE id=?').get(id));
    if (previous) {
      requireMission(previous.digest === fingerprint, 'IDEMPOTENCY_CONFLICT', 'This conversation request ID already refers to different content');
      return JSON.parse(String(previous.body)) as T;
    }
    const result = await perform();
    (await this.db.prepare("INSERT INTO conversation_requests (id,digest,body) VALUES (?,?,?)").run(id, fingerprint, JSON.stringify(result))); return result;
  }
  /** Restart never resends a request that might have reached Mattermost. */
  async recover(): Promise<void> {
    for (const row of (await this.db.prepare("SELECT body FROM conversation_deliveries WHERE state='sending'").all())) {
      const item = parseConversationDelivery(JSON.parse(String(row.body)));
      (await this.saveDelivery({ ...item, state: 'uncertain', reason: 'process-restarted-during-send', updatedAt: new Date().toISOString() }));
    }
  }
  private matchingPost(binding: ConversationBinding, delivery: ConversationDelivery, post: ConversationPost): boolean {
    return post.channelId === binding.channelId && post.rootId === binding.rootPostId && post.userId === binding.botUserId
      && post.deliveryId === delivery.id && post.message === delivery.message && post.deleteAt === 0;
  }
  private async reconcile(binding: ConversationBinding, item: ConversationDelivery, post: ConversationPost): Promise<ConversationDelivery> {
    requireMission(['sending', 'uncertain', 'delivered'].includes(item.state) && item.attemptId, 'CONVERSATION_CONFLICT', 'Delivery has no admitted send');
    // Once duplicate actual posts are observed, an incomplete later scan cannot clear ambiguity.
    if (item.reason === 'multiple-post-receipts') return item;
    if (item.postId && item.postId !== post.id) return (await this.saveDelivery({ ...item, state: 'uncertain', reason: 'multiple-post-receipts', updatedAt: new Date().toISOString() }));
    requireMission(this.matchingPost(binding, item, post), 'CONVERSATION_CONFLICT', 'Post receipt does not match the admitted delivery');
    const result = { ...item, state: 'delivered' as const, postId: post.id, updatedAt: new Date().toISOString() }; delete result.reason;
    return (await this.saveDelivery(result));
  }
  async execute(op: ConversationOperation): Promise<unknown> {
    switch (op.kind) {
      case 'read': {
        const input = parseConversationRead(op.input); (await this.requireMission(input.missionId));
        const bindings = (await this.db.prepare('SELECT body FROM conversation_bindings WHERE mission_id=?').all(input.missionId)).map(row => parseConversationBinding(JSON.parse(String(row.body))));
        const rows = (await this.db.prepare(`SELECT e.sequence,e.body FROM conversation_events e JOIN conversation_bindings b ON e.binding_id=b.id
          WHERE b.mission_id=? AND e.sequence<? ORDER BY e.sequence DESC LIMIT ?`).all(input.missionId, input.beforeSequence ?? Number.MAX_SAFE_INTEGER, input.limit! + 1));
        const more = rows.length > input.limit!; const page = rows.slice(0, input.limit!);
        const events = page.map(row => ({ ...JSON.parse(String(row.body)), sequence: Number(row.sequence) }) as ConversationEvent).reverse();
        const deliveries = (await this.db.prepare(`SELECT d.body FROM conversation_deliveries d JOIN conversation_bindings b ON d.binding_id=b.id
          WHERE b.mission_id=? ORDER BY (d.state IN ('delivered','failed')) ASC,d.rowid DESC LIMIT 100`).all(input.missionId)).map(row => parseConversationDelivery(JSON.parse(String(row.body)))).reverse();
        return { missionId: input.missionId, available: false, bindings, events, deliveries, responses: (await this.responses(input.missionId)),
          ...(more ? { nextBeforeSequence: Number(page.at(-1)!.sequence) } : {}) } satisfies ConversationPage;
      }
      case 'bindings': return (await this.db.prepare('SELECT body FROM conversation_bindings ORDER BY rowid LIMIT 100').all()).map(row => parseConversationBinding(JSON.parse(String(row.body))));
      case 'bind': {
        const input = parseConversationBind(op.input); const route = parseConversationRoute(op.route); const root = parseConversationPost(op.root); this.human(op.actor);
        (await this.requireMission(input.missionId));
        requireMission(root.id === input.rootPostId && root.rootId === '' && root.channelId === route.channelId && root.userId === route.botUserId && !root.deleteAt,
          'CONVERSATION_CONFLICT', 'Bind an existing live root authored by the configured Studio bot');
        return (await this.receipt('bind', input.commandId, op.actor, { input, route }, async () => {
          const id = digest([route.installationId, route.botUserId, route.channelId, root.id]);
          const existing = (await this.db.prepare('SELECT body FROM conversation_bindings WHERE id=? OR mission_id=?').all(id, input.missionId));
          if (existing.length) {
            requireMission(existing.length === 1, 'CONVERSATION_CONFLICT', 'Thread already belongs to another mission');
            const binding = parseConversationBinding(JSON.parse(String(existing[0]!.body)));
            requireMission(binding.id === id && binding.missionId === input.missionId && binding.origin === route.origin, 'CONVERSATION_CONFLICT', 'This mission or thread already has another binding');
            return binding;
          }
          requireMission(Number((await this.db.prepare('SELECT count(*) AS total FROM conversation_bindings').get())!.total) < 100, 'CONVERSATION_LIMIT', 'The configured conversation limit was reached');
          return (await this.saveBinding({ ...route, id, missionId: input.missionId, rootPostId: root.id, threadUrl: `${route.origin}/_redirect/pl/${root.id}`, createdAt: new Date().toISOString(), createdBy: op.actor.profileId }));
        }));
      }
      case 'comment': {
        const input = parseConversationComment(op.input); const author = this.human(op.actor); const binding = (await this.binding(input.bindingId));
        requireMission(binding.missionId === input.missionId, 'CONVERSATION_CONFLICT', 'Comment must target the bound mission');
        return (await this.receipt('comment', input.commandId, op.actor, input, async () => {
          requireMission(Number((await this.db.prepare("SELECT count(*) AS total FROM conversation_deliveries WHERE binding_id=? AND state IN ('pending','sending','uncertain')").get(binding.id))!.total) < 100,
            'CONVERSATION_LIMIT', 'Resolve outstanding conversation deliveries before adding more');
          const at = new Date().toISOString(); return (await this.saveDelivery({ id: digest(['comment', op.actor.profileId, input.commandId]), ...input, author,
            message: `${author.label} via Studio:\n\n${input.text}`, state: 'pending', createdAt: at, updatedAt: at }));
        }));
      }
      case 'next': {
        const binding = (await this.binding(op.bindingId));
        requireMission(Array.isArray(op.allowedAuthorProfileIds) && op.allowedAuthorProfileIds.length <= 1000, 'INVALID_INPUT', 'Current admitted authors are required');
        for (const row of (await this.db.prepare("SELECT body FROM conversation_deliveries WHERE binding_id=? AND state='pending' ORDER BY rowid LIMIT 100").all(binding.id))) {
          const item = parseConversationDelivery(JSON.parse(String(row.body)));
          const responseRow = item.author.kind === 'agent' ? (await this.db.prepare("SELECT body FROM conversation_responses WHERE binding_id=? AND jsonb_extract_path_text(studio_control_json(body),'reply','deliveryId')=?").get(binding.id, item.id)) : undefined;
          const response = responseRow ? JSON.parse(String(responseRow.body)) as ConversationResponse : undefined;
          const permitted = item.author.kind === 'agent' ? response?.reply?.deliveryId === item.id
            && op.allowedAuthorProfileIds.includes(response.requestedBy) && op.allowedAuthorProfileIds.includes(response.source.author.profileId!)
            : op.allowedAuthorProfileIds.includes(item.author.profileId!);
          if (!permitted) {
            (await this.saveDelivery({ ...item, state: 'failed', reason: 'author-revoked-before-send', updatedAt: new Date().toISOString() })); continue;
          }
          return (await this.saveDelivery({ ...item, state: 'sending', attemptId: randomUUID(), updatedAt: new Date().toISOString() }));
        }
        return null;
      }
      case 'observe': {
        const item = (await this.delivery(op.deliveryId)); const binding = (await this.binding(item.bindingId));
        requireMission(item.attemptId === missionIdentifier(op.attemptId), 'CONVERSATION_CONFLICT', 'Observation belongs to another send attempt');
        if (op.result.state === 'delivered') return (await this.reconcile(binding, item, parseConversationPost(op.result.post)));
        requireMission(['sending', 'uncertain'].includes(item.state) && ['uncertain', 'failed'].includes(op.result.state)
          && typeof op.result.reason === 'string' && /^[a-z][a-z0-9-]{0,127}$/.test(op.result.reason), 'CONVERSATION_CONFLICT', 'Invalid delivery observation');
        // A failed pre-send admission may be recorded only from the just-started effect.
        requireMission(op.result.state !== 'failed' || item.state === 'sending', 'CONVERSATION_CONFLICT', 'Uncertain delivery cannot become safe to resend');
        return (await this.saveDelivery({ ...item, state: op.result.state, reason: op.result.reason, updatedAt: new Date().toISOString() }));
      }
      case 'ingest': {
        const binding = (await this.binding(op.bindingId)); const route = parseConversationRoute(op.route);
        requireMission(Object.entries(route).every(([key, value]) => binding[key as keyof ConversationRoute] === value), 'CONVERSATION_CONFLICT', 'Conversation route changed');
        requireMission(Array.isArray(op.posts) && op.posts.length <= 1000, 'CONVERSATION_LIMIT', 'Conversation scan is too large');
        for (const raw of op.posts) {
          const post = parseConversationPost(raw.post); const author = parseConversationAuthor(raw.author);
          requireMission(author.id === post.userId && author.kind === 'mattermost', 'CONVERSATION_CONFLICT', 'Observed author does not match the authenticated post');
          requireMission(post.channelId === binding.channelId && (post.rootId === binding.rootPostId || post.id === binding.rootPostId && post.rootId === ''), 'CONVERSATION_CONFLICT', 'Observed post is outside the bound thread');
          if (post.userId === binding.botUserId) {
            if (!post.deliveryId) continue;
            const row = (await this.db.prepare('SELECT body FROM conversation_deliveries WHERE id=? AND binding_id=?').get(post.deliveryId, binding.id));
            if (!row) continue;
            const delivery = parseConversationDelivery(JSON.parse(String(row.body)));
            // A forged marker before admission cannot manufacture a send receipt.
            if (!delivery.attemptId || ['pending', 'failed'].includes(delivery.state)) continue;
            if (this.matchingPost(binding, delivery, post)) { (await this.reconcile(binding, delivery, post)); continue; }
            // Preserve the fact of delivery when its already-known post is edited/deleted.
            if (delivery.postId !== post.id) continue;
          }
          const revision = Math.max(post.createAt, post.updateAt, post.deleteAt); const fingerprint = digest(post);
          const old = (await this.db.prepare('SELECT digest FROM conversation_events WHERE binding_id=? AND post_id=? AND source_revision=?').get(binding.id, post.id, revision));
          if (old) { requireMission(old.digest === fingerprint, 'CONVERSATION_CONFLICT', 'Source revision has conflicting bytes'); continue; }
          const event: Omit<ConversationEvent, 'sequence'> = { bindingId: binding.id, postId: post.id, author,
            kind: post.deleteAt ? 'delete' : post.updateAt > post.createAt ? 'edit' : 'message', text: post.deleteAt ? '' : post.message,
            sourceRevision: revision, observedAt: new Date().toISOString() };
          (await this.db.prepare('INSERT INTO conversation_events(binding_id,post_id,source_revision,digest,body) VALUES (?,?,?,?,?)')
            .run(binding.id, post.id, revision, fingerprint, JSON.stringify(event)));
        }
        return;
      }
      case 'sync': {
        const binding = (await this.binding(op.bindingId));
        if (op.error !== undefined) {
          requireMission(['offline', 'route-revoked', 'history-limit', 'invalid-source'].includes(op.error), 'INVALID_INPUT', 'Invalid synchronization state'); binding.syncError = op.error;
        } else { delete binding.syncError; binding.lastSyncedAt = new Date().toISOString(); }
        (await this.saveBinding(binding)); return;
      }
    }
  }
}
