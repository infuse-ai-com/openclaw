import {
  healthObject as object,
  healthText as text,
  healthDigest,
  healthTime,
  healthCount,
  parseTelemetryInput,
  parseCompanySignalInput,
  type ArtifactRetainedSource,
} from '@studio/contracts';
import type { AgentTelemetryConfig } from './telemetry-config.js';
import type { GitContributionsConfig } from './git-config.js';
import { configuredGitMetadata } from './git-config.js';
import { healthDefinition, type MonitoringConfig } from './monitoring-config.js';
import { companySignalDefinition } from './company-config.js';
import { decodeAgentFeed } from './agent-feeds.js';
import { decodeRetainedAgentUsage } from './retained-agent-usage.js';
import { decodeRetainedGitCommits } from './retained-git.js';
import { decodeRetainedHealth, type RetainedHealthMapping } from './retained-health.js';
import {
  normalizeBackofficeArtifactRows,
  artifactRetainedMapping,
} from './retained-artifact-normalize.js';
import { decodeProviderSignalFeed } from './company-reader.js';
import { retainedTimestamp } from './retained-time.js';
import {
  importDigest,
  importCanonical,
  importPayloadSource,
  importPayloadRecords,
  importEntityKeys,
  validateBackofficeImportClock,
  parseBackofficeImportPayload,
  parseBackofficeImportManifest,
  type BackofficeImportPayload,
  type BackofficeImportManifest,
} from './backoffice-import-contract.js';
export interface BackofficeImportAdmission {
  scopeDigest: string;
  projectIds: string[];
  agentTelemetry?: AgentTelemetryConfig;
  contributions?: GitContributionsConfig;
  monitoring?: MonitoringConfig;
  artifactSources: ArtifactRetainedSource[];
}
export interface BackofficeExportPage {
  kind:
    | 'agent-usage'
    | 'agent-feed'
    | 'agent-projection'
    | 'git'
    | 'health'
    | 'company-projection'
    | 'artifacts';
  sourceId: string;
  file: string;
  sha256: string;
  rows: number;
  legacyRepositoryId?: string;
  mapping?: RetainedHealthMapping;
  recordKind?: 'audit' | 'lifecycle' | 'purge-job';
}
export interface BackofficeExportIndex {
  schema: 'infuse.backoffice-export/v1';
  id: string;
  sourceRevision: string;
  exportedAt: string;
  pages: BackofficeExportPage[];
  artifactSources: { sourceId: string; mapping: ReturnType<typeof artifactRetainedMapping> }[];
  exclusions: Record<string, number>;
}
function keys(o: Record<string, unknown>, allowed: string[]) {
  if (Object.keys(o).some((k) => !allowed.includes(k)))
    throw Error('Unexpected selected export field');
}
export function parseBackofficeExportIndex(value: unknown): BackofficeExportIndex {
  const o = object(value);
  keys(o, [
    'schema',
    'id',
    'sourceRevision',
    'exportedAt',
    'pages',
    'artifactSources',
    'exclusions',
  ]);
  if (
    o.schema !== 'infuse.backoffice-export/v1' ||
    !Array.isArray(o.pages) ||
    o.pages.length > 1000 ||
    !Array.isArray(o.artifactSources) ||
    o.artifactSources.length > 50
  )
    throw Error('Invalid selected export index');
  const pages = o.pages.map((raw) => {
    const p = object(raw);
    keys(p, [
      'kind',
      'sourceId',
      'file',
      'sha256',
      'rows',
      'legacyRepositoryId',
      'mapping',
      'recordKind',
    ]);
    if (
      ![
        'agent-usage',
        'agent-feed',
        'agent-projection',
        'git',
        'health',
        'company-projection',
        'artifacts',
      ].includes(String(p.kind)) ||
      typeof p.file !== 'string' ||
      !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,120}\.json$/.test(p.file) ||
      typeof p.sourceId !== 'string' ||
      !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(p.sourceId)
    )
      throw Error('Invalid selected export page');
    return {
      ...p,
      sha256: healthDigest(p.sha256),
      rows: healthCount(p.rows, 768),
    } as unknown as BackofficeExportPage;
  });
  if (new Set(pages.map((p) => p.file)).size !== pages.length)
    throw Error('Duplicate selected export file');
  const artifactSources = o.artifactSources.map((raw) => {
    const s = object(raw);
    keys(s, ['sourceId', 'mapping']);
    const sourceId = text(s.sourceId, 128);
    if (!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(sourceId))
      throw Error('Invalid artifact export source');
    return {
      sourceId,
      mapping: artifactRetainedMapping(s.mapping).sort((a, b) =>
        importCanonical(a) < importCanonical(b)
          ? -1
          : importCanonical(a) > importCanonical(b)
            ? 1
            : 0,
      ),
    };
  });
  if (new Set(artifactSources.map((s) => s.sourceId)).size !== artifactSources.length)
    throw Error('Duplicate artifact export source');
  const probe = parseBackofficeImportManifest({
    schema: 'infuse.backoffice-import/v1',
    id: o.id,
    sourceRevision: o.sourceRevision,
    exportedAt: o.exportedAt,
    policyAt: o.exportedAt,
    scopeDigest: '0'.repeat(64),
    inputDigest: '0'.repeat(64),
    pages: [],
    exclusions: o.exclusions,
  });
  return {
    schema: o.schema,
    id: probe.id,
    sourceRevision: probe.sourceRevision,
    exportedAt: probe.exportedAt,
    pages,
    artifactSources,
    exclusions: probe.exclusions,
  };
}
export function plannedArtifactSources(index: BackofficeExportIndex): ArtifactRetainedSource[] {
  return index.artifactSources.map((s) => ({
    sourceId: s.sourceId,
    manifestDigest: importDigest({
      schema: 'infuse.backoffice-artifacts-source/v1',
      sourceId: s.sourceId,
      sourceRevision: index.sourceRevision,
      exportedAt: index.exportedAt,
      mapping: s.mapping,
      pages: index.pages
        .filter((p) => p.kind === 'artifacts' && p.sourceId === s.sourceId)
        .map((p) => ({ kind: p.recordKind, digest: p.sha256, rows: p.rows }))
        .sort((a, b) =>
          importCanonical(a) < importCanonical(b)
            ? -1
            : importCanonical(a) > importCanonical(b)
              ? 1
              : 0,
        ),
    }),
  }));
}
/** Pure preparation over already hash-verified private source documents; no database access or source transport. */
export function prepareBackofficeImport(
  index: BackofficeExportIndex,
  documents: ReadonlyMap<string, unknown>,
  admission: BackofficeImportAdmission,
  at: string,
): {
  manifest: BackofficeImportManifest;
  payloads: BackofficeImportPayload[];
  requiredArtifactSources: ArtifactRetainedSource[];
  scopeReviewRequired: ArtifactRetainedSource[];
} {
  const policyAt = healthTime(at);
  if (index.exportedAt > new Date(Date.parse(policyAt) + 300000).toISOString())
    throw Error('Export clock is ahead');
  healthDigest(admission.scopeDigest);
  const requiredArtifactSources = plannedArtifactSources(index),
    scopeReviewRequired = requiredArtifactSources.filter(
      (s) =>
        !admission.artifactSources.some(
          (a) => a.sourceId === s.sourceId && a.manifestDigest === s.manifestDigest,
        ),
    ),
    payloads: BackofficeImportPayload[] = [],
    exclusions = { ...index.exclusions },
    seen = new Set<string>(),
    emptyArtifactSources = new Set<string>();
  const usage = new Map<string, unknown[]>(),
    health = new Map<
      string,
      {
        check: ReturnType<typeof healthDefinition>;
        observations: Extract<BackofficeImportPayload, { kind: 'health' }>['observations'];
      }
    >();
  const exclude = (name: string, count: number) => {
    exclusions[name] = (exclusions[name] ?? 0) + count;
  };
  function emit(raw: BackofficeImportPayload) {
    const p = parseBackofficeImportPayload(raw),
      source = importPayloadSource(p),
      ids = importEntityKeys(p);
    validateBackofficeImportClock(p, Date.parse(policyAt));
    for (const id of ids) {
      const key = source + ':' + id;
      if (seen.has(key)) throw Error('Duplicate normalized identity in selected export');
      seen.add(key);
    }
    payloads.push(p);
    if (payloads.length > 1000) throw Error('Prepared page count exceeds bound');
  }
  function chunk<T>(rows: T[], make: (r: T[]) => BackofficeImportPayload, recordBytes = 262144) {
    let page: T[] = [];
    for (const row of rows) {
      const next = [...page, row];
      if (
        next.length > 100 ||
        Buffer.byteLength(importCanonical(next)) > recordBytes ||
        Buffer.byteLength(importCanonical(make(next))) > 262144
      ) {
        if (!page.length) throw Error('One normalized record exceeds its bound');
        emit(make(page));
        page = [row];
      } else page = next;
    }
    if (page.length) emit(make(page));
  }
  for (const p of index.pages) {
    if (!documents.has(p.file)) throw Error('Selected export document is missing');
    const raw = documents.get(p.file),
      count = Array.isArray(raw) ? raw.length : 1;
    if (count !== p.rows) throw Error('Selected export row count changed');
    if (p.kind === 'agent-usage' || p.kind === 'agent-feed' || p.kind === 'agent-projection') {
      const source = admission.agentTelemetry?.sources.find((s) => s.sourceId === p.sourceId);
      if (!source) throw Error('Agent source needs explicit admission');
      if (p.kind === 'agent-usage') {
        if (source.kind !== 'usage' || source.transport.type !== 'retained' || !Array.isArray(raw))
          throw Error('BO usage requires an explicit retained source');
        const rows = usage.get(source.sourceId) ?? [];
        rows.push(...raw);
        if (rows.length > 768) throw Error('Retained usage source window exceeds bound');
        usage.set(source.sourceId, rows);
      } else {
        const input =
          p.kind === 'agent-feed'
            ? decodeAgentFeed(raw, source, index.exportedAt)
            : parseTelemetryInput(raw);
        if (
          input.sourceId !== source.sourceId ||
          input.gatewayId !== source.gatewayId ||
          input.agentId !== source.agentId ||
          input.kind !== source.kind
        )
          throw Error('Agent projection disagrees with approved mapping');
        emit({ kind: 'agent', input });
      }
      continue;
    }
    if (p.kind === 'git') {
      const source = admission.contributions?.repositories.find((s) => s.sourceId === p.sourceId);
      if (!source || !p.legacyRepositoryId)
        throw Error('Retained Git needs immutable source mapping');
      const repository = configuredGitMetadata(source),
        commits = decodeRetainedGitCommits(raw, {
          legacyRepositoryId: p.legacyRepositoryId,
          repository,
        });
      chunk(commits, (commits) => ({ kind: 'git', repository, commits }));
      continue;
    }
    if (p.kind === 'health') {
      const source = admission.monitoring?.checks.find((c) => c.id === p.sourceId);
      if (!source || !p.mapping) throw Error('Retained health needs a reviewed binding');
      const check = healthDefinition(source),
        decoded = decodeRetainedHealth(raw, check, p.mapping, policyAt),
        group = health.get(source.id) ?? { check, observations: [] };
      group.observations.push(...decoded.observations);
      if (group.observations.length > 4096)
        throw Error('Retained health source exceeds sample cap');
      health.set(source.id, group);
      for (const k of ['unmapped', 'unfinished', 'outsideBinding', 'outsideRetention'] as const)
        exclude('health_' + k, decoded[k]);
      continue;
    }
    if (p.kind === 'company-projection') {
      const source = admission.monitoring?.signals?.sources.find((s) => s.sourceId === p.sourceId);
      if (!source) throw Error('Company source needs explicit admission');
      const input =
          source.kind === 'provider-usage' && object(raw).schemaVersion === 1
            ? decodeProviderSignalFeed(raw, source)
            : parseCompanySignalInput(raw),
        definition = companySignalDefinition(source);
      if (
        input.sourceId !== definition.sourceId ||
        input.resourceId !== definition.resourceId ||
        input.kind !== definition.kind ||
        input.specDigest !== definition.specDigest ||
        (source.kind === 'provider-usage' &&
          (input.data as { owner: string }).owner !== source.owner)
      )
        throw Error('Company projection binding changed');
      emit({ kind: 'company', definition, input });
      continue;
    }
    const artifactSource = index.artifactSources.find((s) => s.sourceId === p.sourceId),
      source = requiredArtifactSources.find((s) => s.sourceId === p.sourceId);
    if (!artifactSource || !source || !p.recordKind)
      throw Error('Artifact source/mapping is undeclared');
    if (artifactSource.mapping.some((m) => !admission.projectIds.includes(m.projectId)))
      throw Error('Artifact mapping names an unqualified floor');
    const records = normalizeBackofficeArtifactRows(
      source.sourceId,
      p.recordKind,
      raw,
      artifactSource.mapping,
    );
    if (!records.length) {
      if (
        !index.pages.some(
          (p) => p.kind === 'artifacts' && p.sourceId === source.sourceId && p.rows > 0,
        ) &&
        !emptyArtifactSources.has(source.sourceId)
      ) {
        emptyArtifactSources.add(source.sourceId);
        emit({ kind: 'artifacts', source, records: [] });
      }
    } else chunk(records, (records) => ({ kind: 'artifacts', source, records }), 65536);
  }
  for (const [id, rows] of usage) {
    const source = admission.agentTelemetry!.sources.find((s) => s.sourceId === id)!,
      cutoff = Math.floor(Date.parse(policyAt) / 86400000) * 86400000 - 6 * 86400000,
      kept = rows
        .filter((raw) => {
          const r = object(raw),
            start = retainedTimestamp(r.bucketStart);
          if (Date.parse(start) < cutoff) {
            exclude('usage_outsideRetention', 1);
            return false;
          }
          return true;
        })
        .map((raw) => {
          const r = object(raw);
          return {
            ...r,
            bucketStart: retainedTimestamp(r.bucketStart),
            ...(r.generatedAt ? { generatedAt: retainedTimestamp(r.generatedAt) } : {}),
            ...(r.importedAt ? { importedAt: retainedTimestamp(r.importedAt) } : {}),
          };
        });
    const input = decodeRetainedAgentUsage(kept, source, index.exportedAt),
      buckets = input.data as { start: string; minutes: number; provider: string; model: string }[];
    if (
      new Set(buckets.map((r) => importCanonical([r.start, r.minutes, r.provider, r.model])))
        .size !== buckets.length
    )
      throw Error('Duplicate retained usage bucket');
    emit({ kind: 'agent', input });
  }
  for (const group of health.values()) {
    if (new Set(group.observations.map((s) => s.finishedAt)).size !== group.observations.length)
      throw Error('Ambiguous retained health ordering');
    group.observations.sort(
      (a, b) => a.finishedAt.localeCompare(b.finishedAt) || a.id.localeCompare(b.id),
    );
    chunk(group.observations, (observations) => ({
      kind: 'health',
      check: group.check,
      observations,
    }));
  }
  const manifest = parseBackofficeImportManifest({
    schema: 'infuse.backoffice-import/v1',
    id: index.id,
    sourceRevision: index.sourceRevision,
    exportedAt: index.exportedAt,
    policyAt,
    scopeDigest: admission.scopeDigest,
    inputDigest: importDigest(index),
    pages: payloads.map((p) => ({
      kind: p.kind,
      sourceKey: importPayloadSource(p),
      digest: importDigest(p),
      records: importPayloadRecords(p),
    })),
    exclusions,
  });
  return { manifest, payloads, requiredArtifactSources, scopeReviewRequired };
}
