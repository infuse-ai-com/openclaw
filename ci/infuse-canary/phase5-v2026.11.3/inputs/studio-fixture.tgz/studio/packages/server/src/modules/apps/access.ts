import { appAccessGroups,type AppAccessGroup } from '@studio/contracts';
export type AppIdentity = { issuer:string;subject:string;profileId:string;displayName?:string;groups:AppAccessGroup[] } & (
 { access: 'ongoing'; validUntil?: never } | { access?: never; validUntil: string }
);
export interface AppsAccessPolicy { identities:AppIdentity[] }
export interface VerifiedAppIdentity { issuer:string;subject:string;profileId?:string }
export interface AppMember { profileId:string;displayName?:string }
const audiences=new Set(['infuse-core','infuse-bets','infuse-clients','personal-fito','personal-conbotas']);
const text=(v:unknown,max=8192):v is string=>typeof v==='string'&&v.trim().length>0&&v.length<=max&&!/[\u0000-\u001f\u007f]/u.test(v);
/** Parses explicit operator-owned entitlements; missing expiry never implies ongoing access. */
export function parseAppsAccessPolicy(value:unknown,issuer:string):AppsAccessPolicy {
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>k!=='identities'))throw Error('Invalid app policy');
 const entries=(value as {identities:unknown}).identities;
 if(!Array.isArray(entries)||entries.length>1000)throw Error('Invalid app identities');
 const ids=new Set<string>(),profiles=new Set<string>();
 const identities=entries.map((v:unknown):AppIdentity=>{
  if(!v||typeof v!=='object'||Array.isArray(v))throw Error('Invalid app identity');
  const a=v as Record<string,unknown>;
  if(Object.keys(a).some(k=>!['issuer','subject','profileId','displayName','groups','validUntil','access'].includes(k))||a.issuer!==issuer||!text(a.subject,1024)||!text(a.profileId)
    ||(a.displayName!==undefined&&!text(a.displayName,256))||!Array.isArray(a.groups)||a.groups.length>appAccessGroups.length
    ||!a.groups.every(g=>typeof g==='string'&&(appAccessGroups as readonly string[]).includes(g))||new Set(a.groups).size!==a.groups.length
)throw Error('Invalid app identity fields');
  const ongoing=a.access==='ongoing';
  if(ongoing ? 'validUntil' in a : ('access' in a || typeof a.validUntil!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(a.validUntil)||!Number.isFinite(Date.parse(a.validUntil))
    ||new Date(a.validUntil).toISOString().replace('.000Z','Z')!==a.validUntil.replace('.000Z','Z')))throw Error('Invalid app identity fields');
  const key=JSON.stringify([issuer,a.subject]);
  if(ids.has(key)||profiles.has(a.profileId))throw Error('Duplicate app identity');ids.add(key);profiles.add(a.profileId);
  return {issuer,subject:a.subject,profileId:a.profileId,groups:[...a.groups] as AppAccessGroup[],...(ongoing?{access:'ongoing' as const}:{validUntil:a.validUntil as string}),...(typeof a.displayName==='string'?{displayName:a.displayName}:{})};
 });
 return {identities};
}
/** Pure decision over verified identity and trusted current policy; it does not create a session or grant a floor role. */
export function resolveAppAccess(policy:AppsAccessPolicy|undefined,identity:VerifiedAppIdentity,member:AppMember|undefined,now=Date.now()) {
 const grant=policy?.identities.find(i=>i.issuer===identity.issuer&&i.subject===identity.subject);
 if(grant&&member&&grant.profileId!==member.profileId)throw Error('App and workspace identities disagree');
 const status=!grant?'unconfigured' as const:grant.access==='ongoing'
  ?member?'ready' as const:'unconfigured' as const
  :Date.parse(grant.validUntil)>now?'ready' as const:'expired' as const;
 const eligible=!!member||status==='ready'&&!!grant?.groups.some(g=>audiences.has(g));
 const profileId=member?.profileId??grant?.profileId;
 if(identity.profileId!==undefined&&profileId!==identity.profileId)return {eligible:false,groups:[] as AppAccessGroup[],status};
 return {eligible,groups:eligible&&status==='ready'?[...grant!.groups].sort():[] as AppAccessGroup[],status,
  profileId,displayName:member?.displayName??grant?.displayName??profileId?.slice(0,256),workspaceMember:!!member};
}
