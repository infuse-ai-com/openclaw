import type { AgentReadQuery, AgentReadPage } from '../../persistence/missions/whiteboard-agent-read.js';
import type { WhiteboardAgentCustody, WhiteboardNativeCommand } from './agent-custody.js';
import { whiteboardOverview,whiteboardRevert,whiteboardManifestQuery,whiteboardDetailQuery,whiteboardSearchQuery,whiteboardRenderQuery,type WhiteboardHtml,type WhiteboardImage,type WhiteboardManifest,type WhiteboardDetails,type WhiteboardSearch,whiteboardActor, whiteboardChangesQuery, whiteboardCommand, whiteboardContextQuery, whiteboardId, whiteboardReadQuery,
  type WhiteboardActor, type WhiteboardChanges, type WhiteboardContext, type WhiteboardReceipt, type WhiteboardSnapshot } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
import type { WhiteboardRequest } from '../../persistence/missions/whiteboard.js';
import { WhiteboardWorkQueue } from './work-queue.js';
import { renderWhiteboard } from './render.js';
import { MissionError, requireMission } from '../missions/domain.js';

/** Constructed by a trusted transport. Agent adapters must supply their own explicit live grant. */
export interface WhiteboardPrincipal { projectId: string; actor: WhiteboardActor; canWrite: boolean; nativeCustody?: WhiteboardAgentCustody; nativeCommand?: WhiteboardNativeCommand }
export type WhiteboardGuard = () => WhiteboardPrincipal;
function parsed<T>(parse: (input: unknown) => T, input: unknown): T {
  try { return parse(input); } catch { throw new MissionError('INVALID_INPUT', 'Invalid whiteboard request'); }
}
export class WhiteboardService {
  private queue=new WhiteboardWorkQueue();
  constructor(private store: MissionStore) {}
  private async request<T>(op: WhiteboardRequest, current: WhiteboardGuard): Promise<T> {
    requireMission(typeof current === 'function', 'FORBIDDEN', 'Live whiteboard admission is required');
    const principal = current();
    const projectId = parsed(whiteboardId.parse, principal.projectId);
    const actor = parsed(whiteboardActor.parse, principal.actor);
    const guard = () => {
      const live = current();
      requireMission(live.projectId === projectId && live.actor.kind === actor.kind && live.actor.id === actor.id,
        'FORBIDDEN', 'Whiteboard identity or project changed');
      requireMission(JSON.stringify(live.nativeCommand) === JSON.stringify(principal.nativeCommand), 'FORBIDDEN', 'Whiteboard command changed');
      requireMission(JSON.stringify(live.nativeCustody) === JSON.stringify(principal.nativeCustody), 'FORBIDDEN', 'Whiteboard invocation changed');
      requireMission((op.kind !== 'apply' && op.kind !== 'revert' && op.kind !== 'agent-update') || live.canWrite === true, 'FORBIDDEN', 'Whiteboard write access is required');
    };
    guard();
    const result = await this.queue.run(()=>this.store.whiteboard<T>({ ...op, projectId, actor, nativeCustody: principal.nativeCustody, nativeCommand: principal.nativeCommand }, guard));
    guard();
    return result;
  }
  postAgentUpdate(input:unknown,guard:WhiteboardGuard) {return this.request<import('@studio/contracts').WhiteboardAgentUpdate>({kind:'agent-update',input},guard);}
  agentUpdates(before:number|undefined,limit:number,guard:WhiteboardGuard) {return this.request<{updates:import('@studio/contracts').WhiteboardAgentUpdate[];hasMore:boolean;nextBefore:number|null}>({kind:'agent-updates',before,limit},guard);}
  agentRender(input:unknown,guard:WhiteboardGuard) {return this.request<import('../../persistence/missions/whiteboard-agent-render.js').AgentRenderRead>({kind:'agent-render',input},guard);}
  agentOutcome(commandId:string,payloadHash:string,guard:WhiteboardGuard) {
    return this.request<Extract<import('@studio/contracts').WhiteboardAgentResult,{kind:'receipt'}>['value']>({kind:'agent-outcome',commandId,payloadHash},guard);
  }
  agentChanges(after:number,limit:number,guard:WhiteboardGuard) {
    return this.request<Omit<Extract<import('@studio/contracts').WhiteboardAgentResult,{kind:'changes'}>['value'],'nextCursor'> & {eventRevisions:number[]}>({kind:'agent-changes',after,limit},guard);
  }
  agentCommand(commandId: string, payloadHash: string, guard: WhiteboardGuard) {
    return this.request<import('../../persistence/missions/whiteboard-native-commands.js').NativeCommandReceipt | null>({ kind: 'agent-command', commandId, payloadHash }, guard);
  }
  agentRead(input: AgentReadQuery, guard: WhiteboardGuard) { return this.request<AgentReadPage>({ kind: 'agent-read', input }, guard); }
  async overview(guard:WhiteboardGuard) {return whiteboardOverview.parse(await this.request({kind:'overview',input:{}},guard));}
  revert(input:unknown,guard:WhiteboardGuard) { return this.request<WhiteboardReceipt>({kind:'revert',command:parsed(whiteboardRevert.parse,input)},guard); }
  tile(id:unknown,revision:number,guard:WhiteboardGuard) {
    requireMission(Number.isSafeInteger(revision) && revision>=0,'INVALID_INPUT','Invalid tile revision');
    return this.request<WhiteboardHtml|WhiteboardImage>({kind:'tile',input:{id:parsed(whiteboardId.parse,id),revision}},guard);
  }
  manifest(input:unknown,guard:WhiteboardGuard) {return this.request<WhiteboardManifest>({kind:'manifest',input:parsed(whiteboardManifestQuery.parse,input)},guard);}
  details(input:unknown,guard:WhiteboardGuard) {return this.request<WhiteboardDetails>({kind:'details',input:parsed(whiteboardDetailQuery.parse,input)},guard);}
  search(input:unknown,guard:WhiteboardGuard) {return this.request<WhiteboardSearch>({kind:'search',input:parsed(whiteboardSearchQuery.parse,input)},guard);}
  async render(input:unknown,guard:WhiteboardGuard) {return renderWhiteboard(await this.request<Parameters<typeof renderWhiteboard>[0]>({kind:'render',input:parsed(whiteboardRenderQuery.parse,input)},guard));}
  snapshot(guard: WhiteboardGuard) { return this.request<WhiteboardSnapshot>({ kind: 'snapshot' }, guard); }
  read(input: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardSnapshot>({ kind: 'read', input: parsed(whiteboardReadQuery.parse, input) }, guard); }
  context(input: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardContext>({ kind: 'context', input: parsed(whiteboardContextQuery.parse, input) }, guard); }
  changes(input: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardChanges>({ kind: 'changes', input: parsed(whiteboardChangesQuery.parse, input) }, guard); }
  apply(input: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardReceipt>({ kind: 'apply', command: parsed(whiteboardCommand.parse, input) }, guard); }
  receipt(commandId: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardReceipt | null>({ kind: 'receipt', commandId: parsed(whiteboardId.parse, commandId) }, guard); }
}
