import { projectWhiteboardXml, type WhiteboardXmlRead } from './agent-xml.js';
import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { WHITEBOARD_AGENT_PROTOCOL, whiteboardAgentOperation, whiteboardAgentResponse, whiteboardAgentLimits,
  type WhiteboardAgentResult, type WhiteboardAgentResponse, type WhiteboardSharedView } from '@studio/contracts';
import { MissionError, requireMission } from '../missions/domain.js';
import type { WhiteboardGuard, WhiteboardPrincipal, WhiteboardService } from './service.js';

type Kind = 'context' | 'read' | 'search' | 'changes';
type Value<K extends Kind> = Extract<WhiteboardAgentResult, { kind: K }>['value'];
type Cursor = { revision: number; after?: string; sectionOffset?: number; shareAfter?: string; sharesDone?: boolean; index?: number; offset?: number };
export const whiteboardReadCapabilities = { protocol: WHITEBOARD_AGENT_PROTOCOL,
  tools: ['studio_whiteboard_context', 'studio_whiteboard_read', 'studio_whiteboard_search'] as const, imageContent: false };
const envelope = (result: WhiteboardAgentResult) => ({ version: 2 as const, kind: 'whiteboard' as const,
  protocol: WHITEBOARD_AGENT_PROTOCOL, ok: true as const, result });
const hash = (v: unknown) => createHash('sha256').update(JSON.stringify(v)).digest('hex');
const boundary = (text: string, end: number) => end > 0 && end < text.length && /[\uD800-\uDBFF]/u.test(text[end - 1]!) ? end - 1 : end;

/** Scoped opaque cursors are read continuations, never a grant or a retained body. */
export class WhiteboardAgentReader {
  private key = randomBytes(32);
  constructor(private board: WhiteboardService,
    private views: (principal: WhiteboardPrincipal) => WhiteboardSharedView[] = () => [],
    private now = Date.now,
    private capabilities: {protocol:typeof WHITEBOARD_AGENT_PROTOCOL;tools:import('@studio/contracts').WhiteboardAgentInvocation['toolName'][];imageContent:boolean} = {...whiteboardReadCapabilities,tools:[...whiteboardReadCapabilities.tools]},
    private source?:import('./agent-renderer.js').WhiteboardSourcePort) {}
  private cursor(bind: string, state: Cursor): string {
    const data = Buffer.from(JSON.stringify({ bind, expires: this.now() + 300000, state })).toString('base64url');
    return data + '.' + createHmac('sha256', this.key).update(data).digest('base64url');
  }
  private resume(value: string | undefined, bind: string): Cursor | undefined {
    if (!value) return;
    try {
      const [data, tag, extra] = value.split('.');
      const actual = Buffer.from(tag!, 'base64url'), expected = createHmac('sha256', this.key).update(data!).digest();
      requireMission(!extra && actual.length === expected.length && timingSafeEqual(actual, expected), 'RESYNC_REQUIRED', 'Invalid continuation');
      const parsed = JSON.parse(Buffer.from(data!, 'base64url').toString('utf8'));
      requireMission(parsed.bind === bind && parsed.expires > this.now(), 'RESYNC_REQUIRED', 'Expired or unrelated continuation');
      return parsed.state as Cursor;
    } catch { throw new MissionError('RESYNC_REQUIRED', 'Restart this read from the current board'); }
  }
  async request(input: unknown, guard: WhiteboardGuard): Promise<WhiteboardAgentResponse> {
    const parsed = whiteboardAgentOperation.safeParse(input);
    requireMission(parsed.success, 'INVALID_INPUT', 'Invalid whiteboard operation');
    const op = parsed.data;
    requireMission(op.kind === 'context' || op.kind === 'read' || op.kind === 'search' || op.kind === 'changes', 'UNSUPPORTED_CAPABILITY', 'This capability is not enabled');
    const initial = guard();
    requireMission(initial.actor.kind === 'agent' && initial.projectId === op.input.projectId, 'FORBIDDEN', 'Current agent project access is required');
    const { cursor, format = 'json', ...query } = op.input;
    const present = (result: WhiteboardXmlRead): WhiteboardAgentResult => format === 'xml'
      ? { kind: 'xml', value: projectWhiteboardXml(result) } : result;
    // Budget the actual escaped wire representation, including derived geometry.
    const fits = (result: WhiteboardXmlRead) => Buffer.byteLength(JSON.stringify(envelope(present(result)))) + 1024 <= whiteboardAgentLimits.textBytes;
    const bind = hash({ actor: initial.actor, projectId: initial.projectId, kind: op.kind, query, format });
    const state = this.resume(cursor, bind);
    let result: WhiteboardXmlRead;
    if (op.kind === 'changes') {
      const page=await this.board.agentChanges(Number(state?.after??op.input.afterRevision??0),op.input.limit??20,guard);
      const value:Value<'changes'>={projectId:page.projectId,revision:page.revision,events:[],nextCursor:null};
      let after=Number(state?.after??op.input.afterRevision??0);
      for(const [index,event] of page.events.entries()) {value.events.push(event);if(!fits({kind:'changes',value})){value.events.pop();break;}after=page.eventRevisions[index]!;}
      requireMission(!page.events.length||value.events.length>0,'PAYLOAD_TOO_LARGE','Change event exceeds budget');
      // A checkpoint is returned even at the head, so subsequent polls do not repeat history.
      value.nextCursor=this.cursor(bind,{revision:page.revision,after:String(after)});
      result={kind:'changes',value};
    } else if (op.kind === 'context') {
      const sectionId = op.input.sectionId ?? 'root', limit = op.input.limit ?? 20;
      const page = await this.board.agentRead({ kind: 'context', sectionId, limit,
        revision: state?.revision, after: state?.after, sectionOffset: state?.sectionOffset ?? 0 }, guard);
      requireMission(page.kind === 'context', 'UNAVAILABLE', 'Unexpected read');
      const views = this.views(guard()).sort((a,b) => a.connectionId.localeCompare(b.connectionId));
      const value: Value<'context'> = { projectId: initial.projectId, sectionId, revision: page.revision,
        actor: { kind: 'agent', id: initial.actor.id }, access: initial.canWrite ? 'edit' : 'read',
        capabilities: {...this.capabilities,tools:this.capabilities.tools.filter(t=>initial.canWrite||(t!=='studio_whiteboard_apply'&&t!=='studio_whiteboard_post_update'))},
        ancestors: page.ancestors, total: page.total, items: [], sections: [],
        sharedView: views.length ? { status: 'shared', views: [] } : { status: 'unknown' }, nextCursor: null };
      const next: Cursor = { ...state, revision: page.revision, sectionOffset: state?.sectionOffset ?? 0 };
      let more = false;
      if (!next.sharesDone) {
        for (const view of views.filter(v => v.connectionId > (next.shareAfter ?? ''))) {
          if (value.sharedView.status !== 'shared') break;
          if (value.sharedView.views.length >= 10) { more = true; break; }
          value.sharedView.views.push(view);
          if (!fits({ kind: 'context', value })) { value.sharedView.views.pop(); more = true; break; }
          next.shareAfter = view.connectionId;
        }
        next.sharesDone = !more;
      }
      if (!more) {
        for (const section of page.sections) {
          value.sections.push(section);
          if (!fits({ kind: 'context', value })) { value.sections.pop(); more = true; break; }
          next.sectionOffset!++;
        }
        more ||= next.sectionOffset! < page.sectionsTotal;
      }
      if (!more) {
        for (const item of page.items) {
          value.items.push(item);
          if (!fits({ kind: 'context', value })) { value.items.pop(); more = true; break; }
          next.after = item.item.id;
        }
        more ||= page.nextItem !== null;
      }
      if (more) {
        requireMission(value.items.length > 0 || value.sections.length > 0 ||
          value.sharedView.status === 'shared' && value.sharedView.views.length > 0,
          'PAYLOAD_TOO_LARGE', 'Narrow this context or use JSON');
        value.nextCursor = this.cursor(bind, next);
      }
      result = { kind: 'context', value };
    } else if (op.kind === 'search') {
      const page = await this.board.agentRead({ kind: 'search', query: op.input.query, limit: op.input.limit,
        revision: state?.revision, after: state?.after }, guard);
      requireMission(page.kind === 'search', 'UNAVAILABLE', 'Unexpected read');
      const value: Value<'search'> = { projectId: initial.projectId, revision: page.revision, items: [], nextCursor: null };
      let more = page.nextItem !== null;
      for (const item of page.items) {
        value.items.push(item);
        if (!fits({ kind: 'search', value })) { value.items.pop(); more = true; break; }
      }
      requireMission(!more || value.items.length > 0, 'PAYLOAD_TOO_LARGE', 'Narrow this search');
      if (more) value.nextCursor = this.cursor(bind, { revision: page.revision, after: value.items.at(-1)!.item.id });
      result = { kind: 'search', value };
    } else {
      requireMission(op.input.facet==='content'||this.source,'UNSUPPORTED_CAPABILITY','HTML source reading is not enabled');
      const page = await this.board.agentRead({ kind: 'read', sectionId: op.input.sectionId, revision: op.input.revision, ids: op.input.ids }, guard);
      requireMission(page.kind === 'read', 'UNAVAILABLE', 'Unexpected read');
      const value: Value<'read'> = { projectId: initial.projectId, sectionId: page.sectionId, revision: page.revision,
        items: [], coverage: { complete: false, omitted: [], missingIds: page.missingIds }, nextCursor: null };
      let index = state?.index ?? 0, offset = state?.offset ?? 0;
      for (; index < page.items.length; index++) {
        const source = page.items[index]!;
        if(op.input.facet==='html_source') {
          if(source.item.kind!=='html'){
            value.coverage.omitted.push({id:source.item.id,reason:'This item has no HTML source'});
            if(!fits({kind:'read',value})){value.coverage.omitted.pop();break;}
            continue;
          }
          const bytes=await this.source!(initial.projectId,source.item.reference,'html',guard);
          new TextDecoder('utf-8',{fatal:true}).decode(bytes);
          let end=Math.min(bytes.length,offset+6000);
          const fragment=()=>{while(end<bytes.length&&(bytes[end]!&0xc0)===0x80)end--;return {...source,htmlSource:{hash:source.item.kind==='html'?source.item.reference.sha256:'',from:offset,to:end,totalBytes:bytes.length,text:bytes.subarray(offset,end).toString('utf8')}};};
          let item=fragment();
          while(!fits({kind:'read',value:{...value,items:[...value.items,item]}})&&end>offset){end=offset+Math.floor((end-offset)/2);item=fragment();}
          if(!fits({kind:'read',value:{...value,items:[...value.items,item]}})||end===offset&&offset<bytes.length)break;
          value.items.push(item);if(end<bytes.length){offset=end;break;}offset=0;
        } else if (source.body) {
          const text = source.body.text;
          let low = 0, high = text.length - offset;
          const fragment = (units: number) => { const to = boundary(text, offset + units); return { ...source, body: {
            ...source.body!, from: offset, to, text: text.slice(offset, to) } }; };
          while (low < high) {
            const mid = Math.ceil((low + high) / 2), candidate = fragment(mid);
            if (fits({ kind: 'read', value: { ...value, items: [...value.items, candidate] } })) low = mid;
            else high = mid - 1;
          }
          const item = fragment(low);
          if (!fits({kind:'read',value:{...value,items:[...value.items,item]}}) || (item.body.to === offset && offset < text.length)) break;
          value.items.push(item);
          if (item.body.to < text.length) { offset = item.body.to; break; }
          offset = 0;
        } else if (source.points) {
          let count = Math.min(source.points.length - offset, 200);
          let item;
          do {
            item = { ...source, points: source.points.slice(offset, offset + count) as [number, number][],
              pointRange: { from: offset, to: offset + count, total: source.points.length } };
            if (fits({ kind: 'read', value: { ...value, items: [...value.items, item] } })) break;
            count = Math.floor(count / 2);
          } while (count >= 2);
          if (count < 2) break;
          // Leave two points for the next page (the stroke contract requires two).
          if (source.points.length - offset - count === 1) { if(count===2)break; count--; item = { ...item!, points: source.points.slice(offset, offset + count) as [number, number][], pointRange: { from: offset, to: offset + count, total: source.points.length } }; }
          value.items.push(item!);
          if (offset + count < source.points.length) { offset += count; break; }
          offset = 0;
        } else {
          const item = source as Value<'read'>['items'][number];
          if (!fits({ kind: 'read', value: { ...value, items: [...value.items, item] } })) break;
          value.items.push(item);
        }
      }
      const more = index < page.items.length;
      requireMission(!more || value.items.length > 0 || value.coverage.omitted.length > 0, 'PAYLOAD_TOO_LARGE', 'Read fewer items');
      value.coverage.complete = !more && !cursor && !page.missingIds.length&&!value.coverage.omitted.length;
      if(op.input.facet==='html_source')await this.board.agentRead({kind:'read',sectionId:op.input.sectionId,revision:op.input.revision,ids:op.input.ids},guard);
      if (more) value.nextCursor = this.cursor(bind, { revision: page.revision, index, offset });
      result = { kind: 'read', value };
    }
    const response = whiteboardAgentResponse.parse(envelope(present(result)));
    const live = guard();
    requireMission(live.projectId === initial.projectId && live.actor.id === initial.actor.id, 'FORBIDDEN', 'Access changed before return');
    return response;
  }
}
