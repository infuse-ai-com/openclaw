import { WHITEBOARD_AGENT_PROTOCOL, whiteboardAgentApplyInput, whiteboardAgentPostUpdateInput, whiteboardAgentReceiptInput, type WhiteboardSpatialCommand } from '@studio/contracts';
import { digest, requireMission } from '../missions/domain.js';
import type { WhiteboardGuard, WhiteboardService } from './service.js';
import type { CollaborativeWhiteboardService } from './text-service.js';

/** Shared editing owner. Adapters supply verified Registry access, never an arbitrary URL fetch. */
export class WhiteboardAgentEditor {
  constructor(private board: WhiteboardService, private text: CollaborativeWhiteboardService,
    private verifyAssets?: (command: WhiteboardSpatialCommand, guard: WhiteboardGuard) => Promise<void>) {}
  async apply(input: unknown, current: WhiteboardGuard) {
    const parsed = whiteboardAgentApplyInput.safeParse(input);
    requireMission(parsed.success, 'INVALID_INPUT', 'Invalid native board edit');
    const command = parsed.data;
    const payloadHash = digest({ protocol: WHITEBOARD_AGENT_PROTOCOL, ...command });
    const first = current();
    const guard: WhiteboardGuard = () => {
      const live = current();
      requireMission(live.projectId === command.projectId && live.actor.kind === 'agent' && live.actor.id === first.actor.id && live.canWrite &&
        live.nativeCustody?.invocation.toolName === 'studio_whiteboard_apply' && JSON.stringify(live.nativeCustody) === JSON.stringify(first.nativeCustody),
        'FORBIDDEN', 'Current native edit permission is required');
      return { ...live, nativeCommand: { commandId: command.command.commandId, payloadHash } };
    };
    guard();
    const prior = await this.board.agentCommand(command.command.commandId, payloadHash, guard);
    if (prior) return prior;
    if (command.family === 'spatial') {
      const hasAssets = command.command.operations.some(op => op.type === 'createHtml' || op.type === 'createImage' || op.type === 'updateTile' && op.patch.reference);
      if (hasAssets) {
        requireMission(this.verifyAssets, 'ARTIFACTS_UNAVAILABLE', 'Exact Registry source verification is required');
        await this.verifyAssets(command.command, guard); guard();
      }
      await this.text.spatial(command.command, guard);
    } else if (command.family === 'text') await this.text.agentPatch(command.command, guard);
    else await this.text.comment(command.command, guard);
    const result = await this.board.agentCommand(command.command.commandId, payloadHash, guard);
    requireMission(result, 'UNAVAILABLE', 'Reconcile the exact command receipt');
    return result;
  }
  async postUpdate(input:unknown,current:WhiteboardGuard) {
    const parsed=whiteboardAgentPostUpdateInput.safeParse(input);
    requireMission(parsed.success,'INVALID_INPUT','Invalid board update');
    const command=parsed.data,first=current(),payloadHash=digest({protocol:WHITEBOARD_AGENT_PROTOCOL,...command});
    const guard:WhiteboardGuard=()=>{
      const live=current();
      requireMission(live.projectId===command.projectId && live.actor.kind==='agent' && live.actor.id===first.actor.id && live.canWrite &&
        live.nativeCustody?.invocation.toolName==='studio_whiteboard_post_update' && JSON.stringify(live.nativeCustody)===JSON.stringify(first.nativeCustody),
        'FORBIDDEN','Current native update permission required');
      return {...live,nativeCommand:{commandId:command.commandId,payloadHash}};
    };
    return this.board.postAgentUpdate(command,guard);
  }
  /** Full attributed receipt requires current board admission. Narrow revoked-access reconciliation is a separate transport slice. */
  async receipt(input: unknown, guard: WhiteboardGuard) {
    const parsed = whiteboardAgentReceiptInput.safeParse(input);
    requireMission(parsed.success, 'INVALID_INPUT', 'Invalid native receipt query');
    requireMission(guard().projectId === parsed.data.projectId, 'FORBIDDEN', 'Receipt project is unavailable');
    return this.board.agentCommand(parsed.data.commandId, parsed.data.payloadHash, guard);
  }
}
