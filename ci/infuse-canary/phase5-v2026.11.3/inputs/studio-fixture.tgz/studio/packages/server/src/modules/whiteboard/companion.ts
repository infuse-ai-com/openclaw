import { companionBridgeRequest, companionStart, companionStop, companionChatPage, type BridgePrincipal } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
import { MissionError, requireMission } from '../missions/domain.js';
import type { WhiteboardGuard } from './service.js';
const parse=<T>(schema:{safeParse(value:unknown):{success:true;data:T}|{success:false}},value:unknown):T=>{const result=schema.safeParse(value);if(!result.success)throw new MissionError('INVALID_INPUT','Invalid companion request');return result.data;};
type Target={gatewayId:string;agentId:string};
export type CompanionAccess=Target & {projectId:string;memberIds:string[];generation?:number};
/** Conversation authority stays in the mission writer; this map is only a short transport availability observation. */
export class WhiteboardCompanionService {
  private seen=new Map<string,{generation:number;agents:string[];at:number}>();
  constructor(private store:MissionStore,private now=Date.now){}
  private online(target:Target & {generation?:number}){const seen=this.seen.get(target.gatewayId);return !!seen&&(!target.generation||target.generation===seen.generation)&&seen.agents.includes(target.agentId)&&this.now()-seen.at<15000;}
  async page(targets:Array<Target & {generation?:number}>,enabled:boolean,before:number|undefined,guard:WhiteboardGuard) {
    const first=guard();const current=()=>{const live=guard();requireMission(live.projectId===first.projectId&&live.actor.kind==='human'&&live.actor.id===first.actor.id,'FORBIDDEN','Board access changed');};
    const page=await this.store.companion<ReturnType<typeof companionChatPage.parse>>({kind:'page',projectId:first.projectId,before,targets:targets.map(({gatewayId,agentId})=>({gatewayId,agentId}))},current);
    current();return companionChatPage.parse({...page,enabled,agents:page.agents.map(a=>({...a,availability:a.availability==='available'&&!this.online(targets.find(t=>t.gatewayId===a.gatewayId&&t.agentId===a.agentId)??a)?'offline':a.availability}))});
  }
  async start(input:unknown,guard:WhiteboardGuard,allowed:()=>CompanionAccess[]) {
    const parsed=parse(companionStart,input),first=guard();
    const current=()=>{const live=guard();requireMission(live.actor.kind==='human'&&live.canWrite&&live.projectId===first.projectId&&live.actor.id===first.actor.id,'FORBIDDEN','Current board membership required');
      requireMission(allowed().some(a=>a.projectId===live.projectId&&a.gatewayId===parsed.gatewayId&&a.agentId===parsed.agentId&&a.memberIds.includes(live.actor.id)),'FORBIDDEN','This agent is not connected to the board');
      requireMission(this.online(allowed().find(a=>a.projectId===live.projectId&&a.gatewayId===parsed.gatewayId&&a.agentId===parsed.agentId)??parsed),'AGENT_OFFLINE','This agent is disconnected. Your message has not been started.');};
    current();return this.store.companion({kind:'start',projectId:first.projectId,authorId:first.actor.id,input:parsed},current);
  }
  stop(input:unknown,guard:WhiteboardGuard){const parsed=parse(companionStop,input),first=guard();
    return this.store.companion({kind:'stop',projectId:first.projectId,turnId:parsed.turnId},()=>{const live=guard();requireMission(live.actor.kind==='human'&&live.canWrite&&live.projectId===first.projectId&&live.actor.id===first.actor.id,'FORBIDDEN','Current board membership required');});}
  async request(input:unknown,principal:BridgePrincipal,current:()=>BridgePrincipal,allowed:()=>CompanionAccess[]) {
    const request=parse(companionBridgeRequest,input),initial=JSON.stringify(allowed());
    const guard=()=>{const p=current();requireMission(p.gatewayId===principal.gatewayId&&p.generation===principal.generation&&JSON.stringify(p.agents)===JSON.stringify(principal.agents),'FORBIDDEN','Runtime enrollment changed');
      requireMission(JSON.stringify(allowed())===initial,'AUTHORITY_REVOKED','Board access changed before commit');};
    guard();
    const agents=request.operation.type==='poll'?request.operation.agentIds:principal.agents;
    requireMission(agents.every(id=>principal.agents.includes(id)),'FORBIDDEN','Unenrolled companion agent');
    const value=await this.store.companion({kind:'bridge',principal:{...principal,agents},operation:request.operation,allowed:allowed()},guard);guard();
    if(request.operation.type==='poll')this.seen.set(principal.gatewayId,{generation:principal.generation,agents,at:this.now()});
    return {version:2,kind:'whiteboard-companion',value};
  }
}
