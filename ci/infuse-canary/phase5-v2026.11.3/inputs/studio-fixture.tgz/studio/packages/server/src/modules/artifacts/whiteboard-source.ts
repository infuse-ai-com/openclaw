import { createHash } from 'node:crypto';
import type { WhiteboardHtmlReference } from '@studio/contracts';
import { ArtifactRegistryReadClient, ArtifactRegistryReadError, artifactRegistryEndpoint, artifactRegistryTokenFile } from './read-client.js';
/** Exact pinned source, current project/lifecycle checks before and after bytes. No public URLs. */
export class WhiteboardArtifactSource {
  private client:ArtifactRegistryReadClient;
  constructor(config:{registryUrl:string;readTokenFile:string},private projectId:string,signal?:AbortSignal) {
    this.client=new ArtifactRegistryReadClient({baseUrl:artifactRegistryEndpoint(config.registryUrl),tokenFile:artifactRegistryTokenFile(config.readTokenFile),signal});
  }
  private async current(ref:WhiteboardHtmlReference,guard:()=>unknown) {
    guard();const current=await this.client.current(this.projectId,ref.producer,ref.artifactId);guard();
    return current;
  }
  async read(ref:WhiteboardHtmlReference,kind:'html'|'image',guard:()=>unknown) {
    await this.current(ref,guard);
    const manifest=await this.client.manifest(ref.producer,ref.artifactId,ref.revision);guard();
    const mediaType=kind==='html'?'text/html':'image/webp';
    const file=manifest.files.find(f=>f.path===ref.path&&f.mediaType===mediaType);
    if(manifest.project!==this.projectId||!file||file.bytes!==ref.bytes||file.sha256!==ref.sha256||
      kind==='image'&&manifest.kind!=='whiteboard-image')throw new ArtifactRegistryReadError('integrity_failure');
    const result=await this.client.file(ref.producer,ref.artifactId,ref.revision,ref.path);guard();
    if(result.mediaType!==mediaType||result.body.length!==ref.bytes||createHash('sha256').update(result.body).digest('hex')!==ref.sha256)throw new ArtifactRegistryReadError('integrity_failure');
    await this.current(ref,guard);guard();return result.body;
  }
}
