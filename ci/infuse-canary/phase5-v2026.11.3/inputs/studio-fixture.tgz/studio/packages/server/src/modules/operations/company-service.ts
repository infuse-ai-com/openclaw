import type {MissionStore} from '../../persistence/missions/store.js';
import type {CompanyStoreCommand} from '../../persistence/missions/company-signals.js';
export class CompanySignalsService {
 constructor(private store:MissionStore){}
 read<T>(operation:Extract<CompanyStoreCommand,{kind:'read'}>,guard:()=>void):Promise<T>{return this.store.companySignals(operation,guard);}
}
