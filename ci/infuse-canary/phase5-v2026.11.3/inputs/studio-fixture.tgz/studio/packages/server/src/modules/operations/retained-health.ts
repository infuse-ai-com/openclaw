import { createHash } from 'node:crypto';
import {
  missionIdentifier,
  healthDigest,
  healthObject,
  healthCount,
  healthStatuses,
  parseHealthObservation,
  type HealthObservation,
} from '@studio/contracts';
import type { HealthCheckDefinition } from './monitoring-config.js';
import { retainedTimestamp } from './retained-time.js';
export interface RetainedHealthMapping {
  legacyCheckId: string;
  legacyBindingDigest: string;
  validFrom: string;
  validThrough: string;
}
/** Explicit reviewed historical binding; never infers target equivalence from a reused name. */
export function decodeRetainedHealth(
  rows: unknown,
  check: HealthCheckDefinition,
  rawMapping: RetainedHealthMapping,
  policyAt: string,
): {
  observations: HealthObservation[];
  unmapped: number;
  unfinished: number;
  outsideBinding: number;
  outsideRetention: number;
} {
  if (!Array.isArray(rows) || rows.length > 100)
    throw Error('Retained health page exceeds its bound');
  const m = healthObject(rawMapping);
  if (
    Object.keys(m).sort().join(',') !== 'legacyBindingDigest,legacyCheckId,validFrom,validThrough'
  )
    throw Error('Invalid reviewed legacy health binding');
  healthDigest(m.legacyBindingDigest);
  const legacyCheckId = missionIdentifier(m.legacyCheckId),
    from = retainedTimestamp(m.validFrom),
    through = retainedTimestamp(m.validThrough),
    policy = retainedTimestamp(policyAt);
  if (from > through || through > new Date(Date.parse(policy) + 300000).toISOString())
    throw Error('Invalid legacy health validity window');
  const result = {
    observations: [] as HealthObservation[],
    unmapped: 0,
    unfinished: 0,
    outsideBinding: 0,
    outsideRetention: 0,
  };
  for (const raw of rows) {
    const r = healthObject(raw);
    if (r.healthCheckId !== legacyCheckId) {
      result.unmapped++;
      continue;
    }
    missionIdentifier(r.id);
    const startedAt = retainedTimestamp(r.startedAt);
    if (r.finishedAt === undefined || r.finishedAt === null) {
      result.unfinished++;
      continue;
    }
    const finishedAt = retainedTimestamp(r.finishedAt);
    if (startedAt < from || finishedAt > through) {
      result.outsideBinding++;
      continue;
    }
    if (Date.parse(finishedAt) < Date.parse(policy) - 7 * 86400000) {
      result.outsideRetention++;
      continue;
    }
    if (!healthStatuses.includes(r.status as HealthObservation['status']))
      throw Error('Invalid retained source health status');
    const id =
      'bo-health-' +
      createHash('sha256')
        .update(JSON.stringify([legacyCheckId, r.id]))
        .digest('hex');
    result.observations.push(
      parseHealthObservation({
        id,
        checkId: check.id,
        specDigest: check.specDigest,
        status: r.status,
        message: 'Retained Backoffice sample; binding reviewed',
        startedAt,
        finishedAt,
        durationMs:
          r.durationMs === null || r.durationMs === undefined
            ? null
            : healthCount(r.durationMs, 300000),
        attempts: null,
        source: 'backoffice',
      }),
    );
  }
  return result;
}
