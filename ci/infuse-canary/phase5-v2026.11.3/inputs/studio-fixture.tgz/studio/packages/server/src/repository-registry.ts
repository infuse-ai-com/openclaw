import { createHash } from "node:crypto";
import { isAbsolute } from "node:path";
import { readFile } from "node:fs/promises";
import {
  registryDraft,
  registryComparison,
  registryValidationResult,
  projectRegistry,
  stableRegistryJson,
  type FloorActor,
  type RegistryCandidate,
  type RegistryDraft,
  type RegistryComparison,
} from "@studio/contracts";
import { MissionError } from "./modules/missions/domain.js";
import type { GitContributionsConfig } from "./modules/operations/git-config.js";
import type { FloorDirectoryPort } from "./modules/floors/management.js";
import type { KnowledgeManagementConfig } from "./knowledge-management.js";
import { RegistryManagementClient } from './repository-registry-management.js';

const digest = (value: unknown) =>
  createHash("sha256").update(stableRegistryJson(value)).digest("hex");
export interface RegistryCodeConnection {
  baseUrl: string;
  tokenFile: string;
  management?: boolean;
}
export function parseRegistryCodeConnection(
  value: unknown,
): RegistryCodeConnection {
  const v = value as RegistryCodeConnection;
  if (
    !v ||
    typeof v !== "object" ||
    Object.keys(v).some((k) => !["baseUrl", "tokenFile", "management"].includes(k)) ||
    (v.management !== undefined && typeof v.management !== 'boolean') ||
    typeof v.tokenFile !== "string" ||
    !isAbsolute(v.tokenFile)
  )
    throw Error("Invalid registry connection");
  const url = new URL(v.baseUrl);
  if (
    url.origin !== "http://infuse-sourcebot.sourcebot.svc.cluster.local" ||
    url.pathname !== "/" ||
    url.search ||
    url.hash ||
    url.username ||
    url.password
  )
    throw Error("Registry connection must use its exact private endpoint");
  return { baseUrl: url.href, tokenFile: v.tokenFile, ...(v.management === undefined ? {} : { management: v.management }) };
}
/** Server-only requests. URLs are selected by local configuration, never supplied by a manager draft. */
export class RegistryProviderClient {
  constructor(
    private knowledge?: KnowledgeManagementConfig,
    private code?: RegistryCodeConnection,
  ) {}
  management() { return this.code?.management ? new RegistryManagementClient(this.code) : undefined; }
  async request(
    provider: "documentation" | "code",
    operation: "validate" | "compare",
    input: unknown,
    actor: FloorActor,
    guard: () => void,
  ) {
    const config = provider === "documentation" ? this.knowledge : this.code;
    if (!config)
      throw new MissionError(
        "UNAVAILABLE",
        `${provider === "code" ? "Code search" : "Knowledge"} comparison is not connected`,
      );
    const token = (await readFile(config.tokenFile, "utf8")).trim();
    if (!/^[A-Za-z0-9._~+/-]{16,16384}$/.test(token))
      throw new MissionError(
        "UNAVAILABLE",
        "Provider credential is unavailable",
      );
    const path =
      provider === "documentation"
        ? `/api/v1/repositories/registry/${operation}`
        : `/internal/repository-registry/v1/${operation === "validate" ? "validations" : "comparisons"}/code`;
    const identity =
      actor.kind === "human"
        ? ["human", actor.id]
        : ["agent", actor.gatewayId, actor.id];
    guard();
    const response = await fetch(new URL(path, config.baseUrl), {
      method: "POST",
      redirect: "error",
      signal: AbortSignal.timeout(12000),
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "X-Studio-Actor": createHash("sha256")
          .update(JSON.stringify(identity))
          .digest("hex"),
        "X-Studio-Actor-Audit": Buffer.from(JSON.stringify(actor)).toString(
          "base64url",
        ),
      },
      body: JSON.stringify(input),
    });
    const chunks: Uint8Array[] = [];
    let size = 0;
    for await (const chunk of response.body ?? []) {
      size += chunk.length;
      if (size > 1048576)
        throw new MissionError(
          "UNAVAILABLE",
          "Provider comparison exceeds its limit",
        );
      chunks.push(chunk);
    }
    guard();
    if (!response.ok)
      throw new MissionError(
        response.status === 403 ? "FORBIDDEN" : "UNAVAILABLE",
        "Provider validation or comparison is unavailable",
      );
    const value = JSON.parse(Buffer.concat(chunks).toString("utf8")) as {
      version?: unknown;
      mode?: unknown;
      applied?: unknown;
    };
    if (
      value.version !== 1 ||
      value.mode !== "comparison-only" ||
      value.applied !== false
    )
      throw new MissionError(
        "UNAVAILABLE",
        "Provider did not confirm comparison-only mode",
      );
    if (operation === "validate") {
      const validated = registryValidationResult.parse(value),
        request = input as { repository: { id: string } };
      if (
        validated.provider !== provider ||
        validated.repositoryId !== request.repository.id ||
        validated.requestDigest !== digest(input) ||
        validated.validatedAt > Date.now() + 1000 ||
        validated.expiresAt <= Date.now()
      )
        throw new MissionError(
          "UNAVAILABLE",
          "Provider validation is stale or mismatched",
        );
      return validated;
    }
    const comparison = value as typeof value & {
      provider?: unknown;
      baselineId?: unknown;
      transferable?: unknown;
      requestDigest?: unknown;
      baselineDigest?: unknown;
      proposed?: unknown;
    };
    if (
      comparison.provider !== provider ||
      comparison.baselineId !== (input as RegistryComparison).baselineId ||
      comparison.transferable !== false ||
      comparison.requestDigest !== digest(input) ||
      typeof comparison.baselineDigest !== "string" ||
      !/^[a-f0-9]{64}$/u.test(comparison.baselineDigest) ||
      stableRegistryJson(comparison.proposed) !==
        stableRegistryJson(
          projectRegistry(input as RegistryComparison, provider),
        )
    )
      throw new MissionError(
        "UNAVAILABLE",
        "Provider comparison does not match this baseline",
      );
    return comparison;
  }
}

/** This service has no write port. Existing managers can prepare all three capabilities without transferring authority. */
export class RepositoryRegistryService {
  constructor(
    private floors: FloorDirectoryPort,
    private contributions: () => GitContributionsConfig | undefined,
    private providers: RegistryProviderClient,
  ) {}
  async managementCatalog(actor: FloorActor, guard: () => void) {
    const client = this.providers.management?.();
    if (!client) return undefined;
    guard();
    const catalog = await client.catalog(actor, guard);
    guard();
    return { ...catalog, floors: this.floorSnapshot() };
  }
  async command(_input: unknown, _actor: FloorActor, guard: () => void) {
    guard();
    // V1 commands use retired Azure identities. Preserve catalog/receipt reads,
    // but do not mutate stored registry state until a new contract is adopted.
    throw new MissionError('UNAVAILABLE', 'Legacy repository registry writes are retired');
  }
  async receipt(commandId: string, actor: FloorActor, guard: () => void) {
    const client = this.providers.management?.();
    if (!client) throw new MissionError('UNAVAILABLE', 'Registry management is not enabled');
    return client.receipt(commandId, actor, guard);
  }
  private floorSnapshot() {
    return this.floors.projects(true).map((f) => {
      const record = this.floors.record(f.id);
      return {
        id: f.id,
        name: f.name,
        revision: record?.revision ?? 0,
        retired: !!record?.retiredAt,
        repositoryIds: record?.repositories.map((r) => r.id) ?? [],
      };
    });
  }
  catalog(guard: () => void) {
    guard();
    const config = this.contributions();
    return {
      version: 1,
      mode: "comparison-only",
      applied: false,
      floors: this.floorSnapshot(),
      repositories: (config?.repositories ?? []).map((r) => ({
        id: r.repositoryId,
        sourceId: r.sourceId,
        slug: r.name,
        identity: {
          organization: r.organization,
          azureProjectId: r.projectId,
          azureRepositoryId: r.repositoryId,
          name: r.name,
          url: `https://dev.azure.com/${r.organization}/${encodeURIComponent(r.projectName)}/_git/${encodeURIComponent(r.name)}`,
        },
        contributionFloorIds: r.floorIds,
        contributionIntervalSeconds: (config?.intervalMs ?? 900000) / 1000,
      })),
      capabilityState:
        "Draft selections do not indicate current indexing state.",
    };
  }
  private checkFloors(draft: RegistryDraft) {
    const live = this.floorSnapshot();
    if (draft.floors.length !== live.length)
      throw new MissionError(
        "STATE_CONFLICT",
        "Reload the complete floor list",
      );
    for (const proposed of draft.floors) {
      const current = live.find((f) => f.id === proposed.id);
      if (
        !current ||
        current.revision !== proposed.revision ||
        current.retired !== proposed.retired
      )
        throw new MissionError(
          "STATE_CONFLICT",
          "Floor settings changed; reload the preview",
        );
      const other = (ids: string[]) =>
        ids.filter((id) => id !== draft.repository.id).sort();
      if (
        stableRegistryJson(other(current.repositoryIds)) !==
        stableRegistryJson(other(proposed.repositoryIds))
      )
        throw new MissionError(
          "INVALID_INPUT",
          "A repository draft cannot change other associations",
        );
      if (
        current.retired &&
        stableRegistryJson([...current.repositoryIds].sort()) !==
          stableRegistryJson([...proposed.repositoryIds].sort())
      )
        throw new MissionError(
          "INVALID_INPUT",
          "Retired floors cannot be changed in this preview",
        );
    }
  }
  private async validateContributions(
    repo: RegistryCandidate,
    guard: () => void,
  ) {
    const config = this.contributions(),
      source = config?.repositories.find(
        (r) => r.repositoryId === repo.identity.azureRepositoryId,
      );
    if (
      !source ||
      source.projectId !== repo.identity.azureProjectId ||
      source.organization !== repo.identity.organization ||
      source.sourceId !== repo.sourceId
    )
      throw new MissionError(
        "FORBIDDEN",
        "Contributions needs an existing exact provider binding; new credentials are not implied",
      );
    guard();
    throw new MissionError("UNAVAILABLE", "Legacy Contributions provider validation is retired");
  }
  async validateContributionRequest(input: unknown, guard: () => Promise<void>) {
    const { providerValidationRequest } = await import('@studio/contracts');
    const request = providerValidationRequest.parse(input);
    if (request.provider !== 'contributions' || !request.repository.capabilities.contributions.enabled)
      throw new MissionError('INVALID_INPUT', 'Choose enabled Contributions settings');
    await guard();
    const before = digest(this.contributions()), validatedAt = Date.now();
    await this.validateContributions(request.repository, () => {
      if (before !== digest(this.contributions())) throw new MissionError('STATE_CONFLICT', 'Provider configuration changed');
    });
    await guard();
    if (before !== digest(this.contributions())) throw new MissionError('STATE_CONFLICT', 'Provider configuration changed');
    return { version: 1, mode: 'comparison-only', provider: 'contributions', repositoryId: request.repository.id,
      requestDigest: digest(request), validatedAt, expiresAt: validatedAt + 30000, valid: true, applied: false };
  }
  async preview(input: unknown, actor: FloorActor, guard: () => void) {
    const parsed = registryDraft.safeParse(input);
    if (!parsed.success)
      throw new MissionError(
        "INVALID_INPUT",
        "Check repository identity, settings and floors",
      );
    const draft = parsed.data;
    guard();
    this.checkFloors(draft);
    const before = digest({
      floors: this.floorSnapshot(),
      config: this.contributions(),
    });
    const results: Record<string, unknown> = {};
    for (const provider of [
      "documentation",
      "code",
      "contributions",
    ] as const) {
      if (!draft.repository.capabilities[provider].enabled) {
        results[provider] = { state: "disabled-in-draft" };
        continue;
      }
      guard();
      try {
        const value =
          provider === "contributions"
            ? await this.validateContributions(draft.repository, guard)
            : await this.providers.request(
                provider,
                "validate",
                { version: 1, provider, repository: draft.repository },
                actor,
                guard,
              );
        results[provider] = { state: "validated", ...value };
      } catch {
        results[provider] = {
          state: "unavailable",
          message:
            "Provider admission could not be confirmed; activation remains blocked.",
        };
      }
      guard();
    }
    if (
      before !==
      digest({ floors: this.floorSnapshot(), config: this.contributions() })
    )
      throw new MissionError(
        "STATE_CONFLICT",
        "The baseline changed; retry the preview",
      );
    const active = draft.floors
      .filter(
        (f) => !f.retired && f.repositoryIds.includes(draft.repository.id),
      )
      .map((f) => f.id)
      .sort();
    return {
      version: 1,
      mode: "comparison-only",
      applied: false,
      transferable: false,
      draftDigest: digest(draft),
      providers: results,
      proposedFloors: active,
      eligible: {
        documentation: draft.repository.capabilities.documentation.enabled
          ? active
          : [],
        code: draft.repository.capabilities.code.enabled ? active : [],
        contributions: draft.repository.capabilities.contributions.enabled
          ? active
          : [],
      },
      previousDocumentationFloors: this.floorSnapshot()
        .filter(
          (f) => !f.retired && f.repositoryIds.includes(draft.repository.id),
        )
        .map((f) => f.id),
      previousContributionFloors:
        this.contributions()?.repositories.find(
          (r) => r.sourceId === draft.repository.sourceId,
        )?.floorIds ?? [],
    };
  }
  async compare(input: unknown, actor: FloorActor, guard: () => void) {
    const parsed = registryComparison.safeParse(input);
    if (!parsed.success)
      throw new MissionError(
        "INVALID_INPUT",
        "A complete, unique comparison baseline is required",
      );
    const proposal = parsed.data;
    guard();
    const before = digest({
      config: this.contributions(),
      floors: this.floorSnapshot(),
    });
    const liveFloors = this.floorSnapshot();
    if (
      proposal.floors.length !== liveFloors.length ||
      proposal.floors.some((f) => {
        const live = liveFloors.find((row) => row.id === f.id);
        return (
          !live || live.revision !== f.revision || live.retired !== f.retired
        );
      })
    )
      throw new MissionError(
        "STATE_CONFLICT",
        "Floor settings changed; reload the complete comparison",
      );
    const proposed = projectRegistry(proposal, "contributions");
    const changes: Array<{ id: string; fields: string[] }> = [];
    const remaining = new Map(
      (this.contributions()?.repositories ?? []).map((r) => [
        r.repositoryId,
        r,
      ]),
    );
    for (const row of proposed) {
      const old = remaining.get(row.identity.azureRepositoryId),
        fields: string[] = [];
      if (!old) {
        if (row.settings.enabled) fields.push("added");
      } else {
        if (
          old.projectId !== row.identity.azureProjectId ||
          old.organization !== row.identity.organization
        )
          fields.push("identity");
        if (old.sourceId !== row.sourceId) fields.push("sourceId");
        if (
          stableRegistryJson([...old.floorIds].sort()) !==
          stableRegistryJson(row.floorIds)
        )
          fields.push("floors");
        if (
          !row.settings.enabled ||
          this.contributions()?.enabled !== true ||
          (row.settings.enabled &&
            row.settings.intervalSeconds * 1000 !==
              this.contributions()?.intervalMs)
        )
          fields.push("settings");
      }
      if (fields.length) changes.push({ id: row.id, fields });
      remaining.delete(row.identity.azureRepositoryId);
    }
    for (const row of remaining.values())
      changes.push({ id: row.repositoryId, fields: ["omitted"] });
    const providers: Record<string, unknown> = {
      contributions: {
        proposed,
        changes,
        baselineDigest: before,
        identityValidation: "separate-provider-check-required",
        retainedHistory: "separate-inventory-check-required",
      },
    };
    for (const provider of ["documentation", "code"] as const) {
      guard();
      try {
        providers[provider] = await this.providers.request(
          provider,
          "compare",
          proposal,
          actor,
          guard,
        );
      } catch {
        providers[provider] = { state: "unavailable", complete: false };
      }
      guard();
    }
    if (
      before !==
      digest({ config: this.contributions(), floors: this.floorSnapshot() })
    )
      throw new MissionError(
        "STATE_CONFLICT",
        "Contributions configuration changed",
      );
    return {
      version: 1,
      mode: "comparison-only",
      applied: false,
      transferable: false,
      baselineId: proposal.baselineId,
      providers,
    };
  }
}
