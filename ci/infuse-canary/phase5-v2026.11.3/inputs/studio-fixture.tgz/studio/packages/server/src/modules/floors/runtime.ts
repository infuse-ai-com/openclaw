import { freezeFloorSnapshot, type FloorSnapshot } from './snapshot.js';
import { randomUUID } from 'node:crypto';
import type { NativeRouteIdentity } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
import type { FloorRuntimeRecord } from '../../persistence/missions/floor-runtime.js';
import { digest, MissionError, requireMission } from '../missions/domain.js';

export interface FloorRuntimeSpec {
  projectId: string; authorityId: string; installationId: string; origin: string; anchorChannelId: string;
  roles: Array<Omit<NativeRouteIdentity, 'channelId'> & { channelId?: string }>;
  configuredMemberUserIds?: string[];
  memberProfileIds: string[]; members: Array<{ profileId: string; userId: string }>;
  enrollments: Array<{ gatewayId: string; generation: number; agentIds: string[] }>;
}
export interface FloorChannelProvider {
  ensureChannel(spec: FloorRuntimeSpec, role: string, custodyKey: string, existing?: string): Promise<string>;
  verifyBot(spec: FloorRuntimeSpec, route: NativeRouteIdentity): Promise<void>;
  ensureMember(spec: FloorRuntimeSpec, channelId: string, userId: string): Promise<void>;
  removeMember(spec: FloorRuntimeSpec, channelId: string, userId: string): Promise<void>;
}
export const floorRuntimeSpecHash = (spec: FloorRuntimeSpec) => digest(spec);

/** Application reconciliation; HTTP/Kubernetes transports do not own this state. */
export class FloorRuntimeService {
  private records: FloorSnapshot<FloorRuntimeRecord[]> = Object.freeze([]);
  constructor(private store: MissionStore, private provider: FloorChannelProvider) {}
  async refresh() { this.records = freezeFloorSnapshot(await this.store.floorRuntime<FloorRuntimeRecord[]>({ kind: 'list' }, () => {})); }
  /** Current immutable record; never retain across an asynchronous admission. */
  readRecord(id: string) { return this.records.find(record => record.projectId === id); }
  readCurrent(spec: FloorRuntimeSpec) { const record = this.readRecord(spec.projectId); return record?.specHash === floorRuntimeSpecHash(spec) ? record : undefined; }
  record(id: string): FloorRuntimeRecord | undefined { return structuredClone(this.readRecord(id)) as FloorRuntimeRecord | undefined; }
  current(spec: FloorRuntimeSpec) { const record = this.record(spec.projectId); return record?.specHash === floorRuntimeSpecHash(spec) ? record : undefined; }
  private async save(record: FloorRuntimeRecord, guard: () => void) {
    const next = { ...record, revision: record.revision + 1, updatedAt: new Date().toISOString() };
    try { await this.store.floorRuntime({ kind: 'save', expectedRevision: record.revision, record: next }, guard); }
    finally { await this.refresh(); }
    guard(); return next;
  }
  /** One caller serializes bounded attempts. Every external effect has saved custody first. */
  async reconcile(readSpec: () => FloorRuntimeSpec): Promise<void> {
    const spec = readSpec(), specHash = floorRuntimeSpecHash(spec);
    const guard = () => requireMission(floorRuntimeSpecHash(readSpec()) === specHash, 'AUTHORITY_REVOKED', 'Floor connection configuration changed');
    let record = this.record(spec.projectId);
    if (record?.specHash === specHash && record.state === 'ready') return;
    record ??= { projectId: spec.projectId, revision: 0, specHash, custodyKey: randomUUID(), state: 'provisioning', routes: [], memberUserIds: spec.configuredMemberUserIds ?? [], updatedAt: '' };
    try {
      if (!record.revision || record.specHash !== specHash || record.state === 'blocked') {
        record = await this.save({ ...record, specHash, state: 'provisioning', errorCode: undefined }, guard);
      }
      if (record.state === 'provisioning') {
        const routes: NativeRouteIdentity[] = [];
        for (const role of spec.roles) {
          guard();
          const prior = record.routes.find(route => route.role === role.role);
          const channelId = await this.provider.ensureChannel(spec, role.role, record.custodyKey, role.channelId ?? prior?.channelId);
          guard();
          const route = { ...role, channelId };
          await this.provider.verifyBot(spec, route); guard();
          routes.push(route);
          // Retain every channel immediately; a lost later response resumes the same allocation.
          record = await this.save({ ...record, routes: [...routes, ...record.routes.filter(old => !routes.some(next => next.role === old.role))] }, guard);
        }
        const coordinator = routes.find(route => route.role === 'coordinator');
        requireMission(coordinator, 'CONFIGURATION', 'The shared team needs a coordinator');
        for (const route of routes) for (const bot of new Set([route.nativeBotUserId, coordinator.nativeBotUserId])) {
          guard(); await this.provider.ensureMember(spec, route.channelId, bot); guard();
        }
        record = await this.save({ ...record, routes, state: 'protecting' }, guard);
      }
      const protectedRoutes = await this.store.floorRuntime<boolean>({ kind: 'protected', scope: {
        projectId: spec.projectId, installationId: spec.installationId, origin: spec.origin,
        routes: record.routes, enrollments: spec.enrollments,
      } }, guard);
      guard(); if (!protectedRoutes) return;
      const members = [...new Set(spec.members.map(member => member.userId))];
      const previous = record.memberUserIds;
      // Save attempted membership before sending so revocation can reconcile a lost add response.
      record = await this.save({ ...record, memberUserIds: [...new Set([...previous, ...members])] }, guard);
      for (const route of record.routes) {
        for (const removed of previous.filter(id => !members.includes(id))) {
          guard(); await this.provider.removeMember(spec, route.channelId, removed); guard();
        }
        for (const id of members) { guard(); await this.provider.ensureMember(spec, route.channelId, id); guard(); }
      }
      record = await this.save({ ...record, state: 'ready', memberUserIds: members, errorCode: undefined }, guard);
    } catch (error) {
      const code = error instanceof MissionError ? error.code : '';
      if (['AUTHORITY_REVOKED', 'FORBIDDEN', 'VERSION_CONFLICT', 'NOT_FOUND', 'BUSY'].includes(code)) throw error;
      const errorCode = code === 'CHANNEL_CONFLICT' ? 'CHANNEL_CONFLICT' : code === 'IDENTITY_UNAVAILABLE' ? 'IDENTITY_UNAVAILABLE' : 'CONNECTION_UNAVAILABLE';
      await this.save({ ...record, state: 'blocked', errorCode }, guard);
    }
  }
}
export type { FloorRuntimeRecord } from '../../persistence/missions/floor-runtime.js';
