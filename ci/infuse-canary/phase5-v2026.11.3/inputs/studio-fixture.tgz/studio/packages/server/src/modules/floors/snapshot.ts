/** JSON records published by the sole persistence worker. Freeze only on refresh. */
export type FloorSnapshot<T> = { readonly [K in keyof T]: FloorSnapshot<T[K]> };
export function freezeFloorSnapshot<T>(value: T): FloorSnapshot<T> {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) freezeFloorSnapshot(child);
    Object.freeze(value);
  }
  return value as FloorSnapshot<T>;
}
