// Adapted from Backoffice 657df061 server/artifact-registry/read-client.ts.
// Read-only; no feed fallback, raw tokens, writes or lifecycle credentials.
import { readFile } from "node:fs/promises";
import type { ArtifactManifest, ArtifactRecord, ArtifactPage } from "@studio/contracts";
import { computeArtifactRevision } from "./revision.js";

const ID = /^[a-z0-9][a-z0-9._-]{0,127}$/;
const DIGEST = /^[a-f0-9]{64}$/;
const MAX_JSON_BYTES = 2 * 1024 * 1024;
const MAX_FILE_BYTES = 25 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 3_000;
const MAX_RECORDS = 1_000;
const ALLOWED_MEDIA_TYPES = new Set([
  "application/javascript", "application/json", "application/pdf", "application/zip",
  "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp",
  "text/css", "text/html", "text/javascript", "text/markdown", "text/plain",
]);
const MANIFEST_KEYS = new Set([
  "schema", "producer", "artifactId", "title", "kind", "summary", "project", "tags",
  "intendedConsumer", "missionId", "taskId", "sourceRef", "revision", "createdAt", "files",
]);
const MANIFEST_FILE_KEYS = new Set(["path", "mediaType", "bytes", "sha256"]);
const RECORD_KEYS = new Set(["producer", "artifactId", "revision", "state", "title", "kind", "createdAt", "trashedAt"]);
const SENSITIVE_METADATA = /(?:\b(?:authorization|cookie|password|secret|token)\s*[:=]|https?:\/\/[^/\s:@]+:[^/\s@]+@)/i;

export type ArtifactRegistryReadErrorCode =
  | "configuration_invalid"
  | "authentication_unavailable"
  | "forbidden"
  | "integrity_failure"
  | "not_found"
  | "registry_unavailable";

export class ArtifactRegistryReadError extends Error {
  constructor(readonly code: ArtifactRegistryReadErrorCode, message = "artifact registry read failed") {
    super(message);
    this.name = "ArtifactRegistryReadError";
  }
}

export type ArtifactRegistryReadConfig = {
  baseUrl: URL;
  tokenFile: string;
  signal?: AbortSignal;
};

export function artifactRegistryEndpoint(rawUrl: string | undefined): URL {
  if (!rawUrl) throw new ArtifactRegistryReadError("configuration_invalid", "artifact registry URL is missing");
  let baseUrl: URL;
  try {
    baseUrl = new URL(rawUrl);
  } catch {
    throw new ArtifactRegistryReadError("configuration_invalid", "artifact registry URL is invalid");
  }
  const localTestHost = baseUrl.hostname === "127.0.0.1" || baseUrl.hostname === "localhost" || baseUrl.hostname === "[::1]";
  const clusterHost = baseUrl.hostname.endsWith(".svc") || baseUrl.hostname.endsWith(".svc.cluster.local");
  if ((!clusterHost && !localTestHost)
    || (baseUrl.protocol !== "https:" && baseUrl.protocol !== "http:")
    || baseUrl.username || baseUrl.password || baseUrl.search || baseUrl.hash || baseUrl.pathname !== "/") {
    throw new ArtifactRegistryReadError("configuration_invalid", "artifact registry URL is not an approved internal endpoint");
  }
  return baseUrl;
}

export function artifactRegistryTokenFile(value: string | undefined): string {
  if (!value || !value.startsWith("/") || /[\u0000-\u001f\u007f]/.test(value)) {
    throw new ArtifactRegistryReadError("configuration_invalid", "artifact registry token file path is invalid");
  }
  return value;
}

function safePath(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= 512
    && !/[\u0000-\u001f\u007f]/.test(value) && !value.includes("\\") && !value.startsWith("/") && !value.split("/").some((segment) => !segment || segment === "." || segment === "..");
}

function validTimestamp(value: unknown): value is string {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}

function safeMetadata(value: unknown, maximum: number, required = false): value is string {
  return typeof value === "string" && value === value.trim() && value.length <= maximum
    && (!required || value.length > 0) && !/[\u0000-\u001f\u007f]/.test(value) && !SENSITIVE_METADATA.test(value);
}

function parseManifest(value: unknown): ArtifactManifest {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new ArtifactRegistryReadError("integrity_failure");
  const candidate = value as Partial<ArtifactManifest>;
  if (Object.keys(candidate).some((key) => !MANIFEST_KEYS.has(key))
    || candidate.schema !== "infuse.artifact/v1" || typeof candidate.producer !== "string" || !ID.test(candidate.producer)
    || typeof candidate.artifactId !== "string" || !ID.test(candidate.artifactId)
    || typeof candidate.revision !== "string" || !DIGEST.test(candidate.revision)
    || !safeMetadata(candidate.title, 160, true)
    || typeof candidate.kind !== "string" || !ID.test(candidate.kind)
    || !safeMetadata(candidate.summary, 1_000)
    || (candidate.project !== null && !safeMetadata(candidate.project, 128))
    || !Array.isArray(candidate.tags) || candidate.tags.length > 16
    || candidate.tags.some((tag) => typeof tag !== "string" || !ID.test(tag))
    || new Set(candidate.tags).size !== candidate.tags.length
    || (candidate.intendedConsumer !== null && (typeof candidate.intendedConsumer !== "string" || !ID.test(candidate.intendedConsumer)))
    || (candidate.missionId !== null && (typeof candidate.missionId !== "string" || !ID.test(candidate.missionId)))
    || (candidate.taskId !== null && (typeof candidate.taskId !== "string" || !ID.test(candidate.taskId)))
    || (candidate.sourceRef !== null && !safeMetadata(candidate.sourceRef, 512))
    || !validTimestamp(candidate.createdAt) || !Array.isArray(candidate.files) || candidate.files.length === 0 || candidate.files.length > 100) {
    throw new ArtifactRegistryReadError("integrity_failure");
  }
  const seen = new Set<string>();
  let totalBytes = 0;
  for (const file of candidate.files) {
    if (!file || typeof file !== "object" || Array.isArray(file)
      || Object.keys(file).some((key) => !MANIFEST_FILE_KEYS.has(key)) || !safePath(file.path)
      || seen.has(file.path) || typeof file.mediaType !== "string" || !ALLOWED_MEDIA_TYPES.has(file.mediaType)
      || !Number.isSafeInteger(file.bytes) || file.bytes < 0 || file.bytes > MAX_FILE_BYTES
      || typeof file.sha256 !== "string" || !DIGEST.test(file.sha256)) {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
    seen.add(file.path);
    totalBytes += file.bytes;
  }
  if (totalBytes > MAX_FILE_BYTES || computeArtifactRevision(candidate as ArtifactManifest, candidate.files) !== candidate.revision) {
    throw new ArtifactRegistryReadError("integrity_failure");
  }
  return candidate as ArtifactManifest;
}

function parseRecord(value: unknown): ArtifactRecord {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new ArtifactRegistryReadError("integrity_failure");
  const candidate = value as Partial<ArtifactRecord>;
  if (Object.keys(candidate).some((key) => !RECORD_KEYS.has(key))
    || typeof candidate.producer !== "string" || !ID.test(candidate.producer)
    || typeof candidate.artifactId !== "string" || !ID.test(candidate.artifactId)
    || typeof candidate.revision !== "string" || !DIGEST.test(candidate.revision)
    || (candidate.state !== "active" && candidate.state !== "bin" && candidate.state !== "purged")
    || !safeMetadata(candidate.title, 160, true) || typeof candidate.kind !== "string" || !ID.test(candidate.kind)
    || !validTimestamp(candidate.createdAt)
    || (candidate.trashedAt !== null && !validTimestamp(candidate.trashedAt))) {
    throw new ArtifactRegistryReadError("integrity_failure");
  }
  return candidate as ArtifactRecord;
}

async function boundedBody(response: Response, maximum: number): Promise<Buffer> {
  const declared = Number(response.headers.get("content-length"));
  if (Number.isFinite(declared) && declared > maximum) throw new ArtifactRegistryReadError("integrity_failure");
  if (!response.body) return Buffer.alloc(0);
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of response.body as unknown as AsyncIterable<Uint8Array>) {
    const body = Buffer.from(chunk);
    size += body.length;
    if (size > maximum) throw new ArtifactRegistryReadError("integrity_failure");
    chunks.push(body);
  }
  return Buffer.concat(chunks);
}

function mapStatus(status: number): ArtifactRegistryReadError {
  if (status === 401) return new ArtifactRegistryReadError("authentication_unavailable");
  if (status === 403) return new ArtifactRegistryReadError("forbidden");
  if (status === 404) return new ArtifactRegistryReadError("not_found");
  return new ArtifactRegistryReadError("registry_unavailable");
}

export class ArtifactRegistryReadClient {

  constructor(private readonly config: ArtifactRegistryReadConfig) {
    if (!config.baseUrl || !config.tokenFile) {
      throw new ArtifactRegistryReadError("configuration_invalid");
    }
  }

  private async loadToken(): Promise<string> {
    try {
      const body = await readFile(this.config.tokenFile!, "utf8");
      const token = body.endsWith("\n") ? body.slice(0, -1) : body;
      if (token.length < 32 || token.length > 512 || /[\u0000-\u0020\u007f]/.test(token)) throw new Error("invalid");
      return token;
    } catch {
      throw new ArtifactRegistryReadError("authentication_unavailable");
    }
  }

  private async request(pathname: string, maximum = MAX_JSON_BYTES): Promise<{ body: Buffer; mediaType: string }> {
    const url = new URL(pathname, this.config.baseUrl!);
    let response: Response;
    try {
      response = await fetch(url, {
        headers: { authorization: `Bearer ${await this.loadToken()}` },
        cache: "no-store",
        redirect: "error",
        signal: this.config.signal ? AbortSignal.any([this.config.signal, AbortSignal.timeout(REQUEST_TIMEOUT_MS)]) : AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch (error) {
      if (error instanceof ArtifactRegistryReadError) throw error;
      throw new ArtifactRegistryReadError("registry_unavailable");
    }
    if (!response.ok) throw mapStatus(response.status);
    try {
      return { body: await boundedBody(response, maximum), mediaType: response.headers.get("content-type")?.split(";", 1)[0] ?? "application/octet-stream" };
    } catch (error) {
      if (error instanceof ArtifactRegistryReadError) throw error;
      throw new ArtifactRegistryReadError("registry_unavailable");
    }
  }

  private async json(pathname: string): Promise<unknown> {
    const response = await this.request(pathname);
    if (response.mediaType !== "application/json") throw new ArtifactRegistryReadError("integrity_failure");
    try {
      return JSON.parse(response.body.toString("utf8"));
    } catch {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
  }

  async list(state: "active" | "bin" | "all" = "active"): Promise<ArtifactRecord[]> {
    const value = await this.json(`/v1/artifacts?state=${state}`);
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== 1
      || !Array.isArray((value as { artifacts?: unknown }).artifacts)) {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
    const records = (value as { artifacts: unknown[] }).artifacts;
    if (records.length > MAX_RECORDS) throw new ArtifactRegistryReadError("integrity_failure");
    const parsed = records.map(parseRecord);
    if (state !== "all" && parsed.some((record) => record.state !== state)) {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
    return parsed;
  }

  async library(project:string,state:'active'|'bin',filters:Record<string,string>):Promise<ArtifactPage> {
    if(!ID.test(project)||Object.keys(filters).some(k=>!['cursor','q','scope','mission'].includes(k))
      ||filters.cursor!==undefined&&(!/^[1-9][0-9]{0,3}$/.test(filters.cursor)||Number(filters.cursor)>1000)
      ||filters.q!==undefined&&(filters.q.length>200||/[\u0000-\u001f\u007f]/.test(filters.q))
      ||filters.scope!==undefined&&!['all','mission','standalone'].includes(filters.scope)
      ||filters.mission!==undefined&&!ID.test(filters.mission))throw new ArtifactRegistryReadError('not_found');
    const value=await this.json('/v1/library?'+new URLSearchParams({...filters,project,state}));
    if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2||!('artifacts'in value)||!Array.isArray(value.artifacts)||value.artifacts.length>24||!('nextCursor'in value))throw new ArtifactRegistryReadError('integrity_failure');
    const next=value.nextCursor;
    if(next!==null&&(typeof next!=='string'||!/^[1-9][0-9]{0,3}$/.test(next)||Number(next)>1000||Number(next)<=Number(filters.cursor??0)))throw new ArtifactRegistryReadError('integrity_failure');
    const artifacts=value.artifacts.map(parseManifest),ids=new Set<string>();
    for(const m of artifacts){const id=m.producer+'/'+m.artifactId;
      if(m.project!==project||ids.has(id)||filters.mission&&m.missionId!==filters.mission||filters.scope==='mission'&&!m.missionId||filters.scope==='standalone'&&m.missionId)throw new ArtifactRegistryReadError('integrity_failure');ids.add(id);
    }
    return {artifacts,nextCursor:next as string|null};
  }

  async history(producer: string, artifactId: string): Promise<ArtifactManifest[]> {
    if (!ID.test(producer) || !ID.test(artifactId)) throw new ArtifactRegistryReadError("configuration_invalid");
    const value = await this.json(`/v1/artifacts/${encodeURIComponent(producer)}/${encodeURIComponent(artifactId)}/revisions`);
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== 1
      || !Array.isArray((value as { revisions?: unknown }).revisions)) {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
    const revisions = (value as { revisions: unknown[] }).revisions;
    if (revisions.length > MAX_RECORDS) throw new ArtifactRegistryReadError("integrity_failure");
    const manifests = revisions.map(parseManifest);
    if (manifests.some((manifest) => manifest.producer !== producer || manifest.artifactId !== artifactId)) {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
    return manifests;
  }

  /** Shared current project/lifecycle policy for exact Studio and whiteboard reads. */
  async current(project: string, producer: string, artifactId: string): Promise<ArtifactManifest> {
    if (!ID.test(project) || !ID.test(producer) || !ID.test(artifactId)) throw new ArtifactRegistryReadError("configuration_invalid");
    const value = await this.json(`/v1/artifacts/${encodeURIComponent(producer)}/${encodeURIComponent(artifactId)}/current?${new URLSearchParams({ project })}`);
    const manifest = parseManifest(value);
    if (manifest.producer !== producer || manifest.artifactId !== artifactId || manifest.project !== project) {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
    return manifest;
  }

  async manifest(producer: string, artifactId: string, revision: string): Promise<ArtifactManifest> {
    if (!ID.test(producer) || !ID.test(artifactId) || !DIGEST.test(revision)) throw new ArtifactRegistryReadError("configuration_invalid");
    const value = await this.json(`/v1/artifacts/${encodeURIComponent(producer)}/${encodeURIComponent(artifactId)}/revisions/${revision}`);
    const manifest = parseManifest(value);
    if (manifest.producer !== producer || manifest.artifactId !== artifactId || manifest.revision !== revision) {
      throw new ArtifactRegistryReadError("integrity_failure");
    }
    return manifest;
  }

  async file(producer: string, artifactId: string, revision: string, filePath: string): Promise<{ body: Buffer; mediaType: string }> {
    if (!ID.test(producer) || !ID.test(artifactId) || !DIGEST.test(revision) || !safePath(filePath)) {
      throw new ArtifactRegistryReadError("configuration_invalid");
    }
    return this.request(`/v1/artifacts/${encodeURIComponent(producer)}/${encodeURIComponent(artifactId)}/revisions/${revision}/files/${filePath.split("/").map(encodeURIComponent).join("/")}`, MAX_FILE_BYTES);
  }
}
