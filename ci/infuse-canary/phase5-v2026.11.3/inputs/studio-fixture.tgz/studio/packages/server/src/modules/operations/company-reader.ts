import {healthObject as object,parseCompanySignalInput,providerTimeZone,type CompanySignalInput,type ProviderUsageData} from '@studio/contracts';
import type {CompanySignalConfig,CompanySignalsConfig} from './company-config.js';
import {boundedOperationsFile,readOperationsKubernetes,readOperationsDeployment} from './source-io.js';
import {decodeRuntimeObservation} from './agent-feeds.js';
import {CompanySourceError} from './company-normalize.js';
export type CompanySignalReader=(source:CompanySignalConfig,config:CompanySignalsConfig,signal:AbortSignal)=>Promise<CompanySignalInput>;
/** The backend accepts sanitized producer feeds, never executes a personal/provider CLI or imports private sessions. */
export function decodeProviderSignalFeed(raw:unknown,source:Extract<CompanySignalConfig,{kind:'provider-usage'}>):CompanySignalInput {
 try {
  const feed=object(raw);if(feed.schemaVersion!==1||feed.kind!=='provider-usage'||feed.sourceId!==source.sourceId||feed.resourceId!==source.resourceId)throw Error('Provider feed identity mismatch');
  const input=parseCompanySignalInput({...feed,specDigest:source.specDigest}),data=input.data as ProviderUsageData;
  if(data.provider!==source.provider||data.owner!==source.owner||source.bucketTimeZone&&providerTimeZone(data.bucketTimeZone)!==source.bucketTimeZone)throw Error('Provider ownership/timezone mismatch');
  return input;
 }catch{throw new CompanySourceError('SOURCE_INVALID');}
}
export function decodeCompanyRuntime(source:Extract<CompanySignalConfig,{kind:'runtime'}>,deployment:unknown,pods:unknown,observedAt:string):CompanySignalInput {
 try{const metadata=object(object(deployment).metadata);if(metadata.name!==source.transport.deployment||metadata.namespace!==source.transport.namespace)throw Error('Runtime source identity mismatch');return parseCompanySignalInput({sourceId:source.sourceId,resourceId:source.resourceId,kind:'runtime',specDigest:source.specDigest,...decodeRuntimeObservation(deployment,pods,observedAt)});}catch{throw new CompanySourceError('SOURCE_INVALID');}
}
export const readCompanySignalSource:CompanySignalReader=async(source,config,signal)=>{
 try {
  signal.throwIfAborted();const t=source.transport;
  // Transitional configuration remains readable; retired pipeline sources never contact the old provider.
  if(source.kind==='pipeline')throw new CompanySourceError('SOURCE_UNAVAILABLE');
  if(source.kind==='provider-usage') {
   let raw:string;
   if(t.type==='file')raw=await boundedOperationsFile(t.path,1048576,signal);
   else if(t.type==='config-map') {
    if(!config.cluster)throw new CompanySourceError('SOURCE_UNAVAILABLE');
    const response=object(await readOperationsKubernetes(config.cluster,`/api/v1/namespaces/${encodeURIComponent(t.namespace)}/configmaps/${encodeURIComponent(t.name)}`,signal)),metadata=object(response.metadata);
    if(metadata.name!==t.name||metadata.namespace!==t.namespace)throw new CompanySourceError('SOURCE_INVALID');
    const value=object(response.data)[t.key];if(typeof value!=='string')throw new CompanySourceError('SOURCE_MISSING');if(Buffer.byteLength(value)>1048576)throw new CompanySourceError('SOURCE_LIMIT');raw=value;
   }else throw new CompanySourceError('SOURCE_INVALID');
   return decodeProviderSignalFeed(JSON.parse(raw),source);
  }
  if(!config.cluster||source.transport.type!=='runtime')throw new CompanySourceError('SOURCE_UNAVAILABLE');
  const {deployment,pods}=await readOperationsDeployment(config.cluster,source.transport,signal);
  return decodeCompanyRuntime(source,deployment,pods,new Date().toISOString());
 }catch(error){if(error instanceof CompanySourceError)throw error;signal.throwIfAborted();const code=(error as {code?:string}).code;if(code==='ENOENT')throw new CompanySourceError('SOURCE_MISSING');if(code==='SOURCE_LIMIT')throw new CompanySourceError('SOURCE_LIMIT');if(code==='SOURCE_INVALID'||error instanceof SyntaxError)throw new CompanySourceError('SOURCE_INVALID');throw new CompanySourceError('SOURCE_UNAVAILABLE');}
};
