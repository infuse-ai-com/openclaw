import { WHITEBOARD_AGENT_XML, whiteboardAgentResult, type WhiteboardAgentResult,
  type WhiteboardAgentXml } from '@studio/contracts';

import { whiteboardRelationships } from './agent-relationships.js';

export type WhiteboardXmlRead = Extract<WhiteboardAgentResult, { kind: 'context' | 'read' | 'search' | 'changes' }>;
const tag = (key: string) => key.replace(/[A-Z]/g, c => '-' + c.toLowerCase());
// XML 1.0 cannot represent all accepted JSON strings. Preserve those code units
// losslessly, including unpaired surrogates, rather than replacing saved content.
const xmlCharacters = /^[\u0009\u000A\u000D\u0020-\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}]*$/u;
const escape = (text: string) => text.replace(/[&<>"'\r\n\t]/g, c => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;',
  '\r': '&#13;', '\n': '&#10;', '\t': '&#9;',
})[c]!);
function field(name: string, value: unknown): string {
  if (value === undefined) return '';
  if (value === null) return `<${name} null="true"/>`;
  if (typeof value === 'string' && !xmlCharacters.test(value)) {
    return `<${name} encoding="base64-utf16le">${Buffer.from(value, 'utf16le').toString('base64')}</${name}>`;
  }
  const content = Array.isArray(value) ? value.map(v => field('entry', v)).join('') :
    typeof value === 'object' ? Object.entries(value).map(([k, v]) => field(tag(k), v)).join('') : escape(String(value));
  return `<${name}>${content}</${name}>`;
}
function itemXml(located: Extract<WhiteboardXmlRead, {kind:'read'}>['value']['items'][number]): string {
  const { item, ...detail } = located;
  const { kind, id, sectionId, revision, ...saved } = item;
  const attributes = `id="${escape(id)}" section-id="${escape(sectionId)}" revision="${revision}"`;
  const body = Object.entries(saved).filter(([k]) => !['x','y','width','height','locked'].includes(k)).map(([k,v]) => field(tag(k), v)).join('');
  const bounds = 'x' in item ? `<bounds x="${item.x}" y="${item.y}" width="${item.width}" height="${item.height}"/>` : '';
  const locked = 'locked' in item || kind !== 'connection' ? ` locked="${'locked' in item && item.locked === true}"` : '';
  const visual = kind === 'html' || kind === 'image' ? '<visual-content status="not-inspected"/>' : '';
  return `<${kind} ${attributes}${locked}>${body}${bounds}${visual}${Object.entries(detail).map(([k,v]) => field(tag(k),v)).join('')}</${kind}>`;
}

/** Pure projection: accepts only validated results, performs no reads or effects. */
export function projectWhiteboardXml(input: WhiteboardXmlRead): WhiteboardAgentXml {
  const parsed = whiteboardAgentResult.parse(input);
  if (!['context','read','search','changes'].includes(parsed.kind)) throw new Error('Not a whiteboard read');
  const { kind, value } = parsed as WhiteboardXmlRead;
  const { projectId, revision, nextCursor, ...data } = value;
  const metadata = Object.entries(data).filter(([k]) => k !== 'items').map(([k,v]) => field(tag(k),v)).join('');
  const items = 'items' in value ? `<items>${value.items.map(itemXml).join('')}</items>` : '';
  const mode = kind === 'context' ? 'metadata-only' : kind === 'search' ? 'excerpts-only' : kind === 'changes' ? 'events-only' : 'saved-fragments';
  const continuation = kind === 'changes' ? 'continuation="poll-or-next"' : `has-more="${nextCursor !== null}"`;
  const pagination = `<page coverage="${mode}" ${continuation}/>${field('next-cursor',nextCursor)}`;
  const relationships = 'items' in value ? relationshipXml(value.items.map(row => row.item), revision) : '';
  const document = `<board-context version="1" operation="${kind}" project-id="${escape(projectId)}" revision="${revision}" coordinates="section-local" units="canvas">${metadata}${items}${relationships}${pagination}</board-context>`;
  return { format: WHITEBOARD_AGENT_XML, operation: kind, projectId, revision, document };
}

function relationshipXml(items: Parameters<typeof whiteboardRelationships>[0], revision: number): string {
  const {items:relations,...coverage}=whiteboardRelationships(items);
  const attributes=(values:Record<string,unknown>)=>Object.entries(values).map(([k,v])=>` ${tag(k)}="${escape(String(v))}"`).join('');
  return `<relationships revision="${revision}"${attributes(coverage)}>${relations.map(({kind,...relation})=>`<${kind}${attributes(relation)}/>`).join('')}</relationships>`;
}
