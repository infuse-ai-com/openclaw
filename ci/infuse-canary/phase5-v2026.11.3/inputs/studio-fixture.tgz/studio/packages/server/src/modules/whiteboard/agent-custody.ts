import type { WhiteboardAgentInvocation } from '@studio/contracts';

/** Transport-authenticated metadata, never model input. The writer derives origin. */
export interface WhiteboardNativeCommand { commandId: string; payloadHash: string }

export interface WhiteboardAgentCustody {
  gatewayId: string;
  managedExecutionEnabled: boolean;
  companionExecutionEnabled?: boolean;
  companionMemberIds?: string[];
  enrollmentGeneration?: number;
  invocation: WhiteboardAgentInvocation;
}
