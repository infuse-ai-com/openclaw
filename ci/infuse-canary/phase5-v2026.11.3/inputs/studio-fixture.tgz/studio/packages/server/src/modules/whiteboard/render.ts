import { shapeLabelLayout, whiteboardNoteColors } from '@studio/contracts';
import type { WhiteboardSpatialItem,WhiteboardRender } from '@studio/contracts';
const escape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]!));
/** Deterministic overview. No HTML, script execution, external images or network. */
export function renderWhiteboard(input:{projectId:string;sectionId:string;revision:number;bounds:WhiteboardRender['bounds'];items:WhiteboardSpatialItem[];truncated:boolean;missingIds:string[];omittedLinks:string[]}):WhiteboardRender {
  const omitted:Array<{id:string;reason:string}>=input.omittedLinks.map(id=>({id,reason:'Connection path is not drawn by the overview renderer'}));const nodes:WhiteboardRender['nodes']=[];
  const shapes=input.items.flatMap(item=> {
    if(item.kind==='connection')return [];
    const bounds={x:item.x,y:item.y,width:item.width,height:item.height};nodes.push({id:item.id,bounds});
    if(item.kind==='stroke'){const label=shapeLabelLayout(item.label??'',item.width,item.height);if(item.label&&label.truncated)omitted.push({id:item.id,reason:'Shape label exceeds bounds'});return [`<polyline points="${item.points.map(([x,y])=>`${item.x+x*item.width},${item.y+y*item.height}`).join(' ')}" fill="none" stroke="${{ink:'#282625',orange:'#c86432',blue:'#2459a6',red:'#a93434'}[item.color]}" stroke-width="${item.thickness}"/>${item.label?`<text text-anchor="middle" dominant-baseline="central" font-size="${label.size}">${label.lines.map((line,index)=>`<tspan x="${item.x+item.width/2}" y="${item.y+item.height/2+(index-(label.lines.length-1)/2)*label.size*1.3}">${escape(line)}</tspan>`).join('')}</text>`:''}`];}
    if(item.kind==='image')omitted.push({id:item.id,reason:'Image bytes are not embedded in the overview renderer'});
    if(item.kind==='html' || item.kind==='section')omitted.push({id:item.id,reason:item.kind==='html'?'HTML interior is not executed by the overview renderer':'Nested section interior is outside this section'});
    const text='text' in item?item.text:`${item.kind==='html'?'Pinned HTML':item.kind==='image'?'Pinned image':'Nested section'} · ${item.id}`;
    const fontSize=item.kind==='note'&&text.length<=80?24:14,lineHeight=fontSize*1.4;
    const columns=Math.max(1,Math.min(45,Math.floor((item.width-32)/(fontSize*.65))));
    const lines=text.split('\n').flatMap(line=>line.match(new RegExp(`.{1,${columns}}`,'gu'))??['']);
    const count=Math.max(0,Math.min(20,Math.floor((item.height-65)/lineHeight)));
    if(lines.length>count)omitted.push({id:item.id,reason:'Body text exceeds tile bounds'});
    return [`<g><rect x="${item.x}" y="${item.y}" width="${item.width}" height="${item.height}" rx="12" fill="${item.kind==='note'?whiteboardNoteColors[item.noteColor??'yellow']:'#ffffff'}" stroke="#999"/><clipPath id="clip-${escape(item.id)}"><rect x="${item.x+12}" y="${item.y+12}" width="${item.width-24}" height="${item.height-24}"/></clipPath><g clip-path="url(#clip-${escape(item.id)})"><text x="${item.x+16}" y="${item.y+30}" font-size="18" font-weight="bold">${escape(item.title)}</text>${lines.slice(0,count).map((line,index)=>`<text x="${item.x+16}" y="${item.y+58+lineHeight*index}" font-size="${fontSize}">${escape(line)}</text>`).join('')}</g></g>`];
  });
  if(input.truncated)omitted.push({id:'root',reason:'Region exceeds the 100-item render limit; use a smaller region'});
  const b=input.bounds;return {projectId:input.projectId,sectionId:input.sectionId,revision:input.revision,bounds:b,mediaType:'image/svg+xml',
    image:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${b.x} ${b.y} ${b.width} ${b.height}" width="1600" height="1000"><rect x="${b.x}" y="${b.y}" width="${b.width}" height="${b.height}" fill="#f6f5f2"/><g font-family="sans-serif" fill="#282625">${shapes.join('')}</g></svg>`,nodes,
    coverage:{complete:!omitted.length && !input.missingIds.length,omitted,missingIds:input.missingIds}};
}
