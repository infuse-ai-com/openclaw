# Persistence adapters

Implement module repository interfaces here when the first persistent feature is built. Database-specific clients and transactions remain server-side. Migrations and seeds belong in `/database`. No database client is configured yet.
