import { createHash, randomUUID } from 'node:crypto';
import { open, rename, unlink } from 'node:fs/promises';
import { dirname, isAbsolute } from 'node:path';
import {
  RegistryPolicyLease,
  registryAcknowledgement,
  registryConsumerConfig,
  type RegistryAcknowledgement,
  type RegistryConsumerConfig,
  type PolicyConsumer,
  type PolicyWatermark,
  type RegistryMcpScope,
  type RegistryRequestScope,
} from '@studio/contracts';

/** Bounded failure categories; exception payloads, paths and credentials stay private. */
export type RegistryFailureReason =
  | 'checkpoint_storage'
  | 'credential'
  | 'provider_unavailable'
  | 'policy_invalid'
  | 'policy_expired'
  | 'binding_mismatch';
export class RegistryPolicyFailure extends Error {
  constructor(readonly reason: RegistryFailureReason) {
    super('registry_policy_unavailable');
  }
}
export function registryFailure(error: unknown): RegistryPolicyFailure {
  if (error instanceof RegistryPolicyFailure) {
    return error;
  }
  const message = error instanceof Error ? error.message : '';
  return new RegistryPolicyFailure(
    message === 'registry_policy_unavailable' ||
    message === 'registry_policy_expired'
      ? 'policy_expired'
      : 'policy_invalid',
  );
}

const hash = (value: string) =>
  createHash('sha256').update(value).digest('hex');

export async function boundedRegistryFile(
  path: string,
  limit: number,
): Promise<string> {
  const file = await open(path, 'r');
  try {
    if ((await file.stat()).size > limit) {
      throw Error('registry_file_too_large');
    }
    const data = await file.readFile('utf8');
    if (Buffer.byteLength(data) > limit) {
      throw Error('registry_file_too_large');
    }
    return data;
  } finally {
    await file.close();
  }
}
export async function atomicRegistryFile(
  path: string,
  data: string,
): Promise<void> {
  const temporary = `${path}.${randomUUID()}.tmp`;
  try {
    const file = await open(temporary, 'wx', 0o600);
    try {
      await file.writeFile(data);
      await file.sync();
    } finally {
      await file.close();
    }
    await rename(temporary, path);
    const parent = await open(dirname(path), 'r');
    try {
      await parent.sync();
    } finally {
      await parent.close();
    }
  } finally {
    await unlink(temporary).catch(() => undefined);
  }
}
/** A private complete-view pull. Each process has a distinct durable watermark path. */
export class RegistryPolicyClient {
  private acknowledgements = new Map<string, { digest: string; at: number }>();
  private lastAttempt = Number.NEGATIVE_INFINITY;
  private refreshing: Promise<void> | undefined;
  private lease: RegistryPolicyLease;
  private failure: RegistryPolicyFailure | undefined;
  private constructor(
    private readonly config: RegistryConsumerConfig,
    watermark: unknown,
    private readonly fetcher: typeof fetch,
  ) {
    this.lease = new RegistryPolicyLease(
      config.consumer,
      config.epoch,
      hash,
      async (next: PolicyWatermark) => {
        try {
          await atomicRegistryFile(config.watermarkFile, JSON.stringify(next));
        } catch {
          throw new RegistryPolicyFailure('checkpoint_storage');
        }
      },
      watermark,
    );
  }
  static async create(
    input: unknown,
    fetcher: typeof fetch = fetch,
  ): Promise<RegistryPolicyClient> {
    const config = registryConsumerConfig.parse(input);
    let watermark: unknown;
    try {
      watermark = JSON.parse(
        await boundedRegistryFile(config.watermarkFile, 8192),
      );
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') {
        throw new RegistryPolicyFailure('checkpoint_storage');
      }
    }
    try {
      return new RegistryPolicyClient(config, watermark, fetcher);
    } catch {
      throw new RegistryPolicyFailure('checkpoint_storage');
    }
  }
  private async pull(): Promise<void> {
    const token = (
      await boundedRegistryFile(this.config.tokenFile, 512).catch(() => {
        throw new RegistryPolicyFailure('credential');
      })
    ).trim();
    if (!/^[A-Za-z0-9_-]{43,128}$/u.test(token)) {
      throw new RegistryPolicyFailure('credential');
    }
    const response = await this.fetcher(
      `${this.config.baseUrl}/internal/repository-registry/v1/policies/${this.config.consumer}`,
      {
        redirect: 'error',
        signal: AbortSignal.timeout(8000),
        headers: { authorization: `Bearer ${token}` },
      },
    ).catch(() => {
      throw new RegistryPolicyFailure('provider_unavailable');
    });
    if (!response.ok) {
      await response.body?.cancel();
      throw new RegistryPolicyFailure(
        response.status === 401 || response.status === 403
          ? 'credential'
          : 'provider_unavailable',
      );
    }
    const chunks: Uint8Array[] = [];
    let size = 0;
    for await (const chunk of response.body ?? []) {
      size += chunk.byteLength;
      if (size > 4 * 1024 * 1024) {
        throw Error('registry_policy_too_large');
      }
      chunks.push(chunk);
    }
    await this.lease.install(
      JSON.parse(Buffer.concat(chunks).toString('utf8')),
    );
  }
  async snapshot() {
    if (!this.refreshing && performance.now() - this.lastAttempt >= 30000) {
      this.lastAttempt = performance.now();
      this.refreshing = this.pull()
        .then(() => {
          this.failure = undefined;
        })
        .catch((error) => {
          const failure = registryFailure(error);
          if (this.failure?.reason !== failure.reason) {
            console.warn(
              JSON.stringify({
                event: 'registry_policy_failed',
                consumer: this.config.consumer,
                reason: failure.reason,
              }),
            );
          }
          this.failure = failure;
        })
        .finally(() => {
          this.refreshing = undefined;
        });
    }
    // A failed refresh retains only the original unexpired lease, never a baked manifest.
    await this.refreshing?.catch(() => undefined);
    try {
      return { policy: this.lease.current(), guard: this.lease.guard() };
    } catch {
      throw this.failure ?? new RegistryPolicyFailure('policy_expired');
    }
  }
  /** Acknowledgements describe observed provider state; failure never becomes a successful install. */
  async acknowledge(input: RegistryAcknowledgement): Promise<void> {
    const ack = registryAcknowledgement.parse(input),
      policy = this.current();
    if (
      !policy.repositories.some(
        (row) => row.id === ack.repositoryId && row.revision === ack.revision,
      )
    )
      throw Error('registry_acknowledgement_stale');
    const fingerprint = hash(JSON.stringify(ack)),
      previous = this.acknowledgements.get(ack.repositoryId);
    if (
      previous?.digest === fingerprint &&
      performance.now() - previous.at < 60000
    )
      return;
    const token = (
      await boundedRegistryFile(this.config.tokenFile, 512)
    ).trim();
    if (!/^[A-Za-z0-9_-]{43,128}$/u.test(token))
      throw Error('registry_credential_invalid');
    const response = await this.fetcher(
      `${this.config.baseUrl}/internal/repository-registry/v1/acknowledgements`,
      {
        method: 'POST',
        redirect: 'error',
        signal: AbortSignal.timeout(8000),
        headers: {
          authorization: `Bearer ${token}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify(ack),
      },
    );
    await response.body?.cancel();
    if (!response.ok) throw Error('registry_acknowledgement_unavailable');
    this.acknowledgements.set(ack.repositoryId, {
      digest: fingerprint,
      at: performance.now(),
    });
  }
  current() {
    try {
      return this.lease.current();
    } catch {
      throw this.failure ?? new RegistryPolicyFailure('policy_expired');
    }
  }
  /** This credential stays on the fixed Sourcebot origin and only grants its configured consumer. */
  async nativeHeaders(
    scope: RegistryMcpScope | RegistryRequestScope,
    origin: string,
  ): Promise<Record<string, string>> {
    if (origin !== this.config.baseUrl) throw Error('registry_origin_mismatch');
    if (
      scope.audience !== this.config.consumer ||
      !['code', 'shared'].includes(scope.audience)
    )
      throw Error('registry_consumer_mismatch');
    const current = this.current();
    if (
      scope.registry.epoch !== current.epoch ||
      scope.registry.revision !== current.revision
    )
      throw Error('registry_scope_changed');
    const token = (
      await boundedRegistryFile(this.config.tokenFile, 512)
    ).trim();
    if (!/^[A-Za-z0-9_-]{43,128}$/u.test(token))
      throw Error('registry_credential_invalid');
    return {
      authorization: `Bearer ${token}`,
      'x-infuse-code-scope': Buffer.from(JSON.stringify(scope)).toString(
        'base64url',
      ),
    };
  }
  async nativeRead(
    scope: RegistryMcpScope | RegistryRequestScope,
    body: unknown,
    signal?: AbortSignal,
  ): Promise<Uint8Array> {
    const url = new URL(scope.target, this.config.baseUrl);
    if (url.origin !== this.config.baseUrl || !url.pathname.startsWith('/api/'))
      throw Error('registry_origin_mismatch');
    const headers = await this.nativeHeaders(scope, url.origin);
    const response = await this.fetcher(url, {
      method: scope.method,
      redirect: 'error',
      signal: signal
        ? AbortSignal.any([signal, AbortSignal.timeout(12000)])
        : AbortSignal.timeout(12000),
      headers: {
        ...headers,
        'content-type': 'application/json',
        accept: 'application/json',
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    if (
      !response.ok ||
      response.headers.get('content-type')?.split(';')[0] !== 'application/json'
    ) {
      await response.body?.cancel();
      throw Error('registry_code_unavailable');
    }
    const chunks: Uint8Array[] = [];
    let size = 0;
    for await (const chunk of response.body ?? []) {
      size += chunk.byteLength;
      if (size > 4 * 1024 * 1024) throw Error('registry_result_too_large');
      chunks.push(chunk);
    }
    return Buffer.concat(chunks);
  }
}

const clients = new Map<string, Promise<RegistryPolicyClient>>();
export async function configuredRegistryClient(
  path: string,
  consumer: PolicyConsumer,
) {
  if (!isAbsolute(path)) {
    throw Error('registry_configuration_invalid');
  }
  const raw = await boundedRegistryFile(path, 16384);
  const config = registryConsumerConfig.parse(JSON.parse(raw));
  if (config.consumer !== consumer) {
    throw Error('registry_consumer_mismatch');
  }
  // A configuration change never inherits a different credential/epoch's lease.
  const key = `${path}:${hash(raw)}`;
  let client = clients.get(key);
  if (!client) {
    client = RegistryPolicyClient.create(config);
    for (const oldKey of clients.keys()) {
      if (oldKey.startsWith(`${path}:`)) {
        clients.delete(oldKey);
      }
    }
    clients.set(key, client);
    client.catch(() => {
      clients.delete(key);
    });
  }
  return client;
}
