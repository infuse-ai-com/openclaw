import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { whiteboardImageUpload, whiteboardImageUploaded } from '@studio/contracts';
import type { WhiteboardGuard } from './service.js';
import { MissionError, requireMission } from '../missions/domain.js';

export interface WhiteboardImagePublisherConfig { registryUrl:string; producer:string; tokenFiles:Record<string,string>; floorTokenFile?:string }
let inFlight=0;
/** Registry is the sole asset owner. This adapter never stores image bytes in central mission storage. */
export async function publishWhiteboardImage(input:unknown,config:WhiteboardImagePublisherConfig,guard:WhiteboardGuard) {
  const parsed=whiteboardImageUpload.safeParse(input);
  requireMission(parsed.success,'INVALID_INPUT','Choose a PNG, JPEG or WebP image up to 10 MB');
  const principal=guard(); requireMission(principal.canWrite && principal.actor.kind==='human','FORBIDDEN','Image upload requires human board access');
  const tokenFile=config.tokenFiles[principal.projectId] ?? config.floorTokenFile; requireMission(tokenFile,'ARTIFACTS_UNAVAILABLE','Image uploads are not enabled for this project');
  const check=()=>{const live=guard();requireMission(live.canWrite && live.projectId===principal.projectId && live.actor.kind===principal.actor.kind && live.actor.id===principal.actor.id,'FORBIDDEN','Image upload access changed');};
  const bytes=Buffer.from(parsed.data.contentBase64,'base64');
  requireMission(bytes.length>0 && bytes.length<=10*1024*1024 && bytes.toString('base64')===parsed.data.contentBase64,'INVALID_INPUT','Choose an image up to 10 MB');
  requireMission(inFlight<2,'ARTIFACTS_UNAVAILABLE','Two images are being processed. Try again shortly.');
  inFlight++;
  try {
    const token=(await readFile(tokenFile,'utf8')).trim();
    requireMission(token.length>=32 && token.length<=512 && !/[\s\u0000-\u001f\u007f]/.test(token),'ARTIFACTS_UNAVAILABLE','Image upload credentials are unavailable');
    const artifactId='image-'+createHash('sha256').update(JSON.stringify([principal.projectId,principal.actor.id,parsed.data.uploadId])).digest('hex');
    check();
    const response=await fetch(new URL('/v1/images',config.registryUrl),{method:'POST',redirect:'error',signal:AbortSignal.timeout(90_000),headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify({project:principal.projectId,artifactId,contentBase64:parsed.data.contentBase64})});
    if(!response.ok)throw new MissionError(response.status===400?'INVALID_INPUT':'ARTIFACTS_UNAVAILABLE',response.status===400?'This image could not be decoded. Choose a still PNG, JPEG or WebP image.':'Image storage could not confirm the upload. Retry this image.');
    requireMission(Number(response.headers.get('content-length'))>0 && Number(response.headers.get('content-length'))<65536,'ARTIFACTS_UNAVAILABLE','Invalid image receipt');
    const result=await response.json() as {manifest:{producer:string;artifactId:string;project:string;kind:string;revision:string;files:Array<{path:string;mediaType:string;sha256:string;bytes:number}>};width:number;height:number};
    const m=result.manifest;
    requireMission(m?.producer===config.producer && m.artifactId===artifactId && m.project===principal.projectId && m.kind==='whiteboard-image' && m.files?.length===1 && m.files[0]?.mediaType==='image/webp' && m.files[0].path==='image.webp','ARTIFACTS_UNAVAILABLE','Image receipt does not match this upload');
    const file=m.files[0]!; check();
    return whiteboardImageUploaded.parse({reference:{producer:m.producer,artifactId:m.artifactId,revision:m.revision,path:file.path,sha256:file.sha256,bytes:file.bytes},width:result.width,height:result.height});
  } catch(error) {
    if(error instanceof MissionError)throw error;
    throw new MissionError('ARTIFACTS_UNAVAILABLE','Image storage could not confirm the upload. Retry this image.');
  } finally {inFlight--;}
}
