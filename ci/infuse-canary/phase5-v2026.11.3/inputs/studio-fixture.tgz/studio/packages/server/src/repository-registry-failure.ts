import { MissionError } from './modules/missions/domain.js';
import { RegistryPolicyFailure, registryFailure as sharedFailure } from './repository-registry-policy-client.js';
export type { RegistryPolicyFailure } from './repository-registry-policy-client.js';
/** Translate only known adapter failures, never arbitrary provider messages. */
export function registryFailure(error: unknown): RegistryPolicyFailure {
  if (error instanceof MissionError && error.details?.capability === 'contributions' && ['checkpoint_storage','credential','provider_unavailable','policy_invalid','policy_expired','binding_mismatch'].includes(String(error.details.reason))) return new RegistryPolicyFailure(error.details.reason as ConstructorParameters<typeof RegistryPolicyFailure>[0]);
  const message = error instanceof Error ? error.message : '';
  if (['registry_transfer_required', 'provider_binding_mismatch', 'floor_not_transferred', 'provider_capacity'].includes(message)) return new RegistryPolicyFailure('binding_mismatch');
  if (message === 'credentials_not_configured') return new RegistryPolicyFailure('credential');
  return sharedFailure(error);
}
