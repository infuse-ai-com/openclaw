import {randomUUID} from 'node:crypto';
import type {CompanySignalInput} from '@studio/contracts';
import type {MissionStore} from '../../persistence/missions/store.js';
import type {OperationJob} from '../../persistence/missions/operations.js';
import {companySignalDefinition,type CompanySignalsConfig} from './company-config.js';
import {readCompanySignalSource,type CompanySignalReader} from './company-reader.js';
import {CompanySourceError} from './company-normalize.js';
/** A single fair source per tick and one durable global lease. No page-triggered collection or second writer. */
export class CompanySignalsCollector {
 private owner=randomUUID();private timer?:ReturnType<typeof setInterval>;private active?:Promise<void>;private abort?:AbortController;private stopping=false;
 constructor(private store:MissionStore,private readConfig:()=>CompanySignalsConfig|undefined,private reader:CompanySignalReader=readCompanySignalSource){}
 start():void{if(this.timer)return;this.stopping=false;this.timer=setInterval(()=>{void this.tick().catch(()=>{});},1000);this.timer.unref();void this.tick().catch(()=>{});}
 async stop():Promise<void>{this.stopping=true;if(this.timer)clearInterval(this.timer);this.timer=undefined;this.abort?.abort();await this.active?.catch(()=>{});}
 tick():Promise<void>{if(this.active)return this.active;if(this.stopping)return Promise.resolve();this.active=this.collectOne().finally(()=>{this.active=undefined;});return this.active;}
 private async collectOne():Promise<void> {
  const config=this.readConfig();if(!config?.enabled||!config.sources.length)return;
  const snapshot=JSON.stringify(config),inventoryGuard=()=>{if(this.stopping||JSON.stringify(this.readConfig())!==snapshot)throw Object.assign(Error('Company source admission changed'),{code:'AUTHORITY_REVOKED'});};
  const inventory=await this.store.companySignals<({specDigest:string;nextRunAt:number}|null)[]>({kind:'inventory',definitions:config.sources.map(companySignalDefinition)},inventoryGuard),now=Date.now();
  const due=config.sources.map((source,index)=>({source,next:inventory[index]?.specDigest===source.specDigest?inventory[index]?.nextRunAt??0:0})).filter(item=>item.next<=now).sort((a,b)=>a.next-b.next||a.source.sourceId.localeCompare(b.source.sourceId))[0];if(!due)return;
  const source=due.source,fingerprint=JSON.stringify([source,config.cluster]),guard=()=>{const current=this.readConfig();if(this.stopping||!current?.enabled||JSON.stringify([current.sources.find(s=>s.sourceId===source.sourceId),current.cluster])!==fingerprint)throw Object.assign(Error('Company source authority changed'),{code:'AUTHORITY_REVOKED'});};
  const id='company-sources',current=await this.store.operations<OperationJob|null>({kind:'get',id},guard);
  if(current?.state==='running'&&(current.leaseUntil??0)>now||(current?.nextRunAt??0)>now)return;
  const running:OperationJob={id,kind:'company-signals',source:'studio-company-signals',revision:(current?.revision??0)+1,state:'running',checkpoint:{sourceId:source.sourceId},updatedAt:new Date(now).toISOString(),leaseOwner:this.owner,leaseUntil:now+60000};
  try{await this.store.operations({kind:'save',expectedRevision:current?.revision??0,job:running},guard);}catch(error){if(['BUSY','VERSION_CONFLICT'].includes(String((error as {code?:string}).code)))return;throw error;}
  this.abort=new AbortController();const timeout=setTimeout(()=>this.abort?.abort(),10000);timeout.unref();
  let input:CompanySignalInput|undefined,errorCode='SOURCE_UNAVAILABLE',retryAfterMs=30000;
  try{input=await this.reader(source,config,this.abort.signal);}catch(error){guard();if(error instanceof CompanySourceError){errorCode=error.code;retryAfterMs=error.retryAfterMs;}}
  finally{clearTimeout(timeout);this.abort=undefined;}
  const progress=(success:boolean)=>({expectedRevision:running.revision,job:{...running,revision:running.revision+1,state:success?'succeeded' as const:'failed' as const,updatedAt:new Date().toISOString(),leaseUntil:undefined,nextRunAt:Date.now()+250,checkpoint:{sourceId:source.sourceId,...(success?{lastSuccessAt:new Date().toISOString()}:{})},...(success?{}:{lastError:errorCode})}});
  if(input)try{await this.store.companySignals({kind:'ingest',definition:companySignalDefinition(source),input,progress:progress(true)},guard);return;}catch(error){if(!['INVALID_INPUT','IDEMPOTENCY_CONFLICT'].includes(String((error as {code?:string}).code)))throw error;errorCode='SOURCE_INVALID';}
  const state=errorCode==='SOURCE_MISSING'?'missing':errorCode==='SOURCE_INVALID'||errorCode==='SOURCE_LIMIT'?'invalid':'unavailable';
  await this.store.companySignals({kind:'attempt',definition:companySignalDefinition(source),state,retryAfterMs,progress:progress(false)},guard);
 }
}
