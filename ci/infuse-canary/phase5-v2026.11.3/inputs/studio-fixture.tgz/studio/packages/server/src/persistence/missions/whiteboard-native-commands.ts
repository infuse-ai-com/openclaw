import { postAgentUpdate } from './whiteboard-agent-updates.js';
import { boardRevision } from './whiteboard-spatial.js';
import { activeFloorProject } from './floor-project.js';
import type { StorageDatabase } from './sql.js';
import { whiteboardAgentProvenance, whiteboardAgentUpdate, whiteboardId, whiteboardReceipt, type WhiteboardAgentResult } from '@studio/contracts';
import { requireMission } from '../../modules/missions/domain.js';
import type { WhiteboardStoreOperation } from './whiteboard.js';
import type { TextStoreOperation } from './whiteboard-text.js';

type Operation = WhiteboardStoreOperation | TextStoreOperation;
type Origin = ReturnType<typeof whiteboardAgentProvenance.parse>['origin'];
export type NativeCommandReceipt = Extract<WhiteboardAgentResult, { kind: 'apply' }>['value'];
export async function nativeCommandReceipt(db: StorageDatabase, op: Operation, commandId: string, payloadHash: string): Promise<NativeCommandReceipt | null> {
  whiteboardId.parse(commandId);
  requireMission(/^[a-f0-9]{64}$/.test(payloadHash), 'INVALID_INPUT', 'Invalid command hash');
  const row = (await db.prepare(`SELECT r.body,n.payload_hash,n.provenance FROM whiteboard_receipts r
    LEFT JOIN whiteboard_native_commands n ON n.project_id=r.project_id AND n.actor=r.actor AND n.command_id=r.command_id
    WHERE r.project_id=? AND r.actor=? AND r.command_id=?`).get(op.projectId, JSON.stringify([op.actor.kind, op.actor.id]), commandId));
  if (!row) return null;
  requireMission(row.payload_hash === payloadHash, 'IDEMPOTENCY_CONFLICT', 'Command ID belongs to a different payload');
  return { payloadHash, receipt: whiteboardReceipt.parse(JSON.parse(String(row.body))),
    provenance: whiteboardAgentProvenance.parse(JSON.parse(String(row.provenance))) };
}
/** Runs within the existing writer transaction, including its final live grant.
 * Provenance and the receipt commit or roll back together; retries never replace origin. */
export async function nativeBoardOperation(db: StorageDatabase, projects: string[], op: Operation, origin: Origin | undefined, execute: () => Promise<unknown>): Promise<unknown> {
  if (op.nativeCommand || op.kind === 'agent-command') requireMission((await activeFloorProject(db, projects, op.projectId)),
    'FORBIDDEN', 'Whiteboard project is unavailable');
  if (op.kind === 'agent-command') {
    requireMission(origin && op.nativeCustody && op.actor.kind === 'agent', 'FORBIDDEN', 'Native custody is required');
    return (await execute());
  }
  if (op.kind === 'agent-update') return await postAgentUpdate(db,op,origin);
  if (!op.nativeCommand) return (await execute());
  requireMission(origin && op.nativeCustody && op.actor.kind === 'agent' &&
    op.nativeCustody.invocation.toolName === 'studio_whiteboard_apply', 'FORBIDDEN', 'Exact native apply custody is required');
  if (!['apply', 'submit', 'comment', 'receipt'].includes(op.kind)) return (await execute());
  const commandId = op.kind === 'apply' ? op.command.commandId : 'commandId' in op ? op.commandId : undefined;
  requireMission(commandId === op.nativeCommand.commandId, 'FORBIDDEN', 'Command custody changed');
  const previous = (await nativeCommandReceipt(db, op, commandId, op.nativeCommand.payloadHash));
  if (previous) { requireMission(previous.provenance.invocation.toolName === 'studio_whiteboard_apply','IDEMPOTENCY_CONFLICT','Command belongs to another operation'); return previous.receipt; }
  if (op.kind === 'receipt') return null;
  const receipt = whiteboardReceipt.parse((await execute()));
  requireMission(receipt.commandId === commandId && receipt.actor.id === op.actor.id && receipt.projectId === op.projectId,
    'FORBIDDEN', 'Receipt does not match native command');
  const provenance = whiteboardAgentProvenance.parse({ actor: op.actor, gatewayId: op.nativeCustody.gatewayId,
    invocation: op.nativeCustody.invocation, origin });
  (await db.prepare("INSERT INTO whiteboard_native_commands (project_id,actor,command_id,payload_hash,provenance) VALUES (?,?,?,?,?)").run(op.projectId,
    JSON.stringify([op.actor.kind, op.actor.id]), commandId, op.nativeCommand.payloadHash, JSON.stringify(provenance)));
  return receipt;
}

/** Only outcome metadata; deliberately independent of current floor/managed-run access. */
export async function nativeCommandOutcome(db: StorageDatabase, op: Extract<Operation, {kind:'agent-outcome'}>) {
  const call = op.nativeCustody;
  requireMission(call && call.invocation.toolName === 'studio_whiteboard_receipt' && op.actor.kind === 'agent', 'FORBIDDEN', 'Native receipt custody required');
  const result = (await nativeCommandReceipt(db, op, op.commandId, op.payloadHash));
  if (!result) return {status:'unknown' as const, commandId:op.commandId};
  requireMission(result.provenance.gatewayId === call.gatewayId && result.provenance.invocation.agentId === call.invocation.agentId,
    'FORBIDDEN', 'Receipt belongs to another identity');
  const receipt=result.receipt;
  return {status:'recorded' as const, commandId:op.commandId, payloadHash:op.payloadHash, outcome:receipt.status, revision:receipt.revision, at:receipt.at};
}
export async function nativeChanges(db:StorageDatabase, op:Extract<Operation,{kind:'agent-changes'}>) {
  const revision=(await boardRevision(db,op.projectId));
  requireMission(Number.isSafeInteger(op.after)&&op.after>=0&&op.after<=revision&&Number.isInteger(op.limit)&&op.limit>0&&op.limit<=30,'INVALID_INPUT','Invalid change window');
  const floor=(await db.prepare('SELECT MIN(revision) n FROM whiteboard_v2_events WHERE project_id=?').get(op.projectId))?.n;
  requireMission(floor===null||floor===undefined||op.after>=Number(floor)-1,'RESYNC_REQUIRED','Change window expired');
  const rows=await db.prepare(`SELECT e.revision,e.body,n.payload_hash,n.provenance,u.body update_body FROM whiteboard_v2_events e
    LEFT JOIN whiteboard_native_commands n ON n.project_id=e.project_id
      AND n.command_id=studio_control_json(e.body)->'receipt'->>'commandId'
      AND n.actor::jsonb=jsonb_build_array(studio_control_json(e.body)->'receipt'->'actor'->>'kind',studio_control_json(e.body)->'receipt'->'actor'->>'id')
    LEFT JOIN whiteboard_agent_updates u ON u.project_id=e.project_id AND u.revision=e.revision
    WHERE e.project_id=? AND e.revision>? ORDER BY e.revision LIMIT ?`).all(op.projectId,op.after,op.limit);
  const events=rows.map(row=>row.update_body?{kind:'update' as const,value:whiteboardAgentUpdate.parse(JSON.parse(String(row.update_body)))}:({kind:'command' as const,value:{receipt:whiteboardReceipt.parse(JSON.parse(String(row.body)).receipt),
    payloadHash:row.payload_hash?String(row.payload_hash):null, provenance:row.provenance?whiteboardAgentProvenance.parse(JSON.parse(String(row.provenance))):null}}));
  return {projectId:op.projectId,revision,events,eventRevisions:rows.map(row=>Number(row.revision))};
}
