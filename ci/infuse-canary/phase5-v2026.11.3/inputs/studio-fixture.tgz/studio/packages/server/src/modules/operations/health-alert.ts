import type {AlertDelivery,HealthEpisode,PublicHealthCheck} from '@studio/contracts';
export interface HealthAlertPayload {channel:'#monitoring';username:'agent-infra';icon_url:string;text:string}
/** Escape display text before fixed mentions/markdown are added. Never render a target URL. */
function label(value:string):string {return value.replace(/@/g,'＠').replace(/[\\`*_~<>\[\]#!|]/g,'').slice(0,256);}
export function healthAlertPayload(check:PublicHealthCheck,episode:HealthEpisode,delivery:AlertDelivery):HealthAlertPayload {
 const recovery=delivery.transition==='recovery';
 return {channel:'#monitoring',username:'agent-infra',icon_url:'https://mattermost.infuse-ai.com/api/v4/users/36mrck1137ryim1tnio4c7geqw/image',
  text:`${recovery?'🟢 Recovery':'🔴 Incident · @fito'} — ${label(check.resourceName)} / ${label(check.name)}\nObserved: ${delivery.createdAt} · ${recovery?'healthy':episode.severity}\nEpisode: ${episode.id} · transition: ${delivery.id}`};
}
export type HealthSendOutcome={state:'sent'|'failed'|'uncertain';outcome:string;retryAfterMs?:number};
export function healthWebhookUrl(value:unknown,allowFixture=false):URL {
 if(typeof value!=='string'||value.length>2048)throw Error('Missing health webhook secret');
 let url:URL;try{url=new URL(value);}catch{throw Error('Invalid protected Mattermost webhook');}
 if(url.username||url.password||url.search||url.hash||!/^\/hooks\/[A-Za-z0-9_-]+$/.test(url.pathname)||
  !(url.protocol==='https:'&&url.hostname==='mattermost.infuse-ai.com'&&!url.port||allowFixture&&url.protocol==='http:'&&url.hostname==='127.0.0.1'))throw Error('Invalid protected Mattermost webhook');
 return url;
}
export async function sendHealthAlert(url:URL,payload:HealthAlertPayload,signal:AbortSignal,fetcher:typeof fetch=fetch):Promise<HealthSendOutcome> {
 const combined=AbortSignal.any([signal,AbortSignal.timeout(8000)]);
 try {
  const response=await fetcher(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),redirect:'manual',signal:combined});
  if([400,401,403,404,405,410,413,415,422,429].includes(response.status)){await response.body?.cancel();
   const raw=response.headers.get('retry-after'),seconds=raw&&/^\d+$/.test(raw)?Number(raw):undefined;
   return {state:'failed',outcome:`HTTP_${response.status}`,retryAfterMs:response.status===429?Math.min(900000,Math.max(1000,(seconds??60)*1000)):undefined};
  }
  // Incoming webhooks have no idempotency key or durable response receipt. A timeout,
  // redirect, server failure, or surprising success response cannot safely be replayed.
  if(response.status!==200){await response.body?.cancel();return {state:'uncertain',outcome:'UNCONFIRMED_RESPONSE'};}
  let bytes=0,body='';if(response.body){const reader=response.body.getReader();try{while(true){const next=await reader.read();if(next.done)break;bytes+=next.value.byteLength;if(bytes>128){await reader.cancel();return {state:'uncertain',outcome:'UNCONFIRMED_RESPONSE'};}body+=new TextDecoder().decode(next.value);}}finally{reader.releaseLock();}}
  return body.trim()==='ok'?{state:'sent',outcome:'ACCEPTED'}:{state:'uncertain',outcome:'UNCONFIRMED_RESPONSE'};
 } catch {return {state:'uncertain',outcome:'TRANSPORT_UNCERTAIN'};}
}
