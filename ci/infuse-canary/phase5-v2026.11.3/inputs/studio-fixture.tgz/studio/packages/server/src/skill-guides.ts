import { skillGuideCatalogSchema, skillGuideProvenanceSchema, type SkillGuideCatalog } from '@studio/contracts';

/** Registry JSON is data. Its caller verifies project access and exact byte hashes. */
export function parseSkillCatalog(value: unknown) { return skillGuideCatalogSchema.parse(value); }
export function parseSkillProvenance(value: unknown, catalog: SkillGuideCatalog, skillId: string) {
  const entry = catalog.entries.find(e => e.id === skillId);
  if (!entry) throw Error('Skill is absent from this release');
  const p = skillGuideProvenanceSchema.parse(value);
  if (p.guide.id !== entry.id || p.htmlSha256 !== entry.htmlSha256 || p.source.repository !== entry.source.repository || p.source.path !== entry.source.path
    || p.source.commit !== entry.source.commit || p.source.sha256 !== entry.source.sha256 || p.source.branch !== entry.source.branch) throw Error('Skill provenance does not match the catalog');
  for (const field of ['name', 'promise', 'summary', 'purpose', 'category', 'apps'] as const) if (JSON.stringify(p.guide[field]) !== JSON.stringify(entry[field])) throw Error('Skill presentation does not match the catalog');
  if (entry.output !== undefined && p.guide.output !== entry.output) throw Error('Skill outcome does not match the catalog');
  return p;
}
