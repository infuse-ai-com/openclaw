/** Local integration boundary; runtime/lifecycle authority remains in Workbench. */
export interface StudioComputerBinding { profileId: string; environmentId: string; generation: number }
export function resolveStudioComputer(profileId: string, bindings: readonly StudioComputerBinding[]): StudioComputerBinding {
  if (bindings.some(b => !b.profileId || !/^[a-z][a-z0-9-]{0,63}$/.test(b.environmentId) || !Number.isSafeInteger(b.generation) || b.generation < 1)
    || new Set(bindings.map(b => b.profileId)).size !== bindings.length
    || new Set(bindings.map(b => b.environmentId)).size !== bindings.length) throw Error('Invalid computer ownership bindings');
  const binding = bindings.find(b => b.profileId === profileId);
  if (!binding) throw Error('This Studio profile has no computer binding');
  return { ...binding };
}

/** Shared company access is explicit; legacy personal binding rules stay strict. */
export interface StudioComputerWorkspace {
  workspaceId: string; environmentId: string; generation: number; authorizationRevision: number;
  operatorProfileIds: readonly string[];
}
export interface StudioCompanyComputerBinding extends StudioComputerBinding { workspaceId: string; authorizationRevision: number }
export function resolveStudioCompanyComputer(profileId: string, workspaces: readonly StudioComputerWorkspace[]): StudioCompanyComputerBinding {
  const id=/^[a-z][a-z0-9-]{0,63}$/;
  if(workspaces.some(w=>!id.test(w.workspaceId)||!id.test(w.environmentId)||!Number.isSafeInteger(w.generation)||w.generation<1
    ||!Number.isSafeInteger(w.authorizationRevision)||w.authorizationRevision<1||!Array.isArray(w.operatorProfileIds)
    ||w.operatorProfileIds.some(p=>!id.test(p))||new Set(w.operatorProfileIds).size!==w.operatorProfileIds.length)
    ||new Set(workspaces.map(w=>w.workspaceId)).size!==workspaces.length||new Set(workspaces.map(w=>w.environmentId)).size!==workspaces.length)throw Error('Invalid company computer bindings');
  const matches=workspaces.filter(w=>w.operatorProfileIds.includes(profileId));
  if(matches.length!==1)throw Error('Company computer access is absent or ambiguous');
  const w=matches[0]!;return {profileId,workspaceId:w.workspaceId,environmentId:w.environmentId,generation:w.generation,authorizationRevision:w.authorizationRevision};
}
