import { createHash, timingSafeEqual } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { isAbsolute } from 'node:path';
import { MissionError } from './modules/missions/domain.js';

/** Registry validation only. This credential never grants a human or agent command identity. */
export function registryValidationGuard(header: string | undefined, hashFile: string | undefined) {
  return async () => {
    const token = /^Bearer ([A-Za-z0-9_-]{43,128})$/u.exec(header ?? '')?.[1];
    if (!hashFile || !isAbsolute(hashFile) || !token) throw new MissionError('FORBIDDEN', 'Registry validation is unavailable');
    let expected: string;
    try { expected = (await readFile(hashFile, 'utf8')).trim(); }
    catch { throw new MissionError('UNAVAILABLE', 'Registry validation is unavailable'); }
    if (!/^[a-f0-9]{64}$/u.test(expected) || !timingSafeEqual(Buffer.from(expected, 'hex'), createHash('sha256').update(token).digest()))
      throw new MissionError('FORBIDDEN', 'Registry validation is unavailable');
  };
}
