import {retainedTimestamp as date} from './retained-time.js';
import {createHash} from 'node:crypto';
import {parseArtifactRetainedRecord,type ArtifactRetainedRecord} from '@studio/contracts';
export interface LegacyArtifactMapping {producer:string;artifactId:string;itemKind:'artifact'|'journal';projectId:string}
const ID=/^[a-z0-9][a-z0-9._-]{0,127}$/;
export function artifactRetainedMapping(input:unknown):LegacyArtifactMapping[]{
 if(!Array.isArray(input)||input.length>1000)throw Error('Invalid exact retained artifact mapping');const seen=new Set<string>();return input.map(value=>{
  const r=value as LegacyArtifactMapping;if(!r||typeof r!=='object'||Object.keys(r).sort().join(',')!=='artifactId,itemKind,producer,projectId'||![r.producer,r.artifactId,r.projectId].every(s=>typeof s==='string'&&ID.test(s))||!['artifact','journal'].includes(r.itemKind)||r.itemKind==='journal'&&r.artifactId!=='journal')throw Error('Invalid exact retained artifact mapping');
  const key=JSON.stringify([r.producer,r.itemKind,r.artifactId]);if(seen.has(key))throw Error('Ambiguous retained artifact mapping');seen.add(key);return {...r};
 });
}
function actor(sourceId:string,value:unknown):string|null {if(value===undefined||value===null||value==='')return null;if(typeof value!=='string'||Buffer.byteLength(value)>1024)throw Error('Invalid legacy actor metadata');return createHash('sha256').update(JSON.stringify([sourceId,value])).digest('hex');}
const optionalDate=(v:unknown):string|null=>v===undefined||v===null?null:date(v);
export function normalizeBackofficeArtifactRows(sourceId:string,kind:ArtifactRetainedRecord['kind'],rows:unknown,mappingInput:unknown):ArtifactRetainedRecord[]{
 if(!ID.test(sourceId)||!['audit','lifecycle','purge-job'].includes(kind)||!Array.isArray(rows)||rows.length>100)throw Error('Invalid bounded legacy artifact rows');
 const mapping=artifactRetainedMapping(mappingInput);
 return rows.map(value=>{
  if(!value||typeof value!=='object'||Array.isArray(value))throw Error('Invalid legacy artifact row');const r=value as Record<string,unknown>;
  const producer=r.agentSlug as string,artifactId=r.itemId as string,itemKind=r.itemKind as 'artifact'|'journal',projectId=mapping.find(m=>m.producer===producer&&m.artifactId===artifactId&&m.itemKind===itemKind)?.projectId??null;
  const common={kind,recordId:r.id as string,producer,artifactId,itemKind,projectId,revision:(kind==='purge-job'?r.expectedRevision:r.revision) as string|null??null,at:date(kind==='audit'?r.occurredAt:r.updatedAt??r.createdAt),actorHash:actor(sourceId,kind==='audit'?r.actor:kind==='purge-job'?r.requestedBy:r.purgeRequestedBy??r.trashedBy)};
  if(kind==='audit')return parseArtifactRetainedRecord({...common,action:r.action});
  const hadError=r.lastError!==undefined&&r.lastError!==null&&r.lastError!=='';
  if(kind==='lifecycle')return parseArtifactRetainedRecord({...common,state:r.state,trashedAt:optionalDate(r.trashedAt),purgeRequestedAt:optionalDate(r.purgeRequestedAt),purgedAt:optionalDate(r.purgedAt),hadError});
  return parseArtifactRetainedRecord({...common,state:r.status,attempts:r.attempts,lifecycleId:r.lifecycleId,claimedAt:optionalDate(r.claimedAt),leaseExpiresAt:optionalDate(r.leaseExpiresAt),completedAt:optionalDate(r.completedAt),hadError});
 });
}
