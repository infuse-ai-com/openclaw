import { telemetryObject as obj, telemetryTime as time, parseTelemetryInput, type TelemetryInput } from '@studio/contracts';
import type { AgentFeedMapping } from './agent-feeds.js';
/** A bounded application-data export adapter, never a Prisma/Postgres dependency or a live-source freshness claim. */
export function decodeRetainedAgentUsage(rows:unknown,mapping:AgentFeedMapping,exportedAt:string):TelemetryInput {
  if(mapping.kind!=='usage'||!Array.isArray(rows)||rows.length>768)throw Error('Retained usage export exceeds one bounded source window');
  const stamp=time(exportedAt);
  const buckets=rows.map(raw=>{
    const r=obj(raw);
    if(r.agentId!==mapping.feedAgentId||r.gatewayLabel!==mapping.gatewayLabel)throw Error('Retained usage identity requires an explicit source mapping');
    return {start:time(r.bucketStart),minutes:r.bucketMinutes,provider:r.provider??'unknown',model:r.model??'unknown',input:r.inputTokens,output:r.outputTokens,cacheRead:r.cacheReadTokens,cacheWrite:r.cacheWriteTokens,totalTokens:r.totalTokens,
      legacyGeneratedAt:r.generatedAt===null||r.generatedAt===undefined?null:time(r.generatedAt),...(r.importedAt===undefined?{}:{legacyImportedAt:time(r.importedAt)})};
  });
  return parseTelemetryInput({sourceId:mapping.sourceId,gatewayId:mapping.gatewayId,agentId:mapping.agentId,kind:'usage',generatedAt:stamp,observedAt:stamp,sourceStatus:'unknown',data:buckets});
}
