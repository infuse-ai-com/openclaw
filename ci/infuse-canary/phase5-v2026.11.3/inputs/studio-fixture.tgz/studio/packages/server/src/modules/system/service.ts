import type { HealthResponse } from '@studio/contracts';
/** Shared by HTTP and worker entry points. This reports process health, not integration readiness. */
export function getSystemHealth(): HealthResponse {
  return {service: 'studio', apiVersion: 1, status: 'ok', mode: 'foundation',
    capabilities: {database: false, backgroundQueue: false, liveMissions: false, realtime: false}};
}
