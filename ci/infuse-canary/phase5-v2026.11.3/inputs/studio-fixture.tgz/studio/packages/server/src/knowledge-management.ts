import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { isAbsolute } from 'node:path';
import { MissionError } from './modules/missions/domain.js';
import { repositorySetupReceipt, type FloorActor } from '@studio/contracts';

export interface KnowledgeManagementConfig { baseUrl: string; tokenFile: string; allowInsecureLoopback?: boolean }
export function parseKnowledgeManagementConfig(input: unknown): KnowledgeManagementConfig {
  const value = input as KnowledgeManagementConfig;
  if (!value || typeof value !== 'object' || Object.keys(value).some(key => !['baseUrl', 'tokenFile', 'allowInsecureLoopback'].includes(key))
    || typeof value.baseUrl !== 'string' || typeof value.tokenFile !== 'string' || !isAbsolute(value.tokenFile)
    || value.allowInsecureLoopback !== undefined && typeof value.allowInsecureLoopback !== 'boolean') throw Error('Invalid repository management connection');
  const url = new URL(value.baseUrl), local = ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
  if (url.username || url.password || url.search || url.hash || url.pathname !== '/' || !['http:', 'https:'].includes(url.protocol)
    || !(url.hostname === 'knowledge-base-studio-management.knowledge-base.svc.cluster.local' || local && value.allowInsecureLoopback === true)) throw Error('Repository management needs its admitted private endpoint');
  return { baseUrl: url.href, tokenFile: value.tokenFile, ...(value.allowInsecureLoopback === true ? { allowInsecureLoopback: true } : {}) };
}
export class KnowledgeManagementClient {
  constructor(private config: KnowledgeManagementConfig) {}
  async request(actor: FloorActor, commandId?: string, command?: unknown, guard: () => void = () => {}): Promise<unknown> {
    guard();
    if (command !== undefined) throw new MissionError('UNAVAILABLE', 'Legacy repository setup writes are retired');
    if (commandId !== undefined && !/^[a-f0-9-]{36}$/i.test(commandId)) throw new MissionError('INVALID_INPUT', 'Invalid setup operation');
    const token = (await readFile(this.config.tokenFile, 'utf8')).trim();
    if (!/^[A-Za-z0-9._~+/-]{16,16384}$/.test(token)) throw new MissionError('UNAVAILABLE', 'Repository management is not connected');
    const identity = actor.kind === 'human' ? ['human', actor.id] : ['agent', actor.gatewayId, actor.id];
    guard();
    let response: Response;
    try { response = await fetch(new URL(`/api/v1/repositories/commands${commandId ? `/${commandId}` : ''}`, this.config.baseUrl), {
      method: 'GET', redirect: 'error', signal: AbortSignal.timeout(12000),
      headers: { Authorization: `Bearer ${token}`, 'X-Studio-Actor': createHash('sha256').update(JSON.stringify(identity)).digest('hex'),
        'X-Studio-Actor-Audit': Buffer.from(JSON.stringify(actor)).toString('base64url'),
        Accept: 'application/json' },
    }); } catch { throw new MissionError('UNAVAILABLE', 'Repository setup was interrupted. Check its saved operation before retrying.'); }
    const chunks: Uint8Array[] = []; let bytes = 0;
    for await (const chunk of response.body ?? []) { bytes += chunk.byteLength; if (bytes > 256 * 1024) throw new MissionError('UNAVAILABLE', 'Repository setup returned an invalid response'); chunks.push(chunk); }
    let result: unknown;
    try { result = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new MissionError('UNAVAILABLE', 'Repository setup returned an invalid response'); }
    if (!response.ok) {
      const message = (result as { error?: { message?: unknown } })?.error?.message;
      throw new MissionError(response.status === 409 ? 'STATE_CONFLICT' : response.status === 400 ? 'INVALID_INPUT' : response.status === 403 ? 'FORBIDDEN' : 'UNAVAILABLE',
        typeof message === 'string' && message.length < 500 ? message : 'Repository setup is unavailable');
    }
    try { return result === null ? null : repositorySetupReceipt.parse(result); }
    catch { throw new MissionError('UNAVAILABLE', 'Repository setup returned an invalid operation. Check its saved receipt.'); }
  }
}
