import { parentPort } from 'node:worker_threads';
import * as Y from 'yjs';
import { createPreparer, CandidateError } from './text-candidate.mjs';
const preparer = createPreparer({ gc: true });
parentPort.on('message', ({ id, checkpoint, update, patch, clientId, anchors }) => {
  try {
    if (anchors) {
      const doc=new Y.Doc({ gc:false });
      try {
        const body=doc.getText('body'); Y.applyUpdate(doc,checkpoint);
        const result={ ranges:[] };
        if (anchors.create) {
          const { from,to,quote }=anchors.create; const original=body.toString();
          if (!Number.isInteger(from) || !Number.isInteger(to) || from<0 || to<=from || to>body.length || original.slice(from,to)!==quote || !quote.isWellFormed()) throw new CandidateError('ANCHOR_CONFLICT');
          result.anchor={ from:Y.relativePositionToJSON(Y.createRelativePositionFromTypeIndex(body,from,0)),to:Y.relativePositionToJSON(Y.createRelativePositionFromTypeIndex(body,to,-1)),quote };
        }
        result.ranges=(anchors.resolve ?? []).map(anchor=> {
          const from=Y.createAbsolutePositionFromRelativePosition(Y.createRelativePositionFromJSON(anchor.from),doc);
          const to=Y.createAbsolutePositionFromRelativePosition(Y.createRelativePositionFromJSON(anchor.to),doc);
          return from?.type===body && to?.type===body ? { from:from.index,to:to.index } : null;
        });
        parentPort.postMessage({ id,result }); return;
      } finally { doc.destroy(); }
    }
    if (patch) {
      // The checkpoint came from the sole writer. Patch ranges are still checked
      // here, away from both the HTTP loop and persistence worker.
      const doc = new Y.Doc({ gc: false });
      try {
        const text = doc.getText('body'); Y.applyUpdate(doc, checkpoint); doc.clientID = clientId;
        const original = text.toString(); let last = original.length + 1;
        const boundary = offset => offset === 0 || offset === original.length || !(original.charCodeAt(offset - 1) >= 0xd800 && original.charCodeAt(offset - 1) <= 0xdbff && original.charCodeAt(offset) >= 0xdc00 && original.charCodeAt(offset) <= 0xdfff);
        for (const edit of [...patch].sort((a,b) => b.from - a.from)) {
          if (edit.from > edit.to || edit.to > original.length || edit.to > last || !edit.insert.isWellFormed() || !boundary(edit.from) || !boundary(edit.to) || original.slice(edit.from,edit.to) !== edit.expected) throw new CandidateError('PATCH_CONFLICT');
          last = edit.from;
        }
        const vector = Y.encodeStateVector(doc);
        doc.transact(() => { for (const edit of [...patch].sort((a,b) => b.from - a.from)) { text.delete(edit.from,edit.to - edit.from); text.insert(edit.from,edit.insert); } });
        update = Y.encodeStateAsUpdate(doc, vector);
      } finally { doc.destroy(); }
    }
    const result = preparer.prepare(checkpoint, update);
    parentPort.postMessage({ id, result: { ...result, update } });
  } catch (error) { parentPort.postMessage({ id, error: error.code ?? 'INVALID_ENCODING' }); }
});
parentPort.postMessage({ ready: true });
