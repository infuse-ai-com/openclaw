import {gitObject as obj,gitText as text,gitTime,parseGitCommit,type GitCommitMetadata,type GitRepositoryMetadata} from '@studio/contracts';
/** Bounded BO application-data export. Mapping names to immutable provider IDs must be reviewed before this adapter. */
export function decodeRetainedGitCommits(value:unknown,mapping:{legacyRepositoryId:string;repository:GitRepositoryMetadata}):GitCommitMetadata[]{
 if(!Array.isArray(value)||value.length>100)throw Error('Retained Git import exceeds 100 records');text(mapping.legacyRepositoryId);
 return value.map(raw=>{const r=obj(raw);if(r.repositoryId!==mapping.legacyRepositoryId)throw Error('Retained repository identity does not match its reviewed mapping');
  const date=gitTime(r.committedAt),rawMessage=typeof r.message==='string'?r.message:'',message=rawMessage.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/gu,'').slice(0,1000).replace(/[\ud800-\udbff]$/u,'');
  return parseGitCommit({sha:r.sha,authorName:typeof r.authorName==='string'&&r.authorName.trim()?text(r.authorName):'Unknown',authorEmail:r.authorEmail===undefined||r.authorEmail===null||r.authorEmail===''?null:text(r.authorEmail,320),authorDate:null,committerName:null,committerEmail:null,committerDate:null,message,messageTruncated:rawMessage.length>1000,provenance:'backoffice',...(date?{legacyGraphDate:date,legacyDateBasis:'author-or-committer-fallback'}:{})});
 });
}
