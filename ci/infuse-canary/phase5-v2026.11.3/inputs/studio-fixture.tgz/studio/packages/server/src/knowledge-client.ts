import { readFile } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { isAbsolute } from 'node:path';
import { z } from 'zod';
import { floorRepositoryCatalog, registryRequestScope, stableRegistryJson, type RegistryRequestScope } from '@studio/contracts';
import {
  repositorySchema,
  repositoryTreeSchema,
  libraryUpdatesSchema,
  reviewQueueSchema,
  searchResultSchema,
  documentSchema,
  meaningSearchResponseSchema,
  meaningSearchRequestSchema,
  semanticReadinessRequestSchema,
  semanticReadinessResponseSchema,
  sessionSchema,
  graphSchema,
  semanticNeighborhoodRequestSchema,
  semanticNeighborhoodResponseSchema,
} from '@studio/contracts/knowledge';

export interface KnowledgeConfig {
  baseUrl: string;
  tokenFile: string;
  allowInsecureLoopback?: boolean;
}
export class KnowledgeError extends Error {
  constructor(
    readonly status: number,
    message: string,
    readonly retryAfterSeconds?: number,
  ) {
    super(message);
  }
}
export function parseKnowledgeConfig(input: unknown): KnowledgeConfig {
  const v = input as Partial<KnowledgeConfig>;
  if (
    !v ||
    typeof v !== 'object' ||
    Object.keys(v).some(
      (k) => !['baseUrl', 'tokenFile', 'allowInsecureLoopback'].includes(k),
    ) ||
    typeof v.baseUrl !== 'string' ||
    typeof v.tokenFile !== 'string' ||
    !isAbsolute(v.tokenFile)
  )
    throw Error('Invalid Knowledge configuration');
  const u = new URL(v.baseUrl);
  const local = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname);
  if (
    u.hostname !==
      'knowledge-base-studio-reader.knowledge-base.svc.cluster.local' &&
    !(local && v.allowInsecureLoopback === true)
  )
    throw Error('Knowledge needs the admitted private service endpoint');
  if (
    u.username ||
    u.password ||
    u.search ||
    u.hash ||
    u.pathname !== '/' ||
    !['http:', 'https:'].includes(u.protocol) ||
    (u.protocol === 'http:' &&
      !(
        u.hostname ===
          'knowledge-base-studio-reader.knowledge-base.svc.cluster.local' ||
        (local && v.allowInsecureLoopback === true)
      )) ||
    (v.allowInsecureLoopback !== undefined &&
      typeof v.allowInsecureLoopback !== 'boolean')
  )
    throw Error('Knowledge needs a private service endpoint');
  return {
    baseUrl: u.href,
    tokenFile: v.tokenFile,
    ...(v.allowInsecureLoopback === true
      ? { allowInsecureLoopback: true }
      : {}),
  };
}
const reads = new Set([
  'floors/repositories',
  'graph',
  'session',
  'repositories',
  'library/updates',
  'reviews/queue',
  'search',
  'search/meaning/readiness',
]);
export function knowledgeOperation(method: string, path: string): boolean {
  if (method === 'POST')
    return path === 'search/meaning' || path === 'graph/neighborhood';
  return (
    method === 'GET' &&
    (reads.has(path) ||
      /^repositories\/[a-z0-9]+(?:-[a-z0-9]+)*\/(?:tree|document)$/u.test(
        path,
      ) ||
      /^repositories\/[a-z0-9]+(?:-[a-z0-9]+)*\/(?:rendered-assets|assets)\/[a-f0-9]{40}\/.+/u.test(
        path,
      ))
  );
}
function validateResponse(path: string, body: unknown): unknown {
  if (path === 'floors/repositories') return floorRepositoryCatalog.parse(body);
  if (path === 'graph') return graphSchema.parse(body);
  if (path === 'graph/neighborhood')
    return semanticNeighborhoodResponseSchema.parse(body);
  if (path === 'repositories')
    return z.array(repositorySchema).max(1000).parse(body);
  if (path === 'session') return sessionSchema.parse(body);
  if (path === 'library/updates') return libraryUpdatesSchema.parse(body);
  if (path === 'reviews/queue') return reviewQueueSchema.parse(body);
  if (path === 'search')
    return z.array(searchResultSchema).max(1000).parse(body);
  if (path === 'search/meaning') return meaningSearchResponseSchema.parse(body);
  if (path === 'search/meaning/readiness')
    return semanticReadinessResponseSchema.parse(body);
  if (path.endsWith('/tree')) return repositoryTreeSchema.parse(body);
  if (path.endsWith('/document')) {
    const doc = documentSchema.parse(body);
    if (doc.repository !== path.split('/')[1])
      throw new KnowledgeError(502, 'Knowledge returned a different document.');
    return { ...doc, review: { ...doc.review, canReview: false } };
  }
  throw new KnowledgeError(403, 'This Knowledge operation is unavailable.');
}
export class KnowledgeClient {
  constructor(private config: KnowledgeConfig) {}
  async read(
    method: string,
    path: string,
    query: URLSearchParams,
    body: unknown,
    identity: string,
    signal?: AbortSignal,
    scope?: Array<{ id: string; slug: string }>,
    registryScope?: Pick<RegistryRequestScope, 'floor' | 'registry'>,
  ): Promise<{ body: Uint8Array; contentType: string }> {
    if (
      !knowledgeOperation(method, path) ||
      path.length > 4096 ||
      path.split('/').some((segment) => segment === '..' || segment === '.') ||
      path.includes('\\') ||
      /%2f|%5c|%00|%2e/i.test(path) ||
      query.toString().length > 8192 ||
      (path.startsWith('repositories/') && query.has('repo')) ||
      (/\/(?:assets|rendered-assets)\//u.test(path) && query.size > 0) ||
      (path.endsWith('/document') && query.has('revision'))
    )
      throw new KnowledgeError(403, 'This Knowledge operation is unavailable.');
    let neighborhood: ReturnType<typeof semanticNeighborhoodRequestSchema.parse> | undefined;
    let requestedRepository: string | undefined;
    try {
      if (path === 'graph/neighborhood') body = neighborhood = semanticNeighborhoodRequestSchema.parse(body);
      if (path === 'search/meaning') {
        const request = meaningSearchRequestSchema.parse(body);
        body = request;
        requestedRepository = request.repository;
      }
      if (path === 'search/meaning/readiness') requestedRepository = semanticReadinessRequestSchema.parse(Object.fromEntries(query)).repository;
      if (path === 'search') requestedRepository = query.get('repo') ?? undefined;
    } catch { throw new KnowledgeError(400, 'The Knowledge request is invalid.'); }
    if (scope) {
      const requested = [
        ...(path.startsWith('repositories/') ? [path.split('/')[1]!] : []),
        ...(path === 'graph' ? query.getAll('repo') : []),
        ...(requestedRepository ? [requestedRepository] : []),
        ...(neighborhood?.repositories ?? []),
      ];
      if (path === 'floors/repositories' || requested.some(slug => !scope.some(source => source.slug === slug)))
        throw new KnowledgeError(403, 'This operation is unavailable for the selected floor sources.');
    }
    let token: string;
    try {
      token = (await readFile(this.config.tokenFile, 'utf8')).trim();
    } catch {
      throw new KnowledgeError(503, 'Knowledge connection is unavailable.');
    }
    if (!/^[A-Za-z0-9._~+/-]{16,16384}$/u.test(token))
      throw new KnowledgeError(503, 'Knowledge connection is unavailable.');
    const serialized = body === undefined ? undefined : JSON.stringify(body);
    if (
      serialized &&
      Buffer.byteLength(serialized) > (neighborhood ? 256 * 1024 : 8192)
    )
      throw new KnowledgeError(413, 'Knowledge request is too large.');
    const url = new URL(`/api/v1/${path}`, this.config.baseUrl);
    url.search = query.toString();
    const issuedAt = Date.now();
    const actor = createHash('sha256').update(identity).digest('hex');
    const envelope = registryScope ? registryRequestScope.parse({ version: 3, audience: 'documentation', actor,
      requestId: randomUUID(), floor: registryScope.floor, registry: registryScope.registry, method, target: url.pathname + url.search,
      bodyDigest: body === undefined ? null : createHash('sha256').update(stableRegistryJson(body)).digest('hex'),
      issuedAt, expiresAt: issuedAt + 15000, repositories: scope }) : scope ? { version: 2, repositories: scope } : undefined;
    let response: Response;
    try {
      response = await fetch(url, {
        method,
        redirect: 'error',
        signal: signal
          ? AbortSignal.any([signal, AbortSignal.timeout(12000)])
          : AbortSignal.timeout(12000),
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${token}`,
          'X-Studio-Reader': actor,
          ...(serialized ? { 'Content-Type': 'application/json' } : {}),
          ...(envelope ? { 'X-Studio-Knowledge-Scope': Buffer.from(JSON.stringify(envelope)).toString('base64url') } : {}),
        },
        ...(serialized ? { body: serialized } : {}),
      });
    } catch {
      throw new KnowledgeError(503, 'Knowledge service is unavailable.');
    }
    if (!response.ok) {
      await response.body?.cancel();
      throw new KnowledgeError(
        [400, 403, 404, 413, 429].includes(response.status)
          ? response.status
          : 503,
        'Knowledge could not complete this read.',
        [429, 503].includes(response.status) &&
          /^\d{1,5}$/u.test(response.headers.get('retry-after') ?? '')
          ? Math.max(
              1,
              Math.min(60, Number(response.headers.get('retry-after'))),
            )
          : undefined,
      );
    }
    if (scope && response.headers.get('x-knowledge-scope-version') !== (registryScope ? '3' : '2')) {
      await response.body?.cancel();
      throw new KnowledgeError(503, 'This Knowledge service does not support floor sources yet.');
    }
    const asset = /\/(?:assets|rendered-assets)\//u.test(path);
    const type = response.headers.get('content-type')?.split(';')[0]?.trim();
    if (
      asset
        ? ![
            'image/png',
            'image/jpeg',
            'image/gif',
            'image/webp',
            'image/svg+xml',
          ].includes(type ?? '')
        : type !== 'application/json'
    ) {
      await response.body?.cancel();
      throw new KnowledgeError(502, 'Knowledge returned an invalid response.');
    }
    const reader = response.body?.getReader();
    const chunks: Uint8Array[] = [];
    let length = 0;
    if (!reader)
      throw new KnowledgeError(502, 'Knowledge returned an empty response.');
    try {
      while (true) {
        const next = await reader.read();
        if (next.done) break;
        length += next.value.byteLength;
        if (length > 8 * 1024 * 1024) {
          await reader.cancel();
          throw new KnowledgeError(
            502,
            'Knowledge response exceeded its limit.',
          );
        }
        chunks.push(next.value);
      }
    } catch (error) {
      if (error instanceof KnowledgeError) throw error;
      throw new KnowledgeError(503, 'Knowledge read was interrupted.');
    }
    const bytes = Buffer.concat(chunks);
    if (asset) return { body: bytes, contentType: type! };
    try {
      const parsed = validateResponse(path, JSON.parse(bytes.toString('utf8')));
      if (scope || requestedRepository) {
        const allowed = new Set(requestedRepository ? [requestedRepository] : scope?.map(source => source.slug));
        const check = (row: unknown): void => {
          if (!row || typeof row !== 'object') return;
          if (Array.isArray(row)) { row.forEach(check); return; }
          const item = row as Record<string, unknown>;
          for (const key of ['repository', 'slug']) {
            if (typeof item[key] === 'string' && !allowed.has(item[key])) throw new KnowledgeError(502, 'Knowledge returned content outside this floor.');
          }
          for (const key of ['entries', 'results', 'nodes', 'focus', 'provenance']) check(item[key]);
        };
        check(parsed);
        if (path === 'search/meaning/readiness' && scope) {
          const readiness = semanticReadinessResponseSchema.parse(parsed);
          if (readiness.repositories.selected !== (requestedRepository ? 1 : scope.length))
            throw new KnowledgeError(502, 'Knowledge returned readiness for a different scope.');
        }
      }
      if (path === 'graph') {
        const graph = graphSchema.parse(parsed);
        const scope = new Set(query.getAll('repo'));
        const ids = new Set(graph.nodes.map((node) => node.id));
        if (
          graph.nodes.length > 250 ||
          graph.edges.length > 2000 ||
          graph.clusters.length > 250 ||
          ids.size !== graph.nodes.length ||
          graph.limit > 250 ||
          graph.nodes.some(
            (node) =>
              node.id !== `${node.repository}:${node.path}` ||
              !scope.has(node.repository) ||
              node.provenance.repository !== node.repository,
          ) ||
          graph.edges.some(
            (edge) => !ids.has(edge.sourceId) || !ids.has(edge.targetId),
          )
        )
          throw new KnowledgeError(
            502,
            'Knowledge returned a different graph scope.',
          );
      }
      if (neighborhood) {
        const result = semanticNeighborhoodResponseSchema.parse(parsed);
        const ids = new Set(
          neighborhood.candidates.map((node) =>
            JSON.stringify([node.repository, node.path]),
          ),
        );
        if (
          result.focus.repository !== neighborhood.focus.repository ||
          result.focus.path !== neighborhood.focus.path ||
          result.results.some(
            (node) =>
              !ids.has(JSON.stringify([node.repository, node.path])) ||
              node.provenance.repository !== node.repository,
          )
        )
          throw new KnowledgeError(
            502,
            'Knowledge returned a different neighborhood scope.',
          );
      }
      if (
        path.endsWith('/document') &&
        (parsed as { path: string }).path !== query.get('path')
      )
        throw new KnowledgeError(
          502,
          'Knowledge returned a different document.',
        );
      return {
        body: Buffer.from(JSON.stringify(parsed)),
        contentType: 'application/json',
      };
    } catch {
      throw new KnowledgeError(502, 'Knowledge returned an invalid response.');
    }
  }
}
