import { whiteboardSharedView, type WhiteboardPresenceState, type WhiteboardSharedView, type WhiteboardViewTarget } from '@studio/contracts';
import { requireMission } from '../missions/domain.js';
import type { WhiteboardGuard, WhiteboardPrincipal } from './service.js';
type Source = { guard: WhiteboardGuard; name():string; current():{ state?:WhiteboardPresenceState; seen?:number } };
/** Reads the existing ephemeral socket owner; no duplicate presence cache or durable camera state. */
export class WhiteboardSharedViews {
  private sources=new Map<string,Source>();
  constructor(private allowed:(projectId:string,target:WhiteboardViewTarget)=>boolean,private now=Date.now){}
  register(id:string,source:Source) { requireMission(this.sources.size<32,'BUSY','Presence capacity reached');this.sources.set(id,source); }
  remove(id:string){this.sources.delete(id);}
  assertTarget(projectId:string,target:WhiteboardViewTarget){requireMission(this.allowed(projectId,target),'FORBIDDEN','This agent is no longer connected to the board');}
  views(principal:WhiteboardPrincipal):WhiteboardSharedView[]{
    const custody=principal.nativeCustody;
    if(principal.actor.kind!=='agent'||!custody)return [];
    const result:WhiteboardSharedView[]=[];
    for(const [connectionId,source] of this.sources){
      try{
        const {state,seen}=source.current(),target=state?.shareView;
        if(!target||seen===undefined||this.now()-seen>=30000||!state?.sectionId||!state.viewport||!state.viewSize)continue;
        if(target.gatewayId!==custody.gatewayId||target.agentId!==custody.invocation.agentId||(target.sessionId&&target.sessionId!==custody.invocation.sessionId))continue;
        const human=source.guard();
        if(human.projectId!==principal.projectId||human.actor.kind!=='human')continue;
        this.assertTarget(human.projectId,target);
        const {x,y,zoom}=state.viewport,{width,height}=state.viewSize;
        const parsed=whiteboardSharedView.safeParse({connectionId,profileId:human.actor.id,name:source.name().slice(0,100)||human.actor.id,
          projectId:human.projectId,sectionId:state.sectionId,selectedIds:state.selectedIds??[],bounds:{x:-x/zoom,y:-y/zoom,width:width/zoom,height:height/zoom},
          viewport:{width,height,zoom},observedAt:new Date(seen).toISOString(),expiresAt:new Date(seen+30000).toISOString()});
        if(parsed.success)result.push(parsed.data);
      }catch{/* A vanished, expired or revoked producer has no shared view. */}
    }
    return result;
  }
}
