import { createHash, createPublicKey, verify } from 'node:crypto';
import { z } from 'zod';
import { MachineError } from '../machine/errors.js';

const id = z.string().min(1).max(128).regex(/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/);
const text = z.string().min(1).max(512).regex(/^[^\u0000-\u001f\u007f]+$/);
const seconds = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const scopes = z.tuple([z.literal('whiteboard:read')]);
const signer = z.strictObject({ issuer: text, keyId: id, enabled: z.boolean(), publicKey: z.string().max(4096) });
const binding = z.strictObject({ issuer: text, credentialId: id, clientId: text, gatewayId: id, agentId: id,
  projectId: id, enrollmentGeneration: z.number().int().positive(), enabled: z.boolean(), issuedAt: seconds, expiresAt: seconds,
}).refine(b => b.expiresAt > b.issuedAt && b.expiresAt - b.issuedAt <= 90 * 86400, 'Credential lifetime exceeds 90 days');
const configuration = z.discriminatedUnion('enabled', [z.strictObject({ enabled: z.literal(false) }),
  z.strictObject({ enabled: z.literal(true), signers: z.array(signer).min(1).max(20), bindings: z.array(binding).max(2000) })]);
export type WhiteboardMcpConfig = z.infer<typeof configuration>;
function publicKey(pem: string) {
  if (!pem.startsWith('-----BEGIN PUBLIC KEY-----')) throw Error('Expected public verification key');
  const key = createPublicKey(pem);
  if (key.asymmetricKeyType !== 'ec' || key.asymmetricKeyDetails?.namedCurve !== 'prime256v1') throw Error('Expected ES256 verification key');
  return key;
}
export function parseWhiteboardMcpConfig(value: unknown): WhiteboardMcpConfig {
  const config = configuration.parse(value);
  if (!config.enabled) return config;
  for (const s of config.signers) publicKey(s.publicKey);
  if (new Set(config.signers.map(s => JSON.stringify([s.issuer, s.keyId]))).size !== config.signers.length
    || new Set(config.bindings.map(b => JSON.stringify([b.issuer, b.credentialId, b.projectId]))).size !== config.bindings.length)
    throw Error('Duplicate whiteboard MCP admission');
  // A credential may span projects, but must never name a different agent/client.
  const identities = new Map<string, string>();
  for (const b of config.bindings) {
    const key = JSON.stringify([b.issuer, b.credentialId]);
    const identity = JSON.stringify([b.clientId, b.gatewayId, b.agentId, b.issuedAt, b.expiresAt]);
    if (identities.has(key) && identities.get(key) !== identity) throw Error('Inconsistent whiteboard MCP credential identity');
    identities.set(key, identity);
  }
  return config;
}
const claimsSchema = z.strictObject({ iss: text, aud: z.literal('urn:infuse:studio:whiteboard-agent-read:v1'),
  iat: seconds, nbf: seconds, exp: seconds, jti: id, credentialId: id, clientId: text, projectId: id, scopes,
  actor: z.strictObject({ kind: z.literal('agent'), gatewayId: id, agentId: id }),
  request: z.strictObject({ method: z.literal('POST'), path: z.string().max(128), bodySha256: z.string().regex(/^[a-f0-9]{64}$/) }),
});
export interface WhiteboardMcpIdentity {
  credentialId: string; clientId: string; gatewayId: string; agentId: string; enrollmentGeneration: number; bindingHash: string;
}
/** A separate read-only audience. Neither a human token nor native bridge credentials are accepted. */
export function whiteboardMcpIdentity(authorization: unknown, path: string, body: Buffer, projectId: string,
  config: WhiteboardMcpConfig | undefined): WhiteboardMcpIdentity {
  if (!config?.enabled) throw new MachineError('FORBIDDEN');
  try {
    if (typeof authorization !== 'string' || !authorization.startsWith('Bearer ') || authorization.length > 8192) throw Error();
    const parts = authorization.slice(7).split('.');
    if (parts.length !== 3 || parts.some(p => !/^[A-Za-z0-9_-]+$/.test(p) || Buffer.from(p, 'base64url').toString('base64url') !== p)) throw Error();
    const [h, p, s] = parts as [string, string, string];
    const decode = (v: string) => JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(Buffer.from(v, 'base64url')));
    const header = z.strictObject({ alg: z.literal('ES256'), typ: z.literal('infuse-studio-whiteboard-agent+jwt'), kid: id }).parse(decode(h));
    const claims = claimsSchema.parse(decode(p));
    const registered = config.signers.find(s => s.enabled && s.issuer === claims.iss && s.keyId === header.kid);
    const signature = Buffer.from(s, 'base64url');
    if (!registered || signature.length !== 64 || !verify('sha256', Buffer.from(`${h}.${p}`),
      { key: publicKey(registered.publicKey), dsaEncoding: 'ieee-p1363' }, signature)) throw Error();
    const now = Date.now() / 1000;
    if (claims.nbf !== claims.iat || claims.exp <= claims.iat || claims.exp - claims.iat > 30 || claims.iat > now + 5 || claims.exp <= now
      || claims.request.path !== path || claims.request.bodySha256 !== createHash('sha256').update(body).digest('hex')) throw Error();
    const mapped = config.bindings.find(b => b.enabled && b.issuer === claims.iss && b.credentialId === claims.credentialId && b.projectId === projectId);
    if (!mapped || claims.projectId !== projectId || mapped.clientId !== claims.clientId || mapped.gatewayId !== claims.actor.gatewayId
      || mapped.agentId !== claims.actor.agentId || mapped.issuedAt > now || mapped.expiresAt <= now || claims.exp > mapped.expiresAt)
      throw new MachineError('FORBIDDEN');
    return { credentialId: mapped.credentialId, clientId: mapped.clientId, gatewayId: mapped.gatewayId, agentId: mapped.agentId,
      enrollmentGeneration: mapped.enrollmentGeneration, bindingHash: createHash('sha256').update(JSON.stringify([registered, mapped])).digest('hex') };
  } catch (error) {
    if (error instanceof MachineError) throw error;
    throw new MachineError('UNAUTHENTICATED');
  }
}
