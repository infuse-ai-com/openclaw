import { createHash } from 'node:crypto';
import {appAccents,type AppLink,type AppAccessGroup} from '@studio/contracts';
import { appsForCategory,filterMyAppsByAccess,myApps,myAppCategories } from './catalog.js';
/** Filter before serializing: private destinations never enter a public browser bundle. */
export function readMyApps(groups:AppAccessGroup[]):{categories:string[];apps:AppLink[]}{
 const allowed=filterMyAppsByAccess(myApps,groups);
 const categories=myAppCategories.filter(c=>allowed.some(a=>a.category===c));
 const apps=categories.flatMap(c=>appsForCategory(allowed,c)).map(a=>({
  id:createHash('sha256').update(a.url).digest('hex').slice(0,24),name:a.name,description:a.description,
  url:a.url,category:a.category,icon:a.icon,accent:appAccents.find(color=>a.accent.startsWith(`from-${color}-`))??'slate',
 }));
 return {categories,apps};
}
