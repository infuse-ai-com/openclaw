import { boardItem, boardSummary, searchBoard } from './whiteboard-read-content.js';
import { whiteboardConnectable } from '@studio/contracts';
import type { StorageDatabase } from './sql.js';
import { whiteboardId,whiteboardManifestQuery,whiteboardDetailQuery,whiteboardSearchQuery,whiteboardRenderQuery,
  type WhiteboardSpatialItem,type WhiteboardManifest,type WhiteboardSearch,type WhiteboardDetails } from '@studio/contracts';
import { requireMission } from '../../modules/missions/domain.js';
import { collaborative } from './whiteboard-text-records.js';
export type SpatialRead={kind:'manifest'|'details'|'search'|'render'|'tile'|'overview';input:unknown};
export const parent=(item:WhiteboardSpatialItem)=>item.sectionId??'root';
export const spatial=async (db:StorageDatabase,project:string)=>!!(await db.prepare('SELECT 1 FROM whiteboard_v3_boards WHERE project_id=?').get(project));
export const boardRevision=async (db:StorageDatabase,project:string)=>Number((await db.prepare('SELECT revision FROM whiteboard_boards WHERE project_id=?').get(project))?.revision??0);
function fence(actual:number,expected:number|undefined) { requireMission(expected===undefined || expected===actual,'VERSION_CONFLICT','The board changed; refresh this view before continuing'); }
export async function ancestors(db:StorageDatabase,project:string,section:string) {
  const chain:Array<{id:string;title:string;x:number;y:number}>=[];const seen=new Set<string>();
  while(section!=='root') {
    requireMission(chain.length<8 && !seen.has(section),'INVALID_INPUT','Section nesting is invalid');seen.add(section);
    const row=(await db.prepare('SELECT body FROM whiteboard_items WHERE project_id=? AND id=? AND body IS NOT NULL').get(project,section));
    const item=row?JSON.parse(String(row.body)) as WhiteboardSpatialItem:undefined;
    requireMission(item?.kind==='section','NOT_FOUND','This section is unavailable');
    chain.unshift({id:item.id,title:item.title,x:item.x,y:item.y});section=parent(item);
  }
  return [{id:'root',title:'Whiteboard',x:0,y:0},...chain];
}
export async function spatialRead(db:StorageDatabase,project:string,op:SpatialRead):Promise<unknown> {
  const revision=(await boardRevision(db,project));const base={projectId:project,revision};
  if(op.kind==='overview') {
    const counts=new Map((await db.prepare("SELECT COALESCE(studio_control_json(body)->>'sectionId','root') id,count(*) n FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND jsonb_extract_path_text(studio_control_json(body),'kind')!='connection' GROUP BY COALESCE(studio_control_json(body)->>'sectionId','root')").all(project)).map(row=>[String(row.id),Number(row.n)]));
    const sections=[{id:'root',parentId:null,title:'Whiteboard',count:counts.get('root')??0},...(await db.prepare("SELECT body,structure_revision FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND studio_control_json(body)->>'kind'='section' ORDER BY id").all(project)).map(row=>{
      const item=boardItem(row);requireMission(item.kind==='section','STORE_ERROR','Expected a section');
      return {id:item.id,parentId:parent(item),title:item.title,count:counts.get(item.id)??0};
    })];
    const comments=(await db.prepare("SELECT c.block_id id,sum(CASE WHEN (jsonb_extract_path_text(studio_control_json(c.body),'resolved'))::boolean::integer=0 THEN 1 ELSE 0 END) n FROM whiteboard_comment_threads c JOIN whiteboard_items i ON i.project_id=c.project_id AND i.id=c.block_id AND i.body IS NOT NULL WHERE c.project_id=? GROUP BY c.block_id").all(project)).map(row=>({blockId:String(row.id),open:Number(row.n)}));
    const authors=(await db.prepare("SELECT DISTINCT jsonb_extract_path_text(m.value::jsonb,'author','id') id FROM whiteboard_comment_threads c,jsonb_array_elements(jsonb_extract_path(studio_control_json(c.body),'messages')) m WHERE c.project_id=? AND jsonb_extract_path_text(m.value::jsonb,'author','kind')='human' ORDER BY id").all(project)).map(row=>String(row.id));
    return {...base,sections,comments,authors};
  }
  if(op.kind==='tile') {
    const q=op.input as {id:string;revision:number};whiteboardId.parse(q.id);
    const row=(await db.prepare('SELECT body,structure_revision FROM whiteboard_items WHERE project_id=? AND id=? AND body IS NOT NULL').get(project,q.id));
    const item=row?JSON.parse(String(row.body)):undefined;
    requireMission(item?.kind==='html'||item?.kind==='image','NOT_FOUND','This tile is unavailable');fence(Number(row!.structure_revision),q.revision);
    return {...item,revision:Number(row!.structure_revision)};
  }
  if(op.kind==='manifest') {
    const q=whiteboardManifestQuery.parse(op.input);fence(revision,q.revision);
    const chain=(await ancestors(db,project,q.sectionId));
    const rows=(await db.prepare(`SELECT body,structure_revision FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND COALESCE(studio_control_json(body)->>'sectionId','root')=? AND id>? ORDER BY id LIMIT ?`).all(project,q.sectionId,q.after??'',q.limit+1));
    const total=Number((await db.prepare("SELECT count(*) n FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND COALESCE(studio_control_json(body)->>'sectionId','root')=?").get(project,q.sectionId))?.n);
    return {...base,version:3,mode:(await collaborative(db,project))?'collaborative':'legacy',spatial:(await spatial(db,project)),sectionId:q.sectionId,ancestors:chain,
      items:rows.slice(0,q.limit).map(row=>boardSummary(boardItem(row))),nextCursor:rows.length>q.limit?boardItem(rows[q.limit-1]!).id:null,total} satisfies WhiteboardManifest;
  }
  if(op.kind==='search') {
    const q=whiteboardSearchQuery.parse(op.input);fence(revision,q.revision);
    const items=await searchBoard(db,project,q);
    return {...base,items:items.slice(0,q.limit),nextCursor:items.length>q.limit?items[q.limit-1]!.id:null} satisfies WhiteboardSearch;
  }
  if(op.kind==='details') {
    const q=whiteboardDetailQuery.parse(op.input);fence(revision,q.revision);(await ancestors(db,project,q.sectionId));
    const rows=(await db.prepare(`SELECT body,structure_revision FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND COALESCE(studio_control_json(body)->>'sectionId','root')=? AND id IN (${q.ids.map(()=>'?').join(',')}) ORDER BY id`).all(project,q.sectionId,...q.ids));
    const items=rows.map(row=>({...JSON.parse(String(row.body)),revision:Number(row.structure_revision)})) as WhiteboardSpatialItem[];
    return {...base,sectionId:q.sectionId,items,missingIds:q.ids.filter(id=>!items.some(item=>item.id===id))} satisfies WhiteboardDetails;
  }
  const q=whiteboardRenderQuery.parse(op.input);fence(revision,q.revision);(await ancestors(db,project,q.sectionId));
  const b=q.bounds;
  const rows=(await db.prepare(`SELECT body FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND COALESCE(studio_control_json(body)->>'sectionId','root')=? AND jsonb_extract_path_text(studio_control_json(body),'kind')!='connection' AND (jsonb_extract_path_text(studio_control_json(body),'x'))::double precision<? AND (jsonb_extract_path_text(studio_control_json(body),'y'))::double precision<? AND (jsonb_extract_path_text(studio_control_json(body),'x'))::double precision+(jsonb_extract_path_text(studio_control_json(body),'width'))::double precision>? AND (jsonb_extract_path_text(studio_control_json(body),'y'))::double precision+(jsonb_extract_path_text(studio_control_json(body),'height'))::double precision>? ${q.ids?.length?`AND id IN (${q.ids.map(()=>'?').join(',')})`:''} ORDER BY id LIMIT 101`).all(project,q.sectionId,b.x+b.width,b.y+b.height,b.x,b.y,...(q.ids??[])));
  const items=rows.slice(0,100).map(row=>JSON.parse(String(row.body)) as WhiteboardSpatialItem);
  const links=(await db.prepare("SELECT id FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND COALESCE(studio_control_json(body)->>'sectionId','root')=? AND jsonb_extract_path_text(studio_control_json(body),'kind')='connection' ORDER BY id LIMIT 2000").all(project,q.sectionId)).map(row=>String(row.id));
  return {...base,sectionId:q.sectionId,bounds:b,items,omittedLinks:links,truncated:rows.length>100,missingIds:q.ids?.filter(id=>!items.some(item=>item.id===id))??[]};
}
/** Validate the entire topology after a batch, including descendants of a moved section. */
export function spatialTopology(items:Map<string,WhiteboardSpatialItem>) {
  for(const item of items.values()) {
    requireMission(item.kind!=='section'||item.id!=='root','INVALID_INPUT','Root is reserved for the board section');
    let section=parent(item);const seen=new Set([item.id]);let depth=0;
    while(section!=='root') {
      const container=items.get(section);
      requireMission(container?.kind==='section' && !seen.has(section) && ++depth<=8,'INVALID_INPUT','Sections require a live parent, no cycles and at most eight levels');
      seen.add(section);section=parent(container);
    }
    if(item.kind==='connection') {
      const a=items.get(item.source),b=items.get(item.target);
      requireMission(a && b && a.id!==b.id && a.kind!=='connection' && b.kind!=='connection' && whiteboardConnectable(a) && whiteboardConnectable(b) && parent(a)===parent(b) && parent(item)===parent(a),'INVALID_INPUT','Connections must join two blocks in the same section');
    }
  }
}
export function worldOrigin(items:Map<string,WhiteboardSpatialItem>,section:string) {
  let x=0,y=0;const seen=new Set<string>();
  while(section!=='root') {const item=items.get(section);requireMission(item?.kind==='section' && !seen.has(section),'INVALID_INPUT','Invalid section');seen.add(section);x+=item.x;y+=item.y;section=parent(item);}
  return {x,y};
}
