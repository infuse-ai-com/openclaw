import type { AgentTelemetry, RuntimeTarget } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
export class AgentTelemetryService {
  constructor(private store:MissionStore){}
  read(target:RuntimeTarget,sourceIds:string[],guard:()=>void,freshness?:Record<string,number>):Promise<AgentTelemetry>{
    return this.store.agentTelemetry({kind:'read',target,sourceIds,freshness},guard);
  }
}
