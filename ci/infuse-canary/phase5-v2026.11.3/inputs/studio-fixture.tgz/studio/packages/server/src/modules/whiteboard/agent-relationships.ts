import type { WhiteboardSummary } from '@studio/contracts';

export const whiteboardRelationshipLimits = Object.freeze({ tolerance: 4, gap: 400, neighbors: 4, relations: 32 });
type Rectangle = Extract<WhiteboardSummary, {kind:'note'|'document'|'section'|'html'|'image'}>;
type Relation = {kind:'aligned-with'|'right-of'|'below'|'same-size'|'overlaps'; item:string; ref:string;
  feature?:string; delta?:number; tolerance?:number; gap?:number; width?:number; height?:number;
  intersectionArea?:number; itemFraction?:number; refFraction?:number};
const compareId = (a:string,b:string) => a < b ? -1 : a > b ? 1 : 0;
const isRectangle = (item:WhiteboardSummary):item is Rectangle => ['note','document','section','html','image'].includes(item.kind);
const overlap = (a:number,as:number,b:number,bs:number) => Math.min(a+as,b+bs)-Math.max(a,b);

/** Only supplied, same-revision page metadata is examined. No store access or semantic inference. */
export function whiteboardRelationships(items:readonly WhiteboardSummary[]) {
  const rectangles=items.filter(isRectangle).sort((a,b)=>compareId(a.id,b.id));
  const pairs:Array<{a:Rectangle;b:Rectangle;distance:number}>=[];
  for(let i=0;i<rectangles.length;i++)for(let j=i+1;j<rectangles.length;j++) {
    const a=rectangles[i]!,b=rectangles[j]!;
    if(a.sectionId!==b.sectionId)continue;
    const dx=Math.max(0,-overlap(a.x,a.width,b.x,b.width)),dy=Math.max(0,-overlap(a.y,a.height,b.y,b.height));
    const distance=Math.hypot(dx,dy);
    if(distance<=whiteboardRelationshipLimits.gap)pairs.push({a,b,distance});
  }
  pairs.sort((a,b)=>a.distance-b.distance||compareId(a.a.id,b.a.id)||compareId(a.b.id,b.b.id));
  const counts=new Map<string,number>();
  const selected=pairs.filter(({a,b})=>{
    if((counts.get(a.id)??0)>=whiteboardRelationshipLimits.neighbors||(counts.get(b.id)??0)>=whiteboardRelationshipLimits.neighbors)return false;
    counts.set(a.id,(counts.get(a.id)??0)+1);counts.set(b.id,(counts.get(b.id)??0)+1);return true;
  });
  const relations:Relation[]=[];
  for(const {a,b} of selected) {
    for(const [feature,left,right] of [
      ['left',a.x,b.x],['center-x',a.x+a.width/2,b.x+b.width/2],['right',a.x+a.width,b.x+b.width],
      ['top',a.y,b.y],['center-y',a.y+a.height/2,b.y+b.height/2],['bottom',a.y+a.height,b.y+b.height],
    ] as const) {
      const delta=right-left;
      if(Math.abs(delta)<=whiteboardRelationshipLimits.tolerance)relations.push({kind:'aligned-with',item:b.id,ref:a.id,feature,delta,tolerance:whiteboardRelationshipLimits.tolerance});
    }
    const ox=overlap(a.x,a.width,b.x,b.width),oy=overlap(a.y,a.height,b.y,b.height);
    if(oy>0&&ox<=0) {
      const [left,right]=a.x<b.x?[a,b]:[b,a];
      relations.push({kind:'right-of',item:right.id,ref:left.id,gap:right.x-left.x-left.width});
    }
    if(ox>0&&oy<=0) {
      const [top,bottom]=a.y<b.y?[a,b]:[b,a];
      relations.push({kind:'below',item:bottom.id,ref:top.id,gap:bottom.y-top.y-top.height});
    }
    if(a.width===b.width&&a.height===b.height)relations.push({kind:'same-size',item:b.id,ref:a.id,width:a.width,height:a.height});
    if(ox>0&&oy>0)relations.push({kind:'overlaps',item:b.id,ref:a.id,intersectionArea:ox*oy,itemFraction:ox*oy/(b.width*b.height),refFraction:ox*oy/(a.width*a.height)});
  }
  return {basis:'geometry' as const, scope:'returned-items-same-section' as const, persistent:false,
    tolerance:whiteboardRelationshipLimits.tolerance,maxGap:whiteboardRelationshipLimits.gap,
    maxNeighbors:whiteboardRelationshipLimits.neighbors,maxRelations:whiteboardRelationshipLimits.relations,
    candidatePairs:pairs.length,omittedPairs:pairs.length-selected.length,
    omittedRelations:Math.max(0,relations.length-whiteboardRelationshipLimits.relations),
    items:relations.slice(0,whiteboardRelationshipLimits.relations)};
}
