import {createHash} from 'node:crypto';
import {createConnection} from 'node:net';
import {healthObject as obj,healthText as text,type HealthStatus} from '@studio/contracts';
export const HEALTH_PROBE_TIMEOUT_MS=1500;
export type ProbeConfig={kind:'http';url:string;method:'GET'|'HEAD';expectedStatuses:number[]}|{kind:'tcp';host:string;port:number}|{kind:'unsupported'};
export interface ProbeResult {status:HealthStatus;message:string;durationMs:number;attempts:number;startedAt:string;finishedAt:string}
export function allowedProbeHost(value:string):boolean {
 const host=value.toLowerCase();return host==='localhost'||host==='127.0.0.1'||host.endsWith('.svc.cluster.local')||host==='infuse-ai.com'||host.endsWith('.infuse-ai.com')||host==='infuse-ai-tech.party'||host.endsWith('.infuse-ai-tech.party');
}
export function parseProbeConfig(value:unknown):ProbeConfig {
 const o=obj(value);
 if(o.kind==='unsupported')return {kind:'unsupported'};
 if(o.kind==='http'){
  let url:URL;try{url=new URL(text(o.url,2048));}catch{throw Error('Invalid protected probe URL');}if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.hash||!allowedProbeHost(url.hostname))throw Error('Probe target is outside the approved hosts/protocols');
  const method=o.method??'GET';if(method!=='GET'&&method!=='HEAD')throw Error('Only GET/HEAD health probes are allowed');
  const statuses=o.expectedStatuses??[];if(!Array.isArray(statuses)||statuses.length>20||statuses.some(s=>!Number.isInteger(s)||s<100||s>599)||new Set(statuses).size!==statuses.length)throw Error('Invalid expected HTTP statuses');
  return {kind:'http',url:url.href,method,expectedStatuses:[...statuses].sort((a,b)=>a-b)};
 }
 if(o.kind==='tcp'){
  const host=text(o.host,253).toLowerCase();if(!allowedProbeHost(host)||typeof o.port!=='number'||!Number.isInteger(o.port)||o.port<1||o.port>65535)throw Error('Invalid allowed TCP probe');
  return {kind:'tcp',host,port:o.port};
 }
 throw Error('Unsupported health probe configuration');
}
export function probeDigest(probe:ProbeConfig,resourceId:string):string{return createHash('sha256').update(JSON.stringify([resourceId,parseProbeConfig(probe)])).digest('hex');}
async function sleep(ms:number,signal:AbortSignal):Promise<void>{signal.throwIfAborted();if(ms<=0)return;await new Promise<void>((resolve,reject)=>{const done=()=>{signal.removeEventListener('abort',abort);resolve();},timer=setTimeout(done,ms),abort=()=>{clearTimeout(timer);reject(signal.reason);};signal.addEventListener('abort',abort,{once:true});});}
async function tcp(host:string,port:number,signal:AbortSignal):Promise<{status:HealthStatus;message:string}>{
 return new Promise((resolve,reject)=>{
  let settled=false;const socket=createConnection({host,port}),finish=(status:HealthStatus,message:string)=>{if(settled)return;settled=true;clearTimeout(timer);signal.removeEventListener('abort',abort);socket.destroy();resolve({status,message});};
  const timer=setTimeout(()=>finish('critical','TCP timeout'),HEALTH_PROBE_TIMEOUT_MS),abort=()=>{if(settled)return;settled=true;clearTimeout(timer);socket.destroy();reject(signal.reason);};
  signal.addEventListener('abort',abort,{once:true});if(signal.aborted){abort();return;}
  socket.once('connect',()=>finish('healthy','TCP connection accepted'));socket.once('error',()=>finish('critical','TCP connection failed'));
 });
}
export async function runProbe(probe:ProbeConfig,options:{retries?:number;retryDelayMs?:number;signal:AbortSignal;fetch?:typeof fetch}):Promise<ProbeResult>{
 const parsed=parseProbeConfig(probe),retries=options.retries??1,retryDelayMs=options.retryDelayMs??1000;
 if(!Number.isInteger(retries)||retries<0||retries>5||!Number.isInteger(retryDelayMs)||retryDelayMs<0||retryDelayMs>30000)throw Error('Invalid bounded probe retry policy');
 const startedAt=new Date().toISOString(),start=performance.now();let result:{status:HealthStatus;message:string}={status:'unknown',message:'Probe is unsupported'},attempts=0;
 for(let attempt=0;attempt<=retries;attempt++){
  options.signal.throwIfAborted();attempts++;
  if(parsed.kind==='http'){
   const timeout=AbortSignal.timeout(HEALTH_PROBE_TIMEOUT_MS),signal=AbortSignal.any([options.signal,timeout]);
   try{const response=await (options.fetch??fetch)(parsed.url,{method:parsed.method,redirect:'manual',signal,headers:{Accept:'*/*'}});await response.body?.cancel();result={status:response.ok||parsed.expectedStatuses.includes(response.status)?'healthy':'critical',message:`HTTP ${response.status}`};}
   catch{options.signal.throwIfAborted();result={status:'critical',message:timeout.aborted?'HTTP timeout':'HTTP connection failed'};}
  }else if(parsed.kind==='tcp')result=await tcp(parsed.host,parsed.port,options.signal);
  if(!['warning','critical'].includes(result.status)||attempt===retries)break;
  await sleep(retryDelayMs,options.signal);
 }
 return {...result,startedAt,finishedAt:new Date().toISOString(),durationMs:Math.round(performance.now()-start),attempts};
}
