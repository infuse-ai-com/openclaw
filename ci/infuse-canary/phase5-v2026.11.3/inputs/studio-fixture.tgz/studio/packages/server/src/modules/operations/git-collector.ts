import {createHash,randomUUID} from 'node:crypto';
import type {MissionStore} from '../../persistence/missions/store.js';
import type {OperationJob} from '../../persistence/missions/operations.js';
import type {GitRepositoryState} from '../../persistence/missions/git-contributions.js';
import {GitSourceError,type GitSource} from './git-source.js';
import {configuredGitMetadata,type GitContributionsConfig,type GitRepositoryConfig} from './git-config.js';
import { StudioGitLabPilotSource } from './studio-gitlab-pilot.js';
export type GitSourceFactory=(repository:GitRepositoryConfig)=>GitSource;
/** One page per source/tick; persisted leases and frozen cursors survive process restart and long outages. */
export class GitContributionsCollector {
 private owner=randomUUID();private timer?:ReturnType<typeof setInterval>;private active?:Promise<void>;private abort?:AbortController;private stopping=false;
 constructor(private store:MissionStore,private readConfig:()=>GitContributionsConfig|undefined,private factory?:GitSourceFactory){}
 start():void{if(this.timer)return;this.stopping=false;this.timer=setInterval(()=>{void this.tick().catch(()=>{});},1000);this.timer.unref();void this.tick().catch(()=>{});}
 async stop():Promise<void>{this.stopping=true;if(this.timer)clearInterval(this.timer);this.timer=undefined;this.abort?.abort();await this.active?.catch(()=>{});}
 tick():Promise<void>{if(this.active)return this.active;if(this.stopping)return Promise.resolve();this.active=this.collect().finally(()=>{this.active=undefined;});return this.active;}
 private async collect():Promise<void>{
  const config=this.readConfig();if(!config?.enabled||!config.repositories.length)return;
  if(config.registryOwned&&config.repositories.some(source=>!source.registryEpoch||!source.registryRevision))throw Error('registry_policy_unavailable');
  const snapshot=JSON.stringify(config),inventoryGuard=()=>{if(this.stopping||JSON.stringify(this.readConfig())!==snapshot)throw Object.assign(Error('Git inventory authority changed'),{code:'AUTHORITY_REVOKED'});};
  const sources=config.repositories.filter(source=>this.factory||source.gitLabPilotTokenEnv);
  if(!sources.length)return;
  const ids=sources.map(source=>'git-'+createHash('sha256').update(source.sourceId).digest('hex').slice(0,32));
  // One guarded writer request for all schedules, including sources that are not due.
  const jobs=await this.store.operations<(OperationJob|null)[]>({kind:'get-many',ids},inventoryGuard);
  for(const [index,source] of sources.entries()){
   const id=ids[index]!,current=jobs[index],now=Date.now();
   if((current?.nextRunAt??0)>now||current?.state==='running'&&(current.leaseUntil??0)>now)continue;
   if(this.stopping)return;const fingerprint=JSON.stringify([source,config.intervalMs]);
   const guard=()=>{const live=this.readConfig();if(this.stopping||!live?.enabled||JSON.stringify([live.repositories.find(r=>r.sourceId===source.sourceId),live.intervalMs])!==fingerprint)throw Object.assign(Error('Git source authority changed'),{code:'AUTHORITY_REVOKED'});};
   guard();
   const running:OperationJob={id,kind:'git-contributions',source:source.sourceId,revision:(current?.revision??0)+1,state:'running',checkpoint:current?.checkpoint??{},updatedAt:new Date(now).toISOString(),leaseOwner:this.owner,leaseUntil:now+60000};
   try{await this.store.operations({kind:'save',expectedRevision:current?.revision??0,job:running},guard);}catch(e){if(['BUSY','VERSION_CONFLICT'].includes(String((e as {code?:string}).code)))continue;throw e;}
   const progress={expectedRevision:running.revision,job:{...running,revision:running.revision+1,updatedAt:new Date().toISOString()},intervalMs:source.intervalMs??config.intervalMs};
   const state=await this.store.gitContributions<{source:GitRepositoryState;branch:{name:string;head:string;offset:number}|null}|null>({kind:'inspect',sourceId:source.sourceId},guard);
   this.abort=new AbortController();const timeout=setTimeout(()=>this.abort?.abort(),10000);timeout.unref();
   try{
    const adapter=this.source(source),signal=this.abort.signal,scanProvider=source.gitLabPilotTokenEnv?'gitlab':undefined;
    const activeScan=state&&['refs','commits'].includes(state.source.stage);
    if(scanProvider&&activeScan&&!state.source.scanProvider){
     const repository=await adapter.metadata(signal),cycleId=new Date(Math.max(Date.now(),Date.parse(state.source.cycleId!)+1)).toISOString();
     await this.store.gitContributions({kind:'restart',repository,cycleId,reason:'provider-cutover',scanProvider,progress},guard);
    }else if(!state||state.source.stage==='idle'||state.source.stage==='complete'){
     const repository=await adapter.metadata(signal),cycleId=new Date(Math.max(Date.now(),Date.parse(state?.source.cycleId??'')+1||0)).toISOString();
     await this.store.gitContributions({kind:'begin',repository,cycleId,scanProvider,progress},guard);
    }else if(state.source.scanProvider==='gitlab'&&!scanProvider){
     // Removing the pilot pauses its generation so the exact GitLab cursor can resume on re-enable.
     throw new GitSourceError('GITLAB_PILOT_DISABLED',900000);
    }else if(state.source.stage==='refs'){
     const page=await adapter.refs(state.source.refsCursor,signal);
     await this.store.gitContributions({kind:'refs',sourceId:source.sourceId,cycleId:state.source.cycleId!,cursor:state.source.refsCursor,...page,progress},guard);
    }else{
     if(!state.branch)throw new GitSourceError('GIT_SCAN_STATE_INVALID');
     const page=await adapter.commits(state.branch.head,state.branch.offset,signal);
     await this.store.gitContributions({kind:'page',sourceId:source.sourceId,cycleId:state.source.cycleId!,branch:state.branch.name,head:state.branch.head,offset:state.branch.offset,commits:page.commits,nextOffset:page.nextOffset,progress},guard);
    }
   }catch(error){
    guard();
    if(error instanceof GitSourceError&&['AZURE_CURSOR_UNAVAILABLE','GITLAB_HEAD_UNAVAILABLE'].includes(error.code)&&state&&['refs','commits'].includes(state.source.stage)){
     try{const repository=await this.source(source).metadata(this.abort.signal),cycleId=new Date(Math.max(Date.now(),Date.parse(state.source.cycleId!)+1)).toISOString();
      await this.store.gitContributions({kind:'restart',repository,cycleId,reason:state.source.stage==='refs'?'cursor-expired':'head-unavailable',
       scanProvider:source.gitLabPilotTokenEnv?'gitlab':undefined,progress},guard);continue;
     }catch(recoveryError){error=recoveryError;guard();}
    }
    const fallback='GIT_SOURCE_UNAVAILABLE';
    const raw=String((error as {code?:string}).code??fallback),code=/^[A-Z][A-Z0-9_]{0,79}$/.test(raw)?raw:fallback;
    await this.store.gitContributions({kind:'failure',repository:configuredGitMetadata(source),code,retryAfterMs:error instanceof GitSourceError?error.retryAfterMs:30000,progress},guard);
   }finally{clearTimeout(timeout);this.abort=undefined;}
  }
 }
 private source(source:GitRepositoryConfig):GitSource {
  if(this.factory)return this.factory(source);
  const tokenEnv=source.gitLabPilotTokenEnv;
  return new StudioGitLabPilotSource(source,()=>tokenEnv?process.env[tokenEnv]:undefined);
 }
}
