export type MachineErrorCode = 'UNAUTHENTICATED' | 'FORBIDDEN' | 'INVALID_INPUT' | 'NOT_FOUND' | 'SOURCE_CHANGED' | 'INVALID_CURSOR' | 'RESULT_TOO_LARGE' | 'UNAVAILABLE';
const statuses: Record<MachineErrorCode, number> = { UNAUTHENTICATED: 401, FORBIDDEN: 403, INVALID_INPUT: 400, NOT_FOUND: 404, SOURCE_CHANGED: 409, INVALID_CURSOR: 409, RESULT_TOO_LARGE: 422, UNAVAILABLE: 503 };
export class MachineError extends Error {
  readonly status: number;
  constructor(readonly code: MachineErrorCode, readonly humanUrl?: string) {
    super(code); this.status = statuses[code];
  }
}
