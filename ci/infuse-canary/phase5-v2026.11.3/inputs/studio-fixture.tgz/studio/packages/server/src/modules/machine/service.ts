import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';
import { MACHINE_CONTRACT, MACHINE_RESPONSE_BYTES, machineResponses, artifactViewerPath, type MachineRequest, type ArtifactManifest, type RuntimeTarget } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
import type { MachineStoreResult } from '../../persistence/missions/machine-read.js';
import { MachineError } from './errors.js';

export interface MachinePrincipal { profileId: string; cursorBinding: string; project: { id: string; name: string }; targets: RuntimeTarget[] }
export interface MachineReadOptions {
  requestId: string; origin: string; authorityId: string; cursorKey(): Buffer;
  guard(): MachinePrincipal; artifact?(producer: string, artifactId: string, revision: string): Promise<ArtifactManifest>;
}
const cursorSchema = z.strictObject({ binding: z.string().regex(/^[a-f0-9]{64}$/), revision: z.string().regex(/^[a-f0-9]{64}$/), offset: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER), sequence: z.number().int().min(0), expires: z.number().int() });
const digest = (value: unknown) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
function preview(value: string): { text: string; truncated: boolean } {
  let text = '', bytes = 0;
  for (const character of value) { const size = Buffer.byteLength(character); if (bytes + size > 1024) break; text += character; bytes += size; }
  return { text, truncated: text.length !== value.length };
}
export class MachineReadService {
  constructor(private readonly store: MissionStore) {}
  async read(request: MachineRequest, options: MachineReadOptions): Promise<unknown> {
    const actor = options.guard(), value = request.value;
    const { cursor: inputCursor, ...filters } = value as typeof value & { cursor?: string };
    const binding = digest([options.authorityId, options.origin, actor.profileId, actor.cursorBinding, request.operation, filters]);
    let position: z.infer<typeof cursorSchema> | undefined;
    if (inputCursor) {
      try {
        const parts = inputCursor.split('.');
        if (parts.length !== 2 || parts.some(p => !/^[A-Za-z0-9_-]+$/.test(p) || Buffer.from(p, 'base64url').toString('base64url') !== p)) throw Error();
        const mac = createHmac('sha256', options.cursorKey()).update(parts[0]!).digest(), supplied = Buffer.from(parts[1]!, 'base64url');
        if (supplied.length !== mac.length || !timingSafeEqual(supplied, mac)) throw Error();
        position = cursorSchema.parse(JSON.parse(Buffer.from(parts[0]!, 'base64url').toString('utf8')));
        if (position.binding !== binding || position.expires <= Date.now() / 1000) throw Error();
      } catch { throw new MachineError('INVALID_CURSOR'); }
    }
    const offset = position?.offset ?? 0, sequence = position?.sequence ?? 0;
    const projectUrl = new URL(`/?project=${encodeURIComponent(value.projectId)}`, options.origin).href;
    const missionUrl = (id: string) => new URL(`/missions/v2/${encodeURIComponent(id)}?project=${encodeURIComponent(value.projectId)}`, options.origin).href;
    const cursor = (revision: string, next: number) => {
      const payload = Buffer.from(JSON.stringify({ binding, revision, offset: next, sequence: sequence + 1, expires: position?.expires ?? Math.floor(Date.now() / 1000) + 600 })).toString('base64url');
      return `${payload}.${createHmac('sha256', options.cursorKey()).update(payload).digest('base64url')}`;
    };
    const envelope = (data: unknown, revision: string, humanUrl: string) => ({ apiContract: MACHINE_CONTRACT, requestId: options.requestId, projectId: value.projectId, data,
      source: { authorityId: options.authorityId, origin: options.origin, humanUrl, revision } });
    const fits = (result: unknown) => Buffer.byteLength(JSON.stringify(result)) <= MACHINE_RESPONSE_BYTES;
    const finish = (result: unknown) => { options.guard(); if (!fits(result)) throw new MachineError('RESULT_TOO_LARGE', projectUrl); return machineResponses[request.operation].parse(result); };
    const page = (items: unknown[], base: Record<string, unknown>, field: 'items' | 'targets', revision: string, more: boolean, humanUrl: string) => {
      for (let size = items.length; size >= (items.length ? 1 : 0); size--) {
        const result = envelope({ ...base, [field]: items.slice(0, size), nextCursor: more || size < items.length ? cursor(revision, offset + size) : null }, revision, humanUrl);
        if (fits(result)) return finish(result);
      }
      throw new MachineError('RESULT_TOO_LARGE', humanUrl);
    };
    if (request.operation === 'context') {
      const targets = [...actor.targets].sort((a, b) => `${a.gatewayId}/${a.agentId}`.localeCompare(`${b.gatewayId}/${b.agentId}`));
      const revision = digest([actor.project, targets]);
      if (position && position.revision !== revision) throw new MachineError('SOURCE_CHANGED');
      return page(targets.slice(offset, offset + 20), { project: actor.project, capabilities: ['studio:read'], nativeContractVersion: 2 }, 'targets', revision, offset + 20 < targets.length, projectUrl);
    }
    if (request.operation === 'artifacts/read') {
      if (!options.artifact) throw new MachineError('UNAVAILABLE');
      const { producer, artifactId, revision } = request.value;
      const manifest = await options.artifact(producer, artifactId, revision); options.guard();
      if (manifest.project !== value.projectId || manifest.producer !== producer || manifest.artifactId !== artifactId || manifest.revision !== revision) throw new MachineError('NOT_FOUND');
      const humanUrl = new URL(`${artifactViewerPath(producer, artifactId, revision)}?project=${encodeURIComponent(value.projectId)}`, options.origin).href;
      const result = envelope({ manifest, humanUrl }, revision, humanUrl);
      if (!fits(result)) throw new MachineError('RESULT_TOO_LARGE', humanUrl);
      return finish(result);
    }
    const limit = request.operation === 'missions/list' ? request.value.limit ?? 10 : 20;
    let result: MachineStoreResult;
    try { result = await this.store.native<MachineStoreResult>({ kind: 'machine-read', request, offset, limit, revision: position?.revision }, () => { options.guard(); }); }
    catch (error) { const code = (error as { code?: string }).code; if (code === 'NOT_FOUND' || code === 'SOURCE_CHANGED') throw new MachineError(code); throw error; }
    options.guard();
    if (request.operation === 'missions/list') return page(result.missions!.map(m => ({ id: m.id, title: m.paper.title, state: m.state, held: m.held, version: m.version,
      paperRevision: m.paperRevision, paperDigest: m.paperDigest, updatedAt: m.updatedAt, humanUrl: missionUrl(m.id) })), {}, 'items', result.revision, result.more, projectUrl);
    const m = result.mission!, section = request.value.section ?? 'summary', humanUrl = missionUrl(m.id);
    const base = { missionId: m.id, section, missionVersion: m.version, paperRevision: m.paperRevision, paperDigest: m.paperDigest };
    if (section === 'summary') {
      if (position) throw new MachineError('INVALID_CURSOR');
      return finish(envelope({ ...base, nextCursor: null, title: m.paper.title, state: m.state, held: m.held, updatedAt: m.updatedAt, humanUrl, counts: result.counts!, approvalPresent: !!m.approval }, result.revision, humanUrl));
    }
    if (section === 'paper') {
      const paper = JSON.stringify(m.paper);
      if (createHash('sha256').update(paper).digest('hex') !== m.paperDigest) throw new MachineError('UNAVAILABLE');
      const characters = Array.from(paper);
      if (offset >= characters.length) throw new MachineError('INVALID_CURSOR');
      const build = (size: number) => envelope({ ...base, encoding: 'utf8-json', chunk: characters.slice(offset, offset + size).join(''), sequence,
        nextCursor: offset + size < characters.length ? cursor(result.revision, offset + size) : null }, result.revision, humanUrl);
      let low = 1, high = characters.length - offset, best = 0;
      while (low <= high) { const mid = Math.floor((low + high) / 2); if (fits(build(mid))) { best = mid; low = mid + 1; } else high = mid - 1; }
      if (!best) throw new MachineError('RESULT_TOO_LARGE', humanUrl);
      return finish(build(best));
    }
    const items = section === 'tasks' ? result.tasks!.map(t => {
      const p = preview(t.blocker ?? ''); return { id: t.id, title: t.plan.title, role: t.plan.role, state: t.state, version: t.version, required: t.plan.required, dependencies: t.plan.dependencies,
        ...(t.blocker === undefined ? {} : { blocker: p.text }), ...(t.evidenceId ? { evidenceId: t.evidenceId } : {}), previewTruncated: p.truncated };
    }) : result.evidence!.map(e => { const p = preview(e.summary); return { id: e.id, taskId: e.taskId, revision: e.revision, sha256: e.sha256, uri: e.uri, summary: p.text, references: e.references, previewTruncated: p.truncated }; });
    return page(items, base, 'items', result.revision, result.more, humanUrl);
  }
}
