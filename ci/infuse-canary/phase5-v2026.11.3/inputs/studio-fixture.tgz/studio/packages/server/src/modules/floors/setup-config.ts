import { z } from 'zod';
import { floorId } from '@studio/contracts';
import { allowedProbeHost } from '../operations/health-probes.js';
import { parseOperationsCluster, type OperationsCluster } from '../operations/company-config.js';
const name = z.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,99}$/);
const dns = z.string().regex(/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/);
const env = z.string().regex(/^[A-Z][A-Z0-9_]{0,99}$/);
const origin = z.string().refine(value => {
  try { const url = new URL(value); return allowedProbeHost(url.hostname) &&
    (url.protocol === 'https:' || url.protocol === 'http:' && (url.hostname.endsWith('.svc.cluster.local') || url.hostname === '127.0.0.1')) &&
    !url.username && !url.password && url.pathname === '/' && !url.search && !url.hash; } catch { return false; }
}, 'Use an approved service origin');
const provider = z.object({ origin, tokenEnv: env }).strict();
export const floorSetupConfigSchema = z.object({
  azure: z.object({ organization: name, tokenEnv: env }).strict().optional(),
  cluster: z.unknown().transform(value => parseOperationsCluster(value)).optional(),
  harbor: provider.optional(), grafana: provider.optional(),
  floors: z.array(z.object({
    id: floorId,
    azureProjects: z.array(z.object({ id: z.uuid(), name: z.string().min(1).max(100) }).strict()).max(32).default([]),
    repositories: z.array(z.object({ id: z.uuid(), projectId: z.uuid(), name: name }).strict()).max(32).default([]),
    namespace: dns.optional(),
    harbor: z.object({ id: z.number().int().positive(), name: name }).strict().optional(),
    grafana: z.object({ dashboardUid: name, datasourceUid: name, namespace: dns, deployment: dns,
      publicOrigin: origin }).strict().optional(),
  }).strict()).max(100),
}).strict().superRefine((value, ctx) => {
  if (new Set(value.floors.map(f => f.id)).size !== value.floors.length) ctx.addIssue({code:'custom',message:'Duplicate floor mapping'});
  for (const floor of value.floors) {
    if (new Set(floor.repositories.map(r => r.id)).size !== floor.repositories.length || new Set(floor.azureProjects.map(p => p.id)).size !== floor.azureProjects.length)
      ctx.addIssue({code:'custom',message:'Duplicate setup target'});
    if (floor.repositories.some(r => !floor.azureProjects.some(p => p.id === r.projectId))) ctx.addIssue({code:'custom',message:'Repository requires its explicit project mapping'});
    if (floor.grafana && floor.grafana.namespace !== floor.namespace) ctx.addIssue({code:'custom',message:'Monitoring namespace must match the floor mapping'});
  }
});
export type FloorSetupConfig = Omit<z.infer<typeof floorSetupConfigSchema>, 'cluster'> & { cluster?: OperationsCluster };
export type FloorSetupTarget = FloorSetupConfig['floors'][number];
export function parseFloorSetupConfig(value: unknown): FloorSetupConfig { return floorSetupConfigSchema.parse(value); }
