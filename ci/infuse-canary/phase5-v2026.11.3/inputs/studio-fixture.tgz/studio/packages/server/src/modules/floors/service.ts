import { floorActor, floorCommand, floorCommandTarget, type FloorActor, type FloorCommand, type FloorRecord, type FloorReceipt } from '@studio/contracts';
import { freezeFloorSnapshot, type FloorSnapshot } from './snapshot.js';
import type { MissionStore } from '../../persistence/missions/store.js';
import { MissionError, requireMission } from '../missions/domain.js';

export interface FloorPrincipal { actor: FloorActor; canManage: boolean }
export type FloorGuard = () => FloorPrincipal;
export class FloorService {
  private records: FloorSnapshot<FloorRecord[]> = Object.freeze([]);
  private pending = new Map<string, number>();
  private unavailable = false;
  constructor(private store: MissionStore) {}
  /** Startup read and post-commit refresh; this cache never writes independently. */
  async refresh(): Promise<void> { this.records = freezeFloorSnapshot(await this.store.floors<FloorRecord[]>({ kind: 'list' }, () => {})); this.unavailable = false; }
  /** Immutable generation; callers must reacquire at each admission boundary. */
  readSnapshot(): FloorSnapshot<FloorRecord[]> { return this.records; }
  /** Detached mutable records for editing/public projections. */
  snapshot(): readonly FloorRecord[] { return structuredClone(this.records) as FloorRecord[]; }
  record(id: string): FloorRecord | undefined { return structuredClone(this.records.find(record => record.id === id)) as FloorRecord | undefined; }
  assertSettled(id: string): void {
    requireMission(!this.unavailable && !this.pending.has(id), 'BUSY', 'Floor settings are changing. Refresh before continuing.');
  }
  private guard(current: FloorGuard): { actor: FloorActor; guard: () => void } {
    const initial = current();
    let actor: FloorActor;
    try { actor = floorActor.parse(initial.actor); } catch { throw new MissionError('FORBIDDEN', 'An admitted floor manager is required'); }
    const guard = () => {
      const live = current();
      requireMission(live.canManage === true && JSON.stringify(live.actor) === JSON.stringify(actor), 'FORBIDDEN', 'Floor management permission changed');
    };
    guard(); return { actor, guard };
  }
  async apply(input: unknown, current: FloorGuard, validate: (command: FloorCommand) => void): Promise<FloorReceipt> {
    let command: FloorCommand;
    try { command = floorCommand.parse(input); } catch { throw new MissionError('INVALID_INPUT', 'Invalid floor edits'); }
    const { actor, guard: admit } = this.guard(current);
    const guard = () => { admit(); validate(command); };
    guard();
    this.pending.set(floorCommandTarget(command), (this.pending.get(floorCommandTarget(command)) ?? 0) + 1);
    try {
      const receipt = await this.store.floors<FloorReceipt>({ kind: 'apply', command, actor }, guard);
      await this.refresh(); admit(); return receipt;
    } catch (error) {
      // A failed transport/worker response is not proof that the write failed.
      try { await this.refresh(); } catch { this.unavailable = true; }
      throw error;
    } finally {
      const count = (this.pending.get(floorCommandTarget(command)) ?? 1) - 1;
      if (count) this.pending.set(floorCommandTarget(command), count); else this.pending.delete(floorCommandTarget(command));
    }
  }
  async receipt(commandId: string, current: FloorGuard): Promise<FloorReceipt | null> {
    requireMission(/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/.test(commandId), 'INVALID_INPUT', 'Invalid command ID');
    const { actor, guard } = this.guard(current);
    const receipt = await this.store.floors<FloorReceipt | null>({ kind: 'receipt', commandId, actor }, guard);
    await this.refresh(); guard(); return receipt;
  }
}
