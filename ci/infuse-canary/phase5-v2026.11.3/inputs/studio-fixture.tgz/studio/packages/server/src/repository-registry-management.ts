import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { registryManagementCatalog, registryManagementReceipt, type FloorActor } from '@studio/contracts';
import { MissionError } from './modules/missions/domain.js';
import type { RegistryCodeConnection } from './repository-registry.js';

/** One transport for both human and attested agent commands. No local desired-state writer or automatic retries. */
export class RegistryManagementClient {
  constructor(private readonly connection: RegistryCodeConnection, private readonly fetcher: typeof fetch = fetch) {}
  async catalog(actor: FloorActor, guard: () => void) {
    return registryManagementCatalog.parse(await this.request('catalog', actor, guard));
  }
  async command(_input: unknown, _actor: FloorActor, guard: () => void): Promise<never> {
    guard();
    throw new MissionError('UNAVAILABLE', 'Legacy repository registry writes are retired');
  }
  async receipt(commandId: string, actor: FloorActor, guard: () => void) {
    if (!/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(commandId))
      throw new MissionError('INVALID_INPUT', 'Invalid repository operation');
    const receipt = registryManagementReceipt.parse(await this.request(`commands/${commandId}`, actor, guard));
    if (receipt.commandId !== commandId.toLowerCase()) throw new MissionError('UNAVAILABLE', 'Registry returned a different operation');
    return receipt;
  }
  private async request(path: string, actor: FloorActor, guard: () => void): Promise<unknown> {
    guard();
    const token = (await readFile(this.connection.tokenFile, 'utf8')).trim();
    if (!/^[A-Za-z0-9_-]{43,128}$/.test(token)) throw new MissionError('UNAVAILABLE', 'Registry connection is unavailable');
    const identity = actor.kind === 'human' ? ['human', actor.id] : ['agent', actor.gatewayId, actor.id];
    guard();
    let response: Response;
    try {
      response = await this.fetcher(new URL(`/internal/repository-registry/v1/${path}`, this.connection.baseUrl), {
        method: 'GET', redirect: 'error', signal: AbortSignal.timeout(12000),
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json',
          'X-Studio-Actor': createHash('sha256').update(JSON.stringify(identity)).digest('hex'),
          'X-Studio-Actor-Audit': Buffer.from(JSON.stringify(actor)).toString('base64url') },
      });
      const chunks: Uint8Array[] = []; let size = 0;
      for await (const chunk of response.body ?? []) {
        size += chunk.byteLength;
        if (size > 4 * 1024 * 1024) throw Error('response_limit');
        chunks.push(chunk);
      }
      guard();
      if (!response.ok) throw new MissionError(response.status === 409 ? 'STATE_CONFLICT' : response.status === 400 ? 'INVALID_INPUT' : response.status === 403 ? 'FORBIDDEN' : response.status === 404 ? 'NOT_FOUND' : 'UNAVAILABLE',
        response.status === 409 ? 'Repository settings changed. Reload before saving.' : 'Registry operation unavailable. Check its saved receipt before retrying.');
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch (error) {
      guard();
      if (error instanceof MissionError) throw error;
      throw new MissionError('UNAVAILABLE', 'Registry response was interrupted. Check the saved command before retrying.');
    }
  }
}
