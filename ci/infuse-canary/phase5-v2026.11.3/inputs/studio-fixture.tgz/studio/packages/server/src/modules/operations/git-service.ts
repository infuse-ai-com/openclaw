import type {MissionStore} from '../../persistence/missions/store.js';
import type {GitStoreCommand} from '../../persistence/missions/git-contributions.js';
export class GitContributionsService {
 constructor(private store:MissionStore){}
 read<T>(operation:Extract<GitStoreCommand,{kind:'read'|'day'|'inventory'}>,guard:()=>void):Promise<T>{return this.store.gitContributions(operation,guard);}
}
