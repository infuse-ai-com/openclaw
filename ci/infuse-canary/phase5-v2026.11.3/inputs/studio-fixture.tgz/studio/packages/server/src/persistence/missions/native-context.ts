import type { StorageDatabase } from './sql.js';
import { createHash } from 'node:crypto';
import { nativeHistoryCollections, nativeToolTextWeight, type NativeAssignment, type NativeHistoryQuery, type NativeRecordQuery } from '@studio/contracts';
import { requireMission } from '../../modules/missions/domain.js';

// Conservative bound for the host's minimum 16k weighted-character tool limit.
// ASCII costs one; every non-ASCII codepoint reserves its worst supported weight.
export const nativeTextWeight = nativeToolTextWeight;
export function nativeResultWeight(value: unknown) { return nativeTextWeight(JSON.stringify(value)); }
function preview(text: string, budget = 500) {
  let result = ''; let size = 0;
  for (const c of text) { const next = c.codePointAt(0)! < 128 ? 1 : 16; if (size + next > budget) break; result += c; size += next; }
  return result;
}
export function assignmentContext(assignment: NativeAssignment) {
  const { handoff: _handoff, previousSessions, ...current } = assignment;
  return { ...current, previousSessionCount: previousSessions?.length ?? 0, recordRef: { collection: 'assignments', id: assignment.id } };
}
export function compactNativeRecord(collection: string, item: Record<string, any>) {
  let value = { ...item };
  if (collection === 'assignments') value = assignmentContext(item as NativeAssignment);
  if (collection === 'evidence') { delete value.artifact; delete value.references; }
  if (collection === 'findings') {
    // Keep actionable identity/state visible even when fix/check history grows.
    value = { id: item.id, missionId: item.missionId, taskId: item.taskId, version: item.version,
      paperRevision: item.paperRevision, state: item.state, severity: item.severity, required: item.required,
      title: preview(item.title, 150), evidenceId: item.evidenceId, partial: true };
  }
  if (collection === 'tasks') {
    value.plan = { ...value.plan, objective: preview(value.plan.objective), acceptance: preview(value.plan.acceptance) };
    if (value.plan.dependencies.length > 8) value.plan.dependencies = value.plan.dependencies.slice(0, 8);
    if (value.review) value.review = { ...value.review, summary: preview(value.review.summary) };
    if (value.blocker) value.blocker = preview(value.blocker);
  }
  for (const field of ['text', 'prompt', 'summary', 'failure']) if (typeof value[field] === 'string') value[field] = preview(value[field], field === 'prompt' ? 1000 : 500);
  delete value.deliveryText;
  const recordRef = { collection, id: String(item.id ?? item.sequence) };
  value.recordRef = recordRef;
  if (JSON.stringify(value) !== JSON.stringify({ ...item, recordRef })) value.partial = true;
  if (nativeResultWeight(value) > 2500) value = { id: item.id, sequence: item.sequence, missionId: item.missionId, partial: true, recordRef };
  return value;
}

/** Each independently requested history page fits the minimum host tool budget. */
export async function nativeHistory(db: StorageDatabase, missionId: string, query: NativeHistoryQuery, budget = 9000) {
  requireMission(nativeHistoryCollections.includes(query.collection), 'INVALID_INPUT', 'Unknown history collection');
  const collection = query.collection;
  const cursor = query.before ? Number(query.before) : Number.MAX_SAFE_INTEGER;
  const rows = (await db.prepare(`SELECT rowid AS cursor, body FROM native_${collection} WHERE mission_id=? AND rowid<? ORDER BY rowid DESC LIMIT 41`).all(missionId, cursor));
  const items: unknown[] = []; let bytes = 0; let lastCursor: string | undefined;
  for (const row of rows) {
    const parsed = JSON.parse(String(row.body));
    if (collection === 'events') parsed.sequence = Number(row.cursor);
    const item = compactNativeRecord(collection, parsed); const size = nativeResultWeight(item);
    if (items.length >= 40 || bytes + size > budget) break;
    items.push(item); bytes += size; lastCursor = String(row.cursor);
  }
  const truncated = items.length < rows.length;
  return { [collection]: items.reverse(), pages: { [collection]: { truncated, ...(truncated ? { nextBefore: lastCursor ?? String(cursor) } : {}) } } };
}

export function nativeJsonPage(body: string, offset = 0) {
  requireMission(Number.isSafeInteger(offset) && offset >= 0 && offset < body.length, 'INVALID_INPUT', 'Invalid record offset');
  let end = Math.min(body.length, offset + 4000);
  let page;
  do {
    page = { format: 'json-fragment', content: body.slice(offset, end), offset, totalLength: body.length,
      sha256: createHash('sha256').update(body).digest('hex'), ...(end < body.length ? { nextOffset: end } : {}) };
    if (nativeResultWeight(page) <= 9000) return page;
    end = offset + Math.max(1, Math.floor((end - offset) / 2));
  } while (end > offset);
  throw Error('Cannot fit a record page');
}
export async function nativeRecord(db: StorageDatabase, missionId: string, query: NativeRecordQuery) {
  let row;
  if (query.collection === 'paper') row = (await db.prepare('SELECT body FROM native_papers WHERE mission_id=? AND revision=?').get(missionId, query.id));
  else {
    requireMission(nativeHistoryCollections.includes(query.collection), 'INVALID_INPUT', 'Unknown record collection');
    row = (await db.prepare(`SELECT body FROM native_${query.collection} WHERE mission_id=? AND ${query.collection === 'events' ? 'sequence' : 'id'}=?`).get(missionId, query.id));
  }
  requireMission(row, 'NOT_FOUND', 'Record is outside this admitted mission');
  if (query.collection === 'evidence') {
    const evidence = JSON.parse(String(row.body));
    requireMission(createHash('sha256').update(evidence.artifact.content).digest('hex') === evidence.sha256, 'ARTIFACT_INTEGRITY', 'Evidence hash mismatch');
  }
  return { missionId, record: { collection: query.collection, id: query.id, ...nativeJsonPage(String(row.body), query.offset) } };
}

export async function nativeContext(db: StorageDatabase, mission: Record<string, any>, assignment: NativeAssignment, action: Record<string, any>) {
  let paper = mission.paper; const paperPartial = nativeResultWeight(paper) > 3000;
  if (paperPartial) paper = { title: preview(paper.title), objective: preview(paper.objective), acceptance: preview(paper.acceptance), coordinator: paper.coordinator,
    humanAcceptance: paper.humanAcceptance, taskCount: paper.tasks.length, recordRef: { collection: 'paper', id: String(mission.paperRevision) } };
  const result: Record<string, any> = { mission: { ...mission, paper, ...(paperPartial ? { paperPartial: true } : {}) }, assignment: assignmentContext(assignment),
    action: compactNativeRecord('actions', action), assignments: [assignmentContext(assignment)], actions: [], replies: [], provisioning: [], pages: {},
    historyAvailable: nativeHistoryCollections, note: 'Partial records have recordRef. Fetch exact JSON fragments with record before planning or reviewing missing content. History pages are independently bounded; follow pages.nextBefore.' };
  if (assignment.instructionVersion === 1) {
    const items = (await db.prepare('SELECT body FROM native_instructions WHERE assignment_id=?').all(assignment.id)).map(r => JSON.parse(String(r.body)));
    result.inbox = { version: 1, sequence: items.at(-1)?.sequence ?? 0, unresolved: items.filter(i => !['applied', 'superseded'].includes(i.state)).length,
      query: { inbox: {} }, note: 'Read every inbox page before delivery. Pass current sequence and applied outcomes; on conflict refresh, or block and settle.' };
  }
  // Current task state is prioritized. Historical text never grows the default envelope.
  for (const collection of ['tasks', 'events', 'evidence', 'threads', 'findings'] as const) {
    const budget = Math.max(0, Math.min(collection === 'tasks' ? 4500 : 1000, 11500 - nativeResultWeight(result) - 300));
    const page = (await nativeHistory(db, mission.id, { collection }, budget));
    result[collection] = page[collection]; Object.assign(result.pages, page.pages);
  }
  requireMission(nativeResultWeight(result) <= 12000, 'CONTEXT_LIMIT', 'Current context exceeds the supported tool budget');
  return result;
}
