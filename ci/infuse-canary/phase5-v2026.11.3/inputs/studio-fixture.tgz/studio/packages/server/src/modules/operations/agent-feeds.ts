import { telemetryObject as obj, telemetryString as str, telemetryTime as time, telemetryCount as count,
  parseTelemetryInput, parseTelemetryData, type RuntimeObservation, type TelemetryInput, type TelemetryKind, type RuntimeTarget, type UsageBucket, type CollectorObservation } from '@studio/contracts';

export interface AgentFeedMapping extends RuntimeTarget { sourceId:string; kind:TelemetryKind; feedAgentId:string; gatewayLabel:string }
/** Accept the Python producers' explicit UTC format without weakening stored/API timestamps. */
function feedTime(value: unknown, { truncateSubmilliseconds = false } = {}): string {
  const raw = str(value, 40);
  const match = /^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d{1,6}))?(?:Z|\+00:00)$/.exec(raw);
  if (!match) throw Error('Invalid feed UTC timestamp');
  // Generations use stored millisecond precision; bucket boundaries must remain exact.
  if (!truncateSubmilliseconds && /[1-9]/.test((match[2] ?? '').slice(3))) throw Error('Inexact feed bucket timestamp');
  return time(`${match[1]}.${(match[2] ?? '').padEnd(3, '0').slice(0, 3)}Z`);
}
/** BO feed compatibility adapter. Project only explicitly selected sanitized fields. Never persist raw input. */
export function decodeAgentFeed(raw:unknown,mapping:AgentFeedMapping,observedAt:string):TelemetryInput {
  const root=obj(raw),generatedAt=feedTime(root.generatedAt, { truncateSubmilliseconds: true });
  if(mapping.kind==='collectors')return decodeSessionFeed(root,mapping,generatedAt,observedAt);
  const source=obj(root.source);
  if(mapping.kind==='schedules'){
    if(root.schemaVersion!==1||source.type!=='openclaw_schedules'||source.agentId!==mapping.feedAgentId||source.gatewayLabel!==mapping.gatewayLabel
      ||source.backend!=='gateway_cron_list'||source.paginationComplete!==true||source.status!=='available')throw Error('Invalid complete schedule feed identity');
    return parseTelemetryInput({sourceId:mapping.sourceId,gatewayId:mapping.gatewayId,agentId:mapping.agentId,kind:'schedules',generatedAt,observedAt,sourceStatus:'available',
      data:{snapshotRevision:source.snapshotRevision,tasks:root.tasks}});
  }
  const expected=mapping.kind==='usage'?'openclaw_agent_token_usage':'openclaw_agent_model_policy';
  if(root.schemaVersion!==1||source.type!==expected||source.agentId!==mapping.feedAgentId||source.gatewayLabel!==mapping.gatewayLabel)throw Error('Feed identity does not match explicit mapping');
  const common={sourceId:mapping.sourceId,gatewayId:mapping.gatewayId,agentId:mapping.agentId,kind:mapping.kind,generatedAt,observedAt,sourceStatus:str(source.status,80)};
  if(mapping.kind==='model')return parseTelemetryInput({...common,data:obj(root.modelPolicy)});
  if(mapping.kind!=='usage')throw Error('Runtime requires its configured Kubernetes adapter');
  const usage=obj(root.usage),rows:UsageBucket[]=[];
  // Empty published arrays are an actual empty window. Absent arrays are unknown, never zero.
  if(!Array.isArray(usage.daily)&&!Array.isArray(usage.periods4h))throw Error('Usage coverage is absent');
  for(const [field,minutes] of [['daily',1440],['periods4h',240]] as const) {
    if(usage[field]===undefined)continue;
    const list=usage[field];if(!Array.isArray(list)||list.length>768)throw Error('Invalid usage rows');
    for(const value of list) {
      const row=obj(value);let start:unknown;
      if(minutes===1440){const date=str(row.date,10);if(!/^\d{4}-\d\d-\d\d$/.test(date))throw Error('Invalid usage date');start=date+'T00:00:00.000Z';}
      else {start=row.periodStartIso??row.periodStart??row.bucketStartIso??row.bucketStart??row.startIso??row.start??row.from;
        if(start===undefined&&typeof row.date==='string'&&Number.isInteger(row.hour))start=`${row.date}T${String(row.hour).padStart(2,'0')}:00:00.000Z`;}
      rows.push({...row,start:feedTime(start),minutes,provider:row.provider??'unknown',model:row.model??'unknown'} as UsageBucket);
    }
  }
  return parseTelemetryInput({...common,data:rows,usageSummary:{today:usage.today,last7d:usage.last7d,byModel:usage.byModel}});
}
function decodeSessionFeed(root:Record<string,unknown>,m:AgentFeedMapping,generatedAt:string,observedAt:string):TelemetryInput {
  if(root.schema!=='openclaw.session-metadata.v1'||!Array.isArray(root.sessions)||!Array.isArray(root.tasks)||root.sessions.length+root.tasks.length>10000)throw Error('Invalid sanitized session feed');
  const data:CollectorObservation={running:0,waiting:0,completed24h:0,failed24h:0,sessions:0,tasks:0,unknown:0};
  const generatedMs=Date.parse(generatedAt),cutoff=generatedMs-86400000;
  for(const [field,items] of [['sessions',root.sessions],['tasks',root.tasks]] as const)for(const raw of items){
    const item=obj(raw);if(item.agentId!==m.feedAgentId)continue;data[field]++;
    const status=str(item.status,48),stamp=(key:string)=>item[key]===undefined?undefined:Date.parse(time(item[key]));
    const ended=stamp('endedAt'),updated=stamp('updatedAt'),event=stamp('lastEventAt'),started=stamp('startedAt'),created=stamp('createdAt');
    const last=updated??event??started??created,completed=ended??updated??event;
    const recent=ended===undefined&&last!==undefined&&last>=cutoff&&last<=generatedMs;
    const running=['active','running','in_progress','started'].includes(status);
    const waiting=field==='tasks'&&(status==='queued'||status==='waiting'||item.deliveryStatus==='session_queued'||item.terminalOutcome==='blocked');
    const done=field==='sessions'?['done','completed'].includes(status):['succeeded','completed'].includes(status);
    const failed=['failed','errored','error','cancelled','aborted'].includes(status);
    if(running&&recent)data.running++;
    if(waiting&&(recent||completed!==undefined&&completed>=cutoff&&completed<=generatedMs))data.waiting++;
    if(completed!==undefined&&completed>=cutoff&&completed<=generatedMs){if(done)data.completed24h++;if(failed)data.failed24h++;}
    if(!running&&!waiting&&!done&&!failed||ended===undefined&&(running||waiting)&&last===undefined||(done||failed)&&completed===undefined||completed!==undefined&&completed>generatedMs)data.unknown++;
  }
  return parseTelemetryInput({sourceId:m.sourceId,gatewayId:m.gatewayId,agentId:m.agentId,kind:m.kind,generatedAt,observedAt,sourceStatus:'available',data});
}
/** Minimal projection from authorized Kubernetes reads; private pod/container configuration is discarded. */
export function decodeRuntime(deployment:unknown,pods:unknown,m:Pick<AgentFeedMapping,'sourceId'|'gatewayId'|'agentId'>,observedAt:string):TelemetryInput {
 return parseTelemetryInput({...m,kind:'runtime',...decodeRuntimeObservation(deployment,pods,observedAt)});
}
/** Shared resource projection, with no invented agent or Gateway identity. */
export function decodeRuntimeObservation(deployment:unknown,pods:unknown,observedAt:string):{generatedAt:string;observedAt:string;sourceStatus:'available'|'unknown';data:RuntimeObservation} {
  const d=obj(deployment),status=obj(d.status),spec=obj(d.spec),metadata=obj(d.metadata),p=obj(pods);
  if(!Array.isArray(p.items)||p.items.length>200||p.metadata&&obj(p.metadata).continue)throw Error('Incomplete Kubernetes pod coverage');
  let restarts=0;
  for(const raw of p.items){const pod=obj(raw);const statuses=pod.status?obj(pod.status).containerStatuses:undefined;
    if(statuses!==undefined){if(!Array.isArray(statuses)||statuses.length>100)throw Error('Invalid pod statuses');for(const c of statuses)restarts+=count(obj(c).restartCount);}}
  const template=obj(spec.template),podSpec=obj(template.spec);
  const templateMetadata=template.metadata?obj(template.metadata):{};
  const annotations=templateMetadata.annotations?obj(templateMetadata.annotations):{};
  const containers=podSpec.containers;if(!Array.isArray(containers)||!containers.length)throw Error('Runtime image missing');
  return {generatedAt:time(observedAt),observedAt:time(observedAt),sourceStatus:Number.isSafeInteger(metadata.generation)&&Number.isSafeInteger(status.observedGeneration)&&(metadata.generation as number)>=0&&(status.observedGeneration as number)>=0&&(status.observedGeneration as number)>=(metadata.generation as number)?'available':'unknown',data:parseTelemetryData('runtime',{
    desiredReplicas:count(spec.replicas??1),readyReplicas:count(status.readyReplicas??0),restarts,
    ...(annotations['openclaw.infuse-ai.com/version']===undefined?{}:{version:str(annotations['openclaw.infuse-ai.com/version'])}),image:str(obj(containers[0]).image,512)}) as RuntimeObservation};
}
