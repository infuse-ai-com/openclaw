import { missionIdentifier,gitGuid,gitObject as obj,gitText as text,parseGitRepositoryIdentity,gitRepositoryUrl,type GitRepositoryIdentity,type GitRepositoryMetadata } from '@studio/contracts';
export interface GitLabContributionProject {id:number;path:string}
export interface GitLabContributionBinding extends GitRepositoryIdentity {registryId:string;gitLabProject:GitLabContributionProject}
export interface GitRepositoryConfig extends GitRepositoryIdentity {floorIds:string[];tokenEnv?:string;name:string;projectName:string;intervalMs?:number;registryEpoch?:string;registryRevision?:number;gitLabPilotTokenEnv?:string;gitLabProject?:GitLabContributionProject}
export interface GitContributionsConfig {registryOwned?:true;enabled:boolean;intervalMs:number;repositories:GitRepositoryConfig[];authorAliases:{key:string;label:string;kind:'person'|'agent'|'bot'}[];studioGitLabPilotTokenEnv?:string;gitLabProjects?:GitLabContributionBinding[]}
function keys(o:Record<string,unknown>,allowed:string[]):void{if(Object.keys(o).some(k=>!allowed.includes(k)))throw Error('Unknown Git configuration field');}
export function parseGitContributionsConfig(value:unknown):GitContributionsConfig {
 const root=obj(value);keys(root,['enabled','intervalMs','repositories','credentialBindings','authorAliases','studioGitLabPilotTokenEnv','gitLabProjects']);
 const registryOwned=root.credentialBindings!==undefined;if(registryOwned&&root.repositories!==undefined)throw Error('Git credentials must have one source');
 const input=registryOwned?root.credentialBindings:root.repositories;
 const intervalMs=root.intervalMs??900000;if(typeof root.enabled!=='boolean'||typeof intervalMs!=='number'||!Number.isSafeInteger(intervalMs)||intervalMs<30000||intervalMs>86400000||!Array.isArray(input)||input.length>100)throw Error('Invalid Git collection configuration');
 const repositories=input.map(raw=>{const r=obj(raw);keys(r,registryOwned?['sourceId','organization','projectId','repositoryId','tokenEnv']:['sourceId','organization','projectId','repositoryId','floorIds','tokenEnv','name','projectName']);const id=parseGitRepositoryIdentity(r);
  if(!registryOwned&&(!Array.isArray(r.floorIds)||!r.floorIds.length||r.floorIds.length>100))throw Error('Git repositories require explicit Studio floor admission');
  const floorIds=registryOwned?[]:(r.floorIds as unknown[]).map(missionIdentifier);
  const tokenEnv=registryOwned&&r.tokenEnv===undefined?undefined:text(r.tokenEnv);
  if(new Set(floorIds).size!==floorIds.length||tokenEnv!==undefined&&!/^[A-Z][A-Z0-9_]*$/.test(tokenEnv))throw Error('Invalid source admission or credential reference');
  return {...id,floorIds,...(tokenEnv===undefined?{}:{tokenEnv}),name:r.name===undefined?id.repositoryId:text(r.name),projectName:r.projectName===undefined?id.projectId:text(r.projectName)};
 });
 if(new Set(repositories.map(r=>r.sourceId)).size!==repositories.length||new Set(repositories.map(r=>r.organization+'/'+r.repositoryId)).size!==repositories.length)throw Error('Duplicate Git source/repository identity');
 const aliases=root.authorAliases??[];if(!Array.isArray(aliases)||aliases.length>500)throw Error('Invalid Git display aliases');
 const authorAliases=aliases.map(raw=>{const a=obj(raw);keys(a,['key','label','kind']);if(!['person','agent','bot'].includes(String(a.kind)))throw Error('Unknown author alias kind');return {key:text(a.key,1024).trim().toLowerCase(),label:text(a.label),kind:a.kind as 'person'|'agent'|'bot'};});
 if(authorAliases.some(a=>a.key.length>1024)||new Set(authorAliases.map(a=>a.key)).size!==authorAliases.length)throw Error('Duplicate Git author display alias');
 const pilot=root.studioGitLabPilotTokenEnv;
 if(pilot!==undefined&&(!registryOwned||typeof pilot!=='string'||!/^[A-Z][A-Z0-9_]{0,127}$/.test(pilot)||repositories.some(repo=>repo.tokenEnv===pilot)))throw Error('Studio GitLab pilot requires a separate registry-owned credential');
 const gitLabProjects=root.gitLabProjects===undefined?undefined:parseGitLabProjects(root.gitLabProjects,repositories,pilot);
 return {...(registryOwned?{registryOwned:true as const}:{}),enabled:root.enabled,intervalMs,repositories,authorAliases,...(pilot===undefined?{}:{studioGitLabPilotTokenEnv:pilot}),
  ...(gitLabProjects===undefined?{}:{gitLabProjects})};
}
function parseGitLabProjects(value:unknown,repositories:GitRepositoryConfig[],tokenEnv:string|undefined):GitLabContributionBinding[] {
 if(!tokenEnv||!Array.isArray(value)||value.length>repositories.length)throw Error('GitLab projects require registry bindings and a credential reference');
 const projects=value.map(raw=>{
  const row=obj(raw);keys(row,['sourceId','organization','projectId','repositoryId','registryId','gitLabProject']);
  const identity=parseGitRepositoryIdentity(row),registryId=gitGuid(row.registryId);
  if(!repositories.some(repository=>sameGitSource(repository,identity)))throw Error('GitLab project must match a configured source');
  const project=obj(row.gitLabProject);keys(project,['id','path']);
  const {id}=project,path=text(project.path,1024);
  if(typeof id!=='number'||!Number.isSafeInteger(id)||id<1||!path.split('/').every(segment=>/^[A-Za-z0-9_][A-Za-z0-9_.-]*$/.test(segment))||!path.includes('/'))
   throw Error('Invalid GitLab project identity');
  return {...identity,registryId,gitLabProject:{id,path}};
 });
 for(const ids of [projects.map(p=>p.sourceId),projects.map(p=>p.registryId),projects.map(p=>p.gitLabProject.id),projects.map(p=>p.gitLabProject.path.toLowerCase())]){
  if(new Set<string|number>(ids).size!==projects.length)throw Error('Duplicate GitLab project mapping');
 }
 return projects;
}
export function sameGitSource(a:GitRepositoryIdentity,b:GitRepositoryIdentity):boolean {
 return a.sourceId===b.sourceId&&a.organization===b.organization&&a.projectId===b.projectId&&a.repositoryId===b.repositoryId;
}
export function configuredGitMetadata(source:GitRepositoryConfig):GitRepositoryMetadata {const id=parseGitRepositoryIdentity(source);return {...id,name:source.name,projectName:source.projectName,url:gitRepositoryUrl(id)};}

/** Import only credential bindings from the protected pre-transfer configuration.
 * Its names, repository selection and floor fields have no runtime authority. */
export function registryGitCredentialBindings(value: unknown): unknown {
 const root=obj(value);
 if(root.credentialBindings!==undefined)return root;
 keys(root,['enabled','intervalMs','repositories','authorAliases','studioGitLabPilotTokenEnv','gitLabProjects']);
 if(!Array.isArray(root.repositories))throw Error('Invalid Git credential bindings');
 const credentialBindings=root.repositories.map(raw=>{
  const row=obj(raw);
  keys(row,['sourceId','organization','projectId','repositoryId','floorIds','tokenEnv','name','projectName']);
  return {sourceId:row.sourceId,organization:row.organization,projectId:row.projectId,repositoryId:row.repositoryId,tokenEnv:row.tokenEnv};
 });
 const {repositories: _retired,...settings}=root;
 return {...settings,credentialBindings};
}
