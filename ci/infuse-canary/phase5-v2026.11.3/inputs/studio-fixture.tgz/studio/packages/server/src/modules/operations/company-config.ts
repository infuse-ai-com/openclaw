import {createHash} from 'node:crypto';
import {isAbsolute,resolve} from 'node:path';
import {missionIdentifier,healthObject as object,healthText as text,providerTimeZone,gitGuid,type CompanySignalDefinition} from '@studio/contracts';
export interface OperationsCluster {origin:string;tokenFile:string;caFile:string}
export type ProviderSignalTransport={type:'file';path:string}|{type:'config-map';namespace:string;name:string;key:string};
interface SourceBase extends CompanySignalDefinition {floorIds:string[]}
export type CompanySignalConfig=
 | SourceBase&{kind:'runtime';transport:{type:'runtime';namespace:string;deployment:string}}
 | SourceBase&{kind:'provider-usage';owner:string;provider:string;bucketTimeZone?:string;transport:ProviderSignalTransport}
 | SourceBase&{kind:'pipeline';transport:{type:'azure-builds';organization:string;projectId:string;definitionId:number;tokenEnv:string}};
type SourceDetails=
 | {kind:'runtime';transport:Extract<CompanySignalConfig,{kind:'runtime'}>['transport']}
 | {kind:'provider-usage';owner:string;provider:string;bucketTimeZone?:string;transport:ProviderSignalTransport}
 | {kind:'pipeline';transport:Extract<CompanySignalConfig,{kind:'pipeline'}>['transport']};
export interface CompanySignalsConfig {enabled:boolean;sources:CompanySignalConfig[];cluster?:OperationsCluster}
export function operationKeys(o:Record<string,unknown>,allowed:string[]):void {if(Object.keys(o).some(key=>!allowed.includes(key)))throw Error('Unknown operational source configuration field');}
export function operationPath(value:unknown):string {const path=text(value,4096);if(!isAbsolute(path))throw Error('Operational paths must be absolute');return resolve(path);}
export function operationDns(value:unknown):string {const name=text(value,253);if(!/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/.test(name))throw Error('Invalid Kubernetes source name');return name;}
export function parseOperationsCluster(value:unknown):OperationsCluster {
 const c=object(value);operationKeys(c,['origin','tokenFile','caFile']);let url:URL;try{url=new URL(text(c.origin,2048));}catch{throw Error('Invalid protected Kubernetes origin');}
 if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw Error('Kubernetes requires an explicit HTTPS origin');
 return {origin:url.origin,tokenFile:operationPath(c.tokenFile),caFile:operationPath(c.caFile)};
}
function number(value:unknown,fallback:number,min:number,max:number):number {const n=value??fallback;if(typeof n!=='number'||!Number.isSafeInteger(n)||n<min||n>max)throw Error('Invalid bounded company source policy');return n;}
export function parseCompanySignalsConfig(value:unknown):CompanySignalsConfig {
 const root=object(value);operationKeys(root,['enabled','sources','cluster']);if(typeof root.enabled!=='boolean'||!Array.isArray(root.sources)||root.sources.length>50)throw Error('Invalid company signal configuration');
 const cluster=root.cluster===undefined?undefined:parseOperationsCluster(root.cluster);
 const sources:CompanySignalConfig[]=root.sources.map((raw):CompanySignalConfig=>{
  const s=object(raw);operationKeys(s,['sourceId','resourceId','kind','name','owner','provider','bucketTimeZone','floorIds','intervalMs','staleAfterMs','transport']);
  const sourceId=missionIdentifier(s.sourceId),resourceId=missionIdentifier(s.resourceId),name=text(s.name),intervalMs=number(s.intervalMs,300000,30000,86400000),staleAfterMs=number(s.staleAfterMs,Math.min(86400000,intervalMs*3),intervalMs,86400000);
  if(!Array.isArray(s.floorIds)||!s.floorIds.length||s.floorIds.length>100)throw Error('Company sources require explicit floor admission');
  const floorIds=s.floorIds.map(missionIdentifier);if(new Set(floorIds).size!==floorIds.length)throw Error('Duplicate company floor admission');
  const t=object(s.transport);let details:SourceDetails;
  if(s.kind==='runtime'){
   if(s.owner!==undefined||s.provider!==undefined||s.bucketTimeZone!==undefined)throw Error('Runtime sources do not carry provider/account metadata');
   operationKeys(t,['type','namespace','deployment']);if(t.type!=='runtime')throw Error('Runtime signals require Kubernetes');
   details={kind:'runtime',transport:{type:'runtime',namespace:operationDns(t.namespace),deployment:operationDns(t.deployment)}};
  }else if(s.kind==='provider-usage') {
   let transport:ProviderSignalTransport;
   if(t.type==='file'){operationKeys(t,['type','path']);transport={type:'file',path:operationPath(t.path)};}
   else if(t.type==='config-map'){operationKeys(t,['type','namespace','name','key']);transport={type:'config-map',namespace:operationDns(t.namespace),name:operationDns(t.name),key:text(t.key)};}
   else throw Error('Provider usage requires a sanitized file/ConfigMap feed');
   const provider=text(s.provider,100);if(!/^[a-z][a-z0-9_-]*$/.test(provider))throw Error('Invalid explicit provider identity');
   const bucketTimeZone=providerTimeZone(s.bucketTimeZone);details={kind:'provider-usage',owner:text(s.owner),provider,transport,...(bucketTimeZone?{bucketTimeZone}:{})};
  }else if(s.kind==='pipeline') {
   if(s.owner!==undefined||s.provider!==undefined||s.bucketTimeZone!==undefined)throw Error('Pipeline signals do not carry provider/account metadata');
   operationKeys(t,['type','organization','projectId','definitionId','tokenEnv']);const organization=text(t.organization,100).toLowerCase(),tokenEnv=text(t.tokenEnv);
   if(t.type!=='azure-builds'||!/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/.test(organization)||!/^[A-Z][A-Z0-9_]*$/.test(tokenEnv))throw Error('Invalid explicit pipeline source');
   details={kind:'pipeline',transport:{type:'azure-builds',organization,projectId:gitGuid(t.projectId),definitionId:number(t.definitionId,0,1,2147483647),tokenEnv}};
  }else throw Error('Unknown company signal kind');
  const specDigest=createHash('sha256').update(JSON.stringify([resourceId,details,details.transport.type==='runtime'||details.transport.type==='config-map'?cluster:null,intervalMs,staleAfterMs])).digest('hex');
  return {sourceId,resourceId,name,floorIds,intervalMs,staleAfterMs,specDigest,...details};
 });
 if(new Set(sources.map(s=>s.sourceId)).size!==sources.length)throw Error('Duplicate company signal source');
 if(new Set(sources.map(s=>s.resourceId+'|'+s.kind)).size!==sources.length)throw Error('A resource/kind requires one explicit current source');
 if(sources.some(s=>s.transport.type==='runtime'||s.transport.type==='config-map')&&!cluster)throw Error('Selected Kubernetes sources require explicit cluster and credentials');
 return {enabled:root.enabled,sources,...(cluster?{cluster}:{})};
}
export function companySignalDefinition(s:CompanySignalConfig):CompanySignalDefinition {
 const {sourceId,resourceId,kind,name,specDigest,intervalMs,staleAfterMs}=s;return {sourceId,resourceId,kind,name,specDigest,intervalMs,staleAfterMs,...(s.kind==='provider-usage'?{owner:s.owner}:{})};
}
