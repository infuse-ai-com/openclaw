import { missionIdentifier, parseNativeCommand, parseNativeDecisionRequest,
  type NativeMission, type NativeMissionView, type NativeReceipt, type NativeDecision, type NativePaper, type RuntimeTarget } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
import type { NativeLifecycleScope } from '../../persistence/missions/native-provisioning.js';
import { MissionError, requireMission } from './domain.js';
import type { StudioHumanActor, StudioAccessGuard } from './authority.js';

export interface NativeAuthorityOptions {
  store: MissionStore; projectId: string; targets(): RuntimeTarget[]; executionEnabled(): boolean;
  validatePaper?(paper: NativePaper): void;
  lifecycleScope?(): NativeLifecycleScope | undefined;
}
function parsed<T>(parse: (v: unknown) => T, input: unknown): T {
  try { return parse(input); } catch (error) { throw new MissionError('INVALID_INPUT', (error as Error).message); }
}
export class NativeAuthority {
  constructor(private options: NativeAuthorityOptions) {}
  private guard(actor: StudioHumanActor, current: StudioAccessGuard, approver = false) {
    return () => {
      const live = current(); requireMission(live.kind === 'human' && live.profileId === actor.profileId && (!approver || live.approver),
        'FORBIDDEN', 'Current project membership and role are required');
    };
  }
  async list(actor: StudioHumanActor, current: StudioAccessGuard): Promise<NativeMission[]> {
    const guard = this.guard(actor, current); const result = await this.options.store.native<NativeMission[]>({ kind: 'list', projectId: this.options.projectId }, guard); guard(); return result;
  }
  async read(id: unknown, actor: StudioHumanActor, current: StudioAccessGuard): Promise<NativeMissionView> {
    const guard = this.guard(actor, current); const result = await this.options.store.native<NativeMissionView>({ kind: 'read', missionId: parsed(missionIdentifier, id) }, guard);
    requireMission(result.mission.projectId === this.options.projectId, 'FORBIDDEN', 'Mission belongs to another project'); guard(); return result;
  }
  async command(input: unknown, actor: StudioHumanActor, current: StudioAccessGuard): Promise<NativeReceipt> {
    const command = parsed(parseNativeCommand, input); const membership = this.guard(actor, current);
    requireMission(command.type === 'create' || command.type === 'shape', 'FORBIDDEN', 'Task execution and review belong to their admitted agent');
    const guard = () => { membership(); this.options.validatePaper?.(command.paper); };
    guard();
    if (command.type === 'create') requireMission(command.projectId === this.options.projectId, 'FORBIDDEN', 'Mission belongs to another project');
    else await this.read(command.missionId, actor, current);
    return this.options.store.native({ kind: 'command', command, actor, targets: this.options.targets(), executionEnabled: this.options.executionEnabled() }, guard);
  }
  async prepare(input: unknown, actor: StudioHumanActor, current: StudioAccessGuard): Promise<NativeDecision> {
    const request = parsed(parseNativeDecisionRequest, input); await this.read(request.missionId, actor, current);
    return this.options.store.native({ kind: 'prepare', ...request, actor }, this.guard(actor, current, true));
  }
  async decide(input: unknown, actor: StudioHumanActor, current: StudioAccessGuard): Promise<NativeMissionView> {
    requireMission(!!input && typeof input === 'object' && !Array.isArray(input) && Object.keys(input).length === 1 && 'decisionId' in input, 'INVALID_INPUT', 'Submit an exact prepared decision reference');
    const decisionId = parsed(missionIdentifier, (input as { decisionId: unknown }).decisionId);
    const guard = this.guard(actor, current, true);
    const decision = await this.options.store.native<NativeDecision>({ kind: 'decision', decisionId }, guard);
    await this.read(decision.missionId, actor, current);
    return this.options.store.native({ kind: 'decide', decisionId, actor, executionEnabled: this.options.executionEnabled(), lifecycleScope: this.options.lifecycleScope?.() }, () => {
      guard(); // Execution revocation remains live at commit, not only at request parsing.
      if (['approve', 'resume'].includes(decision.action)) requireMission(this.options.executionEnabled(), 'EXECUTION_DISABLED', 'Managed execution is disabled');
    });
  }
}
