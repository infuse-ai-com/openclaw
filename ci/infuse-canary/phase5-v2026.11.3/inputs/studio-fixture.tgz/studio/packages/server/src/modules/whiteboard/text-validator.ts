import { Worker } from 'node:worker_threads';
import type { WhiteboardTextPatch, WhiteboardCommentThread } from '@studio/contracts';
import { MissionError } from '../missions/domain.js';
import type { Candidate } from './text-candidate.mjs';

type Input = { checkpoint: Uint8Array; update?: Uint8Array; patch?: WhiteboardTextPatch['edits']; clientId?: number };
export type AnchorInput = { checkpoint:Uint8Array; anchors: { create?:{ from:number;to:number;quote:string }; resolve?:WhiteboardCommentThread['anchor'][] } };
export type AnchorResult = { anchor?:WhiteboardCommentThread['anchor']; ranges:({ from:number;to:number }|null)[] };
export type TextCandidate = Candidate & { update: Uint8Array };
type Task = { id: number; input: Input|AnchorInput; resolve(value: unknown): void; reject(error: Error): void };
const failure = (code: string) => new MissionError(code, 'Text was not accepted. Check its saved version before trying again.');

/** One replaceable CPU worker per authority, 16 candidates including active work. */
export class TextValidator {
  private queue: Task[] = [];
  private active?: Task;
  private worker?: Worker;
  private ready = false;
  private sequence = 0;
  private closed = false;
  private replacing?: Promise<unknown>;
  private timer?: ReturnType<typeof setTimeout>;
  prepare(input: Input): Promise<TextCandidate> {
    return this.enqueue(input) as Promise<TextCandidate>;
  }
  anchors(input:AnchorInput):Promise<AnchorResult> {
    if ((input.anchors.resolve?.length ?? 0)>100) return Promise.reject(failure('HISTORY_LIMIT'));
    return this.enqueue(input) as Promise<AnchorResult>;
  }
  private enqueue(input:Input|AnchorInput):Promise<unknown> {
    if (this.closed) return Promise.reject(failure('UNAVAILABLE'));
    if (input.checkpoint.length > 262144 || ('update' in input && (input.update?.length ?? 0) > 32768)) return Promise.reject(failure('HISTORY_LIMIT'));
    if (this.queue.length + Number(!!this.active) >= 16) return Promise.reject(failure('BUSY'));
    return new Promise((resolve,reject) => {
      this.queue.push({ id: ++this.sequence, input: structuredClone(input), resolve, reject }); this.pump();
    });
  }
  private pump(): void {
    if (this.closed || this.replacing || this.active || !this.queue.length) return;
    if (!this.worker) {
      const worker = this.worker = new Worker(new URL('./text-worker.mjs', import.meta.url), {
        env: {}, execArgv: [], resourceLimits: { maxOldGenerationSizeMb: 64, maxYoungGenerationSizeMb: 8, stackSizeMb: 4 },
      });
      this.timer = setTimeout(() => this.fail(worker, 'WORKER_START_TIMEOUT'), 5000);
      worker.on('error', () => this.fail(worker, 'WORKER_FAILED'));
      worker.on('exit', () => this.fail(worker, 'WORKER_FAILED'));
      worker.on('message', message => {
        if (this.worker !== worker) return;
        if (message.ready) { clearTimeout(this.timer); this.ready = true; this.pump(); return; }
        if (!this.active || message.id !== this.active.id) { this.fail(worker, 'WORKER_PROTOCOL'); return; }
        const task = this.active; this.active = undefined; clearTimeout(this.timer);
        if (message.error) task.reject(failure(message.error)); else task.resolve(message.result);
        this.pump();
      });
    }
    if (!this.ready) return;
    this.active = this.queue.shift()!;
    const worker = this.worker;
    this.timer = setTimeout(() => this.fail(worker, 'PREPARE_TIMEOUT'), 500);
    worker.postMessage({ id: this.active.id, ...this.active.input });
  }
  private fail(worker: Worker, code: string): void {
    if (worker !== this.worker) return;
    clearTimeout(this.timer); this.worker = undefined; this.ready = false;
    const task = this.active; this.active = undefined;
    if (task) task.reject(failure(code)); else for (const queued of this.queue.splice(0)) queued.reject(failure(code));
    this.replacing = worker.terminate().finally(() => { this.replacing = undefined; this.pump(); });
  }
  async close(): Promise<void> {
    this.closed = true; clearTimeout(this.timer); this.active?.reject(failure('UNAVAILABLE')); this.active = undefined;
    for (const task of this.queue.splice(0)) task.reject(failure('UNAVAILABLE'));
    const worker = this.worker; this.worker = undefined;
    if (worker) await worker.terminate(); await this.replacing;
  }
}
