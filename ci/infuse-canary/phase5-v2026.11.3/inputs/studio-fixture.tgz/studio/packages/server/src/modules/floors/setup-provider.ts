import type { FloorSetupCheck } from '@studio/contracts';
import { readOperationsKubernetes } from '../operations/source-io.js';
import type { FloorSetupConfig, FloorSetupTarget } from './setup-config.js';
type Value = Record<string, unknown>;
const object = (value: unknown): Value => value && typeof value === 'object' && !Array.isArray(value) ? value as Value : {};
class SourceError extends Error { constructor(readonly status?: number, readonly noData = false) { super('Setup source unavailable'); } }
export interface SetupIO {
  json(url: string, authorization: string, signal: AbortSignal): Promise<unknown>;
  kubernetes: typeof readOperationsKubernetes;
  credential(name: string): string | undefined;
}
export const setupIO: SetupIO = {
  credential: name => process.env[name], kubernetes: readOperationsKubernetes,
  async json(url, authorization, signal) {
    const response = await fetch(url, { headers: { Authorization: authorization, Accept: 'application/json' }, redirect: 'error', signal });
    if (!response.ok) { await response.body?.cancel(); throw new SourceError(response.status); }
    const reader = response.body?.getReader(); if (!reader) throw new SourceError();
    const chunks: Uint8Array[] = []; let bytes = 0;
    try { for (;;) { const part = await reader.read(); if (part.done) break; bytes += part.value.length;
      if (bytes > 1024 * 1024) { await reader.cancel(); throw new SourceError(); } chunks.push(part.value); }
    } finally { reader.releaseLock(); }
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  },
};
export async function collectFloorSetup(config: FloorSetupConfig | undefined, floor: FloorSetupTarget | undefined,
  io: SetupIO = setupIO, now = Date.now()): Promise<FloorSetupCheck[]> {
  const at = new Date(now).toISOString();
  const checks: Array<() => Promise<FloorSetupCheck>> = [];
  const deadline = AbortSignal.timeout(12000);
  const add = (id: string, label: string, target: string | undefined, configured: boolean, check: (signal: AbortSignal) => Promise<string>, href?: string) => {
    checks.push(async (): Promise<FloorSetupCheck> => {
      const base = { id, label, target: target ?? 'No target selected', ...(href ? { href } : {}) };
      if (!target || !configured) return { ...base, state: 'unconfigured', detail: target ? 'An operator needs to connect the read-only check.' : 'An operator needs to link this floor to its setup target.', checkedAt: null };
      try { return { ...base, state: 'verified', detail: await check(AbortSignal.any([deadline, AbortSignal.timeout(8000)])), checkedAt: at }; }
      catch (error) { return { ...base, state: error instanceof SourceError && (error.status === 404 || error.noData) ? 'blocked' : 'unverified', checkedAt: at,
        detail: error instanceof SourceError && error.noData ? 'The dashboard is available, but recent metrics for this deployment are missing.' : error instanceof SourceError && error.status === 404 ? 'The configured resource was not found.' : error instanceof SourceError && [401,403].includes(error.status ?? 0) ? 'Studio does not have access to verify this resource.' : 'This check could not confirm readiness. Check the service connection and try again.' }; }
    });
  };
  const auth = (env: string, kind: 'bearer' | 'basic') => {
    const token = io.credential(env); if (!token || /[\r\n]/.test(token)) throw new SourceError(401);
    return kind === 'basic' ? `Basic ${Buffer.from(token).toString('base64')}` : `Bearer ${token}`;
  };
  add('namespace', 'Kubernetes namespace', floor?.namespace, !!config?.cluster || !!(config?.grafana && floor?.grafana), async signal => {
    if (!config?.cluster) {
      const query = `timestamp(kube_namespace_status_phase{namespace="${floor!.namespace}",phase="Active"} == 1)`;
      const result = object(await io.json(`${config!.grafana!.origin}/api/datasources/proxy/uid/${floor!.grafana!.datasourceUid}/api/v1/query?${new URLSearchParams({query})}`, auth(config!.grafana!.tokenEnv,'bearer'), signal));
      const values = object(result.data).result;
      if (result.status !== 'success' || !Array.isArray(values) || !values.some(raw => {
        const row = object(raw), metric = object(row.metric), value = row.value;
        return metric.namespace === floor!.namespace && metric.phase === 'Active' && Array.isArray(value) && Number(value[1]) >= now/1000-120 && Number(value[1]) <= now/1000+30;
      })) throw new SourceError();
      return 'Recent Kubernetes metrics confirm the namespace is active. Workload health is separate.';
    }
    const value = object(await io.kubernetes(config!.cluster!, `/api/v1/namespaces/${floor!.namespace}`, signal));
    if (object(value.metadata).name !== floor!.namespace || object(value.status).phase !== 'Active') throw new SourceError();
    return 'Namespace is active. Workload health is a separate check.';
  });
  add('harbor', 'Harbor project', floor?.harbor?.name, !!config?.harbor, async signal => {
    const value = object(await io.json(`${config!.harbor!.origin}/api/v2.0/projects/${floor!.harbor!.id}`, auth(config!.harbor!.tokenEnv,'basic'), signal));
    if (value.project_id !== floor!.harbor!.id || value.name !== floor!.harbor!.name || object(value.metadata).public !== 'false') throw new SourceError();
    return 'Private image project exists.';
  });
  const grafana = floor?.grafana;
  add('grafana', 'Grafana monitoring', grafana ? `${grafana.namespace} / ${grafana.deployment}` : undefined, !!config?.grafana, async signal => {
    const provider = config!.grafana!, credential = auth(provider.tokenEnv,'bearer');
    const dashboard = object(await io.json(`${provider.origin}/api/dashboards/uid/${grafana!.dashboardUid}`, credential, signal));
    if (object(dashboard.dashboard).uid !== grafana!.dashboardUid) throw new SourceError();
    const datasource = object(await io.json(`${provider.origin}/api/datasources/uid/${grafana!.datasourceUid}`, credential, signal));
    if (datasource.type !== 'prometheus' || datasource.uid !== grafana!.datasourceUid) throw new SourceError();
    const query = `timestamp(kube_deployment_status_replicas_available{namespace="${grafana!.namespace}",deployment="${grafana!.deployment}"})`;
    const result = object(await io.json(`${provider.origin}/api/datasources/proxy/uid/${grafana!.datasourceUid}/api/v1/query?${new URLSearchParams({ query })}`, credential, signal));
    const data = object(result.data), values = Array.isArray(data.result) ? data.result : [];
    if (result.status !== 'success' || data.resultType !== 'vector' || !values.some(raw => {
      const row = object(raw), metric = object(row.metric), value = row.value;
      return metric.namespace === grafana!.namespace && metric.deployment === grafana!.deployment && Array.isArray(value) &&
        typeof value[0] === 'number' && value[0] >= now / 1000 - 120 && value[0] <= now / 1000 + 30 && Number(value[1]) >= now / 1000 - 120 && Number(value[1]) <= now / 1000 + 30;
    })) throw new SourceError(undefined, true);
    return 'Dashboard and data source are available, with recent deployment metrics.';
  }, grafana ? `${grafana.publicOrigin}/d/${grafana.dashboardUid}?${new URLSearchParams({ 'var-namespace': grafana.namespace, 'var-deployment': grafana.deployment })}` : undefined);
  const results: FloorSetupCheck[] = new Array(checks.length); let cursor = 0;
  await Promise.all(Array.from({length: Math.min(4, checks.length)}, async () => {
    while (cursor < checks.length) { const index = cursor++; results[index] = await checks[index]!(); }
  }));
  return results;
}
