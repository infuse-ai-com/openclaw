// Registry v1 canonical hash. Preserve wire compatibility with Backoffice.
import { createHash } from 'node:crypto';
import type { ArtifactManifest } from '@studio/contracts';

export function computeArtifactRevision(
  publication: ArtifactManifest,
  files: Array<{ path: string; mediaType: string; bytes: number; sha256: string }>,
): string {
  const canonical = JSON.stringify({
    producer: publication.producer,
    artifactId: publication.artifactId,
    title: publication.title,
    kind: publication.kind,
    summary: publication.summary ?? "",
    project: publication.project ?? null,
    tags: [...(publication.tags ?? [])].sort(),
    intendedConsumer: publication.intendedConsumer ?? null,
    missionId: publication.missionId ?? null,
    taskId: publication.taskId ?? null,
    sourceRef: publication.sourceRef ?? null,
    files: [...files].sort((a, b) => a.path.localeCompare(b.path)),
  });
  return createHash("sha256").update(canonical).digest("hex");
}
