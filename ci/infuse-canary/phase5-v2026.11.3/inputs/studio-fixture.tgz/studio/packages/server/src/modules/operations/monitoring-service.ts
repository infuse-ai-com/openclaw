import type {MissionStore} from '../../persistence/missions/store.js';
import type {MonitoringStoreCommand} from '../../persistence/missions/monitoring.js';
export class MonitoringService {
 constructor(private store:MissionStore){}
 ready(guard:()=>void):Promise<{ready:true}>{return this.store.monitoring({kind:'ready'},guard);}
 read<T>(op:Extract<MonitoringStoreCommand,{kind:'read'|'detail'|'audit'}>,guard:()=>void):Promise<T>{return this.store.monitoring(op,guard);}
 control<T>(op:Extract<MonitoringStoreCommand,{kind:'control'}>,guard:()=>void):Promise<T>{return this.store.monitoring(op,guard);}
}
