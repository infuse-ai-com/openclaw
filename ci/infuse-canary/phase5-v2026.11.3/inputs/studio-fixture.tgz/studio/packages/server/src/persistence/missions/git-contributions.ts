import { mapRows } from './sql.js';
import {createHash} from 'node:crypto';
import type { SqlInput } from './sql.js';
import type { StorageDatabase } from './sql.js';
import { missionIdentifier,parseGitRepositoryIdentity,gitRepositoryUrl,gitText,gitSha,gitTime,gitGuid,parseGitCommit,gitAuthorKey,contributionDate,
  type GitScanRecovery,type GitRepositoryIdentity,type GitRepositoryMetadata,type GitBranch,type GitCommitMetadata } from '@studio/contracts';
import { requireMission } from '../../modules/missions/domain.js';
import { OperationsPersistence,type OperationJob } from './operations.js';

export interface GitRepositoryState extends GitRepositoryMetadata {
 scanProvider?:'gitlab';
 stage:'idle'|'refs'|'commits'|'complete'; cycleId?:string; refsCursor?:string; lastAttemptAt:string; lastSuccessAt?:string; lastCompleteAt?:string; lastError?:string;historyGap?:boolean;recoveries?:GitScanRecovery[];
}
interface Progress {expectedRevision:number;job:OperationJob;intervalMs:number}
export type GitStoreCommand=
 | {kind:'inventory';after?:string}
 | {kind:'retire-azure-history';gitLabSourceIds:string[]}
 | {kind:'inspect';sourceId:string}
 | {kind:'begin';repository:GitRepositoryMetadata;cycleId:string;scanProvider?:'gitlab';progress?:Progress}
 | {kind:'restart';repository:GitRepositoryMetadata;cycleId:string;reason:GitScanRecovery['reason'];scanProvider?:'gitlab';progress?:Progress}
 | {kind:'refs';sourceId:string;cycleId:string;cursor?:string;branches:GitBranch[];nextCursor?:string;progress?:Progress}
 | {kind:'page';sourceId:string;cycleId:string;branch:string;head:string;offset:number;commits:GitCommitMetadata[];nextOffset?:number;progress?:Progress}
 | {kind:'import';repository:GitRepositoryMetadata;commits:GitCommitMetadata[]}
 | {kind:'failure';repository:GitRepositoryMetadata;code:string;retryAfterMs:number;progress?:Progress}
 | {kind:'read';sourceIds:string[];expectedRepositories?:GitRepositoryIdentity[];year:number;selectedSourceId?:string;projectId?:string;authorKey?:string}
 | {kind:'day';sourceIds:string[];expectedRepositories?:GitRepositoryIdentity[];date:string;authorKey?:string;after?:{at:string;sourceId:string;sha:string};limit?:number};
const placeholders=(count:number)=>Array(count).fill('?').join(',');
const azureRetirementMarker='git-azure-history-retired-v1';
function sourceIds(ids:string[]):void {requireMission(Array.isArray(ids)&&ids.length<=100&&new Set(ids).size===ids.length,'INVALID_INPUT','Invalid Git source scope');ids.forEach(missionIdentifier);}
function repository(value:GitRepositoryMetadata):GitRepositoryMetadata {const id=parseGitRepositoryIdentity(value);return {...id,name:gitText(value.name),projectName:gitText(value.projectName),url:gitRepositoryUrl(id)};}
function batch(rows:GitCommitMetadata[],provenance:GitCommitMetadata['provenance']):GitCommitMetadata[]{
 requireMission(Array.isArray(rows)&&rows.length<=100,'INVALID_INPUT','Git batches are limited to 100 records');
 const result=rows.map(parseGitCommit);requireMission(new Set(result.map(c=>c.sha)).size===result.length,'INVALID_INPUT','Duplicate SHA in one Git page');requireMission(result.every(c=>c.provenance===provenance&&(provenance!=='backoffice'||c.authorDate===null&&c.committerDate===null))&&new TextEncoder().encode(JSON.stringify(result)).length<=262144,'INVALID_INPUT','Invalid Git batch provenance or byte limit');return result;
}
/** Bounded Git metadata/progress transactions in the existing mission worker only. */
export class GitContributionsPersistence {
 constructor(private db:StorageDatabase,private now:()=>number=Date.now){}
 private async current(id:string):Promise<GitRepositoryState|undefined> {missionIdentifier(id);const row=(await this.db.prepare('SELECT body FROM studio_git_repositories WHERE source_id=?').get(id));return row?JSON.parse(String(row.body)):undefined;}
 private async save(value:GitRepositoryState):Promise<void> {
  const old=(await this.current(value.sourceId));requireMission(!old||old.organization===value.organization&&old.repositoryId===value.repositoryId,'INVALID_INPUT','Git source identity cannot change');
  const duplicate=(await this.db.prepare('SELECT source_id FROM studio_git_repositories WHERE organization=? AND repository_id=?').get(value.organization,value.repositoryId));
  requireMission(!duplicate||duplicate.source_id===value.sourceId,'ALREADY_EXISTS','Repository already belongs to another source');
  requireMission(old!==undefined||Number((await this.db.prepare('SELECT COUNT(*) n FROM studio_git_repositories').get())!.n)<1000,'INVALID_INPUT','Git repository quota reached');
  requireMission(Buffer.byteLength(JSON.stringify(value))<=32768,'INVALID_INPUT','Git source state exceeds 32 KiB');
  (await this.db.prepare("INSERT INTO studio_git_repositories (source_id,organization,repository_id,body) VALUES(?,?,?,?) ON CONFLICT(source_id) DO UPDATE SET body=excluded.body").run(value.sourceId,value.organization,value.repositoryId,JSON.stringify(value)));
 }
 private async finish(source:GitRepositoryState,progress?:Progress,retryAfterMs?:number):Promise<GitRepositoryState> {
  if(!source.lastError&&source.stage==='commits'&&!(await this.db.prepare('SELECT 1 FROM studio_git_heads WHERE source_id=? AND cycle_id=? AND complete=0 LIMIT 1').get(source.sourceId,source.cycleId!))){
   source={...source,stage:'complete',lastCompleteAt:new Date(this.now()).toISOString()};
   (await this.db.prepare('DELETE FROM studio_git_heads WHERE source_id=? AND cycle_id<>?').run(source.sourceId,source.cycleId!));
  }
  (await this.save(source));
  if(progress){
   requireMission(progress.job.kind==='git-contributions'&&progress.job.source===source.sourceId&&Number.isSafeInteger(progress.intervalMs)&&progress.intervalMs>=30000&&progress.intervalMs<=86400000,'INVALID_INPUT','Git progress requires its exact source and interval');
   (await new OperationsPersistence(this.db,this.now).execute({kind:'save',expectedRevision:progress.expectedRevision,job:{...progress.job,checkpoint:{stage:source.stage,cycleId:source.cycleId??null,refsCursor:source.refsCursor??null},state:source.lastError?'failed':source.stage==='complete'?'succeeded':'pending',nextRunAt:this.now()+(retryAfterMs??(source.stage==='complete'?progress.intervalMs:1000)),leaseUntil:undefined}}));
  }
  return source;
 }
 private async writeCommits(id:string,rows:GitCommitMetadata[]):Promise<void> {
  const insert=this.db.prepare("INSERT INTO studio_git_commits (source_id,sha,author_key,graph_date,date_basis,imported_at,body) VALUES(?,?,?,?,?,?,?) ON CONFLICT(source_id,sha) DO UPDATE SET author_key=excluded.author_key,graph_date=excluded.graph_date,date_basis=excluded.date_basis,body=excluded.body");
  for(const next of rows){
   const raw=(await this.db.prepare('SELECT body FROM studio_git_commits WHERE source_id=? AND sha=?').get(id,next.sha)),old=raw?JSON.parse(String(raw.body)) as GitCommitMetadata:undefined;
   // A mirrored SHA already has a retained record, including its original date and provenance.
   if(old&&(next.provenance==='gitlab'||old.provenance==='gitlab'))continue;
   if(old?.provenance==='azure'&&next.provenance==='azure')for(const key of ['authorDate','committerDate'] as const)requireMission(!old[key]||!next[key]||old[key]===next[key],'STATE_CONFLICT','Immutable Git timestamps changed');
   if(old?.legacyGraphDate&&next.legacyGraphDate)requireMission(old.legacyGraphDate===next.legacyGraphDate,'IDEMPOTENCY_CONFLICT','Retained Git timestamp provenance changed');
   const primary=old?.provenance==='azure'&&next.provenance==='backoffice'?old:next,secondary=primary===old?next:old;
   const merged=parseGitCommit({...primary,authorName:primary.authorName==='Unknown'?secondary?.authorName??primary.authorName:primary.authorName,authorEmail:primary.authorEmail??secondary?.authorEmail??null,committerName:primary.committerName??secondary?.committerName??null,committerEmail:primary.committerEmail??secondary?.committerEmail??null,authorDate:primary.authorDate??secondary?.authorDate??null,committerDate:primary.committerDate??secondary?.committerDate??null,
    ...(primary.messageTruncated&&secondary&&!secondary.messageTruncated?{message:secondary.message,messageTruncated:false}:{}),
    ...(old?.legacyGraphDate||next.legacyGraphDate?{legacyGraphDate:old?.legacyGraphDate??next.legacyGraphDate,legacyDateBasis:'author-or-committer-fallback'}:{})});
   const date=contributionDate(merged);(await insert.run(id,merged.sha,gitAuthorKey(merged),date.date,date.basis,new Date(this.now()).toISOString(),JSON.stringify(merged)));
  }
  requireMission(Number((await this.db.prepare('SELECT COUNT(*) n FROM studio_git_commits WHERE source_id=?').get(id))!.n)<=1000000,'INVALID_INPUT','Git repository exceeds retained metadata quota; coverage remains incomplete');
 }
 async execute(op:GitStoreCommand):Promise<unknown> {
  if(op.kind==='inventory')return (await this.inventory(op.after));
  if(op.kind==='retire-azure-history')return this.retireAzureHistory(op.gitLabSourceIds);
  if(op.kind==='read')return (await this.read(op));
  if(op.kind==='day')return (await this.day(op));
  if(op.kind==='inspect'){
   const source=(await this.current(op.sourceId));if(!source)return null;
   const row=source.cycleId?(await this.db.prepare('SELECT * FROM studio_git_heads WHERE source_id=? AND cycle_id=? AND complete=0 ORDER BY name LIMIT 1').get(source.sourceId,source.cycleId)):undefined;
   return {source,branch:row?{name:String(row.name),head:String(row.head),offset:Number(row.offset)}:null};
  }
  const at=new Date(this.now()).toISOString();
  if(op.kind==='begin'||op.kind==='restart'||op.kind==='import'||op.kind==='failure'){
   const meta=repository(op.repository),current=(await this.current(meta.sourceId));
   requireMission(!current||current.organization===meta.organization&&current.repositoryId===meta.repositoryId,'INVALID_INPUT','Git source identity cannot change');
   let source:GitRepositoryState=op.kind==='begin'||op.kind==='restart'?{stage:'idle',...current,...meta,lastAttemptAt:at}:{...meta,stage:'idle',...current,lastAttemptAt:at};
   if(op.kind==='begin'||op.kind==='restart'){
    const cycle=gitTime(op.cycleId);requireMission(!!cycle&&Date.parse(cycle)<=this.now()+300000&&(!current?.cycleId||Date.parse(cycle)>Date.parse(current.cycleId)),'VERSION_CONFLICT','Git cycle must advance');
    requireMission(op.kind==='restart'?!!current&&['refs','commits'].includes(current.stage):!current||['idle','complete'].includes(current.stage),'BUSY','Resume the current Git scan before starting another');
    if(op.kind==='restart'){
     const cutover=op.reason==='provider-cutover'&&op.scanProvider==='gitlab'&&!current!.scanProvider;
     requireMission((cutover||['cursor-expired','head-unavailable'].includes(op.reason)&&op.scanProvider===current!.scanProvider)&&(current!.recoveries?.length??0)<20,'STATE_CONFLICT','Review historical scan gaps before restarting again');
     const oldHead=current!.stage==='commits'?(await this.db.prepare("SELECT name,head,\"offset\" FROM studio_git_heads WHERE source_id=? AND cycle_id=? AND complete=0 ORDER BY name LIMIT 1").get(source.sourceId,current!.cycleId!)):undefined;
     const recovery:GitScanRecovery={at,reason:op.reason,previousCycleId:current!.cycleId!,...(oldHead?{branch:String(oldHead.name),head:String(oldHead.head),offset:Number(oldHead.offset)}:{})};
     source={...source,historyGap:true,recoveries:[...(current!.recoveries??[]),recovery]};
    }
    source={...source,stage:'refs',cycleId:cycle,scanProvider:op.scanProvider,refsCursor:undefined,lastError:undefined,lastSuccessAt:at};return (await this.finish(source,op.progress));
   }
   if(op.kind==='import'){
    const commits=batch(op.commits,'backoffice');(await this.save(source));(await this.writeCommits(source.sourceId,commits));return (await this.finish(source));
   }
   requireMission(/^[A-Z][A-Z0-9_]{0,79}$/.test(op.code)&&Number.isSafeInteger(op.retryAfterMs)&&op.retryAfterMs>=1000&&op.retryAfterMs<=900000,'INVALID_INPUT','Invalid bounded Git source failure');
   source={...source,lastError:op.code};return (await this.finish(source,op.progress,op.retryAfterMs));
  }
  const current=(await this.current(op.sourceId));requireMission(!!current&&current.cycleId===gitTime(op.cycleId),'VERSION_CONFLICT','Git scan generation changed');
  let source:GitRepositoryState={...current,lastAttemptAt:at,lastSuccessAt:at,lastError:undefined};
  if(op.kind==='refs'){
   requireMission(current.stage==='refs'&&current.refsCursor===op.cursor&&(op.nextCursor===undefined||typeof op.nextCursor==='string'&&op.nextCursor.length>0&&op.nextCursor!==op.cursor&&op.nextCursor.length<=2048),'VERSION_CONFLICT','Git refs cursor changed');
   requireMission(Array.isArray(op.branches)&&op.branches.length<=100&&new TextEncoder().encode(JSON.stringify(op.branches)).length<=131072,'INVALID_INPUT','Git ref page exceeds limits');
   const branches=op.branches.map(b=>({name:gitText(b.name,512),head:gitSha(b.head)}));requireMission(new Set(branches.map(b=>b.name)).size===branches.length&&branches.every(b=>b.name.startsWith('refs/heads/')),'INVALID_INPUT','Invalid frozen Git branch page');
   for(const b of branches){
    const old=(await this.db.prepare('SELECT * FROM studio_git_heads WHERE source_id=? AND name=?').get(source.sourceId,b.name));
    requireMission(!old||old.cycle_id!==source.cycleId||old.head===b.head,'VERSION_CONFLICT','Branch head changed within a frozen refs cycle');
    if(old?.cycle_id===source.cycleId)continue;
    (await this.db.prepare("INSERT INTO studio_git_heads (source_id,name,head,completed_head,cycle_id,\"offset\",complete,page_digest) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source_id,name) DO UPDATE SET head=excluded.head,cycle_id=excluded.cycle_id,\"offset\"=excluded.\"offset\",complete=excluded.complete,page_digest=excluded.page_digest").run(source.sourceId,b.name,b.head,old?.completed_head??null,source.cycleId!,0,old?.completed_head===b.head?1:0,null));
   }
   requireMission(Number((await this.db.prepare('SELECT COUNT(*) n FROM studio_git_heads WHERE source_id=? AND cycle_id=?').get(source.sourceId,source.cycleId!))!.n)<=1000,'INVALID_INPUT','Branch inventory exceeds 1000; coverage remains incomplete');
   source={...source,refsCursor:op.nextCursor,stage:op.nextCursor?'refs':'commits'};
  }else {
   requireMission(op.kind==='page'&&current.stage==='commits','STATE_CONFLICT','Git source is not scanning commits');
   const branch=(await this.db.prepare('SELECT * FROM studio_git_heads WHERE source_id=? AND name=? AND cycle_id=?').get(source.sourceId,op.branch,source.cycleId!));
   requireMission(!!branch&&branch.head===gitSha(op.head)&&Number(branch.offset)===op.offset&&branch.complete===0,'VERSION_CONFLICT','Frozen branch progress changed');
   if(!current.scanProvider)requireMission(!await this.db.prepare('SELECT value FROM metadata WHERE key=?').get(azureRetirementMarker),
    'STATE_CONFLICT','Azure Contributions history has been retired');
   const commits=batch(op.commits,current.scanProvider??'azure');requireMission(Number.isSafeInteger(op.offset)&&op.offset>=0&&(commits.length===100?op.nextOffset===op.offset+100:op.nextOffset===undefined),'INVALID_INPUT','Commit page progress must follow its raw records');
   const digest=createHash('sha256').update(JSON.stringify(commits.map(c=>c.sha))).digest('hex');
   requireMission(!commits.length||op.offset===0||branch.page_digest!==digest,'STATE_CONFLICT','Git provider repeated a page without advancing');
   (await this.writeCommits(source.sourceId,commits));
   (await this.db.prepare("UPDATE studio_git_heads SET page_digest=?,\"offset\"=?,complete=?,completed_head=CASE WHEN ?=1 THEN head ELSE completed_head END WHERE source_id=? AND name=?").run(digest,op.offset+commits.length,op.nextOffset===undefined?1:0,op.nextOffset===undefined?1:0,source.sourceId,op.branch));
  }
  return (await this.finish(source,op.progress));
 }
 private async retireAzureHistory(gitLabSourceIds:string[]):Promise<unknown> {
  sourceIds(gitLabSourceIds);
  requireMission(gitLabSourceIds.length>0,'INVALID_INPUT','GitLab collection must be configured before retiring Azure history');
  const prior=await this.db.prepare('SELECT value FROM metadata WHERE key=?').get(azureRetirementMarker);
  if(prior)return JSON.parse(String(prior.value));
  const azureRows="body::jsonb->>'provenance'='azure'";
  const rows=await this.db.prepare(`SELECT DISTINCT source_id FROM studio_git_commits WHERE ${azureRows}`).all();
  const mapped=rows.map(row=>String(row.source_id)).filter(id=>gitLabSourceIds.includes(id));
  for(const id of mapped){
   const current=await this.current(id);
   requireMission(current?.scanProvider==='gitlab'&&!!current.lastCompleteAt&&!current.lastError,'STATE_CONFLICT','Complete a GitLab scan before retiring Azure history');
  }
  const deleted=Number((await this.db.prepare(`WITH removed AS (DELETE FROM studio_git_commits WHERE ${azureRows} RETURNING 1) SELECT count(*) AS total FROM removed`).get())!.total);
  for(const id of mapped){
   const current=(await this.current(id))!;
   await this.db.prepare('DELETE FROM studio_git_heads WHERE source_id=?').run(id);
   await this.db.prepare("DELETE FROM studio_operation_jobs WHERE kind='git-contributions' AND source=?").run(id);
   await this.save({...current,stage:'idle',cycleId:undefined,refsCursor:undefined,lastCompleteAt:undefined});
  }
  const result={deletedAzureCommits:deleted,affectedSources:rows.length,rescanSources:mapped.length};
  await this.db.prepare('INSERT INTO metadata(key,value) VALUES(?,?)').run(azureRetirementMarker,JSON.stringify(result));
  return result;
 }
 private async inventory(after?:string):Promise<unknown> {
  if(after!==undefined)try{missionIdentifier(after);}catch{requireMission(false,'INVALID_INPUT','Invalid inventory cursor');}
  // Use the sole writer's existing read transaction. Never create a competing database connection.
  // Only 25 source summaries and at most 1000 checkpoints per source are read.
  const rows=(await this.db.prepare('SELECT source_id,body FROM studio_git_repositories WHERE source_id>? ORDER BY source_id LIMIT 26').all(after??''));
  const repositories=(await mapRows(rows.slice(0,25), async row=>{
   const state=JSON.parse(String(row.body)) as GitRepositoryState;
   const heads=(await this.db.prepare("SELECT name,head,completed_head,cycle_id,\"offset\",complete,page_digest FROM studio_git_heads WHERE source_id=? ORDER BY name LIMIT 1001").all(state.sourceId));
   requireMission(heads.length<=1000,'STATE_CONFLICT','Git checkpoint inventory exceeds its qualified bound');
   const retainedCommits=Number((await this.db.prepare('SELECT COUNT(*) n FROM studio_git_commits WHERE source_id=?').get(state.sourceId))!.n);
   return {sourceId:state.sourceId,organization:state.organization,projectId:state.projectId,repositoryId:state.repositoryId,
    name:state.name,projectName:state.projectName,stage:state.stage,cycleId:state.cycleId,lastCompleteAt:state.lastCompleteAt,
    lastError:state.lastError,historyGap:state.historyGap??false,recoveryCount:state.recoveries?.length??0,retainedCommits,
    checkpoints:heads.length,completedCheckpoints:heads.filter(h=>h.complete===1).length,
    stateDigest:createHash('sha256').update(String(row.body)).digest('hex'),
    checkpointDigest:createHash('sha256').update(JSON.stringify(heads)).digest('hex')};
  }));
  return {repositories,totalSources:Number((await this.db.prepare('SELECT COUNT(*) n FROM studio_git_repositories').get())!.n),
   ...(rows.length>25?{nextCursor:String(rows[24]!.source_id)}:{}),readAt:new Date(this.now()).toISOString()};
 }
 private async bindings(ids:string[],expected?:GitRepositoryIdentity[]):Promise<void> {
  if(expected===undefined)return;
  requireMission(Array.isArray(expected)&&expected.length===ids.length&&new Set(expected.map(r=>r.sourceId)).size===expected.length,'INVALID_INPUT','Git source bindings must cover the exact admitted scope');
  for(const value of expected){const id=parseGitRepositoryIdentity(value);requireMission(ids.includes(id.sourceId),'INVALID_INPUT','Unexpected Git source binding');const stored=(await this.current(id.sourceId));
   requireMission(!stored||stored.organization===id.organization&&stored.projectId===id.projectId&&stored.repositoryId===id.repositoryId,'FORBIDDEN','Stored repository does not match current source admission');}
 }
 private filtered(ids:string[],author?:string):{sql:string;values:SqlInput[]} {
  sourceIds(ids);if(author!==undefined)gitText(author,1024);
  return {sql:ids.length?`source_id IN (${placeholders(ids.length)})${author===undefined?'':' AND author_key=?'}`:'1=0',values:ids.length?[...ids,...(author===undefined?[]:[author])]:[]};
 }
 private async read(op:Extract<GitStoreCommand,{kind:'read'}>):Promise<unknown> {
  requireMission(Number.isInteger(op.year)&&op.year>=0&&op.year<=9999,'INVALID_INPUT','Invalid contribution year');
  sourceIds(op.sourceIds);(await this.bindings(op.sourceIds,op.expectedRepositories));if(op.projectId!==undefined)gitGuid(op.projectId);if(op.selectedSourceId!==undefined)requireMission(op.sourceIds.includes(op.selectedSourceId),'FORBIDDEN','Repository is outside source admission');
  let repositories=(await mapRows(op.sourceIds, async id=>(await this.current(id)))).filter((r):r is GitRepositoryState=>!!r);
  const scoped=repositories.filter(r=>(!op.selectedSourceId||r.sourceId===op.selectedSourceId)&&(!op.projectId||r.projectId===op.projectId)).map(r=>r.sourceId),scope=this.filtered(scoped,op.authorKey);
  const year=String(op.year).padStart(4,'0'),range=`${scope.sql} AND graph_date>=? AND graph_date<=?`,values=[...scope.values,year+'-01-01T00:00:00.000Z',year+'-12-31T23:59:59.999Z'];
  const days=(await this.db.prepare(`SELECT substr(graph_date,1,10) date,COUNT(*) count FROM studio_git_commits WHERE ${range} GROUP BY date ORDER BY date`).all(...values)).map(r=>({date:String(r.date),count:Number(r.count)}));
  const total=days.reduce((n,r)=>n+Number(r.count),0),unknownDates=Number((await this.db.prepare(`SELECT COUNT(*) n FROM studio_git_commits WHERE ${scope.sql} AND graph_date IS NULL`).get(...scope.values))!.n);
  const authorsScope=this.filtered(scoped),authors=(await this.db.prepare(`SELECT author_key key,MIN(jsonb_extract_path_text(body::jsonb,'authorName')) name,MIN(jsonb_extract_path_text(body::jsonb,'authorEmail')) email,COUNT(*) count FROM studio_git_commits WHERE ${authorsScope.sql} GROUP BY author_key ORDER BY name,key LIMIT 201`).all(...authorsScope.values));
  const activity=(await this.db.prepare(`SELECT source_id "sourceId",COUNT(*) count,MAX(graph_date) latest FROM studio_git_commits WHERE ${range} GROUP BY source_id ORDER BY count DESC,source_id`).all(...values));
  const weekly=(await this.db.prepare(`SELECT source_id "sourceId",CAST(trunc(EXTRACT(EPOCH FROM (graph_date::timestamptz-?::timestamptz))/604800) AS bigint) idx,COUNT(*) count FROM studio_git_commits WHERE ${range} GROUP BY source_id,idx ORDER BY source_id,idx`).all(year+'-01-01T00:00:00.000Z',...values));
  const yearsScope=this.filtered(scoped,op.authorKey),years=(await this.db.prepare(`SELECT DISTINCT CAST(substr(graph_date,1,4) AS INTEGER) "year" FROM studio_git_commits WHERE ${yearsScope.sql} AND graph_date IS NOT NULL ORDER BY "year" DESC LIMIT 10000`).all(...yearsScope.values)).map(r=>Number(r.year));
  repositories=repositories.map(r=>({...r}));
  const coverage=(await mapRows(repositories, async r=>{const heads=r.cycleId?(await this.db.prepare('SELECT COUNT(*) branches,CAST(COALESCE(SUM(complete),0) AS BIGINT) completed FROM studio_git_heads WHERE source_id=? AND cycle_id=?').get(r.sourceId,r.cycleId)):{branches:0,completed:0};return {sourceId:r.sourceId,organization:r.organization,projectId:r.projectId,repositoryId:r.repositoryId,name:r.name,projectName:r.projectName,url:r.url,stage:r.stage,cycleId:r.cycleId,lastAttemptAt:r.lastAttemptAt,lastSuccessAt:r.lastSuccessAt,lastCompleteAt:r.lastCompleteAt,lastError:r.lastError,historyGap:r.historyGap,recoveryCount:r.recoveries?.length??0,lastRecoveryAt:r.recoveries?.at(-1)?.at,...heads,retainedCommits:Number((await this.db.prepare('SELECT COUNT(*) n FROM studio_git_commits WHERE source_id=?').get(r.sourceId))!.n)};}));
  return {year:op.year,days,total,unknownDates,repositories:coverage,authors:authors.slice(0,200),authorsTruncated:authors.length>200,activity:activity.map(a=>({...a,weeks:weekly.filter(w=>w.sourceId===a.sourceId).map(w=>({index:Number(w.idx),count:Number(w.count)}))})),years,readAt:new Date(this.now()).toISOString()};
 }
 private async day(op:Extract<GitStoreCommand,{kind:'day'}>):Promise<unknown> {
  const at=gitTime(op.date+'T00:00:00.000Z');requireMission(!!at&&at.slice(0,10)===op.date,'INVALID_INPUT','Invalid UTC contribution day');
  const limit=op.limit??50;requireMission(Number.isSafeInteger(limit)&&limit>0&&limit<=100,'INVALID_INPUT','Invalid commit page limit');
  (await this.bindings(op.sourceIds,op.expectedRepositories));const scope=this.filtered(op.sourceIds,op.authorKey),until=op.date+'T23:59:59.999Z';let where=`${scope.sql} AND graph_date>=? AND graph_date<=?`,values:SqlInput[]=[...scope.values,at,until];
  if(op.after){const cursor=op.after;requireMission(gitTime(cursor.at)===cursor.at,'INVALID_INPUT','Commit cursor must use its exact canonical timestamp');missionIdentifier(cursor.sourceId);gitSha(cursor.sha);requireMission(op.sourceIds.includes(cursor.sourceId)&&cursor.at>=at&&cursor.at<=until,'INVALID_INPUT','Commit cursor is outside this day/source scope');where+=' AND (graph_date<? OR (graph_date=? AND (source_id>? OR (source_id=? AND sha>?))))';values.push(cursor.at,cursor.at,cursor.sourceId,cursor.sourceId,cursor.sha);}
  const rows=(await this.db.prepare(`SELECT source_id,sha,graph_date,date_basis,imported_at,body FROM studio_git_commits WHERE ${where} ORDER BY graph_date DESC,source_id,sha LIMIT ?`).all(...values,limit+1)),page=rows.slice(0,limit),last=page.at(-1);
  return {date:op.date,commits:page.map(r=>({sourceId:r.source_id,dateBasis:r.date_basis,importedAt:r.imported_at,...JSON.parse(String(r.body))})),...(rows.length>limit&&last?{nextCursor:{at:last.graph_date,sourceId:last.source_id,sha:last.sha}}:{})};
 }
}
