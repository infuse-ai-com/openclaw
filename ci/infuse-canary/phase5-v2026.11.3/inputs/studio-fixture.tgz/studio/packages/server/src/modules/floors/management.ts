import { floorCommand, floorRepositoryCatalog, type FloorCommand, type FloorRecord, type FloorRepositoryCatalog } from '@studio/contracts';
import { KnowledgeClient } from '../../knowledge-client.js';
import { KnowledgeManagementClient } from '../../knowledge-management.js';
import { MissionError } from '../missions/domain.js';
import type { RepositoryRegistryService } from '../../repository-registry.js';
import type { FloorGuard, FloorService } from './service.js';

export interface FloorDirectoryPort {
  projects(includeRetired?: boolean): Array<{ id: string; name: string; memberProfileIds: string[]; kind?: 'company' }>;
  record(id: string): FloorRecord | undefined;
  knowledgeOnly(id: string): boolean;
  configured(id: string): boolean;
  validate(command: FloorCommand): void;
}

/** Shared by browser and attested Gateway transports; neither supplies actor authority in command data. */
export class FloorManagementService {
  constructor(private service: FloorService, readonly directory: FloorDirectoryPort, private members: () => Array<{ id: string; name: string }>,
    private knowledge?: KnowledgeClient, private management?: KnowledgeManagementClient,
    private readRepositoryInventory?: (after: string | undefined, guard: () => void) => Promise<unknown>, private registry?: RepositoryRegistryService) {}
  async registryOperation(kind: 'catalog' | 'preview' | 'compare' | 'command' | 'receipt', guard: FloorGuard, input?: unknown) {
    const initial=guard();
    const admit=()=>{const current=guard(); if(!current.canManage||JSON.stringify(current.actor)!==JSON.stringify(initial.actor))
      throw new MissionError('FORBIDDEN','Repository management permission changed');};
    admit(); if(!this.registry) throw new MissionError('UNAVAILABLE','Repository preview is unavailable');
    const result=kind==='catalog'?(await this.registry.managementCatalog(initial.actor,admit) ?? this.registry.catalog(admit)):
      kind==='command'?await this.registry.command(input,initial.actor,admit):
      kind==='receipt'?await this.registry.receipt(String(input),initial.actor,admit):
      kind==='preview'?await this.registry.preview(input,initial.actor,admit):await this.registry.compare(input,initial.actor,admit);
    admit();return result;
  }
  async repositoryInventory(guard: FloorGuard, after?: string): Promise<unknown> {
    const initial = guard();
    const admit = () => {
      const live = guard();
      if (!live.canManage || JSON.stringify(live.actor) !== JSON.stringify(initial.actor))
        throw new MissionError('FORBIDDEN', 'Repository management permission changed');
    };
    admit();
    if (!this.readRepositoryInventory) throw new MissionError('UNAVAILABLE', 'Repository inventory is unavailable');
    const result = await this.readRepositoryInventory(after, admit);
    admit(); return result;
  }
  async catalog(guard: FloorGuard): Promise<FloorRepositoryCatalog> {
    const principal = guard();
    if (!principal.canManage) throw new MissionError('FORBIDDEN', 'Floor management access is required');
    const admit = () => {
      const current = guard();
      if (!current.canManage || JSON.stringify(current.actor) !== JSON.stringify(principal.actor))
        throw new MissionError('FORBIDDEN', 'Repository management permission changed');
    };
    const registry = await this.registry?.managementCatalog(principal.actor, admit);
    if (registry) {
      if (registry.mode !== 'active') throw new MissionError('UNAVAILABLE', 'Repository authority transfer is not active');
      return floorRepositoryCatalog.parse(registry.repositories.map(repo => ({ id: repo.id, slug: repo.slug,
        displayName: repo.identity.name, owner: repo.metadata.owner, branch: repo.capabilities.documentation.enabled ? repo.capabilities.documentation.branch : 'default',
        state: 'pending', commit: null, documentCount: 0, errorCode: null, revision: repo.revision, managed: true,
        capabilities: repo.capabilities, providerStatus: registry.statuses.filter(status => status.repositoryId === repo.id) })));
    }
    if (!this.knowledge) throw new MissionError('UNAVAILABLE', 'Knowledge is not connected');
    const response = await this.knowledge.read('GET', 'floors/repositories', new URLSearchParams(), undefined, JSON.stringify(principal.actor));
    const current = guard();
    if (!current.canManage || JSON.stringify(current.actor) !== JSON.stringify(principal.actor)) throw new MissionError('FORBIDDEN', 'Floor management permission changed');
    return floorRepositoryCatalog.parse(JSON.parse(Buffer.from(response.body).toString('utf8')));
  }
  list(guard: FloorGuard) {
    if (!guard().canManage) throw new MissionError('FORBIDDEN', 'Floor management access is required');
    return { floors: this.directory.projects(true).map(project => ({
      id: project.id, name: project.name, description: this.directory.record(project.id)?.description ?? '',
      memberProfileIds: project.memberProfileIds, repositories: this.directory.record(project.id)?.repositories ?? [],
      revision: this.directory.record(project.id)?.revision ?? 0,
      configured: this.directory.configured(project.id),
      canRetire: true,
      retiredAt: this.directory.record(project.id)?.retiredAt,
      legacyCore: project.id === 'core' && project.kind === 'company' && !this.directory.record(project.id),
    })), members: this.members() };
  }
  async apply(input: unknown, guard: FloorGuard) {
    const parsed = floorCommand.safeParse(input);
    if (!parsed.success) throw new MissionError('INVALID_INPUT', 'Check the floor name, members and source selection.');
    if (!('floor' in parsed.data)) return this.service.apply(parsed.data, guard, command => this.directory.validate(command));
    // Parse again in the application/worker layers; no caller-provided catalog is trusted.
    const candidates = await this.catalog(guard);
    if (parsed.data.floor.id !== 'core') await this.adoptCore(guard, candidates);
    return this.service.apply(parsed.data, guard, command => {
      this.directory.validate(command);
      if ('floor' in command && command.floor.repositories.some(source => !candidates.some(candidate => candidate.id === source.id && candidate.slug === source.slug)))
        throw new MissionError('FORBIDDEN', 'A selected repository is no longer admitted');
    });
  }
  receipt(commandId: string, guard: FloorGuard) { return this.service.receipt(commandId, guard); }
  private async adoptCore(guard: FloorGuard, candidates?: FloorRepositoryCatalog) {
    const core = this.directory.projects().find(project => project.id === 'core' && project.kind === 'company');
    if (!core || this.directory.record('core')) return;
    const principal = guard();
    if (await this.registry?.managementCatalog(principal.actor, () => {
      const current = guard();
      if (!current.canManage || JSON.stringify(current.actor) !== JSON.stringify(principal.actor)) throw new MissionError('FORBIDDEN', 'Management permission changed');
    })) throw new MissionError('UNAVAILABLE', 'The existing Core association must be transferred before registry floor edits');
    const sources = candidates ?? await this.catalog(guard);
    // Freeze the legacy inventory before the first management mutation can add a
    // new source. This is part of that authorized mutation, never a GET effect.
    await this.service.apply({ commandId: 'core-source-adoption-v1', intent: 'update', expectedRevision: 0,
      floor: { id: 'core', name: core.name, description: '', memberProfileIds: core.memberProfileIds,
        repositories: sources.map(({ id, slug }) => ({ id, slug, shared: true })) } }, guard, command => this.directory.validate(command));
  }
  async repositoryOperation(guard: FloorGuard, commandId?: string, command?: unknown) {
    const initial = guard();
    if (!initial.canManage) throw new MissionError('FORBIDDEN', 'Repository management access is required');
    if (command !== undefined) throw new MissionError('UNAVAILABLE', 'Legacy repository setup writes are retired');
    if (!this.management) throw new MissionError('UNAVAILABLE', 'Repository onboarding is not connected');
    const guardDispatch = () => {
      const live = guard();
      if (!live.canManage || JSON.stringify(live.actor) !== JSON.stringify(initial.actor)) throw new MissionError('FORBIDDEN', 'Repository management permission changed');
    };
    guardDispatch();
    const result = await this.management.request(initial.actor, commandId, command, guardDispatch);
    const setup = result as { slug?: string; lexicalReady?: boolean } | null;
    let meaning: unknown = { state: 'unavailable', reason: 'Documents are not indexed yet.' };
    if (setup?.lexicalReady && setup.slug && this.knowledge) {
      try {
        const response = await this.knowledge.read('GET', 'search/meaning/readiness', new URLSearchParams({ repository: setup.slug }), undefined, JSON.stringify(initial.actor));
        meaning = JSON.parse(Buffer.from(response.body).toString('utf8'));
      } catch { meaning = { state: 'unavailable', reason: 'Meaning readiness could not be confirmed.' }; }
    }
    const live = guard();
    if (!live.canManage || JSON.stringify(live.actor) !== JSON.stringify(initial.actor)) throw new MissionError('FORBIDDEN', 'Repository management permission changed');
    return result ? { ...(result as object), meaning } : null;
  }
}
