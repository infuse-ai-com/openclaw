import { createHash } from 'node:crypto';
import type { Mission, MissionArtifact, MissionCommand, MissionCoordinatorIdentity, MissionDispatch, MissionRole } from '@studio/contracts';

export class MissionError extends Error {
  constructor(public readonly code: string, message: string, public readonly details?: Record<string, unknown>) { super(message); }
}
export type MissionActor =
  | { kind: 'human'; profileId: string; approver: boolean }
  | { kind: 'agent'; gatewayId: string; agentId: string; sessionKey: string; sessionId: string };
export function requireMission(condition: unknown, code: string, message: string): asserts condition {
  if (!condition) throw new MissionError(code, message);
}
export function digest(value: unknown): string {
  // Callers supply parsed records with canonical property order, never arbitrary JSON text.
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}
export function actorKey(actor: MissionActor): string {
  return actor.kind === 'human' ? `human:${actor.profileId}`
    : JSON.stringify(['agent', actor.gatewayId, actor.agentId, actor.sessionKey, actor.sessionId]);
}
export function authorize(command: MissionCommand, actor: MissionActor, binding?: MissionDispatch): void {
  if (['delegate', 'deliver', 'verify', 'close'].includes(command.type)) {
    const required: MissionRole = command.type === 'deliver' ? 'specialist' : 'coordinator';
    requireMission(actor.kind === 'agent' && binding?.role === required, 'FORBIDDEN', `Requires the assigned ${required}`);
  } else {
    requireMission(actor.kind === 'human', 'FORBIDDEN', 'Requires an authenticated Studio member');
    if (command.type !== 'create') requireMission(actor.approver, 'FORBIDDEN', 'Requires a configured Studio approver');
  }
}
export function assertBinding(mission: Mission, actor: MissionActor, binding?: MissionDispatch): asserts binding is MissionDispatch {
  requireMission(actor.kind === 'agent' && binding, 'FORBIDDEN', 'No mission assignment for this session');
  const current = mission.assignments[binding.role];
  requireMission(binding.missionId === mission.id && current?.dispatchId === binding.id
    && current.generation === binding.generation && ['sending', 'accepted', 'uncertain'].includes(binding.state)
    && binding.gatewayId === actor.gatewayId && binding.agentId === actor.agentId
    && binding.sessionKey === actor.sessionKey && binding.sessionId === actor.sessionId
    && mission.state === 'running', 'STALE_ASSIGNMENT', 'This runtime assignment is no longer authoritative');
}
export function coordinatorIdentity(binding: MissionDispatch): MissionCoordinatorIdentity {
  requireMission(binding.role === 'coordinator' && binding.sessionId, 'STALE_ASSIGNMENT', 'An exact coordinator assignment is required');
  return { gatewayId: binding.gatewayId, agentId: binding.agentId, sessionKey: binding.sessionKey, sessionId: binding.sessionId,
    assignmentId: binding.id, generation: binding.generation };
}
export function transition(previous: Mission | undefined, command: MissionCommand, actor: MissionActor,
  binding: MissionDispatch | undefined, at: string, closeoutDispatch?: MissionDispatch): {
    mission: Mission; dispatches: MissionDispatch[]; continuation?: MissionDispatch['continuation']; artifact?: MissionArtifact;
  } {
  authorize(command, actor, binding);
  if (actor.kind === 'agent') { requireMission(previous, 'NOT_FOUND', 'Mission not found'); assertBinding(previous, actor, binding); }
  requireMission((previous?.version ?? 0) === command.expectedVersion, 'VERSION_CONFLICT', 'Reload the mission before submitting this command');
  if (command.type === 'create') {
    requireMission(!previous, 'ALREADY_EXISTS', 'Mission already exists');
    return { mission: { id: command.missionId, version: 1, state: 'draft', held: false, paper: command.paper,
      paperDigest: digest(command.paper), assignments: {}, task: { state: 'pending' }, createdAt: at, updatedAt: at }, dispatches: [] };
  }
  requireMission(previous, 'NOT_FOUND', 'Mission not found');
  requireMission(!['accepted', 'closed', 'cancelled'].includes(previous.state) || (previous.state === 'closed' && command.type === 'acknowledge'), 'TERMINAL', 'Mission is terminal');
  requireMission(!previous.closeoutRequest || ['hold', 'cancel', 'resolve-closeout-gate', 'acknowledge'].includes(command.type),
    'CLOSEOUT_PENDING', 'The closeout request freezes further mission work');
  const mission = structuredClone(previous);
  const dispatches: MissionDispatch[] = [];
  let continuation: MissionDispatch['continuation'];
  let artifact: MissionArtifact | undefined;
  const humanId = actor.kind === 'human' ? actor.profileId : '';
  function dispatch(role: MissionRole) {
    const generation = (mission.assignments[role]?.generation ?? 0) + 1;
    const id = digest([mission.id, command.commandId, role, generation]);
    const target = mission.paper[role];
    mission.assignments[role] = { generation, dispatchId: id };
    dispatches.push({ id, missionId: mission.id, role, generation, ...target,
      sessionKey: mission.paper.capabilities ? `agent:${target.agentId}:subagent:studio-${id}` : `agent:${target.agentId}:studio:${id}`, state: 'pending', createdAt: at });
  }
  switch (command.type) {
    case 'approve':
      requireMission(mission.state === 'draft', 'STATE_CONFLICT', 'Only a draft can be approved');
      mission.approval = { profileId: humanId, paperDigest: mission.paperDigest, at }; mission.state = 'approved'; break;
    case 'start':
      requireMission(mission.state === 'approved' && !mission.held && mission.approval?.paperDigest === mission.paperDigest,
        'STATE_CONFLICT', 'An approved, unheld paper is required');
      mission.state = 'running'; dispatch('coordinator'); break;
    case 'delegate':
      requireMission(mission.state === 'running' && !mission.held && mission.task.state === 'pending', 'STATE_CONFLICT', 'Task cannot be dispatched');
      mission.task.state = 'assigned'; dispatch('specialist'); break;
    case 'deliver':
      requireMission(mission.task.state === 'assigned', 'STATE_CONFLICT', 'Task is not awaiting evidence');
      requireMission(mission.assignments.coordinator, 'STALE_ASSIGNMENT', 'Delivery requires an assigned coordinator');
      requireMission(!mission.correction || command.artifact, 'STATE_CONFLICT', 'A correction requires stored artifact content');
      if (command.artifact) {
        requireMission(binding, 'STALE_ASSIGNMENT', 'Artifact delivery requires an assigned specialist');
        const bytes = Buffer.from(command.artifact.content, 'utf8');
        const sha256 = createHash('sha256').update(bytes).digest('hex');
        artifact = { uri: `artifact:studio:${mission.id}:${sha256}`, revision: mission.correction ? '2' : '1',
          mediaType: command.artifact.mediaType, content: command.artifact.content, byteLength: bytes.length, sha256, createdAt: at,
          producer: { gatewayId: binding.gatewayId, agentId: binding.agentId, assignmentId: binding.id, generation: binding.generation } };
        mission.task = { state: 'delivered', evidence: { uri: artifact.uri, revision: artifact.revision, sha256, summary: command.artifact.summary } };
      } else mission.task = { state: 'delivered', evidence: command.evidence };
      continuation = { assignmentId: mission.assignments.coordinator.dispatchId, commandId: command.commandId,
        missionVersion: mission.version + 1, evidenceHash: mission.task.evidence!.sha256, evidenceRevision: mission.task.evidence!.revision }; break;
    case 'verify':
      requireMission(mission.task.state === 'delivered' && mission.task.evidence?.sha256 === command.evidenceHash
        && (!mission.correction || command.evidenceRevision === '2')
        && (command.evidenceRevision === undefined || command.evidenceRevision === mission.task.evidence.revision),
        'EVIDENCE_CONFLICT', 'Verification must name the current evidence revision and hash');
      if (mission.paper.closeoutPolicy) {
        requireMission(!mission.held && command.evidenceRevision === mission.task.evidence.revision && command.assessment
          && command.assessment.residualGaps.length === 0 && binding, 'VERIFICATION_REQUIRED', 'Coordinator verification requires an exact read and an assessment without residual gaps');
        mission.verification = { commandId: command.commandId, actor: coordinatorIdentity(binding), paperDigest: mission.paperDigest,
          policyDigest: digest(mission.paper.closeoutPolicy), evidenceHash: command.evidenceHash, evidenceRevision: command.evidenceRevision,
          at, assessment: structuredClone(command.assessment) };
      }
      mission.task.state = 'verified'; break;
    case 'close': {
      const verification = mission.verification;
      requireMission(mission.paper.closeoutPolicy && mission.state === 'running' && !mission.held && mission.task.state === 'verified'
        && verification && binding && closeoutDispatch, 'CLOSEOUT_REQUIRED', 'Closeout requires the verified coordinator turn');
      requireMission(command.evidenceHash === mission.task.evidence?.sha256 && command.evidenceRevision === mission.task.evidence.revision
        && command.verificationCommandId === verification.commandId && verification.evidenceHash === command.evidenceHash
        && verification.evidenceRevision === command.evidenceRevision && verification.paperDigest === mission.paperDigest
        && verification.policyDigest === digest(mission.paper.closeoutPolicy) && verification.assessment.residualGaps.length === 0
        && digest(verification.actor) === digest(coordinatorIdentity(binding)), 'EVIDENCE_CONFLICT', 'Closeout requires the current exact verification');
      mission.closeoutRequest = { commandId: command.commandId, actor: coordinatorIdentity(binding), paperDigest: mission.paperDigest,
        policyDigest: digest(mission.paper.closeoutPolicy), evidenceHash: command.evidenceHash, evidenceRevision: command.evidenceRevision,
        verificationCommandId: verification.commandId, missionVersion: mission.version + 1, dispatchId: closeoutDispatch.id, at };
      break;
    }
    case 'resolve-closeout-gate':
      requireMission(mission.paper.closeoutPolicy?.humanGate === 'required' && mission.state === 'running' && !mission.held
        && mission.task.state === 'verified' && !mission.closeoutGate, 'STATE_CONFLICT', 'There is no unresolved verified closeout gate');
      requireMission(command.evidenceHash === mission.task.evidence?.sha256 && command.evidenceRevision === mission.task.evidence.revision,
        'EVIDENCE_CONFLICT', 'Gate resolution requires the exact verified evidence');
      mission.closeoutGate = { profileId: humanId, evidenceHash: command.evidenceHash, evidenceRevision: command.evidenceRevision, paperDigest: mission.paperDigest, at }; break;
    case 'acknowledge':
      requireMission(mission.state === 'closed' && mission.closeout && !mission.acknowledgement, 'STATE_CONFLICT', 'Only a coordinator closure can be acknowledged once');
      requireMission(command.evidenceHash === mission.closeout.evidenceHash && command.evidenceRevision === mission.closeout.evidenceRevision,
        'EVIDENCE_CONFLICT', 'Acknowledgement requires the exact closed evidence');
      mission.acknowledgement = { profileId: humanId, evidenceHash: command.evidenceHash, evidenceRevision: command.evidenceRevision, at }; break;
    case 'accept':
      requireMission(!mission.paper.closeoutPolicy, 'STATE_CONFLICT', 'This approved paper uses coordinator closeout');
      requireMission(mission.task.state === 'verified' && mission.task.evidence?.sha256 === command.evidenceHash
        && (!mission.correction || command.evidenceRevision === '2')
        && (command.evidenceRevision === undefined || command.evidenceRevision === mission.task.evidence.revision),
        'EVIDENCE_CONFLICT', 'Human acceptance requires the current verified evidence revision and hash');
      mission.state = 'accepted'; mission.acceptance = { profileId: humanId, evidenceHash: command.evidenceHash, evidenceRevision: mission.task.evidence.revision, at }; break;
    case 'request-correction': {
      requireMission(mission.state === 'running' && mission.task.state === 'verified' && !mission.correction,
        'STATE_CONFLICT', 'One correction may be requested for the first verified result');
      const evidence = mission.task.evidence;
      requireMission(evidence && evidence.revision === '1' && evidence.uri === `artifact:studio:${mission.id}:${evidence.sha256}`
        && command.evidenceRevision === '1' && command.evidenceHash === evidence.sha256,
      'EVIDENCE_CONFLICT', 'Correction must name the first stored evidence revision and hash');
      requireMission(mission.assignments.specialist?.generation === 1, 'STALE_ASSIGNMENT', 'Correction requires the original specialist assignment');
      dispatch('specialist');
      mission.correction = { commandId: command.commandId, profileId: humanId, reason: command.reason, at,
        evidence: structuredClone(evidence), specialistAssignmentId: mission.assignments.specialist.dispatchId };
      mission.task = { state: 'assigned' }; delete mission.verification; delete mission.closeoutGate; break;
    }
    case 'hold': requireMission(!mission.held, 'STATE_CONFLICT', 'Already held'); mission.held = true; break;
    case 'resume': requireMission(mission.held, 'STATE_CONFLICT', 'Not held'); mission.held = false; break;
    case 'cancel':
      mission.state = 'cancelled'; mission.cancellation = { profileId: humanId, reason: command.reason, at }; break;
  }
  mission.version++; mission.updatedAt = at;
  return { mission, dispatches, ...(continuation ? { continuation } : {}), ...(artifact ? { artifact } : {}) };
}

export function coordinatorContinuation(mission: Mission, binding: MissionDispatch,
  cause: NonNullable<MissionDispatch['continuation']>, at: string): MissionDispatch {
  requireMission(cause.kind !== 'resume' && cause.kind !== 'conversation', 'STATE_CONFLICT', 'Only evidence delivery uses this continuation factory');
  requireMission(binding.sessionId && !binding.continuation && binding.role === 'coordinator'
    && binding.id === cause.assignmentId && mission.assignments.coordinator?.dispatchId === binding.id
    && mission.assignments.coordinator.generation === binding.generation
    && binding.missionId === mission.id && ['sending', 'accepted', 'uncertain'].includes(binding.state),
  'STALE_ASSIGNMENT', 'Coordinator assignment cannot receive a continuation');
  return { id: digest([mission.id, cause.assignmentId, cause.commandId, 'evidence-delivered']),
    missionId: mission.id, role: binding.role, generation: binding.generation,
    gatewayId: binding.gatewayId, agentId: binding.agentId, sessionKey: binding.sessionKey,
    sessionId: binding.sessionId, continuation: cause, state: 'bound', createdAt: at };
}

export function continuationIsCurrent(mission: Mission, item: MissionDispatch, binding: MissionDispatch): boolean {
  if (item.continuation?.kind === 'resume' || item.continuation?.kind === 'conversation') return Boolean(mission.state === 'running'
    && (item.continuation.kind !== 'conversation' || !mission.closeoutRequest && item.role === 'coordinator' && item.transport === 'outbound-v1')
    && binding.id === item.continuation.assignmentId && !binding.continuation && binding.missionId === mission.id
    && mission.assignments[item.role]?.dispatchId === binding.id && mission.assignments[item.role]?.generation === item.generation
    && binding.generation === item.generation && binding.role === item.role && ['sending', 'accepted', 'uncertain'].includes(binding.state)
    && binding.gatewayId === item.gatewayId && binding.agentId === item.agentId
    && binding.sessionKey === item.sessionKey && binding.sessionId === item.sessionId);
  return Boolean(item.continuation && mission.state === 'running' && mission.task.state === 'delivered'
    && mission.task.evidence?.sha256 === item.continuation.evidenceHash
    && mission.task.evidence.revision === (item.continuation.evidenceRevision ?? (mission.correction ? '1' : mission.task.evidence.revision))
    && binding.id === item.continuation.assignmentId && binding.missionId === mission.id
    && mission.assignments.coordinator?.dispatchId === binding.id
    && mission.assignments.coordinator.generation === item.generation && binding.generation === item.generation
    && !binding.continuation && binding.role === 'coordinator' && ['sending', 'accepted', 'uncertain'].includes(binding.state)
    && binding.gatewayId === item.gatewayId && binding.agentId === item.agentId
    && binding.sessionKey === item.sessionKey && binding.sessionId === item.sessionId);
}
