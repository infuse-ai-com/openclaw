import {ArtifactRetainedService} from '../operations/artifact-retained-service.js';
import {CompanySignalsService} from '../operations/company-service.js';
import {MonitoringService} from '../operations/monitoring-service.js';
import { GitContributionsService } from '../operations/git-service.js';
import { AgentTelemetryService } from '../operations/agent-telemetry-service.js';
import { MachineReadService } from '../machine/service.js';
import {
  missionIdentifier, parseMissionCommand, parseMissionEvidenceQuery, parseMissionListQuery,
  type RuntimeTarget, type StudioBootstrap,
} from '@studio/contracts';
import { WhiteboardCompanionService } from '../whiteboard/companion.js';
import { MissionStore } from '../../persistence/missions/store.js';
import { MissionError, requireMission, type MissionActor } from './domain.js';
import { WhiteboardService } from '../whiteboard/service.js';
import { CollaborativeWhiteboardService } from '../whiteboard/text-service.js';
import { FloorService } from '../floors/service.js';

export type StudioHumanActor = Extract<MissionActor, { kind: 'human' }>;
/** The transport resolves current membership/session authority synchronously at admission. */
export type StudioAccessGuard = () => StudioHumanActor;
function parsed<T>(parse: (value: unknown) => T, value: unknown): T {
  try { return parse(value); } catch { throw new MissionError('INVALID_INPUT', 'Invalid Studio request'); }
}

export interface StudioAuthorityOptions {
  store: MissionStore;
  authorityId: string;
  gatewayId?: string;
  targets: RuntimeTarget[];
  dispatchEnabled: boolean | (() => boolean);
  /** Native mode may queue intent while its dispatcher is off. Standalone S1 cannot. */
  executionCommandsEnabled?: boolean | (() => boolean);
  executionTargets?: () => RuntimeTarget[];
  executionEnrollment?: (gatewayId: string) => number | undefined;
  dispatchTransport?: 'outbound-v1';
  singleActiveMission?: boolean;
  whiteboardCollaborationEnabled?: () => boolean;
}

/** Human application operations shared by HTTP and the native Gateway adapter. */
export class StudioAuthority {
  readonly artifactRetained: ArtifactRetainedService;
  readonly companySignals: CompanySignalsService;
  readonly monitoring: MonitoringService;
  readonly contributions: GitContributionsService;
  readonly agentTelemetry: AgentTelemetryService;
  readonly machineReads: MachineReadService;
  readonly floors: FloorService;
  readonly whiteboardCompanion: WhiteboardCompanionService;
  readonly whiteboard: WhiteboardService;
  readonly collaborativeWhiteboard: CollaborativeWhiteboardService;
  private readonly targets: RuntimeTarget[];
  private readonly authorityId: string;
  private readonly gatewayId: string;

  constructor(private readonly options: StudioAuthorityOptions) {
    this.artifactRetained = new ArtifactRetainedService(options.store);
    this.companySignals = new CompanySignalsService(options.store);
    this.monitoring = new MonitoringService(options.store);
    this.contributions = new GitContributionsService(options.store);
    this.agentTelemetry = new AgentTelemetryService(options.store);
    this.machineReads = new MachineReadService(options.store);
    this.floors = new FloorService(options.store);
    this.whiteboardCompanion = new WhiteboardCompanionService(options.store);
    this.whiteboard = new WhiteboardService(options.store);
    this.collaborativeWhiteboard = new CollaborativeWhiteboardService(options.store, options.whiteboardCollaborationEnabled);
    this.authorityId = missionIdentifier(options.authorityId);
    this.gatewayId = missionIdentifier(options.gatewayId ?? 'studio');
    this.targets = [...new Map(options.targets.map(target => {
      const value = { gatewayId: missionIdentifier(target.gatewayId), agentId: missionIdentifier(target.agentId) };
      return [JSON.stringify(value), value];
    })).values()];
  }

  available(): boolean { return this.options.store.available(); }

  private human(actor: StudioHumanActor): void {
    requireMission(actor?.kind === 'human' && typeof actor.profileId === 'string' && actor.profileId.trim()
      && typeof actor.approver === 'boolean', 'FORBIDDEN', 'An authenticated Studio member is required');
  }
  private enabled(value: boolean | (() => boolean) | undefined, fallback = true): boolean {
    return typeof value === 'function' ? value() : value ?? fallback;
  }

  private guard(actor: StudioHumanActor, current: StudioAccessGuard, approver = false): () => void {
    this.human(actor);
    requireMission(typeof current === 'function', 'FORBIDDEN', 'Live Studio authority is required');
    return () => {
      const live = current(); this.human(live);
      requireMission(live.profileId === actor.profileId, 'FORBIDDEN', 'Studio identity changed');
      requireMission(!approver || live.approver, 'FORBIDDEN', 'Studio approver role was revoked');
    };
  }

  bootstrap(actor: StudioHumanActor): StudioBootstrap {
    this.human(actor);
    return { profileId: actor.profileId, gatewayId: this.gatewayId, authorityId: this.authorityId,
      capabilities: { member: true, approver: actor.approver }, targets: structuredClone(this.targets),
      dispatchEnabled: this.enabled(this.options.dispatchEnabled, false) };
  }

  async list(query: unknown, actor: StudioHumanActor, current: StudioAccessGuard) {
    const guard = this.guard(actor, current);
    const value = await this.options.store.list(parsed(parseMissionListQuery, query), guard);
    guard(); return value;
  }

  async get(id: unknown, actor: StudioHumanActor, current: StudioAccessGuard) {
    const guard = this.guard(actor, current);
    const value = await this.options.store.view(parsed(missionIdentifier, id), guard);
    guard(); return value;
  }

  async evidence(query: unknown, actor: StudioHumanActor, current: StudioAccessGuard) {
    const guard = this.guard(actor, current);
    const value = await this.options.store.evidence(parsed(parseMissionEvidenceQuery, query), guard);
    guard(); return value;
  }

  async command(input: unknown, actor: StudioHumanActor, current: StudioAccessGuard) {
    const command = parsed(parseMissionCommand, input);
    const guard = this.guard(actor, current, command.type !== 'create');
    guard();
    const receipt = await this.options.store.command(command, actor, guard,
      { executionCommandsEnabled: this.enabled(this.options.executionCommandsEnabled), allowedTargets: this.targets,
        ...(this.options.dispatchTransport ? { dispatchTransport: this.options.dispatchTransport } : {}),
        singleActiveMission: this.options.singleActiveMission,
        ...(this.options.executionTargets ? { allowedExecutionTargets: this.options.executionTargets() } : {}),
        executionGuard: targets => {
          requireMission(this.enabled(this.options.executionCommandsEnabled), 'DISPATCH_DISABLED', 'Runtime execution is disabled');
          const allowed = this.options.executionTargets?.();
          if (allowed) for (const target of targets) requireMission(allowed.some(item => item.gatewayId === target.gatewayId && item.agentId === target.agentId),
            'CONFIGURATION', 'Execution target is no longer enrolled');
          for (const target of targets) if (target.enrollmentGeneration !== undefined) requireMission(
            this.options.executionEnrollment?.(target.gatewayId) === target.enrollmentGeneration, 'CONFIGURATION', 'Execution enrollment has changed');
        } });
    guard(); return receipt;
  }
}
