import type {MissionStore} from '../../persistence/missions/store.js';
import type {ArtifactRetainedCommand} from '../../persistence/missions/artifact-retained.js';
import type {ArtifactRetainedPage} from '@studio/contracts';
export class ArtifactRetainedService {constructor(private store:MissionStore){}read(operation:Extract<ArtifactRetainedCommand,{kind:'read'}>,guard:()=>void):Promise<ArtifactRetainedPage>{return this.store.artifactRetained(operation,guard);}}
