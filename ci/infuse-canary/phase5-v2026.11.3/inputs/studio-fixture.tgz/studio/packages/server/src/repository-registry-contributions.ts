import { registryFailure, type RegistryPolicyFailure } from './repository-registry-failure.js';
import { createHash } from 'node:crypto';
import type { MissionStore } from './persistence/missions/store.js';
import type { OperationJob } from './persistence/missions/operations.js';
import type { GitRepositoryState } from './persistence/missions/git-contributions.js';
import { policyEnabled, policyContent, stableRegistryJson, type RegistryPolicy } from '@studio/contracts';
import { sameGitSource, type GitContributionsConfig, type GitRepositoryConfig } from './modules/operations/git-config.js';
import type { FloorDirectoryPort } from './modules/floors/management.js';
import { configuredRegistryClient, type RegistryPolicyClient } from './repository-registry-policy-client.js';
import { MissionError } from './modules/missions/domain.js';
import { isStudioPilotRepository, studioGitLabProject } from './modules/operations/studio-gitlab-pilot.js';

/** Desired settings come from the registry; credentials, stop switch and history remain with the existing collector. */
export class RegistryContributionsAdapter {
  private client?: RegistryPolicyClient;
  private failure?: RegistryPolicyFailure;
  private timer?: ReturnType<typeof setInterval>;
  private refreshing?: Promise<void>;
  constructor(private readonly path: string, private readonly local: () => GitContributionsConfig | undefined,
    private readonly floors: FloorDirectoryPort, private readonly store?: MissionStore) {}
  start() {
    if (this.timer) return;
    void this.refresh().catch(() => {});
    this.timer = setInterval(() => { void this.refresh().catch(() => {}); }, 30000);
    this.timer.unref();
  }
  async stop() { if (this.timer) clearInterval(this.timer); this.timer = undefined; await this.refreshing?.catch(() => {}); }
  refresh(): Promise<void> {
    if (!this.refreshing) this.refreshing = (async () => {
      let client: RegistryPolicyClient;
      try { client = await configuredRegistryClient(this.path, 'contributions'); }
      catch (error) { this.client = undefined; throw error; }
      // Replace the old configured identity before fetching; an unavailable new credential cannot reuse its lease.
      this.client = undefined;
      const snapshot = await client.snapshot();
      if (this.store) {
        const marker = await this.store.operations<OperationJob | null>({ kind: 'get', id: contributionsRegistryMarker }, snapshot.guard);
        if (marker?.checkpoint.epoch !== snapshot.policy.epoch) { this.client = undefined; throw Error('registry_transfer_required'); }
        this.client = client;
        const effective = this.read();
        for (const row of snapshot.policy.repositories) {
          const source = effective.repositories.find(source => source.sourceId === row.sourceId);
          const result = row.sourceId ? await this.store.gitContributions<{source: GitRepositoryState} | null>({ kind: 'inspect', sourceId: row.sourceId }, snapshot.guard) : null;
          const state = result?.source;
          const complete = state?.stage === 'complete' && !state.historyGap && (!source?.gitLabPilotTokenEnv || state.scanProvider === 'gitlab');
          await client.acknowledge({ version: 1, repositoryId: row.id, revision: row.revision,
            phase: !source ? 'disabled' : !effective.enabled ? 'pending' : state?.lastError ? 'failed' : complete ? 'ready' : state ? 'indexing' : 'pending',
            commit: null, details: { generation: state?.cycleId ?? null, coverage: complete ? 'complete' : state ? 'partial' : 'none',
              lastSuccessAt: state?.lastSuccessAt ?? null, error: state?.lastError?.toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0,80) ?? null },
          });
        }
      } else { this.client = client; }
      this.failure = undefined;
    })().catch(error => {
      const failure = registryFailure(error);
      if (this.failure?.reason !== failure.reason) console.warn(JSON.stringify({ event: 'contributions_policy_failed', reason: failure.reason }));
      this.failure = failure; throw failure;
    }).finally(() => { this.refreshing = undefined; });
    return this.refreshing;
  }
  read(): GitContributionsConfig {
    try {
      if (!this.client) throw this.failure ?? new Error('policy_not_loaded');
      const policy = this.client.current(), local = this.local();
      if (!local) throw Error('credentials_not_configured');
      const records = this.floors.projects(true).map(floor => {
        const record = this.floors.record(floor.id);
        if (!record) throw Error('floor_not_transferred');
        return record;
      });
      const repositories: GitRepositoryConfig[] = [];
      for (const row of policy.repositories.filter(row => policyEnabled(row, 'contributions'))) {
        const binding = local.repositories.find(source => source.sourceId === row.sourceId);
        if (!binding || binding.organization !== row.identity.organization || binding.projectId !== row.identity.azureProjectId ||
          binding.repositoryId !== row.identity.azureRepositoryId || !row.capabilities.contributions.enabled) throw Error('provider_binding_mismatch');
        const gitLabProject = local.gitLabProjects
          ? local.gitLabProjects.find(mapping => mapping.registryId === row.id && sameGitSource(mapping, binding))?.gitLabProject
          : isStudioPilotRepository(binding, row.id) ? studioGitLabProject : undefined;
        repositories.push({ ...binding, name: row.identity.name,
          projectName: decodeURIComponent(new URL(row.identity.url).pathname.split('/')[2]!),
          floorIds: records.filter(f => !f.retiredAt && f.repositories.some(r => r.id === row.id)).map(f => f.id).sort(),
          registryEpoch: policy.epoch, registryRevision: row.revision,
          intervalMs: row.capabilities.contributions.intervalSeconds * 1000,
          ...(local.studioGitLabPilotTokenEnv && gitLabProject
            ? {gitLabPilotTokenEnv:local.studioGitLabPilotTokenEnv, gitLabProject} : {}) });
      }
      if (repositories.length > 100) throw Error('provider_capacity');
      return { ...local, repositories };
    } catch (error) {
      throw new MissionError('UNAVAILABLE', 'Repository access cannot currently be checked. Retry, or ask a workspace operator to check the connection.', { capability: 'contributions', reason: registryFailure(error).reason });
    }
  }
}

export const contributionsRegistryMarker = 'repository-registry-contributions';
export const contributionsTransferDigest = (value: unknown) => createHash('sha256').update(stableRegistryJson(value)).digest('hex');

/** Preflight the complete transfer before any floor or collector ownership write. */
export function validateContributionsTransfer(local: GitContributionsConfig, policy: RegistryPolicy,
  packet: { version: 1; epoch: string; revision: number; localDigest: string; policyDigest: string }) {
  if (packet.version !== 1 || packet.epoch !== policy.epoch || packet.revision !== policy.revision || policy.consumer !== 'contributions' ||
      packet.localDigest !== contributionsTransferDigest(local) || packet.policyDigest !== createHash('sha256').update(policyContent(policy)).digest('hex'))
    throw Error('registry_transfer_conflict');
  // Disabled/import-only sources retain their source binding and history. Transfer
  // must cover every old binding, but must never turn those records into active collectors.
  const bound = policy.repositories.filter(row => row.sourceId !== null);
  if (bound.length !== local.repositories.length || local.repositories.some(source => !bound.some(row => row.sourceId === source.sourceId &&
    row.identity.organization === source.organization && row.identity.azureProjectId === source.projectId && row.identity.azureRepositoryId === source.repositoryId)))
    throw Error('registry_transfer_changes_admission');
}

/** Explicit operator handover through the existing sole writer; no Git history or cursors are rewritten. */
export async function transferContributionsRegistry(store: MissionStore, local: GitContributionsConfig, policy: RegistryPolicy,
  packet: { version: 1; epoch: string; revision: number; localDigest: string; policyDigest: string }, guard: () => void) {
  validateContributionsTransfer(local, policy, packet);
  const current = await store.operations<OperationJob | null>({ kind: 'get', id: contributionsRegistryMarker }, guard);
  const checkpoint = { epoch: policy.epoch, revision: policy.revision, localDigest: packet.localDigest, policyDigest: packet.policyDigest };
  if (current) {
    if (stableRegistryJson(current.checkpoint) !== stableRegistryJson(checkpoint)) throw Error('registry_transfer_conflict');
    return;
  }
  await store.operations({ kind: 'save', expectedRevision: 0, job: { id: contributionsRegistryMarker, kind: 'repository-registry', source: 'contributions',
    revision: 1, state: 'succeeded', checkpoint, updatedAt: new Date().toISOString() } }, guard);
}
export async function requireLegacyContributionsAuthority(store: MissionStore): Promise<void> {
  if (await store.operations({ kind: 'get', id: contributionsRegistryMarker }, () => undefined)) throw Error('registry_policy_configuration_required');
}
