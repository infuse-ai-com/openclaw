import { createHash } from 'node:crypto';
import {
  healthObject as object,
  healthText as text,
  healthDigest,
  healthTime,
  healthCount,
  missionIdentifier,
  parseTelemetryInput,
  parseGitRepositoryIdentity,
  gitRepositoryUrl,
  gitText,
  parseGitCommit,
  parseHealthCheckView,
  parseHealthObservation,
  parseCompanySignalDefinition,
  parseCompanySignalInput,
  parseArtifactRetainedSource,
  parseArtifactRetainedRecord,
  type TelemetryInput,
  type GitRepositoryMetadata,
  type GitCommitMetadata,
  type HealthObservation,
  type CompanySignalDefinition,
  type CompanySignalInput,
  type ArtifactRetainedSource,
  type ArtifactRetainedRecord,
} from '@studio/contracts';
import type { HealthCheckDefinition } from './monitoring-config.js';
export type BackofficeImportPayload =
  | { kind: 'agent'; input: TelemetryInput }
  | { kind: 'git'; repository: GitRepositoryMetadata; commits: GitCommitMetadata[] }
  | { kind: 'health'; check: HealthCheckDefinition; observations: HealthObservation[] }
  | { kind: 'company'; definition: CompanySignalDefinition; input: CompanySignalInput }
  | { kind: 'artifacts'; source: ArtifactRetainedSource; records: ArtifactRetainedRecord[] };
export interface BackofficeImportManifest {
  schema: 'infuse.backoffice-import/v1';
  id: string;
  sourceRevision: string;
  exportedAt: string;
  policyAt: string;
  scopeDigest: string;
  inputDigest: string;
  pages: {
    kind: BackofficeImportPayload['kind'];
    sourceKey: string;
    digest: string;
    records: number;
  }[];
  exclusions: Record<string, number>;
}
const kinds = ['agent', 'git', 'health', 'company', 'artifacts'] as const;
export function importCanonical(value: unknown): string {
  if (value === null) return 'null';
  if (typeof value === 'string' || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(importCanonical).join(',') + ']';
  if (value && typeof value === 'object')
    return (
      '{' +
      Object.entries(value)
        .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
        .map(([k, v]) => JSON.stringify(k) + ':' + importCanonical(v))
        .join(',') +
      '}'
    );
  throw Error('Invalid import JSON value');
}
export const importDigest = (value: unknown): string =>
  createHash('sha256').update(importCanonical(value)).digest('hex');
function keys(o: Record<string, unknown>, allowed: string[]): void {
  if (Object.keys(o).some((k) => !allowed.includes(k))) throw Error('Unexpected import field');
}
function rows(value: unknown, max: number): unknown[] {
  if (!Array.isArray(value) || value.length > max) throw Error('Import page exceeds row bound');
  return value;
}
export function parseBackofficeImportPayload(value: unknown): BackofficeImportPayload {
  const o = object(value);
  if (Buffer.byteLength(JSON.stringify(value)) > 262144)
    throw Error('Import page exceeds byte bound');
  if (o.kind === 'agent') {
    keys(o, ['kind', 'input']);
    const input = parseTelemetryInput(o.input);
    if (input.kind === 'usage') {
      const data = input.data as {
        start: string;
        minutes: number;
        provider: string;
        model: string;
      }[];
      if (
        new Set(data.map((r) => importCanonical([r.start, r.minutes, r.provider, r.model])))
          .size !== data.length
      )
        throw Error('Duplicate import usage bucket');
    }
    return { kind: 'agent', input };
  }
  if (o.kind === 'git') {
    keys(o, ['kind', 'repository', 'commits']);
    const r = object(o.repository);
    keys(r, [
      'sourceId',
      'organization',
      'projectId',
      'repositoryId',
      'name',
      'projectName',
      'url',
    ]);
    const id = parseGitRepositoryIdentity(r);
    if (r.url !== gitRepositoryUrl(id)) throw Error('Untrusted retained repository link');
    const commits = rows(o.commits, 100).map(parseGitCommit);
    if (
      commits.some(
        (c) => c.provenance !== 'backoffice' || c.authorDate !== null || c.committerDate !== null,
      )
    )
      throw Error('Retained Git dates cannot claim provider observation');
    return {
      kind: 'git',
      repository: {
        ...id,
        name: gitText(r.name),
        projectName: gitText(r.projectName),
        url: gitRepositoryUrl(id),
      },
      commits,
    };
  }
  if (o.kind === 'health') {
    keys(o, ['kind', 'check', 'observations']);
    const c = object(o.check);
    keys(c, [
      'id',
      'resourceId',
      'resourceName',
      'name',
      'kind',
      'enabled',
      'specDigest',
      'intervalMs',
      'staleAfterMs',
      'minSamples',
    ]);
    const view = parseHealthCheckView({
        definition: c,
        status: 'unknown',
        threshold: c.minSamples,
        consecutiveDegraded: 0,
        openIncidents: 0,
        outstandingDeliveries: 0,
      }),
      minSamples = healthCount(c.minSamples, 10);
    if (minSamples < 2) throw Error('Invalid import health threshold');
    const observations = rows(o.observations, 100).map(parseHealthObservation);
    if (observations.some((s) => s.source !== 'backoffice'))
      throw Error('Imported health must retain original provenance');
    return { kind: 'health', check: { ...view.definition, minSamples }, observations };
  }
  if (o.kind === 'company') {
    keys(o, ['kind', 'definition', 'input']);
    return {
      kind: 'company',
      definition: parseCompanySignalDefinition(o.definition),
      input: parseCompanySignalInput(o.input),
    };
  }
  if (o.kind === 'artifacts') {
    keys(o, ['kind', 'source', 'records']);
    if (Buffer.byteLength(JSON.stringify(o.records)) > 65536)
      throw Error('Artifact import page exceeds its byte bound');
    return {
      kind: 'artifacts',
      source: parseArtifactRetainedSource(o.source),
      records: rows(o.records, 100).map(parseArtifactRetainedRecord),
    };
  }
  throw Error('Unsupported import effect');
}
export function importPayloadSource(p: BackofficeImportPayload): string {
  return (
    p.kind +
    ':' +
    (p.kind === 'agent'
      ? p.input.sourceId
      : p.kind === 'git'
        ? p.repository.sourceId
        : p.kind === 'health'
          ? p.check.id
          : p.kind === 'company'
            ? p.definition.sourceId
            : p.source.sourceId)
  );
}
export function importPayloadRecords(p: BackofficeImportPayload): number {
  return p.kind === 'agent'
    ? p.input.kind === 'usage'
      ? (p.input.data as unknown[]).length
      : 1
    : p.kind === 'git'
      ? p.commits.length
      : p.kind === 'health'
        ? p.observations.length
        : p.kind === 'artifacts'
          ? p.records.length
          : 1;
}
export function parseBackofficeImportManifest(value: unknown): BackofficeImportManifest {
  const o = object(value);
  keys(o, [
    'schema',
    'id',
    'sourceRevision',
    'exportedAt',
    'policyAt',
    'scopeDigest',
    'inputDigest',
    'pages',
    'exclusions',
  ]);
  if (
    o.schema !== 'infuse.backoffice-import/v1' ||
    typeof o.sourceRevision !== 'string' ||
    !/^[a-f0-9]{40}$/.test(o.sourceRevision)
  )
    throw Error('Invalid import source revision');
  const pages = rows(o.pages, 1000).map((raw) => {
    const p = object(raw);
    keys(p, ['kind', 'sourceKey', 'digest', 'records']);
    if (
      !kinds.includes(p.kind as BackofficeImportPayload['kind']) ||
      typeof p.sourceKey !== 'string' ||
      !new RegExp('^' + p.kind + ':[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$').test(p.sourceKey)
    )
      throw Error('Invalid import source identity');
    return {
      kind: p.kind as BackofficeImportPayload['kind'],
      sourceKey: p.sourceKey,
      digest: healthDigest(p.digest),
      records: healthCount(p.records, p.kind === 'agent' ? 768 : p.kind === 'company' ? 1 : 100),
    };
  });
  if (new Set(pages.map((p) => p.sourceKey + ':' + p.digest)).size !== pages.length)
    throw Error('Duplicate prepared page');
  const rawExclusions = object(o.exclusions);
  if (Object.keys(rawExclusions).length > 32) throw Error('Import exclusions exceed bound');
  const exclusions: Record<string, number> = {};
  for (const [k, v] of Object.entries(rawExclusions)) {
    if (!/^[a-zA-Z][a-zA-Z0-9_-]{0,79}$/.test(k)) throw Error('Invalid exclusion category');
    exclusions[k] = healthCount(v, 1000000);
  }
  const m: BackofficeImportManifest = {
    schema: o.schema,
    id: missionIdentifier(o.id),
    sourceRevision: o.sourceRevision,
    exportedAt: healthTime(o.exportedAt),
    policyAt: healthTime(o.policyAt),
    scopeDigest: healthDigest(o.scopeDigest),
    inputDigest: healthDigest(o.inputDigest),
    pages,
    exclusions,
  };
  if (Buffer.byteLength(importCanonical(m)) > 131072) throw Error('Import manifest exceeds bound');
  return m;
}
export function importReviewReference(value: unknown): string {
  const s = text(value, 160);
  if (!/^[a-zA-Z0-9][a-zA-Z0-9:._/-]*$/.test(s)) throw Error('Invalid import review reference');
  return s;
}

export function importEntityKeys(p: BackofficeImportPayload): string[] {
  const values =
    p.kind === 'agent' || p.kind === 'company'
      ? ['source-window']
      : p.kind === 'git'
        ? p.commits.map((r) => r.sha)
        : p.kind === 'health'
          ? p.observations.map((r) => r.id)
          : p.records.map((r) => r.kind + ':' + r.recordId);
  const keys = values.map(importDigest);
  if (new Set(keys).size !== keys.length) throw Error('Duplicate import entity');
  return keys;
}

/** Pure preflight uses the frozen policy instant; offline apply repeats against the current clock. */
export function validateBackofficeImportClock(p: BackofficeImportPayload, now: number): void {
  const ceiling = now + 300000,
    check = (s: string | null) => {
      if (s !== null && Date.parse(s) > ceiling) throw Error('Import source clock is ahead');
    };
  if (p.kind === 'agent') {
    check(p.input.generatedAt);
    check(p.input.observedAt);
    if (p.input.kind === 'usage')
      for (const b of p.input.data as { start: string }[]) check(b.start);
  } else if (p.kind === 'company') {
    check(p.input.generatedAt);
    check(p.input.observedAt);
  } else if (p.kind === 'health')
    for (const observation of p.observations) check(observation.finishedAt);
}
