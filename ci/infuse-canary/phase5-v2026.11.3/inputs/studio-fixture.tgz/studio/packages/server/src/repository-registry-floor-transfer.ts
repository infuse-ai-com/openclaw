import { floorRepository, type FloorRecord, type FloorReceipt } from '@studio/contracts';
import type { MissionStore } from './persistence/missions/store.js';
import { contributionsTransferDigest } from './repository-registry-contributions.js';
import type { OperationJob } from './persistence/missions/operations.js';

export interface RegistryFloorTransfer {
  id: string; expectedRevision: number; expectedRepositoriesDigest: string;
  repositories: Array<{id:string;slug:string;shared:boolean}>;
}
/** Offline operator command through the exclusive writer. Exact receipts permit interrupted continuation. */
export async function transferRegistryFloors(store: MissionStore, transfers: RegistryFloorTransfer[], epoch: string, guard:()=>void):Promise<void> {
  if(new Set(transfers.map(t=>t.id)).size!==transfers.length)throw Error('registry_floor_transfer_duplicate');
  const id='repository-registry-floors',digest=contributionsTransferDigest({epoch,transfers});
  let marker=await store.operations<OperationJob|null>({kind:'get',id},guard);
  if(marker && marker.checkpoint.digest!==digest)throw Error('registry_floor_transfer_conflict');
  if(marker?.state==='succeeded')return;
  if(!marker)marker=await store.operations<OperationJob>({kind:'save',expectedRevision:0,job:{id,kind:'repository-registry',source:'floors',revision:1,state:'pending',checkpoint:{epoch,digest},updatedAt:new Date().toISOString()}},guard);
  const actor={kind:'human' as const,id:'registry-rollout-operator'};
  for(const transfer of transfers){
    guard();
    const commandId=`registry-${epoch}-${transfer.id}`;
    const receipt=await store.floors<FloorReceipt|null>({kind:'receipt',commandId,actor},guard);
    if(receipt){if(receipt.status!=='applied')throw Error('registry_floor_transfer_conflict');continue;}
    const records=await store.floors<FloorRecord[]>({kind:'list'},guard);
    const current=records.find(f=>f.id===transfer.id);
    if(!current||current.retiredAt||current.revision!==transfer.expectedRevision||contributionsTransferDigest(current.repositories)!==transfer.expectedRepositoriesDigest)
      throw Error('registry_floor_transfer_conflict');
    const repositories=transfer.repositories.map(r=>floorRepository.parse(r));
    const result=await store.floors<FloorReceipt>({kind:'apply',actor,command:{commandId,expectedRevision:current.revision,intent:'update',floor:{
      id:current.id,name:current.name,description:current.description,memberProfileIds:current.memberProfileIds,repositories,
    }}},guard);
    if(result.status!=='applied')throw Error('registry_floor_transfer_conflict');
  }
  await store.operations({kind:'save',expectedRevision:marker.revision,job:{...marker,revision:marker.revision+1,state:'succeeded',updatedAt:new Date().toISOString()}},guard);
}
