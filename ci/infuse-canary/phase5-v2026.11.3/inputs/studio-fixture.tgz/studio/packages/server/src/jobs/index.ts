import { getSystemHealth } from '../modules/system/service.js';
/** Local startup check only. Durable ingestion and retries require a queue adapter. */
export type SystemJob = { kind: 'system.health' };
export function executeSystemJob(job: SystemJob) {
  switch (job.kind) {
    case 'system.health': return getSystemHealth();
    default: throw new Error('Unsupported job');
  }
}
