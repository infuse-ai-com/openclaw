import { createHash, randomUUID } from 'node:crypto';
import { registryRequestScope, stableRegistryJson } from '@studio/contracts';
import type { FloorDirectoryPort } from './modules/floors/management.js';
import { registryFloorSelection } from './repository-registry-scope.js';
import { MissionError } from './modules/missions/domain.js';

const gets = new Set(['repos','source','commits','commit','diff']);
const posts = new Set(['search','tree','find_definitions','find_references']);
export async function readFloorCode(input: { configPath: string; floorId: string; floors: FloorDirectoryPort;
  method: string; path: string; query: URLSearchParams; body?: unknown; identity: string; guard: () => void; signal?: AbortSignal }) {
  if (!(input.method === 'GET' ? gets : input.method === 'POST' ? posts : new Set()).has(input.path) ||
    input.query.toString().length > 8192 || Buffer.byteLength(JSON.stringify(input.body ?? null)) > 16384)
    throw new MissionError('INVALID_INPUT', 'This floor code operation is unavailable.');
  const scope = await registryFloorSelection(input.configPath, 'code', input.floorId, input.floors, input.guard);
  const issuedAt = Date.now();
  const target = `/api/${input.path}${input.query.size ? `?${input.query.toString()}` : ''}`;
  const envelope = registryRequestScope.parse({ version: 3, audience: 'code',
    actor: createHash('sha256').update(input.identity).digest('hex'), requestId: randomUUID(),
    floor: scope.floor, registry: scope.registry, method: input.method, target,
    bodyDigest: input.body === undefined ? null : createHash('sha256').update(stableRegistryJson(input.body)).digest('hex'),
    issuedAt, expiresAt: issuedAt + 15000, repositories: scope.repositories });
  scope.guard();
  const result = await scope.client.nativeRead(envelope, input.body, input.signal);
  scope.guard();
  return result;
}
