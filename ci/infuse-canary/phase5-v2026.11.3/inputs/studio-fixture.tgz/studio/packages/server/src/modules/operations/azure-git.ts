import { gitObject as obj,gitSha,gitTime,parseGitCommit,type GitCommitMetadata } from '@studio/contracts';
function shortText(value:unknown,max:number,fallback:string):string {if(typeof value!=='string')return fallback;const result=value.replace(/[\u0000-\u001f\u007f]/gu,'').trim().slice(0,max);return result||fallback;}
export function decodeAzureCommit(raw:unknown):GitCommitMetadata {
  const r=obj(raw),author=r.author===undefined?{}:obj(r.author),committer=r.committer===undefined?{}:obj(r.committer);
  const optional=(value:unknown,max:number)=>shortText(value,max,'')||null;
  const rawMessage=typeof r.comment==='string'?r.comment:'',message=rawMessage.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/gu,'').slice(0,1000).replace(/[\ud800-\udbff]$/u,'');
  return parseGitCommit({sha:gitSha(r.commitId),authorName:shortText(author.name,256,'Unknown'),authorEmail:optional(author.email,320),authorDate:gitTime(author.date),committerName:optional(committer.name,256),committerEmail:optional(committer.email,320),committerDate:gitTime(committer.date),message,messageTruncated:r.commentTruncated===true||rawMessage.length>1000,provenance:'azure'});
}
