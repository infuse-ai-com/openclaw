import type { GitBranch, GitCommitMetadata, GitRepositoryMetadata } from '@studio/contracts';

export interface GitSource {
  metadata(signal: AbortSignal): Promise<GitRepositoryMetadata>;
  refs(cursor: string | undefined, signal: AbortSignal): Promise<{ branches: GitBranch[]; nextCursor?: string }>;
  commits(head: string, offset: number, signal: AbortSignal): Promise<{ commits: GitCommitMetadata[]; rawCount: number; nextOffset?: number }>;
}

export class GitSourceError extends Error {
  constructor(readonly code: string, readonly retryAfterMs = 30000) { super(code); }
}
