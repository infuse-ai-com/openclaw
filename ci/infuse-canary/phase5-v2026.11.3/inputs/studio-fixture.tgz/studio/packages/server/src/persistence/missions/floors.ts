import type { StorageDatabase } from './sql.js';
import { floorActor, floorCommand, floorCommandTarget, type FloorActor, type FloorCommand, type FloorRecord, type FloorReceipt } from '@studio/contracts';
import { digest, requireMission } from '../../modules/missions/domain.js';

export type FloorStoreOperation = { kind: 'list' }
  | { kind: 'receipt'; commandId: string; actor: FloorActor }
  | { kind: 'apply'; command: FloorCommand; actor: FloorActor };

/** Only invoked in the mission writer's transaction and live prepare/grant. */
export class FloorPersistence {
  constructor(private db: StorageDatabase, private configured: string[]) {}
  async execute(op: FloorStoreOperation): Promise<unknown> {
    if (op.kind === 'list') return (await this.db.prepare('SELECT body FROM studio_floors ORDER BY rowid').all()).map(row => JSON.parse(String(row.body)) as FloorRecord);
    const actor = floorActor.parse(op.actor);
    // Session provenance is audited, but recovery belongs to the admitted actor.
    const actorKey = JSON.stringify(actor.kind === 'human' ? ['human', actor.id] : ['agent', actor.gatewayId, actor.id]);
    if (op.kind === 'receipt') {
      const row = (await this.db.prepare('SELECT body FROM studio_floor_receipts WHERE actor=? AND command_id=?').get(actorKey, op.commandId));
      return row ? JSON.parse(String(row.body)) : null;
    }
    const command = floorCommand.parse(op.command), fingerprint = digest(command);
    const previous = (await this.db.prepare('SELECT fingerprint, body FROM studio_floor_receipts WHERE actor=? AND command_id=?').get(actorKey, command.commandId));
    if (previous) {
      requireMission(previous.fingerprint === fingerprint, 'IDEMPOTENCY_CONFLICT', 'This command ID belongs to different floor edits');
      return JSON.parse(String(previous.body));
    }
    const row = (await this.db.prepare('SELECT body FROM studio_floors WHERE id=?').get(floorCommandTarget(command)));
    const current = row ? JSON.parse(String(row.body)) as FloorRecord : undefined;
    const revision = current?.revision ?? 0;
    const conflict = revision !== command.expectedRevision || command.intent === 'create' && !!current;
    requireMission(!!current || Number((await this.db.prepare('SELECT count(*) AS total FROM studio_floors').get())!.total) < 100,
      'STATE_CONFLICT', 'This workspace has reached its floor limit');
    const at = new Date().toISOString();
    const receipt: FloorReceipt = { commandId: command.commandId, floorId: floorCommandTarget(command),
      status: conflict ? 'conflict' : 'applied', revision: conflict ? revision : revision + 1, actor, at,
      message: conflict ? 'This floor changed. Read the saved version before submitting new edits.' : 'Saved' };
    if (!conflict) {
      const lifecycle = !('floor' in command);
      requireMission(!lifecycle || !!current, 'NOT_FOUND', 'Save this floor before changing its availability');
      requireMission(lifecycle || !current?.retiredAt, 'STATE_CONFLICT', 'Restore this floor before editing it');
      requireMission(!lifecycle || (command.intent === 'retire' ? !current!.retiredAt : !!current!.retiredAt),
        'STATE_CONFLICT', command.intent === 'retire' ? 'This floor is already retired' : 'This floor is already active');
      const record: FloorRecord = { ...(lifecycle ? current! : command.floor), origin: current?.origin ?? (command.intent === 'create' ? 'created' : 'configured'), revision: receipt.revision, updatedAt: at, updatedBy: actor };
      if (command.intent === 'retire') {
        const records = (await this.db.prepare('SELECT body FROM studio_floors').all()).map(row => JSON.parse(String(row.body)) as FloorRecord);
        const activeIds = new Set([...this.configured, ...records.filter(floor => floor.origin === 'created').map(floor => floor.id)]);
        for (const floor of records) if (floor.retiredAt) activeIds.delete(floor.id);
        requireMission([...activeIds].some(id => id !== record.id), 'STATE_CONFLICT', 'Keep at least one active floor to manage this workspace');
        const active = (await this.db.prepare("SELECT 1 FROM native_missions WHERE project_id=? AND jsonb_extract_path_text(studio_control_json(body),'state') NOT IN ('closed','cancelled') LIMIT 1").get(record.id));
        const unsettled = (await this.db.prepare("SELECT 1 FROM native_actions a JOIN native_missions m ON m.id=a.mission_id WHERE m.project_id=? AND jsonb_extract_path_text(studio_control_json(a.body),'state') IN ('queued','dispatching','uncertain','running') LIMIT 1").get(record.id));
        const delivery = (await this.db.prepare("SELECT 1 FROM native_provisioning p JOIN native_missions m ON m.id=p.mission_id WHERE m.project_id=? AND jsonb_extract_path_text(studio_control_json(p.body),'state') IN ('queued','sending','uncertain') LIMIT 1").get(record.id));
        const reply = (await this.db.prepare("SELECT 1 FROM native_replies r JOIN native_missions m ON m.id=r.mission_id WHERE m.project_id=? AND jsonb_extract_path_text(studio_control_json(r.body),'state') IN ('queued','sending','uncertain') LIMIT 1").get(record.id));
        const legacyOwner = (await this.db.prepare("SELECT value FROM metadata WHERE key='project'").get())?.value === record.id;
        const legacyRuns = legacyOwner && (await this.db.prepare("SELECT 1 FROM bridge_turns WHERE jsonb_extract_path_text(studio_control_json(body),'terminal') IS NULL AND (jsonb_extract_path_text(studio_control_json(body),'runId') IS NOT NULL OR jsonb_extract_path_text(studio_control_json(body),'uncertain') IS NOT NULL OR jsonb_extract_path_text(studio_control_json(body),'admission') IS NOT NULL) LIMIT 1").get());
        const legacy = (await this.db.prepare("SELECT value FROM metadata WHERE key='project'").get())?.value === record.id
          && (await this.db.prepare("SELECT 1 FROM missions WHERE jsonb_extract_path_text(studio_control_json(body),'state') NOT IN ('closed','cancelled') LIMIT 1").get());
        requireMission(!active && !unsettled && !delivery && !reply && !legacy && !legacyRuns, 'STATE_CONFLICT', 'Settle and close or cancel this floor’s missions before retiring it');
        record.retiredAt = at;
      }
      if (command.intent === 'restore') delete record.retiredAt;
      (await this.db.prepare("INSERT INTO studio_floors (id,body) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body").run(record.id, JSON.stringify(record)));
    }
    (await this.db.prepare("INSERT INTO studio_floor_receipts (actor,command_id,fingerprint,body) VALUES (?,?,?,?)").run(actorKey, command.commandId, fingerprint, JSON.stringify(receipt)));
    return receipt;
  }
}
