import {open} from 'node:fs/promises';
import {constants} from 'node:fs';
import {request} from 'node:https';
import {telemetryObject as object} from '@studio/contracts';
import type {OperationsCluster} from './company-config.js';
export async function boundedOperationsFile(path:string,limit:number,signal:AbortSignal):Promise<string>{
  signal.throwIfAborted();const file=await open(path,constants.O_RDONLY|constants.O_NONBLOCK);try{
    const stat=await file.stat();if(!stat.isFile()||stat.size>limit)throw Object.assign(Error('Invalid source file'),{code:'SOURCE_INVALID'});
    const buffer=Buffer.alloc(limit+1);let offset=0;
    while(offset<buffer.length){signal.throwIfAborted();const result=await file.read(buffer,offset,buffer.length-offset,null);if(!result.bytesRead)break;offset+=result.bytesRead;}
    if(offset>limit)throw Object.assign(Error('Source is too large'),{code:'SOURCE_INVALID'});return buffer.subarray(0,offset).toString('utf8');
  }finally{await file.close();}
}
export async function readOperationsKubernetes(config:OperationsCluster,path:string,signal:AbortSignal):Promise<unknown>{
  const [token,ca]=await Promise.all([boundedOperationsFile(config.tokenFile,8192,signal),boundedOperationsFile(config.caFile,65536,signal)]);
  if(!token.trim()||/[\r\n]/.test(token.trim()))throw Error('Invalid Kubernetes token');
  return new Promise((resolve,reject)=>{
    const req=request(new URL(path,config.origin),{method:'GET',ca,signal,headers:{Authorization:`Bearer ${token.trim()}`,Accept:'application/json'}},res=>{
      if(res.statusCode!==200){res.destroy();reject(Error('Kubernetes source unavailable'));return;}
      const chunks:Buffer[]=[];let size=0;
      res.on('data',(chunk:Buffer)=>{size+=chunk.length;if(size>1048576)res.destroy(Object.assign(Error('Kubernetes response exceeds limit'),{code:'SOURCE_LIMIT'}));else chunks.push(chunk);});
      res.on('error',reject);res.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));}catch{reject(Object.assign(Error('Invalid Kubernetes response'),{code:'SOURCE_INVALID'}));}});
    });req.setTimeout(5000,()=>req.destroy(Error('Kubernetes source timed out')));req.on('error',reject);req.end();
  });
}
/** Exact deployment and selected pods only; missing/complex selectors never broaden into a namespace scan. */
export async function readOperationsDeployment(cluster:OperationsCluster,target:{namespace:string;deployment:string},signal:AbortSignal):Promise<{deployment:unknown;pods:unknown}> {
 const deployment=await readOperationsKubernetes(cluster,`/apis/apps/v1/namespaces/${encodeURIComponent(target.namespace)}/deployments/${encodeURIComponent(target.deployment)}`,signal);
 let selector:string;
 try {
  const selection=object(object(object(deployment).spec).selector);
  if(selection.matchExpressions!==undefined&&(!Array.isArray(selection.matchExpressions)||selection.matchExpressions.length))throw Error('Unsupported selector');
  const labels=object(selection.matchLabels),entries=Object.entries(labels);if(!entries.length||entries.length>100)throw Error('Invalid selector bounds');
  selector=entries.map(([key,value])=>{if(typeof value!=='string'||key.length>253||value.length>63||!/^(?:[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\/)?[a-zA-Z0-9](?:[-_.a-zA-Z0-9]*[a-zA-Z0-9])?$/.test(key)||!/^$|^[a-zA-Z0-9](?:[-_.a-zA-Z0-9]*[a-zA-Z0-9])?$/.test(value))throw Error('Invalid selector label');return `${key}=${value}`;}).sort().join(',');
 }catch{throw Object.assign(Error('Invalid bounded deployment selector'),{code:'SOURCE_INVALID'});}
 const pods=await readOperationsKubernetes(cluster,`/api/v1/namespaces/${encodeURIComponent(target.namespace)}/pods?${new URLSearchParams({labelSelector:selector,limit:'200'})}`,signal);
 return {deployment,pods};
}
