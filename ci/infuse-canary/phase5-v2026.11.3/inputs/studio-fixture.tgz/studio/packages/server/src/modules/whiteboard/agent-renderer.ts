import {createHash} from 'node:crypto';
import {WHITEBOARD_AGENT_PROTOCOL,WHITEBOARD_RENDERER_VERSION,whiteboardAgentRenderInput,whiteboardAgentImageMetadata,whiteboardRenderBundle,type WhiteboardRenderBundle,type WhiteboardHtmlReference} from '@studio/contracts';
import type {WhiteboardService,WhiteboardGuard} from './service.js';
import {renderWhiteboard} from './render.js';
import {requireMission} from '../missions/domain.js';
export type WhiteboardRenderPort=(bundle:WhiteboardRenderBundle,signal:AbortSignal)=>Promise<Buffer>;
export type WhiteboardSourcePort=(projectId:string,reference:WhiteboardHtmlReference,kind:'html'|'image',guard:WhiteboardGuard)=>Promise<Buffer>;
const escape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]!));
/** One renderer slot, four waiters, one outstanding render per actor. Cancellation
 * and the eight-second deadline cover queueing, source collection and capture. */
export class WhiteboardAgentRenderer {
 private busy=false;private waiters:Array<()=>void>=[];private actors=new Set<string>();
 constructor(private board:WhiteboardService,private source:WhiteboardSourcePort,private capture:WhiteboardRenderPort){}
 async render(input:unknown,current:WhiteboardGuard) {
  const q=whiteboardAgentRenderInput.parse(input),initial=current(),actor=JSON.stringify(initial.actor);
  requireMission(initial.projectId===q.projectId&&initial.actor.kind==='agent','FORBIDDEN','Current agent access required');
  requireMission(!this.actors.has(actor)&&this.waiters.length<4,'BUSY','Renderer busy');this.actors.add(actor);
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000),signal=controller.signal;
  const guard:WhiteboardGuard=()=>{requireMission(!signal.aborted,'CANCELLED','Capture deadline ended');const p=current();requireMission(p.projectId===initial.projectId&&p.actor.id===initial.actor.id,'FORBIDDEN','Capture identity changed');return p;};
  // Transport current() detects aborted HTTP; relay it into outstanding renderer fetch.
  const pulse=setInterval(()=>{try{guard();}catch{controller.abort();}},25);
  let held=false,queued:(()=>void)|undefined;
  try {
   if(this.busy)await new Promise<void>((resolve,reject)=>{queued=()=>{held=true;resolve();};this.waiters.push(queued);signal.addEventListener('abort',()=>{if(!held){this.waiters=this.waiters.filter(w=>w!==queued);reject(Object.assign(Error('Capture cancelled'),{code:'CANCELLED'}));}},{once:true});});
   else {this.busy=true;held=true;}
   guard();const data=await this.board.agentRender(q,guard);
   const baseline=renderWhiteboard({...data,omittedLinks:data.items.filter(i=>i.kind==='connection').map(i=>i.id)});
   let coverage=baseline.coverage,content=baseline.image,kind:WhiteboardRenderBundle['kind']='svg',crop:WhiteboardRenderBundle['crop'];
   let source:ReturnType<typeof whiteboardAgentImageMetadata.parse>['source'];
   if(q.mode==='html'||q.mode==='image') {
    const tile=data.items[0]!;requireMission(tile.kind==='html'||tile.kind==='image','NOT_FOUND','Tile unavailable');
    const bytes=await this.source(q.projectId,tile.reference,tile.kind,guard);guard();kind=tile.kind;
    requireMission(bytes.length<=(kind==='html'?2*1024*1024:7*1024*1024),'PAYLOAD_TOO_LARGE','Source exceeds capture budget');
    content=kind==='html'?new TextDecoder('utf-8',{fatal:true}).decode(bytes):bytes.toString('base64');
    crop=tile.kind==='image'&&q.mode==='image'&&!q.fullImage?tile.crop??null:null;
    source={reference:tile.reference,...(q.mode==='image'?{crop:crop??null,fullImage:q.fullImage}:{})};
    coverage={complete:true,omitted:[],missingIds:[]};
   } else if(q.mode==='region') {
    let overlays='';
    const included=new Set<string>();
    for(const item of data.items) {
     if(item.kind==='image') {
      const bytes=await this.source(q.projectId,item.reference,'image',guard);guard();
      const c=item.crop??{x:0,y:0,width:1,height:1};
      // Nested SVG clips the normalized source crop; no remote source URLs enter the bundle.
      overlays+=`<svg x="${item.x}" y="${item.y}" width="${item.width}" height="${item.height}" viewBox="${c.x} ${c.y} ${c.width} ${c.height}" preserveAspectRatio="none" overflow="hidden"><image width="1" height="1" preserveAspectRatio="none" href="data:image/webp;base64,${bytes.toString('base64')}"/></svg>`;included.add(item.id);
     }
     if(item.kind==='connection') {
      const a=data.items.find(i=>i.id===item.source),b=data.items.find(i=>i.id===item.target);
      if(!a||!b||a.kind==='connection'||b.kind==='connection')continue;
      const x=a.x+a.width/2,y=a.y+a.height/2,x2=b.x+b.width/2,y2=b.y+b.height/2;
      overlays+=`<g><line x1="${x}" y1="${y}" x2="${x2}" y2="${y2}" stroke="#64748b" stroke-width="2"/><text x="${(x+x2)/2}" y="${(y+y2)/2}" font-size="14">${escape(item.label)}</text></g>`;included.add(item.id);
     }
    }
    content=content.replace('</svg>',overlays+'</svg>');coverage={...coverage,omitted:coverage.omitted.filter(o=>!included.has(o.id))};coverage.complete=!coverage.omitted.length&&!coverage.missingIds.length;
   }
   // Do not enlarge image tiles merely to fill the PNG limit: it adds no detail
   // and inflates the native model payload. Overview/region still benefit from zoom.
   const ratio=Math.min(q.mode==='image'?1:Infinity,1600/data.bounds.width,1000/data.bounds.height),width=Math.max(1,Math.round(data.bounds.width*ratio)),height=Math.max(1,Math.round(data.bounds.height*ratio));
   if(kind==='svg')content=content.replace('width="1600" height="1000"',`width="${width}" height="${height}" preserveAspectRatio="none"`);
   const bundle=whiteboardRenderBundle.parse({version:1,width,height,kind,content,...(kind==='html'?{viewport:{width:Math.round(data.bounds.width),height:Math.round(data.bounds.height)}}:{}),...(kind==='image'?{crop}: {})});
   // Collection and completed capture must refer to the same saved board revision.
   requireMission((await this.board.overview(guard)).revision===q.revision,'RESYNC_REQUIRED','Board changed during collection');
   const png=await this.capture(bundle,signal);guard();
   requireMission(png.length>=33&&png.length<=1024*1024&&png.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))&&png.readUInt32BE(16)===width&&png.readUInt32BE(20)===height,'UNAVAILABLE','Invalid renderer output');
   requireMission((await this.board.overview(guard)).revision===q.revision,'RESYNC_REQUIRED','Board changed during capture');
   for(const item of data.items)if(item.kind==='image'&&q.mode!=='overview'||item.kind==='html'&&q.mode==='html')await this.source(q.projectId,item.reference,item.kind,guard);
   requireMission((await this.board.overview(guard)).revision===q.revision,'RESYNC_REQUIRED','Board changed during source revalidation');
   const metadata=whiteboardAgentImageMetadata.parse({protocol:WHITEBOARD_AGENT_PROTOCOL,projectId:q.projectId,sectionId:q.sectionId,revision:q.revision,mode:q.mode,width,height,
     sha256:createHash('sha256').update(png).digest('hex'),bounds:data.bounds,capturedAt:new Date().toISOString(),rendererVersion:WHITEBOARD_RENDERER_VERSION,source,
     nodes:baseline.nodes.map(n=>({id:n.id,bounds:{x:(n.bounds.x-data.bounds.x)*width/data.bounds.width,y:(n.bounds.y-data.bounds.y)*height/data.bounds.height,width:n.bounds.width*width/data.bounds.width,height:n.bounds.height*height/data.bounds.height}})),coverage});
   requireMission(Buffer.byteLength(JSON.stringify(metadata))<=11000,'PAYLOAD_TOO_LARGE','Narrow capture metadata');guard();return {metadata,png};
  } finally {clearTimeout(timer);clearInterval(pulse);controller.abort();this.actors.delete(actor);if(held){const next=this.waiters.shift();if(next)next();else this.busy=false;}}
 }
}
