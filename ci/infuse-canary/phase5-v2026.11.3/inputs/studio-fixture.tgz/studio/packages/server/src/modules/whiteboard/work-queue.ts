import { requireMission } from '../missions/domain.js';

/** Bound whiteboard work before the mission writer; a released slot passes FIFO. */
export class WhiteboardWorkQueue {
  private active=0;
  private waiters:Array<()=>void>=[];
  async run<T>(action:()=>Promise<T>):Promise<T> {
    if(this.active>=8) {
      requireMission(this.waiters.length<16,'BUSY','Whiteboard requests are busy; try again');
      await new Promise<void>(resolve=>this.waiters.push(resolve));
    }else this.active++;
    try{return await action();}
    finally{const next=this.waiters.shift();if(next)next();else this.active--;}
  }
}
