import * as Y from 'yjs';

export const limits = Object.freeze({ update: 32768, checkpoint: 262144, body: 12000, structs: 16000, clients: 256 });
export class CandidateError extends Error {
  constructor(code) { super(code); this.code = code; }
}
const require = (condition, code) => { if (!condition) throw new CandidateError(code); };
const integer = n => Number.isSafeInteger(n) && n >= 0;
const validId = id => id && integer(id.client) && id.client <= 0xffffffff && integer(id.clock);
const empty = new Uint8Array([0, 0]);

// Qualified decoder: only public Yjs exports and decoded wire records are used.
// No doc.store, pendingStructs or other private runtime structures are inspected.
function inspect(bytes, allowDeleted = false) {
  let decoded, source;
  // decodeUpdateV2 accepts a decoder class. Selecting the exported V1 decoder
  // lets us require complete consumption of the lib0 byte reader as well.
  class CompleteDecoder extends Y.UpdateDecoderV1 {
    constructor(reader) { super(reader); source = reader; }
  }
  try { decoded = Y.decodeUpdateV2(bytes, CompleteDecoder); } catch { throw new CandidateError('INVALID_ENCODING'); }
  require(source.pos === bytes.length, 'INVALID_ENCODING');
  require(decoded.structs.length <= limits.structs && decoded.ds.clients.size <= limits.clients, 'HISTORY_LIMIT');
  const heads = new Map();
  for (const item of decoded.structs) {
    require(item instanceof Y.Item && (item.content instanceof Y.ContentString || (allowDeleted && item.content instanceof Y.ContentDeleted)), 'TEXT_ONLY');
    require(validId(item.id) && integer(item.length) && item.length > 0 && integer(item.id.clock + item.length), 'INVALID_CLOCK');
    require(item.content.getLength() === item.length && item.parentSub === null, 'TEXT_ONLY');
    require(item.parent === 'body' || item.parent === null, 'TEXT_ONLY');
    require(item.parent === 'body' || item.origin !== null || item.rightOrigin !== null, 'INVALID_PARENT');
    for (const reference of [item.origin, item.rightOrigin]) require(reference === null || validId(reference), 'INVALID_CLOCK');
    const previous = heads.get(item.id.client);
    require(previous === undefined || previous === item.id.clock, 'INCOMPLETE_UPDATE');
    heads.set(item.id.client, item.id.clock + item.length);
  }
  require(heads.size <= limits.clients, 'HISTORY_LIMIT');
  let ranges = 0;
  for (const [client, deletes] of decoded.ds.clients) {
    require(integer(client) && client <= 0xffffffff, 'INVALID_CLOCK');
    for (const deletion of deletes) {
      require(++ranges <= limits.structs, 'HISTORY_LIMIT');
      require(integer(deletion.clock) && integer(deletion.len) && deletion.len > 0 && integer(deletion.clock + deletion.len), 'INVALID_CLOCK');
    }
  }
  return { ...decoded, heads };
}

function complete(decoded) {
  const next = new Map();
  for (const item of decoded.structs) {
    require(item.id.clock === (next.get(item.id.client) ?? 0), 'INCOMPLETE_UPDATE');
    next.set(item.id.client, item.id.clock + item.length);
    for (const reference of [item.origin, item.rightOrigin]) {
      if (reference) require(reference.clock < (decoded.heads.get(reference.client) ?? 0), 'INCOMPLETE_UPDATE');
    }
  }
  for (const [client, deletes] of decoded.ds.clients) {
    for (const deletion of deletes) require(deletion.clock + deletion.len <= (next.get(client) ?? 0), 'INCOMPLETE_UPDATE');
  }
}

export function seed(text) {
  require(typeof text === 'string' && text.length <= limits.body, 'BODY_LIMIT');
  require(text.isWellFormed(), 'INVALID_INPUT');
  const doc = new Y.Doc({ gc: false }); doc.clientID = 1;
  try { doc.getText('body').insert(0, text); return Y.encodeStateAsUpdate(doc); }
  finally { doc.destroy(); }
}

function candidate(checkpoint, update, { gc = false } = {}, previous = null) {
  require(checkpoint instanceof Uint8Array && checkpoint.length <= limits.checkpoint, 'HISTORY_LIMIT');
  require(update instanceof Uint8Array && update.length <= limits.update, 'UPDATE_LIMIT');
  const baseline = inspect(checkpoint, gc); complete(baseline);
  const incoming = inspect(update);
  const expected = new Map(baseline.heads);
  // Exact duplicate requests belong to receipt recovery. Reusing an accepted
  // client clock under another command cannot smuggle contradictory content.
  for (const item of incoming.structs) {
    require(item.id.clock === (expected.get(item.id.client) ?? 0), item.id.clock < (expected.get(item.id.client) ?? 0) ? 'CLOCK_REUSED' : 'INCOMPLETE_UPDATE');
    expected.set(item.id.client, item.id.clock + item.length);
  }
  const combined = Y.mergeUpdates([checkpoint, update]);
  require(combined.length <= limits.checkpoint, 'HISTORY_LIMIT');
  const all = inspect(combined, gc); complete(all);
  // The decoder above bounds structure before integration. The CPU worker also
  // bounds integration time/memory, including adversarial dependency cycles.
  const doc = previous ?? new Y.Doc({ gc });
  try {
    const body = doc.getText('body');
    Y.applyUpdate(doc, previous ? update : combined);
    const vector = Y.decodeStateVector(Y.encodeStateVector(doc));
    require(vector.size === all.heads.size && [...all.heads].every(([client, clock]) => vector.get(client) === clock), 'INCOMPLETE_UPDATE');
    const text = body.toString();
    require(text.length <= limits.body, 'BODY_LIMIT');
    const state = Y.encodeStateAsUpdate(doc);
    require(state.length <= limits.checkpoint, 'HISTORY_LIMIT');
    return { doc, result: { state, text, structs: all.structs.length, clients: all.heads.size, updateClients: [...incoming.heads.keys()] } };
  } catch (error) {
    doc.destroy();
    if (error instanceof CandidateError) throw error;
    throw new CandidateError('INVALID_ENCODING');
  }
}

export function prepare(checkpoint, update, options) {
  const { doc, result } = candidate(checkpoint, update, options);
  doc.destroy(); return result;
}

/** A single speculative candidate, never an authority or an accepted-head cache.
 * Reuse requires exact byte equality with the checkpoint supplied by the service.
 * A denied/stale candidate cannot leak into a later preparation from another head.
 */
export function createPreparer(options) {
  let retained = null;
  const discard = () => { retained?.doc.destroy(); retained = null; };
  return {
    prepare(checkpoint, update) {
      const previous = retained; retained = null;
      const matches = previous && checkpoint instanceof Uint8Array && checkpoint.length === previous.state.length && checkpoint.every((byte, index) => byte === previous.state[index]);
      if (previous && !matches) previous.doc.destroy();
      try {
        const next = candidate(checkpoint, update, options, matches ? previous.doc : null);
        // Never share the retained key with a caller who could mutate its bytes.
        retained = { doc: next.doc, state: next.result.state.slice() };
        return next.result;
      } catch (error) { if (matches) previous.doc.destroy(); throw error; }
    },
    close: discard,
  };
}

export function validateCheckpoint(state, options) { return prepare(state, empty, options); }
