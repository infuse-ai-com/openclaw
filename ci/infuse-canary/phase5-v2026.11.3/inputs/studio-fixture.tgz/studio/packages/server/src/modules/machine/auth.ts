import { createHash, createPublicKey, verify } from 'node:crypto';
import { z } from 'zod';
import { MachineError } from './errors.js';

const text = z.string().min(1).max(512).regex(/^[^\u0000-\u001f\u007f]+$/);
const id = z.string().min(1).max(128).regex(/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/);
const scopes = z.array(z.literal('studio:read')).max(1);
const signer = z.strictObject({ issuer: text, keyId: id, enabled: z.boolean(), publicKey: z.string().min(1).max(4096), clientIds: z.array(text).min(1).max(100), scopes });
const binding = z.strictObject({ issuer: text, subject: text, profileId: id, projectId: id, enabled: z.boolean(), clientIds: z.array(text).min(1).max(100), scopes });
const enabled = z.strictObject({ enabled: z.literal(true), signers: z.array(signer).min(1).max(20), bindings: z.array(binding).min(1).max(2000), cursorKeyEnv: z.string().regex(/^[A-Z][A-Z0-9_]*$/) });
const configuration = z.discriminatedUnion('enabled', [z.strictObject({ enabled: z.literal(false) }), enabled]);
export type MachineConfig = z.infer<typeof configuration>;
export function parseMachineConfig(value: unknown): MachineConfig {
  const config = configuration.parse(value);
  if (!config.enabled) return config;
  for (const s of config.signers) publicKey(s.publicKey);
  if (new Set(config.signers.map(s => JSON.stringify([s.issuer, s.keyId]))).size !== config.signers.length
    || new Set(config.bindings.map(b => JSON.stringify([b.issuer, b.subject, b.projectId]))).size !== config.bindings.length) throw Error('Duplicate machine admission');
  return config;
}
function publicKey(pem: string) {
  if (!pem.startsWith('-----BEGIN PUBLIC KEY-----')) throw Error('Expected a public verification key');
  const key = createPublicKey(pem);
  if (key.asymmetricKeyType !== 'ec' || key.asymmetricKeyDetails?.namedCurve !== 'prime256v1') throw Error('Expected an ES256 verification key');
  return key;
}
export function machineCursorKey(config: MachineConfig | undefined): Buffer {
  if (!config?.enabled) throw new MachineError('FORBIDDEN');
  const value = process.env[config.cursorKeyEnv];
  if (!value || !/^[a-f0-9]{64}$/.test(value)) throw new MachineError('UNAVAILABLE');
  return Buffer.from(value, 'hex');
}
const claimsSchema = z.strictObject({
  iss: text, aud: z.literal('urn:infuse:studio:machine-api:v1'), iat: z.number().int(), nbf: z.number().int(), exp: z.number().int(), jti: id,
  actor: z.strictObject({ kind: z.literal('human'), issuer: text, subject: text }), clientId: text, projectId: id, scopes,
  request: z.strictObject({ method: z.literal('POST'), path: z.string().max(128), bodySha256: z.string().regex(/^[a-f0-9]{64}$/) }),
});
export interface MachineIdentity { profileId: string; cursorBinding: string; serviceIssuer: string; clientId: string }
/** The caller's untrusted body never supplies a profile, key URL, client identity or capability. */
export function machineIdentity(authorization: unknown, path: string, body: Buffer, projectId: string, config: MachineConfig | undefined): MachineIdentity {
  if (!config?.enabled) throw new MachineError('FORBIDDEN');
  try {
    if (typeof authorization !== 'string' || !authorization.startsWith('Bearer ') || authorization.length > 8192) throw Error();
    const token = authorization.slice(7), parts = token.split('.');
    if (parts.length !== 3 || parts.some(p => !/^[A-Za-z0-9_-]+$/.test(p) || Buffer.from(p, 'base64url').toString('base64url') !== p)) throw Error();
    const [headerPart, payloadPart, signaturePart] = parts as [string, string, string];
    const header = z.strictObject({ alg: z.literal('ES256'), typ: z.literal('infuse-studio-delegation+jwt'), kid: id }).parse(JSON.parse(Buffer.from(headerPart, 'base64url').toString('utf8')));
    const claims = claimsSchema.parse(JSON.parse(Buffer.from(payloadPart, 'base64url').toString('utf8')));
    const registered = config.signers.find(s => s.enabled && s.issuer === claims.iss && s.keyId === header.kid);
    const signature = Buffer.from(signaturePart, 'base64url');
    if (!registered || signature.length !== 64 || !verify('sha256', Buffer.from(`${headerPart}.${payloadPart}`), { key: publicKey(registered.publicKey), dsaEncoding: 'ieee-p1363' }, signature)) throw Error();
    const now = Date.now() / 1000;
    if (claims.nbf !== claims.iat || claims.exp <= claims.iat || claims.exp - claims.iat > 30 || claims.iat > now + 5 || claims.exp <= now - 5
      || claims.request.method !== 'POST' || claims.request.path !== path || claims.request.bodySha256 !== createHash('sha256').update(body).digest('hex')) throw Error();
    const mapped = config.bindings.find(b => b.enabled && b.issuer === claims.actor.issuer && b.subject === claims.actor.subject && b.projectId === projectId);
    if (claims.projectId !== projectId || !registered.clientIds.includes(claims.clientId) || !registered.scopes.includes('studio:read') || !claims.scopes.includes('studio:read')
      || !mapped?.clientIds.includes(claims.clientId) || !mapped.scopes.includes('studio:read')) throw new MachineError('FORBIDDEN');
    return { profileId: mapped.profileId, serviceIssuer: registered.issuer, clientId: claims.clientId, cursorBinding: createHash('sha256').update(JSON.stringify([registered, mapped, claims.clientId])).digest('hex') };
  } catch (error) {
    if (error instanceof MachineError) throw error;
    throw new MachineError('UNAUTHENTICATED');
  }
}
