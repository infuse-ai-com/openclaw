import { whiteboardAgentPresenceInput, type WhiteboardAgentPresence } from '@studio/contracts';
import { requireMission } from '../missions/domain.js';
import type { WhiteboardGuard, WhiteboardService } from './service.js';

type Lease = { value: WhiteboardAgentPresence; until: number; revalidate: WhiteboardGuard };
/** One bounded ephemeral owner for native observations. No timers renew an agent's lease. */
export class WhiteboardAgentPresenceService {
  private leases = new Map<string, Lease>();
  constructor(private board: WhiteboardService, private now = Date.now) {}
  private prune() { for (const [key, row] of this.leases) if (row.until <= this.now()) this.leases.delete(key); }
  async publish(input: unknown, guard: WhiteboardGuard, revalidate: WhiteboardGuard) {
    const parsed = whiteboardAgentPresenceInput.safeParse(input);
    requireMission(parsed.success, 'INVALID_INPUT', 'Invalid agent location');
    const state = parsed.data, principal = guard(), custody = principal.nativeCustody;
    requireMission(principal.actor.kind === 'agent' && principal.projectId === state.projectId &&
      custody?.invocation.toolName === 'studio_whiteboard_presence', 'FORBIDDEN', 'Native location custody required');
    await this.board.agentRead({kind:'location',sectionId:state.sectionId,ids:state.selectedIds},guard);
    guard();
    const retained = revalidate();
    requireMission(retained.actor.id === principal.actor.id && retained.projectId === principal.projectId &&
      JSON.stringify(retained.nativeCustody) === JSON.stringify(custody), 'FORBIDDEN', 'Location identity changed');
    this.prune();
    const key = JSON.stringify([principal.projectId,principal.actor.id,custody.invocation.sessionId]);
    requireMission(this.leases.has(key) || this.leases.size < 32, 'BUSY', 'Agent presence capacity reached');
    const observed = this.now(), until = observed + 30000;
    this.leases.set(key,{until,revalidate,value:{...state,actorId:principal.actor.id,gatewayId:custody.gatewayId,
      agentId:custody.invocation.agentId,sessionId:custody.invocation.sessionId,
      observedAt:new Date(observed).toISOString(),expiresAt:new Date(until).toISOString()}});
    return {expiresAt:new Date(until).toISOString()};
  }
  async list(guard: WhiteboardGuard): Promise<WhiteboardAgentPresence[]> {
    const project = guard().projectId;
    this.prune();
    const result:WhiteboardAgentPresence[]=[];
    for (const [key,row] of this.leases) {
      if (row.value.projectId !== project) continue;
      try {
        // Recheck current enrollment/floor/policy and retained managed custody in the writer.
        await this.board.agentRead({kind:'location',sectionId:row.value.sectionId,ids:row.value.selectedIds},row.revalidate);
        row.revalidate();
        if(row.until > this.now() && this.leases.get(key) === row) result.push(structuredClone(row.value));
      } catch { if(this.leases.get(key) === row)this.leases.delete(key); }
    }
    requireMission(guard().projectId === project,'FORBIDDEN','Project changed');
    return result;
  }
}
