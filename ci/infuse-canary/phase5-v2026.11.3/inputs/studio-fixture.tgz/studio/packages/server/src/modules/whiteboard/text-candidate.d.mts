export const limits: { update: number; checkpoint: number; body: number; structs: number; clients: number };
export class CandidateError extends Error { code: string; constructor(code: string) }
export interface Candidate { state: Uint8Array; text: string; structs: number; clients: number; updateClients: number[] }
export function seed(text: string): Uint8Array;
export function prepare(checkpoint: Uint8Array, update: Uint8Array, options?: { gc?: boolean }): Candidate;
export function createPreparer(options?: { gc?: boolean }): { prepare(checkpoint: Uint8Array, update: Uint8Array): Candidate; close(): void };
