import type { WhiteboardAgentCustody, WhiteboardNativeCommand } from '../../modules/whiteboard/agent-custody.js';
import { activeFloorProject } from './floor-project.js';
import type { StorageDatabase } from './sql.js';
import { whiteboardItem,whiteboardLocatedItem,whiteboardId, type WhiteboardActor, type WhiteboardReceipt, type WhiteboardTextHead,
  type WhiteboardEvent, type WhiteboardV2Snapshot } from '@studio/contracts';
import { boardRevision,spatial } from './whiteboard-spatial.js';
import { requireMission } from '../../modules/missions/domain.js';
import type { WhiteboardPersistence } from './whiteboard.js';
import { collaborative, installText, recordBoardEvent, textHash, textQuota, type PreparedTextSeed } from './whiteboard-text-records.js';
import { applyComment, type PreparedComment, type StoredComments } from './whiteboard-comments.js';

type Identity = { projectId: string; actor: WhiteboardActor; nativeCustody?: WhiteboardAgentCustody; nativeCommand?: WhiteboardNativeCommand };
export type TextRequest =
  | { kind: 'snapshot' }
  | { kind: 'read'; ids: string[] }
  | { kind: 'head'; blockId: string }
  | { kind:'location';blockId:string }
  | { kind: 'events'; after: number; limit: number }
  | { kind: 'receipt'; commandId: string; fingerprint?: string }
  | { kind:'comments';blockId:string }
  | ({ kind:'comment';commandId:string;fingerprint:string } & PreparedComment)
  | { kind: 'lease'; blockId: string; epoch: string; clientKey: string }
  | { kind: 'convert'; commandId: string; fingerprint: string; expectedRevision: number; seeds: PreparedTextSeed[] }
  | { kind: 'submit'; commandId: string; fingerprint: string; blockId: string; epoch: string;
      sourceRevision: number; sourceHash: string; expectedContentHash?: string; state: Uint8Array; text: string; update: string };
export type TextStoreOperation = TextRequest & Identity;

/** No CRDT decoding here: only bounded prepared values and head fencing in the sole writer. */
export class WhiteboardTextPersistence {
  constructor(private db: StorageDatabase, private projects: string[], private board: WhiteboardPersistence) {}
  private async receipt(op: Identity & { commandId: string; fingerprint?: string }): Promise<WhiteboardReceipt | null> {
    const previous = (await this.db.prepare('SELECT fingerprint,body FROM whiteboard_receipts WHERE project_id=? AND actor=? AND command_id=?')
      .get(op.projectId, JSON.stringify([op.actor.kind, op.actor.id]), op.commandId));
    if (!previous) return null;
    requireMission(op.fingerprint === undefined || previous.fingerprint === op.fingerprint, 'IDEMPOTENCY_CONFLICT', 'This command ID belongs to different edits');
    return JSON.parse(String(previous.body));
  }
  private async head(project: string, blockId: string): Promise<WhiteboardTextHead> {
    const row = (await this.db.prepare('SELECT h.* FROM whiteboard_text_heads h JOIN whiteboard_items i ON i.project_id=h.project_id AND i.id=h.block_id WHERE h.project_id=? AND h.block_id=? AND i.body IS NOT NULL').get(project, blockId));
    requireMission(row, 'NOT_FOUND', 'This collaborative block no longer exists');
    return { blockId, epoch: String(row.epoch), textRevision: Number(row.text_revision),
      cursor: (await boardRevision(this.db,project)), hash: String(row.hash), checkpoint: Buffer.from(row.checkpoint as Uint8Array).toString('base64') };
  }
  async execute(op: TextStoreOperation): Promise<unknown> {
    whiteboardId.parse(op.projectId);
    requireMission((await activeFloorProject(this.db, this.projects, op.projectId)), 'FORBIDDEN', 'Whiteboard project is unavailable');
    if (op.kind === 'receipt') return (await this.receipt(op));
    const revision=(await boardRevision(this.db,op.projectId));
    const converted = (await collaborative(this.db, op.projectId));
    if(op.kind==='location') {
      const row=(await this.db.prepare("SELECT jsonb_extract_path_text(studio_control_json(body),'kind') kind,COALESCE(studio_control_json(body)->>'sectionId','root') \"sectionId\" FROM whiteboard_items WHERE project_id=? AND id=? AND body IS NOT NULL").get(op.projectId,op.blockId));
      requireMission(row,'NOT_FOUND','This block is unavailable');return {kind:String(row.kind),sectionId:String(row.sectionId)};
    }
    if (op.kind === 'snapshot' || op.kind === 'read') {
      const value=(await this.read(op.projectId,op.kind==='read'?op.ids:undefined));
      if(op.kind==='snapshot')return value;
      return {...value,coverage:{complete:true,requestedIds:op.ids,missingIds:op.ids.filter(id=>!value.items.some(item=>item.id===id))}};
    }
    if (op.kind === 'convert' || op.kind === 'submit' || op.kind === 'comment') {
      const receipt = (await this.receipt(op)); if (receipt) return receipt;
    }
    if (op.kind === 'convert') {
      const snapshot=(await this.board.snapshot(op.projectId));
      requireMission(!converted, 'STATE_CONFLICT', 'This board is already collaborative');
      requireMission(snapshot.revision === op.expectedRevision, 'VERSION_CONFLICT', 'The board changed before conversion');
      const blocks = snapshot.items.filter(item => 'text' in item);
      requireMission(blocks.length === op.seeds.length && new Set(op.seeds.map(seed => seed.blockId)).size === blocks.length,
        'INVALID_INPUT', 'Conversion requires every live body exactly once');
      for (const block of blocks) {
        const seed = op.seeds.find(seed => seed.blockId === block.id);
        requireMission(seed && seed.text === block.text, 'VERSION_CONFLICT', 'A conversion seed changed');
        (await installText(this.db, op.projectId, seed));
      }
      (await textQuota(this.db, op.projectId));
      (await this.db.prepare("INSERT INTO whiteboard_v2_boards (project_id) VALUES (?)").run(op.projectId));
      return (await this.commit(op, snapshot.revision + 1, [], 'Collaborative editing enabled'));
    }
    requireMission(converted, 'CONVERSION_REQUIRED', 'Convert this board before collaborative editing');
    if (op.kind==='comments') {
      const threads=(await this.db.prepare('SELECT body FROM whiteboard_comment_threads WHERE project_id=? AND block_id=? ORDER BY id').all(op.projectId,op.blockId)).map(row=>JSON.parse(String(row.body)));
      const live=(await this.db.prepare('SELECT 1 FROM whiteboard_text_heads WHERE project_id=? AND block_id=?').get(op.projectId,op.blockId));
      return { blockId:op.blockId,cursor:revision,threads,...(live ? { head:(await this.head(op.projectId,op.blockId)) } : {}) } satisfies StoredComments;
    }
    if (op.kind==='comment') {
      const blockId=(await applyComment(this.db,op.projectId,op.actor,op,revision+1));
      return (await this.commit(op,revision+1,[blockId],op.command.type==='create'?'Comment added':op.command.type==='reply'?'Reply added':op.command.resolved?'Comment resolved':'Comment reopened'));
    }
    if (op.kind === 'head') return (await this.head(op.projectId, op.blockId));
    if (op.kind === 'events') {
      requireMission(op.after <= revision, 'INVALID_INPUT', 'Cursor is ahead of this board');
      const earliest = Number((await this.db.prepare('SELECT MIN(revision) n FROM whiteboard_v2_events WHERE project_id=?').get(op.projectId))?.n ?? revision + 1);
      requireMission(op.after >= earliest - 1, 'CURSOR_EXPIRED', 'Read a fresh board snapshot before subscribing');
      const events = (await this.db.prepare('SELECT body FROM whiteboard_v2_events WHERE project_id=? AND revision>? ORDER BY revision LIMIT ?')
        .all(op.projectId, op.after, op.limit)).map(row => JSON.parse(String(row.body)) as WhiteboardEvent);
      return { cursor: events.at(-1)?.receipt.revision ?? op.after, headRevision: revision, events };
    }
    const head = (await this.head(op.projectId, op.blockId));
    requireMission(head.epoch === op.epoch, 'EPOCH_CHANGED', 'Reload this collaborative document');
    if (op.kind === 'lease') {
      const actor = JSON.stringify([op.actor.kind, op.actor.id]);
      const previous = (await this.db.prepare('SELECT client_id FROM whiteboard_text_clients WHERE project_id=? AND block_id=? AND actor=? AND client_key=?')
        .get(op.projectId, op.blockId, actor, op.clientKey));
      if (previous) return { clientId: Number(previous.client_id) };
      const clientId = Number((await this.db.prepare('SELECT COALESCE(MAX(client_id),1)+1 n FROM whiteboard_text_clients WHERE project_id=? AND block_id=?').get(op.projectId,op.blockId))?.n);
      requireMission(clientId <= 256, 'HISTORY_LIMIT', 'This document has reached its editor identity limit');
      (await this.db.prepare("INSERT INTO whiteboard_text_clients (project_id,block_id,actor,client_key,client_id) VALUES (?,?,?,?,?)").run(op.projectId,op.blockId,actor,op.clientKey,clientId));
      return { clientId };
    }
    requireMission(head.textRevision === op.sourceRevision && head.hash === op.sourceHash, 'HEAD_CHANGED', 'Text changed during preparation');
    requireMission(op.state.length <= 262144 && op.text.length <= 12000, 'HISTORY_LIMIT', 'Text history limit reached');
    const row=(await this.db.prepare('SELECT body FROM whiteboard_items WHERE project_id=? AND id=? AND body IS NOT NULL').get(op.projectId,op.blockId));
    const item=row?whiteboardLocatedItem.parse(JSON.parse(String(row.body))):undefined;
    requireMission(item && (item.kind === 'note' || item.kind === 'document'), 'NOT_FOUND', 'This block was deleted');
    requireMission(op.expectedContentHash === undefined || textHash(Buffer.from(item.text, 'utf8')) === op.expectedContentHash,
      'VERSION_CONFLICT', 'Read the complete current body before patching');
    const nextRevision = revision + 1;
    const projected = { ...item, text: op.text, revision:nextRevision };
    requireMission(Number((await this.db.prepare("SELECT COALESCE(sum(octet_length(body)),0) n FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND id!=?").get(op.projectId,op.blockId))?.n)+Buffer.byteLength(JSON.stringify(projected)) <= ((await spatial(this.db,op.projectId))?16777216:1048576),
      'HISTORY_LIMIT', 'This board has reached its size limit');
    (await this.db.prepare('UPDATE whiteboard_items SET body=? WHERE project_id=? AND id=?').run(JSON.stringify(projected), op.projectId,op.blockId));
    (await this.db.prepare('UPDATE whiteboard_text_heads SET checkpoint=?,hash=?,text_revision=? WHERE project_id=? AND block_id=?')
      .run(op.state,textHash(op.state),head.textRevision + 1,op.projectId,op.blockId));
    (await textQuota(this.db, op.projectId));
    return (await this.commit(op, nextRevision, [op.blockId], 'Saved', { blockId: op.blockId, epoch: op.epoch, textRevision: head.textRevision + 1, update: op.update }));
  }
  private async read(projectId:string,ids?:string[]):Promise<WhiteboardV2Snapshot> {
    const rows=ids?(await this.db.prepare(`SELECT body FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL AND id IN (${ids.map(()=>'?').join(',')})`).all(projectId,...ids)):undefined;
    const snapshot=rows?{projectId,sectionId:'root' as const,revision:(await boardRevision(this.db,projectId)),items:rows.map(row=> {
      const {sectionId:_,...item}=whiteboardLocatedItem.parse(JSON.parse(String(row.body)));
      requireMission(item.kind!=='section'&&item.kind!=='html'&&item.kind!=='image','UPGRADE_REQUIRED','Use the spatial detail API for this tile');return whiteboardItem.parse(item);
    })}:(await this.board.snapshot(projectId));
    const selected=ids?`AND id IN (${ids.map(()=>'?').join(',')})`:'';
    const bodies=ids?`AND block_id IN (${ids.map(()=>'?').join(',')})`:'';
    return {...snapshot,version:2,mode:(await collaborative(this.db,projectId))?'collaborative':'legacy',
      structureRevisions:Object.fromEntries((await this.db.prepare(`SELECT id,structure_revision FROM whiteboard_items WHERE project_id=? AND body IS NOT NULL ${selected}`).all(projectId,...(ids??[]))).map(row=>[String(row.id),Number(row.structure_revision)])),
      texts:(await this.db.prepare(`SELECT block_id,epoch,text_revision FROM whiteboard_text_heads WHERE project_id=? ${bodies}`).all(projectId,...(ids??[]))).map(row=>({blockId:String(row.block_id),epoch:String(row.epoch),textRevision:Number(row.text_revision)})),
    };
  }
  private async commit(op: Identity & { commandId: string; fingerprint: string }, revision: number, changedIds: string[], message: string, text?: WhiteboardEvent['text']): Promise<WhiteboardReceipt> {
    const receipt: WhiteboardReceipt = { projectId: op.projectId, commandId: op.commandId, actor: op.actor,
      status: 'applied', revision, changedIds, message, at: new Date().toISOString() };
    (await this.db.prepare("INSERT INTO whiteboard_boards (project_id,revision) VALUES (?,?) ON CONFLICT(project_id) DO UPDATE SET revision=excluded.revision").run(op.projectId, revision));
    (await this.db.prepare("INSERT INTO whiteboard_receipts (project_id,actor,command_id,fingerprint,body) VALUES (?,?,?,?,?)").run(op.projectId,JSON.stringify([op.actor.kind,op.actor.id]),op.commandId,op.fingerprint,JSON.stringify(receipt)));
    (await this.db.prepare("INSERT INTO whiteboard_changes (project_id,revision,body) VALUES (?,?,?)").run(op.projectId,revision,JSON.stringify(receipt)));
    (await recordBoardEvent(this.db, op.projectId, { receipt, ...(text ? { text } : {}) }));
    return receipt;
  }
}
