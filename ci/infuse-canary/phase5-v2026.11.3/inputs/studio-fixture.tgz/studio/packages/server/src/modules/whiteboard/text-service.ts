import { randomUUID } from 'node:crypto';
import { whiteboardAgentTextPatch, whiteboardRevert,whiteboardSpatialCommand,whiteboardActor, whiteboardId, whiteboardConvert, whiteboardStructureCommand, whiteboardTextJoin,
  whiteboardTextPatch, whiteboardTextUpdate, whiteboardChangesQuery, whiteboardReadQuery,
  whiteboardCommentCommand, whiteboardPresenceState, type WhiteboardPresenceState, type WhiteboardCommentPage,
  type WhiteboardReceipt, type WhiteboardTextHead, type WhiteboardV2Snapshot, type WhiteboardEventPage, type WhiteboardTextRead } from '@studio/contracts';
import type { MissionStore } from '../../persistence/missions/store.js';
import type { TextRequest } from '../../persistence/missions/whiteboard-text.js';
import type { PreparedTextSeed } from '../../persistence/missions/whiteboard-text-records.js';
import { digest, MissionError, requireMission } from '../missions/domain.js';
import type { WhiteboardGuard } from './service.js';
import { seed } from './text-candidate.mjs';
import { WhiteboardWorkQueue } from './work-queue.js';
import { TextValidator } from './text-validator.js';
import type { StoredComments } from '../../persistence/missions/whiteboard-comments.js';

function parse<T>(parser: (input: unknown) => T, input: unknown): T {
  try { return parser(input); } catch { throw new MissionError('INVALID_INPUT', 'Invalid collaborative whiteboard request'); }
}
const fingerprint = (kind: string, command: unknown) => digest({ version: 2, kind, command });
const seeded = (block: { id: string; text: string }): PreparedTextSeed => ({ blockId: block.id, text: block.text, epoch: randomUUID(), state: seed(block.text) });

export class CollaborativeWhiteboardService {
  private validator = new TextValidator();
  private queue=new WhiteboardWorkQueue();
  private mutations = 0;
  private textTails = new Map<string,Promise<void>>();
  constructor(private store: MissionStore, private enabled: () => boolean = () => false) {}
  private admission(current: WhiteboardGuard, write = false): WhiteboardGuard {
    requireMission(typeof current === 'function', 'FORBIDDEN', 'Live whiteboard admission is required');
    const initial = current(); const projectId = parse(whiteboardId.parse, initial.projectId); const actor = parse(whiteboardActor.parse, initial.actor);
    return () => {
      const live = current();
      requireMission(live.projectId === projectId && live.actor.kind === actor.kind && live.actor.id === actor.id && (!write || live.canWrite), 'FORBIDDEN', 'Whiteboard access changed');
      requireMission(JSON.stringify(live.nativeCommand) === JSON.stringify(initial.nativeCommand), 'FORBIDDEN', 'Whiteboard command changed');
      requireMission(JSON.stringify(live.nativeCustody) === JSON.stringify(initial.nativeCustody), 'FORBIDDEN', 'Whiteboard invocation changed');
      if (write) requireMission(this.enabled(), 'COLLABORATION_DISABLED', 'Collaborative editing is not enabled');
      return { ...live, projectId, actor };
    };
  }
  private async request<T>(operation: TextRequest, guard: WhiteboardGuard): Promise<T> {
    return this.withStore(guard,identity=>this.store.whiteboardText<T>({ ...operation, projectId: identity.projectId, actor: identity.actor, nativeCustody: identity.nativeCustody, nativeCommand: identity.nativeCommand }, () => { guard(); }));
  }
  /** Absorb a bounded five-partner read burst before the writer, without
   * increasing its eight-request allowance. A reserved slot passes FIFO. */
  private async withStore<T>(guard:WhiteboardGuard,action:(identity:ReturnType<WhiteboardGuard>)=>Promise<T>):Promise<T> {
    return this.queue.run(async()=>{const value=await action(guard());guard();return value;});
  }
  private async mutate<T>(action: () => Promise<T>): Promise<T> {
    requireMission(this.mutations < 8, 'BUSY', 'Whiteboard editing is busy; try again'); this.mutations++;
    try { return await action(); } finally { this.mutations--; }
  }
  /** Serialize preparation per body, inside the existing eight-mutation bound.
   * Otherwise five simultaneous edits exhaust three head-race retries despite
   * being valid. Waiting work holds no writer slot and rechecks live admission. */
  private textMutation<T>(blockId:string,current:WhiteboardGuard,action:()=>Promise<T>):Promise<T> {
    const admitted=this.admission(current);
    const key=JSON.stringify([admitted().projectId,blockId]);
    return this.mutate(async()=> {
      const previous=this.textTails.get(key);
      let release!:()=>void;
      const tail=new Promise<void>(resolve=>{release=resolve}); this.textTails.set(key,tail);
      try { await previous; admitted(); return await action(); }
      finally { release(); if(this.textTails.get(key)===tail)this.textTails.delete(key); }
    });
  }
  snapshot(guard: WhiteboardGuard) { return this.request<WhiteboardV2Snapshot>({ kind: 'snapshot' }, this.admission(guard)); }
  read(input: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardTextRead>({ kind:'read',...parse(whiteboardReadQuery.parse,input) },this.admission(guard)); }
  head(blockId: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardTextHead>({ kind: 'head', blockId: parse(whiteboardId.parse, blockId) }, this.admission(guard)); }
  receipt(commandId: unknown, guard: WhiteboardGuard) { return this.request<WhiteboardReceipt | null>({ kind: 'receipt', commandId: parse(whiteboardId.parse, commandId) }, this.admission(guard)); }
  events(input: unknown, guard: WhiteboardGuard) {
    const query = parse(whiteboardChangesQuery.parse, input);
    return this.request<WhiteboardEventPage>({ kind: 'events', ...query }, this.admission(guard));
  }
  async comments(blockId:unknown,current:WhiteboardGuard):Promise<WhiteboardCommentPage> {
    const guard=this.admission(current);
    const value=await this.request<StoredComments>({ kind:'comments',blockId:parse(whiteboardId.parse,blockId) },guard);
    const resolved=value.head && value.threads.length ? await this.validator.anchors({ checkpoint:Buffer.from(value.head.checkpoint,'base64'),anchors:{ resolve:value.threads.map(t=>t.anchor) } }) : undefined;
    guard();
    return { blockId:value.blockId,cursor:value.cursor,threads:value.threads.map((thread,index)=> {
      const range=resolved?.ranges[index]; const live=range && range.from<range.to;
      return { ...thread,anchorState:!value.head || value.head.epoch!==thread.epoch ? 'deleted' : live ? 'live' : 'orphaned',...(live ? { range } : {}) };
    }) };
  }
  async comment(input:unknown,current:WhiteboardGuard):Promise<WhiteboardReceipt> {
    const command=parse(whiteboardCommentCommand.parse,input); const hash=fingerprint('comment',command);
    return this.mutate(async()=> {
      const previous=await this.previous(command.commandId,hash,current); if (previous) return previous;
      const guard=this.admission(current,true);
      if (command.type!=='create') return this.request({ kind:'comment',commandId:command.commandId,fingerprint:hash,command },guard);
      const head=await this.head(command.blockId,guard);
      requireMission(head.epoch===command.epoch && head.textRevision===command.expectedTextRevision,'VERSION_CONFLICT','Select a range from the current saved text');
      const result=await this.validator.anchors({ checkpoint:Buffer.from(head.checkpoint,'base64'),anchors:{ create:command } });
      return this.request({ kind:'comment',commandId:command.commandId,fingerprint:hash,command,anchor:result.anchor,sourceHash:head.hash },guard);
    });
  }
  async presence(input:unknown,current:WhiteboardGuard):Promise<WhiteboardPresenceState> {
    const state=parse(whiteboardPresenceState.parse,input); const guard=this.admission(current,true);
    requireMission(Buffer.byteLength(JSON.stringify(state))<=2048,'INVALID_INPUT','Presence is too large');
    if (state.selection) {
      if(state.sectionId!==undefined) {
        const location=await this.request<{sectionId:string}>({kind:'location',blockId:state.selection.blockId},guard);
        requireMission(location.sectionId===state.sectionId,'NOT_FOUND','Selection belongs to another section');
      }
      const head=await this.head(state.selection.blockId,guard);
      requireMission(head.epoch===state.selection.epoch,'EPOCH_CHANGED','Selection document changed');
      const value=await this.validator.anchors({ checkpoint:Buffer.from(head.checkpoint,'base64'),anchors:{ resolve:[{ from:state.selection.anchor,to:state.selection.head,quote:'' }] } });
      requireMission(value.ranges[0],'INVALID_INPUT','Selection must reference saved text');
    }
    for(const blockId of new Set(state.selectedIds??[])) {
      const location=await this.request<{sectionId:string}>({kind:'location',blockId},guard);
      requireMission(location.sectionId===(state.sectionId??'root'),'NOT_FOUND','Selected item belongs to another section');
    }
    if (state.drag) {
      const location=await this.request<{kind:string;sectionId:string}>({kind:'location',blockId:state.drag.blockId},guard);
      requireMission(location.kind!=='connection' && (state.sectionId===undefined || location.sectionId===state.sectionId),'NOT_FOUND','Dragged block is unavailable in this section');
    }
    guard(); return state;
  }
  private previous(commandId: string, fingerprint: string, guard: WhiteboardGuard) {
    return this.request<WhiteboardReceipt | null>({ kind: 'receipt', commandId, fingerprint }, this.admission(guard));
  }
  async convert(input: unknown, current: WhiteboardGuard): Promise<WhiteboardReceipt> {
    const command = parse(whiteboardConvert.parse, input); const hash = fingerprint('convert',command);
    return this.mutate(async () => {
      const previous = await this.previous(command.commandId,hash,current); if (previous) return previous;
      const guard = this.admission(current,true); const board = await this.snapshot(guard);
      requireMission(board.revision === command.expectedRevision, 'VERSION_CONFLICT', 'The board changed before conversion');
      const seeds = board.items.flatMap(item => 'text' in item ? [seeded(item)] : []);
      return this.request({ kind: 'convert', ...command, fingerprint: hash, seeds }, guard);
    });
  }
  async revert(input:unknown,current:WhiteboardGuard):Promise<WhiteboardReceipt> {
    const command=parse(whiteboardRevert.parse,input),guard=this.admission(current,true);
    return this.mutate(()=>this.withStore(guard,identity=>this.store.whiteboard<WhiteboardReceipt>({kind:'revert',version:2,command,projectId:identity.projectId,actor:identity.actor,nativeCustody:identity.nativeCustody,nativeCommand:identity.nativeCommand},()=>{guard();})));
  }
  async spatial(input:unknown,current:WhiteboardGuard):Promise<WhiteboardReceipt> {
    const command=parse(whiteboardSpatialCommand.parse,input);
    return this.mutate(async()=> {
      const previous=await this.previous(command.commandId,digest({version:3,kind:'structure',command}),current);if(previous)return previous;
      const guard=this.admission(current,true);
      const seeds=command.operations.flatMap(op=>op.type==='create'?[seeded(op.block)]:[]);
      return this.withStore(guard,identity=>this.store.whiteboard<WhiteboardReceipt>({kind:'apply',command,version:3,seeds,projectId:identity.projectId,actor:identity.actor,nativeCustody:identity.nativeCustody,nativeCommand:identity.nativeCommand},()=>{guard();}));
    });
  }
  async structure(input: unknown, current: WhiteboardGuard): Promise<WhiteboardReceipt> {
    const command = parse(whiteboardStructureCommand.parse, input);
    return this.mutate(async () => {
      const previous = await this.previous(command.commandId,fingerprint('structure',command),current); if (previous) return previous;
      const guard = this.admission(current,true);
      const seeds = command.operations.flatMap(op => op.type === 'create' ? [seeded(op.block)] : []);
      return this.withStore(guard,identity=>this.store.whiteboard<WhiteboardReceipt>({ kind: 'apply', command, version: 2, seeds, projectId: identity.projectId, actor: identity.actor, nativeCustody: identity.nativeCustody, nativeCommand: identity.nativeCommand }, () => { guard(); }));
    });
  }
  join(input: unknown, current: WhiteboardGuard) {
    const command = parse(whiteboardTextJoin.parse, input);
    return this.request<{ clientId: number }>({ kind: 'lease', ...command }, this.admission(current,true));
  }
  async submit(input: unknown, current: WhiteboardGuard): Promise<WhiteboardReceipt> {
    const command = parse(whiteboardTextUpdate.parse,input); const hash = fingerprint('text',command);
    const update = Buffer.from(command.update,'base64');
    requireMission(update.length <= 32768 && update.toString('base64') === command.update, 'INVALID_INPUT', 'Invalid text encoding');
    return this.textMutation(command.blockId,current,async () => {
      const previous = await this.previous(command.commandId,hash,current); if (previous) return previous;
      const guard = this.admission(current,true);
      const lease = await this.join({ blockId: command.blockId, epoch: command.epoch, clientKey: command.clientKey },guard);
      for (let attempt = 0; attempt < 3; attempt++) {
        // A concurrent duplicate can finish while this candidate waits.
        const previous = await this.previous(command.commandId,hash,guard); if (previous) return previous;
        const head = await this.head(command.blockId,guard);
        requireMission(head.epoch === command.epoch, 'EPOCH_CHANGED', 'Reload this document');
        let candidate;
        try { candidate = await this.validator.prepare({ checkpoint: Buffer.from(head.checkpoint,'base64'), update }); }
        catch (error) {
          const settled = await this.previous(command.commandId,hash,guard); if (settled) return settled;
          throw error;
        }
        requireMission(candidate.updateClients.every(id => id === lease.clientId), 'FORBIDDEN', 'Text identity does not belong to this editor');
        try {
          return await this.request<WhiteboardReceipt>({ kind: 'submit', commandId: command.commandId, fingerprint: hash,
            blockId: command.blockId, epoch: command.epoch, sourceRevision: head.textRevision, sourceHash: head.hash,
            state: candidate.state, text: candidate.text, update: command.update },guard);
        } catch (error) { if (!(error instanceof MissionError) || error.code !== 'HEAD_CHANGED') throw error; }
      }
      throw new MissionError('BUSY','Text changed during preparation. Check the original receipt before retrying.');
    });
  }
  /** Native semantic edits bind the complete saved UTF-8 body, not just edited excerpts. */
  async agentPatch(input: unknown, current: WhiteboardGuard): Promise<WhiteboardReceipt> {
    const { expectedHash, ...command } = parse(whiteboardAgentTextPatch.parse, input);
    requireMission(current().nativeCustody, 'FORBIDDEN', 'Native invocation custody is required');
    return this.patchCommand(command, current, expectedHash);
  }
  async patch(input: unknown, current: WhiteboardGuard): Promise<WhiteboardReceipt> {
    return this.patchCommand(parse(whiteboardTextPatch.parse, input), current);
  }
  private async patchCommand(command: ReturnType<typeof whiteboardTextPatch.parse>, current: WhiteboardGuard,
    expectedContentHash?: string): Promise<WhiteboardReceipt> {
    const hash = expectedContentHash === undefined ? fingerprint('patch', command)
      : fingerprint('agent-patch', { ...command, expectedHash: expectedContentHash });
    return this.textMutation(command.blockId,current,async () => {
      const previous = await this.previous(command.commandId,hash,current); if (previous) return previous;
      const guard = this.admission(current,true); requireMission(guard().actor.kind === 'agent', 'FORBIDDEN', 'Semantic patches require an admitted agent');
      const head = await this.head(command.blockId,guard);
      requireMission(head.epoch === command.epoch && head.textRevision === command.expectedTextRevision, 'VERSION_CONFLICT', 'Read the current text before patching');
      const lease = await this.join({ blockId: command.blockId, epoch: command.epoch, clientKey: 'semantic-agent' },guard);
      const candidate = await this.validator.prepare({ checkpoint: Buffer.from(head.checkpoint,'base64'), patch: command.edits, clientId: lease.clientId });
      try {
        return await this.request<WhiteboardReceipt>({ kind: 'submit', commandId: command.commandId, fingerprint: hash,
          blockId: command.blockId, epoch: command.epoch, sourceRevision: head.textRevision, sourceHash: head.hash,
          state: candidate.state, text: candidate.text, update: Buffer.from(candidate.update).toString('base64'),
          ...(expectedContentHash === undefined ? {} : { expectedContentHash }) },guard);
      } catch (error) { if (error instanceof MissionError && error.code === 'HEAD_CHANGED') throw new MissionError('VERSION_CONFLICT','Read the current text before patching'); throw error; }
    });
  }
  close() { return this.validator.close(); }
}
