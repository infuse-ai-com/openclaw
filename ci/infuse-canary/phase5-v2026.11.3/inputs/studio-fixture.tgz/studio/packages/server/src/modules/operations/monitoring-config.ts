import {parseCompanySignalsConfig,type CompanySignalsConfig} from './company-config.js';
import {createHash} from 'node:crypto';
import {missionIdentifier,healthObject,healthText,healthTime,type PublicHealthCheck} from '@studio/contracts';
import {parseProbeConfig,type ProbeConfig} from './health-probes.js';

export interface HealthCheckDefinition extends PublicHealthCheck {minSamples:number}
export interface HealthCheckConfig extends HealthCheckDefinition {
 floorIds:string[];probe:ProbeConfig;retries:number;retryDelayMs:number;
}
export interface MonitoringDeliveryConfig {
 mode:'shadow'|'live';destinationId:string;webhookEnv?:string;
 ownership?:{epoch:string;receipt:string;backofficeGrantRevokedAt:string};
}
export interface MonitoringConfig {enabled:boolean;checks:HealthCheckConfig[];delivery:MonitoringDeliveryConfig;signals?:CompanySignalsConfig}
function keys(o:Record<string,unknown>,allowed:string[]):void {
 if(Object.keys(o).some(k=>!allowed.includes(k)))throw Error('Unknown monitoring configuration field');
}
function integer(value:unknown,fallback:number,min:number,max:number):number {
 const n=value??fallback;if(typeof n!=='number'||!Number.isSafeInteger(n)||n<min||n>max)throw Error('Invalid bounded monitoring policy');return n;
}
export function parseMonitoringConfig(value:unknown):MonitoringConfig {
 const o=healthObject(value);keys(o,['enabled','checks','delivery','signals']);
 if(typeof o.enabled!=='boolean'||!Array.isArray(o.checks)||o.checks.length>100)throw Error('Invalid monitoring configuration');
 const checks=o.checks.map(raw=>{
  const c=healthObject(raw);keys(c,['id','resourceId','resourceName','system','name','enabled','floorIds','probe','intervalMs','staleAfterMs','minSamples','retries','retryDelayMs']);
  const id=missionIdentifier(c.id),resourceId=missionIdentifier(c.resourceId),probe=parseProbeConfig(c.probe);
  if(typeof c.enabled!=='boolean'||!Array.isArray(c.floorIds)||!c.floorIds.length||c.floorIds.length>100)throw Error('Checks require explicit floor admission and enablement');
  const floorIds=c.floorIds.map(missionIdentifier);if(new Set(floorIds).size!==floorIds.length)throw Error('Duplicate check floor admission');
  const intervalMs=integer(c.intervalMs,300000,30000,86400000),staleAfterMs=integer(c.staleAfterMs,Math.min(86400000,intervalMs*3),intervalMs,86400000);
  const minSamples=integer(c.minSamples,2,2,10),retries=integer(c.retries,1,0,5),retryDelayMs=integer(c.retryDelayMs,1000,0,30000);
  const specDigest=createHash('sha256').update(JSON.stringify([resourceId,probe,c.enabled,intervalMs,staleAfterMs,minSamples,retries,retryDelayMs])).digest('hex');
  const system=c.system===undefined?undefined:healthObject(c.system);
  if(system)keys(system,['id','name']);
  return {id,resourceId,resourceName:healthText(c.resourceName),...(system?{system:{id:missionIdentifier(system.id),name:healthText(system.name)}}:{}),name:healthText(c.name),kind:probe.kind,enabled:c.enabled,specDigest,intervalMs,staleAfterMs,minSamples,floorIds,probe,retries,retryDelayMs};
 });
 if(new Set(checks.map(c=>c.id)).size!==checks.length)throw Error('Duplicate monitoring check identity');
 const d=healthObject(o.delivery??{mode:'shadow',destinationId:'monitoring'});keys(d,['mode','destinationId','webhookEnv','ownership']);
 if(!['shadow','live'].includes(String(d.mode)))throw Error('Invalid monitoring delivery mode');
 const delivery:MonitoringDeliveryConfig={mode:d.mode as 'shadow'|'live',destinationId:missionIdentifier(d.destinationId)};
 if(delivery.destinationId!=='monitoring')throw Error('Only the preserved monitoring destination is supported');
 if(d.webhookEnv!==undefined){const env=healthText(d.webhookEnv);if(!/^[A-Z][A-Z0-9_]*$/.test(env))throw Error('Invalid monitoring secret reference');delivery.webhookEnv=env;}
 if(d.ownership!==undefined){const own=healthObject(d.ownership);keys(own,['epoch','receipt','backofficeGrantRevokedAt']);delivery.ownership={epoch:missionIdentifier(own.epoch),receipt:missionIdentifier(own.receipt),backofficeGrantRevokedAt:healthTime(own.backofficeGrantRevokedAt)};}
 if(delivery.mode==='live'&&(!delivery.webhookEnv||!delivery.ownership))throw Error('Live delivery requires an explicit single-emitter cutover receipt and secret reference');
 return {enabled:o.enabled,checks,delivery,...(o.signals===undefined?{}:{signals:parseCompanySignalsConfig(o.signals)})};
}
export function healthDefinition(c:HealthCheckConfig):HealthCheckDefinition {
 const {id,resourceId,resourceName,system,name,kind,enabled,specDigest,intervalMs,staleAfterMs,minSamples}=c;
 return {id,resourceId,resourceName,...(system?{system}:{}),name,kind,enabled,specDigest,intervalMs,staleAfterMs,minSamples};
}


/** Non-secret presentation labels, deployed independently of protected probe targets. */
export function withMonitoringSystems(config:MonitoringConfig,raw:string):MonitoringConfig {
 if(Buffer.byteLength(raw)>32768)throw Error('Monitoring system labels exceed limit');
 const value:unknown=JSON.parse(raw);
 if(!Array.isArray(value)||value.length>100)throw Error('Invalid monitoring systems');
 const resources=new Set(config.checks.map(c=>c.resourceId)),labels=new Map<string,{id:string;name:string}>(),systems=new Set<string>();
 for(const item of value){
  const group=healthObject(item);keys(group,['id','name','resources']);
  const system={id:missionIdentifier(group.id),name:healthText(group.name)};
  if(systems.has(system.id)||!Array.isArray(group.resources)||!group.resources.length||group.resources.length>100)throw Error('Invalid system resource group');
  systems.add(system.id);
  for(const rawId of group.resources){
   const id=missionIdentifier(rawId);
   if(!resources.has(id)||labels.has(id))throw Error('Unknown or repeated monitoring resource');
   labels.set(id,system);
  }
 }
 return {...config,checks:config.checks.map(check=>{
  const system=labels.get(check.resourceId);
  if(!system)return check;
  if(check.system)throw Error('Monitoring system labels must have one owner');
  return {...check,system};
 })};
}
