import {healthObject as object,healthCount as count,healthText as text,healthTime as time,providerDay,providerTimeZone,parseCompanySignalInput,type CompanySignalInput,type ProviderUsageData} from '@studio/contracts';
export class CompanySourceError extends Error {constructor(readonly code:'SOURCE_INVALID'|'SOURCE_MISSING'|'SOURCE_UNAVAILABLE'|'SOURCE_LIMIT',readonly retryAfterMs=30000){super(code);}}
export interface ProviderFeedMapping {sourceId:string;resourceId:string;specDigest:string;provider:string;owner:string;bucketTimeZone?:string}
/** A single explicitly mapped usage scope/provider. Never select an arbitrary last account or import private projects/sessions. */
export function decodeCodexBarProvider(raw:unknown,m:ProviderFeedMapping,observedAt:string):CompanySignalInput {
 try {
  const values=Array.isArray(raw)?raw:[raw];if(values.length>100)throw Error('Too many provider payloads');
  const selected=values.map(object).filter(v=>v.provider===m.provider);if(selected.length!==1)throw Error('Ambiguous/missing provider account');
  const source=selected[0]!;if(source.error!==undefined&&source.error!==null)throw new CompanySourceError('SOURCE_UNAVAILABLE');
  const generatedAt=source.updatedAt===null||source.updatedAt===undefined?null:time(source.updatedAt);
  const explicitZone=providerTimeZone(m.bucketTimeZone),reportedZone=providerTimeZone(source.bucketTimeZone);
  if(explicitZone&&reportedZone&&explicitZone!==reportedZone)throw Error('Provider bucket timezone disagrees with source declaration');
  if(source.currencyCode!==undefined&&source.currencyCode!=='USD')throw Error('Unsupported provider cost currency');
  if(source.historyCoverageIsEstablished!==undefined&&typeof source.historyCoverageIsEstablished!=='boolean')throw Error('Invalid provider coverage flag');
  if(!Array.isArray(source.daily)||source.daily.length>366)throw Error('Invalid bounded provider daily rows');
  const days=source.daily.map(rawDay=>{
   const d=object(rawDay),models=d.modelBreakdowns??[];if(!Array.isArray(models)||models.length>50)throw Error('Provider model bound exceeded');
   return {date:providerDay(d.date),totalTokens:d.totalTokens??null,costUsd:d.totalCost??null,incompleteRequests:count(d.incompleteRequestCount??0,1e9),models:models.map(rawModel=>{const model=object(rawModel);return {model:text(model.modelName),totalTokens:model.totalTokens??null,costUsd:model.cost??null,incompleteRequests:count(model.incompleteRequestCount??0,1e9)};})};
  });
  if(new Set(days.map(d=>d.date)).size!==days.length)throw Error('Duplicate provider calendar date');
  const incomplete=count(source.incompleteRequestCount??0,1e9)>0||days.some(d=>d.incompleteRequests>0||d.models.some(model=>model.incompleteRequests>0));
  const coverage:ProviderUsageData['coverage']=incomplete||source.historyCoverageIsEstablished===false?'partial':source.historyCoverageIsEstablished===true?'complete':'unknown';
  return parseCompanySignalInput({sourceId:m.sourceId,resourceId:m.resourceId,specDigest:m.specDigest,kind:'provider-usage',generatedAt,observedAt:time(observedAt),sourceStatus:generatedAt?'available':'unknown',data:{provider:m.provider,owner:m.owner,bucketTimeZone:reportedZone??explicitZone,coverage,historyDays:source.historyDays??null,costBasis:'estimate',days:days.sort((a,b)=>a.date.localeCompare(b.date)).slice(-31)}});
 }catch(error){if(error instanceof CompanySourceError)throw error;throw new CompanySourceError('SOURCE_INVALID');}
}
