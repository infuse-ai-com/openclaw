import { gitObject, gitSha, gitText, parseGitCommit, type GitBranch, type GitCommitMetadata, type GitRepositoryMetadata } from '@studio/contracts';
import { GitSourceError, type GitSource } from './git-source.js';
import { configuredGitMetadata, type GitRepositoryConfig } from './git-config.js';

// Sourcebot's reviewed mapping and activation record identify this one repository.
const repositoryId = '788c56ae-4b2e-4c73-b9f9-0e559cb70c80';
const projectId = '1935d9e7-daa2-4872-998b-d947bb666e90';
const sourceId = 'azure-' + repositoryId;
export const studioGitLabProject = Object.freeze({ id: 76, path: 'platform/internal-tools/studio' });
const endpoint = 'https://gitlab.infuse-ai-tech.party/api/v4/projects/';
const pageSize = 100;
const responseLimit = 4 * 1024 * 1024;

export function isStudioPilotRepository(repository: GitRepositoryConfig, registryId: string = repositoryId): boolean {
  return registryId === repositoryId && repository.sourceId === sourceId && repository.organization === 'infuse-ai'
    && repository.projectId === projectId && repository.repositoryId === repositoryId;
}

async function readJson(response: Response): Promise<unknown> {
  const reader = response.body?.getReader();
  if (!reader) throw new GitSourceError('GITLAB_RESPONSE_INVALID');
  const chunks: Uint8Array[] = [];
  let length = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) return JSON.parse(Buffer.concat(chunks, length).toString('utf8'));
      length += value.length;
      if (length > responseLimit) throw new GitSourceError('GITLAB_RESPONSE_LIMIT');
      chunks.push(value);
    }
  } finally {
    await reader.cancel().catch(() => undefined);
    reader.releaseLock();
  }
}

function optionalText(value: unknown, max: number): string | null {
  if (typeof value !== 'string') return null;
  return value.replace(/[\u0000-\u001f\u007f]/gu, '').trim().slice(0, max).replace(/[\ud800-\udbff]$/u, '') || null;
}

function decodeCommit(raw: unknown): GitCommitMetadata {
  const row = gitObject(raw);
  const message = (typeof row.message === 'string' ? row.message : '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/gu, '');
  return parseGitCommit({
    sha: row.id, authorName: optionalText(row.author_name, 256) ?? 'Unknown', authorEmail: optionalText(row.author_email, 320),
    authorDate: row.authored_date, committerName: optionalText(row.committer_name, 256),
    committerEmail: optionalText(row.committer_email, 320), committerDate: row.committed_date,
    message: message.slice(0, 1000).replace(/[\ud800-\udbff]$/u, ''), messageTruncated: message.length > 1000, provenance: 'gitlab',
  });
}

function pageRows(value: unknown): unknown[] {
  if (!Array.isArray(value) || value.length > pageSize) throw new GitSourceError('GITLAB_RESPONSE_INVALID');
  return value;
}

export class StudioGitLabPilotSource implements GitSource {
  private readonly project;

  constructor(private readonly repository: GitRepositoryConfig, private readonly credential: () => string | undefined,
    private readonly fetcher: typeof fetch = fetch) {
    const project = repository.gitLabProject ?? (isStudioPilotRepository(repository) ? studioGitLabProject : undefined);
    if (!project || !Number.isSafeInteger(project.id) || project.id < 1)
      throw new GitSourceError('GITLAB_PROJECT_MISMATCH');
    this.project = project;
  }

  async metadata(signal: AbortSignal): Promise<GitRepositoryMetadata> {
    const project = gitObject(await this.read('', {}, signal));
    if (project.id !== this.project.id || project.path_with_namespace !== this.project.path)
      throw new GitSourceError('GITLAB_PROJECT_MISMATCH');
    return configuredGitMetadata(this.repository);
  }

  async refs(cursor: string | undefined, signal: AbortSignal): Promise<{branches: GitBranch[]; nextCursor?: string}> {
    const page = cursor === undefined ? 1 : Number(cursor);
    if (!Number.isSafeInteger(page) || page < 1 || page > 11 || cursor !== undefined && String(page) !== cursor)
      throw new GitSourceError('GITLAB_REFS_LIMIT');
    const rows = pageRows(await this.read('/repository/branches', { page: String(page), per_page: String(pageSize) }, signal));
    return {
      branches: rows.map(raw => {
        const row = gitObject(raw);
        return { name: 'refs/heads/' + gitText(row.name, 501), head: gitSha(gitObject(row.commit).id) };
      }),
      ...(rows.length === pageSize ? { nextCursor: String(page + 1) } : {}),
    };
  }

  async commits(head: string, offset: number, signal: AbortSignal): Promise<{commits: GitCommitMetadata[]; rawCount: number; nextOffset?: number}> {
    if (!Number.isSafeInteger(offset) || offset < 0 || offset % pageSize) throw new GitSourceError('GITLAB_RESPONSE_INVALID');
    const sha = gitSha(head);
    const rows = pageRows(await this.read('/repository/commits', {
      page: String(offset / pageSize + 1), per_page: String(pageSize), ref_name: sha, order: 'topo',
    }, signal, true));
    const commits = rows.map(decodeCommit);
    if (offset === 0 && commits[0]?.sha !== sha) throw new GitSourceError('GITLAB_HEAD_UNAVAILABLE');
    return { commits, rawCount: rows.length, ...(rows.length === pageSize ? { nextOffset: offset + pageSize } : {}) };
  }

  private async read(path: string, query: Record<string, string>, signal: AbortSignal, frozenHead = false): Promise<unknown> {
    const token = this.credential();
    if (!token || !/^[\x21-\x7e]{16,512}$/u.test(token)) throw new GitSourceError('GITLAB_CREDENTIAL_UNAVAILABLE');
    const url = new URL(endpoint + this.project.id + path);
    url.search = new URLSearchParams(query).toString();
    try {
      const response = await this.fetcher(url, { signal, redirect: 'error', headers: { 'private-token': token, accept: 'application/json' } });
      if (response.status === 200) return await readJson(response);
      await response.body?.cancel();
      if (response.status === 429) {
        const seconds = Number(response.headers.get('retry-after')) || 60;
        throw new GitSourceError('GITLAB_RATE_LIMIT', Math.trunc(Math.min(900, Math.max(1, seconds)) * 1000));
      }
      if (frozenHead && response.status === 404) throw new GitSourceError('GITLAB_HEAD_UNAVAILABLE');
      throw new GitSourceError('GITLAB_SOURCE_UNAVAILABLE');
    } catch (error) {
      if (error instanceof GitSourceError) throw error;
      throw new GitSourceError('GITLAB_SOURCE_UNAVAILABLE');
    }
  }
}
