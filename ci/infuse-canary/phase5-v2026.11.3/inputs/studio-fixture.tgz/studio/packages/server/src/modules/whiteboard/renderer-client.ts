import type {WhiteboardRenderPort} from './agent-renderer.js';
import {requireMission} from '../missions/domain.js';
/** Configured internal worker only. No cookies, auth headers or arbitrary source URLs. */
export function whiteboardRendererClient(address:string):WhiteboardRenderPort {
 const url=new URL(address);requireMission(['http:','https:'].includes(url.protocol)&&!url.username&&!url.password&&!url.search&&!url.hash&&url.pathname==='/'&&
   (['127.0.0.1','localhost','[::1]'].includes(url.hostname)||url.hostname.endsWith('.svc')||url.hostname.endsWith('.svc.cluster.local')),'INVALID_INPUT','Renderer endpoint must be internal');
 return async(bundle,signal)=>{
  const response=await fetch(new URL('/render',url),{method:'POST',redirect:'error',credentials:'omit',signal,headers:{'Content-Type':'application/json'},body:JSON.stringify(bundle)});
  requireMission(response.ok&&response.headers.get('content-type')==='image/png','UNAVAILABLE','Renderer unavailable');
  const parts:Uint8Array[]=[];let size=0;
  for await(const part of response.body??[]){size+=part.byteLength;requireMission(size<=1024*1024,'PAYLOAD_TOO_LARGE','Capture exceeds budget');parts.push(part);}
  return Buffer.concat(parts);
 };
}
