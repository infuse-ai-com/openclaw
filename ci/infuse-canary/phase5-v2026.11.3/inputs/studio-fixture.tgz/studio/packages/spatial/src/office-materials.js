import { assetUrls } from '@studio/ui/assets';
import * as THREE from 'three';

// Small, locally bundled material tiles. Content and lighting remain real 3D.
export function createOfficeMaterials(renderer,manager) {
  const cache=new Map(),textures=[],pending=[];
  let disposed=false;
  const loader=new THREE.TextureLoader(manager);
  function tile(url,color=false) {
    const entry={map:null};
    const map=loader.load(url,loaded=>{
      if(disposed)return;
      entry.map=loaded;
      for(const apply of pending)apply();
    });
    map.wrapS=map.wrapT=THREE.RepeatWrapping;
    map.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
    if(color)map.colorSpace=THREE.SRGBColorSpace;
    textures.push(map);return entry;
  }
  const oak=tile(assetUrls['oak-grain.webp'],true);
  const oakRelief=tile(assetUrls['oak-relief.webp']);
  const linen=tile(assetUrls['linen-weave.webp'],true);
  const linenRelief=tile(assetUrls['linen-relief.webp']);
  function surface(type,color) {
    color=color?.isColor?color.getHex():color;
    const key=`${type}:${color}`;
    if(cache.has(key))return cache.get(key);
    const properties={color,roughness:.84,metalness:0};
    if(type==='wood')Object.assign(properties,{roughness:.64,bumpScale:.012});
    if(type==='fabric'||type==='rug')Object.assign(properties,{roughness:1,bumpScale:type==='rug'?.025:.014});
    if(type==='metal')Object.assign(properties,{roughness:.39,metalness:.72});
    if(type==='brass')Object.assign(properties,{roughness:.36,metalness:.65});
    if(type==='ceramic')Object.assign(properties,{roughness:.32,side:THREE.DoubleSide});
    if(type==='shade')Object.assign(properties,{roughness:.9,side:THREE.DoubleSide,emissive:0xffcd87,emissiveIntensity:.12});
    if(type==='glass')Object.assign(properties,{roughness:.15,metalness:.1,transparent:true,opacity:.18,depthWrite:false,side:THREE.DoubleSide});
    if(type==='screen')Object.assign(properties,{roughness:.48,emissive:color,emissiveIntensity:.14});
    if(type==='signal')Object.assign(properties,{roughness:.45,emissive:color,emissiveIntensity:.35});
    const mat=type==='unlit'?new THREE.MeshBasicMaterial({color}):new THREE.MeshStandardMaterial(properties);
    // Use metre-based UVs for furniture so a long desk never stretches its grain.
    mat.userData.surfaceScale=type==='wood'?.7:type==='fabric'?2:type==='rug'?.65:0;
    const sources=type==='wood'?[oak,oakRelief]:['fabric','rug'].includes(type)?[linen,linenRelief]:null;
    if(sources){const apply=()=>{if(sources[0].map&&sources[1].map&&!mat.map){mat.map=sources[0].map;mat.bumpMap=sources[1].map;mat.needsUpdate=true;}};pending.push(apply);apply();}
    cache.set(key,mat);return mat;
  }
  return {surface,dispose(){disposed=true;cache.forEach(mat=>mat.dispose());textures.forEach(map=>map.dispose());}};
}

export function surfaceUVs(geometry,scale) {
  if(!scale)return geometry;
  const p=geometry.attributes.position,n=geometry.attributes.normal,uv=geometry.attributes.uv;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
    if(Math.abs(n.getY(i))>.5)uv.setXY(i,x*scale,z*scale);
    else if(Math.abs(n.getX(i))>.5)uv.setXY(i,z*scale,y*scale);
    else uv.setXY(i,x*scale,y*scale);
  }
  return geometry;
}
