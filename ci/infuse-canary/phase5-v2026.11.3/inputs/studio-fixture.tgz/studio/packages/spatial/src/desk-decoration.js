import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

/** Static maker's corner, outside the two screens and excluded from desk picking. */
export function addDeskDecoration(scene, {box, material}) {
  const decoration=new THREE.Group();
  const group=(parent,x,y,z)=>{const node=new THREE.Group();node.position.set(x,y,z);parent.add(node);return node;};
  const sage=0x8c9978,ink=0x29342f,paper=0xe8e1cb,oak=0xae7c4d,orange=0xd87832;

  const mesh=(parent,geometry,x,y,z,color)=>{
    const node=new THREE.Mesh(geometry,material(color));node.position.set(x,y,z);parent.add(node);return node;
  };
  // Flat bevels keep the voxel silhouette while giving edges a readable highlight.
  const bevelBox=(parent,w,h,d,x,y,z,color,b=.02)=>{
    const shape=new THREE.Shape(),hw=w/2-b,hh=h/2-b;
    shape.moveTo(-hw,-hh);shape.lineTo(hw,-hh);shape.lineTo(hw,hh);shape.lineTo(-hw,hh);shape.closePath();
    const geometry=new THREE.ExtrudeGeometry(shape,{depth:d-2*b,bevelEnabled:true,bevelSize:b,bevelThickness:b,bevelSegments:1,steps:1,curveSegments:1});
    geometry.translate(0,0,-d/2+b);
    return mesh(parent,geometry,x,y,z,color);
  };
  // Open, eight-sided pots: tapered walls, a bevelled foot, thick lip and visible soil/floor.
  const vessel=(parent,r,h,x,y,z,color)=>{
    const rings=[[r*.8,0],[r*.88,.025],[r,h-.035],[r,h],[r-.035,h],[r*.74,.07],[0,.07]],positions=[];
    const point=(ring,i)=>{const angle=(i+.5)*Math.PI/4;return [Math.cos(angle)*ring[0],ring[1],Math.sin(angle)*ring[0]];};
    for(let layer=0;layer<rings.length-1;layer++)for(let i=0;i<8;i++){
      const a=point(rings[layer],i),b=point(rings[layer],i+1),c=point(rings[layer+1],i),d=point(rings[layer+1],i+1);
      positions.push(...a,...c,...b);if(rings[layer+1][0])positions.push(...b,...c,...d);
    }
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
    geometry.setAttribute('uv',new THREE.Float32BufferAttribute(new Array(positions.length/3*2).fill(0),2));geometry.computeVertexNormals();
    return mesh(parent,geometry,x,y,z,color);
  };

  // The perforated board sits below the wall LCD and to the left of the monitor.
  const pegboard=group(decoration,-5.65,4.12,-3.94);
  const boardShape=new THREE.Shape();
  boardShape.moveTo(-1.8,-1.2);boardShape.lineTo(1.8,-1.2);boardShape.lineTo(1.8,1.2);boardShape.lineTo(-1.8,1.2);boardShape.closePath();
  for(let row=0;row<8;row++)for(let col=0;col<12;col++){
    const x=-1.56+col*.284,y=-.98+row*.28,hole=new THREE.Path();
    hole.moveTo(x-.033,y-.033);hole.lineTo(x-.033,y+.033);hole.lineTo(x+.033,y+.033);hole.lineTo(x+.033,y-.033);hole.closePath();boardShape.holes.push(hole);
  }
  const board=new THREE.Mesh(new THREE.ExtrudeGeometry(boardShape,{depth:.09,bevelEnabled:false}),material(sage));pegboard.add(board);
  for(const x of [-1.62,1.62])box(pegboard,.08,2.05,.08,x,0,-.04,0x647354);
  // Pixel-stepped arc with an inner cushion and layered, chamfered ear pads.
  const headphones=group(pegboard,-.65,.02,.24);
  box(pegboard,.08,.08,.24,-.65,.78,.19,oak);
  for(let i=0;i<19;i++){
    const angle=i*Math.PI/18,x=Math.round(Math.cos(angle)*.56/.045)*.045,y=Math.round((.05+Math.sin(angle)*.65)/.045)*.045;
    box(headphones,.135,.125,.17,x,y,0,0x252925);
    if(i>2&&i<16)box(headphones,.1,.09,.13,x*.86,.05+(y-.05)*.86,.045,0x393c34);
  }
  const earPad=(parent,w,h,d,x,y,z,color)=>{
    const shape=new THREE.Shape();
    const points=[[-.22,-.5],[.22,-.5],[.22,-.43],[.4,-.43],[.4,-.32],[.5,-.32],[.5,.32],[.4,.32],[.4,.43],[.22,.43],[.22,.5],[-.22,.5],[-.22,.43],[-.4,.43],[-.4,.32],[-.5,.32],[-.5,-.32],[-.4,-.32],[-.4,-.43],[-.22,-.43]];
    points.forEach(([px,py],i)=>{if(i===0)shape.moveTo(px*w,py*h);else shape.lineTo(px*w,py*h);});shape.closePath();
    const geometry=new THREE.ExtrudeGeometry(shape,{depth:d,bevelEnabled:false});geometry.translate(0,0,-d/2);
    return mesh(parent,geometry,x,y,z,color);
  };
  for(const side of [-1,1]){
    const ear=group(headphones,side*.53,-.31,.015);ear.rotation.z=side*-.22;ear.rotation.y=side*-.2;
    bevelBox(ear,.15,.35,.17,side*.015,.24,-.015,0x43453c,.025);
    earPad(ear,.37,.66,.3,0,-.02,.025,0x282a27);
    earPad(ear,.31,.57,.075,side*.035,-.02,.197,0x3a3b36);
    earPad(ear,.13,.56,.3,-side*.18,-.02,.025,0x171b18);
    bevelBox(ear,.055,.35,.21,-side*.245,-.02,.035,0x0f1713,.018);
    for(const y of [-.2,-.1,0,.1])box(ear,.255,.013,.012,side*.035,y,.238,0x505047);
  }
  for(const [x,y,w,h,color] of [[1.06,.57,.67,.86,paper],[1.32,-.17,.48,.49,0xd4bea0]]){
    bevelBox(pegboard,w,h,.025,x,y,.14,color,.006);
    box(pegboard,w-.04,.018,.009,x,y-h/2+.014,.16,0xcfc5aa);
    bevelBox(pegboard,.095,.2,.055,x,y+h/2,.17,oak,.009);
    box(pegboard,.055,.055,.015,x,y+h/2-.025,.205,0xc39764);
  }

  // All shelf items stay below the overview and outside the monitor's sightline.
  const shelf=group(decoration,5.1,3.62,-3.62);
  bevelBox(shelf,3.95,.19,.76,0,0,0,oak,.025);
  box(shelf,3.87,.022,.018,0,.058,.385,0xc19460);
  for(const y of [-.045,.012])box(shelf,3.76,.006,.008,.025,y,.389,0xa57346);
  for(const x of [-1.4,1.4]){
    box(shelf,.18,.43,.18,x,-.26,-.19,0x41543b);
    box(shelf,.18,.1,.6,x,-.12,-.04,0x41543b);
  }
  for(const [x,h,w,color,tilt] of [[-1.41,1.04,.25,0x687d56,-.035],[-1.1,1.26,.27,paper,0],[-.78,1.31,.28,0x29473e,0],[-.45,1.2,.27,orange,0]]){
    const book=group(shelf,x,.11,0);book.rotation.z=tilt;
    box(book,w-.04,h-.055,.4,0,h/2,0,paper);
    for(const side of [-1,1])bevelBox(book,.03,h,.47,side*w/2,h/2,0,color,.006);
    bevelBox(book,w,.99*h,.055,0,h/2,.232,color,.012);
    for(const side of [-1,1])box(book,.012,h-.055,.008,side*(w/2-.018),h/2,.263,color===paper?0xc5bda4:color===orange?0xba612b:0x425846);
    box(book,w*.36,.07,.008,0,.23,.264,0xafa68b);
    if(color===orange)box(book,w*.46,.3,.008,0,h-.37,.264,0xe4b17a);
    for(const y of [h-.07,h-.095])box(book,w-.05,.006,.35,0,y,-.015,0xc8c3ae);
  }
  // Stocky toy proportions, recessed face, stepped lid and articulated hands/boots.
  const robot=group(shelf,.43,.11,.07),robotOrange=0xc05e24;
  for(const side of [-1,1]){
    bevelBox(robot,.21,.12,.29,side*.145,.06,.035,0xb65c29,.018);
    box(robot,.17,.02,.25,side*.145,.017,.035,0x8e4b29);
    bevelBox(robot,.13,.16,.14,side*.145,.19,0,robotOrange,.018);
    box(robot,.12,.065,.13,side*.145,.255,0,ink);
    bevelBox(robot,.14,.19,.2,side*.32,.54,0,robotOrange,.025);
    box(robot,.13,.07,.13,side*.33,.405,0,0x4a4434);
    bevelBox(robot,.14,.14,.18,side*.33,.315,.025,0xc4692e,.02);
    box(robot,.07,.025,.035,side*.33,.29,.128,0x985127);
  }
  bevelBox(robot,.46,.38,.3,0,.46,0,robotOrange,.035);
  bevelBox(robot,.32,.27,.045,0,.47,.17,0xd9772c,.014);
  box(robot,.37,.035,.03,0,.305,.162,0xa85a2a);
  box(robot,.13,.045,.14,0,.672,0,0x4a4434);
  bevelBox(robot,.57,.39,.36,0,.9,0,0xc15c20,.033);
  box(robot,.52,.035,.33,0,1.109,0,0xd7752b);
  box(robot,.43,.035,.275,0,1.144,-.01,0xc16a2e);
  box(robot,.31,.025,.2,0,1.174,-.01,0xe48b40);
  for(const side of [-1,1]){
    bevelBox(robot,.085,.22,.22,side*.321,.91,0,0xb96027,.018);
    box(robot,.028,.13,.15,side*.373,.91,.008,0xda7c32);
  }
  bevelBox(robot,.47,.277,.035,0,.905,.194,0xdf8130,.012);
  box(robot,.395,.213,.016,0,.905,.215,0x202b25);
  for(const x of [-.105,.105])box(robot,.055,.085,.012,x,.914,.228,0xf3ebd5);

  const plant=group(shelf,1.42,.11,.01);
  vessel(plant,.255,.41,0,0,0,paper);
  mesh(plant,new THREE.CylinderGeometry(.21,.21,.014,8),0,.356,0,0x484833);
  const leaf=(parent,x,y,z,size,angle,color)=>{
    const node=bevelBox(parent,size*.85,size*.9,size*.48,x,y,z,color,.008);
    node.rotation.set(-.15+(angle%3)*.15,Math.sin(angle)*.35,angle*.7);return node;
  };
  for(let i=0;i<32;i++){
    const angle=i*2.4,r=.1+(i%4)*.058,x=Math.cos(angle)*r,z=Math.sin(angle)*r,y=.45+(i%5)*.065;
    const stem=box(plant,.021,y-.34,.021,x*.6,(y+.34)/2,z*.6,0x526238);stem.rotation.z=-x*.6;
    leaf(plant,x,y,z,.14+(i%3)*.025,Math.sin(angle)*.9,[0x29451f,0x3b592b,0x526b36,0x3a5327][i%4]);
  }
  // Fine, irregular trails fall over the front/right edge rather than a row of blocks.
  for(const [offset,count,phase] of [[0,12,0],[.17,8,1.7],[-.12,5,.8]])for(let i=0;i<count;i++){
    const x=.23+offset+Math.sin(i*.75+phase)*.055,y=.5-i*.13,z=.24+Math.sin(i*.6+phase)*.05;
    box(plant,.018,.16,.018,x,y,z,0x536638);
    leaf(plant,x+(i%2?.045:-.045),y-.05,z+.035,.14+(i%3)*.015,i%2?.4:-.6,i%3?0x3b592b:0x526b36);
  }

  // Faceted stationery cup with a heavy foot, visible interior and distinct pens/pencils.
  const pot=group(decoration,3.75,2.17,.45);
  vessel(pot,.23,.43,0,0,0,paper);
  for(const [x,z,h,color,lean] of [[-.09,0,.78,ink,.1],[.02,.06,.64,0x51664b,-.05],[.1,-.05,.8,orange,-.16]]){
    const pencil=group(pot,x,.05,z);pencil.rotation.z=lean;
    bevelBox(pencil,.055,h,.055,0,h/2,0,color,.006);
    if(color===ink){
      box(pencil,.06,.11,.06,0,h-.035,0,0x35473b);
      box(pencil,.012,.16,.018,.035,h-.1,.02,0x91a18b);
    }else{
      mesh(pencil,new THREE.CylinderGeometry(.01,.029,.075,4),0,h+.025,0,0xd6bc8c);
      mesh(pencil,new THREE.CylinderGeometry(0,.01,.024,4),0,h+.074,0,ink);
    }
  }

  // Batch static decoration by material so the fine details add only a few draw calls.
  decoration.updateMatrixWorld(true);
  const batches=new Map();
  decoration.traverse(mesh=>{
    if(!mesh.isMesh)return;
    const geometry=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();
    geometry.applyMatrix4(mesh.matrixWorld);
    if(!batches.has(mesh.material))batches.set(mesh.material,[]);
    batches.get(mesh.material).push(geometry);mesh.geometry.dispose();
  });
  for(const [mat,geometries] of batches){
    const mesh=new THREE.Mesh(mergeGeometries(geometries),mat);mesh.castShadow=mesh.receiveShadow=true;scene.add(mesh);
    geometries.forEach(geometry=>geometry.dispose());
  }
}
