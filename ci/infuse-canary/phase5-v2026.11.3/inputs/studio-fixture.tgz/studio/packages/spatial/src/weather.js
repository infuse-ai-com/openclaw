/** Decorative weather: a seeded 5% chance per UTC hour, stable across reloads and tabs.
 * This is an invented atmosphere, not a local weather forecast. No storage or location is needed.
 */
export function officeThunderstorm(timestamp) {
  // Mix the hour into a uniform 32-bit sample, so adjacent hours do not share a pattern.
  let seed = Math.floor(timestamp / 3_600_000);
  seed = Math.imul(seed ^ (seed >>> 16), 0x21f0aaad);
  seed = Math.imul(seed ^ (seed >>> 15), 0x735a2d97);
  return ((seed ^ (seed >>> 15)) >>> 0) / 2 ** 32 < .05;
}
