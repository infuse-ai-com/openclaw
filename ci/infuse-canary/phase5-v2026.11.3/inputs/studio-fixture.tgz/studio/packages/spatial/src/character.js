import * as THREE from 'three';

/** Reusable geometry only. The caller supplies identity and observed work. */
export function createOfficeCharacter(appearance) {
  const group = new THREE.Group(), body = new THREE.Group(), head = new THREE.Group();
  const materials = new Map(), geometries = [];
  function material(color) {
    if (!materials.has(color)) materials.set(color, new THREE.MeshStandardMaterial({color, roughness: .88}));
    return materials.get(color);
  }
  function box(parent, w, h, d, x, y, z, color) {
    const geometry = new THREE.BoxGeometry(w,h,d); geometries.push(geometry);
    const mesh = new THREE.Mesh(geometry, material(color)); mesh.position.set(x,y,z);
    mesh.receiveShadow = true; parent.add(mesh); return mesh;
  }
  group.add(body); body.add(head); head.position.y = 1.21;
  box(body,.59,.55,.34,0,.91,0,appearance.shirt);
  box(body,.48,.07,.35,0,.62,0,0x2f393b);
  box(head,.47,.43,.42,0,.18,0,appearance.skin);
  box(head,.51,.14,.45,0,.43,-.02,appearance.hair);
  box(head,.51,.25,.11,0,.28,-.2,appearance.hair);
  for (const x of [-.25,.25]) box(head,.055,.12,.12,x,.16,0,appearance.skin);
  for (const x of [-.105,.105]) box(head,.05,.055,.025,x,.205,.218,0x25372f);
  box(head,.06,.075,.06,0,.125,.23,appearance.skin);
  box(head,.10,.02,.02,0,.055,.221,0x956b51);
  const legs = [-.16,.16].map(x => {
    const hip = new THREE.Group(); hip.position.set(x,.65,0); group.add(hip);
    box(hip,.24,.29,.25,0,-.145,0,appearance.pants ?? 0x344246);
    const knee = new THREE.Group(); knee.position.y=-.29; hip.add(knee);
    box(knee,.22,.29,.23,0,-.145,0,appearance.pants ?? 0x344246);
    box(knee,.25,.11,.39,0,-.29,.065,appearance.shoes ?? 0x202d2c);
    return {hip,knee};
  });
  const arms = [-.365,.365].map(x => {
    const shoulder = new THREE.Group(); shoulder.position.set(x,1.15,0); body.add(shoulder);
    box(shoulder,.18,.27,.23,0,-.135,0,appearance.shirt);
    const elbow = new THREE.Group(); elbow.position.y=-.27; shoulder.add(elbow);
    box(elbow,.155,.24,.19,0,-.12,0,appearance.shirt);
    box(elbow,.15,.13,.18,0,-.28,0,appearance.skin);
    return {shoulder,elbow};
  });
  if (appearance.detail==='headphones') {
    box(head,.62,.085,.17,0,.46,0,0x263549);
    for (const x of [-.29,.29]) box(head,.10,.25,.22,x,.28,0,0x263549);
  }
  if (['glasses','beard'].includes(appearance.detail)) {
    for (const x of [-.115,.115]) {
      box(head,.19,.12,.038,x,.21,.24,0x263532);
      box(head,.13,.065,.012,x,.21,.263,0xa6b4a6);
    }
    box(head,.08,.035,.025,0,.21,.25,0x263532);
    box(head,.30,.15,.045,0,.015,.215,appearance.detail==='beard'?0xbba98f:0x51473e);
  }
  if (appearance.detail==='cap') {
    box(head,.55,.12,.47,0,.46,0,0xd1b56e);
    box(head,.55,.035,.29,0,.405,.24,0xb49b5a);
  }
  if (appearance.detail==='badge') box(body,.13,.17,.015,-.15,.96,.18,0xf7edce);
  if (appearance.detail==='tie') {
    box(body,.18,.45,.02,0,.94,.18,0xf1e6cf);
    box(body,.055,.30,.025,0,.97,.20,0x65556d);
  }
  const ringGeometry = new THREE.RingGeometry(.53,.58,40); geometries.push(ringGeometry);
  const ring = new THREE.Mesh(ringGeometry, new THREE.MeshBasicMaterial({color:0xfe7a39,side:THREE.DoubleSide}));
  ring.rotation.x=-Math.PI/2; ring.position.y=.035; ring.visible=false; group.add(ring);
  group.scale.setScalar(.94);
  return {
    group,
    select(value) { ring.visible=value; },
    pose({seated,stride,walking,gesture,working,wave=0}) {
      body.position.y=seated*.14;
      body.rotation.z=walking?Math.sin(stride)*.025:gesture*.014;
      head.rotation.set(working?gesture*.065:0,working?0:gesture*.16,0);
      for (const [i,{hip,knee}] of legs.entries()) {
        hip.position.y=.65+seated*.14;
        hip.rotation.x=-seated*Math.PI/2+(walking?Math.sin(stride+i*Math.PI)*.48:0);
        knee.rotation.x=seated*Math.PI/2+(walking?Math.max(0,-Math.sin(stride+i*Math.PI))*.3:0);
      }
      for (const [i,{shoulder,elbow}] of arms.entries()) {
        shoulder.rotation.x=seated*(working?-.86:-.4)+(walking?Math.sin(stride+(i+1)*Math.PI)*.35:0)+(working?gesture*(i?-.04:.04):0);
        elbow.rotation.x=seated*(working?-.6:-.5);
        shoulder.rotation.z=i?-.045:.045;
        if(i===1&&wave){shoulder.rotation.z-=wave*1.8;shoulder.rotation.x-=wave*.45;elbow.rotation.x-=wave*.7;}
      }
    },
    dispose() { group.removeFromParent(); geometries.forEach(g=>g.dispose()); materials.forEach(m=>m.dispose()); ring.material.dispose(); },
  };
}
