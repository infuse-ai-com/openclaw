import * as THREE from 'three';

// Authored architecture shared by every initiative. All coordinates are in office metres.
export function furnishOffice(parent, layout, floorInfo, kit) {
  const {box,softBox,part,material,surface,printMaterial,signMaterial,boardPapers,reviewPapers}=kit;
  const C={wood:0xa0784e,oak:0xbe915a,dark:0x343934,wall:0xcfb699,cream:0xf1e5c9,sage:0x687b57,light:0x8d9c74};
  const group=(p,x=0,z=0,rotation=0)=>{const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rotation;p.add(g);return g;};
  const b=box,r=softBox;
  const timber=c=>surface('wood',c),fabric=c=>surface('fabric',c);
  const brass=surface('brass',0xa18b60),metal=surface('metal',0xb9beb9);
  const glow=material('lamp');
  const floorY=.085;
  function mesh(p,geometry,finish,x,y,z,cast=true){const m=new THREE.Mesh(geometry,material(finish));m.position.set(x,y,z);m.castShadow=cast;m.receiveShadow=true;p.add(m);return m;}
  function tapered(p,w,h,d,x,y,z,finish,bottom=.82){
    const geometry=new THREE.BoxGeometry(w,h,d),pos=geometry.attributes.position;
    for(let i=0;i<pos.count;i++)if(pos.getY(i)<0){pos.setX(i,pos.getX(i)*bottom);pos.setZ(i,pos.getZ(i)*bottom);}
    geometry.computeVertexNormals();return mesh(p,geometry,finish,x,y,z);
  }
  function hardback(p,x,y,z,w=.32,d=.25,c=0x708068,rotation=0){
    const g=group(p,x,z,rotation);g.position.y=y;
    b(g,w,.018,d,0,0,0,c);b(g,w-.028,.065,d-.027,0,.042,0,0xe5dcc4);b(g,w,.016,d,0,.084,0,c);
    b(g,.021,.083,d,-w/2+.008,.042,0,c);for(const yy of [.025,.045,.064])b(g,w-.055,.003,.003,.005,yy,d/2-.011,0xc6bea9,false);return g;
  }
  function openBook(p,x,y,z,rotation=0){
    const g=group(p,x,z,rotation);g.position.y=y;
    b(g,.57,.025,.38,0,0,0,0x9b7753);
    for(const side of [-1,1]){const page=group(g,side*.142,0);page.position.y=.045;page.rotation.z=side*-.13;b(page,.275,.055,.355,0,0,0,0xfff0d0);for(let row=0;row<5;row++)b(page,.19,.004,.009,0,.03,-.12+row*.051,0xcac2a9,false);}
    b(g,.025,.06,.36,0,.035,0,0xd4c6a9);return g;
  }
  function penCup(p,x,y,z){
    b(p,.13,.18,.13,x,y+.09,z,surface('ceramic',0xb57542));b(p,.095,.008,.095,x,y+.187,z,0x5c4b35,false);
    for(let i=0;i<3;i++){const pen=b(p,.015,.19+i*.023,.015,x-.034+i*.03,y+.24,z+(i%2?-.025:.015),[0x586a58,0xc3b991,0x394449][i]);pen.rotation.z=(i-1)*.12;}
  }
  function warmLight(p,x,y,z,intensity=2.8,distance=3.2){const light=new THREE.PointLight(0xffbc75,intensity,distance,2);light.position.set(x,y,z);p.add(light);}
  function rug(p,w,d,x,z,c){
    b(p,w,.035,d,x,.109,z,surface('rug',c),false);
    const trim=surface('fabric',new THREE.Color(c).multiplyScalar(.83));
    for(const side of [-1,1]){b(p,w-.12,.01,.045,x,.13,z+side*(d/2-.075),trim,false);b(p,.045,.01,d-.12,x+side*(w/2-.075),.13,z,trim,false);}
  }
  function plant(p,x,z,s=1,y=0,wide=false,pot=true){
    const g=group(p,x,z);g.position.y=y;
    const seed=Math.abs(Math.sin(x*13.7+z*7.1+y*21.8));g.rotation.y=seed*Math.PI;
    if(pot){tapered(g,.46*s,.46*s,.46*s,0,.28*s,0,surface('ceramic',0x675e4a),.78);b(g,.48*s,.055*s,.48*s,0,.515*s,0,0x8b7d61);b(g,.35*s,.015,.35*s,0,.525*s,0,0x403d29);}
    b(g,.065*s,.86*s,.065*s,0,.9*s,0,0x716343);
    const leaves=[[-.24,.89,.09,.31,.29,.32],[.18,1.15,-.05,.35,.35,.31],[-.12,1.44,-.13,.3,.36,.3],[.12,.69,.18,.27,.23,.29],[-.3,1.22,.06,.23,.22,.26],[.22,1.59,-.08,.25,.27,.25],[0,1.75,.04,.23,.23,.25]];
    leaves.forEach(([lx,ly,lz,w,h,d],i)=>{
      const spread=.85+seed*.4,leaf=b(g,w*s*(wide?1.2:1),h*s,d*s,lx*s*spread,ly*s*(.9+seed*.18),lz*s,[0x69833c,0x879947,0x4d682f,0x8f9d4b][(i+Math.floor(seed*3))%4]);
      leaf.rotation.y=(i%3-1)*.18;leaf.rotation.z=(seed-.5)*.18;
    });return g;
  }
  function planter(p,x,z,w=1.8,rotation=0){
    const g=group(p,x,z,rotation);b(g,w,.35,.46,0,.27,0,0xab9771);b(g,w+.08,.075,.54,0,.47,0,0xd8c19a);b(g,w-.12,.02,.36,0,.515,0,0x4e5337);
    const count=Math.ceil(w/.55);for(let i=0;i<count;i++)plant(g,-w/2+(i+.5)*w/count,(i%2?-.05:.04),.45+(i%3)*.035,.27,true,false);
  }
  function chair(p,x,z,rotation=0,office=false,seatColor=C.sage){
    const g=group(p,x,z,rotation);r(g,.6,.16,.57,0,.58,0,fabric(office&&seatColor!==C.sage?seatColor:0x8b9c79),.025);
    const back=r(g,.59,.58,.15,0,.9,.245,fabric(seatColor),.025);back.rotation.x=-.08;
    r(g,.49,.4,.055,0,.92,.152,fabric(office&&seatColor!==C.sage?seatColor:0x8f9e7b),.018);
    if(office){b(g,.075,.32,.075,0,.3,0,metal);b(g,.26,.075,.28,0,.47,0,C.dark);b(g,.065,.42,.065,0,.69,.25,C.dark);b(g,.13,.025,.025,.25,.45,.06,C.dark);for(let i=0;i<5;i++){const arm=group(g,0,0,i*Math.PI*2/5);b(arm,.065,.065,.37,0,.12,.15,C.dark);for(const side of [-1,1]){const wheel=mesh(arm,new THREE.CylinderGeometry(.062,.062,.035,8),0x242b27,side*.045,.13,.31);wheel.rotation.z=Math.PI/2;}}for(const side of [-1,1]){b(g,.055,.23,.055,side*.34,.7,.07,C.dark);r(g,.09,.06,.38,side*.34,.84,0,C.dark,.018);}}
    else for(const x of [-.23,.23])for(const z of [-.2,.2])b(g,.065,.5,.065,x,.28,z,C.dark);
    return g;
  }
  function armchair(p,x,z,rotation=0){
    const g=group(p,x,z,rotation);r(g,1.06,.22,.91,0,.46,0,fabric(0x657953),.025);
    const back=r(g,.99,.6,.19,0,.83,.36,fabric(0x80916c),.025);back.rotation.x=-.12;
    r(g,.73,.19,.68,0,.66,-.05,fabric(0x91a07d),.03);
    r(g,.73,.38,.1,0,.88,.239,fabric(0x889974),.025).rotation.x=-.12;
    for(const side of [-1,1]){
      r(g,.155,.37,.95,side*.485,.69,0,fabric(0x7c8d65),.02);
      b(g,.165,.045,.92,side*.485,.892,-.005,fabric(0x879975));
      for(const z of [-.31,.31]){const leg=tapered(g,.08,.3,.08,side*.44,.26,z,timber(0x5b5140),.75);leg.rotation.z=side*-.06;}
    }return g;
  }
  function mug(p,x,y,z){
    const cup=group(p,x,z,.2);cup.position.y=y;
    const ceramic=surface('ceramic',C.cream);
    mesh(cup,new THREE.CylinderGeometry(.087,.069,.15,8,1,true),ceramic,0,0,0);
    mesh(cup,new THREE.CylinderGeometry(.069,.069,.018,8),ceramic,0,-.074,0);
    const coffee=mesh(cup,new THREE.CircleGeometry(.071,8),0x66442d,0,.051,0,false);coffee.rotation.x=-Math.PI/2;
    const rim=mesh(cup,new THREE.RingGeometry(.073,.087,8),ceramic,0,.076,0,false);rim.rotation.x=-Math.PI/2;
    mesh(cup,new THREE.TorusGeometry(.051,.017,4,8),ceramic,.105,-.005,0);
  }
  function papers(p,x,y,z,rotation=0){const g=group(p,x,z,rotation);b(g,.34,.035,.26,0,y,0,0xcec6ae);b(g,.31,.017,.24,0,y+.027,0,0xfff4d7);for(let i=0;i<3;i++)b(g,.19,.004,.013,-.015,y+.037,-.06+i*.042,0xc8beaa,false);}
  function monitor(p,x=0,z=0,variant=0,screenOffset=0){
    const sx=x+screenOffset;
    r(p,.38,.035,.27,sx,1.015,z,0x39433c,.012);b(p,.07,.23,.075,sx,1.125,z-.05,0x3c4840);
    const screen=group(p,sx,z-.08);screen.position.y=1.45;screen.rotation.x=-.08;
    r(screen,.88,.55,.085,0,0,0,0x28332f,.017);
    b(screen,.78,.45,.012,0,.017,.049,surface('screen',variant===2?0x436878:0x405c55),false);
    b(screen,.75,.019,.014,0,-.248,.049,0x4e5b52,false);b(screen,.019,.008,.015,.36,-.248,.058,surface('signal',0x9ead89),false);
    b(screen,.21,.22,.019,0,-.06,-.053,0x354239);for(let i=0;i<5;i++)b(screen,.26,.012,.007,-.15,.11-i*.031,-.056,0x202c28,false);
    b(screen,.034,.033,.01,-.337,.171,.059,0x8caa93,false);
    for(let i=0;i<4;i++)b(screen,.23+(i%2)*.13,.015,.006,-.09,.165-i*.07,.059,[0x80a191,0x637e75,0x9aafa0][i%3],false);
    r(p,.5,.025,.185,x,1.015,z+.4,0x515d52,.008);
    for(let row=0;row<3;row++)for(let col=0;col<9;col++)b(p,.039,.006,.037,x-.21+col*.05,1.032,z+.335+row*.05,0x9d9e88,false);
    r(p,.105,.05,.15,x+.38,1.025,z+.4,0x4d5c51,.023);b(p,.012,.006,.029,x+.38,1.052,z+.366,0xa7ac93,false);
    b(p,.025,.11,.025,sx,1.04,z-.23,0x434a3e,false);b(p,.075,.015,.075,sx,.999,z-.25,0x505448,false);
  }
  function table(p,w,d,x,z,h=.93,c=C.oak){const g=group(p,x,z);r(g,w,.13,d,0,h,0,timber(c===C.oak?0xe0c6a5:c),.022);b(g,w-.12,.06,d-.08,0,h-.08,0,timber(0xbca07d));for(const dx of [-w/2+.15,w/2-.15])for(const dz of [-d/2+.12,d/2-.12])b(g,.1,h-.11,.1,dx,(h-.1)/2,dz,C.dark);return g;}
  function cabinet(p,x,z,w=1,y=0,c=C.wood){
    const g=group(p,x,z);g.position.y=y;
    b(g,w-.08,.12,.49,0,.16,0,timber(0x6f5a43));b(g,w,.74,.58,0,.58,0,timber(c));r(g,w+.07,.075,.66,0,.997,0,timber(0xbe9b6f),.015);
    const doors=Math.max(2,Math.round(w/.7)),doorWidth=(w-.1)/doors;
    for(let i=0;i<doors;i++){const dx=-w/2+.05+(i+.5)*doorWidth;b(g,doorWidth-.027,.67,.045,dx,.585,.315,timber(c));b(g,doorWidth-.1,.51,.012,dx,.585,.343,timber(new THREE.Color(c).multiplyScalar(.91)));b(g,.023,.12,.028,dx+doorWidth*.31,.64,.369,brass);}
    return g;
  }
  function lamp(p,x,z,y=0){
    r(p,.27,.04,.27,x,y+.03,z,brass,.012);b(p,.035,.38,.035,x,y+.22,z,brass);
    const shade=mesh(p,new THREE.CylinderGeometry(.165,.258,.29,4,1,true),surface('shade',0xf1ddb5),x,y+.56,z);shade.rotation.y=Math.PI/4;
    for(const side of [-1,1]){
      b(p,.246,.018,.018,x,y+.71,z+side*.116,0xffedc9,false);b(p,.018,.018,.246,x+side*.116,y+.71,z,0xffedc9,false);
      b(p,.376,.018,.018,x,y+.409,z+side*.183,0xc6b38d,false);b(p,.018,.018,.376,x+side*.183,y+.409,z,0xc6b38d,false);
    }
    r(p,.09,.13,.09,x,y+.51,z,glow,.025);warmLight(p,x,y+.44,z+.08,5.2,3.2);
  }
  function taskLamp(p,x,z,y=0){
    const g=group(p,x,z);g.position.y=y;const dark=surface('metal',0x394238);
    mesh(g,new THREE.CylinderGeometry(.13,.145,.035,8),dark,0,.023,0);
    b(g,.029,.65,.032,0,.36,0,dark);
    const joint=mesh(g,new THREE.CylinderGeometry(.047,.047,.054,8),brass,0,.693,0);joint.rotation.x=Math.PI/2;
    const arm=b(g,.029,.35,.034,.104,.825,0,dark);arm.rotation.z=-.61;
    const head=group(g,.217,0);head.position.y=.986;head.rotation.z=.55;
    mesh(head,new THREE.CylinderGeometry(.057,.15,.16,8,1,true),surface('shade',0x3f4a3b),0,-.065,0);
    const bulb=mesh(head,new THREE.CircleGeometry(.128,8),glow,0,-.147,0,false);bulb.rotation.x=Math.PI/2;
  }
  function bookshelf(p,x,z,w=3.25,h=2.2,rotation=0){
    const g=group(p,x,z,rotation),rows=Math.max(1,Math.round(h/.55)),step=(h-.16)/rows,columns=Math.max(1,Math.round(w/1.05)),cell=(w-.16)/columns;
    b(g,w,h,.075,0,h/2,-.25,timber(0x67513a));b(g,w-.04,.12,.53,0,.15,0,timber(0x7f6447));
    for(const x of [-w/2,w/2])b(g,.11,h,.62,x,h/2,0,timber(0x93734e));
    for(let col=1;col<columns;col++)b(g,.065,h,.57,-w/2+.08+col*cell,h/2,0,timber(0xa8875c));
    for(let row=0;row<rows;row++){
      const yy=.19+row*step;b(g,w+.05,.07,.64,0,yy,0,timber(0xb08b60));
      for(let col=0;col<columns;col++){
        const left=-w/2+.11+col*cell,count=Math.max(2,Math.floor((cell-.08)/.12));
        for(let j=0;j<count;j++){
          const xx=left+.07+j*.119,index=row*11+col*7+j,color=[0x668063,0xb39567,0x435f4d,0xd3c4a3,0x927243,0x637c78][index%6];
          if(j===count-2&&(row+col)%2===0){hardback(g,xx+.045,yy+.054,.075,.24,.33,color);hardback(g,xx+.035,yy+.152,.069,.22,.31,0xbda77c,-.06);break;}
          const height=Math.min(step-.12,.25+(index%5)*.028),book=group(g,xx,.075+(index%3)*.012);book.position.y=yy+.037;
          if(j===count-1&&(row+col)%3===1)book.rotation.z=-.13;
          b(book,.09,height,.33,0,height/2,0,color);b(book,.095,.012,.34,0,height-.006,0,color);
          b(book,.066,height-.025,.015,0,height/2,-.175,0xded2b7);b(book,.069,.013,.009,0,.065,.174,0xc8bfa4,false);b(book,.052,.009,.009,0,height-.075,.174,0xd2c8b0,false);
        }
      }
    }
    r(g,w+.12,.105,.69,0,h+.045,0,timber(0xb39065),.012);
    if(h>1.5){plant(g,-w*.32,0,.42,h+.105);plant(g,w*.32,0,.48,h+.105);}
    else {hardback(g,-w*.27,h+.108,.03,.35,.3,0x7d8d67,-.08);hardback(g,-w*.27,h+.205,.03,.33,.29,0xc8b38d,.06);plant(g,w*.28,0,.43,h+.1);}
    return g;
  }
  function wallPrint(p,x,y,z,w,h,index){b(p,w+.12,h+.12,.09,x,y,z,0x655941);b(p,w,h,.017,x,y,z+.06,0xe4dcc6);const art=new THREE.Mesh(new THREE.PlaneGeometry(w-.1,h-.1),printMaterial(index));art.position.set(x,y,z+.072);p.add(art);return art;}
  function sofa(p,x,z,rotation=0){
    const g=group(p,x,z,rotation);for(const x of [-1.18,1.18])for(const z of [-.34,.34])b(g,.12,.2,.12,x,.19,z,timber(0x655b47));
    r(g,2.8,.36,1.06,0,.46,0,fabric(0x617451),.03);r(g,2.72,.68,.23,0,.8,-.43,fabric(0x738461),.035);
    for(const x of [-1.3,1.3])r(g,.22,.46,1.04,x,.7,0,fabric(0x80916c),.04);
    for(const [i,x] of [-.8,0,.8].entries()){
      r(g,.76,.22,.76,x,.735,.055,fabric(i===1?0x94a07e:0x879873),.045);
      const cushion=r(g,.77,.46,.21,x,.98,-.275,fabric(0x84936e),.038);cushion.rotation.x=-.13;
      b(g,.68,.014,.011,x,.723,.43,fabric(0x6e7e5c),false);
    }
    const pillow=r(g,.41,.36,.16,-.99,.99,-.09,fabric(0xb2b393),.045);pillow.rotation.z=.18;pillow.rotation.x=-.2;
    return g;
  }


  // Continuous oak boards and a dark cutaway slab keep the whole floor legible.
  b(parent,22.2,.38,14.2,0,-.18,0,0x4c5147);b(parent,22,.1,14,0,.035,0,0x8f806a);
  for(let row=0;row<28;row++)for(let col=-1;col<9;col++){
    const edge=-11+col*2.8+(row%2)*1.4,x=Math.max(-11,edge),w=Math.min(edge+2.774,11)-x;if(w<=0)continue;
    const plank=new THREE.Mesh(new THREE.PlaneGeometry(w,.482),timber([0xf4dfc3,0xead6bc,0xeedbbf,0xf6e4cd,0xe9d7c1][(row*7+col*3+10)%5]));const uv=plank.geometry.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*w*.7+col*.29,uv.getY(i)*.34+row*.13);plank.rotation.x=-Math.PI/2;plank.position.set(x+w/2,floorY+.008,-6.75+row*.5);plank.receiveShadow=true;parent.add(plank);
  }
  if (kit.living) {
    b(parent,22.15,.82,.24,0,.49,-7,0x8c8978);b(parent,21.92,.64,.06,0,.48,-6.845,C.wall);
    for (let x=-11;x<=11;x+=2.75) b(parent,.10,2.16,.20,x,1.96,-6.95,0x53584f);
    b(parent,22.15,.12,.26,0,.90,-6.95,0x53584f);
  } else { b(parent,22.15,2.9,.24,0,1.53,-7,0x8c8978);b(parent,21.92,2.38,.06,0,1.33,-6.845,C.wall); }
  b(parent,22.25,.13,.33,0,3.02,-7,0x53584f);
  b(parent,.23,.6,14,-11,.35,0,0x9e9782);
  b(parent,.23,2.9,14,11,1.53,0,0x888877);b(parent,.06,2.55,13.75,10.855,1.4,0,C.wall);b(parent,.33,.13,14.1,11,3.02,0,0x53584f);
  b(parent,21.85,.12,.09,0,.18,-6.79,0x998665);b(parent,.09,.12,13.75,10.79,.18,0,0x998665);

  // Mission table: a whiteboard, six seats, and room for the squad to gather.
  const mission=part(parent,'whiteboard',...layout.board);
  warmLight(mission,-.9,2.6,.65,4.5,4.8);
  b(mission,3.85,1.55,.15,0,1.72,0,C.wood);b(mission,3.67,1.39,.055,0,1.72,.108,0xf0e6ce);b(mission,3.8,.055,.22,0,1.01,.17,0xb6a581);
  for(const x of [-1.5,1.5]){b(mission,.075,1.02,.09,x,.6,0,C.dark);b(mission,.45,.07,.43,x,.15,0,C.dark);}
  for(let i=0;i<8;i++){const paper=b(mission,.42,.29,.013,-1.4+(i%4)*.88,2.07-Math.floor(i/4)*.54,.144,0xd1c3a5,false);const marks=[0,1,2].map(line=>b(paper,.26-line*.035,.016,.006,-.015,.075-line*.068,.011,0xa69c80,false));boardPapers.push({mesh:paper,marks,index:i,floor:parent.userData.floor});}
  for(let i=0;i<4;i++)b(mission,.36,.018,.017,-1.36+i*.88,1.24,.15,0xb6af92,false);
  table(mission,3.55,1.4,0,2.6);for(const x of [-1.18,0,1.18]){chair(mission,x,3.64);chair(mission,x,1.61,Math.PI);}
  b(mission,.66,.018,.39,-.25,1.01,2.65,0x4e6651);papers(mission,-1.17,1.02,2.4,.12);papers(mission,.75,1.02,2.85,-.1);mug(mission,-.9,1.095,2.7);mug(mission,1.3,1.095,2.35);
  plant(parent,-10.28,-4.1,1.03);

  const library=part(parent,'shelf',...layout.shelf);warmLight(library,-1,2.5,.8,2.5,3.7);bookshelf(library,0,0,3.7,2.15);
  table(library,1.4,.84,.2,1.27);chair(library,.6,2.07,.22,true);papers(library,-.2,1.02,1.35,.2);openBook(library,.5,1.015,1.1,-.24);b(library,.48,.79,.67,-.25,.52,1.27,timber(0xb28c5c));b(library,.4,.27,.025,-.25,.72,1.618,timber(0xc29c69));b(library,.16,.025,.025,-.25,.72,1.64,brass);taskLamp(library,-.4,1,1.01);
  // Founder office separated by a waist-height display wall and a warm credenza.
  rug(parent,5.25,5.4,-8.1,3.77,0xb9ac93);
  const founder=part(parent,'founder',...layout.founder);
  b(founder,5.1,2.02,.18,0,1.11,-1.61,0xd9c7a4);b(founder,5.17,.09,.25,0,2.165,-1.61,0xead8b3);
  cabinet(founder,0,-1.07,3.9,0,0xa88b68);wallPrint(founder,-.6,1.65,-1.5,1.37,.72,0);lamp(founder,1.52,-1.02,1.02);plant(founder,-1.72,-1.04,.55,1.02);
  const fd=table(founder,3.7,1.28,0,.7,.99,0x93714c);b(fd,3.48,.72,.13,0,.57,.515,timber(0x76563c));for(const dx of [-1.14,0,1.14]){b(fd,1.06,.58,.025,dx,.56,.596,timber(0x826247));b(fd,1.03,.022,.02,dx,.842,.614,timber(0x9b7951));};for(const x of [-1.43,1.43]){b(fd,.54,.78,.8,x,.54,0,timber(0x94785b));for(let j=0;j<3;j++){b(fd,.49,.2,.025,x,.32+j*.22,.415,timber(0xb0936e));b(fd,.14,.025,.022,x,.36+j*.22,.437,0x514a36);}}
  b(founder,1.3,.012,.55,0,1.068,.42,fabric(0x61766b),false);b(founder,.41,.035,.14,.93,1.076,.38,timber(0x88724f));b(founder,.26,.015,.022,.94,1.1,.38,brass,false);
  const workstation=group(founder,0,.7,Math.PI);monitor(workstation,0,0,0,-.38);penCup(founder,-1.47,1.064,.9);hardback(founder,-1.12,1.066,.69,.35,.29,0xe3d6b8,-.1);papers(founder,-1.03,1.174,.67,-.12);mug(founder,1.17,1.145,.82);chair(founder,0,-.28,Math.PI,true,0x3a4942);armchair(founder,-1.48,2.25,.26).scale.setScalar(1.1);armchair(founder,1.48,2.25,-.26).scale.setScalar(1.1);plant(founder,2.02,-1.18,.96);

  // Shared benches: eight places, six resident agents and two guest positions.
  rug(parent,8.6,5.2,1,-3.8,0xb9bf9f);
  const team=part(parent,'team',0,0);
  for(const [i,station] of layout.workstations.entries()){
    const desk=group(team,station.x,station.z,station.facing);table(desk,1.93,1.18,0,0);monitor(desk,0,-.16,i%3);chair(desk,0,1,0,true);
    b(desk,.51,.76,.77,.63,.48,0,0x72816a);for(let j=0;j<3;j++){b(desk,.45,.19,.02,.63,.26+j*.22,.405,0x7c8970);b(desk,.13,.022,.021,.63,.3+j*.22,.425,0xc3bea3);}
    papers(desk,-.59,1.016,.22,(i%2?-.14:.14));mug(desk,.57,1.09,.28);if(i%2===0)plant(desk,-.68,-.28,.32,1.0);else penCup(desk,-.72,.998,-.24);if(i===1||i===4)hardback(desk,-.59,1.018,.22,.31,.23,i===1?0xb59c78:0x667c70,.11);
    if(station.guest)b(desk,.3,.025,.16,.56,1.02,-.35,0xc6b0ce);
  }
  const printer=part(parent,'shelf',-2.7,-6.2);
  r(printer,.89,.7,.68,0,.49,0,0x626b63,.018);for(const yy of [.3,.58]){b(printer,.8,.22,.025,0,yy,.357,0x747e73);b(printer,.25,.024,.025,0,yy+.057,.379,0x343e37);}
  b(printer,.78,.26,.65,-.035,.975,-.035,0x7e877a);b(printer,.64,.065,.54,-.085,1.145,-.07,0x9b9f8b);b(printer,.59,.018,.47,-.085,1.185,-.07,0xb2b19d);
  b(printer,.63,.078,.12,0,.86,.345,0x28352f);b(printer,.48,.021,.31,0,.832,.415,0xbfc0a9);papers(printer,-.01,.855,.44,-.015);
  const copierPanel=r(printer,.25,.025,.16,.24,1.064,.276,0x3d504a,.008);copierPanel.rotation.x=.2;b(printer,.12,.008,.074,.23,1.083,.266,surface('screen',0x718e7d),false);
  if (!kit.living) wallPrint(parent,-.8,1.95,-6.76,1.13,.8,0);
  if (!kit.living) for(let i=0;i<8;i++)b(parent,.37,.34,.045,1.4+(i%4)*.41,1.96-Math.floor(i/4)*.4,-6.76,[0xa1ad76,0xd8ba7b,0x819565][i%3]);
  planter(parent,-3.42,-.7,1.9,Math.PI/2);planter(parent,4.35,-.25,1.8);planter(parent,-2.45,1.95,1.25);

  // Operations room: a framed partition and two lit equipment racks.
  rug(parent,4.85,3.75,8.36,-5,0xb4b09a);
  const ops=part(parent,'operations',...layout.operations);
  b(parent,.16,.64,3.65,5.92,.43,-5.09,0x858773);b(parent,.22,.11,3.68,5.92,.795,-5.09,0x566153);
  for(const z of [-6.86,-5.09,-3.32])b(parent,.14,2.05,.1,5.92,1.845,z,0x586353);
  for(const z of [-5.975,-4.205])b(part(parent,'operations',5.92,z),.021,1.97,1.66,0,1.83,0,surface('glass',0xa5b8ad),false);
  b(parent,4.9,.17,.25,8.36,2.87,-3.22,0x555b50);for(const x of [5.93,10.75])b(parent,.21,2.72,.21,x,1.47,-3.22,0x5e6557);
  for(const dx of [-1.27,1.58]){
    b(ops,1.05,2.3,.89,dx,1.23,-.71,0x404c40);b(ops,.92,2.13,.03,dx,1.23,-.235,0x2e3a31);b(ops,1.09,.09,.94,dx,2.43,-.71,0x616753);for(const side of [-1,1])b(ops,.039,2.1,.028,dx+side*.437,1.23,-.205,0x6b7566);b(ops,.035,.3,.05,dx+.395,1.39,-.175,0x7d8575);
    for(let j=0;j<7;j++){b(ops,.81,.22,.04,dx,.37+j*.28,-.20,0x4c5746);b(ops,.035,.045,.017,dx+.29,.39+j*.28,-.171,surface('signal',0x6bb789));b(ops,.055,.018,.014,dx+.16,.39+j*.28,-.17,0x709b7b);for(let k=0;k<3;k++)b(ops,.23,.015,.01,dx-.12,.31+j*.28+k*.034,-.174,0x303e34,false);}
  }
  bookshelf(ops,-.27,-.67,.62,2.15);const console=group(ops,.62,.45);table(console,1.05,.7,0,0);monitor(console,0,-.1,2);chair(console,0,.94,0,true);plant(parent,10.3,-5.75,.9);plant(parent,5.9,-3.25,.75);
  b(ops,2.4,.11,.35,.12,2.6,-1.03,0xb19870);b(ops,2.15,.045,.2,.12,2.535,-.95,glow);warmLight(ops,.12,2.35,-.5,6,3.4);


  // Review room: design studies are decoration; orange pins show actual mission evidence.
  rug(parent,4.95,5.25,8.37,-.05,0xdb8c5c);
  const review=part(parent,'review',10.72,-.38);review.rotation.y=-Math.PI/2;
  b(review,4.28,1.67,.13,0,1.62,0,0x424e43);b(review,4.1,1.5,.04,0,1.62,.09,0xe5dec7);
  for(let i=0;i<3;i++){
    wallPrint(review,-1.35+i*1.35,1.63,.115,1.19,1.25,i+1);
    const mesh=b(review,.2,.075,.022,-1.35+i*1.35,2.34,.23,0xf1e5cb),pin=b(review,.1,.09,.028,-1.35+i*1.35,2.34,.249,0xfe5600);reviewPapers.push({mesh,pin,floor:parent.userData.floor});
  }
  for(const x of [-1.6,0,1.6]){b(review,.12,.24,.15,x,2.74,-.07,0x454b3d);b(review,.23,.12,.24,x,2.68,.04,0x424a3b);b(review,.17,.035,.17,x,2.604,.075,glow);warmLight(review,x,2.5,.33,7,3.5);}
  for(const [x,z] of [[7.35,-1.15],[7.35,1.0],[9.05,1.0]]){const seat=part(parent,'review',x,z);table(seat,.79,1.6,0,0,.46,0x596849);r(seat,.82,.18,1.65,0,.59,0,fabric(0x94a17d),.035);}
  const reviewCab=cabinet(review,2.8,-.05,.85);lamp(reviewCab,0,0,1.02);plant(parent,10.27,2.95,.95);

  // Lounge and a tall, planted bookcase separate social space from arrival.
  rug(parent,5.95,4.26,4.65,4.57,0xb7bea0);
  const lounge=part(parent,'lounge',...layout.lounge);sofa(lounge,.35,-.72);sofa(lounge,.35,1.63,Math.PI);
  table(lounge,2.13,.86,.35,.48,.55,0xa67b4a);hardback(lounge,.13,.626,.47,.42,.3,0xd4c49f,-.1);hardback(lounge,.08,.723,.5,.36,.28,0xf0e1bf,.06);mug(lounge,1.03,.704,.52);
  for(const [x,z] of [[2.12,-.85],[2.12,1.72]]){table(lounge,.61,.6,x,z,.58);lamp(lounge,x,z,.66);}
  // The living floor leaves shoulder clearance beside the lounge bookcase.
  bookshelf(lounge,kit.living?-2.48:-2.08,.62,3.4,1.18,-Math.PI/2);plant(lounge,-2.12,-1.32,.64);plant(lounge,-2.12,2.56,.8);plant(parent,9.9,5.8,1.12);

  // Recessed elevator doors, deep jambs, a limestone apron and roof tiles.
  const entrance=part(parent,'entrance',...layout.entrance);entrance.scale.x=1.1;
  b(entrance,4.3,.32,2.17,0,-.1,.12,0x53594e);b(entrance,4.15,.1,2.07,0,.11,.12,0x9f947e);
  for(let row=0;row<2;row++)for(let col=0;col<3;col++)b(entrance,1.36,.018,1.015,-1.38+col*1.38,.172,-.4+row*1.035,[0xdbcaab,0xd6c3a1,0xe1d1b3][(row+col)%3],false);
  b(entrance,4.02,2.73,.12,0,1.53,-.2,0xaaa48f);
  b(entrance,.79,2.73,.48,-1.615,1.53,.03,0xd1c5ae);b(entrance,1.65,2.73,.48,1.185,1.53,.03,0xd1c5ae);
  b(entrance,1.62,.45,.48,-.48,2.67,.03,0xd1c5ae);
  for(const x of [-1.95,1.95])b(entrance,.18,2.7,1.15,x,1.49,-.43,0xb8b19b);
  b(entrance,4.1,.12,1.24,0,2.96,-.36,0x6e7568);
  for(let col=0;col<3;col++)b(entrance,1.29,.055,1.17,-1.33+col*1.33,3.047,-.36,[0x838d80,0x758073,0x9ca495][col]);
  b(entrance,.43,.15,.47,.64,3.13,-.58,0xb2bcb0);b(entrance,.28,.1,.31,.64,3.245,-.59,0xc4cdc0);
  b(entrance,1.79,2.32,.06,-.48,1.39,.03,0x394137);
  const doors=[];
  for(const [index,dx] of [-.88,-.08].entries()) {
    const door=group(entrance,dx,0);door.userData.dynamic=!!kit.living;door.userData.closedX=dx;door.userData.side=index===0?-1:1;
    b(door,.78,2.16,.052,0,1.35,.092,metal);
    b(door,.024,.1,.018,index===0?.31:-.31,1.17,.129,0xd0cfb6,false);doors.push(door);
  }
  if (kit.living) {
    b(entrance,1.55,2.12,.015,-.48,1.35,.065,surface('shade',0xe9c893),false);
    const cabin=new THREE.PointLight(0xffc47c,4,3.5,2);cabin.position.set(-.48,1.6,.3);entrance.add(cabin);
  }
  for(const x of [-1.38,.42])b(entrance,.115,2.34,.3,x,1.4,.194,surface('metal',0xa5aa9d));
  b(entrance,1.91,.11,.31,-.48,2.585,.19,surface('metal',0xa5aa9d));
  b(entrance,1.81,.04,.4,-.48,.245,.23,metal);for(const z of [.21,.28,.35])b(entrance,1.71,.006,.013,-.48,.269,z,0x798073,false);
  if (!kit.living) b(entrance,.018,2.16,.015,-.48,1.35,.13,0x3e463b);
  b(entrance,.68,.027,.022,-.48,2.51,.24,glow,false);warmLight(entrance,-.48,2.37,.42,9,3.5);
  const arrowShape=new THREE.Shape();arrowShape.moveTo(-.13,.07);arrowShape.lineTo(.13,.07);arrowShape.lineTo(0,-.09);arrowShape.closePath();
  mesh(entrance,new THREE.ExtrudeGeometry(arrowShape,{depth:.025,bevelEnabled:false}),surface('unlit',0xfe6700),-.48,2.76,.28,false);
  r(entrance,.17,.37,.07,-1.59,1.17,.299,0x485246,.012);
  b(entrance,.065,.07,.012,-1.59,1.255,.341,surface('signal',0xee9b43),false);
  for(const yy of [1.16,1.075]){const button=mesh(entrance,new THREE.CylinderGeometry(.024,.024,.014,8),surface('metal',0xbcbd9d),-1.59,yy,.345,false);button.rotation.x=Math.PI/2;}
  mesh(entrance,new THREE.PlaneGeometry(1.48,.56),signMaterial(floorInfo.title),1.14,2.08,.278,false);
  plant(entrance,-1.62,.76,.75);plant(entrance,1.64,.65,.84);plant(parent,-2.6,5.8,.73);planter(parent,-8.1,6.65,2.9);
  return {founderSeat:[layout.founder[0],layout.founder[1]-.28],doors};
}
