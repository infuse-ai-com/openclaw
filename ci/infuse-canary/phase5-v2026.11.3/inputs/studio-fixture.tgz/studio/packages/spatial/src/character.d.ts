import type { Group } from 'three';
export interface CharacterAppearance {
  shirt: number; hair: number; skin: number;
  pants?: number; shoes?: number;
  detail: 'plain' | 'badge' | 'headphones' | 'glasses' | 'cap' | 'beard' | 'tie';
}
export interface CharacterPose { seated: number; stride: number; walking: boolean; gesture: number; working: boolean; wave?: number }
export function createOfficeCharacter(appearance: CharacterAppearance): {
  group: Group;
  pose(value: CharacterPose): void;
  select(value: boolean): void;
  dispose(): void;
};
