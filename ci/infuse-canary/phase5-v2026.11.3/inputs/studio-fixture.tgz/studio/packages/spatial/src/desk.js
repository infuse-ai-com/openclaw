import * as THREE from 'three';
import { paintDeskScreensaver } from './desk-screensaver.js';
import { addDeskDecoration } from './desk-decoration.js';
import { createDeskRoom } from './desk-room.js';

/** A seated, pickable workspace with a visible-only screensaver and live desktop surface. */
export function createDesk(host, {onSelect, onFailure, tokens='—', overview={}, desktopCanvas=null, exampleData=false, selected=null, cameraView, onCameraChange=()=>{}, onMonitorBounds=()=>{}, onDesktopInput, arrival=false, onArrivalStart=()=>{}, onArrivalComplete=()=>{}}) {
  let renderer;
  try { renderer = new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'}); }
  catch { onFailure(); return {destroy(){},select(){},cameraAction(){},update(){},finishArrival(){}}; }
  renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  renderer.shadowMap.enabled=true;
  // Reuse shadows between screen frames; refresh them when clock lighting changes.
  renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;
  renderer.shadowMap.type=THREE.PCFShadowMap;
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure=1.25;
  renderer.domElement.setAttribute('role','img');
  renderer.domElement.tabIndex=0;
  renderer.domElement.setAttribute('aria-describedby','desk-camera-help');
  renderer.domElement.setAttribute('aria-label','Interactive view from your desk. Arrow keys look around, plus and minus zoom, Home resets your seat. Use the Desk objects buttons to open an object.');
  host.append(renderer.domElement);
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(64,1,.1,70);
  // The eye stays in the chair: looking around never orbits behind the monitor.
  camera.position.set(0,4.6,5.2);
  const home={yaw:0,pitch:-.11,zoom:1,alignment:0};
  const view={...home,...cameraView};
  const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
  const materials=new Map(),textures=[],targets=[],outlines=new Map();
  function material(color){if(!materials.has(color))materials.set(color,new THREE.MeshStandardMaterial({color,roughness:.85}));return materials.get(color);}
  function box(parent,w,h,d,x,y,z,color){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material(color));mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;}
  function object(id,x,y,z){const group=new THREE.Group();group.position.set(x,y,z);group.userData.deskObject=id;scene.add(group);targets.push(group);return group;}
  function screen(parent,w,h,x,y,z,width,height,paint){
    const surface=document.createElement('canvas');surface.width=width;surface.height=height;
    paint(surface.getContext('2d'),width,height);
    const texture=new THREE.CanvasTexture(surface);texture.colorSpace=THREE.SRGBColorSpace;textures.push(texture);
    texture.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:texture,toneMapped:false}));
    mesh.position.set(x,y,z);parent.add(mesh);
    return {mesh,repaint(){paint(surface.getContext('2d'),width,height);texture.needsUpdate=true;}};
  }
  function display(parent,w,h,x,y,z,lines,{background='#263c30',color='#e4ebd2'}={}){
    return screen(parent,w,h,x,y,z,768,384,ctx=>{
      ctx.fillStyle=background;ctx.fillRect(0,0,768,384);ctx.fillStyle=color;
      (typeof lines==='function'?lines():lines).forEach((line,i)=>{ctx.font=`${i===0?'500 38':'600 100'}px sans-serif`;ctx.fillText(line,46,i===0?82:235,680);});
      ctx.fillStyle='#fe7d3e';ctx.fillRect(48,310,100,8);
    });
  }
  function outline(group,w,d){const ring=new THREE.Group();
    for(const side of [-1,1]){box(ring,w,.025,.045,0,-.02,side*d/2,0x718466);box(ring,.045,.025,d,side*w/2,-.02,0,0x718466);}
    group.add(ring);outlines.set(group.userData.deskObject,ring);
  }
  // Voxel furniture shares the office's timber, paper, sage and Foundry palette.
  // A continuous room replaces the floating diorama; the desk is the foreground.
  scene.background=new THREE.Color(0xe8e5da);
  // A real object in the room: a shallow LCD chassis, wall mounts and luminous face.
  const wall=object('wall',0,7.14,-3.76);
  // Keep the larger overview above the foreground monitor from the seated view.
  wall.scale.set(1.15,1.15,1);
  for(const x of [-2.6,2.6])box(wall,.45,1.8,.34,x,0,-.22,0x283732);
  box(wall,9.8,3,.22,0,0,0,0x222f2d);
  box(wall,9.65,2.86,.045,0,0,.131,0x4d6259);
  const wallScreen=screen(wall,9.42,2.66,0,.015,.16,1536,434,ctx=>{
    const text=(value,x,y,size,color='#e7f0e9',weight='500',width=1400)=>{ctx.fillStyle=color;ctx.font=`${weight} ${size}px sans-serif`;ctx.fillText(String(value),x,y,width);};
    const bg=ctx.createLinearGradient(0,0,1536,434);bg.addColorStop(0,'#112820');bg.addColorStop(1,'#1b3437');ctx.fillStyle=bg;ctx.fillRect(0,0,1536,434);
    text('STUDIO / DAILY OVERVIEW',48,54,26,'#b2cbbd');
    text(exampleData?'LOCAL DEMO':'RECORDED WORK',1210,54,23,'#f4b77d');
    ctx.fillStyle='#3b554a';ctx.fillRect(48,84,1440,2);
    text('TOKENS YESTERDAY',48,136,23,'#a1bbaa');text(tokens,48,245,96,'#e9f0dc','600');
    text(exampleData?'EXAMPLE USAGE':'NOT CONNECTED',50,284,19,'#f4b77d');
    for(const x of [585,1080]){ctx.fillStyle='#3b554a';ctx.fillRect(x,118,2,178);}
    text(exampleData?'DECISIONS TO MAKE':'ITEMS NEEDING YOU',630,136,23,'#a1bbaa');text(overview.decisions??'—',630,245,96,'#e9f0dc','600');
    text(exampleData?'ALL PROJECTS':'INSPECTED RECORDS',634,284,19,'#a1bbaa');
    text(exampleData?'SAVED MISSIONS':'MISSIONS IN VIEW',1125,136,23,'#a1bbaa');text(overview.missions??'—',1125,245,96,'#e9f0dc','600');
    text(overview.project??'Current project',1128,284,19,'#a1bbaa','500',350);
    if(exampleData && Number.isFinite(overview.input) && Number.isFinite(overview.output)) {
    const total=overview.input+overview.output;
    const share=total>0?overview.input/total:0;
    ctx.fillStyle='#9dbea0';ctx.fillRect(48,332,1440*share,14);
    ctx.fillStyle='#eea772';ctx.fillRect(48+1440*share,332,1440*(1-share),14);
    text(`INPUT  ${overview.input.toLocaleString('en-US')}`,48,390,23,'#b9d1bb');
    text(`OUTPUT  ${overview.output.toLocaleString('en-US')}`,1165,390,23,'#f4b77d');
    } else {text(overview.status??'Open the wall display to inspect project coverage.',48,355,24,'#b9d1bb');text('Token usage is not connected.',48,398,21,'#a1bbaa');}
  });
  box(wall,9.1,.025,.03,0,-1.45,.14,0x91c5aa);
  const wallSelection=new THREE.Group();wall.add(wallSelection);
  for(const x of [-4.92,4.92])box(wallSelection,.035,3.04,.035,x,0,.16,0x718466);
  for(const y of [-1.52,1.52])box(wallSelection,9.87,.035,.035,0,y,.16,0x718466);
  outlines.set('wall',wallSelection);

  box(scene,7.8,.04,4.5,0,-.035,.6,0x97a388);
  for(let i=0;i<9;i++)box(scene,7.8,.015,.035,0,-.007,-1.35+i*.48,0xb7bea8);
  box(scene,8,.25,3.8,0,2,0,0xa5744b);
  for(let i=0;i<16;i++)box(scene,.46,.025,3.72,-3.72+i*.495,2.14,0,i%3===0?0xbb8b5e:0xb58559);
  for(const x of [-3.45,3.45]){box(scene,.18,1.92,.25,x,.97,-1.3,0x39483a);box(scene,.18,1.92,.25,x,.97,1.3,0x39483a);box(scene,.2,.18,2.8,x,.15,0,0x39483a);}
  box(scene,6.9,.2,.15,0,.6,-1.3,0x39483a);
  box(scene,4.2,.035,2.6,-.15,2.18,.25,0x52634d);
  const monitorWidth=3.68,monitorHeight=monitorWidth*9/16,monitorPixels={width:1920,height:1080};
  const monitor=object('monitor',-.25,2.23,-.55);
  // A 16:9 Full HD screen. Preserve its lower edge and give the extra height to the top.
  box(monitor,1.55,.09,.8,0,.04,0,0x6b7770);
  box(monitor,.2,.64,.2,0,.37,-.22,0x48564f);
  box(monitor,monitorWidth+.26,monitorHeight+.26,.19,0,1.65,-.22,0x202e2b);
  box(monitor,monitorWidth+.16,monitorHeight+.16,.025,0,1.66,-.115,0x526158);
  let saverTime=0;
  const monitorScreen=screen(monitor,monitorWidth,monitorHeight,0,1.68,-.097,monitorPixels.width,monitorPixels.height,(ctx,width,height)=>{
    if(selected!=='monitor'){paintDeskScreensaver(ctx,width,height,saverTime);return;}
    ctx.fillStyle='#10231f';ctx.fillRect(0,0,width,height);
    if(desktopCanvas?.width && desktopCanvas?.height){
      const scale=Math.min(width/desktopCanvas.width,height/desktopCanvas.height);
      const w=desktopCanvas.width*scale,h=desktopCanvas.height*scale;
      ctx.drawImage(desktopCanvas,(width-w)/2,(height-h)/2,w,h);return;
    }
    ctx.save();ctx.scale(width/1280,height/720);
    ctx.fillStyle='#aec3b3';ctx.font='500 22px sans-serif';ctx.fillText('INFUSE / WORKBENCH',50,60);
    ctx.fillStyle='#e6eddd';ctx.font='500 62px sans-serif';ctx.fillText('Your workspace.',50,330);
    ctx.fillStyle='#aec3b3';ctx.font='28px sans-serif';ctx.fillText(onDesktopInput?'Connect using the controls above.':'Continue in the overlay on your desk.',52,390);
    ctx.fillStyle='#f4b57d';ctx.font='21px sans-serif';ctx.fillText(exampleData?'DESKTOP PREVIEW':'PERSONAL DESKTOP',52,620);ctx.restore();
  });
  box(monitor,.07,.018,.025,monitorWidth/2-.095,.52,-.114,0xa9dab2);
  // The keyboard shares the monitor action.
  const keyboard=object('monitor',-.25,2.23,.9);
  box(keyboard,2.8,.1,.82,0,.03,0,0xa7b2a5);
  for(let row=0;row<4;row++)for(let col=0;col<14;col++)box(keyboard,.16,.025,.13,-1.22+col*.187,.095,-.26+row*.16,0x38463e);
  // A faceted wireless mouse: chamfered shell, split buttons and a ribbed wheel.
  const mouse=new THREE.Group();mouse.position.set(1.63,2.2,.85);mouse.rotation.y=-.08;scene.add(mouse);
  box(mouse,.36,.045,.59,0,.023,0,0x46534b);
  const mouseShape=new THREE.Shape();
  [[-.14,-.33],[.14,-.33],[.2,-.24],[.21,.16],[.14,.32],[-.14,.32],[-.21,.16],[-.2,-.24]].forEach(([x,z],i)=>{
    if(i===0)mouseShape.moveTo(x,-z);else mouseShape.lineTo(x,-z);
  });
  mouseShape.closePath();
  const mouseShell=new THREE.Mesh(new THREE.ExtrudeGeometry(mouseShape,{depth:.12,steps:1,bevelEnabled:true,bevelSize:.025,bevelThickness:.025,bevelSegments:1}),material(0xc3c9bb));
  mouseShell.rotation.x=-Math.PI/2;mouseShell.position.y=.055;mouseShell.castShadow=mouseShell.receiveShadow=true;mouse.add(mouseShell);
  box(mouse,.29,.025,.24,0,.195,.13,0xd2d4c5);
  for(const x of [-.1,.1])box(mouse,.175,.026,.25,x,.194,-.17,0xe0e1d3);
  box(mouse,.025,.008,.25,0,.187,-.17,0x46534b);
  box(mouse,.065,.014,.16,0,.204,-.13,0x46534b);
  box(mouse,.04,.045,.115,0,.228,-.13,0x7b8978);
  for(let i=0;i<4;i++)box(mouse,.042,.006,.012,0,.253,-.17+i*.027,0x38463e);
  for(const z of [-.04,.065])box(mouse,.018,.035,.075,-.226,.12,z,0x687960);
  box(mouse,.022,.008,.027,0,.212,.025,0x91b397);
  const meter=object('tokens',3.05,2.23,-.55);outline(meter,1.9,1.1);
  box(meter,1.7,.95,.65,0,.48,0,0x314638);
  const meterScreen=display(meter,1.5,.73,0,.5,.331,()=>[exampleData?'YESTERDAY · DEMO':'YESTERDAY',tokens],{background:'#c7d4ac',color:'#28452e'});
  box(meter,1.9,.08,.85,0,.02,0,0x283c31);
  const tray=object('inbox',-3.05,2.23,.25);tray.rotation.y=.12;outline(tray,1.65,1.9);
  box(tray,1.5,.1,1.7,0,.03,0,0x435b42);
  for(const x of [-.72,.72])box(tray,.08,.3,1.7,x,.2,0,0x435b42);
  box(tray,1.5,.3,.08,0,.2,-.81,0x435b42);
  for(let i=0;i<4;i++)box(tray,1.23,.035,1.42,i*.035-.04,.12+i*.04,0,0xeae7d4);
  for(let i=0;i<4;i++)box(tray,.78,.008,.025,-.02,.266,-.4+i*.15,0xa3ac94);
  // A full page block between two covers makes the notebook sit visibly on the timber.
  const notebook=object('notebook',2.65,2.19,.95);notebook.rotation.y=-.18;outline(notebook,1.4,1.5);
  box(notebook,1.3,.04,1.42,0,.02,0,0x994c29);
  box(notebook,1.22,.24,1.35,0,.16,0,0xe8e2cc);
  box(notebook,1.3,.04,1.42,0,.3,0,0xcc6735);box(notebook,.1,.32,1.42,-.59,.16,0,0x994c29);
  box(notebook,.62,.014,.42,.05,.33,-.18,0xf3e9d0);box(notebook,.06,.05,1.1,.83,.02,.05,0x273d2f);
  // A lamp and a block-leaf plant make the desk feel inhabited.
  box(scene,.65,.08,.65,-3.65,2.23,-1.2,0x304536);box(scene,.09,1.8,.09,-3.65,3.1,-1.2,0x304536);
  const arm=box(scene,1.25,.09,.09,-3.35,3.94,-1.2,0x304536);arm.rotation.z=-.15;
  box(scene,.65,.3,.52,-2.95,3.75,-1.2,0x627859);box(scene,.52,.025,.4,-2.95,3.59,-1.2,0xffd18b);
  box(scene,.7,.7,.7,4.25,.36,-2.1,0xbf7953);box(scene,.6,.02,.6,4.25,.72,-2.1,0x504833);
  for(let i=0;i<7;i++){const angle=i*2.4,x=4.25+Math.cos(angle)*.32,z=-2.1+Math.sin(angle)*.32;box(scene,.1,.9,.1,x,.95,z,0x4f6841);const leaf=box(scene,.34,.65,.3,x,1.48+(i%3)*.18,z,i%2?0x6a8153:0x84976a);leaf.rotation.z=Math.cos(angle)*.4;}

  addDeskDecoration(scene,{box,material});

  let disposed=false,failed=false;
  const canvas=renderer.domElement;
  const draw=()=>{if(!disposed&&!failed)renderer.render(scene,camera);};
  const room=createDeskRoom(scene,{box,redraw:draw});
  let lightingMinute=-1,lightingTimer=0;
  function updateLighting(){
    const now=new Date(),minute=Math.floor(now.getTime()/60000);
    if(minute===lightingMinute)return;
    lightingMinute=minute;const light=room.update(now);
    host.dataset.lighting=light.night>.8?'night':light.night>.15?'twilight':'day';
    host.dataset.hour=String(now.getHours());
    renderer.shadowMap.needsUpdate=true;draw();
  }
  const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
  let arriving=arrival&&!reducedMotion.matches&&!document.hidden,arrivalFrame=0,arrivalProgress=0;
  const entryPath=new THREE.CubicBezierCurve3(new THREE.Vector3(-10.4,5.65,6.6),new THREE.Vector3(-6.4,5.65,6.3),new THREE.Vector3(-.8,5.65,6.2),new THREE.Vector3(0,5.65,5.2));
  host.dataset.arrival=arriving?'walking':'settled';
  function poseArrival(progress){
    const ease=progress*progress*(3-2*progress);
    camera.position.copy(entryPath.getPoint(ease));
    camera.position.y=THREE.MathUtils.lerp(5.65,4.6,THREE.MathUtils.smoothstep(progress,.68,1));
    camera.lookAt(0,4.6+Math.tan(home.pitch)*5.2,0);
    camera.fov=fieldOfView(1);camera.updateProjectionMatrix();
    room.arrive(progress);renderer.shadowMap.needsUpdate=true;draw();onMonitorBounds(null);
  }
  function finishArrival(){
    if(!arriving)return;
    arriving=false;cancelAnimationFrame(arrivalFrame);arrivalFrame=0;
    room.arrive(1);host.dataset.arrival='settled';Object.assign(view,home);
    renderer.shadowMap.needsUpdate=true;updateCamera();syncAnimation();onArrivalComplete();
  }
  let frame=0,lastFrame=0,inView=true,cameraFrame=0,monitorFramed=false,deskView=null,cameraTarget=null;
  const canAnimate=()=>!arriving&&!disposed&&!failed&&!document.hidden&&inView&&host.clientWidth>0&&host.clientHeight>0&&
    (selected==='monitor'?!!desktopCanvas:!reducedMotion.matches);
  function animate(now){
    frame=0;if(!canAnimate())return;
    if(!lastFrame)lastFrame=now;
    if(now-lastFrame>=50){
      if(selected!=='monitor')saverTime+=(now-lastFrame)/1000;
      lastFrame=now;monitorScreen.repaint();draw();
    }
    frame=requestAnimationFrame(animate);
  }
  function syncAnimation(){
    const visible=!disposed&&!failed&&!document.hidden&&inView&&host.clientWidth>0&&host.clientHeight>0;
    if(visible){
      updateLighting();
      if(!lightingTimer)lightingTimer=setInterval(updateLighting,60000);
    }else{clearInterval(lightingTimer);lightingTimer=0;}
    cancelAnimationFrame(frame);frame=0;lastFrame=0;
    if(canAnimate())frame=requestAnimationFrame(animate);
  }
  function preferenceChanged(){if(reducedMotion.matches)finishArrival();if(reducedMotion.matches&&cameraTarget)moveCamera(cameraTarget,false);syncAnimation();}
  reducedMotion.addEventListener('change',preferenceChanged);
  function visibilityChanged(){if(document.hidden){finishArrival();releaseDesktop();stopCameraMove();}syncAnimation();}
  document.addEventListener('visibilitychange',visibilityChanged);
  const visibility=new IntersectionObserver(entries=>{inView=entries[0]?.isIntersecting??false;syncAnimation();});
  visibility.observe(host);
  function select(id){
    releaseDesktop();
    const restore=selected==='monitor'&&id!=='monitor'?deskView:null;
    if(id!=='monitor'){stopCameraMove();monitorFramed=false;deskView=null;}
    selected=id;for(const [key,ring] of outlines)ring.visible=key===id;
    renderer.shadowMap.needsUpdate=true;monitorScreen.repaint();
    if(restore)moveCamera(restore);else draw();syncAnimation();
  }
  function fieldOfView(zoom){
    // Preserve a generous horizontal view on narrow screens.
    const base=clamp(THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(THREE.MathUtils.degToRad(39))/camera.aspect)),68,98);
    return THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(THREE.MathUtils.degToRad(base/2))/zoom));
  }
  function monitorBounds(from=camera,bezel=.13){
    const corners=[];
    for(const x of [-monitorWidth/2-bezel,monitorWidth/2+bezel])for(const y of [-monitorHeight/2-bezel,monitorHeight/2+bezel]){
      const point=monitor.localToWorld(new THREE.Vector3(x,(bezel?1.65:1.68)+y,-.097)).project(from);
      if(point.z < -1 || point.z > 1)return null;
      corners.push({x:(point.x+1)*host.clientWidth/2,y:(1-point.y)*host.clientHeight/2});
    }
    const left=Math.min(...corners.map(p=>p.x)),top=Math.min(...corners.map(p=>p.y));
    return {left,top,width:Math.max(...corners.map(p=>p.x))-left,height:Math.max(...corners.map(p=>p.y))-top};
  }
  function updateCamera(){
    if(arriving){poseArrival(arrivalProgress);return;}
    view.yaw=clamp(view.yaw,-1.15,1.15);view.pitch=clamp(view.pitch,-.95,.25);view.zoom=clamp(view.zoom,.7,selected==='monitor'||view.alignment>0?6:1.9);
    const center=monitorScreen.mesh.getWorldPosition(new THREE.Vector3());
    camera.position.set(center.x*view.alignment,THREE.MathUtils.lerp(4.6,center.y,view.alignment),5.2);
    camera.lookAt(camera.position.clone().add(new THREE.Vector3(Math.sin(view.yaw)*Math.cos(view.pitch),Math.sin(view.pitch),-Math.cos(view.yaw)*Math.cos(view.pitch))));
    camera.fov=fieldOfView(view.zoom);
    camera.updateProjectionMatrix();draw();onCameraChange({...view});onMonitorBounds(monitorBounds());
  }
  function stopCameraMove(){cancelAnimationFrame(cameraFrame);cameraFrame=0;cameraTarget=null;}
  function focusMonitor(smooth=true){
    stopCameraMove();monitorFramed=true;
    if(!host.clientWidth||!host.clientHeight||failed||disposed)return;
    const center=monitorScreen.mesh.getWorldPosition(new THREE.Vector3());
    // Align the eye with the screen normal: enlarged desktop pixels stay rectangular.
    const preview=camera.clone();preview.position.set(center.x,center.y,5.2);preview.lookAt(center);
    preview.fov=fieldOfView(1);preview.updateProjectionMatrix();preview.updateMatrixWorld();
    const bounds=monitorBounds(preview,0);if(!bounds)return;
    const height=Math.max(120,host.clientHeight-300);
    const target={yaw:0,pitch:0,alignment:1,zoom:clamp(Math.min(host.clientWidth*.9/bounds.width,height/bounds.height),.7,6)};
    moveCamera(target,smooth);
  }
  function moveCamera(target,smooth=true){
    stopCameraMove();
    if(!smooth||reducedMotion.matches||document.hidden){Object.assign(view,target);updateCamera();return;}
    cameraTarget={...target};
    const start={...view},started=performance.now();
    const step=now=>{
      cameraFrame=0;if(disposed||failed)return;
      const t=Math.min(1,(now-started)/360),ease=t*t*(3-2*t);
      for(const key of ['yaw','pitch','zoom','alignment'])view[key]=start[key]+(target[key]-start[key])*ease;
      updateCamera();if(t<1)cameraFrame=requestAnimationFrame(step);else cameraTarget=null;
    };
    cameraFrame=requestAnimationFrame(step);
  }
  function cameraAction(action){
    if(arriving){finishArrival();return;}
    if(action==='monitor'){
      // Refocusing or reopening during the return trip must retain the original seat.
      deskView??={...(cameraTarget??view)};focusMonitor();return;
    }
    stopCameraMove();monitorFramed=false;
    if(action==='reset')Object.assign(view,home);
    else if(action==='left')view.yaw-=.13;
    else if(action==='right')view.yaw+=.13;
    else if(action==='up')view.pitch+=.09;
    else if(action==='down')view.pitch-=.09;
    else if(action==='in')view.zoom*=1.12;
    else if(action==='out')view.zoom/=1.12;
    else return;
    updateCamera();
  }
  function resize(){
    const w=host.clientWidth,h=host.clientHeight;if(!w||!h){stopCameraMove();syncAnimation();return;}
    const destination=cameraTarget;stopCameraMove();camera.aspect=w/h;renderer.setSize(w,h,false);
    if(monitorFramed)focusMonitor(false);else if(destination)moveCamera(destination,false);else updateCamera();syncAnimation();
  }
  const observer=new ResizeObserver(resize);observer.observe(host);
  const ray=new THREE.Raycaster(),pointer=new THREE.Vector2(),pointers=new Map();
  let gesture=null,desktopPointer=null,lastDesktopPoint=null;
  // Raycast the real screen plane, then remove the same letterboxing used by paint.
  // This also follows a captured drag beyond the bezel, clamped to the desktop edge.
  function desktopPoint(event, captured=false){
    if(!onDesktopInput || selected!=='monitor' || !desktopCanvas?.width || !desktopCanvas?.height)return null;
    const r=canvas.getBoundingClientRect();
    pointer.set((event.clientX-r.left)/r.width*2-1,-(event.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);
    const mesh=monitorScreen.mesh;
    const normal=new THREE.Vector3(0,0,1).transformDirection(mesh.matrixWorld);
    const plane=new THREE.Plane().setFromNormalAndCoplanarPoint(normal,mesh.getWorldPosition(new THREE.Vector3()));
    const point=ray.ray.intersectPlane(plane,new THREE.Vector3());if(!point)return null;
    mesh.worldToLocal(point);
    const fit=Math.min(monitorPixels.width/desktopCanvas.width,monitorPixels.height/desktopCanvas.height);
    const w=desktopCanvas.width*fit/monitorPixels.width,h=desktopCanvas.height*fit/monitorPixels.height;
    const x=(point.x/monitorWidth+.5-(1-w)/2)/w,y=(.5-point.y/monitorHeight-(1-h)/2)/h;
    if(!captured&&(x<0||x>1||y<0||y>1))return null;
    return {x:clamp(x,0,1),y:clamp(y,0,1)};
  }
  function sendDesktop(type,event,point){
    lastDesktopPoint=point;
    onDesktopInput?.({type,...point,button:event.button??0,buttons:event.buttons??0,
      deltaX:event.deltaX??0,deltaY:event.deltaY??0,deltaMode:event.deltaMode??0});
  }
  function releaseDesktop(){
    if(desktopPointer===null)return;
    onDesktopInput?.({type:'mouseup',...lastDesktopPoint,button:0,buttons:0,deltaX:0,deltaY:0,deltaMode:0});
    const id=desktopPointer;desktopPointer=null;
    if(canvas.hasPointerCapture(id))canvas.releasePointerCapture(id);
  }
  function blurDesktop(){finishArrival();releaseDesktop();stopCameraMove();}
  window.addEventListener('blur',blurDesktop);
  canvas.addEventListener('contextmenu',event=>{if(desktopPoint(event))event.preventDefault();});
  function hit(event){const r=canvas.getBoundingClientRect();pointer.set((event.clientX-r.left)/r.width*2-1,-(event.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);let mesh=ray.intersectObjects(targets,true)[0]?.object;while(mesh&&!mesh.userData.deskObject)mesh=mesh.parent;return mesh?.userData.deskObject;}
  function distance(){const [a,b]=[...pointers.values()];return Math.hypot(a.x-b.x,a.y-b.y);}
  canvas.addEventListener('pointerdown',event=>{
    if(arriving){finishArrival();return;}
    stopCameraMove();
    const point=desktopPoint(event);
    if(point && !pointers.size && (desktopPointer===null||desktopPointer===event.pointerId)){
      event.preventDefault();desktopPointer=event.pointerId;canvas.setPointerCapture(event.pointerId);
      sendDesktop('mousedown',event,point);return;
    }
    if(desktopPointer!==null||event.button!==0)return;
    monitorFramed=false;
    canvas.focus({preventScroll:true});canvas.setPointerCapture(event.pointerId);
    pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
    if(pointers.size===1)gesture={startX:event.clientX,startY:event.clientY,moved:false,pinched:false};
    else if(gesture){gesture.pinched=true;gesture.distance=distance();}
    canvas.style.cursor='grabbing';
  });
  canvas.addEventListener('pointermove',event=>{
    if(desktopPointer!==null){
      if(desktopPointer===event.pointerId)sendDesktop('mousemove',event,desktopPoint(event,true)??lastDesktopPoint);
      return;
    }
    const point=desktopPoint(event);
    if(point&&!pointers.size){sendDesktop('mousemove',event,point);canvas.style.cursor=desktopCanvas.style.cursor||'default';return;}
    const previous=pointers.get(event.pointerId);
    if(!previous){canvas.style.cursor=hit(event)?'pointer':'grab';return;}
    pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
    if(pointers.size>=2){
      const next=distance();
      if(gesture.distance>0)view.zoom*=next/gesture.distance;
      gesture.distance=next;updateCamera();return;
    }
    if(!gesture||gesture.pinched)return;
    if(Math.hypot(event.clientX-gesture.startX,event.clientY-gesture.startY)>6)gesture.moved=true;
    if(gesture.moved){view.yaw-=(event.clientX-previous.x)*.004;view.pitch+=(event.clientY-previous.y)*.003;updateCamera();}
  });
  function release(event,cancelled=false){
    if(desktopPointer===event.pointerId){
      sendDesktop('mouseup',cancelled?{button:event.button,buttons:0}:event,desktopPoint(event,true)??lastDesktopPoint);
      if(cancelled||!event.buttons){desktopPointer=null;if(canvas.hasPointerCapture(event.pointerId))canvas.releasePointerCapture(event.pointerId);}
      return;
    }
    if(!pointers.has(event.pointerId))return;
    const pick=!cancelled&&pointers.size===1&&gesture&&!gesture.moved&&!gesture.pinched&&Math.hypot(event.clientX-gesture.startX,event.clientY-gesture.startY)<=6;
    pointers.delete(event.pointerId);
    if(canvas.hasPointerCapture(event.pointerId))canvas.releasePointerCapture(event.pointerId);
    if(!pointers.size){gesture=null;canvas.style.cursor='grab';}
    if(pick){const id=hit(event);if(id)onSelect(id);}
  }
  canvas.addEventListener('pointerup',event=>release(event));
  canvas.addEventListener('pointercancel',event=>release(event,true));
  canvas.addEventListener('lostpointercapture',event=>release(event,true));
  canvas.addEventListener('wheel',event=>{
    event.preventDefault();stopCameraMove();
    const point=desktopPoint(event);if(point){sendDesktop('wheel',event,point);return;}
    monitorFramed=false;
    const pixels=event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?host.clientHeight:1);
    view.zoom*=Math.exp(-clamp(pixels,-160,160)*.002);updateCamera();
  },{passive:false});
  canvas.addEventListener('keydown',event=>{
    const action={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down','+':'in','=':'in','-':'out',Home:'reset'}[event.key];
    if(action){event.preventDefault();cameraAction(action);}
  });
  canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();failed=true;finishArrival();releaseDesktop();stopCameraMove();syncAnimation();onFailure();});
  resize();select(selected);
  if(arriving){
    onArrivalStart();
    const started=performance.now();
    const step=now=>{
      if(disposed||failed||!arriving)return;
      arrivalProgress=Math.min(1,(now-started)/3000);
      if(arrivalProgress===1){finishArrival();return;}
      poseArrival(arrivalProgress);arrivalFrame=requestAnimationFrame(step);
    };
    arrivalFrame=requestAnimationFrame(step);
  }
  return {select,cameraAction,finishArrival,update(data){
    if('tokens' in data)tokens=data.tokens??'—';
    if('overview' in data)overview=data.overview??{};
    if('desktopCanvas' in data){if(desktopCanvas!==data.desktopCanvas)releaseDesktop();desktopCanvas=data.desktopCanvas;}
    wallScreen.repaint();meterScreen.repaint();monitorScreen.repaint();draw();syncAnimation();
  },destroy(){
    releaseDesktop();window.removeEventListener('blur',blurDesktop);
    disposed=true;cancelAnimationFrame(arrivalFrame);clearInterval(lightingTimer);room.dispose();stopCameraMove();cancelAnimationFrame(frame);visibility.disconnect();
    document.removeEventListener('visibilitychange',visibilityChanged);reducedMotion.removeEventListener('change',preferenceChanged);
    desktopCanvas=null;pointers.clear();observer.disconnect();
    scene.traverse(mesh=>{mesh.geometry?.dispose();if(mesh.material?.map)mesh.material.dispose();});
    for(const mat of materials.values())mat.dispose();
    textures.forEach(texture=>texture.dispose());
    renderer.dispose();canvas.remove();
  }};
}
