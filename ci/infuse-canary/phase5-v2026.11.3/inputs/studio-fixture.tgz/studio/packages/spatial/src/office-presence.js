// Authored against the fixed 22×14 Paseo layout. No runtime or identity state.
export const OFFICE_WORKSTATIONS = Array.from({length:8},(_,i)=>({
  x:-2.1+(i%4)*1.95,z:i<4?-4.4:-3,facing:i<4?Math.PI:0,
}));
const order=[4,6,5,7,0,2,1,3];
export function presenceRoute(slot) {
  const station=OFFICE_WORKSTATIONS[order[slot]??4];
  const desk={x:station.x,z:station.z+Math.cos(station.facing),facing:station.facing+Math.PI};
  const lounge=slot===0||slot===2;
  const home=lounge?{x:slot===0?3.65:5.30,z:3.65,facing:0}:desk;
  // Exit the sofa into its front aisle, then use the open spine west of the lounge.
  // Rear workstations are reached via the east aisle, outside the shared benches.
  const points=lounge?[
    home,{x:home.x,z:4.14},{x:2.55,z:4.14},{x:2.55,z:-1.15},
    ...(station.z<-4?[{x:5.20,z:-1.15},{x:5.20,z:-6.22},{x:desk.x,z:-6.22}]:[{x:desk.x,z:-1.15}]),desk,
  ]:[desk];
  return {home,desk,points,lounge};
}

/** Reversible travel along one authored path. New data changes direction, not position. */
export function createOfficeTravel(route, initiallyAtDesk) {
  const lengths=route.points.slice(1).map((p,i)=>Math.hypot(p.x-route.points[i].x,p.z-route.points[i].z));
  const total=lengths.reduce((a,b)=>a+b,0);
  let distance=initiallyAtDesk?total:0, target=distance, seated=1, facing=initiallyAtDesk?route.desk.facing:route.home.facing;
  const position={x:0,z:0};
  function sample() {
    if(distance===0||distance===total){
      const p=distance===total?route.desk:route.home;position.x=p.x;position.z=p.z;return;
    }
    let remaining=distance;
    for(let i=0;i<lengths.length;i++) {
      const length=lengths[i];
      if(remaining<=length||i===lengths.length-1) {
        const a=route.points[i],b=route.points[i+1],t=length?remaining/length:0;
        position.x=a.x+(b.x-a.x)*t;position.z=a.z+(b.z-a.z)*t;
        if(distance!==target)facing=Math.atan2((b.x-a.x)*(target>distance?1:-1),(b.z-a.z)*(target>distance?1:-1));
        return;
      }
      remaining-=length;
    }
    position.x=route.desk.x;position.z=route.desk.z;
  }
  sample();
  return {
    aim(atDesk) { target=atDesk?total:0; },
    settle() { distance=target;seated=1;facing=target===total?route.desk.facing:route.home.facing;sample(); },
    step(seconds,allowed=true) {
      const dt=Math.max(0,Math.min(.1,seconds));
      if(distance!==target) {
        if(!allowed)return;
        seated=Math.max(0,seated-dt*4);
        if(seated===0) {
          const delta=Math.sign(target-distance)*Math.min(Math.abs(target-distance),dt*2.8);
          distance+=delta; sample();
        }
      } else {
        facing=target===total?route.desk.facing:route.home.facing;
        seated=Math.min(1,seated+dt*4);
      }
    },
    get moving(){return distance!==target||seated<1;},
    get position(){return {...position};},
    get facing(){return facing;},
    get seated(){return seated;},
    get distance(){return distance;},
    get atDesk(){return !route.lounge||distance===total;},
  };
}
