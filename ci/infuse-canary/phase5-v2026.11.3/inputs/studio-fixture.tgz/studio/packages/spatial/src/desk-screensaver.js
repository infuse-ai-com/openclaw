/** A quiet, procedural voxel landscape. Time is supplied by the visible desk. */
export function paintDeskScreensaver(ctx, width, height, time) {
  ctx.save();
  ctx.scale(width / 1280, height / 720);
  const background=ctx.createLinearGradient(0,0,1280,720);
  background.addColorStop(0,'#071c21');background.addColorStop(1,'#244239');
  ctx.fillStyle=background;ctx.fillRect(0,0,1280,720);
  const glow=ctx.createRadialGradient(830,330,0,830,330,420);
  glow.addColorStop(0,'#93c4a52b');glow.addColorStop(1,'#93c4a500');
  ctx.fillStyle=glow;ctx.fillRect(0,0,1280,720);
  const face=(points,color)=>{
    ctx.fillStyle=color;ctx.beginPath();
    points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));
    ctx.closePath();ctx.fill();
  };
  // Diagonal strips draw from back to front; gentle height waves stay continuous.
  for(let diagonal=0;diagonal<=24;diagonal++)for(let x=0;x<=12;x++){
    const z=diagonal-x;if(z<0||z>12)continue;
    const px=862+(x-z)*26,py=210+(x+z)*11;
    const wave=Math.sin(x*.47+time*.65)+Math.cos(z*.53-time*.48);
    const lift=22+(wave+2)*15;
    const amber=(x===5&&z>=3&&z<=9)||(z===6&&x>=5&&x<=9);
    const light=Math.round(38+wave*5);
    face([[px-25,py],[px,py+11],[px,py+11-lift],[px-25,py-lift]],amber?'#a95b35':`hsl(158 21% ${light-16}%)`);
    face([[px,py+11],[px+25,py],[px+25,py-lift],[px,py+11-lift]],amber?'#c77c49':`hsl(158 24% ${light-8}%)`);
    face([[px-25,py-lift],[px,py-11-lift],[px+25,py-lift],[px,py+11-lift]],amber?'#f4b57b':`hsl(148 26% ${light+17}%)`);
  }
  const fade=ctx.createLinearGradient(330,0,650,0);
  fade.addColorStop(0,'#0a2022');fade.addColorStop(1,'#0a202200');
  ctx.fillStyle=fade;ctx.fillRect(0,0,650,720);
  ctx.fillStyle='#acc4b6';ctx.font='500 18px sans-serif';ctx.fillText('INFUSE / WORKBENCH',50,92);
  ctx.fillStyle='#e5ecda';ctx.font='500 56px sans-serif';ctx.fillText('Room to think.',50,310);
  ctx.fillStyle='#afc3b4';ctx.font='24px sans-serif';ctx.fillText('Your workspace is one touch away.',52,360);
  ctx.fillStyle='#f4b57b';ctx.fillRect(52,420,52,4);
  ctx.fillStyle='#e5ecda';ctx.font='500 21px sans-serif';ctx.fillText('Click to open Workbench  ↗',52,610);
  ctx.restore();
}
