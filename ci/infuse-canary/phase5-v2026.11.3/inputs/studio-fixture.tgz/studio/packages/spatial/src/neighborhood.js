import * as THREE from 'three';

// An authored miniature city. None of its windows or traffic represent live work.
const stops = [
  [0, '#111c36', '#263653', '#abc7ff', .22, .32, 1],
  [5, '#17233d', '#354157', '#becfff', .28, .4, 1],
  [7, '#cdb6ac', '#efe0cb', '#ffc999', 2.1, .72, .18],
  [10, '#cfdee1', '#f2eee2', '#fff0d7', 3.1, .85, 0],
  [16, '#ccdadd', '#efebdf', '#ffe6c1', 2.9, .8, 0],
  [18.5, '#ad8f9c', '#e4bba5', '#ffac6b', 1.7, .6, .42],
  [20.5, '#192641', '#334255', '#adc9ff', .28, .38, 1],
  [24, '#111c36', '#263653', '#abc7ff', .22, .32, 1],
];
/** Device wall-clock hours, not astronomical sunrise or a location lookup. */
export function officeDaylight(hours) {
  const hour = ((hours % 24) + 24) % 24;
  const index = stops.findIndex((stop, i) => i < stops.length - 1 && hour >= stop[0] && hour < stops[i + 1][0]);
  const a = stops[index], b = stops[index + 1];
  const t = THREE.MathUtils.smoothstep(hour, a[0], b[0]);
  const mix = i => THREE.MathUtils.lerp(a[i], b[i], t);
  const color = i => new THREE.Color(a[i]).lerp(new THREE.Color(b[i]), t);
  const sunVisibility = THREE.MathUtils.smoothstep(hour, 5.75, 7) * (1 - THREE.MathUtils.smoothstep(hour, 19, 20.5));
  const elevation = Math.sin(THREE.MathUtils.clamp((hour - 6) / 14, 0, 1) * Math.PI);
  return { sunVisibility, elevation, sky: color(1), horizon: color(2), sun: color(3), sunlight: mix(4), ambient: mix(5), night: mix(6), hour };
}

export function createNeighborhood({ root, box, ownedMaterials, textures }) {
  const city = new THREE.Group(); city.name = 'decorative-neighborhood'; root.add(city);
  const own = material => (ownedMaterials.push(material), material);
  const material = (color, options = {}) => own(new THREE.MeshStandardMaterial({ color, roughness: .86, ...options }));
  const stone = material(0xc2bba9), curb = material(0xd8d2bd), asphalt = material(0x56646a);
  const marking = material(0xc9c9b5), metal = material(0x425358), timber = material(0x9b7559);
  const foliage = [material(0x708777), material(0x8b9b73), material(0x4e756a)];
  const facades = [material(0xc1bba9), material(0x9eada6), material(0xbf9983), material(0x9daeb3)];
  const window = material(0x354e59, { metalness: .25, roughness: .4 });
  const litWindow = material(0x738184, { emissive: 0xffca78, emissiveIntensity: 0 });
  const lamp = material(0xffe7ba, { emissive: 0xffcc7a, emissiveIntensity: .1 });
  const headlight = material(0xffefc6, { emissive: 0xffe4a3, emissiveIntensity: .1 });
  const tailLight = material(0xa23c32, { emissive: 0xff4627, emissiveIntensity: .15 });
  // Batch the stationary architecture: hundreds of windows are a handful of draw calls.
  const batches = new Map(), dummy = new THREE.Object3D();
  function block(w, h, d, x, y, z, finish, rotation = 0) {
    if (!batches.has(finish)) batches.set(finish, []);
    dummy.position.set(x, y, z); dummy.scale.set(w, h, d); dummy.rotation.set(0, rotation, 0); dummy.updateMatrix();
    batches.get(finish).push(dummy.matrix.clone());
  }
  block(66, .45, 45, 0, -1.34, -3, metal);
  block(66, .16, 45, 0, -1.035, -3, stone);
  // Extend the existing front road and wrap it around the company block.
  block(65.8, .10, 5, 0, -.88, 8.55, asphalt);
  block(65.8, .10, 4.7, 0, -.88, -8.6, asphalt);
  for (const x of [-11.9, 12.1]) block(4.6, .10, 36, x, -.88, -3, asphalt);
  for (let x = -31; x < 33; x += 3) {
    if (Math.abs(x + 12) < 3 || Math.abs(x - 12) < 3 || Math.abs(x + 5) < 2) continue;
    block(1.2, .016, .075, x, -.815, 8.55, marking);
    block(1.2, .016, .075, x, -.815, -8.6, marking);
  }
  for (let z = -19; z < 15; z += 3) for (const x of [-11.9, 12.1]) {
    if (Math.abs(z - 8.5) < 3 || Math.abs(z + 8.6) < 3) continue;
    block(.075, .016, 1.2, x, -.815, z, marking);
  }
  for (const [x, z, w, d] of [[0,-17,19,11.5],[-24,-3,17,36],[24,-3,17,36],[0,15.6,19,6.6]]) {
    block(w, .28, d, x, -.78, z, curb);
    block(w-.25, .06, d-.25, x, -.61, z, stone);
  }
  // Opposite pavement and crossings keep cars clearly on their own road.
  for (let i=0; i<6; i++) block(.38,.016,2.1,9.8+i*.75,-.815,3.8,marking);
  for (const x of [-5, 21]) for (let i=0;i<6;i++) block(2.4,.016,.35,x,-.815,6.6+i*.68,marking);

  function building(x,z,w,d,floors,palette,seed) {
    const height = floors*2.35;
    block(w,height,d,x,height/2-.55,z,facades[palette]);
    block(w+.3,.22,d+.3,x,height-.43,z,curb);
    block(w-.35,.07,d-.35,x,height-.28,z,metal);
    for (const side of [-1,1]) {
      for (let row=0;row<floors;row++) for(let col=0;col<Math.floor(w/1.6);col++) {
        const px=x-w/2+1+col*1.6, y=.65+row*2.35;
        block(.9,1.35,.035,px,y,z+side*(d/2+.025),(row*7+col*3+seed)%5<2?litWindow:window);
        block(1.05,.09,.13,px,y-.73,z+side*(d/2+.06),curb);
      }
      for (let row=0;row<floors;row++) for(let col=0;col<Math.floor(d/1.6);col++) {
        block(.035,1.35,.9,x+side*(w/2+.025),.65+row*2.35,z-d/2+1+col*1.6,(row*3+col+seed)%4===0?litWindow:window);
      }
    }
    // Rooftop equipment, planters, and slim shop awnings give each neighbor a silhouette.
    block(w*.32,.65,d*.34,x+.5,height+.02,z-.4,metal);
    block(w*.34,.1,d*.36,x+.5,height+.4,z-.4,curb);
    block(w-.5,.17,.9,x,1.6,z+d/2+.35,palette===2?timber:foliage[2]);
    for(const dx of [-w/2+.5,w/2-.5]) block(.16,1.9,.16,x+dx,.4,z+d/2+.65,metal);
    for(let i=0;i<3;i++) {
      block(.85,.4,.85,x-w/2+.8+i*1.05,height-.02,z+d/2-.7,timber);
      block(.7,.5,.7,x-w/2+.8+i*1.05,height+.36,z+d/2-.7,foliage[(i+seed)%3]);
    }
  }
  building(-5.1,-17,7.4,7.7,4,0,1); building(4.4,-17,7.4,7.7,5,1,4);
  building(-22,-14.8,10,8,3,2,2); building(-23.8,-2.9,7,9,2,0,3);
  building(23,-14.9,10,8.5,5,3,6); building(23,-3.1,10,8,3,2,3);
  // Low corner pavilions leave the company's entrances unobstructed.
  building(-25,10,8,6,1,1,2); building(25,10,8,6,2,0,5);
  function tree(x,z,seed) {
    block(1.65,.25,1.65,x,-.45,z,curb); block(.2,2.6,.2,x,.8,z,timber);
    block(1.85,1.6,1.8,x,2.25,z,foliage[seed%3],seed*.4);
    block(1.2,1.05,1.25,x+.2,3.25,z,foliage[(seed+1)%3],seed*.6);
  }
  [[-17,2],[-17,-6],[-16,-17],[16,-18],[16,-4],[16,3],[16,14],[-17,14],[-8,15],[2,16],[8,15],[-29,-8],[29,3]].forEach(([x,z],i)=>tree(x,z,i));
  for(const x of [-3,4]) {
    for (const dx of [-.8,.8]) block(.12,.5,.6,x+dx,-.3,14,metal);
    block(2,.1,.7,x,0,14,timber); block(2,.5,.09,x,.3,14.4,timber);
  }
  const glowCanvas=document.createElement('canvas'); glowCanvas.width=glowCanvas.height=64;
  const ctx=glowCanvas.getContext('2d'), gradient=ctx.createRadialGradient(32,32,0,32,32,32);
  gradient.addColorStop(0,'rgba(255,209,131,.65)'); gradient.addColorStop(1,'rgba(255,209,131,0)');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,64,64);
  const glowMap=new THREE.CanvasTexture(glowCanvas); glowMap.colorSpace=THREE.SRGBColorSpace;textures.push(glowMap);
  const glow=own(new THREE.MeshBasicMaterial({map:glowMap,transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending}));
  for (const [x,z] of [[-15,5],[-15,-7],[15,5],[15,-7],[-7,12],[7,12],[-7.8,5.35],[7.8,5.35]]) {
    if(Math.abs(x)!==7.8) {block(.12,3.4,.12,x,1.08,z,metal);block(.8,.12,.35,x+.3,2.8,z,metal);block(.65,.04,.27,x+.3,2.72,z,lamp);}
    const pool=new THREE.Mesh(new THREE.PlaneGeometry(5.5,5.5),glow);pool.rotation.x=-Math.PI/2;pool.position.set(x+.3,-.5,z);city.add(pool);
  }
  for(const [finish,matrices] of batches) {
    const mesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),finish,matrices.length);
    matrices.forEach((matrix,i)=>mesh.setMatrixAt(i,matrix));mesh.castShadow=true;mesh.receiveShadow=true;city.add(mesh);
  }
  // A rounded, closed route: cars never teleport or drive across the pavement.
  function route(left,right,back,front,radius) {
    const path=new THREE.CurvePath(), v=(x,z)=>new THREE.Vector3(x,-.74,z);
    const line=(a,b)=>path.add(new THREE.LineCurve3(v(...a),v(...b)));
    const turn=(a,b,c)=>path.add(new THREE.QuadraticBezierCurve3(v(...a),v(...b),v(...c)));
    line([left+radius,front],[right-radius,front]);turn([right-radius,front],[right,front],[right,front-radius]);
    line([right,front-radius],[right,back+radius]);turn([right,back+radius],[right,back],[right-radius,back]);
    line([right-radius,back],[left+radius,back]);turn([left+radius,back],[left,back],[left,back+radius]);
    line([left,back+radius],[left,front-radius]);turn([left,front-radius],[left,front],[left+radius,front]);return path;
  }
  const routes=[route(-12.85,13.05,-9.55,9.5,2.7),route(-10.95,11.15,-7.65,7.6,2.4)];
  const cars=[];
  [0xe3d8bd,0xb76f52,0x668a86,0xc6aa68,0x536c82,0xd4c9b8].forEach((color,i)=>{
    const car=new THREE.Group();car.name=`ambient-car-${i+1}`;city.add(car);
    box(car,1.06,.38,2.08,0,.45,0,color);box(car,.9,.35,1.08,0,.8,-.1,window);box(car,.94,.07,1.12,0,1,-.1,color);
    for(const x of [-.56,.56])for(const z of [-.65,.65])box(car,.14,.38,.39,x,.25,z,metal);
    for(const x of [-.33,.33]) {box(car,.23,.12,.045,x,.48,1.05,headlight,false);box(car,.23,.1,.045,x,.48,-1.05,tailLight,false);}
    // VSM also includes receivers in its map; keep moving cars out of the cached static shadows.
    car.traverse(item => { if (item.isMesh) { item.castShadow=false; item.receiveShadow=false; } });
    cars.push({car,path:routes[i%2],offset:(Math.floor(i/2)/3 + (i%2)*.12)%1,direction:i%2?-1:1});
  });
  const point=new THREE.Vector3(), tangent=new THREE.Vector3();
  function animate(seconds) {
    for(const {car,path,offset,direction} of cars) {
      const position=((offset+seconds*.022*direction)%1+1)%1;
      path.getPointAt(position,point);path.getTangentAt(position,tangent);car.position.copy(point);car.rotation.y=Math.atan2(tangent.x*direction,tangent.z*direction);
    }
  }
  animate(0);
  return {
    animate,
    setNight(night) {litWindow.emissiveIntensity=night*2.1;lamp.emissiveIntensity=.1+night*2.4;headlight.emissiveIntensity=.1+night*2.8;tailLight.emissiveIntensity=.15+night*.8;glow.opacity=night*.85;},
  };
}
