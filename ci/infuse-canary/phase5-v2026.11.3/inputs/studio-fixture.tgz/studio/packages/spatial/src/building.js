import * as THREE from 'three';

export const STOREY_HEIGHT = 4.2;

// Exterior assets live for the lifetime of the world; floor geometry is rebuilt
// when projects change. Project wordmarks are placeholders until logos exist.
export function createBuildingExterior({box, ownedMaterials, textures, fontFamily = 'Plex'}) {
  const own = material => (ownedMaterials.push(material), material);
  const metal = own(new THREE.MeshStandardMaterial({color:0x405c60,emissive:0x233d40,emissiveIntensity:.28,metalness:.5,roughness:.34}));
  const trim = own(new THREE.MeshStandardMaterial({color:0x6c827e,metalness:.65,roughness:.3}));
  const dark = own(new THREE.MeshStandardMaterial({color:0x0c2023,roughness:.6}));
  const glow = own(new THREE.MeshBasicMaterial({color:0xc0d3bb}));
  const glassCanvas=document.createElement('canvas');glassCanvas.width=512;glassCanvas.height=512;
  const ctx=glassCanvas.getContext('2d');
  const gradient=ctx.createLinearGradient(0,512,512,0);
  gradient.addColorStop(0,'#24484e');gradient.addColorStop(.36,'#3b646c');gradient.addColorStop(.38,'#739998');gradient.addColorStop(.65,'#58848a');gradient.addColorStop(.67,'#365d68');gradient.addColorStop(1,'#6a9297');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,512,512);
  const glassMap=new THREE.CanvasTexture(glassCanvas);glassMap.colorSpace=THREE.SRGBColorSpace;textures.push(glassMap);
  const glass=own(new THREE.MeshStandardMaterial({map:glassMap,color:0xb7d4d1,emissiveMap:glassMap,emissive:0x668f94,emissiveIntensity:.6,transparent:true,opacity:.72,metalness:.15,roughness:.3,depthWrite:false,side:THREE.DoubleSide}));
  const signs=new Map(), entrances=new Map();
  let hoveredFloor=null,focusedFloor=null;
  function refreshHighlight(){
    const selected=focusedFloor||hoveredFloor;
    for(const [id,{outline,entry}] of entrances){
      outline.visible=id===selected;
      entry.classList.toggle('is-highlighted',id===selected);
    }
  }
  function highlight(id){hoveredFloor=id;refreshHighlight();}
  function clear(){entrances.clear();hoveredFloor=focusedFloor=null;}
  function billboard(info) {
    const key=JSON.stringify([info.id,info.title,info.number,info.accent]);
    if(signs.has(key))return signs.get(key).material;
    const canvas=document.createElement('canvas');canvas.width=1536;canvas.height=384;
    const c=canvas.getContext('2d'),map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace;textures.push(map);
    const material=own(new THREE.MeshBasicMaterial({map}));
    function draw(){
      c.fillStyle='#0c191c';c.fillRect(0,0,1536,384);
      c.fillStyle=info.accent||'#fe5600';c.fillRect(0,0,12,384);
      c.fillStyle='#9eb2ad';c.font=`500 33px ${fontFamily}, sans-serif`;c.fillText(`FLOOR ${info.number}`,66,76);
      let size=145;c.font=`600 ${size}px ${fontFamily}, sans-serif`;
      while(c.measureText(info.title).width>1230&&size>34)c.font=`600 ${--size}px ${fontFamily}, sans-serif`;
      c.fillStyle='#f4f1e6';c.fillText(info.title,64,247,1230);
      c.fillStyle=info.accent||'#fe5600';c.fillRect(1420,178,22,22);map.needsUpdate=true;
    }
    signs.set(key,{material,draw});draw();return material;
  }
  function pane(parent,w,h,x,y,z,rotation=0){
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,h),glass);mesh.position.set(x,y,z);mesh.rotation.y=rotation;parent.add(mesh);return mesh;
  }
  // A small authored city block gives the company a recognisable address.
  // These decorative groups intentionally have no floor/picking identity.
  function planter(parent,x,y,z,w=1.4,d=1){
    box(parent,w,.5,d,x,y+.25,z,0x7b8273);
    box(parent,w-.12,.045,d-.12,x,y+.51,z,0x3a4431,false);
    for(let i=0;i<Math.ceil(w/.5);i++){
      const px=x-w/2+.25+i*.45;
      box(parent,.42,.4+(i%2)*.2,.55,px,y+.72,z,i%2?0x758750:0x4c6947);
      box(parent,.25,.26,.34,px+.08,y+.99,z-.08,0x91a366);
    }
  }
  function tree(parent,x,z){
    planter(parent,x,-.58,z,1.3,1.3);
    box(parent,.2,1.9,.22,x,.75,z,0x806448);
    for(const [dx,dy,dz,w] of [[0,2,0,1.45],[-.45,1.65,.12,.95],[.45,2.45,0,.95],[0,2.85,-.12,.8]])
      box(parent,w,.85,w,x+dx,dy,z+dz,dy>2?0x859966:0x4d7055);
  }
  function bench(parent,x,y,z){
    for(const dx of [-.75,.75])box(parent,.13,.48,.68,x+dx,y+.24,z,metal);
    for(let i=0;i<4;i++)box(parent,1.95,.1,.14,x,y+.5,z-.25+i*.17,0x987653);
    box(parent,1.95,.38,.09,x,y+.78,z-.37,0xa0805c);
  }
  function streets(root){
    box(root,25,.38,18,-2,-1.02,2,dark);
    box(root,25,.09,18,-2,-.79,2,0x37464a,false);
    // Raised pavement, with a road around the front and left of the property.
    box(root,18.5,.22,12,0,-.64,0,0xa0a798);
    for(let x=-8.75;x<=9;x+=1.25)box(root,.018,.01,11.7,x,-.522,0,0x7f897e,false);
    for(let z=-5.8;z<=6;z+=1.2)box(root,18.3,.01,.018,0,-.52,z,0x7f897e,false);
    box(root,18.5,.16,.18,0,-.52,6,0xc5c7b4);
    box(root,.18,.16,12,-9.25,-.52,0,0xc5c7b4);
    // Tactile threshold and a zebra crossing aligned with the entrance.
    for(let i=0;i<6;i++)box(root,2.5,.015,.36,-5,-.727,6.65+i*.68,0xc2c6b7,false);
    box(root,2.5,.018,.45,-5,-.518,5.66,0xc1ae76,false);
    for(let x=-1;x<10;x+=2.6)box(root,1.3,.012,.065,x,-.73,8.6,0x9ba59a,false);
    for(let z=-5;z<4;z+=2.6)box(root,.065,.012,1.2,-11.8,-.73,z,0x9ba59a,false);
    for(const [x,z] of [[-8.15,-3.8],[8.15,-3.8],[8.15,4.8]])tree(root,x,z);
    bench(root,2.9,-.52,5.1);planter(root,5.3,-.52,5.1,1.8,.8);
    for(const x of [-7.8,7.8]){
      box(root,.14,3.1,.14,x,1.03,5.35,metal);
      box(root,.85,.09,.32,x+.31,2.59,5.35,metal);
      box(root,.65,.035,.22,x+.31,2.53,5.35,glow,false);
    }
    for(const x of [-6.6,-3.4]){box(root,.15,.6,.15,x,-.22,5.75,metal);box(root,.16,.065,.16,x,.05,5.75,glow,false);}
    // A subtle orange route leads from the crossing to the lift doors.
    box(root,.065,.018,1.8,-5,-.51,4.9,0xfe5600,false);
  }
  function rooftop(root,total){
    const roof=new THREE.Group();roof.position.y=total+.27;root.add(roof);
    // Warm timber terrace, framed by a slim parapet and planted corners.
    box(roof,13.8,.09,5.9,0,0,0,0x867253);
    for(let z=-2.8;z<3;z+=.24)box(roof,13.6,.012,.014,0,.051,z,0x675c49,false);
    for(const z of [-3.06,3.06]){
      box(roof,14.2,.28,.14,0,.12,z,metal);
      box(roof,14.2,.055,.1,0,.86,z,trim);
      for(let x=-6.9;x<7;x+=1.73)box(roof,.045,.7,.045,x,.48,z,trim);
    }
    for(const x of [-7,7]){box(roof,.14,.28,6.1,x,.12,0,metal);box(roof,.07,.06,6.1,x,.86,0,trim);}
    // Lift overrun and a signature orange pergola over the roof lounge.
    box(roof,2.5,1.65,2.7,-5, .83,-1.1,metal);
    box(roof,2.7,.13,2.9,-5,1.7,-1.1,trim);
    box(roof,.9,1.35,.035,-5,.7,.27,dark,false);
    for(const x of [-1.8,5.8])for(const z of [-2.3,1.5])box(roof,.14,2.1,.14,x,1.05,z,metal);
    for(const z of [-2.3,1.5])box(roof,7.9,.22,.18,2,2.12,z,0xfe5600);
    for(let x=-1.8;x<=5.8;x+=.55)box(roof,.12,.14,4.05,x,2.16,-.4,0xa3875e);
    bench(roof,1.3,.05,-1.3);bench(roof,4,.05,-1.3);
    box(roof,1.4,.13,.85,2.5,.56,.25,0xa58a62);box(roof,.55,.5,.5,2.5,.25,.25,metal);
    planter(roof,-5.2,.05,2,2.7,1);planter(roof,5.1,.05,2.3,2.6,.8);
    planter(roof,-.7,.05,-2.5,2.2,.7);
    box(roof,14.1,.06,.08,0,-.04,3.3,glow,false);
  }
  function build(root,floors,addLabel,onSelect){
    clear();
    const total=floors.length*STOREY_HEIGHT;
    streets(root);
    box(root,15,.32,7.6,0,-.42,0,metal);
    box(root,16,.14,8.4,0,-.65,0,dark);
    // A continuous shaft, quiet guide rails and one cab behind the glass.
    box(root,2.1,total,.15,-5,total/2,-.15,dark,false);
    for(const x of [-5.85,-4.15])box(root,.055,total,.08,x,total/2,1.1,trim,false);
    box(root,1.5,2.6,1.1,-5,1.55,1.35,metal,false);
    box(root,1.25,2.1,.06,-5,1.45,1.94,trim,false);
    box(root,.025,2.1,.07,-5,1.45,1.99,dark,false);
    box(root,1.24,.035,.08,-5,2.54,1.99,glow,false);
    floors.toReversed().forEach((info,i)=>{
      const g=new THREE.Group();g.position.y=i*STOREY_HEIGHT;g.userData.floor=info.id;root.add(g);
      box(g,14.2,.19,6.2,0,0,0,metal);
      box(g,14,3.98,.1,0,2,-3,dark,false);
      box(g,14,.09,.14,0,.2,2.88,trim,false);
      // No furnished interiors: just depth, a subdued ceiling and glazing.
      box(g,13.6,.07,5.8,0,4.03,0,metal,false);
      pane(g,14,3.96,0,2.1,3.12);
      for(let x=-7;x<7;x+=2){
        box(g,.065,4.2,.1,x,2.1,3.17,metal,false);
      }
      for(const x of [-7.04,7.04]){
        pane(g,6,3.96,x,2.1,0,Math.PI/2);
        for(const z of [-3,-1,1,3])box(g,.1,4.2,.07,x,2.1,z,metal,false);
      }
      box(g,.095,4.2,.095,7,2.1,3.16,trim,false);
      // Floating lightbox attached to the front curtain wall.
      box(g,8.1,1.86,.25,1.2,2.2,3.32,metal,false);
      const sign=new THREE.Mesh(new THREE.PlaneGeometry(7.9,1.72),billboard(info));sign.position.set(1.2,2.2,3.46);g.add(sign);
      box(g,7.7,.028,.035,1.2,1.27,3.47,glow,false);
      const entry=addLabel('↗',new THREE.Vector3(6.2,i*STOREY_HEIGHT+2.2,3.5),()=>onSelect({floor:info.id}),`floor-label billboard-entry floor-label--${info.id}`);
      entry.setAttribute('aria-label',`Enter ${info.title} · Floor ${info.number}`);entry.title=`Enter ${info.title}`;
      entry.dataset.floorEntry=info.id;
      const caption=document.createElement('span');caption.className='billboard-entry-caption';caption.textContent=`Enter ${info.title}`;caption.setAttribute('aria-hidden','true');entry.append(caption);
      // Outline the whole level without tinting or duplicating its materials.
      const outline=new THREE.Group();g.add(outline);outline.visible=false;
      for(const y of [.12,4.16]){
        box(outline,14.3,.055,.055,0,y,3.24,glow,false);
        for(const x of [-7.12,7.12])box(outline,.055,.055,6.3,x,y,.1,glow,false);
      }
      for(const x of [-7.12,7.12])box(outline,.055,4.04,.055,x,2.14,3.24,glow,false);
      entrances.set(info.id,{outline,entry});
      entry.addEventListener('pointerenter',()=>highlight(info.id));
      entry.addEventListener('pointerleave',()=>highlight(null));
      entry.addEventListener('focus',()=>{focusedFloor=info.id;refreshHighlight();});
      entry.addEventListener('blur',()=>{focusedFloor=null;refreshHighlight();});
    });
    box(root,14.5,.28,6.6,0,total+.07,0,metal);
    rooftop(root,total);
    box(root,14.3,.045,.07,0,total+.19,3.29,trim,false);
    // A restrained entry canopy grounds the building without another office.
    box(root,2.8,.12,1.1,-5,.16,3.5,metal);
  }
  function setNight(night) {
    glass.emissive.set(0x668f94).lerp(new THREE.Color(0xdba15c), night * .72);
    glass.emissiveIntensity=.6+night*.35;
    glow.color.set(0xc0d3bb).lerp(new THREE.Color(0xffdda0), night);
  }
  return {build,highlight,clear,setNight,dispose:clear};
}

/** A real directory object, kept separate from project/floor picking identity. */
export function createDirectoryKiosk({ root, box, ownedMaterials, brandMap }) {
  const kiosk = new THREE.Group(); kiosk.position.set(-6.45, -.51, 4.5); kiosk.userData.directory = true; root.add(kiosk);
  const accent = new THREE.MeshStandardMaterial({ color: 0xfe5600, emissive: 0xfe5600, emissiveIntensity: .3, roughness: .4 });
  ownedMaterials.push(accent);
  box(kiosk, 1.3, .12, .8, 0, .06, 0, 0x35464a);
  box(kiosk, 1.08, 1.95, .35, 0, 1.04, 0, 0x24393e);
  for (const x of [-.56, .56]) box(kiosk, .09, 2.03, .41, x, 1.05, 0, accent);
  for (const y of [.08, 2.02]) box(kiosk, 1.2, .09, .41, 0, y, 0, accent);
  box(kiosk, .94, 1.72, .025, 0, 1.06, .19, 0x0c191c);
  const face = new THREE.MeshBasicMaterial({ map: brandMap, transparent: true, depthWrite: false }); ownedMaterials.push(face);
  const logo = new THREE.Mesh(new THREE.PlaneGeometry(.84, .24), face); logo.position.set(0, 1.24, .21); kiosk.add(logo);
  return { position: new THREE.Vector3(-6.45, 1.56, 4.72), highlight(value) { accent.emissiveIntensity = value ? .85 : .3; } };
}
