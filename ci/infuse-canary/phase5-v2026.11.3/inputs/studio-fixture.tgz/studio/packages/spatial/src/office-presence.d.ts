export interface OfficePoint { x: number; z: number }
export interface OfficeSeat extends OfficePoint { facing: number }
export interface PresenceRoute { points: OfficePoint[]; home: OfficeSeat; desk: OfficeSeat; lounge: boolean }
export const OFFICE_WORKSTATIONS: OfficeSeat[];
export function presenceRoute(slot: number): PresenceRoute;
export function createOfficeTravel(route: PresenceRoute, atDesk: boolean): {
  aim(atDesk: boolean): void;
  settle(): void;
  step(seconds: number, allowed?: boolean): void;
  readonly moving: boolean;
  readonly position: OfficePoint;
  readonly facing: number;
  readonly seated: number;
  readonly distance: number;
  readonly atDesk: boolean;
};
