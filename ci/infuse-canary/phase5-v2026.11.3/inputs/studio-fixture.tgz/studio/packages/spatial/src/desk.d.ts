export type DeskObject = 'monitor' | 'tokens' | 'inbox' | 'notebook' | 'wall';
export type DeskCameraAction = 'left' | 'right' | 'up' | 'down' | 'in' | 'out' | 'reset' | 'monitor';
export interface DeskMonitorBounds { left: number; top: number; width: number; height: number }
export interface DeskCameraView { yaw: number; pitch: number; zoom: number; alignment?: number }
export interface DeskOverview {
  decisions?: number | null; missions?: number | null; project?: string;
  input?: number; output?: number; status?: string;
}
export interface DeskPointerInput { type: 'mousedown' | 'mouseup' | 'mousemove' | 'wheel'; x: number; y: number; button: number; buttons: number; deltaX: number; deltaY: number; deltaMode: number }
export interface DeskData { tokens?: string; overview?: DeskOverview; desktopCanvas?: HTMLCanvasElement | null }
export interface DeskScene {
  select(id: DeskObject | null): void;
  update(data: DeskData): void;
  cameraAction(action: DeskCameraAction): void;
  finishArrival(): void;
  destroy(): void;
}
export function createDesk(host: HTMLElement, options: DeskData & {
  onSelect(id: DeskObject): void; onFailure(): void; exampleData?: boolean;
  selected?: DeskObject | null; cameraView?: DeskCameraView;
  arrival?: boolean; onArrivalStart?(): void; onArrivalComplete?(): void;
  onDesktopInput?(input: DeskPointerInput): void;
  onCameraChange?(view: DeskCameraView): void;
  onMonitorBounds?(bounds: DeskMonitorBounds | null): void;
}): DeskScene;
