import * as THREE from 'three';
import { officeDaylight } from './neighborhood.js';

/** Decorative side walls and device-clock lighting; no work or navigation state. */
export function createDeskRoom(scene, {box, redraw}) {
  const room=new THREE.Group();scene.add(room);
  box(room,28,.16,30,0,-.14,0,0xc8b397);
  for(let i=0;i<30;i++)box(room,28,.01,.025,0,-.05,-14.5+i,0xb6a183);
  // A plaster ceiling closes the room above the wall display, including on mobile.
  box(room,20.25,.22,19.4,0,10.45,5.4,0xece8da);
  box(room,20,.14,.18,0,10.25,-3.98,0xbac0aa);
  for(const x of [-9.8,9.8])box(room,.18,.14,19.1,x,10.25,5.5,0xbac0aa);
  box(room,28,10.5,.25,0,5.15,-4.2,0xe3dfd0);
  box(room,28,1.3,.06,0,.65,-4.04,0xa8b29a);
  box(room,28,.09,.12,0,1.32,-3.99,0x8c9b80);
  // The right wall has a real opening: z -2.8…4.2, y 2.4…7.6.
  const wall=(h,d,y,z)=>box(room,.25,h,d,10,y,z,0xd4d3bf);
  wall(10.5,12.2,5.15,-8.9);wall(10.5,10.8,5.15,9.6);
  wall(2.5,7,1.15,.7);wall(2.8,7,9,.7);
  // A real doorway, plus a short enclosed threshold for the first-person arrival.
  for(const [depth,z] of [[20,-5],[6.8,11.6]])box(room,.25,10.5,depth,-10,5.15,z,0xd4d3bf).castShadow=false;
  box(room,.25,3.9,3.2,-10,8.45,6.6,0xd4d3bf).castShadow=false;
  for(const z of [4.94,8.26])box(room,3,7,.16,-11.4,3.4,z,0xb7bead);
  box(room,3,.16,3.48,-11.4,6.95,6.6,0xd4d3bf);
  box(room,.16,7,3.48,-12.85,3.4,6.6,0xb7bead);
  // Inward-facing window with deep timber reveals, mullions and a broad sill.
  const window=new THREE.Group();window.position.set(9.84,5,.7);window.rotation.y=-Math.PI/2;room.add(window);
  for(const x of [-3.58,3.58])box(window,.18,5.54,.32,x,0,0,0x46594c);
  for(const y of [-2.68,2.68])box(window,7.34,.18,.32,0,y,0,0x46594c);
  box(window,7.6,.17,.75,0,-2.78,.17,0xb58b60);
  for(const x of [-1.16,1.16])box(window,.095,5.2,.18,x,0,.07,0x46594c);
  box(window,7,.09,.18,0,.48,.07,0x46594c);
  // Floor-height office glazing: blurred interior light behind opaque privacy film.
  const privacyWindow=new THREE.Group();privacyWindow.position.set(-9.8,4.9,.7);privacyWindow.rotation.y=Math.PI/2;room.add(privacyWindow);
  const frost=document.createElement('canvas');frost.width=1024;frost.height=1024;
  const glass=frost.getContext('2d');
  const wash=glass.createLinearGradient(0,0,0,1024);
  wash.addColorStop(0,'#e5e5df');wash.addColorStop(.18,'#cbd3d2');wash.addColorStop(.73,'#d6dbd5');wash.addColorStop(1,'#c8c2ad');
  glass.fillStyle=wash;glass.fillRect(0,0,1024,1024);
  // Soft architectural shadows suggest a shared office without revealing a view.
  glass.save();glass.filter='blur(28px)';
  glass.fillStyle='#788b8c55';
  for(const [x,w] of [[70,35],[290,48],[570,35],[850,55]])glass.fillRect(x,80,w,760);
  glass.fillStyle='#eff1eab0';glass.fillRect(140,180,390,560);glass.fillRect(650,170,145,590);
  glass.fillStyle='#999b8b60';glass.fillRect(-30,800,1100,38);
  glass.fillStyle='#b0a68d45';glass.fillRect(350,880,750,170);glass.restore();
  const frostTexture=new THREE.CanvasTexture(frost);frostTexture.colorSpace=THREE.SRGBColorSpace;
  const frostMaterial=new THREE.MeshStandardMaterial({map:frostTexture,roughness:.72,metalness:.08});
  for(let i=0;i<4;i++){
    const x=-2.925+i*1.95;
    box(privacyWindow,1.88,9.3,.09,x,0,.025,0x697475);
    const geometry=new THREE.PlaneGeometry(1.79,9.16),uv=geometry.attributes.uv;
    for(let j=0;j<uv.count;j++)uv.setX(j,(i+uv.getX(j))/4);
    const pane=new THREE.Mesh(geometry,frostMaterial);pane.position.set(x,0,.076);privacyWindow.add(pane);
    // Narrow etched bands across the upper portion of each pane.
    for(const y of [3.42,3.54,3.66])box(privacyWindow,1.79,.035,.008,x,y,.083,0xe3e7df);
  }
  for(const x of [-3.9,-1.95,0,1.95,3.9]){
    box(privacyWindow,.115,9.5,.22,x,0,.095,0x899394);
    box(privacyWindow,.022,9.46,.012,x-.035,0,.212,0xb4bdbc);
  }
  for(const y of [-4.69,4.69])box(privacyWindow,7.92,.14,.22,0,y,.095,0x899394);
  // Keep the entrance behind the chair, clear of the window and desk picking targets.
  const door=new THREE.Group();door.position.set(-9.8,0,6.6);door.rotation.y=Math.PI/2;room.add(door);
  const hinge=new THREE.Group();hinge.position.set(-1.51,0,.12);door.add(hinge);
  const leaf=new THREE.Group();leaf.position.x=1.51;hinge.add(leaf);
  box(leaf,3.02,6.33,.13,0,3.17,0,0xa77a50);
  for(const x of [-1.71,1.71])box(door,.19,6.8,.3,x,3.4,.09,0x66765e);
  box(door,3.61,.19,.3,0,6.7,.09,0x66765e);
  for(const y of [1.5,4.65]){
    box(leaf,2.55,2.55,.035,0,y,.085,0x8e6746);
    box(leaf,2.35,2.35,.045,0,y,.11,0xb38a5f);
  }
  box(leaf,.17,.46,.09,1.12,3.03,.13,0x37473e);
  box(leaf,.42,.09,.15,.99,3.13,.23,0xc5bb96);
  box(door,3.4,.06,.46,0,.015,.15,0x6c7563);

  const sky=new THREE.HemisphereLight(0xfff6df,0x71846b,2.2);scene.add(sky);
  const sun=new THREE.DirectionalLight(0xffe5bd,4);sun.castShadow=true;
  sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-12,right:12,top:12,bottom:-12});sun.shadow.normalBias=.035;scene.add(sun);
  const fill=new THREE.DirectionalLight(0xaec7ee,.4);fill.position.set(-4,7,5);scene.add(fill);
  const lamp=new THREE.PointLight(0xffce86,0,12,1.5);lamp.position.set(-2.95,3.5,-1.2);scene.add(lamp);
  const glow=new THREE.MeshStandardMaterial({color:0xffd18b,emissive:0xffb957,emissiveIntensity:0});
  const bulb=new THREE.Mesh(new THREE.BoxGeometry(.52,.028,.4),glow);bulb.position.copy(lamp.position);bulb.position.y=3.575;scene.add(bulb);
  let disposed=false;
  const loader=new THREE.TextureLoader();
  const textures=[new URL('../../ui/assets/floor-window-day.jpg',import.meta.url).href,new URL('../../ui/assets/floor-window-night.jpg',import.meta.url).href].map(url=>{
    const texture=loader.load(url,()=>{if(!disposed)redraw();},undefined,()=>{});
    texture.colorSpace=THREE.SRGBColorSpace;texture.repeat.set(.5,.72);texture.offset.set(.25,.14);return texture;
  });
  const panes=textures.map((map,i)=>{
    const material=new THREE.MeshBasicMaterial({map,transparent:i===1,opacity:i===0?1:0,toneMapped:false});
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(7,5.2),material);mesh.position.z=-.14+i*.005;window.add(mesh);return material;
  });
  return {
    arrive(progress){hinge.rotation.y=-Math.PI*.48*(1-THREE.MathUtils.smoothstep(progress,.2,.75));},
    update(now){
      const light=officeDaylight(now.getHours()+now.getMinutes()/60);
      sky.color.set(0xfff6df).lerp(new THREE.Color(0xa7bce3),light.night);sky.intensity=.65+light.ambient*1.6;
      sun.color.copy(light.sun);sun.intensity=light.sunlight*1.15;
      sun.position.set(16,6+light.elevation*10,-2+light.elevation*5);
      fill.intensity=.25+light.night*.25;lamp.intensity=2+light.night*17;glow.emissiveIntensity=.15+light.night*1.8;
      panes[0].color.copy(light.sun).lerp(new THREE.Color(0xffffff),.5);
      panes[1].opacity=THREE.MathUtils.smoothstep(light.night,.25,1);
      return light;
    },
    dispose(){disposed=true;textures.forEach(t=>t.dispose());frostTexture.dispose();frostMaterial.dispose();glow.dispose();sun.shadow.dispose();},
  };
}
