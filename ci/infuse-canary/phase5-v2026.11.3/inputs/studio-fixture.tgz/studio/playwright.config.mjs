import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests/e2e',
  testMatch: '**/*.spec.mjs',
  fullyParallel: true,
  // Use macOS Metal: the software renderer stalls on the furnished Three.js scene.
  use: { baseURL: 'http://127.0.0.1:4318', trace: 'retain-on-failure', ...(process.platform==='darwin'?{launchOptions:{args:['--use-angle=metal','--enable-gpu']}}:{}) },
  projects: [
    { name: 'desktop', use: { browserName: 'chromium', viewport: { width: 1440, height: 900 } } },
    { name: 'mobile', use: { browserName: 'chromium', viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true } }
  ],
  webServer: { command: 'python3 -m http.server 4318 --bind 127.0.0.1 --directory apps/mockup/dist', url: 'http://127.0.0.1:4318', reuseExistingServer: false },
});
