#!/usr/bin/env python3
"""Remove only Docker resources carrying the exact Studio fixture owner token."""
import json

from run_lane import CUSTODY_LABEL, Docker, LANE_LABEL, atomic_json, environment, require


def owned(labels, owner, lane):
    return (labels or {}).get(CUSTODY_LABEL) == owner and (labels or {}).get(LANE_LABEL) == lane


def execute():
    _, evidence, _, _, _ = environment()
    docker = Docker(evidence)
    path = evidence / "owned-resources.json"
    if not path.is_file():
        atomic_json(evidence / "cleanup-proof.json", {"schema": 1, "status": "passed", "removed": [], "remaining": {}})
        return
    state = json.loads(path.read_bytes())
    require(set(state) == {"schema", "owner", "lane", "containers", "volumes", "networks", "disposable"} and state["schema"] == 1, "owned resource state differs")
    owner, lane = state["owner"], state["lane"]
    removed = []
    for key in ("runtime", "mattermost", "postgres", "proxy"):
        name = state["containers"].get(key)
        if not name:
            continue
        result = docker.run(["container", "inspect", name], "cleanup-inspect-" + key, check=False)
        if result.returncode != 0:
            continue
        values = json.loads(result.stdout)
        require(len(values) == 1 and owned(values[0]["Config"]["Labels"], owner, lane), "refusing foreign container cleanup")
        if key in ("proxy", "mattermost"):
            logs = docker.run(["logs", name], "cleanup-log-" + key, check=False)
            (evidence / f"{key}.jsonl").write_bytes(logs.stdout)
        docker.run(["rm", "--force", name], "cleanup-remove-" + key, 180)
        removed.append({"kind": "container", "name": name})
    for name in state["volumes"]:
        result = docker.run(["volume", "inspect", name], "cleanup-inspect-volume", check=False)
        if result.returncode == 0:
            values = json.loads(result.stdout); require(len(values) == 1 and owned(values[0]["Labels"], owner, lane), "refusing foreign volume cleanup")
            docker.run(["volume", "rm", name], "cleanup-remove-volume", 180); removed.append({"kind": "volume", "name": name})
    for name in state["networks"]:
        result = docker.run(["network", "inspect", name], "cleanup-inspect-network", check=False)
        if result.returncode == 0:
            values = json.loads(result.stdout); require(len(values) == 1 and owned(values[0]["Labels"], owner, lane), "refusing foreign network cleanup")
            docker.run(["network", "rm", name], "cleanup-remove-network", 180); removed.append({"kind": "network", "name": name})
    remaining = {}
    for kind, args in (("containers", ["ps", "-aq", "--filter", f"label={CUSTODY_LABEL}={owner}"]),
                       ("volumes", ["volume", "ls", "-q", "--filter", f"label={CUSTODY_LABEL}={owner}"]),
                       ("networks", ["network", "ls", "-q", "--filter", f"label={CUSTODY_LABEL}={owner}"])):
        remaining[kind] = docker.run(args, "cleanup-remaining-" + kind).stdout.decode().split()
    require(not any(remaining.values()), "owned Docker resources remain after cleanup")
    atomic_json(evidence / "cleanup-proof.json", {"schema": 1, "status": "passed", "removed": removed, "remaining": remaining})


if __name__ == "__main__":
    execute()
