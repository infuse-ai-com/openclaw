import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

assert.equal(process.argv.length, 4, "usage: personal-account-proof.mjs HOST_ROOT OUTPUT");
const host = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
const stateDir = join(host, "phase5-openclaw-state");
process.env.OPENCLAW_STATE_DIR = stateDir;
const packageRoot = join(host, "node_modules/openclaw");
const dist = join(packageRoot, "dist");
const moduleFiles = (await readdir(dist)).filter((name) => name.endsWith(".mjs")).sort();
const moduleEvidence = {};

async function loadFunction(signature, functionName) {
  for (const name of moduleFiles) {
    const path = join(dist, name);
    const source = await readFile(path, "utf8");
    if (!source.includes(signature)) continue;
    const loaded = await import(pathToFileURL(path));
    const value = Object.values(loaded).find(
      (candidate) => typeof candidate === "function" && candidate.name === functionName,
    );
    if (value) {
      moduleEvidence[functionName] = {
        file: name,
        sha256: createHash("sha256").update(source).digest("hex"),
      };
      return value;
    }
  }
  assert.fail(`installed candidate does not export ${functionName}`);
}

const [
  resolveSessionAuthSelection,
  applyDelegationCapability,
  withPluginRuntimePluginScope,
  createRuntimeLlm,
  createGatewaySubagentRuntime,
  resolveReactionToolFinalByDefault,
  ensureProfileForEmail,
  connectUserModelAccount,
] = await Promise.all([
  loadFunction("async function resolveSessionAuthSelection", "resolveSessionAuthSelection"),
  loadFunction("function applyDelegationCapability", "applyDelegationCapability"),
  loadFunction("function withPluginRuntimePluginScope", "withPluginRuntimePluginScope"),
  loadFunction("function createRuntimeLlm", "createRuntimeLlm"),
  loadFunction("function createGatewaySubagentRuntime", "createGatewaySubagentRuntime"),
  loadFunction(
    "function resolveReactionToolFinalByDefault",
    "resolveReactionToolFinalByDefault",
  ),
  loadFunction("function ensureProfileForEmail", "ensureProfileForEmail"),
  loadFunction("function connectUserModelAccount", "connectUserModelAccount"),
]);

await mkdir(join(stateDir, "state"), { recursive: true, mode: 0o700 });
const stateOptions = { path: join(stateDir, "state", "openclaw.sqlite") };
const owner = ensureProfileForEmail("phase5-personal@example.invalid", stateOptions);
const { authProfileId: personalProfileId } = connectUserModelAccount(
  {
    ownerProfileId: owner.id,
    credential: {
      type: "oauth",
      provider: "openai",
      access: "synthetic-phase5-access",
      refresh: "synthetic-phase5-refresh",
      expires: Date.now() + 600_000,
    },
    assertCurrent() {},
  },
  stateOptions,
);
const agentDir = join(host, "phase5-personal-account-agent");
await mkdir(agentDir, { recursive: true, mode: 0o700 });
const sessionKey = "agent:main:phase5-personal";
const sessionEntry = {
  sessionId: "phase5-personal-session",
  updatedAt: 1,
  authProfileOverride: personalProfileId,
  authProfileOverrideSource: "auto",
};
const originalSessionEntry = structuredClone(sessionEntry);
const selection = await resolveSessionAuthSelection({
  agentId: "main",
  cfg: {},
  provider: "openai",
  modelId: "gpt-5.6-luna",
  configuredProfileId: "openai:operator-shared",
  agentDir,
  sessionEntry,
  sessionStore: { [sessionKey]: sessionEntry },
  sessionKey,
  isNewSession: false,
});
assert.equal(selection?.profileId, personalProfileId);
assert.equal(selection?.source, "user");
assert.deepEqual(sessionEntry, originalSessionEntry, "selection must not rewrite the personal pin");

const names = [
  "sessions_spawn",
  "sessions_send",
  "openclaw",
  "llm-task",
  "codex_session_send",
  "message",
  "read",
];
const tools = names.map((name) => ({
  name,
  label: name,
  description: name,
  parameters: { type: "object", properties: {} },
  async execute() {
    return { content: [] };
  },
}));
const personalToolNames = applyDelegationCapability(tools, "full", personalProfileId).map(
  (tool) => tool.name,
);
assert.deepEqual(personalToolNames, ["message", "read"]);
assert.equal(applyDelegationCapability(tools, "full", "openai:operator-shared"), tools);

const groupReactionContext = {
  ChatType: "group",
  Provider: "mattermost",
  Surface: "mattermost",
  WasMentioned: true,
};
const reactionCompletion = {
  configuredGroup: resolveReactionToolFinalByDefault({
    ctx: groupReactionContext,
    cfg: { agents: { defaults: { replyCompletion: { group: "message-or-reaction" } } } },
  }),
  surfaceOverride: resolveReactionToolFinalByDefault({
    ctx: groupReactionContext,
    cfg: {
      agents: { defaults: { replyCompletion: { group: "message-or-reaction" } } },
      surfaces: { mattermost: { replyCompletion: { group: "message" } } },
    },
  }),
  directChat: resolveReactionToolFinalByDefault({
    ctx: { ...groupReactionContext, ChatType: "direct" },
    cfg: { agents: { defaults: { replyCompletion: { group: "message-or-reaction" } } } },
  }),
  defaultGroup: resolveReactionToolFinalByDefault({ ctx: groupReactionContext, cfg: {} }),
};
assert.deepEqual(reactionCompletion, {
  configuredGroup: true,
  surfaceOverride: false,
  directChat: false,
  defaultGroup: false,
});

const denialPattern = /Auxiliary plugin inference is unavailable for a personal model-account turn/;
const denialMessages = {};
await withPluginRuntimePluginScope(
  { pluginId: "phase5-personal-proof", personalModelAuthProfileId: personalProfileId },
  async () => {
    const llm = createRuntimeLlm({ getConfig: () => ({}) });
    await assert.rejects(
      llm.complete({
        purpose: "phase5 personal-account spending proof",
        messages: [{ role: "user", content: "This must be denied before model selection." }],
      }),
      (error) => {
        denialMessages.modelTool = String(error?.message ?? error);
        return denialPattern.test(denialMessages.modelTool);
      },
    );
    const subagent = createGatewaySubagentRuntime();
    await assert.rejects(
      subagent.complete({ agentId: "main", message: "This child inference must be denied." }),
      (error) => {
        denialMessages.pluginInference = String(error?.message ?? error);
        return denialPattern.test(denialMessages.pluginInference);
      },
    );
  },
);

const record = {
  schema: 1,
  status: "passed",
  personalProfileId,
  sessionSelection: {
    profileId: selection.profileId,
    source: selection.source,
    sessionPinPreserved: true,
  },
  delegatedRunDenial: {
    requested: names,
    admitted: personalToolNames,
    removed: names.filter((name) => !personalToolNames.includes(name)),
  },
  reactionCompletion,
  denialMessages,
  modules: moduleEvidence,
};
await writeFile(output, JSON.stringify(record, null, 2) + "\n", { mode: 0o600 });
