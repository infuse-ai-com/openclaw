import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";

assert.equal(process.argv.length, 3, "pass exactly one Phase 5 Studio lane");
const lane = process.argv[2]; assert.ok(["managedNative", "ordinaryMattermost"].includes(lane));
const manifestPath = "/phase5/candidate-manifest.json";
const candidate = JSON.parse(await readFile(manifestPath, "utf8"));
assert.equal(candidate.hostVersion, "2026.11.3");
assert.match(candidate.hostCommit, /^[a-f0-9]{40}$/);
assert.match(candidate.hostPackageFile, /^openclaw-2026\.11\.3-[a-f0-9]{10}\.tgz$/);
const archive = join("/phase5/packages", candidate.hostPackageFile);
const sha256 = async (path) => createHash("sha256").update(await readFile(path)).digest("hex");
const before = await sha256(archive); assert.equal(before, candidate.hostPackageSha256);
const env = { ...process.env, HOME: "/work/home", TMPDIR: "/work/tmp", npm_config_cache: "/work/npm-cache",
  npm_config_registry: "https://registry.npmjs.org", npm_config_proxy: "http://proxy:3128", npm_config_https_proxy: "http://proxy:3128", npm_config_noproxy: "" };
for (const path of [env.HOME, env.TMPDIR, env.npm_config_cache, "/work/host"]) await mkdir(path, { recursive: true, mode: 0o700 });
await writeFile("/work/host/package.json", JSON.stringify({ private: true, dependencies: { openclaw: `file:${archive}` } }, null, 2) + "\n");
async function command(binary, args, options = {}) {
  const child = spawn(binary, args, { cwd: options.cwd, env: options.env ?? env, stdio: ["ignore", "pipe", "pipe"] });
  let stdout = "", stderr = "";
  child.stdout.on("data", (chunk) => stdout += chunk); child.stderr.on("data", (chunk) => stderr += chunk);
  const code = await new Promise((resolve, reject) => { child.once("error", reject); child.once("exit", (value) => resolve(value ?? 1)); });
  if (options.stdout) await writeFile(options.stdout, stdout, { mode: 0o600 });
  if (options.stderr) await writeFile(options.stderr, stderr, { mode: 0o600 });
  assert.equal(code, 0, `${binary} ${args[0] ?? ""} failed; inspect private runtime logs`);
  return stdout;
}
await command("npm", ["install", "--omit=dev", "--no-audit", "--no-fund"], { cwd: "/work/host", stdout: "/evidence/host-install.stdout.log", stderr: "/evidence/host-install.stderr.log" });
const host = "/work/host/node_modules/openclaw";
const metadata = JSON.parse(await readFile(join(host, "package.json"), "utf8"));
const build = JSON.parse(await readFile(join(host, "dist/build-info.json"), "utf8"));
assert.equal(metadata.version, candidate.hostVersion); assert.equal(build.commit, candidate.hostCommit);
if (lane === "ordinaryMattermost") {
  await command("node", ["/studio/phase5-fixtures/v2026.11.3/ordinary-mattermost-proof.mjs", "/work/host", "/evidence/ordinary-proof.json"],
    { stdout: "/evidence/ordinary.stdout.log", stderr: "/evidence/ordinary.stderr.log" });
} else {
  await cp("/studio", "/work/studio", { recursive: true, filter: (source) => !source.split("/").includes(".git") });
  await command("npm", ["ci", "--no-audit", "--no-fund"], { cwd: "/work/studio", stdout: "/evidence/studio-install.stdout.log", stderr: "/evidence/studio-install.stderr.log" });
  await command("npm", ["run", "build:plugin"], { cwd: "/work/studio", stdout: "/evidence/studio-build.stdout.log", stderr: "/evidence/studio-build.stderr.log" });
  await command("node", ["/studio/phase5-fixtures/v2026.11.3/personal-account-proof.mjs", "/work/host", "/evidence/personal-account-proof.json"],
    { stdout: "/evidence/personal-account.stdout.log", stderr: "/evidence/personal-account.stderr.log" });
  const nativeWork = "/work/native";
  const nativeEvidence = "/evidence/native";
  const nativeEnv = { ...env, STUDIO_OPENCLAW_ROOT: host, STUDIO_OPENCLAW_CANDIDATE_MANIFEST: manifestPath,
    STUDIO_NATIVE_MATTERMOST_FIXTURE: "/evidence/mattermost-fixture.json", STUDIO_NATIVE_DISPOSABLE_NETWORK: "1",
    STUDIO_NATIVE_NPM_PROXY: "http://proxy:3128", STUDIO_NATIVE_OUTPUT: nativeWork,
    STUDIO_NATIVE_TLS_CERT: "/evidence/native-fixture.crt", STUDIO_NATIVE_TLS_KEY: "/evidence/native-fixture.key",
    STUDIO_PG_DOMAIN_URL: process.env.STUDIO_PG_DOMAIN_URL, STUDIO_PG_TEST_CA: "/evidence/postgres-ca.crt" };
  try {
    await command("node", ["integrations/openclaw-studio/scripts/native-smoke.mjs"], { cwd: "/work/studio", env: nativeEnv,
      stdout: "/evidence/native.stdout.log", stderr: "/evidence/native.stderr.log" });
  } finally {
    await mkdir(nativeEvidence, { recursive: true, mode: 0o700 });
    for (const name of ["proof.json", "failure.json", "cleanup.json", "backend.log", "coordinator-gateway.log", "developer-gateway.log", "designer-gateway.log"]) {
      try { await cp(join(nativeWork, name), join(nativeEvidence, name)); }
      catch (error) { if (error.code !== "ENOENT") throw error; }
    }
  }
}
assert.equal(await sha256(archive), before, "candidate archive changed during Studio qualification");
await writeFile("/evidence/runtime-custody.json", JSON.stringify({ schema: 1, lane, archiveSha256: before, hostVersion: metadata.version,
  hostCommit: build.commit, nodeVersion: process.version, platform: process.platform, architecture: process.arch }, null, 2) + "\n", { mode: 0o600 });
