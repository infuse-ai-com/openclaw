import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readdir, readFile, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { join, resolve } from "node:path";
import { createRequire } from "node:module";

assert.equal(process.argv.length, 4, "usage: ordinary-mattermost-proof.mjs HOST_ROOT OUTPUT");
const host = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
const requireFromHost = createRequire(join(host, "package.json"));
const lifecyclePath = requireFromHost.resolve("openclaw/plugin-sdk/channel-outbound");
const { createLivePreviewLifecycle } = await import(pathToFileURL(lifecyclePath));
const dist = join(host, "node_modules/openclaw/dist");
const loadExportedFunction = async (signature, functionName) => {
  for (const name of (await readdir(dist)).filter((entry) => entry.endsWith(".mjs")).sort()) {
    const path = join(dist, name);
    const value = await readFile(path, "utf8");
    if (!value.includes(signature)) continue;
    const loaded = await import(pathToFileURL(path));
    const fn = Object.values(loaded).find(
      (candidate) => typeof candidate === "function" && candidate.name === functionName,
    );
    if (fn) return { fn, file: name, sha256: createHash("sha256").update(value).digest("hex") };
  }
  assert.fail(`installed candidate does not export ${functionName}`);
};
const reactionRuntime = await loadExportedFunction(
  "function resolveReactionToolFinalByDefault",
  "resolveReactionToolFinalByDefault",
);
const groupReactionContext = {
  ChatType: "group",
  Provider: "mattermost",
  Surface: "mattermost",
  WasMentioned: true,
};
const reactionCompletion = {
  configuredGroup: reactionRuntime.fn({
    ctx: groupReactionContext,
    cfg: { agents: { defaults: { replyCompletion: { group: "message-or-reaction" } } } },
  }),
  surfaceOverride: reactionRuntime.fn({
    ctx: groupReactionContext,
    cfg: {
      agents: { defaults: { replyCompletion: { group: "message-or-reaction" } } },
      surfaces: { mattermost: { replyCompletion: { group: "message" } } },
    },
  }),
  directChat: reactionRuntime.fn({
    ctx: { ...groupReactionContext, ChatType: "direct" },
    cfg: { agents: { defaults: { replyCompletion: { group: "message-or-reaction" } } } },
  }),
  defaultGroup: reactionRuntime.fn({ ctx: groupReactionContext, cfg: {} }),
};
assert.deepEqual(reactionCompletion, {
  configuredGroup: true,
  surfaceOverride: false,
  directChat: false,
  defaultGroup: false,
});
const candidates = (await readdir(dist)).filter((name) => /^monitor-.*\.mjs$/.test(name)).sort();
let sourcePath; let source;
for (const name of candidates) {
  const value = await readFile(join(dist, name), "utf8");
  if (value.includes("function createMattermostDraftStream") && value.includes("function deliverMattermostReplyWithDraftPreview")) {
    sourcePath = join(dist, name); source = value; break;
  }
}
assert.ok(sourcePath && source, "installed candidate does not contain the Mattermost runtime module");
const proofModule = join(dist, `mattermost-phase5-${createHash("sha256").update(source).digest("hex").slice(0, 12)}.mjs`);
await writeFile(proofModule, `${source}\nexport { createMattermostDraftStream, deliverMattermostReplyWithDraftPreview };\n`, { mode: 0o600 });
const { createMattermostDraftStream, deliverMattermostReplyWithDraftPreview } = await import(pathToFileURL(proofModule));

const posts = new Map(); const requests = []; const warnings = [];
let sequence = 0; let failFirstDelete = true;
const parse = (init) => JSON.parse(init?.body ?? "{}");
const request = async (path, init = {}) => {
  requests.push({ path, method: init.method ?? "GET" });
  if (path === "/posts" && init.method === "POST") {
    const body = parse(init); const id = `post-${++sequence}`; const post = { id, message: body.message, type: body.type ?? "" }; posts.set(id, post); return post;
  }
  const id = path.slice("/posts/".length).replace(/\/patch$/, "");
  if (init.method === "DELETE") {
    if (failFirstDelete) { failFirstDelete = false; throw Error("synthetic retained cleanup failure"); }
    posts.delete(id); return {};
  }
  if (init.method === "PUT") {
    const body = parse(init); const post = { ...(posts.get(id) ?? { id }), message: body.message }; posts.set(id, post); return post;
  }
  throw Error(`unexpected request ${init.method ?? "GET"} ${path}`);
};
const client = { baseUrl: "http://mattermost", apiBaseUrl: "http://mattermost/api/v4", token: "disposable", request };
const stream = createMattermostDraftStream({ client, channelId: "fixture-channel", postType: "custom_openclaw_progress", throttleMs: 250, warn: (message) => warnings.push(message) });
stream.update("Working through the disposable qualification"); await stream.flush();
const progressId = stream.postId(); assert.ok(progressId); assert.equal(posts.get(progressId)?.type, "custom_openclaw_progress");
const cleanupFailures = [];
const lifecycle = createLivePreviewLifecycle({
  draft: { flush: stream.flush, id: stream.postId, seal: stream.seal, discardPending: stream.discardPending, clear: stream.clear },
  onCleanupFailure: (error) => cleanupFailures.push(String(error)),
});
const finalText = "Ordinary Mattermost final answer";
const result = await deliverMattermostReplyWithDraftPreview({
  payload: { text: finalText }, info: { kind: "final" }, kind: "direct", client,
  previewLifecycle: lifecycle, separateProgressFinalDelivery: true,
  resolvePreviewFinalText: () => ({ deliveryText: finalText, alreadyDelivered: false }),
  logVerboseMessage: (message) => warnings.push(message),
  deliverPayload: async (payload) => {
    const post = await request("/posts", { method: "POST", body: JSON.stringify({ channel_id: "fixture-channel", message: payload.text }) });
    return { outcome: "text", visibleReplySent: true, messageIds: [post.id], content: post.message,
      receipt: { primaryPlatformMessageId: post.id, platformMessageIds: [post.id], parts: [{ platformMessageId: post.id, kind: "text", index: 0 }] } };
  },
});
const finalId = result.messageIds?.[0]; assert.ok(finalId && finalId !== progressId); assert.equal(posts.get(finalId)?.message, finalText);
await lifecycle.cleanup();
const retainedFailures = warnings.filter((message) => message.includes("synthetic retained cleanup failure"));
const record = { schema: 1, status: "passed", hostModuleSha256: createHash("sha256").update(source).digest("hex"),
  reactionCompletion: { ...reactionCompletion, module: reactionRuntime.file, moduleSha256: reactionRuntime.sha256 },
  requests, progressId, finalId, cleanupFailures, retainedFailures, warnings, remainingPosts: [...posts.values()] };
await writeFile(output, JSON.stringify(record, null, 2) + "\n", { mode: 0o600 });
assert.equal(retainedFailures.length, 1, "the retained cleanup failure must remain observable after its internal retry");
assert.equal(posts.has(progressId), false, "the internal cleanup retry must remove the exact progress post");
assert.equal(posts.get(finalId)?.message, finalText, "cleanup must not retract the accepted ordinary final");
assert.deepEqual(requests.map(({ method }) => method), ["POST", "POST", "DELETE", "DELETE"]);
