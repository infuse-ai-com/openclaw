# OpenClaw 2026.11.3 Studio Phase 5 fixtures

These opt-in adapters execute only the `managedNative` and
`ordinaryMattermost` lanes selected by the authenticated canary plan. They use
an internal owned Docker network, an exact-label cleanup boundary, disposable
credentials, pinned Linux AMD64 images and one registry-only npm proxy.

`managedNative` runs the existing three-Gateway real Mattermost/Studio harness
against the normally installed candidate and records lifecycle, owner/session,
revision/closeout and outage-recovery evidence. It also imports the exact
installed package runtime to prove that a personal account pin survives
selection, delegation tools are withheld, plugin model and subagent inference
fail closed, and the configured group reaction-completion policy is honored.
`ordinaryMattermost` exercises the packaged Mattermost progress/final runtime
with exactly four synthetic transport operations: progress, separate final,
one retained cleanup failure and one successful cleanup retry. It independently
proves the reaction-completion policy from the installed candidate.

No production route, credential, model, publication or deployment is used.
The adapter controller runs `cleanup.py` even after failure; cleanup refuses
every resource without the exact random owner and lane labels written by
`run_lane.py`.
