#!/usr/bin/env python3
"""Run one candidate-bound Studio Phase 5 lane through owned Docker resources."""
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import time
import uuid


ROOT = Path(__file__).resolve().parents[2]
FIXTURE = Path(__file__).resolve().parent
CONTRACT = json.loads((FIXTURE / "candidate-contract.json").read_bytes())
CUSTODY_LABEL = "infuse.phase5.studio-owner"
LANE_LABEL = "infuse.phase5.studio-lane"
MMCTL_CONFIG = "/tmp/phase5-mmctl-config"
MMCTL_TOKEN_FILE = "/phase5-auth/token"
ALLOWED_ENVIRONMENT = {"PHASE5_OUTPUT", "PHASE5_PLAN_DIR", "PHASE5_PACKAGE_DIR", "PHASE5_CANDIDATE_MANIFEST", "PHASE5_LANE", "HOME", "TMPDIR", "PATH", "LANG", "LC_ALL", "LC_CTYPE", "__CF_USER_TEXT_ENCODING"}
CHECKS = {
    "managedNative": ["studioLifecycle", "separateProgressFinal", "requiredOwnerPersistence", "reactionReplyCompletion", "personalAccountIsolation", "modelToolDenial", "delegatedRunDenial", "pluginInferenceDenial", "revisionAndCloseout", "outageRecovery"],
    "ordinaryMattermost": ["separateProgressFinal", "reactionReplyCompletion", "ordinaryFinal", "failureRetention", "postCleanup"],
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    os.chmod(temporary, 0o600)
    temporary.replace(path)


def labels(owner, lane):
    return ["--label", f"{CUSTODY_LABEL}={owner}", "--label", f"{LANE_LABEL}={lane}"]


class Docker:
    def __init__(self, evidence):
        self.evidence = evidence
        self.count = 0

    def run(self, args, label, timeout=120, check=True, stdin=None):
        self.count += 1
        name = f"{self.count:03d}-{label}"
        try:
            result = subprocess.run(["docker", *args], input=stdin, capture_output=True, timeout=timeout, check=False)
        except subprocess.TimeoutExpired as error:
            (self.evidence / f"{name}.stdout.log").write_bytes(error.stdout or b"")
            (self.evidence / f"{name}.stderr.log").write_bytes(error.stderr or b"")
            raise ValueError("Docker operation timed out: " + label) from error
        (self.evidence / f"{name}.stdout.log").write_bytes(result.stdout)
        (self.evidence / f"{name}.stderr.log").write_bytes(result.stderr)
        atomic_json(self.evidence / f"{name}.json", {"argv": ["docker", *args], "returnCode": result.returncode,
                    "stdoutBytes": len(result.stdout), "stderrBytes": len(result.stderr)})
        if check:
            require(result.returncode == 0, "Docker operation failed: " + label)
        return result

    def json(self, args, label, timeout=120):
        return json.loads(self.run(args, label, timeout).stdout)


def environment():
    require(set(os.environ) <= ALLOWED_ENVIRONMENT, "adapter imported an unreviewed environment value")
    require(os.environ.get("LC_CTYPE") in (None, "UTF-8"), "unexpected macOS locale injection")
    for name in os.environ:
        require(re.search(r"TOKEN|SECRET|PASSWORD|COOKIE|CREDENTIAL", name, re.I) is None, "secret-shaped adapter environment name")
    output = Path(os.environ["PHASE5_OUTPUT"]).resolve(strict=True)
    evidence = output / "evidence"
    plan = Path(os.environ["PHASE5_PLAN_DIR"]).resolve(strict=True)
    packages = Path(os.environ["PHASE5_PACKAGE_DIR"]).resolve(strict=True)
    candidate = Path(os.environ["PHASE5_CANDIDATE_MANIFEST"]).resolve(strict=True)
    require(evidence.is_dir() and packages == plan / "packages" and candidate == plan / "candidate-manifest.json", "adapter paths differ")
    return output, evidence, plan, packages, candidate


def write_state(evidence, state):
    atomic_json(evidence / "owned-resources.json", state)


def wait(docker, args, label, attempts=120, interval=.5):
    for index in range(attempts):
        result = docker.run(args, f"{label}-{index + 1}", check=False)
        if result.returncode == 0:
            return result
        time.sleep(interval)
    raise ValueError(label + " did not become ready")


def wait_output(docker, args, expected, label, attempts=120, interval=.5):
    for index in range(attempts):
        result = docker.run(args, f"{label}-{index + 1}", check=False)
        if result.returncode == 0 and expected in result.stdout.decode(errors="replace"):
            return result
        time.sleep(interval)
    raise ValueError(label + " did not become ready")


def inspect_image(docker, image, expected_architecture, label):
    values = docker.json(["image", "inspect", image], label)
    require(len(values) == 1 and values[0]["Os"] == "linux" and values[0]["Architecture"] == expected_architecture, label + " platform differs")
    return values[0]["Id"]


def preflight(docker, lane):
    info = docker.json(["info", "--format", "{{json .}}"], "docker-info")
    cpus, memory = (4, 11 * 1024**3) if lane == "managedNative" else (2, 2 * 1024**3)
    require(info["NCPU"] >= cpus and info["MemTotal"] >= memory, "Docker resources are below the lane contract")
    images = {"node": inspect_image(docker, CONTRACT["node"]["amd64Image"], "amd64", "node-image")}
    if lane == "managedNative":
        images["postgres"] = inspect_image(docker, CONTRACT["postgres"]["image"], "amd64", "postgres-image")
        images["mattermost"] = inspect_image(docker, CONTRACT["mattermost"]["image"], "amd64", "mattermost-image")
    atomic_json(docker.evidence / "host-admission.json", {"schema": 1, "lane": lane, "cpus": info["NCPU"], "memoryBytes": info["MemTotal"], "architecture": info["Architecture"], "images": images})


def extract(value, names):
    if isinstance(value, dict):
        for name in names:
            item = value.get(name)
            if isinstance(item, str) and item:
                return item
        for item in value.values():
            found = extract(item, names)
            if found:
                return found
    if isinstance(value, list):
        for item in value:
            found = extract(item, names)
            if found:
                return found


def mmctl(docker, container, args, label):
    result = docker.run(["exec", container, "mmctl", "--local", "--json", *args], "mmctl-" + label)
    return json.loads(result.stdout)


def mmctl_remote(docker, container, args, label):
    result = docker.run(["exec", "--user", "0", container, "mmctl", "--config", MMCTL_CONFIG, "--json", *args], "mmctl-" + label)
    return json.loads(result.stdout)


def provision_mattermost(docker, state, evidence):
    pg = state["containers"]["postgres"]
    mm = state["containers"]["mattermost"]
    pg_password = state["disposable"]["postgresPassword"]
    mm_password = state["disposable"]["mattermostPassword"]
    docker.run(["exec", "--user", "root", pg, "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1", "-subj", "/CN=postgres", "-addext", "subjectAltName=DNS:postgres,IP:127.0.0.1", "-keyout", "/tmp/server.key", "-out", "/tmp/server.crt"], "postgres-tls")
    docker.run(["exec", "--user", "root", pg, "chown", "postgres:postgres", "/tmp/server.key", "/tmp/server.crt"], "postgres-tls-owner")
    docker.run(["exec", "--user", "root", pg, "chmod", "600", "/tmp/server.key"], "postgres-tls-mode")
    for setting in ("ssl_cert_file='/tmp/server.crt'", "ssl_key_file='/tmp/server.key'", "ssl=on"):
        docker.run(["exec", pg, "psql", "-U", "postgres", "-d", "studio_pg_synthetic_root", "-c", "ALTER SYSTEM SET " + setting], "postgres-setting")
    docker.run(["exec", pg, "psql", "-U", "postgres", "-d", "studio_pg_synthetic_root", "-c", "SELECT pg_reload_conf()"], "postgres-reload")
    docker.run(["cp", f"{pg}:/tmp/server.crt", str(evidence / "postgres-ca.crt")], "postgres-ca-copy")
    docker.run(["exec", "--user", "root", pg, "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1", "-subj", "/CN=localhost", "-addext", "subjectAltName=IP:127.0.0.1,DNS:localhost", "-keyout", "/tmp/native-fixture.key", "-out", "/tmp/native-fixture.crt"], "native-tls")
    docker.run(["cp", f"{pg}:/tmp/native-fixture.crt", str(evidence / "native-fixture.crt")], "native-tls-cert-copy")
    docker.run(["cp", f"{pg}:/tmp/native-fixture.key", str(evidence / "native-fixture.key")], "native-tls-key-copy")
    os.chmod(evidence / "native-fixture.key", 0o600)
    docker.run(["exec", pg, "psql", "-U", "postgres", "-d", "studio_pg_synthetic_root", "-c", f"CREATE ROLE mattermost LOGIN PASSWORD '{mm_password}'"], "mattermost-role")
    docker.run(["exec", pg, "psql", "-U", "postgres", "-d", "studio_pg_synthetic_root", "-c", "CREATE DATABASE mattermost OWNER mattermost"], "mattermost-database")
    docker.run(["start", mm], "mattermost-start")
    wait(docker, ["exec", mm, "mmctl", "--local", "system", "status"], "mattermost-ready", attempts=180, interval=1)
    human_password = secrets.token_urlsafe(24)
    human = mmctl(docker, mm, ["user", "create", "--email", "human@fixture.invalid", "--username", "fixture-human", "--password", human_password, "--system-admin", "--email-verified"], "human-create")
    human_id = extract(human, ("id", "user_id")); require(human_id, "Mattermost human id missing")
    human_token_value = mmctl(docker, mm, ["token", "generate", "fixture-human", "phase5-reader"], "human-token")
    human_token = extract(human_token_value, ("token",)); require(human_token, "Mattermost human token missing")
    token_path = evidence / "mattermost-auth" / "token"
    token_fd = os.open(token_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(token_fd, "w") as token_file:
        token_file.write(human_token + "\n")
    try:
        docker.run(["exec", "--user", "0", mm, "mmctl", "--config", MMCTL_CONFIG, "auth", "login", "http://127.0.0.1:8065", "--name", "phase5", "--access-token-file", MMCTL_TOKEN_FILE], "mmctl-auth-login")
    finally:
        token_path.unlink(missing_ok=True)
    mmctl(docker, mm, ["team", "create", "--name", "phase5", "--display-name", "Phase 5"], "team-create")
    roles = []
    for role in ("coordinator", "developer", "designer"):
        username = "phase5-" + role
        bot = mmctl_remote(docker, mm, ["bot", "create", username, "--display-name", role.title(), "--with-token"], "bot-" + role)
        bot_id = extract(bot, ("user_id", "id")); token = extract(bot, ("token",))
        require(bot_id and token, "Mattermost bot identity missing: " + role)
        channel_name = "lane-" + role
        channel = mmctl(docker, mm, ["channel", "create", "--team", "phase5", "--name", channel_name, "--display-name", role.title()], "channel-" + role)
        channel_id = extract(channel, ("id",)); require(channel_id, "Mattermost channel id missing: " + role)
        roles.append({"role": role, "agentId": role, "accountId": "phase5-" + role, "nativeBotUserId": bot_id,
                      "nativeUsername": username, "token": token, "channelId": channel_id, "channelName": channel_name})
    docker.run(["exec", "--user", "0", mm, "mmctl", "--config", MMCTL_CONFIG, "auth", "delete", "phase5"], "mmctl-auth-cleanup")
    all_users = ["fixture-human", *[item["nativeUsername"] for item in roles]]
    mmctl(docker, mm, ["team", "users", "add", "phase5", *all_users], "team-members")
    coordinator = roles[0]["nativeUsername"]
    for item in roles:
        members = ["fixture-human", coordinator]
        if item["nativeUsername"] != coordinator:
            members.append(item["nativeUsername"])
        mmctl(docker, mm, ["channel", "users", "add", f"phase5:{item['channelName']}", *members], "channel-members-" + item["role"])
        item.pop("channelName")
    fixture = {"origin": "http://mattermost:8065", "image": CONTRACT["mattermost"]["image"], "readerToken": human_token,
               "human": {"userId": human_id, "token": human_token}, "roles": roles, "installationId": "phase5-disposable"}
    atomic_json(evidence / "mattermost-fixture.json", fixture)
    return f"postgresql://postgres:{pg_password}@postgres:5432/studio_pg_synthetic_root"


def create_resources(docker, lane, evidence, plan, packages, candidate):
    owner = uuid.uuid4().hex
    stem = f"phase5-studio-{lane.lower()}-{owner[:10]}"
    state = {"schema": 1, "owner": owner, "lane": lane,
             "containers": {"runtime": stem + "-runtime", "proxy": stem + "-proxy", "postgres": stem + "-postgres" if lane == "managedNative" else None,
                            "mattermost": stem + "-mattermost" if lane == "managedNative" else None},
             "volumes": [stem + "-work"], "networks": [stem + "-network"],
             "disposable": {"postgresPassword": secrets.token_hex(24), "mattermostPassword": secrets.token_hex(24)}}
    write_state(evidence, state)
    network = state["networks"][0]; volume = state["volumes"][0]
    docker.run(["network", "create", "--internal", *labels(owner, lane), network], "network-create")
    docker.run(["volume", "create", *labels(owner, lane), volume], "volume-create")
    node = CONTRACT["node"]["amd64Image"]
    docker.run(["run", "--rm", "--pull", "never", "--platform", "linux/amd64", "--network", "none", *labels(owner, lane), "--cap-drop", "ALL", "--cap-add", "CHOWN", "--security-opt", "no-new-privileges", "--mount", f"source={volume},target=/work", node, "sh", "-c", "chown 1000:1000 /work"], "work-owner", 180)
    proxy = state["containers"]["proxy"]
    docker.run(["create", "--name", proxy, "--pull", "never", "--platform", "linux/amd64", "--network", network, "--network-alias", "proxy", *labels(owner, lane),
                "--user", "1000:1000", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--pids-limit", "128", "--memory", "256m", "--cpus", "0.5",
                "--tmpfs", "/tmp:rw,noexec,nosuid,size=32m", "--mount", f"type=bind,src={FIXTURE},dst=/fixture,readonly", node, "node", "/fixture/proxy.mjs"], "proxy-create")
    docker.run(["network", "connect", "bridge", proxy], "proxy-public-connect")
    docker.run(["start", proxy], "proxy-start")
    wait_output(docker, ["logs", proxy], '"kind":"ready"', "proxy-ready", attempts=30, interval=.2)
    pg_url = None
    if lane == "managedNative":
        pg = state["containers"]["postgres"]
        docker.run(["create", "--name", pg, "--pull", "never", "--platform", "linux/amd64", "--network", network, "--network-alias", "postgres", *labels(owner, lane),
                    "--memory", "768m", "--memory-swap", "768m", "--cpus", "0.75", "--pids-limit", "256", "--tmpfs", "/var/lib/postgresql/data:rw,nosuid,size=1g",
                    "--env", f"POSTGRES_PASSWORD={state['disposable']['postgresPassword']}", "--env", "POSTGRES_DB=studio_pg_synthetic_root", CONTRACT["postgres"]["image"]], "postgres-create")
        docker.run(["start", pg], "postgres-start")
        wait(docker, ["exec", pg, "pg_isready", "-h", "127.0.0.1", "-U", "postgres", "-d", "studio_pg_synthetic_root"], "postgres-ready")
        mm = state["containers"]["mattermost"]
        mattermost_auth = evidence / "mattermost-auth"
        mattermost_auth.mkdir(mode=0o700)
        dsn = f"postgres://mattermost:{state['disposable']['mattermostPassword']}@postgres:5432/mattermost?sslmode=disable&connect_timeout=10"
        docker.run(["create", "--name", mm, "--pull", "never", "--platform", "linux/amd64", "--network", network, "--network-alias", "mattermost", *labels(owner, lane),
                    "--memory", "1280m", "--memory-swap", "1280m", "--cpus", "1", "--pids-limit", "512",
                    "--tmpfs", "/mattermost/config:rw,nosuid,uid=2000,gid=2000,mode=0700,size=64m",
                    "--tmpfs", "/mattermost/data:rw,nosuid,uid=2000,gid=2000,mode=0700,size=128m",
                    "--tmpfs", "/mattermost/logs:rw,nosuid,uid=2000,gid=2000,mode=0700,size=64m",
                    "--tmpfs", "/mattermost/plugins:rw,nosuid,uid=2000,gid=2000,mode=0700,size=64m",
                    "--tmpfs", "/mattermost/client/plugins:rw,nosuid,uid=2000,gid=2000,mode=0700,size=64m",
                    "--mount", f"type=bind,src={mattermost_auth},dst=/phase5-auth,readonly",
                    "--env", "MM_SQLSETTINGS_DRIVERNAME=postgres", "--env", f"MM_SQLSETTINGS_DATASOURCE={dsn}", "--env", "MM_SERVICESETTINGS_SITEURL=http://mattermost:8065",
                    "--env", "MM_SERVICESETTINGS_ENABLEUSERACCESSTOKENS=true", "--env", "MM_SERVICESETTINGS_ENABLEBOTACCOUNTCREATION=true", "--env", "MM_SERVICESETTINGS_ENABLELOCALMODE=true",
                    "--env", "MM_TEAMSETTINGS_ENABLEOPENSERVER=false", "--env", "MM_LOGSETTINGS_CONSOLELEVEL=ERROR", CONTRACT["mattermost"]["image"]], "mattermost-create")
        pg_url = provision_mattermost(docker, state, evidence)
    runtime = state["containers"]["runtime"]
    memory, cpus = ("8g", "4") if lane == "managedNative" else ("2g", "2")
    create = ["create", "--name", runtime, "--pull", "never", "--platform", "linux/amd64", "--network", network, *labels(owner, lane), "--user", "1000:1000", "--read-only", "--init",
              "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--pids-limit", "4096", "--memory", memory, "--memory-swap", memory, "--cpus", cpus,
              "--tmpfs", "/tmp:rw,nosuid,size=512m", "--mount", f"source={volume},target=/work", "--mount", f"type=bind,src={ROOT},dst=/studio,readonly",
              "--mount", f"type=bind,src={evidence},dst=/evidence", "--mount", f"type=bind,src={candidate},dst=/phase5/candidate-manifest.json,readonly",
              "--mount", f"type=bind,src={packages},dst=/phase5/packages,readonly"]
    if pg_url:
        create += ["--env", f"STUDIO_PG_DOMAIN_URL={pg_url}"]
    create += [node, "node", "/studio/phase5-fixtures/v2026.11.3/runtime-entry.mjs", lane]
    docker.run(create, "runtime-create", 180)
    return state


def result(lane, evidence):
    custody = json.loads((evidence / "runtime-custody.json").read_bytes())
    if lane == "ordinaryMattermost":
        proof = json.loads((evidence / "ordinary-proof.json").read_bytes())
        reaction = proof["reactionCompletion"]
        require(proof["status"] == "passed" and len(proof["requests"]) == 4 and len(proof["remainingPosts"]) == 1 and
                reaction["configuredGroup"] is True and reaction["surfaceOverride"] is False and
                reaction["directChat"] is False and reaction["defaultGroup"] is False,
                "ordinary Mattermost proof differs")
        checks = {
            "separateProgressFinal": {"status": "passed", "metrics": {"progressPostId": proof["progressId"], "finalPostId": proof["finalId"], "distinct": True}},
            "reactionReplyCompletion": {"status": "passed", "metrics": {"configuredGroup": True, "surfaceOverride": False,
                                                                            "directChat": False, "defaultGroup": False,
                                                                            "candidateModuleSha256": reaction["moduleSha256"]}},
            "ordinaryFinal": {"status": "passed", "metrics": {"remainingPosts": len(proof["remainingPosts"]), "candidateModuleSha256": proof["hostModuleSha256"]}},
            "failureRetention": {"status": "passed", "metrics": {"retainedFailures": len(proof["retainedFailures"]), "requestsBeforeRetry": 3}},
            "postCleanup": {"status": "passed", "metrics": {"mattermostRequests": len(proof["requests"]), "progressRemaining": False}},
        }
        limits = ["Synthetic disposable Mattermost transport; no production credentials or real model inference"]
    else:
        proof = json.loads((evidence / "native/proof.json").read_bytes())
        cleanup = json.loads((evidence / "native/cleanup.json").read_bytes())
        personal = json.loads((evidence / "personal-account-proof.json").read_bytes())
        view = proof["finalView"]
        receipts = proof["actualGatewayRunReceipts"]
        notices = [item for item in view["provisioning"] if item["kind"] == "lifecycle"]
        require(proof["realMattermost"] is True and view["mission"]["state"] == "closed" and not cleanup["cleanupErrors"] and
                personal["status"] == "passed" and personal["sessionSelection"]["sessionPinPreserved"] is True and
                personal["reactionCompletion"]["configuredGroup"] is True and
                personal["reactionCompletion"]["surfaceOverride"] is False and
                personal["delegatedRunDenial"]["admitted"] == ["message", "read"] and
                "Auxiliary plugin inference is unavailable" in personal["denialMessages"]["modelTool"] and
                "Auxiliary plugin inference is unavailable" in personal["denialMessages"]["pluginInference"],
                "managed native proof differs")
        checks = {
            "studioLifecycle": {"status": "passed", "metrics": {"gateways": proof["nativeGatewayCount"], "runtimeRunReceipts": len(receipts), "missionState": "closed"}},
            "separateProgressFinal": {"status": "passed", "metrics": {"lifecycleNotices": len(notices), "deliveredEvidence": len(view["evidence"]), "closeNotices": len([n for n in notices if n["lifecycle"]["event"] == "closed"])}},
            "requiredOwnerPersistence": {"status": "passed", "metrics": {"taskThreads": len([item for item in view["threads"] if item["kind"] == "task"]), "gatewayRunReceipts": len(receipts)}},
            "reactionReplyCompletion": {"status": "passed", "metrics": personal["reactionCompletion"]},
            "personalAccountIsolation": {"status": "passed", "metrics": personal["sessionSelection"]},
            "modelToolDenial": {"status": "passed", "metrics": {"denied": True, "candidateModuleSha256": personal["modules"]["createRuntimeLlm"]["sha256"]}},
            "delegatedRunDenial": {"status": "passed", "metrics": {"removed": personal["delegatedRunDenial"]["removed"],
                                                                           "candidateModuleSha256": personal["modules"]["applyDelegationCapability"]["sha256"]}},
            "pluginInferenceDenial": {"status": "passed", "metrics": {"denied": True, "candidateModuleSha256": personal["modules"]["createGatewaySubagentRuntime"]["sha256"]}},
            "revisionAndCloseout": {"status": "passed", "metrics": {"revisionNotices": len([n for n in notices if n["lifecycle"]["event"] == "revision"]), "closedFindings": len([f for f in view["findings"] if f["state"] == "closed"])}},
            "outageRecovery": {"status": "passed", "metrics": proof["serviceHealthRecovery"]},
        }
        limits = ["Synthetic deterministic model; no production credentials or real model inference", "Disposable Mattermost and PostgreSQL only"]
    atomic_json(evidence / "fixture-result.json", {"schema": 1, "status": "passed", "checks": checks, "scopeLimits": limits, "reason": ""})


def execute(lane):
    require(lane in CHECKS and os.environ["PHASE5_LANE"] == lane, "unknown or mismatched Studio lane")
    output, evidence, plan, packages, candidate = environment()
    docker = Docker(evidence); preflight(docker, lane)
    state = create_resources(docker, lane, evidence, plan, packages, candidate)
    runtime = state["containers"]["runtime"]
    docker.run(["start", "--attach", runtime], "runtime-run", 7000 if lane == "managedNative" else 3400)
    result(lane, evidence)


if __name__ == "__main__":
    require(len(sys.argv) == 2, "pass exactly one Studio Phase 5 lane")
    execute(sys.argv[1])
