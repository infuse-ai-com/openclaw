import {chromium} from 'playwright';
import sharp from 'sharp';
import {captureWhiteboard} from './capture.mjs';
const controller=new AbortController();process.once('SIGTERM',()=>controller.abort());process.once('SIGINT',()=>controller.abort());
const parts=[];let size=0;
try {
 for await(const part of process.stdin){size+=part.length;if(size>12*1024*1024)throw Error('Input limit');parts.push(part);}
 const png=await captureWhiteboard(JSON.parse(Buffer.concat(parts).toString('utf8')),{chromium,sharp,signal:controller.signal});
 process.stdout.write(png);
} catch {process.exitCode=1;} // Never log source content or browser diagnostics.
