import {readFileSync} from 'node:fs';

/** Refuse a listener without the qualified outer sandbox and container PID ceiling. */
export function assertRendererRuntime({
  read = path => readFileSync(path, 'utf8'),
  platform = process.platform,
  uid = process.getuid?.(),
} = {}) {
  if (platform !== 'linux' || uid !== 10001) throw Error('Renderer requires its isolated Linux identity');
  const status = Object.fromEntries(read('/proc/self/status').split('\n')
    .filter(line => line.includes(':')).map(line => {
      const split = line.indexOf(':');
      return [line.slice(0, split), line.slice(split + 1).trim()];
    }));
  if (status.NoNewPrivs !== '1' || status.Seccomp !== '2' || !/^0+$/.test(status.CapEff ?? '')) {
    throw Error('Renderer sandbox protections are missing');
  }
  // A node label or a requested limit is not evidence that this container has it.
  // Require the visible cgroup's own hard limit; an inaccessible parent is unknown.
  const pids = read('/sys/fs/cgroup/pids.max').trim();
  if (!/^\d+$/.test(pids) || Number(pids) < 32 || Number(pids) > 256) {
    throw Error('Renderer requires a cgroup PID ceiling between 32 and 256');
  }
}
