import {whiteboardRenderBundle,ARTIFACT_CONTENT_SECURITY_POLICY} from '@studio/contracts';
/** Dependency injection is for the pinned offline proof; production supplies its installed libraries. */
export async function captureWhiteboard(input,{chromium,sharp,executablePath='/usr/bin/chromium',signal}) {
 if(process.getuid?.()===0)throw Error('Renderer must be non-root');
 const bundle=whiteboardRenderBundle.parse(input);
 const cleanImage=async encoded=>{
  const bytes=Buffer.from(encoded,'base64');if(bytes.length>7*1024*1024)throw Error('Image byte limit');
  const source=sharp(bytes,{limitInputPixels:16_000_000,failOn:'warning',animated:false});
  const metadata=await source.metadata();if(metadata.format!=='webp'||(metadata.pages??1)!==1)throw Error('Expected still verified WebP');
  return source.webp().toBuffer(); // Decode fully under the pixel limit before embedding.
 };
 let document;
 if(bundle.kind==='html')document=bundle.content;
 else if(bundle.kind==='svg') {
  // Images in a generated overview/region are data-only, decoded under the same limit.
  let svg=bundle.content;
  const matches=[...svg.matchAll(/data:image\/webp;base64,([A-Za-z0-9+/=]+)/g)];
  if(matches.length>100)throw Error('Image count limit');
  for(const match of matches)svg=svg.replace(match[0],'data:image/webp;base64,'+(await cleanImage(match[1])).toString('base64'));
  document=`<body style="margin:0"><img style="display:block;width:100vw;height:100vh" src="data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}">`;
 } else {
  const bytes=await cleanImage(bundle.content),c=bundle.crop??{x:0,y:0,width:1,height:1};
  document=bundle.crop==null
   ? `<body style="margin:0;background:white"><img style="display:block;width:100vw;height:100vh;object-fit:contain" src="data:image/webp;base64,${bytes.toString('base64')}">`
   : `<body style="margin:0;overflow:hidden"><div style="position:relative;width:100vw;height:100vh;overflow:hidden"><img style="position:absolute;width:${100/c.width}%;height:${100/c.height}%;left:${-100*c.x/c.width}%;top:${-100*c.y/c.height}%" src="data:image/webp;base64,${bytes.toString('base64')}"></div>`;
 }
 signal?.throwIfAborted();
 const browser=await chromium.launch({executablePath,chromiumSandbox:true,headless:true,timeout:4000,args:['--disable-dev-shm-usage']});
 const abort=()=>void browser.close();signal?.addEventListener('abort',abort,{once:true});
 try {
  const context=await browser.newContext({viewport:bundle.kind==='html'&&bundle.viewport?bundle.viewport:{width:bundle.width,height:bundle.height},serviceWorkers:'block',acceptDownloads:false});
  const page=await context.newPage();let navigations=0;
  context.on('page',popup=>{if(popup!==page)void popup.close();});
  await context.route('**/*',route=>{
   // Fulfill one synthetic document; no URL is ever fetched by the browser.
   if(route.request().url()==='https://capture.invalid/'&&++navigations===1)
    return route.fulfill({status:200,contentType:'text/html',headers:{'Content-Security-Policy':ARTIFACT_CONTENT_SECURITY_POLICY},body:document});
   return route.abort('blockedbyclient');
  });
  await page.goto('https://capture.invalid/',{waitUntil:'load',timeout:4000});
  await page.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})));});
  await page.waitForTimeout(150); // Bounded initial script/layout settling, never a network-idle wait.
  signal?.throwIfAborted();const raw=await page.screenshot({type:'png',timeout:2000});signal?.throwIfAborted();
  const png=await sharp(raw,{limitInputPixels:16_000_000}).resize(bundle.width,bundle.height,{fit:'fill'}).png({palette:true,colours:256}).toBuffer();
  if(png.length>1024*1024)throw Error('PNG exceeds budget');return png;
 } finally {signal?.removeEventListener('abort',abort);await browser.close();}
}
