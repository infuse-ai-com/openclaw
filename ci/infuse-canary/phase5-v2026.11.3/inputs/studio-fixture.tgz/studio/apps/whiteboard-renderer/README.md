# Whiteboard renderer

October 22 scope: **both Chromium and the proposed SVG-to-PNG agent renderer are deferred**.
Prioritize structured board data and companion dogfood. Retained setup/qualification
instructions below are conditional reference; they do not authorize host changes
or renderer activation. [Current decision](../../docs/plans/active/020-collaborative-whiteboard/renderer-options.md).

Production is deferred by Fito (2026-10-21). Do not run the shared-VM setup.
[Scope and alternatives](../../docs/plans/active/020-collaborative-whiteboard/renderer-options.md)
separate this optional visual worker from the continuing nonvisual W5.4 rollout.

A stateless, credential-free Chromium worker for W5.3. Studio collects saved
revision-pinned content and verified Registry bytes. This service accepts a
bounded bundle, returns one PNG, and retains neither. It has no Registry client,
Studio database, model credentials, service-account token or arbitrary URL input.

Build the optional image from the repository root:

```sh
docker build --target whiteboard-renderer -t studio-whiteboard-renderer:w53 .
```

The default Docker target remains the Studio application. The separate
[production release package](../../infrastructure/production/whiteboard-renderer/README.md)
is prepared; it is not registered, published or deployed yet. Qualify its node and
release through the reviewed main pipeline before setting
`whiteboardAgents.rendererUrl` to its internal root URL. Do not point production
at a workstation worker or place this worker in Studio's network-enabled pod.

Required deployment contract:

- Separate non-root container (UID/GID 10001), read-only root, all capabilities
  dropped, no-new-privileges, no host/state/credential mounts, no service account.
- Chromium sandbox enabled. Install the reviewed qualification seccomp profile
  on the selected nodes; never use `--no-sandbox` or an unconfined fallback.
- Deny all egress, including DNS, loopback forwarding and metadata routes. Allow
  ingress only from the Studio backend on port 4330; no public ingress.
- 2 GiB memory, two CPUs, 256 PID bound and 512 MiB memory-backed `/tmp`.
- The image supplies its own init process. Startup refuses an unqualified identity,
  sandbox settings or a missing/unbounded visible container cgroup PID limit.
- One capture at a time. Studio admits at most four queued requests and one
  outstanding request per actor. Request cancellation/deadline closes Chromium;
  if cleanup hangs the service exits so the container runtime kills all children.
- `GET /health` for probes; `POST /render` accepts a versioned byte-only bundle.
  The source limit is 12 MiB serialized; HTML is further limited to 2 MiB,
  decoded images to 16 million pixels, output to 1600×1000 and 1 MiB PNG.
  No request/response bodies or browser diagnostics are logged.

HTML uses the existing opaque-origin Artifact CSP. It runs at the tile's saved
viewport size and is reduced to the output limit. The screenshot shows that
viewport after a bounded initial layout settle, not all scrollable content or
semantic truth. Region output omits HTML/section interiors and reports text
clipping; exact saved text/HTML-source reads remain separate.

Local qualification (owned offline containers are removed):

```sh
node scripts/studio-whiteboard-visual-smoke.mjs
node scripts/studio-whiteboard-renderer-abuse.mjs
node scripts/studio-whiteboard-renderer-http-smoke.mjs
```

The first runs native tools → authenticated Studio → exact Registry reads →
this image. The second checks CSP/opaque origin, network, worker and popup
blocking, image decompression limits, infinite scripts and cancellation. They do
not enable production access or create backups. The separate four-mode model
proof consumes these synthetic captures and approved access-only input; it never
puts credentials in the renderer.
