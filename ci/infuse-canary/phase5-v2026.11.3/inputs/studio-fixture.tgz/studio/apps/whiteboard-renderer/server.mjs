import {assertRendererRuntime} from './runtime-guard.mjs';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
let active=false;
export const server=createServer(async(req,res)=>{
 if(req.method==='GET'&&req.url==='/health'){res.end('ok');return;}
 if(req.method!=='POST'||req.url!=='/render'){res.writeHead(404).end();return;}
 if(active){res.writeHead(503).end();return;}active=true;
 let child,timer,cleanupTimer;const stop=()=>{if(child?.pid&&child.exitCode===null&&child.signalCode===null){child.kill('SIGTERM');cleanupTimer??=setTimeout(()=>process.exit(1),750);}};
 res.on('close',stop);
 try {
  timer=setTimeout(()=>{stop();res.destroy();},7500);
  const parts=[];let size=0;for await(const part of req){size+=part.length;if(size>12*1024*1024)throw Error();parts.push(part);}
  child=spawn(process.execPath,[fileURLToPath(new URL('./worker.mjs',import.meta.url))],{detached:true,stdio:['pipe','pipe','ignore'],env:{PATH:process.env.PATH,HOME:'/tmp'}});
  const out=[];let length=0;child.stdout.on('data',part=>{length+=part.length;if(length>1024*1024)stop();else out.push(part);});child.stdin.on('error',()=>{});child.stdin.end(Buffer.concat(parts));
  const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',resolve);});
  if(code!==0||length>1024*1024)throw Error();res.writeHead(200,{'Content-Type':'image/png','Cache-Control':'no-store'}).end(Buffer.concat(out));
 } catch {if(!res.destroyed)res.writeHead(503).end();}
 finally{clearTimeout(timer);if(child?.exitCode!==null||child?.signalCode!==null)clearTimeout(cleanupTimer);else stop();active=false;res.removeListener('close',stop);}
});
server.requestTimeout=8000;server.headersTimeout=5000;server.maxConnections=6;
if(process.argv[1]===fileURLToPath(import.meta.url)){assertRendererRuntime();server.listen(Number(process.env.PORT??4330),'0.0.0.0');}
