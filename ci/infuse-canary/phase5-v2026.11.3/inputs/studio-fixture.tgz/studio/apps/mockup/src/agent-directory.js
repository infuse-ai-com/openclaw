import {companySkillsWorkspace,createCapabilitiesController} from './skill-guides.js';
import {companyPeople} from './simulation/company.js';
import {esc} from './connected-parts.js';

const voices={
 emon:{line:'Big ambition. Small, owned steps.',about:'I turn the big, unfinished thought into a mission the team can actually deliver. I ask the awkward scope questions, connect the right specialists and keep the next decision visible.',signature:'Make the next decision obvious.',theme:'ember',discipline:'Coordination'},
 kapiteky:{line:'A better question changes the work.',about:'I connect the work to why we are doing it. Bring me a confident assumption, an unclear tradeoff or a proposal that needs a second perspective. I will help separate evidence from conviction.',signature:'Find the assumption hiding in plain sight.',theme:'teal',discipline:'Strategy & review'},
 tinus:{line:'Make it work. Show that it works.',about:'I turn approved ideas into something you can use. I like small working slices, inspectable code and browser evidence that survives a second look. A convincing demo should also be an honest one.',signature:'Replace “should work” with a runnable proof.',theme:'blue',discipline:'Engineering'},
 satwa:{line:'Tomorrow should be reproducible.',about:'I think about the handoff after the handoff: the build, the environment and the person who has to run it next. I turn hidden setup and operational gaps into concrete, verifiable steps.',signature:'Make the second run as clear as the first.',theme:'ochre',discipline:'Infrastructure'},
 stewie:{line:'Make the next move feel natural.',about:'I start with the person on the other side of the screen. I shape the hierarchy, question the extra click and make rough ideas tangible enough to try. Details matter when they make the whole experience easier.',signature:'Remove the explanation the interface should not need.',theme:'plum',discipline:'Product & design'},
 ramiro:{line:'No surprises. Clear next steps.',about:'I keep client expectations connected to the work. I clarify the real outcome, make progress understandable and prepare the conversations that need a decision. Trust starts with saying exactly where we stand.',signature:'Turn scattered updates into one clear account.',theme:'clay',discipline:'Client partnership'}
};
const bestUsedFor={
 "emon": [
  "Turn this idea into a scoped mission.",
  "Choose the right team and define who owns what.",
  "Help me decide what we should prioritize next."
 ],
 "kapiteky": [
  "Challenge the assumptions in this plan.",
  "Compare these options and explain the tradeoffs.",
  "Tell me what evidence we need before deciding."
 ],
 "tinus": [
  "Build a working slice of this approved idea.",
  "Find the cause of this bug and verify the fix.",
  "Review this implementation for gaps and edge cases."
 ],
 "satwa": [
  "Make this environment easy to set up again.",
  "Investigate why this service is unhealthy.",
  "Prepare a release checklist with rollback steps."
 ],
 "stewie": [
  "Make this screen easier to understand.",
  "Show me three ways this flow could work.",
  "Find the friction in this first-time experience."
 ],
 "ramiro": [
  "Turn these updates into a clear partner briefing.",
  "Clarify the scope and expectations for this request.",
  "Prepare the decisions we need for our next meeting."
 ]
};
export const agentBestUsedFor=p=>bestUsedFor[p.id]||['Review this proposal from your specialist perspective.','Identify the gaps in these findings.','Recommend the next step and explain why.'];
export const agentRoster=s=>companyPeople(s).filter(p=>p.id!=='fito');
export const agentVoice=p=>voices[p.id]||{line:p.traits||'A fresh perspective for the team.',about:p.description||'A guest expert with an owner-supplied point of view.',signature:'Bring a different lens to the work.',theme:'plum',discipline:p.role};
export const agentAvatar=p=>`<span class="agent-avatar" aria-hidden="true"><span class="avatar avatar--${p.guest?'guest':esc(p.id)}"><i></i></span></span>`;
export function skillsWorkspace(s,view={},icons={}){
 return companySkillsWorkspace(s,view,agentRoster(s),icons);
}
export function createSkillsController(options){
 return createCapabilitiesController(options);
}
