import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {createOfficeCharacter} from '../../../packages/spatial/src/character.js';
import {createWelcomeCar} from '../src/onboarding-car.js';

test('boarding clears inherited flips and faces the driver toward the wheel in a banked car',()=>{
 const world=new THREE.Group(),car=createWelcomeCar(world);
 car.group.rotation.set(.08,.4,-.1);car.group.position.set(3,4,5);
 const driver=createOfficeCharacter({shirt:0xeeeeee,hair:0x333333,skin:0xc99c7c,detail:'plain'});
 world.add(driver.group);driver.group.rotation.set(Math.PI,Math.PI,Math.PI);
 car.seatDriver(driver);world.updateMatrixWorld(true);
 const up=new THREE.Vector3(0,1,0).applyQuaternion(car.group.quaternion);
 const towardWheel=car.group.getObjectByName('steering-wheel').getWorldPosition(new THREE.Vector3()).sub(driver.group.getWorldPosition(new THREE.Vector3())).projectOnPlane(up).normalize();
 assert.ok(driver.group.getWorldDirection(new THREE.Vector3()).dot(towardWheel)>.99);
 assert.equal(driver.group.parent,car.group);
});

test('correction jets exhaust opposite the intended acceleration and stop at rest',()=>{
 const car=createWelcomeCar(new THREE.Group());car.thrust(.7,0,{lateral:.6,forward:-.8});
 const active=car.group.children.filter(o=>o.name.startsWith('thruster-')&&o.getObjectByName('exhaust').visible);
 assert.ok(active.some(o=>o.name==='thruster-left'));
 assert.ok(active.some(o=>o.name==='thruster-rear'));
 assert.ok(!active.some(o=>o.name==='thruster-right'||o.name==='thruster-front'));
 for(const mount of active.filter(o=>o.name!=='thruster-lift')){
  const direction=new THREE.Vector3(0,-1,0).applyQuaternion(mount.quaternion);
  assert.ok(direction.dot(new THREE.Vector3(.6,0,-.8))<0);
 }
 car.thrust(0,.1);assert.ok(car.group.children.filter(o=>o.name.startsWith('thruster-')).every(o=>!o.getObjectByName('exhaust').visible));
});

test('ground smoke stays in world space, dissipates after shutdown and clears on replay',()=>{
 const world=new THREE.Group(),car=createWelcomeCar(world);
 car.thrust(.8,0);car.thrust(.8,.08);
 const smoke=world.getObjectByName('ground-smoke'),puff=smoke.children.find(s=>s.visible);
 assert.ok(puff);const position=puff.position.clone();
 car.group.position.set(10,8,10);car.thrust(0,.08);
 assert.ok(puff.position.equals(position));
 for(let i=1;i<=40;i++)car.thrust(0,.08+i*.1);
 assert.ok(smoke.children.every(s=>!s.visible));
 car.group.position.set(0,0,0);car.thrust(.8,4.2);assert.ok(smoke.children.some(s=>s.visible));
 car.resetEffects();assert.ok(smoke.children.every(s=>!s.visible));
});
