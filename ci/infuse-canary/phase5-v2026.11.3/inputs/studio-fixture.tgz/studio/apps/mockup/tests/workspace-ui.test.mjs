import test from 'node:test';
import assert from 'node:assert/strict';
import { pageHeader, emptyState } from '@studio/ui/workspace';

test('shared workspace blocks escape literal text and retain app-owned controls', () => {
  const literal = `<img src=x onerror="alert(1)"> & 'project'`;
  const actionsHtml = '<button data-action="close">Back</button>';
  for (const render of [pageHeader, emptyState]) {
    const html = render({title:literal, description:literal, actionsHtml});
    assert.ok(!html.includes('<img'));
    assert.ok(html.includes('&lt;img src=x onerror=&quot;alert(1)&quot;&gt; &amp; &#039;project&#039;'));
    assert.ok(html.includes(actionsHtml));
  }
});
