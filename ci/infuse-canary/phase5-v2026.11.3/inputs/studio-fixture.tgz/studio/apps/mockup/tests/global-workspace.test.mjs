import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,transition as t} from '../src/simulation/model.js';
import {currentMission} from '../src/simulation/missions.js';
import {emptyConnected} from '../src/simulation/connected.js';
import {companyDeskItems,founderItems} from '../src/simulation/founder.js';
import {personAssignments} from '../src/simulation/company-work.js';
import {switchWorkspaceProject} from '../src/workspace-navigation.js';
import {founderSurface} from '../src/founder-ui.js';
import {peopleWorkspace} from '../src/knowledge-ui.js';

function acrossProjects(){
 let s={...initialState(),connectedEnabled:true,connected:emptyConnected()};
 for(const floor of ['studio','client']){
  s=t(s,{type:'ENTER_FLOOR',id:floor});s=t(s,{type:'MISSION_NEW'});s=t(s,{type:'MISSION_EXAMPLE'});s=t(s,{type:'MISSION_STEP',stage:'shape'});
  const m=currentMission(s);m.title=`${floor} decision`;m.decisionOwner='Fito';
 }
 return s;
}
test('global desk aggregates project decisions, filters the partner and never mutates records',()=>{
 const s=acrossProjects(),before=structuredClone(s),items=companyDeskItems(s);
 assert.deepEqual(new Set(items.map(i=>i.projectId)),new Set(['studio','client']));
 assert.equal(new Set(items.map(i=>i.key)).size,2);
 assert.deepEqual(companyDeskItems({...s,floor:'growth'}),items);
 assert.deepEqual(s,before);
 s.missionDesk.items[1].decisionOwner='Alex';
 assert.equal(companyDeskItems(s).length,1);
 assert.equal(companyDeskItems({...s,connected:{...s.connected,partner:'Alex'}})[0].projectId,'client');
 assert.deepEqual(companyDeskItems({...s,connected:{...s.connected,mode:'denied'}}),[]);
});
test('a global desk decision routes to its origin while keeping the other project unchanged',()=>{
 let s=t(acrossProjects(),{type:'OPEN',surface:'founder-desk'});
 const origin=companyDeskItems(s).find(i=>i.projectId==='studio'),before=structuredClone(s.missionDesk);
 assert.equal(t(s,{type:'FOUNDER_DECIDE',key:origin.key,action:'defer',note:'Wrong project'}),s);
 assert.match(founderSurface(s,{filter:'attention',selected:origin.key}),/data-company-project="studio"/);
 s=switchWorkspaceProject(s,origin.projectId);
 s=t(s,{type:'FOUNDER_DECIDE',key:origin.key,action:'defer',note:'Wait for the Studio evidence.'});
 assert.equal(s.surface,'founder-desk');assert.equal(s.floor,'studio');
 assert.equal(companyDeskItems(s).find(i=>i.key===origin.key).status,'deferred');
 assert.equal(founderItems({...s,floor:'client'})[0].status,'attention');
 assert.deepEqual(s.missionDesk,before);
});
test('shared team work includes all projects without treating drafts or closed work as active runs',()=>{
 const s=acrossProjects(),before=structuredClone(s);
 const work=personAssignments(s,'emon');assert.equal(work.length,2);
 assert.ok(work.every(a=>a.label==='Proposed team · work has not started'));
 assert.deepEqual(personAssignments({...s,floor:'growth'},'emon'),work);
 assert.deepEqual(s,before);
 s.missionDesk.items[0].status='completed';
 assert.equal(personAssignments(s,'emon').length,1);
 assert.deepEqual(personAssignments({...s,connected:{...s.connected,mode:'denied'}},'emon'),[]);
});
test('People includes guests from other projects and preserves the person when project context changes',()=>{
 let s=t(initialState(),{type:'KNOW_GUEST_SAVE',name:'Mira',role:'Research expert',traits:'Question <assumptions>',brief:'Shared <research>',sources:'Owner notes',skills:['expert-review'],model:'GPT-6 Astra',reasoning:'High'});
 const guest=s.guests[0];s=t(s,{type:'OPEN',surface:'people',person:guest.id});
 s=switchWorkspaceProject(s,'client');
 assert.equal(s.detail,guest.id);assert.equal(s.surface,'people');
 const html=peopleWorkspace(s,{});assert.ok(html.includes('Shared &lt;research&gt;'));
 assert.ok(html.includes('Your team'));assert.ok(html.includes('Project knowledge &amp; defaults'));
 assert.match(html, /<option value="client" selected>Finaxis<\/option>/);
 assert.match(html,/data-expert-mission="guest-1" disabled/);
});

test('Agents renders legacy demo titles in English without changing stored or user-authored text',()=>{
 const s=acrossProjects(),[demo,custom]=s.missionDesk.items;
 demo.scenario='studio-design';demo.title='Diseñar la creación de misiones';
 custom.scenario='custom';custom.title='Diseñar la creación de misiones';
 const before=structuredClone(s),work=personAssignments(s,'emon');
 assert.equal(work.find(a=>a.missionId===demo.id).title,'Design mission creation');
 assert.equal(work.find(a=>a.missionId===custom.id).title,custom.title);
 assert.match(peopleWorkspace(s,{}),/Design mission creation/);
 assert.deepEqual(s,before);
});
