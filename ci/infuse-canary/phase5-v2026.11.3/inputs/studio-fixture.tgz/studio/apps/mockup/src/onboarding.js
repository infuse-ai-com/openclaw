import {assetUrls} from '@studio/ui/assets';
import {initialState,transition} from './simulation/model.js';
import {readLook,saveLook,LOOK_OPTIONS,lookSummary} from './onboarding-profile.js';
import {CHAPTERS,FLOOR_STOPS,DESK_STOPS} from './onboarding-content.js';
import './onboarding.css';

const esc=value=>String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
const labels={shirt:'Top',pants:'Trousers',shoes:'Shoes',skin:'Skin tone',hair:'Hair colour',detail:'Accessory'};
export function welcomeSettings(owner){
 const look=readLook(owner);
 return '<section class="welcome-settings"><div><span class="eyebrow">YOUR STUDIO INTRODUCTION</span><h2>Your arrival at Studio.</h2><p>Choose your look, take a solo flight, and meet the team at the office.</p><p class="welcome-look"><span style="background:'+look.shirt+'"></span>'+esc(owner)+' · '+esc(lookSummary(look))+'</p><small>Your appearance is saved per demo partner on this browser.</small></div><div><button class="primary" data-action="onboarding-start">Replay onboarding →</button><button class="secondary" data-action="onboarding-look">Edit my appearance</button></div></section>';
}
export function openWelcome({owner,onClose,onComplete}){
 const trigger=document.activeElement,dialog=document.createElement('dialog');dialog.className='welcome-dialog';dialog.setAttribute('aria-labelledby','welcome-title');
 let chapter=0,look=readLook(owner),saved=JSON.stringify(look),generation=0,scene=null,closed=false,floorIndex=0,deskIndex=0,notice='',motion=false,departing=false,entering=false,paused=false,transitionCleanup=null;
 const explored=new Set();
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const $=selector=>dialog.querySelector(selector);
 dialog.innerHTML='<div class="welcome-shell"><header class="welcome-header"><div><img src="'+assetUrls['INFUSE_favicon.ico']+'" alt=""><span>STUDIO <small>YOUR FIRST DAY</small></span></div><span class="welcome-prototype">Interactive mockup</span><button type="button" data-welcome="exit" aria-label="Exit onboarding">Exit tour <span aria-hidden="true">×</span></button></header><nav class="welcome-chapters" aria-label="Onboarding chapters">'+CHAPTERS.map((c,i)=>'<button type="button" data-chapter="'+i+'"><span>0'+(i+1)+'</span>'+c.name+'</button>').join('')+'</nav><div class="welcome-main"><section class="welcome-visual" aria-label="Onboarding scene"><div class="welcome-scene"></div><div class="welcome-fallback" hidden><img src="'+assetUrls['studio-headquarters.webp']+'" alt="Studio headquarters"><p>Explore with the controls beside this scene. Your tour works without 3D.</p></div><div class="welcome-scene-caption"><span data-caption></span><span data-scene-status role="status">Preparing your scene…</span></div><div class="welcome-camera"></div></section><section class="welcome-panel" aria-labelledby="welcome-title"><div class="welcome-panel-content"></div></section></div><footer class="welcome-footer"><button type="button" class="welcome-back" data-welcome="back">← Back</button><p data-welcome-progress></p><div><button type="button" class="welcome-quiet" data-welcome="skip">Skip to my desk</button><button type="button" class="welcome-primary" data-welcome="next"></button></div></footer><p class="welcome-notice" role="status"></p></div>';
 document.body.append(dialog);dialog.showModal();
 function dirty(){return JSON.stringify(look)!==saved;}
 function writeLook(){const durable=saveLook(owner,look);saved=JSON.stringify(look);notice=durable?'Appearance saved for '+owner+' on this browser.':'Appearance kept for this visit. Browser storage is unavailable.';$('.welcome-notice').textContent=notice;}
 function teardown(){generation++;transitionCleanup?.();transitionCleanup=null;scene?.destroy();scene=null;$('.welcome-scene').replaceChildren();motion=false;departing=false;entering=false;paused=false;dialog.classList.remove('is-cinematic');}
 function failure(){if(closed)return;transitionCleanup?.();transitionCleanup=null;departing=false;entering=false;dialog.classList.remove('is-cinematic');buttons();$('.welcome-fallback').hidden=false;$('.welcome-scene').hidden=true;$('.welcome-visual').dataset.ready='fallback';$('[data-scene-status]').textContent='3D unavailable · all steps still work';}
 function settled(){if(closed)return;if(departing){departing=false;queueMicrotask(()=>{if(!closed)void show(2,{crossfade:true});});}motion=false;dialog.classList.remove('is-cinematic');const button=$('[data-welcome="motion"]');if(button)button.textContent='Replay scene';$('[data-scene-status]').textContent=reduced.matches?'Reduced motion · still view':'Ready when you are';}
 function ready(){if(closed)return;reveal();$('.welcome-visual').dataset.ready='true';$('[data-scene-status]').textContent=reduced.matches?'Reduced motion · still view':'Explore at your own pace';}
 function buttons(){
  $('[data-welcome="back"]').disabled=chapter===0;
  $('[data-welcome="next"]').disabled=departing||entering;
  $('[data-welcome-progress]').textContent=String(chapter+1).padStart(2,'0')+' / 05 · '+(chapter===3?'Training floor':CHAPTERS[chapter].name);
  $('[data-welcome="next"]').textContent=chapter===4&&dirty()?'Save look & go to my desk':CHAPTERS[chapter].action;
 }
 function appearance(){
  return '<div class="welcome-wardrobe">'+Object.entries(LOOK_OPTIONS).map(([key,values])=>'<fieldset><legend>'+labels[key]+'</legend><div class="welcome-options">'+values.map(([name,value])=>'<button type="button" data-look="'+key+'" data-value="'+value+'" aria-label="'+labels[key]+': '+name+'" aria-pressed="'+(look[key]===value)+'">'+(key==='detail'?'<span>'+name+'</span>':'<i style="--swatch:'+value+'" aria-hidden="true"></i><span>'+name+'</span>')+'</button>').join('')+'</div></fieldset>').join('')+'</div><p class="welcome-fine">Choose freely. Save & continue keeps your look; exiting discards unsaved changes.</p>';
 }
 function panel(focus=false){
  const c=CHAPTERS[chapter];let html='<span class="welcome-kicker">0'+(chapter+1)+' / '+c.label+'</span><h1 id="welcome-title" tabindex="-1">'+c.title+'</h1><p class="welcome-intro">'+c.text+'</p>';
  if(chapter===0)html+=appearance();
  if(chapter===1)html+='<ol class="welcome-arrival"><li><span>01</span><div><strong>Your ride, your arrival</strong><p>Step into the white coupe. Your saved appearance comes with you.</p></div></li><li><span>02</span><div><strong>Lift off</strong><p>Four downward thrusters carry you to the rooftop beside Studio.</p></div></li><li><span>03</span><div><strong>The team is waiting</strong><p>Meet Emon and the specialists inside. Emon helps shape your idea into a clear plan; you approve the work and inspect the results.</p></div></li></ol>';
  if(chapter===2)html+='<ol class="welcome-arrival"><li><span>01</span><div><strong>Touch down next door</strong><p>Set down on the rooftop, then step out of your car.</p></div></li><li><span>02</span><div><strong>Cross into Studio</strong><p>A glass bridge connects the two buildings in this prototype.</p></div></li><li><span>03</span><div><strong>Find your project floor</strong><p>Each floor holds its own context, work and results.</p></div></li></ol>';
  if(chapter===3){const stop=FLOOR_STOPS[floorIndex];html+='<p class="welcome-example">EXAMPLE MISSION · A welcome guide for our next partner</p><div class="welcome-stops" aria-label="Floor tour stops">'+FLOOR_STOPS.map((s,i)=>'<button type="button" data-stop="'+i+'" aria-pressed="'+(i===floorIndex)+'"><span>'+String(i+1).padStart(2,'0')+'</span>'+s.label+(explored.has(i)?'<small>Explored</small>':'')+'</button>').join('')+'</div><article class="welcome-detail"><span class="welcome-kicker">STOP '+(floorIndex+1)+' / '+FLOOR_STOPS.length+'</span><h2>'+stop.title+'</h2><p>'+stop.text+'</p><blockquote>'+stop.example+'</blockquote><button type="button" class="welcome-example-action" data-welcome="try">'+stop.action+' →</button><p class="welcome-result" role="status">'+(explored.has(floorIndex)?stop.result:'')+'</p></article>';}
  if(chapter===4){const item=DESK_STOPS[deskIndex];html+='<div class="welcome-stops" aria-label="Explore desk objects">'+DESK_STOPS.map((s,i)=>'<button type="button" data-desk-stop="'+i+'" aria-pressed="'+(i===deskIndex)+'">'+s.title+'</button>').join('')+'</div><article class="welcome-detail"><span class="welcome-kicker">WITHIN REACH</span><h2>'+item.title+'</h2><p>'+item.text+'</p></article><p class="welcome-fine">You’re '+esc(owner)+'. Your saved look comes with you; the desk opens in its usual first-person view.</p>';}
  $('.welcome-panel-content').innerHTML=html;buttons();
  if(focus){$('.welcome-panel').scrollTop=0;$('#welcome-title').focus({preventScroll:true});}
 }
 function reveal(){
  const overlay=dialog.querySelector('.welcome-outgoing');if(!overlay)return;
  const current=generation;
  requestAnimationFrame(()=>requestAnimationFrame(()=>{if(closed||current!==generation)return;overlay.classList.add('is-revealed');}));
 }
 async function show(index,{crossfade=false}={}){
  let outgoing=null,previous=null;
  if(crossfade&&!reduced.matches&&scene){
   previous=scene;scene=null;outgoing=document.createElement('div');outgoing.className='welcome-outgoing';outgoing.setAttribute('aria-hidden','true');outgoing.inert=true;
   outgoing.append(...$('.welcome-scene').childNodes);
  }
  teardown();
  if(outgoing){
   $('.welcome-visual').append(outgoing);let timeout;
   const cleanup=()=>{clearTimeout(timeout);previous.destroy();outgoing.remove();};
   transitionCleanup=cleanup;
   outgoing.addEventListener('transitionend',()=>{if(transitionCleanup===cleanup){cleanup();transitionCleanup=null;}},{once:true});
   // Also retire the old renderer if rendering fails or CSS motion is disabled.
   timeout=setTimeout(()=>{if(transitionCleanup===cleanup){cleanup();transitionCleanup=null;}},2500);
  }
  chapter=index;panel(true);const current=++generation;
  dialog.dataset.chapter=String(index);$('.welcome-scene').hidden=false;$('.welcome-fallback').hidden=true;$('.welcome-visual').dataset.ready='loading';
  $('[data-caption]').textContent=CHAPTERS[index].hint;$('[data-scene-status]').textContent='Preparing your scene…';
  dialog.querySelectorAll('[data-chapter]').forEach(b=>{if(Number(b.dataset.chapter)===index)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current');});
  $('.welcome-camera').innerHTML=index===0?'<button type="button" data-welcome="rotate-left" aria-label="Turn character left">↶</button><span>TURN YOUR CHARACTER</span><button type="button" data-welcome="rotate-right" aria-label="Turn character right">↷</button>':index===1||index===2?'<button type="button" data-welcome="motion">Replay scene</button><button type="button" data-welcome="ambient" aria-pressed="false"'+(reduced.matches?' disabled':'')+'>Pause movement</button>':index===3?'<button type="button" data-welcome="fit">Fit floor</button><span>DRAG TO PAN · SCROLL TO ZOOM</span>':'';
  const host=$('.welcome-scene');
  const sceneFailure=()=>{if(!closed&&current===generation)failure();};
  if(new URLSearchParams(location.search).has('no3d')){failure();return;}
  try{
   if(index<=2){
    const {createWelcomeScene}=await import('./onboarding-scene.js');if(closed||current!==generation)return;
    scene=createWelcomeScene(host,{chapter:index,look,onFailure:sceneFailure,onSettled:()=>{if(!closed&&current===generation)settled();},onEnter:()=>{if(!closed&&current===generation)void show(3,{crossfade:true});},onBeat:text=>{if(!closed&&current===generation)$('[data-scene-status]').textContent=text;}});
    if(scene){ready();if(index===2&&!reduced.matches){scene.play();motion=true;dialog.classList.add('is-cinematic');$('[data-welcome="motion"]').textContent='Skip landing';}}
   }else if(index===3){
    const {createWorld}=await import('./world.js');if(closed||current!==generation)return;
    scene=createWorld(host,{onSelect:hit=>{const next=FLOOR_STOPS.findIndex(s=>s.zone===hit.object);if(next>=0){floorIndex=next;scene?.focusZone?.(FLOOR_STOPS[next].zone);panel();}},onCamera(){},onExit(){},onFailure:sceneFailure});
    let example=transition(initialState(),{type:'ENTER_FLOOR',id:'studio'});example.connected={partner:owner};
    scene.update(example);scene.pause(false);if($('.welcome-visual').dataset.ready!=='fallback')ready();
   }else{
    const {createDesk}=await import('@studio/spatial/desk');if(closed||current!==generation)return;
    scene=createDesk(host,{onSelect:id=>{const i=DESK_STOPS.findIndex(s=>s.id===id);if(i>=0){deskIndex=i;panel();}},onFailure:sceneFailure,exampleData:true,tokens:'Example',overview:{decisions:0,missions:0,project:'Training floor',status:'Illustrative onboarding'}});
    if($('.welcome-visual').dataset.ready!=='fallback')ready();
   }
  }catch{if(!closed&&current===generation)failure();}
 }
 function close(complete=false){
  if(closed)return;closed=true;teardown();dialog.close();dialog.remove();reduced.removeEventListener('change',motionChange);
  if(complete)onComplete();else{onClose();if(trigger?.isConnected)trigger.focus();else document.querySelector('[data-action="onboarding-start"]')?.focus();}
 }
 function motionChange(){
  const b=$('[data-welcome="ambient"]');if(b){b.disabled=reduced.matches;b.textContent='Pause movement';b.setAttribute('aria-pressed','false');}
  if(reduced.matches){paused=false;motion=false;scene?.pauseMotion?.(false);scene?.skip?.();dialog.classList.remove('is-cinematic');transitionCleanup?.();transitionCleanup=null;}
 }
 reduced.addEventListener('change',motionChange);
 dialog.addEventListener('cancel',e=>{e.preventDefault();close();});
 dialog.addEventListener('keydown',e=>{e.stopPropagation();});
 dialog.addEventListener('click',e=>{
  e.stopPropagation();const b=e.target.closest('button');if(!b||b.disabled)return;
  if(b.dataset.look){look={...look,[b.dataset.look]:b.dataset.value};scene?.updateLook?.(look);dialog.querySelectorAll('[data-look="'+b.dataset.look+'"]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.value===b.dataset.value)));notice='Unsaved appearance · Save & continue to keep it.';$('.welcome-notice').textContent=notice;buttons();return;}
  if(b.dataset.chapter!==undefined){void show(Number(b.dataset.chapter));return;}
  if(b.dataset.stop!==undefined){floorIndex=Number(b.dataset.stop);scene?.focusZone?.(FLOOR_STOPS[floorIndex].zone);panel();$('[data-stop="'+floorIndex+'"]').focus();return;}
  if(b.dataset.deskStop!==undefined){deskIndex=Number(b.dataset.deskStop);scene?.select?.(DESK_STOPS[deskIndex].id);panel();$('[data-desk-stop="'+deskIndex+'"]').focus();return;}
  const action=b.dataset.welcome;
  if(action==='exit')close();
  if(action==='back'&&chapter>0)void show(chapter-1);
  if(action==='skip')void show(4);
  if(action==='next'){
   if(chapter===2&&scene?.enter&&!reduced.matches){entering=true;motion=true;paused=false;dialog.classList.add('is-cinematic');buttons();$('[data-welcome="next"]').textContent='Entering Studio…';$('[data-welcome="motion"]').textContent='Skip walk';const ambient=$('[data-welcome="ambient"]');ambient.textContent='Pause movement';ambient.setAttribute('aria-pressed','false');scene.enter();return;}
   if(chapter===1&&scene?.play&&!reduced.matches){departing=true;motion=true;paused=false;dialog.classList.add('is-cinematic');$('[data-welcome="ambient"]').textContent='Pause movement';$('[data-welcome="ambient"]').setAttribute('aria-pressed','false');scene.play();buttons();$('[data-welcome="next"]').textContent='Flying to Studio…';$('[data-welcome="motion"]').textContent='Skip flight';return;}if(chapter===0||chapter===4)writeLook();if(chapter===4)close(true);else void show(chapter+1);}
  if(action==='rotate-left')scene?.rotate?.(-Math.PI/4);
  if(action==='rotate-right')scene?.rotate?.(Math.PI/4);
  if(action==='fit')scene?.home?.();
  if(action==='try'){explored.add(floorIndex);panel();$('[data-welcome="try"]').focus();}
  if(action==='ambient'){paused=!paused;scene?.pauseMotion?.(paused);b.textContent=paused?'Resume movement':'Pause movement';b.setAttribute('aria-pressed',String(paused));}
  if(action==='motion'){if(motion){scene?.skip?.();}else if(scene?.play){paused=false;const ambient=$('[data-welcome="ambient"]');ambient.textContent='Pause movement';ambient.setAttribute('aria-pressed','false');motion=!reduced.matches;scene.play();dialog.classList.toggle('is-cinematic',motion);b.textContent=motion?'Skip scene':'Replay scene';}}
 });
 void show(0);
 return {close};
}
