import {assetUrls} from '@studio/ui/assets';
import {appearanceControls} from './appearance.js';
import { currentMission } from './simulation/missions.js';
import { allFloors } from './simulation/company.js';
import { transition } from './simulation/model.js';
import { partner } from './simulation/reference-catalog.js';
import { pendingHumanReviews, canonicalWorkspaceState } from './workspace-navigation.js';

const esc = value => String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');

// Changing the entry view never creates a mission or alters its saved content.
export function initialWorkspaceState(state) {
  if (state.surface) return canonicalWorkspaceState(state);
  return transition(transition(state, {type:'ENTER_FLOOR', id:state.floor}), {type:'MISSION_LIST'});
}
export const SIDEBAR_PREFERENCE_KEY = 'studio.mockup.sidebar';
export function sidebarCollapsed(preference, surface) {
  return preference === 'collapsed' || (preference !== 'expanded' && surface === 'knowledge-reader');
}
export function workspaceSidebar(state, icons, collapsed = false, theme = 'light') {
  const floors = allFloors(state).toSorted((a,b)=>Number(a.number)-Number(b.number)), floor = floors.find(item => item.id === state.floor), surface = state.surface;
  const pending = pendingHumanReviews(state).length;
  const grilling=surface==='ideas'||(surface==='mission-flow'&&currentMission(state)?.status==='draft'&&!currentMission(state)?.execution);
  const projectName = floor?.title || 'Studio';
  const onProjectFloor = !surface && state.view === 'floor';
  const link = (icon, label, action, selected, badge='', scope=projectName) => `<button data-action="${action}" aria-label="${esc(label)}" title="${esc(label)} · ${esc(scope)}${badge ? ` · ${badge} pending human decisions` : ''}" ${selected ? 'aria-current="page"' : ''}>${icons[icon]}<span>${label}</span>${badge ? `<b class="workbench-badge" aria-label="${badge} pending human decisions">${badge}</b>` : ''}</button>`;
  const project = item => `<button data-workspace-project="${esc(item.id)}" title="${esc(item.title)}" ${item.id === state.floor ? 'aria-current="true"' : ''}>${icons.building}<span>${esc(item.title)}</span></button>`;
  const menu = (id,icon,label,content,extra='') => `<details class="workbench-popover workbench-${id}-menu" data-preserve-details="workspace-${id}"><summary aria-label="${id==='project'?'Switch project: ':id==='profile'?'Account: ':''}${esc(label)}" title="${id==='project'?'Switch project: ':id==='profile'?'Account: ':''}${esc(label)}" ${extra}>${icons[icon]}<span>${label}</span>${icons.chevron}</summary><div class="workbench-popover-panel">${content}</div></details>`;
  return `<div class="workbench-brand-row"><button class="workbench-brand" data-action="workspace-office" aria-label="INFUSE Studio · ${esc(projectName)} project floor" title="Open ${esc(projectName)} project floor"><img src="${assetUrls['INFUSE_favicon.ico']}" alt=""/><strong>INFUSE</strong><span>/ Studio</span></button><button class="workbench-collapse" data-action="collapse-sidebar" aria-label="${collapsed?'Expand':'Collapse'} sidebar" title="${collapsed?'Expand':'Collapse'} sidebar" aria-expanded="${!collapsed}">${icons.chevron}</button></div>
    <button class="workbench-search" data-action="navigate" aria-label="Go to…" title="Go to… (⌘P)">${icons.search}<span>Go to…</span><kbd>⌘ P</kbd></button>
    <nav class="workbench-nav" aria-label="Work navigation">
      <div class="workbench-scope" role="group" aria-label="Company navigation">
        <p class="workbench-scope-label"><span class="scope-expanded">Company</span><span class="scope-rail" aria-hidden="true">Global</span></p>
        ${link('building','Office','building',!surface && state.view==='building','','Company · all projects')}
        ${link('home','My desk','founder-desk',surface==='founder-desk','','All projects')}
        ${link('users','Agents','people',surface==='people','','Shared company team')}
        ${link('library','Skills','skills',surface==='skills','','Human guides from company skills')}
        ${import.meta.env?.DEV?link('chart','Activity','contributions',surface==='contributions','','Mock Git activity'):''}
        ${link('server','Tools','tools',surface==='tools','','Supporting Infuse apps')}
      </div>
      <div class="workbench-scope workbench-project-scope" role="group" aria-label="Project navigation: ${esc(projectName)}">
        <p class="workbench-scope-label"><span>Project</span></p>
    ${menu('project','switchProject',esc(floor?.title || 'Studio'),`<p class="workbench-menu-heading">Switch project</p><nav aria-label="Switch project">${floors.map(project).join('')}${link('plus','New project','floor-begin',false)}</nav>`)}
      <div class="workbench-scope-links">
      ${link('building','Project floor','workspace-office',onProjectFloor)}
      ${link('board','Whiteboard','freeboard',false)}
      ${link('edit','Grilling','connected-ideas',grilling)}
      ${link('files','Missions','mission-list',!grilling&&['missions','mission-flow','library','connected-output','delivery-review','floor-activity'].includes(surface))}
      ${link('review','Review','review-wall',surface==='review-wall',pending || '')}
      ${link('library','Knowledge','knowledge-reader',surface==='knowledge-reader')}
      ${link('document','Artifacts','artifacts',surface==='artifacts')}
      ${link('flask','Prototype','lab',surface==='lab')}
      ${link('operations','Operations','operations',surface==='operations')}
      </div></div>
    </nav>
    <div class="workbench-bottom"><nav aria-label="Workspace tools">${menu('help','help','Help',`<p class="workbench-menu-heading">Find your way</p>${link('building','Studio onboarding','settings',surface==='settings','','Company')}<p class="workbench-menu-copy">⌘ / Ctrl + P · Go to…<br>Escape · Close the current overlay or view</p>`)}</nav>
      ${menu('profile','profile',esc(partner(state)),`<p class="workbench-menu-heading">${esc(partner(state))} · Infuse AI partner</p><p class="workbench-menu-copy">Local demo account. No live session or account settings.</p>${link('settings','Profile & settings','settings',surface==='settings','','Account')}${appearanceControls(theme)}<fieldset><legend>Navigation</legend><button data-sidebar-mode="collapsed" aria-pressed="${collapsed}">Icon rail</button><button data-sidebar-mode="expanded" aria-pressed="${!collapsed}">Expanded sidebar</button></fieldset>${link('home','My desk','founder-desk',false,'','All projects')}<label class="workbench-menu-copy">Preview as admitted partner<select data-connected-partner>${['Fito','Alex'].map(p=>`<option ${partner(state)===p?'selected':''}>${p}</option>`).join('')}</select></label>`)}
    </div>`;
}
