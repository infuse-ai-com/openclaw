import { defineConfig } from "vite";
import { fileURLToPath } from "node:url";
const here = (path) => fileURLToPath(new URL(path, import.meta.url));
export default defineConfig({
  base: process.env.STUDIO_MOCKUP_BASE || "/",
  plugins: [
    {
      name: "removed-legacy",
      configureServer(server) {
        server.middlewares.use((req, res, next) => {
          if (/^\/legacy(?:\/|$|\?)/.test(req.url)) {
            res.statusCode = 410;
            res.end("This mockup was retired. Open / for Studio.");
          } else next();
        });
      },
    },
  ],
  root: here("./src"),
  publicDir: here("./public"),
  server: { host: "127.0.0.1", port: 4317, strictPort: true },
  build: {
    outDir: here("./dist"),
    emptyOutDir: true,
    rollupOptions: { input: { main: here("./src/index.html") } },
  },
});
