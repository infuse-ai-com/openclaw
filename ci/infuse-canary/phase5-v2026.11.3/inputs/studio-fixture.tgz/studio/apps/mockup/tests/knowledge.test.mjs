import test from 'node:test';
import assert from 'node:assert/strict';
import { initialState, transition as t, restoreState } from '../src/simulation/model.js';
import { currentMission, createdMissionMarkdown } from '../src/simulation/missions.js';
import { libraryEntries, acceptedWork, entryStatus } from '../src/simulation/knowledge.js';
import { floorPeople } from '../src/simulation/company.js';
import { savedKnowledgeSurface, peopleWorkspace } from '../src/knowledge-ui.js';
const reload=s=>{const r=restoreState(JSON.stringify(s));assert.equal(r.notice,null);return r.state;};
const source=s=>t(s,{type:'KNOW_SOURCE_SAVE',title:'Research <notes>',body:'  Literal findings.\nUncertainty stays visible.  ',reference:'Internal study · 2026-10-02'});
const guest={type:'KNOW_GUEST_SAVE',name:'Mira',role:'Research expert',traits:'Challenge assumptions with evidence.',brief:'Exact research <context>\nKeep uncertainty.',sources:'Owner supplied study.',skills:['expert-review'],model:'GPT-6 Astra',reasoning:'High'};
function complete(s){s=t(s,{type:'MISSION_STEP',stage:'review'});for(const id of ['outcome','scope','evidence'])s=t(s,{type:'MISSION_CONFIRM',id,inline:true});s=t(s,{type:'MISSION_APPROVE',start:true});assert.equal(currentMission(s).status,'approved');for(let i=0;i<40&&currentMission(s).status!=='completed';i++)s=t(s,{type:'MISSION_ADVANCE'});s=t(s,{type:'MISSION_DELIVERY_REVIEWED',value:true});s=t(s,{type:'MISSION_DELIVERY_CRITERIA',value:true});return t(s,{type:'MISSION_DELIVERY_ACCEPT'});}
function accepted(){let s=t(initialState(),{type:'MISSION_NEW'});s=t(s,{type:'MISSION_EXAMPLE'});return complete(s);}
test('sources preserve wording, reset owner review on edit, and remain scoped to their floor',()=>{
 let s=source(initialState()),e=libraryEntries(s)[0];s=t(s,{type:'KNOW_REVIEW',id:e.id,review:'reviewed'});assert.equal(entryStatus(s,libraryEntries(s)[0]),'Owner reviewed');
 s=t(s,{type:'KNOW_SOURCE_SAVE',id:e.id,title:e.title,body:'Updated notes',reference:e.reference});s=reload(s);assert.equal(libraryEntries(s)[0].review,'unreviewed');assert.equal(libraryEntries(s)[0].revision,2);
 s=t(s,{type:'ENTER_FLOOR',id:'growth'});assert.equal(libraryEntries(s).length,0);assert.equal(t(s,{type:'KNOW_REVIEW',id:e.id,review:'reviewed'}),s);
});
test('accepted learning retains evidence and becomes stale when its origin changes',()=>{
 let s=accepted(),id=currentMission(s).id;
 s=t(s,{type:'KNOW_LEARNING',id,body:'Keep this exact learning.\nRequire a fresh check.'});const e=structuredClone(libraryEntries(s)[0]);
 assert.ok(e.origin.evidence.includes('Remaining gap'));assert.equal(t(s,{type:'KNOW_LEARNING',id,body:'duplicate'}),s);s=reload(s);
 s=t(s,{type:'MISSION_DELIVERY_SOURCE'});assert.equal(entryStatus(s,libraryEntries(s)[0]),'Origin changed');assert.deepEqual(libraryEntries(s)[0].origin,e.origin);assert.equal(acceptedWork(s).length,0);
});
test('mission reuse takes only selected context and resets approvals without altering the source',()=>{
 let s=source(accepted());const original=structuredClone(currentMission(s)),e=libraryEntries(s)[0];
 s=t(s,{type:'KNOW_REUSE',missionId:original.id,title:'Next iteration',intent:'Explore another interaction',sources:[e.id],plan:true,team:true});
 const m=currentMission(s);assert.notEqual(m.id,original.id);assert.equal(m.status,'draft');assert.equal(m.approved,null);assert.equal(m.events.length,0);assert.deepEqual(m.confirmed,['intent']);assert.deepEqual(m.squad,original.approved.squad);assert.equal(m.planning.steps.length,original.approved.plan.length);assert.ok(m.content.references.includes(e.body));assert.ok(createdMissionMarkdown(s).includes(e.body));assert.deepEqual(s.missionDesk.items.find(x=>x.id===original.id),original);
 s=t(s,{type:'KNOW_SOURCE_SAVE',id:e.id,title:e.title,body:'Later source update',reference:e.reference});assert.ok(currentMission(s).content.references.includes(e.body));s=reload(s);
 assert.equal(t(s,{type:'KNOW_REUSE',intent:'No forbidden source',title:'',sources:['missing'],plan:false,team:false}),s);
});
test('guest expertise, presets and linked knowledge carry into a chosen mission as snapshots',()=>{
 let s=source(initialState());s=t(s,guest);const p=s.guests[0],e=libraryEntries(s)[0];assert.ok(floorPeople(s).some(x=>x.id===p.id));
 s=t(s,{type:'KNOW_EXPERT_LINK',person:p.id,id:e.id});s=reload(s);assert.deepEqual(s.knowledge.expertLinks[p.id],[e.id]);
 s=t(s,{type:'KNOW_REUSE',person:p.id,title:'Research together',intent:'Review this idea',sources:[e.id],plan:false,team:false});
 assert.deepEqual(currentMission(s).squad,['emon',p.id]);assert.equal(currentMission(s).config[p.id].model,'GPT-6 Astra');assert.deepEqual(currentMission(s).config[p.id].skills,['expert-review']);const brief=structuredClone(currentMission(s).guestBriefs[p.id]);
 s=complete(s);const approved=structuredClone(currentMission(s).approved);
 s=t(s,{...guest,id:p.id,traits:'A changed shared personality',brief:'Updated research',model:'Opus 5.5'});s=reload(s);
 assert.deepEqual(currentMission(s).approved,approved);assert.deepEqual(currentMission(s).guestBriefs[p.id],brief);assert.equal(s.guests[0].brief,'Updated research');
});
test('empty or duplicate guest profiles and overflowing reuse cannot mutate saved work',()=>{
 let s=t(initialState(),guest);assert.equal(t(s,{...guest,name:''}),s);assert.equal(t(s,guest),s);
 s=source(s);s=t(s,{type:'KNOW_SOURCE_SAVE',title:'Long context',body:'x'.repeat(8000),reference:''});assert.equal(t(s,{type:'KNOW_REUSE',title:'',intent:'Test',sources:libraryEntries(s).map(e=>e.id),plan:false,team:false}),s);
});
test('knowledge recovery preserves missions and identities; UI escapes supplied research',()=>{
 let s=source(t(initialState(),guest));s=t(s,{type:'MISSION_NEW'});const before=structuredClone(s.missionDesk);
 assert.ok(savedKnowledgeSurface(s,{tab:'sources'}).includes('Research &lt;notes&gt;'));s.detail=s.guests[0].id;assert.ok(peopleWorkspace(s,{}).includes('&lt;context&gt;'));
 s.knowledge.entries=[null];const r=restoreState(JSON.stringify(s));assert.match(r.notice,/Library links/);assert.deepEqual(r.state.missionDesk,before);assert.equal(r.state.guests.length,1);
 assert.deepEqual(t(r.state,{type:'RESET'}).knowledge,{entries:[],expertLinks:{},expertFloors:{},expertConfigs:{}});
});
