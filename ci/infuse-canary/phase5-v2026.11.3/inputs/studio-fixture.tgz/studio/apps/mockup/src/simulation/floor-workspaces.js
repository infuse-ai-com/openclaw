import { workStatus, workEvidence } from './work-projections.js';
import { createdMissions, MISSION_LABELS } from './missions.js';
import { englishEvent } from './mission-copy.js';

// These are projections of saved demo records, never generated files or live work.
export function floorWorkspaceRecords(state) {
  const missions = createdMissions(state);
  return {
    papers: missions.map(m=>({id:m.id,title:m.title||'Untitled mission',status:workStatus(m)?.label||MISSION_LABELS[m.status],revision:m.approved?.revision||m.revision,summary:m.content.outcome||m.content.intent||'An idea waiting to be shaped.'})),
    activity: missions.filter(m=>m.events.length).map(m=>({id:m.id,title:m.title||'Untitled mission',events:m.events.map(englishEvent)})),
    deliveries: [...missions.flatMap(m=>workEvidence(m).map((e,i)=>({id:`${m.id}:evidence:${i}`,missionId:m.id,missionTitle:m.title,title:`${e.taskTitle} · r${e.revision}`,detail:e.summary}))),...missions.flatMap(m=>m.events.filter(e=>e.type==='task_delivered').map(englishEvent).map((event,index)=>({id:`${m.id}:${index}`,missionId:m.id,missionTitle:m.title||'Untitled mission',...event})))],
    results: [...missions.filter(m=>m.execution&&workEvidence(m).length).map(m=>({id:m.id,title:m.title,revision:workEvidence(m).at(-1).revision,accepted:m.execution.state==='closed',label:workStatus(m).label,summary:m.summary})),...missions.filter(m=>m.delivery).map(m=>({id:m.id,title:m.title,revision:m.delivery.versions.at(-1).revision,accepted:!!m.delivery.accepted,summary:m.delivery.versions.at(-1).summary}))],
    original: state.floor==='studio' ? state.mission.artifact : null,
  };
}
