import test from 'node:test';
import assert from 'node:assert/strict';
import { initialState, transition as t } from '../src/simulation/model.js';
import { currentMission } from '../src/simulation/missions.js';
import { floorWorkspaceRecords } from '../src/simulation/floor-workspaces.js';

test('library and activity only project saved work from the current floor',()=>{
 let state=t(initialState(),{type:'ENTER_FLOOR',id:'studio'});
 state=t(state,{type:'MISSION_NEW'});
 state=t(state,{type:'MISSION_EDIT',field:'title',value:'Studio paper <exact>'});
 const studioId=currentMission(state).id;
 state=t(state,{type:'ENTER_FLOOR',id:'growth'});
 state=t(state,{type:'MISSION_NEW'});
 state=t(state,{type:'MISSION_EDIT',field:'title',value:'Growth paper'});
 const before=structuredClone(state);
 const records=floorWorkspaceRecords(state);
 assert.equal(records.papers.length,1);assert.equal(records.papers[0].title,'Growth paper');
 assert(!records.papers.some(p=>p.id===studioId));
 assert.deepEqual(records.activity,[]);assert.deepEqual(records.deliveries,[]);assert.equal(records.original,null);
 assert.deepEqual(state,before);
});

test('workspace navigation preserves selected mission, camera and draft content',()=>{
 let state=t(initialState(),{type:'ENTER_FLOOR',id:'studio'});
 state=t(state,{type:'MISSION_NEW'});
 state=t(state,{type:'MISSION_EDIT',field:'intent',value:'Keep my exact words.'});
 state=t(state,{type:'CAMERA',key:'studio',x:2,y:1,zoom:1.3});
 const mission=structuredClone(currentMission(state)),cameras=structuredClone(state.cameras);
 for(const surface of ['library','floor-activity','people']){
  state=t(state,{type:'OPEN',surface});assert.equal(state.surface,surface);
  state=t(state,{type:'CLOSE'});assert.equal(state.surface,null);
  assert.deepEqual(currentMission(state),mission);assert.deepEqual(state.cameras,cameras);
 }
});

test('delivery projection retains exact authored handoff text and mission anchor',()=>{
 const state=t(initialState(),{type:'MISSION_NEW'});
 const mission=currentMission(state);
 const exact='  A prototype <draft> & review notes.\nKeep this wording.  ';
 mission.events.push({type:'task_delivered',title:'A handoff',owner:'tinus',detail:exact,task:0});
 const records=floorWorkspaceRecords(state);
 assert.equal(records.deliveries[0].missionId,mission.id);
 assert.equal(records.deliveries[0].detail,exact);
 assert.equal(records.activity[0].events[0].detail,exact);
});
