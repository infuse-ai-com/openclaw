import test from 'node:test';
import assert from 'node:assert/strict';
import {createAppearance,resolveTheme,THEME_KEY} from '../src/appearance.js';

test('appearance persists independently and follows OS changes only in System mode',()=>{
 const values=new Map([[THEME_KEY,'dark'],['mission','unchanged']]);
 const root={dataset:{},style:{}};let listener,changes=0;
 const media={matches:false,addEventListener(type,fn){assert.equal(type,'change');listener=fn;}};
 const storage=()=>({getItem:key=>values.get(key),setItem:(key,value)=>values.set(key,value)});
 const appearance=createAppearance({root,media,storage,onChange:()=>changes++});
 assert.equal(root.dataset.studioTheme,'dark');
 listener();assert.equal(changes,0);
 appearance.set('system');assert.equal(root.dataset.studioTheme,'light');
 media.matches=true;listener();assert.equal(root.dataset.studioTheme,'dark');
 assert.equal(values.get(THEME_KEY),'system');assert.equal(values.get('mission'),'unchanged');
 appearance.set('light');listener();assert.equal(root.dataset.studioTheme,'light');
 assert.equal(changes,3);
});
test('unavailable or invalid storage keeps theme switching usable',()=>{
 const root={dataset:{},style:{}};
 const appearance=createAppearance({root,media:{matches:true,addEventListener(){}},storage:()=>{throw Error('blocked');}});
 assert.equal(root.dataset.studioTheme,'light');
 appearance.set('dark');assert.equal(root.dataset.studioTheme,'dark');
 assert.equal(root.style.colorScheme,'dark');
 assert.equal(resolveTheme('invalid',true),'light');
});
