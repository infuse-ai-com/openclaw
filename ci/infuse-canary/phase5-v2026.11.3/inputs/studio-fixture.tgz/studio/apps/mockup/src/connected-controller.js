import {knowledgeDocuments, knowledgeReviewQueue} from './knowledge-content.js';
import { sourcesFor, prototypeView } from './simulation/reference-catalog.js';
import { currentMission } from "./simulation/missions.js";
import { connected, projectContext } from "./simulation/connected.js";
export function createConnectedController({
  getState,
  dispatch,
  render,
  open,
  focus,
}) {
  const views = new Map();
  const view = () => {
    const floor = getState().floor;
    if (!views.has(floor))
      views.set(floor, {
        kb: { query: "", panel: "closed", focus: false, revision: null, screen: "home", reviews: {} },
        previewStep: 0,
        candidateRevision: null,
        ideaId: null,
      });
    return views.get(floor);
  };
  const shownPrototype = () => {
    const s=getState(),v=view();
    return prototypeView(s.floor,connected(s).candidateRevision,currentMission(s)?.candidate||projectContext(s).candidate,v.candidateId,v.candidateRevision);
  };
  const send = (type, extra = {}) => dispatch({ type, ...extra });
  function navigate(id) {
    const m = currentMission(getState());
    if (id === "mission") {
      if(m)send("MISSION_OPEN");else open("ideas");
      focus();
      return;
    }
    if (id === "knowledge") {
      const kb=view().kb, selected=m?.source||projectContext(getState()).source;
      Object.assign(kb,{screen:'reader',documentId:selected?.id||kb.documentId,revision:selected?.revision||null});
    }
    open(
      { knowledge: "knowledge-reader", outputs: "connected-output" }[id] || id,
    );
    focus();
  }
  document.addEventListener('keydown',e=>{
    if(getState().surface!=='knowledge-reader') return;
    if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k') {
      e.preventDefault(); e.stopImmediatePropagation();
      Object.assign(view().kb,{screen:'browse',focus:false,confirmReview:false,reviewQueue:null});
      render(); document.getElementById('knowledge-query')?.focus();
    } else if(e.key==='Escape'&&view().kb.screen==='reader'&&(view().kb.panel!=='closed'||view().kb.focus)) {
      e.preventDefault(); e.stopImmediatePropagation();
      Object.assign(view().kb,{panel:'closed',focus:false,confirmReview:false});
      render(); document.querySelector('.kb-tool-rail button')?.focus();
    }
  },true);
  document.addEventListener("click", (e) => {
    const anchor = e.target.closest(".mvp-kb-context a");
    if (anchor) {
      e.preventDefault();
      document
        .getElementById(anchor.hash.slice(1))
        ?.scrollIntoView({ block: "start" });
      return;
    }
    const b = e.target.closest("[data-connected]");
    if (!b || b.disabled) return;
    const a = b.dataset.connected,
      v = view(),
      s = getState(),
      c = connected(s),
      m = currentMission(s);
    if (["knowledge", "lab", "ideas", "outputs", "mission"].includes(a)) {
      navigate(a);
      return;
    }
        if (a === "nav") {
      navigate(b.dataset.view);
      return;
    }
    if (a === 'kb-search') {
      Object.assign(v.kb,{screen:'browse',focus:false,confirmReview:false,reviewQueue:null});
      render(); document.getElementById('knowledge-query')?.focus(); return;
    }
    if (a === 'kb-review-move') {
      const queue=v.kb.reviewQueue, index=queue?.ids.indexOf(v.kb.documentId)??-1;
      const target=index+Number(b.dataset.step);
      if(index<0||!queue.ids[target]) return;
      Object.assign(v.kb,{documentId:queue.ids[target],revision:queue.revision,confirmReview:false,focus:false,panel:'closed'});
      render(); document.querySelector('.atlas-document-title h1')?.focus(); return;
    }
    if (a === 'kb-screen') {
      Object.assign(v.kb,{screen:b.dataset.screen,focus:false,confirmReview:false,reviewQueue:null});
      render(); focus(); return;
    }
    if (a === 'kb-repository') {
      Object.assign(v.kb,{screen:'browse',repository:b.dataset.repository,query:'',type:''});
      render(); focus(); return;
    }
    if (a === 'kb-reset-filters') {
      Object.assign(v.kb,{query:'',repository:'',type:''}); render(); return;
    }
    if (a === 'kb-context') {
      v.kb.context=b.dataset.context; render();
      document.querySelector(`[data-connected="kb-context"][data-context="${v.kb.context}"]`)?.focus(); return;
    }
    if (a === 'kb-revision') {
      const revision=Number(b.dataset.revision);
      if ([1,c.sourceRevision].includes(revision)) v.kb.revision=revision;
      v.kb.confirmReview=false; render(); return;
    }
    if (a === 'kb-review-start' || a === 'kb-review-cancel') {
      if(a==='kb-review-start') {v.kb.panel='inspect';v.kb.focus=false;}
      v.kb.confirmReview=a==='kb-review-start'?{id:v.kb.documentId||sourcesFor(s.floor)[0].id,revision:v.kb.revision||c.sourceRevision}:false; render(); document.querySelector(a==='kb-review-start'?'[data-connected=kb-review-confirm]':'[data-connected=kb-review-start]')?.focus(); return;
    }
    if (a === 'kb-review-confirm') {
      if (c.mode!=='ready'||!c.sourceAvailable||!v.kb.confirmReview) return;
      const id=v.kb.documentId||sourcesFor(s.floor)[0].id;
      const revision=v.kb.revision||c.sourceRevision;
      if(v.kb.confirmReview.id!==id||v.kb.confirmReview.revision!==revision) return;
      v.kb.reviews[id]=[...new Set([...(v.kb.reviews[id]||[]),revision])];
      v.kb.confirmReview=false; render(); document.querySelector('.kb-review-confirm')?.setAttribute('tabindex','-1');document.querySelector('.kb-review-confirm')?.focus(); return;
    }
    if (a === "kb-panel") {
      v.kb.panel = v.kb.panel === b.dataset.panel && !v.kb.focus ? "closed" : b.dataset.panel;
      v.kb.focus=false;
      render(); document.querySelector(`.kb-tool-rail [data-panel="${b.dataset.panel}"]`)?.focus();
      return;
    }
    if (a === "kb-focus") {
      v.kb.focus = !v.kb.focus;
      render();document.querySelector('.kb-tool-rail [data-connected="kb-focus"]')?.focus();
      return;
    }
    if (a === "kb-selected" || a === "kb-latest") {
      v.kb.confirmReview=false;v.kb.reviewQueue=null;
      v.kb.documentId=a==="kb-selected"?(m?.source||projectContext(s).source)?.id:v.kb.documentId;
      v.kb.revision =
        a === "kb-selected"
          ? (m?.source || projectContext(s).source)?.revision
          : null;
      render();
      return;
    }
    if (a === "candidate-selected" || a === "candidate-latest") {
      v.candidateId=a==="candidate-selected"?(m?.candidate||projectContext(s).candidate)?.id:v.candidateId;
      v.deltas=null;
      v.candidateId=a==="candidate-latest"?shownPrototype().candidate.id:v.candidateId;
      v.previewStep=0;
      v.candidateRevision =
        a === "candidate-selected"
          ? (m?.candidate || projectContext(s).candidate)?.revision
          : null;
      render();
      return;
    }
    if (a === "reader") {
      Object.assign(v.kb,{documentId:b.dataset.id,revision:null,screen:'reader',confirmReview:false});
      v.kb.reviewQueue=b.dataset.review?{ids:knowledgeReviewQueue(knowledgeDocuments(s.floor),c.sourceRevision,v.kb),revision:c.sourceRevision}:null;
      v.kb.revision=v.kb.reviewQueue?.revision||null;
      v.kb.focus=false;v.kb.panel='closed';
      render();
      document.querySelector('.atlas-document-title h1')?.focus();
      return;
    }
    if (a === "preview-step") {
      v.previewStep = 1 - v.previewStep;
      render();
      return;
    }
    if (a === "example") {
      document.querySelector("#idea-text").value =
        "Make it easier for a new partner to find their next useful action.";
      return;
    }
    if (a === "edit-idea") {
      v.ideaId = b.dataset.id;
      render();
      return;
    }
    if (
      a === "cancel" &&
      !confirm("Cancel this simulated mission? Its record remains inspectable.")
    )
      return;
    const map = {
      source: "CONNECTED_SOURCE",
      "remove-source":"CONNECTED_REMOVE_SOURCE",
      "mcp-update":"CONNECTED_MCP_UPDATE",
      "mcp-apply":"CONNECTED_MCP_APPLY",
      "mcp-fork":"CONNECTED_MCP_FORK",
      candidate: "CONNECTED_CANDIDATE",
      "idea-draft": "CONNECTED_IDEA_DRAFT",
      mcp: "CONNECTED_MCP",
      advance: "MISSION_ADVANCE",
      hold: "CONNECTED_HOLD",
      resume: "CONNECTED_RESUME",
      cancel: "CONNECTED_CANCEL",
      acknowledge: "CONNECTED_ACK",
      publish: "CONNECTED_PUBLISH",
      learning: "CONNECTED_LEARNING",
      "source-update": "CONNECTED_SOURCE_UPDATE",
      "source-toggle": "CONNECTED_SOURCE_TOGGLE",
      "candidate-update": "CONNECTED_CANDIDATE_UPDATE",
      "preview-toggle": "CONNECTED_PREVIEW_TOGGLE",
    };
    if (map[a]) {
      send(map[a], {
        id: a==="source"?(v.kb.documentId||sourcesFor(s.floor)[0].id):a==="candidate"?shownPrototype().candidate.id:b.dataset.id,
        deltas:a==="candidate"?[...document.querySelectorAll("[data-delta]:checked")].map(el=>el.value):undefined,
        task: b.dataset.task,
        revision:
          a === "source"
            ? v.kb.revision || c.sourceRevision
            : a === "candidate"
              ? shownPrototype().shownRevision
              : Number(b.dataset.revision),
      });
      if (["idea-draft", "mcp"].includes(a)) focus();
    }
  });
  document.addEventListener("submit", (e) => {
    if (
      ![
        "idea-form",
        "lab-feedback-form",
        "knowledge-search",
        "connected-feedback",
        "connected-followup",
      ].includes(e.target.id)
    )
      return;
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target)),
      v = view();
    if (e.target.id === "idea-form") {
      send("CONNECTED_SAVE_IDEA", { id: v.ideaId, text: d.text, start:e.submitter?.value==='start' });
      v.ideaId = null;
      render();
      focus();
    }
    if (e.target.id === "lab-feedback-form")
      send("CONNECTED_LAB_NOTE", {
        text: d.text,
        candidateId:shownPrototype().candidate.id,
        revision:
          shownPrototype().shownRevision,
      });
    if (e.target.id === "knowledge-search") {
      v.kb.query = d.query; v.kb.screen='browse';
      render();
      document.getElementById("knowledge-query")?.focus();
    }
    if (e.target.id === "connected-feedback")
      send(d.kind==="clarification"?"CONNECTED_CLARIFY":d.kind==="scope"?"CONNECTED_SCOPE":"CONNECTED_FEEDBACK", { text: d.text });
    if (e.target.id === "connected-followup") {
      send("MISSION_FOLLOWUP", {
        source: d.source === "on",
        candidate: d.candidate === "on",
      });
      focus();
    }
  });
  document.addEventListener("change", (e) => {
    const el = e.target;
    if(el.matches('[data-kb-filter]')) {view().kb[el.dataset.kbFilter]=el.value;render();document.querySelector(`[data-kb-filter="${el.dataset.kbFilter}"]`)?.focus();return;}
    if(el.matches('[data-kb-library]')) {
      const doc=sourcesFor(getState().floor).find(d=>d.repo===el.value);
      if(doc) Object.assign(view().kb,{documentId:doc.id,revision:null,confirmReview:false,reviewQueue:null});
      render();return;
    }
    if(el.matches('[data-connected-partner]'))send('CONNECTED_PARTNER',{value:el.value});
    if(el.matches('[data-candidate-choice]')){Object.assign(view(),{candidateId:el.value,candidateRevision:null,deltas:null,previewStep:0});render();}
    if(el.matches('[data-delta]'))view().deltas=[...document.querySelectorAll('[data-delta]:checked')].map(el=>el.value);
    if (el.matches("[data-connected-mode]"))
      send("CONNECTED_MODE", { value: el.value });
    if (el.matches("[data-connected-gate]"))
      send("CONNECTED_GATE", { value: el.checked });
    if (el.dataset.pref) {
      const key = el.dataset.pref;
      send("CONNECTED_PREF", {
        value: {
          [key]:
            key === "size"
              ? Number(el.value)
              : key === "wide"
                ? el.value === "true"
                : el.value,
        },
      });
    }
  });
  return {
    view,
    navigate,
    restore() {
      const v = view();
      if (v.ideaId && document.querySelector("#idea-text")) {
        const idea = projectContext(getState()).ideas.find(
          (i) => i.id === v.ideaId,
        );
        if (idea) {
          document.querySelector("#idea-text").value = idea.text;
          document.querySelector("#idea-form [data-save-idea]").textContent =
            "Save changes for later";
        }
      }
    },
  };
}
