// Authored, synthetic project content. No canonical service calls.
export const SOURCE={id:'onboarding-guide',title:'A good first day',path:'docs/onboarding.md',repo:'studio-fixture',revision:1};
export const CANDIDATE={id:'onboarding',title:'A clearer first step',path:'prototype/onboarding',repo:'studio-fixture',revision:1,pr:'DEMO-24',build:'fixture-build-1',baseline:'product-baseline-1',selection:'A next-action card and an accessible first-step checklist.',deltas:[{id:'next-action',label:'A clear next-action card'},{id:'checklist',label:'An accessible first-step checklist'}]};
function primarySourcesFor(floor){return floor==='studio'?[SOURCE,{id:'review-guide',title:'Review exact evidence',path:'docs/review.md',repo:'studio-fixture',revision:1}]:[{id:`${floor}-brief`,title:floor==='client'?'A clear client handoff':'A bounded growth experiment',path:'docs/brief.md',repo:`${floor}-fixture`,revision:1},{id:`${floor}-criteria`,title:'Outcome and verification criteria',path:'docs/criteria.md',repo:`${floor}-fixture`,revision:1}];}
export function candidatesFor(floor){return floor==='studio'?[CANDIDATE,{...CANDIDATE,id:'review-desk',title:'A focused review desk',path:'prototype/review',selection:'Evidence first, followed by the next decision.',deltas:[{id:'evidence',label:'Exact evidence card'},{id:'decision',label:'Required decision panel'}]}]:[{...CANDIDATE,id:`${floor}-handoff`,title:floor==='client'?'A clearer client handoff':'A measurable experiment',repo:`${floor}-fixture`,path:'prototype/handoff',selection:'Agree on the outcome and inspect the verification checklist.',deltas:[{id:'outcome',label:'Visible agreed outcome'},{id:'criteria',label:'Inspectable verification checklist'}]}];}
export const partners=['Fito','Alex'];
export const partner=s=>s.connected?.partner||'Fito';
export const canManage=(s,m)=>!m||!m.decisionOwner||m.decisionOwner===partner(s);

// Knowledge preview sources are synthetic and isolated to the selected project.
export function sourcesFor(floor) {
  return [...primarySourcesFor(floor),
    {id:`${floor}-company`, title:'How we work together', path:'docs/operating-model.md', repo:`${floor}-company-fixture`, revision:1},
    {id:`${floor}-engineering`, title:'From intent to verified delivery', path:'docs/delivery.md', repo:`${floor}-engineering-fixture`, revision:1},
    {id:`${floor}-agents`, title:'Working with your agent team', path:'docs/agents.md', repo:`${floor}-agents-fixture`, revision:1},
    {id:`${floor}-runbooks`, title:'Keep runbooks useful', path:'docs/runbooks.md', repo:`${floor}-engineering-fixture`, revision:1},
  ];
}

// Browsing never changes the selected mission reference. Use its exact version
// on first entry, unless the partner has explicitly chosen another preview.
export function prototypeView(floor, currentRevision, selected, candidateId=null, revision=null) {
  const candidates=candidatesFor(floor);
  const candidate=candidates.find(c=>c.id===(candidateId||selected?.id))||candidates[0];
  const shownRevision=revision||(!candidateId&&selected?.id===candidate.id?selected.revision:currentRevision);
  return {candidate,shownRevision};
}
