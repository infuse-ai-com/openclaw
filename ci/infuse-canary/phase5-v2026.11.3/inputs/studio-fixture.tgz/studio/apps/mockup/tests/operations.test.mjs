import test from 'node:test';
import assert from 'node:assert/strict';
import { initialState, transition as t, restoreState } from '../src/simulation/model.js';
import { checksForFloor, checkNeedsAttention } from '../src/simulation/operations.js';
const config={name:'Exact check <name>',description:'  Keep my instructions & threshold.\nDo not execute them.  ',owner:'satwa',schedule:'hourly',policy:'consecutive'};
test('scheduled checks are scoped to their floor, editable and restored without changing missions',()=>{
 let s=initialState();const mission=structuredClone(s.mission);
 assert.equal(checksForFloor(s).length,4);
 s=t(s,{type:'OPS_CREATE',id:'my-check',config});
 s=t(s,{type:'OPS_UPDATE',id:'my-check',config:{...config,schedule:'daily'}});
 const restored=restoreState(JSON.stringify(s));assert.equal(restored.notice,null);s=restored.state;
 assert.equal(checksForFloor(s).at(-1).description,config.description);assert.equal(checksForFloor(s).at(-1).schedule,'daily');
 assert.deepEqual(s.mission,mission);
 s=t(s,{type:'ENTER_FLOOR',id:'growth'});assert.deepEqual(checksForFloor(s),[]);
 s=t(s,{type:'OPS_EXAMPLES'});assert.equal(checksForFloor(s).length,4);
 s=t(s,{type:'ENTER_FLOOR',id:'studio'});assert.equal(checksForFloor(s).length,5);
});
test('pause preserves failures, blocks a test run, and resume allows explicit simulation',()=>{
 let s=initialState();s=t(s,{type:'OPS_TOGGLE',id:'backup'});
 let job=checksForFloor(s).find(j=>j.id==='backup');assert.equal(job.enabled,false);assert.equal(checkNeedsAttention(job),true);
 assert.equal(t(s,{type:'OPS_RUN',id:'backup',outcome:'healthy'}),s);
 s=t(s,{type:'OPS_TOGGLE',id:'backup'});s=t(s,{type:'OPS_RUN',id:'backup',outcome:'healthy'});
 job=checksForFloor(s).find(j=>j.id==='backup');assert.equal(checkNeedsAttention(job),false);assert.equal(job.runs[0].trigger,'Manual simulation');assert.equal(job.runs[1].status,'attention');
});
test('attention policies distinguish failure history from escalation',()=>{
 let s=t(initialState(),{type:'OPS_CREATE',id:'my-check',config});
 s=t(s,{type:'OPS_RUN',id:'my-check',outcome:'attention'});assert.equal(checkNeedsAttention(checksForFloor(s).at(-1)),false);
 s=t(s,{type:'OPS_RUN',id:'my-check',outcome:'attention'});assert.equal(checkNeedsAttention(checksForFloor(s).at(-1)),true);
 s=t(s,{type:'OPS_UPDATE',id:'my-check',config:{...config,policy:'report'}});assert.equal(checkNeedsAttention(checksForFloor(s).at(-1)),false);
 assert.equal(checksForFloor(s).at(-1).runs[0].status,'attention');
});
test('invalid config cannot be saved, corrupt checks recover independently, reset restores examples',()=>{
 const s=initialState();assert.equal(t(s,{type:'OPS_CREATE',id:'bad',config:{...config,name:'  '}}),s);
 assert.equal(t(s,{type:'OPS_CREATE',id:'bad',config:{...config,schedule:'arbitrary-cron'}}),s);
 s.operationFloors={studio:[{id:'broken'}]};const recovered=restoreState(JSON.stringify(s));
 assert.match(recovered.notice,/operation checks/);assert.deepEqual(recovered.state.mission,s.mission);assert.equal(checksForFloor(recovered.state).length,4);
 const changed=t(recovered.state,{type:'OPS_TOGGLE',id:'backup'});const reset=t(changed,{type:'RESET'});assert.equal(checksForFloor(reset)[0].enabled,true);
});

test('routine categories persist independently of owners and old saved checks still render',async()=>{
 const {checkCategory}=await import('../src/simulation/operations.js');
 const {operationsSurface}=await import('../src/operations-ui.js');
 let s=t(initialState(),{type:'OPS_CREATE',id:'categorized',config:{...config,category:'knowledge',owner:'satwa'}});
 s=t(s,{type:'OPS_UPDATE',id:'categorized',config:{...config,category:'knowledge',owner:'emon'}});
 s=restoreState(JSON.stringify(s)).state;
 assert.equal(checkCategory(checksForFloor(s).at(-1)),'knowledge');
 const html=operationsSurface(s,{filter:'knowledge',selected:'categorized'});
 assert.match(html,/Exact check &lt;name&gt;/);assert.doesNotMatch(html,/data-ops-select="backup"/);
 assert.match(html,/aria-expanded="true"/);assert.match(html,/No runs recorded yet/);
 const paused=operationsSurface(s,{filter:'paused',selected:null});
 assert.match(paused,/No run scheduled/);assert.doesNotMatch(paused,/data-ops-select="availability"/);
 const old=t(initialState(),{type:'OPS_TOGGLE',id:'backup'});
 assert.equal(restoreState(JSON.stringify(old)).notice,null);
 assert.equal(checkCategory(checksForFloor(old)[0]),'infrastructure');
 assert.equal(t(s,{type:'OPS_UPDATE',id:'categorized',config:{...config,category:'unknown'}}),s);
});
