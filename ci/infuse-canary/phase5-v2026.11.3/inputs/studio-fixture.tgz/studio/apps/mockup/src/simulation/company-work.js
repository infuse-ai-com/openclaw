import { allFloors, companyPeople } from './company.js';
import { missionDisplayTitle } from './mission-copy.js';
import { workStatus } from './work-projections.js';

export function personAssignments(state, personId) {
 if (['denied','loading'].includes(state.connected?.mode)||!companyPeople(state).some(p=>p.id===personId)) return [];
 const floors=new Map(allFloors(state).map(f=>[f.id,f.title]));
 return (state.missionDesk?.items||[]).filter(m=>floors.has(m.floorId)&&m.squad.includes(personId)&&
  (m.execution?!['closed','cancelled'].includes(m.execution.state):m.status!=='completed'))
  .map(m=>({projectId:m.floorId,projectTitle:floors.get(m.floorId),missionId:m.id,title:missionDisplayTitle(m)||'Untitled mission',
   label:m.status==='draft'?'Proposed team · work has not started':workStatus(m)?.label||
    (m.status==='approved'?(m.startup==='hold'?'Approved · on hold':'Approved · preparing to start'):'Simulation in progress')}));
}
