import { learningProposals } from './work-projections.js';
import { createdMissions, currentMission, missionTransition } from './missions.js';
import { companyPeople, projectFloor, floorPeople, allFloors, guestValid, MODEL_PRESETS, REASONING_LEVELS } from './company.js';
import { DEFAULT_MODEL } from '../scenarios/catalog.js';
export const emptyKnowledge=()=>({entries:[],expertLinks:{},expertFloors:{},expertConfigs:{}});
const string=(v,max=8000)=>typeof v==='string'&&v.length<=max;
export const libraryEntries=s=>[...(s.knowledge?.entries||[]).filter(e=>e.floorId===s.floor),...learningProposals(s)];
export const acceptedWork=s=>createdMissions(s).filter(m=>m.execution?.state==='closed'||m.delivery?.accepted);
export function entryStatus(s,e){
 if(e.review==='proposed')return 'Proposed · source owner review pending';
 if(e.origin){const m=createdMissions(s,e.floorId).find(m=>m.id===e.origin.missionId);if(!m?.delivery?.accepted||m.delivery.accepted.revision!==e.origin.revision)return 'Origin changed';}
 return {unreviewed:'Not reviewed',reviewed:'Owner reviewed',stale:'Review due'}[e.review];
}
export function reusableContext(s,person){return libraryEntries(s).filter(e=>e.review!=='proposed').map(e=>({...e,status:entryStatus(s,e),reason:s.knowledge?.expertLinks?.[person]?.includes(e.id)?'Linked to this expert’s knowledge profile.':e.kind==='learning'?'Learning from an accepted result on this floor.':'A source saved on this project floor.'}));}
export function sourceSnapshot(e){return `${e.title} · r${e.revision}\n${e.body}\nSource: ${e.reference||'Owner-supplied note'}\nReview: ${e.review}\n${e.origin?`Accepted result: ${e.origin.missionId} · r${e.origin.revision}\n${e.origin.evidence}`:''}`;}
export function knowledgeTransition(state,event){
 if(!event.type.startsWith('KNOW_'))return null;
 const s=structuredClone(state);s.knowledge??=emptyKnowledge();const k=s.knowledge,entries=libraryEntries(s);
 if(event.type==='KNOW_SOURCE_SAVE'){
  if(!string(event.title,120)||!event.title.trim()||!string(event.body,8000)||!event.body.trim()||!string(event.reference,2000))return state;
  const existing=entries.find(e=>e.id===event.id);if(event.id&&!existing||existing?.kind==='learning')return state;
  if(existing){Object.assign(existing,{title:event.title,body:event.body,reference:event.reference,revision:existing.revision+1,review:'unreviewed',reviewedAt:null});}
  else k.entries.push({id:`knowledge-${Math.max(0,...k.entries.map(e=>Number(e.id.split('-')[1])))+1}`,floorId:s.floor,kind:'source',title:event.title,body:event.body,reference:event.reference,revision:1,review:'unreviewed',reviewedAt:null,origin:null});
  return s;
 }
 if(event.type==='KNOW_REVIEW'){
  const e=entries.find(e=>e.id===event.id);if(!e||e.review==='proposed'||!['reviewed','stale'].includes(event.review))return state;
  e.review=event.review;e.reviewedAt=event.review==='reviewed'?new Date().toISOString():null;return s;
 }
 if(event.type==='KNOW_LEARNING'){
  const m=acceptedWork(s).find(m=>m.id===event.id);if(!m||m.execution||!string(event.body,8000)||!event.body.trim())return state;
  const revision=m.delivery.accepted.revision;if(entries.some(e=>e.origin?.missionId===m.id&&e.origin.revision===revision))return state;
  const artifact=m.delivery.versions.find(v=>v.revision===revision);
  const evidence=[...artifact.sections.map(x=>`${x.title}\n${x.body}`),...m.delivery.notes.map(n=>`Feedback on ${n.anchor} / r${n.revision}\n${n.text}`)].join('\n\n');
  k.entries.push({id:`knowledge-${Math.max(0,...k.entries.map(e=>Number(e.id.split('-')[1])))+1}`,floorId:s.floor,kind:'learning',title:`Learning · ${m.title}`.slice(0,120),body:event.body,reference:`Local accepted delivery ${m.id} · r${revision}`,revision:1,review:'reviewed',reviewedAt:new Date().toISOString(),origin:{missionId:m.id,revision,evidence}});return s;
 }
 if(event.type==='KNOW_REUSE'){
  const expert=event.person?floorPeople(s).find(p=>p.id===event.person&&p.id!=='fito'):null;if(event.person&&!expert)return state;
  const source=event.missionId?acceptedWork(s).find(m=>m.id===event.missionId):null;
  if(event.missionId&&!source||!string(event.intent,8000)||!event.intent.trim()||!string(event.title,160)||!Array.isArray(event.sources)||new Set(event.sources).size!==event.sources.length||event.sources.some(id=>!entries.some(e=>e.id===id&&e.review!=='proposed'))||typeof event.plan!=='boolean'||typeof event.team!=='boolean')return state;
  const selected=entries.filter(e=>event.sources.includes(e.id));
  const context=selected.map(e=>`${sourceSnapshot(e)}\nCurrent status: ${entryStatus(s,e)}`).join('\n\n---\n\n');if(context.length>8000)return state;
  let next=missionTransition(s,{type:'MISSION_NEW'});const m=currentMission(next);m.title=event.title;m.content.intent=event.intent;m.content.references=context;
  if(source){m.parentId=source.id;for(const field of ['outcome','scope','nonGoals','decisions','evidence'])m.content[field]=source.approved.content[field];
   if(event.team){m.squad=[...source.approved.squad];m.candidates=[...new Set([...m.candidates,...source.candidates])];m.config={...m.config,...structuredClone(source.approved.config)};m.guestBriefs={...m.guestBriefs,...structuredClone(source.approved.guestBriefs)};}
   if(event.plan){m.planning.steps=structuredClone(source.approved.plan).map((p,i)=>({...p,id:`step-${i+1}`,owner:m.squad.includes(p.owner)?p.owner:'emon'}));m.planning.notes=source.approved.planNotes||'';}
  }
  if(expert)m.squad=[...new Set(['emon',expert.id])];
  m.origins=Object.fromEntries(Object.entries(m.content).filter(([,v])=>v).map(([key])=>[key,'user']));m.summary='Chosen context copied as a snapshot. Review the reused scope, plan and team before approving this new mission.';
  next=missionTransition(next,{type:'MISSION_STEP',stage:'shape'});return next;
 }
 if(event.type==='KNOW_EXPERT_LINK'){
  const person=companyPeople(s).find(p=>p.id===event.person),e=entries.find(e=>e.id===event.id);if(!person||person.id==='fito'||!e||e.review==='proposed')return state;
  const ids=k.expertLinks[person.id]??=[];k.expertLinks[person.id]=ids.includes(e.id)?ids.filter(id=>id!==e.id):[...ids,e.id];return s;
 }
 if(event.type==='KNOW_GUEST_SAVE'){
  const existing=companyPeople(s).find(p=>p.id===event.id&&p.guest);if(event.id&&!existing)return state;
  const id=existing?.id||`guest-${Math.max(0,...companyPeople(s,true).filter(p=>p.guest).map(p=>Number(p.id.split('-')[1])))+1}`;
  const p={id,...Object.fromEntries(['name','role','traits','brief','sources'].map(key=>[key,event[key]])),description:'Guest expert with an owner-supplied research brief.',guest:true,color:'#aa8fbe',hair:'#4b3549',skills:['expert-advice','expert-review']};
  if(!guestValid(p)||companyPeople(s).some(x=>x.id!==id&&x.name.trim().toLowerCase()===p.name.trim().toLowerCase()))return state;
  if(!MODEL_PRESETS.includes(event.model)||!REASONING_LEVELS.includes(event.reasoning)||!Array.isArray(event.skills)||!event.skills.length||new Set(event.skills).size!==event.skills.length||event.skills.some(x=>!p.skills.includes(x)))return state;
  const project=projectFloor(s),residents=project?.residents,extra=k.expertFloors[s.floor]??=[];
  if(!existing&&!floorPeople(s).some(x=>x.id===id)&&floorPeople(s).filter(x=>x.id!=='fito').length>=8)return state;
  s.guests=[...s.guests.filter(x=>x.id!==id),p];
  const config={personId:id,capabilities:[...event.skills],llm:event.model,reasoning:event.reasoning};
  if(residents){const r=residents.find(x=>x.personId===id);if(r)Object.assign(r,config);else if(residents.length<8)residents.push(config);}
  else {if(!extra.includes(id)&&extra.length<2)extra.push(id);k.expertConfigs[s.floor]??={};k.expertConfigs[s.floor][id]=config;}
  s.detail=id;s.surface='people';return s;
 }
 return state;
}
export function restoreKnowledge(s){
 if(s.knowledge===undefined){s.knowledge=emptyKnowledge();return false;}
 const k=s.knowledge,object=x=>x&&typeof x==='object'&&!Array.isArray(x),floors=allFloors(s).map(f=>f.id),people=companyPeople(s);
 const valid=object(k)&&Array.isArray(k.entries)&&new Set(k.entries.map(e=>e?.id)).size===k.entries.length&&k.entries.every(e=>e&&/^knowledge-[1-9]\d*$/.test(e.id)&&floors.includes(e.floorId)&&['source','learning'].includes(e.kind)&&string(e.title,120)&&e.title.trim()&&string(e.body,8000)&&e.body.trim()&&string(e.reference,2000)&&Number.isInteger(e.revision)&&e.revision>0&&['unreviewed','reviewed','stale'].includes(e.review)&&(e.reviewedAt===null||Number.isFinite(Date.parse(e.reviewedAt)))&&(e.origin===null||object(e.origin)&&/^mission-[1-9]\d*$/.test(e.origin.missionId)&&Number.isInteger(e.origin.revision)&&e.origin.revision>0&&string(e.origin.evidence,500000)))&&object(k.expertLinks)&&Object.entries(k.expertLinks).every(([id,ids])=>people.some(p=>p.id===id)&&Array.isArray(ids)&&new Set(ids).size===ids.length&&ids.every(id=>k.entries.some(e=>e.id===id)))&&object(k.expertFloors)&&Object.entries(k.expertFloors).every(([id,ids])=>floors.includes(id)&&Array.isArray(ids)&&ids.length<=2&&new Set(ids).size===ids.length&&ids.every(id=>s.guests.some(p=>p.id===id)))&&object(k.expertConfigs)&&Object.entries(k.expertConfigs).every(([floor,configs])=>floors.includes(floor)&&object(configs)&&Object.entries(configs).every(([id,c])=>s.guests.some(p=>p.id===id)&&c&&c.personId===id&&MODEL_PRESETS.includes(c.llm)&&REASONING_LEVELS.includes(c.reasoning)&&Array.isArray(c.capabilities)&&c.capabilities.length>0&&c.capabilities.every(x=>['expert-advice','expert-review'].includes(x))));
 if(!valid)s.knowledge=emptyKnowledge();return !valid;
}
