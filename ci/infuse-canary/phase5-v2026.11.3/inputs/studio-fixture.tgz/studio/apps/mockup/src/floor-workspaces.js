import { pageHeader, emptyState } from '@studio/ui/workspace';
import { allFloors } from './simulation/company.js';
import { missionPerson } from './simulation/missions.js';
import { floorWorkspaceRecords } from './simulation/floor-workspaces.js';

const esc = value => String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
export const FLOOR_WORKSPACES = [
  {action:'founder-desk',label:'Your desk',icon:'home',hint:'Prioritized decisions and recommendations from Emon'},
  {action:'mission-list',label:'Missions',icon:'files',hint:'Priorities, status and the next decision'},
  {action:'connected-ideas',label:'Grilling',icon:'edit',hint:'Define a mission with Emon'},
  {action:'knowledge-reader',label:'Knowledge',icon:'library',hint:'Read and select exact sources'},
  {action:'lab',label:'Prototype',icon:'flask',hint:'Review prototype candidates and select intent'},
  {action:'freeboard',label:'Whiteboard',icon:'board',hint:'Shared ideas and editable canvases'},
  {action:'people',label:'Agents',icon:'users',hint:'Residents, capabilities and assignments'},
  {action:'review-wall',label:'Review',icon:'review',hint:'Inspect deliveries, corrections and acceptance'},
  {action:'library',label:'Outputs',icon:'document',hint:'Mission papers and simulated deliveries'},
  {action:'operations',label:'Operations',icon:'operations',hint:'Scheduled checks, health and recurring jobs'},
  {action:'floor-activity',label:'Activity',icon:'chart',hint:'Recorded events and team handoffs'},
];

export function floorWorkspaceLinks(current='',icons={}) {
  return `<nav class="floor-workspace-links" aria-label="Floor workspaces">${FLOOR_WORKSPACES.map(item=>`<button data-action="${item.action}" ${current===item.action?'aria-current="page"':''} title="${item.hint}">${icons[item.icon]||''}<span>${item.label}</span></button>`).join('')}</nav>`;
}

const missionButton=(id,label='Open mission →')=>`<button class="quiet-button" data-mission-select="${esc(id)}">${label}</button>`;

export function floorWorkspaceSurface(state,icons={}) {
  const floor=allFloors(state).find(f=>f.id===state.floor);
  const library=state.surface==='library';
  const records=floorWorkspaceRecords(state);
  const title=library?'The work, kept together.':'What has happened.';
  const description=library?'Papers and handoffs from this floor. Open a mission to inspect its source and decisions.':'Recorded approvals and simulated handoffs, grouped by mission. Nothing starts from this view.';
  return `${pageHeader({eyebrow:floor.title,title:library?'Library':'Activity',description})}<div class="floor-workspace-content">${library?libraryContent(records):activityContent(state,records)}<p class="floor-workspace-boundary">Local demo · papers are saved in this browser. Deliveries and activity are simulated.</p></div>`;
}

function libraryContent(records) {
  return `<section class="floor-record-section"><div class="ui-section-heading floor-section-heading"><h2>Mission papers</h2><span>${records.papers.length} saved</span></div>${records.papers.length?`<div class="floor-paper-grid">${records.papers.map(p=>`<article><div class="floor-record-meta"><span>${esc(p.status)}</span><span>r${p.revision}</span></div><h3>${esc(p.title)}</h3><p>${esc(p.summary)}</p>${missionButton(p.id,'Inspect paper and mission →')}</article>`).join('')}</div>`:empty('Your first brief belongs here.','Shape a mission with Emon. Its paper will appear here as you work.','Start a mission','mission-new')}</section><section class="floor-record-section"><div class="ui-section-heading floor-section-heading"><h2>Deliveries</h2><span>Simulation evidence</span></div>${records.results.map(r=>`<article class="ui-card floor-delivery"><span class="eyebrow">${r.accepted?'ACCEPTED DEMO RESULT':'AWAITING RESULT REVIEW'} / r${r.revision}</span><h3>${esc(r.title)}</h3><p>${esc(r.summary)}</p><button class="quiet-button" data-delivery-open="${r.id}">Inspect delivery and evidence →</button></article>`).join('')}${records.deliveries.map(d=>`<article class="ui-card floor-delivery"><span class="eyebrow">${esc(d.missionTitle)} / SIMULATED</span><h3>${esc(d.title)}</h3><p>${esc(d.detail)}</p>${missionButton(d.missionId,'Inspect recorded delivery →')}</article>`).join('')}${records.original?`<article class="ui-card floor-delivery"><span class="eyebrow">ORIGINAL STUDIO WALKTHROUGH</span><h3>Design proposal</h3><p>The proposal and its review evidence from the guided demo.</p>${missionButton('studio-001','Open original mission →')}</article>`:''}${!records.deliveries.length&&!records.original?'<div class="ui-empty floor-workspace-empty"><h3>No deliveries yet.</h3><p>Approved missions will leave simulated handoffs here as you advance their work.</p></div>':''}</section>`;
}
function activityContent(state,records) {
  return records.activity.length?records.activity.map(m=>`<section class="floor-record-section"><div class="ui-section-heading floor-section-heading"><h2>${esc(m.title)}</h2>${missionButton(m.id)}</div><ol class="floor-event-list">${m.events.map((e,i)=>`<li><span class="floor-event-index">${String(i+1).padStart(2,'0')}</span><div><span class="eyebrow">${esc(e.actor||missionPerson(state,e.owner)?.name||e.owner)} / SIMULATED</span><h3>${esc(e.title)}</h3><p>${esc(e.detail)}</p></div></li>`).join('')}</ol></section>`).join(''):empty('A quiet floor, with room to begin.','Approvals and simulated work will appear here. Drafting a brief does not start the team.','Open missions','mission-list');
}
function empty(title,description,label,action){return emptyState({title,description,actionsHtml:`<button class="secondary" data-action="${esc(action)}">${esc(label)}</button>`});}
