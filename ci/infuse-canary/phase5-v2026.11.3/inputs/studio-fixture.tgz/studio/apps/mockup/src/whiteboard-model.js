// Field-level last-writer-wins registers for the local collaboration prototype.
// Lamport clocks + actor IDs make concurrent delivery deterministic. This is
// deliberately not character-level co-editing or a server-backed CRDT service.
export const boardPrefix = floor => `studio-whiteboard-v1:${encodeURIComponent(floor)}:`;
const idOK = value => typeof value==='string' && /^[\w-]{1,100}$/.test(value);
const pointOK = value => value && Number.isFinite(value.x) && Number.isFinite(value.y);
export const DEFAULT_TAB='tab-exploration';
export const CARD_TONES=['cream','yellow','green','blue','pink'];
const sizeOK = value => value && Number.isFinite(value.w) && value.w>=120 && value.w<=900 && Number.isFinite(value.h) && value.h>=70 && value.h<=1000;
const textOK = value => typeof value==='string' && value.length<=12000;
export function validOperation(op){
  if(!op||!idOK(op.node)||!idOK(op.actor)||!Number.isSafeInteger(op.clock)||op.clock<0)return false;
  const v=op.value;
  if(op.field==='tab')return v&&typeof v.title==='string'&&v.title.trim().length>0&&v.title.length<=80&&Number.isSafeInteger(v.order)&&v.order>=0;
  if(op.field==='link')return v&&idOK(v.from)&&idOK(v.to)&&v.from!==v.to&&idOK(v.tab);
  if(op.field==='tone')return CARD_TONES.includes(v);
  if(op.field==='shape')return ['rectangle','ellipse','diamond'].includes(v);
  if(op.field==='card')return v&&(v.tab===undefined||idOK(v.tab))&&['note','document','preview','text','shape'].includes(v.kind)&&textOK(v.title)&&textOK(v.body)&&pointOK(v.position)&&sizeOK(v.size)&&CARD_TONES.includes(v.tone);
  if(op.field==='position')return pointOK(v);
  if(op.field==='size')return sizeOK(v);
  if(op.field==='title'||op.field==='body')return textOK(v);
  if(op.field==='deleted')return typeof v==='boolean';
  if(/^comment-[\w-]{1,100}$/.test(op.field))return v&&textOK(v.text)&&v.text.trim()&&typeof v.author==='string'&&v.author.length<=60;
  return false;
}
export function newer(a,b){return !b||a.clock>b.clock||(a.clock===b.clock&&a.actor>b.actor);}
export function applyOperation(records,op){
  if(!validOperation(op))return false;
  const fields=records.get(op.node)||new Map();
  if(!newer(op,fields.get(op.field)))return false;
  fields.set(op.field,structuredClone(op));records.set(op.node,fields);return true;
}
export function cardsFrom(records,tab){
  return [...records].flatMap(([id,fields])=>{
    const base=fields.get('card')?.value;if(!base||fields.get('deleted')?.value)return [];
    const card={tab:DEFAULT_TAB,shape:'rectangle',...structuredClone(base),id,comments:[]};
    if(tab&&card.tab!==tab)return [];
    for(const [key,op] of fields){
      if(['position','size','title','body','tone','shape'].includes(key))card[key]=structuredClone(op.value);
      if(key.startsWith('comment-'))card.comments.push({id:key,...op.value,clock:op.clock,actor:op.actor});
    }
    card.comments.sort((a,b)=>a.clock-b.clock||a.actor.localeCompare(b.actor));return [card];
  }).sort((a,b)=>a.id.localeCompare(b.id));
}
export function seedBoard(){
  const rows=[
    ['brief','document','A place to think together','We want Studio to feel like our company.\n\nA space where an idea can become a clear brief, with people, references and decisions in view.\n\nThis whiteboard is a free exploration: edit the content and organize it your way.',0,0,440,420,'cream'],
    ['question','note','What should happen first?','Enter my floor, find Emon and explain the idea in my own words.\n\nLet the space help make sense of the work.',500,0,320,340,'yellow'],
    ['experience','preview','From thought to decision','A proposal to explore together: inhabit the company, shape the mission and review a delivery with context.',880,0,470,440,'cream'],
    ['principles','document','What we want to preserve','01  The space has a purpose.\n\n02  People and their capabilities are recognizable.\n\n03  Every proposal makes clear what it needs from me.\n\n04  Work and its evidence remain accessible.',0,490,440,370,'cream'],
    ['decision','note','A decision to try','The content lives in HTML. We can edit a document, move a note and zoom into a detail without leaving the whiteboard.',500,390,320,310,'green'],
    ['try','document','Try it together','Open another tab from “Collaborate”.\n\nMove a card or edit a block: the other tab receives the changes. Comments stay attached to the card.\n\nA local test in the same browser. It does not yet connect people on other devices.',880,490,470,370,'cream']
  ];
  const seed=rows.map(([node,kind,title,body,x,y,w,h,tone])=>({node,field:'card',actor:'seed',clock:0,value:{kind,title,body,position:{x,y},size:{w,h},tone}}));
  seed.push({node:DEFAULT_TAB,field:'tab',actor:'seed',clock:0,value:{title:'Exploration',order:0}},{node:'tab-flow',field:'tab',actor:'seed',clock:0,value:{title:'Mission flow',order:1}});
  for(const [i,title] of ['An idea','Emon proposal','Your decision'].entries())seed.push({node:`flow-${i}`,field:'card',actor:'seed',clock:0,value:{kind:'shape',title,body:['Explain the intent in your own words.','Review the outcome, plan and team.','Approve or request a correction.'][i],position:{x:i*360,y:100},size:{w:270,h:180},tone:['yellow','cream','green'][i],tab:'tab-flow'}});
  for(let i=0;i<2;i++)seed.push({node:`flow-link-${i}`,field:'link',actor:'seed',clock:0,value:{from:`flow-${i}`,to:`flow-${i+1}`,tab:'tab-flow'}});
  for(const [i,[from,to]] of [['brief','question'],['question','experience'],['principles','decision'],['decision','try']].entries())seed.push({node:`seed-link-${i}`,field:'link',actor:'seed',clock:0,value:{from,to,tab:DEFAULT_TAB}});
  return seed;
}
export function zoomAt(camera,zoom,point){
  zoom=Math.min(2,Math.max(.2,zoom));const ratio=zoom/camera.zoom;
  return {zoom,x:point.x-(point.x-camera.x)*ratio,y:point.y-(point.y-camera.y)*ratio};
}
export function cardVisible(card,camera,width,height,padding=240){
  const x=card.position.x*camera.zoom+camera.x,y=card.position.y*camera.zoom+camera.y;
  return x+card.size.w*camera.zoom>-padding&&y+card.size.h*camera.zoom>-padding&&x<width+padding&&y<height+padding;
}

export function tabsFrom(records){
  return [...records].flatMap(([id,fields])=>fields.has('tab')?[{id,...fields.get('tab').value}]:[]).sort((a,b)=>a.order-b.order||a.id.localeCompare(b.id));
}
export function linksFrom(records,tab){
  const ids=new Set(cardsFrom(records,tab).map(c=>c.id));
  return [...records].flatMap(([id,fields])=>{const link=fields.get('link')?.value;return link&&link.tab===tab&&!fields.get('deleted')?.value&&ids.has(link.from)&&ids.has(link.to)?[{id,...link}]:[];});
}
export function connectionPath(from,to){
  const a={x:from.position.x+from.size.w/2,y:from.position.y+from.size.h/2},b={x:to.position.x+to.size.w/2,y:to.position.y+to.size.h/2};
  const horizontal=Math.abs(b.x-a.x)>=Math.abs(b.y-a.y),sign=horizontal?Math.sign(b.x-a.x)||1:Math.sign(b.y-a.y)||1;
  if(horizontal){a.x+=sign*from.size.w/2;b.x-=sign*to.size.w/2;}else{a.y+=sign*from.size.h/2;b.y-=sign*to.size.h/2;}
  const bend=Math.max(35,Math.abs(horizontal?b.x-a.x:b.y-a.y)/2)*sign;
  return horizontal?`M ${a.x} ${a.y} C ${a.x+bend} ${a.y}, ${b.x-bend} ${b.y}, ${b.x} ${b.y}`:`M ${a.x} ${a.y} C ${a.x} ${a.y+bend}, ${b.x} ${b.y-bend}, ${b.x} ${b.y}`;
}
