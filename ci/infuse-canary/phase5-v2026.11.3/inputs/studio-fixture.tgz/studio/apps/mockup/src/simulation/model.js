import { canManage } from './reference-catalog.js';
import {connectedTransition, canDecide, restoreConnected} from './connected.js';
import { emptyKnowledge, knowledgeTransition, restoreKnowledge } from './knowledge.js';
import { emptyFounderDesk, founderTransition, restoreFounderDesk } from './founder.js';
import { operationTransition, restoreOperations } from './operations.js';
import { currentMission, emptyMissionDesk, missionTransition, restoreMissionDesk } from './missions.js';
// Pure local-demo domain. The renderer never owns mission lifecycle state.
export const STORAGE_KEY = 'infuse.studio.spatial.v1';
import { FLOORS, PEOPLE, SKILLS, OBJECTS, CATALOG_REVISION, MODEL_PRESETS, DEFAULT_MODEL } from '../scenarios/catalog.js';
export { FLOORS, PEOPLE, SKILLS, OBJECTS } from '../scenarios/catalog.js';
import { allFloors, floorPeople, companyTransition, validateCompanyState, migrateCatalog } from './company.js';
export const SECTIONS = [
  {id:'intent',title:'The thought',tag:'01 / START HERE',question:'What kind of place do you want Studio to become?',suggestions:['A company I can inhabit, where people and work have a place.','A shared space where I can understand and shape the work.'],required:true},
  {id:'outcome',title:'The experience',tag:'02 / OUTCOME',question:'What should feel different after the first ten minutes?',suggestions:['I feel like I’m leading a company, and know what needs my judgment.','My rough idea has become a clear mission that I can explain.'],required:true},
  {id:'first',title:'The first useful moment',tag:'03 / FOCUS',question:'Where should the opening put its energy?',suggestions:['Enter the office and gather the squad at the whiteboard.','Bring a thought and watch the mission board take shape.'],required:true},
  {id:'constraints',title:'The boundaries',tag:'04 / KEEP IT SMALL',question:'What belongs in this first version, and what can wait?',suggestions:['One useful mission, three example floors, a readable board. Live execution can wait.','Prove shaping and review first. Leave freeform furniture editing and live agents for later.'],required:true},
  {id:'references',title:'What we know',tag:'05 / CONTEXT',question:'Which source or reference should the team keep close?',suggestions:['The Studio vision, product direction, and the approved INFUSE brand.'],required:false},
  {id:'evidence',title:'How we will know',tag:'06 / EVIDENCE',question:'What would convince you that this experience works?',suggestions:['I can shape, staff, inspect, correct, and resolve the mission without losing context.','I can enter the floor, explain what everyone is doing, and find my next decision.'],required:true}
];
export function initialState() {
  return { version:1, catalogRevision:CATALOG_REVISION, view:'building', floor:'studio', surface:null, selectedObject:null, peekPerson:null, projects:[], guests:[], floorDraft:null, missionDesk:emptyMissionDesk(), operationFloors:{}, founderDesk:emptyFounderDesk(), knowledge:emptyKnowledge(),
    settings:Object.fromEntries(FLOORS.map(f=>[f.id,{layout:'promenade',desk:'fixed'}])),
    cameras:{}, boardCamera:{x:0,y:0,zoom:1}, section:'intent', detail:null,
    mission:{ id:'studio-001', title:'Design Studio together', phase:'shaping', revision:1,
      content:{intent:'I want Studio to feel like a company I can inhabit — with my team, my initiatives, and a shared place to shape the work.',outcome:'',first:'',constraints:'',references:'',evidence:''},
      notes:{}, deferred:[], squad:['emon','kapiteky','tinus'], capabilities:Object.fromEntries(PEOPLE.filter(p=>p.id!=='fito').map(p=>[p.id,[...p.skills]])),
      model:DEFAULT_MODEL, effort:'Medium', size:'M', approvedRevision:null, step:0,
      artifact:null, sourceRevision:1, driftAcknowledged:false,
      annotation:{section:'experience',text:'',recorded:null}, accepted:false, history:[],
      summary:'The room is ready. Bring the thought to the whiteboard.' }, notice:null };
}
export function unresolved(state) {return SECTIONS.filter(s=>s.required&&!state.mission.content[s.id].trim());}
export function nextSection(state) {return SECTIONS.find(s=>!state.mission.content[s.id].trim()&&!state.mission.deferred.includes(s.id))?.id || 'paper';}
export function phaseLabel(state) {return {shaping:'Shaping the idea',squad:'Gathering the squad',ready:'Your approval needed',running:'Squad at work',review:'Your review needed',resolved:'Mission resolved'}[state.mission.phase];}
export function companionQuestion(state,section) {
  const c=state.mission.content;
  if(section==='first'&&c.outcome===SECTIONS[1].suggestions[0])return 'To feel like the company is yours, should we begin with the room or the shared thought?';
  if(section==='constraints'&&c.first===SECTIONS[2].suggestions[0])return 'What is the smallest office that makes gathering your team useful?';
  if(section==='constraints'&&c.first===SECTIONS[2].suggestions[1])return 'Which parts of shaping and review must work before we connect live agents?';
  if(section==='evidence'&&c.first===SECTIONS[2].suggestions[1]) return 'When the board forms around your thought, what must it help you understand?';
  return SECTIONS.find(s=>s.id===section)?.question || 'The mission is taking shape. Review the paper when you’re ready.';
}
export function planSteps(state) {
  const m=state.mission;
  return [
    {owner:'emon',title:'Shape the interaction contract',output:'A bounded mission and clear first scene',skill:'shaping'},
    ...m.squad.filter(id=>id!=='emon').flatMap(id=>m.capabilities[id].map(skill=>({owner:id,title:SKILLS[skill].title,output:SKILLS[skill].artifact,skill}))),
    {owner:'emon',title:'Assemble the design proposal',output:'One proposal, source references, and an owner decision',skill:'coordination'}
  ];
}
export function artifactSections(state) {
  const c=state.mission.content;
  return [
    {id:'experience',title:'A company you can inhabit',body:c.outcome||c.intent,detail:'Enter a cutaway building, choose an initiative floor, and find a team with recognizable responsibilities. A quiet office becomes active as you shape its work.'},
    {id:'opening',title:'The first ten minutes',body:c.first,detail:'You bring an unfinished thought to Emon Lusk at the whiteboard. Questions appear beside the section they shape. The paper, references, and decisions stay connected as you go deeper.'},
    {id:'scope',title:'A deliberately bounded first version',body:c.constraints,detail:'A shared office layout connects mission shaping, eight workstations, and review along one clear promenade. The shared board remains readable and operable by keyboard. All execution in this version is a local simulation.'},
    {id:'evidence',title:'A clear review moment',body:c.evidence,detail:'The review wall receives this proposal. An annotation belongs to a specific section, becomes explicit follow-up work, and remains visible in the resolution evidence.'}
  ];
}
function invalidate(m) {
  m.revision++;m.approvedRevision=null;m.phase='shaping';m.step=0;m.artifact=null;
  m.annotation={section:'experience',text:'',recorded:null};m.accepted=false;m.driftAcknowledged=false;
}
export function transition(state,event) {
  const connectedResult=connectedTransition(state,event);if(connectedResult!==null)return connectedResult;
  if(state.connectedEnabled&&!canDecide(state)&&event.type.startsWith('MISSION_')&&!['MISSION_LIST','MISSION_OPEN','MISSION_SELECT','MISSION_STEP','MISSION_SECTION'].includes(event.type))return state;
  if(state.connectedEnabled&&!canManage(state,currentMission(state))&&event.type.startsWith('MISSION_')&&!['MISSION_LIST','MISSION_OPEN','MISSION_SELECT','MISSION_STEP','MISSION_SECTION','MISSION_NEW','MISSION_DELIVERY_OPEN','MISSION_FOLLOWUP','MISSION_ADVANCE'].includes(event.type))return state;
  const knowledgeResult=knowledgeTransition(state,event);if(knowledgeResult!==null)return knowledgeResult;
  const founderResult=founderTransition(state,event);if(founderResult!==null)return founderResult;
  const operationResult=operationTransition(state,event);if(operationResult!==null)return operationResult;
  const missionResult=missionTransition(state,event);if(missionResult!==null)return missionResult;
  const companyResult=companyTransition(state,event);
  if(companyResult!==null)return companyResult;
  const s=structuredClone(state),m=s.mission;
  switch(event.type) {
    case 'ENTER_FLOOR':
      if(!allFloors(s).some(f=>f.id===event.id))return state;
      s.floor=event.id;s.view='floor';s.surface=null;s.selectedObject=null;s.peekPerson=null;return s;
    case 'BUILDING':s.view='building';s.surface=null;s.peekPerson=null;return s;
    case 'INSPECT_PERSON':
      if(s.view!=='floor'||s.surface||!floorPeople(s).some(p=>p.id===event.id))return state;
      s.peekPerson=event.id;s.selectedObject=event.id;return s;
    case 'DISMISS_PERSON':s.peekPerson=null;return s;
    case 'OPEN':
      if(!['board','squad','artifact','activity','contributions','people','skills','tools','settings','history','missions','mission-flow','project','library','floor-activity','operations','review-wall','delivery-review','founder-desk','my-screen','artifacts','knowledge-reader','lab','ideas','connected-output'].includes(event.surface))return state;
      s.surface=event.surface;s.peekPerson=null;s.selectedObject=event.object||event.surface;s.detail=event.person||null;return s;
    case 'CLOSE':s.surface=null;s.detail=null;return s;
    case 'SECTION':
      if(![...SECTIONS.map(x=>x.id),'paper','plan'].includes(event.id))return state;
      s.section=event.id;s.detail=null;return s;
    case 'DETAIL':s.detail=event.id;return s;
    case 'LAYOUT':
    case 'DESK':return state; // Retired customization actions cannot alter the shared floor.
    case 'CAMERA':s.cameras[event.key]={x:event.x,y:event.y,zoom:event.zoom};return s;
    case 'BOARD_CAMERA':s.boardCamera={x:event.x,y:event.y,zoom:event.zoom};return s;
    case 'EDIT':
      if(!SECTIONS.some(x=>x.id===event.id)||typeof event.value!=='string')return state;
      if(m.content[event.id]===event.value)return state;
      m.content[event.id]=event.value;invalidate(m);m.deferred=m.deferred.filter(x=>x!==event.id);
      m.summary=`Updated ${SECTIONS.find(x=>x.id===event.id).title.toLowerCase()}. The paper reflects your wording.`;return s;
    case 'NOTE':
      if(!SECTIONS.some(x=>x.id===event.id)||typeof event.value!=='string')return state;
      m.notes[event.id]=event.value;return s;
    case 'DEFER':
      if(!SECTIONS.some(x=>x.id===event.id&&!x.required))return state;
      if(!m.deferred.includes(event.id))m.deferred.push(event.id);
      m.summary='Reference gathering is deferred and remains visible in the paper.';s.section=nextSection(s);return s;
    case 'ANSWER':
      s.section=nextSection(s);m.summary='Your answer is on the board. Follow the next useful question.';return s;
    case 'APPROVE_PAPER':
      if(m.phase!=='shaping'||unresolved(s).length)return state;
      m.approvedRevision=m.revision;m.phase='squad';s.surface='squad';m.summary='The mission paper is approved. Gather the capabilities this work needs.';return s;
    case 'SQUAD':
      if(!['squad','ready'].includes(m.phase)||!PEOPLE.some(p=>p.id===event.id&&p.id!=='fito'&&!p.required))return state;
      m.squad=m.squad.includes(event.id)?m.squad.filter(id=>id!==event.id):[...m.squad,event.id];m.phase='squad';return s;
    case 'SKILL':
      if(!['squad','ready'].includes(m.phase)||!PEOPLE.find(p=>p.id===event.person)?.skills.includes(event.id)||event.person==='emon')return state;
      m.capabilities[event.person]=m.capabilities[event.person].includes(event.id)?m.capabilities[event.person].filter(x=>x!==event.id):[...m.capabilities[event.person],event.id];m.phase='squad';return s;
    case 'PRESET':
      if(!['shaping','squad','ready'].includes(m.phase))return state;
      if(event.key==='size'&&['S','M','L'].includes(event.value))m.size=event.value;
      if(event.key==='model'&&MODEL_PRESETS.includes(event.value))m.model=event.value;
      if(event.key==='effort'&&['Low','Medium','High'].includes(event.value))m.effort=event.value;
      return s;
    case 'CONFIRM_SQUAD':
      if(m.phase!=='squad'||m.squad.some(id=>!m.capabilities[id].length))return state;
      m.phase='ready';s.surface='activity';m.summary='The plan is ready. You decide when the demo starts.';return s;
    case 'LAUNCH':
      if(m.phase!=='ready'||m.approvedRevision!==m.revision)return state;
      m.phase='running';m.step=0;s.surface=null;m.summary='Emon Lusk gathered the squad. Advance the next named step when you’re ready.';return s;
    case 'ADVANCE': {
      if(m.phase!=='running')return state;
      const steps=planSteps(s);m.summary=`${PEOPLE.find(p=>p.id===steps[m.step].owner).name}: ${steps[m.step].output}.`;m.step++;
      if(m.step===steps.length){m.phase='review';m.artifact={id:'proposal-001',sourceId:'local-demo:studio-001/mission-paper',sourceRevision:m.sourceRevision,paperRevision:m.revision,generatedAt:event.at||new Date().toISOString(),generator:'studio-demo/0.2',sections:artifactSections(s)};m.summary='The design proposal is on the review wall. Your judgment is the next step.';}
      return s;
    }
    case 'SOURCE_UPDATE':
      if(m.phase!=='review'||!m.artifact||m.sourceRevision>m.artifact.sourceRevision)return state;
      m.sourceRevision++;m.driftAcknowledged=false;m.accepted=false;m.summary='A source update arrived. Inspect the drift before accepting this proposal.';return s;
    case 'ACK_DRIFT':
      if(m.phase!=='review'||m.sourceRevision===m.artifact?.sourceRevision)return state;
      m.driftAcknowledged=true;m.summary='Source drift recorded as a follow-up. The older proposal remains visible.';return s;
    case 'ANNOTATE':
      if(!['review','resolved'].includes(m.phase)||!m.artifact?.sections.some(x=>x.id===event.section)||typeof event.text!=='string')return state;
      m.annotation={section:event.section,text:event.text,recorded:null};m.accepted=false;m.phase='review';return s;
    case 'RECORD':
      if(m.phase!=='review'||!m.annotation.text.trim())return state;
      m.annotation.recorded={artifactId:m.artifact.id,section:m.annotation.section,text:m.annotation.text,owner:m.squad.includes('tinus')?'tinus':'emon',status:'Open follow-up'};
      m.summary='Your correction is recorded against the proposal. It stays open after demo resolution.';return s;
    case 'ACCEPT':
      if(m.phase!=='review')return state;
      m.accepted=Boolean(event.value);return s;
    case 'RESOLVE':
      if(m.phase!=='review'||!m.annotation.recorded||!m.accepted||(m.sourceRevision!==m.artifact.sourceRevision&&!m.driftAcknowledged))return state;
      m.phase='resolved';m.summary='Demo mission resolved with an accepted proposal and explicit open follow-ups.';return s;
    case 'REUSE': {
      if(m.phase!=='resolved')return state;
      const fresh=initialState();fresh.operationFloors=s.operationFloors;fresh.founderDesk=s.founderDesk;fresh.knowledge=s.knowledge;fresh.missionDesk=s.missionDesk;fresh.projects=s.projects;fresh.guests=s.guests;fresh.floorDraft=s.floorDraft;fresh.settings=s.settings;fresh.cameras=s.cameras;fresh.floor='studio';fresh.view='floor';fresh.surface='board';
      fresh.mission.history=[{title:m.title,markdown:missionMarkdown(s),resolvedAt:new Date().toISOString()},...m.history].slice(0,5);
      fresh.mission.content.intent='';fresh.mission.summary='The structure is ready for a fresh thought. Previous evidence remains in mission history.';return fresh;
    }
    case 'RESET':return initialState();
    default:return state;
  }
}
export function missionMarkdown(state) {
  const m=state.mission;
  return [`# ${m.title}`,'','> Local guided demo. No live agents or canonical-source changes.','',
    ...SECTIONS.flatMap(s=>[`## ${s.title}`,m.content[s.id]||(m.deferred.includes(s.id)?'Deferred — needs context.':'Unresolved.'),'']),
    ...Object.entries(m.notes).filter(([,v])=>v).flatMap(([id,v])=>[`### Note on ${SECTIONS.find(x=>x.id===id).title}`,v,'']),
    '## Plan',...planSteps(state).map(x=>`- ${PEOPLE.find(p=>p.id===x.owner).name}: ${x.title} → ${x.output}`),'',
    '## Decisions',`Paper revision: ${m.revision}. Approved revision: ${m.approvedRevision??'none'}.`,
    `Weight: ${m.size}. Demo model preset: ${m.model}. Reasoning: ${m.effort}.`,'',
    '## Source references','docs/PRODUCT_VISION.md · docs/PROJECT_BRIEF.md · approved INFUSE brand direction',
    ...(m.artifact?['', '## Projection provenance',`Source: ${m.artifact.sourceId}@${m.artifact.sourceRevision}. Current source: ${m.sourceRevision}.`, `Generated: ${m.artifact.generatedAt} by ${m.artifact.generator}.`, `Drift recorded: ${m.driftAcknowledged}.`]:[]),'',
    '## Review and correction',m.annotation.recorded?`Artifact: ${m.annotation.recorded.artifactId} / ${m.annotation.recorded.section}\n${m.annotation.recorded.text}\nDisposition: open follow-up; not yet implemented.`:'No correction recorded.',
    '', '## Resolution',`State: ${m.phase}. Owner accepted: ${m.accepted}.`,m.phase==='resolved'?'Known gap: the correction and any drift follow-up remain open. Live usefulness still needs owner evaluation.':m.summary,''].join('\n');
}
export function restoreState(raw) {
  if(!raw)return {state:initialState(),notice:null};
  try {
    const s=JSON.parse(raw),m=s.mission;
    const catalogUpdated=migrateCatalog(s);
    validateCompanyState(s);
    if(m&&!m.notes)m.notes={};
    if(!m||typeof m.notes!=='object'||m.notes===null||Array.isArray(m.notes)||!Object.entries(m.notes).every(([k,v])=>SECTIONS.some(x=>x.id===k)&&typeof v==='string'))throw Error('notes');
    if(s.version!==1||!m||!['shaping','squad','ready','running','review','resolved'].includes(m.phase)||!['building','floor'].includes(s.view)||!allFloors(s).some(f=>f.id===s.floor)||!s.settings||!s.cameras||!s.boardCamera)throw Error('shape');
    if(!SECTIONS.every(x=>typeof m.content?.[x.id]==='string')||!Array.isArray(m.squad)||!m.squad.includes('emon')||new Set(m.squad).size!==m.squad.length||m.squad.some(id=>!PEOPLE.some(p=>p.id===id&&id!=='fito')))throw Error('mission');
    if(!PEOPLE.filter(p=>p.id!=='fito').every(p=>Array.isArray(m.capabilities?.[p.id])&&m.capabilities[p.id].every(k=>p.skills.includes(k))))throw Error('capabilities');
    if(!Array.isArray(m.deferred)||m.deferred.some(id=>!SECTIONS.some(x=>x.id===id&&!x.required))||!Array.isArray(m.history)||!m.history.every(h=>typeof h.title==='string'&&typeof h.markdown==='string'&&typeof h.resolvedAt==='string'))throw Error('history');
    if(!Number.isInteger(m.revision)||m.revision<1||!Number.isInteger(m.sourceRevision)||m.sourceRevision<1||!Number.isInteger(m.step)||m.step<0||m.step>planSteps(s).length||typeof m.summary!=='string')throw Error('revision');
    if(!m.annotation||typeof m.annotation.text!=='string'||!['experience','opening','scope','evidence'].includes(m.annotation.section)||typeof m.accepted!=='boolean'||typeof m.driftAcknowledged!=='boolean')throw Error('review');
    if(m.annotation.recorded&&(!['experience','opening','scope','evidence'].includes(m.annotation.recorded.section)||m.annotation.recorded.section!==m.annotation.section||m.annotation.recorded.artifactId!==m.artifact?.id||!m.annotation.recorded.text?.trim()||typeof m.annotation.recorded.text!=='string'||m.annotation.recorded.text!==m.annotation.text))throw Error('recorded');
    if(!['S','M','L'].includes(m.size)||!MODEL_PRESETS.includes(m.model)||!['Low','Medium','High'].includes(m.effort))throw Error('preset');
    let officeUpdated=false;
    for(const f of allFloors(s)){
      const setting=s.settings[f.id];
      if(!setting||!['promenade','workshop','open','review'].includes(setting.layout)||!['fixed','window','team','quiet'].includes(setting.desk))throw Error('layout');
      if(setting.layout!=='promenade'||setting.desk!=='fixed')officeUpdated=true;
      s.settings[f.id]={layout:'promenade',desk:'fixed'};
    }
    for(const c of [...Object.values(s.cameras),s.boardCamera])if(!c||!['x','y','zoom'].every(k=>Number.isFinite(c[k]))||c.zoom<=0)throw Error('camera');
    if(['ready','running','review','resolved'].includes(m.phase)&&m.squad.some(id=>!m.capabilities[id].length))throw Error('empty capabilities');
    if(m.phase==='running'&&m.step>=planSteps(s).length)throw Error('event cursor');
    if(m.artifact&&(![m.artifact.id,m.artifact.sourceId,m.artifact.generatedAt,m.artifact.generator].every(x=>typeof x==='string')||!Number.isFinite(Date.parse(m.artifact.generatedAt))||m.artifact.sections?.length!==4||new Set(m.artifact.sections.map(x=>x.id)).size!==4||!Number.isInteger(m.artifact.paperRevision)||!Number.isInteger(m.artifact.sourceRevision)||!Array.isArray(m.artifact.sections)||!m.artifact.sections.every(x=>['experience','opening','scope','evidence'].includes(x.id)&&[x.title,x.body,x.detail].every(v=>typeof v==='string'))))throw Error('artifact');
    if(['review','resolved'].includes(m.phase)&&!m.artifact)throw Error('missing artifact');
    if(m.phase!=='shaping'&&(m.approvedRevision!==m.revision||unresolved(s).length))throw Error('approval');
    if(m.phase==='resolved'&&(!m.accepted||!m.annotation.recorded||(m.sourceRevision!==m.artifact.sourceRevision&&!m.driftAcknowledged)))throw Error('resolution');
    s.surface=null;s.detail=null;s.peekPerson=null;s.section=SECTIONS.some(x=>x.id===s.section)||['paper','plan'].includes(s.section)?s.section:'intent';
    const knowledgeRecovered=restoreKnowledge(s);
    const missionNotice=restoreMissionDesk(s);
    const connectedNotice=restoreConnected(s);
    const operationsRecovered=restoreOperations(s);
    const founderRecovered=restoreFounderDesk(s);
    return {state:s,notice:missionNotice||connectedNotice|| (knowledgeRecovered?'Saved Library links could not be read and were reset. Your missions and guest identities are preserved.':null)|| (founderRecovered?'Saved desk decisions could not be read and were reset. Your missions and operation checks are preserved.':null)|| (operationsRecovered?'Saved operation checks could not be read. The example checks were restored; your missions are preserved.':null)|| (officeUpdated?'Welcome to the project walkthrough. Every project now shares a larger office. Your projects, team and mission work are preserved.':catalogUpdated?'The demo roster and model options have been updated. Existing work is preserved; review the named model presets in your saved setup.':null)};
  } catch {return {state:initialState(),notice:'The saved demo could not be read. A fresh company is ready; no external work was changed.'};}
}
