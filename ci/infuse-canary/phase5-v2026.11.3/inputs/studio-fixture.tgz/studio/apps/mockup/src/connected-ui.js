export { missionInspection as executionView } from './mission-inspection.js';
import { pageHeader } from '@studio/ui/workspace';
import { partner, canManage } from './simulation/reference-catalog.js';
import { currentMission, createdMissions } from "./simulation/missions.js";
import { allFloors } from "./simulation/company.js";
import {
  connected,
  projectContext,
  canDecide,
} from "./simulation/connected.js";
import { knowledge } from "./knowledge-reader.js";
import { lab, ideas, esc } from "./connected-parts.js";
export const featureState = (s) => ({
  missions: createdMissions(s),
  ...connected(s),
  selectedMission: currentMission(s),
  projectContext: projectContext(s),
  floor:s.floor,
  manageable:canManage(s,currentMission(s)),
});
const button = (text, type, disabled = false, extra = "") =>
  `<button class="secondary" data-connected="${type}" ${disabled ? "disabled" : ""} ${extra}>${text}</button>`;
export function referenceBar(s, m = currentMission(s)) {
  return `<details class="mission-reference-drawer" data-preserve-details="mission-context"><summary><strong>Context & references</strong>${[m?.source,m?.candidate].filter(Boolean).length} selected · ${esc(m?.decisionOwner||partner(s))}${m?.origin==='MCP'?' · MCP draft':''}</summary><div class="connected-references"><strong>${esc(partner(s))} · Decision owner: ${esc(m?.decisionOwner||partner(s))}${!canManage(s,m)?" · view only; prepare your own mission from the board":""}</strong><strong>${m?.origin === "MCP" ? "MCP draft · saved without dispatch" : "MISSION CONTEXT"}</strong><span>${m?.source ? `${esc(m.source.title)} · r${m.source.revision}` : "No Knowledge source selected"}</span>${button("Knowledge ↗", "knowledge")}<span>${m?.candidate ? `Prototype candidate ${m.candidate.revision}` : "No prototype selected"}</span>${button("Prototype ↗", "lab")}${m?.importContext?`<details><summary>MCP draft provenance · ${esc(m.importContext.status)}</summary><p>${esc(m.importContext.partner)} / ${esc(m.importContext.client)} / ${esc(m.importContext.project)}</p><p>${esc(m.importContext.context)}</p><small>Receipt ${esc(m.importContext.receipt)} · imported r${m.importContext.importedRevision}</small>${m.importContext.pending?`<p>${esc(m.importContext.pending.intent)}</p>${button('Apply incoming draft','mcp-apply',!canManage(s,m))}${button('Prepare separate draft','mcp-fork')}`:''}</details>`:''}</div></details>`;
}
export function fixtures(s) {
  const c = connected(s),
    m = currentMission(s);
  return `<details class="connected-fixtures" data-preserve-details="connected-fixtures"><summary>Reference controls · deterministic local events</summary><div><button class="secondary" data-inspect="example">Open mission inspection example</button><label>Viewing as admitted partner<select data-connected-partner>${["Fito","Alex"].map(p=>`<option ${partner(s)===p?"selected":""}>${p}</option>`).join("")}</select></label><p>Both fixture partners can read shared projects and prepare work. The named paper owner approves and controls that mission.</p><label>Workspace state<select data-connected-mode>${["ready", "loading", "offline", "denied", "expired", "signed-out"].map((v) => `<option ${v === c.mode ? "selected" : ""}>${v}</option>`).join("")}</select></label>${button("Advance one work event", "advance", !canDecide(s) || !m?.execution || m.execution.state !== "running" || m.execution.held)}${button("Receive MCP draft", "mcp", !canDecide(s))}${m?.importContext?button("Receive changed MCP draft","mcp-update",!canDecide(s)):""}${button("New source revision", "source-update", !canDecide(s))}${button(c.sourceAvailable ? "Make source unavailable" : "Restore exact source", "source-toggle", !canDecide(s))}${button("New prototype candidate", "candidate-update", !canDecide(s))}${button(c.previewAvailable ? "Expire preview" : "Restore exact preview", "preview-toggle", !canDecide(s))}<small>No models, external writes or live execution.</small></div></details>`;
}
export function accessState(s) {
 const mode=connected(s).mode;
 if(!['denied','loading','expired','signed-out'].includes(mode))return null;
 const copy={denied:['Project access unavailable.','Your identity is known, but this project is unavailable. Project content is hidden.','Restore demo access'],loading:['Opening the workspace…','Checking the current project and your access.','Finish demo loading'],expired:['Your session expired.','Sign in again to continue. Your saved mission and pending requests stay attached to their original owner.','Sign in again · demo'],'signed-out':['Welcome to Studio.','Sign in to open your workspace and continue with your team.','Sign in to Studio · demo']}[mode];
 return `<section class="inspection-entry"><span class="ui-eyebrow">INFUSE / STUDIO</span><h1>${copy[0]}</h1><p>${copy[1]}</p><button class="primary" data-inspect="restore-access">${copy[2]}</button><small>Local identity preview. No identity provider is contacted.</small></section>`;
}
export function connectedSurface(s, view, icons, savedKnowledge="") {
  const current = s.surface,
    floor = allFloors(s).find((f) => f.id === s.floor);
  const labels = {
    "knowledge-reader": "Knowledge",
    lab: "Prototype",
    ideas: "Grilling",
  };
  const content =
    accessState(s) ||
    `<div class="connected-surface">${current === "knowledge-reader" ? knowledge({...featureState(s),projectTitle:floor.title}, view.kb, savedKnowledge) : current === "lab" ? lab(featureState(s), view.previewStep, view.candidateRevision, view.candidateId, view.deltas) : current === "ideas" ? ideas(featureState(s)) : ''}</div>`;
  return `${['knowledge-reader','lab'].includes(current)?'':pageHeader({eyebrow:floor.title,title:labels[current]})}${connected(s).notice ? `<div class="connected-notice" role="status">${esc(connected(s).notice)}</div>` : ""}${connected(s).mode === "offline" ? '<div class="connected-notice">Offline · last known state. Decisions are disabled.</div>' : ""}${content}${fixtures(s)}`;
}
