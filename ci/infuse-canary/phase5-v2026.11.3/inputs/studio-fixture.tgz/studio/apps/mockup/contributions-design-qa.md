# Activity UX exploration — 2026-10-23

Question: which structure makes it easiest to understand activity and inspect an
individual change: an overview, a daily journal, or a repository explorer?

This is a mock-data exploration in the existing Studio prototype. No production
calls, imported private records, live Git writes or publishing actions are used.
The user has not selected a direction yet.

## Production inspection

Visited `https://studio.infuse-ai.com/contributions?project=core` in the signed-in
production session. The screen returned “Contribution history is unavailable.
Previous private records are hidden.” Refresh, Reset filters and a fresh page
load retained that result. Populated production screens could not be verified;
this is not evidence of empty Git history. No production settings were changed.

The implemented source was read to establish the existing surface:
`apps/web/src/features/workspace/contributions.tsx` and `contribution-summary.tsx`.
It includes year/project/repository/author filters, an annual UTC calendar,
summary metrics, repository trends, day-level commit paging, commit metadata,
external commit links, and source coverage. The prototype uses that information
shape, not claimed live values.

## Run and compare

From this worktree, run:

```sh
npm run dev --workspace @studio/mockup -- --port 4418
```

Open `http://127.0.0.1:4418/?prototype=contributions&variant=overview&no3d`.
The existing Company sidebar also has an Activity entry in development.
The other shareable variants are `variant=journal` and `variant=repositories`.
Use the top switcher, its previous/next buttons, or Left/Right outside inputs.
Arrow keys on the calendar navigate days/weeks instead of switching layouts.

All three variants share deterministic 2025/2026 fixture history. Filters, selected
day, commit, source screen, scenario and variant are URL state and survive reload.
No fixture is inserted into the mission simulation or real application.

- **Activity overview:** summary, annual calendar, repositories, contributors,
  and recent changes. A day opens its exact filtered commit list.
- **Daily journal:** changes lead, grouped by day, with contributors and repository
  context alongside. Earlier days are progressively revealed.
- **Repository explorer:** repository navigation beside its history; opening a
  commit retains the underlying list in an inspector.
- **Commit inspector:** message, author, repository, full mock SHA, UTC author and
  committer dates, date fallback, import timestamp; Escape/Close returns focus.
- **Source coverage:** independent coverage view, including a historical gap.
- **Scenarios:** populated, coverage gap, empty, unavailable; mock retry restores
  the populated example without external effects.

## Intentional prototype differences

Monthly sparklines replace the production seven-day buckets. The journal and
repository drill-down are exploration affordances. Real commit links are explicitly
not connected, and the full mock metadata is visible rather than collapsed.
Author initials distinguish people in this exploration; they are not new identity
records. Counts describe activity, not value or quality. Coverage remains separate
from filtering. Future production adoption must preserve real identity, admission,
paging, date semantics and source status contracts.

## Naming

The prototype is labeled **Activity** in company navigation, its page title,
loading state and return actions. “Git activity” identifies its current scope.
Existing prototype URLs and internal surface IDs are retained so shared links
continue to work. The production Contributions tab is unchanged.

## Brand alignment

The palette was corrected against the local `infuse-ai-brand` repository at
`6a2e630`: `INFUSE_BRAND_APPROVED_DIRECTION.md`, `DESIGN_SYSTEM/tokens.css` and
`DESIGN_SYSTEM/INFUSE_TOKENS_v1.md`. Approved anchors are Foundry Black, INFUSE
Orange, IBM Plex and restrained modular geometry; detailed semantic and chart
ramps are documented candidates, not an assertion that the full system is approved.

Dark surfaces reuse the existing Studio theme tokens. Light surfaces use neutral
paper/white. Orange marks actions and selection, blue represents activity using
the documented chart palette, and green is reserved for success. Unknown coverage
is neutral. Arbitrary contributor and repository colors were removed.

The revised overview, journal, repository explorer and commit inspector were
visually checked in the browser, with an additional light-theme overview. Syntax
and whitespace checks passed after the brand correction.

## Verification

- Opened all three layouts and exercised repository, contributor, year and day
  filters; checked year/repository persistence on reload.
- Checked commit inspection, Escape/Close, focus return, and layout/calendar keys.
- Exercised all four scenarios, coverage inspection and return, and mock retry.
- Reviewed desktop and narrow layouts and the inspector with no horizontal
  overflow. The browser's requested 390px override reported an effective 520px
  viewport; 520px is the evidenced narrow width, not a claimed 390px proof.
- Reviewed light and dark themes; no browser error logs observed.
- Mock data checks: unique commit IDs and daily sums match totals for both years
  (1,621 / 1,283 commits).
- Mockup production build passed. The gated module, fixture strings and prototype
  styles are absent from `apps/mockup/dist`; no Activity prototype control is emitted
  by the production sidebar. No files in `apps/web` were modified.

The exploration proves that the same records can support three navigable layouts
without hiding commit or coverage details. Which feels best remains a human design
choice. It does not establish production data availability or user acceptance.
