# Local demo persistence

The existing session adapter remains in `app.js` and uses the versioned key exported by `simulation/model.js`. `whiteboard.js` owns its separate floor/page storage and local collaboration channel. Keep those keys and restoration rules stable when extracting further adapters. This local browser state is intentionally independent from real server persistence.
