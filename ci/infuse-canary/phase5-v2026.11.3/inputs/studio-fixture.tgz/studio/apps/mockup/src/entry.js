// One supported mockup: the company, office and established mission authoring flow.
import './app.js';

// Mockup-only workbench styling; real application styles remain separately owned.
import '@studio/ui/workspace.css';
import './workspace-theme.css';
import './workspace-surfaces.css';

import './knowledge-workspace.css';

import './mission-space.css';

import './agent-directory.css';
import './company-capabilities.css';

import './appearance.css';

import './workspace-backgrounds.css';

import './agent-showcase.css';
