import test from 'node:test';
import assert from 'node:assert/strict';
import {prototypeView,candidatesFor} from '../src/simulation/reference-catalog.js';
import {lab} from '../src/connected-parts.js';

test('Prototype opens the exact selected reference and browsing latest does not rewrite it',()=>{
 const selected={...candidatesFor('studio')[1],revision:1};
 assert.equal(prototypeView('studio',3,selected).candidate.id,selected.id);
 assert.equal(prototypeView('studio',3,selected).shownRevision,1);
 assert.equal(prototypeView('studio',3,selected,selected.id).shownRevision,3);
 assert.equal(prototypeView('studio',3,selected,selected.id,2).shownRevision,2);
 assert.equal(selected.revision,1);
});
test('Prototype defaults to the current project and rejects a different project reference',()=>{
 const own=candidatesFor('client')[0],foreign=candidatesFor('studio')[1];
 for(const selected of [null,{...foreign,revision:1}]) {
  const shown=prototypeView('client',4,selected);
  assert.equal(shown.candidate.id,own.id);
  assert.equal(shown.shownRevision,4);
 }
});
test('Prototype keeps optional review controls collapsed and unavailable previews cannot be adopted',()=>{
 const s={floor:'studio',candidateRevision:2,previewAvailable:true,mode:'ready',projectContext:{candidate:{...candidatesFor('studio')[1],revision:1}}};
 const html=lab(s);
 assert.match(html,/<details class="prototype-details" data-preserve-details="prototype-tools">/);
 assert.match(html,/A focused review desk/);
 assert.match(html,/Feedback on candidate 1/);
 assert.match(html,/View latest candidate/);
 assert.doesNotMatch(html,/Try the idea before|Lab tools|data-action="freeboard"/);
 const unavailable=lab({...s,previewAvailable:false});
 assert.match(unavailable,/Preview unavailable/);
 assert.match(unavailable,/data-connected="candidate" disabled/);
 assert.doesNotMatch(unavailable,/Find my first step/);
});
