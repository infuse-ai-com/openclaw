// Illustrative Git history only. No production records, identities or receipts.
export const authors=[
 {id:'fito',name:'Fito',kind:'Partner'},
 {id:'tinus',name:'Tinus Lordvals',kind:'Agent'},
 {id:'stewie',name:'Stewie Hobs',kind:'Agent'},
 {id:'satwa',name:'Satwa Nutella',kind:'Agent'},
 {id:'alex',name:'Alex',kind:'Partner'},
];
export const repositories=[
 {id:'studio',name:'studio',project:'Infuse AI',description:'The shared workspace for people, agents and missions.',branches:8},
 {id:'workbench',name:'workbench',project:'Infuse AI',description:'A dependable place for the team to build and verify.',branches:4},
 {id:'agent-skills',name:'agent-skills',project:'Infuse AI',description:'Working methods that improve with every project.',branches:3},
 {id:'finaxis',name:'finaxis-app',project:'Finaxis',description:'Research and decisions for a clearer financial picture.',branches:5},
 {id:'hauscraft',name:'hauscraft-web',project:'Hauscraft',description:'Helping clients find the right home for their ideas.',branches:2},
];
const messages={
 studio:['Make agent profiles easier to explore','Keep project selection when returning to the whiteboard','Add keyboard navigation to the mission board','Clarify the next step in mission review','Show source freshness beside token usage','Give the desk a calmer first impression'],
 workbench:['Restore the workspace after reconnecting','Improve startup feedback for the shared desktop','Keep preview links scoped to the project','Verify the browser handoff before opening a session'],
 'agent-skills':['Add a practical release verification guide','Explain when to use the mission shaping skill','Improve examples for reviewing evidence','Document the handoff from design to delivery'],
 finaxis:['Explain the assumptions behind the weekly summary','Add source dates to the research view','Improve the market comparison layout','Keep chart labels readable on small screens'],
 hauscraft:['Refine the project gallery on mobile','Make the client enquiry flow easier to follow','Add accessible labels to the image gallery','Improve the project brief introduction'],
};
export function makeHistory(year=2026){
 const output=[],end=year===2026?296:365;
 for(let day=0;day<end;day++){
  const at=Date.UTC(year,0,1+day),weekday=new Date(at).getUTCDay();
  const count=day<30?0:weekday===0?0:(day*13+7)%17===0?0:((day*7+3)%8)+(weekday===6?0:3);
  for(let index=0;index<count;index++){
   const seed=(day*31+index*17+year)%100;
   const repo=repositories[seed<44?0:seed<67?1:seed<82?2:seed<94?3:4],author=authors[seed<26?0:seed<64?1:seed<77?2:seed<92?3:4];
   const sha=((Math.imul(year*100000+day*20+index,2654435761)>>>0).toString(16).padStart(8,'0')+(day*20+index).toString(16).padStart(4,'0'));
   output.push({id:sha,sha:sha.padEnd(40,'a'),repo:repo.id,author:author.id,date:new Date(at).toISOString().slice(0,10),time:`${String(9+index%10).padStart(2,'0')}:${String((index*17+day)%60).padStart(2,'0')}`,message:messages[repo.id][(day+index)%messages[repo.id].length],body:'Refine the experience while preserving project context and existing behavior.\n\nChecked the main flow, keyboard navigation and a narrow viewport. This commit is an illustrative prototype record.',fallback:day%37===0&&index===0});
  }
 }
 return output.reverse();
}
export const histories={2026:makeHistory(2026),2025:makeHistory(2025)};
export function summarize(commits){
 const days=new Map(),weekdays=Array(7).fill(0);for(const c of commits){days.set(c.date,(days.get(c.date)||0)+1);weekdays[new Date(c.date+'T00:00:00Z').getUTCDay()]++;}
 let longest=0,run=0,last=0;for(const date of [...days.keys()].sort()){const at=Date.parse(date+'T00:00:00Z');run=at-last===86400000?run+1:1;longest=Math.max(longest,run);last=at;}
 return {total:commits.length,days,longest,busiest:commits.length?['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][weekdays.indexOf(Math.max(...weekdays))]:'—'};
}
