// Local presentation preference, deliberately separate from company/mission state.
export const THEME_KEY = 'studio.mockup.theme';
export const themePreference = value => ['light','dark','system'].includes(value) ? value : 'light';
export const resolveTheme = (preference, systemDark) => preference === 'system' ? (systemDark ? 'dark' : 'light') : themePreference(preference);
export function createAppearance({root=document.documentElement, media=matchMedia('(prefers-color-scheme: dark)'), storage=()=>localStorage, onChange=()=>{}}={}) {
 let preference='light';
 try { preference=themePreference(storage().getItem(THEME_KEY)); } catch { /* Storage is optional. */ }
 const apply=()=>{root.dataset.studioTheme=resolveTheme(preference,media.matches);root.style.colorScheme=root.dataset.studioTheme;};
 apply();
 media.addEventListener('change',()=>{if(preference==='system'){apply();onChange();}});
 return {preference:()=>preference,set(value){preference=themePreference(value);try{storage().setItem(THEME_KEY,preference);}catch{/* Keep the session usable. */}apply();onChange();}};
}
export const appearanceControls = preference => `<fieldset class="theme-options"><legend>Appearance</legend>${['light','dark','system'].map(mode=>`<button type="button" data-studio-theme="${mode}" aria-pressed="${mode===preference}">${mode[0].toUpperCase()+mode.slice(1)}</button>`).join('')}</fieldset>`;
