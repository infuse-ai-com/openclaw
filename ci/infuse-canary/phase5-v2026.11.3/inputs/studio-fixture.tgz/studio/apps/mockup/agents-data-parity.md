# Agents prototype: comparison with the real page

Compared against `apps/web/src/features/workspace/company.tsx`,
`agent-overview.tsx`, `agent-telemetry.tsx`, and `agent-schedules.tsx`, plus the
synthetic preview at `http://127.0.0.1:4422/agents?project=core`.

The partner explicitly requested populated mock data to judge the design. This
supersedes the previous disconnected presentation. The header labels Mock data;
the telemetry tab dates its fixed illustrative snapshot to 23 October 2026.
`agentDemo` owns these display fixtures; it never writes to simulation missions.

| Real page information | Prototype treatment |
| --- | --- |
| Name, role, portrait, introduction, strengths | Existing six authored identities and shared voxel geometry; 240 × 260 px portrait. |
| Working style and skills | Visible alongside the introduction; Most used skills shows illustrative 30-day usage and opens existing skill details. Supporting apps removed by partner request. |
| Runtime, model, seven-day tokens | Selected-agent summary and separate team-level operations view, with consistent telemetry drill-down. |
| Team attention and problem states | All/Needs attention filter, next actions and ages. Six examples: healthy, degraded, model mismatch, stale, paused and unconfigured. |
| Cross-project work, role, state, next action | Two assigned example missions and one proposed mission; visible progress, deliverables and decision/session examples. Existing saved simulation missions remain separately navigable. |
| Profile identity and project coverage | Two illustrative projects and explicitly demo-prefixed Gateway identities. |
| Runtime health, replicas, restarts, version, image | Shared operational fixtures plus visible details; retained observations and missing values explicitly labelled. |
| Configured versus observed model policy | Matching and mismatched model examples; stale and absent comparisons labelled. |
| Usage today/seven days, daily/four-hour/provider-model | Working selectors with consistent totals and labeled bars. Partial current-day buckets end at snapshot time. |
| Input/output/cache counters and coverage | Inspectable counters; cache reads/writes explicitly included in input, seven-day coverage. |
| Sessions/tasks, recent activity and 24-hour counters | Populated timeline, completed/running/waiting counts, failures and unclassified counts. |
| Scheduled tasks, enabled state, timing and results | Two example schedules with timezone, last/next run and completed results. No jobs execute. |
| Source status and freshness | Illustrative observed, generated, imported and collection timestamps. |

## Production integration boundary

The mockup remains a layout exploration with illustrative data. The approved
[real-app adoption](../../docs/plans/active/018-frontend-design-adoption/agents-spotlight.md)
now uses existing admitted project-work and telemetry reads. Authorization,
membership, persistence and execution enrollment retain their existing owners.
Skill rankings remain unavailable; role suggestions are not reported as usage.
The mock now covers several attention states; broader loading, source-error,
scaled-to-zero and incomplete-coverage variations remain to be explored.
Illustrative mission cards show their details inline; they never navigate to fabricated IDs.
