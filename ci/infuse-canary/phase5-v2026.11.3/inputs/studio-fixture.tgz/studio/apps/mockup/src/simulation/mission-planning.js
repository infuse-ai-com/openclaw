import { capability } from './company.js';

// Authored local planning companion. No language-model or execution service.
export const PLAN_EXAMPLES = [
  {id:'lean',legacyText:'Propón un equipo más pequeño para esta primera versión.',label:'Reduce the team',text:'Suggest a smaller team for this first version.'},
  {id:'review',legacyText:'Quiero revisar el diseño antes de empezar a construir.',label:'Review before building',text:'I want to review the design before building starts.'}
];
export const skillNames={shaping:'Define the brief',coordination:'Coordinate the team',grounding:'Company context',review:'Review evidence',prototype:'Build the prototype',browser:'Verify the flow',packaging:'Prepare the delivery',runtime:'Review infrastructure',design:'Design the experience',usability:'Review usability','client-brief':'Define client needs','client-updates':'Prepare client updates'};
export const contributions={emon:'Clarifies the brief and connects the deliverables.',stewie:'Designs the flow and reviews how it is used.',tinus:'Builds the prototype and verifies the flow.',kapiteky:'Checks decisions against the vision and evidence.',satwa:'Reviews the delivery and its technical requirements.',ramiro:'Connects the work to client needs.'};
const authored={
 emon:['Prepare the brief and coordinate delivery','A bounded brief, open decisions and connected deliverables.','Each step has an owner and supports the agreed outcome.'],
 stewie:['Design the mission flow','An interaction proposal covering the screens and their decisions.','The flow makes the outcome and next decision clear.'],
 tinus:['Build and test the prototype','A working prototype and evidence of the flow.','The flow works on desktop and narrow screens, and preserves work on reload.'],
 kapiteky:['Check the proposal and its evidence','Observations on assumptions and unverified points.','Each observation identifies a specific decision or piece of evidence.'],
 satwa:['Prepare a reproducible delivery','Startup instructions and outstanding requirements.','Another person can open and verify the same version.'],
 ramiro:['Align the delivery with expectations','A summary of the outcome, decisions and next steps for the client.','Expectations are documented; no real communications are sent.']
};
export const emptyPlanning=()=>({steps:null,notes:'',draft:'',branch:null,messages:[],pending:null});
export function defaultPlanningSteps(m){
 const order=['emon','stewie','tinus'];
 return [...m.squad].sort((a,b)=>(order.includes(a)?order.indexOf(a):3)-(order.includes(b)?order.indexOf(b):3)).map((owner,i)=>{
  let copy=authored[owner];
  if(!copy)copy=[m.config[owner].skills.map(k=>capability(k)?.title).join(' · ')||'Contribute expert judgment','An expert proposal based on the supplied context.','Conclusions distinguish sources, assumptions and limitations.'];
  if(m.scenario!=='studio-design'&&['stewie','tinus'].includes(owner))copy=owner==='stewie'?['Propose a solution for review','A proposal that addresses the mission outcome and scope.','Design decisions are checked against the agreed acceptance criteria.']:['Prepare and verify the first version','A bounded first version and evidence that it works.','The result meets the recorded acceptance criteria or states its limitations.'];
  return {id:`step-${i+1}`,owner,title:copy[0],output:copy[1],verification:copy[2]};
 });
}
export function ensurePlanning(m){m.planning??=emptyPlanning();if(m.status==='draft'&&m.planning.steps===null){m.planning.steps=defaultPlanningSteps(m);m.revision++;}}
export const planningSignature=m=>JSON.stringify({steps:m.planning?.steps,squad:m.squad,notes:m.planning?.notes,config:m.config});
export const planFeedbackCurrent=m=>Boolean(m.planning?.pending&&m.planning.pending.before===planningSignature(m));
export function planIssues(m){
 const p=m.planning;if(!p?.steps)return [];
 const issues=[];if(!p.steps.length)issues.push('Add at least one step to the plan.');
 p.steps.forEach((x,i)=>{if(!m.squad.includes(x.owner))issues.push(`Step ${i+1}: assign an owner.`);if(['title','output','verification'].some(k=>!x[k].trim()))issues.push(`Step ${i+1}: complete the task, deliverable and verification.`);});
 if(p.pending)issues.push('Review or discard the pending adjustment from Emon.');
 return issues;
}
function proposal(m,text,branch){
 const after={steps:structuredClone(m.planning.steps),squad:[...m.squad],notes:m.planning.notes};
 let summary;
 if(branch==='lean'){
  const specialist=after.squad.find(id=>id==='stewie')||after.squad.find(id=>id!=='emon');
  after.squad=['emon',...(specialist?[specialist]:[])];
  after.steps=after.steps.filter(x=>after.squad.includes(x.owner));
  summary='Team reduced to coordination and one specialist. Steps owned by removed members are removed too; check that the scope is still covered.';
 }else if(branch==='review'){
  const designer=after.steps.findIndex(x=>x.owner==='stewie');
  if(after.steps.length<24&&!after.steps.some(x=>x.id==='design-review'))after.steps.splice(designer>=0?designer+1:1,0,{id:'design-review',owner:'emon',title:'Prepare the design review with Fito',output:'Design and decisions presented to Fito for review before building.',verification:'Record the decision from Fito and the requested changes. The demo only illustrates this step.'});
  summary=after.steps.some(x=>x.id==='design-review')?'A review step after the design proposal and before building. Execution in this demo remains simulated.':'The plan has 24 steps. Remove one before adding a review.';
 }else{
  after.notes=[after.notes,`Feedback from Fito:\n${text}`].filter(Boolean).join('\n\n');
  summary='I saved your exact comment in the plan notes. You can edit the steps directly in this demo; free text is not interpreted.';
 }
 return {text,branch,before:planningSignature(m),after,summary};
}
export function planningTransition(m,e){
 const p=m.planning,step=p.steps.find(x=>x.id===e.id);
 const changed=()=>{m.revision++;m.summary='Plan saved. Review the steps and their owners before approving.';return true;};
 if(e.type==='MISSION_PLAN_EDIT'){
  if(!step||!['title','output','verification','owner'].includes(e.field)||typeof e.value!=='string'||e.value.length>2000||e.field==='owner'&&!m.squad.includes(e.value)||step[e.field]===e.value)return false;
  step[e.field]=e.value;return changed();
 }
 if(e.type==='MISSION_PLAN_NOTES'){if(typeof e.value!=='string'||e.value.length>8000)return false;p.notes=e.value;return changed();}
 if(e.type==='MISSION_PLAN_ADD'){
  if(p.steps.length>=24)return false;
  let n=1;while(p.steps.some(x=>x.id===`step-${n}`))n++;
  p.steps.push({id:`step-${n}`,owner:'emon',title:'',output:'',verification:''});return changed();
 }
 if(e.type==='MISSION_PLAN_REMOVE'){if(!step)return false;p.steps=p.steps.filter(x=>x!==step);return changed();}
 if(e.type==='MISSION_PLAN_MOVE'){
  const i=p.steps.indexOf(step),j=i+e.direction;if(i<0||![-1,1].includes(e.direction)||j<0||j>=p.steps.length)return false;
  [p.steps[i],p.steps[j]]=[p.steps[j],p.steps[i]];return changed();
 }
 if(e.type==='MISSION_PLAN_CHAT_DRAFT'){if(typeof e.text!=='string'||e.text.length>4000)return false;p.draft=e.text;p.branch=null;return true;}
 if(e.type==='MISSION_PLAN_CHAT_EXAMPLE'){const ex=PLAN_EXAMPLES.find(x=>x.id===e.id);if(!ex||p.pending)return false;p.draft=ex.text;p.branch=ex.id;return true;}
 if(e.type==='MISSION_PLAN_CHAT_SEND'||e.type==='MISSION_PLAN_CHAT_RETRY'){
  if(e.type==='MISSION_PLAN_CHAT_SEND'&&(!p.draft.trim()||p.pending)||e.type==='MISSION_PLAN_CHAT_RETRY'&&!p.pending)return false;
  const text=e.type==='MISSION_PLAN_CHAT_RETRY'?p.pending.text:p.draft,branch=e.type==='MISSION_PLAN_CHAT_RETRY'?p.pending.branch:p.branch;
  if(e.type==='MISSION_PLAN_CHAT_SEND')p.messages.push({role:'user',text});
  const next=proposal(m,text,branch);
  if(next.after.notes.length>8000){p.pending=null;p.messages.push({role:'emon',text:'Comment saved in the conversation. The notes have reached their limit; edit them to make room.'});}
  else{p.pending=next;p.messages.push({role:'emon',text:next.summary});}
  p.draft='';p.branch=null;return true;
 }
 if(e.type==='MISSION_PLAN_CHAT_DISCARD'){if(!p.pending)return false;p.pending=null;p.messages.push({role:'emon',text:'Adjustment discarded. The plan and team are unchanged.'});return true;}
 if(e.type==='MISSION_PLAN_CHAT_APPLY'){
  if(!planFeedbackCurrent(m))return false;
  const next=p.pending.after;p.steps=next.steps;p.notes=next.notes;m.squad=next.squad;p.pending=null;changed();
  p.messages.push({role:'emon',text:'Changes applied. Review the plan and team before continuing.'});return true;
 }
 return false;
}
export function validPlanning(m){
 const p=m.planning,text=(x,n=2000)=>typeof x==='string'&&x.length<=n;
 const steps=list=>Array.isArray(list)&&list.length<=24&&new Set(list.map(x=>x.id)).size===list.length&&list.every(x=>/^(step-\d+|design-review)$/.test(x.id)&&(x.owner===''||m.candidates.includes(x.owner))&&['title','output','verification'].every(k=>text(x[k])));
 if(!p||!(p.steps===null||steps(p.steps))||!text(p.notes,8000)||!text(p.draft,4000)||!(p.branch===null||PLAN_EXAMPLES.some(x=>x.id===p.branch&&(x.text===p.draft||x.legacyText===p.draft)))||!Array.isArray(p.messages)||p.messages.some(x=>!['user','emon'].includes(x.role)||!text(x.text,4000)))return false;
 if(p.pending){const x=p.pending;if(!text(x.text,4000)||!text(x.summary,4000)||!text(x.before,250000)||!(x.branch===null||PLAN_EXAMPLES.some(y=>y.id===x.branch&&(y.text===x.text||y.legacyText===x.text)))||!x.after||!steps(x.after.steps)||!text(x.after.notes,8000)||!Array.isArray(x.after.squad)||!x.after.squad.includes('emon')||new Set(x.after.squad).size!==x.after.squad.length||x.after.squad.some(id=>!m.candidates.includes(id))||x.after.steps.some(y=>y.owner&&!x.after.squad.includes(y.owner)))return false;}
 return true;
}
