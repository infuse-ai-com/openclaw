// Personal presentation only. Kept separate from mission and access state.
export const LOOK_KEY = 'studio.mockup.look.v1';
export const LOOK_OPTIONS = {
 shirt: [['Terracotta','#b95532'],['Sage','#72816a'],['Navy','#334e66'],['Ivory','#e7dfca'],['Plum','#70566c']],
 pants: [['Charcoal','#344246'],['Sand','#bba78a'],['Navy','#263c57']],
 shoes: [['Cream','#e7e4d9'],['Ink','#202d2c'],['Orange','#b95532']],
 skin: [['Light','#e9bd9e'],['Warm','#c99c7c'],['Brown','#956747'],['Deep','#5d3e30']],
 hair: [['Dark','#302820'],['Brown','#73503a'],['Blond','#c8ad72'],['Silver','#b8b4a9']],
 detail: [['None','plain'],['Headphones','headphones'],['Glasses','glasses'],['Cap','cap'],['Badge','badge']]
};
export const DEFAULT_LOOK=Object.freeze({shirt:'#b95532',pants:'#344246',shoes:'#e7e4d9',skin:'#c99c7c',hair:'#302820',detail:'plain'});
const memory=new Map();
export function normalizeLook(value){
 const result={...DEFAULT_LOOK};
 for(const key of Object.keys(result))if(LOOK_OPTIONS[key].some(([,v])=>v===value?.[key]))result[key]=value[key];
 return result;
}
export function readLook(owner,storage){
 if(memory.has(owner)&&storage===undefined)return {...memory.get(owner)};
 try{const source=storage===undefined?globalThis.localStorage:storage;return normalizeLook(JSON.parse(source?.getItem(LOOK_KEY)||'{}')?.[owner]);}catch{return {...DEFAULT_LOOK};}
}
export function saveLook(owner,look,storage){
 const next=normalizeLook(look);if(storage===undefined)memory.set(owner,next);
 try{const source=storage===undefined?globalThis.localStorage:storage;if(!source)throw Error('Unavailable');
 const parsed=JSON.parse(source.getItem(LOOK_KEY)||'{}');const all=parsed&&typeof parsed==='object'&&!Array.isArray(parsed)?parsed:{};
 source.setItem(LOOK_KEY,JSON.stringify({...all,[owner]:next}));return true;}catch{return false;}
}
export function characterLook(look){return Object.fromEntries(Object.entries(normalizeLook(look)).map(([key,value])=>[key,key==='detail'?value:Number.parseInt(value.slice(1),16)]));}
export function lookSummary(look){return ['shirt','pants','detail'].map(key=>LOOK_OPTIONS[key].find(([,v])=>v===look[key])?.[0]).filter(Boolean).join(' · ');}
