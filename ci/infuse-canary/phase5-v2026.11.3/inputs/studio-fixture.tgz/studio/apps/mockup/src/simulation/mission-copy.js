// Read compatibility for authored Spanish demo events. Never translate a user's
// mission content, plan, feedback, or approved snapshot during restoration.
export function englishEvent(event) {
  const titles={
    coordinator_prepared:['Emon recibe la versión aprobada','Emon receives the approved version'],
    mission_activated:['Emon activa la misión','Emon activates the mission'],
    task_verified:['Emon revisa la entrega','Emon reviews the delivery'],
    mission_completed:['Recorrido simulado completado','Simulated flow completed']
  };
  const details={
    coordinator_prepared:['Contexto preparado en esta simulación.','Context prepared in this simulation.'],
    mission_activated:['El plan ya puede convertirse en asignaciones simuladas.','The plan can now become simulated assignments.'],
    mission_completed:['Las entregas de ejemplo están revisadas. No se ha ejecutado trabajo real.','The example deliverables have been reviewed. No real work has been executed.']
  };
  const copy={...event},title=titles[event.type],detail=details[event.type];
  if(title&&copy.title===title[0])copy.title=title[1];
  if(detail&&copy.detail===detail[0])copy.detail=detail[1];
  if(event.type==='task_assigned')copy.title=copy.title.replace(/^Asignación a /u,'Assignment to ');
  if(event.type==='task_delivered')copy.title=copy.title.replace(/^Entrega de /u,'Delivery from ');
  if(event.type==='mission_approved'){
    if(copy.title==='Misión aprobada · preparando el inicio')copy.title='Mission approved · preparing to start';
    if(copy.title==='Misión aprobada · en espera')copy.title='Mission approved · on hold';
    copy.detail=copy.detail.replace(/^Revisión (\d+)\. Papel y equipo conservados\.$/u,'Revision $1. Paper and team preserved.');
  }
  return copy;
}


// Display compatibility for old authored fixtures; stored papers stay literal.
export function missionDisplayTitle(mission) {
  if(mission.scenario==='studio-design'&&mission.title==='Diseñar la creación de misiones')return 'Design mission creation';
  return mission.title;
}
export function englishMissionSummary(summary) {
  return summary==='Cambio guardado. Revisa las secciones que dependían de esta respuesta.'
    ? 'Change saved. Review the sections that depended on this answer.' : summary;
}
