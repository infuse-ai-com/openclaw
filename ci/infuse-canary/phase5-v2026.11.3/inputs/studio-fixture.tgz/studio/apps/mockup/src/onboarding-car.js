import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {createCarPropulsion} from './onboarding-propulsion.js';

// Stylised geometry based on the partner's supplied flying-coupe reference.
// The parent cinematic owns disposal of all geometry, materials and lights.
export function createWelcomeCar(parent){
 const group=new THREE.Group();parent.add(group);
 const paint=new THREE.MeshStandardMaterial({color:0xf4f6fa,metalness:.52,roughness:.22});
 const trim=new THREE.MeshStandardMaterial({color:0x283334,metalness:.65,roughness:.32});
 const rubber=new THREE.MeshStandardMaterial({color:0x171e20,roughness:.85});
 const hub=new THREE.MeshStandardMaterial({color:0xaebfc0,metalness:.8,roughness:.25});
 const glass=new THREE.MeshStandardMaterial({color:0x10282e,transparent:true,opacity:.43,metalness:.3,roughness:.13,side:THREE.DoubleSide,depthWrite:false});
 const white=new THREE.MeshBasicMaterial({color:0xe1faff}),red=new THREE.MeshBasicMaterial({color:0xff343e});
 function mesh(geometry,material,p=group){const m=new THREE.Mesh(geometry,material);m.castShadow=true;m.receiveShadow=true;p.add(m);return m;}
 function box(w,h,d,x,y,z,mat,p=group){const m=mesh(new RoundedBoxGeometry(w,h,d,4,Math.min(.16,w/3,h/3,d/3)),mat,p);m.position.set(x,y,z);return m;}
 // Loft a curved deck from smooth longitudinal sections, with rounded shoulders.
 function deck(sections){
  const curve=new THREE.CatmullRomCurve3(sections.map(([z,w,h])=>new THREE.Vector3(w,h,z))),vertices=[],indices=[];
  const rows=36,cols=32;
  for(let i=0;i<=rows;i++){
   const v=curve.getPoint(i/rows);
   for(let j=0;j<=cols;j++){
    const angle=j/cols*Math.PI*2,side=Math.sin(angle),top=Math.cos(angle);
    const x=v.x*Math.sign(side)*Math.pow(Math.abs(side),.55);
    const y=top>=0?v.y-.23+.23*Math.pow(top,.65):.64+.12*top;
    vertices.push(x,y,v.z);
   }
  }
  for(let i=0;i<rows;i++)for(let j=0;j<cols;j++){const a=i*(cols+1)+j,b=a+cols+1;indices.push(a,b,a+1,b,b+1,a+1);}
  for(const row of [0,rows]){const v=curve.getPoint(row/rows),center=vertices.length/3;vertices.push(0,(v.y+.52)/2,v.z);for(let j=0;j<cols;j++){const a=row*(cols+1)+j;indices.push(center,row===0?a:a+1,row===0?a+1:a);}}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals();mesh(geo,paint);
 }
 function pane(points,p=group,material=glass,bulge=.035){
  const vertices=[],indices=[],n=16;
  const corners=points.map(v=>new THREE.Vector3(...v));
  for(let i=0;i<=n;i++)for(let j=0;j<=n;j++){
   const u=j/n,v=i/n,pos=corners[0].clone().lerp(corners[1],u).lerp(corners[3].clone().lerp(corners[2],u),v);
   pos.y+=Math.sin(u*Math.PI)*Math.sin(v*Math.PI)*bulge;vertices.push(...pos);
  }
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){const a=i*(n+1)+j,b=a+n+1;indices.push(a,b,a+1,b,b+1,a+1);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals();return mesh(geo,material,p);
 }
 function bar(a,b,r,mat,p=group){const start=new THREE.Vector3(...a),end=new THREE.Vector3(...b),v=end.clone().sub(start);const m=mesh(new THREE.CylinderGeometry(r,r,v.length(),12),mat,p);m.position.copy(start.add(end).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),v.normalize());return m;}
 box(2.9,.24,6.5,0,.5,0,trim);
 deck([[-3.58,.35,.82],[-3.47,1.17,1.0],[-3.1,1.42,1.12],[-2.25,1.52,1.32],[-1.38,1.44,1.34]]);
 deck([[1.4,1.44,1.36],[2.15,1.53,1.35],[2.9,1.44,1.25],[3.4,1.24,1.16],[3.48,.4,.98]]);
 for(const x of [-1.45,1.45])box(.13,.28,2.8,x,.65,0,paint);
 // Hollow passenger compartment: one driver, one empty passenger seat.
 for(const x of [-.65,.65]){box(.74,.15,.75,x,.7,.15,trim);box(.74,.88,.19,x,1.02,.54,trim);}
 box(2.55,.22,.5,0,1.02,-1.24,trim);box(.5,.02,.25,.45,1.14,-1.18,white);
 const steering=mesh(new THREE.TorusGeometry(.24,.035,8,24),trim);steering.name='steering-wheel';steering.position.set(-.65,1.14,-.78);steering.rotation.x=-.35;
 // A gently crowned roof flows into the raked windshield and rear glass.
 pane([[-1.16,1.96,-.88],[1.16,1.96,-.88],[1.16,1.96,.92],[-1.16,1.96,.92]],group,paint,.14);
 pane([[-1.42,1.3,-1.6],[1.42,1.3,-1.6],[1.16,1.97,-.88],[-1.16,1.97,-.88]]);
 pane([[-1.16,1.97,.92],[1.16,1.97,.92],[1.42,1.35,1.75],[-1.42,1.35,1.75]]);
 for(const x of [-1,1]){bar([x*1.42,1.3,-1.6],[x*1.16,2,-.88],.045,paint);bar([x*1.16,2,.92],[x*1.42,1.35,1.75],.055,paint);}
 const doors=[];
 for(const side of [-1,1]){
  const door=new THREE.Group();door.position.set(side*1.47,.75,-1.35);group.add(door);doors.push(door);
  box(.16,.56,2.75,0,.27,1.37,paint,door);
  pane([[0,.54,0],[-side*.3,1.22,.48],[-side*.3,1.22,2.27],[0,.61,2.75]],door);
  box(.035,.05,.3,side*.065,.46,2.1,trim,door);
 }
 for(const x of [-1.51,1.51])for(const z of [-2.25,2.15]){
  const tyre=mesh(new THREE.CylinderGeometry(.64,.64,.28,64),rubber);tyre.rotation.z=Math.PI/2;tyre.position.set(x,.66,z);
  const disc=mesh(new THREE.CylinderGeometry(.51,.51,.30,64),hub);disc.rotation.z=Math.PI/2;disc.position.copy(tyre.position);
  const cap=mesh(new THREE.CylinderGeometry(.12,.12,.295,20),trim);cap.rotation.z=Math.PI/2;cap.position.copy(tyre.position);
 }
 for(const x of [-.93,.93]){const lamp=box(.64,.055,.08,x,1.03,-3.39,white);lamp.rotation.y=x<0?-.16:.16;}
 box(2.35,.065,.06,0,1.12,3.43,red);
 box(2.5,.16,.12,0,.68,3.45,trim);
 const propulsion=createCarPropulsion(group,parent);
 function seatDriver(character){
  // Explicit local transform: attach() may decompose PI yaw into X/Z flips.
  group.add(character.group);character.group.position.set(-.65,.23,-.25);
  character.group.rotation.set(0,Math.PI,0);character.group.scale.setScalar(.94);
  character.group.userData.seated=true;
  character.pose({seated:1,stride:0,walking:false,gesture:0,working:true});
 }
 return {group,seatDriver,thrust:propulsion.update,resetEffects:propulsion.reset,door(open){doors[0].rotation.y=-open*1.12;}};
}
