# Mockup test ownership

- Test the renderer or reducer currently used by the mockup. Before extending an
  old helper test, check its non-test callers; the Skills guide reader replaced
  the earlier capability glossary and its private filter helpers.
- Keep legacy restoration, simulated lifecycle and browser interaction contracts
  distinct. Shared wording is not evidence of duplicate coverage.
- For composed filters, use a known positive case and change one filter at a time
  for negative controls. Avoid copied full-catalog inventories unless the exact
  inventory is an independent product contract.
- An assertion about a local value unchanged since the previous assertion does
  not prove controller behavior. Invoke the owning transition or retain only the
  actual projection contract the test exercises.
