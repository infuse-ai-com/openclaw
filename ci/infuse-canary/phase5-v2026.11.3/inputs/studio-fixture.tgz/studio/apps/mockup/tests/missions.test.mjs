import {test} from 'node:test';
import assert from 'node:assert/strict';
import {initialState,transition as t,restoreState} from '../src/simulation/model.js';
import {currentMission as current,missionReady,createdMissionMarkdown,proposedMissionPlan} from '../src/simulation/missions.js';
import {floorPeople} from '../src/simulation/company.js';
import {personPresence,stationStatus} from '../src/simulation/presence.js';
const edit=(s,field,value)=>t(s,{type:'MISSION_EDIT',field,value});
function draft(s=initialState()){
 s=t(s,{type:'MISSION_NEW'});s=edit(s,'title','Mi encargo');s=edit(s,'intent','  Mi idea <original> & literal.\nSin resumen.  ');
 return t(s,{type:'MISSION_STEP',stage:'shape'});
}
function ready(s=draft()){
 for(const id of ['outcome','scope','evidence']){s=t(s,{type:'MISSION_SECTION',id});s=edit(s,id,`${id}: criterio propio`);s=t(s,{type:'MISSION_CONFIRM'});}
 for(const id of ['references','decisions']){s=t(s,{type:'MISSION_SECTION',id});s=t(s,{type:'MISSION_DEFER'});}
 return s;
}
function reload(s){const r=restoreState(JSON.stringify(s));assert.equal(r.notice,null);return r.state;}
test('review keeps a draft editable and confirms the exact version without leaving the screen',()=>{
 let s=t(draft(),{type:'MISSION_STEP',stage:'review'});
 const camera=structuredClone(s.cameras),paper=current(s).content;
 assert.equal(current(s).status,'draft');assert.equal(current(s).approved,null);
 assert.equal(t(s,{type:'MISSION_APPROVE',start:true}),s);
 for(const id of ['outcome','scope','evidence'])s=t(s,{type:'MISSION_CONFIRM',id,inline:true});
 assert.equal(current(s).stage,'review');assert(missionReady(current(s)));
 s=edit(s,'outcome','  Resultado <revisado> & exacto.\nCon evidencia.  ');
 assert.equal(current(s).stage,'review');assert(!missionReady(current(s)));
 for(const id of ['outcome','scope','evidence'])assert(!current(s).confirmed.includes(id));
 assert.equal(t(s,{type:'MISSION_APPROVE',start:false}),s);
 assert.equal(current(s).content.scope,paper.scope);
 for(const id of ['outcome','scope','evidence'])s=t(s,{type:'MISSION_CONFIRM',id,inline:true});
 s=reload(s);assert.equal(current(s).stage,'review');assert.deepEqual(s.cameras,camera);
 const reviewed=structuredClone(current(s));s=t(s,{type:'MISSION_APPROVE',start:false});
 assert.equal(current(s).approved.revision,reviewed.revision);
 assert.deepEqual(current(s).approved.content,reviewed.content);
 assert.deepEqual(current(s).approved.plan,proposedMissionPlan(s,reviewed));
 assert.equal(current(s).startup,'hold');assert.equal(current(s).cursor,0);
 assert(createdMissionMarkdown(s).includes(reviewed.content.outcome));
});
test('last feedback stays in review and cannot approve a pending or unconfirmed adjustment',()=>{
 let s=t(ready(),{type:'MISSION_STEP',stage:'review'});
 s=t(s,{type:'MISSION_CHAT_ANCHOR',anchor:'evidence'});
 const text='  Comprobar el recorrido con teclado <exacto>.  ';
 s=t(s,{type:'MISSION_CHAT_DRAFT',text});s=t(s,{type:'MISSION_CHAT_SEND'});
 assert.equal(current(s).stage,'review');assert(!missionReady(current(s)));
 assert.equal(t(s,{type:'MISSION_APPROVE',start:true}),s);
 s=t(s,{type:'MISSION_CHAT_APPLY'});assert.equal(current(s).stage,'review');
 assert(current(s).content.evidence.includes(text));assert(!missionReady(current(s)));
 s=t(s,{type:'MISSION_CONFIRM',id:'evidence',inline:true});assert(missionReady(current(s)));
 const saved=reload(s);assert(createdMissionMarkdown(saved).includes(text));
 assert.deepEqual(current(saved).shaping.messages,current(s).shaping.messages);
});
test('mission records isolate floors, selection, exact text, office camera and rejects the retired walkthrough',()=>{
 const original=initialState();let s=draft();const first=structuredClone(current(s));
 s=t(s,{type:'CAMERA',key:'studio',x:1,y:2,zoom:1.4});s=draft(s);s=edit(s,'intent','Second idea');const second=current(s).id;
 s=t(s,{type:'ENTER_FLOOR',id:'growth'});s=draft(s);const third=current(s).id;
 s=t(reload(s),{type:'ENTER_FLOOR',id:'studio'});assert.equal(current(s).id,second);
 s=t(s,{type:'MISSION_SELECT',id:first.id});assert.deepEqual(current(s),first);assert.equal(s.missionDesk.items.length,3);
 assert.deepEqual(s.cameras.studio,{x:1,y:2,zoom:1.4});assert.deepEqual(s.mission,original.mission);
 assert.equal(t(s,{type:'MISSION_SELECT',id:third}),s);assert.equal(t(s,{type:'MISSION_SELECT',id:'studio-001'}),s);
 assert.deepEqual(t(s,{type:'RESET'}),initialState());
});
test('literal authored answers reach paper/export, dependent decisions must be reconfirmed',()=>{
 let s=draft();const literal=current(s).content.intent;s=ready(s);assert(missionReady(current(s)));
 assert(createdMissionMarkdown(s).includes(literal));assert.deepEqual(current(s).deferred,['references','decisions']);
 s=edit(s,'intent','Changed idea');assert.equal(current(s).rawThought,literal);assert.equal(current(s).confirmed.length,0);
 s=t(s,{type:'MISSION_STEP',stage:'review'});assert(!missionReady(current(s)));assert.equal(t(s,{type:'MISSION_APPROVE',start:true}),s);
 s=t(s,{type:'MISSION_SECTION',id:'intent'});s=t(s,{type:'MISSION_CONFIRM'});s=ready(s);
 const authoredPlan=proposedMissionPlan(s);
 s=t(s,{type:'MISSION_CONFIG',person:'emon',key:'skill',value:'shaping'});assert.deepEqual(proposedMissionPlan(s),authoredPlan);assert(!current(s).config.emon.skills.includes('shaping'));s=t(s,{type:'MISSION_CONFIG',person:'emon',key:'skill',value:'coordination'});
 assert(!missionReady(current(s)));assert.equal(t(s,{type:'MISSION_APPROVE',start:false}),s);assert.equal(t(s,{type:'MISSION_SQUAD',id:'emon'}),s);
});
test('approval hold, preparation, activation and assignment have distinct presence and survive reload',()=>{
 let s=ready();s=t(s,{type:'MISSION_APPROVE',start:false});let m=current(s);
 assert.equal(m.status,'approved');assert.equal(m.startup,'hold');assert.equal(m.events.length,1);
 assert.equal(t(s,{type:'MISSION_ADVANCE'}),s);assert.notEqual(personPresence(s,'emon').tone,'working');assert.match(stationStatus(s,'operations'),/on hold/);
 s=reload(s);s=t(s,{type:'MISSION_START'});assert.equal(current(s).cursor,0);
 s=t(s,{type:'MISSION_ADVANCE'});assert.equal(current(s).status,'approved');assert.equal(current(s).cursor,1);s=reload(s);
 s=t(s,{type:'MISSION_ADVANCE'});assert.equal(current(s).status,'active');assert(!current(s).events.some(e=>e.type==='task_assigned'));assert.notEqual(personPresence(s,'emon').tone,'working');s=reload(s);
 s=t(s,{type:'MISSION_ADVANCE'});assert.equal(personPresence(s,'emon').tone,'working');assert.equal(personPresence(s,'tinus').label,'Awaiting assignment');
 let guard=0;while(current(s).status!=='completed'&&guard++<100)s=reload(t(s,{type:'MISSION_ADVANCE'}));
 m=current(s);assert.equal(m.status,'completed');assert.equal(m.events.filter(e=>e.type==='task_assigned').length,proposedMissionPlan(s).length);
 assert.equal(personPresence(s,'emon').tone,'done');assert.equal(t(s,{type:'MISSION_ADVANCE'}),s);
});
test('revising before startup keeps approved versions; active records only allow independent follow-up',()=>{
 let s=t(ready(),{type:'MISSION_APPROVE',start:false});const approved=structuredClone(current(s).approved);
 s=t(s,{type:'MISSION_REVISE'});s=edit(s,'title','Revisión del encargo');assert.deepEqual(current(s).approvals[0],approved);
 s=t(s,{type:'MISSION_APPROVE',start:true});assert.equal(current(s).approvals.length,2);s=reload(s);
 for(let i=0;i<2;i++)s=t(s,{type:'MISSION_ADVANCE'});const active=structuredClone(current(s));
 assert.equal(t(s,{type:'MISSION_REVISE'}),s);assert.equal(edit(s,'outcome','erase'),s);assert.equal(t(s,{type:'MISSION_SQUAD',id:'tinus'}),s);
 s=t(s,{type:'MISSION_FOLLOWUP'});assert.equal(s.missionDesk.items.length,2);assert.equal(current(s).parentId,active.id);assert.deepEqual(s.missionDesk.items[0],active);assert.equal(current(s).confirmed.length,0);reload(s);
});
test('project residents and guest research are inherited, mission presets do not reconfigure the floor',()=>{
 let s=initialState();s=t(s,{type:'FLOOR_BEGIN'});s=t(s,{type:'FLOOR_FIELD',key:'title',value:'Research'});s=t(s,{type:'FLOOR_FIELD',key:'description',value:'Specific project context'});
 s=t(s,{type:'FLOOR_RESIDENT',id:'emon'});s=t(s,{type:'GUEST_BEGIN'});
 for(const [key,value] of Object.entries({name:'Mira',role:'Research',traits:'Skeptical',brief:'  Evidence <A>\nUnverified.  ',sources:'Owner notes'}))s=t(s,{type:'GUEST_FIELD',key,value});
 s=t(s,{type:'GUEST_SAVE'});s=t(s,{type:'FLOOR_PRESET',person:'guest-1',key:'llm',value:'GPT-6 Astra'});s=t(s,{type:'FLOOR_SAVE'});
 const floor=structuredClone(s.projects[0]);s=draft(s);assert.equal(current(s).config['guest-1'].model,'GPT-6 Astra');assert(floorPeople(s).some(p=>p.id==='emon'));
 s=t(s,{type:'MISSION_SQUAD',id:'guest-1'});s=t(s,{type:'MISSION_CONFIG',person:'guest-1',key:'reasoning',value:'High'});
 assert(createdMissionMarkdown(s).includes('  Evidence <A>\nUnverified.  '));assert.deepEqual(s.projects[0],floor);
 s=draft(s);assert.equal(current(s).config['guest-1'].reasoning,'Medium');assert.deepEqual(s.projects[0],floor);reload(s);
});
test('legacy saves migrate, corrupt new missions recover independently and reject false execution evidence',()=>{
 const old=initialState();delete old.missionDesk;assert.deepEqual(reload(old).mission,old.mission);
 let s=t(ready(),{type:'MISSION_APPROVE',start:true});for(let i=0;i<3;i++)s=t(s,{type:'MISSION_ADVANCE'});
 for(const mutate of [m=>m.status='completed',m=>m.approved.title='different',m=>m.cursor=99,m=>m.events.at(-1).type='task_verified',m=>m.squad=[],m=>m.config.emon.model='invalid']){
  const invalid=structuredClone(s);mutate(current(invalid));const restored=restoreState(JSON.stringify(invalid));assert.match(restored.notice,/mission collection/);assert.deepEqual(restored.state.mission,s.mission);assert.deepEqual(restored.state.projects,s.projects);assert.equal(restored.state.missionDesk.items.length,0);
 }
});

test('board state follows approval and simulation evidence; sorting cannot change the lifecycle',async()=>{
 const {missionColumn,missionBoardCards,sortBoardCards}=await import('../src/mission-board.js');
 let s=draft();assert.equal(missionColumn(current(s)),'draft');
 s=ready(s);assert.equal(missionColumn(current(s)),'approval');
 s=t(s,{type:'MISSION_APPROVE',start:false});assert.equal(missionColumn(current(s)),'waiting');
 const first=structuredClone(current(s));
 s=t(s,{type:'MISSION_PRIORITY',id:first.id,priority:'high'});s=reload(s);
 assert.deepEqual(current(s),first);assert.equal(missionBoardCards(s)[0].priority,'high');
 assert.equal(missionBoardCards(s)[0].decision,true);
 s=t(s,{type:'MISSION_START'});s=t(s,{type:'MISSION_ADVANCE'});assert.equal(missionColumn(current(s)),'waiting');assert.equal(missionBoardCards(s)[0].decision,false);
 s=t(s,{type:'MISSION_ADVANCE'});assert.equal(missionColumn(current(s)),'active');
 while(current(s).status!=='completed')s=t(s,{type:'MISSION_ADVANCE'});
 assert.equal(missionColumn(current(s)),'review');
 s=draft(s);const second=current(s).id;s=t(s,{type:'MISSION_PRIORITY',id:second,priority:'low'});
 s=draft(s);s=t(s,{type:'MISSION_PRIORITY',id:current(s).id,priority:'high'});
 const cards=missionBoardCards(s);assert.deepEqual(sortBoardCards(cards).map(c=>c.priority),['high','high','low']);
 assert.equal(cards[1].id,second);assert.equal(t(s,{type:'MISSION_PRIORITY',id:second,priority:'urgent'}),s);
 s=t(s,{type:'ENTER_FLOOR',id:'growth'});assert.equal(missionBoardCards(s).length,0);
 assert.equal(t(s,{type:'MISSION_PRIORITY',id:second,priority:'high'}),s);
});
test('board examples never become saved missions and old saved collections gain priority metadata',async()=>{
 const {missionBoard,BOARD_EXAMPLES}=await import('../src/mission-board.js');
 const s=initialState(),snapshot=structuredClone(s);
 const markup=missionBoard(s,{mode:'examples'});assert(markup.includes('Studio example.'));
 assert.equal(BOARD_EXAMPLES.length,8);assert.deepEqual(s,snapshot);
 const old=draft();delete old.missionDesk.priorities;
 const restored=reload(old);assert.deepEqual(restored.missionDesk.priorities,{});assert.deepEqual(current(restored),current(old));
});

test('an optional name becomes an editable suggestion while authored names and original words survive',()=>{
 let s=t(initialState(),{type:'MISSION_NEW'});
 const words='  Mejorar la bienvenida de un proyecto.\nConservar estas palabras exactamente.  ';
 s=edit(s,'intent',words);s=t(s,{type:'MISSION_STEP',stage:'shape'});
 assert.equal(current(s).title,'Mejorar la bienvenida de un proyecto');
 assert.equal(current(s).origins.title,'suggestion');assert.equal(current(s).rawThought,words);
 s=reload(s);s=edit(s,'title','Nuestra forma de empezar');
 assert.equal(current(s).origins.title,'user');
 s=t(s,{type:'MISSION_STEP',stage:'idea'});s=t(s,{type:'MISSION_STEP',stage:'shape'});
 assert.equal(current(s).title,'Nuestra forma de empezar');assert.equal(current(s).content.intent,words);
 assert(createdMissionMarkdown(s).startsWith('# Nuestra forma de empezar'));
 s=t(initialState(),{type:'MISSION_NEW'});s=edit(s,'title','  Nombre propio & literal  ');
 s=t(s,{type:'MISSION_EXAMPLE'});assert.equal(current(s).title,'  Nombre propio & literal  ');
 s=t(s,{type:'MISSION_STEP',stage:'shape'});assert.equal(current(s).title,'  Nombre propio & literal  ');
 s=t(initialState(),{type:'MISSION_NEW'});s=t(s,{type:'MISSION_EXAMPLE'});
 assert.equal(current(s).title,'');s=t(s,{type:'MISSION_STEP',stage:'shape'});
 assert.equal(current(s).title,'Design mission creation');
});

test('Emon seeds a complete unconfirmed draft once, without replacing authored or deliberately cleared content',()=>{
 let s=t(initialState(),{type:'MISSION_NEW'});s=edit(s,'intent','  Mis palabras <exactas>  ');
 s=edit(s,'scope','Mi límite');s=t(s,{type:'MISSION_STEP',stage:'shape'});
 assert.equal(current(s).content.intent,'  Mis palabras <exactas>  ');assert.equal(current(s).content.scope,'Mi límite');
 for(const id of ['outcome','references','decisions','evidence']){assert(current(s).content[id]);assert.equal(current(s).origins[id],'suggestion');assert(!current(s).confirmed.includes(id));}
 assert(!missionReady(current(s)));s=edit(s,'outcome','');s=reload(s);s=t(s,{type:'MISSION_OPEN'});assert.equal(current(s).content.outcome,'');
 const old=draft();delete current(old).shaping;current(old).content.scope='Conservar el trabajo anterior';const resumed=t(reload(old),{type:'MISSION_OPEN'});
 assert.equal(current(resumed).content.scope,'Conservar el trabajo anterior');assert(current(resumed).shaping.seeded);
});
test('feedback keeps exact wording and anchor, previews changes, and refuses to overwrite newer edits',()=>{
 let s=ready();const before=structuredClone(current(s).content),text='  Primero <revisar> & después decidir.\nTexto literal.  ';
 s=t(s,{type:'MISSION_CHAT_ANCHOR',anchor:'scope'});s=t(s,{type:'MISSION_CHAT_DRAFT',text});s=t(s,{type:'MISSION_CHAT_SEND'});
 assert.deepEqual(current(s).content,before);assert.deepEqual(current(s).shaping.messages[0],{role:'user',text,anchor:'scope'});
 assert(!missionReady(current(s)));assert.equal(t(s,{type:'MISSION_APPROVE',start:true}),s);
 s=reload(s);s=edit(s,'scope','Una edición posterior');assert.equal(t(s,{type:'MISSION_CHAT_APPLY'}),s);
 s=t(s,{type:'MISSION_CHAT_RETRY'});s=t(s,{type:'MISSION_CHAT_APPLY'});
 assert.equal(current(s).content.scope,`Una edición posterior\n\nFeedback from Fito:\n${text}`);
 assert(!current(s).confirmed.includes('scope'));assert(!current(s).confirmed.includes('evidence'));
 assert(createdMissionMarkdown(s).includes(text));s=reload(s);assert.equal(current(s).shaping.pending,null);
});
test('authored chat branches are explicit, can be discarded, and never interpret edited free text',()=>{
 let s=draft();const original=structuredClone(current(s).content);
 s=t(s,{type:'MISSION_CHAT_EXAMPLE',id:'smaller'});s=t(s,{type:'MISSION_CHAT_SEND'});
 assert.deepEqual(current(s).shaping.pending.changes.map(x=>x.field),['scope','nonGoals']);
 s=t(s,{type:'MISSION_CHAT_DISCARD'});assert.deepEqual(current(s).content,original);
 s=t(s,{type:'MISSION_CHAT_EXAMPLE',id:'direct'});s=t(s,{type:'MISSION_CHAT_DRAFT',text:'Mi petición diferente'});s=t(s,{type:'MISSION_CHAT_SEND'});
 assert.equal(current(s).shaping.pending.branch,null);assert.deepEqual(current(s).shaping.pending.changes.map(x=>x.field),['decisions']);
 s=t(s,{type:'MISSION_CHAT_DISCARD'});s=ready(s);s=t(s,{type:'MISSION_APPROVE',start:false});
 assert.equal(t(s,{type:'MISSION_CHAT_DRAFT',text:'Cambiar trabajo aprobado'}),s);
});


test('editable ordered plans reach approval, export and simulation without changing on preset edits',()=>{
 let s=t(ready(),{type:'MISSION_STEP',stage:'squad'});const original=proposedMissionPlan(s);
 assert.deepEqual(original.map(p=>p.owner),['emon','stewie','tinus']);
 const id=original[1].id,text='  Diseñar <juntos> & revisar.  ';
 s=t(s,{type:'MISSION_PLAN_EDIT',id,field:'title',value:text});
 s=t(s,{type:'MISSION_PLAN_EDIT',id,field:'output',value:'Mis pantallas exactas'});
 s=t(s,{type:'MISSION_PLAN_MOVE',id,direction:-1});
 s=t(s,{type:'MISSION_CONFIG',person:'stewie',key:'model',value:'GPT-6 Astra'});
 assert.equal(proposedMissionPlan(s)[0].title,text);assert(createdMissionMarkdown(s).includes(text));
 s=reload(s);const plan=proposedMissionPlan(s);s=t(s,{type:'MISSION_APPROVE',start:true});
 assert.deepEqual(current(s).approved.plan,plan);s=reload(s);
 for(let i=0;i<3;i++)s=t(s,{type:'MISSION_ADVANCE'});
 assert.equal(current(s).events.at(-1).owner,'stewie');assert.equal(current(s).events.at(-1).detail,text);
 assert.equal(t(s,{type:'MISSION_PLAN_EDIT',id,field:'title',value:'Cambiar aprobado'}),s);
});
test('removing people preserves their work for reassignment and incomplete steps block approval',()=>{
 let s=t(ready(),{type:'MISSION_STEP',stage:'squad'});const tinus=proposedMissionPlan(s).find(x=>x.owner==='tinus');
 s=t(s,{type:'MISSION_SQUAD',id:'tinus'});assert.equal(proposedMissionPlan(s).find(x=>x.id===tinus.id).owner,'');
 assert(!missionReady(current(s)));assert.equal(t(s,{type:'MISSION_APPROVE',start:true}),s);
 s=reload(s);s=t(s,{type:'MISSION_PLAN_EDIT',id:tinus.id,field:'owner',value:'stewie'});assert(missionReady(current(s)));
 s=t(s,{type:'MISSION_PLAN_ADD'});const last=proposedMissionPlan(s).at(-1);assert(!missionReady(current(s)));
 s=t(s,{type:'MISSION_PLAN_REMOVE',id:last.id});assert(missionReady(current(s)));
 for(const p of proposedMissionPlan(s))s=t(s,{type:'MISSION_PLAN_REMOVE',id:p.id});assert(!missionReady(current(s)));
});
test('plan feedback previews atomic changes, guards stale edits and retains literal notes',()=>{
 let s=t(ready(),{type:'MISSION_STEP',stage:'squad'});const original=structuredClone(current(s).squad);
 s=t(s,{type:'MISSION_PLAN_CHAT_EXAMPLE',id:'lean'});s=t(s,{type:'MISSION_PLAN_CHAT_SEND'});
 assert.deepEqual(current(s).squad,original);assert(!missionReady(current(s)));s=reload(s);
 const id=proposedMissionPlan(s)[0].id;
 s=t(s,{type:'MISSION_PLAN_EDIT',id,field:'title',value:'Mi coordinación'});
 assert.equal(t(s,{type:'MISSION_PLAN_CHAT_APPLY'}),s);
 s=t(s,{type:'MISSION_PLAN_CHAT_RETRY'});s=t(s,{type:'MISSION_PLAN_CHAT_APPLY'});
 assert.deepEqual(current(s).squad,['emon','stewie']);assert.equal(proposedMissionPlan(s)[0].title,'Mi coordinación');
 const text='  Mi feedback <literal>.\nSin inventar una interpretación.  ';
 s=t(s,{type:'MISSION_PLAN_CHAT_DRAFT',text});s=t(s,{type:'MISSION_PLAN_CHAT_SEND'});
 assert.equal(current(s).planning.messages.findLast(x=>x.role==='user').text,text);
 assert(!current(s).planning.notes);s=t(s,{type:'MISSION_PLAN_CHAT_APPLY'});
 assert(current(s).planning.notes.includes(text));assert(createdMissionMarkdown(s).includes(text));s=reload(s);
 s=t(s,{type:'MISSION_APPROVE',start:false});assert(current(s).approved.planNotes.includes(text));reload(s);
});
test('review branch inserts a named planning step and old approved plans keep their existing evidence',()=>{
 let s=t(ready(),{type:'MISSION_STEP',stage:'squad'});
 s=t(s,{type:'MISSION_PLAN_CHAT_EXAMPLE',id:'review'});s=t(s,{type:'MISSION_PLAN_CHAT_SEND'});s=t(s,{type:'MISSION_PLAN_CHAT_APPLY'});
 assert.deepEqual(proposedMissionPlan(s).map(p=>p.owner),['emon','stewie','emon','tinus']);
 s=t(s,{type:'MISSION_PLAN_CHAT_EXAMPLE',id:'lean'});s=t(s,{type:'MISSION_PLAN_CHAT_SEND'});
 const plan=proposedMissionPlan(s);s=t(s,{type:'MISSION_PLAN_CHAT_DISCARD'});assert.deepEqual(proposedMissionPlan(s),plan);
 // Simulate a pre-editable-plan save and retain its approved plan/events verbatim.
 s=ready();delete current(s).planning;s=t(s,{type:'MISSION_APPROVE',start:true});
 for(let i=0;i<3;i++)s=t(s,{type:'MISSION_ADVANCE'});
 const approved=structuredClone(current(s).approved),events=structuredClone(current(s).events);
 s=reload(s);assert.deepEqual(current(s).approved,approved);assert.deepEqual(current(s).events,events);
 const bad=structuredClone(s);current(bad).planning.steps=[{id:'step-1',owner:'stranger',title:'x',output:'x',verification:'x'}];
 assert.match(restoreState(JSON.stringify(bad)).notice,/mission collection/);
});

test('English UI and exports preserve non-English owner content across every mission stage',async()=>{
 const {missionSurface}=await import('../src/mission-ui.js');
 let s=t(initialState(),{type:'MISSION_NEW'});
 assert.match(missionSurface(s),/Your idea, in your words/);
 assert.match(missionSurface(s),/Mission name/);
 assert(!missionSurface(s).includes('lang="es"'));
 const exact='  Quiero una misión con mis palabras: diseño, café y revisión.\nSin traducción.  ';
 s=edit(s,'intent',exact);
 for(const stage of ['shape','squad','review']){
  s=t(s,{type:'MISSION_STEP',stage});
  const markup=missionSurface(s);
  assert.match(markup,/Saved in this browser/);
  assert.match(markup,/Plan and team/);
  assert.match(markup,/The work/);
  assert.equal(current(s).content.intent,exact);
 }
 assert(createdMissionMarkdown(s).includes(exact));
 assert.match(createdMissionMarkdown(s),/## Team and configuration/);
 assert.equal(current(reload(s)).content.intent,exact);
});

test('Spanish authored feedback branches remain valid after English copy changes',async()=>{
 const {FEEDBACK_EXAMPLES}=await import('../src/scenarios/mission-companion.js');
 const {PLAN_EXAMPLES}=await import('../src/simulation/mission-planning.js');
 for(const option of FEEDBACK_EXAMPLES){
  let s=draft();Object.assign(current(s).shaping,{draft:option.legacyText,branch:option.id});
  s=reload(s);s=t(s,{type:'MISSION_CHAT_SEND'});s=reload(s);
  assert.equal(current(s).shaping.pending.text,option.legacyText);
  assert.equal(current(s).shaping.messages[0].text,option.legacyText);
 }
 for(const option of PLAN_EXAMPLES){
  let s=t(draft(),{type:'MISSION_STEP',stage:'squad'});Object.assign(current(s).planning,{draft:option.legacyText,branch:option.id});
  s=reload(s);s=t(s,{type:'MISSION_PLAN_CHAT_SEND'});s=reload(s);
  assert.equal(current(s).planning.pending.text,option.legacyText);
 }
});

test('Spanish simulation events reload without rewriting approvals or accepting false evidence',async()=>{
 const {englishEvent}=await import('../src/simulation/mission-copy.js');
 let s=t(ready(),{type:'MISSION_APPROVE',start:true});
 while(current(s).status!=='completed')s=t(s,{type:'MISSION_ADVANCE'});
 const titles={coordinator_prepared:'Emon recibe la versión aprobada',mission_activated:'Emon activa la misión',task_verified:'Emon revisa la entrega',mission_completed:'Recorrido simulado completado'};
 const details={coordinator_prepared:'Contexto preparado en esta simulación.',mission_activated:'El plan ya puede convertirse en asignaciones simuladas.',mission_completed:'Las entregas de ejemplo están revisadas. No se ha ejecutado trabajo real.'};
 for(const e of current(s).events){
  if(titles[e.type])e.title=titles[e.type];if(details[e.type])e.detail=details[e.type];
  if(e.type==='task_assigned')e.title=e.title.replace('Assignment to ','Asignación a ');
  if(e.type==='task_delivered')e.title=e.title.replace('Delivery from ','Entrega de ');
 }
 const old=structuredClone(current(s));s=reload(s);assert.deepEqual(current(s),old);
 assert.match(createdMissionMarkdown(s),/Emon activates the mission/);
 const task=old.events.find(e=>e.type==='task_delivered');assert.equal(englishEvent(task).detail,task.detail);
 current(s).events.find(e=>e.type==='task_verified').detail='Evidencia falsa';
 assert.match(restoreState(JSON.stringify(s)).notice,/mission collection/);
});


test('English floor copy projects old demo text without rewriting authored content or snapshots',async()=>{
 const {missionDisplayTitle,englishMissionSummary}=await import('../src/simulation/mission-copy.js');
 const old={scenario:'studio-design',origins:{title:'suggestion'},title:'Diseñar la creación de misiones',approved:{title:'Diseñar la creación de misiones'}};
 const before=structuredClone(old);
 assert.equal(missionDisplayTitle(old),'Design mission creation');
 assert.deepEqual(old,before);
 assert.equal(missionDisplayTitle({...old,scenario:'custom',origins:{title:'user'}}),old.title);
 assert.equal(missionDisplayTitle({...old,title:'Mi proyecto original'}),'Mi proyecto original');
 assert.equal(englishMissionSummary('Cambio guardado. Revisa las secciones que dependían de esta respuesta.'),'Change saved. Review the sections that depended on this answer.');
 assert.equal(englishMissionSummary('Mi texto literal'),'Mi texto literal');
});
