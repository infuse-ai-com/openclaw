import test from 'node:test';
import assert from 'node:assert/strict';
import {knowledgeDocuments,filterKnowledge,knowledgeReview,relatedDocuments,knowledgeReviewQueue} from '../src/knowledge-content.js';
import {knowledge} from '../src/knowledge-reader.js';

test('Knowledge lookup composes scope, type and full-text terms',()=>{
  const docs=knowledgeDocuments('studio');
  assert.deepEqual(filterKnowledge(docs,{query:'operational learning',type:'runbook'}).map(d=>d.id),['studio-runbooks']);
  assert.equal(filterKnowledge(docs,{query:'operational learning',repository:'studio-fixture'}).length,0);
  assert.equal(filterKnowledge(docs,{query:'not-a-document'}).length,0);
  assert.equal(filterKnowledge(docs,{query:'  '} ).length,6);
});
test('Knowledge demo corpus and authored relationships remain project isolated',()=>{
  const studio=knowledgeDocuments('studio'),client=knowledgeDocuments('client');
  assert.equal(client.some(d=>studio.some(a=>a.id===d.id||a.repo===d.repo)),false);
  for(const doc of client) for(const related of relatedDocuments(doc,client)) {
    assert.ok(client.includes(related));
    assert.ok(relatedDocuments(related,client).includes(doc));
  }
});
test('reviewing one exact fixture revision never attests a newer version',()=>{
  const doc=knowledgeDocuments('studio')[1];
  assert.equal(knowledgeReview(doc,1,{}),'never-reviewed');
  const ui={reviews:{[doc.id]:[1,3]}};
  assert.equal(knowledgeReview(doc,1,ui),'reviewed');
  assert.equal(knowledgeReview(doc,2,ui),'changed');
  assert.equal(knowledgeReview(doc,3,ui),'reviewed');
  assert.equal(knowledgeReview(doc,4,ui),'changed');
});
test('reader retains a selected revision while showing the latest, and disables unavailable source actions',()=>{
  const doc=knowledgeDocuments('studio')[0];
  const s={floor:'studio',sourceRevision:2,sourceAvailable:true,mode:'ready',preferences:{theme:'light',size:100,wide:false},projectContext:{source:{...doc,revision:1}}};
  const ui={screen:'reader',panel:'inspect',query:'',reviews:{}};
  const html=knowledge(s,ui);
  assert.match(html,/main · fixture r2/);
  assert.match(html,/Selected source · r1/);
  assert.match(html,/View selected source/);
  assert.match(html,/Changed since review/);
  const unavailable=knowledge({...s,sourceAvailable:false},ui);
  assert.match(unavailable,/Source unavailable/);
  assert.doesNotMatch(unavailable,/data-connected="source"/);
  assert.match(unavailable,/data-connected="kb-review-start" disabled/);
});

test('review desk prioritizes shared standards and excludes only exact reviewed versions',()=>{
  const docs=knowledgeDocuments('studio'), ui={reviews:{}};
  const queue={ids:knowledgeReviewQueue(docs,1,ui),revision:1};
  assert.equal(docs.find(d=>d.id===queue.ids[0]).type,'standard');
  assert.equal(queue.ids.length,4);
  ui.reviews[queue.ids[0]]=[1];
  assert.equal(knowledgeReviewQueue(docs,1,ui).length,3);
  assert.equal(knowledgeReviewQueue(docs,2,ui).length,6,'a new revision needs a fresh review');
  const s={floor:'studio',sourceRevision:2,sourceAvailable:true,mode:'ready',preferences:{theme:'light',size:100,wide:false},projectContext:{}};
  const html=knowledge(s,{...ui,screen:'reader',panel:'closed',documentId:queue.ids[0],revision:queue.revision,reviewQueue:queue});
  assert.match(html,/REVIEW DESK · 1 OF 4/);
  assert.match(html,/Local review recorded for r1/);
  assert.match(html,/data-step="-1" disabled/);
  assert.match(html,/View latest source/);
  assert.doesNotMatch(html,/data-connected="kb-review-start"/);
});
