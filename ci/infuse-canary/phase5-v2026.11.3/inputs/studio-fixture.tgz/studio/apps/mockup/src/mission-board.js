import {nextWork} from './simulation/connected.js';
import { allFloors, projectFloor } from './simulation/company.js';
import { createdMissions, missionPerson, missionReady, missionMissing, nextSimulationEvent } from './simulation/missions.js';

export const BOARD_COLUMNS = [
  {id:'draft', title:'Draft', hint:'Shaping the brief'},
  {id:'approval', title:'Awaiting approval', hint:'Your decision needed'},
  {id:'waiting', title:'On hold', hint:'Work paused or awaiting continuation'},
  {id:'active', title:'In progress', hint:'The team is working'},
  {id:'review', title:'Result review', hint:'Delivery needs your judgment'},
  {id:'completed', title:'Closed', hint:'Verified closeout or cancellation'}
];
export const BOARD_PRIORITIES = {high:'High',medium:'Medium',low:'Low'};
const rank = {high:0,medium:1,low:2};
const esc = value => String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
const avatar = id => `<span class="avatar avatar--${id.startsWith('guest-')?'guest':id}" aria-hidden="true"><i></i></span>`;

// Illustrative cards are presentation fixtures, never mission execution records.
export const BOARD_EXAMPLES = [
  {id:'example-01',column:'draft',priority:'medium',title:'A welcome for every project',outcome:'Define what the team needs to know when entering a floor.',next:'Clarify the outcome with Emon',team:['emon','ramiro'],detail:'The idea is captured. Decide which context is essential and how we will know the team is ready to start.'},
  {id:'example-02',column:'draft',priority:'high',title:'Turn an idea into a mission',outcome:'A simple start: share your idea and shape it with Emon.',next:'Choose the first interaction',team:['emon','stewie'],detail:'The open decision is how to start: a conversation at the whiteboard or an initial written idea. The scope is not yet approved.'},
  {id:'example-03',column:'approval',priority:'medium',title:'Prepare the first client visit',outcome:'A short tour explaining the project, the team and its deliverables.',next:'Approve the scope and team',team:['emon','ramiro','kapiteky'],detail:'The brief proposes a three-part tour: objective, proposal and next decision. Approval would authorize that scope; work has not started yet.'},
  {id:'example-04',column:'approval',priority:'high',title:'Design the mission board',outcome:'See at a glance what is moving forward and what needs your decision.',next:'Review the brief before starting',team:['emon','stewie','tinus'],detail:'Proposal: five status columns, priority within each and a next action per mission. Review validates the scope and participants; it does not accept a finished result.'},
  {id:'example-05',column:'waiting',priority:'medium',title:'Connect a real mission',outcome:'Bring an approved brief into Mission Control with traceability.',next:'Decide when to start',team:['emon','tinus','satwa'],detail:'An example of an approved mission on hold. There are no active assignments. Starting requires verifying the integration contract first.'},
  {id:'example-06',column:'active',priority:'high',title:'Bring the office to life',outcome:'Make the floor areas, people and work easy to understand.',next:'Stewie prepares the visual proposal',team:['emon','stewie'],detail:'This example shows Stewie working on the areas and interaction points. The next deliverable is a proposal for review; this card does not represent real activity.'},
  {id:'example-07',column:'active',priority:'medium',title:'Remember where we left off',outcome:'Resume the floor, mission and decisions when returning to Studio.',next:'Tinus verifies session recovery',team:['emon','tinus','satwa'],detail:'The planned delivery checks saving, reloading and session recovery. This illustrates the activity without running agents or producing evidence.'},
  {id:'example-08',column:'completed',priority:'low',title:'Define the Studio team',outcome:'Recognizable people, roles and capabilities across every floor.',next:'View the example result',team:['emon','kapiteky'],detail:'Example of a completed flow: a documented people and capabilities catalog. This is not real acceptance or evidence of executed work.'}
];

export function missionColumn(m) {
  if(m.execution)return ['closed','cancelled'].includes(m.execution.state)?'completed':m.execution.held?'waiting':m.execution.state==='closing'?'review':'active';
  if(m.status==='draft')return missionReady(m)?'approval':'draft';
  if(m.status==='approved')return 'waiting';
  return m.status==='completed'&&!m.delivery?.accepted?'review':m.status;
}
export function missionBoardCards(s) {
  return createdMissions(s).map(m=>{
    const column=missionColumn(m);
    const next=m.execution?nextWork(s,m):column==='draft'?`Define ${missionMissing(m)[0]?.title.toLowerCase()||(!m.title.trim()?'the name':'team capabilities')}`
      :column==='approval'?'Review and approve the brief'
      :column==='waiting'?(m.startup==='hold'?'Decide when to start':'Continue preparation')
      :column==='review'?'Inspect and judge the delivery'
      :column==='completed'?'Revisit accepted delivery'
      :nextSimulationEvent(s,m)?.title||'View activity';
    return {id:m.id,column,priority:s.missionDesk.priorities?.[m.id]||'medium',title:m.title||'Untitled idea',outcome:m.content.outcome||m.content.intent||'Tell Emon what you want to achieve.',next,decision:column==='approval'||column==='review'||m.status==='approved'&&m.startup==='hold',team:m.squad,revision:m.revision};
  });
}
export function sortBoardCards(cards) {
  return [...cards].sort((a,b)=>rank[a.priority]-rank[b.priority]);
}
const needsDecision = card => card.decision??['approval','waiting'].includes(card.column);
export function boardMode(s,view) {if(s.connectedEnabled)return view.mode||'mine';return view.mode||(!createdMissions(s).length&&s.floor==='studio'?'examples':'mine');}
function cardMarkup(s,c,example) {
  const priority=`<label class="mb-priority" data-priority="${c.priority}"><span class="sr-only">Priority for ${esc(c.title)}</span><select aria-label="Priority for ${esc(c.title)}" data-board-priority="${c.id}" ${example?'data-example-priority':''}>${Object.entries(BOARD_PRIORITIES).map(([id,label])=>`<option value="${id}" ${c.priority===id?'selected':''}>${label}</option>`).join('')}</select></label>`;
  const content=`<h3>${esc(c.title)}</h3><p>${esc(c.outcome)}</p>`;
  const action=`<div class="mb-next"><span>${needsDecision(c)?'YOUR NEXT DECISION':'NEXT STEP'}</span><p>${esc(c.next)}</p></div>`;
  const names=c.team.map(id=>missionPerson(s,id)?.name||id);
  return `<article class="mb-card" data-card-id="${c.id}"><div class="mb-card-top">${priority}<span>${example?'EXAMPLE':`r${c.revision}`}</span></div>${example?`<details class="mb-example-detail"><summary>${content}${action}<span class="mb-card-link">View example context <span aria-hidden="true">↗</span></span></summary><div class="mb-example-copy"><strong>About this mission</strong><p>${esc(c.detail)}</p></div></details>`:`<button class="mb-open" data-mission-select="${c.id}">${content}${action}<span class="mb-card-link">Open mission <span aria-hidden="true">↗</span></span></button>`}<div class="mb-card-team"><span class="mf-mini-team" role="img" aria-label="Team: ${esc(names.join(', '))}" title="${esc(names.join(', '))}">${c.team.slice(0,3).map(avatar).join('')}</span><span>${c.team.length} people</span></div></article>`;
}
export function missionBoard(s,view={}) {
  const floor=allFloors(s).find(f=>f.id===s.floor),history=Boolean(view.history),example=!history&&boardMode(s,view)==='examples';
  const columns=history?BOARD_COLUMNS.filter(c=>c.id==='completed'):BOARD_COLUMNS;
  const cards=example?BOARD_EXAMPLES.map(c=>({...c,priority:view.examplePriorities?.[c.id]||c.priority})):missionBoardCards(s).filter(c=>!history||c.column==='completed');
  const filter=history&&view.filter==='decision'?'all':view.filter||'all';
  const visible=sortBoardCards(cards.filter(c=>filter==='high'?c.priority==='high':filter==='decision'?needsDecision(c):true));
  const pending=cards.filter(needsDecision).length;
  return `<div class="mf-scroll mb-page"><div class="mb-heading"><div><span class="eyebrow">${esc(floor.title).toUpperCase()} / MISSIONS</span><h1>Missions</h1><p>${history?'Revisit closed missions and their original evidence.':'Shape the work. See what needs you.'}</p></div><button class="primary" data-action="mission-new">Start grilling →</button></div>
    <div class="mb-overview"><div><strong>${cards.length}</strong><span>${history?'closed missions':example?'example missions':'missions'}</span></div>${history?'':`<div><strong>${pending}</strong><span>need your decision</span></div><div><strong>${cards.filter(c=>c.column==='active').length}</strong><span>in progress</span></div>`}<details class="mb-project"><summary>Floor context</summary><p>${esc(floor.description)}</p>${projectFloor(s)?'<button class="quiet-button" data-action="floor-edit">Edit project and team</button>':''}</details></div>
    <div class="mb-toolbar">${history?'':`<div class="mb-layout-tabs" role="group" aria-label="Mission layout">${[['board','Board'],['list','List']].map(([id,label])=>`<button data-board-layout="${id}" aria-pressed="${(history?'list':view.layout||'board')===id}">${label}</button>`).join('')}</div>`}<div class="mb-filters" role="group" aria-label="Filter missions">${[['all','All'],['high','High priority'],['decision','Need my decision']].filter(([id])=>!history||id!=='decision').map(([id,label])=>`<button data-board-filter="${id}" aria-pressed="${filter===id}">${label}</button>`).join('')}</div>${history?'':`<div class="mb-mode" role="group" aria-label="Board content"><button data-board-mode="mine" aria-pressed="${!example}">My missions</button><button data-board-mode="examples" aria-pressed="${example}">View example</button></div>`}</div>
    <div class="mb-caption"><p>${history?'Closed and cancelled missions remain inspectable with their approved scope and evidence.':example?'<strong>Studio example.</strong> Illustrative data to explore the board. Your saved missions are preserved.':'Open a mission to continue. Its status changes as you move through the flow.'}</p><span>High priority first</span></div>
    <nav class="mb-column-jumps" aria-label="Jump to a status">${columns.map(c=>`<button data-board-column="${c.id}">${c.title} <span>${visible.filter(item=>item.column===c.id).length}</span></button>`).join('')}</nav>
    <div class="mb-board" data-layout="${history||view.layout==='list'?'list':'board'}" role="region" aria-label="Mission board by status" tabindex="0">${columns.map(column=>{
      const items=visible.filter(c=>c.column===column.id);
      return `<section class="mb-column mb-column--${column.id}" aria-labelledby="column-${column.id}" data-column="${column.id}"><header><div><span class="mb-state-dot" aria-hidden="true"></span><h2 id="column-${column.id}">${column.title}</h2><span class="mb-count">${items.length}</span></div><p>${column.hint}</p></header><div class="mb-cards">${items.map(c=>cardMarkup(s,c,example)).join('')||`<div class="mb-column-empty"><p>${filter==='all'?(history?'No closed missions yet.':'No missions in this status.'):'No matches for this filter.'}</p>${column.id==='draft'&&filter==='all'&&!example?'<button data-action="mission-new">Start grilling →</button>':''}</div>`}</div></section>`;
    }).join('')}</div><div class="mb-bottom"><p>${visible.length} of ${cards.length} missions · Change priority on each card.</p></div>${history&&s.floor==='studio'&&s.mission.history.length?`<section class="history-content"><h2>Archived mission evidence</h2><p>Read-only records retained from earlier work.</p>${s.mission.history.map((h,i)=>`<article><h3>${esc(h.title)}</h3><button class="secondary" data-history-download="${i}">Download archived evidence ↓</button></article>`).join('')}</section>`:''}</div>`;
}
