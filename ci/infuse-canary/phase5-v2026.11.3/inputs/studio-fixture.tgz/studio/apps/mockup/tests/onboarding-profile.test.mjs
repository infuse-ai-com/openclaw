import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_LOOK,LOOK_KEY,readLook,saveLook,characterLook} from '../src/onboarding-profile.js';

function store(seed='{}'){let value=seed;return {getItem:key=>key===LOOK_KEY?value:null,setItem(key,next){assert.equal(key,LOOK_KEY);value=next;}};}
test('saving one demo partner preserves the other partner and survives a fresh read',()=>{
 const storage=store();
 assert.equal(saveLook('Fito',{...DEFAULT_LOOK,shirt:'#72816a',detail:'headphones'},storage),true);
 assert.equal(saveLook('Alex',{...DEFAULT_LOOK,shirt:'#334e66',skin:'#5d3e30'},storage),true);
 assert.equal(readLook('Fito',storage).shirt,'#72816a');
 assert.equal(readLook('Fito',storage).detail,'headphones');
 assert.equal(readLook('Alex',storage).shirt,'#334e66');
 assert.equal(characterLook(readLook('Alex',storage)).skin,0x5d3e30);
});
test('malformed and out-of-catalog persisted choices recover to safe usable defaults',()=>{
 assert.deepEqual(readLook('Fito',store('not-json')),DEFAULT_LOOK);
 const storage=store(JSON.stringify({Fito:{shirt:'<img onerror=x>',detail:'unknown',skin:'#5d3e30'}}));
 assert.equal(readLook('Fito',storage).shirt,DEFAULT_LOOK.shirt);
 assert.equal(readLook('Fito',storage).detail,'plain');
 assert.equal(readLook('Fito',storage).skin,'#5d3e30');
});
test('unavailable storage reports that the look was not durably saved',()=>{
 const storage={getItem(){throw Error('Storage blocked');},setItem(){throw Error('Storage blocked');}};
 assert.deepEqual(readLook('Fito',storage),DEFAULT_LOOK);
 assert.equal(saveLook('Fito',{...DEFAULT_LOOK,shirt:'#72816a'},storage),false);
});
