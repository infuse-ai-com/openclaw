// Read-only projections. The mission remains the sole owner of execution/evidence.
export function workStatus(m) {
 const x=m.execution;
 if(!x)return null;
 if(x.state==='closed')return {status:'history',label:'Closed by Emon',recommendation:'Inspect verified results or prepare independent follow-up work.'};
 if(x.state==='cancelled')return {status:'history',label:'Cancelled',recommendation:'Inspect retained evidence; cancellation does not verify unfinished work.'};
 if(x.held)return {status:'attention',label:'On hold',recommendation:'Resume the same assignments when the project owner is ready.'};
 if(x.state==='closing')return {status:'attention',label:'Required human gate',recommendation:'The named owner must acknowledge the explicit closeout gate.'};
 return {status:'motion',label:x.tasks.some(t=>t.state==='delivered')?'Emon reviewing exact evidence':'Mission in motion',recommendation:'Inspect task progress, conversations and exact evidence.'};
}
export const workEvidence=m=>m.execution?.tasks.flatMap(t=>t.evidence.map(e=>({...e,taskId:t.id,taskTitle:t.title,session:t.session})))||[];
export const learningProposals=s=>(s.connected?.learning||[]).filter(e=>e.project===s.floor).map(e=>({...e,id:`proposal-${e.missionId}`,floorId:e.project,kind:'learning',title:`Learning proposal · ${s.missionDesk.items.find(m=>m.id===e.missionId)?.title||e.missionId}`,body:e.text,reference:e.destination||'Project repository / docs/runbooks (source owner review pending)',revision:1,review:'proposed',origin:null}));
