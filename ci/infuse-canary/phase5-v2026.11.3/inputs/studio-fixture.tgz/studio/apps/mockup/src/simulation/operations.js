// Authored scheduling demo. No timers, network requests or cron execution.
export const DEMO_CLOCK = '2026-10-02T07:40:00.000Z';
export const OPERATIONS_TIMEZONE = 'Europe/Madrid';
export const CHECK_CATEGORIES={infrastructure:'Infrastructure',mission:'Mission health',knowledge:'Knowledge'};
export const checkCategory=job=>job.category??(job.owner==='emon'?'mission':job.owner==='tinus'?'knowledge':'infrastructure');
export const CHECK_OWNERS = {satwa:'Satwa Nutella',tinus:'Tinus Lordvals',emon:'Emon Lusk'};
export const CHECK_SCHEDULES = {
  five:{label:'Every 5 minutes',cron:'*/5 * * * *',next:'2026-10-02T07:45:00.000Z'},
  fifteen:{label:'Every 15 minutes',cron:'*/15 * * * *',next:'2026-10-02T07:45:00.000Z'},
  hourly:{label:'Every hour',cron:'0 * * * *',next:'2026-10-02T08:00:00.000Z'},
  daily:{label:'Every day at 06:00',cron:'0 6 * * *',next:'2026-10-03T04:00:00.000Z'},
  weekly:{label:'Mondays at 09:00',cron:'0 9 * * 1',next:'2026-10-05T07:00:00.000Z'},
};
const run=(id,status,at,summary)=>({id,status,at,summary,trigger:'Scheduled example'});
export function exampleChecks(){return [
  {id:'backup',name:'Backup freshness',description:'Check that the latest project backup completed within the last 24 hours. Report the age and identify a missed backup.',owner:'satwa',schedule:'daily',enabled:true,policy:'immediate',runs:[run('backup-2','attention','2026-10-02T04:00:00.000Z','Latest successful backup is 28 hours old. Check the backup worker and confirm the next backup completes.'),run('backup-1','healthy','2026-10-01T04:00:00.000Z','Latest backup is 4 hours old. The 24-hour freshness threshold is satisfied.')]},
  {id:'availability',name:'Service availability',description:'Check the project app and API health endpoints. Flag an unreachable service and include the failing endpoint in the report.',owner:'satwa',schedule:'five',enabled:true,policy:'consecutive',runs:[run('availability-2','healthy','2026-10-02T07:35:00.000Z','App and API responded successfully. Both checks completed within the 2-second target.'),run('availability-1','healthy','2026-10-02T07:30:00.000Z','App and API responded successfully.')]},
  {id:'queue',name:'Stalled mission check',description:'Look for active mission tasks without a recent heartbeat. Report any task waiting longer than 15 minutes and its assigned owner.',owner:'emon',schedule:'fifteen',enabled:true,policy:'immediate',runs:[run('queue-1','healthy','2026-10-02T07:30:00.000Z','No active tasks are missing a heartbeat. Nothing needs intervention.')]},
  {id:'knowledge',name:'Knowledge source review',description:'Check that linked project references are reachable and flag sources that need a freshness review.',owner:'tinus',schedule:'weekly',enabled:false,policy:'report',runs:[run('knowledge-1','healthy','2026-09-28T07:00:00.000Z','All six example sources are reachable. Two are due for a human freshness review next month.')]},
];}
export const CHECK_POLICIES = {immediate:'Flag after one failed check',consecutive:'Flag after two consecutive failures',report:'Record in run history only'};
export const checksForFloor = state => state.operationFloors?.[state.floor] ?? (state.floor==='studio'?exampleChecks():[]);
export function checkNeedsAttention(job){
  if(job.policy==='report'||job.runs[0]?.status!=='attention')return false;
  return job.policy!=='consecutive'||job.runs[1]?.status==='attention';
}
export function checkConfigValid(job){return Boolean(job&&typeof job.name==='string'&&job.name.trim()&&job.name.length<=120&&typeof job.description==='string'&&job.description.trim()&&job.description.length<=2000&&(job.category===undefined||Object.hasOwn(CHECK_CATEGORIES,job.category))&&Object.hasOwn(CHECK_OWNERS,job.owner)&&Object.hasOwn(CHECK_SCHEDULES,job.schedule)&&Object.hasOwn(CHECK_POLICIES,job.policy));}
export function operationTransition(state,event){
  if(!event.type.startsWith('OPS_'))return null;
  const jobs=checksForFloor(state);
  if(event.type==='OPS_EXAMPLES'&&jobs.length)return state;
  if(['OPS_CREATE','OPS_UPDATE'].includes(event.type)&&!checkConfigValid(event.config))return state;
  const index=jobs.findIndex(j=>j.id===event.id);
  if(['OPS_UPDATE','OPS_TOGGLE','OPS_RUN'].includes(event.type)&&index<0)return state;
  if(event.type==='OPS_CREATE'&&(!/^[a-zA-Z0-9-]{1,80}$/.test(event.id||'')||index>=0))return state;
  if(event.type==='OPS_RUN'&&(!jobs[index].enabled||!['healthy','attention'].includes(event.outcome)))return state;
  if(!['OPS_EXAMPLES','OPS_CREATE','OPS_UPDATE','OPS_TOGGLE','OPS_RUN'].includes(event.type))return state;
  const next=structuredClone(state);
  next.operationFloors??={};
  const target=next.operationFloors[state.floor]=structuredClone(jobs);
  const config=()=>({...Object.fromEntries(['name','description','owner','schedule','policy'].map(key=>[key,event.config[key]])),category:checkCategory(event.config)});
  if(event.type==='OPS_EXAMPLES')next.operationFloors[state.floor]=exampleChecks();
  if(event.type==='OPS_CREATE')target.push({id:event.id,...config(),enabled:true,runs:[]});
  if(event.type==='OPS_UPDATE')Object.assign(target[index],config());
  if(event.type==='OPS_TOGGLE')target[index].enabled=!target[index].enabled;
  if(event.type==='OPS_RUN'){
    const job=target[index];
    job.runs.unshift({id:`${event.id}-run-${Math.max(0,...job.runs.map(r=>Number(r.id.match(/-run-(\d+)$/)?.[1])||0))+1}`,status:event.outcome,at:DEMO_CLOCK,trigger:'Manual simulation',summary:event.outcome==='healthy'?'Simulated pass. This is an authored result; no endpoint, worker or instruction was executed.':'Simulated failure. Inspect the check configuration and investigate its target before a real retry.'});
    job.runs=job.runs.slice(0,10);
  }
  return next;
}
export function restoreOperations(state){
  if(state.operationFloors===undefined){state.operationFloors={};return false;}
  const floors=state.operationFloors;
  const valid=floors&&typeof floors==='object'&&!Array.isArray(floors)&&Object.values(floors).every(jobs=>Array.isArray(jobs)&&jobs.length<=100&&new Set(jobs.map(j=>j?.id)).size===jobs.length&&jobs.every(j=>checkConfigValid(j)&&typeof j.id==='string'&&/^[a-zA-Z0-9-]{1,80}$/.test(j.id)&&typeof j.enabled==='boolean'&&Array.isArray(j.runs)&&j.runs.length<=10&&j.runs.every(r=>r&&typeof r.id==='string'&&['healthy','attention'].includes(r.status)&&typeof r.summary==='string'&&typeof r.trigger==='string'&&Number.isFinite(Date.parse(r.at)))));
  if(!valid)state.operationFloors={};
  return !valid;
}
