import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,transition,restoreState} from '../src/simulation/model.js';
import {currentMission as mission} from '../src/simulation/missions.js';
import {emptyConnected,validExecution} from '../src/simulation/connected.js';
import {artifactCatalog,selectedRevision} from '../src/artifact-workspace.js';
import {missionInspection,decisionIdentity} from '../src/mission-inspection.js';
const act=(s,type,extra={})=>transition(s,{type,...extra});
function approved(){let s={...initialState(),connectedEnabled:true,connected:emptyConnected()};s=act(s,'MISSION_NEW');s=act(s,'MISSION_EDIT',{field:'intent',value:'A clearer handoff'});s=act(s,'MISSION_STEP',{stage:'shape'});for(const id of ['outcome','scope','evidence'])s=act(s,'MISSION_CONFIRM',{id,inline:true});s=act(s,'MISSION_STEP',{stage:'review'});return act(s,'MISSION_APPROVE',{revision:mission(s).revision});}
test('uncertain comments remain one exact owner-bound record through reconciliation and reload',()=>{
 let s=approved();const event={commandId:'request-1',thread:'coordination',text:'  <literal> & text  ',uncertain:true};
 s=act(s,'CONNECTED_COMMENT',event);s=act(s,'CONNECTED_COMMENT',{...event,text:'replacement'});assert.equal(mission(s).execution.comments.length,1);assert.equal(mission(s).execution.comments[0].text,event.text);
 s=act(s,'CONNECTED_PARTNER',{value:'Alex'});s=act(s,'CONNECTED_COMMENT_RECONCILE',{id:event.commandId});assert.equal(mission(s).execution.comments[0].delivery,'uncertain');
 s=act(s,'CONNECTED_PARTNER',{value:'Fito'});s=act(s,'CONNECTED_MODE',{value:'offline'});s=act(s,'CONNECTED_COMMENT_RECONCILE',{id:event.commandId});assert.equal(mission(s).execution.comments[0].delivery,'uncertain');
 s=act(s,'CONNECTED_MODE',{value:'ready'});s=act(s,'CONNECTED_COMMENT_RECONCILE',{id:event.commandId});assert.equal(mission(s).execution.comments[0].delivery,'delivered');assert.ok(validExecution(mission(s)));assert.ok(missionInspection(s,mission(s),{section:'conversations'}).includes('&lt;literal&gt; &amp; text'));
 const restored=restoreState(JSON.stringify(s));assert.equal(restored.state.missionDesk.items.find(m=>m.id===mission(s).id).execution.comments.length,1);
});
test('uncertain transport stops advancement and reconciliation does not change evidence or session',()=>{
 let s=approved();const before=structuredClone(mission(s).execution.tasks);s=act(s,'CONNECTED_TRANSPORT');s=act(s,'MISSION_ADVANCE');assert.deepEqual(mission(s).execution.tasks,before);s=act(s,'CONNECTED_TRANSPORT_RECONCILE');assert.deepEqual(mission(s).execution.tasks,before);s=act(s,'MISSION_ADVANCE');assert.notDeepEqual(mission(s).execution.tasks,before);
});
test('multiple applied instructions and resolved findings remain inspectable',()=>{
 let s=approved();s=act(s,'CONNECTED_FEEDBACK',{text:'First instruction'});s=act(s,'MISSION_ADVANCE');s=act(s,'MISSION_ADVANCE');s=act(s,'MISSION_ADVANCE');
 assert.equal(mission(s).execution.findings[0].state,'closed');
 s=act(s,'CONNECTED_FEEDBACK',{text:'Second instruction'});
 const x=mission(s).execution;assert.equal(x.instructions.length,2);assert.equal(x.instructions[0].state,'applied');assert.equal(x.instructions[1].state,'received');assert.equal(x.findings.length,2);assert.equal(x.findings[0].history.length,2);assert.ok(validExecution(mission(s)));
});
test('artifact catalog isolates projects and includes only published exact evidence revisions',()=>{
 let s=approved();const initial=artifactCatalog(s);assert.equal(initial.length,2);assert.ok(initial.every(a=>!a.missionId));s=act(s,'MISSION_ADVANCE');s=act(s,'MISSION_ADVANCE');const m=mission(s),t=m.execution.tasks[0];assert.equal(t.evidence.length,1);assert.equal(artifactCatalog(s).length,2);s=act(s,'CONNECTED_PUBLISH',{task:t.id,revision:1});const linked=artifactCatalog(s).find(a=>a.missionId);assert.equal(linked.missionId,m.id);assert.equal(selectedRevision(linked,{revision:1}).revision,1);assert.match(selectedRevision(linked,{}).content('index.html'),/SYNTHETIC DELIVERABLE/);s=act(s,'ENTER_FLOOR',{id:'growth'});assert.equal(artifactCatalog(s).length,2);assert.ok(artifactCatalog(s).every(a=>a.id.startsWith('growth-')));
});
test('session expiry hides mission access while preserving saved state and stale decisions differ',()=>{
 let s=approved();const before=structuredClone(mission(s)),key=decisionIdentity(before);s=act(s,'CONNECTED_MODE',{value:'expired'});assert.equal(restoreState(JSON.stringify(s)).state.connected.mode,'expired');s=act(s,'CONNECTED_HOLD');assert.deepEqual(mission(s),before);s=act(s,'CONNECTED_MODE',{value:'ready'});s=act(s,'CONNECTED_HOLD');assert.notEqual(decisionIdentity(mission(s)),key);assert.equal(mission(s).approved.revision,before.approved.revision);
});
