export const CATALOG_REVISION = 2;
export const MODEL_PRESETS = ['Opus 5.5', 'GPT-6 Astra', 'GPT-6 Sol', 'GPT-5.6 Sol', 'GPT-5.6 Terra'];
export const DEFAULT_MODEL = 'GPT-6 Sol';
export const REASONING_LEVELS = ['Low', 'Medium', 'High'];

export const FLOORS = [
  { id: 'growth', number: '03', title: 'Hauscraft', status: 'Quiet', description: 'The next opportunity starts here.', accent: '#b6b58c' },
  { id: 'client', number: '02', title: 'Finaxis', status: 'Decision needed', description: 'A proposal is ready for its owner.', accent: '#e2b85c' },
  { id: 'studio', number: '01', title: 'Core', status: 'Ready to shape', description: 'A place to build the way we work.', accent: '#fe5600' }
];
// Shared architecture. Project identity lives in people, work and artifacts.
export const OFFICE = {
  width: 22, depth: 14, label: 'The project walk',
  board: [-8.65, -5.6], team: [0, -3.1], shelf: [-4.7, -5.8],
  review: [8.2, -.9], operations: [8.2, -5.3], lounge: [4.15, 4.3],
  founder: [-8.3, 2.5], entrance: [-2.3, 6.15],
  workstations: Array.from({length:8}, (_,i) => ({
    x: -2.1 + (i%4)*1.95, z: i<4 ? -4.4 : -3, facing: i<4 ? Math.PI : 0,
    guest: i===3 || i===7
  }))
};
export const OFFICE_ZONES = [
  {id:'entrance',label:'Entrance',description:'Return to the company and choose a project.'},
  {id:'founder',label:'Leadership',description:'Your desk, decisions and conversations with Emon.'},
  {id:'whiteboard',label:'Mission table',description:'Open the free whiteboard: shared documents, ideas and comments.'},
  {id:'team',label:'Workstations',description:'Six resident stations and two places for guest experts.'},
  {id:'review',label:'Review',description:'Inspect the proposal, leave feedback and judge the evidence.'},
  {id:'shelf',label:'Library',description:'Keep references, research and previous artifacts close.'},
  {id:'operations',label:'Operations',description:'Scheduled checks that monitor project health and flag what needs attention.'},
  {id:'lounge',label:'Lounge',description:'Find your team between missions.'}
];
export const PEOPLE = [
  { id:'fito', name:'Fito', role:'Founder & mission owner', color:'#e9e9e6', hair:'#49342b', description:'Sets direction, makes consequential decisions, and accepts the outcome.', skills:[] },
  { id:'emon', name:'Emon Lusk', role:'CEO · coordinator', color:'#fe5600', hair:'#31281e', description:'Shapes company intent into bounded missions, coordinates the team, and keeps decisions and handoffs clear.', skills:['shaping','coordination'], required:true },
  { id:'kapiteky', name:'Kapiteky', role:'Advisor', color:'#7eb2ad', hair:'#d5bba0', description:'Connects the proposed work to company direction, challenges assumptions, and checks the evidence.', skills:['grounding','review'] },
  { id:'tinus', name:'Tinus Lordvals', role:'AI engineer', color:'#8c9cbc', hair:'#2e2429', description:'Turns approved AI and product ideas into working prototypes, then verifies the interaction and implementation.', skills:['prototype','browser'] },
  { id:'satwa', name:'Satwa Nutella', role:'Infrastructure', color:'#c3ad70', hair:'#865936', description:'Prepares reproducible builds and checks infrastructure, packaging, and operational readiness.', skills:['packaging','runtime'] },
  { id:'stewie', name:'Stewie Hobs', role:'Design', color:'#454b50', hair:'#645344', description:'Shapes the product experience, gives the work a clear visual direction, and checks how it feels to use.', skills:['design','usability'] },
  { id:'ramiro', name:'Ramiro Garcia', role:'Client management', color:'#b88169', hair:'#352c28', description:'Keeps client goals, expectations, decisions, and next steps connected to the work.', skills:['client-brief','client-updates'] }
];
export const SKILLS = {
  shaping:{title:'Mission shaping',outcome:'Turn intent into an actionable mission paper.',requires:'Owner context and source references',tools:'Mission board · repository context',permissions:'Local draft edits',artifact:'Mission paper and open decisions',verification:'Outcome, scope, and evidence are explicit'},
  coordination:{title:'Squad coordination',outcome:'Give each specialist a bounded responsibility.',requires:'Approved paper and selected squad',tools:'Mission context · task ledger',permissions:'Demo assignments only',artifact:'Owned plan and handoffs',verification:'Every step has an owner and expected output'},
  grounding:{title:'Company grounding',outcome:'Keep the design coherent with the company vision.',requires:'Product vision and brand direction',tools:'Knowledge references',permissions:'Read selected references',artifact:'Constraints and rationale',verification:'Decisions link back to the stated intent'},
  review:{title:'Evidence review',outcome:'Expose gaps before the owner accepts the work.',requires:'Proposed artifact and acceptance criteria',tools:'Artifact inspector',permissions:'Comment and propose corrections',artifact:'Review findings',verification:'Claims have evidence or an explicit gap'},
  prototype:{title:'Experience prototyping',outcome:'Make a difficult interaction something you can try.',requires:'Approved interaction scope',tools:'Repository · local preview',permissions:'Local prototype changes',artifact:'Playable design proposal',verification:'The intended user journey is operable'},
  browser:{title:'Browser evidence',outcome:'Check the interaction at desktop and narrow widths.',requires:'Runnable preview',tools:'Browser',permissions:'Demo interactions',artifact:'Flow checks and captured evidence',verification:'Controls, content, and focus remain usable'},
  packaging:{title:'Packaging review',outcome:'Prepare a reproducible preview handoff.',requires:'Prototype and build commands',tools:'Repository · build scripts',permissions:'Local build only',artifact:'Packaging checklist',verification:'Assets and startup instructions work'},
  runtime:{title:'Runtime readiness',outcome:'Identify what a later deployment will need.',requires:'Agreed delivery environment',tools:'Deployment reference material',permissions:'Read-only planning; no deployment',artifact:'Readiness notes',verification:'Unmet operational requirements are visible'},
  design:{title:'Experience design',outcome:'Turn the intent into a clear interaction and visual direction.',requires:'Project brief, audience, and constraints',tools:'Mission board · design references',permissions:'Local design proposals',artifact:'Interaction proposal and design rationale',verification:'The proposed flow addresses the stated user outcome'},
  usability:{title:'Usability review',outcome:'Find friction in the proposed experience.',requires:'Inspectable prototype and intended user journey',tools:'Preview · artifact inspector',permissions:'Local inspection and comments',artifact:'Usability findings and suggested refinements',verification:'Each finding names a concrete interaction and its impact'},
  'client-brief':{title:'Client discovery',outcome:'Make the client’s goals and expectations explicit.',requires:'Owner-supplied client context',tools:'Project brief · selected references',permissions:'Local draft analysis; no client contact',artifact:'Client brief and open questions',verification:'Scope, success criteria, and assumptions are distinguished'},
  'client-updates':{title:'Client communication',outcome:'Prepare a clear account of progress and decisions for the client.',requires:'Agreed scope and current work evidence',tools:'Mission context · artifact references',permissions:'Draft only; no messages are sent',artifact:'Client update draft and decision requests',verification:'Every status claim is supported and next steps have owners'}
};
export const OBJECTS = [
  ['entrance','Company entrance','Return to the company overview'],
  ['whiteboard','Free whiteboard','Explore the shared HTML canvas'], ['founder','Your desk','See the decision waiting for you'],
  ['team','Workstations','Gather people and capabilities'], ['shelf','Library & artifacts','Explore this mission’s work'],
  ['review','Review wall','Inspect the proposal and leave a correction'], ['operations','Operations corner','Inspect schedules, check results and monitoring rules'],
  ['lounge','Team lounge','Find the people behind the work']
];
