# Agents character spotlight — current prototype review

final result: passed

## Current brief

The partner selected the character-selection concept, then requested the roster
at the top, an approximately one-third-size portrait, richer information from the
real Agents page, and finally populated mock data and removal of the gray canvas.
Those later refinements supersede the original full-height spotlight and the
intermediate disconnected-state design.

## Visual evidence

- Before: `/private/tmp/studio-agents-compact-final.png`.
- Current: `/private/tmp/studio-agents-warm-final.png`.
- Direct comparison: `/private/tmp/studio-agents-warm-comparison.png`.
- Both IAB frames are 1494 × 1171 pixels; side-by-side at native size, no cropping.
- Browser-test captures under `test-results/mockup-agents-character-ro-dae7f-h-and-guides-stay-connected-{desktop,mobile}/`: `agents-about.png`, `agents-work.png`, `agents-telemetry.png`.
- Desktop: 1487 × 1058 CSS/pixels. Mobile: 390 × 844. Device scale 1.

## Review

A shared background override initially kept the header gray and body white.
Scoped the prototype palette at its owning surface and verified the computed
background plus final screenshot. The entire team page now uses warm off-white,
with green current-work emphasis and orange selection/action cues. The surrounding
workspace sidebar keeps its own shell styling.

Existing shared voxel characters remain fully visible in a 240 × 260 desktop
stage (120 × 160 mobile). Plex hierarchy, top roster and accessible tabs are
preserved. Current mission and next step sit above the tabs; deeper runtime,
usage, activity and schedules remain in Telemetry. Long mobile content scrolls;
there is no horizontal page overflow. Mock data is labelled once in the header,
with its fixed snapshot timestamp in Telemetry. Repeated caveats were removed.

Inspected desktop About/Telemetry and mobile About at native sizes. No remaining
actionable P0/P1/P2 findings for this requested refinement. Partner acceptance
is pending; the prototype is local and has not been deployed.

## Verification

- Five focused unit tests pass, including fixture totals, agent variation,
  guest text escaping and no mutation of mission state.
- Four browser tests pass across desktop/mobile: roster/search, tabs/keyboard,
  expandable mock missions, usage switching, guides, guest editor and WebGL fallback.
- Mockup build passes. Fast repository source gate passes.
- Existing simulation actions retain their owners. No backend or real Agents change.

## Visible sections and icons — partner refinement

Replaced all disclosures in the Agents profile with permanent sections, including
project/profile details, guest research, saved missions, defaults, mission progress
and runtime/usage/schedule/source details. About / Work / Telemetry remain the
page’s navigation. Shared outline icons mark headings, metrics and tabs without
changing accessible labels. The token total retains its seven-day mini chart.

Five unit checks and four desktop/mobile browser checks pass; the browser suite
now also confirms there are no disclosure elements in the Agents surface.
Final IAB capture: `/private/tmp/studio-agents-visible-details.png`.

## Best used for — partner refinement

Added a permanently visible Best used for section at the top of the About
sidebar, above guides/apps. Each established agent has three role-specific
example requests; guests receive specialist-review examples. Examples are plain
text, not dispatch controls. Shared pointer icon and simple separated rows
retain the warm page style.

## Identity above portrait — partner refinement

Moved the name, role and signature above the voxel portrait on desktop and mobile.
Removed View linked work and Supporting apps. Replaced Profile source with Harness
(OpenClaw 2026.10.2, illustrative), and Guides to explore with Most used skills,
including mock 30-day usage counts and existing skill detail navigation. Agent
selection now focuses the relocated heading.

## Team operations — partner refinement

Team operations is opened by a separate button beside Meet the team. Its
full-width view preserves the roster and hides the individual profile and tabs.
Back to profiles restores the selected profile tab and returns keyboard focus
to the team-level button.
Attention-first rows expose health, model policy, seven-day usage, observation
age and next action. All/Needs attention filtering is local and announces the
result count. Shared mock fixtures keep drill-down consistent: Emon healthy,
Tinus degraded, Kapiteky model mismatch, Stewie stale, Satwa paused, Ramiro unknown.
Unknown usage has no chart; retained usage is labelled. No collapsed sections.

- IAB: `/private/tmp/studio-agents-team-button.png`, 1494 × 1171.
- Desktop/mobile captures in `test-results/mockup-agents-team-operati-74347-istent-individual-telemetry-{desktop,mobile}/agents-team-operations.png`.
- Six unit tests and six desktop/mobile browser tests passed, including filter
  behavior, keyboard access and degraded/unknown/mismatched drill-down. Build passed.
- Visual inspection: warm surface, shared icons, readable status text (not color
  alone), four desktop metric columns/two mobile columns, no horizontal overflow.
- final result: passed; partner acceptance remains pending.
