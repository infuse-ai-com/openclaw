import {escapeHtml as esc} from '@studio/ui/workspace';
export function missionChatDrawer(m,kind,content){
 const chat=kind==='plan'?m.planning:m.shaping;
 const note=chat?.pending?'Proposal ready to review':chat?.draft?.trim()?'Unsent draft saved':kind==='plan'?'Discuss the plan and team':'Discuss the paper';
 return `<details class="mission-chat-drawer" data-preserve-details="mission-chat-${kind}" ${chat?.pending?'open':''}><summary id="mission-chat-${kind}-toggle"><strong>Talk with Emon</strong><span>${esc(note)}</span><span class="mission-chat-toggle" aria-hidden="true"></span></summary><div class="mission-chat-body">${content}</div></details>`;
}
export function focusMissionChat(selector){
 const input=document.querySelector(selector),drawer=input?.closest('.mission-chat-drawer');
 if(drawer)drawer.open=true;
 input?.focus({preventScroll:true});
}
