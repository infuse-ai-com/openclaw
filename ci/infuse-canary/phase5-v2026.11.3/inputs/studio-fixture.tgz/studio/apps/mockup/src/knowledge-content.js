// Authored demonstration content; never a copy of the private Knowledge Base corpus.
import {sourcesFor} from './simulation/reference-catalog.js';
const sections = [
  ['Start with one useful outcome', 'A partner should understand the team, the project and the next action before making a commitment. Choose a small improvement that can be inspected and verified.'],
  ['Keep context close', 'Read the relevant guidance, select the exact source and make the intended outcome explicit. A newer document must not silently change an approved mission.'],
  ['Review what changed', 'Compare the result with the agreed intent. Record what was adopted, what remains incomplete and which evidence supports the outcome.'],
];
const extras = {
  company: {domain:'Company', description:'Shared ownership, clear decisions and a useful first contribution.', type:'guide', sections:[
    ['Build together', 'Partners help run Infuse AI and build projects together. Shared knowledge and infrastructure should make the next contribution easier.'],
    ['Keep decisions visible', 'Name the person responsible for a decision. Discuss alternatives with the team and retain the reason for the agreed direction.'],
    ['Start small', 'Bring a real problem, find the relevant context and shape one bounded mission before asking agents to execute.']]},
  engineering: {domain:'Engineering', description:'A practical path from an agreed outcome to inspectable evidence.', type:'standard', sections:[
    ['Agree on the outcome', 'Write the intended behavior, scope and verification before starting implementation. Link the exact guidance used to make the decision.'],
    ['Deliver evidence', 'A delivery includes the changed artifact and the checks that demonstrate its behavior. Publishing an artifact is separate from verifying the task.'],
    ['Close the loop', 'Review the exact revision, retain unresolved findings and record what the next contributor needs to know.']]},
  agents: {domain:'Agent platform', description:'Give the team useful context, bounded work and a clear decision owner.', type:'guide', sections:[
    ['Give the team a mission', 'Start with one useful outcome. The coordinator helps turn an idea into a paper with a named decision owner and clear acceptance criteria.'],
    ['Stay in the conversation', 'Follow progress, answer clarifications and review the work. Same-scope feedback stays with the active assignment.'],
    ['Change scope explicitly', 'A changed outcome needs a new approval. A message or a saved draft alone does not authorize execution.']]},
  runbooks: {domain:'Engineering', description:'Turn operational learning into reliable steps someone else can follow.', type:'runbook', sections:[
    ['Describe the signal', 'Begin with the symptom, the environment and the evidence needed to establish what happened.'],
    ['Make recovery repeatable', 'Write the smallest safe steps, their expected results and the point at which a person must make a decision.'],
    ['Keep the source current', 'Propose changes in the owning repository. Review the exact new version before relying on it for another mission.']]},
};
export function knowledgeDocuments(floor) {
  return sourcesFor(floor).map((source,index)=> {
    const meta=extras[source.id.split('-').at(-1)];
    return {...source, domain:meta?.domain||'Project', description:meta?.description||(index===0?'A clear first step for the project and every new partner.':'Read exact delivered evidence before accepting an outcome.'), type:meta?.type||'guide', status:'active', owner:'team:product-engineering', sections:meta?.sections||(index===1?[[source.title,'Read the exact delivered evidence. Publication alone is not task verification.'],['Check the agreed criteria','Inspect each selected requirement and preserve unresolved findings for the same assignment.'],['Record the decision','State what passed, what still needs attention and which revision the decision applies to.']]:sections), initialReviewed:index===0||index===2};
  });
}
export function filterKnowledge(docs, {query='', repository='', type=''}={}) {
  const terms=query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  return docs.filter(d=>(!repository||d.repo===repository)&&(!type||d.type===type)&&terms.every(t=>[d.title,d.description,d.path,d.repo,d.type,d.owner,...d.sections.flat()].join(' ').toLowerCase().includes(t)));
}
export function knowledgeReview(doc,revision,ui) {
  const revisions=ui.reviews?.[doc.id]||[];
  const exact=revisions.includes(revision)||(doc.initialReviewed&&revision===1);
  return exact?'reviewed':revisions.some(r=>r<revision)||(doc.initialReviewed&&revision>1)?'changed':'never-reviewed';
}
export const reviewLabel=state=>({'reviewed':'Human reviewed','changed':'Changed since review','never-reviewed':'Never reviewed'}[state]);
export const revisionAddition=revision=>`Revision ${revision} adds a reminder to review the agreed outcome with a teammate.`;

export function relatedDocuments(doc,docs) {
  const links=[[0,1],[0,2],[0,3],[0,4],[1,3],[2,4],[3,5],[4,5]];
  const index=docs.findIndex(d=>d.id===doc.id);
  return links.filter(pair=>pair.includes(index)).map(pair=>docs[pair.find(i=>i!==index)]).filter(Boolean);
}

// Snapshot the desk order once, so recording a review never skips the next document.
export function knowledgeReviewQueue(docs,revision,ui) {
  return docs.filter(doc=>knowledgeReview(doc,revision,ui)!=='reviewed')
    .toSorted((a,b)=>Number(b.type==='standard')-Number(a.type==='standard'))
    .map(doc=>doc.id);
}
