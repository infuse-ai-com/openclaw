import { allFloors } from './simulation/company.js';
import { companyDeskItems } from './simulation/founder.js';
import { createdMissions } from './simulation/missions.js';
import { partner } from './simulation/reference-catalog.js';
import './my-desk.css';

const esc = value => String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
// An explicit fixture, independent of mission activity or provider billing.
export const DESK_USAGE = Object.freeze({input:96400, output:32000, previous:146000});
export const deskTokens = () => DESK_USAGE.input + DESK_USAGE.output;
const number = value => new Intl.NumberFormat('en-US').format(value);
export const deskOverview = state => ({...DESK_USAGE,decisions:companyDeskItems(state).filter(item=>item.status==='attention').length,missions:createdMissions(state).length,project:allFloors(state).find(f=>f.id===state.floor)?.title||'Current project'});

export function myDeskSurface(state, view, icons, desktopHtml) {
  const decisions = companyDeskItems(state).filter(item => item.status === 'attention').length;
  const missions = createdMissions(state);
  const objects = [
    {id:'monitor', name:'Widescreen', detail:'Your Workbench', icon:'server'},
    {id:'tokens', name:'Token meter', detail:`${(deskTokens()/1000).toFixed(1)}k yesterday · example`, icon:'chart'},
    {id:'inbox', name:'Decision tray', detail:`${decisions} need${decisions === 1 ? 's' : ''} you`, icon:'list'},
    {id:'notebook', name:'Mission notebook', detail:`${missions.length} saved on this floor`, icon:'document'},
  ];
  return `<div class="md-scroll"><div class="md-layout" data-desk-layout data-panel-open="${Boolean(view.panelOpen)}">
      <section class="md-room" aria-label="Your interactive desk">
        <div class="md-world" data-desk-world><p class="md-scene-fallback" data-desk-fallback>Loading your desk. Everything is also available in the object dock.</p></div>
        <header class="md-room-caption"><div><span class="md-eyebrow">${esc(partner(state))}’S WORKSPACE</span><h1>My desk</h1></div><button class="md-wall-link" data-desk-object="wall" aria-pressed="${view.panelOpen&&view.selected==='wall'}">Wall display ↗<small>Daily overview · local demo</small></button></header>
        <div class="md-camera-tools" role="group" aria-label="Desk camera">
          <span class="md-camera-label">FROM YOUR SEAT</span>
          <div class="md-camera-buttons">
            <button data-desk-camera="out" aria-label="Zoom out" title="Zoom out">−</button>
            <output data-desk-zoom aria-label="Desk zoom" aria-live="off">100%</output><button data-desk-camera="in" aria-label="Zoom in" title="Zoom in">+</button>
            <button class="md-reset-view" data-desk-camera="reset" aria-label="Reset seated view" title="Reset seated view">Reset view</button>
          </div>
        </div>
        <div class="md-dock">
          <p class="md-hint" id="desk-camera-help">Drag to look around · Scroll or pinch to zoom · Click an object to open it<span>Keyboard: arrows to look, + / − to zoom, Home to reset.</span></p>
          <nav class="md-objects" aria-label="Desk objects">${objects.map(item=>`<button data-desk-object="${item.id}" aria-pressed="${view.panelOpen&&view.selected===item.id}">${icons[item.icon]}<span><strong>${item.name}</strong><small>${item.detail}</small></span></button>`).join('')}</nav>
        </div>
      </section>
      <section class="md-panel" role="dialog" aria-modal="false" aria-labelledby="desk-panel-title" data-desk-panel ${view.panelOpen?'':'hidden'}>
        <div class="md-panel-top"><span>ON YOUR DESK</span><button data-action="desk-panel-close" aria-label="Close desk panel" title="Close panel · Esc">✕</button></div>
        <div data-desk-panel-content>${deskPanel(state,view,icons,desktopHtml)}</div>
      </section>
    </div></div>`;
}

export function deskPanel(state, view, icons, desktopHtml) {
  const decisions=companyDeskItems(state).filter(item=>item.status==='attention').length;
  const missions=createdMissions(state);
  const floor=allFloors(state).find(f=>f.id===state.floor);
  if(view.selected==='wall'){
    const data=deskOverview(state);
    return `<div class="md-panel-heading"><span class="md-panel-icon">${icons.chart}</span><span class="eyebrow">WALL DISPLAY / LOCAL DEMO</span></div><h2 id="desk-panel-title" tabindex="-1">Your day, in view.</h2><p class="md-copy">The big picture behind your workspace. A daily usage example alongside this browser’s saved work.</p><div class="md-overview">
      <button data-desk-object="tokens"><span>Tokens yesterday · example</span><strong>${number(deskTokens())}</strong><small>${number(data.input)} input + ${number(data.output)} output →</small></button>
      <button data-desk-object="inbox"><span>Decisions to make · all projects</span><strong>${data.decisions}</strong><small>Open your decision tray →</small></button>
      <button data-desk-object="notebook"><span>Saved missions · ${esc(data.project)}</span><strong>${data.missions}</strong><small>Open your mission notebook →</small></button>
    </div><p class="md-small">Token usage is fixed example data, with no account connected. Decisions cover all projects; missions belong to the selected project.</p>`;
  }
  if(view.selected==='tokens') {
    const change=Math.round((1-deskTokens()/DESK_USAGE.previous)*100);
    return `<div class="md-panel-heading"><span class="md-panel-icon">${icons.chart}</span><span class="eyebrow">TOKEN METER / EXAMPLE DATA</span></div><h2 id="desk-panel-title" tabindex="-1">Yesterday’s burn.</h2><p class="md-copy">An example of your daily usage at a glance. No provider account is connected.</p><div class="md-token-total"><strong>${number(deskTokens())}</strong><span>tokens · previous calendar day</span></div><span class="md-trend">${change}% less than the example day before</span><div class="md-usage-bar" role="img" aria-label="${number(DESK_USAGE.input)} input tokens and ${number(DESK_USAGE.output)} output tokens"><span style="width:${DESK_USAGE.input/deskTokens()*100}%"></span></div><dl class="md-usage"><div><dt>Input tokens</dt><dd>${number(DESK_USAGE.input)}</dd></div><div><dt>Output tokens</dt><dd>${number(DESK_USAGE.output)}</dd></div><div><dt>Previous day</dt><dd>${number(DESK_USAGE.previous)}</dd></div></dl><div class="md-note"><strong>A little context for the number</strong><p>This fixed example explores the desk interaction. It does not measure this project, refresh daily, or estimate a bill.</p></div>`;
  }
  if(view.selected==='inbox')return `<div class="md-panel-heading"><span class="md-panel-icon">${icons.list}</span><span class="eyebrow">DECISION TRAY / ALL PROJECTS</span></div><h2 id="desk-panel-title" tabindex="-1">${decisions?'Your judgment, please.':'A little room to think.'}</h2><p class="md-copy">${decisions?`${decisions} item${decisions===1?'':'s'} need your attention. Review the context and Emon’s recommendation before deciding.`:'Nothing needs your judgment across your projects right now. Your mission decisions and failed checks will collect here.'}</p><div class="md-big-count">${decisions}<span>need you</span></div><button class="primary" data-action="desk-inbox">Open decision inbox →</button><p class="md-small">Your existing decisions and notes stay with their source records.</p>`;
  if(view.selected==='notebook')return `<div class="md-panel-heading"><span class="md-panel-icon">${icons.document}</span><span class="eyebrow">MISSION NOTEBOOK / ${esc(floor.title)}</span></div><h2 id="desk-panel-title" tabindex="-1">What’s on your mind?</h2><p class="md-copy">A place for the idea you want to shape with Emon, and the work already taking form.</p><div class="md-mission-list">${missions.length?missions.slice(0,3).map(m=>`<button data-mission-select="${esc(m.id)}"><span>${esc(m.title||'Untitled mission')}</span><small>${esc(m.execution?.state||m.status)}</small></button>`).join(''):'<p>No saved missions on this floor yet.</p>'}</div><button class="primary" data-action="mission-new">Shape a mission with Emon →</button><button class="md-text-button" data-action="mission-list">See all missions →</button><button class="md-text-button" data-action="artifacts">Open project artifacts →</button>`;
  return `<div class="md-panel-heading"><span class="md-panel-icon">${icons.desktop}</span><span class="eyebrow">WIDESCREEN / WORKBENCH</span><span class="md-demo">Preview</span></div><h2 id="desk-panel-title" tabindex="-1">Your workspace.</h2><p class="md-copy">Your Linux workspace, with the rest of your desk in reach.</p>${desktopHtml}`;
}
