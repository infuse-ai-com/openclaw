import { test } from 'node:test';
import assert from 'node:assert/strict';
import { initialState, transition as t, restoreState, missionMarkdown, SECTIONS, PEOPLE, planSteps, unresolved } from '../src/simulation/model.js';
const shaped=()=>SECTIONS.reduce((s,x)=>t(s,{type:'EDIT',id:x.id,value:`My custom ${x.id} <words> & detail`}),initialState());
function review(){let s=t(t(t(shaped(),{type:'APPROVE_PAPER'}),{type:'CONFIRM_SQUAD'}),{type:'LAUNCH'});while(s.mission.phase==='running')s=t(s,{type:'ADVANCE',at:'2026-09-23T12:00:00Z'});return s;}
function corrected(s=review()){s=t(s,{type:'ANNOTATE',section:'opening',text:'  Keep <the board> & sources together.\nExactly.  '});return t(t(s,{type:'RECORD'}),{type:'ACCEPT',value:true});}

test('navigation retains cameras, selected board section, content, and local floor preferences',()=>{
  let s=t(initialState(),{type:'ENTER_FLOOR',id:'studio'});
  s=t(s,{type:'CAMERA',key:'studio',x:2,y:-1,zoom:1.3});s=t(s,{type:'LAYOUT',id:'open'});s=t(s,{type:'DESK',id:'team'});
  s=t(s,{type:'OPEN',surface:'board',object:'whiteboard'});s=t(s,{type:'SECTION',id:'evidence'});s=t(s,{type:'BOARD_CAMERA',x:-200,y:-500,zoom:.8});
  s=t(s,{type:'CLOSE'});s=t(s,{type:'BUILDING'});s=t(s,{type:'ENTER_FLOOR',id:'client'});s=t(s,{type:'ENTER_FLOOR',id:'studio'});
  const restored=restoreState(JSON.stringify(s));assert.equal(restored.notice,null);
  assert.deepEqual(restored.state.settings.studio,{layout:'promenade',desk:'fixed'});assert.deepEqual(restored.state.cameras.studio,{x:2,y:-1,zoom:1.3});assert.equal(restored.state.section,'evidence');assert.equal(restored.state.boardCamera.y,-500);
});
test('required decisions block approval, optional context can be deferred, custom words export',()=>{
  let s=initialState();assert.equal(t(s,{type:'APPROVE_PAPER'}),s);assert.equal(t(s,{type:'DEFER',id:'outcome'}),s);
  for(const section of SECTIONS.filter(x=>x.required))s=t(s,{type:'EDIT',id:section.id,value:`Custom ${section.id} <&>`});
  s=t(s,{type:'DEFER',id:'references'});assert.deepEqual(unresolved(s),[]);assert.equal(t(s,{type:'APPROVE_PAPER'}).mission.phase,'squad');
  const md=missionMarkdown(s);assert.match(md,/Custom intent <&>/);assert.match(md,/Custom evidence <&>/);assert.match(md,/Deferred/);
});
test('persistent people are shared while selected capabilities determine assignments and work',()=>{
  const identities=structuredClone(PEOPLE);let s=t(shaped(),{type:'APPROVE_PAPER'});s=t(s,{type:'SQUAD',id:'tinus'});s=t(s,{type:'SQUAD',id:'satwa'});s=t(s,{type:'SKILL',person:'satwa',id:'runtime'});
  assert(!planSteps(s).some(x=>x.owner==='tinus'));assert.equal(planSteps(s).filter(x=>x.owner==='satwa').length,1);
  s=t(s,{type:'ENTER_FLOOR',id:'client'});assert.deepEqual(PEOPLE,identities);
  s=t(s,{type:'CONFIRM_SQUAD'});s=t(s,{type:'LAUNCH'});const count=planSteps(s).length;
  for(let i=0;i<count;i++)s=t(s,{type:'ADVANCE'});assert.equal(s.mission.phase,'review');assert.equal(s.mission.step,count);
});
test('empty selected capability sets block launch and altering the paper clears old execution evidence',()=>{
  let s=t(shaped(),{type:'APPROVE_PAPER'});s=t(s,{type:'SKILL',person:'tinus',id:'browser'});s=t(s,{type:'SKILL',person:'tinus',id:'prototype'});assert.equal(t(s,{type:'CONFIRM_SQUAD'}),s);
  s=t(review(),{type:'EDIT',id:'outcome',value:'A different outcome'});assert.equal(s.mission.phase,'shaping');assert.equal(s.mission.artifact,null);assert.equal(s.mission.approvedRevision,null);assert.match(missionMarkdown(s),/A different outcome/);
});
test('annotation preserves exact text and anchor; changed correction invalidates resolution evidence',()=>{
  let s=corrected();assert.equal(s.mission.annotation.recorded.section,'opening');assert.equal(s.mission.annotation.recorded.text,s.mission.annotation.text);
  s=t(s,{type:'RESOLVE'});assert.equal(s.mission.phase,'resolved');
  s=t(s,{type:'ANNOTATE',section:'scope',text:'Updated correction'});assert.equal(s.mission.phase,'review');assert.equal(s.mission.annotation.recorded,null);assert.equal(s.mission.accepted,false);assert.equal(t(s,{type:'RESOLVE'}),s);
});
test('source updates leave the older projection stale and gate resolution until explicit disposition',()=>{
  let s=t(corrected(),{type:'SOURCE_UPDATE'});assert.equal(s.mission.sourceRevision,2);assert.equal(s.mission.artifact.sourceRevision,1);
  s=t(s,{type:'ACCEPT',value:true});assert.equal(t(s,{type:'RESOLVE'}),s);s=t(s,{type:'ACK_DRIFT'});s=t(s,{type:'RESOLVE'});assert.equal(s.mission.phase,'resolved');assert.match(missionMarkdown(s),/Drift recorded: true/);
});
test('reuse retains inspectable outcome and preferences; reset clears the session',()=>{
  let s=t(corrected(),{type:'RESOLVE'});s=t(s,{type:'LAYOUT',id:'review'});s=t(s,{type:'REUSE'});assert.equal(s.mission.history.length,1);assert.match(s.mission.history[0].markdown,/State: resolved/);assert.equal(s.settings.studio.layout,'promenade');assert.equal(s.mission.content.intent,'');assert.equal(s.mission.phase,'shaping');assert.deepEqual(t(s,{type:'RESET'}),initialState());
});
test('invalid saved data recovers explicitly, valid lifecycle states survive reload',()=>{
  for(const raw of ['{','null','{}',JSON.stringify({...initialState(),version:99})])assert.match(restoreState(raw).notice,/saved demo could not be read/);
  for(const s of [shaped(),review(),t(corrected(),{type:'RESOLVE'})]){const result=restoreState(JSON.stringify(s));assert.equal(result.notice,null);assert.equal(result.state.mission.phase,s.mission.phase);}
  const bad=review();bad.mission.artifact.sections=null;assert(restoreState(JSON.stringify(bad)).notice);
});

test('section annotations retain literal wording and export with their section anchor',()=>{
  const s=t(shaped(),{type:'NOTE',id:'outcome',value:'  Beside the outcome: <keep> & inspect.  '});
  assert.equal(restoreState(JSON.stringify(s)).state.mission.notes.outcome,'  Beside the outcome: <keep> & inspect.  ');
  assert.match(missionMarkdown(s),/Note on The experience\n  Beside the outcome: <keep> & inspect\.  /);
});


test('retired floor preferences migrate without changing mission evidence or camera context',()=>{
  const old=t(corrected(),{type:'RESOLVE'});
  old.settings.studio={layout:'review',desk:'quiet'};
  old.settings.client={layout:'open',desk:'team'};
  old.cameras.studio={x:2,y:-1,zoom:1.15};
  const restored=restoreState(JSON.stringify(old));
  assert.match(restored.notice,/larger office/);
  assert.deepEqual(restored.state.mission,old.mission);
  assert.deepEqual(restored.state.cameras,old.cameras);
  for(const value of Object.values(restored.state.settings))assert.deepEqual(value,{layout:'promenade',desk:'fixed'});
  assert.equal(t(restored.state,{type:'LAYOUT',id:'open'}),restored.state);
  assert.equal(t(restored.state,{type:'DESK',id:'team'}),restored.state);
  assert.equal(restoreState(JSON.stringify(restored.state)).notice,null);
});
