// Synthetic screenshots only. Start `npm run dev`, then run this script.
import { chromium } from "@playwright/test";
import { mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import {
  initialState,
  transition,
  STORAGE_KEY,
} from "../src/simulation/model.js";
import { currentMission } from "../src/simulation/missions.js";
import { emptyConnected } from "../src/simulation/connected.js";
const output = resolve(process.argv[2] || "/tmp/studio-mvp-evidence");
const origin = process.env.STUDIO_MOCKUP_URL || "http://127.0.0.1:4317";
await mkdir(output, { recursive: true });
const browser = await chromium.launch(
  process.platform === "darwin"
    ? { args: ["--use-angle=metal", "--enable-gpu"] }
    : {},
);
try {
  let page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const snap = async (name) => {
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(350);
    await page.screenshot({ path: resolve(output, `${name}.png`) });
  };
  await page.goto(origin);
  await page.locator("#world canvas").waitFor();
  await snap("mvp-company");
  await page.locator("[data-action=enter-studio]").first().click();
  await snap("mvp-home");
  await page.locator("[data-action=knowledge-reader]").first().click();
  await snap("mvp-knowledge");
  await page.locator("[data-surface] [data-action=lab]").click();
  await snap("mvp-lab");
  let s = {
    ...initialState(),
    connectedEnabled: true,
    connected: emptyConnected(),
  };
  const act = (type, extra = {}) => {
    s = transition(s, { type, ...extra });
  };
  act("ENTER_FLOOR", { id: "studio" });
  act("MISSION_NEW");
  act("MISSION_EDIT", {
    field: "intent",
    value:
      "Give a new partner a clear first action, with a keyboard-accessible checklist.",
  });
  act("MISSION_STEP", { stage: "shape" });
  for (const id of ["outcome", "scope", "evidence"])
    act("MISSION_CONFIRM", { id, inline: true });
  act("MISSION_STEP", { stage: "review" });
  act("CONNECTED_SOURCE");
  act("CONNECTED_CANDIDATE");
  const install = async () => {
    await page.close();
    page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    await page.addInitScript(
      ({ key, s }) => {if(window===window.top)localStorage.setItem(key, JSON.stringify(s));},
      { key: STORAGE_KEY, s },
    );
    await page.goto(origin);
    await page.locator("[data-action=mission-open]:visible").first().click();
  };
  await install();
  await snap("mvp-paper");
  act("MISSION_APPROVE", { revision: currentMission(s).revision });
  for (
    let i = 0;
    i < 100 && currentMission(s).execution.state === "running";
    i++
  )
    act("MISSION_ADVANCE");
  act("CONNECTED_LEARNING");
  await install();
  await page
    .getByRole("button", { name: "Inspect output & evidence ↗" })
    .click();
  await snap("mvp-outputs");
  await page.locator('.connected-artifact summary').first().click();
  await page.locator('.connected-artifact').first().scrollIntoViewIfNeeded();
  await snap("mvp-result-detail");
  await page.locator('[data-surface] [data-action=library]').click();
  await snap("mvp-library");
  await page.locator('[data-surface] [data-action=review-wall]').click();
  await snap("mvp-review-queue");
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole("button", { name: "Back to floor →",exact:true }).click();
  await snap("mvp-mobile-home");
  await page.locator("[data-action=lab]").first().click();
  await snap("mvp-mobile-lab");
  console.log(`Synthetic reference screenshots: ${output}`);
} finally {
  await browser.close();
}
