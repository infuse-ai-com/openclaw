import {welcomeSettings,openWelcome} from './onboarding.js';
import {createAppearance} from './appearance.js';
import {skillsWorkspace,createSkillsController} from './agent-directory.js';
import {companyToolsWorkspace} from './skill-guides.js';
import {focusMissionChat} from './mission-chat.js';
import {createInspectionController} from './inspection-controller.js';
import {artifactWorkspace} from './artifact-workspace.js';
import './inspection.css';
import { missionDisplayTitle, englishMissionSummary } from './simulation/mission-copy.js';
import { desktopSurface, createDesktopController } from './my-screen.js';
import './my-screen.css';
import { pageHeader } from '@studio/ui/workspace';
import { switchWorkspaceProject, missionWorkspaceTabs, canonicalWorkspaceState } from './workspace-navigation.js';
import { workspaceSidebar, initialWorkspaceState, sidebarCollapsed, SIDEBAR_PREFERENCE_KEY } from './workspace-sidebar.js';
import {createConnectedController} from './connected-controller.js';
import { canManage, partner } from './simulation/reference-catalog.js';
import { workCollection } from './work-results.js';
import {connectedSurface, fixtures, accessState} from './connected-ui.js';
import {emptyConnected, connected, canDecide} from './simulation/connected.js';
import './connected.css';
import { savedKnowledgeSurface, peopleWorkspace } from './knowledge-ui.js';
import { createKnowledgeController } from './knowledge-controller.js';
import './knowledge.css';
import { founderSurface } from './founder-ui.js';
import { myDeskSurface } from './my-desk.js';
import { createMyDeskController } from './my-desk-controller.js';
import './founder.css';
import { deliverySurface } from './delivery-ui.js';
import { deliveryMarkdown, deliveryExample } from './simulation/deliveries.js';
import './delivery.css';
import { operationsSurface } from './operations-ui.js';
import { checksForFloor, CHECK_SCHEDULES, checkConfigValid, checkCategory } from './simulation/operations.js';
import './operations.css';
import { floorWorkspaceSurface } from './floor-workspaces.js';
import './floor-workspaces.css';
import { openWhiteboard } from './whiteboard.js';
import { reviewReadiness } from './review-ui.js';
import './planning.css';
import { planIssues, planFeedbackCurrent } from './simulation/mission-planning.js';
import './shaping.css';
import { feedbackCurrent } from './scenarios/mission-companion.js';
import './missions.css';
import './mission-board.css';
import './review.css';
import { missionSurface } from './mission-ui.js';
import { currentMission, missionPendingLabel, missionReady, missionStage, createdMissionMarkdown, MISSION_SECTIONS, MISSION_LABELS } from './simulation/missions.js';
import { icons } from '@studio/ui/icons';
import { OFFICE, OFFICE_ZONES } from './scenarios/catalog.js';
import { allFloors, companyPeople, floorPeople, projectFloor, residentFor, modelLabel } from './simulation/company.js';
import { floorSetupSurface, projectSurface } from './floor-setup.js';
import { personPresence } from './simulation/presence.js';
import { STORAGE_KEY, initialState, restoreState, transition, phaseLabel } from './simulation/model.js';


const $=selector=>document.querySelector(selector);
const esc=value=>String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
const person=id=>companyPeople(state).find(p=>p.id===id);
const avatar=id=>`<span class="avatar avatar--${id.startsWith('guest-')?'guest':id}" aria-hidden="true"><i></i></span>`;
const btn=(text,action,kind='secondary',extra='')=>`<button class="${kind}" data-action="${action}" ${extra}>${text}</button>`;
const founderViews={};
const founderView=()=>founderViews[partner(state)]??=({filter:'attention',selected:null,note:'',owner:'emon'});
const deliveryViews={};
const deliveryView=()=>deliveryViews[currentMission(state)?.id]??=({revision:'latest',compare:false,anchor:'proposal',draft:'',proposal:'',editId:null});
const operationViews={};
const operationView=()=>operationViews[state.floor]??=( {selected:'backup',filter:'all',outcome:'healthy',history:false,draft:null,editId:null,notice:''} );
function focusOperation(){const target=$('#ops-detail-title');target?.focus({preventScroll:true});if(window.innerWidth<=1150)target?.scrollIntoView({block:'start'});}
const missionBoardView={mode:null,history:false,layout:'board',filter:'all',examplePriorities:{}};
let freeboard=null,welcome=null;
function showWelcome(){
 if(welcome)return;
 world?.pause(true);
 welcome=openWelcome({owner:partner(state),onClose:()=>{welcome=null;render();},onComplete:()=>{welcome=null;open('founder-desk');}});
}
function showFreeboard(){
  if(freeboard)return;
  const trigger=document.activeElement;world?.pause(true);document.body.classList.add('whiteboard-open');
  freeboard=openWhiteboard({floor:allFloors(state).find(f=>f.id===state.floor),onClose:()=>{freeboard=null;document.body.classList.remove('whiteboard-open');world?.pause(Boolean(state.surface));if(trigger?.isConnected)trigger.focus({preventScroll:true});else restoreFocus();}});
}
const appearance=createAppearance({onChange:()=>render()});
let sidebarPreference=null;
try { sidebarPreference=localStorage.getItem(SIDEBAR_PREFERENCE_KEY); } catch { /* Keep navigation usable without storage. */ }
let loaded;
try {loaded=restoreState(localStorage.getItem(STORAGE_KEY));}catch{loaded={state:initialState(),notice:'Browser storage is unavailable. You can still explore and download your mission.'};}
let state=loaded.state,storageNotice=loaded.notice,saveTimer,returnFocus=null,world,floorExplorer;
state.connectedEnabled=true;state.connected??=emptyConnected();
state=initialWorkspaceState(state);
let contributionsUI=null;
if(!import.meta.env.DEV&&state.surface==='contributions')state={...state,surface:'missions'};
if(import.meta.env.DEV)import('./contributions-prototype.js').then(({createContributionsPrototype})=>{
  contributionsUI=createContributionsPrototype({icons});
  if(new URLSearchParams(location.search).get('prototype')==='contributions')state=transition(state,{type:'OPEN',surface:'contributions'});
  if(state.surface==='contributions')render();
});
const connectedUI=createConnectedController({getState:()=>state,dispatch,render,open,focus:focusSurface});
const inspectionUI=createInspectionController({getState:()=>state,dispatch,render,open});
if(loaded.state.surface==='connected-output')inspectionUI.view().section='evidence';
const desktopUI=createDesktopController({getOwner:()=>partner(state),isVisible:()=>state.surface==='founder-desk'&&!deskUI.view().inbox&&deskUI.view().panelOpen&&deskUI.view().selected==='monitor',render:renderDesktop});
const desktopHtml=()=>desktopSurface(partner(state),desktopUI.view(),icons,{embedded:true});
const deskUI=createMyDeskController({getState:()=>state,getDesktopHtml:desktopHtml,icons});
const skillsUI=createSkillsController({render,open});
const knowledgeUI=createKnowledgeController({getState:()=>state,dispatch,render,open,focus:focusSurface,openKnowledge:tab=>{connectedUI.view().kb.screen=tab==='learning'?'learning':'saved';open('knowledge-reader');}});

function notice(text){const el=$('[data-notice]');el.innerHTML=text?`<span>${esc(text)}</span><button data-action="dismiss-notice" aria-label="Dismiss notice">×</button>`:'';$('[data-notice]').hidden=!text;}
function persist(){clearTimeout(saveTimer);saveTimer=setTimeout(()=>{try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch{notice('Your demo is running in memory. Browser storage is unavailable; download the paper to keep it.');}},120);}
function dispatch(event,{quiet=false}={}) {
  const old=state;state=transition(state,event);if(old===state)return;
  if(state.surface==='connected-output')inspectionUI.view().section='evidence';
  state=canonicalWorkspaceState(state);
  if(event.type==='RESET'){state.connectedEnabled=true;state.connected=emptyConnected();}
  if(['denied','loading','expired','signed-out'].includes(connected(state).mode)&&!state.surface)state.surface='ideas';
  persist();
  if(!quiet){render();if(event.type==='CLOSE')restoreFocus();else if(['OPEN','SECTION','APPROVE_PAPER','CONFIRM_SQUAD','RESOLVE','MISSION_NEW','MISSION_SELECT','MISSION_STEP','MISSION_SECTION','MISSION_CONFIRM','MISSION_DEFER','MISSION_APPROVE','MISSION_LIST','MISSION_OPEN','MISSION_DELIVERY_OPEN','MISSION_REVISE','MISSION_FOLLOWUP'].includes(event.type)&&!event.inline)focusSurface();}
  else updateLiveContent();
  if(event.type==='MISSION_SECTION'&&currentMission(state)?.status==='draft')$(`#mission-${event.id}`)?.focus();
  if(['MISSION_SECTION','MISSION_CONFIRM','MISSION_DEFER'].includes(event.type)&&currentMission(state)?.stage==='shape'){
    const inspector=$('.mf-inspector');if(inspector)inspector.scrollTop=0;
    const body=$('.mf-shape-body');if(body&&window.innerWidth<=760)body.scrollTop=0;
  }
}
function focusSurface(){const heading=$('[data-surface] h1')||$('[data-surface] h2');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}}
function restoreFocus(){const visible=selector=>[...document.querySelectorAll(selector)].find(el=>el.getClientRects().length&&!el.closest('[inert]'));(returnFocus&&visible(returnFocus)||visible('[data-action="navigate"]'))?.focus({preventScroll:true});}
function open(surface,object,personId){
  if(surface==='my-screen')surface='founder-desk';
  if(surface==='founder-desk')deskUI.view().inbox=false;
  if(state.peekPerson){returnFocus??=`[data-peek-person="${state.peekPerson}"]`;}else if(!state.surface){const el=document.activeElement;const attr=['data-action','data-object','data-floor','data-scene-object'].find(key=>el?.hasAttribute(key));const region=['.mission-bar','.icon-rail','.floor-team','.floor-workspace-links','.scene-status','.world-heading','.app-header'].find(selector=>el?.closest(selector));returnFocus=attr?`${region?region+' ':''}[${attr}="${el.getAttribute(attr)}"]`:object?`[data-object="${object}"]`:null;}
  if(surface==='artifact'&&currentMission(state)?.execution){open('connected-output');return;}
  if(['board','squad','activity','artifact'].includes(surface)){
    const mission=currentMission(state);
    if(mission){dispatch({type:'MISSION_OPEN'});if(mission.status==='draft'&&surface==='squad')dispatch({type:'MISSION_STEP',stage:'squad'});return;}
    dispatch({type:'MISSION_LIST'});return;
  }
  dispatch({type:'OPEN',surface,object,person:personId});
}
function objectAction(object){
  if(!object)return;
  if(object==='whiteboard'){showFreeboard();return;}
  if(object==='entrance'){dispatch({type:'BUILDING'});return;}
  if(floorPeople(state).some(p=>p.id===object)){inspectPerson(object);return;}
  const map={founder:'founder-desk',team:'people',shelf:'artifacts',review:'review-wall',operations:'operations',lounge:'people'};
  open(map[object]||'floor-activity',object);
}
function inspectPerson(id){
  returnFocus=document.activeElement?.matches(`[data-peek-person="${id}"]`)?`.floor-team [data-peek-person="${id}"]`:`[data-person-label="${id}"],.floor-team [data-peek-person="${id}"]`;
  dispatch({type:'INSPECT_PERSON',id});
  const heading=$('#peek-name');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}
}
function peopleStrip(){return `<nav class="floor-team" aria-label="People on this floor"><span>YOUR PEOPLE</span>${floorPeople(state).map(p=>{const presence=personPresence(state,p.id);return `<button data-peek-person="${p.id}" data-tone="${presence.tone}" aria-label="Inspect ${esc(p.name)}: ${presence.label}" aria-pressed="${state.peekPerson===p.id}"><i aria-hidden="true"></i>${esc(p.name)}</button>`;}).join('')}</nav>`;}
function personPeek(){const p=person(state.peekPerson);if(!p)return '';const presence=personPresence(state,p.id),resident=residentFor(state,p.id),config=currentMission(state)?.config[p.id];return `<button class="peek-close" data-action="dismiss-person" aria-label="Close person details">×</button><div class="peek-person">${avatar(p.id)}<div><span class="eyebrow">YOUR PEOPLE</span><h2 id="peek-name">${esc(p.name)}</h2><p>${esc(p.role)}</p></div></div><span class="presence-badge" data-tone="${presence.tone}">${presence.label}</span><p class="peek-task">${esc(presence.task)}</p>${presence.output?`<div class="peek-output"><span>HANDOFF</span><p>${esc(presence.output)}</p></div>`:''}<p class="peek-capabilities">${config?`${config.skills.length} mission capabilities · ${esc(config.model)} / ${config.reasoning} · demo preset`:resident?`${resident.capabilities.length} floor capabilities · ${esc(modelLabel(resident.llm))} / ${resident.reasoning} reasoning · demo`:p.skills.length?`${(currentMission(state)?.config[p.id]?.skills||state.mission.capabilities[p.id]||p.skills).length} mission capabilities · ${state.floor==='studio'&&state.mission.squad.includes(p.id)?'In this squad':'Available to invite'}`:'Direction · judgment · acceptance'}</p>${p.id==='emon'?btn('Start grilling with Emon →','mission-new','primary'):''}${btn(p.id==='fito'?'Inspect your next decision →':'Open capability sheet ↗','peek-capabilities','secondary')}`;}
function updateLiveContent(){
  const m=currentMission(state);
  if(m&&state.surface==='mission-flow'){
    for(const x of MISSION_SECTIONS){const node=$(`[data-mission-node="${x.id}"]`);if(node)node.textContent=m.content[x.id]||'This section has not been defined yet.';const label=$(`[data-mission-state="${x.id}"]`);if(label)label.textContent=m.confirmed.includes(x.id)?'✓ Confirmed':m.deferred.includes(x.id)?'— Deferred':m.content[x.id]?(m.origins[x.id]==='suggestion'?'○ Emon proposal · review':'○ Your words · confirm'):'○ To be defined';}
    for(const section of MISSION_SECTIONS){
      const b=$(`[data-confirm-section="${section.id}"]`);if(b){b.disabled=!m.content[section.id].trim()||m.confirmed.includes(section.id);b.textContent=m.confirmed.includes(section.id)?'Confirmed':'Confirm';}
      const defer=$(`[data-defer-section="${section.id}"]`);if(defer)defer.disabled=m.deferred.includes(section.id);
    }
    const planSend=$('[data-send-plan-feedback]');if(planSend)planSend.disabled=!m.planning?.draft.trim()||Boolean(m.planning?.pending);
    const planApply=$('[data-action="plan-chat-apply"]');if(planApply)planApply.disabled=!planFeedbackCurrent(m);
    const planConflict=$('[data-plan-conflict]');if(planConflict)planConflict.hidden=planFeedbackCurrent(m);
    const planRetry=$('[data-action="plan-chat-retry"]');if(planRetry)planRetry.hidden=planFeedbackCurrent(m);
    const issues=$('[data-plan-issues]');if(issues){const list=planIssues(m);issues.hidden=!list.length;issues.innerHTML=list.map(x=>`<p>${esc(x)}</p>`).join('');}
    const send=$('[data-send-feedback]');if(send)send.disabled=!m.shaping?.draft.trim()||Boolean(m.shaping?.pending);
    const apply=$('[data-action="mission-chat-apply"]');if(apply)apply.disabled=!feedbackCurrent(m);
    const conflict=$('[data-feedback-conflict]');if(conflict)conflict.hidden=feedbackCurrent(m);
    const retry=$('[data-action="mission-chat-retry"]');if(retry)retry.hidden=feedbackCurrent(m);
    const summary=$('[data-mission-summary]');if(summary)summary.textContent=englishMissionSummary(m.summary);
    const count=$('[data-mission-missing]');if(count)count.textContent=missionPendingLabel(m);
    for(const rev of document.querySelectorAll('[data-mission-revision],[data-paper-revision]'))rev.textContent=m.revision;
    for(const copy of document.querySelectorAll('[data-review-copy],[data-paper-field]'))copy.textContent=m.content[copy.dataset.reviewCopy||copy.dataset.paperField]||'To be defined.';
    for(const label of document.querySelectorAll('[data-paper-state]')){const id=label.dataset.paperState;label.textContent=m.confirmed.includes(id)?'Confirmed':m.deferred.includes(id)?'Explicitly deferred':'Awaiting confirmation';}
    const readiness=$('[data-review-readiness]');if(readiness)readiness.innerHTML=reviewReadiness(state,m);
    for(const action of ['mission-approve','mission-hold']){const b=$(`[data-action="${action}"]`);if(b)b.disabled=!missionReady(m);}
    const confirm=$('[data-action="mission-confirm"]');if(confirm)confirm.disabled=!m.content[m.section].trim();
    const idea=$('[data-needs-idea]');if(idea)idea.disabled=!m.content.intent.trim();
    const name=$('[data-mission-title-warning]');if(name)name.hidden=Boolean(m.title.trim());
    const paperTitle=$('.mf-paper > h2');if(paperTitle)paperTitle.textContent=m.title||'Untitled mission';
    $('[data-mission-name]').textContent=m.title||'A new mission';
    const titleHint=$('[data-title-hint]');if(titleHint&&m.stage!=='idea')titleHint.textContent=m.origins.title==='suggestion'?'A demo suggestion from Emon. You can refine or change it.':'You can refine the name or change it entirely.';
    $('[data-live]').textContent=englishMissionSummary(m.summary);return;
  }

  $('[data-live]').textContent=englishMissionSummary(m?.summary)||'Workspace updated.';
}
function heading(){
  const floor=allFloors(state).find(f=>f.id===state.floor);
  if(state.view==='building')return `<h1>Office</h1><p>Choose a project floor.</p>`;
  return `<div class="floor-identity"><span>FLOOR ${esc(floor.number)} / ${projectFloor(state)?'YOUR PROJECT':'DEMO PROJECT'}</span></div><h1>${esc(floor.title)}<span class="company-dot">.</span></h1><p>${state.floor==='studio'?'A shared space to shape ideas and move the work forward.':esc(floor.description)}</p>`;
}
function missionBar(){
  const switcher=`<div class="mission-switch-row">${btn('Start grilling →','mission-new','mission-switch')}</div>`;
  const active=currentMission(state);
  if(state.view==='floor'&&active)return `${peopleStrip()}<div class="mission-context"><small>${(active.execution?(['closed','cancelled'].includes(active.execution.state)?active.execution.state:active.execution.held?'On hold':active.execution.state):MISSION_LABELS[active.status])}${active.startup==='hold'?' · on hold':''}</small><strong>${esc(missionDisplayTitle(active)||'A new mission')}</strong></div>${switcher}${btn(active.status==='draft'?'Continue mission →':'View mission →','mission-open','primary')}`;

  if(state.view==='building')return '';
  if(projectFloor(state))return `${peopleStrip()}<div class="bar-person">${avatar('fito')}<span><strong>Your project has a home.</strong><small>${projectFloor(state).residents.length} resident agents · Ready to shape its first mission</small></span></div>${switcher}${btn('Start grilling →','mission-new','primary')}${btn('Open project brief ↗','project-brief','mission-switch')}`;
  if(state.floor!=='studio')return `${peopleStrip()}<div class="bar-person">${avatar('kapiteky')}<span><strong>${state.floor==='client'?'A proposal is waiting for a decision.':'A quiet floor, ready for an opportunity.'}</strong><small>Shared team · this project keeps its own sources and prototype scenario.</small></span></div>${switcher}${btn('Start grilling →','mission-new','primary')}`;
  return `${peopleStrip()}${switcher}<div class="bar-person">${avatar('emon')}<span><strong>A shared team. Your next useful outcome.</strong><small>Start with an idea, then shape and review the mission.</small></span></div>${btn('Start grilling →','connected-ideas','primary')}`;
}
function render(){
  const openDetails=[...document.querySelectorAll('details[data-preserve-details][open]')].map(el=>el.dataset.preserveDetails);
  const scrollables=['.md-scroll','.md-panel','.inspection-workspace','.connected-surface','.connected-execution','.mr-brief','.mr-decision-body','.mr-scroll','.mp-scroll','.ms-board-scroll','.ms-chat-dock','.mission-chat-body','.mf-scroll','.mf-canvas','.mf-inspector','.mf-shape-body','.review-layout','.squad-layout','.capability-sheet','.activity-layout','.settings-content','.people-layout','.floor-setup-scroll','.floor-workspace-content','.ops-scroll','.dr-scroll','.dr-wall','.fd-scroll','.kl-scroll','.skills-scroll'];
  const sidebarTop=$('.workbench-nav')?.scrollTop||0;
  const boardLeft=$('.mb-board')?.scrollLeft||0;
  const scrollPositions=scrollables.map(selector=>[selector,$(selector)?.scrollTop||0]);
  const active=document.activeElement;const activeAttribute=['data-inspect','data-inspect-select','data-workspace-project','data-connected','data-pref','data-review-jump','data-action','data-squad','data-skill','data-preset','data-person-detail','data-accept','data-annotation-section','data-peek-person','data-floor-person','data-floor-resident','data-resident-capability','data-resident-preset','data-mission-member','data-mission-config','data-mission-skill','data-board-filter','data-board-layout','data-board-mode','data-board-priority','data-confirm-section','data-defer-section','data-feedback-anchor','data-chat-example','data-ops-select','data-ops-filter','data-ops-toggle','data-ops-run','data-ops-history','data-ops-edit','data-ops-attention','data-delivery-anchor','data-delivery-edit-note','data-founder-select','data-founder-filter','data-expert-link','data-knowledge-review'].find(k=>active?.hasAttribute(k));
  let focusSelector=active?.id?`#${CSS.escape(active.id)}`:activeAttribute?`[${activeAttribute}="${CSS.escape(active.getAttribute(activeAttribute))}"]`:null;
  if(activeAttribute==='data-inspect')for(const key of ['data-value','data-id'])if(active.hasAttribute(key))focusSelector+=`[${key}="${CSS.escape(active.getAttribute(key))}"]`;
  const activeMission=currentMission(state);
  const screenKey=state.surface==='mission-flow'&&activeMission?`${activeMission.id}:${missionStage(activeMission)}`:state.surface||'';
  const sameScreen=document.body.dataset.missionScreen===screenKey;

  const peek=$('aside[data-person-peek]');peek.hidden=!state.peekPerson;peek.innerHTML=personPeek();
  document.body.dataset.inspectedPerson=state.peekPerson||'';
  $('[data-world-heading]').innerHTML=heading();$('[data-mission-bar]').innerHTML=missionBar();
  $('[data-mission-bar]').hidden=state.view==='building';$('.world-legend').hidden=state.view==='building';
  $('[data-scene-status]').innerHTML=state.view==='floor'?`<span class="status-signal"></span>${currentMission(state)?(currentMission(state).execution?.state||MISSION_LABELS[currentMission(state).status]):state.floor==='studio'?phaseLabel(state):allFloors(state).find(f=>f.id===state.floor).status}<button data-action="settings">Studio onboarding ↗</button>`:'';
  const surface=$('[data-surface]');surface.hidden=!state.surface;
  if(state.surface){surface.innerHTML=(['missions','floor-activity'].includes(state.surface)?missionWorkspaceTabs(state,missionBoardView.history):'')+surfaceContent();surface.className=`surface surface--${state.surface}`;connectedUI.restore();if(!canDecide(state)||!canManage(state,currentMission(state))){if(!canDecide(state))for(const el of surface.querySelectorAll('.kb-saved-content input,.kb-saved-content textarea,.kb-saved-content select,.kb-saved-content button'))el.disabled=true;for(const el of surface.querySelectorAll('[data-mission-field],[data-mission-step],[data-action=mission-approve],[data-connected-gate]'))el.disabled=true;}}
  deskUI.mount();
  if(state.surface==='contributions')contributionsUI?.mount();
  if(state.surface==='people')import('./agent-showcase.js').then(({mountAgentShowcase})=>mountAgentShowcase(state));
  $('[data-action=home-camera] span').textContent=state.view==='building'?'Fit building':'View full floor';
  document.body.dataset.missionPhase=currentMission(state)?.status||state.mission.phase;document.body.dataset.view=state.view;document.body.dataset.activeSurface=state.surface||'';
  const hidden=Boolean(state.surface);$('#workspace').inert=hidden;$('.app-header').inert=false;
  const collapsed=sidebarCollapsed(sidebarPreference,state.surface);
  document.body.classList.toggle('sidebar-collapsed',collapsed);
  $('[data-workbench-sidebar]').innerHTML=workspaceSidebar(state,icons,collapsed,appearance.preference());
  $('.workbench-nav').scrollTop=sidebarTop;
  $('.workbench-menu').innerHTML=icons.list;
  $('.skip-link').href=hidden?'#work-content':'#workspace';
  document.body.dataset.missionScreen=screenKey;
  if(sameScreen){for(const key of openDetails){const detail=document.querySelector(`[data-preserve-details="${CSS.escape(key)}"]`);if(detail)detail.open=true;}for(const [selector,top] of scrollPositions){const element=$(selector);if(element)element.scrollTop=top;}if(focusSelector)$(focusSelector)?.focus({preventScroll:true});}
  if(sameScreen&&$('.mb-board'))$('.mb-board').scrollLeft=boardLeft;
  for(const selector of ['.mf-stages','.mf-nodes']){const nav=$(selector),selected=nav?.querySelector('[aria-current]');if(nav&&selected&&nav.scrollWidth>nav.clientWidth)nav.scrollLeft=selected.offsetLeft-nav.offsetLeft-(nav.clientWidth-selected.offsetWidth)/2;}
  floorExplorer?.sync(state);world?.update(state);world?.pause(hidden||Boolean(freeboard));$('[data-live]').textContent=['denied','loading','expired','signed-out'].includes(connected(state).mode)?'Workspace access unavailable':state.surface==='missions'?($('.mb-bottom>p')?.textContent||'Mission workspace'):englishMissionSummary(currentMission(state)?.summary||state.mission.summary);
  $('[data-nav-items]').innerHTML=`${[['founder-desk','My desk'],['people','Agents'],['skills','Skills'],['tools','Tools'],['building','Office · Building'],['workspace-office','Project floor'],['freeboard','Whiteboard'],['ideas','Grilling'],['mission-list','Missions'],['mission-history','Missions · Closed'],['review-wall','Review'],['knowledge-reader','Knowledge'],['lab','Prototype'],['artifacts','Artifacts'],['floor-activity','Missions · Activity'],['operations','Operations'],['settings','Studio onboarding']].map(([action,label])=>`<button data-nav-surface="${action}">${label}</button>`).join('')}${allFloors(state).toSorted((a,b)=>Number(a.number)-Number(b.number)).map(f=>`<button data-nav-floor="${f.id}"><span>${f.number}</span><strong>${esc(f.title)}</strong><small>Project floor</small></button>`).join('')}${btn('＋ New project','nav-new-floor')}<button data-nav-surface="reset">Reset demo</button>`;
}
function surfaceHeader(kicker,title,tools=''){return pageHeader({eyebrow:kicker,title,actionsHtml:tools});}

function surfaceContent(){
  if(['knowledge-reader','lab','ideas'].includes(state.surface)){const kb=connectedUI.view().kb;return connectedSurface(state,connectedUI.view(),icons,state.surface==='knowledge-reader'&&['saved','learning'].includes(kb.screen)?savedKnowledgeSurface(state,knowledgeUI.view(),kb.screen==='learning'):'');}
  if(accessState(state))return accessState(state)+fixtures(state);

  if(state.surface==='artifacts')return artifactWorkspace(state,inspectionUI.artifacts())+fixtures(state);
  if(state.surface==='founder-desk')return (deskUI.view().inbox?founderSurface(state,founderView(),icons):myDeskSurface(state,deskUI.view(),icons,desktopHtml()))+fixtures(state);
  if(state.surface==='review-wall')return workCollection(state,icons);
  if(state.surface==='delivery-review')return deliverySurface(state,deliveryView());
  if(state.surface==='operations')return operationsSurface(state,operationView(),icons);
  if(state.surface==='skills')return skillsWorkspace(state,skillsUI.view(),icons);
  if(state.surface==='tools')return companyToolsWorkspace(skillsUI.view(),icons);
  if(import.meta.env.DEV&&state.surface==='contributions')return contributionsUI?.html()||'<p>Opening Activity prototype…</p>';
  if(state.surface==='people')return peopleWorkspace(state,knowledgeUI.view().expert,icons);
  if(state.surface==='floor-activity')return floorWorkspaceSurface(state,icons);
  if(['missions','mission-flow'].includes(state.surface))return missionSurface(state,{...missionBoardView,inspection:inspectionUI.view()},icons)+fixtures(state);
  if(state.surface==='floor-setup')return floorSetupSurface(state);
  if(state.surface==='project'&&projectFloor(state))return projectSurface(state);
  if(state.surface==='settings')return settingsSurface();
  return missionSurface({...state,surface:'missions'},missionBoardView,icons);
}
function renderDesktop(){
  const focused=document.activeElement?.closest('[data-desktop-action]');
  const action=focused?.dataset.desktopAction,value=focused?.dataset.desktopValue;
  deskUI.refresh();
  if(focused){
    const controls=[...document.querySelectorAll('[data-desktop-action]')];
    const fallback=desktopUI.view().status==='connecting'?'disconnect':desktopUI.view().status==='connected'?'tool':'connect';
    (controls.find(el=>el.dataset.desktopAction===action&&el.dataset.desktopValue===value)||controls.find(el=>el.dataset.desktopAction===fallback))?.focus({preventScroll:true});
  }
}
function settingsSurface(){return `${surfaceHeader('YOUR WORKSPACE','Profile & settings')}<div class="settings-content office-guide">${welcomeSettings(partner(state))}<h2>${OFFICE.label}</h2><p class="surface-intro">Define → make → review. One generous promenade connects the work, with a familiar place for every conversation.</p><p class="small-copy">The same office on every project floor. The people, brief and work make it yours.</p><p class="small-copy">Explore the building or floor: drag or use the arrow keys to pan, scroll or use + / − to zoom, and use Fit to restore the view. Tab to a project entrance and press Enter to visit its floor.</p><div class="office-zones">${OFFICE_ZONES.map((z,i)=>`<button data-office-zone="${z.id}"><span class="eyebrow">0${i+1}</span><strong>${z.label}</strong><p>${z.description}</p><span>Open →</span></button>`).join('')}</div>${btn('Open project floor ↗','workspace-office','primary')}</div>`;}

function download(text,name='studio-mission.md'){const url=URL.createObjectURL(new Blob([text],{type:'text/markdown;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),500);}
const missionEvent=(type,extra={})=>{if(state.peekPerson)returnFocus=window.innerWidth>800?`[data-person-label="${state.peekPerson}"]`:`[data-peek-person="${state.peekPerson}"]`;else if(!state.surface){const action=document.activeElement?.dataset.action;returnFocus=action?`[data-action="${action}"]`:'[data-action="mission-list"]';}dispatch({type,...extra});};
const actions={
  'onboarding-start':showWelcome,
  'onboarding-look':showWelcome,
  'collapse-sidebar':()=>{
    sidebarPreference=sidebarCollapsed(sidebarPreference,state.surface)?'expanded':'collapsed';
    try { localStorage.setItem(SIDEBAR_PREFERENCE_KEY,sidebarPreference); } catch { /* Session preference still works. */ }
    render();
    $('[data-action=collapse-sidebar]')?.focus({preventScroll:true});
  },
  'toggle-sidebar':()=>{const expanded=document.body.classList.toggle('sidebar-open');$('.workbench-menu').setAttribute('aria-expanded',String(expanded));if(expanded)$('[data-workbench-sidebar] .workbench-brand').focus();},
  'knowledge-home':()=>{connectedUI.view().kb.screen='home';open('knowledge-reader');},
  'knowledge-saved':()=>{connectedUI.view().kb.screen='saved';open('knowledge-reader');},
  'knowledge-learning':()=>{connectedUI.view().kb.screen='learning';open('knowledge-reader');},
  'workspace-office':()=>{dispatch({type:'ENTER_FLOOR',id:state.floor});$('#workspace').focus();},
  'contributions':()=>{if(import.meta.env.DEV)open('contributions');},
  'connected-ideas':()=>open('ideas'),
  'knowledge-reader':()=>open('knowledge-reader'),
  lab:()=>open('lab'),
  'connected-output':()=>open('connected-output'),
  'plan-add':()=>{dispatch({type:'MISSION_PLAN_ADD'});const step=currentMission(state)?.planning?.steps.at(-1);if(step)$(`#plan-${step.id}-title`)?.focus();},
  'plan-chat-apply':()=>dispatch({type:'MISSION_PLAN_CHAT_APPLY'}),
  'plan-chat-discard':()=>dispatch({type:'MISSION_PLAN_CHAT_DISCARD'}),
  'plan-chat-retry':()=>dispatch({type:'MISSION_PLAN_CHAT_RETRY'}),
  'project-brief':()=>open('project'),
  'mission-list':()=>{missionBoardView.history=false;missionEvent('MISSION_LIST');},
  'mission-history':()=>{Object.assign(missionBoardView,{history:true,mode:'mine',filter:'all'});missionEvent('MISSION_LIST');},
  'mission-chat-apply':()=>dispatch({type:'MISSION_CHAT_APPLY'}),
  'mission-chat-discard':()=>dispatch({type:'MISSION_CHAT_DISCARD'}),
  'mission-chat-retry':()=>dispatch({type:'MISSION_CHAT_RETRY'}),
  'mission-new':()=>{missionBoardView.history=false;missionBoardView.mode='mine';missionBoardView.filter='all';open('ideas');},
  'mission-open':()=>missionEvent('MISSION_OPEN'),
  'mission-example':()=>dispatch({type:'MISSION_EXAMPLE'}),
  'mission-confirm':()=>dispatch({type:'MISSION_CONFIRM'}),
  'mission-defer':()=>dispatch({type:'MISSION_DEFER'}),
  'mission-approve':()=>dispatch({type:'MISSION_APPROVE',revision:currentMission(state)?.revision,start:true}),
  'mission-hold':()=>dispatch({type:'MISSION_APPROVE',start:false}),
  'mission-revise':()=>dispatch({type:'MISSION_REVISE'}),
  'mission-start':()=>dispatch({type:'MISSION_START'}),
  'mission-advance':()=>dispatch({type:'MISSION_ADVANCE'}),
  'founder-desk':()=>open('founder-desk','founder'),
  'desk-inbox':()=>{deskUI.view().inbox=true;render();focusSurface();},
  'desk-panel-close':()=>deskUI.close(),
  'desk-home':()=>{deskUI.view().inbox=false;render();focusSurface();},
  'review-wall':()=>open('review-wall','review'),
  'delivery-open':()=>{dispatch({type:'MISSION_DELIVERY_OPEN'});focusSurface();},
  'delivery-mission':()=>dispatch({type:'MISSION_OPEN'}),
  'delivery-latest':()=>{deliveryView().revision='latest';render();},
  'delivery-export':()=>download(deliveryMarkdown(currentMission(state)),'studio-delivery.md'),
  'delivery-source':()=>dispatch({type:'MISSION_DELIVERY_SOURCE'}),
  'delivery-revise':()=>{deliveryView().revision='latest';dispatch({type:'MISSION_DELIVERY_REVISE'});},
  'delivery-accept':()=>dispatch({type:'MISSION_DELIVERY_ACCEPT'}),
  'delivery-cancel-note':()=>{Object.assign(deliveryView(),{editId:null,draft:'',proposal:''});render();},
  'delivery-example':()=>{Object.assign(deliveryView(),deliveryExample(currentMission(state)));render();$('#delivery-comment')?.focus();},
  'mission-followup':()=>dispatch({type:'MISSION_FOLLOWUP'}),
  'mission-download':()=>download(createdMissionMarkdown(state),'mission-paper.md'),

  'floor-begin':()=>{returnFocus='[data-action="floor-begin"]';dispatch({type:'FLOOR_BEGIN'});focusSurface();},
  'nav-new-floor':()=>{$('.navigator').close();actions['floor-begin']();},
  'floor-edit':()=>{dispatch({type:'FLOOR_EDIT'});focusSurface();},
  'floor-save':()=>{dispatch({type:'FLOOR_SAVE'});if(!state.surface){const h=$('[data-world-heading] h1');h.tabIndex=-1;h.focus();$('[data-live]').textContent='Project floor saved. Your residents are ready.';}else focusSurface();},
  'guest-begin':()=>{dispatch({type:'GUEST_BEGIN'});$('[data-guest-field="name"]')?.focus();},
  'guest-save':()=>{dispatch({type:'GUEST_SAVE'});$('.floor-errors:not([hidden])')?.scrollIntoView({block:'nearest'});},
  'guest-cancel':()=>dispatch({type:'GUEST_CANCEL'}),
  'dismiss-person':()=>{dispatch({type:'DISMISS_PERSON'});restoreFocus();},
  'peek-capabilities':()=>{const id=state.peekPerson;open(id==='fito'?'founder-desk':'people',id,id);},
  'dismiss-notice':()=>notice(null),building:()=>dispatch({type:'BUILDING'}),'enter-studio':()=>dispatch({type:'ENTER_FLOOR',id:'studio'}),
  freeboard:()=>showFreeboard(),
  'nav-freeboard':()=>{$('.navigator').close();showFreeboard();},
  operations:()=>open('operations','operations'),
  'ops-new':()=>{const v=operationView();v.draft={name:'',description:'',owner:'satwa',category:'infrastructure',schedule:'five',policy:'immediate'};v.editId=null;v.notice='';render();$('#ops-name')?.focus();if(window.innerWidth<=1150)$('#ops-name')?.scrollIntoView({block:'center'});},
  'ops-cancel':()=>{operationView().draft=null;render();focusOperation();},
  'ops-examples':()=>{dispatch({type:'OPS_EXAMPLES'});},
  library:()=>open('library','shelf'),'floor-activity':()=>open('floor-activity','operations'),
  artifacts:()=>open('artifacts'),
  'my-screen':()=>{Object.assign(deskUI.view(),{selected:'monitor',panelOpen:true});open('founder-desk');},
  people:()=>open('people'),skills:()=>open('skills'),tools:()=>open('tools'),settings:()=>open('settings'),owner:()=>open('founder-desk'),
  close:()=>dispatch({type:'CLOSE'}),
  navigate:()=>{for(const menu of document.querySelectorAll('.workbench-popover[open]'))menu.removeAttribute('open');const input=$('[data-nav-search]');input.value='';filterNavigator('');$('.navigator').showModal();input.focus();},'close-nav':()=>$('.navigator').close(),
  'nav-building':()=>{$('.navigator').close();dispatch({type:'BUILDING'});},
  reset:()=>$('.reset-dialog').showModal(),'cancel-reset':()=>$('.reset-dialog').close(),'confirm-reset':()=>{deskUI.reset();desktopUI.reset();inspectionUI.reset();for(const key of Object.keys(founderViews))delete founderViews[key];for(const key of Object.keys(deliveryViews))delete deliveryViews[key];for(const key of Object.keys(operationViews))delete operationViews[key];$('.reset-dialog').close();dispatch({type:'RESET'});notice(null);},
  'zoom-in':()=>world?.zoom(.15),'zoom-out':()=>world?.zoom(-.15),'home-camera':()=>world?.home(),
};
$('.navigator').addEventListener('close',()=>{if(innerWidth<=760)$('.workbench-menu').focus();});
function filterNavigator(query) {
  const term=query.trim().toLocaleLowerCase();
  const buttons=[...document.querySelectorAll('[data-nav-items]>button')];
  for(const button of buttons)button.hidden=!button.textContent.toLocaleLowerCase().includes(term);
  $('[data-nav-empty]').hidden=buttons.some(button=>!button.hidden);
}
// Place flyouts beside their actual trigger, including shorter windows.
document.addEventListener('toggle',e=>{
  const menu=e.target;
  if(!menu.matches?.('.workbench-popover')||!menu.open)return;
  const panel=menu.querySelector('.workbench-popover-panel'),anchor=menu.querySelector('summary').getBoundingClientRect();
  panel.style.top=`${Math.max(12,Math.min(anchor.top,innerHeight-panel.offsetHeight-12))}px`;
  panel.style.bottom='auto';
},true);
document.addEventListener('click',e=>{
  for(const menu of document.querySelectorAll('.workbench-popover[open]'))if(!menu.contains(e.target))menu.removeAttribute('open');
  const b=e.target.closest('button');if(!b||b.disabled)return;
  if(b.dataset.deskObject)deskUI.select(b.dataset.deskObject);
  if(b.dataset.deskCamera)deskUI.cameraAction(b.dataset.deskCamera);
  const fromSidebar=Boolean(b.closest('[data-workbench-sidebar]'));
  const companyProject=b.closest('[data-company-project]')?.dataset.companyProject;
  if(companyProject){state=switchWorkspaceProject(state,companyProject);persist();}
  if(fromSidebar)returnFocus=innerWidth<=760?'[data-action=toggle-sidebar]':b.dataset.action?`[data-workbench-sidebar] [data-action="${b.dataset.action}"]`:null;
  if(b.dataset.workspaceProject){b.closest('details')?.removeAttribute('open');state=switchWorkspaceProject(state,b.dataset.workspaceProject);persist();render();focusSurface();}
  if(b.dataset.studioTheme){const mode=b.dataset.studioTheme;appearance.set(mode);const menu=$('.workbench-profile-menu');menu.open=true;menu.querySelector(`[data-studio-theme="${mode}"]`)?.focus();return;}
  if(b.dataset.sidebarMode){sidebarPreference=b.dataset.sidebarMode;try{localStorage.setItem(SIDEBAR_PREFERENCE_KEY,sidebarPreference);}catch{/* Keep this session usable. */}b.closest('details')?.removeAttribute('open');render();$('.workbench-profile-menu summary')?.focus();}
  if(fromSidebar&&b.dataset.action)b.closest('.workbench-popover')?.removeAttribute('open');
  if(fromSidebar&&state.view==='building'&&b.dataset.action&&!['building','workspace-office','navigate','collapse-sidebar'].includes(b.dataset.action))dispatch({type:'ENTER_FLOOR',id:state.floor});
  if(b.dataset.desktopAction)desktopUI.act(b.dataset.desktopAction,b.dataset.desktopValue);
  if(b.dataset.action)actions[b.dataset.action]?.();
  if(fromSidebar){document.body.classList.remove('sidebar-open');$('.workbench-menu').setAttribute('aria-expanded','false');}
  if(b.dataset.founderFilter){Object.assign(founderView(),{filter:b.dataset.founderFilter,selected:null,note:''});render();}
  if(b.dataset.founderSelect){Object.assign(founderView(),{selected:b.dataset.founderSelect,note:''});render();$('#fd-title')?.focus({preventScroll:true});if(innerWidth<=900)$('#fd-title')?.scrollIntoView({block:'start'});}
  if(b.dataset.founderPropose){dispatch({type:'FOUNDER_PROPOSE',key:b.dataset.founderPropose});focusSurface();}
  if(b.dataset.founderCheck){Object.assign(operationView(),{selected:b.dataset.founderCheck,filter:'all',history:true,draft:null});open('operations','operations');}
  if(b.dataset.founderReopen||b.dataset.founderTakeback){dispatch({type:'FOUNDER_DECIDE',key:b.dataset.founderReopen||b.dataset.founderTakeback,action:b.dataset.founderReopen?'reopen':'take-back',note:'Returned to my desk.'});focusSurface();}
  if(b.dataset.deliveryOpen){dispatch({type:'MISSION_SELECT',id:b.dataset.deliveryOpen});dispatch({type:'MISSION_DELIVERY_OPEN'});focusSurface();}
  if(b.dataset.deliveryAnchor){deliveryView().anchor=b.dataset.deliveryAnchor;render();$('#delivery-comment')?.focus();}
  if(b.dataset.deliveryEditNote){const n=currentMission(state)?.delivery?.notes.find(n=>n.id===b.dataset.deliveryEditNote);if(n){Object.assign(deliveryView(),{editId:n.id,anchor:n.anchor,draft:n.text,proposal:n.proposal});render();$('#delivery-comment')?.focus();}}
  if(b.dataset.opsSelect){const v=operationView();v.selected=v.selected===b.dataset.opsSelect?null:b.dataset.opsSelect;v.history=false;v.notice='';render();}
  if(b.dataset.opsHistory){const v=operationView();v.history=!v.history;render();}
  if(b.dataset.opsAttention){const v=operationView();v.selected=b.dataset.opsAttention;v.filter='all';v.history=false;render();focusOperation();}
  if(b.dataset.opsFilter){operationView().filter=b.dataset.opsFilter;render();}
  if(b.dataset.opsEdit){const job=checksForFloor(state).find(j=>j.id===b.dataset.opsEdit);if(job){const v=operationView();v.editId=job.id;v.draft={...structuredClone(job),category:checkCategory(job)};v.notice='';render();$('#ops-name')?.focus();}}
  if(b.dataset.opsToggle){const job=checksForFloor(state).find(j=>j.id===b.dataset.opsToggle);operationView().notice=job?.enabled?'Schedule paused locally. Previous failures remain visible.':'Schedule resumed in the demo. No real job has been scheduled.';dispatch({type:'OPS_TOGGLE',id:b.dataset.opsToggle});}
  if(b.dataset.opsRun){operationView().notice='Simulated run recorded. No external system was checked.';dispatch({type:'OPS_RUN',id:b.dataset.opsRun,outcome:operationView().outcome});}

  if(b.dataset.boardLayout){missionBoardView.layout=b.dataset.boardLayout;render();}
  if(b.dataset.boardFilter){missionBoardView.filter=b.dataset.boardFilter;render();}
  if(b.dataset.boardMode){missionBoardView.mode=b.dataset.boardMode;missionBoardView.filter='all';render();}
  if(b.dataset.boardColumn){const column=$(`[data-column="${b.dataset.boardColumn}"]`);column?.scrollIntoView({block:'nearest',inline:'start',behavior:'instant'});const heading=column?.querySelector('h2');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}}
  if(b.dataset.focusField)$(`#mission-${b.dataset.focusField}`)?.focus();
  if(b.dataset.reviewJump){
    const id=b.dataset.reviewJump;
    if(['intent','references','decisions'].includes(id))$('[data-review-context]').open=true;
    const target=id==='title'?$('#mission-title'):$(`#review-${id}`);target?.scrollIntoView({block:'nearest'});target?.focus({preventScroll:true});
  }
  if(b.hasAttribute('data-review-decision')){const target=$('.mr-decision');target?.scrollIntoView({block:'start'});target?.focus({preventScroll:true});}
  if(b.hasAttribute('data-review-chat'))focusMissionChat('#mission-feedback');
  if(b.dataset.confirmSection){dispatch({type:'MISSION_CONFIRM',id:b.dataset.confirmSection,inline:true});$(`#review-${b.dataset.confirmSection}`)?.focus({preventScroll:true});}
  if(b.dataset.deferSection){dispatch({type:'MISSION_DEFER',id:b.dataset.deferSection,inline:true});$(`#review-${b.dataset.deferSection}`)?.focus({preventScroll:true});}
  if(b.dataset.feedbackAnchor){dispatch({type:'MISSION_CHAT_ANCHOR',anchor:b.dataset.feedbackAnchor});focusMissionChat('#mission-feedback');}
  if(b.dataset.chatExample){dispatch({type:'MISSION_CHAT_EXAMPLE',id:b.dataset.chatExample});focusMissionChat('#mission-feedback');}
  if(b.dataset.missionStep)dispatch({type:'MISSION_STEP',stage:b.dataset.missionStep});
  if(b.dataset.missionSelect)dispatch({type:'MISSION_SELECT',id:b.dataset.missionSelect});
  if(b.dataset.missionSection)dispatch({type:'MISSION_SECTION',id:b.dataset.missionSection});
  if(b.dataset.missionMember)dispatch({type:'MISSION_SQUAD',id:b.dataset.missionMember});
  if(b.dataset.missionSuggestion!==undefined)dispatch({type:'MISSION_SUGGESTION',index:Number(b.dataset.missionSuggestion)});
  if(b.dataset.floorStep){dispatch({type:'FLOOR_STEP',step:b.dataset.floorStep});$('.floor-setup-scroll').scrollTop=0;focusSurface();}
  if(b.dataset.floorPerson)dispatch({type:'FLOOR_PERSON',id:b.dataset.floorPerson});
  if(b.dataset.floorResident)dispatch({type:'FLOOR_RESIDENT',id:b.dataset.floorResident});
  if(b.dataset.guestEdit){dispatch({type:'GUEST_BEGIN',id:b.dataset.guestEdit});$('[data-guest-field="name"]')?.focus();}
  if(b.dataset.peekPerson)inspectPerson(b.dataset.peekPerson);
  if(b.dataset.planExample){dispatch({type:'MISSION_PLAN_CHAT_EXAMPLE',id:b.dataset.planExample});focusMissionChat('#plan-feedback');}
  if(b.dataset.planRemove){dispatch({type:'MISSION_PLAN_REMOVE',id:b.dataset.planRemove});$('[data-action="plan-add"]')?.focus({preventScroll:true});}
  if(b.dataset.planMove)dispatch({type:'MISSION_PLAN_MOVE',id:b.dataset.planMove,direction:Number(b.dataset.direction)});
  if(b.dataset.floor)dispatch({type:'ENTER_FLOOR',id:b.dataset.floor});
  if(b.dataset.object)objectAction(b.dataset.object);
  if(b.dataset.personDetail){dispatch({type:'DETAIL',id:b.dataset.personDetail});if(state.surface==='people'){if(b.dataset.agentInspect)$('.surface--people').dataset.agentInitialTab=b.dataset.agentInspect;const heading=$('.agent-profile-heading h2');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}if(innerWidth>850)$('.kl-scroll').scrollTop=0;else heading?.scrollIntoView({block:'start'});}}
  if(b.dataset.officeZone){if(b.dataset.officeZone==='entrance')dispatch({type:'BUILDING'});else objectAction(b.dataset.officeZone);}
  if(b.dataset.navObject){$('.navigator').close();if(state.view==='building')dispatch({type:'ENTER_FLOOR',id:state.floor});objectAction(b.dataset.navObject);}
  if(b.dataset.navSurface){$('.navigator').close();if(['ideas','knowledge-reader','lab','connected-output'].includes(b.dataset.navSurface))open(b.dataset.navSurface);else actions[b.dataset.navSurface]?.();}
  if(b.dataset.navFloor){$('.navigator').close();dispatch({type:'ENTER_FLOOR',id:b.dataset.navFloor});}
  if(b.hasAttribute('data-nav-board')){$('.navigator').close();if(state.view==='building')dispatch({type:'ENTER_FLOOR',id:state.floor});actions['mission-list']();}
  if(b.dataset.historyDownload!==undefined&&state.floor==='studio'){const archive=state.mission.history[Number(b.dataset.historyDownload)];if(archive)download(archive.markdown,'studio-archived-mission.md');}
});
document.addEventListener('submit',e=>{
  if(e.target.id==='founder-decision-form'){e.preventDefault();if(!e.target.reportValidity()||!$('#founder-note').value.trim())return;const key=e.target.dataset.founderKey;const event={type:'FOUNDER_DECIDE',key,action:e.submitter?.value,owner:$('#founder-owner').value,note:$('#founder-note').value};const project=e.target.closest('[data-company-project]')?.dataset.companyProject;if(project)state=switchWorkspaceProject(state,project);founderView().note='';dispatch(event);focusSurface();return;}
  if(e.target.id==='delivery-feedback-form'){e.preventDefault();if(!e.target.reportValidity())return;const v=deliveryView();if(!v.draft.trim())return;dispatch({type:v.editId?'MISSION_DELIVERY_EDIT_NOTE':'MISSION_DELIVERY_NOTE',id:v.editId,anchor:v.anchor,text:v.draft,proposal:v.proposal},true);Object.assign(v,{draft:'',proposal:'',editId:null});render();return;}
  if(e.target.id!=='ops-config-form')return;
  e.preventDefault();const v=operationView();if(!e.target.reportValidity()||!checkConfigValid(v.draft))return;
  const id=v.editId||`check-${crypto.randomUUID()}`;
  const event={type:v.editId?'OPS_UPDATE':'OPS_CREATE',id,config:v.draft};
  v.selected=id;v.history=false;v.draft=null;v.filter='all';v.notice='Check saved locally. Its schedule and instructions will not execute.';
  dispatch(event);focusOperation();
});
document.addEventListener('input',e=>{
  if(e.target.hasAttribute('data-nav-search')){filterNavigator(e.target.value);return;}
  if(e.target.id==='founder-note')founderView().note=e.target.value;
  if(e.target.id==='founder-owner')founderView().owner=e.target.value;
  if(e.target.dataset.deliveryField){deliveryView()[e.target.dataset.deliveryField]=e.target.value;}
  if(e.target.hasAttribute('data-delivery-revision')){deliveryView().revision=e.target.value;render();}
  if(e.target.hasAttribute('data-delivery-compare')){deliveryView().compare=e.target.checked;render();}
  if(e.target.dataset.deliveryVerify)dispatch({type:'MISSION_DELIVERY_VERIFY',id:e.target.dataset.deliveryVerify,value:e.target.checked});
  if(e.target.dataset.deliveryCheck)dispatch({type:e.target.dataset.deliveryCheck==='reviewed'?'MISSION_DELIVERY_REVIEWED':'MISSION_DELIVERY_CRITERIA',value:e.target.checked});
  if(e.target.dataset.opsField&&operationView().draft){operationView().draft[e.target.dataset.opsField]=e.target.value;if(e.target.dataset.opsField==='schedule')$('[data-ops-cron]').textContent=CHECK_SCHEDULES[e.target.value].cron;}
  if(e.target.hasAttribute('data-ops-outcome'))operationView().outcome=e.target.value;

  const t=e.target;
  if(t.hasAttribute('data-plan-feedback'))dispatch({type:'MISSION_PLAN_CHAT_DRAFT',text:t.value},{quiet:true});
  if(t.hasAttribute('data-plan-notes'))dispatch({type:'MISSION_PLAN_NOTES',value:t.value},{quiet:true});
  if(t.dataset.planField)dispatch({type:'MISSION_PLAN_EDIT',id:t.dataset.step,field:t.dataset.planField,value:t.value},{quiet:true});
  if(t.hasAttribute('data-mission-feedback'))dispatch({type:'MISSION_CHAT_DRAFT',text:t.value},{quiet:true});
  if(t.dataset.missionField)dispatch({type:'MISSION_EDIT',field:t.dataset.missionField,value:t.value},{quiet:true});
  if((t.dataset.floorField||t.dataset.guestField)&&$('.floor-errors'))$('.floor-errors').hidden=true;
  if(t.dataset.floorField)dispatch({type:'FLOOR_FIELD',key:t.dataset.floorField,value:t.value},{quiet:true});
  if(t.dataset.guestField)dispatch({type:'GUEST_FIELD',key:t.dataset.guestField,value:t.value},{quiet:true});
});
document.addEventListener('change',e=>{const t=e.target;
  if(t.dataset.planOwner)dispatch({type:'MISSION_PLAN_EDIT',id:t.dataset.planOwner,field:'owner',value:t.value});
  if(t.hasAttribute('data-chat-anchor'))dispatch({type:'MISSION_CHAT_ANCHOR',anchor:t.value});
  if(t.dataset.boardPriority){if(t.hasAttribute('data-example-priority')){missionBoardView.examplePriorities[t.dataset.boardPriority]=t.value;render();}else dispatch({type:'MISSION_PRIORITY',id:t.dataset.boardPriority,priority:t.value});}
  if(t.dataset.missionConfig)dispatch({type:'MISSION_CONFIG',person:t.dataset.person,key:t.dataset.missionConfig,value:t.value});
  if(t.dataset.missionSkill)dispatch({type:'MISSION_CONFIG',person:t.dataset.person,key:'skill',value:t.dataset.missionSkill});
  if(t.dataset.residentCapability)dispatch({type:'FLOOR_CAPABILITY',person:t.dataset.person,id:t.dataset.residentCapability});
  if(t.dataset.residentPreset)dispatch({type:'FLOOR_PRESET',person:t.dataset.person,key:t.dataset.residentPreset,value:t.value});
});
document.addEventListener('change',e=>{
  if(e.target.matches('[data-people-project]')){state=switchWorkspaceProject(state,e.target.value);persist();render();$('#people-project')?.focus();}
});
document.addEventListener('submit',e=>{
  if(e.target.matches('[data-plan-chat-form]')){e.preventDefault();dispatch({type:'MISSION_PLAN_CHAT_SEND'});focusMissionChat('#plan-feedback');return;}
  if(!e.target.matches('[data-mission-chat-form]'))return;
  e.preventDefault();dispatch({type:'MISSION_CHAT_SEND'});focusMissionChat('#mission-feedback');
});
document.addEventListener('keydown',e=>{
  if((e.metaKey||e.ctrlKey)&&e.key==='Enter'&&e.target.matches('[data-plan-feedback]')){e.preventDefault();dispatch({type:'MISSION_PLAN_CHAT_SEND'});focusMissionChat('#plan-feedback');return;}
  if((e.metaKey||e.ctrlKey)&&e.key==='Enter'&&e.target.matches('[data-mission-feedback]')){e.preventDefault();dispatch({type:'MISSION_CHAT_SEND'});focusMissionChat('#mission-feedback');return;}
  if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='p'){e.preventDefault();if(!$('.navigator').open)actions.navigate();}
  if(freeboard)return;
  if(e.key==='Escape'&&$('.workbench-popover[open]')){e.preventDefault();const menu=$('.workbench-popover[open]');menu.removeAttribute('open');menu.querySelector('summary').focus();return;}
  if(e.key==='Escape'&&document.body.classList.contains('sidebar-open')){e.preventDefault();document.body.classList.remove('sidebar-open');$('.workbench-menu').setAttribute('aria-expanded','false');$('.workbench-menu').focus();return;}
  if(e.key==='Escape'&&state.surface==='founder-desk'&&deskUI.view().inbox&&!$('.navigator').open&&!$('.reset-dialog').open){e.preventDefault();actions['desk-home']();return;}
  if(e.key==='Escape'&&state.surface==='founder-desk'&&deskUI.view().panelOpen&&!$('.navigator').open&&!$('.reset-dialog').open){e.preventDefault();deskUI.close();return;}
  if(e.key==='Escape'&&state.peekPerson&&!$('.navigator').open&&!$('.reset-dialog').open){e.preventDefault();e.stopPropagation();actions['dismiss-person']();return;}
  if(e.key==='Escape'&&state.surface&&!$('.navigator').open&&!$('.reset-dialog').open){e.preventDefault();dispatch({type:'CLOSE'});}
});
window.addEventListener('pagehide',()=>{try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch{}});
render();notice(storageNotice);
if(new URLSearchParams(location.search).has('onboarding')){open('settings');showWelcome();}
const sharedFloor=new URLSearchParams(location.search).get('whiteboard');
if(sharedFloor&&allFloors(state).some(f=>f.id===sharedFloor)){dispatch({type:'ENTER_FLOOR',id:sharedFloor});showFreeboard();}
// This exploration is opt-in and compiled out of production.
if(import.meta.env.DEV && new URLSearchParams(location.search).has('floor-explorer')){
  const {createFloorExplorer}=await import('./floor-explorer.js');
  dispatch({type:'ENTER_FLOOR',id:state.floor});
  floorExplorer=createFloorExplorer({getState:()=>state,enterFloor:id=>{state.cameras[id]={x:0,y:0,zoom:1};dispatch({type:'ENTER_FLOOR',id});}});
}
if(!new URLSearchParams(location.search).has('no3d'))import('./world.js').then(({createWorld})=>{world=createWorld($('#world'),{exploration:floorExplorer,onSelect:hit=>{if(hit.floor)dispatch({type:'ENTER_FLOOR',id:hit.floor});else objectAction(hit.object);},onCamera:(key,c)=>{state.cameras[key]=c;persist();},onExit:()=>{if(floorExplorer&&state.view==='floor')floorExplorer.open();else dispatch({type:'BUILDING'});},onFailure:()=>{$('[data-fallback]').hidden=false;}});
world.update(state);world.pause(Boolean(state.surface)||Boolean(freeboard)||Boolean(welcome));}).catch(()=>{$('[data-fallback]').hidden=false;});

else $('[data-fallback]').hidden=false;

// Let keyboard users return to the paper without leaving the mission.
document.addEventListener('keydown',event=>{
 const drawer=event.target.closest?.('.mission-chat-drawer[open]');
 if(event.key==='Escape'&&drawer){event.preventDefault();event.stopImmediatePropagation();drawer.open=false;drawer.querySelector('summary').focus();}
},true);
