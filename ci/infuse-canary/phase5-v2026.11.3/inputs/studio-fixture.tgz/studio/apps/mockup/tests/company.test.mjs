import { test } from 'node:test';
import assert from 'node:assert/strict';
import { initialState, transition as t, restoreState, PEOPLE, SECTIONS, planSteps } from '../src/simulation/model.js';
import { allFloors, companyPeople, floorPeople, MODEL_PRESETS } from '../src/simulation/company.js';
import { personPresence } from '../src/simulation/presence.js';

function projectDraft(s=initialState(),title='Customer research'){
  s=t(s,{type:'FLOOR_BEGIN'});
  s=t(s,{type:'FLOOR_FIELD',key:'title',value:title});
  return t(s,{type:'FLOOR_FIELD',key:'description',value:'  Understand the customer’s workflow <exactly>.\nKeep their own language.  '});
}
function withGuest(s){
  s=t(s,{type:'GUEST_BEGIN'});
  for(const [key,value] of Object.entries({name:'Mira',role:'Qualitative researcher',traits:'Calm, skeptical; asks for disconfirming evidence.',brief:'  Prior finding <A> & assumption B.\nDo not conflate them.  ',sources:'Interviews, 2026-09-20; supplied by the owner.'}))s=t(s,{type:'GUEST_FIELD',key,value});
  return t(s,{type:'GUEST_SAVE'});
}
test('project creation validates brief and residents before saving an independent floor',()=>{
  const original=initialState();let s=t(original,{type:'FLOOR_BEGIN'});
  s=t(s,{type:'FLOOR_STEP',step:'team'});assert.equal(s.floorDraft.step,'project');assert.equal(s.projects.length,0);assert.equal(s.floorDraft.errors.length,2);
  s=projectDraft(s,' Core ');s=t(s,{type:'FLOOR_SAVE'});assert.equal(s.projects.length,0);assert.match(s.floorDraft.errors.join(),/already/);
  s=projectDraft(s);s=t(s,{type:'FLOOR_RESIDENT',id:'emon'});s=t(s,{type:'FLOOR_SAVE'});assert.equal(s.projects.length,0);assert.match(s.floorDraft.errors.join(),/at least one resident/);
  s=t(s,{type:'FLOOR_RESIDENT',id:'satwa'});s=t(s,{type:'FLOOR_CAPABILITY',person:'satwa',id:'packaging'});s=t(s,{type:'FLOOR_CAPABILITY',person:'satwa',id:'runtime'});
  s=t(s,{type:'FLOOR_SAVE'});assert.equal(s.projects.length,0);assert.match(s.floorDraft.errors.join(),/capability/);
  s=t(s,{type:'FLOOR_CAPABILITY',person:'satwa',id:'packaging'});s=t(s,{type:'FLOOR_SAVE'});
  assert.equal(s.floor,'project-1');assert.equal(s.surface,null);assert.equal(allFloors(s).length,4);assert.equal(s.projects[0].number,'04');assert.deepEqual(s.mission,original.mission);
  assert.deepEqual(floorPeople(s).map(p=>p.id),['fito','satwa']);assert.equal(personPresence(s,'satwa').label,'Resident');
});
test('guest identity, exact research, and per-floor capability and LLM settings survive reload',()=>{
  let s=withGuest(projectDraft());const research=s.floorDraft.guests[0].brief;
  s=t(s,{type:'FLOOR_PRESET',person:'guest-1',key:'llm',value:MODEL_PRESETS[1]});s=t(s,{type:'FLOOR_PRESET',person:'guest-1',key:'reasoning',value:'High'});
  s=t(s,{type:'FLOOR_CAPABILITY',person:'guest-1',id:'expert-review'});s=t(s,{type:'FLOOR_SAVE'});
  s=t(s,{type:'LAYOUT',id:'open'});s=t(s,{type:'CAMERA',key:'project-1',x:1,y:2,zoom:1.1});
  const restored=restoreState(JSON.stringify(s));assert.equal(restored.notice,null);s=restored.state;
  assert.equal(s.guests[0].brief,research);assert.equal(s.guests[0].traits,'Calm, skeptical; asks for disconfirming evidence.');
  assert.deepEqual(s.projects[0].residents[1],{personId:'guest-1',llm:MODEL_PRESETS[1],reasoning:'High',capabilities:['expert-advice']});
  const mission=structuredClone(s.mission);s=t(s,{type:'ENTER_FLOOR',id:'studio'});s=t(s,{type:'ENTER_FLOOR',id:'project-1'});
  assert.deepEqual(s.mission,mission);assert.deepEqual(s.cameras['project-1'],{x:1,y:2,zoom:1.1});assert.equal(s.settings['project-1'].layout,'promenade');
  s=projectDraft(s,'Second project');s=t(s,{type:'FLOOR_RESIDENT',id:'guest-1'});s=t(s,{type:'FLOOR_PRESET',person:'guest-1',key:'reasoning',value:'Low'});s=t(s,{type:'FLOOR_SAVE'});
  assert.equal(s.guests.length,1);assert.equal(s.projects[0].residents[1].reasoning,'High');assert.equal(s.projects[1].residents[1].reasoning,'Low');
  assert.equal(floorPeople(s).find(p=>p.id==='guest-1'),companyPeople(s).find(p=>p.id==='guest-1'));
});
test('drafts survive closing and reload, guest cancellation has no company side effects, editing preserves floor identity',()=>{
  let s=withGuest(projectDraft());s=t(s,{type:'GUEST_BEGIN'});s=t(s,{type:'GUEST_FIELD',key:'name',value:'Unfinished'});
  s=t(s,{type:'CLOSE'});const result=restoreState(JSON.stringify(s));assert.equal(result.notice,null);s=t(result.state,{type:'FLOOR_BEGIN'});
  assert.equal(s.floorDraft.guestEditor.name,'Unfinished');assert.equal(s.guests.length,0);assert.equal(s.projects.length,0);
  s=t(s,{type:'GUEST_CANCEL'});s=t(s,{type:'FLOOR_SAVE'});const id=s.floor;s=t(s,{type:'FLOOR_EDIT'});
  s=t(s,{type:'FLOOR_FIELD',key:'title',value:'Renamed project'});s=t(s,{type:'FLOOR_SAVE'});
  assert.equal(s.projects.length,1);assert.equal(s.floor,id);assert.equal(s.projects[0].title,'Renamed project');
  assert.deepEqual(t(s,{type:'RESET'}),initialState());
});
test('old saves migrate without mission changes and corrupt floor data recovers explicitly',()=>{
  const old=initialState();delete old.projects;delete old.guests;delete old.floorDraft;
  const migrated=restoreState(JSON.stringify(old));assert.equal(migrated.notice,null);assert.deepEqual(migrated.state.mission,old.mission);
  const s=t(withGuest(projectDraft()),{type:'FLOOR_SAVE'});
  for(const change of [x=>x.projects[0].residents[1].personId='missing',x=>x.projects[0].residents[0].llm='unknown',x=>x.guests[0].skills=['shaping'],x=>delete x.settings['project-1'],x=>x.projects[0].residents[0].capabilities=[]]){const bad=structuredClone(s);change(bad);assert.match(restoreState(JSON.stringify(bad)).notice,/saved demo could not be read/);}
});

test('the named roster and exact model catalog are available across project and mission settings',()=>{
  assert.deepEqual(MODEL_PRESETS,['Opus 5.5','GPT-6 Astra','GPT-6 Sol','GPT-5.6 Sol','GPT-5.6 Terra']);
  assert.deepEqual(PEOPLE.filter(p=>p.id!=='fito').map(p=>[p.name,p.role]),[['Emon Lusk','CEO · coordinator'],['Kapiteky','Advisor'],['Tinus Lordvals','AI engineer'],['Satwa Nutella','Infrastructure'],['Stewie Hobs','Design'],['Ramiro Garcia','Client management']]);
  let s=projectDraft();
  for(const model of MODEL_PRESETS){s=t(s,{type:'FLOOR_PRESET',person:'emon',key:'llm',value:model});assert.equal(s.floorDraft.residents[0].llm,model);s=t(s,{type:'PRESET',key:'model',value:model});assert.equal(s.mission.model,model);}
  assert.equal(t(s,{type:'FLOOR_PRESET',person:'emon',key:'llm',value:'Balanced'}),s);
  for(const id of ['stewie','ramiro'])s=t(s,{type:'FLOOR_RESIDENT',id});
  s=t(s,{type:'FLOOR_SAVE'});assert.deepEqual(floorPeople(s).map(p=>p.id),['fito','emon','stewie','ramiro']);
  for(const section of SECTIONS)s=t(s,{type:'EDIT',id:section.id,value:section.suggestions[0]});
  s=t(s,{type:'APPROVE_PAPER'});for(const id of ['stewie','ramiro'])s=t(s,{type:'SQUAD',id});
  s=t(t(s,{type:'CONFIRM_SQUAD'}),{type:'LAUNCH'});
  while(s.mission.phase==='running'){
    const step=planSteps(s)[s.mission.step];assert(personPresence(s,step.owner,'studio').station);
    s=t(s,{type:'ADVANCE'});
  }
  assert.equal(restoreState(JSON.stringify(s)).notice,null);
});

test('previous roster saves migrate assignments and presets without losing in-progress evidence',()=>{
  let s=withGuest(projectDraft());s=t(s,{type:'FLOOR_RESIDENT',id:'satwa'});s=t(s,{type:'FLOOR_SAVE'});
  for(const section of SECTIONS)s=t(s,{type:'EDIT',id:section.id,value:`Keep exact ${section.id}: Pieter, Tinus & Emon.`});
  s=t(s,{type:'APPROVE_PAPER'});s=t(s,{type:'SQUAD',id:'satwa'});s=t(t(s,{type:'CONFIRM_SQUAD'}),{type:'LAUNCH'});s=t(s,{type:'ADVANCE'});
  s=t(s,{type:'FLOOR_EDIT'});s.floorDraft.selectedPerson='satwa';
  const contents=structuredClone(s.mission.content),research=structuredClone(s.guests),steps=planSteps(s).length;
  delete s.catalogRevision;delete s.mission.capabilities.stewie;delete s.mission.capabilities.ramiro;
  s.mission.capabilities.pieter=s.mission.capabilities.satwa;delete s.mission.capabilities.satwa;s.mission.squad=s.mission.squad.map(id=>id==='satwa'?'pieter':id);s.mission.model='Balanced';
  for(const f of [s.projects[0],s.floorDraft])for(const r of f.residents){if(r.personId==='satwa')r.personId='pieter';r.llm='OpenAI · balanced';}
  s.floorDraft.selectedPerson='pieter';s.selectedObject='pieter';
  const result=restoreState(JSON.stringify(s)),restored=result.state;
  assert.match(result.notice,/roster and model options/);assert.equal(restored.mission.phase,'running');assert.equal(restored.mission.step,1);assert.equal(planSteps(restored).length,steps);
  assert.equal(restored.mission.model,'GPT-6 Sol');assert(restored.mission.squad.includes('satwa'));assert(!restored.mission.squad.includes('stewie'));
  assert.deepEqual(restored.mission.content,contents);assert.deepEqual(restored.guests,research);assert.equal(restored.floorDraft.selectedPerson,'satwa');
  assert.equal(restored.projects[0].residents.at(-1).personId,'satwa');assert.equal(restored.projects[0].residents.at(-1).llm,'GPT-6 Sol');
  assert.equal(restoreState(JSON.stringify(restored)).notice,null);
});
