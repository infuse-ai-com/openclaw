import test from 'node:test';
import assert from 'node:assert/strict';
import { initialState, transition as t, restoreState } from '../src/simulation/model.js';
import { currentMission } from '../src/simulation/missions.js';
import { latestDelivery, deliveryStale, canAcceptDelivery, deliveryMarkdown, validDelivery } from '../src/simulation/deliveries.js';
import { missionColumn } from '../src/mission-board.js';
import { floorWorkspaceRecords } from '../src/simulation/floor-workspaces.js';
function completed(){
 let s=t(initialState(),{type:'MISSION_NEW'});
 s=t(s,{type:'MISSION_EXAMPLE'});s=t(s,{type:'MISSION_STEP',stage:'review'});
 for(const id of ['outcome','scope','evidence'])s=t(s,{type:'MISSION_CONFIRM',id,inline:true});
 s=t(s,{type:'MISSION_APPROVE',start:true});
 for(let i=0;i<40&&currentMission(s).status!=='completed';i++)s=t(s,{type:'MISSION_ADVANCE'});
 assert.equal(currentMission(s).status,'completed');return s;
}
const d=s=>currentMission(s).delivery;
const review=s=>t(t(s,{type:'MISSION_DELIVERY_REVIEWED',value:true}),{type:'MISSION_DELIVERY_CRITERIA',value:true});
const reload=s=>{const r=restoreState(JSON.stringify(s));assert.equal(r.notice,null);return r.state;};
test('delivery acceptance is separate from approved briefs and simulation completion',()=>{
 let s=completed();const approved=structuredClone(currentMission(s).approved);
 assert.equal(missionColumn(currentMission(s)),'review');assert.equal(t(s,{type:'MISSION_DELIVERY_ACCEPT'}),s);
 s=t(s,{type:'MISSION_DELIVERY_OPEN'});assert.equal(s.surface,'delivery-review');
 s=t(review(s),{type:'MISSION_DELIVERY_ACCEPT'});assert.equal(d(s).accepted.revision,1);
 assert.equal(missionColumn(currentMission(s)),'completed');assert.deepEqual(currentMission(s).approved,approved);
 assert.equal(floorWorkspaceRecords(s).results[0].accepted,true);s=reload(s);
 s=t(s,{type:'ENTER_FLOOR',id:'growth'});assert.equal(floorWorkspaceRecords(s).results.length,0);
 assert.equal(t(s,{type:'MISSION_DELIVERY_OPEN'}),s);
});
test('anchored literal feedback, revised wording, comparison and verification survive reload',()=>{
 let s=completed();const original=structuredClone(latestDelivery(d(s)));
 const text='  My exact <feedback> & correction.\nKeep this.  ',proposal='A user-authored replacement.\nNo paraphrase.';
 s=t(s,{type:'MISSION_DELIVERY_NOTE',anchor:'proposal',text,proposal});
 assert.equal(d(s).notes[0].revision,1);assert.equal(d(s).notes[0].text,text);
 assert.equal(t(review(s),{type:'MISSION_DELIVERY_ACCEPT'}).missionDesk.items[0].delivery.accepted,null);
 s=t(s,{type:'MISSION_DELIVERY_REVISE'});assert.deepEqual(d(s).versions[0],original);
 assert.equal(latestDelivery(d(s)).sections[0].body,proposal);assert.equal(canAcceptDelivery(d(s)),false);
 s=t(s,{type:'MISSION_DELIVERY_VERIFY',id:'note-1',value:true});s=t(review(s),{type:'MISSION_DELIVERY_ACCEPT'});s=reload(s);
 assert.equal(d(s).accepted.revision,2);assert.match(deliveryMarkdown(currentMission(s)),/My exact <feedback> & correction/);
 s=t(s,{type:'MISSION_DELIVERY_EDIT_NOTE',id:'note-1',text:'Correction changed',proposal:'Revised correction'});
 assert.equal(d(s).accepted,null);assert.equal(d(s).notes[0].verifiedRevision,null);assert.equal(d(s).acceptanceHistory.length,1);
 assert.equal(t(s,{type:'MISSION_DELIVERY_VERIFY',id:'note-1',value:true}),s);
});
test('source drift invalidates acceptance and all correction verification',()=>{
 let s=completed();s=t(s,{type:'MISSION_DELIVERY_NOTE',anchor:'scope',text:'Keep the boundary explicit',proposal:'No live execution.'});
 s=t(s,{type:'MISSION_DELIVERY_REVISE'});s=t(s,{type:'MISSION_DELIVERY_VERIFY',id:'note-1',value:true});
 s=t(review(s),{type:'MISSION_DELIVERY_ACCEPT'});s=t(s,{type:'MISSION_DELIVERY_SOURCE'});
 assert.equal(deliveryStale(d(s)),true);assert.equal(d(s).accepted,null);assert.equal(t(s,{type:'MISSION_DELIVERY_REVIEWED',value:true}),s);
 s=t(s,{type:'MISSION_DELIVERY_REVISE'});assert.equal(deliveryStale(d(s)),false);assert.equal(d(s).notes[0].verifiedRevision,null);s=reload(s);
 assert.equal(latestDelivery(d(s)).sourceRevision,2);assert.equal(d(s).acceptanceHistory[0].revision,2);
});
test('missing proposed wording blocks revisions and invalid delivery recovery preserves mission history',()=>{
 let s=completed();s=t(s,{type:'MISSION_DELIVERY_NOTE',anchor:'evidence',text:'Show evidence',proposal:''});
 assert.equal(t(s,{type:'MISSION_DELIVERY_REVISE'}),s);
 const approved=structuredClone(currentMission(s).approved),events=structuredClone(currentMission(s).events);
 d(s).notes[0].anchor='unknown';const recovered=restoreState(JSON.stringify(s));
 assert.match(recovered.notice,/delivery review evidence/);assert.deepEqual(currentMission(recovered.state).approved,approved);assert.deepEqual(currentMission(recovered.state).events,events);
 assert.equal(d(recovered.state).notes.length,0);assert.equal(d(recovered.state).accepted,null);
});

test('malformed nested delivery records recover without discarding approved missions',()=>{
 for(const field of ['versions','notes']){
  const s=completed();d(s)[field]=[null];
  assert.equal(validDelivery(d(s)),false);
  const restored=restoreState(JSON.stringify(s));
  assert.match(restored.notice,/delivery review evidence/);
  assert.deepEqual(currentMission(restored.state).approved,currentMission(s).approved);
 }
 const markdown=deliveryMarkdown(currentMission(completed()));
 assert.match(markdown,/\n## The proposed experience\n/);
});
