import { deskPanel, deskTokens, deskOverview } from './my-desk.js';
import { partner } from './simulation/reference-catalog.js';

export function createMyDeskController({getState,getDesktopHtml,icons}) {
  const views=new Map();let scene=null,generation=0;
  const view=()=>{const owner=partner(getState());if(!views.has(owner))views.set(owner,{selected:'monitor',panelOpen:false,inbox:false,camera:null});return views.get(owner);};
  function refresh(){
    const panel=document.querySelector('[data-desk-panel]');if(!panel)return;
    const current=view();
    panel.hidden=!current.panelOpen;
    document.querySelector('[data-desk-layout]').dataset.panelOpen=String(current.panelOpen);
    panel.querySelector('[data-desk-panel-content]').innerHTML=deskPanel(getState(),current,icons,getDesktopHtml());
    document.querySelectorAll('[data-desk-object]').forEach(button=>button.setAttribute('aria-pressed',String(current.panelOpen&&button.dataset.deskObject===current.selected)));
    scene?.select(current.panelOpen?current.selected:null);
  }
  function select(id){
    if(!['monitor','tokens','inbox','notebook','wall'].includes(id))return;
    Object.assign(view(),{selected:id,panelOpen:true});refresh();
    document.querySelector('[data-desk-panel]').scrollTop=0;
    document.querySelector('#desk-panel-title')?.focus({preventScroll:true});
  }
  function close(){
    view().panelOpen=false;refresh();
    document.querySelector(`[data-desk-object="${view().selected}"]`)?.focus({preventScroll:true});
  }
  function mount(){
    const current=++generation;scene?.destroy();scene=null;
    if(getState().surface!=='founder-desk')return;
    const host=document.querySelector('[data-desk-world]');if(!host)return;
    const ownerView=view();
    const failure=()=>{
      if(current!==generation||!host.isConnected)return;
      const fallback=host.querySelector('[data-desk-fallback]');
      if(fallback){fallback.hidden=false;fallback.textContent='The 3D desk is unavailable. Use the desk objects below to keep working.';}
      document.querySelectorAll('[data-desk-camera]').forEach(button=>button.disabled=true);
    };
    import('@studio/spatial/desk').then(({createDesk})=>{
      if(current!==generation||!host.isConnected)return;
      host.querySelector('[data-desk-fallback]').hidden=true;
      scene=createDesk(host,{onSelect:select,onFailure:failure,selected:ownerView.panelOpen?ownerView.selected:null,exampleData:true,tokens:`${(deskTokens()/1000).toFixed(1)}k`,overview:deskOverview(getState()),cameraView:ownerView.camera,onCameraChange:camera=>{
        ownerView.camera=camera;
        const output=document.querySelector('[data-desk-zoom]');
        if(output){output.value=`${Math.round(camera.zoom*100)}%`;output.title=`Look direction: ${Math.round(camera.yaw*180/Math.PI)}° horizontal, ${Math.round(camera.pitch*180/Math.PI)}° vertical`;}
      }});
    }).catch(failure);
  }
  return {view,mount,select,close,refresh,cameraAction(action){scene?.cameraAction(action);},reset(){views.clear();generation++;scene?.destroy();scene=null;}};
}
