import { missionDisplayTitle, englishMissionSummary } from './mission-copy.js';
import {presenceFor} from './connected.js';
import { companyPeople, projectFloor, capability } from './company.js';
import { currentMission, proposedMissionPlan, MISSION_LABELS } from './missions.js';
import { SECTIONS, planSteps } from './model.js';

// One read model for room labels, people sheets, movement, and the next handoff.
// Presence is a projection of the mission, never a second execution ledger.
export function workMoment(state) {
  const m = state.mission;
  const steps = planSteps(state);
  const next = m.phase === 'running' ? steps[m.step] : null;
  const last = m.step > 0 ? steps[m.step - 1] : null;
  return { next, last, total: steps.length, completed: m.step };
}

export function personPresence(state, id, floor = state.floor) {
  const p = companyPeople(state).find(person => person.id === id);
  if (!p) return null;
  const m = state.mission;
  const base = { id, name: p.name, role: p.role, tone: 'quiet', station: ({satwa:'operations',stewie:'review'})[id]||'team', label: 'Available', task: 'Available for the next mission.', output: null };
  const connectedPresence=state.connectedEnabled&&presenceFor(state,id);if(connectedPresence)return {...base,...connectedPresence};
  const selected=currentMission(state,floor);
  if(selected)return createdPresence(state,selected,base);
  const project=projectFloor(state,floor);
  if(project){const resident=project.residents.find(r=>r.personId===id);return {...base,label:id==='fito'?'Project owner':'Resident',station:id==='fito'?'founder':'team',tone:'ready',task:id==='fito'?'Shape the first mission for this project.':`${p.guest?'Guest expert':'Team member'} · Ready for the first mission.`,output:resident?.capabilities.map(id=>capability(id).title).join(' · ')||null};}
  if (floor !== 'studio') return { ...base, label: 'Example presence', task: 'The same team, shown on an illustrative initiative floor. Playable assignments live on Studio.', station: id === 'fito' ? 'founder' : 'team' };
  if (id === 'fito') {
    const labels = { shaping:'Shaping direction', squad:'Choosing the squad', ready:'Ready to launch', running:'Following the work', review:'Your decision', resolved:'Outcome accepted' };
    return { ...base, label:labels[m.phase], tone:['ready','review'].includes(m.phase)?'decision':'quiet', station:'founder', task:m.phase==='review'?'Inspect the proposal, anchor your correction, and decide its disposition.':m.phase==='running'?'Follow each named handoff. Advance the simulation when you’re ready.':englishMissionSummary(m.summary) };
  }
  if (!m.squad.includes(id)) return base;
  if (m.phase === 'resolved') return { ...base, label:'Work handed over', tone:'done', station:'lounge', task:'The proposal is accepted. Recorded corrections remain explicit follow-up work.' };
  if (m.phase === 'review') return { ...base, label:'Awaiting your review', tone:'decision', station:'review', task:'The design proposal is on the review wall. Fito’s judgment is the next step.' };
  if (m.phase === 'shaping') return { ...base, label:id==='emon'?'Shaping with you':'Recommended', tone:id==='emon'?'working':'quiet', station:id==='emon'?'whiteboard':base.station, task:id==='emon'?'Help turn the thought into an explicit outcome, scope, and evidence.':'Recommended for this mission. Confirm the squad after shaping the paper.' };
  if (['squad','ready'].includes(m.phase)) return { ...base, label:'At the whiteboard', tone:'ready', station:'whiteboard', task:m.phase==='squad'?'Gathering around the approved mission. Choose which capabilities to bring.':'The scope and squad are ready. Waiting for Fito to launch the demo.' };
  const steps = planSteps(state);
  const current = steps[m.step];
  if (current?.owner === id) {
    const station = ({shaping:'whiteboard',coordination:'review',grounding:'whiteboard',review:'review',prototype:'team',browser:'team',packaging:'operations',runtime:'operations',design:'whiteboard',usability:'review','client-brief':'whiteboard','client-updates':'team'})[current.skill];
    return { ...base, label:'Working now', tone:'working', station, task:current.title, output:current.output };
  }
  const upcoming = steps.slice(m.step).find(step => step.owner === id);
  if (upcoming) return { ...base, label:'Up next', tone:'ready', station:'team', task:`Waiting for the handoff: ${upcoming.title}.`, output:upcoming.output };
  const last = steps.slice(0,m.step).filter(step => step.owner === id).at(-1);
  return { ...base, label:'Work handed over', tone:'done', station:'lounge', task:last?`${last.title} is ready in the simulation.`:'Available for the next handoff.', output:last?.output || null };
}

function createdPresence(state,m,base) {
  const id=base.id;
  if(id==='fito')return {...base,station:'founder',label:MISSION_LABELS[m.status],task:englishMissionSummary(m.summary),tone:m.status==='draft'?'decision':'quiet'};
  if(!m.squad.includes(id))return {...base,label:'Available',task:'No assignment in this mission.'};
  if(m.status==='draft')return {...base,label:id==='emon'?'Shaping it with you':'Proposed team',station:id==='emon'?'whiteboard':base.station,tone:'ready',task:'Preparing the brief. No assignments yet.'};
  if(m.status==='approved')return {...base,label:m.startup==='hold'?'Approved · on hold':'Preparing to start',tone:'ready',station:m.startup==='prepared'&&id==='emon'?'whiteboard':base.station,task:m.startup==='hold'?'Approval is saved. No activity or assignments yet.':'Startup progresses through events. No tasks assigned yet.'};
  if(m.status==='completed')return {...base,label:'Flow completed',tone:'done',station:'lounge',task:'Example deliverables reviewed. The history and paper remain available.'};
  const plan=proposedMissionPlan(state,m),index=plan.findIndex(p=>p.owner===id),task=plan[index];
  const event=m.events.filter(e=>e.task===index).at(-1);
  if(event?.type==='task_assigned')return {...base,label:'Working · simulated',tone:'working',station:base.station,task:task.title,output:task.output};
  if(event?.type==='task_delivered')return {...base,label:'Delivery awaiting review',tone:'decision',station:'review',task:'Simulated delivery available. Waiting for the verification event from Emon.',output:task.output};
  if(event?.type==='task_verified')return {...base,label:'Delivery reviewed',tone:'done',station:'lounge',task:task.verification,output:task.output};
  return {...base,label:'Awaiting assignment',tone:'ready',task:'The mission is active; this task has not been assigned yet.',output:task?.output||null};
}

export function stationStatus(state, id, floor = state.floor) {
  const selected=currentMission(state,floor);
  if(selected){
    if(id==='whiteboard')return `${selected.confirmed.length} confirmed sections · ${missionDisplayTitle(selected)||'New mission'}`;
    if(id==='team')return `${selected.squad.length} people · ${selected.status==='draft'?'proposed team':'approved team'}`;
    if(id==='review'||id==='shelf')return (selected.execution?selected.execution.tasks.some(t=>t.evidence.length):selected.events.some(e=>e.type==='task_delivered'))?'Simulated deliverables · view history':'Mission paper';
    return (selected.execution?.state||MISSION_LABELS[selected.status])+((selected.execution?.held||selected.startup==='hold')?' · on hold':'');
  }
  if (projectFloor(state,floor))return id==='whiteboard'?'Project brief · first mission not shaped':id==='team'?`${projectFloor(state,floor).residents.length} resident agents`:'Ready for the first mission';
  if (floor !== 'studio') return 'Example initiative';
  const m = state.mission;
  if (id === 'whiteboard') return `${SECTIONS.filter(s=>m.content[s.id].trim()).length} of ${SECTIONS.length} sections shaped`;
  if (id === 'review' || id === 'shelf') return !m.artifact?'Waiting for the proposal':m.sourceRevision!==m.artifact.sourceRevision?'Older proposal · source updated':m.phase==='resolved'?'Accepted · follow-up open':'Proposal ready for review';
  if (id === 'team') return `${m.squad.length} people in the proposed squad`;
  if (id === 'operations') return m.phase==='running'?`Demo step ${m.step+1} of ${planSteps(state).length}`:'Local simulation only';
  return id==='founder'?personPresence(state,'fito',floor).label:'A place between missions';
}
