import { inspectionTransition, retainInspectionHistory, validInspection } from './inspection-state.js';
import { allFloors } from "./company.js";
import {
  currentMission,
  missionTransition,
  missionReady,
  proposedMissionPlan,
} from "./missions.js";
import { SOURCE, CANDIDATE, sourcesFor, candidatesFor, partner, canManage } from './reference-catalog.js';
import { referenceTransition } from './reference-decisions.js';
export { SOURCE, CANDIDATE } from './reference-catalog.js';
export const emptyConnected = () => ({
  version: 1,
  mode: "ready",
  partner: "Fito",
  sequence: 1,
  sourceRevision: 1,
  candidateRevision: 1,
  sourceAvailable: true,
  previewAvailable: true,
  externalBusy: true,
  projects: {},
  receipts: {},
  learning: [],
  preferences: { theme: "light", size: 100, wide: false },
  notice: "",
});
export const connected = (s) => s.connected || emptyConnected();
export const projectContext = (s) =>
  connected(s).projects[s.floor] || {
    ideas: [],
    source: null,
    candidate: null,
    labNotes: [],
  };
export const canDecide = (s) => connected(s).mode === "ready";
export const runtime = (s) => currentMission(s)?.execution;
export const settled = (x) => ["closed", "cancelled"].includes(x?.state);
export const currentTask = (x) => x?.tasks.find((t) => t.state !== "verified");
const otherRun = (s, m, owner) =>
  s.missionDesk.items
    .flatMap((n) => (n.id === m.id ? [] : n.execution?.tasks || []))
    .find((t) => t.owner === owner && t.runActive);
const record = (m, text, owner = "emon") => {
  m.events.push({
    type: "connected_event",
    title: text,
    detail: "Local simulation only.",
    owner,
  });
  m.summary = text;
};
export function nextWork(s, m = currentMission(s)) {
  const x = m?.execution,
    t = currentTask(x);
  if (!canDecide(s))
    return "Restore current project access before making a decision.";
  if (!x)
    return "Shape and review the exact paper before approving coordination.";
  if (x.state === "closed")
    return "Emon closed the verified work. Choose what to carry forward.";
  if (x.state === "cancelled")
    return "Cancelled. The record remains inspectable.";
  if(x.transport?.state==='uncertain')return "A delivery receipt is uncertain. Reconcile the recorded request before advancing work.";
  if (x.held) return "Work is on hold. Resume the same assignments when ready.";
  if (
    (m.source && !connected(s).sourceAvailable) ||
    (m.candidate && !connected(s).previewAvailable)
  )
    return "A selected reference is unavailable. Restore access to that exact version.";
  if (x.state === "closing")
    return "Required work is verified. Your explicit acknowledgment is pending.";
  if (t && otherRun(s, m, t.owner))
    return "This agent is occupied by another mission. Wait for its run to settle.";
  if (x.instruction?.state === "received")
    return "Instruction received. The assigned agent still needs to read and apply it.";
  if (t?.state === "queued")
    return t.owner === "tinus" && connected(s).externalBusy
      ? "Tinus is finishing a separate fixture run. This assignment is queued."
      : "The next admitted task is ready to begin.";
  if (["working", "revision"].includes(t?.state))
    return "The assigned agent is preparing the next delivery.";
  if (t?.state === "delivered")
    return "Emon reviews this exact evidence revision before verifying the task.";
  return "All required tasks are verified and runs settled. Emon can close.";
}
export function presenceFor(s, id) {
  for (const m of s.missionDesk.items) {
    const t = m.execution?.tasks.find((t) => t.owner === id && t.runActive);
    if (t)
      return {
        label: m.execution.held ? "Held assignment" : "Working",
        tone: m.execution.held ? "waiting" : "working",
        task: `${m.title} · ${t.title}`,
        station: "team",
      };
  }
  if (id === "tinus" && connected(s).externalBusy)
    return {
      label: "Busy · separate fixture run",
      tone: "quiet",
      task: "An explicitly simulated outside assignment must settle before new work starts.",
      station: "lounge",
    };
  for (const m of s.missionDesk.items) {
    const x = m.execution,
      t = x?.tasks.find((t) => t.owner === id && t.state !== "verified");
    if (t && !settled(x))
      return {
        label: x.held
          ? "Held assignment"
          : t.state === "delivered"
            ? "Awaiting exact review"
            : "Queued assignment",
        tone: "waiting",
        task: `${m.title} · ${t.title}`,
        station: "team",
      };
  }
  const selected = currentMission(s);
  if (selected && !selected.execution) return null;
  return s.connectedEnabled
    ? {
        label: id === "fito" ? "Project owner" : "Available",
        tone: "quiet",
        task: "No active assignment.",
        ...(id === "fito" ? { station: "founder" } : {}),
      }
    : null;
}
function setup(s) {
  s.connected ??= emptyConnected();
  for (const f of allFloors(s))
    s.connected.projects[f.id] ??= {
      ideas: [],
      source: null,
      candidate: null,
      labNotes: [],
    };
}
function referencesAvailable(s, m) {
  return !(
    (m.source && !connected(s).sourceAvailable) ||
    (m.candidate && !connected(s).previewAvailable)
  );
}
export function connectedTransition(state, event) {
  const native = currentMission(state)?.execution;
  const handled =
    event.type.startsWith("CONNECTED_") ||
    (state.connectedEnabled && event.type === "MISSION_APPROVE") ||
    (native &&
      [
        "MISSION_ADVANCE",
        "MISSION_START",
        "MISSION_REVISE",
        "MISSION_FOLLOWUP",
        "MISSION_DELIVERY_OPEN",
      ].includes(event.type));
  if (!handled) return null;
  let s = structuredClone(state);
  setup(s);
  const c = s.connected,
    p = c.projects[s.floor],
    m = currentMission(s),
    x = m?.execution;
  c.notice = "";
  if (event.type === "CONNECTED_MODE") {
    if (["ready", "offline", "loading", "denied", "expired", "signed-out"].includes(event.value))
      c.mode = event.value;
    return s;
  }
  if (event.type === "CONNECTED_PREF") {
    const v = event.value;
    if (["light", "dark", "system"].includes(v.theme))
      c.preferences.theme = v.theme;
    if ([90, 100, 110, 120].includes(v.size)) c.preferences.size = v.size;
    if (typeof v.wide === "boolean") c.preferences.wide = v.wide;
    return s;
  }
  if (!canDecide(s)) {
    c.notice =
      "Decisions are disabled until access and current state are restored.";
    return s;
  }
  if(inspectionTransition(s,event,m))return s;
  const extra=referenceTransition(s,event);
  if(extra)return extra;
  if(['MISSION_APPROVE','CONNECTED_ACK','CONNECTED_HOLD','CONNECTED_RESUME','CONNECTED_CANCEL','CONNECTED_GATE','CONNECTED_SOURCE','CONNECTED_CANDIDATE','CONNECTED_REMOVE_SOURCE'].includes(event.type)&&!canManage(s,m)){
    c.notice=`${m.decisionOwner} owns this decision. Switch the synthetic partner context to continue.`;return s;
  }
  switch (event.type) {
    case "CONNECTED_SAVE_IDEA": {
      if (!event.text?.trim()) return state;
      const found = p.ideas.find((i) => i.id === event.id);
      if (found) found.text = event.text.slice(0, 2000);
      else
        p.ideas.push({
          id: `idea-${c.sequence++}`,
          text: event.text.slice(0, 2000),
          missionId: null,
        });
      if(event.start){
        const idea=found||p.ideas.at(-1);
        return connectedTransition(s,{type:'CONNECTED_IDEA_DRAFT',id:idea.id});
      }
      c.notice = "Idea saved for later. No mission or agent work started.";
      break;
    }
    case "CONNECTED_IDEA_DRAFT": {
      const idea = p.ideas.find((i) => i.id === event.id);
      if (!idea) return state;
      if (idea.missionId)
        return missionTransition(s, {
          type: "MISSION_SELECT",
          id: idea.missionId,
        });
      s = missionTransition(s, { type: "MISSION_NEW" });
      const n = currentMission(s);
      n.content.intent = idea.text;
      n.rawThought = idea.text;
      s.connected.projects[s.floor].ideas.find(
        (i) => i.id === idea.id,
      ).missionId = n.id;
      return missionTransition(s,{type:'MISSION_STEP',stage:'shape'});
    }
    case "CONNECTED_MCP": {
      const receipt = `${s.floor}:fixture-receipt-1`;
      if (c.receipts[receipt]) {
        s = missionTransition(s, {
          type: "MISSION_SELECT",
          id: c.receipts[receipt],
        });
        s.connected.notice =
          "Existing receipt found. No duplicate draft created.";
      } else {
        s = missionTransition(s, { type: "MISSION_NEW" });
        const n = currentMission(s);
        n.content.intent = s.floor==="studio"?"Improve onboarding with a clearer next action.":`Clarify the ${s.floor} outcome and verification handoff.`;
        n.rawThought = n.content.intent;
        n.origin = "MCP";
        n.importContext={partner:partner(s),client:'Codex · admitted fixture client',project:s.floor,receipt,importedRevision:1,paperRevision:n.revision,status:'Saved',context:'Partner-supplied brief; no source fetched or agent dispatched.'};
        s.connected.receipts[receipt] = n.id;
        s.connected.notice =
          "MCP draft saved only. No shaping or specialist run started.";
      }
      break;
    }
    case "CONNECTED_SOURCE":
    case "CONNECTED_CANDIDATE": {
      const source = event.type === "CONNECTED_SOURCE",
        latest = source ? c.sourceRevision : c.candidateRevision,
        rev = event.revision ?? latest;
      if (
        !Number.isInteger(rev) ||
        rev < 1 ||
        rev > latest ||
        (source && !c.sourceAvailable) ||
        (!source && !c.previewAvailable)
      )
        return state;
      const field = source ? "source" : "candidate",
        ref = source
          ? { ...(sourcesFor(s.floor).find(d=>d.id===event.id)||sourcesFor(s.floor)[0]), revision: rev }
          : { ...(candidatesFor(s.floor).find(d=>d.id===event.id)||candidatesFor(s.floor)[0]), revision: rev, build: `fixture-build-${rev}` };
      if(!source&&event.deltas){ref.deltas=ref.deltas.filter(d=>event.deltas.includes(d.id));if(!ref.deltas.length)return state;ref.selection=ref.deltas.map(d=>d.label).join('; ');}
      p[field] = ref;
      if (m?.status === "draft") {
        m[field] = structuredClone(ref);
        m.revision++;
      }
      c.notice = m?.approved
        ? "Selected for future work. The approved references are unchanged."
        : "Exact reference added to the draft context.";
      break;
    }
    case "CONNECTED_GATE":
      if (!m || m.status !== "draft") return state;
      m.humanGate = Boolean(event.value);
      m.revision++;
      break;
    case "MISSION_APPROVE": {
      if (
        !m ||
        m.status !== "draft" ||
        !missionReady(m) ||
        (event.revision !== undefined && event.revision !== m.revision)
      )
        return state;
      if (!referencesAvailable(s, m)) {
        c.notice = "Restore the exact selected references before approving.";
        return s;
      }
      // Reuse the established authoring snapshot; the native-style execution starts immediately.
      s = missionTransition(s, { ...event, start: true });
      const n = currentMission(s);
      n.events.at(-1).title = "Mission approved · coordination authorized";
      n.events.at(-1).actor=partner(s);
      n.approved.source = structuredClone(n.source || null);
      n.approved.candidate = structuredClone(n.candidate || null);
      n.approved.humanGate = Boolean(n.humanGate);
      n.approved.decisionOwner=n.decisionOwner||partner(s);
      n.approvals[n.approvals.length - 1] = structuredClone(n.approved);
      n.execution = {
        version: 1,
        state: "running",
        held: false,
        instruction: null,
        finding: null,
        humanAcknowledged: false,
        learningProposed: false,
        tasks: proposedMissionPlan(s, n).map((t, i) => ({
          ...t,
          id: `${n.id}-task-${i + 1}`,
          session: `${n.id}-session-${i + 1}`,
          state: "queued",
          runActive: false,
          evidence: [],
        })),
      };
      n.status = "active";
      n.startup = "prepared";
      record(
        n,
        `Paper r${n.revision} approved. Emon coordinates directly; no separate Start.`,
      );
      break;
    }
    case "MISSION_DELIVERY_OPEN":
      s.surface = "connected-output";
      s.peekPerson = null;
      break;
    case "MISSION_START":
    case "MISSION_REVISE":
      return state;
    case "CONNECTED_HOLD":
      if (!x || settled(x)) return state;
      x.held = true;
      record(
        m,
        "Mission held. Assignment and session identities are retained.",
      );
      break;
    case "CONNECTED_RESUME":
      if (!x || settled(x)) return state;
      x.held = false;
      record(m, "Mission resumed with the same assignments.");
      break;
    case "CONNECTED_CANCEL":
      if (!x || settled(x)) return state;
      x.state = "cancelled";
      for (const t of x.tasks) t.runActive = false;
      m.status = "completed";
      record(
        m,
        "Mission cancelled. Its paper and evidence remain inspectable.",
      );
      break;
    case "CONNECTED_FEEDBACK": {
      if (!x || x.state !== "running" || !event.text?.trim()) return state;
      const t = currentTask(x) || x.tasks.at(-1);
      if(x.instruction?.state==='received'){c.notice='Apply the pending instruction before sending another in this fixture.';return s;}
      x.instruction = {
        text: event.text.slice(0, 2000),
        state: "received",
        taskId: t.id,
      };
      x.finding = {
        state: "open",
        title: "Partner feedback requires fresh evidence",
        taskId: t.id,
      };
      t.state = "revision";
      record(
        m,
        "Instruction received; application and fresh review are still required.",
      );
      break;
    }
    case "MISSION_ADVANCE": {
      if (!x || x.state !== "running" || x.held || x.transport?.state==='uncertain') return state;
      if (!referencesAvailable(s, m)) {
        c.notice = "Restore exact source/preview access before continuing.";
        return s;
      }
      const t = currentTask(x);
      if (!t) {
        if (
          x.tasks.some((t) => t.runActive) ||
          x.finding?.state === "open" ||
          x.instruction?.state === "received"
        )
          return state;
        if (m.humanGate && !x.humanAcknowledged) {
          x.state = "closing";
          record(
            m,
            "All required tasks verified. Waiting for the explicit human gate.",
          );
        } else {
          x.state = "closed";
          m.status = "completed";
          record(
            m,
            "Emon closed the verified mission. No deployment is claimed.",
          );
        }
        break;
      }
      if (otherRun(s, m, t.owner)) {
        c.notice =
          "Agent occupied by another mission; wait for that run to settle.";
        return s;
      }
      if (
        x.instruction?.state === "received" &&
        x.instruction.taskId === t.id
      ) {
        x.instruction.state = "applied";
        t.state = "revision";
        t.runActive = true;
        record(
          m,
          "Instruction read and applied in the same session. New evidence is due.",
          t.owner,
        );
      } else if (t.state === "queued") {
        if (t.owner === "tinus" && c.externalBusy) {
          c.externalBusy = false;
          record(
            m,
            "Tinus’s separate fixture run settled. This task remains queued.",
          );
        } else {
          t.state = "working";
          t.runActive = true;
          record(m, `Task started: ${t.title}`, t.owner);
        }
      } else if (["working", "revision"].includes(t.state)) {
        const revision = t.evidence.length + 1,
          partial = Boolean(
            m.candidate && (m.candidate.deltas?.length??2)>1 && t.owner === "tinus" && revision === 1,
          );
        t.evidence.push({
          revision,
          summary: partial
            ? `${m.candidate.deltas?.[0]?.label||"First-step card"} delivered; remaining selected changes are incomplete.`
            : t.output,
          adoption: partial ? "partial" : "complete",
          reviewed: false,
          published: false,
          source: structuredClone(m.approved.source),
          candidate: structuredClone(m.approved.candidate),
        });
        t.state = "delivered";
        t.runActive = false;
        record(
          m,
          `Evidence r${revision} delivered for ${t.title}. Exact review is pending.`,
          t.owner,
        );
      } else if (t.state === "delivered") {
        const e = t.evidence.at(-1);
        if (e.adoption === "partial") {
          x.finding = {
            state: "open",
            title: "Selected change adoption is incomplete",
            taskId: t.id,
          };
          t.state = "revision";
          record(
            m,
            "Partial adoption requires revision in the same assignment.",
          );
        } else {
          e.reviewed = true;
          t.state = "verified";
          if (x.finding?.taskId === t.id) x.finding.state = "closed";
          record(m, `Exact evidence r${e.revision} verified for ${t.title}.`);
        }
      }
      break;
    }
    case "CONNECTED_ACK":
      if (!x || x.state !== "closing" || x.held) return state;
      x.humanAcknowledged = true;
      x.state = "closed";
      m.status = "completed";
      record(m, "Explicit human gate acknowledged; Emon closed verified work.");
      break;
    case "CONNECTED_PUBLISH": {
      const t = x?.tasks.find((t) => t.id === event.task),
        e = t?.evidence.find((e) => e.revision === event.revision);
      if (!e) return state;
      e.published = true;
      c.notice = "Fixture output published. Task verification is unchanged.";
      break;
    }
    case "MISSION_FOLLOWUP":
      if (!x || !settled(x)) return state;
      {
        const old = structuredClone(m);
        s = missionTransition(s, { type: "MISSION_NEW" });
        const n = currentMission(s);
        n.title = `Follow-up · ${old.title}`.slice(0, 160);
        n.content = structuredClone(old.content);
        n.parentId = old.id;
        n.source = event.source ? structuredClone(old.source) : null;
        n.candidate = event.candidate ? structuredClone(old.candidate) : null;
        n.summary =
          "Independent unapproved follow-up. Confirm the brief and plan again.";
      }
      break;
    case "CONNECTED_LEARNING":
      if (x?.state !== "closed" || x.learningProposed) return state;
      x.learningProposed = true;
      c.learning.push({
        missionId: m.id,
        project: s.floor,
        status: "proposed",
        text: `Review the verified approach from “${m.title}” before reusing it. Evidence: ${x.tasks.map(t=>`${t.id} r${t.evidence.at(-1)?.revision}`).join(', ')}.`,
        destination:`${s.floor}-fixture / docs/runbooks · project source owner`,
      });
      c.notice = "Learning proposed. Canonical guidance is unchanged.";
      break;
    case "CONNECTED_LAB_NOTE": {
      const revision = event.revision ?? c.candidateRevision;
      if (
        !event.text?.trim() ||
        !c.previewAvailable ||
        !Number.isInteger(revision) ||
        revision < 1 ||
        revision > c.candidateRevision
      )
        return state;
      p.labNotes.push({ revision, candidateId:event.candidateId||candidatesFor(s.floor)[0].id, text: event.text.slice(0, 2000) });
      break;
    }
    case "CONNECTED_SOURCE_UPDATE":
      c.sourceRevision++;
      break;
    case "CONNECTED_CANDIDATE_UPDATE":
      c.candidateRevision++;
      break;
    case "CONNECTED_SOURCE_TOGGLE":
      c.sourceAvailable = !c.sourceAvailable;
      break;
    case "CONNECTED_PREVIEW_TOGGLE":
      c.previewAvailable = !c.previewAvailable;
      break;
    default:
      return state;
  }
  retainInspectionHistory(currentMission(s),event);
  return s;
}
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const refValid = (r, kind) =>
  r === null ||
  (r &&
    typeof r.id === 'string' && typeof r.repo === 'string' && typeof r.path === 'string' &&
    typeof r.title === "string" &&
    Number.isInteger(r.revision) &&
    r.revision > 0 && (r.deltas===undefined || (Array.isArray(r.deltas)&&r.deltas.every(d=>typeof d.id==='string'&&typeof d.label==='string'))));
export function validExecution(m) {
  const x = m.execution;
  if (
    !x ||
    x.version !== 1 ||
    !["running", "closing", "closed", "cancelled"].includes(x.state) ||
    typeof x.held !== "boolean" ||
    typeof x.humanAcknowledged !== "boolean" ||
    typeof x.learningProposed !== "boolean" ||
    !m.approved ||
    !equal(m.approved, m.approvals.at(-1)) ||
    !refValid(m.source, "source") ||
    !refValid(m.candidate, "candidate") ||
    !Array.isArray(x.tasks) ||
    x.tasks.length !== m.approved.plan.length ||
    !x.tasks.length
  )
    return false;
  if(!validInspection(x))return false;
  if(x.conversation!==undefined&&(!Array.isArray(x.conversation)||x.conversation.some(c=>!['author','kind','text'].every(k=>typeof c[k]==='string'))))return false;
  if ((settled(x) ? "completed" : "active") !== m.status) return false;
  if (
    !x.tasks.every((t, i) => {
      const plan = m.approved.plan[i];
      return (
        ["owner", "title", "output", "verification"].every(
          (k) => t[k] === plan[k],
        ) &&
        t.id === `${m.id}-task-${i + 1}` &&
        t.session === `${m.id}-session-${i + 1}` &&
        ["queued", "working", "revision", "delivered", "verified"].includes(
          t.state,
        ) &&
        typeof t.runActive === "boolean" &&
        (!t.runActive || ["working", "revision"].includes(t.state)) &&
        Array.isArray(t.evidence) &&
        t.evidence.every(
          (e, j) =>
            e.revision === j + 1 &&
            typeof e.summary === "string" &&
            ["partial", "complete"].includes(e.adoption) &&
            typeof e.reviewed === "boolean" &&
            typeof e.published === "boolean" &&
            (!e.reviewed || e.adoption === "complete") &&
            equal(e.source, m.approved.source) &&
            equal(e.candidate, m.approved.candidate),
        ) &&
        (!["delivered", "verified"].includes(t.state) ||
          t.evidence.length > 0) &&
        (t.state !== "verified" || t.evidence.at(-1).reviewed)
      );
    })
  )
    return false;
  if (
    x.instruction &&
    (!x.tasks.some((t) => t.id === x.instruction.taskId) ||
      typeof x.instruction.text !== "string" ||
      !["received", "applied"].includes(x.instruction.state))
  )
    return false;
  if (
    x.finding &&
    (!x.tasks.some((t) => t.id === x.finding.taskId) ||
      typeof x.finding.title !== "string" ||
      !["open", "closed"].includes(x.finding.state))
  )
    return false;
  if (
    ["closing", "closed"].includes(x.state) &&
    (x.tasks.some((t) => t.state !== "verified" || t.runActive) ||
      x.finding?.state === "open" ||
      x.instruction?.state === "received")
  )
    return false;
  return !(x.state === "closed" && m.humanGate && !x.humanAcknowledged);
}
export function restoreConnected(s) {
  if (!s.connected) {
    s.connected = emptyConnected();
    return null;
  }
  try {
    const c = s.connected;
    c.partner??='Fito';
    if (!['Fito','Alex'].includes(c.partner))throw Error();
    if (
      c.version !== 1 ||
      !["ready", "offline", "denied", "loading", "expired", "signed-out"].includes(c.mode) ||
      !["sequence", "sourceRevision", "candidateRevision"].every(
        (k) => Number.isInteger(c[k]) && c[k] > 0,
      ) ||
      !["sourceAvailable", "previewAvailable", "externalBusy"].every(
        (k) => typeof c[k] === "boolean",
      ) ||
      !c.projects ||
      Array.isArray(c.projects) ||
      !c.receipts ||
      Array.isArray(c.receipts) ||
      !Array.isArray(c.learning) ||
      typeof c.notice !== "string" ||
      !["light", "dark", "system"].includes(c.preferences?.theme) ||
      ![90, 100, 110, 120].includes(c.preferences.size) ||
      typeof c.preferences.wide !== "boolean"
    )
      throw Error();
    for (const [floor, p] of Object.entries(c.projects)) {
      if (
        !allFloors(s).some((f) => f.id === floor) ||
        !Array.isArray(p.ideas) ||
        !Array.isArray(p.labNotes) ||
        !refValid(p.source, "source") ||
        !refValid(p.candidate, "candidate") ||
        p.ideas.some(
          (i) =>
            typeof i.id !== "string" ||
            typeof i.text !== "string" ||
            (i.missionId !== null &&
              !s.missionDesk.items.some(
                (m) => m.id === i.missionId && m.floorId === floor,
              )),
        ) ||
        p.labNotes.some(
          (n) =>
            !Number.isInteger(n.revision) ||
            n.revision < 1 ||
            typeof n.text !== "string",
        )
      )
        throw Error();
    }
    for (const [receipt, id] of Object.entries(c.receipts))
      if (
        !s.missionDesk.items.some(
          (m) => m.id === id && receipt === `${m.floorId}:fixture-receipt-1`,
        )
      )
        throw Error();
    return null;
  } catch {
    s.connected = emptyConnected();
    return "Saved reference controls could not be read and were reset. Valid mission papers and office state are preserved.";
  }
}
