// Authored local companion: no provider calls or arbitrary-language interpretation.
export const FEEDBACK_ANCHORS=['general','intent','outcome','scope','references','decisions','evidence'];
export const FEEDBACK_EXAMPLES=[
  {id:'smaller',legacyText:'Acotemos la primera versión a una misión sencilla, con una sola ronda de revisión.',label:'Narrow the first version',text:'Keep the first version to one simple mission, with a single review round.'},
  {id:'direct',legacyText:'Quiero poder editar cada parte de la propuesta directamente, además de dar feedback en el chat.',label:'Prioritize direct editing',text:'I want to edit each part of the proposal directly, as well as give feedback in chat.'},
  {id:'evidence',legacyText:'Necesito criterios observables para revisar el resultado, incluyendo la recarga y la conservación de mis cambios.',label:'Clarify acceptance criteria',text:'I need observable acceptance criteria, including reloading and preserving my changes.'}
];
export const emptyShaping=()=>({seeded:false,draft:'',anchor:'general',branch:null,messages:[],pending:null});
export function initialMissionProposal(m){
 const design=m.scenario==='studio-design';
 return {
  outcome:design?'A working mission creation flow: start with an idea, review the proposal from Emon, choose the team and approve the brief.':'An initial proposal for review that addresses your intent, with a concrete outcome and boundaries agreed with you.',
  scope:design?'One mission within a floor. Include the initial idea, an editable proposal, feedback to Emon, a plan, a team and a review before starting.':'A first version of the outcome, your review and one round of revisions. Define deliverables before starting.',
  nonGoals:design?'Connecting real agents, executing external work or adding multiuser collaboration.':'Expanding the brief or starting external actions without an explicit decision.',
  references:`Floor context «${m.projectContext.title}»: ${m.projectContext.description}\n\nStarting point: your original idea. Additional sources still to be provided.`,
  decisions:'You confirm the outcome and scope before starting. Any expansion of the brief goes back to review. The proposal from Emon is a draft.',
  evidence:design?'I can create a mission in my own words, review and edit the proposal, choose the team and approve it. Reloading preserves my changes, and I can explain what each person will do.':'The deliverable meets the agreed outcome, with visible boundaries and evidence. You can review it, request a correction and verify the change.'
 };
}
export function feedbackChanges(m,text,anchor,branch){
 const scenario=m.scenario==='studio-design';
 let values;
 if(branch==='smaller')values={scope:scenario?'One simple mission in Studio: an idea, an editable proposal from Emon, team selection and review. A first version and a single correction round.':'One simple mission, one reviewable deliverable and a single correction round. Any expansion requires a new decision.',nonGoals:'Parallel missions, additional rounds and scope expansion in this first version.'};
 else if(branch==='direct')values={outcome:scenario?'A mission proposal I can edit section by section or refine through feedback to Emon, before choosing the team and approving it.':'A reviewable proposal with direct section editing and feedback to Emon, preserving the changes made by the owner.',scope:`${m.content.scope}\n\nThe proposal supports direct editing and feedback anchored to each section. Suggested changes never replace your words without review.`};
 else if(branch==='evidence')values={evidence:'I can edit each section and preserve the exact text. Feedback retains its original section. I see proposed changes before applying them. Reloading preserves edits and the conversation. Approval requires all essential decisions to be confirmed.'};
 else {const field=anchor==='general'?'decisions':anchor;values={[field]:`${m.content[field]}${m.content[field]?'\n\n':''}Feedback from Fito:\n${text}`};}
 const changes=Object.entries(values).map(([field,after])=>({field,before:m.content[field],after}));
 return changes.some(c=>c.after.length>8000)?[]:changes.filter(c=>c.before!==c.after);
}
export const feedbackCurrent=m=>Boolean(m.shaping?.pending?.changes.every(c=>m.content[c.field]===c.before));
