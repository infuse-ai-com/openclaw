import './whiteboard.css';
import { toolsMarkup, toolDefinitions, toolIcons } from './whiteboard-tools.js';
import { boardPrefix, validOperation, applyOperation, cardsFrom, seedBoard, zoomAt, cardVisible, tabsFrom, linksFrom, connectionPath, DEFAULT_TAB, CARD_TONES } from './whiteboard-model.js';

const actor=crypto.randomUUID();
const palette=['#bd552d','#557e66','#725da2','#36788c'];
const color=palette[parseInt(actor.slice(0,2),16)%palette.length];
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const button=(label,action,extra='')=>`<button type="button" data-wb="${action}" ${extra}>${label}</button>`;

export function openWhiteboard({floor,onClose}){
  const prefix=boardPrefix(floor.id),records=new Map(),peers=new Map(),elements=new Map();
  let clock=0,camera={x:80,y:80,zoom:.8},selected='brief',mode='select',space=false,drag=null,closed=false,storageOK=true,channel=null,lastPointer=0,cursor=null;
  let name=`Fito · ${actor.slice(0,3).toUpperCase()}`,commentTarget=null;
  let activeTab=DEFAULT_TAB,selectedLink=null,connectFrom=null,shapeChoice='rectangle';
  const views=new Map();
  let recovery=[];
  try{const saved=JSON.parse(sessionStorage.getItem(prefix+'recovery'));if(Array.isArray(saved))recovery=saved.filter(r=>typeof r?.title==='string'&&typeof r?.text==='string');}catch{}
  seedBoard().forEach(op=>applyOperation(records,op));
  let invalid=0;
  try{for(let i=0;i<localStorage.length;i++){
    const key=localStorage.key(i);if(!key.startsWith(prefix+'op:'))continue;
    try{const op=JSON.parse(localStorage.getItem(key));if(!validOperation(op)){invalid++;continue;}applyOperation(records,op);clock=Math.max(clock,op.clock);}catch{invalid++;}
  }}catch{storageOK=false;}
  try{const saved=sessionStorage.getItem(prefix+'active-tab');if(tabsFrom(records).some(t=>t.id===saved))activeTab=saved;}catch{}
  const currentCards=()=>cardsFrom(records,activeTab);
  const dialog=document.createElement('dialog');dialog.className='wb';dialog.setAttribute('aria-label',`Shared whiteboard for ${floor.title}`);
  dialog.innerHTML=`<header class="wb-header"><div class="wb-heading">${button('←','close','aria-label="Close whiteboard"')}<div><span>${esc(floor.title)} / FREE WHITEBOARD</span><h1>A space to think together<span>.</span></h1></div></div><div class="wb-collaboration"><span class="wb-presence" data-wb-presence></span>${button('Collaborate ↗','share','class="wb-share"')}</div></header>
    <nav class="wb-tabs-bar" aria-label="Whiteboard tabs"><div class="wb-tabs" role="tablist" aria-label="Canvases"></div>${button('＋ New tab','new-tab','class="wb-new-tab"')}</nav><div class="wb-layout"><aside class="wb-outline"><label class="wb-kicker" for="wb-tab-name">TAB NAME</label><input id="wb-tab-name" class="wb-tab-name" maxlength="80" aria-label="Tab name"><p data-tab-summary></p><div class="wb-outline-list"></div><div class="wb-outline-foot"><strong>An editable example</strong><p>Zoom in to write.<br>Zoom out to see the whole picture.</p>${button('Download whiteboard ↓','export')}</div></aside>
    <div class="wb-stage"><div class="wb-viewport" tabindex="0" aria-label="Infinite canvas. Drag the background to pan. Use plus and minus to zoom."><div class="wb-plane"><svg class="wb-links" aria-hidden="true"></svg><div class="wb-cards"></div></div><div class="wb-cursors" aria-hidden="true"></div></div>
    <div class="wb-topline"><span class="wb-kicker">EXPLORATION / 01</span><span data-wb-save></span></div>
    <div class="wb-context" role="toolbar" aria-label="Selection options" hidden><span data-selection-label></span><div class="wb-colors">${CARD_TONES.map(t=>`<button data-tone="${t}" aria-label="Color ${t}" title="Color ${t}" class="wb-swatch wb-swatch--${t}"></button>`).join('')}</div><select data-shape-choice aria-label="Shape type"><option value="rectangle">Rectangle</option><option value="ellipse">Ellipse</option><option value="diamond">Diamond</option></select>${button(toolIcons.duplicate,'duplicate','aria-label="Duplicate selection" title="Duplicate"')}${button(toolIcons.delete,'delete','aria-label="Delete selection" title="Delete"')}</div>
    <div class="wb-empty-board" hidden><span>A NEW CANVAS</span><h2>What will we explore here?</h2><p>Choose a tool and click the canvas.<br>Or start with a note.</p>${button('Create my first note','first-note')}</div>
    <div class="wb-toolbar" role="toolbar" aria-label="Whiteboard tools">${toolsMarkup()}</div>
    <div class="wb-shape-picker" hidden><span>CHOOSE A SHAPE</span>${button('▭ Rectangle','shape-rectangle')}${button('○ Ellipse','shape-ellipse')}${button('◇ Diamond','shape-diamond')}</div>
    <div class="wb-camera">${button('−','out','aria-label="Zoom out"')}<output data-wb-zoom>80%</output>${button('+','in','aria-label="Zoom in"')}${button('Fit','fit')}</div><p class="wb-hint">Drag to pan · Space to move · Ctrl/⌘ + scroll to zoom</p>
    <div class="wb-message" role="status" hidden></div></div>
    <aside class="wb-inspector" hidden></aside></div>
    <section class="wb-share-panel" hidden><h2>Try it together, here.</h2><p>This demo syncs tabs in the same browser. Open another to see live cursors, selection and changes.</p><label>Your name<input data-wb-name maxlength="40" value="${esc(name)}"></label><a class="wb-open-peer" href="?whiteboard=${encodeURIComponent(floor.id)}#workspace" target="_blank" rel="noopener">Open another tab ↗</a><p class="wb-small">Remote rooms and invitations are not available yet. If two people edit the same field, the latest version wins. We keep a local copy of text replaced during editing.</p>${button('Got it','share')}</section>`;
  document.body.append(dialog);dialog.showModal();
  const $=selector=>dialog.querySelector(selector),viewport=$('.wb-viewport'),plane=$('.wb-plane'),cardsHost=$('.wb-cards');
  function readCamera(id){try{const c=JSON.parse(sessionStorage.getItem(prefix+'camera:'+id)||(id===DEFAULT_TAB?sessionStorage.getItem(prefix+'camera'):null));return c&&Number.isFinite(c.x)&&Number.isFinite(c.y)&&c.zoom>=.2&&c.zoom<=2?c:null;}catch{return null;}}
  function renderTabs(){
    const tabs=tabsFrom(records),host=$('.wb-tabs'),focused=host.contains(document.activeElement)?document.activeElement.dataset.tab:null;
    host.innerHTML=tabs.map(t=>`<button type="button" role="tab" data-tab="${t.id}" aria-selected="${t.id===activeTab}" tabindex="${t.id===activeTab?0:-1}"><span>▧</span>${esc(t.title)}<small>${cardsFrom(records,t.id).length}</small></button>`).join('');
    if(focused)host.querySelector(`[data-tab="${focused}"]`)?.focus({preventScroll:true});
    const tab=tabs.find(t=>t.id===activeTab);if(document.activeElement!==$('#wb-tab-name'))$('#wb-tab-name').value=tab?.title||'';
    $('[data-tab-summary]').textContent=`${currentCards().length} blocks on this canvas. Select one to zoom in.`;
    $('.wb-topline .wb-kicker').textContent=tab?.title||'';
  }
  function switchTab(id){
    if(id===activeTab||!tabsFrom(records).some(t=>t.id===id))return;
    if(drag&&viewport.hasPointerCapture(drag.pointer))viewport.releasePointerCapture(drag.pointer);
    views.set(activeTab,{camera:{...camera},selected});activeTab=id;const view=views.get(id),saved=readCamera(id);camera=view?.camera||saved||{x:80,y:80,zoom:1};selected=view?.selected||null;selectedLink=null;connectFrom=null;commentTarget=null;cursor=null;drag=null;
    $('.wb-inspector').hidden=true;$('.wb-inspector').replaceChildren();$('.wb-message').hidden=true;setTool('select');render();if(!view&&!saved)fit();announce();
    try{sessionStorage.setItem(prefix+'active-tab',id);}catch{}
  }
  function setTool(tool){
    mode=tool;connectFrom=null;dialog.dataset.mode=tool;$('.wb-shape-picker').hidden=true;
    for(const [id] of toolDefinitions)$(`[data-wb="${id}"]`).setAttribute('aria-pressed',String(id===tool));
    $('.wb-hint').textContent=tool==='connect'?'Choose the source block, then the destination · Esc to cancel':tool==='comment'?'Select a block to comment':['note','document','text','shape'].includes(tool)?'Click the canvas to place · Enter to place in the center · Esc to cancel':'Drag to pan · Space to move · Ctrl/⌘ + scroll to zoom';
    viewport.focus({preventScroll:true});
  }
  function placeCard(kind,point){
    const sizes={note:[320,300],document:[440,400],text:[320,140],shape:[270,180]},[w,h]=sizes[kind],id=crypto.randomUUID();
    operation(id,'card',{kind,title:({note:'A new idea',document:'Untitled document',text:'Write an idea',shape:'New step'})[kind],body:'',tone:kind==='note'?'yellow':'cream',position:{x:(point.x-camera.x)/camera.zoom-w/2,y:(point.y-camera.y)/camera.zoom-h/2},size:{w,h},tab:activeTab});
    if(kind==='shape')operation(id,'shape',shapeChoice);
    selected=id;selectedLink=null;setTool('select');render();announce();elements.get(id).querySelector('[data-field="title"]').focus({preventScroll:true});
  }
  function connectCard(id){
    if(!connectFrom){connectFrom=id;selected=id;render();$('.wb-hint').textContent='Now select the destination block · Esc to cancel';return;}
    if(connectFrom===id)return;
    const edge='link-'+crypto.randomUUID();operation(edge,'link',{from:connectFrom,to:id,tab:activeTab});setTool('select');selected=null;selectedLink=edge;render();announce();
  }
  function tell(text){const el=$('.wb-message');el.hidden=false;el.textContent=text;}
  function saved(){ $('[data-wb-save]').textContent=storageOK?'Saved in this browser':'In memory only · download your whiteboard'; }
  function post(message){try{channel?.postMessage({...message,actor});}catch{}}
  function operation(node,field,value){
    const op={node,field,value,clock:++clock,actor};
    if(!applyOperation(records,op))return;
    try{localStorage.setItem(`${prefix}op:${actor}:${node}:${field}`,JSON.stringify(op));}catch{storageOK=false;}
    post({type:'operation',op});saved();render();
  }
  function receive(op){
    if(!validOperation(op))return;clock=Math.max(clock,op.clock);
    const active=document.activeElement;
    const editing=active?.closest('[data-card]')?.dataset.card===op.node&&active.dataset.field===op.field;
    const draft=editing?active.value:null;
    if(applyOperation(records,op)){
      if(editing&&draft!==op.value){
        recovery.push({title:currentCards().find(c=>c.id===op.node)?.title||op.node,text:draft});
        try{sessionStorage.setItem(prefix+'recovery',JSON.stringify(recovery));}catch{}
        tell('This field changed in another tab. Your previous text is in “Recovered text” in the comments panel.');
        active.value=op.value;
      }
      render();if(commentTarget===op.node&&(op.field.startsWith('comment-')||op.field==='deleted'||op.field==='title'))renderInspector();
    }
  }
  const onStorage=e=>{if(e.key?.startsWith(prefix+'op:')&&e.newValue){try{receive(JSON.parse(e.newValue));}catch{tell('Could not read a change from another tab.');}}};
  window.addEventListener('storage',onStorage);
  try{
    channel=new BroadcastChannel(prefix+'live');
    channel.onmessage=({data})=>{
      if(!data||data.actor===actor)return;
      if(data.type==='operation')receive(data.op);
      if(data.type==='presence'&&typeof data.actor==='string'&&typeof data.name==='string'){
        peers.set(data.actor,{...data,name:data.name.slice(0,40),seen:Date.now()});renderPresence();
      }
      if(data.type==='hello'){announce();post({type:'sync',ops:[...records.values()].flatMap(fields=>[...fields.values()])});}
      if(data.type==='sync'&&Array.isArray(data.ops))data.ops.slice(0,5000).forEach(receive);
      if(data.type==='leave'){peers.delete(data.actor);renderPresence();}
    };
  }catch{}
  function announce(){post({type:'presence',name,color,cursor,selected,tab:activeTab});}
  function renderPresence(){
    for(const [id,peer] of peers)if(Date.now()-peer.seen>11000)peers.delete(id);
    $('[data-wb-presence]').textContent=`● ${channel?'Local':'No shared cursors'} · ${peers.size+1} ${peers.size?'people':'person'}`;
    $('[data-wb-presence]').title=[name,...[...peers.values()].map(p=>p.name)].join(', ');
    const cursors=$('.wb-cursors');cursors.replaceChildren();
    for(const peer of peers.values()){
      if((peer.tab||DEFAULT_TAB)!==activeTab||!peer.cursor||!Number.isFinite(peer.cursor.x)||!Number.isFinite(peer.cursor.y))continue;
      const x=peer.cursor.x*camera.zoom+camera.x,y=peer.cursor.y*camera.zoom+camera.y;
      if(x<0||y<0||x>viewport.clientWidth||y>viewport.clientHeight)continue;
      const el=document.createElement('div');el.className='wb-peer-cursor';el.style.transform=`translate(${x}px,${y}px)`;el.style.color=palette.includes(peer.color)?peer.color:palette[0];
      const arrow=document.createElement('b');arrow.textContent='↖';const label=document.createElement('span');label.textContent=peer.name;el.append(arrow,label);cursors.append(el);
    }
    for(const [id,el] of elements){const peer=[...peers.values()].find(p=>(p.tab||DEFAULT_TAB)===activeTab&&p.selected===id);el.classList.toggle('wb-remote-selected',Boolean(peer));el.querySelector('.wb-peer-label').textContent=peer?`${peer.name} is here`:'';}
  }
  const heartbeat=setInterval(()=>{announce();renderPresence();},3000);
  function createCard(card){
    const el=document.createElement('article');el.className=`wb-card wb-card--${card.kind} wb-tone--${card.tone}`;el.dataset.card=card.id;
    el.innerHTML=`<span class="wb-peer-label"></span><div class="wb-card-handle" tabindex="0" role="button" aria-label="Move card: ${esc(card.title)}" title="Drag to move. Use arrow keys with the keyboard."><span>${({note:'NOTE',preview:'HTML / PROPOSAL',text:'TEXT',shape:'SHAPE',document:'DOCUMENT'})[card.kind]}</span><span>⠿</span></div><div class="wb-card-content"><textarea class="wb-card-title" rows="1" data-field="title" aria-label="Title of ${esc(card.title)}" maxlength="12000"></textarea><textarea class="wb-card-body" data-field="body" aria-label="Content of ${esc(card.title)}" spellcheck="true" maxlength="12000"></textarea>${card.kind==='preview'?'<div class="wb-html-preview"><span>STUDIO / A LIVING COMPANY</span><h3>The next great idea<br>starts <em>here.</em></h3><div><span>01<br><b>Inhabit</b></span><span>02<br><b>Shape</b></span><span>03<br><b>Decide</b></span></div></div>':''}<button class="wb-card-comments" data-wb-card-comments>＋ Comment</button></div><button class="wb-resize" aria-label="Resize: ${esc(card.title)}" title="Drag or use arrow keys to resize">⌟</button>`;
    cardsHost.append(el);elements.set(card.id,el);return el;
  }
  function render(){
    renderTabs();
    const cards=currentCards(),ids=new Set(cards.map(c=>c.id));
    for(const [id,el] of elements)if(!ids.has(id)){el.remove();elements.delete(id);}
    for(const card of cards){
      const el=elements.get(card.id)||createCard(card);
      el.style.left=`${card.position.x}px`;el.style.top=`${card.position.y}px`;el.style.width=`${card.size.w}px`;el.style.height=`${card.size.h}px`;
      el.className=`wb-card wb-card--${card.kind} wb-tone--${card.tone}`;el.dataset.shape=card.shape;
      el.classList.toggle('is-selected',selected===card.id);el.classList.toggle('is-link-origin',connectFrom===card.id);
      el.querySelector('.wb-card-handle').setAttribute('aria-label',`Move card: ${card.title}`);el.querySelector('.wb-resize').setAttribute('aria-label',`Resize: ${card.title}`);
      for(const field of ['title','body']){const input=el.querySelector(`[data-field="${field}"]`);if(input!==document.activeElement)input.value=card[field];if(field==='title')el.dataset.measureTitle='true';}
      el.querySelector('.wb-card-comments').textContent=card.comments.length?`${card.comments.length} ${card.comments.length===1?'comment':'comments'} ↗`:'＋ Comment';
    }
    const outline=$('.wb-outline-list');const focused=outline.contains(document.activeElement)?document.activeElement.dataset.jump:null;
    outline.replaceChildren();for(const card of cards){const b=document.createElement('button');b.type='button';b.dataset.jump=card.id;b.textContent=card.title||'Untitled';b.setAttribute('aria-current',String(selected===card.id));outline.append(b);if(focused===card.id)b.focus({preventScroll:true});}
    if(selected&&!ids.has(selected))selected=null;
    const selectedCard=cards.find(c=>c.id===selected),link=linksFrom(records,activeTab).find(l=>l.id===selectedLink);
    if(!link)selectedLink=null;
    $('.wb-context').hidden=!selectedCard&&!link;
    $('[data-selection-label]').textContent=link?'Connector':selectedCard?({shape:'Shape',text:'Text',note:'Note',document:'Document',preview:'HTML'})[selectedCard.kind]:'';
    $('.wb-colors').hidden=!selectedCard;$('[data-wb="duplicate"]').hidden=!selectedCard;
    $('[data-shape-choice]').hidden=selectedCard?.kind!=='shape';if(selectedCard)$('[data-shape-choice]').value=selectedCard.shape;
    for(const b of dialog.querySelectorAll('[data-tone]'))b.setAttribute('aria-pressed',String(b.dataset.tone===selectedCard?.tone));
    $('.wb-empty-board').hidden=cards.length>0;
    $('.wb-links').innerHTML='<defs><marker id="wb-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z"/></marker></defs>'+linksFrom(records,activeTab).map(link=>{
      const path=connectionPath(cards.find(c=>c.id===link.from),cards.find(c=>c.id===link.to));
      return `<path class="wb-link-hit" data-link="${link.id}" d="${path}"/><path class="wb-link-line ${selectedLink===link.id?'is-selected':''}" d="${path}" marker-end="url(#wb-arrow)"/>`;
    }).join('');
    cameraRender();renderPresence();
  }
  function cameraRender(){
    plane.style.transform=`translate(${camera.x}px,${camera.y}px) scale(${camera.zoom})`;
    viewport.style.backgroundSize=`${24*camera.zoom}px ${24*camera.zoom}px`;viewport.style.backgroundPosition=`${camera.x}px ${camera.y}px`;
    $('[data-wb-zoom]').textContent=`${Math.round(camera.zoom*100)}%`;
    for(const card of currentCards()){const el=elements.get(card.id);el.hidden=!el.contains(document.activeElement)&&!cardVisible(card,camera,viewport.clientWidth,viewport.clientHeight);if(!el.hidden&&el.dataset.measureTitle==='true'){const title=el.querySelector('[data-field=title]');title.style.height='0px';title.style.height=`${Math.max(34,Math.min(120,title.scrollHeight))}px`;el.dataset.measureTitle='false';}}
    renderPresence();
    try{sessionStorage.setItem(prefix+'camera:'+activeTab,JSON.stringify(camera));}catch{}
  }
  function fit(){
    const cards=currentCards();if(!cards.length){camera={x:80,y:80,zoom:1};cameraRender();return;}
    const minX=Math.min(...cards.map(c=>c.position.x)),minY=Math.min(...cards.map(c=>c.position.y)),maxX=Math.max(...cards.map(c=>c.position.x+c.size.w)),maxY=Math.max(...cards.map(c=>c.position.y+c.size.h));
    const zoom=Math.max(.2,Math.min(1,(viewport.clientWidth-100)/(maxX-minX),(viewport.clientHeight-190)/(maxY-minY)));
    camera={zoom,x:(viewport.clientWidth-(maxX-minX)*zoom)/2-minX*zoom,y:65-minY*zoom};cameraRender();
  }
  function focusCard(id){const card=currentCards().find(c=>c.id===id);if(!card)return;selected=id;camera={zoom:1,x:(viewport.clientWidth-card.size.w)/2-card.position.x,y:90-card.position.y};render();announce();elements.get(id).querySelector('[data-field="body"]').focus({preventScroll:true});}
  function openComments(id){if(commentTarget!==id)$('.wb-inspector').replaceChildren();commentTarget=id;renderInspector();}
  function renderInspector(){
    const inspector=$('.wb-inspector'),card=currentCards().find(c=>c.id===commentTarget);
    if(!card){inspector.hidden=true;commentTarget=null;return;}
    const previous=inspector.querySelector('textarea'),draft=previous?.value||'',hadFocus=previous===document.activeElement,selection=previous?[previous.selectionStart,previous.selectionEnd]:null;
    inspector.hidden=false;inspector.innerHTML=`<header><span class="wb-kicker">CONVERSATION</span>${button('×','close-comments','aria-label="Close comments"')}</header><h2>${esc(card.title)}</h2><p class="wb-small">Each comment stays attached to this card.</p><div class="wb-comments">${card.comments.length?card.comments.map(c=>`<article><strong>${esc(c.author)}</strong><p>${esc(c.text)}</p></article>`).join(''):'<p class="wb-empty">No comments yet.<br>Start the conversation.</p>'}</div><form class="wb-comment-form"><label>Your comment<textarea aria-label="Your comment" required maxlength="12000" placeholder="What would you change or decide here?">${esc(draft)}</textarea></label><button type="submit">Add comment →</button></form>${recovery.length?`<details><summary>Recovered text (${recovery.length})</summary>${recovery.map(r=>`<p><strong>${esc(r.title)}</strong></p><pre>${esc(r.text)}</pre>`).join('')}</details>`:''}`;
    if(hadFocus){const input=inspector.querySelector('textarea');input.focus({preventScroll:true});if(selection)input.setSelectionRange(...selection);}cameraRender();
  }
  function close(){if(closed)return;closed=true;post({type:'leave'});channel?.close();clearInterval(heartbeat);observer.disconnect();window.removeEventListener('storage',onStorage);window.removeEventListener('pagehide',close);dialog.close();dialog.remove();onClose();}
  dialog.addEventListener('cancel',e=>{e.preventDefault();close();});window.addEventListener('pagehide',close);
  dialog.addEventListener('click',e=>{
    const tab=e.target.closest('[data-tab]');if(tab){switchTab(tab.dataset.tab);return;}
    const edge=e.target.closest('[data-link]');if(edge){selected=null;selectedLink=edge.dataset.link;setTool('select');render();return;}
    const tone=e.target.closest('[data-tone]');if(tone&&selected){operation(selected,'tone',tone.dataset.tone);return;}
    const jump=e.target.closest('[data-jump]');if(jump){focusCard(jump.dataset.jump);return;}
    const card=e.target.closest('[data-card]');if(card&&mode==='connect'){connectCard(card.dataset.card);return;}if(card&&mode==='comment'){selected=card.dataset.card;setTool('select');render();openComments(selected);return;}if(card&&selected!==card.dataset.card){selected=card.dataset.card;selectedLink=null;render();announce();}
    if(e.target.closest('[data-wb-card-comments]')){openComments(card.dataset.card);return;}
    const action=e.target.closest('[data-wb]')?.dataset.wb;
    if(action==='close')close();
    if(action==='share')$('.wb-share-panel').hidden=!$('.wb-share-panel').hidden;
    if(action==='fit')fit();
    if(toolDefinitions.some(t=>t[0]===action)){setTool(action);if(action==='shape')$('.wb-shape-picker').hidden=false;return;}
    if(action?.startsWith('shape-')){shapeChoice=action.slice(6);setTool('shape');return;}
    if(action==='new-tab'){const id='tab-'+crypto.randomUUID();operation(id,'tab',{title:`Untitled ${tabsFrom(records).length+1}`,order:clock+2});switchTab(id);$('#wb-tab-name').focus();$('#wb-tab-name').select();}
    if(action==='first-note')placeCard('note',{x:viewport.clientWidth/2,y:viewport.clientHeight/2});
    if(action==='duplicate'&&selected){const card=currentCards().find(c=>c.id===selected),id=crypto.randomUUID();const {comments,...copy}=card;delete copy.id;operation(id,'card',{...copy,title:card.title+'· copy',position:{x:card.position.x+45,y:card.position.y+45}});selected=id;render();announce();}
    if(action==='in'||action==='out'){camera=zoomAt(camera,camera.zoom*(action==='in'?1.2:1/1.2),{x:viewport.clientWidth/2,y:viewport.clientHeight/2});cameraRender();}
    if(action==='close-comments'){commentTarget=null;$('.wb-inspector').hidden=true;cameraRender();}
    if(action==='delete'&&(selected||selectedLink)){const id=selected||selectedLink;operation(id,'deleted',true);tell('Item removed.');const undo=document.createElement('button');undo.textContent='Undo';undo.onclick=()=>{operation(id,'deleted',false);$('.wb-message').hidden=true;};$('.wb-message').append(undo);renderInspector();}
    if(action==='export'){const blob=new Blob([JSON.stringify({version:2,floor:floor.id,tabs:tabsFrom(records),links:tabsFrom(records).flatMap(t=>linksFrom(records,t.id)),cards:cardsFrom(records),recoveredTexts:recovery},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`whiteboard-${floor.id}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  });
  dialog.addEventListener('input',e=>{if(e.target.id==='wb-tab-name'){const tab=tabsFrom(records).find(t=>t.id===activeTab);if(e.target.value.trim())operation(activeTab,'tab',{title:e.target.value,order:tab.order});return;}const field=e.target.dataset.field;if(field){operation(e.target.closest('[data-card]').dataset.card,field,e.target.value);}if(e.target.hasAttribute('data-wb-name')){name=e.target.value.trim()||'Visitor';announce();renderPresence();}});
  dialog.addEventListener('change',e=>{if(e.target.hasAttribute('data-shape-choice')&&selected)operation(selected,'shape',e.target.value);if(e.target.id==='wb-tab-name'&&!e.target.value.trim())e.target.value=tabsFrom(records).find(t=>t.id===activeTab).title;});
  dialog.addEventListener('submit',e=>{if(!e.target.matches('.wb-comment-form'))return;e.preventDefault();const input=e.target.querySelector('textarea');if(!input.value.trim())return;operation(commentTarget,`comment-${crypto.randomUUID()}`,{text:input.value,author:name});input.value='';renderInspector();});
  viewport.addEventListener('wheel',e=>{const scrollable=e.target.closest('textarea,.wb-html-preview');if(!e.ctrlKey&&!e.metaKey&&scrollable&&((e.deltaY>0&&scrollable.scrollTop+scrollable.clientHeight<scrollable.scrollHeight-1)||(e.deltaY<0&&scrollable.scrollTop>0)))return;e.preventDefault();if(e.ctrlKey||e.metaKey){const rect=viewport.getBoundingClientRect();camera=zoomAt(camera,camera.zoom*Math.exp(-e.deltaY*.003),{x:e.clientX-rect.left,y:e.clientY-rect.top});}else{camera.x-=e.deltaX;camera.y-=e.deltaY;}cameraRender();},{passive:false});
  viewport.addEventListener('pointerdown',e=>{
    if(e.button!==0&&e.button!==1)return;
    const card=e.target.closest('[data-card]');
    if(e.button===0&&!space){
      if(['note','document','text','shape'].includes(mode)&&!card){e.preventDefault();const r=viewport.getBoundingClientRect();placeCard(mode,{x:e.clientX-r.left,y:e.clientY-r.top});return;}
      if(['connect','comment'].includes(mode)){e.preventDefault();return;}
    }
    const resize=e.target.closest('.wb-resize'),handle=e.target.closest('.wb-card-handle');
    if(e.button!==1&&!space&&mode!=='hand'&&card&&!handle&&!resize)return;
    e.preventDefault();const c=card?currentCards().find(c=>c.id===card.dataset.card):null;
    drag={pointer:e.pointerId,x:e.clientX,y:e.clientY,camera:{...camera},card:c,type:!space&&mode!=='hand'&&e.button===0&&c?(resize?'resize':'card'):'pan'};
    if(c&&drag.type!=='pan'){selected=c.id;render();announce();}
    viewport.setPointerCapture(e.pointerId);
  });
  viewport.addEventListener('pointermove',e=>{
    const rect=viewport.getBoundingClientRect();cursor={x:(e.clientX-rect.left-camera.x)/camera.zoom,y:(e.clientY-rect.top-camera.y)/camera.zoom};
    if(Date.now()-lastPointer>50){announce();lastPointer=Date.now();}
    if(!drag||e.pointerId!==drag.pointer)return;
    const dx=e.clientX-drag.x,dy=e.clientY-drag.y;
    if(drag.type==='pan'){camera.x=drag.camera.x+dx;camera.y=drag.camera.y+dy;cameraRender();}
    else if(drag.type==='card')operation(drag.card.id,'position',{x:drag.card.position.x+dx/camera.zoom,y:drag.card.position.y+dy/camera.zoom});
    else operation(drag.card.id,'size',{w:Math.max(['text','shape'].includes(drag.card.kind)?120:260,Math.min(900,drag.card.size.w+dx/camera.zoom)),h:Math.max(['text','shape'].includes(drag.card.kind)?70:200,Math.min(1000,drag.card.size.h+dy/camera.zoom))});
  });
  const stopDrag=()=>{drag=null;};viewport.addEventListener('pointerup',stopDrag);viewport.addEventListener('pointercancel',stopDrag);viewport.addEventListener('lostpointercapture',stopDrag);
  viewport.addEventListener('pointerleave',()=>{cursor=null;announce();});
  dialog.addEventListener('keydown',e=>{
    e.stopPropagation();if(e.key==='Escape'){e.preventDefault();if(mode!=='select'){setTool('select');return;}if(!$('.wb-inspector').hidden){commentTarget=null;$('.wb-inspector').hidden=true;return;}close();return;}
    if(e.target.matches('input,textarea,select'))return;
    if(e.target.matches('[role=tab]')&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const tabs=tabsFrom(records),i=tabs.findIndex(t=>t.id===activeTab),next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;switchTab(tabs[next].id);$(`[data-tab="${activeTab}"]`).focus();return;}
    if(e.key==='Enter'&&e.target.closest('.wb-card-handle')&&['connect','comment'].includes(mode)){e.preventDefault();e.target.click();return;}
    if(e.key==='Enter'&&e.target===viewport&&['note','document','text','shape'].includes(mode)){e.preventDefault();placeCard(mode,{x:viewport.clientWidth/2,y:viewport.clientHeight/2});return;}
    const card=currentCards().find(c=>c.id===e.target.closest('[data-card]')?.dataset.card),arrows={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]};
    if(card&&arrows[e.key]&&(e.target.closest('.wb-card-handle')||e.target.closest('.wb-resize'))){e.preventDefault();const [x,y]=arrows[e.key],step=e.shiftKey?50:10;if(e.target.closest('.wb-resize'))operation(card.id,'size',{w:Math.max(['text','shape'].includes(card.kind)?120:260,Math.min(900,card.size.w+x*step)),h:Math.max(['text','shape'].includes(card.kind)?70:200,Math.min(1000,card.size.h+y*step))});else operation(card.id,'position',{x:card.position.x+x*step,y:card.position.y+y*step});return;}
    if(e.code==='Space'){e.preventDefault();space=true;dialog.dataset.panning='true';}
    if(!e.ctrlKey&&!e.metaKey&&!e.altKey){const tool=toolDefinitions.find(t=>t[2].toLowerCase()===e.key.toLowerCase());if(tool){e.preventDefault();setTool(tool[0]);}}
    if(e.key==='+'||e.key==='=')$('[data-wb="in"]').click();if(e.key==='-')$('[data-wb="out"]').click();
    if(e.key==='0')fit();
    if(arrows[e.key]&&e.target===viewport){e.preventDefault();camera.x-=arrows[e.key][0]*60;camera.y-=arrows[e.key][1]*60;cameraRender();}
  });
  dialog.addEventListener('keyup',e=>{if(e.code==='Space'){space=false;dialog.dataset.panning='false';}});
  dialog.addEventListener('focusout',()=>{space=false;dialog.dataset.panning='false';});
  const observer=new ResizeObserver(()=>cameraRender());observer.observe(viewport);
  let savedCamera;try{savedCamera=readCamera(activeTab);}catch{}
  if(savedCamera&&Number.isFinite(savedCamera.x)&&Number.isFinite(savedCamera.y)&&savedCamera.zoom>=.2&&savedCamera.zoom<=2)camera=savedCamera;
  render();if(!savedCamera)fit();saved();post({type:'hello'});announce();viewport.focus({preventScroll:true});
  if(invalid)tell(`Ignored ${invalid} invalid saved changes. The rest of the whiteboard is available.`);
  return {close};
}
