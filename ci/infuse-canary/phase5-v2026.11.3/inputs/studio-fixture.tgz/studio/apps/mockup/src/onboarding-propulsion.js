import * as THREE from 'three';

// Scene-owned exhaust and world-space dust. One clock makes pause/replay exact.
export function createCarPropulsion(car,world){
 const jets=[],particles=[],worldPoint=new THREE.Vector3();
 let previousTime=null,emission=0,cursor=0;
 const nozzleMaterial=new THREE.MeshStandardMaterial({color:0x35454a,metalness:.8,roughness:.25});
 const nozzleGeometry=new THREE.CylinderGeometry(.13,.16,.16,20);
 const plumeGeometry=new THREE.CylinderGeometry(.10,.24,1,20,12,true);
 function plumeMaterial(){return new THREE.ShaderMaterial({
  uniforms:{time:{value:0},power:{value:0},seed:{value:jets.length*2.7}},transparent:true,depthWrite:false,side:THREE.DoubleSide,toneMapped:false,
  vertexShader:'varying vec2 vUv; uniform float time; uniform float seed; void main(){vUv=uv; vec3 p=position; float tail=1.0-uv.y; p.x+=sin(uv.y*19.0-time*24.0+seed)*.035*tail; p.z+=cos(uv.y*23.0-time*19.0+seed)*.035*tail; gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);}',
  fragmentShader:'varying vec2 vUv; uniform float time; uniform float seed; uniform float power; void main(){float life=smoothstep(0.0,.7,vUv.y); float ripple=.74+.26*sin(vUv.y*45.0-time*32.0+seed); float core=pow(vUv.y,4.0); vec3 tint=mix(vec3(.12,.66,.95),vec3(.88,.98,1.0),core); gl_FragColor=vec4(tint,life*ripple*.65*min(power*2.0,1.0));}'
 });}
 function nozzle(position,direction,kind){
  const mount=new THREE.Group();mount.name='thruster-'+kind;mount.position.set(...position);mount.quaternion.setFromUnitVectors(new THREE.Vector3(0,-1,0),new THREE.Vector3(...direction));car.add(mount);
  const rim=new THREE.Mesh(nozzleGeometry,nozzleMaterial);mount.add(rim);
  const plume=new THREE.Mesh(plumeGeometry,plumeMaterial());plume.name='exhaust';plume.visible=false;mount.add(plume);
  jets.push({mount,plume,direction:new THREE.Vector3(...direction),kind});
 }
 for(const x of [-1.03,1.03])for(const z of [-2.15,2.15])nozzle([x,.3,z],[0,-1,0],'lift');
 for(const z of [-.85,.85]){nozzle([-1.55,.68,z],[-1,0,0],'left');nozzle([1.55,.68,z],[1,0,0],'right');}
 for(const x of [-.94,.94]){nozzle([x,.78,3.43],[0,0,1],'rear');nozzle([x,.74,-3.52],[0,0,-1],'front');}
 // Soft, irregular density instead of opaque cones or solid smoke spheres.
 const side=64,data=new Uint8Array(side*side*4);
 for(let y=0;y<side;y++)for(let x=0;x<side;x++){
  const u=(x/side-.5)*2,v=(y/side-.5)*2,r=Math.hypot(u,v),noise=.65+.16*Math.sin(x*.32+y*.21)+.13*Math.cos(y*.46-x*.18);
  const i=(y*side+x)*4;data[i]=data[i+1]=data[i+2]=230;data[i+3]=Math.round(Math.max(0,1-r)**1.3*noise*255);
 }
 const texture=new THREE.DataTexture(data,side,side,THREE.RGBAFormat);texture.needsUpdate=true;
 const smoke=new THREE.Group();smoke.name='ground-smoke';world.add(smoke);
 for(let i=0;i<80;i++){
  const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,color:0xa4b0b5,toneMapped:false,transparent:true,opacity:0,depthWrite:false}));sprite.visible=false;smoke.add(sprite);
  particles.push({sprite,age:9,life:2.4,velocity:new THREE.Vector3(),seed:i*2.39996});
 }
 function emit(jet,groundY,power){
  jet.mount.getWorldPosition(worldPoint);const clearance=worldPoint.y-groundY;
  if(clearance>2.6||clearance<0)return;
  const particle=particles[cursor++%particles.length],a=particle.seed+cursor*.1;
  particle.age=0;particle.life=2.6+(cursor%7)*.14;
  particle.sprite.position.set(worldPoint.x,groundY+.12,worldPoint.z);
  const spread=1.1+power*1.4;particle.velocity.set(Math.cos(a)*spread,.25+(cursor%3)*.09,Math.sin(a)*spread);
  particle.sprite.material.rotation=a;particle.sprite.visible=true;
 }
 function update(power,time=0,{lateral=0,forward=0,groundY=0}={}){
  const dt=previousTime===null?0:Math.min(.1,Math.max(0,time-previousTime));previousTime=time;
  car.updateWorldMatrix(true,true);
  for(const jet of jets){
   const amount=jet.kind==='lift'?power:Math.max(0,-jet.direction.x*lateral-jet.direction.z*forward);
   jet.plume.visible=amount>.025;jet.plume.material.uniforms.time.value=time;jet.plume.material.uniforms.power.value=amount;
   const length=amount*(jet.kind==='lift'?1.85:1.1)*(1+Math.sin(time*27+jet.direction.x)*.06);
   jet.plume.scale.setScalar(jet.kind==='lift'?1:.7);jet.plume.scale.y=length;jet.plume.position.y=-.08-length/2;
  }
  emission+=dt;
  if(emission>=.045){emission=0;if(power>.12)for(const jet of jets)if(jet.kind==='lift')emit(jet,groundY,power);}
  for(const p of particles){
   p.age+=dt;if(p.age>=p.life){p.sprite.visible=false;continue;}
   p.sprite.position.addScaledVector(p.velocity,dt);p.velocity.x*=Math.exp(-dt*.3);p.velocity.z*=Math.exp(-dt*.3);
   const age=p.age/p.life;p.sprite.scale.setScalar(1.1+p.age*1.6);p.sprite.material.opacity=Math.sin(Math.min(1,age*3)*Math.PI/2)*(1-age)*.95;
  }
 }
 function reset(){previousTime=null;emission=0;for(const p of particles){p.age=9;p.sprite.visible=false;}for(const j of jets)j.plume.visible=false;}
 return {update,reset,smoke};
}
