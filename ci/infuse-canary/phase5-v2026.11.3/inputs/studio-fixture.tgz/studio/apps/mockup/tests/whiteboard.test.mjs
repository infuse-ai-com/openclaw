import test from 'node:test';
import assert from 'node:assert/strict';
import { applyOperation, cardsFrom, seedBoard, validOperation, zoomAt, cardVisible, boardPrefix } from '../src/whiteboard-model.js';
const create=()=>{const records=new Map();seedBoard().forEach(op=>applyOperation(records,op));return records;};
const op=(field,value,clock=1,actor='a',node='brief')=>({node,field,value,clock,actor});
test('concurrent fields and late operations converge without replacing other cards',()=>{
  const events=[op('title','My words'),op('body','Literal <script> is text',1,'b'),op('position',{x:-75000,y:30000},2),op('title','Later title',3,'b')];
  const a=create(),b=create();events.forEach(e=>applyOperation(a,e));events.toReversed().forEach(e=>applyOperation(b,e));
  assert.deepEqual(cardsFrom(a),cardsFrom(b));assert.equal(cardsFrom(a).find(c=>c.id==='brief').body,'Literal <script> is text');
  assert.equal(cardsFrom(a).find(c=>c.id==='question').title,'What should happen first?');
  assert.equal(applyOperation(a,events[0]),false);
});
test('same-field collisions have deterministic actor ordering and survive stored replay',()=>{
  const events=[op('body','One',4,'a'),op('body','Two',4,'b')];const a=create(),b=create();
  events.forEach(e=>applyOperation(a,e));events.toReversed().forEach(e=>applyOperation(b,e));assert.deepEqual(cardsFrom(a),cardsFrom(b));
  const restored=new Map();JSON.parse(JSON.stringify([...a.values()].flatMap(fields=>[...fields.values()]))).forEach(e=>applyOperation(restored,e));
  assert.deepEqual(cardsFrom(restored),cardsFrom(a));assert.equal(cardsFrom(a).find(c=>c.id==='brief').body,'Two');
});
test('comments keep exact wording and card anchors; deletion and recovery retain evidence',()=>{
  const a=create(),text='  Mantén este comentario\nexactamente así.  ';
  applyOperation(a,op('comment-one',{text,author:'Fito'},2));applyOperation(a,op('comment-two',{text:'Otro',author:'Invitado'},2,'b'));
  assert.equal(cardsFrom(a).find(c=>c.id==='brief').comments[0].text,text);
  assert.equal(cardsFrom(a).find(c=>c.id==='question').comments.length,0);
  applyOperation(a,op('deleted',true,3));assert.ok(!cardsFrom(a).some(c=>c.id==='brief'));
  applyOperation(a,op('deleted',false,4));assert.equal(cardsFrom(a).find(c=>c.id==='brief').comments.length,2);
});
test('invalid saved records do not poison valid content; rooms have distinct keys',()=>{
  const a=create(),before=cardsFrom(a);
  for(const invalid of [null,{},op('__proto__',{}),op('position',{x:NaN,y:1}),op('body',null),op('size',{w:0,h:1}),op('body','x',Infinity)]){
    assert.equal(Boolean(validOperation(invalid)),false);assert.equal(applyOperation(a,invalid),false);
  }
  assert.deepEqual(cardsFrom(a),before);assert.notEqual(boardPrefix('studio'),boardPrefix('client'));
});
test('zoom preserves the world point under the pointer and distant HTML can be culled',()=>{
  const c={x:170,y:-80,zoom:.8},p={x:510,y:325},next=zoomAt(c,1.4,p);
  assert.ok(Math.abs((p.x-c.x)/c.zoom-(p.x-next.x)/next.zoom)<1e-9);
  assert.ok(Math.abs((p.y-c.y)/c.zoom-(p.y-next.y)/next.zoom)<1e-9);
  assert.equal(zoomAt(c,40,p).zoom,2);
  const card=cardsFrom(create())[0];assert.equal(cardVisible(card,{x:0,y:0,zoom:1},1200,800),true);
  assert.equal(cardVisible(card,{x:-10000,y:-10000,zoom:1},1200,800),false);
});

test('legacy cards stay on Exploration while tabs isolate new content and replay their names',async()=>{
  const {DEFAULT_TAB,tabsFrom}=await import('../src/whiteboard-model.js');const a=create();
  assert.equal(cardsFrom(a,DEFAULT_TAB).length,6);assert.equal(cardsFrom(a,'tab-flow').length,3);
  applyOperation(a,op('tab',{title:'Referencias',order:10},10,'a','tab-custom'));
  const base=cardsFrom(a,DEFAULT_TAB)[0];applyOperation(a,op('card',{...base,tab:'tab-custom'},11,'a','custom-card'));
  applyOperation(a,op('title','Texto propio',12,'b','custom-card'));
  assert.equal(cardsFrom(a,'tab-custom')[0].title,'Texto propio');assert.equal(cardsFrom(a,DEFAULT_TAB).length,6);
  applyOperation(a,op('tab',{title:'Ideas nuevas',order:10},12,'b','tab-custom'));
  const b=new Map();[...a.values()].flatMap(f=>[...f.values()]).toReversed().forEach(o=>applyOperation(b,o));
  assert.deepEqual(tabsFrom(b),tabsFrom(a));assert.deepEqual(cardsFrom(b,'tab-custom'),cardsFrom(a,'tab-custom'));
});
test('connections follow moved shapes and exclude removed or cross-tab endpoints',async()=>{
  const {linksFrom,connectionPath}=await import('../src/whiteboard-model.js');const a=create();
  assert.equal(linksFrom(a,'tab-flow').length,2);const before=cardsFrom(a,'tab-flow');
  const path=connectionPath(before[0],before[1]);applyOperation(a,op('position',{x:-100,y:400},2,'a','flow-0'));
  const after=cardsFrom(a,'tab-flow');assert.notEqual(connectionPath(after[0],after[1]),path);
  applyOperation(a,op('link',{from:'brief',to:'flow-1',tab:'tab-flow'},3,'a','cross-page'));assert.equal(linksFrom(a,'tab-flow').length,2);
  applyOperation(a,op('deleted',true,4,'a','flow-0'));assert.equal(linksFrom(a,'tab-flow').length,1);
  applyOperation(a,op('deleted',false,5,'a','flow-0'));assert.equal(linksFrom(a,'tab-flow').length,2);
  applyOperation(a,op('deleted',true,6,'a','flow-link-0'));assert.equal(linksFrom(a,'tab-flow').length,1);
});
test('style edits merge with text; invalid tab and connector data are rejected',()=>{
  const a=create();applyOperation(a,op('tone','blue',2,'a','flow-0'));applyOperation(a,op('shape','ellipse',2,'b','flow-0'));applyOperation(a,op('title','Start',2,'c','flow-0'));
  const card=cardsFrom(a,'tab-flow')[0];assert.equal(card.tone,'blue');assert.equal(card.shape,'ellipse');assert.equal(card.title,'Start');
  for(const bad of [op('tab',{title:'',order:1}),op('link',{from:'a',to:'a',tab:'tab-flow'}),op('tone','url(script)'),op('shape','unknown')])assert.equal(Boolean(validOperation(bad)),false);
});
