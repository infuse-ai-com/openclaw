import {readLook} from './onboarding-profile.js';
import {partner} from './simulation/reference-catalog.js';
import { assetUrls } from '@studio/ui/assets';
import { currentMission } from './simulation/missions.js';
import { allFloors, companyPeople, floorPeople, projectFloor } from './simulation/company.js';
import { personPresence, stationStatus } from './simulation/presence.js';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { furnishOffice } from '@studio/spatial/office';
import { createBuildingExterior, STOREY_HEIGHT } from '@studio/spatial/building';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { createOfficeMaterials, surfaceUVs } from '@studio/spatial/office-materials';
import { OBJECTS } from './simulation/model.js';
import { OFFICE, OFFICE_ZONES } from './scenarios/catalog.js';

const color = {floor:0xb8b3a0,edge:0x303b3b,wall:0x718380,wood:0x9a7050,dark:0x243433,screen:0xadc9bb,paper:0xece7d6,orange:0xfe5600};
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
export function createWorld(host,{onSelect,onCamera,onExit,onFailure,exploration}) {
  let renderer;
  try {renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});}
  catch {onFailure();return {update(){},destroy(){},zoom(){},home(){},pause(){}};}
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.5));
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.VSMShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.03;
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setClearColor(0x02080b,0);
  host.appendChild(renderer.domElement);
  renderer.domElement.setAttribute('aria-label','Interactive voxel company. Equivalent controls are in the floor and people navigation.');
  renderer.domElement.setAttribute('role','img');renderer.domElement.tabIndex=0;
  const tooltip=document.createElement('div');tooltip.className='world-tooltip';tooltip.hidden=true;host.append(tooltip);
  const scene=new THREE.Scene();
  const camera=new THREE.OrthographicCamera(-15,15,15,-15,.1,150);
  camera.position.set(23,23,29);
  const controls=new OrbitControls(camera,renderer.domElement);
  controls.enableRotate=false;controls.enableDamping=false;controls.minZoom=.65;controls.maxZoom=2.1;
  controls.mouseButtons={LEFT:THREE.MOUSE.PAN,MIDDLE:THREE.MOUSE.DOLLY,RIGHT:THREE.MOUSE.PAN};
  controls.touches={ONE:THREE.TOUCH.PAN,TWO:THREE.TOUCH.DOLLY_PAN};
  controls.screenSpacePanning=false;
  scene.add(new THREE.HemisphereLight(0xf5f2e9,0x746b60,.65));
  const pmrem=new THREE.PMREMGenerator(renderer),environmentRoom=new RoomEnvironment();
  const environment=pmrem.fromScene(environmentRoom,.04);environmentRoom.dispose();pmrem.dispose();
  scene.environment=environment.texture;scene.environmentIntensity=.12;
  const finishes=createOfficeMaterials(renderer),surface=finishes.surface;
  const sun=new THREE.DirectionalLight(0xffecd6,3.25);sun.position.set(-7,15,6);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);
  Object.assign(sun.shadow.camera,{left:-23,right:23,top:28,bottom:-22,near:.5,far:65});sun.shadow.bias=-.00015;sun.shadow.normalBias=.018;sun.shadow.radius=3;sun.shadow.blurSamples=8;scene.add(sun);
  const fill=new THREE.DirectionalLight(0xdce9f0,.42);fill.position.set(15,12,-10);scene.add(fill);
  const connectorLayer=document.createElementNS('http://www.w3.org/2000/svg','svg');connectorLayer.classList.add('world-connectors');connectorLayer.setAttribute('aria-hidden','true');host.append(connectorLayer);
  const labels=document.createElement('div');labels.className='world-labels';host.append(labels);
  let root=new THREE.Group();scene.add(root);
  let state,lastKey='',actors=[],labelEntries=[],objects=[],boardPapers=[],reviewPapers=[],paused=false,disposed=false,suppress=false;
  let baseTarget=new THREE.Vector3(),cameraKey='',selected=null;
  const materials=new Map(),ownedMaterials=[],textures=[],signMaps=new Map();
  const prints=[0,1,2,3].map(()=>{const mat=new THREE.MeshStandardMaterial({color:0xffffff,roughness:1});ownedMaterials.push(mat);return mat;});
  const atlas=new THREE.TextureLoader().load(assetUrls['office-prints.webp'],loaded=>{
    if(disposed)return;
    prints.forEach((mat,i)=>{const map=loaded.clone();map.repeat.set(.5,.5);map.offset.set(i%2*.5,i<2?.5:0);map.colorSpace=THREE.SRGBColorSpace;map.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());map.needsUpdate=true;textures.push(map);mat.map=map;mat.needsUpdate=true;});
  });atlas.colorSpace=THREE.SRGBColorSpace;textures.push(atlas);
  const printMaterial=i=>prints[i];
  function signMaterial(title){
    if(signMaps.has(title))return signMaps.get(title);
    const canvas=document.createElement('canvas');canvas.width=768;canvas.height=256;const ctx=canvas.getContext('2d');
    ctx.fillStyle='#25352d';ctx.font='italic 700 190px Plex, sans-serif';const label=title.length>13?title.slice(0,12)+'…':title;
    ctx.fillText(label,18,193,690);ctx.fillStyle='#fe5600';ctx.fillRect(Math.min(ctx.measureText(label).width+23,710),173,22,22);
    const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace;textures.push(map);const mat=new THREE.MeshBasicMaterial({map,transparent:true});ownedMaterials.push(mat);signMaps.set(title,mat);return mat;
  }
  const composer=new EffectComposer(renderer);
  composer.renderTarget1.samples=composer.renderTarget2.samples=Math.min(4,renderer.capabilities.maxSamples);
  const ao=new SSAOPass(scene,camera,512,512,16);ao.kernelRadius=.52;ao.minDistance=.0015;ao.maxDistance=.12;ao.ssaoMaterial.defines.PERSPECTIVE_CAMERA=0;ao.depthRenderMaterial.defines.PERSPECTIVE_CAMERA=0;
  composer.addPass(new RenderPass(scene,camera));composer.addPass(ao);composer.addPass(new OutputPass());
  materials.set('lamp',new THREE.MeshStandardMaterial({color:0xffe3ab,emissive:0xffbe63,emissiveIntensity:1.3,roughness:.5}));
  const material=(hex)=>{if(hex?.isMaterial)return hex;hex=hex?.isColor?hex.getHex():hex;if(!materials.has(hex))materials.set(hex,new THREE.MeshStandardMaterial({color:hex,roughness:.86,metalness:0}));return materials.get(hex);};
  function box(parent,w,h,d,x,y,z,hex,cast=true){const mesh=new THREE.Mesh(surfaceUVs(new THREE.BoxGeometry(w,h,d),material(hex).userData.surfaceScale),material(hex));mesh.position.set(x,y,z);mesh.castShadow=cast;mesh.receiveShadow=true;parent.add(mesh);return mesh;}
  const exterior=createBuildingExterior({box,ownedMaterials,textures});
  function softBox(parent,w,h,d,x,y,z,hex,radius=.035){const mat=material(hex);const mesh=new THREE.Mesh(surfaceUVs(new RoundedBoxGeometry(w,h,d,1,radius),mat.userData.surfaceScale),mat);mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;}
  function part(parent,id,x,z){const group=new THREE.Group();group.position.set(x,0,z);group.userData.object=id;parent.add(group);objects.push(group);return group;}
  function person(parent,p,x,z){const g=part(parent,p.id,x,z);g.userData.person=p.id;
    const look=p.id==='fito'?readLook(partner(state)):null;
    const outfit=new THREE.Color(look?.shirt||p.color),hair=new THREE.Color(look?.hair||p.hair);
    const skin=look?new THREE.Color(look.skin):0xd1a481,pants=look?new THREE.Color(look.pants):0x283338,shoes=look?new THREE.Color(look.shoes):0x172223;
    const standing=new THREE.Group();g.add(standing);const seated=new THREE.Group();g.add(seated);
    for(const x of [-.18,.18]){box(seated,.27,.23,.5,x,.64,.12,pants);box(seated,.26,.47,.25,x,.34,.32,pants);box(seated,.31,.13,.4,x,.1,.4,shoes);}
    box(standing,.26,.5,.27,-.18,.3,0,pants);box(standing,.26,.5,.27,.18,.3,0,pants);
    box(standing,.31,.13,.4,-.18,.08,.05,shoes);box(standing,.31,.13,.4,.18,.08,.05,shoes);
    const body=new THREE.Group();g.add(body);
    box(body,.64,.55,.36,0,.79,0,outfit);
    const arms=[-.4,.4].map(x=>{
      const shoulder=new THREE.Group();shoulder.position.set(x,1.06,0);body.add(shoulder);
      box(shoulder,.2,.26,.25,0,-.13,0,outfit);
      const elbow=new THREE.Group();elbow.position.y=-.25;shoulder.add(elbow);
      box(elbow,.18,.27,.21,0,-.125,0,outfit);box(elbow,.17,.14,.2,0,-.31,0,look?skin:0xc9946e);
      return {shoulder,elbow};
    });
    const head=new THREE.Group();head.position.y=1.14;head.scale.setScalar(1.08);body.add(head);
    box(head,.5,.47,.44,0,.19,0,skin);box(head,.55,.15,.48,0,.46,-.025,hair);box(head,.55,.3,.14,0,.31,-.22,hair);
    for(const x of [-.115,.115])box(head,.065,.065,.02,x,.22,.23,0x273033);
    box(head,.055,.08,.045,0,.135,.24,look?skin:0xc9946e);box(head,.12,.021,.018,0,.045,.23,0x98664d);
    if(p.id==='kapiteky'){box(head,.42,.06,.04,0,.23,.255,0x334e50);box(head,.26,.16,.045,0,.04,.23,0xcab398);}
    if(p.guest){box(head,.62,.07,.1,0,.23,.27,0x4b3549);box(body,.18,.26,.03,0,.8,.21,0xdbcfe1);}
    if(p.id==='satwa'||look?.detail==='cap')box(head,.6,.1,.65,0,.53,.06,0xd4b066);
    if(p.id==='stewie'||look?.detail==='glasses'){box(head,.6,.06,.045,0,.23,.265,0x1c2528);box(head,.25,.19,.04,0,-.01,.22,0x454b50);}
    if(p.id==='ramiro'){box(body,.2,.35,.03,0,.81,.2,0xeee4cf);box(body,.065,.25,.02,0,.8,.23,0x594e68);}
    if(p.id==='emon'||look?.detail==='badge')box(body,.17,.18,.02,-.17,.85,.19,color.paper);
    if(p.id==='tinus'||look?.detail==='headphones'){box(head,.65,.1,.17,0,.44,0,0x202e3e);for(const x of [-.3,.3])box(head,.09,.26,.24,x,.27,0,0x202e3e);}
    const ring=new THREE.Group();g.add(ring);for(const side of [-1,1]){box(ring,.9,.025,.04,0,.025,side*.45,color.orange,false);box(ring,.04,.025,.9,side*.45,.025,0,color.orange,false);}ring.visible=false;g.userData.ring=ring;
    g.scale.setScalar(.9);g.userData.pose={standing,seated,body,arms,head};return g;
  }
  function addLabel(text,position,onClick,className='',anchor=null){const el=document.createElement('button');el.type='button';el.className=`scene-label ${className}`;el.textContent=text;el.addEventListener('pointerdown',e=>e.stopPropagation());el.onclick=onClick;labels.append(el);let line=null;if(anchor){line=document.createElementNS('http://www.w3.org/2000/svg','line');connectorLayer.append(line);}
    labelEntries.push({el,position,anchor,line});return el;}
  // Batch immutable furniture by its picking identity and material. The mutable
  // papers and the animated characters retain their own meshes.
  function batchFurniture(floor){
    floor.updateMatrixWorld(true);const inverse=floor.matrixWorld.clone().invert();
    const mutable=new Set([...boardPapers.flatMap(p=>[p.mesh,...p.marks]),...reviewPapers.flatMap(p=>[p.mesh,p.pin])]);const batches=new Map();
    floor.traverse(mesh=>{
      if(!mesh.isMesh||mutable.has(mesh))return;
      let object;for(let p=mesh.parent;p&&p!==floor;p=p.parent)if(p.userData.object){object=p.userData.object;break;}
      const key=`${object||''}:${mesh.material.uuid}:${mesh.castShadow}`;
      if(!batches.has(key))batches.set(key,{object,material:mesh.material,cast:mesh.castShadow,meshes:[]});batches.get(key).meshes.push(mesh);
    });
    for(const batch of batches.values()){
      const geometries=batch.meshes.map(mesh=>(mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone()).applyMatrix4(inverse.clone().multiply(mesh.matrixWorld)));
      const geometry=mergeGeometries(geometries);geometries.forEach(g=>g.dispose());
      const mesh=new THREE.Mesh(geometry,batch.material);mesh.castShadow=batch.cast;mesh.receiveShadow=true;mesh.userData.object=batch.object;floor.add(mesh);
      batch.meshes.forEach(old=>{old.removeFromParent();old.geometry.dispose();});
    }
  }
  function floor(parent,id,y){
    const floorInfo=allFloors(state).find(f=>f.id===id),layout=OFFICE;
    const g=new THREE.Group();g.position.y=y;g.userData.floor=id;parent.add(g);objects.push(g);
    const {founderSeat}=furnishOffice(g,layout,floorInfo,{box,softBox,part,material,surface,printMaterial,signMaterial,boardPapers,reviewPapers});
    batchFurniture(g);
    const residents=floorPeople(state,id).filter(p=>p.id!=='fito');
    for(const p of floorPeople(state,id)){
      const index=residents.findIndex(r=>r.id===p.id),slot=layout.workstations[[0,1,2,4,5,6,3,7][index]];
      const pos=p.id==='fito'?founderSeat:[slot.x,slot.z+(slot.facing?-.95:.95)];
      const pg=person(g,p,...pos);pg.rotation.y=p.id==='fito'?0:(slot.facing+Math.PI);
      actors.push({mesh:pg,id:p.id,floor:id,index,base:pg.position.clone(),target:pg.position.clone(),seed:actors.length,rotation:pg.rotation.y});
      {const label=addLabel(p.id==='fito'?partner(state):p.name,new THREE.Vector3(0,1.55,0),()=>onSelect({object:p.id}),'person-label',pg);label.dataset.personLabel=p.id;}
    }
    {
      const positions={entrance:[-3.1,3.15,5.8],founder:[-7.4,2.15,1.2],whiteboard:[-8.65,2.9,-5.6],team:[.4,2.65,-5.4],shelf:[-4.7,3,-5.8],review:[10.2,3.2,-.6],operations:[8.2,3.1,-5.5],lounge:[6.75,1.65,4.15]};
      for(const zone of OFFICE_ZONES){const label=addLabel(zone.label,new THREE.Vector3(...positions[zone.id]),()=>onSelect({object:zone.id}),'object-label');label.dataset.sceneObject=zone.id;label.title=zone.description;label.setAttribute('aria-label',`${zone.label}: ${zone.description}`);}
    }
  }
  function clear(){tooltip.hidden=true;exterior.clear();root.traverse(o=>{if(o.geometry)o.geometry.dispose();});scene.remove(root);root=new THREE.Group();scene.add(root);labels.replaceChildren();connectorLayer.replaceChildren();actors=[];labelEntries=[];objects=[];boardPapers=[];reviewPapers=[];}
  function resetCamera(saved){
    suppress=true;const building=state.view==='building';baseTarget.set(0,building?allFloors(state).length*STOREY_HEIGHT/2:1.1,0);
    Object.assign(sun.shadow.camera,building?{left:-23,right:23,top:28,bottom:-22}:{left:-16,right:16,top:17,bottom:-17});sun.shadow.camera.updateProjectionMatrix();
    controls.target.copy(baseTarget);controls.target.x+=saved?.x||0;controls.target.z+=saved?.y||0;
    camera.position.copy(controls.target).add(building?new THREE.Vector3(-14,13,30):new THREE.Vector3(-10,24,30));camera.zoom=clamp(saved?.zoom||1,.65,2.1);
    resize();controls.update();suppress=false;
  }
  function resize(){exploration?.invalidate();const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;const ratio=Math.min(window.devicePixelRatio,1.5);if(renderer.getPixelRatio()!==ratio){renderer.setPixelRatio(ratio);composer.setPixelRatio(ratio);}renderer.setSize(w,h,false);composer.setSize(w,h);const height=state?.view==='building'?Math.max(23,allFloors(state).length*STOREY_HEIGHT+9,34*h/w):Math.max(17.8,25.2*h/w);camera.left=-height*w/h/2;camera.right=height*w/h/2;camera.top=height/2;camera.bottom=-height/2;camera.updateProjectionMatrix();}
  const observer=new ResizeObserver(resize);observer.observe(host);
  controls.addEventListener('change',()=>{
    if(!state||suppress||exploration?.active())return;
    const old=controls.target.clone();controls.target.x=clamp(controls.target.x,-8,8);controls.target.z=clamp(controls.target.z,-5,5);controls.target.y=baseTarget.y;camera.position.add(controls.target.clone().sub(old));
    onCamera(cameraKey,{x:controls.target.x,y:controls.target.z,zoom:camera.zoom});
    if(state.view==='floor'&&camera.zoom<=.66)exploration?.open();
  });
  let down=null;const ray=new THREE.Raycaster();const pointer=new THREE.Vector2();
  renderer.domElement.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY};});
  function hit(e){const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);return ray.intersectObject(root,true).find(hit=>{for(let object=hit.object;object;object=object.parent)if(!object.visible)return false;return true;})?.object;}
  function identity(mesh){let object=null,floorId=null;for(let o=mesh;o;o=o.parent){object ||= o.userData.object;floorId ||= o.userData.floor;}return {object,floor:floorId};}
  renderer.domElement.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down.x,e.clientY-down.y)>7)return;const mesh=hit(e);if(mesh){const found=identity(mesh);if(exploration?.active()){exploration.pick(found.floor);down=null;return;}if(state.view==='building'?found.floor:found.object)onSelect(state.view==='building'?{floor:found.floor}:{object:found.object});}down=null;});
  renderer.domElement.addEventListener('pointermove',e=>{const mesh=hit(e);const id=mesh?identity(mesh):{};if(exploration?.active()){if(id.floor)exploration.select(id.floor);renderer.domElement.style.cursor=id.floor?'pointer':'default';tooltip.hidden=true;return;}exterior.highlight(state.view==='building'?id.floor:null);renderer.domElement.style.cursor=id.object||id.floor?'pointer':'grab';host.dataset.hover=id.object||id.floor||'';const personInfo=companyPeople(state).find(p=>p.id===id.object),objectInfo=OBJECTS.find(p=>p[0]===id.object);tooltip.textContent=state.view==='building'?(id.floor?`Enter ${allFloors(state).find(f=>f.id===id.floor)?.title}`:''):personInfo?`${personInfo.name} · ${personPresence(state,personInfo.id).label}`:objectInfo?`${objectInfo[1]} · ${stationStatus(state,objectInfo[0])}`:'';tooltip.hidden=!tooltip.textContent;const rect=host.getBoundingClientRect();tooltip.style.left=`${Math.min(e.clientX-rect.left+12,host.clientWidth-240)}px`;tooltip.style.top=`${e.clientY-rect.top+16}px`;});
  renderer.domElement.addEventListener('pointerleave',()=>{tooltip.hidden=true;exterior.highlight(null);});
  renderer.domElement.addEventListener('keydown',e=>{if(exploration?.key(e))return;const directions={ArrowLeft:[-.5,0],ArrowRight:[.5,0],ArrowUp:[0,-.5],ArrowDown:[0,.5]};if(directions[e.key]){e.preventDefault();const [x,z]=directions[e.key];controls.target.x+=x;controls.target.z+=z;camera.position.x+=x;camera.position.z+=z;controls.dispatchEvent({type:'change'});}if(e.key==='Escape'&&!state.peekPerson)onExit();});
  function exploreWheel(e){
    if(!exploration||state?.view!=='floor'||state.surface)return;
    const label=e.target.closest?.('[data-fx-floor]');
    if(exploration.wheel(e,()=>label?.dataset.fxFloor||identity(hit(e)).floor)){e.preventDefault();e.stopImmediatePropagation();}
  }
  // Capture before OrbitControls so one wheel gesture owns both normal zoom
  // and the continuous pullback, including wheel input over projected labels.
  host.addEventListener('wheel',exploreWheel,{capture:true,passive:false});
  renderer.domElement.addEventListener('wheel',e=>{if(state?.view==='floor'&&camera.zoom<=.66&&e.deltaY>0)onExit();},{passive:false});
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();paused=true;onFailure();});
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
  exploration?.bind({host,canvas:renderer.domElement,camera,controls,root:()=>root,home:()=>resetCamera(),
    setFloorZoom:zoom=>{camera.zoom=zoom;camera.updateProjectionMatrix();onCamera(cameraKey,{x:controls.target.x,y:controls.target.z,zoom});},
    restoreCamera:pose=>{suppress=true;controls.target.copy(pose.target);camera.position.copy(pose.position);camera.zoom=pose.zoom;camera.updateProjectionMatrix();controls.update();suppress=false;onCamera(cameraKey,{x:controls.target.x,y:controls.target.z,zoom:camera.zoom});},
    hideDetails:value=>{labels.inert=value;tooltip.hidden=true;},
    decorate:(object,title)=>{const signs=new Set(signMaps.values());object.traverse(mesh=>{if(signs.has(mesh.material))mesh.material=signMaterial(title);});},
    mountExterior:(floors,addEntry)=>{
      const group=new THREE.Group();root.add(group);
      exterior.build(group,floors.toReversed(),addEntry,()=>{});
      // Fade temporary facade materials without changing the office's materials.
      const copies=new Map();
      group.traverse(mesh=>{
        if(!mesh.isMesh)return;
        const original=mesh.material;
        if(!copies.has(original))copies.set(original,{material:original.clone(),opacity:original.opacity,depthWrite:original.depthWrite});
        mesh.material=copies.get(original).material;mesh.material.transparent=true;
      });
      return {
        group,highlight:id=>exterior.highlight(id),
        opacity:value=>{group.visible=value>.001;for(const copy of copies.values()){copy.material.opacity=copy.opacity*value;copy.material.depthWrite=copy.depthWrite&&value>.98;}},
        destroy:()=>{group.removeFromParent();group.traverse(mesh=>mesh.geometry?.dispose());for(const copy of copies.values())copy.material.dispose();exterior.clear();},
      };
    }
  });
  function update(next){exploration?.sync(next);state=next;cameraKey=state.view==='building'?'building':state.floor;const key=JSON.stringify([state.view,state.floor,state.settings,state.projects,state.guests,readLook(partner(state)),partner(state),allFloors(state).map(f=>floorPeople(state,f.id).map(p=>p.id))]);
    if(lastKey!==key){clear();if(state.view==='building'){exterior.build(root,allFloors(state),addLabel,onSelect);}else floor(root,state.floor,0);labelEntries.sort((a,b)=>Number(Boolean(a.anchor))-Number(Boolean(b.anchor)));lastKey=key;resetCamera(state.cameras[cameraKey]);}
    const m=state.mission;
    for(const a of actors){
      const presence=personPresence(state,a.id,a.floor);
      const layout=OFFICE;
      a.tone=presence.tone;
      a.mesh.userData.ring.visible=a.floor===state.floor&&(state.peekPerson===a.id||presence.tone==='working');
      a.target.copy(a.base);
      const sitting=a.id==='fito'||presence.station==='team';
      const pose=a.mesh.userData.pose;
      a.station=presence.station;a.sitting=sitting;
      pose.standing.visible=!sitting;pose.seated.visible=sitting;pose.body.position.set(0,sitting?.18:0,sitting?.1:0);
      pose.head.rotation.set(sitting?.12:0,sitting?(a.seed%2?-.07:.07):0,0);
      for(const [i,arm] of pose.arms.entries()){
        const pointing=!sitting&&i===1&&['whiteboard','review'].includes(a.station);
        arm.shoulder.rotation.set(sitting?-1.08:pointing?(a.station==='whiteboard'?1.25:-1.4):-.07,0,sitting?(i?-.14:.14):(i?-.07:.07));
        arm.elbow.rotation.x=sitting?-.48:pointing?(a.station==='whiteboard'?.5:-.55):-.13;
        arm.rest={x:arm.shoulder.rotation.x,elbow:arm.elbow.rotation.x};
      }
      a.facing=a.rotation;
      if(a.id==='fito'||(a.floor!=='studio'&&!currentMission(state,a.floor)))continue;
      const index=a.index,station=presence.station,column=index%3,row=Math.floor(index/3);
      const selected=currentMission(state,a.floor);
      const staged=selected?selected.status==='draft':state.mission.phase==='shaping';
      const places={
        whiteboard:[layout.board[0]+1.75-column*1.55,layout.board[1]+.85+row*3.3],
        lounge:[layout.lounge[0]-1+column,layout.lounge[1]-.4+row*2.2],
        operations:[layout.operations[0]+.62,layout.operations[1]+1.45],
        review:[9.45-column*.64,-1.3+row*2.2]
      };
      if(places[station]){a.target.set(places[station][0],0,places[station][1]);a.facing=station==='review'?Math.PI/2:station==='whiteboard'?.15:Math.PI;}
      if(staged&&station==='review')a.target.set(9.5,0,-1.25);

    }
    for(const label of labelEntries){
      const id=label.el.dataset.personLabel;if(!id)continue;
      const presence=personPresence(state,id);
      label.el.textContent=presence.name;
      label.el.dataset.tone=presence.tone;
      label.el.classList.toggle('is-inspected',state.peekPerson===id);
      label.el.setAttribute('aria-label',`Inspect ${presence.name}: ${presence.label}`);
      label.el.title=`${presence.label} · ${presence.task}`;
    }
    const filled=Object.values(m.content).filter(v=>v.trim()).length;
    for(const paper of boardPapers){const selected=currentMission(state,paper.floor);if(selected){const filled=Object.values(selected.content).filter(v=>v.trim()).length;paper.mesh.material=material(paper.index<filled?0xe0ba6e:0xd0cabb);for(const mark of paper.marks)mark.visible=paper.index<filled;continue;}paper.mesh.material=material(paper.floor==='studio'?(paper.index<filled?0xe0ba6e:0xd0cabb):projectFloor(state,paper.floor)?(paper.index===0?0xaa8fbe:0xd0cabb):0x7faaa1);for(const mark of paper.marks)mark.visible=paper.floor==='studio'?paper.index<filled:paper.index<2;}
    for(const paper of reviewPapers){const selected=currentMission(state,paper.floor);if(selected){paper.mesh.visible=paper.pin.visible=(selected.execution?selected.execution.tasks.some(t=>t.evidence.length):selected.events.some(e=>e.type==='task_delivered'));paper.mesh.material=material(color.paper);continue;}paper.mesh.visible=paper.pin.visible=paper.floor==='client'||(paper.floor==='studio'&&Boolean(m.artifact));paper.mesh.material=material(paper.floor==='studio'&&m.artifact&&m.sourceRevision!==m.artifact.sourceRevision?0xe0ba6e:color.paper);}

  }
  const projected=new THREE.Vector3(),anchorPosition=new THREE.Vector3();let last=0;
  renderer.setAnimationLoop(t=>{
    if(disposed||paused||document.hidden)return;
    const dt=Math.min((t-last)/1000,.05);last=t;
    if(exploration?.tick(performance.now())===false)return;
    for(const a of actors){
      a.mesh.position.lerp(a.target,reduced.matches?1:1-Math.exp(-dt*8));a.mesh.position.y=0;a.mesh.rotation.y=a.facing;
      const pose=a.mesh.userData.pose,working=a.tone==='working'&&!reduced.matches;
      // Quiet people hold their pose. Only the current named work event animates.
      pose.head.rotation.x=(a.sitting?.12:0)+(working?Math.sin(t*.0015+a.seed)*.035:0);
      pose.head.rotation.y=(a.sitting?(a.seed%2?-.07:.07):0)+(working?Math.sin(t*.0008+a.seed)*.045:0);
      for(const [i,arm] of pose.arms.entries()){
        const movement=working&&(a.sitting||i===1)?Math.sin(t*(a.sitting?.005:.0016)+a.seed+i)*.035:0;
        arm.shoulder.rotation.x=arm.rest.x+movement;arm.elbow.rotation.x=arm.rest.elbow+movement;
      }
    }
    ao.ssaoMaterial.uniforms.cameraProjectionMatrix.value.copy(camera.projectionMatrix);ao.ssaoMaterial.uniforms.cameraInverseProjectionMatrix.value.copy(camera.projectionMatrixInverse);
    composer.render();
    const occupied=[];
    for(const l of labelEntries){
      if(l.anchor){l.anchor.getWorldPosition(anchorPosition);projected.copy(anchorPosition).add(l.position);}else projected.copy(l.position);
      projected.project(camera);const originX=(projected.x*.5+.5)*host.clientWidth,originY=(-projected.y*.5+.5)*host.clientHeight;
      let x=originX,y=originY;const width=l.el.offsetWidth||65,height=l.el.offsetHeight||26;
      if(l.anchor){
        const offsets=[[0,0],[-48,0],[48,0],[0,-30],[-80,-15],[80,-15],[-100,-42],[100,-42],[0,-65]];
        for(const [dx,dy] of offsets){x=originX+dx;y=originY+dy;if(!occupied.some(r=>Math.abs(r.x-x)<(r.width+width)/2+4&&Math.abs(r.y-(y-height/2))<(r.height+height)/2+4))break;}
      }
      occupied.push({x,y:l.anchor?y-height/2:y,width,height});l.el.style.left=`${x}px`;l.el.style.top=`${y}px`;
      const hidePerson=l.anchor&&state.peekPerson!==l.el.dataset.personLabel&&host.dataset.hover!==l.el.dataset.personLabel&&l.el.dataset.tone!=='working';const hidden=hidePerson||projected.z>1||Math.abs(projected.x)>1||Math.abs(projected.y)>1;l.el.hidden=hidden;
      if(l.line){l.line.setAttribute('x1',originX);l.line.setAttribute('y1',originY+10);l.line.setAttribute('x2',x);l.line.setAttribute('y2',y);l.line.style.display=hidden?'none':'';}
    }
  });
  return {
    focusZone(id){
      if(state?.view!=='floor')return;
      const point=({whiteboard:OFFICE.board,team:OFFICE.team,shelf:OFFICE.shelf,review:OFFICE.review,operations:OFFICE.operations,lounge:OFFICE.lounge,founder:OFFICE.founder,entrance:OFFICE.entrance})[id];
      if(!point)return;
      controls.target.set(point[0]*.65,1.1,point[1]*.65);
      camera.position.copy(controls.target).add(new THREE.Vector3(-10,24,30));camera.zoom=1.25;camera.updateProjectionMatrix();controls.update();
      for(const label of labels.querySelectorAll('[data-scene-object]'))label.classList.toggle('is-welcome-zone',label.dataset.sceneObject===id);
    },
    update, zoom(delta){if(exploration?.zoom(delta))return;if(state?.view==='floor'&&camera.zoom<=.66&&delta<0){onExit();return;}camera.zoom=clamp(camera.zoom+delta,.65,2.1);camera.updateProjectionMatrix();controls.dispatchEvent({type:'change'});},
    home(){if(exploration?.home())return;resetCamera();onCamera(cameraKey,{x:0,y:0,zoom:1});},pause(value){paused=value;if(value)tooltip.hidden=true;},
    destroy(){disposed=true;exploration?.destroy();host.removeEventListener('wheel',exploreWheel,true);renderer.setAnimationLoop(null);observer.disconnect();controls.dispose();clear();materials.forEach(m=>m.dispose());ownedMaterials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());finishes.dispose();exterior.dispose();environment.dispose();ao.noiseTexture.dispose();ao.ssaoMaterial.dispose();ao.dispose();composer.passes.at(-1).dispose();composer.dispose();renderer.dispose();labels.remove();connectorLayer.remove();renderer.domElement.remove();}
  };
}
