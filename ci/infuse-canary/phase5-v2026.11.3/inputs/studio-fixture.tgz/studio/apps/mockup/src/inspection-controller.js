import {currentMission} from './simulation/missions.js';
import {canDecide} from './simulation/connected.js';
import {partner,canManage} from './simulation/reference-catalog.js';
import {selectedArtifact,selectedRevision} from './artifact-workspace.js';
import {decisionIdentity} from './mission-inspection.js';
export function createInspectionController({getState,dispatch,render,open}){
 const views=new Map(),artifactViews=new Map();let hashRequest=0;
 const view=()=>{const s=getState(),key=`${partner(s)}:${s.floor}:${currentMission(s)?.id||''}`;if(!views.has(key))views.set(key,{section:'tasks',thread:'coordination',drafts:{}});return views.get(key);};
 const artifacts=()=>{const floor=getState().floor;if(!artifactViews.has(floor))artifactViews.set(floor,{query:'',scope:'all',artifact:null,page:'index.html'});return artifactViews.get(floor);};
 function refresh(){render();document.querySelector('.inspection-workspace')?.scrollTo({top:0});document.querySelector('.inspection-tabs [aria-current="page"]')?.focus({preventScroll:true});}
 async function digest(){const v=artifacts(),a=selectedArtifact(getState(),v),r=selectedRevision(a,v);if(!r)return;const page=r.pages.includes(v.page)?v.page:r.pages[0],token=++hashRequest;v.digest='';const bytes=new TextEncoder().encode(r.content(page));const hash=await crypto.subtle.digest('SHA-256',bytes);if(token===hashRequest){v.digest=[...new Uint8Array(hash)].map(n=>n.toString(16).padStart(2,'0')).join('');if(getState().surface==='artifacts'&&artifacts()===v)render();}}
 const send=(type,extra={})=>dispatch({type,...extra});
 document.addEventListener('input',e=>{if(e.target.matches('#inspection-comment textarea'))view().drafts[view().thread||'coordination']=e.target.value;});
 document.addEventListener('click',e=>{
  const b=e.target.closest('[data-inspect]');if(!b||b.disabled)return;
  const a=b.dataset.inspect,v=view(),av=artifacts(),s=getState(),m=currentMission(s);
  if(a==='restore-access'){send('CONNECTED_MODE',{value:'ready'});return;}
  if(['expire','deny','offline','signout'].includes(a)){send('CONNECTED_MODE',{value:{expire:'expired',deny:'denied',offline:'offline',signout:'signed-out'}[a]});return;}
  if(a==='section'){v.section=b.dataset.value;refresh();return;}
  if(a==='task'){v.task=b.dataset.id;render();document.querySelector('.inspection-task-detail h2')?.setAttribute('tabindex','-1');document.querySelector('.inspection-task-detail h2')?.focus();return;}
  if(a==='thread'){v.thread=b.dataset.id;v.threadLink=false;render();document.querySelector('#inspection-comment textarea')?.focus();return;}
  if(a==='thread-link'){v.threadLink=!v.threadLink;render();return;}
  if(a==='transport'){send('CONNECTED_TRANSPORT');return;}
  if(a==='transport-reconcile'){send('CONNECTED_TRANSPORT_RECONCILE');return;}
  if(a==='comment-reconcile'){send('CONNECTED_COMMENT_RECONCILE',{id:b.dataset.id});document.querySelector('#inspection-comment textarea')?.focus();return;}
  if(a==='decision'){v.decision={action:b.dataset.value,identity:decisionIdentity(m)};v.stale=false;render();document.querySelector('.inspection-decision button')?.focus();return;}
  if(a==='decision-dismiss'){v.decision=null;render();return;}
  if(a==='decision-stale'){v.stale=true;render();return;}
  if(a==='decision-refresh'){v.decision.identity=decisionIdentity(m);v.stale=false;v.section='paper';render();return;}
  if(a==='decision-confirm'){if(!v.decision||v.stale||v.decision.identity!==decisionIdentity(m)||!canDecide(s)||!canManage(s,m))return;const event={hold:'CONNECTED_HOLD',resume:'CONNECTED_RESUME',cancel:'CONNECTED_CANCEL'}[v.decision.action];v.decision=null;if(event)send(event);return;}
  if(a==='artifact-open'){Object.assign(av,{artifact:b.dataset.id,revision:null,page:'index.html',expanded:false,digest:''});render();void digest();return;}
  if(a==='artifact-back'){av.artifact=null;hashRequest++;render();return;}
  if(a==='artifact-clear'){av.query='';av.scope='all';render();return;}
  if(a==='artifact-expand'){av.expanded=!av.expanded;render();return;}
  if(a==='mission-artifacts'){Object.assign(av,{artifact:null,scope:'mission',query:''});open('artifacts');return;}
  if(a==='artifact-download'){
   if(!canDecide(s))return;const item=selectedArtifact(s,av),r=selectedRevision(item,av);if(!r)return;const page=r.pages.includes(av.page)?av.page:r.pages[0];const url=URL.createObjectURL(new Blob([r.content(page)],{type:'text/html;charset=utf-8'}));const link=document.createElement('a');link.href=url;link.download=`artifact-r${r.revision}-${page}`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return;
  }
  if(a==='example'){
   if(!canDecide(s))return;
   const existing=s.missionDesk.items.find(m=>m.floorId===s.floor&&m.title==='A clearer partner handoff · inspection example');
   if(existing){send('MISSION_SELECT',{id:existing.id});return;}
   send('MISSION_NEW');send('MISSION_EDIT',{field:'title',value:'A clearer partner handoff · inspection example'});send('MISSION_EDIT',{field:'intent',value:'Create a concise partner handoff with the outcome, open questions and next decision in one place.'});send('MISSION_STEP',{stage:'shape'});for(const id of ['outcome','scope','evidence'])send('MISSION_CONFIRM',{id,inline:true});send('MISSION_STEP',{stage:'review'});send('MISSION_APPROVE',{revision:currentMission(getState()).revision});
   for(let i=0;i<3;i++)send('MISSION_ADVANCE');
   send('CONNECTED_FEEDBACK',{text:'Make the next decision explicit and keep the handoff readable on mobile.'});send('MISSION_ADVANCE');send('MISSION_ADVANCE');
   const example=currentMission(getState()),t=example.execution?.tasks.find(t=>t.evidence.length);if(t)send('CONNECTED_PUBLISH',{task:t.id,revision:t.evidence.at(-1).revision});
   view().section='tasks';render();return;
  }
 });
 document.addEventListener('change',e=>{
  const key=e.target.dataset.inspectSelect;if(!key)return;const v=artifacts();
  if(key==='scope'&&['all','standalone','mission'].includes(e.target.value))v.scope=e.target.value;
  if(key==='revision'){v.revision=Number(e.target.value);v.page='index.html';v.digest='';}
  if(key==='page'){v.page=e.target.value;v.digest='';}
  render();if(key!=='scope')void digest();
 });
 document.addEventListener('submit',e=>{
  if(e.target.id==='artifact-search'){e.preventDefault();artifacts().query=new FormData(e.target).get('query').toString();render();return;}
  if(e.target.id!=='inspection-comment')return;e.preventDefault();const s=getState(),m=currentMission(s),v=view(),d=new FormData(e.target),thread=v.thread||'coordination';
  if(!canDecide(s)||!m?.execution||m.execution.comments?.some(c=>c.thread===thread&&c.author===partner(s)&&c.delivery==='uncertain'))return;
  send('CONNECTED_COMMENT',{commandId:crypto.randomUUID(),text:d.get('text'),thread,uncertain:d.get('uncertain')==='on'});v.drafts[thread]='';render();document.querySelector('[data-inspect=comment-reconcile],#inspection-comment textarea')?.focus();
 });
 return {view,artifacts,reset(){views.clear();artifactViews.clear();hashRequest++;}};
}
