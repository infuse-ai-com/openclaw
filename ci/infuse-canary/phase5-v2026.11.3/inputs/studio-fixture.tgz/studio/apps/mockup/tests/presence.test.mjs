import { test } from 'node:test';
import assert from 'node:assert/strict';
import { initialState, transition as t, SECTIONS, PEOPLE, planSteps, restoreState } from '../src/simulation/model.js';
import { personPresence, workMoment, stationStatus } from '../src/simulation/presence.js';
function running(){let s=initialState();for(const x of SECTIONS)s=t(s,{type:'EDIT',id:x.id,value:x.suggestions[0]});s=t(s,{type:'APPROVE_PAPER'});s=t(s,{type:'SQUAD',id:'tinus'});s=t(s,{type:'SQUAD',id:'satwa'});return t(t(s,{type:'CONFIRM_SQUAD'}),{type:'LAUNCH'});}
test('only the current step owner works; uninvited people stay available and completed people hand over',()=>{
  let s=running();while(s.mission.phase==='running'){
    const moment=workMoment(s),workers=PEOPLE.filter(p=>personPresence(s,p.id).tone==='working');
    assert.deepEqual(workers.map(p=>p.id),[moment.next.owner]);assert.equal(personPresence(s,'tinus').label,'Available');assert.equal(personPresence(s,'tinus').station,'team');
    assert.equal(personPresence(s,moment.next.owner).output,moment.next.output);
    const previous=moment.next;s=t(s,{type:'ADVANCE'});assert.equal(workMoment(s).last.title,previous.title);
  }
  for(const id of s.mission.squad)assert.equal(personPresence(s,id).station,'review');
  assert.equal(personPresence(s,'fito').label,'Your decision');assert.match(stationStatus(s,'review'),/ready for review/);
});
test('example floor presence does not claim playable assignments or change the mission',()=>{
  const s=running(),before=structuredClone(s);for(const id of s.mission.squad){assert.equal(personPresence(s,id,'client').label,'Example presence');assert.equal(personPresence(s,id,'growth').tone,'quiet');}
  assert.deepEqual(s,before);assert.equal(stationStatus(s,'review','client'),'Example initiative');
});
test('quick inspection preserves mission and camera and closes on surface or floor navigation',()=>{
  let s=t(running(),{type:'ENTER_FLOOR',id:'studio'});s=t(s,{type:'CAMERA',key:'studio',x:2,y:1,zoom:1.2});const before=structuredClone(s);
  s=t(s,{type:'INSPECT_PERSON',id:'satwa'});assert.equal(s.peekPerson,'satwa');assert.equal(s.surface,null);assert.deepEqual(s.mission,before.mission);assert.deepEqual(s.cameras,before.cameras);
  assert.equal(t(s,{type:'OPEN',surface:'people',person:'satwa'}).peekPerson,null);assert.equal(t(s,{type:'BUILDING'}).peekPerson,null);assert.equal(t(s,{type:'ENTER_FLOOR',id:'client'}).peekPerson,null);
  const saved=restoreState(JSON.stringify(s));assert.equal(saved.notice,null);assert.equal(saved.state.peekPerson,null);assert.deepEqual(saved.state.mission,s.mission);
});
