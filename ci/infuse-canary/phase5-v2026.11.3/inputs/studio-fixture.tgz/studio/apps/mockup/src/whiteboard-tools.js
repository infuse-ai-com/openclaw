const svg=paths=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
export const toolIcons={
 select:svg('<path d="m5 3 14 9-7 1-3 7Z"/>'),
 hand:svg('<path d="M8 13V6a2 2 0 0 1 4 0v6-8a2 2 0 0 1 4 0v8-5a2 2 0 0 1 4 0v8c0 4-2 6-6 6h-1c-3 0-4-2-6-4l-3-4a2 2 0 0 1 3-2l1 2Z"/>'),
 note:svg('<path d="M4 3h16v12l-5 6H4Z M15 21v-6h5 M8 8h8 M8 12h5"/>'),
 text:svg('<path d="M4 5V3h16v2 M12 3v18 M8 21h8"/>'),
 shape:svg('<rect x="3" y="3" width="13" height="13" rx="2"/><circle cx="16" cy="16" r="5"/>'),
 document:svg('<path d="M5 3h10l4 4v14H5Z M15 3v5h4 M9 12h6 M9 16h6"/>'),
 connect:svg('<path d="M3 5h5a3 3 0 0 1 3 3v8a3 3 0 0 0 3 3h7 M17 15l4 4-4 4"/><circle cx="3" cy="5" r="2"/>'),
 comment:svg('<path d="M21 15a3 3 0 0 1-3 3H9l-6 4V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3Z M7 8h10 M7 12h6"/>'),
 duplicate:svg('<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M15 4H4v12"/>'),
 delete:svg('<path d="M3 6h18 M9 6V3h6v3 M6 6l1 15h10l1-15 M10 10v7 M14 10v7"/>')
};
export const toolDefinitions=[['select','Select','V'],['hand','Hand','H'],['note','Note','N'],['text','Text','T'],['shape','Shape','R'],['document','Document','D'],['connect','Connector','L'],['comment','Comment','C']];
export function toolsMarkup(){return toolDefinitions.map(([id,label,key],i)=>`${[2,6,7].includes(i)?'<i class="wb-tool-divider"></i>':''}<button type="button" data-wb="${id}" class="wb-tool" aria-label="${label}" aria-pressed="${id==='select'}" title="${label} (${key})">${toolIcons[id]}<span>${label}</span><kbd>${key}</kbd></button>`).join('');}
