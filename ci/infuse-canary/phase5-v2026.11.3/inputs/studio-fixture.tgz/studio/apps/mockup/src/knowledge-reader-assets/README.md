# Reference provenance

- Office geometry and INFUSE assets: existing Studio `packages/spatial`,
  `packages/ui` and `apps/mockup/src/world.js`; no new brand artwork.
- Knowledge reader: source-derived composition and visual values from Knowledge
  Base commit `fe0600754f53a30b2dc6a3ad14384468493ac0be`, specifically
  `apps/web/src/components/ReaderHeader.tsx`, `DocumentPanel.tsx`,
  `ReadingSettings.tsx`, `LibraryHome.tsx`, `LibraryPanel.tsx`, the Explore product
  contract and `styles.css`. The local donor is still at this commit on 2026-10-11. Existing KB build inspected locally with
  synthetic API responses. No private corpus or credentials are copied.
- Google Sans Flex variable font: KB's pinned `@fontsource-variable/google-sans-flex`
  package 5.3.1. Its OFL license accompanies the local font.
- Article, project, PR/build references and onboarding candidate: authored synthetic
  fixtures. The preview now covers six synthetic documents per project: Library Home,
  keyword/type/repository filtering, authored relationships, reading, revision
  history and session-only exact-revision review. Real attestations, semantic
  search, graph pan/zoom, arbitrary version diffing, full IKF facets and live
  repositories remain in the KB migration plan. No claim of migration parity.

- Studio integration refinement (2026-10-11): the shared icon rail, compact
  Knowledge toolbar and unframed white surface supersede the embedded app chrome.
  Navigation uses Studio tokens/Plex; article typography and reading controls
  retain the source-derived KB behavior. The local preview is an adaptation,
  not a pixel-identical copy of the standalone application.
