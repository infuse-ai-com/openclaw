import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {createOfficeCharacter} from '@studio/spatial/character';
import {createBuildingExterior} from '@studio/spatial/building';
import {createWelcomeCar} from './onboarding-car.js';
import {characterLook} from './onboarding-profile.js';

// A mockup-only cinematic. It owns geometry and timing, never mission state.
export function createWelcomeScene(host,{chapter,look,onFailure,onSettled,onEnter,onBeat}){
 let renderer;
 try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'low-power'});}catch{onFailure();return null;}
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.2;
 renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;
 host.append(renderer.domElement);renderer.domElement.setAttribute('role','img');
 renderer.domElement.setAttribute('aria-label',['Your adjustable 3D character','Your character boarding a white flying coupe for a solo flight','Your flying car landing on the neighbouring rooftop beside Studio'][chapter]);
 const scene=new THREE.Scene();scene.background=new THREE.Color(chapter===2?0xdce3d9:0xe9e4d8);
 const camera=new THREE.PerspectiveCamera(35,1,.1,180);
 scene.add(new THREE.HemisphereLight(0xfff2dc,0x718c7e,2.4));
 const sun=new THREE.DirectionalLight(0xffdda9,4);sun.position.set(-10,20,15);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);
 Object.assign(sun.shadow.camera,{left:-25,right:25,top:25,bottom:-25,near:.1,far:70});sun.shadow.bias=-.001;scene.add(sun);
 const fill=new THREE.DirectionalLight(0xc6e6f6,1.5);fill.position.set(10,6,-10);scene.add(fill);
 const root=new THREE.Group();scene.add(root);const materials=new Map(),actors=[];
 let character=null,car=null,exterior=null,rotation=.2,disposed=false,dirty=true,flight=null;
 const ownedMaterials=[],textures=[];
 let vehicle=null,paused=false,time=0,lastFrame=null,lastBeat='';
 let pendingEntry=false;
 const cameraTarget=new THREE.Vector3(0,3,0),walkers=[];
 const smooth=t=>{t=THREE.MathUtils.clamp(t,0,1);return t*t*(3-2*t);};
 function beat(id,text){if(lastBeat===id)return;lastBeat=id;host.dataset.journeyPhase=id;onBeat?.(text);}
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 function material(value){if(value?.isMaterial)return value;const color=value?.isColor?value.getHex():value;if(!materials.has(color))materials.set(color,new THREE.MeshStandardMaterial({color,roughness:.72}));return materials.get(color);}
 function box(p,w,h,d,x,y,z,color,cast=true,radius=0){
  const mesh=new THREE.Mesh(radius?new RoundedBoxGeometry(w,h,d,2,radius):new THREE.BoxGeometry(w,h,d),material(color));
  mesh.position.set(x,y,z);mesh.castShadow=cast;mesh.receiveShadow=true;p.add(mesh);return mesh;
 }
 function cylinder(p,r,h,x,y,z,color){const mesh=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,48),material(color));mesh.position.set(x,y,z);mesh.receiveShadow=true;p.add(mesh);return mesh;}
 function plant(p,x,y,z){box(p,.52,.55,.52,x,y+.27,z,0xc4b296);box(p,.14,1.1,.14,x,y+.9,z,0x7c674a);for(const [dx,dy,dz]of [[0,1.5,0],[-.3,1.2,.1],[.28,1.8,-.1]])box(p,.65,.55,.6,x+dx,y+dy,z+dz,0x738368,true,.1);}
 function addActor(appearance,p,x,y,z,angle=0,seated=false){
  const actor=createOfficeCharacter(appearance);actor.group.position.set(x,y,z);actor.group.rotation.y=angle;
  actor.pose({seated:seated?1:0,stride:0,walking:false,gesture:0,working:false});
  actor.group.userData.seated=seated;actor.group.userData.baseY=y;
  actor.group.traverse(o=>{if(o.isMesh)o.castShadow=true;});p.add(actor.group);actors.push(actor);return actor;
 }
 function addVisitor(p,x,y,z,angle=0,seated=false){character=addActor(characterLook(look),p,x,y,z,angle,seated);character.group.userData.seated=seated;}
 if(chapter===0){
  cylinder(root,1.7,.12,0,-.05,0,0xd2c8b4);
  box(root,9,.2,7,0,-.25,-1,0xdccbb0);
  box(root,9,4.5,.15,0,1.9,-3,0xd4c3a8);
  box(root,1.9,3,.12,2.55,1.45,-2.8,0x8d765b,true,.08);
  box(root,1.7,2.8,.04,2.55,1.45,-2.71,0xb4c8bf,false,.05);
  for(const x of [-3.3,-1.7])box(root,.05,2.3,.05,x,1,-1.8,0x4b5750);
  box(root,1.65,.05,.05,-2.5,2.15,-1.8,0x4b5750);
  for(const [i,c]of [0x72816a,0x334e66,0xe7dfca].entries()){box(root,.42,.67,.18,-3.06+i*.55,1.7,-1.8,c,true,.025);box(root,.62,.15,.19,-3.06+i*.55,1.96,-1.8,c);}
  plant(root,3.4,0,.5);addVisitor(root,0,.02,0,rotation);
  camera.position.set(3.8,2.7,7.4);camera.lookAt(-.1,1.1,-.3);
 }else if(chapter===1){
  vehicle=createWelcomeCar(root);car=vehicle.group;vehicle.door(1);
  addVisitor(root,-3.3,0,-1.9,Math.PI/2,false);
  cylinder(root,5.4,.15,0,-.08,0,0xcbd0bf);
  camera.position.set(-11.5,6.8,-12.65);camera.lookAt(0,.8,0);
 }else{
  const hq=new THREE.Group();hq.position.set(6,0,-1);hq.scale.setScalar(.6);root.add(hq);
  exterior=createBuildingExterior({box,ownedMaterials,textures});
  exterior.build(hq,[{id:'welcome',number:'01',title:'Welcome floor',accent:'#fe5600'},{id:'projects',number:'02',title:'Project floors',accent:'#aabd9a'},{id:'company',number:'03',title:'Studio',accent:'#fe5600'}],()=>document.createElement('button'),()=>{});
  box(root,34,.3,23,0,-1,0,0x9ca99a);
  box(root,8,4.3,8,-7,1.05,0,0x465c58,true,.08);
  for(const z of [-4.03,4.03])for(let x=-10.5;x<-3.4;x+=1.15)box(root,.92,2.8,.04,x,1.2,z,0x97aaa1,false);
  box(root,8.5,.25,8.5,-7,3.3,0,0xc5c0a9);
  cylinder(root,3.4,.04,-7,3.46,0,0x67786b);
  const ring=new THREE.Mesh(new THREE.RingGeometry(3.12,3.2,64),new THREE.MeshBasicMaterial({color:0xffb46f,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.set(-7,3.49,0);root.add(ring);
  // The connection is explicitly a design proposal and has no routing authority.
  box(root,5.2,.22,1.45,-.4,3.3,1.7,0x9c947e);
  const bridgeGlass=new THREE.MeshStandardMaterial({color:0xa4c7bc,transparent:true,opacity:.35,side:THREE.DoubleSide});ownedMaterials.push(bridgeGlass);
  for(const z of [1,2.4])box(root,5.2,1.5,.055,-.4,4.1,z,bridgeGlass,false);
  for(const x of [-2.9,-1.2,.5,2.2])for(const z of [1,2.4])box(root,.045,1.6,.045,x,4.1,z,0x40574f);
  for(const x of [-10.5,-3.5])plant(root,x,3.45,-3.5);
  vehicle=createWelcomeCar(root);car=vehicle.group;car.scale.setScalar(.75);car.position.set(-7,3.5,0);car.rotation.y=-.2;
  addVisitor(car,-.65,.23,-.25,Math.PI,true);vehicle.seatDriver(character);
  character.group.userData.cabin=character.group.position.clone();walkers.push(character);
  camera.position.set(-23,22,34);camera.lookAt(0,3,0);
 }
 function resize(){if(disposed)return;const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();dirty=true;}
 const observer=new ResizeObserver(resize);observer.observe(host);resize();
 function resetBoarding(){
  car.position.set(0,0,0);car.rotation.set(0,0,0);vehicle.door(1);vehicle.resetEffects();
  root.add(character.group);character.group.position.set(-3.3,0,-1.9);character.group.rotation.set(0,Math.PI/2,0);
  character.pose({seated:0,stride:0,walking:false,gesture:0,working:false});
  camera.position.set(-11.5,6.8,-12.65);camera.lookAt(0,.8,0);
 }
 function resetArrival(){
  car.position.set(-7,3.5,0);car.rotation.set(0,-.2,0);vehicle.door(0);
  for(const actor of walkers){vehicle.seatDriver(actor);actor.group.visible=true;}
  camera.position.set(-23,22,34);cameraTarget.set(0,3,0);camera.lookAt(cameraTarget);
 }
 function settle(){
  const type=pendingEntry?'entry':flight?.type;pendingEntry=false;flight=null;vehicle?.resetEffects();dirty=true;
  if(chapter===2){resetArrival();beat('landed','Touchdown · your office is ready');}
  if(chapter===1){resetBoarding();}
  if(type==='entry')onEnter?.();else onSettled?.();
 }
 function play(){
  if(chapter===0)return;vehicle.resetEffects();if(chapter===1)resetBoarding();pendingEntry=false;paused=false;lastBeat='';if(chapter===2)resetArrival();
  if(reduced.matches){settle();return;}
  flight={start:time,type:'flight'};dirty=true;
 }
 function enter(){
  if(chapter!==2)return;paused=false;
  if(flight?.type==='flight'){pendingEntry=true;return;}
  if(reduced.matches){onEnter?.();return;}
  resetArrival();paused=false;lastBeat='';flight={start:time,type:'entry'};dirty=true;
 }
 function motionChange(){if(reduced.matches)settle();dirty=true;}
 function visibility(){lastFrame=null;dirty=true;}
 reduced.addEventListener('change',motionChange);document.addEventListener('visibilitychange',visibility);
 renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();if(!disposed)onFailure();});
 // All motion uses one pausable clock. Hidden tabs and reduced motion never
 // accumulate elapsed flight time or leave callbacks queued after disposal.
 renderer.setAnimationLoop(now=>{
  if(disposed||document.hidden){lastFrame=null;return;}
  const dt=lastFrame===null?0:Math.min(now-lastFrame,100);lastFrame=now;
  const animate=!reduced.matches&&!paused&&chapter>0;
  if(animate)time+=dt;
  if(animate){
   const t=time/1000;let thrustPower=0,lateral=0,forward=0;
   if(chapter===1&&!flight){character.pose({seated:0,stride:0,walking:false,gesture:Math.sin(t)*.7,working:false});}
   if(chapter===2&&!flight){character.pose({seated:1,stride:0,walking:false,gesture:0,working:true});}
   if(flight){
    const elapsed=time-flight.start;
    if(flight.type==='entry'){
     const p=Math.min(1,elapsed/7500);
     beat(p<.18?'disembark':p<.78?'bridge':'office-door',p<.18?'Door open · step out onto the rooftop':p<.78?'Across the bridge · your place is inside':'Welcome inside · opening the example floor');
     vehicle.door(smooth(p/.16));
     walkers.forEach((actor,i)=>{
      const q=THREE.MathUtils.clamp((p-.12-i*.035)/.65,0,1);
      if(q<=0)return;
      if(actor.group.parent!==root){root.attach(actor.group);actor.group.scale.setScalar(.705);actor.group.userData.seated=false;actor.group.userData.walkStart=actor.group.position.clone();actor.group.userData.route=null;}
      const points=[actor.group.userData.walkStart,new THREE.Vector3(-9,3.5,.1),new THREE.Vector3(-9,3.5,3.5),new THREE.Vector3(-3.2,3.5,3.5),new THREE.Vector3(-2.8,3.5,1.7),new THREE.Vector3(2.8,3.5,1.7)];
      const route=actor.group.userData.route??=(new THREE.CatmullRomCurve3(points,false,'centripetal'));
      actor.group.position.copy(route.getPoint(q));const tangent=route.getTangent(Math.min(q,.999));actor.group.rotation.set(0,Math.atan2(tangent.x,tangent.z),0);
      actor.pose({seated:0,stride:t*8+i,walking:q<1,gesture:0,working:false});actor.group.visible=q<.99;
     });
     const dolly=smooth((p-.12)/.88);
     camera.position.lerpVectors(new THREE.Vector3(-23,22,34),new THREE.Vector3(-.6,6.5,8.5),dolly);
     cameraTarget.lerpVectors(new THREE.Vector3(0,3,0),new THREE.Vector3(3.8,4.2,1.3),dolly);camera.lookAt(cameraTarget);
     if(p===1){flight=null;paused=true;onEnter?.();}
    }else if(chapter===1){
     const p=Math.min(1,elapsed/7500),board=smooth(p/.29),lift=smooth((p-.4)/.6);
     beat(p<.29?'boarding':p<.4?'ignition':p<.72?'lift-off':'departure',p<.29?'Your ride is ready · take the driver’s seat':p<.4?'Door closed · thrusters coming online':p<.72?'Lift-off · next stop, Studio':'On your way · the team is waiting inside');
     if(p<.29){
      character.group.position.lerpVectors(new THREE.Vector3(-3.3,0,-1.9),new THREE.Vector3(-.65,.23,-.25),board);
      character.group.rotation.set(0,THREE.MathUtils.lerp(Math.PI/2,Math.PI,smooth((board-.6)/.4)),0);
      character.pose({seated:smooth((board-.6)/.4),stride:t*8,walking:board<.8,gesture:0,working:false});
     }else if(character.group.parent!==car){vehicle.seatDriver(character);}
     vehicle.door(1-smooth((p-.29)/.11));thrustPower=smooth((p-.32)/.15);lateral=-Math.sin(lift*Math.PI)*.7;forward=-Math.sin(lift*Math.PI)*.9;
     car.position.set(-lift*2,lift*5,-lift*7);car.rotation.z=-Math.sin(lift*Math.PI)*.07;car.rotation.x=-Math.sin(lift*Math.PI)*.04;
     camera.position.lerpVectors(new THREE.Vector3(-11.5,6.8,-12.65),new THREE.Vector3(-11,7,8),smooth(lift));cameraTarget.copy(car.position).add(new THREE.Vector3(0,1,0));camera.lookAt(cameraTarget);
     if(p===1){flight=null;paused=true;onSettled?.();}
    }else{
     const p=Math.min(1,elapsed/8000),approach=smooth(p/.82);
     beat(p<.5?'approach':p<.82?'descent':'touchdown',p<.5?'Studio in sight · approaching the rooftop':p<.82?'Easy does it · lining up with the landing pad':'Touchdown · welcome to the neighbourhood');
     car.position.set(-7-12*(1-approach),3.5+8*(1-approach),-9*(1-approach));
     car.rotation.z=Math.sin(p*Math.PI)*-.12;car.rotation.x=Math.sin(p*Math.PI)*.06;
     thrustPower=p<.82?.85:1-smooth((p-.82)/.18);lateral=(p<.42?.65:-.5)*Math.sin(p*Math.PI);forward=(p<.42?.5:-.6)*Math.sin(p*Math.PI);
     if(p>.82)car.position.y-=Math.sin((p-.82)/.18*Math.PI)*.12;
     camera.position.lerpVectors(new THREE.Vector3(-30,16,24),new THREE.Vector3(-23,22,34),smooth(p));cameraTarget.lerpVectors(car.position,new THREE.Vector3(0,3,0),smooth(p));camera.lookAt(cameraTarget);
     if(p===1){flight=null;car.rotation.z=0;car.rotation.x=0;thrustPower=0;beat('landed','Touchdown · ready to walk into Studio');if(pendingEntry){pendingEntry=false;enter();}else onSettled?.();}
    }
   }
   vehicle?.thrust(thrustPower,t,{lateral,forward,groundY:chapter===2?3.5:0});
   dirty=true;
  }
  if(dirty){renderer.render(scene,camera);dirty=false;}
 });
 return {
  play,enter,skip:settle,
  pauseMotion(value){paused=value;host.dataset.motion=paused?'paused':'playing';dirty=true;},
  rotate(delta){if(chapter!==0)return;rotation+=delta;character.group.rotation.y=rotation;dirty=true;},
  updateLook(next){look=next;if(!character)return;const previous=character,group=previous.group,parent=group.parent,pos=group.position.clone(),angle=group.rotation.y,seated=group.userData.seated;actors.splice(actors.indexOf(previous),1);previous.dispose();addVisitor(parent,pos.x,pos.y,pos.z,angle,seated);dirty=true;},
  destroy(){disposed=true;renderer.setAnimationLoop(null);observer.disconnect();reduced.removeEventListener('change',motionChange);document.removeEventListener('visibilitychange',visibility);
   const geometries=new Set(),mats=new Set(),maps=new Set(textures);scene.traverse(o=>{if(o.geometry)geometries.add(o.geometry);for(const m of [].concat(o.material||[])){mats.add(m);if(m.map)maps.add(m.map);}});
   geometries.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());maps.forEach(m=>m.dispose());exterior?.dispose();sun.shadow.map?.dispose();renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();
  }
 };
}
