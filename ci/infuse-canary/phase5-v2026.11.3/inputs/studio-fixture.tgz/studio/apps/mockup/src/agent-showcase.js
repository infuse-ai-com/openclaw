import * as THREE from 'three';
import {createOfficeCharacter} from '@studio/spatial/character';
import {agentRoster} from './agent-directory.js';

// Still renders of the shared office geometry. No availability or work animation.
const portraits=new Map();
const details={emon:'badge',tinus:'headphones',stewie:'glasses',satwa:'cap',kapiteky:'beard',ramiro:'tie'};
export function mountAgentShowcase(state){
 const root=document.querySelector('.surface--people');
 if(!root)return;
 const slot=root.querySelector('[data-agent-portrait]');
 const person=agentRoster(state).find(p=>p.id===slot?.dataset.agentPortrait);
 if(person){
  const key=JSON.stringify([person.id,person.color,person.hair]);
  if(!portraits.has(key)){
   let renderer,character,geometry,material;
   try{
    renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});
    renderer.setSize(800,1000);renderer.setPixelRatio(1);
    renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure=1.25;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    const scene=new THREE.Scene();scene.background=null;
    const camera=new THREE.PerspectiveCamera(30,.8,.1,20);camera.position.set(1.35,1.25,4.1);camera.lookAt(0,.79,0);
    scene.add(new THREE.HemisphereLight(0xfff3df,0x587666,2.3));
    const keyLight=new THREE.DirectionalLight(0xffdfba,4);keyLight.position.set(-3,4,5);keyLight.castShadow=true;keyLight.shadow.mapSize.set(1024,1024);keyLight.shadow.bias=-.001;scene.add(keyLight);
    const rim=new THREE.DirectionalLight(0xfe8d45,3);rim.position.set(2,2,-2);scene.add(rim);
    character=createOfficeCharacter({shirt:person.color,hair:person.hair,skin:0xc99c7c,detail:details[person.id]||'plain'});
    character.pose({seated:0,stride:0,walking:false,gesture:0,working:false});
    character.group.traverse(object=>{if(object.isMesh)object.castShadow=true;});scene.add(character.group);
    geometry=new THREE.PlaneGeometry(200,200);material=new THREE.ShadowMaterial({opacity:.24});
    const floor=new THREE.Mesh(geometry,material);floor.rotation.x=-Math.PI/2;floor.position.y=-.035;floor.receiveShadow=true;scene.add(floor);
    renderer.render(scene,camera);portraits.set(key,renderer.domElement.toDataURL('image/webp'));
    keyLight.shadow.map?.dispose();
   }catch{/* The established pixel portrait remains visible without WebGL. */}
   finally{character?.dispose();geometry?.dispose();material?.dispose();renderer?.dispose();renderer?.forceContextLoss();}
  }
  if(portraits.has(key)){const img=document.createElement('img');img.src=portraits.get(key);img.alt='';slot.replaceChildren(img);slot.dataset.ready='true';}
 }
 function showTeam(open){
  root.querySelector('.agent-showcase').hidden=open;
  root.querySelector('.agent-team-view').hidden=!open;
  root.querySelector('[data-team-operations]').setAttribute('aria-expanded',String(open));
 }
 root.querySelector('[data-team-operations]').onclick=()=>{showTeam(true);root.querySelector('#agent-team-heading').focus({preventScroll:true});};
 root.querySelector('[data-team-back]').onclick=()=>{showTeam(false);root.querySelector('[data-team-operations]').focus({preventScroll:true});};
 function selectTab(name,focus=false){
  showTeam(false);
  const tabs=[...root.querySelectorAll('[data-agent-tab]')];
  for(const tab of tabs){const selected=tab.dataset.agentTab===name;tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;if(selected&&focus)tab.focus();}
  for(const panel of root.querySelectorAll('.agent-panel'))panel.hidden=panel.id!==`agent-panel-${name}`;
 }
 for(const button of root.querySelectorAll('[data-agent-tab],[data-agent-show]'))button.onclick=()=>selectTab(button.dataset.agentTab||button.dataset.agentShow,true);
 root.querySelector('.agent-tabs')?.addEventListener('keydown',event=>{
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
  const tabs=[...root.querySelectorAll('[data-agent-tab]')],i=tabs.indexOf(document.activeElement);if(i<0)return;
  event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(i+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;selectTab(tabs[next].dataset.agentTab,true);
 });
 root.querySelector('[data-agent-usage]')?.addEventListener('change',event=>{for(const view of root.querySelectorAll('[data-agent-usage-view]'))view.hidden=view.dataset.agentUsageView!==event.target.value;});
 for(const button of root.querySelectorAll('[data-operations-filter]'))button.onclick=()=>{
  const attention=button.dataset.operationsFilter==='attention';let visible=0;
  for(const filter of root.querySelectorAll('[data-operations-filter]'))filter.setAttribute('aria-pressed',String(filter===button));
  for(const row of root.querySelectorAll('.agent-operation-row')){row.hidden=attention&&row.dataset.needsAttention!=='true';if(!row.hidden)visible++;}
  root.querySelector('[data-operations-result]').textContent=`Showing ${visible} ${attention?'agents needing attention':'agents'}`;
 };
 const initialTab=root.dataset.agentInitialTab;delete root.dataset.agentInitialTab;
 if(initialTab)selectTab(initialTab,true);
 const search=root.querySelector('#agent-search');
 search?.addEventListener('input',()=>{
  const query=search.value.trim().toLowerCase();let found=0;
  for(const button of root.querySelectorAll('[data-agent-search-text]')){button.hidden=!button.dataset.agentSearchText.includes(query);if(!button.hidden)found++;}
  root.querySelector('.agent-search-empty').hidden=found>0;
 });
}
