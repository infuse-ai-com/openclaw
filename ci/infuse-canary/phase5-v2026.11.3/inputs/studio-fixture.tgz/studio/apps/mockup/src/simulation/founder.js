import { workStatus } from './work-projections.js';
import { checksForFloor, checkNeedsAttention } from './operations.js';
import { createdMissions, currentMission, missionTransition, missionMissing } from './missions.js';
import { floorPeople, allFloors } from './company.js';

import { partner } from './reference-catalog.js';

// Aggregate the existing project read model; decisions still write through their owning project.
export function companyDeskItems(s) {
 if (['denied','loading'].includes(s.connected?.mode)) return [];
 const items=allFloors(s).flatMap(floor=>founderItems({...s,floor:floor.id}).filter(item=>{
  const mission=s.missionDesk?.items.find(m=>m.id===item.missionId);
  return !mission?.decisionOwner||mission.decisionOwner===partner(s);
 }).map(item=>({...item,projectId:floor.id,projectTitle:floor.title})));
 return items.sort((a,b)=>({high:0,medium:1,low:2}[a.priority]-{high:0,medium:1,low:2}[b.priority])||a.key.localeCompare(b.key));
}

export const emptyFounderDesk=()=>({links:[],decisions:{}});
const checkKey=(floor,job,run)=>`${floor}:check:${job}:${run}`;
const missionKey=m=>`${m.floorId}:mission:${m.id}`;
const progress=m=>workStatus(m)?.status||(m.delivery?.accepted?'history':m.status==='completed'?'attention':m.status==='active'||m.status==='approved'&&m.startup!=='hold'?'motion':'attention');
const stamp=m=>`${m.revision}:${m.status}:${m.startup}:${m.delivery?.versions.at(-1).revision||0}:${m.delivery?.sourceRevision||0}:${JSON.stringify(m.delivery?.notes||[])}:${m.delivery?.accepted?.at||''}`;
export function founderItems(s){
 const desk=s.founderDesk||emptyFounderDesk(),missions=createdMissions(s),jobs=s.connectedEnabled?[]:checksForFloor(s),items=[];
 const links=desk.links.filter(l=>l.floorId===s.floor);
 for(const job of jobs){
  const run=job.runs[0];if(!checkNeedsAttention(job)||!run)continue;
  const key=checkKey(s.floor,job.id,run.id);if(links.some(l=>l.key===key))continue;
  items.push({key,kind:'check',priority:'high',title:job.name,jobId:job.id,source:run.summary,runId:run.id,at:run.at,description:job.description,impact:'The check’s failure policy requires attention. Its target has not been verified as healthy.',recommendation:'Ask Emon to prepare a bounded investigation, with a proposed correction and evidence for your review.',status:'attention',label:'Check needs attention',fingerprint:JSON.stringify([run,job.description,job.policy])});
 }
 for(const link of links){
  const m=missions.find(m=>m.id===link.missionId);if(!m)continue;
  const job=jobs.find(j=>j.id===link.jobId),needsCheck=job&&job.runs[0]?.id===link.runId&&checkNeedsAttention(job),accepted=!!m.delivery?.accepted;
  items.push({key:link.key,kind:'check',priority:'high',title:link.title,jobId:link.jobId,source:link.source,at:link.at,description:link.description,missionId:m.id,missionTitle:m.title,status:accepted&&needsCheck?'attention':progress(m),label:accepted&&needsCheck?'Result accepted · check still failing':accepted?'Result accepted':m.status==='completed'?'Delivery ready for review':m.status==='draft'?'Emon’s proposal needs you':m.startup==='hold'?'Approved · waiting to start':'Mission in motion',impact:accepted?'Acceptance records your judgment of the proposal. It does not change the check result.':'The investigation is linked to its original failed check. The approved scope controls the work.',recommendation:accepted&&needsCheck?'Inspect the check and record a new simulated result. A real recovery will need verified execution.':accepted?'Revisit the accepted result and its recorded check evidence. The original failure remains available in Operations.':m.status==='completed'?'Inspect the delivery and verify each correction before accepting the result.':m.status==='draft'?'Refine the proposed outcome, plan and team, then explicitly approve the brief.':'Open the mission to inspect its next named event.',fingerprint:stamp(m)+JSON.stringify(job?.runs[0])});
 }
 for(const m of missions){
  if(links.some(l=>l.missionId===m.id)||m.status==='draft'&&m.stage==='idea')continue;
  const status=progress(m),missing=missionMissing(m);
  items.push({key:missionKey(m),kind:m.status==='completed'?'delivery':'mission',priority:s.missionDesk.priorities?.[m.id]||'medium',title:m.title||'Untitled mission',missionId:m.id,missionTitle:m.title,status,label:m.delivery?.accepted?'Accepted result':m.status==='completed'?'Delivery ready for review':m.status==='draft'?'Brief needs your decision':m.startup==='hold'?'Approved · waiting to start':'Mission in motion',source:m.content.outcome||m.content.intent,impact:m.status==='draft'?`${missing.length} required sections still need confirmation. Work has not started.`:'Your approved brief and recorded simulation events remain available.',recommendation:m.status==='completed'?'Review the result against the agreed criteria and remaining gaps.':m.status==='draft'?'Review Emon’s proposal and resolve the required decisions.':'Inspect the next event and the team’s recorded handoffs.',fingerprint:stamp(m)});
 }
 return items.map(item=>{const m=missions.find(m=>m.id===item.missionId),native=m&&workStatus(m);if(native){Object.assign(item,native);item.fingerprint+=JSON.stringify(m.execution);if(item.jobId&&native.status==='history'&&checkNeedsAttention(jobs.find(j=>j.id===item.jobId)||{runs:[]})){item.status='attention';item.label='Mission closed · check still needs attention';item.recommendation='Inspect the original check; mission closeout does not prove recovery.';}}const saved=desk.decisions[item.key],decision=saved?.fingerprint===item.fingerprint?saved:null;return {...item,decision,previousDecision:decision?null:saved,status:decision?.deferred&&item.status!=='history'?'deferred':item.status};}).sort((a,b)=>({high:0,medium:1,low:2}[a.priority]-{high:0,medium:1,low:2}[b.priority])||a.key.localeCompare(b.key));
}
export function founderTransition(state,event){
 if(!event.type.startsWith('FOUNDER_'))return null;
 const item=founderItems(state).find(i=>i.key===event.key);if(!item)return state;
 if(event.type==='FOUNDER_PROPOSE'){
  if(item.kind!=='check'||item.missionId)return state;
  let s=missionTransition(state,{type:'MISSION_NEW'});const m=currentMission(s);
  m.scenario='operations-investigation';m.title=`Investigate ${item.title}`.slice(0,160);m.rawThought=`Investigate the failed check “${item.title}”.\n${item.source}`;
  m.content={intent:m.rawThought,outcome:`A reviewable diagnosis and recovery proposal for ${item.title}, with evidence requirements and remaining gaps.`,scope:'Inspect the recorded failure, propose a bounded correction and define a verification check. Include one review and correction round.',nonGoals:'No production changes, live checks, automatic retries or external execution in this mockup.',references:`Operations / ${item.title}\nRecorded run: ${item.runId} · ${item.at}\nExact result:\n${item.source}\n\nCheck instructions:\n${item.description}`,decisions:'Fito approves the investigation scope and reviews the result. Any production action requires a separate decision.',evidence:'The proposal identifies the recorded failure, distinguishes observations from assumptions, gives a correction and verification procedure, and states that a fresh successful check is still required.'};
  if(item.decision?.note)m.content.references+=`\n\nFounder’s recorded decision notes:\n${(item.decision.history||[item.decision]).map(x=>x.note).join('\n\n')}`;
  m.origins=Object.fromEntries(Object.keys(m.content).map(k=>[k,'suggestion']));m.shaping.seeded=true;m.stage='shape';m.confirmed=['intent'];m.squad=['emon',...(m.candidates.includes('satwa')?['satwa']:[])];
  const specialist=m.squad.includes('satwa')?'satwa':'emon';
  m.planning.steps=[{id:'step-1',owner:'emon',title:'Bound the investigation',output:'Failure context, constraints and required evidence.',verification:'The original run is referenced without changing its wording.'},{id:'step-2',owner:specialist,title:'Propose recovery and verification',output:'A diagnosis proposal, correction procedure and fresh-check requirements.',verification:'Assumptions and remaining execution gaps are explicit.'}];
  m.summary='Emon prepared this local example from the failed check. Refine and approve it before any simulation starts.';
  s.founderDesk??=emptyFounderDesk();s.founderDesk.links.push({key:item.key,floorId:s.floor,jobId:item.jobId,runId:item.runId,missionId:m.id,title:item.title,source:item.source,description:item.description,at:item.at});return s;
 }
 if(event.type!=='FOUNDER_DECIDE'||!['defer','reopen','delegate','take-back'].includes(event.action)||item.status==='history')return state;
 if(event.action==='delegate'&&!floorPeople(state).some(p=>p.id===event.owner&&p.id!=='fito'))return state;
 if(typeof event.note!=='string'||event.note.length>2000||['defer','delegate'].includes(event.action)&&!event.note.trim())return state;
 const s=structuredClone(state);s.founderDesk??=emptyFounderDesk();const previous=s.founderDesk.decisions[item.key];
 s.founderDesk.decisions[item.key]={fingerprint:item.fingerprint,deferred:event.action==='defer'?true:event.action==='reopen'?false:item.decision?.deferred||false,owner:event.action==='delegate'?event.owner:event.action==='take-back'?null:item.decision?.owner||null,note:event.note,action:event.action,at:new Date().toISOString()};
 const record=s.founderDesk.decisions[item.key];record.history=[...(previous?.history||(previous?[{action:previous.action,note:previous.note,at:previous.at}]:[])),{action:record.action,note:record.note,at:record.at}].slice(-100);return s;
}
export function restoreFounderDesk(s){
 if(s.founderDesk===undefined){s.founderDesk=emptyFounderDesk();return false;}
 const d=s.founderDesk,str=(x,max=12000)=>typeof x==='string'&&x.length<=max;
 const valid=d&&Array.isArray(d.links)&&d.links.length<=1000&&new Set(d.links.map(l=>l?.key)).size===d.links.length&&d.links.every(l=>l&&['key','floorId','jobId','runId','missionId','title','source','description','at'].every(k=>str(l[k]))&&Number.isFinite(Date.parse(l.at))&&l.key===checkKey(l.floorId,l.jobId,l.runId)&&s.missionDesk.items.some(m=>m.id===l.missionId&&m.floorId===l.floorId))&&d.decisions&&typeof d.decisions==='object'&&!Array.isArray(d.decisions)&&Object.entries(d.decisions).every(([key,v])=>str(key)&&v&&str(v.fingerprint,1000000)&&typeof v.deferred==='boolean'&&(v.owner===null||str(v.owner,120))&&str(v.note,2000)&&(v.history===undefined||Array.isArray(v.history)&&v.history.length<=100&&v.history.every(h=>h&&str(h.note,2000)&&['defer','reopen','delegate','take-back'].includes(h.action)&&Number.isFinite(Date.parse(h.at))))&&['defer','reopen','delegate','take-back'].includes(v.action)&&Number.isFinite(Date.parse(v.at)));
 if(!valid)s.founderDesk=emptyFounderDesk();return !valid;
}
