import { currentMission, missionTransition } from './missions.js';
import { partner, partners, canManage } from './reference-catalog.js';
// Named decisions model explicit intent; free text is never classified by inference.
export function referenceTransition(s,event){
 const c=s.connected,m=currentMission(s),x=m?.execution;
 if(event.type==='CONNECTED_PARTNER'){if(partners.includes(event.value))c.partner=event.value;return s;}
 if(event.type==='CONNECTED_REMOVE_SOURCE'){
  if(!canManage(s,m))return s;
  if(m?.status==='draft'){m.source=null;m.revision++;}
  c.projects[s.floor].source=null;c.notice=m?.approved?'Future source selection cleared. Approved context unchanged.':'Draft source removed.';return s;
 }
 if(event.type==='CONNECTED_CLARIFY'){
  if(!x||x.state!=='running'||!event.text?.trim())return s;
  x.conversation??=[];x.conversation.push({author:partner(s),kind:'Clarification',text:event.text.slice(0,2000)});
  x.conversation.push({author:'Emon',kind:'Authored fixture reply',text:'The approved outcome and selected references stay unchanged. A correction needs new evidence; a larger outcome needs a fresh approved paper.'});
  c.notice='Clarification recorded in the mission conversation. No scope or task state changed.';return s;
 }
 if(event.type==='CONNECTED_SCOPE'){
  if(!m?.approved||!event.text?.trim())return s;
  const old=m;let next=missionTransition(s,{type:'MISSION_NEW'}),draft=currentMission(next);
  draft.title=`Scope proposal · ${old.title}`.slice(0,160);draft.content.intent=event.text.slice(0,2000);draft.parentId=old.id;
  draft.source=structuredClone(old.source);draft.candidate=structuredClone(old.candidate);
  draft.summary='Changed scope requires a newly shaped paper and fresh owner approval. The original mission is unchanged.';
  next.connected.notice=draft.summary;return next;
 }
 if(event.type==='CONNECTED_MCP_UPDATE'){
  if(!m?.importContext)return s;
  const incoming={intent:'Updated MCP draft: include an explicit handoff checklist.',revision:m.importContext.importedRevision+1};
  m.importContext.pending=incoming;m.importContext.status='Incoming update · review required';
  c.notice='Incoming draft differs from the saved paper. Inspect it before applying; approval is never imported.';return s;
 }
 if(event.type==='CONNECTED_MCP_APPLY'){
  const ctx=m?.importContext;if(!ctx?.pending||!canManage(s,m))return s;
  if(m.status!=='draft'||ctx.paperRevision!==m.revision){ctx.status='Conflict · local paper changed';c.notice='Saved paper retained. Prepare the incoming version as a separate draft.';return s;}
  m.content.intent=ctx.pending.intent;m.rawThought=ctx.pending.intent;m.confirmed=[];m.revision++;
  ctx.importedRevision=ctx.pending.revision;ctx.paperRevision=m.revision;ctx.pending=null;ctx.status='Updated draft · confirmation required';return s;
 }
 if(event.type==='CONNECTED_MCP_FORK'){
  const incoming=m?.importContext?.pending;if(!incoming)return s;
  const next=missionTransition(s,{type:'MISSION_NEW'}),n=currentMission(next);
  n.title='Review incoming MCP changes';n.content.intent=incoming.intent;n.rawThought=incoming.intent;n.parentId=m.id;n.origin='MCP';n.importContext={...structuredClone(m.importContext),pending:null,status:'Separate unapproved draft',paperRevision:n.revision};
  next.missionDesk.items.find(x=>x.id===m.id).importContext.pending=null;
  next.connected.notice='Separate draft prepared; the original paper and receipt remain unchanged.';return next;
 }
 return null;
}
