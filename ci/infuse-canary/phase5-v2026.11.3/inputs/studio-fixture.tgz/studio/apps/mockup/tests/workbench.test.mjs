import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState, transition, restoreState} from '../src/simulation/model.js';
import {initialWorkspaceState} from '../src/workspace-sidebar.js';
import {missionBoard} from '../src/mission-board.js';
import {emptyConnected} from '../src/simulation/connected.js';
import {currentMission} from '../src/simulation/missions.js';

test('the default workbench opens missions without creating work or changing the selected project',()=>{
  let state=initialState();
  state=transition(state,{type:'ENTER_FLOOR',id:'client'});
  const before=structuredClone(state);
  const result=initialWorkspaceState(state);
  assert.equal(result.surface,'missions');
  assert.equal(result.floor,'client');
  assert.deepEqual(result.missionDesk,before.missionDesk);
  assert.deepEqual(result.mission,before.mission);
  assert.deepEqual(state,before);
});

test('entry preserves an open draft; a reloaded board reopens its exact saved mission',()=>{
  let state={...initialState(),connectedEnabled:true,connected:emptyConnected()};
  state=transition(state,{type:'MISSION_NEW'});
  state=transition(state,{type:'MISSION_EDIT',field:'intent',value:'  Mi idea <literal> & original.\nKeep it.  '});
  assert.equal(initialWorkspaceState(state),state);
  const restored=restoreState(JSON.stringify(state));
  assert.equal(restored.notice,null);
  const result=initialWorkspaceState(restored.state);
  assert.equal(result.surface,'missions');
  const opened=transition(result,{type:'MISSION_OPEN'});
  assert.equal(opened.surface,'mission-flow');
  assert.deepEqual(currentMission(opened),currentMission(state));
  assert.deepEqual(currentMission(result),currentMission(state));
  const closed=transition(result,{type:'CLOSE'});
  const reopened=initialWorkspaceState(closed);
  assert.equal(reopened.surface,'missions');
  assert.deepEqual(currentMission(reopened),currentMission(state));
});

test('board and list projections keep every lifecycle column and the same filtered work',()=>{
  const state=initialState();
  const before=structuredClone(state);
  const board=missionBoard(state,{mode:'examples',layout:'board',filter:'high'});
  const list=missionBoard(state,{mode:'examples',layout:'list',filter:'high'});
  const cardIds=html=>[...html.matchAll(/data-card-id="([^"]+)"/g)].map(match=>match[1]);
  assert.deepEqual(cardIds(board),cardIds(list));
  assert.equal(cardIds(board).length,3);
  for(const column of ['draft','approval','waiting','active','review','completed'])assert.ok(list.includes(`data-column="${column}"`));
  assert.deepEqual(state,before);
});


const {switchWorkspaceProject,pendingHumanReviews}=await import('../src/workspace-navigation.js');
test('project navigation retains the section without transferring selected work or sources',()=>{
 let s={...initialState(),connectedEnabled:true,connected:emptyConnected()};
 s=transition(s,{type:'MISSION_NEW'});
 s=transition(s,{type:'MISSION_EDIT',field:'intent',value:'Keep this Studio draft exactly as supplied.'});
 s=transition(s,{type:'OPEN',surface:'knowledge-reader'});
 const before=structuredClone(s);
 const next=switchWorkspaceProject(s,'client');
 assert.equal(next.floor,'client');assert.equal(next.surface,'knowledge-reader');
 assert.equal(currentMission(next),null);assert.deepEqual(next.missionDesk,before.missionDesk);
 assert.deepEqual(s,before);
 assert.equal(switchWorkspaceProject(next,'studio').surface,'knowledge-reader');
 assert.deepEqual(currentMission(switchWorkspaceProject(next,'studio')),currentMission(s));
 assert.equal(switchWorkspaceProject(s,'missing'),s);
});
test('project navigation maps mission detail to its collection and preserves both Office scales',()=>{
 let s=transition(initialState(),{type:'ENTER_FLOOR',id:'studio'});
 s=transition(s,{type:'MISSION_NEW'});
 assert.equal(switchWorkspaceProject(s,'client').surface,'ideas');
 for(const detail of ['connected-output','delivery-review']){
  const result=switchWorkspaceProject(transition(s,{type:'OPEN',surface:detail}),'client');
  assert.equal(result.surface,'missions');assert.equal(result.floor,'client');
 }
 s=transition(s,{type:'CLOSE'});
 assert.equal(switchWorkspaceProject(s,'client').surface,null);
 s=transition(s,{type:'BUILDING'});
 const next=switchWorkspaceProject(s,'client');assert.equal(next.view,'building');assert.equal(next.surface,null);assert.equal(next.floor,'client');
});
test('human review counts exclude agent evidence checks, closed work and other projects',()=>{
 let s={...initialState(),connectedEnabled:true,connected:emptyConnected()};
 s=transition(s,{type:'MISSION_NEW'});
 s=transition(s,{type:'MISSION_EDIT',field:'intent',value:'A clear first action'});
 s=transition(s,{type:'MISSION_STEP',stage:'shape'});
 for(const id of ['outcome','scope','evidence'])s=transition(s,{type:'MISSION_CONFIRM',id,inline:true});
 assert.equal(pendingHumanReviews(s).length,1);
 assert.equal(pendingHumanReviews({...s,connected:{...s.connected,mode:'denied'}}).length,0);
 s=transition(s,{type:'MISSION_APPROVE'});assert.equal(pendingHumanReviews(s).length,0);
 const m=currentMission(s);m.execution.state='closing';m.execution.humanAcknowledged=false;
 assert.equal(pendingHumanReviews(s).length,1);
 assert.equal(pendingHumanReviews(switchWorkspaceProject(s,'client')).length,0);
 m.execution.state='closed';assert.equal(pendingHumanReviews(s).length,0);
});


test('Missions History includes only this project’s closed records without changing saved evidence',()=>{
 let s={...initialState(),connectedEnabled:true,connected:emptyConnected()};
 for(const [floor,title,status] of [['studio','Closed core','closed'],['studio','Cancelled core','cancelled'],['studio','Active core','running'],['client','Closed finaxis','closed']]){
  s=transition(s,{type:'ENTER_FLOOR',id:floor});s=transition(s,{type:'MISSION_NEW'});
  const m=currentMission(s);m.title=title;m.execution={state:status,held:false,tasks:[]};
 }
 s=transition(s,{type:'ENTER_FLOOR',id:'studio'});
 s.mission.history=[{title:'Earlier <literal> evidence',markdown:'Original text'}];
 const before=structuredClone(s),html=missionBoard(s,{history:true,mode:'examples'});
 assert.ok(html.includes('Closed core'));assert.ok(html.includes('Cancelled core'));
 assert.ok(!html.includes('Active core'));assert.ok(!html.includes('Closed finaxis'));
 assert.ok(html.includes('Earlier &lt;literal&gt; evidence'));assert.ok(!html.includes('View example'));
 assert.ok(!missionBoard(switchWorkspaceProject(s,'client'),{history:true}).includes('Earlier &lt;literal&gt;'));
 assert.deepEqual(s,before);
});


test('retired output routes retain exact mission records and canonical destinations',()=>{
 let state=transition(initialState(),{type:'MISSION_NEW'});
 state=transition(state,{type:'MISSION_EDIT',field:'intent',value:'  Exact <paper> & original.  '});
 const before=structuredClone(state);
 assert.equal(initialWorkspaceState({...state,surface:'library'}).surface,'artifacts');
 assert.equal(initialWorkspaceState({...state,surface:'connected-output'}).surface,'missions');
 currentMission(state).execution={state:'running',tasks:[]};
 const result=initialWorkspaceState({...state,surface:'connected-output'});
 assert.equal(result.surface,'mission-flow');
 assert.equal(result.floor,state.floor);
 assert.equal(currentMission(result),currentMission(state));
 assert.deepEqual(currentMission(result).content,currentMission(before).content);
 assert.equal(initialWorkspaceState(result),result);
});
