import { transition } from './simulation/model.js';
import { allFloors } from './simulation/company.js';
import { createdMissions, missionReady, currentMission } from './simulation/missions.js';

const esc = value => String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
export function canonicalWorkspaceState(state){
 if(state.surface==='my-screen')return {...state,surface:'founder-desk'};
 if(state.surface==='library')return {...state,surface:'artifacts'};
 if(state.surface==='connected-output')return {...state,surface:currentMission(state)?.execution?'mission-flow':'missions'};
 return state;
}
// Project scope changes never carry a selected mission or source into another project.
export function switchWorkspaceProject(state, id) {
  if (id === state.floor || !allFloors(state).some(f => f.id === id)) return state;
  let next = transition(state, {type:'ENTER_FLOOR', id});
  if (!state.surface) return state.view === 'building' ? transition(next, {type:'BUILDING'}) : next;
  const section = {'mission-flow':currentMission(state)?.status==='draft'&&!currentMission(state)?.execution?'ideas':'missions','connected-output':'missions','delivery-review':'missions','library':'artifacts','project':'missions','floor-setup':'missions'}[state.surface] || state.surface;
  return section === 'missions' ? transition(next, {type:'MISSION_LIST'}) : transition(next, {type:'OPEN', surface:section,person:section==='people'?state.detail:undefined});
}
export function pendingHumanReviews(state) {
  if (['denied','loading','expired','signed-out'].includes(state.connected?.mode)) return [];
  return createdMissions(state).filter(m => m.execution ? m.execution.state === 'closing' && !m.execution.humanAcknowledged : m.status === 'draft' ? missionReady(m) : Boolean(m.delivery && !m.delivery.accepted));
}
export function missionWorkspaceTabs(state, history=false) {
  const section = state.surface === 'floor-activity' ? 'activity' : state.surface==='missions'&&history ? 'history' : 'missions';
  const floor = allFloors(state).find(f=>f.id===state.floor);
  return `<nav class="workspace-section-tabs" aria-label="Project work"><span>${esc(floor?.title || state.floor)}</span>${[['missions','All missions','mission-list'],['history','Closed','mission-history'],['activity','Activity','floor-activity']].map(([key,label,action])=>`<button data-action="${action}" ${section===key?'aria-current="page"':''}>${label}</button>`).join('')}</nav>`;
}
