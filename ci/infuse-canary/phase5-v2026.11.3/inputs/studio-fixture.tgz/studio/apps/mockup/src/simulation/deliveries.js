// Review evidence belongs to a simulated artifact, separately from brief approval.
export const DELIVERY_SECTIONS=['proposal','scope','evidence','references'];
export const latestDelivery=d=>d.versions.at(-1);
export const deliveryStale=d=>latestDelivery(d).sourceRevision!==d.sourceRevision;
export const unresolvedDelivery=d=>d.notes.filter(n=>n.verifiedRevision!==latestDelivery(d).revision);
export const canAcceptDelivery=d=>!deliveryStale(d)&&d.reviewedRevision===latestDelivery(d).revision&&d.criteriaRevision===latestDelivery(d).revision&&!unresolvedDelivery(d).length;
export function createDelivery(m){
 const c=m.approved?.content||m.content;
 const proposal=m.scenario==='operations-investigation'?'Proposed investigation and recovery procedure\n\n1. Inspect the recorded failure and the check configuration. Compare the expected cadence with the latest successful run.\n2. Investigate the worker or target using its run history; distinguish a stale schedule from a failed execution. Neither cause has been verified in this demo.\n3. Propose a correction only after the cause is supported by evidence. Any real change needs a separate approval.\n4. Run the check again after the correction and attach the fresh result. The original failed run remains part of the evidence.\n\nThis is an authored procedure for review. No diagnosis, repair or successful recovery is claimed.':m.scenario==='studio-design'?'Start with your idea in your own words. Emon prepares an editable brief, then proposes a bounded plan and the people to carry it out. Approve the brief before the simulation starts. Review the result separately before accepting it.':`Proposed outcome\n${c.outcome}\n\nThis is a structured review example based on your approved brief. It is not generated domain work.`;
 return {sourceId:`local-demo:${m.id}/approved-paper@${m.approved?.revision||m.revision}`,sourceRevision:1,versions:[{revision:1,sourceRevision:1,summary:'First reviewable proposal. Check the outcome, boundaries and acceptance evidence.',sections:[{id:'proposal',title:m.scenario==='studio-design'?'The proposed experience':'The proposed result',body:proposal},{id:'scope',title:'Scope and remaining gaps',body:`${c.scope}\n\nOut of scope\n${c.nonGoals||'No additional exclusions recorded.'}\n\nRemaining gap: this is a local simulation. No production integration or live agent execution has been verified.`},{id:'evidence',title:'Acceptance evidence',body:`Your agreed criteria\n${c.evidence}\n\nDemo evidence: the approved brief and named simulation events are available for inspection. They do not prove the real outcome has been delivered.`},{id:'references',title:'Sources and decisions',body:`${c.references||'No external sources supplied.'}\n\n${c.decisions||'No additional decisions recorded.'}`}]}],notes:[],reviewedRevision:null,criteriaRevision:null,accepted:null,acceptanceHistory:[]};
}
function invalidate(d){d.reviewedRevision=null;d.criteriaRevision=null;d.accepted=null;}
export function deliveryTransition(m,e){
 if(m.status!=='completed')return false;
 m.delivery??=createDelivery(m);const d=m.delivery,v=latestDelivery(d),note=d.notes.find(n=>n.id===e.id);
 if(e.type==='MISSION_DELIVERY_NOTE'){
  if(!DELIVERY_SECTIONS.includes(e.anchor)||typeof e.text!=='string'||!e.text.trim()||e.text.length>2000||typeof e.proposal!=='string'||e.proposal.length>8000||d.notes.length>=50)return false;
  d.notes.push({id:`note-${d.notes.length+1}`,anchor:e.anchor,revision:v.revision,text:e.text,proposal:e.proposal,addressedRevision:null,verifiedRevision:null});invalidate(d);return true;
 }
 if(e.type==='MISSION_DELIVERY_EDIT_NOTE'){
  if(!note||typeof e.text!=='string'||!e.text.trim()||e.text.length>2000||typeof e.proposal!=='string'||e.proposal.length>8000)return false;
  if(note.text===e.text&&note.proposal===e.proposal)return false;
  note.text=e.text;note.proposal=e.proposal;note.addressedRevision=null;note.verifiedRevision=null;invalidate(d);return true;
 }
 if(e.type==='MISSION_DELIVERY_REVISE'){
  const pending=d.notes.filter(n=>!n.addressedRevision);
  if(!pending.length&&!deliveryStale(d)||pending.some(n=>!n.proposal.trim())||d.versions.length>=30)return false;
  const next=structuredClone(v);next.revision++;next.sourceRevision=d.sourceRevision;
  next.summary=pending.length?`${pending.length} requested correction${pending.length===1?'':'s'} included. Compare the wording and verify each comment.`:'Projection refreshed against the updated demo source. Review the new revision.';
  for(const n of pending){next.sections.find(s=>s.id===n.anchor).body=n.proposal;n.addressedRevision=next.revision;}
  // Multiple proposals on one section are applied in order; the reviewer verifies
  // each against the final wording, so no correction is accepted automatically.
  if(deliveryStale(d))next.sections.find(s=>s.id==='references').body+=`\n\nDemo source update r${d.sourceRevision}: acceptance must state the remaining integration gaps explicitly.`;
  for(const n of d.notes)n.verifiedRevision=null;
  d.versions.push(next);invalidate(d);return true;
 }
 if(e.type==='MISSION_DELIVERY_VERIFY'){
  if(!note?.addressedRevision||deliveryStale(d)||typeof e.value!=='boolean')return false;
  note.verifiedRevision=e.value?v.revision:null;d.accepted=null;return true;
 }
 if(e.type==='MISSION_DELIVERY_REVIEWED'||e.type==='MISSION_DELIVERY_CRITERIA'){
  if(deliveryStale(d)||typeof e.value!=='boolean')return false;
  d[e.type==='MISSION_DELIVERY_REVIEWED'?'reviewedRevision':'criteriaRevision']=e.value?v.revision:null;d.accepted=null;return true;
 }
 if(e.type==='MISSION_DELIVERY_SOURCE') {d.sourceRevision++;for(const n of d.notes)n.verifiedRevision=null;invalidate(d);return true;}
 if(e.type==='MISSION_DELIVERY_ACCEPT'){
  if(!canAcceptDelivery(d)||d.accepted)return false;
  d.accepted={revision:v.revision,sourceRevision:d.sourceRevision,at:new Date().toISOString(),noteIds:d.notes.map(n=>n.id)};d.acceptanceHistory.push(structuredClone(d.accepted));return true;
 }
 return false;
}
const text=(v,max=8000)=>typeof v==='string'&&v.length<=max;
export function validDelivery(d){
 if(!d||!text(d.sourceId)||!Number.isInteger(d.sourceRevision)||d.sourceRevision<1||!Array.isArray(d.versions)||!d.versions.length||d.versions.length>30||!Array.isArray(d.notes)||d.notes.length>50||!Array.isArray(d.acceptanceHistory))return false;
 if(d.versions.some((v,i)=>!v||v.revision!==i+1||!Number.isInteger(v.sourceRevision)||v.sourceRevision<1||v.sourceRevision>d.sourceRevision||!text(v.summary)||!Array.isArray(v.sections)||v.sections.length!==4||new Set(v.sections.map(s=>s?.id)).size!==4||v.sections.some(s=>!DELIVERY_SECTIONS.includes(s?.id)||!text(s.title)||!text(s.body,20000))))return false;
 const last=latestDelivery(d).revision,rev=v=>v===null||Number.isInteger(v)&&v>=1&&v<=last;
 if(!rev(d.reviewedRevision)||!rev(d.criteriaRevision)||new Set(d.notes.map(n=>n?.id)).size!==d.notes.length||d.notes.some((n,i)=>!n||n.id!==`note-${i+1}`||!DELIVERY_SECTIONS.includes(n.anchor)||!text(n.text,2000)||!n.text.trim()||!text(n.proposal)||!Number.isInteger(n.revision)||n.revision<1||n.revision>last||!rev(n.addressedRevision)||!rev(n.verifiedRevision)||n.addressedRevision!==null&&n.addressedRevision<=n.revision||n.verifiedRevision!==null&&(!n.addressedRevision||n.verifiedRevision<n.addressedRevision)))return false;
 const acceptance=a=>a&&Number.isInteger(a.revision)&&a.revision>=1&&a.revision<=last&&Number.isInteger(a.sourceRevision)&&a.sourceRevision===d.versions[a.revision-1].sourceRevision&&Number.isFinite(Date.parse(a.at))&&Array.isArray(a.noteIds)&&a.noteIds.every(id=>d.notes.some(n=>n.id===id));
 if(d.acceptanceHistory.some(a=>!acceptance(a)))return false;
 if(d.accepted&&(!acceptance(d.accepted)||!canAcceptDelivery(d)||d.accepted.revision!==last||d.accepted.sourceRevision!==d.sourceRevision||JSON.stringify(d.accepted.noteIds)!==JSON.stringify(d.notes.map(n=>n.id))||JSON.stringify(d.accepted)!==JSON.stringify(d.acceptanceHistory.at(-1))))return false;
 return true;
}
export function deliveryMarkdown(m){const d=m.delivery;if(!d)return '';const v=latestDelivery(d);return [`# ${m.title} · delivery r${v.revision}`,'> Local simulated proposal; not evidence of real execution.',`Source: ${d.sourceId} · source r${v.sourceRevision} (current r${d.sourceRevision})`,'',...v.sections.flatMap(s=>[`## ${s.title}`,s.body,'']),'## Anchored feedback',...d.notes.flatMap(n=>[`### ${n.anchor} · artifact r${n.revision}`,n.text,`Proposed replacement: ${n.proposal||'Not supplied.'}`,`Verified on revision: ${n.verifiedRevision||'pending'}`,'']),`Acceptance: ${d.accepted?`r${d.accepted.revision} · ${d.accepted.at}`:'Awaiting judgment'}.`].join('\n');}

export function deliveryExample(m){
 const design=m.scenario==='studio-design';
 return {anchor:'proposal',draft:design?'Make the first interaction explicit: I should explain the mission in my words, with an optional name.':'Make the verification gap explicit before accepting the proposal.',proposal:latestDelivery(m.delivery).sections.find(s=>s.id==='proposal').body+(design?'\n\nFirst interaction: describe the mission in your own words. The name is optional. Emon proposes the first brief; you can edit each section or give feedback before approving it.':'\n\nVerification gap: this is a proposal for review. Real execution and fresh evidence are still required before claiming the underlying outcome is achieved.')};
}
