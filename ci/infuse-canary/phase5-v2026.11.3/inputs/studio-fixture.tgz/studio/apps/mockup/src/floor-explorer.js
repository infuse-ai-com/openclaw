import * as THREE from 'three';
import { STOREY_HEIGHT } from '@studio/spatial/building';
import { allFloors } from './simulation/company.js';
import './floor-explorer.css';

const clamp=THREE.MathUtils.clamp,lerp=THREE.MathUtils.lerp;
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const examples=[
  {status:'Review needed',counts:'2 active · 1 review',next:'Workspace direction is ready for your decision'},
  {status:'In progress',counts:'3 active · 1 blocked',next:'Market signal · 3 of 6 tasks verified'},
  {status:'Quiet floor',counts:'No active missions',next:'Ready for the next idea'},
];

// One camera leaves the room, travels along the facade and returns indoors.
export function createFloorExplorer({getState,enterFloor}) {
  let api,phase='floor',origin,originIndex,selected,floors=[],entries=[],building,room;
  let progress=0,goal=0,floorPosition=0,floorGoal=0,lastTime=0,dirty=true;
  let closePose,entryPose,roomScale,roomPosition,roomY=0;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const shell=document.querySelector('.world-shell');
  const overlay=document.createElement('div');
  overlay.className='fx-overlay';overlay.hidden=true;
  overlay.innerHTML='<div class="fx-heading"><span>COMPANY / PROJECT FLOORS</span><h2>Your office, outside.</h2><p>Scroll to move between floors.</p></div><div class="fx-floor-labels" aria-label="Project floors"></div><aside class="fx-mission" aria-label="Focused floor mission status"></aside><p class="fx-footnote">Scroll between floors · Click a floor to enter · Esc to return</p>';
  document.querySelector('#world').append(overlay);
  const trigger=document.createElement('button');
  trigger.className='fx-trigger';trigger.textContent='Floors ↗';
  trigger.setAttribute('aria-label','Explore project floors');
  document.querySelector('.world-controls').append(trigger);
  trigger.onclick=()=>open(true);
  overlay.addEventListener('click',event=>{
    const button=event.target.closest('[data-fx-floor]');
    if(button)enter(button.dataset.fxFloor);
  });
  overlay.addEventListener('focusin',event=>{
    const button=event.target.closest('[data-fx-floor]');
    if(button)select(button.dataset.fxFloor);
  });
  const onKey=event=>{if(!event.defaultPrevented&&key(event))event.stopPropagation();};
  shell.addEventListener('keydown',onKey);
  const active=()=>phase!=='floor';
  function setPhase(value){phase=value;shell.dataset.floorTransition=value;}
  function snapshot(){return {target:api.controls.target.clone(),position:api.camera.position.clone(),zoom:api.camera.zoom};}
  function open(automatic=true){
    if(active()||getState().view!=='floor'||getState().surface)return;
    origin=selected=getState().floor;
    floors=allFloors(getState()).toSorted((a,b)=>Number(a.number)-Number(b.number));
    originIndex=floors.findIndex(f=>f.id===origin);
    floorPosition=floorGoal=originIndex;progress=0;goal=automatic?1:0;
    entries=[];dirty=true;entryPose=null;lastTime=performance.now();
    overlay.querySelector('.fx-floor-labels').replaceChildren();
    overlay.hidden=false;shell.classList.add('fx-overview');
    room=api?.root().children.find(child=>child.userData.floor===origin);
    if(!room){
      shell.classList.add('fx-flat');setPhase('exterior');
      for(const floor of floors){
        const button=document.createElement('button');
        button.dataset.fxFloor=floor.id;button.className='fx-floor-label';button.textContent=floor.title;
        overlay.querySelector('.fx-floor-labels').append(button);
      }
      select(origin);return;
    }
    closePose=snapshot();roomScale=room.scale.clone();roomPosition=room.position.clone();roomY=0;
    api.controls.enabled=false;api.hideDetails(true);
    building=api.mountExterior(floors,(text,point,action,className)=>{
      const button=document.createElement('button');
      button.className=`fx-floor-label ${className}`;button.textContent=text;
      overlay.querySelector('.fx-floor-labels').append(button);
      entries.push({button,point});
      return button;
    });
    for(const entry of entries)entry.button.dataset.fxFloor=entry.button.dataset.floorEntry;
    building.group.position.y=-originIndex*STOREY_HEIGHT;
    building.opacity(0);
    select(origin);setPhase('pulling-out');
  }
  function select(id){
    if(phase==='entering'||(!active()&&!building))return;
    const index=floors.findIndex(floor=>floor.id===id);
    if(index<0)return;
    selected=id;building?.highlight(id);dirty=true;
    shell.dataset.floorTarget=id;
    for(const entry of entries)entry.button.dataset.selected=String(entry.button.dataset.fxFloor===id);
    const panel=overlay.querySelector('.fx-mission');
    if(panel.dataset.floor===id)return;
    panel.dataset.floor=id;
    const floor=floors[index],status=examples[index]||examples[2];
    panel.innerHTML=`<span class="fx-eyebrow">FLOOR ${esc(floor.number)} / MISSION DESK</span><h3>${esc(floor.title)}</h3><p class="fx-status">${status.status} <span>${status.counts}</span></p><p class="fx-next">${status.next}</p><button data-fx-floor="${esc(id)}">Enter floor ↗</button><small>Illustrative mission status</small>`;
  }
  function exteriorPose(){
    const height=api.camera.top-api.camera.bottom,width=api.camera.right-api.camera.left;
    const middle=(floors.length-1)*STOREY_HEIGHT/2;
    const focus=middle+2.2+(floorPosition*STOREY_HEIGHT-middle)*.4-originIndex*STOREY_HEIGHT;
    const target=new THREE.Vector3(-.6,focus,0);
    return {target,position:target.clone().add(new THREE.Vector3(-14,13,30)),zoom:Math.min(.9,height/28,width/29)};
  }
  function applyPose(pose){
    api.controls.target.copy(pose.target);api.camera.position.copy(pose.position);
    api.camera.zoom=pose.zoom;api.camera.lookAt(pose.target);api.camera.updateProjectionMatrix();
  }
  function enter(id=selected,automatic=true){
    if(!active()||!floors.some(floor=>floor.id===id))return;
    if(!room){cleanup();enterFloor(id);return;}
    if(id===origin&&progress<1&&phase!=='entering'){goal=0;dirty=true;return;}
    selected=id;entryPose=snapshot();goal=automatic?0:1;progress=1;
    roomY=(floors.findIndex(f=>f.id===id)-originIndex)*STOREY_HEIGHT;
    api.decorate(room,floors.find(f=>f.id===id).title);
    setPhase('entering');dirty=true;
  }
  function travel(delta){
    floorGoal=clamp(floorGoal+delta/480,0,floors.length-1);
    select(floors[Math.round(floorGoal)].id);dirty=true;
  }
  function wheel(event,floorAtPointer){
    if(getState().view!=='floor'||getState().surface||!api||!event.deltaY)return false;
    let pixels=event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?api.host.clientHeight:1);
    if(!active()){
      const current=api.camera.zoom,next=clamp(current*Math.exp(-pixels*.0015),.65,2.1);
      if(pixels>0&&next<=.65){
        pixels-=Math.max(0,Math.log(current/.65)/.0015);
        api.setFloorZoom(.65);open(false);
      }else{api.setFloorZoom(next);return true;}
    }
    if(!room)return false;
    if(phase==='entering'){goal=clamp(goal+pixels/600,0,1);dirty=true;return true;}
    if(goal>=1&&progress>=.9999){
      if(pixels<0){enter(floorAtPointer?.()||selected,false);goal=clamp(1+pixels/600,0,1);dirty=true;}
      else travel(pixels);
      return true;
    }
    const next=goal+pixels/600;
    goal=clamp(next,0,1);
    if(next>1)travel((next-1)*600);
    dirty=true;return true;
  }
  function cleanup(){
    building?.destroy();building=null;
    if(room){room.visible=true;room.scale.copy(roomScale);room.position.copy(roomPosition);api.decorate(room,floors.find(f=>f.id===origin).title);}
    entries=[];setPhase('floor');shell.dataset.floorProgress='0';
    delete shell.dataset.floorTarget;delete shell.dataset.floorPosition;
    shell.classList.remove('fx-overview','fx-flat');overlay.hidden=true;
    if(api){api.controls.enabled=true;api.hideDetails(false);}
  }
  function tick(now){
    if(!active()||!room)return;
    const dt=Math.max(0,now-lastTime);lastTime=now;
    if(progress===goal&&floorPosition===floorGoal&&!dirty)return false;
    const ease=reduced.matches?1:1-Math.exp(-dt/75);
    progress=lerp(progress,goal,ease);floorPosition=lerp(floorPosition,floorGoal,ease);
    if(Math.abs(progress-goal)<.0001)progress=goal;
    if(Math.abs(floorPosition-floorGoal)<.0001)floorPosition=floorGoal;
    const entering=phase==='entering',outside=entering?entryPose:exteriorPose();
    const inside=entering?{
      target:new THREE.Vector3(0,roomY+1.1,0),
      position:new THREE.Vector3(-10,roomY+25.1,30),zoom:1,
    }:closePose;
    applyPose({
      target:inside.target.clone().lerp(outside.target,progress),
      position:inside.position.clone().lerp(outside.position,progress),
      zoom:lerp(inside.zoom,outside.zoom,progress),
    });
    room.position.y=roomY;
    room.scale.set(lerp(roomScale.x,.52,progress),lerp(roomScale.y,.85,progress),lerp(roomScale.z,.45,progress));
    room.visible=progress<.88;
    building.group.scale.set(lerp(1.9,1,progress),1,lerp(2.2,1,progress));
    building.opacity(clamp((progress-.12)/.7,0,1));
    shell.dataset.floorProgress=progress.toFixed(4);
    shell.dataset.floorPosition=floorPosition.toFixed(4);
    if(!entering)setPhase(progress===1?'exterior':progress===goal?'scrubbing':'pulling-out');
    project();dirty=false;
    if(entering&&progress===1&&goal===1){roomY=0;entryPose=null;setPhase('exterior');}
    if(progress===0&&goal===0){
      const destination=entering?selected:origin;
      cleanup();
      if(entering){enterFloor(destination);api.home();}
      else api.restoreCamera(closePose);
      api.canvas.focus({preventScroll:true});
    }
  }
  function project(){
    api.camera.updateMatrixWorld();building.group.updateMatrixWorld(true);
    const width=api.host.clientWidth,height=api.host.clientHeight;
    for(const {button,point} of entries){
      const p=building.group.localToWorld(point.clone()).project(api.camera);
      button.style.left=`clamp(8px, ${(.5+p.x*.5)*width}px, ${width-58}px)`;
      button.style.top=`${(.5-p.y*.5)*height-23}px`;
      button.style.opacity=String(clamp((progress-.6)/.4,0,1));
      button.style.pointerEvents=progress>.9?'auto':'none';
    }
    const panel=overlay.querySelector('.fx-mission');
    panel.style.opacity=String(clamp((progress-.55)/.45,0,1));panel.inert=progress<.9;
  }
  function key(event){
    if(!active())return false;
    if(event.key==='Escape'){event.preventDefault();enter(origin);return true;}
    if(['ArrowUp','ArrowDown'].includes(event.key)){
      event.preventDefault();goal=1;travel(event.key==='ArrowUp'?480:-480);return true;
    }
    if(event.key==='Enter'){event.preventDefault();enter(event.target.closest?.('[data-fx-floor]')?.dataset.fxFloor||selected);return true;}
    return false;
  }
  return {
    bind(value){api=value;},open,active,tick,select,key,wheel,invalidate(){dirty=true;},
    pick(id){if(id)enter(id);},
    zoom(delta){if(!active())return false;if(delta>0)enter();else{goal=1;travel(480);}return true;},
    home(){if(!active())return false;enter(origin);return true;},
    sync(next){if(active()&&(next.view!=='floor'||next.surface||next.floor!==origin)){cleanup();api?.home();}},
    destroy(){cleanup();shell.removeEventListener('keydown',onKey);overlay.remove();trigger.remove();},
  };
}
