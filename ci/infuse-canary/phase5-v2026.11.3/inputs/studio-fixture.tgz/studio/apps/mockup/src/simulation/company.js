import { FLOORS, PEOPLE, SKILLS, CATALOG_REVISION, MODEL_PRESETS, DEFAULT_MODEL, REASONING_LEVELS } from '../scenarios/catalog.js';
export { MODEL_PRESETS, REASONING_LEVELS } from '../scenarios/catalog.js';

// Saved project membership is separate from a mission's temporary squad.
// Provider choices are descriptive demo presets; no model calls are made.
export const modelLabel = preset => preset;
export const GUEST_SKILLS = {
  'expert-advice': {title:'Specialist advice',outcome:'Apply the supplied expertise and brief to a focused question.',requires:'Mission context and reviewed research brief',tools:'Supplied notes and source references',permissions:'Local draft advice only',artifact:'Recommendations with assumptions',verification:'Separate sourced claims from judgment'},
  'expert-review': {title:'Expert critique',outcome:'Challenge an artifact from this expert’s point of view.',requires:'Artifact and acceptance criteria',tools:'Artifact inspector and supplied brief',permissions:'Comments only',artifact:'Anchored findings and open questions',verification:'Each finding identifies evidence or a gap'}
};
export const capability = id => SKILLS[id] || GUEST_SKILLS[id];
export const allFloors = s => s.mvpFloors || [...(s.projects || []).toReversed(), ...FLOORS];
export const projectFloor = (s,id=s.floor) => s.projects?.find(f=>f.id===id);
export function companyPeople(s, draft=false) {
  if(s.mvpPeople)return s.mvpPeople;
  const guests=new Map((s.guests||[]).map(p=>[p.id,p]));
  if(draft)for(const p of s.floorDraft?.guests||[])guests.set(p.id,p);
  return [...PEOPLE,...guests.values()];
}
export function floorPeople(s,id=s.floor) {
  const f=projectFloor(s,id);
  const mission=s.missionDesk?.items.find(m=>m.floorId===id&&m.id===s.missionDesk.selected[id]);
  return f?companyPeople(s).filter(p=>p.id==='fito'||f.residents.some(r=>r.personId===p.id)||mission?.squad.includes(p.id)):companyPeople(s).filter(p=>!p.guest||s.knowledge?.expertFloors?.[id]?.includes(p.id)||mission?.squad.includes(p.id));
}
export const residentFor = (s,id) => projectFloor(s)?.residents.find(r=>r.personId===id);
const limits={title:64,description:2400,name:48,role:120,traits:1200,brief:8000,sources:4000};
const textOK=(v,key,required=false)=>typeof v==='string'&&v.length<=limits[key]&&(!required||v.trim().length>0);
const nextId=(prefix,records)=>`${prefix}-${Math.max(0,...records.map(x=>Number(x.id.split('-')[1])||0))+1}`;
export const guestValid=p=>p&&/^guest-\d+$/.test(p.id)&&['name','role','traits'].every(k=>textOK(p[k],k,true))&&['brief','sources'].every(k=>textOK(p[k],k))&&p.skills?.length===2&&p.skills[0]==='expert-advice'&&p.skills[1]==='expert-review'&&p.color==='#aa8fbe'&&p.hair==='#4b3549';
const newResident=p=>({personId:p.id,capabilities:[...p.skills],llm:DEFAULT_MODEL,reasoning:'Medium'});
export function floorErrors(s,step='review') {
  const d=s.floorDraft;if(!d)return ['Start a project first.'];
  const errors=[];
  if(!d.title.trim())errors.push('Give this project a name.');
  if(!d.description.trim())errors.push('Describe what this project is here to achieve.');
  if(allFloors(s).some(f=>f.id!==d.originalId&&f.title.trim().toLowerCase()===d.title.trim().toLowerCase()))errors.push('A floor already uses this name. Choose a distinct project name.');
  if(step!=='project'){
    if(!d.residents.length)errors.push('Choose at least one resident agent.');
    if(d.residents.some(r=>!r.capabilities.length))errors.push('Choose at least one capability for each resident.');
    if(d.guestEditor)errors.push('Save or cancel the guest profile before continuing.');
  }
  return errors;
}
export function companyTransition(state,event) {
  if(!event.type.startsWith('FLOOR_')&&!event.type.startsWith('GUEST_'))return null;
  const s=structuredClone(state);
  if(event.type==='FLOOR_BEGIN'||event.type==='FLOOR_EDIT'){
    const existing=event.type==='FLOOR_EDIT'?projectFloor(s):null;
    if(event.type==='FLOOR_EDIT'&&!existing)return state;
    if(existing||!s.floorDraft)s.floorDraft={originalId:existing?.id||null,title:existing?.title||'',description:existing?.description||'',residents:existing?structuredClone(existing.residents):[newResident(PEOPLE.find(p=>p.id==='emon'))],guests:[],step:'project',selectedPerson:existing?.residents[0]?.personId||'emon',guestEditor:null,errors:[]};
    s.surface='floor-setup';s.peekPerson=null;s.detail=null;return s;
  }
  const d=s.floorDraft;if(!d)return state;
  switch(event.type){
    case 'FLOOR_FIELD':
      if(!['title','description'].includes(event.key)||!textOK(event.value,event.key))return state;
      d[event.key]=event.value;d.errors=[];return s;
    case 'FLOOR_STEP': {
      if(!['project','team','review'].includes(event.step))return state;
      d.errors=event.step==='project'?[]:floorErrors(s,event.step==='team'?'project':'review');
      if(!d.errors.length)d.step=event.step;
      return s;
    }
    case 'FLOOR_RESIDENT': {
      const p=companyPeople(s,true).find(p=>p.id===event.id&&p.id!=='fito');if(!p)return state;
      if(d.residents.some(r=>r.personId===p.id))d.residents=d.residents.filter(r=>r.personId!==p.id);
      else {if(d.residents.length>=8){d.errors=['This demo floor has room for eight resident agents.'];return s;}d.residents.push(newResident(p));d.selectedPerson=p.id;}
      d.errors=[];return s;
    }
    case 'FLOOR_PERSON':
      if(!companyPeople(s,true).some(p=>p.id===event.id&&p.id!=='fito'))return state;
      d.selectedPerson=event.id;return s;
    case 'FLOOR_CAPABILITY': {
      const r=d.residents.find(r=>r.personId===event.person),p=companyPeople(s,true).find(p=>p.id===event.person);
      if(!r||!p.skills.includes(event.id))return state;
      r.capabilities=r.capabilities.includes(event.id)?r.capabilities.filter(k=>k!==event.id):[...r.capabilities,event.id];d.errors=[];return s;
    }
    case 'FLOOR_PRESET': {
      const r=d.residents.find(r=>r.personId===event.person);if(!r)return state;
      if(event.key==='llm'&&MODEL_PRESETS.includes(event.value))r.llm=event.value;
      else if(event.key==='reasoning'&&REASONING_LEVELS.includes(event.value))r.reasoning=event.value;
      else return state;
      return s;
    }
    case 'GUEST_BEGIN': {
      const existing=companyPeople(s,true).find(p=>p.id===event.id&&p.guest);
      d.guestEditor=existing?structuredClone(existing):{id:nextId('guest',companyPeople(s,true).filter(p=>p.guest)),name:'',role:'',traits:'',brief:'',sources:'',description:'Custom expert with an owner-supplied brief.',guest:true,color:'#aa8fbe',hair:'#4b3549',skills:['expert-advice','expert-review']};d.errors=[];return s;
    }
    case 'GUEST_FIELD':
      if(!d.guestEditor||!['name','role','traits','brief','sources'].includes(event.key)||!textOK(event.value,event.key))return state;
      d.guestEditor[event.key]=event.value;d.errors=[];return s;
    case 'GUEST_CANCEL':d.guestEditor=null;d.errors=[];return s;
    case 'GUEST_SAVE': {
      const p=d.guestEditor;if(!guestValid(p)){d.errors=['Give the guest a name, specialty, and working style. Research notes and sources can be added later.'];return s;}
      if(companyPeople(s,true).some(x=>x.id!==p.id&&x.name.trim().toLowerCase()===p.name.trim().toLowerCase())){d.errors=['Choose a distinct name so this guest is easy to recognize.'];return s;}
      if(!d.residents.some(r=>r.personId===p.id)&&d.residents.length>=8){d.errors=['This demo floor has room for eight resident agents. Remove a resident before adding this guest.'];return s;}
      d.guests=[...d.guests.filter(x=>x.id!==p.id),p];
      if(!d.residents.some(r=>r.personId===p.id))d.residents.push(newResident(p));
      d.selectedPerson=p.id;d.guestEditor=null;d.errors=[];return s;
    }
    case 'FLOOR_SAVE': {
      d.errors=floorErrors(s);if(d.errors.length){d.step=d.errors.some(e=>e.includes('name')||e.includes('Describe'))?'project':'team';return s;}
      const existing=projectFloor(s,d.originalId),id=existing?.id||nextId('project',s.projects);
      const f={id,number:existing?.number||String(FLOORS.length+s.projects.length+1).padStart(2,'0'),title:d.title.trim(),description:d.description,residents:d.residents,status:'Ready for first mission',accent:'#aa8fbe'};
      s.projects=existing?s.projects.map(p=>p.id===id?f:p):[...s.projects,f];
      const guestMap=new Map(s.guests.map(p=>[p.id,p]));for(const p of d.guests)guestMap.set(p.id,p);s.guests=[...guestMap.values()];
      s.settings[id]||={layout:'promenade',desk:'fixed'};
      s.floor=id;s.view='floor';s.surface=null;s.peekPerson=null;s.selectedObject=null;s.floorDraft=null;return s;
    }
    default:return state;
  }
}

// Migrate identity references, never user wording, research, or archived evidence.
// New specialists are available but are not silently added to an existing squad.
export function migrateCatalog(s) {
  if(s.catalogRevision===CATALOG_REVISION)return false;
  if(s.catalogRevision!==undefined)throw Error('catalog revision');
  const identity=id=>id==='pieter'?'satwa':id;
  const oldModels={'Balanced':DEFAULT_MODEL,'Fast':'GPT-5.6 Sol','Deep':'GPT-6 Astra','OpenAI · balanced':DEFAULT_MODEL,'Anthropic · deliberate':'Opus 5.5','Google · broad context':DEFAULT_MODEL,'Local · private':DEFAULT_MODEL};
  const model=value=>Object.hasOwn(oldModels,value)?oldModels[value]:value;
  const m=s.mission;
  if(m){
    if(Array.isArray(m.squad))m.squad=m.squad.map(identity);
    if(m.capabilities&&typeof m.capabilities==='object'){
      if(Object.hasOwn(m.capabilities,'pieter')){m.capabilities.satwa=m.capabilities.pieter;delete m.capabilities.pieter;}
      for(const id of ['stewie','ramiro'])m.capabilities[id]??=[...PEOPLE.find(p=>p.id===id).skills];
    }
    m.model=model(m.model);
    if(m.annotation?.recorded)m.annotation.recorded.owner=identity(m.annotation.recorded.owner);
  }
  for(const f of [...(Array.isArray(s.projects)?s.projects:[]),...(s.floorDraft?[s.floorDraft]:[])]){
    if(Array.isArray(f.residents))for(const r of f.residents){r.personId=identity(r.personId);r.llm=model(r.llm);}
    if(f.selectedPerson)f.selectedPerson=identity(f.selectedPerson);
  }
  for(const key of ['selectedObject','peekPerson','detail'])if(s[key])s[key]=identity(s[key]);
  s.catalogRevision=CATALOG_REVISION;
  return true;
}

// Old spatial saves gain empty company collections without altering the mission.
// Reject malformed company data using the same explicit recovery notice as v1.
export function validateCompanyState(s) {
  s.projects??=[];s.guests??=[];s.floorDraft??=null;
  if(!Array.isArray(s.projects)||!Array.isArray(s.guests)||s.guests.some(p=>!guestValid(p)||p.guest!==true)||new Set(s.guests.map(p=>p.id)).size!==s.guests.length)throw Error('company people');
  const validateResidents=(residents,people,incomplete=false)=>{
    if(!Array.isArray(residents)||residents.length>8||(!incomplete&&!residents.length)||new Set(residents.map(r=>r.personId)).size!==residents.length)throw Error('residents');
    for(const r of residents){const p=people.find(p=>p.id===r.personId&&p.id!=='fito');if(!p||!Array.isArray(r.capabilities)||(!incomplete&&!r.capabilities.length)||new Set(r.capabilities).size!==r.capabilities.length||r.capabilities.some(k=>!p.skills.includes(k))||!MODEL_PRESETS.includes(r.llm)||!REASONING_LEVELS.includes(r.reasoning))throw Error('resident config');}
  };
  if(new Set(s.projects.map(p=>p.id)).size!==s.projects.length)throw Error('floor ids');
  for(const p of s.projects){if(!/^project-\d+$/.test(p.id)||!/^\d+$/.test(p.number)||!textOK(p.title,'title',true)||!textOK(p.description,'description',true)||p.status!=='Ready for first mission'||p.accent!=='#aa8fbe')throw Error('project');validateResidents(p.residents,companyPeople(s));}
  const d=s.floorDraft;if(!d)return;
  if(!textOK(d.title,'title')||!textOK(d.description,'description')||!['project','team','review'].includes(d.step)||!Array.isArray(d.guests)||d.guests.some(p=>!guestValid(p))||(d.originalId!==null&&!projectFloor(s,d.originalId))||!Array.isArray(d.errors)||d.errors.some(e=>typeof e!=='string'))throw Error('floor draft');
  validateResidents(d.residents,companyPeople(s,true),true);
  if(d.guestEditor){const g=d.guestEditor;if(!/^guest-\d+$/.test(g.id)||!['name','role','traits','brief','sources'].every(k=>textOK(g[k],k)))throw Error('guest draft');}
  if(d.selectedPerson&&!companyPeople(s,true).some(p=>p.id===d.selectedPerson))throw Error('selected resident');
}
