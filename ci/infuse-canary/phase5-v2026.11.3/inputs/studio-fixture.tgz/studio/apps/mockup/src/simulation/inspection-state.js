import { partner } from './reference-catalog.js';

// Transport previews never start work or stand in for task verification.
export function inspectionTransition(s,event,m) {
 const x=m?.execution;if(!x)return false;
 if(event.type==='CONNECTED_COMMENT'){
  if(typeof event.text!=='string'||!event.text.trim()||typeof event.commandId!=='string'||!event.commandId||event.commandId.length>160||!['coordination',...x.tasks.map(t=>t.id)].includes(event.thread))return true;
  x.comments??=[];
  if(x.comments.some(c=>c.id===event.commandId))return true;
  x.comments.push({id:event.commandId,thread:event.thread,text:event.text.slice(0,2000),author:partner(s),delivery:event.uncertain?'uncertain':'delivered'});
  s.connected.notice=event.uncertain?'Comment receipt is uncertain. Reconcile this exact request; do not send another copy.':'Comment recorded in the local thread. No external message was sent.';
  return true;
 }
 if(event.type==='CONNECTED_COMMENT_RECONCILE'){
  const c=x.comments?.find(c=>c.id===event.id&&c.author===partner(s));
  if(c)c.delivery='delivered';return true;
 }
 if(event.type==='CONNECTED_TRANSPORT'){
  const t=x.tasks.find(t=>t.state!=='verified');
  if(t&&!['closed','cancelled'].includes(x.state))x.transport={taskId:t.id,state:'uncertain'};
  return true;
 }
 if(event.type==='CONNECTED_TRANSPORT_RECONCILE'){
  if(x.transport)x.transport.state='delivered';return true;
 }
 return false;
}
export function retainInspectionHistory(m,event){
 const x=m?.execution;if(!x)return;
 x.instructions??=[];x.findings??=[];
 if(x.instruction){
  let item=x.instructions.at(-1);
  if(event.type==='CONNECTED_FEEDBACK'&&(!item||item.text!==x.instruction.text||item.state!==x.instruction.state)||!item){
   item={...x.instruction,id:`instruction-${x.instructions.length+1}`,receipts:['Received by Studio']};x.instructions.push(item);
  }
  if(item.state!==x.instruction.state){item.state=x.instruction.state;item.receipts.push('Read and applied in the same task session');}
 }
 if(x.finding){
  let item=x.findings.at(-1);
  if(!item||item.taskId!==x.finding.taskId||item.title!==x.finding.title||item.state==='closed'&&x.finding.state==='open'){
   item={...x.finding,id:`finding-${x.findings.length+1}`,severity:'medium',required:true,history:['Opened · fresh evidence required']};x.findings.push(item);
  }
  if(item.state!==x.finding.state){item.state=x.finding.state;item.history.push('Closed · Emon verified the revised evidence');}
 }
}
export function validInspection(x){
 return (!x.comments||Array.isArray(x.comments)&&x.comments.every(c=>['id','thread','text','author'].every(k=>typeof c[k]==='string')&&['delivered','uncertain'].includes(c.delivery)&&['coordination',...x.tasks.map(t=>t.id)].includes(c.thread)))
 &&(!x.transport||x.tasks.some(t=>t.id===x.transport.taskId)&&['uncertain','delivered'].includes(x.transport.state))
 &&(!x.instructions||Array.isArray(x.instructions)&&x.instructions.every(i=>typeof i.id==='string'&&typeof i.text==='string'&&['received','applied'].includes(i.state)&&x.tasks.some(t=>t.id===i.taskId)&&Array.isArray(i.receipts)&&i.receipts.every(r=>typeof r==='string')))
 &&(!x.findings||Array.isArray(x.findings)&&x.findings.every(f=>typeof f.id==='string'&&typeof f.title==='string'&&['open','closed'].includes(f.state)&&x.tasks.some(t=>t.id===f.taskId)&&Array.isArray(f.history)&&f.history.every(h=>typeof h==='string')));
}
