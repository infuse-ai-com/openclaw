import test from 'node:test';
import assert from 'node:assert/strict';
import {createDesktopController,desktopSurface} from '../src/my-screen.js';
import {initialState,transition} from '../src/simulation/model.js';
import {switchWorkspaceProject,canonicalWorkspaceState} from '../src/workspace-navigation.js';
import {workspaceSidebar} from '../src/workspace-sidebar.js';

test('personal desktops survive project switches without changing mission records and isolate partners',()=>{
 let owner='Fito';const pending=[];
 const desktop=createDesktopController({getOwner:()=>owner,isVisible:()=>true,render(){},schedule:fn=>pending.push(fn)});
 let state=canonicalWorkspaceState(transition(initialState(),{type:'OPEN',surface:'my-screen'}));
 const before=structuredClone(state.missionDesk);
 desktop.act('connect');pending.shift()();desktop.act('tool','Claude Code');desktop.act('folder','Finaxis');
 state=switchWorkspaceProject(state,'growth');
 assert.equal(state.surface,'founder-desk');assert.equal(state.floor,'growth');assert.deepEqual(state.missionDesk,before);
 assert.equal(desktop.view().status,'connected');assert.equal(desktop.view().folder,'Finaxis');
 owner='Alex';assert.equal(desktop.view().status,'disconnected');assert.equal(desktop.view().tool,'Codex');
 owner='Fito';assert.equal(desktop.view().tool,'Claude Code');
 const html=workspaceSidebar(state,new Proxy({},{get:()=>''}));
 assert.ok(html.indexOf('aria-label="My desk"')<html.indexOf('aria-label="Project navigation:'));
 assert.match(html,/data-action="founder-desk"[^>]*aria-current="page"/);assert.ok(!html.includes('aria-label="My screen"'));
});
test('cancelled, reset and superseded connection attempts cannot reopen a desktop',()=>{
 let owner='Fito';const pending=[];
 const desktop=createDesktopController({getOwner:()=>owner,isVisible:()=>true,render(){},schedule:fn=>pending.push(fn)});
 desktop.act('connect');desktop.act('disconnect');pending.shift()();assert.equal(desktop.view().status,'disconnected');
 desktop.act('connect');desktop.act('disconnect');desktop.act('connect');pending.shift()();assert.equal(desktop.view().status,'connecting');pending.shift()();assert.equal(desktop.view().status,'connected');
 desktop.act('tool','Terminal');desktop.act('interrupt');desktop.act('connect');pending.shift()();assert.equal(desktop.view().tool,'Terminal');
 desktop.act('connect');desktop.reset();desktop.act('connect');pending.shift()();assert.equal(desktop.view().status,'connecting');pending.shift()();assert.equal(desktop.view().status,'connected');
 desktop.act('disconnect');desktop.act('connect');owner='Alex';pending.shift()();assert.equal(desktop.view().status,'disconnected');assert.equal(desktop.view('Fito').status,'connected');
});
test('desktop previews escape the owner and label tool output as simulated',()=>{
 const desktop=createDesktopController({getOwner:()=>'<img src=x>',isVisible:()=>true,render(){}});
 const html=desktopSurface('<img src=x>',{...desktop.view(),status:'connected'},new Proxy({},{get:()=>''}));
 assert.ok(!html.includes('<img'));assert.ok(html.includes('&lt;img src=x&gt;'));assert.match(html,/No commands or model sessions run/);assert.match(html,/Connected · demo/);
 desktop.act('folder','/etc/secret');assert.equal(desktop.view().folder,'Core');
});
