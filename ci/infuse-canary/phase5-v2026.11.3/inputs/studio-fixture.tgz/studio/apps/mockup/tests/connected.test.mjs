import {missionColumn} from '../src/mission-board.js';
import test from "node:test";
import assert from "node:assert/strict";
import {
  initialState,
  transition,
  restoreState,
} from "../src/simulation/model.js";
import {
  currentMission as mission,
  proposedMissionPlan,
  createdMissionMarkdown,
} from "../src/simulation/missions.js";
import {
  emptyConnected,
  projectContext,
  validExecution,
} from "../src/simulation/connected.js";
const act = (s, type, extra = {}) => transition(s, { type, ...extra });
function initial() {
  return {
    ...initialState(),
    connectedEnabled: true,
    connected: emptyConnected(),
  };
}
function ready(s = initial()) {
  s = act(s, "MISSION_NEW");
  for (const [field, value] of Object.entries({
    title: "A useful first step",
    intent: "  Mi idea <literal> & original.  ",
  }))
    s = act(s, "MISSION_EDIT", { field, value });
  s = act(s, "MISSION_STEP", { stage: "shape" });
  for (const id of ["outcome", "scope", "evidence"])
    s = act(s, "MISSION_CONFIRM", { id, inline: true });
  return act(s, "MISSION_STEP", { stage: "review" });
}
function approved({ candidate = false, gate = false, state } = {}) {
  let s = ready(state);
  s = act(s, "CONNECTED_SOURCE");
  if (candidate) s = act(s, "CONNECTED_CANDIDATE");
  if (gate) s = act(s, "CONNECTED_GATE", { value: true });
  return act(s, "MISSION_APPROVE", { revision: mission(s).revision });
}
function reload(s) {
  const r = restoreState(JSON.stringify(s));
  assert.equal(r.notice, null);
  assert.deepEqual(r.state.missionDesk, s.missionDesk);
  return r.state;
}
function until(s, predicate) {
  let count = 0;
  while (!predicate(mission(s)) && count++ < 100)
    s = reload(act(s, "MISSION_ADVANCE"));
  assert.ok(predicate(mission(s)), "fixture reached desired state");
  return s;
}
test("ideas preserve literal words, continuation and MCP receipts are idempotent and project scoped", () => {
  let s = act(initial(), "CONNECTED_SAVE_IDEA", {
    text: " <img src=x> esto es mío ",
  });
  assert.equal(s.missionDesk.items.length, 0);
  assert.equal(projectContext(s).ideas[0].text, " <img src=x> esto es mío ");
  const id = projectContext(s).ideas[0].id;
  s = act(s, "CONNECTED_IDEA_DRAFT", { id });
  const first = mission(s).id;
  s = act(s, "CONNECTED_IDEA_DRAFT", { id });
  assert.equal(mission(s).id, first);
  s = act(s, "CONNECTED_MCP");
  const receipt = mission(s).id;
  s = act(s, "CONNECTED_MCP");
  assert.equal(mission(s).id, receipt);
  assert.equal(mission(s).approved, null);
  assert.equal(mission(s).execution, undefined);
  s = act(s, "ENTER_FLOOR", { id: "growth" });
  s = act(s, "CONNECTED_MCP");
  assert.notEqual(mission(s).id, receipt);
  assert.equal(s.missionDesk.items.length, 3);
  reload(s);
});
test("approval is exact, coordinates immediately and uses the actual authored plan", () => {
  let s = ready();
  const revision = mission(s).revision;
  s = act(s, "CONNECTED_GATE", { value: true });
  s = act(s, "MISSION_APPROVE", { revision });
  assert.equal(mission(s).status, "draft");
  const plan = proposedMissionPlan(s);
  s = act(s, "MISSION_APPROVE", { revision: mission(s).revision });
  assert.equal(mission(s).execution.state, "running");
  assert.equal(mission(s).status, "active");
  assert.equal(mission(s).execution.tasks.length, plan.length);
  assert.deepEqual(mission(s).approved.plan, plan);
  assert.ok(validExecution(mission(s)));
  reload(s);
  assert.equal(act(s, "MISSION_START"), s);
  assert.equal(act(s, "MISSION_REVISE"), s);
});
test("source/candidate updates do not rewrite approvals; unavailable references block progress", () => {
  let s = approved({ candidate: true });
  const exact = structuredClone(mission(s));
  for (const type of [
    "CONNECTED_SOURCE_UPDATE",
    "CONNECTED_CANDIDATE_UPDATE",
    "CONNECTED_SOURCE",
    "CONNECTED_CANDIDATE",
  ])
    s = act(s, type);
  assert.deepEqual(mission(s), exact);
  s = act(s, "CONNECTED_SOURCE_TOGGLE");
  s = act(s, "MISSION_ADVANCE");
  assert.deepEqual(mission(s), exact);
  assert.match(s.connected.notice, /Restore/);
  reload(s);
});
test("partial adoption and partner feedback need same-session delivery and exact renewed review", () => {
  let s = approved({ candidate: true });
  s = until(s, (m) => m.execution.finding?.state === "open");
  const t = mission(s).execution.tasks.find((t) => t.state === "revision"),
    identity = [t.id, t.session],
    rev = t.evidence.length;
  s = act(s, "CONNECTED_PUBLISH", { task: t.id, revision: rev });
  assert.equal(
    mission(s).execution.tasks.find((n) => n.id === t.id).state,
    "revision",
  );
  s = act(s, "CONNECTED_FEEDBACK", { text: "Include the keyboard checklist" });
  assert.equal(mission(s).execution.instruction.state, "received");
  s = act(s, "MISSION_ADVANCE");
  assert.equal(mission(s).execution.instruction.state, "applied");
  s = act(s, "MISSION_ADVANCE");
  let now = mission(s).execution.tasks.find((n) => n.id === t.id);
  assert.equal(now.evidence.length, rev + 1);
  assert.equal(now.evidence.at(-1).reviewed, false);
  s = act(s, "MISSION_ADVANCE");
  now = mission(s).execution.tasks.find((n) => n.id === t.id);
  assert.equal(now.evidence.at(-1).reviewed, true);
  assert.deepEqual([now.id, now.session], identity);
  s = until(s, (m) => m.execution.state === "closed");
  assert.ok(
    mission(s).execution.tasks.every(
      (t) => t.state === "verified" && !t.runActive,
    ),
  );
  assert.match(createdMissionMarkdown(s), /Exact approved references/);
});
test("explicit gate, hold, resume and cancellation preserve inspectable records", () => {
  let s = until(
    approved({ gate: true }),
    (m) => m.execution.state === "closing",
  );
  s = act(s, "CONNECTED_HOLD");
  s = act(s, "CONNECTED_ACK");
  assert.equal(mission(s).execution.state, "closing");
  s = act(s, "CONNECTED_RESUME");
  s = act(s, "CONNECTED_ACK");
  assert.equal(mission(s).execution.state, "closed");
  reload(s);
  s = approved();
  s = act(s, "CONNECTED_HOLD");
  const before = structuredClone(mission(s));
  s = act(s, "MISSION_ADVANCE");
  assert.deepEqual(mission(s), before);
  s = act(s, "CONNECTED_CANCEL");
  assert.equal(mission(s).execution.state, "cancelled");
  assert.equal(missionColumn(mission(s)), "completed");
  reload(s);
});
test("global agent serialization applies across floors and retains queued assignments", () => {
  let s = approved();
  s = until(s, (m) => m.execution.tasks.some((t) => t.runActive));
  const first = mission(s).id,
    owner = mission(s).execution.tasks.find((t) => t.runActive).owner;
  s = act(s, "ENTER_FLOOR", { id: "growth" });
  s = approved({ state: s });
  assert.equal(mission(s).execution.tasks[0].owner, owner);
  s = act(s, "MISSION_ADVANCE");
  assert.equal(mission(s).execution.tasks[0].state, "queued");
  assert.match(s.connected.notice, /occupied/);
  s = act(s, "ENTER_FLOOR", { id: "studio" });
  s = act(s, "MISSION_SELECT", { id: first });
  s = act(s, "MISSION_ADVANCE");
  s = act(s, "ENTER_FLOOR", { id: "growth" });
  s = act(s, "MISSION_ADVANCE");
  assert.equal(mission(s).execution.tasks[0].state, "working");
});
test("follow-up is independent, selected context is deliberate and learning remains proposed", () => {
  let s = until(
    approved({ candidate: true }),
    (m) => m.execution.state === "closed",
  );
  s = act(s, "CONNECTED_LEARNING");
  assert.equal(s.connected.learning[0].status, "proposed");
  const old = structuredClone(mission(s));
  s = act(s, "MISSION_FOLLOWUP", { source: false, candidate: true });
  assert.deepEqual(s.missionDesk.items[0], old);
  assert.equal(mission(s).source, null);
  assert.deepEqual(mission(s).candidate, old.candidate);
  assert.equal(mission(s).approved, null);
  assert.equal(mission(s).execution, undefined);
  reload(s);
});
test("unavailable states block decisions and metadata corruption preserves valid missions", () => {
  let s = approved();
  for (const value of ["denied", "loading", "offline"]) {
    const disabled = act(s, "CONNECTED_MODE", { value });
    for (const type of [
      "CONNECTED_MCP",
      "MISSION_ADVANCE",
      "MISSION_NEW",
      "CONNECTED_SOURCE_UPDATE",
    ])
      assert.deepEqual(act(disabled, type).missionDesk, disabled.missionDesk);
  }
  const broken = structuredClone(s);
  broken.connected.preferences.size = -1;
  const r = restoreState(JSON.stringify(broken));
  assert.match(r.notice, /reference controls/);
  assert.deepEqual(r.state.missionDesk, s.missionDesk);
});
test("corrupt task identity, premature closeout and forged review cannot survive reload", () => {
  const s = approved();
  for (const mutate of [
    (m) => (m.execution.tasks[0].session = "other-session"),
    (m) => {
      m.execution.state = "closed";
      m.status = "completed";
    },
    (m) => (m.execution.tasks[0].state = "verified"),
  ]) {
    const bad = structuredClone(s);
    mutate(mission(bad));
    assert.equal(validExecution(mission(bad)), false);
    assert.match(
      restoreState(JSON.stringify(bad)).notice,
      /could not be recovered/,
    );
  }
});
test("viewed older source and candidate remain explicitly selectable and feedback stays pinned", () => {
  let s = ready();
  s = act(s, "CONNECTED_SOURCE_UPDATE");
  s = act(s, "CONNECTED_CANDIDATE_UPDATE");
  s = act(s, "CONNECTED_SOURCE", { revision: 1 });
  s = act(s, "CONNECTED_CANDIDATE", { revision: 1 });
  s = act(s, "CONNECTED_LAB_NOTE", {
    revision: 1,
    text: "Keep this first step",
  });
  assert.equal(mission(s).source.revision, 1);
  assert.equal(mission(s).candidate.revision, 1);
  assert.equal(projectContext(s).labNotes[0].revision, 1);
  const m = structuredClone(mission(s));
  s = act(s, "CONNECTED_SOURCE", { revision: 3 });
  assert.deepEqual(mission(s), m);
  reload(s);
});

// Cross-surface regressions found by the roadmap audit.
test('closed work agrees across Desk, board, Review, Library and learning projections', async()=>{
 const {founderItems}=await import('../src/simulation/founder.js');
 const {acceptedWork,libraryEntries,reusableContext}=await import('../src/simulation/knowledge.js');
 const {floorWorkspaceRecords}=await import('../src/simulation/floor-workspaces.js');
 const {workCollection,artifactHTML}=await import('../src/work-results.js');
 let s=until(approved({candidate:true}),m=>m.execution.state==='closed');
 const m=mission(s);assert.equal(founderItems(s).find(i=>i.missionId===m.id).status,'history');
 assert.equal(missionColumn(m),'completed');assert.equal(acceptedWork(s)[0].id,m.id);
 assert.equal(floorWorkspaceRecords(s).results[0].label,'Closed by Emon');
 assert.match(workCollection(s,{},true),/Closed by Emon/);
 const t=m.execution.tasks.find(t=>t.owner==='tinus');
 assert.match(artifactHTML(m,t,t.evidence[0]),/A clear next-action card/);
 assert.doesNotMatch(artifactHTML(m,t,t.evidence[0]),/<li>An accessible first-step checklist/);
 assert.match(artifactHTML(m,t,t.evidence.at(-1)),/<li>An accessible first-step checklist/);
 s=act(s,'CONNECTED_LEARNING');assert.equal(libraryEntries(s)[0].review,'proposed');assert.equal(reusableContext(s).length,0);
 const {savedKnowledgeSurface}=await import('../src/knowledge-ui.js');
 assert.match(savedKnowledgeSurface(s,{},true),/Pending source-owner review/);
 assert.doesNotMatch(workCollection(s,{}),/Pending source-owner review/);
 const before=structuredClone(s.connected.learning);s=act(s,'KNOW_REVIEW',{id:libraryEntries(s)[0].id,review:'reviewed'});assert.deepEqual(s.connected.learning,before);reload(s);
});
test('admitted partners retain decision ownership and project context across reload',()=>{
 let s=ready();const original=structuredClone(mission(s));
 s=act(s,'CONNECTED_PARTNER',{value:'Alex'});s=act(s,'MISSION_APPROVE');assert.equal(mission(s).approved,null);
 s=act(s,'MISSION_EDIT',{field:'title',value:'Not mine'});assert.equal(mission(s).title,original.title);
 s=ready(s);assert.equal(mission(s).decisionOwner,'Alex');s=act(s,'MISSION_APPROVE');assert.equal(mission(s).approved.decisionOwner,'Alex');assert.equal(mission(s).events.find(e=>e.type==='mission_approved').actor,'Alex');
 s=act(s,'ENTER_FLOOR',{id:'client'});s=act(s,'MISSION_NEW');s=act(s,'CONNECTED_SOURCE');s=act(s,'CONNECTED_CANDIDATE');
 assert.equal(mission(s).source.repo,'client-fixture');assert.equal(mission(s).candidate.id,'client-handoff');reload(s);
 s=act(s,'ENTER_FLOOR',{id:'studio'});assert.equal(mission(s).approved.decisionOwner,'Alex');
});
test('source changes and selected design deltas remain pinned and removable only in draft',()=>{
 let s=ready();s=act(s,'CONNECTED_SOURCE',{id:'review-guide'});assert.equal(mission(s).source.id,'review-guide');
 s=act(s,'CONNECTED_REMOVE_SOURCE');assert.equal(mission(s).source,null);
 s=act(s,'CONNECTED_SOURCE');s=act(s,'CONNECTED_CANDIDATE',{id:'review-desk',deltas:['decision']});
 assert.deepEqual(mission(s).candidate.deltas.map(d=>d.id),['decision']);
 s=act(s,'MISSION_APPROVE');const approvedPaper=structuredClone(mission(s).approved);
 s=act(s,'CONNECTED_SOURCE_UPDATE');s=act(s,'CONNECTED_REMOVE_SOURCE');assert.deepEqual(mission(s).approved,approvedPaper);assert.ok(mission(s).source);
 s=until(s,m=>m.execution.state==='closed');assert.ok(mission(s).execution.tasks.every(t=>t.evidence.every(e=>e.adoption==='complete')));reload(s);
});
test('clarification preserves work, correction retains sessions, scope change creates fresh unapproved work',()=>{
 let s=approved();const previous=structuredClone(mission(s));
 s=act(s,'CONNECTED_CLARIFY',{text:'  What does <done> mean?  '});assert.deepEqual(mission(s).execution.tasks,previous.execution.tasks);assert.equal(mission(s).execution.conversation[0].text,'  What does <done> mean?  ');
 s=act(s,'CONNECTED_FEEDBACK',{text:'Check the first step'});assert.deepEqual(mission(s).execution.tasks.map(t=>t.session),previous.execution.tasks.map(t=>t.session));
 const before=structuredClone(mission(s));s=act(s,'CONNECTED_SCOPE',{text:'Add a new external workflow'});
 assert.deepEqual(s.missionDesk.items[0],before);assert.equal(mission(s).approved,null);assert.equal(mission(s).execution,undefined);assert.equal(mission(s).parentId,previous.id);reload(s);
});
test('MCP update conflict preserves local edits and ordinary approval is never imported',()=>{
 let s=act(initial(),'CONNECTED_MCP');const id=mission(s).id;
 s=act(s,'CONNECTED_MCP_UPDATE');s=act(s,'CONNECTED_MCP_APPLY');assert.equal(mission(s).importContext.importedRevision,2);
 s=act(s,'MISSION_EDIT',{field:'intent',value:'My local change'});s=act(s,'CONNECTED_MCP_UPDATE');s=act(s,'CONNECTED_MCP_APPLY');
 assert.equal(mission(s).content.intent,'My local change');assert.equal(mission(s).importContext.status,'Conflict · local paper changed');
 s=act(s,'CONNECTED_MCP_FORK');assert.equal(mission(s).parentId,id);assert.equal(mission(s).approved,null);
 s=act(s,'CONNECTED_MCP');assert.equal(mission(s).id,id);assert.equal(s.missionDesk.items.length,2);reload(s);
});

test('Grilling saves optional thoughts and starts one unapproved paper with literal intent',()=>{
 const literal='  A clearer <handoff> & one owner.\nKeep these words.  ';
 let s=act(initial(),'CONNECTED_SAVE_IDEA',{text:literal});
 assert.equal(s.missionDesk.items.length,0);
 const id=projectContext(s).ideas[0].id;
 s=act(s,'CONNECTED_SAVE_IDEA',{id,text:literal,start:true});
 const draft=mission(s);
 assert.equal(draft.content.intent,literal);
 assert.equal(draft.rawThought,literal);
 assert.equal(draft.stage,'shape');
 assert.equal(draft.status,'draft');
 assert.ok(!draft.approved&&!draft.execution);
 assert.equal(projectContext(s).ideas.length,1);
 assert.equal(projectContext(s).ideas[0].missionId,draft.id);
 s=act(s,'CONNECTED_IDEA_DRAFT',{id});
 assert.equal(s.missionDesk.items.length,1);
 assert.equal(mission(s).id,draft.id);
 s=act(s,'ENTER_FLOOR',{id:'client'});
 assert.equal(projectContext(s).ideas.length,0);
 s=act(s,'CONNECTED_SAVE_IDEA',{text:'Another project',start:true});
 assert.notEqual(mission(s).id,draft.id);
 assert.equal(mission(s).floorId,'client');
});

test('Grilling cannot create a draft from whitespace or an offline thought',()=>{
 let s=initial();
 s=act(s,'CONNECTED_SAVE_IDEA',{text:'  ',start:true});
 assert.equal(s.missionDesk.items.length,0);
 s=act(s,'CONNECTED_MODE',{value:'offline'});
 s=act(s,'CONNECTED_SAVE_IDEA',{text:'Not authorized offline',start:true});
 assert.equal(s.missionDesk.items.length,0);
 assert.equal(projectContext(s).ideas.length,0);
});
