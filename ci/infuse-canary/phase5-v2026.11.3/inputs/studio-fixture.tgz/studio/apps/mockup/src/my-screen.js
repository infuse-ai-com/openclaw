import { pageHeader, escapeHtml as esc } from '@studio/ui/workspace';
export const DESKTOP_TOOLS = ['Codex', 'Claude Code', 'Terminal'];
export const DESKTOP_FOLDERS = ['Core', 'Finaxis', 'Hauscraft'];
export const newDesktopSession = () => ({status:'disconnected', tool:'Codex', folder:'Core', expanded:false, attempt:0});

// Preview state belongs to a partner, never a project or mission record.
export function desktopTransition(session, event) {
  switch(event.type) {
    case 'connect': return {...session,status:'connecting',attempt:session.attempt+1};
    case 'ready': return session.status==='connecting' && event.attempt===session.attempt ? {...session,status:'connected'} : session;
    case 'disconnect': return {...session,status:'disconnected',expanded:false,attempt:session.attempt+1};
    case 'interrupt': return {...session,status:'interrupted',expanded:false,attempt:session.attempt+1};
    case 'tool': return DESKTOP_TOOLS.includes(event.value) ? {...session,tool:event.value} : session;
    case 'folder': return DESKTOP_FOLDERS.includes(event.value) ? {...session,folder:event.value} : session;
    case 'expand': return session.status==='connected' ? {...session,expanded:!session.expanded} : session;
    default: return session;
  }
}
export function createDesktopController({getOwner, isVisible, render, schedule=setTimeout}) {
  const sessions=new Map();let generation=0;
  function view(owner=getOwner()) {if(!sessions.has(owner))sessions.set(owner,newDesktopSession());return sessions.get(owner);}
  function update(owner,event) {sessions.set(owner,desktopTransition(view(owner),event));if(getOwner()===owner&&isVisible())render();}
  return {view, reset(){sessions.clear();generation++;}, act(type,value){
    const owner=getOwner();update(owner,{type,value});
    if(type==='connect'){
      const attempt=view(owner).attempt, currentGeneration=generation;
      schedule(()=>{const current=sessions.get(owner);if(generation===currentGeneration&&current?.status==='connecting'&&current.attempt===attempt)update(owner,{type:'ready',attempt});},650);
    }
  }};
}
const control=(label,action,extra='',kind='secondary')=>`<button class="${kind}" data-desktop-action="${action}" ${extra}>${label}</button>`;
function toolPreview(session,owner) {
  const path=`~/Code/${session.folder}`;
  const terminal=session.tool==='Terminal';
  const content=terminal?`<span class="terminal-muted">${esc(owner.toLowerCase())}@my-linux</span> <span class="terminal-path">${path}</span>\n$ ls\nREADME.md  docs/  src/\n\n<span class="terminal-muted">Your repositories and tools share this desktop.</span>\n$ ▌`:`<span class="terminal-muted">${path}</span>\n$ ${session.tool==='Codex'?'codex':'claude'}\n\n<strong>${session.tool}</strong>\nYour coding workspace is open.\n\n<span class="terminal-muted">Example task</span>\nRead the project docs and help me plan the next change.\n\n<span class="terminal-muted">Working directory</span>\n${path}`;
  return `<div class="desktop-terminal" role="region" aria-label="${session.tool} preview"><p class="desktop-terminal-label">${session.tool}<span>Read-only preview</span></p><pre>${content}</pre>${terminal?'':'<div class="desktop-prompt"><span>›</span><span>Your next task starts here</span><kbd>Preview</kbd></div>'}<p class="desktop-terminal-note">No commands or model sessions run in this preview. Sign-in and live coding will happen inside your Linux desktop.</p></div>`;
}
export function desktopSurface(owner,session,icons,{embedded=false}={}) {
  const connected=session.status==='connected', connecting=session.status==='connecting', interrupted=session.status==='interrupted';
  const status={connected:'Connected · demo',connecting:'Connecting · demo',disconnected:'Disconnected',interrupted:'Connection interrupted'}[session.status];
  return `<div class="my-screen ${session.expanded?'my-screen--expanded':''}">
    ${embedded?'':pageHeader({title:'My screen',description:'Your personal Linux workspace, across every project.',actionsHtml:'<span class="desktop-demo-badge">Interactive mockup</span>'})}
    <div class="my-screen-body"><section class="desktop-frame" aria-label="Personal Linux desktop">
      <header class="desktop-toolbar"><div class="desktop-identity">${icons.desktop}<div><strong>${esc(owner)}’s Linux</strong><span>Personal workspace · VNC</span></div></div><div class="desktop-session-controls"><span class="desktop-status" role="status" data-status="${session.status}"><i aria-hidden="true"></i>${status}</span>${connected?`${embedded?'':control(session.expanded?'Exit focus':'Focus desktop','expand',`aria-pressed="${session.expanded}"`)}${control('Disconnect','disconnect')}`:connecting?control('Cancel','disconnect'):control(interrupted?'Reconnect':'Connect','connect','','primary')}</div></header>
      ${connected?`<div class="linux-desktop"><div class="linux-topbar"><span>Linux workspace</span><span>Desktop preview · ${esc(owner)}</span></div><div class="linux-workspace"><aside class="desktop-files" aria-label="Desktop repositories"><p>Code</p>${DESKTOP_FOLDERS.map(folder=>`<button data-desktop-action="folder" data-desktop-value="${folder}" aria-pressed="${session.folder===folder}">${icons.folder}<span>${folder}</span></button>`).join('')}<small>Desktop folders.<br>Independent of Studio’s project selector.</small></aside><div class="desktop-app"><nav aria-label="Desktop applications">${DESKTOP_TOOLS.map(tool=>control(tool,'tool',`data-desktop-value="${tool}" aria-pressed="${session.tool===tool}"`)).join('')}</nav>${toolPreview(session,owner)}</div></div></div>`:`<div class="desktop-connection" aria-busy="${connecting}"><div class="desktop-connection-icon">${icons.desktop}</div><h2>${connecting?'Opening your workspace…':interrupted?'Your connection was interrupted':'Your Linux workspace'}</h2><p>${connecting?'Preparing the simulated desktop view.':interrupted?'Reconnect to return to your tools and selected folder.':'Open your own desktop with Codex, Claude Code and a terminal. Your workspace stays with you as you move between projects.'}</p>${!connecting?control(interrupted?'Reconnect to desktop':'Connect to desktop','connect','','primary'):''}<span class="desktop-connection-hint">VNC preview · no remote computer is connected</span></div>`}
      <footer class="desktop-frame-note">${icons.help}<span>${connected?'Simulated desktop. App and folder switches are interactive; terminal content is a read-only example.':'This prototype demonstrates the connection experience. It does not provision a computer or start a VNC session.'}</span></footer>
    </section><div class="desktop-details"><div><span>Yours across projects</span><p>One personal Linux workspace for your work in Studio.</p></div><div><span>Your coding tools</span><p>Codex, Claude Code and a terminal in the same environment.</p></div><div><span>Disconnect, then return</span><p>The intended live experience leaves desktop apps running when you close the viewer.</p></div></div><details class="desktop-preview-controls"><summary>Preview connection states</summary><p>Exercise a lost connection in this local mockup.</p>${control('Simulate connection loss','interrupt',connected?'':'disabled')}</details></div></div>`;
}
