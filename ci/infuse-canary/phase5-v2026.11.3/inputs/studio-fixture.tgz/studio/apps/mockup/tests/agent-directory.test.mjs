import {agentAssignmentEvidence,agentTelemetryContent,agentDemo,agentDemoWork,agentOperationalState} from '../src/agent-evidence.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,transition} from '../src/simulation/model.js';
import {agentRoster,skillsWorkspace} from '../src/agent-directory.js';
import {peopleWorkspace} from '../src/knowledge-ui.js';
import {switchWorkspaceProject} from '../src/workspace-navigation.js';
import {workspaceSidebar} from '../src/workspace-sidebar.js';

test('Skills guide search composes query, agent, purpose and app filters',()=>{
 const s=initialState(),before=structuredClone(s);
 const guideIds=html=>[...html.matchAll(/data-company-skill="([^"]+)"/g)].map(match=>match[1]);
 const filters={query:'  SOURCE  ',agent:'emon',category:'understand',app:'knowledge-base'};
 assert.deepEqual(guideIds(skillsWorkspace(s,filters)),['knowledge-retrieval','source-synthesis']);
 for(const override of [{query:'nothing-matches-this'},{agent:'tinus'},{category:'build'},{app:'workbench'}]){
  const html=skillsWorkspace(s,{...filters,...override});
  assert.deepEqual(guideIds(html),[],JSON.stringify(override));
  assert.match(html,/No matching guides/);
 }
 const unfiltered=guideIds(skillsWorkspace(s,{}));
 assert.ok(unfiltered.includes('spec-driven-delivery'));
 assert.deepEqual(guideIds(skillsWorkspace(s,{query:'   '})),unfiltered);
 assert.deepEqual(s,before);
});
test('Skills navigation is global and project switches do not alter mission state',()=>{
 let s=transition(initialState(),{type:'OPEN',surface:'skills'});
 assert.equal(s.surface,'skills');
 const before=structuredClone(s.missionDesk),next=switchWorkspaceProject(s,'client');
 assert.equal(next.surface,'skills');assert.deepEqual(next.missionDesk,before);
 const html=workspaceSidebar(s,{}),company=html.split('Project navigation:')[0];
 assert.ok(company.indexOf('aria-label="Agents"')<company.indexOf('aria-label="Skills"'));
 assert.ok(company.includes('data-action="skills"'));
});
test('shared guest roster and profile preserve literal text and capability controls',()=>{
 let s=transition(initialState(),{type:'KNOW_GUEST_SAVE',name:'Mira <test>',role:'Evidence expert',traits:'Question <assumptions>',brief:'Research',sources:'Notes',skills:['expert-review'],model:'GPT-6 Sol',reasoning:'Medium'});
 const before=structuredClone(s),roster=agentRoster(s);
 assert.equal(roster.some(p=>p.id==='fito'),false);
 assert.deepEqual(agentRoster({...s,floor:'client'}),roster);
 const guest=roster.find(p=>p.guest);
 assert.ok(guest);
 const html=peopleWorkspace({...s,detail:guest.id},{},{});
 assert.match(html,/Question &lt;assumptions&gt;/);assert.doesNotMatch(html,/<assumptions>/);
 assert.match(html,/data-agent-skill="expert-review"/);
 assert.match(skillsWorkspace(s,{query:'<script>'}),/value="&lt;script&gt;"/);
 assert.deepEqual(s,before);
});

test('prototype assignment evidence distinguishes proposals, holds and runtime receipts',()=>{
 const assignment={missionId:'mission-1',projectId:'studio'};
 const mission={id:'mission-1',floorId:'studio',status:'draft',approved:null};
 const state={missionDesk:{items:[mission]}};
 assert.equal(agentAssignmentEvidence(state,assignment).role,'Proposed team');
 assert.match(agentAssignmentEvidence(state,assignment).next,/before approval/);
 mission.status='approved';mission.startup='hold';mission.approved={revision:3};
 const evidence=agentAssignmentEvidence(state,assignment);
 assert.equal(evidence.role,'Approved team');assert.equal(evidence.held,true);
 assert.match(evidence.next,/hold/);assert.match(evidence.receipt,/revision 3/);
 assert.match(evidence.receipt,/No Gateway execution receipt/);
});
test('illustrative agent fixtures are populated, internally consistent and isolated from mission state',()=>{
 const state=initialState(),before=structuredClone(state),roster=agentRoster(state);
 for(const person of roster){
  const demo=agentDemo(person),html=agentTelemetryContent(state,person);
  assert.equal(demo.daily.reduce((sum,value)=>sum+value,0),demo.total);
  assert.equal(demo.daily.at(-1),demo.today);
  assert.equal(demo.work.filter(job=>job.role.startsWith('Assigned')).length,2);
  for(const title of ['Runtime health','Model policy','Token usage','Collector activity','Scheduled tasks','Sources &amp; freshness'])assert.ok(html.includes(title));
  assert.match(html,/Illustrative snapshot/);assert.match(html,/23 Oct 2026/);
  const op=agentOperationalState(person);
  assert.match(html,new RegExp(op.label));
  if(!op.hasObservation)assert.match(html,/No recorded usage/);
  if(!op.current)assert.doesNotMatch(html,/Configuration and runtime agree/);
  const work=agentDemoWork(person);assert.match(work,/agent-mission/);assert.doesNotMatch(work,/data-mission-select/);
 }
 assert.notEqual(agentDemo(roster[0]).title,agentDemo(roster[1]).title);
 assert.notEqual(agentDemo(roster[0]).total,agentDemo(roster[1]).total);
 const guest={id:'guest-<test>',role:'Review <scripts>'};
 assert.match(agentTelemetryContent(state,guest),/Review &lt;scripts&gt;/);
 assert.doesNotMatch(agentTelemetryContent(state,guest),/<scripts>|guest-<test>/);
 assert.deepEqual(state,before);
});

test('operational fixtures distinguish current failures, retained evidence and unknown usage',()=>{
 const state=initialState(),before=structuredClone(state);
 const ops=agentRoster(state).map(person=>agentOperationalState(person));
 assert.equal(ops.filter(op=>op.attention).length,5);
 assert.equal(agentOperationalState({id:'tinus'}).runtime,'Degraded');
 assert.equal(agentOperationalState({id:'kapiteky'}).observedModel,'GPT-6 Sol');
 for(const id of ['stewie','satwa']){const op=agentOperationalState({id});assert.equal(op.current,false);assert.equal(op.hasObservation,true);assert.equal(op.runtime,'Unknown');}
 assert.equal(agentOperationalState({id:'ramiro'}).hasObservation,false);
 assert.deepEqual(state,before);
});
