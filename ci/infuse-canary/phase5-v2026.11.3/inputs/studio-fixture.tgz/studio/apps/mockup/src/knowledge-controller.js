import { libraryEntries } from './simulation/knowledge.js';
import { companyPeople, residentFor } from './simulation/company.js';
export function createKnowledgeController({getState,dispatch,render,open,focus,openKnowledge}){
 const views={};const view=()=>views[getState().floor]??=({tab:'sources',editor:null,reuse:null,capture:null,learning:'',error:'',expert:{editor:null,error:''}});
 const reset=()=>{for(const key of Object.keys(views))delete views[key];};
 const close=()=>{Object.assign(view(),{editor:null,reuse:null,capture:null,error:''});render();};
 const reuse=(missionId=null,sources=[],person=null)=>{Object.assign(view(),{tab:'reuse',editor:null,capture:null,error:'',reuse:{missionId,person,title:'',intent:'',sources,plan:!!missionId,team:!!missionId}});openKnowledge(view().tab);};
 document.addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b||b.disabled)return;const v=view(),s=getState(),d=b.dataset;
  if(d.connected==='kb-screen' || ['knowledge-saved','knowledge-learning'].includes(d.action)){Object.assign(v,{editor:null,reuse:null,capture:null,error:''});render();focus();}
  if(d.action==='knowledge-new'){v.editor={title:'',body:'',reference:''};v.error='';render();document.getElementById('knowledge-title')?.focus();}
  if(d.action==='knowledge-cancel')close();
  if(d.knowledgeEdit){v.editor=structuredClone(libraryEntries(s).find(x=>x.id===d.knowledgeEdit));v.error='';render();document.getElementById('knowledge-title')?.focus();}
  if(d.knowledgeReview)dispatch({type:'KNOW_REVIEW',id:d.knowledgeReview,review:d.reviewValue});
  if(d.knowledgeCapture){v.capture=d.knowledgeCapture;v.learning='';v.error='';v.tab='learning';openKnowledge(view().tab);document.getElementById('knowledge-learning')?.focus();}
  if(d.knowledgeReuse)reuse(d.knowledgeReuse==='new'?null:d.knowledgeReuse);
  if(d.knowledgeUse)reuse(null,[d.knowledgeUse]);
  if(d.expertMission)reuse(null,[],d.expertMission);
  if(d.personDetail){v.expert.editor=null;v.expert.error='';}
  if(d.action==='expert-new'||d.expertEdit){const p=companyPeople(s).find(p=>p.id===d.expertEdit&&p.guest),c=p&&(residentFor(s,p.id)||s.knowledge?.expertConfigs?.[s.floor]?.[p.id]);v.expert.editor=p?{...structuredClone(p),model:c?.llm||'GPT-6 Sol',reasoning:c?.reasoning||'Medium',skills:[...(c?.capabilities||p.skills)]}:{name:'',role:'',traits:'',brief:'',sources:'',skills:['expert-advice','expert-review'],model:'GPT-6 Sol',reasoning:'Medium'};v.expert.error='';render();document.getElementById('expert-name')?.focus();}
  if(d.action==='expert-cancel'){v.expert.editor=null;v.expert.error='';render();}
  if(d.action==='confirm-reset')reset();
 });
 document.addEventListener('input',e=>{
  const v=view(),id=e.target.id;
  const sourceMap={'knowledge-title':'title','knowledge-body':'body','knowledge-reference':'reference'};
  const reuseMap={'reuse-title':'title','reuse-intent':'intent'};
  if(v.editor&&sourceMap[id])v.editor[sourceMap[id]]=e.target.value;
  if(id==='knowledge-learning')v.learning=e.target.value;
  if(v.reuse&&reuseMap[id])v.reuse[reuseMap[id]]=e.target.value;
  if(v.reuse&&['reuse-plan','reuse-team'].includes(id))v.reuse[id.slice(6)]=e.target.checked;
  if(v.reuse&&e.target.dataset.reuseSource){const key=e.target.dataset.reuseSource;v.reuse.sources=e.target.checked?[...new Set([...v.reuse.sources,key])]:v.reuse.sources.filter(x=>x!==key);}
  if(v.expert.editor&&id.startsWith('expert-')){const field=id.slice(7);if(['name','role','traits','brief','sources','model','reasoning'].includes(field))v.expert.editor[field]=e.target.value;}
  if(v.expert.editor&&e.target.dataset.expertSkill){const key=e.target.dataset.expertSkill;v.expert.editor.skills=e.target.checked?[...new Set([...v.expert.editor.skills,key])]:v.expert.editor.skills.filter(x=>x!==key);}
  if(e.target.dataset.expertLink)dispatch({type:'KNOW_EXPERT_LINK',person:e.target.dataset.expertPerson,id:e.target.dataset.expertLink});
 });
 document.addEventListener('submit',e=>{
  const v=view(),id=e.target.id;let event;
  if(id==='knowledge-source-form')event={type:'KNOW_SOURCE_SAVE',...v.editor};
  if(id==='knowledge-learning-form')event={type:'KNOW_LEARNING',id:v.capture,body:v.learning};
  if(id==='knowledge-reuse-form')event={type:'KNOW_REUSE',...v.reuse};
  if(id==='expert-profile-form')event={type:'KNOW_GUEST_SAVE',...v.expert.editor};
  if(!event)return;e.preventDefault();const before=getState();dispatch(event);
  if(getState()===before){const error=id==='expert-profile-form'?'Complete the name, specialty, working style and at least one capability. Use a distinct name; this floor has room for eight agents.':id==='knowledge-reuse-form'?'Describe the next mission and choose a current accepted template. Selected context must fit within 8,000 characters; choose fewer sources if needed.':'Add a title and useful content, or confirm that the origin result is still accepted.';if(id==='expert-profile-form')v.expert.error=error;else v.error=error;render();return;}
  if(id==='expert-profile-form'){v.expert.editor=null;v.expert.error='';}else {if(v.capture)v.tab='learning';Object.assign(v,{editor:null,reuse:null,capture:null,error:''});}
  render();focus();
 });
 return {view,reset};
}
