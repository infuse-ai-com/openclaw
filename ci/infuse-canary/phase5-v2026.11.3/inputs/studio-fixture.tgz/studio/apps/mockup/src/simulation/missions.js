import {projectContext, validExecution} from './connected.js';
import { createDelivery, deliveryTransition, validDelivery } from './deliveries.js';
import { englishEvent } from './mission-copy.js';
import { emptyPlanning, ensurePlanning, planIssues, planningTransition, validPlanning } from './mission-planning.js';
import { emptyShaping, initialMissionProposal, feedbackChanges, feedbackCurrent, FEEDBACK_ANCHORS, FEEDBACK_EXAMPLES } from '../scenarios/mission-companion.js';
import { PEOPLE, DEFAULT_MODEL, MODEL_PRESETS, REASONING_LEVELS } from '../scenarios/catalog.js';
import { allFloors, companyPeople, projectFloor, floorPeople, capability } from './company.js';

// Authoring and simulation only. These records are never SQL lifecycle receipts.
export const MISSION_SECTIONS = [
  {id:'intent',title:'Intent',question:'What do you want to achieve in this project?',required:true},
  {id:'outcome',title:'Outcome',question:'What needs to exist at the end that does not exist today?',required:true},
  {id:'scope',title:'Scope and boundaries',question:'How far will this mission go, and what will we leave for later?',required:true},
  {id:'references',title:'Context and sources',question:'What existing material or decisions should the team respect?'},
  {id:'decisions',title:'Decisions',question:'Which decision do you want to make before the team moves forward?'},
  {id:'evidence',title:'Acceptance',question:'What will you review to decide whether the result is good enough?',required:true}
];
export const MISSION_STAGES = ['idea','shape','squad','review','activity'];
export const MISSION_LABELS = {draft:'Draft',approved:'Approved',active:'Simulation in progress',completed:'Simulation complete'};
export const emptyMissionDesk = () => ({version:1,items:[],priorities:{},selected:{studio:'studio-001'}});
export const createdMissions = (s,floor=s.floor) => (s.missionDesk?.items||[]).filter(m=>m.floorId===floor);
export const currentMission = (s,floor=s.floor) => createdMissions(s,floor).find(m=>m.id===s.missionDesk?.selected[floor]) || null;
export const missionPerson = (s,id) => companyPeople(s).find(p=>p.id===id);
export const isMissionEditable = m => m.status==='draft';
export const missionMissing = m => MISSION_SECTIONS.filter(x=>x.required&&(!m.content[x.id].trim()||!m.confirmed.includes(x.id)));
export const missionReady = m => Boolean(m.title.trim()&&!missionMissing(m).length&&!m.shaping?.pending&&!planIssues(m).length&&m.squad.includes('emon')&&m.squad.every(id=>m.config[id]?.skills.length));
export const missionPendingLabel = m => {const n=missionMissing(m).length;return n===1?'1 essential decision pending':`${n} essential decisions pending`;};
export const missionStage = m => m.status==='draft'?m.stage:'activity';
const own=(o,k)=>Object.hasOwn(o,k);
const validText=(v,max=8000)=>typeof v==='string'&&v.length<=max;
const fieldIds=[...MISSION_SECTIONS.map(x=>x.id),'nonGoals'];

// Local demo suggestion: shorten the owner's first sentence, without an LLM call.
export function missionTitleProposal(m) {
  if(m.scenario==='studio-design')return 'Design mission creation';
  const first=m.content.intent.trim().split(/[.!?\n]/u).find(part=>part.trim())?.trim()||m.content.intent.trim();
  const words=first.replace(/\s+/gu,' ');
  if(words.length<=90)return words;
  const prefix=words.slice(0,87),space=prefix.lastIndexOf(' ');
  return `${prefix.slice(0,space>45?space:87)}…`;
}
export function proposedMissionPlan(s,m=currentMission(s)) {
  if(m.plan)return structuredClone(m.plan);
  if(m.planning?.steps)return structuredClone(m.planning.steps);
  return m.squad.map(id=>{const fullCoordinator=id==='emon'&&['shaping','coordination'].every(k=>m.config[id].skills.includes(k));return {owner:id,title:fullCoordinator?'Clarify the brief and coordinate delivery':m.config[id].skills.map(k=>capability(k)?.title).join(' · '),
    output:fullCoordinator?'A bounded brief with connected decisions and deliverables':m.config[id].skills.map(k=>capability(k)?.artifact).join(' · '),
    verification:fullCoordinator?'Check the outcome against approved criteria':m.config[id].skills.map(k=>capability(k)?.verification).join(' · ')};});
}
export function missionSuggestions(m,id) {
  const design=m.scenario==='studio-design';
  const options={
    intent:['Design and validate the mission creation flow in Studio.'],
    outcome:design?['A working flow from an idea to an approved mission, with its plan and team.','A prototype that helps Fito understand what the team will do and what approval means.']:['A reviewable proposal that addresses the brief and states its boundaries.','A prototype to test the result before connecting it to real systems.'],
    scope:design?['Create, shape, choose a team and approve a mission within a floor.','Try a simple mission from start to finish, including saving and resuming the draft.']:['A bounded outcome, a reviewable first version and one correction round.'],
    references:[],
    decisions:['I want to review the result before accepting it. Any scope expansion needs my decision.'],
    evidence:design?['I can create the mission, adjust the team and approve it without losing context. Reloading preserves my work.','I can explain the outcome, scope and contribution of each person before starting.']:['The result meets the agreed criteria, and each claim has evidence or an explicit limitation.']
  };return options[id]||[];
}
export function nextSimulationEvent(s,m=currentMission(s)) {
  if(m.status==='draft'||m.status==='completed'||m.status==='approved'&&m.startup==='hold')return null;
  const steps=[{type:'coordinator_prepared',title:'Emon receives the approved version',detail:'Context prepared in this simulation.',owner:'emon'},
    {type:'mission_activated',title:'Emon activates the mission',detail:'The plan can now become simulated assignments.',owner:'emon'},
    ...proposedMissionPlan(s,m).flatMap((p,index)=>[
      {type:'task_assigned',title:`Assignment to ${missionPerson(s,p.owner)?.name}`,detail:p.title,owner:p.owner,task:index},
      {type:'task_delivered',title:`Delivery from ${missionPerson(s,p.owner)?.name}`,detail:p.output,owner:p.owner,task:index},
      {type:'task_verified',title:'Emon reviews the delivery',detail:p.verification,owner:'emon',task:index}]),
    {type:'mission_completed',title:'Simulated flow completed',detail:'The example deliverables have been reviewed. No real work has been executed.',owner:'emon'}];
  return steps[m.cursor]||null;
}
function ensureProposal(m){
  if(m.status!=='draft'||!m.content.intent.trim())return;
  m.shaping??=emptyShaping();if(m.shaping.seeded)return;
  let filled=0;
  for(const [field,value] of Object.entries(initialMissionProposal(m))){
    if(!m.content[field].trim()&&!m.origins[field]&&!m.deferred.includes(field)){
      m.content[field]=value.slice(0,8000);m.origins[field]='suggestion';filled++;
    }
  }
  m.shaping.seeded=true;
  if(filled){m.revision++;m.summary='Emon has prepared a first draft. Edit it or give feedback before confirming.';}
}
function proposeFeedback(m,text,anchor,branch,repeat=false){
  const chat=m.shaping,changes=feedbackChanges(m,text,anchor,branch);
  if(!repeat)chat.messages.push({role:'user',text,anchor});
  const answer=changes.length?(branch?'I prepared an example adjustment. Review the changes before applying them.':'I saved your exact comment as a note in the selected section. This demo does not interpret free text; you can edit the proposal directly.'):'I saved the comment. There are no new changes to apply, or the section exceeds its limit; you can edit it directly.';
  chat.messages.push({role:'emon',text:answer,anchor});
  chat.pending=changes.length?{text,anchor,branch,changes}:null;
  chat.draft='';chat.branch=null;m.summary=answer;
}
function newMission(s,source) {
  const floor=allFloors(s).find(f=>f.id===s.floor),project=projectFloor(s);
  const people=project?companyPeople(s).filter(p=>project.residents.some(r=>r.personId===p.id)):floorPeople(s).filter(p=>p.id!=='fito');
  if(!people.some(p=>p.id==='emon'))people.unshift(PEOPLE.find(p=>p.id==='emon'));
  const id=`mission-${Math.max(0,...s.missionDesk.items.map(m=>Number(m.id.slice(8))))+1}`;
  const config=Object.fromEntries(people.map(p=>{const r=project?.residents.find(r=>r.personId===p.id)||s.knowledge?.expertConfigs?.[s.floor]?.[p.id];return [p.id,{skills:[...(r?.capabilities||p.skills)],model:r?.llm||DEFAULT_MODEL,reasoning:r?.reasoning||'Medium'}];}));
  const m={id,floorId:s.floor,title:'',scenario:'custom',status:'draft',stage:'idea',section:'outcome',revision:1,
    planning:emptyPlanning(),shaping:emptyShaping(),rawThought:null,content:Object.fromEntries(fieldIds.map(k=>[k,''])),origins:{},confirmed:[],deferred:[],
    candidates:people.map(p=>p.id),squad:['emon',...people.filter(p=>['stewie','tinus'].includes(p.id)).map(p=>p.id)],config,
    projectContext:{title:floor.title,description:floor.description},guestBriefs:Object.fromEntries(people.filter(p=>p.guest).map(p=>[p.id,{traits:p.traits,brief:p.brief,sources:p.sources}])),
    approved:null,approvals:[],events:[],cursor:0,startup:null,summary:'An idea is enough to get started.',createdAt:new Date().toISOString(),parentId:source?.id||null};
  if(source){m.title=`Follow-up · ${source.title}`.slice(0,160);m.content=structuredClone(source.content);m.config=structuredClone(source.config);m.candidates=[...source.candidates];m.squad=[...source.squad];m.guestBriefs=structuredClone(source.guestBriefs);m.scenario=source.scenario;m.planning=emptyPlanning();m.planning.steps=structuredClone(proposedMissionPlan(s,source)).map((p,i)=>({...p,id:p.id||`step-${i+1}`}));m.planning.notes=source.planning?.notes||'';m.summary='A new mission using the previous context. Confirm the brief again.';}
  if(s.connectedEnabled){m.source=structuredClone(projectContext(s).source);m.candidate=structuredClone(projectContext(s).candidate);m.humanGate=false;m.origin='Studio';m.decisionOwner=s.connected?.partner||'Fito';}
  s.missionDesk.items.push(m);s.missionDesk.selected[s.floor]=id;s.surface='mission-flow';s.peekPerson=null;s.detail=null;
  return m;
}
function edited(m,field) {
  m.revision++;m.deferred=m.deferred.filter(k=>k!==field);
  const dependencies={intent:['outcome','scope','evidence'],outcome:['scope','evidence'],scope:['evidence'],nonGoals:['scope','evidence']};
  const affected=[field,...(dependencies[field]||[])];m.confirmed=m.confirmed.filter(k=>!affected.includes(k));
  m.summary='Change saved. Review the sections that depended on this answer.';
}
export function missionTransition(state,event) {
  if(!event.type.startsWith('MISSION_'))return null;
  const s=structuredClone(state);s.missionDesk??=emptyMissionDesk();
  if(event.type==='MISSION_LIST'){s.surface='missions';s.peekPerson=null;s.detail=null;return s;}
  if(event.type==='MISSION_NEW'){newMission(s);return s;}
  if(event.type==='MISSION_PRIORITY'){
    if(!createdMissions(s).some(m=>m.id===event.id)||!['high','medium','low'].includes(event.priority))return state;
    s.missionDesk.priorities??={};s.missionDesk.priorities[event.id]=event.priority;return s;
  }
  if(event.type==='MISSION_SELECT'){
    const m=createdMissions(s).find(m=>m.id===event.id);if(!m)return state;
    s.missionDesk.selected[s.floor]=m.id;s.surface='mission-flow';s.peekPerson=null;if(m.stage==='shape')ensureProposal(m);if(['squad','review'].includes(m.stage))ensurePlanning(m);return s;
  }
  const m=currentMission(s);if(!m)return state;
  if(event.type==='MISSION_DELIVERY_OPEN'){if(m.status!=='completed')return state;m.delivery??=createDelivery(m);s.surface='delivery-review';s.peekPerson=null;return s;}
  if(event.type.startsWith('MISSION_DELIVERY_'))return deliveryTransition(m,event)?s:state;
  if(event.type==='MISSION_OPEN'){s.surface='mission-flow';s.peekPerson=null;if(m.stage==='shape')ensureProposal(m);if(['squad','review'].includes(m.stage))ensurePlanning(m);return s;}
  if(event.type==='MISSION_FOLLOWUP'){if(!['active','completed'].includes(m.status))return state;newMission(s,m);return s;}
  if(event.type==='MISSION_STEP'){
    if(!MISSION_STAGES.includes(event.stage))return state;
    if(event.stage==='idea'||event.stage==='shape'||event.stage==='squad'||event.stage==='review'){
      if(m.status!=='draft')return state;
      if(event.stage!=='idea'&&!m.content.intent.trim()){m.summary='First, write what you want to achieve.';return s;}
      if(event.stage!=='idea'&&m.stage==='idea'){
        if(m.rawThought===null)m.rawThought=m.content.intent;
        if(!m.confirmed.includes('intent')){m.confirmed.push('intent');m.revision++;}
        if(!m.title.trim()){
          m.title=missionTitleProposal(m);m.origins.title='suggestion';m.revision++;
          m.summary='Emon suggests an example name. You can refine or change it before continuing.';
        }
      }
    }
    if(m.status==='draft'&&event.stage==='activity')return state;
    m.stage=event.stage;if(event.stage!=='idea')ensureProposal(m);if(['squad','review'].includes(event.stage))ensurePlanning(m);s.surface='mission-flow';return s;
  }
  if(event.type.startsWith('MISSION_PLAN_')){
    if(!isMissionEditable(m))return state;
    ensurePlanning(m);return planningTransition(m,event)?s:state;
  }
  if(event.type.startsWith('MISSION_CHAT_')){
    if(!isMissionEditable(m))return state;
    m.shaping??=emptyShaping();const chat=m.shaping;
    if(event.type==='MISSION_CHAT_DRAFT'){
      if(!validText(event.text,4000))return state;
      chat.draft=event.text;chat.branch=null;return s;
    }
    if(event.type==='MISSION_CHAT_ANCHOR'){
      if(!FEEDBACK_ANCHORS.includes(event.anchor))return state;
      chat.anchor=event.anchor;return s;
    }
    if(event.type==='MISSION_CHAT_EXAMPLE'){
      const option=FEEDBACK_EXAMPLES.find(x=>x.id===event.id);if(!option||chat.pending)return state;
      chat.draft=option.text;chat.branch=option.id;chat.anchor='general';return s;
    }
    if(event.type==='MISSION_CHAT_SEND'){
      if(!chat.draft.trim()||chat.pending)return state;
      proposeFeedback(m,chat.draft,chat.anchor,chat.branch);return s;
    }
    if(event.type==='MISSION_CHAT_RETRY'){
      if(!chat.pending)return state;
      const {text,anchor,branch}=chat.pending;proposeFeedback(m,text,anchor,branch,true);return s;
    }
    if(event.type==='MISSION_CHAT_DISCARD'){
      if(!chat.pending)return state;
      chat.pending=null;chat.messages.push({role:'emon',text:'Proposal discarded. The mission content is unchanged; your comment stays in the conversation.',anchor:chat.anchor});return s;
    }
    if(event.type==='MISSION_CHAT_APPLY'){
      if(!chat.pending||!feedbackCurrent(m))return state;
      const pending=chat.pending;
      for(const change of pending.changes){m.content[change.field]=change.after;edited(m,change.field);m.origins[change.field]='suggestion';}
      chat.pending=null;m.summary='Changes applied. Review and confirm the affected sections.';
      chat.messages.push({role:'emon',text:m.summary,anchor:pending.anchor});return s;
    }
    return state;
  }
  if(event.type==='MISSION_SECTION'){
    if(!MISSION_SECTIONS.some(x=>x.id===event.id))return state;
    m.section=event.id;if(m.status==='draft'){m.stage='shape';ensureProposal(m);}return s;
  }
  if(event.type==='MISSION_EDIT'){
    if(!isMissionEditable(m)||!['title',...fieldIds].includes(event.field)||!validText(event.value,event.field==='title'?160:8000))return state;
    if(event.field==='title'){if(m.title===event.value)return state;m.title=event.value;m.origins.title='user';m.revision++;}
    else {if(m.content[event.field]===event.value)return state;m.content[event.field]=event.value;m.origins[event.field]='user';edited(m,event.field);}
    return s;
  }
  if(event.type==='MISSION_EXAMPLE'){
    if(!isMissionEditable(m))return state;
    m.scenario='studio-design';m.content.intent=missionSuggestions(m,'intent')[0];m.origins.intent='suggestion';edited(m,'intent');return s;
  }
  if(event.type==='MISSION_SUGGESTION'){
    const value=missionSuggestions(m,m.section)[event.index];if(!isMissionEditable(m)||!value)return state;
    m.content[m.section]=value;edited(m,m.section);m.origins[m.section]='suggestion';m.summary='Example proposal. You can edit it before confirming.';return s;
  }
  if(event.type==='MISSION_CONFIRM'){
    if(event.id){if(!MISSION_SECTIONS.some(x=>x.id===event.id))return state;m.section=event.id;}
    if(!isMissionEditable(m)||!m.content[m.section].trim())return state;
    if(!m.confirmed.includes(m.section)){m.confirmed.push(m.section);m.revision++;}
    m.deferred=m.deferred.filter(id=>id!==m.section);m.summary=`${MISSION_SECTIONS.find(x=>x.id===m.section).title} confirmed. Your words are preserved in the paper.`;
    if(event.inline)return s;
    const next=MISSION_SECTIONS.find(x=>!m.confirmed.includes(x.id)&&!m.deferred.includes(x.id));
    if(next)m.section=next.id;else {m.stage='squad';ensurePlanning(m);}return s;
  }
  if(event.type==='MISSION_DEFER'){
    if(event.id){if(!MISSION_SECTIONS.some(x=>x.id===event.id))return state;m.section=event.id;}
    const section=MISSION_SECTIONS.find(x=>x.id===m.section);if(!isMissionEditable(m)||section.required)return state;
    if(!m.deferred.includes(section.id))m.deferred.push(section.id);
    m.confirmed=m.confirmed.filter(id=>id!==section.id);m.revision++;m.summary='Decision deferred; it will remain visible in the paper.';
    if(event.inline)return s;
    const next=MISSION_SECTIONS.find(x=>!m.confirmed.includes(x.id)&&!m.deferred.includes(x.id));if(next)m.section=next.id;else {m.stage='squad';ensurePlanning(m);}return s;
  }
  if(event.type==='MISSION_SQUAD'){
    if(!isMissionEditable(m)||event.id==='emon'||!m.candidates.includes(event.id))return state;
    m.squad=m.squad.includes(event.id)?m.squad.filter(id=>id!==event.id):[...m.squad,event.id];
    if(m.planning?.steps)for(const step of m.planning.steps)if(!m.squad.includes(step.owner))step.owner='';
    m.revision++;m.summary='Team updated. Review the plan owners.';return s;
  }
  if(event.type==='MISSION_CONFIG'){
    if(!isMissionEditable(m)||!m.candidates.includes(event.person))return state;
    const c=m.config[event.person];
    if(event.key==='model'&&MODEL_PRESETS.includes(event.value))c.model=event.value;
    else if(event.key==='reasoning'&&REASONING_LEVELS.includes(event.value))c.reasoning=event.value;
    else if(event.key==='skill'&&missionPerson(s,event.person)?.skills.includes(event.value))c.skills=c.skills.includes(event.value)?c.skills.filter(k=>k!==event.value):[...c.skills,event.value];
    else return state;m.revision++;return s;
  }
  if(event.type==='MISSION_APPROVE'){
    if(!isMissionEditable(m)||!missionReady(m))return state;
    m.approved={revision:m.revision,title:m.title,rawThought:m.rawThought,content:structuredClone(m.content),confirmed:[...m.confirmed],deferred:[...m.deferred],squad:[...m.squad],config:structuredClone(m.config),guestBriefs:structuredClone(m.guestBriefs),plan:proposedMissionPlan(s,m),planNotes:m.planning?.notes||'',at:new Date().toISOString()};
    m.approvals.push(structuredClone(m.approved));m.status='approved';m.startup=event.start?'preparing':'hold';m.stage='activity';
    m.events.push({type:'mission_approved',title:event.start?'Mission approved · preparing to start':'Mission approved · on hold',detail:`Revision ${m.revision}. Paper and team preserved.`,owner:'fito'});m.summary=m.events.at(-1).title;return s;
  }
  if(event.type==='MISSION_REVISE'){
    if(m.status!=='approved'||m.cursor!==0)return state;
    m.status='draft';m.approved=null;m.startup=null;m.stage='shape';m.revision++;m.summary='Review the mission again before approving. The previous approval remains in the history.';return s;
  }
  if(event.type==='MISSION_START'){
    if(m.status!=='approved'||m.startup!=='hold')return state;
    m.startup='preparing';m.summary='Preparing to start the simulation.';return s;
  }
  if(event.type==='MISSION_ADVANCE'){
    if(!['approved','active'].includes(m.status))return state;
    const next=nextSimulationEvent(s,m);if(!next)return state;
    m.events.push(next);m.cursor++;m.summary=next.title;
    if(next.type==='coordinator_prepared')m.startup='prepared';
    if(next.type==='mission_activated')m.status='active';
    if(next.type==='mission_completed'){m.status='completed';m.delivery=createDelivery(m);}
    return s;
  }
  return state;
}

export function createdMissionMarkdown(s,m=currentMission(s)) {
  const plan=proposedMissionPlan(s,m);
  return [`# ${m.title||'Untitled mission'}`,'',`Project: ${m.projectContext.title}`,'> Local mockup. Proposals and execution are simulated; no agents are connected.','',
    ...(m.rawThought!==null?['## Initial idea · original words',m.rawThought,'']:[]),
    ...MISSION_SECTIONS.flatMap(x=>[`## ${x.title}`,m.content[x.id]||'No content yet.',`Status: ${m.confirmed.includes(x.id)?'Confirmed':m.deferred.includes(x.id)?'Deferred':'Awaiting confirmation'}.`,'']),
    '## Out of scope',m.content.nonGoals||'Not recorded.','','## Proposed plan',...plan.map(p=>`- ${missionPerson(s,p.owner)?.name}: ${p.title}\n  Deliverable: ${p.output}\n  Verification: ${p.verification}`),'','## Plan notes',m.planning?.notes||'No additional notes.','','## Team and configuration',
    ...m.squad.flatMap(id=>{const c=m.config[id],g=m.guestBriefs[id];return [`- ${missionPerson(s,id)?.name}: ${c.model} / ${c.reasoning}. ${c.skills.map(k=>capability(k)?.title).join(', ')}`,...(g?[`  Traits: ${g.traits}`,`  Supplied research, unverified: ${g.brief}`,`  Sources: ${g.sources}`]:[])];}),
    '',`Current revision: ${m.revision}. Approved: ${m.approved?.revision||'none'}.`,`Demo status: ${m.execution?.state||MISSION_LABELS[m.status]}.`,...(m.execution?['','## Exact approved references',JSON.stringify({source:m.approved.source,candidate:m.approved.candidate,humanGate:m.approved.humanGate},null,2),'','## Task execution and evidence',JSON.stringify(m.execution,null,2)]:[]),'','## Approval history',...m.approvals.map(a=>`- r${a.revision} · ${a.at} · ${a.title}`),'','## Shaping feedback',...(m.shaping?.messages||[]).map(x=>`- ${x.role==='user'?'Fito':'Emon (demo)'} · ${x.anchor}: ${x.text}`),...(m.shaping?.pending?['> A proposed change is waiting to be applied.']:[]),'','## Plan feedback',...(m.planning?.messages||[]).map(x=>`- ${x.role==='user'?'Fito':'Emon (demo)'}: ${x.text}`),...(m.planning?.pending?['> A plan adjustment is waiting to be applied.']:[]),'','## Simulated events',...m.events.map(englishEvent).map(e=>`- ${e.title}: ${e.detail}`),''].join('\n');
}

// Recover only this new collection; an invalid record must not erase the legacy
// mission, projects, guest profiles, or office preferences.
export function restoreMissionDesk(s) {
  if(!s.missionDesk){s.missionDesk=emptyMissionDesk();return null;}
  try {
    let deliveryRecovered=false;
    const d=s.missionDesk,floors=allFloors(s).map(f=>f.id),people=companyPeople(s);
    if(d.version!==1||!Array.isArray(d.items)||!d.selected||typeof d.selected!=='object'||Array.isArray(d.selected)||new Set(d.items.map(m=>m.id)).size!==d.items.length)throw Error();
    d.priorities??={};
    if(typeof d.priorities!=='object'||Array.isArray(d.priorities)||Object.entries(d.priorities).some(([id,value])=>!d.items.some(m=>m.id===id)||!['high','medium','low'].includes(value)))throw Error();
    for(const m of d.items){
      m.planning??=emptyPlanning();
      if(!validPlanning(m))throw Error();
      m.shaping??=emptyShaping();const chat=m.shaping;
      if(typeof chat.seeded!=='boolean'||!validText(chat.draft,4000)||!FEEDBACK_ANCHORS.includes(chat.anchor)||!(chat.branch===null||FEEDBACK_EXAMPLES.some(x=>x.id===chat.branch&&(x.text===chat.draft||x.legacyText===chat.draft)))||!Array.isArray(chat.messages)||chat.messages.some(x=>!['user','emon'].includes(x.role)||!validText(x.text,4000)||!FEEDBACK_ANCHORS.includes(x.anchor)))throw Error();
      if(chat.pending){const p=chat.pending;if(!validText(p.text,4000)||!FEEDBACK_ANCHORS.includes(p.anchor)||!(p.branch===null||FEEDBACK_EXAMPLES.some(x=>x.id===p.branch&&(x.text===p.text||x.legacyText===p.text)))||!Array.isArray(p.changes)||!p.changes.length||p.changes.some(x=>!fieldIds.includes(x.field)||!validText(x.before)||!validText(x.after)))throw Error();}

      if(!/^mission-[1-9]\d*$/.test(m.id)||!floors.includes(m.floorId)||!validText(m.title,160)||!['custom','studio-design','operations-investigation'].includes(m.scenario)||!own(MISSION_LABELS,m.status)||!MISSION_STAGES.includes(m.stage)||!MISSION_SECTIONS.some(x=>x.id===m.section)||!Number.isInteger(m.revision)||m.revision<1||!Number.isInteger(m.cursor)||m.cursor<0||!fieldIds.every(k=>validText(m.content?.[k]))||!validText(m.summary)||!validText(m.createdAt)||(m.rawThought!==null&&!validText(m.rawThought))||!m.projectContext||!validText(m.projectContext.title)||!validText(m.projectContext.description)||!m.guestBriefs||!m.origins)throw Error();
      for(const list of ['confirmed','deferred','candidates','squad'])if(!Array.isArray(m[list])||new Set(m[list]).size!==m[list].length)throw Error();
      if(m.confirmed.some(id=>!MISSION_SECTIONS.some(x=>x.id===id)||!m.content[id].trim())||m.deferred.some(id=>!MISSION_SECTIONS.some(x=>x.id===id&&!x.required)||m.confirmed.includes(id)))throw Error();
      if(!m.squad.includes('emon')||m.squad.some(id=>!m.candidates.includes(id))||m.candidates.some(id=>!people.some(p=>p.id===id&&id!=='fito')))throw Error();
      for(const id of m.candidates){const c=m.config?.[id],p=people.find(p=>p.id===id);if(!c||!Array.isArray(c.skills)||new Set(c.skills).size!==c.skills.length||c.skills.some(k=>!p.skills.includes(k))||!MODEL_PRESETS.includes(c.model)||!REASONING_LEVELS.includes(c.reasoning))throw Error();}
      for(const [id,g] of Object.entries(m.guestBriefs))if(!m.candidates.includes(id)||!['traits','brief','sources'].every(k=>validText(g[k])))throw Error();
      if(!Array.isArray(m.events)||m.events.some(e=>!validText(e.type,80)||!validText(e.title)||!validText(e.detail)||!people.some(p=>p.id===e.owner))||!Array.isArray(m.approvals))throw Error();
      if(m.status!=='draft'&&(!missionReady(m)||!m.approved||m.approved.revision!==m.revision||m.approved.title!==m.title||(m.approved.planNotes||'')!==(m.planning.notes||'')||m.approved.rawThought!==m.rawThought||JSON.stringify(m.approved.plan)!==JSON.stringify(proposedMissionPlan(s,m))||JSON.stringify(m.approved.guestBriefs)!==JSON.stringify(m.guestBriefs)||JSON.stringify(m.approved.confirmed)!==JSON.stringify(m.confirmed)||JSON.stringify(m.approved.deferred)!==JSON.stringify(m.deferred)||JSON.stringify(m.approved.content)!==JSON.stringify(m.content)||JSON.stringify(m.approved.config)!==JSON.stringify(m.config)||JSON.stringify(m.approved.squad)!==JSON.stringify(m.squad)))throw Error();
      if(m.execution){if(!validExecution(m)||JSON.stringify(m.approved.source)!==JSON.stringify(m.source)||JSON.stringify(m.approved.candidate)!==JSON.stringify(m.candidate)||m.approved.humanGate!==Boolean(m.humanGate))throw Error();continue;}
      if(m.cursor>3+proposedMissionPlan(s,m).length*3||!['hold','preparing','prepared',null].includes(m.startup))throw Error();
      const finalCursor=3+proposedMissionPlan(s,m).length*3;
      if(m.status==='draft'&&(m.approved||m.cursor!==0||m.startup!==null))throw Error();
      if(m.status==='approved'&&(m.cursor>1||m.startup===null||(m.cursor===1)!==(m.startup==='prepared')))throw Error();
      if(m.status==='active'&&(m.cursor<2||m.cursor>=finalCursor||m.startup!=='prepared'))throw Error();
      if(m.status==='completed'&&(m.cursor!==finalCursor||m.startup!=='prepared'))throw Error();
      const lastApproval=m.events.findLastIndex(e=>e.type==='mission_approved');
      if(m.status!=='draft'){
        if(lastApproval<0||m.events.length-lastApproval-1!==m.cursor||JSON.stringify(m.approvals.at(-1))!==JSON.stringify(m.approved))throw Error();
        for(let i=0;i<m.cursor;i++)if(JSON.stringify(englishEvent(m.events[lastApproval+1+i]))!==JSON.stringify(nextSimulationEvent(s,{...m,status:'active',cursor:i})))throw Error();
      }
      if(m.status==='completed'){if(m.delivery&&!validDelivery(m.delivery)){m.delivery=createDelivery(m);deliveryRecovered=true;}else m.delivery??=createDelivery(m);}
      for(const a of m.approvals)if((a.planNotes!==undefined&&!validText(a.planNotes))||!Number.isInteger(a.revision)||!validText(a.title,160)||!validText(a.at)||!fieldIds.every(k=>validText(a.content?.[k]))||(a.rawThought!==null&&!validText(a.rawThought))||!Array.isArray(a.plan)||a.plan.some(p=>!people.some(x=>x.id===p.owner)||!['title','output','verification'].every(k=>validText(p[k])))||!Array.isArray(a.squad)||!a.config||a.squad.some(id=>!people.some(p=>p.id===id)||!a.config[id]||!Array.isArray(a.config[id].skills)||a.config[id].skills.some(k=>!capability(k))||!MODEL_PRESETS.includes(a.config[id].model)||!REASONING_LEVELS.includes(a.config[id].reasoning)))throw Error();
    }
    for(const [floor,id] of Object.entries(d.selected))if(!floors.includes(floor)||!(floor==='studio'&&id==='studio-001')&&!d.items.some(m=>m.id===id&&m.floorId===floor))throw Error();
    return deliveryRecovered?'Saved delivery review evidence was invalid and has been reset. Your approved briefs and mission history are preserved.':null;
  }catch{s.missionDesk=emptyMissionDesk();return 'The new mission collection could not be recovered. Your Studio mission, projects and office are preserved.';}
}
