import { Button, PageHeader } from './ui.js';
import { icons } from '@studio/ui/icons';
import { InfuseSpinner, LoadingState } from './loading.js';
import type { RefObject } from 'react';
import type { DeskPointerInput } from '@studio/spatial/desk';
import { useEffect, useRef, useState } from 'react';
import { api, readableError } from './api.js';
import { useWorkspace } from './context.js';
import './computer.css';
interface ComputerScreen {
  scaleViewport: boolean; focusOnClick: boolean;
  disconnect(): void; focus(options?: FocusOptions): void;
  addEventListener(name: string, listener: () => void): void;
}
/** Only bundled Tabler artwork enters this decorative markup boundary. */
function ComputerIcon({ name }: { name: keyof typeof icons }) {
  return <span className="ws-computer-icon" aria-hidden="true" dangerouslySetInnerHTML={{ __html: icons[name] }} />;
}
/** Pinned noVNC is served as trusted client code; desktop HTML is never proxied. */
export function ComputerView({ zen, toggleZen, embedded = false, onScreenChange, desktopInput, onClose }: { zen: boolean; toggleZen(): void; embedded?: boolean; onScreenChange?(canvas: HTMLCanvasElement | null): void; desktopInput?: RefObject<((input: DeskPointerInput) => void) | null>; onClose?(): void }) {
  const { current } = useWorkspace();
  const target = useRef<HTMLDivElement>(null), activeScreen = useRef<ComputerScreen | undefined>(undefined);
  const [status, setStatus] = useState('Connecting to your desktop…');
  const [connecting, setConnecting] = useState(true);
  const [attempt, setAttempt] = useState(0), [viewing, setViewing] = useState(true), [connected, setConnected] = useState(false);
  useEffect(() => {
    setConnected(false); onScreenChange?.(null);
    if (!current || !viewing) {
      setConnecting(false); setStatus(current ? 'Viewer disconnected. Your desktop keeps running.' : 'Studio connection unavailable. Refresh your access to reconnect.');
      return;
    }
    setConnecting(true); setStatus('Connecting to your desktop…');
    let cancelled = false; let screen: ComputerScreen | undefined;
    void (async () => {
      const data = await api('/api/workbench') as { websocketPath?: string; adapterVersion?: number };
      if (data.websocketPath !== '/api/workbench/stream' || data.adapterVersion !== 1) throw Error('Invalid computer connection');
      const clientPath = '/api/workbench-client/core/rfb.js';
      const { default: RFB } = await import(/* @vite-ignore */ clientPath);
      // The pinned noVNC capture utility lets the spatial surface own pointer capture.
      // Input still enters the ordinary client canvas, without private RFB methods or a second stream.
      const eventsPath = '/api/workbench-client/core/util/events.js';
      const releaseCapture = desktopInput ? (await import(/* @vite-ignore */ eventsPath)).releaseCapture as () => void : undefined;
      if (cancelled || !target.current) return;
      const url = new URL(data.websocketPath, location.origin); url.protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
      screen = new RFB(target.current, url.href) as ComputerScreen; activeScreen.current = screen;
      screen.scaleViewport = true; screen.focusOnClick = true;
      screen.addEventListener('connect', () => { if (!cancelled) { setConnecting(false); setConnected(true); setStatus('Computer connected'); const canvas = target.current?.querySelector('canvas') ?? null;
        if (desktopInput && canvas) desktopInput.current = input => {
          const bounds = canvas.getBoundingClientRect(); if (!bounds.width || !bounds.height) return;
          const init = { bubbles: true, cancelable: true, clientX: bounds.left + Math.min(bounds.width - 1, input.x * bounds.width), clientY: bounds.top + Math.min(bounds.height - 1, input.y * bounds.height), button: input.button, buttons: input.buttons };
          if (input.type === 'mousedown') screen?.focus({ preventScroll: true });
          canvas.dispatchEvent(input.type === 'wheel' ? new WheelEvent('wheel', { ...init, deltaX: input.deltaX, deltaY: input.deltaY, deltaMode: input.deltaMode }) : new MouseEvent(input.type, init));
          releaseCapture?.();
        };
        onScreenChange?.(canvas); } });
      screen.addEventListener('disconnect', () => { if (!cancelled) { setConnecting(false); setConnected(false); setStatus('Computer disconnected. Reconnect after it starts or sign in again.'); if (desktopInput) desktopInput.current = null; onScreenChange?.(null); } });
    })().catch(error => { if (!cancelled) { setConnecting(false); setStatus(readableError(error)); } });
    return () => { cancelled = true; if (desktopInput) desktopInput.current = null; activeScreen.current = undefined; screen?.disconnect(); onScreenChange?.(null); target.current?.replaceChildren(); };
  }, [attempt, viewing, current, onScreenChange, desktopInput]);
  return <section className={`ws-surface ws-computer${zen ? ' ws-computer--zen' : ''}`} aria-labelledby="computer-title">
    <PageHeader title="Workbench" level={embedded ? 3 : 1} compact={zen || embedded} headingProps={{ id: 'computer-title', className: embedded && !zen ? 'ws-sr-only' : undefined }} descriptionProps={{ className: 'ws-computer-status', role: connecting ? undefined : 'status' }} description={<>{connecting ? <InfuseSpinner /> : <ComputerIcon name={connected ? 'plugConnected' : 'plugDisconnected'} />}<span>{status}</span></>} actions={<><Button variant="quiet" aria-pressed={zen} onClick={toggleZen}><ComputerIcon name={zen ? 'minimize' : 'fit'} />{zen ? 'Exit Zen mode' : 'Zen mode'}</Button>
        <Button variant="quiet" disabled={!connected} onClick={() => activeScreen.current?.focus({ preventScroll: true })}><ComputerIcon name="pointer" />Focus desktop</Button>
        <Button variant="quiet" disabled={!viewing} onClick={() => setViewing(false)}><ComputerIcon name="plugDisconnected" />Disconnect viewer</Button>
        <Button disabled={!current} onClick={() => { setViewing(true); setAttempt(n => n + 1); }}><ComputerIcon name="refresh" />Reconnect computer</Button>{onClose && !zen && <Button variant="quiet" onClick={onClose}><ComputerIcon name="moon" />Sleep monitor</Button>}</>} />
    {embedded && connecting && !zen && <LoadingState label="Connecting to your desktop…" overlay className="ws-computer-spatial-loading" />}
    <div className="ws-computer-stage">{connecting && <LoadingState label="Connecting to your desktop…" overlay />}<div ref={target} data-workbench-screen className="ws-computer-screen" role="region" aria-label="Remote desktop" /></div>
    {!zen && <footer className="ws-computer-note"><span>Your personal Workbench</span><p>Disconnecting this viewer leaves your desktop running.</p></footer>}
  </section>;
}
