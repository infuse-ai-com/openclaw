import type { CompanionTurn } from '@studio/contracts';
export const activeCompanionTurn = (turn: CompanionTurn) => !['completed', 'failed', 'stopped'].includes(turn.state);
/** Every label comes from durable lifecycle or an exact-turn edit receipt. No simulated phases. */
export function companionProgress(turn: CompanionTurn, now = Date.now()) {
  if (turn.stopRequested && activeCompanionTurn(turn)) return { label: 'Stopping…', detail: 'Stop requested. Waiting for the agent to confirm it has finished stopping.' };
  switch (turn.state) {
    case 'queued': return { label: 'Waiting to start…', detail: 'Your request is saved and waiting for the agent to connect.' };
    case 'preparing': return { label: 'Connecting…', detail: 'Preparing this conversation with the selected agent.' };
    case 'admitted': return { label: 'Starting…', detail: 'Your request was accepted. Waiting for the agent to begin.' };
    case 'running': {
      const last = turn.changes?.latestAt ? Date.parse(turn.changes.latestAt) : NaN;
      return { label: 'Working…', detail: Number.isFinite(last) && now >= last && now - last < 30000
        ? 'A board edit was saved for this request. Waiting for the next update.'
        : 'The agent is working on your request. No newer activity has been reported yet.' };
    }
    case 'uncertain': return { label: 'Reconnecting…', detail: 'Checking the existing request. It will not be started again.' };
    case 'completed': return { label: 'Finished', detail: '' };
    case 'stopped': return { label: 'Stopped', detail: '' };
    case 'failed': return { label: 'Could not finish', detail: '' };
  }
}
export function companionElapsed(turn: CompanionTurn, now: number) {
  const seconds = Math.max(0, Math.floor((now - Date.parse(turn.createdAt)) / 1000));
  if (!Number.isFinite(seconds)) return '';
  return seconds < 60 ? `${seconds}s elapsed` : `${Math.floor(seconds / 60)}m ${seconds % 60}s elapsed`;
}
