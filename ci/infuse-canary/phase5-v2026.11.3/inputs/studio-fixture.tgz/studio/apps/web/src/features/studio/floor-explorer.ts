import * as THREE from 'three';
import type { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createBuildingExterior, STOREY_HEIGHT } from '@studio/spatial/building';
import type { OfficeBox } from '@studio/spatial/office';
import './floor-explorer.css';

export interface ExplorerProject { id: string; name: string }
export interface ExplorerSummary { projectId: string; status: string; detail: string }
export interface FloorNavigation {
  projectId: string;
  projects: ExplorerProject[];
  enter(id: string): void;
  changed(projectId: string | null): void;
}
type Pose = { target: THREE.Vector3; position: THREE.Vector3; zoom: number };
type Phase = 'room' | 'reveal' | 'exterior' | 'enter' | 'handoff';
const clamp = THREE.MathUtils.clamp, lerp = THREE.MathUtils.lerp;

/** Presentation only. Session admission, summary reads and routing stay with React. */
export function createFloorExplorer(kit: {
  host: HTMLElement; element: HTMLElement; scene: THREE.Scene; room: THREE.Group;
  camera: THREE.OrthographicCamera; controls: OrbitControls; canvas: HTMLCanvasElement;
  labels: HTMLElement; navigation: FloorNavigation; redraw(): void; begin(): void;
}) {
  const { host, element, scene, room, camera, controls, canvas, labels, navigation } = kit;
  const projects = navigation.projects;
  const originIndex = projects.findIndex(p => p.id === navigation.projectId);
  const materials: THREE.Material[] = [], textures: THREE.Texture[] = [];
  const finishes = new Map<number | string, THREE.Material>();
  const opacity = new Map<THREE.Material, { value: number; transparent: boolean; depthWrite: boolean }>();
  const box: OfficeBox = (parent, w, h, d, x, y, z, finish, cast = true) => {
    let material: THREE.Material;
    if (finish instanceof THREE.Material) material = finish;
    else {
      const color = finish instanceof THREE.Color ? finish.getHex() : finish;
      if (!finishes.has(color)) { const value = new THREE.MeshStandardMaterial({ color, roughness: .7 }); finishes.set(color, value); materials.push(value); }
      material = finishes.get(color)!;
    }
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
    mesh.position.set(x, y, z); mesh.castShadow = cast; mesh.receiveShadow = true; parent.add(mesh); return mesh;
  };
  const exterior = createBuildingExterior({ box, ownedMaterials: materials, textures, fontFamily: 'StudioPlex' });
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const overlay = document.createElement('div'); overlay.className = 'studio-floor-explorer'; overlay.hidden = true;
  overlay.innerHTML = '<div class="studio-floor-explorer-heading"><span>PROJECT FLOORS</span><h2>Your office, outside.</h2><p>Scroll out to explore. Hover a floor and scroll in to enter.</p></div><nav class="studio-floor-entries" aria-label="Project floors"></nav><aside class="studio-floor-summary" aria-label="Focused floor mission desk"><small>MISSION DESK</small><h3></h3><p data-explorer-status role="status"></p><p data-explorer-detail></p><button type="button" data-explorer-enter>Enter floor ↗</button></aside>';
  host.append(overlay);
  const trigger = document.createElement('button'); trigger.type = 'button'; trigger.textContent = 'Floors ↗'; trigger.setAttribute('aria-label', 'Explore project floors');
  element.querySelector('.studio-space-controls')!.append(trigger);
  const entryLayer = overlay.querySelector<HTMLElement>('.studio-floor-entries')!;
  const panel = overlay.querySelector<HTMLElement>('.studio-floor-summary')!;
  const heading = overlay.querySelector<HTMLElement>('.studio-floor-explorer-heading')!;
  const outsideOffset = new THREE.Vector3(-14, 13, 30);
  const outsideBasis = new THREE.Matrix4().lookAt(outsideOffset, new THREE.Vector3(), camera.up);
  const screenRight = new THREE.Vector3().setFromMatrixColumn(outsideBasis, 0);
  const screenUp = new THREE.Vector3().setFromMatrixColumn(outsideBasis, 1);
  const buildingCenter = new THREE.Vector3(), projectedSize = new THREE.Vector2();
  const entries: { button: HTMLButtonElement; point: THREE.Vector3 }[] = [];
  const summaries = new Map<string, ExplorerSummary>();
  let phase: Phase = 'room', group: THREE.Group | undefined;
  let progress = 0, goal = 0, floor = originIndex, floorGoal = originIndex, last = 0;
  let selected = navigation.projectId, closePose: Pose, entryPose: Pose;
  let roomScale = room.scale.clone(), roomPosition = room.position.clone(), roomY = 0;
  let entryStart = { roomScale: room.scale.clone(), roomPosition: room.position.clone(), buildingScale: new THREE.Vector3(1, 1, 1), alpha: 1 };
  let alpha = 0, down: { x: number; y: number } | undefined;
  const active = () => phase !== 'room';
  const pose = (): Pose => ({ target: controls.target.clone(), position: camera.position.clone(), zoom: camera.zoom });
  function mark() {
    element.dataset.floorTransition = phase;
    element.dataset.floorProgress = progress.toFixed(4);
    element.dataset.floorPosition = floor.toFixed(4);
    element.dataset.floorTarget = active() ? selected : '';
  }
  function fade(value: number) {
    alpha = value;
    if (group) group.visible = value > .001;
    for (const [material, base] of opacity) {
      material.opacity = base.value * value; material.transparent = value < 1 || base.transparent;
      material.depthWrite = value > .98 && base.depthWrite;
    }
  }
  function summary() {
    panel.querySelector('h3')!.textContent = projects.find(p => p.id === selected)?.name ?? '';
    const value = summaries.get(selected);
    panel.querySelector('[data-explorer-status]')!.textContent = value?.status ?? 'Loading mission desk…';
    panel.querySelector('[data-explorer-detail]')!.textContent = value?.detail ?? '';
    panel.querySelector<HTMLElement>('[data-explorer-enter]')!.dataset.floorEntry = selected;
  }
  function select(id: string) {
    if (!active() || phase === 'enter' || phase === 'handoff' || !projects.some(p => p.id === id)) return;
    const changed = selected !== id; selected = id;
    exterior.highlight(id);
    for (const { button } of entries) button.setAttribute('aria-current', String(button.dataset.floorEntry === id));
    summary(); mark(); kit.redraw();
    if (changed) navigation.changed(id);
  }
  function open(automatic = true) {
    if (active() || originIndex < 0) return;
    kit.begin(); closePose = pose(); roomScale = room.scale.clone(); roomPosition = room.position.clone();
    progress = 0; goal = automatic ? 1 : 0; floor = floorGoal = originIndex; roomY = 0; selected = navigation.projectId;
    last = performance.now(); phase = 'reveal'; controls.enabled = false; labels.inert = true; labels.hidden = true;
    overlay.hidden = false; element.dataset.floorExploring = 'true'; entryLayer.replaceChildren(); entries.length = 0;
    group = new THREE.Group(); group.position.y = -originIndex * STOREY_HEIGHT; scene.add(group);
    exterior.build(group, projects.map((p, index) => ({ id: p.id, title: p.name, number: String(index + 1).padStart(2, '0') })).toReversed(),
      (text, point) => {
        const button = document.createElement('button'); button.type = 'button'; button.className = 'studio-floor-entry'; button.textContent = text;
        entryLayer.append(button); entries.push({ button, point }); return button;
      }, ({ floor: id }) => enter(id));
    group.traverse(object => {
      if (object instanceof THREE.Mesh) for (const material of Array.isArray(object.material) ? object.material : [object.material])
        if (!opacity.has(material)) opacity.set(material, { value: material.opacity, transparent: material.transparent, depthWrite: material.depthWrite });
    });
    // Fit the actual projected meshes, not the empty corners of a world-space
    // box stretching the street's width all the way up to the roof.
    new THREE.Box3().setFromObject(group).getCenter(buildingCenter);
    const silhouette = new THREE.Box2(), corner = new THREE.Vector3();
    group.traverse(object => {
      if (!(object instanceof THREE.Mesh)) return;
      object.geometry.computeBoundingBox();
      const bounds = object.geometry.boundingBox!;
      for (const x of [bounds.min.x, bounds.max.x]) for (const y of [bounds.min.y, bounds.max.y]) for (const z of [bounds.min.z, bounds.max.z]) {
        corner.set(x, y, z).applyMatrix4(object.matrixWorld);
        silhouette.expandByPoint(new THREE.Vector2(corner.dot(screenRight), corner.dot(screenUp)));
      }
    });
    const center = silhouette.getCenter(new THREE.Vector2());
    silhouette.getSize(projectedSize);
    buildingCenter.addScaledVector(screenRight, center.x - buildingCenter.dot(screenRight));
    buildingCenter.addScaledVector(screenUp, center.y - buildingCenter.dot(screenUp));
    fade(0); select(selected); navigation.changed(selected); mark(); kit.redraw();
  }
  function outside(): Pose {
    const width = host.clientWidth, height = host.clientHeight;
    const narrow = matchMedia('(max-width: 760px)').matches;
    // Fit the full projected silhouette in the space left by the heading,
    // mission desk and camera controls. Recompute on resize and summary changes.
    const top = heading.offsetTop + heading.offsetHeight + 16;
    const fit = (right: number, bottom: number) => Math.min(
      Math.max(1, right - 20) / width * (camera.right - camera.left) / projectedSize.x,
      Math.max(1, bottom - top - 16) / height * (camera.top - camera.bottom) / projectedSize.y,
    );
    let right = narrow ? width - 48 : panel.offsetLeft - 20;
    let bottom = narrow ? panel.offsetTop - 16 : height - 76;
    let zoom = fit(right, bottom);
    // On tall windows use the full width above the mission desk instead of
    // reserving an empty column beside it all the way up the screen.
    const aboveZoom = fit(width - 48, panel.offsetTop - 16);
    if (!narrow && aboveZoom > zoom) {
      right = width - 48; bottom = panel.offsetTop - 16; zoom = aboveZoom;
    }
    const pixelsPerUnit = height * zoom / (camera.top - camera.bottom);
    // A restrained tracking motion keeps every storey in view, including at wrap.
    const drift = (clamp(floor / Math.max(1, projects.length - 1), 0, 1) - .5) * 12;
    const target = buildingCenter.clone()
      .addScaledVector(screenRight, (width / 2 - (20 + right) / 2) / pixelsPerUnit)
      .addScaledVector(screenUp, ((top + bottom) / 2 - height / 2 + drift) / pixelsPerUnit);
    return { target, position: target.clone().add(outsideOffset), zoom };
  }
  function travel(amount: number) {
    floorGoal = THREE.MathUtils.euclideanModulo(floorGoal + amount / 480, projects.length);
    select(projects[Math.round(floorGoal) % projects.length]!.id); kit.redraw();
  }
  function enter(id = selected, automatic = true) {
    if (!active() || phase === 'handoff' || !projects.some(p => p.id === id)) return;
    if (id === navigation.projectId && phase === 'reveal') { goal = 0; kit.redraw(); return; }
    select(id); selected = id; entryPose = pose();
    entryStart = { roomScale: room.scale.clone(), roomPosition: room.position.clone(), buildingScale: group!.scale.clone(), alpha };
    roomY = (projects.findIndex(p => p.id === id) - originIndex) * STOREY_HEIGHT;
    phase = 'enter'; progress = 1; goal = automatic ? 0 : 1;
    mark(); kit.redraw();
  }
  function cleanup() {
    fade(1);
    if (group) { group.removeFromParent(); group.traverse(object => { if (object instanceof THREE.Mesh) object.geometry.dispose(); }); group = undefined; }
    exterior.clear(); entries.length = 0; entryLayer.replaceChildren();
    room.visible = true; room.scale.copy(roomScale); room.position.copy(roomPosition);
    controls.enabled = true; labels.inert = false; labels.hidden = false; overlay.hidden = true;
    phase = 'room'; progress = goal = 0; element.dataset.floorExploring = 'false'; mark();
    navigation.changed(null);
  }
  function cancel() {
    if (!active()) return;
    cleanup(); controls.target.copy(closePose.target); camera.position.copy(closePose.position); camera.zoom = closePose.zoom;
    camera.updateProjectionMatrix(); controls.update(); kit.redraw();
  }
  function project() {
    camera.updateMatrixWorld(); group!.updateMatrixWorld(true);
    const projected = entries.map(({ button, point }) => {
      const p = group!.localToWorld(point.clone()).project(camera);
      return { button, x: (.5 + p.x * .5) * host.clientWidth, y: (.5 - p.y * .5) * host.clientHeight, z: p.z };
    }).sort((a, b) => a.y - b.y);
    const minTop = heading.offsetTop + heading.offsetHeight + 8;
    const bottom = matchMedia('(max-width: 760px)').matches ? panel.offsetTop - 8 : host.clientHeight - 76;
    // Keep named 44px entrances usable when the fitted facade becomes compact.
    let previous = minTop - 44;
    const tops = projected.map(({ y }) => (previous = Math.max(y - 22, previous + 44)));
    const overflow = Math.max(0, (tops.at(-1) ?? 0) + 44 - bottom);
    projected.forEach(({ button, x, z }, index) => {
      const top = tops[index]! - overflow;
      button.hidden = progress < .7 || z < -1 || z > 1;
      button.style.left = `${clamp(x, 8, host.clientWidth - 48)}px`; button.style.top = `${top}px`;
    });
    panel.style.opacity = String(clamp((progress - .55) / .45, 0, 1)); panel.inert = progress < .9;
  }
  function tick(now: number): boolean {
    if (!active()||phase==='handoff') return false;
    const ease = reduced.matches ? 1 : 1 - Math.exp(-Math.max(0, now - last) / 75); last = now;
    progress = lerp(progress, goal, ease); floor = lerp(floor, floorGoal, ease);
    if (Math.abs(progress - goal) < .0001) progress = goal;
    if (Math.abs(floor - floorGoal) < .0001) floor = floorGoal;
    const entering = phase === 'enter', far = entering ? entryPose : outside();
    const near = entering ? {
      target: new THREE.Vector3(0, roomY + .7, 0), position: new THREE.Vector3(-15, roomY + 25.7, 28), zoom: 1,
    } : closePose;
    controls.target.copy(near.target).lerp(far.target, progress); camera.position.copy(near.position).lerp(far.position, progress);
    camera.zoom = lerp(near.zoom, far.zoom, progress); camera.lookAt(controls.target); camera.updateProjectionMatrix();
    room.position.copy(entering ? new THREE.Vector3(0, roomY, 0).lerp(entryStart.roomPosition, progress) : roomPosition);
    room.scale.copy(roomScale).lerp(entering ? entryStart.roomScale : new THREE.Vector3(.52, .85, .45), progress);
    // Never project the current project's people/papers into a different project.
    room.visible = progress < .88 && (!entering || selected === navigation.projectId);
    group!.scale.copy(entering ? new THREE.Vector3(1.9, 1, 2.2).lerp(entryStart.buildingScale, progress) : new THREE.Vector3(1.9, 1, 2.2).lerp(new THREE.Vector3(1, 1, 1), progress));
    fade(entering ? entryStart.alpha * clamp((progress - .12) / .7, selected===navigation.projectId?0:.4, 1) : clamp((progress - .12) / .7, 0, 1));
    if (!entering && progress === 1) phase = 'exterior';
    project(); mark();
    if (entering && progress === 1 && goal === 1) { phase = 'exterior'; mark(); }
    if (progress === 0 && goal === 0) {
      const id = selected;
      if (entering && id !== navigation.projectId) {
        // Hold the destination until the admitted project route replaces this scene.
        phase = 'handoff';mark();navigation.enter(id); overlay.hidden = true; return false;
      }
      cleanup();
      if (entering) { controls.target.set(0, .7, 0); camera.position.set(-15, 25.7, 28); camera.zoom = 1; }
      else { controls.target.copy(closePose.target); camera.position.copy(closePose.position); camera.zoom = closePose.zoom; }
      camera.updateProjectionMatrix(); controls.update(); canvas.focus({ preventScroll: true }); return false;
    }
    return progress !== goal || floor !== floorGoal;
  }
  const ray = new THREE.Raycaster(), pointer = new THREE.Vector2();
  function hit(event: MouseEvent): string | undefined {
    const button = event.target instanceof Element ? event.target.closest<HTMLElement>('[data-floor-entry]') : null;
    if (button?.dataset.floorEntry) return button.dataset.floorEntry;
    if (!group?.visible) return;
    const rect = canvas.getBoundingClientRect();
    pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
    ray.setFromCamera(pointer, camera);
    for (const intersection of ray.intersectObject(group, true)) {
      for (let object: THREE.Object3D | null = intersection.object; object; object = object.parent)
        if (typeof object.userData.floor === 'string') return object.userData.floor as string;
    }
    return;
  }
  function wheel(event: WheelEvent) {
    if (!event.deltaY) return;
    event.preventDefault(); event.stopImmediatePropagation(); kit.begin();
    if(phase==='handoff')return;
    let pixels = event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? host.clientHeight : 1);
    if (!active()) {
      const next = clamp(camera.zoom * Math.exp(-pixels * .0015), .65, 2.2);
      if (pixels > 0 && next <= .65) {
        pixels -= Math.max(0, Math.log(camera.zoom / .65) / .0015); camera.zoom = .65; camera.updateProjectionMatrix(); open(false);
      } else { camera.zoom = next; camera.updateProjectionMatrix(); kit.redraw(); return; }
    }
    if (phase === 'exterior' && pixels < 0) enter(hit(event) ?? selected, false);
    if (phase === 'enter') goal = clamp(goal + pixels / 600, 0, 1);
    else if (phase === 'exterior') travel(pixels);
    else {
      const next = goal + pixels / 600; goal = clamp(next, 0, 1);
      if (next > 1) travel((next - 1) * 600);
    }
    kit.redraw();
  }
  function key(event: KeyboardEvent): boolean {
    if (!active()) return false;
    if (['Escape', 'Home'].includes(event.key)) { event.preventDefault(); enter(navigation.projectId); return true; }
    if (['ArrowUp', 'ArrowDown'].includes(event.key)) { event.preventDefault(); if (phase !== 'enter') { goal = 1; travel(event.key === 'ArrowUp' ? 480 : -480); } return true; }
    if (['Enter', '+', '='].includes(event.key)) { event.preventDefault(); enter(hitTarget(event.target) ?? selected); return true; }
    return false;
  }
  const hitTarget = (target: EventTarget | null) => target instanceof Element ? target.closest<HTMLElement>('[data-floor-entry]')?.dataset.floorEntry : undefined;
  const click = (event: MouseEvent) => { const id = hitTarget(event.target); if (id) enter(id); };
  const hover = (event: PointerEvent) => { const id = hitTarget(event.target); if (id) select(id); };
  const focus = (event: FocusEvent) => { const id = hitTarget(event.target); if (id) select(id); };
  const move = (event: PointerEvent) => { if (active() && phase !== 'enter') { const id = hit(event); if (id) select(id); canvas.style.cursor = id ? 'pointer' : 'default'; } };
  const pointerDown = (event: PointerEvent) => { if (active()) down = { x: event.clientX, y: event.clientY }; };
  const pointerUp = (event: PointerEvent) => { if (down && Math.hypot(event.clientX - down.x, event.clientY - down.y) < 6) { const id = hit(event); if (id) enter(id); } down = undefined; };
  trigger.onclick = () => open();
  host.addEventListener('wheel', wheel, { capture: true, passive: false });
  overlay.addEventListener('click', click); overlay.addEventListener('focusin', focus); overlay.addEventListener('pointerover', hover);
  canvas.addEventListener('pointermove', move); canvas.addEventListener('pointerdown', pointerDown); canvas.addEventListener('pointerup', pointerUp);
  mark();
  return {
    active, open, tick, key, cancel,
    zoom(factor: number) { if (active()) { if (factor > 1) enter(); else { goal = 1; travel(480); } return true; } if (factor < 1 && camera.zoom <= .66) { open(); return true; } return false; },
    summary(value: ExplorerSummary) { summaries.set(value.projectId, value); if (selected === value.projectId) { summary(); kit.redraw(); } },
    dispose() {
      if (active()) cleanup();
      host.removeEventListener('wheel', wheel, true); overlay.removeEventListener('click', click); overlay.removeEventListener('focusin', focus); overlay.removeEventListener('pointerover', hover);
      canvas.removeEventListener('pointermove', move); canvas.removeEventListener('pointerdown', pointerDown); canvas.removeEventListener('pointerup', pointerUp);
      exterior.dispose(); materials.forEach(material => material.dispose()); textures.forEach(texture => texture.dispose()); overlay.remove(); trigger.remove();
    },
  };
}
