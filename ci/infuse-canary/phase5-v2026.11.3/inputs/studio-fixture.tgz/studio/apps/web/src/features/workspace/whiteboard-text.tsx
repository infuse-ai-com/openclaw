import { useEffect, useRef, useState } from 'react';
import { NoteTextFit } from './whiteboard-note-fit.js';
import { icons } from '@studio/ui/icons';
import * as Y from 'yjs';
import { EditorState, Compartment } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { standardKeymap } from '@codemirror/commands';
import { yCollab, yUndoManagerKeymap } from 'y-codemirror.next';
import { whiteboardEvent, whiteboardReceipt, whiteboardTextHead, whiteboardTextUpdate,
  type WhiteboardTextUpdate, type WhiteboardTextHead } from '@studio/contracts';
import { api, accessDenied, type SignedInSession } from './api.js';
import { clearWhiteboardTextRecovery } from './whiteboard-recovery.js';
import { persistWhiteboardEnvelope } from './whiteboard-storage.js';
import { BoardPresence } from './whiteboard-presence.js';
import { remoteSelectionField, remoteSelections, selectionDecorations } from './whiteboard-selections.js';
import type { CommentSelection, CommentNavigator } from './whiteboard-comments.js';

const decode=(value:string)=>Uint8Array.from(atob(value),c=>c.charCodeAt(0));
const encode=(value:Uint8Array)=>btoa(String.fromCharCode(...value));
export type BodyDrafts=Map<string,string>;
export interface SharedBodyOptions { path:string; owner:string; session:SignedInSession; drafts:BodyDrafts; enabled:boolean; changed(id:string,dirty:boolean):void;
  presence:BoardPresence;anchors:CommentNavigator;comment(selection:CommentSelection):void }

/** Recovery rebuilds from authenticated checkpoints, never from the optimistic document. */
export function SharedBodyEditor({ blockId, options, enabled, autoFocus=false, fitNote=false }: { blockId:string; options:SharedBodyOptions; enabled:boolean; autoFocus?:boolean; fitNote?:boolean }) {
  const mount=useRef<HTMLDivElement>(null),editor=useRef<EditorView|undefined>(undefined);
  const [fitText,setFitText]=useState('');
  const [status,setStatus]=useState('Connecting…'); const [review,setReview]=useState<string>();
  const [retry,setRetry]=useState(false); const [reconnect,setReconnect]=useState(false);
  const [generation,setGeneration]=useState(0); const actions=useRef({ retry:()=>{}, apply:()=>{}, discard:()=>{}, undo:()=>{}, redo:()=>{} });
  const [selection,setSelection]=useState<CommentSelection|null>(null);
  useEffect(()=> {
    let live=true, socket:WebSocket|undefined, view:EditorView|undefined, doc:Y.Doc|undefined, undo:Y.UndoManager|undefined;
    let head:WhiteboardTextHead, clientKey='', storageKey='', pending:WhiteboardTextUpdate|null=null;
    let focusPending=autoFocus;
    let ready=false, paused=true, queued:Uint8Array[]=[], cursor=0, savedDraft=options.drafts.get(blockId);
    let timer:ReturnType<typeof setTimeout>|undefined, ackTimer:ReturnType<typeof setTimeout>|undefined;
    const editable=new Compartment(); const remote={};
    const set=(message:string)=> { if (live) setStatus(message); };
    const dirty=()=> !!pending || queued.length>0 || savedDraft!==undefined;
    function selectionChanged() {
      if (!live || !doc || !view || !head) return;
      if (paused || pending || queued.length || savedDraft!==undefined) { setSelection(null); options.presence.update({ selection:null }); return; }
      const range=view.state.selection.main,body=doc.getText('body');
      options.presence.update({ selection:{ blockId,epoch:head.epoch,
        anchor:Y.relativePositionToJSON(Y.createRelativePositionFromTypeIndex(body,range.anchor,0)),
        head:Y.relativePositionToJSON(Y.createRelativePositionFromTypeIndex(body,range.head,0)) } });
      const quote=body.toString().slice(range.from,range.to);
      setSelection(quote && quote.length<=2000 ? { blockId,epoch:head.epoch,expectedTextRevision:head.textRevision,from:range.from,to:range.to,quote } : null);
    }
    function focusAnchor() {
      const target=options.anchors.pending;
      if(!target||target.blockId!==blockId||!view||!doc||!head)return;
      if(target.epoch!==head.epoch){options.anchors.finish('This comment belongs to an earlier version of the note.');return;}
      const from=Y.createAbsolutePositionFromRelativePosition(Y.createRelativePositionFromJSON(target.anchor.from),doc);
      const to=Y.createAbsolutePositionFromRelativePosition(Y.createRelativePositionFromJSON(target.anchor.to),doc);
      const body=doc.getText('body');
      if(!from||!to||from.type!==body||to.type!==body||from.index>=to.index){options.anchors.finish('The original text was deleted. The comment keeps its quote.');return;}
      view.dispatch({selection:{anchor:from.index,head:to.index},effects:EditorView.scrollIntoView(from.index,{y:'center'})});view.focus();options.anchors.finish();
    }
    const unsubscribeAnchor=options.anchors.subscribe(focusAnchor);
    function decorate() { if (live && view && doc) view.dispatch({ effects:remoteSelections.of(selectionDecorations(doc,blockId,head.epoch,options.presence.peers)) }); }
    const unsubscribe=options.presence.subscribe(decorate);
    const notify=()=> { options.changed(blockId,dirty()); selectionChanged(); };
    const remember=()=> { if (doc && (pending || queued.length)) { savedDraft=doc.getText('body').toString(); options.drafts.set(blockId,savedDraft); } notify(); };
    function lock() { paused=true; view?.contentDOM.blur(); remember(); view?.dispatch({ effects:editable.reconfigure([EditorState.readOnly.of(true),EditorView.editable.of(false)]) }); }
    function denied() {
      if (!live) return;
      paused=true; ready=false; queued=[]; pending=null; savedDraft=undefined; options.drafts.delete(blockId);
      clearWhiteboardTextRecovery(options.owner);
      view?.destroy(); view=undefined; editor.current=undefined; setFitText(''); doc?.destroy(); doc=undefined;
      socket?.close(); setReview(undefined); setRetry(false); setReconnect(false); set('Access to this text is no longer available.'); notify();
    }
    function pause(message:string) {
      if (!live) return;
      ready=false; lock(); clearTimeout(timer); clearTimeout(ackTimer);
      set(message); if (live) { setReconnect(true); setRetry(false); setReview(savedDraft); } socket?.close();
    }
    function persist(command:WhiteboardTextUpdate) {
      persistWhiteboardEnvelope(storageKey,command);
    }
    function transmit(command:WhiteboardTextUpdate) {
      if (!ready || socket?.readyState!==WebSocket.OPEN) { pause('Connection lost. Check saved text before continuing.'); return; }
      persist(command); pending=command; socket.send(JSON.stringify({ type:'update',command }));
      set('Saving…'); notify(); ackTimer=setTimeout(()=>pause('Save status is unknown. Reconnect to check the original receipt.'),15000);
    }
    function flush() {
      if (!live || !ready || paused || pending || !queued.length || view?.composing) return;
      try {
        const update=Y.mergeUpdates(queued);
        const command=whiteboardTextUpdate.parse({ commandId:crypto.randomUUID(),blockId,epoch:head.epoch,clientKey,update:encode(update) });
        persist(command); queued=[]; transmit(command);
      } catch { pause('Text could not be queued. Review your draft and allow session storage before reconnecting.'); }
    }
    function schedule() { clearTimeout(timer); timer=setTimeout(()=> { if (view?.composing) schedule(); else flush(); },150); }
    function unlock() {
      paused=false; view?.dispatch({ effects:editable.reconfigure([EditorState.readOnly.of(false),EditorView.editable.of(true)]) });
      set(queued.length?'Local changes':'Saved'); if (queued.length) schedule(); notify();
      if(focusPending&&view){
        focusPending=false;
        // Joining the shared body is asynchronous. Respect a person who has
        // already started typing in the title or another field while it loads.
        const active=document.activeElement;
        const typingElsewhere=active instanceof HTMLElement&&active.closest('input,textarea,[contenteditable="true"]')&&!view.dom.contains(active);
        if(!typingElsewhere)view.focus();
      }
      focusAnchor();
    }
    async function start() {
      try {
        setReconnect(false); setRetry(false);
        head=whiteboardTextHead.parse(await api(options.path+'/text/'+encodeURIComponent(blockId),{ isCurrent:()=>live })); if (!live) return;
        cursor=head.cursor;
        if (enabled) {
        storageKey='studio.whiteboard.text.pending:'+options.owner+':'+blockId+':'+head.epoch;
        const identityKey='studio.whiteboard.text.editor:'+options.owner+':'+blockId+':'+head.epoch;
        clientKey=sessionStorage.getItem(identityKey) ?? crypto.randomUUID(); sessionStorage.setItem(identityKey,clientKey);
        const raw=sessionStorage.getItem(storageKey);
        if (raw) {
          pending=whiteboardTextUpdate.parse(JSON.parse(raw));
          if (pending.blockId!==blockId || pending.epoch!==head.epoch || pending.clientKey!==clientKey) throw Error('Recovery identity changed');
          const result=await api(options.path+'/receipts/'+encodeURIComponent(pending.commandId),{ isCurrent:()=>live }); if (!live) return;
          if (result) { verifyReceipt(result,pending); sessionStorage.removeItem(storageKey); sessionStorage.removeItem(storageKey+'.rejected'); pending=null; }
          else if (sessionStorage.getItem(storageKey+'.rejected')===pending.commandId) {
            sessionStorage.removeItem(storageKey); sessionStorage.removeItem(storageKey+'.rejected'); pending=null;
          }
        }
        }
        doc=new Y.Doc({ gc:false });
        const text=doc.getText('body');
        Y.applyUpdate(doc,decode(head.checkpoint),remote);
        undo=new Y.UndoManager(text);
        if(fitNote)setFitText(text.toString());
        view=new EditorView({ parent:mount.current!, state:EditorState.create({ doc:text.toString(), extensions:[
          EditorView.lineWrapping, EditorView.contentAttributes.of({ 'aria-label':'Block text',spellcheck:'true' }),
          editable.of([EditorState.readOnly.of(true),EditorView.editable.of(false)]), keymap.of([...yUndoManagerKeymap,...standardKeymap]), yCollab(text,null,{ undoManager:undo }),remoteSelectionField,
          EditorView.updateListener.of(update=> { if(fitNote&&update.docChanged)setFitText(update.state.doc.toString()); if(update.selectionSet) queueMicrotask(selectionChanged); }),
        ] }) });
        editor.current=view;
        doc.on('update',(update:Uint8Array,origin:unknown)=> {
          if (origin===remote) return;
          queued.push(update); remember();
          if (doc!.getText('body').length>12000) { pause('This text exceeds the 12,000 character limit. Review the draft before continuing.'); return; }
          if (!paused) { set(pending?'Saving…':'Local changes'); schedule(); }
        });
        if (savedDraft===text.toString()) { savedDraft=undefined; options.drafts.delete(blockId); }
        setReview(savedDraft); notify();
        if (!enabled) { set('Collaborative editing is paused.'); focusAnchor(); return; }
        const url=new URL(options.path+'/stream',location.origin); url.protocol=url.protocol==='https:'?'wss:':'ws:';
        socket=new WebSocket(url); let chain=Promise.resolve();
        socket.onopen=()=>socket!.send(JSON.stringify({ type:'hello',version:2,csrf:options.session.csrfToken }));
        socket.onmessage=event=> { chain=chain.then(async()=> {
          if (!live) return;
          const message=JSON.parse(String(event.data));
          if (message.type==='hello') socket!.send(JSON.stringify({ type:'subscribe',blockId,epoch:head.epoch,clientKey,after:cursor }));
          else if (message.type==='subscribed') {
            if (!Number.isInteger(message.clientId) || message.clientId<2 || message.clientId>256) throw Error('Invalid editor identity');
            doc!.clientID=message.clientId; ready=true;
            if (pending) { set('An earlier save has no receipt. Retry that exact edit to continue.'); setRetry(true); }
            else if (savedDraft!==undefined) { set('Review your earlier draft before continuing.'); }
            else unlock();
          } else if (message.type==='event') {
            const event=whiteboardEvent.parse(message.event);
            if (event.receipt.projectId!==options.session.project.id || event.receipt.revision!==cursor+1) throw Error('Stream gap');
            cursor=event.receipt.revision;
            if (event.text?.blockId===blockId) {
              if (event.text.epoch!==head.epoch) throw Error('Document changed');
              Y.applyUpdate(doc!,decode(event.text.update),remote);
              head.textRevision=Math.max(head.textRevision,event.text.textRevision); decorate(); selectionChanged();
            } else if (event.receipt.changedIds.includes(blockId)) {
              // A structural event may delete this body. The authenticated read
              // confirms liveness without replacing selection or optimistic text.
              await api(options.path+'/text/'+encodeURIComponent(blockId),{ isCurrent:()=>live });
            }
          } else if (message.type==='receipt') {
            if (!pending) throw Error('Unexpected receipt'); verifyReceipt(message.receipt,pending);
            clearTimeout(ackTimer); sessionStorage.removeItem(storageKey); pending=null;
            setRetry(false);
            // Refresh the accepted baseline even when an event notification was lost.
            const fresh=whiteboardTextHead.parse(await api(options.path+'/text/'+encodeURIComponent(blockId),{ isCurrent:()=>live })); if (!live) return;
            if (fresh.epoch!==head.epoch) throw Error('Document changed');
            Y.applyUpdate(doc!,decode(fresh.checkpoint),remote);
            head.textRevision=fresh.textRevision;
            if (!queued.length && !paused) { savedDraft=undefined; options.drafts.delete(blockId); }
            if (paused && (savedDraft===undefined || savedDraft===doc!.getText('body').toString())) { savedDraft=undefined; options.drafts.delete(blockId); setReview(undefined); unlock(); }
            else if (paused) { setReview(savedDraft); set('Earlier save settled. Review your draft.'); }
            else { set(queued.length?'Local changes':'Saved'); schedule(); } notify();
          } else if (message.type==='error') {
            if (pending && ['INVALID_ENCODING','TEXT_ONLY','CLOCK_REUSED','INCOMPLETE_UPDATE','HISTORY_LIMIT','BODY_LIMIT','UPDATE_LIMIT','INVALID_CLOCK','INVALID_PARENT','EPOCH_CHANGED','NOT_FOUND','PREPARE_TIMEOUT','FORBIDDEN'].includes(message.code)) sessionStorage.setItem(storageKey+'.rejected',pending.commandId);
            pause('Text was not accepted ('+String(message.code)+'). Reconnect to check saved text.');
          }
          else throw Error('Invalid collaborative response');
        }).catch(error=> { if (accessDenied(error)) denied(); else pause('Text needs recovery. Reconnect to read the saved version.'); }); };
        socket.onclose=event=> { if (!live) return; if (event.reason==='Access changed') denied(); else if (ready || !paused) pause('Connection lost. Reconnect to check saved text.'); else { set('Connection ended. Reconnect to check saved text.'); setReconnect(true); } };
        socket.onerror=()=> { if (live) pause('Connection unavailable. Reconnect to check saved text.'); };
      } catch (error) { if (accessDenied(error)) denied(); else pause('Could not open saved text. Reconnect before editing.'); }
    }
    function verifyReceipt(value:unknown,command:WhiteboardTextUpdate) {
      const receipt=whiteboardReceipt.parse(value);
      if (receipt.commandId!==command.commandId || receipt.projectId!==options.session.project.id || receipt.actor.kind!=='human'
        || receipt.actor.id!==options.session.profileId || receipt.status!=='applied') throw Error('Receipt mismatch');
    }
    actions.current={ retry:()=> { if (pending) { setRetry(false); try { transmit(pending); } catch { pause('Unable to persist the exact retry.'); } } },
      apply:()=> { if (!ready || pending || !doc || savedDraft===undefined) return; const draft=savedDraft; savedDraft=undefined; options.drafts.delete(blockId); setReview(undefined); unlock();
        if (draft!==doc.getText('body').toString()) doc.transact(()=> { const text=doc!.getText('body'); text.delete(0,text.length); text.insert(0,draft); }); },
      discard:()=> { if (pending) return; queued=[]; savedDraft=undefined; options.drafts.delete(blockId); setReview(undefined); notify(); setGeneration(value=>value+1); },
      undo:()=> { if (!paused) undo?.undo(); },redo:()=> { if (!paused) undo?.redo(); } };
    void start();
    return ()=> { remember(); live=false; unsubscribe(); unsubscribeAnchor(); options.presence.update({ selection:null }); clearTimeout(timer); clearTimeout(ackTimer); socket?.close(); view?.destroy(); editor.current=undefined; undo?.destroy(); doc?.destroy(); };
  },[blockId,options,enabled,generation,autoFocus,fitNote]);
  return <div className="wboard-shared-body nodrag nopan nowheel" onClick={event=>event.stopPropagation()}>
    {fitNote?<NoteTextFit text={fitText} onFit={()=>editor.current?.requestMeasure()}><div ref={mount} className="wboard-prose" /></NoteTextFit>:<div ref={mount} className="wboard-prose" />}
    <small className="wboard-text-status" data-quiet={fitNote&&status==='Saved'||undefined} aria-live="polite">{status}</small>
    <div className="wboard-actions wboard-text-actions">
      <button type="button" className="wboard-text-tool" disabled={status!=='Saved' && status!=='Local changes' && status!=='Saving…'} onClick={()=>actions.current.undo()} title="Undo text (⌘/Ctrl Z)" aria-label="Undo text"><span className="wboard-icon" aria-hidden="true" dangerouslySetInnerHTML={{__html:icons.undo}}/></button>
      <button type="button" className="wboard-text-tool" disabled={status!=='Saved' && status!=='Local changes' && status!=='Saving…'} onClick={()=>actions.current.redo()} title="Redo text (⌘/Ctrl Shift Z)" aria-label="Redo text"><span className="wboard-icon" aria-hidden="true" dangerouslySetInnerHTML={{__html:icons.redo}}/></button>
      <button title="Comment on selection" className={!selection?'wboard-comment-idle':undefined} type="button" disabled={!selection || status!=='Saved'} onMouseDown={event=>event.preventDefault()} onClick={()=> { if(selection) options.comment(selection); }}>Comment on selection</button>
      {reconnect && <button type="button" onClick={()=>setGeneration(value=>value+1)}>Reconnect text</button>}
      {retry && <button type="button" onClick={()=>actions.current.retry()}>Retry original edit</button>}
    </div>
    {review!==undefined && <details><summary>Review earlier draft</summary><pre>{review || '(Empty text)'}</pre>
      <p>This unsent draft stays in memory only. Keep this page open until you save or discard it.</p>
      <button type="button" disabled={retry || reconnect} onClick={()=>actions.current.apply()}>Apply this draft to saved text</button>
      <button type="button" disabled={retry || reconnect} onClick={()=>actions.current.discard()}>Use saved text</button>
    </details>}
  </div>;
}
