import { useQuery } from '@tanstack/react-query';
import { parseMissionList, type MissionSummary } from '@studio/contracts';
import { useWorkspace } from './context.js';
import { api, ApiError, accessDenied, getSession } from './api.js';
import { getNativeMissions } from './native-missions.js';
import { workCards } from './collection.js';
import type { ExplorerSummary } from '../studio/floor-explorer.js';

/** Only the focused admitted project is read; no roster or task-detail fanout. */
export function useFloorSummary(projectId: string | null, shown: boolean): ExplorerSummary {
  const { session, current, visible } = useWorkspace();
  const admitted=!!projectId&&session.projects.some(project=>project.id===projectId);
  const query=useQuery({
    queryKey:['workspace','floor-summary',session.bootstrap.authorityId,session.profileId,session.bootstrap.capabilities.approver,session.projects.map(p=>p.id).sort(),projectId],
    enabled:admitted&&current&&visible&&shown,
    refetchInterval:admitted&&current&&visible&&shown?15000:false,
    queryFn:async({signal})=>{
      const selected=await getSession(signal,undefined,projectId!);
      if(!selected.authenticated||selected.profileId!==session.profileId||selected.bootstrap.authorityId!==session.bootstrap.authorityId||selected.project.id!==projectId)
        throw new ApiError('IDENTITY_CHANGED','Project access changed.',403);
      let legacy:MissionSummary[]=[];let partial=false;
      if(selected.legacyProject){
        const page=parseMissionList(await api('/api/studio/missions?limit=30',{signal}));
        legacy=page.missions;partial=!!page.nextCursor;
      }
      const native=selected.nativeMissions?await getNativeMissions(projectId!,signal):[];
      partial ||= native.length>=100;
      const open=workCards(legacy,native).filter(card=>!card.closed);
      const decisions=selected.bootstrap.capabilities.approver?open.filter(card=>card.decision).length:0;
      return {status:`${open.length} open · ${decisions} awaiting your decision`,detail:partial?'Partial view of recent missions. Open the mission board for more.':open[0]?.title??'No open missions in the inspected records.'};
    },
  });
  const id=projectId??session.project.id;
  if(!admitted||!current||accessDenied(query.error))return {projectId:id,status:'Mission desk unavailable',detail:'Project access could not be confirmed.'};
  if(query.isPending)return {projectId:id,status:'Loading mission desk…',detail:''};
  if(query.isError)return {projectId:id,status:'Mission desk unavailable',detail:'Activity could not refresh. Enter the floor to try again.'};
  return {projectId:id,status:query.data?.status??'Mission desk unavailable',detail:query.data?.detail??''};
}
