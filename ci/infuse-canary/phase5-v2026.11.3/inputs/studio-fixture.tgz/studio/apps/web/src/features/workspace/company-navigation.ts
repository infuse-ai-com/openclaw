/** Shared company destinations for the workspace and admitted launcher shell. */
export const companyNavigation=[['/company','Office','company'],['/desk','My desk','desk'],['/apps','My Apps','apps'],['/agents','Agents','agents'],['/skills','Skills','skills'],['/contributions','Activity','contributions'],['/monitoring','Monitoring','monitoring']] as const;
