import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { Mission, MissionView } from '@studio/contracts';
import { checkArtifact, displayedEvidence, evidenceRevisions, isLatestEvidence, managedEvidence } from '../studio/evidence.js';
import { coordinatorCloseout, dateLabel, gatePending, safeEvidenceUrl, targetLabel, terminal } from '../studio/presentation.js';
import { useWorkspace } from './context.js';
import { api, readableError } from './api.js';

type ReviewProps = { mission: Mission; progress?: MissionView['closeoutProgress']; readable: boolean; decisions: boolean };
export function ArtifactReview(props: ReviewProps) {
  const [selection, setSelection] = useState('');
  // An explicit historical choice survives mission refreshes; inspected bytes and acknowledgment never do.
  return <ArtifactInspection key={`${props.mission.version}:${props.readable}:${selection}`} {...props} selection={selection} setSelection={setSelection} />;
}
function ArtifactInspection({ mission: m, progress, readable, decisions, selection, setSelection }: ReviewProps & { selection: string; setSelection(value: string): void }) {
  const { owner, commands } = useWorkspace();
  const [requested, setRequested] = useState(false);
  const [reviewed, setReviewed] = useState(false);
  const evidence = displayedEvidence(m, selection);
  const managed = managedEvidence(m, evidence);
  const latest = isLatestEvidence(m, evidence);
  const artifact = useQuery({ queryKey: ['workspace', owner, 'artifact', m.id, m.version, evidence?.revision, evidence?.sha256],
    queryFn: async ({ signal }) => {
      if (!evidence) throw Error('This mission has no evidence to inspect.');
      const params = new URLSearchParams({ evidenceHash: evidence.sha256, evidenceRevision: evidence.revision });
      return checkArtifact(await api(`/api/studio/missions/${encodeURIComponent(m.id)}/evidence?${params}`, { signal }), m, evidence);
    }, enabled: requested && managed && readable, retry: false, refetchOnWindowFocus: false, refetchOnReconnect: false, gcTime: 0,
  });
  if (!evidence) return <div className="ws-inline-empty"><span className="ws-eyebrow">EVIDENCE & REVIEW</span><h2>No evidence has been delivered.</h2><p>{m.state === 'cancelled' ? 'This mission was cancelled before a result was recorded.' : 'The recorded result will appear here when the specialist delivers it.'}</p></div>;
  const ready = requested && !!artifact.data && !artifact.isError && !artifact.isFetching && readable;
  const autonomous = coordinatorCloseout(m);
  const action = m.state === 'closed' && !m.acknowledgement ? 'acknowledge'
    : !terminal(m) && m.task.state === 'verified' && autonomous && gatePending(m) ? 'resolve-closeout-gate'
    : !terminal(m) && m.task.state === 'verified' && !autonomous ? 'accept' : undefined;
  const canReview = decisions && latest && !!action && (!managed || ready) && (action !== 'resolve-closeout-gate' || !m.held);
  const actionLabel = action === 'acknowledge' ? 'Acknowledge this result' : action === 'resolve-closeout-gate' ? 'Resolve human gate' : 'Accept this result';
  const safeUrl = safeEvidenceUrl(evidence.uri);
  return <section className="ws-evidence" aria-label="Evidence review"><span className="ws-eyebrow">DELIVERY / REVISION {evidence.revision}</span><h2>{m.state === 'closed' && latest ? 'The coordinator closed this result.' : m.state === 'accepted' && latest ? 'The accepted result.' : m.state === 'cancelled' ? 'Evidence from this cancelled mission.' : latest ? 'Read the result. Judge the evidence.' : 'An earlier result.'}</h2><p className="ws-literal">{evidence.summary}</p>
    {m.correction && <div className="ws-correction-record"><span className="ws-eyebrow">CORRECTION REQUEST / REVISION {m.correction.evidence.revision}</span><p className="ws-literal">{m.correction.reason}</p><small>{m.correction.profileId} · {dateLabel(m.correction.at)}</small></div>}
    {evidenceRevisions(m).length > 1 && <label className="ws-field">Artifact revision<select value={evidence.revision} onChange={event => { setSelection(event.target.value); setRequested(false); setReviewed(false); }}>{evidenceRevisions(m).map(e => <option value={e.revision} key={e.revision}>Revision {e.revision} · {isLatestEvidence(m, e) ? 'Latest result' : 'Earlier result'}</option>)}</select></label>}
    {!latest && <div className="ws-alert">Earlier revision. This content remains inspectable; any acceptance belongs to the latest verified result.</div>}
    {managed ? <><div className="ws-artifact-toolbar"><div><strong>{ready ? 'Content hash matches' : 'A stored mission artifact'}</strong><p>Inspect the exact bytes against the approved criteria.</p></div><button className="ws-button ws-button--quiet" disabled={!readable || artifact.isFetching} onClick={() => { setReviewed(false); if (requested) void artifact.refetch(); else setRequested(true); }}>{artifact.isFetching ? 'Checking contents…' : 'Inspect contents'}</button></div>
      {artifact.isError && <div className="ws-alert" role="alert">{readableError(artifact.error)}</div>}
      {ready && <><div className="ws-integrity" role="status">SHA-256 checked in this browser · {artifact.data!.byteLength.toLocaleString('en')} bytes · {artifact.data!.mediaType}</div><div className="ws-artifact-review"><div><h3>Artifact contents</h3><pre className="ws-artifact-content" tabIndex={0} aria-label="Artifact contents"><code>{artifact.data!.content}</code></pre><p className="ws-small">Literal text. Matching bytes establish integrity, not whether the criteria have been met.</p></div><aside><span className="ws-eyebrow">APPROVED CRITERIA</span><p className="ws-literal">{m.paper.acceptance}</p></aside></div><p className="ws-small">Produced by {targetLabel(artifact.data!.producer)} · {dateLabel(artifact.data!.createdAt)}</p></>}
    </> : <div className="ws-inline-empty">{safeUrl ? <a className="ws-button ws-button--quiet" href={safeUrl} target="_blank" rel="noopener noreferrer">Open evidence ↗</a> : <p>This artifact reference has no content provider in Studio.</p>}<p className="ws-small">Recorded metadata only. Studio has not fetched these contents or checked their hash.</p></div>}
    <details className="ws-record"><summary>Evidence reference & recorded digest</summary><dl><dt>Reference</dt><dd>{evidence.uri}</dd><dt>Revision</dt><dd>{evidence.revision}</dd><dt>SHA-256</dt><dd>{evidence.sha256}</dd></dl></details>
    {m.verification && latest && <div className="ws-correction-record"><span className="ws-eyebrow">COORDINATOR VERIFICATION</span><p className="ws-literal">{m.verification.assessment.summary}</p><small>{targetLabel(m.verification.actor)} · {dateLabel(m.verification.at)} · revision {m.verification.evidenceRevision}</small><p className="ws-small">{m.verification.assessment.residualGaps.length ? `Residual gaps: ${m.verification.assessment.residualGaps.join('; ')}` : 'No residual gaps reported.'}</p></div>}
    {action && <div className="ws-accept"><label><input type="checkbox" disabled={!canReview} checked={reviewed && canReview} onChange={event => setReviewed(event.target.checked)} /> I reviewed this result and its approved acceptance criteria.</label><button className="ws-button" disabled={!canReview || !reviewed} onClick={() => void commands.send({ type: action, commandId: crypto.randomUUID(), missionId: m.id, expectedVersion: m.version, evidenceHash: evidence.sha256, evidenceRevision: evidence.revision })}>{actionLabel}</button><p className="ws-small">{action === 'acknowledge' ? 'Acknowledgement is optional. The coordinator’s closeout is already recorded.' : action === 'resolve-closeout-gate' ? 'This paper requires a human gate. Resolving it lets coordinator closeout finish once runtime receipts are settled.' : 'This paper retains its recorded human acceptance step.'}</p></div>}
    {m.state === 'closed' && <div className="ws-integrity">Closed by {m.closeout?.actor.agentId} for revision {m.closeout?.evidenceRevision}. {m.acknowledgement ? `Acknowledged by ${m.acknowledgement.profileId}.` : 'No human acceptance is required.'}</div>}
    {m.closeoutRequest && !terminal(m) && <p className={progress?.state === 'blocked' ? 'ws-alert' : 'ws-small'}>{progress?.reason ?? 'The coordinator requested closeout. Studio keeps this mission open until the approved gate and runtime completion receipts are settled.'}</p>}
    {m.state === 'accepted' && <div className="ws-integrity">Acceptance is recorded for revision {m.acceptance?.evidenceRevision ?? m.task.evidence?.revision}.</div>}
    {m.state === 'cancelled' && <p className="ws-small">This mission is cancelled. Evidence remains inspectable; acceptance is unavailable.</p>}
    {m.task.state !== 'verified' && !terminal(m) && <p className="ws-small">{autonomous ? 'The coordinator will inspect the current revision, record an assessment and request closeout.' : 'The assigned coordinator must verify the current revision before acceptance is available.'}</p>}
  </section>;
}
