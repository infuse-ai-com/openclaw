import { repositoryHealthLabel } from './RepositoryIndexingNotice';
import { LoadingState } from '../../../loading.js';
import type {
  LibraryUpdates,
  Repository,
  ReviewQueue,
} from '@studio/contracts/knowledge';
import type { ReadingProgress } from '../readingProgress';
import {
  reviewReason,
  reviewRisk,
  reviewStateLabel,
  type ReviewQueueEntry,
} from './ReviewFlow';

interface LibraryHomeProps {
  continueReading: ReadingProgress | undefined;
  onOpenContinue: (progress: ReadingProgress) => void;
  onOpenDocument: (repository: string, path: string) => void;
  onOpenReview: (entry: ReviewQueueEntry, index: number) => void;
  onOpenRepository: (repository: Repository) => void;
  onOpenSearch: () => void;
  onRetryUpdates: () => void;
  onRetryReviewQueue: () => void;
  repositories: readonly Repository[];
  updates: LibraryUpdates | undefined;
  updatesError: boolean;
  reviewQueue: ReviewQueue | undefined;
  reviewQueueError: boolean;
}

const startingPoints = [
  {
    description:
      'Company context, operating model, and the first documents to load.',
    label: 'Company operating system',
    path: 'docs/00-start-here/agent-bootstrap.md',
    repository: 'company-docs',
  },
  {
    description:
      'Shared engineering principles, delivery standards, and practices.',
    label: 'Engineering standards',
    path: 'README.md',
    repository: 'engineering-handbook',
  },
  {
    description: 'How the OpenClaw agent platform is structured and operated.',
    label: 'Agent platform',
    path: 'README.md',
    repository: 'openclaw-k8s-swarm',
  },
  {
    description: 'How repositories become one searchable, connected library.',
    label: 'How this library works',
    path: 'docs/HOW_IT_WORKS.md',
    repository: 'knowledge-base',
  },
] as const;

const repositoryGroups = [
  {
    label: 'Company',
    repositories: [
      'company-docs',
      'engineering-handbook',
      'project-scaffold',
      'infrastructure',
      'backoffice',
    ],
  },
  {
    label: 'Agent platform',
    repositories: [
      'agent-skills',
      'openclaw-agents-persona',
      'openclaw-k8s-swarm',
      'openclaw-agents-memory',
    ],
  },
  {
    label: 'Products',
    repositories: ['fnx-docs', 'md-docs', 'infuse-azure-devops-mcp'],
  },
  { label: 'Library', repositories: ['knowledge-base'] },
] as const;

function formatRelativeTime(value: string): string {
  const elapsed = Date.now() - new Date(value).getTime();
  const units = [
    { milliseconds: 86_400_000, name: 'day' },
    { milliseconds: 3_600_000, name: 'hour' },
    { milliseconds: 60_000, name: 'minute' },
  ] as const;
  const unit = units.find(({ milliseconds }) => elapsed >= milliseconds);
  if (!unit) return 'just now';
  const amount = Math.max(1, Math.floor(elapsed / unit.milliseconds));
  return `${String(amount)} ${unit.name}${amount === 1 ? '' : 's'} ago`;
}

function ArrowIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 20 20">
      <path d="M4 10h11m-4-4 4 4-4 4" />
    </svg>
  );
}

export function LibraryHome(props: LibraryHomeProps) {
  const currentProgress = props.continueReading;
  const repositoryBySlug = new Map(
    props.repositories.map((repository) => [repository.slug, repository]),
  );
  const totalDocuments = props.repositories.reduce(
    (total, repository) => total + repository.documentCount,
    0,
  );
  const unhealthyCount = props.repositories.filter(
    (repository) => repository.health !== 'ready',
  ).length;
  const knownRepositories = new Set<string>(
    repositoryGroups.flatMap((group) => [...group.repositories]),
  );
  const groups = [
    ...repositoryGroups.map((group) => ({
      label: group.label,
      repositories: group.repositories
        .map((slug) => repositoryBySlug.get(slug))
        .filter((repository): repository is Repository => Boolean(repository)),
    })),
    {
      label: 'Other',
      repositories: props.repositories.filter(
        (repository) => !knownRepositories.has(repository.slug),
      ),
    },
  ].filter((group) => group.repositories.length > 0);
  const availableStartingPoints = startingPoints.filter(({ repository }) =>
    repositoryBySlug.has(repository),
  );

  return (
    <div className="library-home" data-testid="library-home">
      <header className="library-home-header">
        <div>
          <p className="eyebrow">Library home</p>
          <h1>Find what you need.</h1>
          <p>
            Knowledge from this floor’s selected repositories and shared guidance.
          </p>
        </div>
        <dl aria-label="Library status" className="library-pulse">
          <div>
            <dt>Repositories</dt>
            <dd>{props.repositories.length}</dd>
          </div>
          <div>
            <dt>Documents</dt>
            <dd>{totalDocuments}</dd>
          </div>
          <div>
            <dt>Status</dt>
            <dd>
              {unhealthyCount === 0
                ? 'Ready'
                : `${String(unhealthyCount)} need attention`}
            </dd>
          </div>
        </dl>
      </header>

      {currentProgress && repositoryBySlug.has(currentProgress.repository) && (
        <section className="library-home-section continue-reading">
          <div className="library-home-section-heading">
            <div>
              <p className="eyebrow">Continue</p>
              <h2>Continue reading</h2>
            </div>
          </div>
          <button
            className="continue-reading-card"
            onClick={() => props.onOpenContinue(currentProgress)}
            type="button"
          >
            <span>
              <small>
                {repositoryBySlug.get(currentProgress.repository)?.displayName}
              </small>
              <strong>{currentProgress.title}</strong>
              <span>{currentProgress.path}</span>
            </span>
            <span className="home-card-action">
              Continue reading <ArrowIcon />
            </span>
          </button>
        </section>
      )}

      <section className="library-home-section recent-library-updates">
        <div className="library-home-section-heading">
          <div>
            <p className="eyebrow">Recently changed</p>
            <h2>Recent documents</h2>
          </div>
        </div>
        {props.updatesError ? (
          <div className="home-inline-state">
            <p>Recent changes are temporarily unavailable.</p>
            <button onClick={props.onRetryUpdates} type="button">
              Retry
            </button>
          </div>
        ) : !props.updates ? (
          <LoadingState label="Loading recent documents…" size="panel" />
        ) : props.updates.entries.length === 0 ? (
          <p className="home-inline-state">
            No recent document changes are available yet.
          </p>
        ) : (
          <ol className="library-update-list">
            {props.updates.entries.map((update) => (
              <li key={`${update.repository}:${update.path}`}>
                <button
                  onClick={() =>
                    props.onOpenDocument(update.repository, update.path)
                  }
                  type="button"
                >
                  <span className={`library-update-kind ${update.change}`}>
                    {update.change}
                  </span>
                  <span>
                    <strong>{update.title}</strong>
                    <small>
                      {repositoryBySlug.get(update.repository)?.displayName ??
                        update.repository}
                      {' · indexed '}
                      {formatRelativeTime(update.changedAt)}
                    </small>
                  </span>
                  <ArrowIcon />
                </button>
              </li>
            ))}
          </ol>
        )}
      </section>
      {availableStartingPoints.length > 0 && (
        <section className="library-home-section start-here">
          <div className="library-home-section-heading">
            <div>
              <p className="eyebrow">Start here</p>
              <h2>Useful paths into the library</h2>
            </div>
            <button
              className="home-text-action"
              onClick={props.onOpenSearch}
              type="button"
            >
              Search this floor <kbd>⌘K</kbd>
            </button>
          </div>
          <div className="starting-point-grid">
            {availableStartingPoints.map((point) => (
              <button
                key={`${point.repository}:${point.path}`}
                onClick={() =>
                  props.onOpenDocument(point.repository, point.path)
                }
                type="button"
              >
                <small>
                  {repositoryBySlug.get(point.repository)?.displayName}
                </small>
                <strong>{point.label}</strong>
                <span>{point.description}</span>
                <ArrowIcon />
              </button>
            ))}
          </div>
        </section>
      )}

      <section className="library-home-section repository-overview">
        <div className="library-home-section-heading">
          <div>
            <p className="eyebrow">Repositories</p>
            <h2>Browse by source</h2>
          </div>
        </div>
        <div className="repository-group-grid">
          {groups.map((group) => (
            <section key={group.label}>
              <h3>{group.label}</h3>
              <div>
                {group.repositories.map((repository) => (
                  <button
                    key={repository.slug}
                    onClick={() => props.onOpenRepository(repository)}
                    type="button"
                  >
                    <span>
                      <strong>{repository.displayName}</strong>
                      <small>{repository.documentCount} documents</small>
                    </span>
                    {repository.health !== 'ready' && (
                      <em>{repositoryHealthLabel(repository)}</em>
                    )}
                    <ArrowIcon />
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      </section>

      <section className="library-home-section review-desk" id="review-desk">
        <div className="library-home-section-heading review-desk-heading">
          <div>
            <p className="eyebrow">Human review</p>
            <h2>Review status</h2>
            <p>
              Inspect the recorded review status and read the current document.
              Review actions will be available in a later release.
            </p>
          </div>
          {props.reviewQueue && props.reviewQueue.entries.length > 0 && (
            <span className="review-desk-count">
              {String(props.reviewQueue.entries.length)} priority{' '}
              {props.reviewQueue.entries.length === 1
                ? 'document'
                : 'documents'}{' '}
              shown
            </span>
          )}
        </div>
        {props.reviewQueueError ? (
          <div className="home-inline-state review-desk-state">
            <div>
              <strong>Review status is temporarily unavailable</strong>
              <p>The rest of the library remains readable.</p>
            </div>
            <button onClick={props.onRetryReviewQueue} type="button">
              Retry
            </button>
          </div>
        ) : !props.reviewQueue ? (
          <LoadingState label="Loading review status…" size="panel" />
        ) : props.reviewQueue.entries.length === 0 ? (
          <div className="review-desk-empty">
            <span aria-hidden="true">✓</span>
            <div>
              <strong>No priority documents shown</strong>
              <p>
                No documents in this source scope appear in the current bounded
                review queue.
              </p>
            </div>
          </div>
        ) : (
          <ol className="review-desk-list">
            {props.reviewQueue.entries.map((entry, index) => {
              const reason = reviewReason(entry.review.state);
              const risk = reviewRisk(entry.type);
              return (
                <li key={`${entry.repository}:${entry.path}`}>
                  <button
                    aria-label={`${reason.title}: ${entry.title}`}
                    onClick={() => props.onOpenReview(entry, index)}
                    type="button"
                  >
                    <span className="review-desk-signal">
                      <span
                        className={`review-state-badge ${entry.review.state}`}
                      >
                        {reviewStateLabel(entry.review.state)}
                      </span>
                      <span className={`review-risk-badge ${risk.level}`}>
                        {risk.label}
                      </span>
                    </span>
                    <span className="review-desk-copy">
                      <span>
                        <strong>{entry.title}</strong>
                        <small>
                          {repositoryBySlug.get(entry.repository)
                            ?.displayName ?? entry.repository}
                          {' · '}
                          {entry.type}
                          {' · '}
                          {entry.owner}
                        </small>
                      </span>
                      <span>{entry.description}</span>
                    </span>
                    <span className="review-desk-action">
                      Read document
                      <ArrowIcon />
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        )}
      </section>
    </div>
  );
}
