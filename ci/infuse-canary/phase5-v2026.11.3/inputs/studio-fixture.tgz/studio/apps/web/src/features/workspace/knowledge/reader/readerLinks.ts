export type ReaderLinkTarget =
  | { kind: 'external' }
  | { kind: 'invalid' }
  | { kind: 'internal'; path: string; headingId?: string };

function decode(value: string): string | undefined {
  try {
    return decodeURIComponent(value);
  } catch {
    return;
  }
}

function resolvedPathSegments(
  sourcePath: string,
  decodedPath: string,
): string[] | undefined {
  const segments = decodedPath
    ? sourcePath.split('/').slice(0, -1)
    : sourcePath.split('/');
  for (const segment of decodedPath.split('/')) {
    if (!segment || segment === '.') continue;
    if (segment === '..') {
      if (segments.length === 0) return;
      segments.pop();
      continue;
    }
    segments.push(segment);
  }
  return segments;
}

export function resolveReaderLink(
  sourcePath: string,
  href: string,
): ReaderLinkTarget {
  if (/^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(href)) {
    return { kind: 'external' };
  }

  const [pathAndQuery = '', rawFragment] = href.split('#', 2);
  const [rawPath = ''] = pathAndQuery.split('?', 1);
  const decodedPath = decode(rawPath);
  const headingId = rawFragment ? decode(rawFragment) : undefined;
  if (
    decodedPath === undefined ||
    (rawFragment && headingId === undefined) ||
    decodedPath.startsWith('/') ||
    decodedPath.includes('\0')
  ) {
    return { kind: 'invalid' };
  }

  const path = resolvedPathSegments(sourcePath, decodedPath)?.join('/');
  return path
    ? { kind: 'internal', path, ...(headingId ? { headingId } : {}) }
    : { kind: 'invalid' };
}

export function readerUrl(
  repository: string,
  path: string,
  headingId?: string,
  projectId = 'core',
): string {
  const search = new URLSearchParams({ project: projectId, repo: repository, path });
  return `/knowledge?${search}${headingId ? `#${encodeURIComponent(headingId)}` : ''}`;
}

export function parseReaderLocation(
  pathname: string,
): { repository: string; path: string } | undefined {
  const match = /^\/r\/([^/]+)\/(.+)$/.exec(pathname);
  if (!match?.[1] || !match[2]) return;
  try {
    return {
      repository: decodeURIComponent(match[1]),
      path: match[2]
        .split('/')
        .map((segment) => decodeURIComponent(segment))
        .join('/'),
    };
  } catch {
    return;
  }
}
