import { useCompanionNavigation } from './whiteboard-companion-navigation.js';
import { whiteboardDrag } from './whiteboard-drag.js';
import { useWhiteboardSelectionMenu } from './whiteboard-selection-menu-state.js';
import { whiteboardKeyDown } from './whiteboard-shortcuts.js';
import { useWhiteboardCreation } from './whiteboard-creation.js';
import { useWhiteboardSelection } from './whiteboard-selection.js';
import {
  whiteboardChanges,
  whiteboardNavigation,
  type WhiteboardBlock,
  type WhiteboardSpatialOperation,
  type WhiteboardStroke,
} from '@studio/contracts';
import { useQuery } from '@tanstack/react-query';
import '@xyflow/react/dist/style.css';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import { accessDenied, api, projectPath, readableError } from './api.js';
import { useWorkspace } from './context.js';
import { useNavigate } from './navigation.js';
import { useWhiteboardCommands } from './use-whiteboard-commands.js';
import { type AlignmentGuide } from './whiteboard-alignment.js';
import { useWhiteboardCamera } from './whiteboard-camera.js';
import { WhiteboardCanvas } from './whiteboard-canvas.js';
import {
  CommentNavigator,
  WhiteboardComments,
  type CommentSelection,
} from './whiteboard-comments.js';
import { settleDrafts, useDraftAutosave } from './whiteboard-editing.js';
import { useWhiteboardDrafts } from './whiteboard-editor-state.js';
import { isTyping } from './whiteboard-history.js';
import { useWhiteboardHtmlFrames } from './whiteboard-html-frames.js';
import { HtmlPicker } from './whiteboard-html-picker.js';
import { useWhiteboardImages } from './whiteboard-images.js';
import { useWhiteboardNodeProjection } from './whiteboard-node-projection.js';
import { WhiteboardPanel } from './whiteboard-panel.js';
import { useBoardPresence } from './whiteboard-presence.js';
import { WhiteboardExitDialog, useWhiteboardExit } from './whiteboard-recovery.js';
import { useWhiteboardSectionZoom } from './whiteboard-section-navigation.js';
import { useSectionTransition } from './whiteboard-section-transition.js';
import { MarkerType } from '@xyflow/react';
import { selectionSection } from './whiteboard-selection-section.js';
import { SelectionMenu, LockPrompt } from './whiteboard-selection-menu.js';
import { type ArrangeAction } from './whiteboard-arrange.js';
import { boardClipboardPrefix } from './whiteboard-clipboard.js';
import { type ShapeKind } from './whiteboard-shapes.js';
import { useSpatialBoard } from './whiteboard-spatial.js';
import { WhiteboardCompanion } from './whiteboard-companion.js';
import { WhiteboardStatus } from './whiteboard-status.js';
import { type SharedBodyOptions } from './whiteboard-text.js';
import { WhiteboardToolbar } from './whiteboard-toolbar.js';
import type { BlockNode, BoardPanel, BoardTool, CanvasItem } from './whiteboard-types.js';
import { WhiteboardZoomControls } from './whiteboard-zoom-controls.js';
import './whiteboard.css';

export function WhiteboardWorkspace() {
  const { session, owner, current, visible } = useWorkspace();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const sectionId = params.get('section') || 'root';
  const camera = useWhiteboardCamera(sectionId);
  const { canvas, flow, canvasSize, viewport, previousView, setPreviousView } = camera;
  const zoom = viewport.zoom;
  const [replaceHtml, setReplaceHtml] = useState<string | null>(null);
  const path = projectPath('/api/studio/whiteboard', session.project.id);
  const {
    commands,
    pending,
    busy,
    denied,
    message,
    historyVersion,
    resetGeometry: commandGeometryReset,
  } = useWhiteboardCommands({
    owner,
    path,
    projectId: session.project.id,
    profileId: session.profileId,
    context: () => ({
      canSend: current && !forbidden,
      csrf: session.csrfToken,
      settled: (intent, receipt) => {
        if (intent.kind === 'convert' && receipt.status === 'applied') {
          drafts.clear();
          setFocused(null);
        }
        if (intent.kind === 'edit') {
          settleDrafts(intent.command.operations, receipt, drafts, isShared);
          syncDraftStatus();
        }
      },
      refresh: () => board.refetch(),
    }),
  });
  const { history, setMessage } = commands;
  const conversionPending = pending?.kind === 'convert';
  const selectNext = useRef<string[]>([]);
  const [autoFocusId, setAutoFocusId] = useState<string | null>(null);
  const [resetGeometry, setResetGeometry] = useState(0);
  const pastePoint = useRef<{ x: number; y: number } | null>(null);
  const { selectionMenu, lockPrompt, setSelectionMenu, setLockPrompt, closeSelectionMenu,
    lockedIds, showLockPrompt, guardLockedGesture, openSelectionMenu } = useWhiteboardSelectionMenu(() => ({
    enabled, hasDraft, imagePending, tool, selection, blocks, canvas, canvasSize, flow, pastePoint,
    setFocused, setPanel, selectNext, setNodes, setAutoFocusId,
  }));
  const [dropTarget, setDropTarget] = useState<string | null>(null),
    [dropReady, setDropReady] = useState<string | null>(null);
  useEffect(() => {
    setDropReady(null);
    if (!dropTarget) return;
    const timer = setTimeout(() => setDropReady(dropTarget), 550);
    return () => clearTimeout(timer);
  }, [dropTarget]);
  const { preparing, preparingRef, run: runSelection } = useWhiteboardSelection(() => ({
    allowed: enabled && !hasDraft && !imagePending,
    shared: isShared, scope: actionScope.current, owner, projectId: session.project.id,
    selection, path, sectionId, csrf: session.csrfToken,
    pastePoint: { x: (canvasSize.width / 2 - viewport.x) / viewport.zoom,
      y: (canvasSize.height / 2 - viewport.y) / viewport.zoom },
    refresh: async () => { const result = await board.refetch(); return result.isError ? undefined : result.data; },
    commit, notify: setMessage,
    started: action => {
      setSelectionMenu(null); setLockPrompt(null);
      if (action.kind === 'move') { setDropTarget(null); setDropReady(null); presence.update({ drag: null }); }
      if (action.kind === 'pasteClipboard') canvas.current?.focus();
    },
    applied: (action, ids, result, receipt) => {
      if (action.kind === 'delete') {
        for (const item of ids) { drafts.delete(item); bodyDrafts.delete(item); bodyDirty.delete(item); }
        syncDraftStatus();
      }
      if (result.selected) {
        selectNext.current = result.selected;
        setFocused(result.focused && receipt ? { ...result.focused, revision: receipt.revision } : null);
        setAutoFocusId(null); setPanel(null);
        setNodes(previous => previous.map(n => ({ ...n, selected: result.selected!.includes(n.id) })));
        if (action.kind === 'paste' || action.kind === 'pasteClipboard') setTool('select');
      }
      if (result.message) setMessage(result.message);
      if (action.kind === 'group' || action.kind === 'lock') canvas.current?.focus();
    },
    finished: action => { if (action.kind === 'move') setResetGeometry(v => v + 1); },
  }));
  const [focused, setFocused] = useState<CanvasItem | null>(null);
  const [alignmentGuides, setAlignmentGuides] = useState<AlignmentGuide[]>([]);
  const [nodes, setNodes] = useState<BlockNode[]>([]);
  const [target, setTarget] = useState('');
  const [tool, setTool] = useState<BoardTool>('hand');
  const [panel, setPanel] = useState<BoardPanel>(null);
  const [penColor, setPenColor] = useState<WhiteboardStroke['color']>('ink');
  const [penWidth, setPenWidth] = useState(3);
  const [shapeKind, setShapeKind] = useState<ShapeKind>('rectangle');
  const [following, setFollowing] = useState<string | null>(null);
  const commentsOpen = panel === 'comments';
  const setCommentsOpen = useCallback(
    (open: boolean) =>
      setPanel((value) => (open ? 'comments' : value === 'comments' ? null : value)),
    [],
  );
  const [commentSelection, setCommentSelection] = useState<CommentSelection | null>(null);
  const commentFrame = useRef<(id: string) => void>(() => {});
  const commentNavigator = useMemo(() => new CommentNavigator(setMessage), []);
  const beginComment = useCallback((selection: CommentSelection) => {
    setCommentSelection(selection);
    setCommentsOpen(true);
    commentFrame.current(selection.blockId);
  }, []);
  const panelElement = useRef<HTMLElement>(null);
  const panelTrigger = useRef<HTMLElement | null>(null);
  const editor = useWhiteboardDrafts(owner);
  const { blocks: drafts, bodies: bodyDrafts, bodyDirty, comments: commentDrafts } = editor.drafts;
  const { hasDraft, version: draftVersion, changed: syncDraftStatus } = editor;
  const imageDiscard = useRef<() => void>(() => {});
  const [imagePending, setImagePending] = useState(false);
  const interacting = useRef(false);
  const live = useRef(true);
  const discardLocal = () => {
    imageDiscard.current();
    setImagePending(false);
    editor.clear();
    commands.clear();
  };
  const exit = useWhiteboardExit(hasDraft || imagePending || !!pending || busy, discardLocal);
  useEffect(() => {
    live.current = true;
    return () => {
      live.current = false;
    };
  }, []);
  function openPanel(next: typeof panel) {
    if (
      document.activeElement instanceof HTMLElement &&
      !panelElement.current?.contains(document.activeElement)
    )
      panelTrigger.current = document.activeElement;
    setPanel((value) => (value === next && next !== 'editor' ? null : next));
  }
  function dismissPanel() {
    setPanel(null);
    if (panelTrigger.current?.isConnected) panelTrigger.current.focus();
    else canvas.current?.focus();
  }
  useEffect(() => {
    if (panel) panelElement.current?.focus();
  }, [panel]);
  const board = useSpatialBoard(
    path,
    owner,
    session,
    sectionId,
    current,
    visible,
    denied,
    viewport,
    canvasSize,
    focused?.id,
  );
  useEffect(() => {
    setFocused(null);
    setNodes([]);
    setPanel(null);
    setCommentSelection(null);
    setCommentsOpen(false);
    commentNavigator.finish();
  }, [sectionId]);
  function enterSection(next: string, block?: string) {
    camera.remember();
    void navigate(
      '/whiteboard?' +
        new URLSearchParams({
          project: session.project.id,
          section: next,
          ...(block ? { block } : {}),
        }),
    );
  }
  const companionNavigation = useCompanionNavigation({ path, projectId: session.project.id, sectionId,
    blocked: !current || denied || hasDraft || busy || !!pending || imagePending,
    camera, navigate: next => { setFollowing(null); enterSection(next); }, notify: setMessage });
  const capability = useQuery({
    queryKey: ['workspace', owner, 'whiteboard-capability'],
    queryFn: async () => (await api(path + '/v2/capabilities')) as { enabled: boolean },
    enabled: current,
    refetchInterval: current && visible ? 7000 : false,
  });
  const navigation = useQuery({
    queryKey: ['workspace', owner, 'whiteboard-navigation', board.data?.revision],
    gcTime: 0,
    queryFn: async ({ signal }) => {
      const value = whiteboardNavigation.parse(await api(path + '/v3/navigation', { signal }));
      if (value.projectId !== session.project.id) throw Error('Whiteboard scope changed');
      return value;
    },
    placeholderData: (previous) => previous,
    enabled: current && !denied && !!board.data,
    refetchInterval: current && visible && !denied ? 7000 : false,
    retry: false,
  });
  const activity = useQuery({
    queryKey: ['workspace', owner, 'whiteboard-activity', board.data?.revision],
    queryFn: async ({ signal }) =>
      whiteboardChanges.parse(
        await api(path + '/changes?after=' + Math.max(0, (board.data?.revision ?? 0) - 8), {
          signal,
        }),
      ),
    enabled: current && !denied && !!board.data && !board.isError,
  });
  const forbidden =
    denied ||
    accessDenied(board.error) ||
    accessDenied(activity.error) ||
    accessDenied(navigation.error);
  useEffect(() => {
    if (!forbidden) return;
    editor.clear();
    imageDiscard.current();
    setCommentsOpen(false);
    setCommentSelection(null);
    commands.deny();
    setFocused(null);
    setNodes([]);
    try {
      history.clear();
    } catch {
      /* Admission is still denied. */
    }
  }, [forbidden, commands, owner, history]);
  const transition = useSectionTransition(
    canvas,
    owner,
    sectionId,
    board.data?.sectionId === sectionId &&
      !board.loadingIds.length &&
      nodes.every((node) => node.data.sectionId === sectionId),
    forbidden || !current || !visible || !!board.error || !!panel || commentsOpen || !!following,
  );
  const isShared = board.data?.mode === 'collaborative';
  // A committed batch can contain several events. Share an in-flight read
  // instead of cancelling/restarting it per event; periodic refresh also
  // covers a newer commit arriving while that read is already in flight.
  const refreshBoard = useCallback(() => {
    void board.refetch({ cancelRefetch: false });
  }, [board.refetch]);
  const presence = useBoardPresence(
    path + '/v2',
    session,
    isShared && current && !forbidden && capability.data?.enabled === true,
    refreshBoard,
  );
  useEffect(() => {
    if (!following) return;
    const peer = presence.peers.find((peer) => peer.connectionId === following);
    if (!peer) {
      setFollowing(null);
      return;
    }
    if ((peer.state.sectionId ?? 'root') !== sectionId) {
      if (hasDraft || pending || busy) {
        setFollowing(null);
        setMessage('Save or discard your drafts before following into another section.');
      } else enterSection(peer.state.sectionId ?? 'root');
      return;
    }
    if (peer.state.viewport) void flow.current?.setViewport(peer.state.viewport);
  }, [following, presence.peers, sectionId, hasDraft, pending, busy]);
  useEffect(() => {
    presence.update({ sectionId, pointer: null, selection: null, drag: null });
  }, [presence, sectionId]);
  const shared = useMemo<SharedBodyOptions | undefined>(
    () =>
      isShared
        ? {
            path: path + '/v2',
            owner,
            session,
            drafts: bodyDrafts,
            enabled:
              current && !forbidden && !conversionPending && capability.data?.enabled === true,
            presence,
            anchors: commentNavigator,
            comment: beginComment,
            changed: (id, dirty) => {
              bodyDirty.set(id, dirty);
              syncDraftStatus();
            },
          }
        : undefined,
    [
      isShared,
      path,
      owner,
      session.csrfToken,
      session.profileId,
      session.project.id,
      current,
      forbidden,
      conversionPending,
      capability.data?.enabled,
      syncDraftStatus,
      presence,
      beginComment,
      commentNavigator,
    ],
  );
  const editable =
    (!isShared || capability.data?.enabled === true) &&
    current &&
    !forbidden &&
    !board.isError &&
    !!board.data &&
    !conversionPending;
  const enabled = editable && !busy && !pending && !preparing && !transition.active;
  const blocks = useMemo(
    () =>
      board.data?.items
        .filter((item): item is CanvasItem => item.kind !== 'connection')
        .map((item) => ({ ...item, revision: item.revision })) ?? [],
    [board.data],
  );
  const { activeHtml, setActiveHtml, engagedHtml, engageHtml } = useWhiteboardHtmlFrames({
    blocks,
    canvasSize,
    viewport,
    editable,
    visible,
    panel,
    sectionId,
    board,
  });
  useEffect(() => setAlignmentGuides([]), [sectionId, tool, current, visible, enabled]);
  const { alignDrag, dragDestination } = whiteboardDrag({
    flow, viewport, blocks, sectionId, canvasSize, setNodes, setAlignmentGuides, interacting, presence, commit,
  });
  function frameBlock(block: CanvasItem, withComments = false) {
    setFollowing(null);
    camera.frameBlock(block, withComments);
  }
  function fitBoard(remember = true) {
    camera.fitBoard(blocks, remember);
  }
  useEffect(() => {
    if (board.data?.sectionId === sectionId) camera.fitInitial(blocks, !!params.get('block'));
  }, [sectionId, board.data?.sectionId, board.data?.revision, canvasSize]);
  commentFrame.current = (id) => {
    const block = blocks.find((b) => b.id === id);
    if (!block || (block.kind !== 'note' && block.kind !== 'document')) return;
    setFocused(block);
    setAutoFocusId(block.id);
    setTool('select');
    setNodes((previous) => previous.map((node) => ({ ...node, selected: node.id === id })));
    frameBlock(block, true);
  };
  useEffect(() => {
    if (
      focused?.kind === 'note' &&
      board.data &&
      !busy &&
      !blocks.some((block) => block.id === focused.id)
    )
      setPanel('editor');
  }, [blocks, board.data, busy, focused]);
  const deepLink = useRef('');
  useEffect(() => {
    const blockId = params.get('block'),
      key = sectionId + ':' + blockId;
    if (!blockId || deepLink.current === key) return;
    const block = blocks.find((item) => item.id === blockId);
    if (block) {
      deepLink.current = key;
      select(block);
    }
  }, [blocks, params, sectionId]);
  const edges = useMemo(
    () =>
      board.data?.items
        .filter((item) => item.kind === 'connection')
        .map((item) => ({
          id: item.id,
          source: item.source,
          target: item.target,
          label: item.label,
          markerEnd: { type: MarkerType.ArrowClosed },
          className: companionNavigation.highlighted.includes(item.id) ? 'wboard-companion-edge-highlight' : undefined,
        })) ?? [],
    [board.data, companionNavigation.highlighted],
  );
  async function commit(operations: WhiteboardSpatialOperation[]) {
    if (!enabled) return;
    return commands.edit(operations, {
      sectionId,
      shared: isShared,
      spatial: board.data?.spatial === true,
    });
  }
  async function enableCollaboration() {
    if (!enabled || hasDraft || isShared || capability.data?.enabled !== true || !board.data)
      return;
    await commands.convert(board.data.revision);
  }
  useDraftAutosave(drafts, draftVersion, enabled, sectionId, isShared, commit, syncDraftStatus);
  async function reverse(direction: 'undo' | 'redo') {
    if (!enabled || hasDraft) return;
    const receipt = await commands.revert(sectionId, direction);
    if (receipt?.status === 'applied') {
      selectNext.current = [];
      setFocused(null);
      setPanel(null);
      setNodes((previous) => previous.map((n) => ({ ...n, selected: false })));
    }
  }
  function fitSelection() {
    const chosen = nodes.filter((n) => n.selected);
    if (!chosen.length) return;
    setPreviousView({ sectionId, ...(flow.current?.getViewport() ?? viewport) });
    setAutoFocusId(null);
    void flow.current?.fitView({
      nodes: chosen,
      padding: 0.3,
      minZoom: 0.1,
      maxZoom: 1.5,
      duration: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 180,
    });
  }
  useEffect(() => {
    pastePoint.current = null;
  }, [owner, sectionId]);
  const selectedIds = nodes.filter((n) => n.selected).map((n) => n.id);
  const selection = selectedIds.length
    ? selectedIds
    : focused && blocks.some((b) => b.id === focused.id)
      ? [focused.id]
      : [];
  const actionScope = useRef('');
  actionScope.current = JSON.stringify([owner, sectionId, current, visible, forbidden]);
  useEffect(() => {
    setSelectionMenu(null);
    setLockPrompt(null);
  }, [owner, sectionId, tool, current, visible, enabled, viewport.x, viewport.y, viewport.zoom]);
  useEffect(() => {
    presence.update({ sectionId, viewport,
      viewSize: canvasSize.width > 0 && canvasSize.height > 0 ? canvasSize : undefined,
      selectedIds: selection.slice(0, 30),
    });
  }, [presence, sectionId, viewport.x, viewport.y, viewport.zoom,
    canvasSize.width, canvasSize.height, selection.join('|')]);
  const selectionLocks = lockedIds(selection);
  const lockReason =
    selection.length > 30
      ? 'Choose up to 30 elements at once.'
      : !enabled || hasDraft || imagePending
        ? 'Finish saving your changes first.'
        : '';
  const setSelectionLocked = (ids: string[], locked: boolean) => runSelection({ kind: 'lock', ids, locked });
  const selectionAction = (kind: 'delete' | 'duplicate', ids = selection) => {
    if (kind === 'delete' && lockedIds(ids).length) { showLockPrompt(ids); return Promise.resolve(); }
    return runSelection({ kind, ids });
  };
  function sectionSelectionReason(ids: string[]) {
    if (!enabled || hasDraft || imagePending)
      return 'Finish saving your changes before creating a section.';
    if (!isShared) return 'Enable collaboration to create sections.';
    try {
      selectionSection(board.data?.summaries ?? [], ids, sectionId, 'selection-preview');
      return '';
    } catch (error) {
      return readableError(error);
    }
  }
  const groupSelection = (ids = selection) => runSelection({ kind: 'group', ids });
  const colorNotes = (color: NonNullable<WhiteboardBlock['noteColor']>) => runSelection({ kind: 'color', color });
  const arrange = (action: ArrangeAction) => runSelection({ kind: 'arrange', action });
  const moveToSection = (destination: string, ids = selection) => runSelection({ kind: 'move', destination, ids });
  const copySelection = (ids = selection) => runSelection({ kind: 'copy', ids });
  const pasteElements = (text: string) => runSelection({ kind: 'paste', text, point: pastePoint.current });
  const pasteClipboard = () => runSelection({ kind: 'pasteClipboard', point: pastePoint.current });

  useWhiteboardNodeProjection({
    commit,
    interacting,
    focused,
    panel,
    tool,
    commentsOpen,
    busy,
    setNodes,
    canvasSize,
    viewport,
    current,
    visible,
    blocks,
    engagedHtml,
    selectNext,
    board,
    navigation,
    setCommentsOpen,
    setCommentSelection,
    commentFrame,
    autoFocusId,
    enabled,
    activeHtml,
    setActiveHtml,
    enterSection,
    drafts,
    syncDraftStatus,
    setFocused,
    openPanel,
    editable,
    draftVersion,
    resetGeometry: resetGeometry + commandGeometryReset,
    dropTarget,
    dropReady,
    selectedIds,
    selectionLocks,
    shared,
    engageHtml,
    sectionId,
    path,
  });
  function select(block: CanvasItem) {
    setFollowing(null);
    setFocused(block);
    setAutoFocusId(block.kind === 'note' || block.kind === 'document' ? block.id : null);
    setTarget('');
    setTool('select');
    if (
      block.kind === 'note' ||
      block.kind === 'html' ||
      block.kind === 'image' ||
      block.kind === 'document'
    )
      setPanel(null);
    else openPanel('editor');
    setNodes((previous) => previous.map((node) => ({ ...node, selected: node.id === block.id })));
    frameBlock(block, commentsOpen);
  }
  function renameSection(section: NonNullable<typeof navigation.data>['sections'][number]) {
    const block = blocks.find((b) => b.id === section.id);
    if (block) select(block);
    else {
      deepLink.current = '';
      enterSection(section.parentId ?? 'root', section.id);
    }
  }
  const { create, saveShape, createSection, attachHtml } = useWhiteboardCreation(() => ({
    scope: actionScope.current, sectionId, camera, blocks, replaceHtml, commit, notify: setMessage,
    created: (item, focusText) => {
      selectNext.current = [item.id]; setTool('select'); setAutoFocusId(focusText ? item.id : null);
      setFocused(item); setPanel(null); if (!focusText) canvas.current?.focus();
    },
    attached: () => { setReplaceHtml(null); dismissPanel(); },
  }));
  function chooseShape(kind: ShapeKind) {
    setShapeKind(kind);
    setTool('shape');
    setPanel(null);
    setFocused(null);
    setAutoFocusId(null);
    canvas.current?.focus();
  }
  const imageCapability = useQuery({
    queryKey: ['workspace', owner, 'whiteboard-images'],
    queryFn: () => api(path + '/v3/images/capabilities') as Promise<{ enabled: boolean }>,
    enabled: current && !forbidden,
    retry: false,
  });
  const images = useWhiteboardImages({
    path,
    session,
    sectionId,
    enabled: enabled && isShared && imageCapability.data?.enabled === true,
    knownIds: blocks.map((b) => b.id),
    commit,
    changed: setImagePending,
    notify: setMessage,
    place: (point) => {
      const rect = canvas.current?.getBoundingClientRect();
      return (
        flow.current?.screenToFlowPosition(
          point ?? {
            x: (rect?.x ?? 0) + canvasSize.width / 2 - 160,
            y: (rect?.y ?? 0) + canvasSize.height / 2 - 100,
          },
        ) ?? { x: 200, y: 200 }
      );
    },
  });
  imageDiscard.current = images.discard;
  const zoomNavigation = useWhiteboardSectionZoom({
    cameraOwner: camera,
    sectionId,
    blocks,
    ancestors: board.data?.ancestors ?? [],
    transition,
    enterSection,
    blocked: () =>
      transition.active ||
      !current ||
      !visible ||
      forbidden ||
      board.isError ||
      board.data?.sectionId !== sectionId ||
      !!pending ||
      busy ||
      preparing ||
      hasDraft ||
      imagePending ||
      !!following ||
      interacting.current ||
      !!panel ||
      commentsOpen ||
      !!engagedHtml.length ||
      !['select', 'hand'].includes(tool),
    moved: () => setFollowing(null),
    updatePresence: (viewport) => presence.update({ viewport }),
  });

  if (forbidden)
    return (
      <section className="ws-whiteboard wboard-unavailable">
        <h1>Whiteboard</h1>
        <p role="alert">Access to this project board is no longer available.</p>
      </section>
    );
  const selectedSaved = blocks.find((block) => block.id === focused?.id);
  const loadingBoard = board.isPending && current;
  const notice = !current
    ? 'Connection paused. Editing is unavailable.'
    : board.isError
      ? readableError(board.error)
      : loadingBoard
        ? ''
        : message;
  const informational = notice.startsWith('Copied.') || notice.startsWith('Moved into ');
  const attention =
    !!notice && !informational && notice !== 'Saved to this project.' && notice !== 'Saving…';
  return (
    <section
      className="ws-whiteboard"
      aria-label="Whiteboard workspace"
      onPaste={(event) => {
        if (isTyping(event.target)) return;
        const text = event.clipboardData.getData('text/plain');
        if (text.startsWith(boardClipboardPrefix)) {
          event.preventDefault();
          void pasteElements(text);
        } else images.paste(event);
      }}
      onKeyDown={event => whiteboardKeyDown({
        canvas, tool, setTool, setAutoFocusId, panel, dismissPanel, focused, setFocused, setPanel,
        blocks, selection, copySelection, selectionAction, reverse, lockPrompt, setLockPrompt,
        flow, viewport, canvasSize, saveShape, shapeKind, penColor, penWidth, setMessage, create,
      }, event)}
    >
      <WhiteboardExitDialog blocker={exit} discard={discardLocal} />
      <WhiteboardCanvas
        openSelectionMenu={openSelectionMenu}
        guardLockedGesture={guardLockedGesture}
        pastePoint={pastePoint}
        preparingRef={preparingRef}
        setLockPrompt={setLockPrompt}
        setSelectionMenu={setSelectionMenu}
        selectedIds={selectedIds}
        showLockPrompt={showLockPrompt}
        dropTarget={dropTarget}
        dropReady={dropReady}
        setDropTarget={setDropTarget}
        setDropReady={setDropReady}
        dragDestination={dragDestination}
        moveToSection={moveToSection}
        canvas={canvas}
        tool={tool}
        images={images}
        flow={flow}
        presence={presence}
        zoomNavigation={zoomNavigation}
        sectionId={sectionId}
        nodes={nodes.map(node => companionNavigation.highlighted.includes(node.id) ? { ...node, className: [node.className, 'wboard-companion-highlight'].filter(Boolean).join(' ') } : node)}
        edges={edges}
        enabled={enabled}
        setAutoFocusId={setAutoFocusId}
        create={create}
        setPanel={setPanel}
        setFocused={setFocused}
        selectNext={selectNext}
        setNodes={setNodes}
        interacting={interacting}
        commit={commit}
        transition={transition}
        setFollowing={setFollowing}
        setTarget={setTarget}
        commentsOpen={commentsOpen}
        openPanel={openPanel}
        setAlignmentGuides={setAlignmentGuides}
        alignDrag={alignDrag}
        penColor={penColor}
        penWidth={penWidth}
        setMessage={setMessage}
        shapeKind={shapeKind}
        saveShape={saveShape}
        setTool={setTool}
        hasDraft={hasDraft}
        blocks={blocks}
        alignmentGuides={alignmentGuides}
        viewport={viewport}
        board={board}
        current={current}
      />
      {capability.data?.enabled === true && current && !forbidden && <WhiteboardCompanion key={owner} projectId={session.project.id} owner={owner} path={path} csrf={session.csrfToken} sectionId={sectionId}
        suspended={panel!==null || hasDraft || busy || imagePending || !!pending}
        reveal={(section,ids)=>void companionNavigation.reveal(section,ids)}
        openLink={(section,block)=>void companionNavigation.reveal(section,block?[block]:[])}
        locate={person=>{
          if(hasDraft || busy || pending || imagePending)return false;
          setFollowing(null);
          if(person.sectionId!==sectionId){enterSection(person.sectionId);return true;}
          if(person.bounds && canvas.current && flow.current){
            const rect=canvas.current.getBoundingClientRect(),bounds=person.bounds;
            const zoom=Math.max(0.1,Math.min(2,(rect.width-80)/bounds.width,(rect.height-80)/bounds.height));
            void flow.current.setViewport({x:rect.width/2-(bounds.x+bounds.width/2)*zoom,y:rect.height/2-(bounds.y+bounds.height/2)*zoom,zoom});
          }
          return true;
        }}/>}
      <WhiteboardStatus
        informational={informational}
        session={session}
        panel={panel}
        openPanel={openPanel}
        isShared={isShared}
        presence={presence}
        following={following}
        setFollowing={setFollowing}
        sectionId={sectionId}
        board={board}
        enterSection={enterSection}
        attention={attention}
        loadingBoard={loadingBoard}
        busy={busy}
        imagePending={imagePending}
        hasDraft={hasDraft}
        current={current}
        commentsOpen={commentsOpen}
        focused={focused}
        commentFrame={commentFrame}
        setCommentsOpen={setCommentsOpen}
        notice={notice}
        pending={!!pending}
        commands={commands}
      />
      {selectionMenu && (
        <SelectionMenu
          copy={() => void copySelection(selectionMenu.ids)}
          paste={() => void pasteClipboard()}
          {...selectionMenu}
          width={canvasSize.width}
          height={canvasSize.height}
          count={selectionMenu.ids.length}
          reason={sectionSelectionReason(selectionMenu.ids)}
          locked={lockedIds(selectionMenu.ids).length}
          lockReason={
            selectionMenu.ids.length > 30 ? 'Choose up to 30 elements at once.' : lockReason
          }
          close={closeSelectionMenu}
          setLocked={(locked) => void setSelectionLocked(selectionMenu.ids, locked)}
          create={() => void groupSelection(selectionMenu.ids)}
          duplicate={() => {
            setSelectionMenu(null);
            void selectionAction('duplicate');
          }}
          remove={() => {
            setSelectionMenu(null);
            void selectionAction('delete');
          }}
        />
      )}
      {lockPrompt && lockedIds(lockPrompt.ids).length > 0 && (
        <LockPrompt
          {...lockPrompt}
          width={canvasSize.width}
          height={canvasSize.height}
          count={lockedIds(lockPrompt.ids).length}
          enabled={enabled && !hasDraft && !imagePending}
          unlock={() => void setSelectionLocked(lockPrompt.ids, false)}
          close={() => setLockPrompt(null)}
        />
      )}
      <WhiteboardToolbar
        nodes={nodes}
        viewport={viewport}
        canvasSize={canvasSize}
        colorNotes={colorNotes}
        copySelection={copySelection}
        fitSelection={fitSelection}
        selectionLocks={selectionLocks}
        lockReason={lockReason}
        setSelectionLocked={setSelectionLocked}
        sectionSelectionReason={sectionSelectionReason}
        groupSelection={groupSelection}
        selection={selection}
        enabled={enabled}
        hasDraft={hasDraft}
        selectionAction={selectionAction}
        tool={tool}
        shapeKind={shapeKind}
        chooseShape={chooseShape}
        penColor={penColor}
        penWidth={penWidth}
        setPenColor={setPenColor}
        setPenWidth={setPenWidth}
        setTool={setTool}
        setPanel={setPanel}
        setFocused={setFocused}
        setAutoFocusId={setAutoFocusId}
        canvas={canvas}
        create={create}
        isShared={isShared}
        createSection={createSection}
        images={images}
        imageCapability={imageCapability}
        imagePending={imagePending}
        setReplaceHtml={setReplaceHtml}
        openPanel={openPanel}
        panel={panel}
        historyVersion={historyVersion}
        history={history}
        sectionId={sectionId}
        reverse={reverse}
      />
      <WhiteboardZoomControls
        setFollowing={setFollowing}
        transition={transition}
        zoom={zoom}
        sectionId={sectionId}
        flow={flow}
        zoomNavigation={zoomNavigation}
        setPreviousView={setPreviousView}
        viewport={viewport}
        fitBoard={fitBoard}
        previousView={previousView}
      />
      {panel === 'html' && (
        <HtmlPicker
          path={path}
          session={session}
          sectionTitle={board.data?.ancestors.at(-1)?.title ?? 'Whiteboard'}
          replacing={!!replaceHtml}
          enabled={enabled}
          previewReady={!nodes.some((node) => node.data.activeHtml)}
          notice={attention ? notice : ''}
          choose={attachHtml}
          close={dismissPanel}
        />
      )}
      <WhiteboardPanel
        removeElement={(id) => void selectionAction('delete', [id])}
        setAutoFocusId={setAutoFocusId}
        openPanel={openPanel}
        selection={selection}
        selectionLocks={selectionLocks}
        arrange={arrange}
        moveToSection={moveToSection}
        renameSection={renameSection}
        panel={panel}
        panelElement={panelElement}
        focused={focused}
        dismissPanel={dismissPanel}
        path={path}
        session={session}
        navigation={navigation}
        enterSection={enterSection}
        selectedSaved={selectedSaved}
        syncDraftStatus={syncDraftStatus}
        enabled={enabled}
        commit={commit}
        setReplaceHtml={setReplaceHtml}
        setPanel={setPanel}
        isShared={isShared}
        board={board}
        blocks={blocks}
        select={select}
        drafts={drafts}
        sectionId={sectionId}
        editable={editable}
        shared={shared}
        target={target}
        setTarget={setTarget}
        activity={activity}
        capability={capability}
        hasDraft={hasDraft}
        enableCollaboration={enableCollaboration}
      />
      {commentsOpen && isShared && (
        <WhiteboardComments
          path={path + '/v2'}
          owner={owner}
          session={session}
          blockId={
            focused?.kind === 'note' || focused?.kind === 'document' ? focused.id : undefined
          }
          selection={commentSelection}
          people={navigation.data?.people ?? []}
          jump={(thread) => {
            commentFrame.current(thread.blockId);
            commentNavigator.jump(thread);
          }}
          drafts={commentDrafts}
          enabled={current && !forbidden && !conversionPending && capability.data?.enabled === true}
          changed={syncDraftStatus}
          close={() => setCommentsOpen(false)}
        />
      )}
    </section>
  );
}
