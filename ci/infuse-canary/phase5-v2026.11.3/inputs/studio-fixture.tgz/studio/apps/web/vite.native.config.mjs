import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';

const path = relative => fileURLToPath(new URL(relative, import.meta.url));

// The native page is served as an authenticated OpenClaw plugin asset. Library
// mode embeds imported assets so it does not depend on the standalone /public.
export default defineConfig({
  root: path('./src'),
  publicDir: false,
  build: {
    target: 'es2023',
    outDir: path('../../integrations/openclaw-studio/dist/control-ui/studio'),
    emptyOutDir: true,
    sourcemap: false,
    cssCodeSplit: false,
    lib: { entry: path('./src/native.ts'), formats: ['es'], fileName: 'index', cssFileName: 'studio' },
  },
});
