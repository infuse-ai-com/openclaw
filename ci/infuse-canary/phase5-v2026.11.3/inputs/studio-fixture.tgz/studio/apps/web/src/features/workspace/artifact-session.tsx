import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { useLocation } from 'react-router';
import { artifactLifecycleConfirmation, artifactViewerPath, type ArtifactLifecycleReceipt } from '@studio/contracts';
import { useNavigate } from './navigation.js';
import { useArtifactLifecycleController } from './artifact-lifecycle.js';
import { useWorkspace } from './context.js';
import { Button } from './ui.js';

export type ArtifactVisit = { key: string; url: string; search: string; scope: string; pages: number; path: string; scroll: number; row: number };
function useSession() {
  const route = useLocation(), navigate = useNavigate();
  const saved = useRef<ArtifactVisit | undefined>(undefined);
  const [undo, setUndo] = useState<ArtifactLifecycleReceipt>();
  const visit = saved.current && (route.key === saved.current.key || route.state?.artifactVisit === saved.current.key) ? saved.current : undefined;
  const backTo = visit?.url ?? '/artifacts';
  const backState = visit ? { artifactVisit: visit.key } : undefined;
  const controller = useArtifactLifecycleController(receipt => {
    setUndo(receipt.action === 'trash' ? receipt : undefined);
    if (receipt.action === 'trash' && window.location.pathname === artifactViewerPath(receipt.producer, receipt.artifactId, receipt.revision)) {
      navigate(backTo, { replace: true, state: backState });
    }
  });
  return { controller, saved, visit, backTo, backState, undo, dismissUndo: () => setUndo(undefined) };
}
const Context = createContext<ReturnType<typeof useSession> | undefined>(undefined);
export function ArtifactSession({ children }: { children: ReactNode }) {
  return <Context value={useSession()}>{children}</Context>;
}
export function useArtifactSession() {
  const value = useContext(Context);
  if (!value) throw Error('Artifact browsing session is unavailable');
  return value;
}
export function ArtifactUndo() {
  const { undo, dismissUndo, controller } = useArtifactSession(), { current } = useWorkspace();
  const [paused, setPaused] = useState(false);
  useEffect(() => setPaused(false), [undo]);
  const dismiss = useRef(dismissUndo); dismiss.current = dismissUndo;
  useEffect(() => {
    if (!undo || paused || controller.busy || controller.pending) return;
    const timer = window.setTimeout(() => dismiss.current(), 30000);
    return () => window.clearTimeout(timer);
  }, [undo, paused, controller.busy, controller.pending]);
  if (!undo || !current) return null;
  function restore(receipt: ArtifactLifecycleReceipt) {
    const { producer, artifactId, revision, generation } = receipt;
    const target = { producer, artifactId, revision, generation, action: 'restore' as const };
    void controller.send({ ...target, commandId: crypto.randomUUID(), confirmation: artifactLifecycleConfirmation(target) });
  }
  return <div className="ws-artifact-undo" onFocus={() => setPaused(true)} onBlur={e=>{if(!e.currentTarget.contains(e.relatedTarget))setPaused(false);}} onMouseEnter={() => setPaused(true)} onMouseLeave={e=>setPaused(e.currentTarget.contains(document.activeElement))}>
    <span role="status">Moved to bin.</span><Button variant="quiet" disabled={controller.busy || !!controller.pending || controller.blocked} onClick={() => restore(undo)}>Undo</Button>
    <button type="button" aria-label="Dismiss notification" onClick={dismissUndo}>×</button>
  </div>;
}
