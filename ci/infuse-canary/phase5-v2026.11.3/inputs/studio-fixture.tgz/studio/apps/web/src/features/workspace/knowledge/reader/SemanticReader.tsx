import { useEffect, useRef, type CSSProperties, type ReactNode } from 'react';
import type { Document } from '@studio/contracts/knowledge';
import type { GraphEntryOrigin } from './graphLayout';

interface SemanticReaderProps {
  children: ReactNode;
  document: Document;
  onExit: () => void;
  transitionOrigin?: GraphEntryOrigin;
}

const EXIT_GESTURE_DISTANCE = 180;

export function SemanticReader({
  children,
  document,
  onExit,
  transitionOrigin,
}: SemanticReaderProps) {
  const portalRef = useRef<HTMLElement>(null);
  const exitDistanceRef = useRef(0);

  useEffect(() => {
    portalRef.current?.scrollTo({ top: 0 });
    exitDistanceRef.current = 0;
  }, [document.path, document.repository]);

  useEffect(() => {
    const portal = portalRef.current;
    if (!portal) return;

    function handleWheel(event: globalThis.WheelEvent) {
      if (Math.abs(event.deltaY) < 1) return;
      event.preventDefault();

      if (event.deltaY < 0) {
        exitDistanceRef.current = 0;
        portal?.scrollBy({
          top: Math.max(48, -event.deltaY * 0.9),
          behavior: 'auto',
        });
        return;
      }

      if ((portal?.scrollTop ?? 0) > 1) {
        exitDistanceRef.current = 0;
        portal?.scrollBy({
          top: -Math.max(48, event.deltaY * 0.9),
          behavior: 'auto',
        });
        return;
      }

      exitDistanceRef.current += event.deltaY;
      if (exitDistanceRef.current >= EXIT_GESTURE_DISTANCE) {
        exitDistanceRef.current = 0;
        onExit();
      }
    }

    portal.addEventListener('wheel', handleWheel, { passive: false });
    return () => portal.removeEventListener('wheel', handleWheel);
  }, [onExit]);

  return (
    <section
      aria-label={`Reading ${document.title}`}
      className="semantic-reader-portal atlas-scroll-surface"
      data-transition-origin={
        transitionOrigin
          ? `${String(Math.round(transitionOrigin.x))},${String(Math.round(transitionOrigin.y))}`
          : 'center'
      }
      data-testid="semantic-reader"
      ref={portalRef}
      style={
        transitionOrigin
          ? ({
              '--semantic-origin-x': `${String(transitionOrigin.x)}px`,
              '--semantic-origin-y': `${String(transitionOrigin.y)}px`,
            } as CSSProperties)
          : undefined
      }
    >
      {children}
    </section>
  );
}
