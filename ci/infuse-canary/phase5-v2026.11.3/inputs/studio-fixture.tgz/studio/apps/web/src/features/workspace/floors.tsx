import { PageHeader, Button, EmptyState } from './ui.js';
import { RegistryRepositoryEditor } from './registry-repository-editor.js';
import { FloorSetup } from './floor-setup.js';
import { useSearchParams } from 'react-router';
import { useEffect, useRef, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { floorCommand, floorCommandTarget, floorRepositoryCatalog, type FloorCommand, type FloorReceipt } from '@studio/contracts';
import { ApiError, api, readableError } from './api.js';
import { useWorkspace } from './context.js';
import { Link, useNavigate } from './navigation.js';
import { LoadingState } from './loading.js';
import { RepositorySetupForm } from './repository-setup.js';
import type { RepositorySetup } from '@studio/contracts';
import { FloorDetails, FloorMembers, FloorRepositories, FloorIcon, type EditableFloor, type FloorDirectory } from './floor-fields.js';
import './floors.css';

export function FloorManager() {
  const { session, current, owner } = useWorkspace(), query = useQueryClient(), navigate = useNavigate();
  const [params] = useSearchParams();
  const requestedFloor = params.get('edit'), createRequested = params.get('create') === '1';
  const recoveryKey = `studio.floor.pending:${JSON.stringify([session.bootstrap.authorityId, session.profileId])}`;
  const [pending, setPending] = useState<FloorCommand | null>(() => {
    try { const raw = sessionStorage.getItem(recoveryKey); return raw ? floorCommand.parse(JSON.parse(raw)) : null; } catch { return null; }
  });
  const [draft, setDraft] = useState<EditableFloor | null>(pending && 'floor' in pending ? { ...pending.floor, revision: pending.expectedRevision, configured: false, legacyCore: false, canRetire: false } : null);
  const [busy, setBusy] = useState(false), [message, setMessage] = useState(''), [error, setError] = useState('');
  const [baseline, setBaseline] = useState<EditableFloor | null>(null);
  const [tab, setTab] = useState<'setup' | 'repositories' | 'members' | 'settings'>('setup');
  const [step, setStep] = useState(0), [picking, setPicking] = useState(false);
  const [retiring, setRetiring] = useState(false);
  const initialized = useRef(false), heading = useRef<HTMLHeadingElement>(null);
  const creating = !!draft && !draft.configured && draft.revision === 0;
  const dirty = !!draft && !!baseline && JSON.stringify(draft) !== JSON.stringify(baseline);
  const [registryPreview,setRegistryPreview]=useState(false);
  const [setup, setSetup] = useState<{ source?: RepositorySetup; revision?: number } | null>(null);
  const enabled = current && session.canManageFloors === true;
  const directory = useQuery({ queryKey: ['workspace', owner, 'floors'], enabled,
    queryFn: async ({ signal }) => await api('/api/studio/floors', { signal }) as FloorDirectory });
  const catalog = useQuery({ queryKey: ['workspace', owner, 'floor-repositories'], enabled,
    queryFn: async ({ signal }) => floorRepositoryCatalog.parse(await api('/api/studio/floors/repositories', { signal })) });
  useEffect(() => { if (!session.canManageFloors) { setDraft(null); setPending(null); } }, [session.canManageFloors]);
  function choose(floor?: EditableFloor) {
    setMessage(''); setError(''); setStep(0); setPicking(false); setRetiring(false); setTab('setup');
    const value = floor ? { ...floor, repositories: floor.legacyCore ? (catalog.data ?? []).map(repo => ({ id: repo.id, slug: repo.slug, shared: true })) : floor.repositories }
      : { id: '', name: '', description: '', memberProfileIds: [session.profileId], repositories: [], revision: 0, configured: false, legacyCore: false, canRetire: true };
    setDraft(value); setBaseline(value); initialized.current = true;
  }
  function discardAllowed() { return !dirty || window.confirm('Discard your unsaved floor changes?'); }
  function select(floor?: EditableFloor) { if (!busy && !pending && !setup && discardAllowed()) choose(floor); }
  function cancel() {
    if (!discardAllowed()) return;
    const saved = directory.data?.floors.find(floor => floor.id === draft?.id) ?? directory.data?.floors.find(floor => floor.id === session.project.id);
    if (saved) choose(saved); else { setDraft(null); setBaseline(null); }
  }
  useEffect(() => { heading.current?.focus({ preventScroll: true }); }, [step, creating]);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); };
    window.addEventListener('beforeunload', warn); return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);
  useEffect(() => {
    if (initialized.current || !enabled || !directory.data || pending || requestedFloor || createRequested) return;
    const floor = directory.data.floors.find(value => value.id === session.project.id) ?? directory.data.floors.find(value => !value.retiredAt);
    if (floor?.legacyCore && !catalog.data) return;
    if (floor) choose(floor);
  }, [enabled, directory.data, catalog.data, pending, requestedFloor, createRequested, session.project.id]);
  useEffect(() => {
    if (!enabled || !directory.data || pending || (!requestedFloor && !createRequested)) return;
    // A navigation shortcut opens the existing editor; it never saves or changes admission.
    if (createRequested) choose();
    else {
      const floor = directory.data.floors.find(value => value.id === requestedFloor);
      if (floor?.legacyCore && !catalog.data) return;
      if (floor) choose(floor);
      else setError('This floor is no longer available to manage. Choose a floor below.');
    }
    navigate('/floors', { replace: true });
  }, [requestedFloor, createRequested, directory.data, catalog.data, enabled, pending]);
  async function save(intent?: 'retire' | 'restore') {
    if ((!draft && !pending) || !enabled || busy) return;
    if (!pending && !intent && !draft!.memberProfileIds.length) { setError('Choose at least one member.'); return; }
    setBusy(true); setError(''); setMessage('');
    try {
      const command = pending ?? floorCommand.parse(intent
        ? { commandId: crypto.randomUUID(), expectedRevision: draft!.revision, intent, floorId: draft!.id }
        : { commandId: crypto.randomUUID(), expectedRevision: draft!.revision, intent: draft!.configured || draft!.revision > 0 ? 'update' : 'create',
          floor: { id: draft!.id, name: draft!.name, description: draft!.description, memberProfileIds: draft!.memberProfileIds, repositories: draft!.repositories } });
      // Persist the exact request before sending; storage failure leaves the form untouched.
      sessionStorage.setItem(recoveryKey, JSON.stringify(command)); setPending(command);
      let receipt = await api(`/api/studio/floors/receipts/${encodeURIComponent(command.commandId)}`) as FloorReceipt | null;
      if (!receipt) receipt = await api('/api/studio/floors/commands', { command, csrf: session.csrfToken }) as FloorReceipt;
      if (receipt.commandId !== command.commandId || receipt.floorId !== floorCommandTarget(command) || !['applied', 'conflict'].includes(receipt.status)) throw Error('The save receipt did not match. Check the saved result before continuing.');
      sessionStorage.removeItem(recoveryKey); setPending(null);
      const saved = await directory.refetch();
      if (receipt.status === 'conflict') { setError(receipt.message); }
      else {
        const savedFloor = saved.data?.floors.find(f => f.id === receipt!.floorId) ?? null;
        setDraft(savedFloor); setBaseline(savedFloor); setPicking(false); setRetiring(false); setStep(0);
        setMessage(command.intent === 'retire' ? 'Floor retired. Its saved settings and records are preserved.' : command.intent === 'restore' ? 'Floor restored.' : 'Floor saved.');
        if (command.intent === 'retire' && session.project.id === receipt.floorId) {
          const next = session.projects.find(project => project.id !== receipt!.floorId);
          if (next) navigate(`/floors?project=${encodeURIComponent(next.id)}`, { replace: true });
        }
      }
      await query.invalidateQueries({ queryKey: ['workspace-session'] });
    } catch (failure) {
      setError(readableError(failure));
      if (failure instanceof ApiError && ['INVALID_INPUT', 'ALREADY_EXISTS', 'STATE_CONFLICT'].includes(failure.code)) { sessionStorage.removeItem(recoveryKey); setPending(null); }
    }
    finally { setBusy(false); }
  }
  if (!session.canManageFloors) return <section className="ws-surface"><h1>Floor management unavailable.</h1><p>Your profile does not have floor management permission.</p><Link to="/company">Back to Office</Link></section>;
  if (directory.isPending) return <LoadingState label="Loading floors…" size="page" />;
  const locked = !enabled || busy || !!pending || !!setup || registryPreview;
  const floorButton = (floor: EditableFloor) => <button type="button" key={floor.id} disabled={locked || (floor.legacyCore && !catalog.data)} aria-label={floor.name} aria-pressed={!creating && draft?.id === floor.id} onClick={() => select(floor)}><FloorIcon name="building" /><span><strong>{floor.name}</strong><small>{floor.legacyCore ? catalog.data?.length ?? 0 : floor.repositories.length} repositories · {floor.memberProfileIds.length} {floor.memberProfileIds.length === 1 ? 'member' : 'members'}</small></span><FloorIcon name="chevron" /></button>;
  return <section className={`ws-surface ws-floor-management${creating ? ' fd-creating' : ''}`}>
    <PageHeader className="fd-page-header" title={creating ? 'Create a floor' : 'Floors'} description={creating ? 'Set up a new place for your team’s work.' : 'The spaces your team works in.'} leading={creating ? <Button variant="quiet" className="fd-back" disabled={locked} onClick={cancel}>← Back to floors</Button> : <Link className="fd-back" to="/company" onClick={event => { if (!discardAllowed()) event.preventDefault(); }}>← Back to Office</Link>} actions={!creating && <Button disabled={locked} onClick={() => select()}><FloorIcon name="plus" />Create floor</Button>} />
    {!registryPreview && <Button variant="quiet" disabled={locked} onClick={()=>setRegistryPreview(true)}>Preview shared repository settings</Button>}
    {registryPreview && <RegistryRepositoryEditor onClose={()=>setRegistryPreview(false)}/>}
    {(error || directory.error || catalog.error) && <div className="fd-message ws-alert" role="alert">{error || readableError(directory.error ?? catalog.error)}{(directory.error || catalog.error) && <Button variant="quiet" className="fd-text-button" disabled={!enabled} onClick={() => { void directory.refetch(); void catalog.refetch(); }}>Try again</Button>}</div>}
    {message && <p className="fd-message" role="status">{message} {draft && !draft.retiredAt && <><Link to={`/floor?project=${encodeURIComponent(draft.id)}`}>Open floor →</Link><Link to={`/knowledge?project=${encodeURIComponent(draft.id)}`}>Open Knowledge →</Link></>}</p>}
    {pending && !draft && <div className="fd-message" role="status">A floor change is awaiting a confirmed receipt. <Button disabled={!enabled || busy} onClick={() => void save()}>Check save</Button></div>}
    <div className="fd-layout" hidden={registryPreview}>
      {!creating && <aside className="fd-directory"><h2>Your floors</h2><nav aria-label="Manage floors">{directory.data?.floors.filter(floor => !floor.retiredAt).map(floorButton)}</nav>
        {!!directory.data?.floors.some(floor => floor.retiredAt) && <details className="fd-retired"><summary>Retired floors</summary><nav aria-label="Retired floors">{directory.data.floors.filter(floor => floor.retiredAt).map(floorButton)}</nav></details>}
      </aside>}
      <div className="fd-editor">
        {setup && <RepositorySetupForm key={setup.source?.slug ?? 'connect'} initial={setup.source} revision={setup.revision}
          onClose={() => { setSetup(null); void catalog.refetch(); }} onConnected={repo => { void catalog.refetch(); setDraft(previous => previous && previous.repositories.length < 32 && !previous.repositories.some(source => source.id === repo.id) ? { ...previous, repositories: [...previous.repositories, { ...repo, shared: false }] } : previous); }} />}
        {draft ? <form hidden={!!setup} className="fd-form" onSubmit={event => { event.preventDefault(); if (creating && step < 2 && !pending) setStep(step + 1); else void save(); }}>
          <div className="fd-form-body ui-layout-form ui-page-content">
            {creating ? <><ol className="fd-steps" aria-label="Create floor progress">{['Details', 'Repositories', 'Members'].map((label, index) => <li key={label} aria-current={step === index ? 'step' : undefined}><span>{index < step ? <FloorIcon name="check" /> : index + 1}</span>{label}</li>)}</ol>
              {step > 0 && <div className="fd-summary"><FloorIcon name="building" /><div><small>Floor</small><strong>{draft.name}</strong></div><div><small>Address</small><span>{draft.id}</span></div><Button variant="quiet" type="button" className="fd-text-button" disabled={locked} onClick={() => setStep(0)}><FloorIcon name="edit" />Edit details</Button></div>}
              <h2 ref={heading} tabIndex={-1}>{step === 0 ? 'Give your floor a name' : step === 1 ? 'Which repositories belong here?' : 'Who will work here?'}</h2><p className="fd-intro">{step === 0 ? 'Start with the basics. You can add sources and teammates next.' : step === 1 ? 'Choose sources for this floor. You can change them later.' : 'Review your team, then create the floor when you’re ready.'}</p>
            </> : <><div className="fd-floor-heading"><div><h2 ref={heading} tabIndex={-1}>{draft.name}</h2><p>{draft.description || 'A shared place for your team’s work.'}</p></div>{draft.retiredAt ? <span className="fd-badge">Retired</span> : <Button variant="quiet" type="button"  onClick={() => setTab('settings')}><FloorIcon name="edit" />Edit floor</Button>}</div>
              <div className="fd-tabs ui-tabs" role="tablist" aria-label="Floor sections">{(['setup', 'repositories', 'members', 'settings'] as const).map(value => <button type="button" role="tab" key={value} id={`floor-tab-${value}`} aria-selected={tab === value} aria-controls="floor-section" tabIndex={tab === value ? 0 : -1} onKeyDown={event => {
                const tabs = ['setup', 'repositories', 'members', 'settings'] as const; let index = tabs.indexOf(value);
                if (event.key === 'ArrowRight') index = (index + 1) % tabs.length; else if (event.key === 'ArrowLeft') index = (index + tabs.length - 1) % tabs.length; else if (event.key === 'Home') index = 0; else if (event.key === 'End') index = tabs.length - 1; else return;
                event.preventDefault(); setTab(tabs[index]!); document.getElementById(`floor-tab-${tabs[index]}`)?.focus();
              }} onClick={() => setTab(value)}>{value === 'setup' ? 'Setup status' : value[0]!.toUpperCase() + value.slice(1)}</button>)}</div></>}
            <fieldset disabled={locked || !!draft.retiredAt} id="floor-section" role={creating ? undefined : 'tabpanel'} aria-labelledby={creating ? undefined : `floor-tab-${tab}`}>
              {!creating && tab === 'setup' && (draft.retiredAt ? <p>Restore this floor to check its setup.</p> : <FloorSetup key={draft.id} floorId={draft.id} owner={owner} enabled={enabled} />)}
              {((creating && step === 0) || (!creating && tab === 'settings')) && <FloorDetails key={creating ? 'new' : draft.id} draft={draft} change={setDraft} creating={creating} />}
              {((creating && step === 1) || (!creating && tab === 'repositories')) && <>
                {!creating && <div className="fd-section-heading"><div><h3>{picking ? 'Choose repositories' : 'Repositories'}</h3><p>{picking ? 'Select the sources this floor works with.' : 'These repositories are available on this floor.'}</p></div><Button variant="quiet" type="button"  onClick={() => setPicking(!picking)}><FloorIcon name={picking ? 'check' : 'plus'} />{picking ? 'Done selecting' : 'Add repositories'}</Button></div>}
                {catalog.isPending ? <LoadingState label="Loading available repositories…" size="panel" /> : <FloorRepositories key={`${draft.id}-${creating}`} draft={draft} catalog={catalog.data ?? []} picking={creating || picking} change={setDraft} setup={setSetup} />}
              </>}
              {((creating && step === 2) || (!creating && tab === 'members')) && <FloorMembers draft={draft} change={setDraft} members={directory.data?.members ?? []} />}
            </fieldset>
            {!creating && draft.revision > 0 && tab === 'settings' && <div className="fd-lifecycle"><h3>{draft.retiredAt ? 'Restore this floor' : 'Retire this floor'}</h3><p>{draft.retiredAt ? 'Bring this floor back with its saved sources and records.' : draft.canRetire ? 'Hide it from navigation and keep its settings and records. You can restore it later.' : 'Close or cancel open missions and settle active runs before retiring this floor.'}</p>
              {(draft.retiredAt || draft.canRetire) && !pending && (retiring ? <div className="fd-retire-confirm" role="group" aria-label="Confirm retirement"><p>Retire {draft.name}? Unsaved edits will not be applied.</p><Button type="button"  disabled={locked} onClick={() => void save('retire')}>Confirm retirement</Button><Button variant="quiet" type="button"  onClick={() => setRetiring(false)}>Keep floor</Button></div> : <Button variant="quiet" type="button"  disabled={locked} onClick={() => draft.retiredAt ? void save('restore') : setRetiring(true)}>{draft.retiredAt ? 'Restore floor' : 'Retire floor'}</Button>)}
            </div>}
            {creating && step === 2 && <div className="fd-create-review"><strong>{draft.name}</strong><span>{draft.repositories.length} repositories · {draft.memberProfileIds.length} members</span><p>Creating a floor saves these choices. It does not grant new repository access.</p></div>}
          </div>
          {(creating || dirty || pending || picking) && <footer className="fd-save-bar"><span>{pending ? 'Awaiting a confirmed receipt' : creating && step === 1 ? `${draft.repositories.length} repositories selected` : creating ? 'Nothing is saved until you create the floor' : dirty ? 'Unsaved changes' : 'No changes yet'}</span><div>
            {!pending && <Button variant="quiet" type="button"  disabled={busy} onClick={() => creating && step > 0 ? setStep(step - 1) : cancel()}>{creating && step > 0 ? 'Back' : 'Cancel'}</Button>}
            <Button type="submit" disabled={!enabled || busy || (!pending && (!catalog.data || ((!creating || step === 2) && !draft.memberProfileIds.length) || (!creating && !dirty)))}>{busy ? 'Checking save…' : pending ? 'Check save' : creating ? step === 0 ? 'Continue to repositories' : step === 1 ? 'Continue to members' : 'Create floor' : 'Save changes'}</Button>
          </div></footer>}
          {error && !pending && draft.revision > 0 && <Button variant="quiet" type="button" className="fd-text-button fd-reload" onClick={() => { const saved = directory.data?.floors.find(floor => floor.id === draft.id); if (saved && discardAllowed()) choose(saved); }}>Load saved floor</Button>}
        </form> : !pending && <EmptyState className="fd-empty" level={2} title={<>Your next project starts here</>}  icon={<FloorIcon name="building" />} actions={<><Button disabled={locked} onClick={() => select()}>Create floor</Button></>}>Create a floor to bring its team and repositories together.</EmptyState>}
      </div>
    </div>
  </section>;
}
