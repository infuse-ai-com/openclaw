import type { ScheduleObservation } from '@studio/contracts';

const stamp=(v:string|null)=>v?`${new Date(v).toLocaleString()} · ${Intl.DateTimeFormat().resolvedOptions().timeZone}`:'Not reported';
export function AgentSchedules({data}:{data:ScheduleObservation}){
  return <>
    <p>Scheduled tasks reported by this agent’s OpenClaw Gateway, including disabled and internal tasks. OpenClaw owns execution. Run times below use your local timezone; cron expressions keep their source timezone.</p>
    {!data.tasks.length?<p>No scheduled tasks were reported in this complete snapshot.</p>:<div className="ws-telemetry-table ws-schedules-table" tabIndex={0} role="region" aria-label="Agent scheduled tasks"><table>
      <thead><tr><th>Task</th><th>State</th><th>Schedule</th><th>Next run</th><th>Last run</th><th>Last result</th></tr></thead>
      <tbody>{data.tasks.map(task=><tr key={task.id}>
        <th scope="row"><span>{task.name}</span><small style={{display:'block'}}>{task.id}</small></th>
        <td>{task.enabled?'Enabled':'Disabled'}</td>
        <td>{task.schedule.kind==='cron'?`${task.schedule.expression} · ${task.schedule.timezone??'Gateway timezone not reported'}`:
          task.schedule.kind==='every'?`Every ${new Intl.NumberFormat('en').format(task.schedule.everyMs/1000)} seconds`:`Once · ${stamp(task.schedule.at)}`}</td>
        <td title={task.nextRunAt??undefined}>{task.enabled?stamp(task.nextRunAt):'Disabled'}</td>
        <td title={task.lastRunAt??undefined}>{stamp(task.lastRunAt)}</td><td>{task.lastStatus==='unknown'?'Not reported':task.lastStatus}</td>
      </tr>)}</tbody>
    </table></div>}
  </>;
}
