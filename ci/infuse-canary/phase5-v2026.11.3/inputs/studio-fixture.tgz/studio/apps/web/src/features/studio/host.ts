/** The public OpenClaw 2026.9.7 Control UI surface used by Studio. */
export interface StudioHost {
  readonly connection: { connected: boolean; canRead: boolean; canWrite: boolean };
  request<T = unknown>(method: string, params?: Record<string, unknown>): Promise<T>;
  subscribe(listener: () => void): () => void;
  navigation: {
    openPage(target: { id: string; params?: Readonly<Record<string, string>> }, options?: { replace?: boolean }): void;
    pageHref(target: { id: string; params?: Readonly<Record<string, string>> }): string;
  };
}
export interface StudioContext {
  readonly host: StudioHost;
  readonly signal: AbortSignal;
  readonly props: Readonly<Record<string, string>>;
  readonly presented: boolean;
}
export interface StudioMount {
  update(context: StudioContext): void;
  focus(): void;
  dispose(): void;
}
export interface StudioActivationHost extends StudioHost {
  ui: {
    registerPage(page: { id: string; label: string; mount(container: HTMLElement, context: StudioContext): StudioMount }): () => void;
    registerNavigation(item: { id: string; label: string; page: { id: string }; order?: number }): () => void;
  };
}
