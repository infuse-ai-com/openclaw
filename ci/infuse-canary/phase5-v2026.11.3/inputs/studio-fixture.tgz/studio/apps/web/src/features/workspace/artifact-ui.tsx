import { icons } from '@studio/ui/icons';
import type { ArtifactDetail, ArtifactManifest } from '@studio/contracts';

export function ArtifactIcon({ name }: { name: keyof typeof icons }) {
  return <span className="ws-artifact-icon" aria-hidden="true" dangerouslySetInnerHTML={{ __html: icons[name] }} />;
}

export function ArtifactSymbol({ manifest }: { manifest: ArtifactManifest }) {
  const image = manifest.files.some(file => /^(image\/(png|jpeg|gif|webp))$/.test(file.mediaType));
  const html = manifest.files.some(file => file.mediaType === 'text/html');
  return <span className="ws-artifact-symbol" data-format={image ? 'image' : html ? 'html' : 'file'}>
    <ArtifactIcon name={image ? 'image' : html ? 'desktop' : 'document'} />
  </span>;
}

export function ArtifactDate({ value }: { value: string }) {
  return <time dateTime={value} title={new Date(value).toISOString().replace('T', ' ').replace('.000Z', ' UTC')}>
    {new Intl.DateTimeFormat('en', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(value))}
  </time>;
}

export function ArtifactVersion({revisions, revision, onChange}: {revisions:ArtifactDetail['revisions'];revision:string;onChange(revision:string):void}) {
  // Registry history is in publication order; dates can tie.
  const newestFirst = [...revisions].reverse();
  if (newestFirst.length < 2) return <div className="ws-artifact-single-value"><span>Version</span><strong>Latest</strong></div>;
  return <label className="ws-artifact-revision"><span>Version</span><select className="ui-control" aria-label="Revision" value={revision} onChange={e => onChange(e.target.value)}>
    {newestFirst.map((item,i) => <option key={item.revision} value={item.revision}>{i === 0 ? 'Latest' : 'Previous'} · v{newestFirst.length-i} · {new Intl.DateTimeFormat('en',{dateStyle:'medium',timeZone:'UTC'}).format(new Date(item.createdAt))}</option>)}
  </select></label>;
}
