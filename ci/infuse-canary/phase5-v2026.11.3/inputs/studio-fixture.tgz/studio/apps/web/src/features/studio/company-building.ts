import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { createBuildingExterior, createDirectoryKiosk, STOREY_HEIGHT } from '@studio/spatial/building';
import { createNeighborhood, officeDaylight } from '@studio/spatial/neighborhood';
import { createOfficeSky } from './office-sky.js';
import brand from '../../../../../packages/ui/assets/INFUSE_horizontal_for_dark_background.png';
import { icons } from '@studio/ui/icons';
import type { Finish } from '@studio/spatial/office';

export type CompanyProject = { id: string; name: string };

/** Presentation only: the session owns project admission; there is no simulated company state. */
export function createCompanyBuilding(host: HTMLElement, projects: CompanyProject[], enter: (id: string) => void, unavailable: () => void, manage?: () => void) {
  const scene = new THREE.Scene(), root = new THREE.Group(); scene.add(root);
  const camera = new THREE.OrthographicCamera(-15, 15, 15, -15, .1, projects.length * STOREY_HEIGHT + 150);
  const labels = document.createElement('div'); labels.className = 'ws-building-labels';
  const finishes = new Map<number | string, THREE.Material>();
  const ownedMaterials: THREE.Material[] = [], textures: THREE.Texture[] = [];
  const entries: { element: HTMLElement; position: THREE.Vector3 }[] = [];
  let renderer: THREE.WebGLRenderer | undefined, controls: OrbitControls | undefined;
  let composer: EffectComposer | undefined, ao: SSAOPass | undefined, output: OutputPass | undefined;
  let environment: THREE.WebGLRenderTarget | undefined, exterior: ReturnType<typeof createBuildingExterior> | undefined;
  let observer: ResizeObserver | undefined, frame = 0, disposed = false, presented = true;
  let sky: ReturnType<typeof createOfficeSky> | undefined, lightning: THREE.DirectionalLight | undefined;
  let directory: ReturnType<typeof createDirectoryKiosk> | undefined;
  let directoryEntry: HTMLButtonElement | undefined;
  let thunderstorm = false;
  let neighborhood: ReturnType<typeof createNeighborhood> | undefined;
  let sun: THREE.DirectionalLight | undefined, skyLight: THREE.HemisphereLight | undefined, fill: THREE.DirectionalLight | undefined;
  let moving = false, elapsed = 0, previousFrame = 0, lastPaint = 0;
  let hours = new Date().getHours() + new Date().getMinutes() / 60;
  const total = projects.length * STOREY_HEIGHT;
  const target = new THREE.Vector3(0, total / 2 + 3.5, 0), offset = new THREE.Vector3(-14, 13, 30);
  const projected = new THREE.Vector3(), ray = new THREE.Raycaster(), pointer = new THREE.Vector2();
  const selected = (id: string) => { if (projects.some(project => project.id === id)) enter(id); };

  function box(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, finish: Finish, cast = true) {
    let material: THREE.Material;
    if (finish instanceof THREE.Material) material = finish;
    else {
      const key = finish instanceof THREE.Color ? finish.getHex() : finish;
      if (!finishes.has(key)) finishes.set(key, new THREE.MeshStandardMaterial({ color: finish, roughness: .86 }));
      material = finishes.get(key)!;
    }
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
    mesh.position.set(x, y, z); mesh.castShadow = cast; mesh.receiveShadow = true; parent.add(mesh); return mesh;
  }
  function addLabel(text: string, position: THREE.Vector3, click: () => void, className = '') {
    const element = document.createElement('button'); element.type = 'button'; element.className = `ws-building-entry ${className}`;
    element.textContent = text; element.onclick = click;
    element.addEventListener('pointerdown', event => event.stopPropagation());
    labels.append(element); entries.push({ element, position }); return element;
  }
  function draw(timestamp: number) {
    frame = 0;
    if (disposed || !presented || document.hidden || !composer || !host.isConnected) return;
    if (moving && previousFrame) elapsed += Math.min((timestamp - previousFrame) / 1000, .1);
    previousFrame = timestamp;
    // Ambient traffic is capped at 30fps; a stopped scene draws only on changes.
    if (moving && timestamp - lastPaint < 32) { queueDraw(); return; }
    lastPaint = timestamp;
    neighborhood?.animate(elapsed);
    if (lightning) lightning.intensity = (sky?.animate(elapsed) ?? 0) * 1.35;
    ao!.ssaoMaterial.uniforms.cameraProjectionMatrix!.value.copy(camera.projectionMatrix);
    ao!.ssaoMaterial.uniforms.cameraInverseProjectionMatrix!.value.copy(camera.projectionMatrixInverse);
    composer.render();
    for (const entry of entries) {
      projected.copy(entry.position).project(camera);
      const x = (projected.x * .5 + .5) * host.clientWidth, y = (-projected.y * .5 + .5) * host.clientHeight;
      // Keep equivalent HTML entrances reachable even when the camera is panned away.
      const directoryLabel = entry.element === directoryEntry;
      const edge = directoryLabel ? 30 : 24;
      entry.element.style.left = `${Math.max(edge, Math.min(host.clientWidth - edge, x))}px`;
      entry.element.style.top = `${Math.max(directoryLabel ? 150 : 96, Math.min(host.clientHeight - 90, y))}px`;
    }
    if (moving) queueDraw();
  }
  function queueDraw() { if (!disposed && presented && !document.hidden && !frame) frame = requestAnimationFrame(draw); }
  function resize() {
    if (!renderer || !composer || !host.clientWidth || !host.clientHeight) return;
    const w = host.clientWidth, h = host.clientHeight, span = Math.max(35, total + 20, (w < 760 ? 30 : 47) * h / w);
    renderer.setSize(w, h, false); composer.setSize(w, h);
    camera.left = -span * w / h / 2; camera.right = -camera.left; camera.top = span / 2; camera.bottom = -span / 2;
    camera.updateProjectionMatrix(); queueDraw();
  }
  function fit() { controls?.target.copy(target); camera.position.copy(target).add(offset); camera.zoom = 1; camera.updateProjectionMatrix(); controls?.update(); queueDraw(); }
  function zoom(delta: number) { camera.zoom = THREE.MathUtils.clamp(camera.zoom + delta, .65, 2.1); camera.updateProjectionMatrix(); queueDraw(); }
  function keydown(event: KeyboardEvent) {
    if (event.target !== renderer?.domElement || !controls) return;
    const movement: Record<string, [number, number]> = { ArrowLeft: [-.5, 0], ArrowRight: [.5, 0], ArrowUp: [0, -.5], ArrowDown: [0, .5] };
    if (movement[event.key]) {
      event.preventDefault(); const [x, z] = movement[event.key]!; controls.target.x += x; controls.target.z += z; controls.update(); queueDraw();
    } else if (['+', '=', '-', 'Home'].includes(event.key)) { event.preventDefault(); if (event.key === 'Home') fit(); else zoom(event.key === '-' ? -.15 : .15); }
  }
  const visibility = () => { previousFrame = 0; if (document.hidden) { cancelAnimationFrame(frame); frame = 0; } else queueDraw(); };
  const cameraClick = (event: MouseEvent) => {
    const control = event.target instanceof Element ? event.target.closest<HTMLElement>('[data-building-camera]')?.dataset.buildingCamera : undefined;
    if (control === 'fit') fit(); else if (control === 'in') zoom(.15); else if (control === 'out') zoom(-.15);
  };
  host.parentElement!.addEventListener('click', cameraClick); host.addEventListener('keydown', keydown);
  document.addEventListener('visibilitychange', visibility);
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5)); renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.VSMShadowMap; renderer.shadowMap.autoUpdate = false;
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.03; renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.setClearColor(0x02080b, 0);
    const canvas = renderer.domElement; canvas.tabIndex = 0; canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', 'Company building. Arrow keys pan; plus and minus zoom; Home fits. Named project entrances open their floors.');
    host.append(canvas, labels); sky = createOfficeSky(host);
    controls = new OrbitControls(camera, canvas); controls.enableRotate = false; controls.enableDamping = false;
    controls.minZoom = .65; controls.maxZoom = 2.1; controls.screenSpacePanning = false;
    controls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
    controls.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_PAN };
    controls.addEventListener('change', () => {
      const before = controls!.target.clone(); controls!.target.x = THREE.MathUtils.clamp(before.x, -8, 8); controls!.target.z = THREE.MathUtils.clamp(before.z, -5, 5); controls!.target.y = target.y;
      camera.position.add(controls!.target.clone().sub(before)); queueDraw();
    });
    skyLight = new THREE.HemisphereLight(0xf5f2e9, 0x746b60, .65); scene.add(skyLight);
    const pmrem = new THREE.PMREMGenerator(renderer), room = new RoomEnvironment(); environment = pmrem.fromScene(room, .04); room.dispose(); pmrem.dispose();
    scene.environment = environment.texture; scene.environmentIntensity = .12;
    sun = new THREE.DirectionalLight(0xffecd6, 3.25); sun.position.set(-7, 15, 6); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -44, right: 44, top: total + 32, bottom: -38, near: .5, far: total + 130 });
    sun.shadow.bias = -.00015; sun.shadow.normalBias = .018; sun.shadow.radius = 3; sun.shadow.blurSamples = 8; scene.add(sun);
    lightning = new THREE.DirectionalLight(0xb6d5ff, 0); lightning.position.set(-12, 32, 16); scene.add(lightning);
    fill = new THREE.DirectionalLight(0xdce9f0, .42); fill.position.set(15, 12, -10); scene.add(fill);
    exterior = createBuildingExterior({ box, ownedMaterials, textures, fontFamily: 'StudioPlex' });
    const floors = projects.map((project, index) => ({ id: project.id, title: project.name, number: String(index + 1).padStart(2, '0') })).toReversed();
    exterior.build(root, floors, addLabel, ({ floor }) => selected(floor));
    if (manage) {
      const brandMap = new THREE.TextureLoader().load(brand, () => queueDraw()); brandMap.colorSpace = THREE.SRGBColorSpace; textures.push(brandMap);
      directory = createDirectoryKiosk({ root, box, ownedMaterials, brandMap });
      directoryEntry = addLabel('', directory.position, manage, 'ws-directory-entry');
      directoryEntry.setAttribute('aria-label', 'Manage floors');
      directoryEntry.title = 'Manage floors';
      // Only bundled Tabler artwork crosses this markup boundary.
      const icon = document.createElement('span'); icon.className = 'ws-glyph'; icon.setAttribute('aria-hidden', 'true'); icon.innerHTML = icons.building;
      directoryEntry.append(icon);
      for (const type of ['pointerenter', 'focus']) directoryEntry.addEventListener(type, () => { directory?.highlight(true); queueDraw(); });
      for (const type of ['pointerleave', 'blur']) directoryEntry.addEventListener(type, () => { directory?.highlight(false); queueDraw(); });
    }
    neighborhood = createNeighborhood({ root, box, ownedMaterials, textures });
    setAtmosphere(hours, moving);
    composer = new EffectComposer(renderer); composer.renderTarget1.samples = composer.renderTarget2.samples = Math.min(4, renderer.capabilities.maxSamples);
    ao = new SSAOPass(scene, camera, 512, 512, 16); ao.kernelRadius = .52; ao.minDistance = .0015; ao.maxDistance = .12;
    ao.ssaoMaterial.defines.PERSPECTIVE_CAMERA = 0; ao.depthRenderMaterial.defines.PERSPECTIVE_CAMERA = 0;
    composer.addPass(new RenderPass(scene, camera)); composer.addPass(ao); output = new OutputPass(); composer.addPass(output);
    let down: { x: number; y: number } | undefined;
    const hit = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect(); pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
      ray.setFromCamera(pointer, camera); const mesh = ray.intersectObject(root, true)[0]?.object;
      for (let item: THREE.Object3D | null | undefined = mesh; item; item = item.parent) { if (item.userData.directory === true) return { kind: 'directory' as const }; if (typeof item.userData.floor === 'string') return { kind: 'floor' as const, id: item.userData.floor as string }; }
      return undefined;
    };
    canvas.addEventListener('pointerdown', event => { down = { x: event.clientX, y: event.clientY }; });
    canvas.addEventListener('pointerup', event => { if (down && Math.hypot(event.clientX - down.x, event.clientY - down.y) <= 7) { const target = hit(event); if (target?.kind === 'directory') manage?.(); else if (target?.kind === 'floor') selected(target.id); } down = undefined; });
    canvas.addEventListener('pointermove', event => { const target = hit(event); exterior!.highlight(target?.kind === 'floor' ? target.id : null); directory?.highlight(target?.kind === 'directory'); directoryEntry?.classList.toggle('is-highlighted', target?.kind === 'directory'); canvas.style.cursor = target ? 'pointer' : 'grab'; queueDraw(); });
    canvas.addEventListener('pointerleave', () => { exterior!.highlight(null); directory?.highlight(false); directoryEntry?.classList.remove('is-highlighted'); down = undefined; queueDraw(); });
    // Native entrance hover/focus changes the shared outline; repaint on those events too.
    for (const entry of entries) for (const type of ['pointerenter', 'pointerleave', 'focus', 'blur']) entry.element.addEventListener(type, queueDraw);
    canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); unavailable(); });
    observer = new ResizeObserver(resize); observer.observe(host); fit(); resize(); host.dataset.webgl = 'ready';
  } catch { unavailable(); }
  function setAtmosphere(hour: number, animate: boolean, storm = false) {
    hours = hour; moving = animate; thunderstorm = storm; previousFrame = 0;
    const light = officeDaylight(hour);
    host.style.background = `radial-gradient(ellipse at 45% 64%, ${light.horizon.getStyle()} 0%, ${light.sky.getStyle()} 85%)`;
    sky?.update(light, thunderstorm, moving);
    if (sun && skyLight && fill && renderer) {
      sun.color.copy(light.sun); sun.intensity = light.sunlight * (thunderstorm ? .38 : 1);
      const angle = (light.hour - 6) / 14 * Math.PI;
      sun.position.set(-Math.cos(angle) * 30, 12 + light.elevation * 30, 18).lerp(new THREE.Vector3(-18, 28, 10), light.night);
      skyLight.intensity = light.ambient * (thunderstorm ? .7 : 1); skyLight.color.copy(light.horizon);
      fill.intensity = .3 - light.night * .08; scene.environmentIntensity = .12 - light.night * .06;
      renderer.toneMappingExposure = 1.03 - light.night * .12;
      renderer.shadowMap.needsUpdate = true;
      neighborhood?.setNight(light.night); exterior?.setNight(light.night);
    }
    host.dataset.lighting = light.night > .8 ? 'night' : light.night > .15 ? 'twilight' : 'day';
    host.dataset.motion = moving ? 'running' : 'paused';
    if (lightning && (!moving || !thunderstorm)) lightning.intensity = 0;
    queueDraw();
  }
  const parent = host.parentElement!;
  return {
    setAtmosphere,
    setPresented(value: boolean) { presented = value; previousFrame = 0; if (value) { resize(); queueDraw(); } else { cancelAnimationFrame(frame); frame = 0; } },
    dispose() {
      if (disposed) return; disposed = true; cancelAnimationFrame(frame); observer?.disconnect(); controls?.dispose();
      parent.removeEventListener('click', cameraClick); host.removeEventListener('keydown', keydown); document.removeEventListener('visibilitychange', visibility);
      const geometries = new Set<THREE.BufferGeometry>(); root.traverse(item => { if (item instanceof THREE.Mesh) geometries.add(item.geometry); if (item instanceof THREE.InstancedMesh) item.dispose(); }); geometries.forEach(geometry => geometry.dispose());
      exterior?.dispose(); finishes.forEach(material => material.dispose()); ownedMaterials.forEach(material => material.dispose()); textures.forEach(texture => texture.dispose());
      sun?.shadow.dispose(); environment?.dispose(); ao?.noiseTexture.dispose(); ao?.ssaoMaterial.dispose(); ao?.dispose(); output?.dispose(); composer?.dispose(); renderer?.dispose(); host.replaceChildren();
    },
  };
}
