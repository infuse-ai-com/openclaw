import { Button, IconButton } from '../../../ui.js';
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
} from 'react';
import type {
  Document,
  DocumentDiff,
  History,
  RelationshipEdge,
  RelationshipNode,
  Relationships,
  Repository,
} from '@studio/contracts/knowledge';
import type {
  ReaderTextSize,
  ReaderWidth,
  Theme,
} from '../useDisplayPreferences';
import { findRenderedHeading } from '../headingTargets';
import { HistoryTimeline } from './HistoryTimeline';
import { ReadingSettings } from './ReadingSettings';

export type ContextMode = 'contents' | 'relationships' | 'history';
export type SidePanel = 'closed' | 'context' | 'inspect' | 'settings';
export type SheetDetent = 'collapsed' | 'expanded';

interface DocumentPanelProps {
  readerOnly?: boolean;
  baseCommit: string;
  comparison: DocumentDiff | undefined;
  comparisonActive: boolean;
  compact: boolean;
  contextMode: ContextMode;
  detent: SheetDetent;
  document: Document | undefined;
  focusReader: boolean;
  focusAvailable: boolean;
  headCommit: string;
  history: History | undefined;
  historyError: boolean;
  onBaseCommitChange: (commit: string) => void;
  onClose: () => void;
  onCompare: () => void;
  onContextModeChange: (mode: ContextMode) => void;
  onDetentChange: (detent: SheetDetent) => void;
  onExploreGraph: () => void;
  onHeadCommitChange: (commit: string) => void;
  onMarkReviewed: () => void;
  onOpenRelated: (path: string) => void;
  onPrepareCompare: (commit: string) => void;
  onReviewChanges: () => void;
  onReaderWidthChange: (width: ReaderWidth) => void;
  onResetDisplayPreferences: () => void;
  onRetryHistory: () => void;
  onTextSizeChange: (size: ReaderTextSize) => void;
  onThemeChange: (theme: Theme) => void;
  onToggleFocus: () => void;
  readerTextSize: ReaderTextSize;
  readerWidth: ReaderWidth;
  relationships: Relationships | undefined;
  reviewError: boolean;
  reviewPending: boolean;
  repository: Repository | undefined;
  restoreDiffFocus: boolean;
  sidePanel: Exclude<SidePanel, 'closed'>;
  theme: Theme;
}

function formatTime(value: string): string {
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value));
}

type TocItem = Document['toc'][number];

interface OutlineNode {
  children: OutlineNode[];
  item: TocItem;
}

function buildOutline(items: readonly TocItem[]): OutlineNode[] {
  const roots: OutlineNode[] = [];
  const stack: { depth: number; node: OutlineNode }[] = [];

  items.forEach((item) => {
    const node = { children: [], item } satisfies OutlineNode;
    while (stack.at(-1) && (stack.at(-1)?.depth ?? 0) >= item.depth) {
      stack.pop();
    }
    const parent = stack.at(-1)?.node;
    if (parent) parent.children.push(node);
    else roots.push(node);
    stack.push({ depth: item.depth, node });
  });

  return roots;
}

function useActiveHeading(document: Document | undefined): string | undefined {
  const [activeHeading, setActiveHeading] = useState<string>();

  useEffect(() => {
    const toc = document?.toc ?? [];
    if (toc.length === 0) {
      setActiveHeading(undefined);
      return;
    }

    const hashHeading = decodeURIComponent(globalThis.location.hash.slice(1));
    setActiveHeading(
      toc.some((item) => item.id === hashHeading) ? hashHeading : toc[0]?.id,
    );

    const reader =
      globalThis.document.querySelector<HTMLElement>(
        '.semantic-reader-portal',
      ) ?? globalThis.document.querySelector<HTMLElement>('.reader-panel');
    if (!reader) return;

    let frame = 0;
    const update = () => {
      const useWindowScroll =
        globalThis.getComputedStyle(reader).overflowY === 'visible';
      const scrollPosition = useWindowScroll
        ? globalThis.scrollY
        : reader.scrollTop;
      const rootTop = useWindowScroll ? 0 : reader.getBoundingClientRect().top;
      const threshold = rootTop + 112;
      let nextHeading = toc[0]?.id;

      if (scrollPosition > 24) {
        for (const item of toc) {
          const heading = findRenderedHeading(item.id);
          if (!heading?.offsetParent) continue;
          if (heading.getBoundingClientRect().top > threshold) break;
          nextHeading = item.id;
        }
      }

      setActiveHeading((current) =>
        current === nextHeading ? current : nextHeading,
      );
    };
    const scheduleUpdate = () => {
      globalThis.cancelAnimationFrame(frame);
      frame = globalThis.requestAnimationFrame(update);
    };

    reader.addEventListener('scroll', scheduleUpdate, { passive: true });
    globalThis.addEventListener('scroll', scheduleUpdate, { passive: true });
    globalThis.addEventListener('resize', scheduleUpdate);
    globalThis.addEventListener('hashchange', scheduleUpdate);
    scheduleUpdate();

    return () => {
      globalThis.cancelAnimationFrame(frame);
      reader.removeEventListener('scroll', scheduleUpdate);
      globalThis.removeEventListener('scroll', scheduleUpdate);
      globalThis.removeEventListener('resize', scheduleUpdate);
      globalThis.removeEventListener('hashchange', scheduleUpdate);
    };
  }, [document]);

  return activeHeading;
}

function OutlineList({
  activeHeading,
  nodes,
  onNavigate,
}: {
  activeHeading: string | undefined;
  nodes: readonly OutlineNode[];
  onNavigate: (heading: string) => void;
}) {
  return (
    <ol className="context-outline-list">
      {nodes.map(({ children, item }) => (
        <li key={item.id}>
          <a
            aria-current={activeHeading === item.id ? 'location' : undefined}
            href={`#${item.id}`}
            onClick={(event) => {
              event.preventDefault();
              onNavigate(item.id);
            }}
          >
            {item.text}
          </a>
          {children.length > 0 && (
            <OutlineList
              activeHeading={activeHeading}
              nodes={children}
              onNavigate={onNavigate}
            />
          )}
        </li>
      ))}
    </ol>
  );
}

function relationshipLabel(count: number, singular: string): string {
  return `${String(count)} ${singular}${count === 1 ? '' : 's'}`;
}

function localKnowledgeReference(
  documentPath: string,
  reference: string,
): string | undefined {
  if (/^https:\/\//i.test(reference)) return undefined;
  const directory = documentPath.split('/').slice(0, -1).join('/');
  const base = `https://atlas.invalid/${directory ? `${directory}/` : ''}`;
  const resolved = new URL(reference, base);
  return decodeURIComponent(resolved.pathname.replace(/^\//, ''));
}

function KnowledgeReference({
  documentPath,
  label,
  onOpen,
  reference,
}: {
  documentPath: string;
  label: string;
  onOpen: (path: string) => void;
  reference: string;
}) {
  const localPath = localKnowledgeReference(documentPath, reference);
  if (localPath) {
    return (
      <button
        className="knowledge-reference"
        onClick={() => onOpen(localPath)}
        type="button"
      >
        <span>{label}</span>
        <small>{reference}</small>
      </button>
    );
  }
  return (
    <a
      className="knowledge-reference"
      href={reference}
      rel="noreferrer"
      target="_blank"
    >
      <span>{label}</span>
      <small>{reference}</small>
    </a>
  );
}

function RelationshipRow({
  direction,
  edge,
  node,
  onOpen,
}: {
  direction: 'backlink' | 'outgoing';
  edge: RelationshipEdge;
  node: RelationshipNode | undefined;
  onOpen: (path: string) => void;
}) {
  const directionIcon = direction === 'outgoing' ? '↗' : '↙';
  const directionLabel =
    direction === 'outgoing' ? 'Outgoing link' : 'Backlink';

  if (edge.status === 'resolved' && node) {
    return (
      <button
        aria-label={`Open ${directionLabel.toLowerCase()} ${node.title}`}
        className="relationship-row"
        onClick={() => onOpen(node.path)}
        type="button"
      >
        <span aria-hidden="true" className="relationship-direction">
          {directionIcon}
        </span>
        <span className="relationship-copy">
          <span className="relationship-kind">{directionLabel}</span>
          <strong>{node.title}</strong>
          <small>
            {node.repository} / {node.path}
          </small>
        </span>
        <span aria-hidden="true" className="relationship-chevron">
          ›
        </span>
      </button>
    );
  }

  return (
    <div
      className={`relationship-row relationship-row-static ${
        edge.status === 'unresolved' ? 'broken-link' : 'external-relationship'
      }`}
    >
      <span aria-hidden="true" className="relationship-direction">
        {directionIcon}
      </span>
      <span className="relationship-copy">
        <span className="relationship-kind">{directionLabel}</span>
        <strong>
          {edge.status === 'unresolved'
            ? 'Broken link'
            : edge.status === 'external'
              ? 'External destination'
              : 'Unavailable document'}
        </strong>
        <small>{edge.rawTarget}</small>
      </span>
    </div>
  );
}

export function DocumentPanel(props: DocumentPanelProps) {
  const panelRef = useRef<HTMLElement>(null);
  const relationshipNodes = useMemo(
    () => new Map(props.relationships?.nodes.map((node) => [node.path, node])),
    [props.relationships],
  );
  const outgoing =
    props.relationships?.edges.filter(
      (edge) => edge.sourcePath === props.document?.path,
    ) ?? [];
  const backlinks =
    props.relationships?.edges.filter(
      (edge) =>
        edge.status === 'resolved' &&
        edge.targetPath === props.document?.path &&
        edge.sourcePath !== props.document.path,
    ) ?? [];

  useEffect(() => {
    if (!props.compact) return;
    const frame = globalThis.requestAnimationFrame(() => {
      panelRef.current?.querySelector<HTMLElement>('button')?.focus();
    });
    return () => globalThis.cancelAnimationFrame(frame);
  }, [props.compact, props.sidePanel]);

  function handleKeyDown(event: KeyboardEvent<HTMLElement>) {
    if (event.key === 'Escape') {
      event.preventDefault();
      props.onClose();
      return;
    }
    if (!props.compact || event.key !== 'Tab') return;
    const focusable = panelRef.current?.querySelectorAll<HTMLElement>(
      'a[href], button:not(:disabled), select:not(:disabled)',
    );
    if (!focusable?.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && globalThis.document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && globalThis.document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  }

  const content =
    props.sidePanel === 'context' ? (
      <ContextContent
        readerOnly={props.readerOnly}
        contextMode={props.contextMode}
        document={props.document}
        history={props.history}
        historyError={props.historyError}
        onContextModeChange={props.onContextModeChange}
        onExploreGraph={props.onExploreGraph}
        onOpenRelated={props.onOpenRelated}
        onPrepareCompare={props.onPrepareCompare}
        onMarkReviewed={props.onMarkReviewed}
        onReviewChanges={props.onReviewChanges}
        onRetryHistory={props.onRetryHistory}
        outgoing={outgoing}
        backlinks={backlinks}
        historyCount={props.history?.entries.length}
        relationshipCount={
          props.relationships ? outgoing.length + backlinks.length : undefined
        }
        relationshipNodes={relationshipNodes}
        reviewError={props.reviewError}
        reviewPending={props.reviewPending}
      />
    ) : props.sidePanel === 'inspect' ? (
      <InspectContent {...props} />
    ) : (
      <ReadingSettings
        focusAvailable={props.focusAvailable}
        focusReader={props.focusReader}
        onReaderWidthChange={props.onReaderWidthChange}
        onResetDisplayPreferences={props.onResetDisplayPreferences}
        onTextSizeChange={props.onTextSizeChange}
        onThemeChange={props.onThemeChange}
        onToggleFocus={props.onToggleFocus}
        readerTextSize={props.readerTextSize}
        readerWidth={props.readerWidth}
        theme={props.theme}
      />
    );

  const panelLabels = {
    context: {
      ariaLabel: 'Document contents',
      title: 'Contents',
    },
    inspect: { ariaLabel: 'Source details', title: 'Source evidence' },
    settings: { ariaLabel: 'Reading settings', title: 'Reading' },
  } as const;
  const panelLabel =
    props.sidePanel === 'inspect' && props.comparisonActive
      ? { ariaLabel: 'Inspect document', title: 'Revision evidence' }
      : panelLabels[props.sidePanel];

  const panel = (
    <aside
      id="knowledge-document-tools"
      aria-label={panelLabel.ariaLabel}
      aria-modal={props.compact ? 'true' : undefined}
      className={`context-panel document-side-panel atlas-scroll-surface ${props.compact ? 'context-sheet' : ''}`}
      data-detent={props.compact ? props.detent : undefined}
      onKeyDown={handleKeyDown}
      ref={panelRef}
      role={props.compact ? 'dialog' : undefined}
    >
      <div className="side-panel-heading">
        <div>
          <p className="eyebrow">{props.sidePanel}</p>
          <strong>{panelLabel.title}</strong>
        </div>
        <div className="side-panel-actions">
          {props.compact && (
            <Button variant="quiet"
              aria-label={
                props.detent === 'collapsed'
                  ? 'Expand document panel'
                  : 'Collapse document panel'
              }
              onClick={() =>
                props.onDetentChange(
                  props.detent === 'collapsed' ? 'expanded' : 'collapsed',
                )
              }
              type="button"
            >
              {props.detent === 'collapsed' ? 'Expand' : 'Collapse'}
            </Button>
          )}
          <IconButton
            aria-label="Close document panel"
            className="side-panel-close"
            onClick={props.onClose}
            title="Close"
            type="button"
          >
            <span aria-hidden="true">×</span>
          </IconButton>
        </div>
      </div>
      {content}
    </aside>
  );

  return props.compact ? (
    <div className="context-sheet-backdrop" onMouseDown={props.onClose}>
      <div onMouseDown={(event) => event.stopPropagation()}>{panel}</div>
    </div>
  ) : (
    panel
  );
}

interface ContextContentProps {
  readerOnly?: boolean;
  backlinks: NonNullable<Relationships['edges']>;
  contextMode: ContextMode;
  document: Document | undefined;
  history: History | undefined;
  historyCount: number | undefined;
  historyError: boolean;
  onContextModeChange: (mode: ContextMode) => void;
  onExploreGraph: () => void;
  onOpenRelated: (path: string) => void;
  onMarkReviewed: () => void;
  onPrepareCompare: (commit: string) => void;
  onReviewChanges: () => void;
  onRetryHistory: () => void;
  outgoing: NonNullable<Relationships['edges']>;
  relationshipCount: number | undefined;
  relationshipNodes: Map<string, Relationships['nodes'][number]>;
  reviewError: boolean;
  reviewPending: boolean;
}

function ContextContent(props: ContextContentProps) {
  const activeHeading = useActiveHeading(props.document);
  const [requestedHeading, setRequestedHeading] = useState<string>();
  const requestedHeadingTimer = useRef<
    ReturnType<typeof globalThis.setTimeout> | undefined
  >(undefined);
  const outline = useMemo(
    () => buildOutline(props.document?.toc ?? []),
    [props.document],
  );
  const tabs = [
    { label: 'Contents', mode: 'contents' as const },
    {
      count: props.relationshipCount,
      label: 'Relationships',
      mode: 'relationships' as const,
    },
    {
      count: props.historyCount,
      label: 'History',
      mode: 'history' as const,
    },
  ];

  useEffect(
    () => () => globalThis.clearTimeout(requestedHeadingTimer.current),
    [],
  );

  function navigateToHeading(headingId: string) {
    setRequestedHeading(headingId);
    globalThis.clearTimeout(requestedHeadingTimer.current);
    requestedHeadingTimer.current = globalThis.setTimeout(
      () => setRequestedHeading(undefined),
      1200,
    );

    const heading = findRenderedHeading(headingId);
    const reader =
      globalThis.document.querySelector<HTMLElement>(
        '.semantic-reader-portal',
      ) ?? globalThis.document.querySelector<HTMLElement>('.reader-panel');
    if (!heading || !reader) return;
    const reduceMotion = globalThis.matchMedia(
      '(prefers-reduced-motion: reduce)',
    ).matches;
    const behavior = reduceMotion ? 'auto' : 'smooth';
    const useWindowScroll =
      globalThis.getComputedStyle(reader).overflowY === 'visible';
    const headingTop = heading.getBoundingClientRect().top;
    const rootTop = useWindowScroll ? 0 : reader.getBoundingClientRect().top;
    const top =
      (useWindowScroll ? globalThis.scrollY : reader.scrollTop) +
      headingTop -
      rootTop -
      96;

    if (useWindowScroll) globalThis.scrollTo({ behavior, top });
    else reader.scrollTo({ behavior, top });

    if (globalThis.location.hash !== `#${headingId}`) {
      const destination = new URL(globalThis.location.href);
      destination.hash = headingId;
      globalThis.history.pushState({}, '', destination);
    }
  }

  return (
    <>
      <div className="context-tabs" aria-label="Document context views">
        {tabs
          .filter((tab) => !props.readerOnly || tab.mode === 'contents')
          .map(({ count, label, mode }) => (
            <button
              aria-label={
                count === undefined ? label : `${label}, ${String(count)} items`
              }
              aria-pressed={props.contextMode === mode}
              key={mode}
              onClick={() => props.onContextModeChange(mode)}
              type="button"
            >
              <span>{label}</span>
              {count !== undefined && (
                <span
                  aria-hidden="true"
                  className="context-tab-count"
                  data-testid={`context-count-${mode}`}
                >
                  {count}
                </span>
              )}
            </button>
          ))}
      </div>

      {props.contextMode === 'contents' && (
        <>
          {props.document && (
            <section
              className="knowledge-review-card"
              data-review-state={props.document.review.state}
            >
              <p className="eyebrow">Human review</p>
              <strong>
                {props.document.review.state === 'reviewed'
                  ? 'Current version reviewed'
                  : props.document.review.state === 'changed'
                    ? 'Changed since last review'
                    : props.document.review.state === 'overdue'
                      ? 'Review is overdue'
                      : 'No human review yet'}
              </strong>
              {props.document.review.reviewedAt && (
                <small>
                  {props.document.review.reviewerName ?? 'Human reviewer'} ·{' '}
                  {formatTime(props.document.review.reviewedAt)}
                </small>
              )}
              {props.document.review.state === 'changed' &&
                !props.readerOnly && (
                  <button onClick={props.onReviewChanges} type="button">
                    Review changes
                  </button>
                )}
              {!props.readerOnly &&
                props.document.review.canReview &&
                props.document.review.state !== 'reviewed' && (
                  <button
                    disabled={props.reviewPending}
                    onClick={props.onMarkReviewed}
                    type="button"
                  >
                    {props.reviewPending
                      ? 'Recording review…'
                      : 'Finish review'}
                  </button>
                )}
              {props.reviewError && (
                <p className="panel-error" role="alert">
                  The review was not recorded. Reload and try again.
                </p>
              )}
            </section>
          )}
          {props.document && (
            <section className="knowledge-metadata-card">
              <p className="eyebrow">Knowledge metadata</p>
              <dl>
                <div>
                  <dt>Type</dt>
                  <dd>{props.document.metadata.type}</dd>
                </div>
                <div>
                  <dt>Status</dt>
                  <dd>{props.document.metadata.status}</dd>
                </div>
                <div>
                  <dt>Owner</dt>
                  <dd>{props.document.metadata.owner}</dd>
                </div>
              </dl>
              <div className="knowledge-tags">
                {props.document.metadata.tags.map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
              {props.document.metadata.sources.length > 0 && (
                <div className="knowledge-reference-list">
                  <p className="eyebrow">Provenance sources</p>
                  {props.document.metadata.sources.map((source) => (
                    <KnowledgeReference
                      documentPath={props.document?.path ?? ''}
                      key={`${source.role}:${source.ref}`}
                      label={source.role}
                      onOpen={props.onOpenRelated}
                      reference={source.ref}
                    />
                  ))}
                </div>
              )}
              {props.document.metadata.superseded_by && (
                <div className="knowledge-reference-list lifecycle-reference">
                  <p className="eyebrow">Lifecycle</p>
                  <KnowledgeReference
                    documentPath={props.document.path}
                    label="Superseded by"
                    onOpen={props.onOpenRelated}
                    reference={props.document.metadata.superseded_by}
                  />
                </div>
              )}
            </section>
          )}
          <nav
            aria-label="Table of contents"
            className="context-outline"
            data-active-heading={requestedHeading ?? activeHeading}
          >
            <p className="eyebrow">On this page</p>
            {props.document?.toc.length === 0 && (
              <p className="panel-empty">
                This document has no section headings.
              </p>
            )}
            <OutlineList
              activeHeading={requestedHeading ?? activeHeading}
              nodes={outline}
              onNavigate={navigateToHeading}
            />
          </nav>
        </>
      )}

      {props.contextMode === 'relationships' && (
        <div className="relationship-list" data-testid="relationships">
          <div
            aria-label={`${relationshipLabel(props.outgoing.length, 'outgoing link')}, ${relationshipLabel(props.backlinks.length, 'backlink')}`}
            className="relationship-summary"
            data-testid="relationship-summary"
          >
            <span>
              <strong>{props.outgoing.length}</strong> outgoing
            </span>
            <span aria-hidden="true">·</span>
            <span>
              <strong>{props.backlinks.length}</strong>{' '}
              {props.backlinks.length === 1 ? 'backlink' : 'backlinks'}
            </span>
          </div>

          {props.outgoing.length > 0 && (
            <section className="relationship-group">
              <p className="eyebrow">Outgoing links</p>
              {props.outgoing.map((edge) => (
                <RelationshipRow
                  direction="outgoing"
                  edge={edge}
                  key={`${edge.sourceHeadingId}:${edge.rawTarget}`}
                  node={
                    edge.targetPath
                      ? props.relationshipNodes.get(edge.targetPath)
                      : undefined
                  }
                  onOpen={props.onOpenRelated}
                />
              ))}
            </section>
          )}

          {props.backlinks.length > 0 && (
            <section className="relationship-group">
              <p className="eyebrow">Backlinks</p>
              {props.backlinks.map((edge) => (
                <RelationshipRow
                  direction="backlink"
                  edge={edge}
                  key={`${edge.sourcePath}:${edge.rawTarget}`}
                  node={props.relationshipNodes.get(edge.sourcePath)}
                  onOpen={props.onOpenRelated}
                />
              ))}
            </section>
          )}

          {(props.outgoing.length === 0 || props.backlinks.length === 0) && (
            <p className="relationship-empty">
              {props.outgoing.length === 0 && props.backlinks.length === 0
                ? 'No explicit relationships connect this document yet.'
                : props.outgoing.length === 0
                  ? 'No outgoing links from this document.'
                  : 'No documents link back here yet.'}
            </p>
          )}

          {props.document?.metadata.superseded_by && (
            <section className="relationship-group lifecycle-relationship">
              <p className="eyebrow">Lifecycle relationship</p>
              <KnowledgeReference
                documentPath={props.document.path}
                label="Superseded by"
                onOpen={props.onOpenRelated}
                reference={props.document.metadata.superseded_by}
              />
              <small>
                Declared by IKF metadata · not an inferred graph edge
              </small>
            </section>
          )}

          {!props.readerOnly && (
            <button
              className="relationship-explore"
              onClick={props.onExploreGraph}
              type="button"
            >
              <svg aria-hidden="true" viewBox="0 0 20 20">
                <path d="M5 6.5 10 10m0 0 5-4.5M10 10l4 4" />
                <circle cx="4" cy="5.5" r="2" />
                <circle cx="16" cy="4.5" r="2" />
                <circle cx="15" cy="15" r="2" />
                <circle cx="10" cy="10" r="2" />
              </svg>
              <span>Explore in graph</span>
              <span aria-hidden="true">→</span>
            </button>
          )}
        </div>
      )}

      {props.contextMode === 'history' && (
        <div className="history-panel" data-testid="history-panel">
          <HistoryTimeline
            currentPath={props.document?.path}
            error={props.historyError}
            history={props.history}
            onCompareRevision={props.onPrepareCompare}
            onRetry={props.onRetryHistory}
          />
        </div>
      )}
    </>
  );
}

function InspectContent(props: DocumentPanelProps) {
  if (props.comparisonActive) {
    return (
      <div className="inspect-panel" data-testid="inspect-panel">
        <section className="inspect-card revision-evidence">
          <p className="eyebrow">From / To</p>
          <p className="panel-empty">
            Exact immutable sources for the comparison in the center workspace.
          </p>
          {props.comparison ? (
            <>
              <RevisionEvidence label="From" revision={props.comparison.base} />
              <RevisionEvidence label="To" revision={props.comparison.head} />
            </>
          ) : (
            <p className="panel-empty">Preparing immutable sources…</p>
          )}
        </section>
      </div>
    );
  }

  const exactSnapshot = (
    <>
      <dl>
        <div>
          <dt>Repository</dt>
          <dd>{props.repository?.displayName ?? props.document?.repository}</dd>
        </div>
        <div>
          <dt>Owner</dt>
          <dd>{props.repository?.owner ?? 'Not specified'}</dd>
        </div>
        <div>
          <dt>Branch</dt>
          <dd>{props.document?.provenance.branch}</dd>
        </div>
        <div>
          <dt>Commit</dt>
          <dd className="source-fact">{props.document?.provenance.commit}</dd>
        </div>
        <div>
          <dt>Indexed</dt>
          <dd>
            {props.document
              ? formatTime(props.document.provenance.indexedAt)
              : 'Unavailable'}
          </dd>
        </div>
      </dl>
      {props.document?.sourceUrl ? (
        <a
          className="source-action"
          href={props.document.sourceUrl}
          rel="noreferrer"
          target="_blank"
        >
          Open exact source <span aria-hidden="true">↗</span>
        </a>
      ) : (
        <p className="panel-empty">No safe source link is registered.</p>
      )}
    </>
  );

  const comparison =
    props.history && props.history.entries.length > 1 ? (
      <section className="inspect-card compare-controls">
        <p className="eyebrow">Compare revisions</p>
        <RevisionPicker
          commit={props.baseCommit}
          history={props.history}
          label="Base"
          onChange={props.onBaseCommitChange}
        />
        <RevisionPicker
          commit={props.headCommit}
          history={props.history}
          label="Head"
          onChange={props.onHeadCommitChange}
        />
        <button
          autoFocus={props.restoreDiffFocus}
          data-compare-revisions
          key={props.restoreDiffFocus ? 'restore-diff-focus' : 'compare'}
          onClick={props.onCompare}
          type="button"
        >
          Compare revisions
        </button>
      </section>
    ) : null;

  return (
    <div className="inspect-panel" data-testid="inspect-panel">
      <section className="inspect-card">
        <p className="eyebrow">Exact snapshot</p>
        {exactSnapshot}
      </section>
      {comparison}
    </div>
  );
}

function RevisionEvidence({
  label,
  revision,
}: {
  label: 'From' | 'To';
  revision: DocumentDiff['base'];
}) {
  return (
    <article className="revision-evidence-card">
      <span>{label}</span>
      <code>{revision.commit.slice(0, 8)}</code>
      <small>{revision.path}</small>
      {revision.sourceUrl ? (
        <a
          className="source-action"
          href={revision.sourceUrl}
          rel="noreferrer"
          target="_blank"
        >
          Open exact {label.toLowerCase()} source{' '}
          <span aria-hidden="true">↗</span>
        </a>
      ) : (
        <p className="panel-empty">No safe source link is registered.</p>
      )}
    </article>
  );
}

function RevisionPicker({
  commit,
  history,
  label,
  onChange,
}: {
  commit: string;
  history: History;
  label: 'Base' | 'Head';
  onChange: (commit: string) => void;
}) {
  const selected = history.entries.find((entry) => entry.commit === commit);
  return (
    <label className="revision-picker">
      <span>{label}</span>
      <select
        aria-label={`${label} revision`}
        onChange={(event) => onChange(event.target.value)}
        value={commit}
      >
        {history.entries.map((entry) => (
          <option key={entry.commit} value={entry.commit}>
            {entry.commit.slice(0, 8)} — {entry.message}
          </option>
        ))}
      </select>
      {selected && <strong>{selected.message}</strong>}
    </label>
  );
}
