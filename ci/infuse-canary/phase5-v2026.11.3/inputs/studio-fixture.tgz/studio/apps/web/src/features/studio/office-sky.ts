import type { officeDaylight } from '@studio/spatial/neighborhood';
type Daylight = ReturnType<typeof officeDaylight>;

/** A decorative sky behind the canvas. It shares the scene clock and owns no timers. */
export function createOfficeSky(host: HTMLElement) {
  const sky = document.createElement('div'); sky.className = 'ws-office-sky'; sky.setAttribute('aria-hidden', 'true');
  const sun = document.createElement('div'); sun.className = 'ws-office-sun';
  const moon = document.createElement('div'); moon.className = 'ws-office-moon';
  const stars = document.createElement('div'); stars.className = 'ws-office-stars';
  let seed = 781749;
  const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
  for (let index = 0; index < 42; index++) {
    const star = document.createElement('i');
    star.style.left = `${5 + random() * 90}%`; star.style.top = `${4 + random() * 57}%`;
    star.style.opacity = String(.28 + (index % 4) * .16); star.style.width = star.style.height = index % 7 === 0 ? '3px' : '2px';
    stars.append(star);
  }
  const clouds = document.createElement('div'); clouds.className = 'ws-office-storm-clouds';
  const flash = document.createElement('div'); flash.className = 'ws-office-lightning';
  flash.innerHTML = '<svg viewBox="0 0 100 180" focusable="false"><path d="M63 1 42 55 59 49 25 139 47 89 27 96 10 126"/><path d="m43 54-22 17 8 18"/></svg>';
  sky.append(stars, sun, moon, clouds, flash); host.prepend(sky);
  let storm = false, moving = false, elapsed = 0, stormStart = 0;
  return {
    update(light: Daylight, thunderstorm: boolean, animate: boolean) {
      if (thunderstorm !== storm) stormStart = elapsed;
      storm = thunderstorm; moving = animate;
      const phase = Math.max(0, Math.min(1, (light.hour - 6) / 14));
      const elevation = Math.sin(phase * Math.PI);
      sun.style.left = `${24 + phase * 44}%`; sun.style.top = `calc(90px + ${(1 - elevation) * 8}%)`;
      sun.style.opacity = String(light.sunVisibility * (storm ? .13 : 1));
      sun.style.setProperty('--sun-color', light.sun.getStyle());
      moon.style.opacity = String(light.night * (storm ? .25 : 1));
      stars.style.opacity = String(light.night * (storm ? .2 : 1));
      clouds.style.opacity = storm ? '.94' : '0';
      sky.dataset.weather = storm ? 'storm' : 'clear';
      sky.dataset.celestial = light.sunVisibility > .1 ? 'sun' : 'moon';
      if (!storm || !moving) flash.style.opacity = '0';
    },
    animate(seconds: number) {
      elapsed = seconds;
      if (!storm || !moving) return 0;
      // One gentle pulse every thirteen seconds; no strobe or independent CSS loop.
      const stormTime = Math.max(0, elapsed - stormStart), phase = (stormTime + 10) % 13;
      const strength = phase < .9 ? Math.sin(phase / .9 * Math.PI) : 0;
      flash.style.opacity = String(strength * .82);
      flash.style.left = `${Math.floor((stormTime + 10) / 13) % 2 === 0 ? 36 : 58}%`;
      return strength;
    },
  };
}
