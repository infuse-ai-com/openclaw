import { useEffect, useRef, useState } from 'react';
import { LoadingState } from './loading.js';
import { createStudioSpace, type AgentScreenAnchor, type StudioSpace } from '../studio/spatial.js';
import type { SpatialDestination, SpatialProjection } from '../studio/spatial-projection.js';
import type { ExplorerSummary, FloorNavigation } from '../studio/floor-explorer.js';

/** Three owns this isolated subtree; React owns the rest of the workspace. */
export function WorkspaceScene({ projection, shown, onNavigate, now, projectName, selected, onAgentSelect, onAgentAnchor, onBackgroundClick, floorNavigation, floorSummary }: {
  floorNavigation: FloorNavigation; floorSummary: ExplorerSummary;
  onBackgroundClick(): void;
  onAgentAnchor(anchor: AgentScreenAnchor | null): void;
  now: Date; projectName: string; selected: string | null; onAgentSelect(key: string): void;
  projection: SpatialProjection; shown: boolean; onNavigate(destination: SpatialDestination): void;
}) {
  const root = useRef<HTMLDivElement>(null);
  const scene = useRef<StudioSpace | undefined>(undefined);
  const [loading,setLoading]=useState(true);
  const navigate = useRef(onNavigate); navigate.current = onNavigate;
  const choose=useRef(onAgentSelect);choose.current=onAgentSelect;
  const dismiss=useRef(onBackgroundClick);dismiss.current=onBackgroundClick;
  const anchor=useRef(onAgentAnchor);anchor.current=onAgentAnchor;
  const latest = useRef(projection); latest.current = projection;
  const navigation=useRef(floorNavigation);navigation.current=floorNavigation;
  const projectKey=JSON.stringify([floorNavigation.projectId,floorNavigation.projects]);
  useEffect(() => {
    setLoading(true);
    const space = createStudioSpace(destination => navigate.current(destination), { activity:'Project activity', evidence:'Review' }, {living:true,projectName,
      floorNavigation:{...navigation.current,enter:id=>navigation.current.enter(id),changed:id=>navigation.current.changed(id)},
      onAgentSelect:key=>choose.current(key),onAgentAnchor:value=>anchor.current(value),onBackgroundClick:()=>dismiss.current(),onSettled:()=>setLoading(false)});
    scene.current = space; root.current!.append(space.element); space.update(latest.current);
    return () => { space.dispose(); scene.current = undefined; };
  }, [projectKey]);
  useEffect(()=>{scene.current?.setFloorSummary(floorSummary);},[floorSummary,projectKey]);
  useEffect(() => { scene.current?.update(projection); }, [projection]);
  useEffect(() => { scene.current?.setPresented(shown); }, [shown,projectKey]);
  useEffect(()=>{scene.current?.setAtmosphere(now);},[now,projectKey]);
  useEffect(()=>{scene.current?.selectAgent(selected);},[selected,projectKey]);
  return <><div className="ws-scene infuse-studio-root" ref={root} aria-hidden={!shown||loading} aria-busy={loading} inert={loading} style={{visibility:loading?'hidden':undefined}} />{loading&&<LoadingState label="Loading project floor…" size="page" overlay />}</>;
}
