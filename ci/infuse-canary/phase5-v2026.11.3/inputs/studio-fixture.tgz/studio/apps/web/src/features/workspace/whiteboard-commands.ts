import {
  whiteboardCommand,
  whiteboardSpatialCommand,
  whiteboardConvert,
  whiteboardRevert,
  whiteboardReceipt,
  type WhiteboardCommand,
  type WhiteboardSpatialCommand,
  type WhiteboardSpatialOperation,
  type WhiteboardReceipt,
} from '@studio/contracts';
import { accessDenied, ApiError, readableError, type api } from './api.js';
import { BoardHistory } from './whiteboard-history.js';
import { persistWhiteboardEnvelope } from './whiteboard-storage.js';

type Version = '1' | '2' | '3';
export type BoardIntent =
  | { kind: 'edit'; version: Version; command: WhiteboardCommand | WhiteboardSpatialCommand }
  | { kind: 'convert'; version: '2'; command: ReturnType<typeof whiteboardConvert.parse> }
  | { kind: 'revert'; version: '3'; command: ReturnType<typeof whiteboardRevert.parse> };
const pendingCommand = whiteboardCommand
  .or(whiteboardSpatialCommand)
  .or(whiteboardConvert)
  .or(whiteboardRevert);

/** Preserve the existing split storage representation, including its legacy version fallback. */
export function readBoardIntent(storage: Storage, key: string): BoardIntent | null {
  try {
    const raw = storage.getItem(key);
    if (!raw) return null;
    const command = pendingCommand.parse(JSON.parse(raw));
    if ('expectedRevision' in command) return { kind: 'convert', version: '2', command };
    if ('targetCommandId' in command) return { kind: 'revert', version: '3', command };
    const version = storage.getItem(key + '.version');
    return { kind: 'edit', version: version === '3' || version === '2' ? version : '1', command };
  } catch {
    return null;
  }
}

export type BoardCommandState = {
  pending: BoardIntent | null;
  phase: 'idle' | 'awaiting-receipt' | 'sending' | 'recovering';
  denied: boolean;
  message: string;
  historyVersion: number;
  resetGeometry: number;
};
export type BoardCommandContext = {
  canSend: boolean;
  csrf: string;
  settled(intent: BoardIntent, receipt: WhiteboardReceipt): void;
  refresh(): Promise<unknown>;
};
type Options = {
  owner: string;
  projectId: string;
  profileId: string;
  path: string;
  storage: Storage;
  request: typeof api;
  context(): BoardCommandContext;
};

/** Owns command custody; neither React rendering nor editor state chooses a wire protocol. */
export class WhiteboardCommands {
  readonly key: string;
  readonly history: BoardHistory;
  private state: BoardCommandState;
  private listeners = new Set<() => void>();
  private active = true;

  constructor(private options: Options) {
    this.key = 'studio.whiteboard.pending:' + options.owner;
    this.history = new BoardHistory('studio.whiteboard.history:' + options.owner, options.storage);
    const pending = readBoardIntent(options.storage, this.key);
    this.state = {
      pending,
      phase: pending ? 'awaiting-receipt' : 'idle',
      denied: false,
      message: pending ? 'A save needs its receipt checked.' : '',
      historyVersion: 0,
      resetGeometry: 0,
    };
  }
  snapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  activate() {
    this.active = true;
  }
  deactivate() {
    this.active = false;
  }
  private update(patch: Partial<BoardCommandState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((listener) => listener());
  }
  private get busy() {
    return this.state.phase === 'sending' || this.state.phase === 'recovering';
  }
  private get available() {
    return this.active && !this.busy && !this.state.denied && this.options.context().canSend;
  }
  setMessage = (message: string) => this.update({ message });
  clear = () => {
    try {
      this.options.storage.removeItem(this.key);
      this.options.storage.removeItem(this.key + '.version');
    } catch {
      /* Hiding private UI must not depend on browser storage. */
    }
    this.update({ pending: null });
  };
  deny = () => {
    this.clear();
    this.update({ denied: true });
  };

  async edit(
    operations: WhiteboardSpatialOperation[],
    scope: { sectionId: string; shared: boolean; spatial: boolean },
  ) {
    if (!this.available || this.state.pending) return;
    let intent: BoardIntent;
    try {
      const spatial =
        scope.spatial ||
        operations.some((op) =>
          ['createSection', 'createHtml', 'createImage', 'updateTile', 'reparent'].includes(
            op.type,
          ),
        );
      const command = spatial
        ? whiteboardSpatialCommand.parse({
            commandId: crypto.randomUUID(),
            sectionId: scope.sectionId,
            operations,
          })
        : whiteboardCommand.parse({ commandId: crypto.randomUUID(), operations });
      intent = { kind: 'edit', version: spatial ? '3' : scope.shared ? '2' : '1', command };
      this.options.storage.setItem(this.key + '.version', intent.version);
      this.history.prepare({
        commandId: command.commandId,
        sectionId: scope.sectionId,
        direction: 'edit',
      });
      persistWhiteboardEnvelope(this.key, command, this.options.storage);
    } catch {
      this.update({
        message:
          'This edit could not be prepared. Check the size limits and allow session storage, then try again.',
        resetGeometry: this.state.resetGeometry + 1,
      });
      return;
    }
    return this.begin(intent);
  }
  async convert(expectedRevision: number) {
    if (!this.available || this.state.pending) return;
    const intent: BoardIntent = {
      kind: 'convert',
      version: '2',
      command: whiteboardConvert.parse({ commandId: crypto.randomUUID(), expectedRevision }),
    };
    try {
      persistWhiteboardEnvelope(this.key, intent.command, this.options.storage);
    } catch {
      this.setMessage(
        'Collaboration could not be prepared. Allow session storage, then try again.',
      );
      return;
    }
    return this.begin(intent);
  }
  async revert(sectionId: string, direction: 'undo' | 'redo') {
    if (!this.available || this.state.pending) return;
    const targetCommandId = this.history.get(sectionId)[direction].at(-1);
    if (!targetCommandId) return;
    const intent: BoardIntent = {
      kind: 'revert',
      version: '3',
      command: whiteboardRevert.parse({ commandId: crypto.randomUUID(), targetCommandId }),
    };
    try {
      this.history.prepare({
        commandId: intent.command.commandId,
        sectionId,
        direction,
        target: targetCommandId,
      });
      this.options.storage.setItem(this.key + '.version', '3');
      persistWhiteboardEnvelope(this.key, intent.command, this.options.storage);
    } catch {
      this.setMessage('Allow session storage before undoing this action.');
      return;
    }
    return this.begin(intent);
  }
  recover = async () => {
    if (!this.available || !this.state.pending) return;
    return this.send(this.state.pending, true);
  };
  private begin(intent: BoardIntent) {
    this.update({ pending: intent });
    return this.send(intent, false);
  }
  private endpoint(intent: BoardIntent) {
    const prefix = this.options.path + (intent.version === '1' ? '' : '/v' + intent.version);
    return (
      prefix +
      (intent.kind === 'convert' ? '/convert' : intent.kind === 'revert' ? '/revert' : '/commands')
    );
  }
  private async finish(value: unknown, intent: BoardIntent) {
    const receipt = whiteboardReceipt.parse(value);
    if (
      receipt.projectId !== this.options.projectId ||
      receipt.commandId !== intent.command.commandId ||
      receipt.actor.kind !== 'human' ||
      receipt.actor.id !== this.options.profileId
    )
      throw Error('The save receipt does not match this edit.');
    if (!this.active) return receipt;
    this.options.context().settled(intent, receipt);
    try {
      this.history.settle(intent.command.commandId, receipt.status === 'applied');
      this.update({ historyVersion: this.state.historyVersion + 1 });
    } catch {
      /* The server receipt remains authoritative if local history is unavailable. */
    }
    this.clear();
    this.setMessage(receipt.status === 'applied' ? 'Saved to this project.' : receipt.message);
    await this.options.context().refresh();
    return receipt;
  }
  private async send(
    intent: BoardIntent,
    recover: boolean,
  ): Promise<WhiteboardReceipt | undefined> {
    if (!this.available) return;
    this.update({
      phase: recover ? 'recovering' : 'sending',
      message: recover ? 'Checking the original receipt…' : 'Saving…',
    });
    const isCurrent = () => this.active;
    try {
      if (recover) {
        const receipt = await this.options.request(
          this.options.path + '/receipts/' + encodeURIComponent(intent.command.commandId),
          { isCurrent },
        );
        if (receipt) return await this.finish(receipt, intent);
        if (!this.active || !this.options.context().canSend) return;
      }
      const value = await this.options.request(this.endpoint(intent), {
        command: intent.command,
        csrf: this.options.context().csrf,
        isCurrent,
      });
      return await this.finish(value, intent);
    } catch (error) {
      if (!this.active) return;
      if (accessDenied(error)) this.deny();
      else if (error instanceof ApiError && error.status >= 400 && error.status < 500) {
        this.clear();
        this.setMessage(readableError(error));
      } else
        this.setMessage('Save status is unknown. Check the original receipt before continuing.');
    } finally {
      if (this.active) this.update({ phase: this.state.pending ? 'awaiting-receipt' : 'idle' });
    }
  }
}
