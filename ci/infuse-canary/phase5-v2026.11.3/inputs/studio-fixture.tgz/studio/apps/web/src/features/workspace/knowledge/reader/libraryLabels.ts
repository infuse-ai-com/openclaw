const LIBRARY_ACRONYMS = new Map([
  ['adr', 'ADR'],
  ['ai', 'AI'],
  ['api', 'API'],
  ['ci', 'CI'],
  ['devops', 'DevOps'],
  ['dns', 'DNS'],
  ['git', 'Git'],
  ['kb', 'KB'],
  ['llm', 'LLM'],
  ['llmops', 'LLMOps'],
  ['mcp', 'MCP'],
  ['mlops', 'MLOps'],
  ['oidc', 'OIDC'],
  ['os', 'OS'],
  ['pr', 'PR'],
  ['qa', 'QA'],
  ['rbac', 'RBAC'],
  ['saas', 'SaaS'],
  ['sre', 'SRE'],
  ['typescript', 'TypeScript'],
  ['ui', 'UI'],
  ['ux', 'UX'],
]);

export function libraryFolderLabel(name: string): string {
  const words = name
    .replace(/^\d+[\s._-]+/, '')
    .split(/[\s._-]+/)
    .filter(Boolean);

  if (words.length === 0) return name;

  return words
    .map((word, index) => {
      const normalized = word.toLowerCase();
      const acronym = LIBRARY_ACRONYMS.get(normalized);
      if (acronym) return acronym;
      if (index > 0) return normalized;
      return `${normalized.charAt(0).toUpperCase()}${normalized.slice(1)}`;
    })
    .join(' ');
}
