import { type WhiteboardStroke, shapeLabelLayout } from '@studio/contracts';
import { editDraft, type Draft } from './whiteboard-drafts.js';
import { DraftStatus } from './whiteboard-properties.js';
export function ShapeLabelEditor({
  block,
  drafts,
  sectionId,
  shared,
  enabled,
  changed,
}: {
  block: WhiteboardStroke;
  drafts: Map<string, Draft>;
  sectionId: string;
  shared: boolean;
  enabled: boolean;
  changed(): void;
}) {
  const cached = drafts.get(block.id),
    draft = (cached?.dirty ? cached.block : block) as WhiteboardStroke;
  return (
    <div
      className="wboard-shape-label-editor nodrag nopan nowheel"
      onClick={(event) => event.stopPropagation()}
    >
      <textarea
        aria-label="Shape text"
        autoFocus
        maxLength={500}
        value={draft.label ?? ''}
        disabled={!enabled}
        placeholder="Type a label…"
        style={{ fontSize: shapeLabelLayout(draft.label ?? '', block.width, block.height).size }}
        onChange={(event) => {
          editDraft(drafts, block, { label: event.target.value }, sectionId, shared);
          changed();
        }}
      />
      {cached?.blocked && (
        <DraftStatus
          drafts={drafts}
          id={block.id}
          saved={block}
          shared={shared}
          enabled={enabled}
          changed={changed}
        />
      )}
    </div>
  );
}
