import mark from '../../../../../packages/ui/assets/INFUSE_favicon.ico';
import './loading.css';

export type LoadingSize = 'page' | 'panel' | 'inline';
/** Decorative mark; the owning status supplies the accessible description. */
export function InfuseSpinner({ size = 'inline' }: { size?: LoadingSize }) {
  return <span className={`ws-infuse-spinner ws-infuse-spinner--${size}`} aria-hidden="true"><span className="ws-infuse-spinner-ring" /><img src={mark} alt="" /></span>;
}
/** Size follows the region waiting for data, never the number of expected records. */
export function LoadingState({ label, size = 'page', overlay = false, className = '' }: { label: string; size?: LoadingSize; overlay?: boolean; className?: string }) {
  const Tag = size === 'inline' ? 'span' : 'div';
  return <Tag className={`ws-loading ws-loading--${size}${overlay ? ' ws-loading--overlay' : ''}${className ? ` ${className}` : ''}`} role="status" aria-live="polite" aria-atomic="true" data-loading={size}>
    <InfuseSpinner size={size} /><span className={`ws-loading-label${size === 'page' ? ' ws-loading-label--hidden' : ''}`}>{label}</span>
  </Tag>;
}
