import { useEffect, useRef } from 'react';
import type { WhiteboardBlock, WhiteboardHtmlReference, WhiteboardStroke } from '@studio/contracts';
import type { CanvasItem, Commit } from './whiteboard-types.js';
import type { useWhiteboardCamera } from './whiteboard-camera.js';

type CreationContext = {
  scope: string; sectionId: string; camera: ReturnType<typeof useWhiteboardCamera>;
  blocks: CanvasItem[]; replaceHtml: string | null; commit: Commit;
  created(item: CanvasItem, focusText: boolean): void;
  attached(): void; notify(message: string): void;
};
/** Creation placement and settlement share the current board scope, independent of selection preparation. */
export function useWhiteboardCreation(context: () => CreationContext) {
  const latest = useRef(context); latest.current = context;
  const mounted = useRef(true);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  const current = (scope: string) => mounted.current && latest.current().scope === scope;
  function center(c: CreationContext) {
    const { canvas, flow, canvasSize } = c.camera, bounds = canvas.current?.getBoundingClientRect();
    return bounds && flow.current ? flow.current.screenToFlowPosition({ x: bounds.x + canvasSize.width / 2, y: bounds.y + canvasSize.height / 2 }) : { x: 240, y: 200 };
  }
  async function create(kind: WhiteboardBlock['kind'], placed?: { x: number; y: number }) {
    const c = context(), position = placed ?? center(c);
    const block = { id: crypto.randomUUID(), kind, title: kind === 'note' ? '' : 'New document', text: '',
      x: Math.round(position.x) - (placed ? 0 : 160), y: Math.round(position.y) - (placed ? 0 : 120), width: 320, height: 240 };
    const receipt = await c.commit([{ type: 'create', block }]);
    if (receipt?.status === 'applied' && current(c.scope)) c.created({ ...block, revision: receipt.revision }, true);
  }
  async function saveShape(stroke: Omit<WhiteboardStroke, 'revision'>) {
    const c = context(), receipt = await c.commit([{ type: 'draw', stroke }]);
    if (receipt?.status === 'applied' && current(c.scope)) c.created({ ...stroke, revision: receipt.revision }, false);
  }
  async function createSection() {
    const c = context();
    await c.commit([{ type: 'createSection', sectionId: c.sectionId, section: {
      id: crypto.randomUUID(), kind: 'section', title: 'New section', ...center(c), width: 400, height: 280,
    } }]);
  }
  async function attachHtml(reference: WhiteboardHtmlReference, title: string) {
    const c = context(), old = c.blocks.find(b => b.id === c.replaceHtml);
    if (c.replaceHtml && old?.kind !== 'html') {
      c.notify('This HTML block is no longer here. Close the library and choose another block.'); return false;
    }
    const receipt = await c.commit(old?.kind === 'html'
      ? [{ type: 'updateTile', id: old.id, expectedRevision: old.revision, patch: { reference, title } }]
      : [{ type: 'createHtml', sectionId: c.sectionId, tile: { id: crypto.randomUUID(), kind: 'html', title, reference, ...center(c), width: 560, height: 420 } }]);
    if (receipt?.status === 'applied' && current(c.scope)) { c.attached(); return true; }
    return false;
  }
  return { create, saveShape, createSection, attachHtml };
}
