import type { KnowledgeGraph } from '@studio/contracts/knowledge';
import type { FilterPreview } from './graphFilters';
import { GraphControlIcon } from './components/GraphControlIcon';
import type { useGraphInteraction } from './useGraphInteraction';
import type { useGraphSimulation } from './useGraphSimulation';
type Props = {
  simulation: Pick<
    ReturnType<typeof useGraphSimulation>,
    'layoutNodes' | 'nodeById' | 'clusterRegions'
  >;
  interaction: Pick<
    ReturnType<typeof useGraphInteraction>,
    | 'canvasRef'
    | 'graphSvgRef'
    | 'hoveredId'
    | 'setHoveredId'
    | 'enteringId'
    | 'transform'
    | 'keyboardFocusId'
    | 'fitGraph'
    | 'zoomAt'
    | 'handlePointerDown'
    | 'handlePointerMove'
    | 'handlePointerUp'
    | 'handleNodePointerDown'
    | 'handleNodeKey'
  >;
  scope: 'global' | 'local';
  setScope(scope: 'global' | 'local'): void;
  focusId?: string;
  visibleEdges: KnowledgeGraph['edges'];
  degree: ReadonlyMap<string, number>;
  connectedToHovered: ReadonlySet<string>;
  previewNodeIds?: ReadonlySet<string>;
  filterPreview?: FilterPreview;
};
export function GraphCanvasView({
  simulation,
  interaction,
  scope,
  setScope,
  focusId,
  visibleEdges,
  degree,
  connectedToHovered,
  previewNodeIds,
  filterPreview,
}: Props) {
  const { layoutNodes, nodeById, clusterRegions } = simulation;
  const {
    canvasRef,
    graphSvgRef,
    hoveredId,
    setHoveredId,
    enteringId,
    transform,
    keyboardFocusId,
    fitGraph,
    zoomAt,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
    handleNodePointerDown,
    handleNodeKey,
  } = interaction;
  return (
    <div
      className="graph-canvas"
      data-scale={transform.scale.toFixed(2)}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      ref={canvasRef}
    >
      <nav aria-label="Graph view controls" className="graph-toolbar" data-testid="graph-toolbar">
        <div className="graph-segmented" aria-label="Graph scope">
          <button
            aria-label="All documents"
            aria-pressed={scope === 'global'}
            onClick={() => setScope('global')}
            title="All documents"
            type="button"
          >
            <GraphControlIcon name="all" />
            <span className="graph-control-label">All documents</span>
          </button>
          <button
            aria-label="Connected"
            aria-pressed={scope === 'local'}
            disabled={!focusId}
            onClick={() => setScope('local')}
            title="Connected documents"
            type="button"
          >
            <GraphControlIcon name="connected" />
            <span className="graph-control-label">Connected</span>
          </button>
        </div>
        <span aria-hidden="true" className="graph-toolbar-divider" />
        <div className="graph-zoom-controls" aria-label="Canvas controls">
          <button aria-label="Zoom out" onClick={() => zoomAt(0.8)} title="Zoom out" type="button">
            <GraphControlIcon name="zoom-out" />
          </button>
          <button aria-label="Zoom in" onClick={() => zoomAt(1.25)} title="Zoom in" type="button">
            <GraphControlIcon name="zoom-in" />
          </button>
          <button
            aria-label="Fit graph to view"
            onClick={() => fitGraph()}
            title="Fit graph to view"
            type="button"
          >
            <GraphControlIcon name="fit" />
          </button>
        </div>
      </nav>

      <svg aria-label="Interactive knowledge graph" ref={graphSvgRef} role="application">
        <g
          data-testid="graph-world"
          transform={`translate(${String(transform.x)} ${String(transform.y)}) scale(${String(transform.scale)})`}
        >
          {clusterRegions.map((cluster) => (
            <g
              className={`graph-cluster-region${
                !filterPreview ||
                (filterPreview.kind === 'cluster' && filterPreview.value === cluster.id) ||
                (filterPreview.kind === 'repository' &&
                  layoutNodes.some(
                    (node) =>
                      node.clusterId === cluster.id && node.repository === filterPreview.value,
                  ))
                  ? ' is-active'
                  : ' is-muted'
              }`}
              data-cluster-id={cluster.id}
              key={cluster.id}
            >
              <ellipse
                cx={cluster.x}
                cy={cluster.y}
                fill={cluster.color}
                rx={cluster.width / 2}
                ry={cluster.height / 2}
              />
              <g
                className="graph-cluster-label"
                style={{ color: cluster.color }}
                transform={`translate(${String(cluster.x)} ${String(cluster.y - cluster.height / 2 + 30)})`}
              >
                <rect
                  height="26"
                  rx="8"
                  width={cluster.labelWidth}
                  x={-cluster.labelWidth / 2}
                  y="-18"
                />
                <text y="0">{cluster.label}</text>
              </g>
            </g>
          ))}
          <g className="graph-links">
            {visibleEdges.map((edge) => {
              const source = nodeById.get(edge.sourceId);
              const target = nodeById.get(edge.targetId);
              if (!source || !target) return null;
              const active = hoveredId
                ? edge.sourceId === hoveredId || edge.targetId === hoveredId
                : !previewNodeIds ||
                  (previewNodeIds.has(edge.sourceId) && previewNodeIds.has(edge.targetId));
              return (
                <line
                  className={active ? 'is-active' : 'is-muted'}
                  key={edge.id}
                  x1={source.x}
                  x2={target.x}
                  y1={source.y}
                  y2={target.y}
                />
              );
            })}
          </g>
          <g className="graph-nodes">
            {layoutNodes.map((node) => {
              const active = hoveredId
                ? connectedToHovered.has(node.id)
                : !previewNodeIds || previewNodeIds.has(node.id);
              const linkCount = degree.get(node.id) ?? 0;
              const labelVisible =
                hoveredId === node.id ||
                focusId === node.id ||
                transform.scale >= 1.05 ||
                linkCount >= 3 ||
                (transform.scale >= 0.78 && linkCount >= 1) ||
                (previewNodeIds?.has(node.id) === true && transform.scale >= 0.62);
              return (
                <g
                  aria-label={`Preview ${node.title}`}
                  className={`${active ? 'is-active' : 'is-muted'}${focusId === node.id ? ' is-focus' : ''}${enteringId === node.id ? ' is-entering' : ''}`}
                  data-cluster-id={node.clusterId}
                  data-label-visible={labelVisible ? 'true' : 'false'}
                  data-node-id={node.id}
                  key={node.id}
                  onBlur={() => setHoveredId(undefined)}
                  onFocus={() => setHoveredId(node.id)}
                  onKeyDown={(event) => handleNodeKey(event, node)}
                  onPointerDown={(event) => handleNodePointerDown(event, node)}
                  onPointerEnter={() => setHoveredId(node.id)}
                  onPointerLeave={() => setHoveredId(undefined)}
                  role="button"
                  tabIndex={node.id === keyboardFocusId ? 0 : -1}
                  transform={`translate(${String(node.x)} ${String(node.y)})`}
                >
                  <circle fill={node.color} r={node.radius} />
                  <circle className="graph-node-ring" r={node.radius + 5} />
                  {labelVisible && <text y={node.radius + 18}>{node.title}</text>}
                </g>
              );
            })}
          </g>
        </g>
      </svg>
      <div className="graph-canvas-hint">
        Drag nodes · drag empty space to pan · zoom into a node to read
      </div>
    </div>
  );
}
