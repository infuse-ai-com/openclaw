import { EmptyState, PageHeader } from './ui.js';
import {useMemo,useRef,useState,type CSSProperties} from 'react';
import {useSearchParams} from 'react-router';
import {useQuery} from '@tanstack/react-query';
import {contributionGrid,parseContributionsView,type ContributionsView} from '@studio/contracts';
import {useWorkspace} from './context.js';
import {readActivity as read} from './activity-read.js';
import './contributions.css';
import {ActivityDay} from './activity-day.js';
import {ActivityCoverage, ActivityPeople} from './activity-panels.js';
import {ShellIcon} from './shell.js';
import {ContributionSummary} from './contribution-summary.js';
import {utcStamp as stamp,contributionWeekRange} from './evidence-time.js';
const format=(n:number)=>new Intl.NumberFormat('en').format(n);
const dateKey=(at:number)=>new Date(at).toISOString().slice(0,10);
function Heatmap({year,days,onSelect,selected}:{year:number;days:ContributionsView['days'];selected:string;onSelect:(day:string)=>void}){
 const grid=useMemo(()=>contributionGrid(year,days),[year,days]);const first=grid.weeks.flat().find(Boolean)!.date;
 const [focus,setFocus]=useState(grid.weeks.flat().some(d=>d?.date===selected)?selected:days.find(d=>d.count>0)?.date||first),root=useRef<HTMLDivElement>(null);
 const dates=new Set(grid.weeks.flat().filter(Boolean).map(d=>d!.date));
 let previousMonth=-1;const months=grid.weeks.map(week=>{const day=week.find(Boolean);if(!day)return '';const month=Number(day.date.slice(5,7))-1;if(month===previousMonth)return '';previousMonth=month;return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][month]??'';});
 function move(event:React.KeyboardEvent<HTMLButtonElement>,day:string){
  const offsets:Record<string,number>={ArrowLeft:-7,ArrowRight:7,ArrowUp:-1,ArrowDown:1};let next:string|undefined;
  if(event.key in offsets)next=dateKey(Date.parse(day+'T00:00:00Z')+offsets[event.key]!*86400000);
  if(event.key==='Home')next=first;if(event.key==='End')next=String(year).padStart(4,'0')+'-12-31';
  if(next){event.preventDefault();if(dates.has(next)){setFocus(next);root.current?.querySelector<HTMLButtonElement>(`button[data-date="${next}"]`)?.focus();}}
 }
 return <section className="ws-contrib-chart" aria-label="Annual contributions"><header><h2>Your year in activity</h2><span>{format(grid.total)} recorded {grid.total===1?'commit':'commits'}</span></header><p id="contribution-grid-help">UTC days · arrows move by day or week; Enter opens recorded commits. Counts describe collected history.</p>
  <div className="ws-contrib-scroll" style={{'--contrib-weeks':grid.weeks.length} as CSSProperties} tabIndex={0} role="region" aria-label="Scrollable annual contribution graph"><div className="ws-contrib-months" aria-hidden="true">{months.map((month,index)=><span key={index}>{month}</span>)}</div><div className="ws-contrib-grid" ref={root} role="group" aria-describedby="contribution-grid-help" aria-label={`${year} UTC contribution days`}>{grid.weeks.map((week,index)=><div className="ws-contrib-week" key={index}>{week.map((day,i)=>day?<button key={day.date} type="button" data-date={day.date} data-level={day.count===0?0:grid.max<=1?4:Math.max(1,Math.ceil(day.count/grid.max*4))} aria-label={`${day.date}: ${format(day.count)} recorded ${day.count===1?'commit':'commits'}`} aria-pressed={selected===day.date} title={`${day.date} · ${format(day.count)} recorded ${day.count===1?'commit':'commits'}`} tabIndex={focus===day.date?0:-1} onFocus={()=>setFocus(day.date)} onKeyDown={event=>move(event,day.date)} onClick={()=>onSelect(day.date)}/>:<span key={i}/>)}</div>)}</div></div>
  <footer><span>Sunday-first weeks · {days.filter(d=>d.count>0).length} recorded active {days.length===1?'day':'days'}</span><span className="ws-contrib-legend"><span><i data-level="0" aria-hidden="true"/>0 commits</span><span>Low {[1,2,3,4].map(level=><i key={level} data-level={level} aria-hidden="true"/>)} High</span></span></footer>
 </section>;
}
export function Contributions(){
 const {session,current,visible}=useWorkspace(),[params,setParams]=useSearchParams();const [repositorySearch,setRepositorySearch]=useState(''),[repositoryLimit,setRepositoryLimit]=useState(20);const yearParam=params.get('year'),year=yearParam===null?new Date().getUTCFullYear():Number(yearParam);
 const repo=params.get('repo')??'',project=params.get('azureProject')??'',author=params.get('author')??'',day=params.get('day')??'',sources=params.get('view')==='sources';
 const validYear=Number.isInteger(year)&&year>=0&&year<=9999&&(yearParam===null||/^\d{1,4}$/.test(yearParam));
 const filters={...(repo?{repository:repo}:{}),...(project?{azureProject:project}:{}),...(author?{author}:{})};
 const query=useQuery({queryKey:['workspace','contributions',session.profileId,session.projects.map(p=>p.id).sort(),year,filters],enabled:current&&validYear,
  queryFn:({signal})=>read(`/api/contributions?${new URLSearchParams({year:String(year),...filters})}`,signal,parseContributionsView),refetchInterval:current&&visible?15000:false,gcTime:0});
 const data=current&&query.data&&'value'in query.data?query.data.value:undefined;
 function filter(key:string,value:string){setParams(previous=>{const next=new URLSearchParams(previous);if(value)next.set(key,value);else next.delete(key);next.delete('day');if(key==='repo'||key==='azureProject')next.delete('author');if(key==='azureProject')next.delete('repo');return next;});}
 function selectDay(value:string){setParams(previous=>{const next=new URLSearchParams(previous);if(value)next.set('day',value);else next.delete('day');return next;});if(!value)queueMicrotask(()=>document.querySelector<HTMLButtonElement>(`button[data-date="${day}"]`)?.focus());}
 function reset(){setParams(previous=>{const next=new URLSearchParams(previous);for(const key of ['year','repo','azureProject','author','day'])next.delete(key);return next;});}
 const complete=data&&(data.configuredSources??0)>0&&data.repositories.length===(data.configuredSources??0)&&data.repositories.every(r=>r.stage==='complete'&&!r.lastError&&!r.historyGap);
 const projects=[...new Map(data?.repositories.map(r=>[r.projectId,{id:r.projectId,name:r.projectName}])??[]).values()];
 const years=[...new Set([year,new Date().getUTCFullYear(),...(data?.years??[])])].filter(Number.isInteger).sort((a,b)=>b-a);
 const repositories=data?.repositories.filter(r=>(!repo||r.sourceId===repo)&&(!project||r.projectId===project)).sort((a,b)=>a.name.localeCompare(b.name))??[];
 const matchingRepositories=repositories.filter(r=>`${r.name} ${r.projectName}`.toLowerCase().includes(repositorySearch.trim().toLowerCase()));
 const activeDays=data?.days.filter(d=>d.count>0).map(d=>d.date).sort().reverse()??[];
 const selectedDay=day&&day.startsWith(String(year).padStart(4,'0')+'-')&&/^\d{4}-\d\d-\d\d$/.test(day)?day:'';
 function showSources(value:boolean){setParams(previous=>{const next=new URLSearchParams(previous);if(value)next.set('view','sources');else next.delete('view');return next;});queueMicrotask(()=>document.getElementById(value?'activity-sources':'activity-coverage-button')?.focus());}
 const scanned=data?.repositories.filter(r=>r.stage==='complete'&&!r.lastError&&!r.historyGap).length??0;
 const filtered=!!(yearParam||repo||project||author||day);
 const failure=query.data&&'unavailable'in query.data?query.data.reason:undefined;
 const diagnosis:Record<string,string>={checkpoint_storage:'The connection cannot save its verification state.',credential:'The repository connection needs its credentials checked.',provider_unavailable:'The repository service is not responding.',policy_invalid:'The repository access policy could not be verified.',policy_expired:'A fresh repository access policy is not available.',binding_mismatch:'The repository connections need to be reconciled.'};
 const coverageLabel=!data?'Source coverage unavailable':!data.configuredSources?'No admitted repository sources':complete?'All observed branch heads scanned':'History coverage incomplete';
 return <section className="ws-surface ws-company-surface ws-contributions ui-layout-wide" aria-label="Activity">
  <PageHeader className="ws-activity-header" eyebrow="COMPANY / GIT ACTIVITY" title={<>Activity<span aria-hidden="true">.</span></>} description="Explore changes across your projects, repositories and team." actions={<div className="ws-activity-actions"><button id="activity-coverage-button" className={`ws-activity-coverage-button ${data?.configuredSources&&!complete?'needs-attention':''}`} disabled={!current} onClick={()=>showSources(!sources)} aria-expanded={sources}><ShellIcon name="contributions"/><span><strong>{coverageLabel}</strong><small>{data?`${scanned} of ${data.configuredSources??0} admitted sources${data.collecting?'':' · Collection paused'}`:'Inspect connection status'}</small></span><span aria-hidden="true">→</span></button><button type="button" className="ws-button ws-button--quiet" disabled={!current||query.isFetching||!validYear} onClick={()=>void query.refetch()}>{query.isFetching?'Refreshing…':'Refresh activity'}</button></div>} />
  {!current?<p className="ws-contrib-message" role="status">Reconnect to refresh activity history.</p>:!validYear?<div className="ws-contrib-message"><p>Choose a valid year.</p><button onClick={reset}>Reset filters</button></div>:query.isPending?<p className="ws-contrib-message" role="status">Loading stored activity history…</p>:!data?<div className="ws-contrib-message" role="status"><h2>Activity history is unavailable</h2><p>Repository access cannot currently be checked. Previous private records are hidden.</p><button type="button" className="ws-button ws-button--quiet" disabled={query.isFetching} onClick={()=>void query.refetch()}>{query.isFetching?'Checking…':'Try again'}</button>{filtered&&<button className="ws-activity-link" onClick={reset}>Reset filters</button>}{sources&&<section id="activity-sources" tabIndex={-1} aria-label="Source connection status"><h3>Source connection status</h3><p>{failure?diagnosis[failure]:'Studio could not verify repository access.'} Ask a workspace operator to check the connection if retrying does not help.</p><button className="ws-activity-link" onClick={()=>showSources(false)}>Close connection status</button></section>}</div>:<div className="ws-contrib-content ui-page-content">
   {sources?<ActivityCoverage data={data} onClose={()=>showSources(false)}/>:<>
   <div className="ws-contrib-filters"><label>Year<select className="ui-control" aria-label="Activity year" value={year} onChange={e=>filter('year',e.target.value)}>{years.map(y=><option key={y} value={y}>{y}</option>)}</select></label><label>Project<select className="ui-control" aria-label="Activity project" value={project} onChange={e=>filter('azureProject',e.target.value)}><option value="">All admitted projects</option>{projects.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label><label>Repository<select className="ui-control" aria-label="Activity repository" value={repo} onChange={e=>filter('repo',e.target.value)}><option value="">All admitted repositories</option>{data.repositories.map(r=><option key={r.sourceId} value={r.sourceId}>{r.name}</option>)}</select></label><label>Contributor<select className="ui-control" aria-label="Activity contributor" value={author} onChange={e=>filter('author',e.target.value)}><option value="">Everyone</option>{data.authors.map(a=><option key={a.key} value={a.key}>{a.label??a.name}{data.authors.filter(other=>(other.label??other.name)===(a.label??a.name)).length>1?` · ${a.email??a.key}`:''}{a.kind?` · ${a.kind}`:''}</option>)}</select></label><button className="ws-activity-link" onClick={reset}>Reset filters</button></div>
   {data.authorsTruncated&&<p className="ws-activity-note">Contributor options cover the first 200 scoped authors.</p>}
   {!complete&&data.repositories.length>0&&<p className="ws-activity-warning">History coverage is incomplete. Counts and trends reflect retained records. <button onClick={()=>showSources(true)}>Inspect source coverage →</button></p>}
   {!data.repositories.length?<EmptyState title={<>{(data.configuredSources??0)>0?'Waiting for source metadata.':'No repository sources are admitted.'}</>}>History appears after configured sources have been collected or imported.</EmptyState>:<>
    <ContributionSummary data={data} repositories={repositories.length}/>
    {data.unknownDates>0&&<p className="ws-activity-note">{format(data.unknownDates)} retained records in these sources have no known graph date and cannot be placed in a year.</p>}
    <Heatmap key={year} year={year} days={data.days} selected={selectedDay} onSelect={selectDay}/>
    {!selectedDay&&<div className="ws-activity-overview">
     <section className="ws-contrib-activity" aria-label="Repository activity"><header><div><h2>Where the work happens</h2><p>{repositories.length} repositories · {year}</p></div><label><span className="ws-visually-hidden">Find repository</span><input className="ui-control" aria-label="Find repository" type="search" value={repositorySearch} onChange={e=>{setRepositorySearch(e.target.value);setRepositoryLimit(20);}} placeholder="Find repository"/></label></header>
      <p className="ws-activity-note">Seven-day UTC buckets from January 1. Hover a bar for its date range.</p>
      {matchingRepositories.slice(0,repositoryLimit).map(r=>{const activity=data.activity.find(a=>a.sourceId===r.sourceId),max=Math.max(1,...(activity?.weeks.map(w=>w.count)??[]));return <article key={r.sourceId}><button className="ws-activity-repo" onClick={()=>filter('repo',r.sourceId)} aria-label={`Filter by ${r.name}`}><span className="ws-activity-symbol"><ShellIcon name="artifact"/></span><span><strong>{r.name}</strong><small>{r.projectName}</small></span></button><div className="ws-contrib-spark" role="img" aria-label={`${r.name}: ${activity?.weeks.length??0} recorded active weeks in ${year}`}>{Array.from({length:53},(_,index)=>{const count=activity?.weeks.find(w=>w.index===index)?.count??0;return <i key={index} style={{height:`${Math.max(4,count/max*100)}%`}} data-active={count>0} title={`${contributionWeekRange(year,index)}: ${format(count)} recorded ${count===1?'commit':'commits'}`}/>;})}</div><div className="ws-activity-repo-count"><strong>{format(activity?.count??0)}</strong><small>commits</small><small title={stamp(activity?.latest)}>{activity?.latest?stamp(activity.latest).slice(0,10)+' UTC':'No recorded date'}</small></div></article>;})}
      <p className="ws-activity-note" role="status">{Math.min(repositoryLimit,matchingRepositories.length)} of {matchingRepositories.length} matching repositories shown</p>{matchingRepositories.length>repositoryLimit&&<button className="ws-activity-link" onClick={()=>setRepositoryLimit(n=>n+20)}>Show more repositories</button>}
     </section><ActivityPeople data={data} selected={author} onSelect={value=>filter('author',value)}/>
    </div>}
    <section className="ws-activity-journal" aria-label="Recent activity"><header><div><h2>{selectedDay?'Recorded changes':'Latest changes'}</h2><p>{selectedDay?'Commits for the selected UTC day.':'Explore the latest recorded day in these filters.'}</p></div>{!selectedDay&&activeDays.length>0&&<label>Recorded day<select className="ui-control" aria-label="Recorded day" value={activeDays[0]} onChange={e=>selectDay(e.target.value)}>{activeDays.map(d=><option key={d} value={d}>{d}</option>)}</select></label>}</header>
     {selectedDay||activeDays[0]?<ActivityDay key={JSON.stringify([selectedDay||activeDays[0],filters,data.repositories.map(r=>[r.sourceId,r.organization,r.projectId,r.repositoryId]),Boolean(selectedDay)])} day={selectedDay||activeDays[0]!} filters={filters} data={data} onClose={selectedDay?()=>selectDay(''):undefined}/>:<p className="ws-activity-note">No commits recorded in {year} with these filters. Inspect source coverage before interpreting an empty year.</p>}
    </section>
   </>}
   </>}
   <p className="ws-contrib-read-time">Stored view read {stamp(data.readAt)}. UTC grouping uses author dates, then known committer or retained legacy dates.</p>
  </div>}
 </section>;
}
