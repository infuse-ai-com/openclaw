import type { Document } from '@studio/contracts/knowledge';
import { resolveAssetPath } from './source-paths';

/** Keep source URLs inert until every local image is pinned to its admitted Git asset. */
export function documentArticleHtml(document: Document, projectId: string, scopeRevision?: number): string {
  const template = globalThis.document.createElement('template');
  template.innerHTML = document.html;
  for (const image of template.content.querySelectorAll('img[src]')) {
    const target = documentAssetUrl(document, image.getAttribute('src') ?? '', projectId, scopeRevision);
    if (target) image.setAttribute('src', target);
    image.setAttribute('loading', 'lazy');
  }
  return template.innerHTML;
}

export function documentAssetUrl(
  document: Document,
  rawTarget: string,
  projectId = 'core',
  scopeRevision?: number,
): string | undefined {
  const resolved = resolveAssetPath(document.path, rawTarget);
  if (!resolved) return;
  const encodedPath = resolved.split('/').map(encodeURIComponent).join('/');
  return `/api/projects/${encodeURIComponent(projectId)}/studio/knowledge/repositories/${encodeURIComponent(
    document.repository,
  )}/assets/${document.provenance.commit}/${encodedPath}${scopeRevision === undefined ? '' : `?floorRevision=${scopeRevision}`}`;
}
