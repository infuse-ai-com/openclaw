import { Button } from './ui.js';
import { NoteColors } from './whiteboard-colors.js';
import {
  type EditableBlock,
  type Draft,
  editDraft,
  draftOperation,
  rebaseDraft,
} from './whiteboard-drafts.js';
import { PenOptions } from './whiteboard-drawing.js';

export function GeometryFields({
  block,
  enabled,
  edit,
}: {
  block: EditableBlock;
  enabled: boolean;
  edit(values: Partial<EditableBlock>): void;
}) {
  const minimum = block.kind === 'stroke' ? 1 : block.kind === 'image' ? 16 : 160;
  return (
    <details className="wboard-position">
      <summary>Position and size</summary>
      <div className="wboard-geometry">
        {(['x', 'y', 'width', 'height'] as const).map((key) => (
          <label key={key}>
            {{ x: 'X position', y: 'Y position', width: 'Width', height: 'Height' }[key]}
            <input className="ui-control"
              type="number"
              required
              step="any"
              disabled={!enabled || !!block.locked}
              min={key === 'x' || key === 'y' ? -100000 : minimum}
              max={key === 'x' || key === 'y' ? 100000 : 4000}
              value={Number.isFinite(block[key]) ? Number(block[key].toFixed(2)) : ''}
              onChange={(event) => edit({ [key]: event.currentTarget.valueAsNumber })}
            />
          </label>
        ))}
      </div>
    </details>
  );
}
export function DraftStatus({
  drafts,
  id,
  saved,
  shared,
  enabled,
  changed,
}: {
  drafts: Map<string, Draft>;
  id: string;
  saved?: EditableBlock;
  shared: boolean;
  enabled: boolean;
  changed(): void;
}) {
  const draft = drafts.get(id),
    invalid = draft?.dirty && !draft.inFlight && !draftOperation(draft, shared);
  return (
    <>
      {draft?.blocked ? (
        <div role="alert">
          Your changes are kept. Review the current version before trying again.
          <Button variant="quiet"
            type="button"
            disabled={!enabled || !saved}
            onClick={() => {
              drafts.delete(id);
              changed();
            }}
          >
            Use saved version
          </Button>
          <Button variant="quiet"
            type="button"
            disabled={!enabled || !saved || !!invalid}
            onClick={() => {
              if (saved) {
                drafts.set(id, rebaseDraft(draft, saved, shared));
                changed();
              }
            }}
          >
            Save my version
          </Button>
        </div>
      ) : (
        <small className="wboard-property-status" role="status">
          {invalid
            ? 'Complete the highlighted fields to save.'
            : draft?.dirty
              ? 'Saving…'
              : 'Changes save automatically'}
        </small>
      )}
      {draft?.dirty && (
        <Button variant="quiet"
          type="button"
          className="wboard-discard-draft"
          disabled={!enabled}
          onClick={() => {
            drafts.delete(id);
            changed();
          }}
        >
          Discard changes
        </Button>
      )}
    </>
  );
}
export function PropertiesEditor({
  block,
  enabled,
  canAct,
  drafts,
  sectionId,
  shared,
  changed,
  remove,
  enter,
  replace,
  editText,
}: {
  block: EditableBlock;
  enabled: boolean;
  canAct: boolean;
  drafts: Map<string, Draft>;
  sectionId: string;
  shared: boolean;
  changed(): void;
  remove(): void;
  enter(): void;
  replace(): void;
  editText(): void;
}) {
  const cached = drafts.get(block.id),
    draft = cached?.dirty ? cached.block : block;
  const edit = (values: Partial<EditableBlock>) => {
    editDraft(drafts, block, values, sectionId, shared);
    changed();
  };
  return (
    <form className="wboard-editor" onSubmit={(event) => event.preventDefault()}>
      {draft.kind === 'stroke' ? (
        <div className="wboard-property-style">
          <span className="wboard-field-label">Color and thickness</span>
          <PenOptions
            color={draft.color}
            width={draft.thickness}
            setColor={(color) => edit({ color })}
            setWidth={(thickness) => edit({ thickness })}
            disabled={!enabled}
          />
        </div>
      ) : (
        <label>
          Title
          <input className="ui-control"
            aria-label="Block title"
            disabled={!enabled}
            maxLength={160}
            required={draft.kind !== 'note' && draft.kind !== 'document'}
            value={draft.title}
            onChange={(event) => edit({ title: event.target.value })}
          />
        </label>
      )}
      {draft.kind === 'stroke' && draft.shape && (
        <label>
          Shape text
          <textarea className="ui-control"
            aria-label="Shape text"
            maxLength={500}
            disabled={!enabled}
            value={draft.label ?? ''}
            onChange={(event) => edit({ label: event.target.value })}
          />
        </label>
      )}
      {(block.kind === 'note' || block.kind === 'document') && (
        <Button variant="quiet" type="button" onClick={editText}>
          Edit text on canvas
        </Button>
      )}
      {draft.kind === 'note' && (
        <NoteColors
          value={draft.noteColor ?? 'yellow'}
          disabled={!enabled}
          choose={(noteColor) => edit({ noteColor })}
        />
      )}
      <GeometryFields block={draft} enabled={enabled} edit={edit} />
      <DraftStatus
        drafts={drafts}
        id={block.id}
        saved={block}
        shared={shared}
        enabled={canAct}
        changed={changed}
      />
      {block.kind === 'section' && (
        <Button variant="quiet" type="button" disabled={!canAct || !!cached?.dirty} onClick={enter}>
          Enter section
        </Button>
      )}
      {(block.kind === 'html' || block.kind === 'image') && (
        <details>
          <summary>Source and saved version</summary>
          <p>
            {block.reference.producer}/{block.reference.artifactId}
            <br />
            {block.reference.path}
          </p>
          <small>Revision {block.reference.revision}</small>
        </details>
      )}
      {block.kind === 'html' && (
        <Button variant="quiet" type="button" disabled={!canAct || !!cached?.dirty} onClick={replace}>
          Replace HTML source
        </Button>
      )}
      <Button variant="quiet"
        className="wboard-delete"
        type="button"
        disabled={!canAct || !!cached?.dirty || !!block.locked}
        onClick={remove}
      >
        Delete{' '}
        {block.kind === 'stroke' ? 'drawing' : block.kind === 'html' ? 'HTML block' : block.kind}
      </Button>
    </form>
  );
}
