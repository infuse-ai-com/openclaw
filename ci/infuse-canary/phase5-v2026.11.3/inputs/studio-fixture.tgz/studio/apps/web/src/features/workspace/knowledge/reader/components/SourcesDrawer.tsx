import { IconButton } from '../../../ui.js';
import { useEffect, useRef } from 'react';
import type { Document, Repository } from '@studio/contracts/knowledge';
import { LibraryPanel } from './LibraryPanel.js';
import { KnowledgeIcon } from './KnowledgeHeader.js';
export function SourcesDrawer({
  repositories,
  currentDocument,
  source,
  onSource,
  onOpenDocument,
  onClose,
}: {
  repositories: readonly Repository[];
  currentDocument?: Document;
  source: string;
  onSource(source: string): void;
  onOpenDocument(repo: string, path: string): void;
  onClose(): void;
}) {
  const panel = useRef<HTMLElement>(null);
  useEffect(() => {
    panel.current?.querySelector<HTMLButtonElement>('button')?.focus();
  }, []);
  return (
    <aside
      id="knowledge-sources"
      ref={panel}
      className="knowledge-sources atlas-scroll-surface"
      role="dialog"
      aria-modal="true"
      aria-label="Knowledge sources"
      onKeyDown={(event) => {
        if (event.key === 'Escape') {
          event.preventDefault();
          event.stopPropagation();
          onClose();
        }
        if (event.key !== 'Tab') return;
        const targets = panel.current?.querySelectorAll<HTMLElement>(
          'button:not(:disabled), select, summary, a[href], [tabindex="0"]',
        );
        if (!targets?.length) return;
        const first = targets[0],
          last = targets[targets.length - 1];
        if (event.shiftKey && globalThis.document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (
          !event.shiftKey &&
          globalThis.document.activeElement === last
        ) {
          event.preventDefault();
          first?.focus();
        }
      }}
    >
      <header>
        <h2>Sources</h2>
        <IconButton aria-label="Close sources" onClick={onClose} type="button">
          <KnowledgeIcon name="close" />
        </IconButton>
      </header>
      <p>This source scope applies to Library, search and Explore.</p>
      <label>
        Source scope
        <select
          aria-label="Source scope"
          value={source}
          onChange={(event) => onSource(event.target.value)}
        >
          <option value="">All admitted sources</option>
          {repositories.map((repo) => (
            <option key={repo.slug} value={repo.slug}>
              {repo.displayName}
            </option>
          ))}
        </select>
      </label>
      <LibraryPanel
        currentDocument={currentDocument}
        home={false}
        onOpenDocument={onOpenDocument}
        onOpenHome={() => onSource('')}
        onOpenRepository={(repo) => onSource(repo.slug)}
        onOpenSearch={() => {}}
        repositories={repositories}
        scopedRepository={source || undefined}
        compactHeader
      />
    </aside>
  );
}
