import type { Document, Repository } from '@studio/contracts/knowledge';
import type { SidePanel } from './DocumentPanel.js';
import { ReadingTools } from './KnowledgeHeader.js';
function reviewLabel(state: Document['review']['state']): string {
  return {
    'never-reviewed': 'Never reviewed',
    reviewed: 'Human reviewed',
    changed: 'Changed since review',
    overdue: 'Review overdue',
  }[state];
}
export function ReaderHeader({
  document,
  repository,
  sidePanel,
  onToggle,
  onBack,
  backLabel,
}: {
  document: Document;
  repository?: Repository;
  sidePanel: SidePanel;
  onToggle(panel: SidePanel): void;
  onBack(): void;
  backLabel: string;
}) {
  return (
    <>
      <ReadingTools
        sidePanel={sidePanel}
        onToggle={onToggle}
        onBack={onBack}
        backLabel={backLabel}
      />
      <header className="atlas-reader-header">
        <nav
          className="breadcrumbs atlas-breadcrumbs"
          aria-label="Document path"
        >
          <span>{repository?.displayName ?? document.repository}</span>
          <span>{document.path}</span>
        </nav>
        <div className="atlas-document-heading">
          <div className="atlas-document-title">
            <h1 tabIndex={-1}>{document.title}</h1>
            <p className="atlas-document-description">
              {document.metadata.description}
            </p>
            <div
              className="atlas-metadata-pills"
              aria-label="Document metadata"
            >
              <span>{document.metadata.type}</span>
              <span>{document.metadata.status}</span>
              <span data-review-state={document.review.state}>
                {reviewLabel(document.review.state)}
              </span>
            </div>
          </div>
          <div className="provenance atlas-provenance" data-testid="provenance">
            <div>
              <strong>
                {document.provenance.branch}@
                {document.provenance.commit.slice(0, 8)}
              </strong>
              <span>
                Indexed{' '}
                {new Intl.DateTimeFormat(undefined, {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                }).format(new Date(document.provenance.indexedAt))}
              </span>
            </div>
            {document.sourceUrl && (
              <a href={document.sourceUrl} rel="noreferrer" target="_blank">
                Source ↗
              </a>
            )}
          </div>
        </div>
      </header>
    </>
  );
}
