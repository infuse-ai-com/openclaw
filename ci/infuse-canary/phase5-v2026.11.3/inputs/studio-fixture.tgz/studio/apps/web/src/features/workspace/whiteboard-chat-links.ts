/** Only explicit HTTP(S) links are actionable; no HTML or image fetching. */
export function companionLink(href: string, origin: string, projectId: string) {
  try {
    if (!/^(https?:\/\/|\/(?!\/))/i.test(href) || /[\x00-\x20\x7f]/.test(href)) return null;
    const url = new URL(href, origin);
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) return null;
    if (url.origin === origin && url.pathname === '/whiteboard' && url.searchParams.get('project') === projectId) {
      return { href: url.href, section: url.searchParams.get('section') || 'root', block: url.searchParams.get('block') || undefined };
    }
    return { href: url.href };
  } catch { return null; }
}
