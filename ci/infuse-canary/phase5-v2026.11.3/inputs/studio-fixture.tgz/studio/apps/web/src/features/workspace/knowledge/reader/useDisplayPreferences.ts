import { useEffect, useState } from 'react';

export type Theme = 'light' | 'dark' | 'system';
export type ReaderWidth = 'comfortable' | 'wide';

export const readerTextSizes = ['90', '100', '110', '120'] as const;
export type ReaderTextSize = (typeof readerTextSizes)[number];

function storedPreference<T extends string>(
  key: string,
  allowed: readonly T[],
  fallback: T,
): T {
  try {
    const value = globalThis.localStorage.getItem(key);
    return allowed.includes(value as T) ? (value as T) : fallback;
  } catch {
    return fallback;
  }
}

export function useDisplayPreferences() {
  const [theme, setTheme] = useState<Theme>(() =>
    storedPreference(
      'studio.knowledge.theme',
      ['light', 'dark', 'system'],
      'system',
    ),
  );
  const [readerWidth, setReaderWidth] = useState<ReaderWidth>(() =>
    storedPreference(
      'studio.knowledge.readerWidth',
      ['comfortable', 'wide'],
      'comfortable',
    ),
  );
  const [readerTextSize, setReaderTextSize] = useState<ReaderTextSize>(() =>
    storedPreference('studio.knowledge.readerTextSize', readerTextSizes, '100'),
  );

  useEffect(() => {
    try {
      globalThis.localStorage.setItem('studio.knowledge.theme', theme);
    } catch {}
  }, [theme]);

  useEffect(() => {
    try {
      globalThis.localStorage.setItem(
        'studio.knowledge.readerWidth',
        readerWidth,
      );
    } catch {}
  }, [readerWidth]);

  useEffect(() => {
    try {
      globalThis.localStorage.setItem(
        'studio.knowledge.readerTextSize',
        readerTextSize,
      );
    } catch {}
  }, [readerTextSize]);

  function resetDisplayPreferences() {
    setTheme('system');
    setReaderWidth('comfortable');
    setReaderTextSize('100');
  }

  return {
    readerTextSize,
    readerWidth,
    resetDisplayPreferences,
    setReaderTextSize,
    setReaderWidth,
    setTheme,
    theme,
  };
}
