import { isHealthResponse, type HealthResponse } from '@studio/contracts';
export async function getHealth(): Promise<HealthResponse> {
  const response = await fetch('/api/health', {signal:AbortSignal.timeout(5000)});
  if (!response.ok) throw new Error('Studio could not reach the backend.');
  const data: unknown = await response.json();
  if (!isHealthResponse(data)) throw new Error('The backend returned an unsupported response.');
  return data;
}
