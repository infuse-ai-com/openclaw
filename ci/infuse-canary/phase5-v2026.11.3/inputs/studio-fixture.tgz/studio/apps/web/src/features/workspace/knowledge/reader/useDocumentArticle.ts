import { useEffect, useMemo, useRef } from 'react';
import type { Document } from '@studio/contracts/knowledge';
import { readerUrl, resolveReaderLink } from './readerLinks';
import { documentArticleHtml } from './articleAssets';
import { useKnowledgeApi } from './api';

type OpenReaderLink = (
  repository: string,
  path: string,
  headingId?: string,
) => void | Promise<void>;

export function useDocumentArticle(
  document: Document | undefined,
  onOpenLink: OpenReaderLink,
  onUnavailable: () => void,
) {
  const { projectId, scopeRevision } = useKnowledgeApi();
  const articleRef = useRef<HTMLElement>(null);
  const articleHtml = useMemo(() => document ? documentArticleHtml(document, projectId, scopeRevision) : '', [document, projectId, scopeRevision]);

  useEffect(() => {
    const article = articleRef.current;
    if (!article || !document) return;
    const activeArticle = article;
    const activeDocument = document;
    const anchorCleanups: (() => void)[] = [];

    for (const anchor of activeArticle.querySelectorAll<HTMLAnchorElement>(
      'a[href]',
    )) {
      const href =
        anchor.dataset.kbRawHref ?? anchor.getAttribute('href') ?? '';
      anchor.dataset.kbRawHref = href;
      const target = resolveReaderLink(activeDocument.path, href);
      if (target.kind === 'external') {
        if (!/^https?:\/\//i.test(href)) continue;
        anchor.target = '_blank';
        anchor.rel = 'noopener noreferrer';
        anchor.classList.add('external-link');
        continue;
      }

      if (target.kind === 'invalid') {
        anchor.classList.add('unresolved-link');
        const handleInvalidLink = (event: MouseEvent) => {
          event.preventDefault();
          onUnavailable();
        };
        anchor.addEventListener('click', handleInvalidLink);
        anchorCleanups.push(() =>
          anchor.removeEventListener('click', handleInvalidLink),
        );
        continue;
      }

      anchor.setAttribute(
        'href',
        readerUrl(activeDocument.repository, target.path, target.headingId, projectId),
      );
      const handleInternalLink = (event: MouseEvent) => {
        if (
          event.button !== 0 ||
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey
        ) {
          return;
        }
        event.preventDefault();
        void onOpenLink(
          activeDocument.repository,
          target.path,
          target.headingId,
        );
      };
      anchor.addEventListener('click', handleInternalLink);
      anchorCleanups.push(() =>
        anchor.removeEventListener('click', handleInternalLink),
      );
    }

    const controller = new AbortController();
    async function renderMermaid() {
      const blocks = [
        ...activeArticle.querySelectorAll('code.language-mermaid'),
      ];
      if (blocks.length === 0) return;
      const { default: mermaid } = await import('mermaid');
      mermaid.initialize({
        securityLevel: 'strict',
        startOnLoad: false,
        theme: 'base',
      });
      for (const [index, block] of blocks.entries()) {
        if (controller.signal.aborted) return;
        const pre = block.closest('pre');
        if (!pre) continue;
        const { svg } = await mermaid.render(
          'kb-mermaid-' +
            activeDocument.provenance.commit.slice(0, 8) +
            '-' +
            String(index),
          block.textContent,
        );
        const diagram = globalThis.document.createElement('div');
        diagram.className = 'mermaid-diagram';
        diagram.dataset.testid = 'mermaid-diagram';
        diagram.setAttribute('role', 'img');
        diagram.setAttribute('aria-label', 'Document diagram');
        diagram.innerHTML = svg;
        pre.replaceWith(diagram);
      }
    }
    void renderMermaid().catch(() => {
      activeArticle
        .querySelector('code.language-mermaid')
        ?.closest('pre')
        ?.classList.add('mermaid-failed');
    });
    return () => {
      controller.abort();
      for (const cleanup of anchorCleanups) cleanup();
    };
  });

  return { articleRef, articleHtml };
}
