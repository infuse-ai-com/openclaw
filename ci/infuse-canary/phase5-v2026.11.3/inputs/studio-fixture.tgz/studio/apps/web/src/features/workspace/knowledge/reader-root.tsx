import type { GraphEntryOrigin } from './reader/graphLayout.js';
import { LoadingState } from '../loading.js';
import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import type {
  Document,
  Repository,
  LibraryUpdates,
  ReviewQueue,
  KnowledgeGraph,
} from '@studio/contracts/knowledge';
import { useKnowledgeApi } from './reader/api.js';
import {
  KnowledgeGraphCanvas,
} from './reader/KnowledgeGraph.js';
import { SemanticReader } from './reader/SemanticReader.js';
import { TerminalState } from './reader/components/TerminalState.js';
import {
  KnowledgeHeader,
  KnowledgeScope,
} from './reader/components/KnowledgeHeader.js';
import { SourcesDrawer } from './reader/components/SourcesDrawer.js';

import { LibraryHome } from './reader/components/LibraryHome.js';
import { CommandSearch } from './reader/components/CommandSearch.js';
import { ReaderHeader } from './reader/components/ReaderHeader.js';
import {
  DocumentPanel,
  type SidePanel,
} from './reader/components/DocumentPanel.js';

import { useCommandSearch } from './reader/useCommandSearch.js';
import { useDocumentArticle } from './reader/useDocumentArticle.js';
import { useDisplayPreferences } from './reader/useDisplayPreferences.js';
import { useReadingProgress } from './reader/readingProgress.js';
import { findRenderedHeading } from './reader/headingTargets.js';
import { LatestRequest } from './reader/latestRequest.js';
import { readerUrl } from './reader/readerLinks.js';
const repositoryOverviewPath = (repository: string) =>
  repository === 'agent-skills' ? 'AGENTS.md' : 'README.md';
import './reader/styles.css';
import './workspace.css';

export default function KnowledgeReader({ owner }: { owner: string }) {
  const { projectId, scopeRevision, loadDocument,
  loadRepositories,
  loadLibraryUpdates,
  loadReviewQueue,
  loadGraph, } = useKnowledgeApi();
  const [params, setParams] = useSearchParams();
  const repository = params.get('repo'),
    path = params.get('path'),
    revision = params.get('revision');
  const source = params.get('source') || '';
  const exploring = params.get('view') === 'explore';
  const zoomReading = exploring && params.get('zoom') === 'reader';
  const [graph, setGraph] = useState<KnowledgeGraph>();
  const [graphSource, setGraphSource] = useState('');
  const [graphLoading, setGraphLoading] = useState(false);
  const [graphError, setGraphError] = useState(false);
  const [graphRefresh, setGraphRefresh] = useState(0);
  const [entryOrigin, setEntryOrigin] = useState<GraphEntryOrigin>();
  const graphRequests = useRef(new LatestRequest());
  const [repositories, setRepositories] = useState<Repository[]>([]);
  const [updates, setUpdates] = useState<LibraryUpdates>();
  const [reviewQueue, setReviewQueue] = useState<ReviewQueue>();
  const [document, setDocument] = useState<Document>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>();
  const [denied, setDenied] = useState(false);
  const [updatesError, setUpdatesError] = useState(false);
  const [reviewQueueError, setReviewQueueError] = useState(false);
  const [documentLoading, setDocumentLoading] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const search = useCommandSearch(searchOpen, source);
  const prefs = useDisplayPreferences();
  const [sidePanel, setSidePanel] = useState<SidePanel>('closed');
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const [compact, setCompact] = useState(false);
  const [focusReader, setFocusReader] = useState(false);
  const [detent, setDetent] = useState<'expanded' | 'collapsed'>('expanded');
  const returnFocus = useRef<HTMLElement | null>(null);
  const root = useRef<HTMLDivElement>(null);
  const panel = useRef<HTMLElement>(null);
  const [refresh, setRefresh] = useState(0);
  const home = (!repository || !path) && !exploring;
  const documentRequests = useRef(new LatestRequest());
  const admitted = useRef(true);
  async function open(
    repo: string,
    nextPath: string,
    heading?: string,
    newTab = false,
    origin?: GraphEntryOrigin,
    fromExplore = exploring || Boolean(origin),
  ) {
    const url = readerUrl(repo, nextPath, heading, projectId);
    const destination = new URL(url, window.location.origin);
    if (source) destination.searchParams.set('source', source);
    if (fromExplore) {
      destination.searchParams.set('view', 'explore');
      destination.searchParams.set('zoom', 'reader');
    }
    if (newTab) {
      window.open(destination.href, '_blank', 'noopener,noreferrer');
      return;
    }
    const request = documentRequests.current.begin();
    setDocumentLoading(true);
    setError(undefined);
    try {
      const next =
        document?.repository === repo && document.path === nextPath
          ? document
          : await loadDocument(repo, nextPath);
      if (!admitted.current || !documentRequests.current.owns(request)) return;
      setDocument(next);
      setSidePanel('closed');
      setSourcesOpen(false);
      setSearchOpen(false);
      search.cancel();
      setEntryOrigin(origin);
      requestAnimationFrame(() =>
        root.current
          ?.querySelector<HTMLElement>('.atlas-document-title h1')
          ?.focus({ preventScroll: true }),
      );
      setParams({
        project: projectId,
        repo,
        path: nextPath,
        ...(source ? { source } : {}),
        ...(fromExplore ? { view: 'explore', zoom: 'reader' } : {}),
      });
      window.location.hash = heading ? encodeURIComponent(heading) : '';
      if (heading)
        requestAnimationFrame(() =>
          findRenderedHeading(heading)?.scrollIntoView(),
        );
    } catch {
      if (admitted.current && documentRequests.current.owns(request)) {
        setError('The linked document is unavailable.');
        if (sourcesOpen) closeSources();
      }
    } finally {
      if (documentRequests.current.owns(request)) setDocumentLoading(false);
    }
  }
  const { articleRef: article, articleHtml } = useDocumentArticle(document, open, () =>
    setError('This document link is unavailable.'),
  );
  const progressKey = 'studio.knowledge.progress:' + owner;
  const progress = useReadingProgress(
    document,
    panel,
    progressKey,
    exploring ? (zoomReading ? 'zoom' : 'map') : 'document',
  );
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    const observer = new ResizeObserver(() =>
      setCompact(element.clientWidth <= 1000),
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    let current = true;
    setLoading(true);
    setError(undefined);
    void Promise.allSettled([
      loadRepositories(),
      loadLibraryUpdates(),
      loadReviewQueue(),
    ]).then(([repos, nextUpdates, nextReviews]) => {
      if (!current || !admitted.current) return;
      if (repos.status === 'fulfilled') {
        setRepositories(repos.value);
      } else {
        setRepositories([]);
        setError(
          'The Knowledge library is unavailable. Your project work remains available.',
        );
      }
      setUpdates(
        nextUpdates.status === 'fulfilled' ? nextUpdates.value : undefined,
      );
      setUpdatesError(nextUpdates.status === 'rejected');
      setReviewQueue(
        nextReviews.status === 'fulfilled' ? nextReviews.value : undefined,
      );
      setReviewQueueError(nextReviews.status === 'rejected');
      setLoading(false);
    });
    return () => {
      current = false;
    };
  }, [owner, refresh]);
  useEffect(() => {
    let current = true;
    if (!admitted.current) return;
    if (
      document?.repository === repository &&
      document.path === path &&
      revision === null
    )
      return;
    const request = documentRequests.current.begin();
    setDocument(undefined);
    setDocumentLoading(false);
    if (!repository || !path) return;
    if (revision !== null) {
      setError('Historical document reading is not available in this release.');
      return;
    }
    setDocumentLoading(true);
    void loadDocument(repository, path)
      .then((next) => {
        if (
          current &&
          admitted.current &&
          documentRequests.current.owns(request)
        ) {
          setDocument(next);
          setError(undefined);
        }
      })
      .catch(() => {
        if (
          current &&
          admitted.current &&
          documentRequests.current.owns(request)
        )
          setError(
            'The selected document is unavailable. Return to the library or search again.',
          );
      })
      .finally(() => {
        if (current && documentRequests.current.owns(request))
          setDocumentLoading(false);
      });
    return () => {
      current = false;
    };
  }, [repository, path, revision, owner, refresh, document]);
  const scopedRepositories = source
    ? repositories.filter((repo) => repo.slug === source)
    : repositories;
  const sourceAvailable = !source || scopedRepositories.length > 0;
  useEffect(() => {
    if (!exploring || repositories.length === 0 || !admitted.current) return;
    if (source && !repositories.some((repo) => repo.slug === source)) {
      graphRequests.current.invalidate();
      setGraph(undefined);
      setGraphLoading(false);
      return;
    }
    const request = graphRequests.current.begin();
    setGraph(undefined);
    setGraphLoading(true);
    setGraphError(false);
    void loadGraph(
      repositories
        .filter((repo) => !source || repo.slug === source)
        .map((repo) => repo.slug),
    )
      .then((next) => {
        if (admitted.current && graphRequests.current.owns(request)) {
          setGraph(next);
          setGraphSource(source);
        }
      })
      .catch(() => {
        if (admitted.current && graphRequests.current.owns(request))
          setGraphError(true);
      })
      .finally(() => {
        if (graphRequests.current.owns(request)) setGraphLoading(false);
      });
    return () => graphRequests.current.invalidate();
  }, [exploring, repositories, source, graphRefresh]);
  useEffect(() => {
    const hide = (event: Event) => {
      const detail = (event as CustomEvent<{ projectId: string; scopeRevision?: number }>).detail;
      if (detail && (detail.projectId !== projectId || detail.scopeRevision !== scopeRevision)) return;
      admitted.current = false;
      documentRequests.current.invalidate();
      graphRequests.current.invalidate();
      setGraph(undefined);
      try {
        localStorage.removeItem(progressKey);
      } catch {}
      setDenied(true);
      setDocument(undefined);
      setRepositories([]);
      setUpdates(undefined);
      setReviewQueue(undefined);
      setSearchOpen(false);
      search.cancel();
    };
    window.addEventListener('studio-knowledge-denied', hide);
    return () => window.removeEventListener('studio-knowledge-denied', hide);
  }, [search.cancel, progressKey, projectId, scopeRevision]);
  useEffect(() => {
    const keyboard = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return;
      if (
        event.key === 'Escape' &&
        !searchOpen &&
        !sourcesOpen &&
        sidePanel === 'closed' &&
        exploring
      ) {
        event.preventDefault();
        if (zoomReading) closeZoomReader();
        else closeExplore();
        return;
      }
      if (event.key === 'Escape' && sidePanel !== 'closed') {
        event.preventDefault();
        closePanel();
        return;
      }
      if (event.key === 'Escape' && sourcesOpen) {
        event.preventDefault();
        closeSources();
        return;
      }
      const target = event.target as HTMLElement;
      const commandSearch =
        (event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k';
      const editable =
        ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) ||
        target.isContentEditable;
      if (commandSearch || (event.key === '/' && !editable)) {
        event.preventDefault();
        openSearch();
      }
    };
    window.addEventListener('keydown', keyboard);
    return () => window.removeEventListener('keydown', keyboard);
  }, [
    exploring,
    zoomReading,
    searchOpen,
    sidePanel,
    sourcesOpen,
    sourceAvailable,
    loading,
    params,
  ]);
  useEffect(() => {
    if (!document || !location.hash) return;
    let id: string;
    try {
      id = decodeURIComponent(location.hash.slice(1));
    } catch {
      return;
    }
    const frame = requestAnimationFrame(() => {
      const heading = findRenderedHeading(id);
      if (heading && root.current?.contains(heading)) heading.scrollIntoView();
    });
    return () => cancelAnimationFrame(frame);
  }, [document]);
  function closePanel() {
    setSidePanel('closed');
    requestAnimationFrame(() => returnFocus.current?.focus());
  }
  function openSearch() {
    if (loading || !sourceAvailable) return;
    returnFocus.current = globalThis.document.activeElement as HTMLElement;
    setSourcesOpen(false);
    setSearchOpen(true);
  }
  function closeSearch() {
    setSearchOpen(false);
    search.cancel();
    requestAnimationFrame(() => returnFocus.current?.focus());
  }
  function toggle(panel: SidePanel) {
    returnFocus.current = globalThis.document.activeElement as HTMLElement;
    setDetent('expanded');
    setSidePanel((current) => (current === panel ? 'closed' : panel));
  }
  function closeExplore() {
    setParams((current) => {
      const next = new URLSearchParams(current);
      next.delete('view');
      next.delete('zoom');
      return next;
    });
    requestAnimationFrame(() =>
      root.current
        ?.querySelector<HTMLButtonElement>('.explore-toggle')
        ?.focus(),
    );
  }
  function closeZoomReader() {
    setSidePanel('closed');
    setFocusReader(false);
    setParams((current) => {
      const next = new URLSearchParams(current);
      next.delete('zoom');
      return next;
    });
    requestAnimationFrame(() =>
      root.current
        ?.querySelector<HTMLElement>('.graph-nodes [role="button"]')
        ?.focus(),
    );
  }
  function toggleExplore() {
    if (exploring) {
      closeExplore();
      return;
    }
    setFocusReader(false);
    setSidePanel('closed');
    setParams((current) => {
      const next = new URLSearchParams(current);
      next.set('view', 'explore');
      next.delete('zoom');
      return next;
    });
  }
  function openHome() {
    documentRequests.current.invalidate();
    setParams({ project: projectId, ...(source ? { source } : {}) });
    setDocument(undefined);
    setError(undefined);
    setSourcesOpen(false);
    setFocusReader(false);
    setSidePanel('closed');
    window.location.hash = '';
  }
  function closeSources() {
    setSourcesOpen(false);
    requestAnimationFrame(() => returnFocus.current?.focus());
  }
  function toggleSources() {
    returnFocus.current = globalThis.document.activeElement as HTMLElement;
    setSidePanel('closed');
    setSourcesOpen((value) => !value);
  }
  function selectSource(nextSource: string) {
    if (nextSource && !repositories.some((repo) => repo.slug === nextSource))
      return;
    search.cancel();
    setParams((current) => {
      const next = new URLSearchParams(current);
      nextSource ? next.set('source', nextSource) : next.delete('source');
      return next;
    });
  }
  const readerHeader = document ? (
    <ReaderHeader
      document={document}
      repository={repositories.find(
        (repo) => repo.slug === document.repository,
      )}
      sidePanel={sidePanel}
      onToggle={toggle}
      onBack={zoomReading ? closeZoomReader : openHome}
      backLabel={zoomReading ? 'Back to Explore' : 'Back to Library'}
    />
  ) : null;
  if (denied)
    return (
      <section className="ws-surface">
        <header className="ws-surface-header">
          <h1>Knowledge access unavailable.</h1>
        </header>
        <div className="ws-empty">
          <p>
            Your Core or source access changed. Refresh the workspace to check
            your current access.
          </p>
          <button
            className="ws-button"
            onClick={() => window.location.reload()}
          >
            Refresh workspace
          </button>
        </div>
      </section>
    );
  return (
    <div
      className="studio-knowledge"
      ref={root}
      data-theme={prefs.theme}
      aria-label="Floor Knowledge"
    >
      <div
        className={`core-knowledge-shell${focusReader ? ' focus-reader' : ''}`}
        data-reader-text-size={prefs.readerTextSize}
        data-reader-width={prefs.readerWidth}
        data-side-panel={sidePanel}
      >
        <KnowledgeHeader
          exploring={exploring}
          onLibrary={openHome}
          onExplore={() => {
            if (!exploring) toggleExplore();
            else if (zoomReading) closeZoomReader();
          }}
          onSearch={openSearch}
          disabled={loading || !sourceAvailable}
        />
        <KnowledgeScope
          name={
            source
              ? scopedRepositories[0]?.displayName || (loading ? 'Loading source…' : 'Unavailable source')
              : 'All floor sources'
          }
          pending={loading && !repositories.length}
          count={scopedRepositories.reduce(
            (sum, repo) => sum + repo.documentCount,
            0,
          )}
          sourceOpen={sourcesOpen}
          onSources={toggleSources}
          onClear={() => selectSource('')}
          filtered={!!source}
        />
        <CommandSearch
          error={search.error}
          hasSearched={search.hasSearched}
          meaningResponse={search.meaningResponse}
          mode={search.mode}
          onClose={closeSearch}
          onModeChange={search.changeMode}
          onOpenMeaningSection={(result, section, newTab) =>
            open(result.repository, result.path, section.headingId, newTab)
          }
          onOpenResult={(result, newTab) =>
            open(result.repository, result.path, result.headingId, newTab)
          }
          onQueryChange={search.setQuery}
          onRepositoryChange={selectSource}
          onSearch={search.submit}
          onSearchByMeaning={search.searchByMeaning}
          open={searchOpen}
          pending={search.pending}
          query={search.query}
          readiness={search.readiness}
          readinessError={search.readinessError}
          readinessPending={search.readinessPending}
          repositories={repositories}
          repository={search.repository}
          results={search.results}
        />
        <div className="knowledge-body" inert={sourcesOpen}>
          <section
            aria-label="Knowledge reader"
            className={`reader-panel atlas-scroll-surface${!exploring || zoomReading ? ' native-reading-surface' : ' native-explore-surface'}`}
            data-reader-theme={prefs.theme}
            data-sheet-background
            ref={panel}
          >
            {!sourceAvailable && !loading && (
              <div className="error-banner" role="alert">
                This source scope is unavailable. Clear the source to browse
                admitted knowledge.
              </div>
            )}
            {error && (
              <div className="error-banner" role="alert">
                {error}
                <button onClick={() => setRefresh((x) => x + 1)}>
                  Retry library
                </button>
              </div>
            )}
            {loading && !repositories.length && !exploring && !document && <LoadingState label={path ? 'Loading document…' : 'Loading library…'} size="page" />}
            {documentLoading && !loading && !exploring && <LoadingState label={document ? 'Loading next document…' : 'Loading document…'} size={document ? 'inline' : 'page'} />}
            {exploring && documentLoading && <div className="knowledge-read-pending"><LoadingState label="Loading document…" size="inline" /></div>}
            {exploring ? (
              graph && graphSource === source ? (
                <>
                  <KnowledgeGraphCanvas
                    key={source}
                    inactive={zoomReading}
                    graph={graph}
                    focusId={
                      document
                        ? `${document.repository}:${document.path}`
                        : undefined
                    }
                    onClose={closeExplore}
                    onOpen={(node) =>
                      void open(
                        node.repository,
                        node.path,
                        undefined,
                        false,
                        undefined,
                        true,
                      )
                    }
                    onEnter={(node, origin) =>
                      void open(
                        node.repository,
                        node.path,
                        undefined,
                        false,
                        origin,
                      )
                    }
                  />
                  {zoomReading && document && (
                    <SemanticReader
                      document={document}
                      onExit={closeZoomReader}
                      transitionOrigin={entryOrigin}
                    >
                      {readerHeader}
                      <article
                        ref={article}
                        className="markdown-body"
                        dangerouslySetInnerHTML={{ __html: articleHtml }}
                      />
                    </SemanticReader>
                  )}
                </>
              ) : graphLoading || loading ? <LoadingState label="Loading Explore…" size="page" overlay /> : !error && sourceAvailable && repositories.length === 0 ? (
                <TerminalState
                  eyebrow="Explore"
                  title="No sources to explore"
                  detail="This floor has no documentation sources available. Add sources to the floor to build its knowledge map."
                  actions={<button onClick={closeExplore}>Return to library</button>}
                />
              ) : (
                <TerminalState
                  eyebrow="Explore"
                  title="Knowledge graph is unavailable"
                  detail="Return to the library or retry the relationship map."
                  live="off"
                  actions={
                    graphError ? (
                      <>
                        <button onClick={() => setGraphRefresh((x) => x + 1)}>
                          Retry map
                        </button>
                        <button onClick={closeExplore}>
                          Return to document
                        </button>
                      </>
                    ) : undefined
                  }
                />
              )
            ) : document ? (
              <>
                {readerHeader}
                <article
                  ref={article}
                  className="markdown-body"
                  dangerouslySetInnerHTML={{ __html: articleHtml }}
                />
              </>
            ) : (
              (!loading || repositories.length > 0) && !documentLoading && !error &&
              home && (
                <LibraryHome
                  continueReading={
                    progress && (!source || progress.repository === source)
                      ? progress
                      : undefined
                  }
                  onOpenContinue={(value) => open(value.repository, value.path)}
                  onOpenDocument={open}
                  onOpenReview={(entry) => open(entry.repository, entry.path)}
                  onOpenRepository={(repo) =>
                    open(repo.slug, repositoryOverviewPath(repo.slug))
                  }
                  onOpenSearch={openSearch}
                  onRetryUpdates={() => setRefresh((x) => x + 1)}
                  onRetryReviewQueue={() => setRefresh((x) => x + 1)}
                  repositories={scopedRepositories}
                  updates={
                    updates
                      ? {
                          ...updates,
                          entries: updates.entries.filter(
                            (entry) => !source || entry.repository === source,
                          ),
                        }
                      : undefined
                  }
                  updatesError={updatesError}
                  reviewQueue={
                    reviewQueue
                      ? {
                          ...reviewQueue,
                          entries: reviewQueue.entries.filter(
                            (entry) => !source || entry.repository === source,
                          ),
                        }
                      : undefined
                  }
                  reviewQueueError={reviewQueueError}
                />
              )
            )}
          </section>
          {(!exploring || zoomReading) && sidePanel !== 'closed' && (
            <DocumentPanel
              readerOnly
              baseCommit=""
              comparison={undefined}
              comparisonActive={false}
              compact={compact}
              contextMode="contents"
              detent={detent}
              document={document}
              focusReader={focusReader}
              focusAvailable={!!document}
              headCommit=""
              history={undefined}
              historyError={false}
              onBaseCommitChange={() => {}}
              onClose={closePanel}
              onCompare={() => {}}
              onContextModeChange={() => {}}
              onDetentChange={setDetent}
              onExploreGraph={() => {}}
              onHeadCommitChange={() => {}}
              onMarkReviewed={() => {}}
              onOpenRelated={(next) =>
                document && open(document.repository, next)
              }
              onPrepareCompare={() => {}}
              onReviewChanges={() => {}}
              onReaderWidthChange={prefs.setReaderWidth}
              onResetDisplayPreferences={prefs.resetDisplayPreferences}
              onRetryHistory={() => {}}
              onTextSizeChange={prefs.setReaderTextSize}
              onThemeChange={prefs.setTheme}
              onToggleFocus={() => setFocusReader((x) => !x)}
              readerWidth={prefs.readerWidth}
              readerTextSize={prefs.readerTextSize}
              relationships={undefined}
              reviewError={false}
              reviewPending={false}
              repository={repositories.find(
                (repo) => repo.slug === document?.repository,
              )}
              sidePanel={sidePanel}
              theme={prefs.theme}
              restoreDiffFocus={false}
            />
          )}
        </div>
        {sourcesOpen && (
          <>
            <div className="knowledge-drawer-backdrop" onClick={closeSources} />
            <SourcesDrawer
              repositories={repositories}
              currentDocument={document}
              source={source}
              onSource={selectSource}
              onOpenDocument={(repo, path) => void open(repo, path)}
              onClose={closeSources}
            />
          </>
        )}
      </div>
    </div>
  );
}
