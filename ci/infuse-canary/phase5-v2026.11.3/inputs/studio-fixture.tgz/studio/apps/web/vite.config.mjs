import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

const here = path => fileURLToPath(new URL(path, import.meta.url));

export default defineConfig({
  plugins: [react()],
  root: here('./src'),
  publicDir: here('./public'),
  server: {
    host: '127.0.0.1',
    port: 4320,
    strictPort: true,
    // Keep browser source modules outside src/api: this URL space belongs to HTTP.
    proxy: { '/api': process.env.STUDIO_API_ORIGIN || 'http://127.0.0.1:4321' },
  },
  build: { outDir: here('./dist'), emptyOutDir: true },
});
