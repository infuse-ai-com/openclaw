import {useEffect,useRef,useState} from 'react';
import {missionIdentifier,parseHealthDeliveryControl,parseAlertDelivery,healthObject,healthTime,type HealthDeliveryControl} from '@studio/contracts';
import {api,ApiError,getSession,readableError} from './api.js';
import {useWorkspace} from './context.js';
interface Envelope {checkId:string;floor:string;command:HealthDeliveryControl}
function parseEnvelope(raw:unknown):Envelope {const o=healthObject(raw);return {checkId:missionIdentifier(o.checkId),floor:o.floor===''?'':missionIdentifier(o.floor),command:parseHealthDeliveryControl(o.command)};}
const definitive=new Set(['INVALID_INPUT','VERSION_CONFLICT','CONFIRMATION_REQUIRED','INVALID_STATE']);
/** One explicit recoverable control envelope per identity; reads/polling never repeat a mutation. */
export function useMonitoringCommands(onRecorded:()=>void) {
 const {session,current}=useWorkspace(),key=`infuse-studio:monitoring-control:${encodeURIComponent(session.bootstrap.authorityId)}:${encodeURIComponent(session.profileId)}`;
 const [recovered]=useState(()=>{try{const raw=sessionStorage.getItem(key);return {pending:raw?parseEnvelope(JSON.parse(raw)):undefined,error:''};}catch{return {pending:undefined,error:'Saved alert control could not be read. Inspect its audit before starting another control.'};}});
 const [pending,setPending]=useState<Envelope|undefined>(recovered.pending),[busy,setBusy]=useState(false),[error,setError]=useState(recovered.error),[notice,setNotice]=useState('');
 const mounted=useRef(true),locked=useRef(false),pendingRef=useRef(pending);useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
 async function execute(envelope:Envelope) {
  if(locked.current||!current||!navigator.onLine)return;
  try{const serialized=JSON.stringify(envelope);if(serialized.length>4096)throw Error('Control envelope exceeds its bound');sessionStorage.setItem(key,serialized);}catch{setError('Browser recovery storage is unavailable. No alert control was sent.');return;}
  pendingRef.current=envelope;setPending(envelope);locked.current=true;setBusy(true);setError('');setNotice('');
  try {
   const fresh=await getSession(undefined,()=>mounted.current,session.project.id);
   if(!mounted.current)return;
   if(!fresh.authenticated||fresh.profileId!==session.profileId||fresh.bootstrap.authorityId!==session.bootstrap.authorityId)throw Error('Reconnect as the original identity to recover this alert control.');
   const result=healthObject(await api(`/api/monitoring/checks/${encodeURIComponent(envelope.checkId)}/deliveries/actions${envelope.floor?'?'+new URLSearchParams({floor:envelope.floor}):''}`,{command:envelope.command,csrf:fresh.csrfToken,isCurrent:()=>mounted.current}));
   const delivery=parseAlertDelivery(result.delivery);healthTime(result.at);
   if(result.commandId!==envelope.command.commandId||delivery.id!==envelope.command.deliveryId||delivery.checkId!==envelope.checkId||delivery.revision!==envelope.command.expectedRevision+1)throw Error('The alert control receipt did not match the exact reviewed command.');
   if(!mounted.current)return;
   sessionStorage.removeItem(key);pendingRef.current=undefined;setPending(undefined);setNotice('Alert control recorded. The durable delivery state will refresh.');onRecorded();
  }catch(error){if(!mounted.current)return;
   if(error instanceof ApiError&&definitive.has(error.code))try{sessionStorage.removeItem(key);pendingRef.current=undefined;setPending(undefined);onRecorded();}catch{/* Keep the exact envelope recoverable. */}
   setError(readableError(error));
  }finally{locked.current=false;if(mounted.current)setBusy(false);}
 }
 return {pending,busy,error,notice,blocked:!!recovered.error,send:(envelope:Envelope)=>!pendingRef.current&&!recovered.error?execute(parseEnvelope(envelope)):Promise.resolve(),retry:()=>pendingRef.current?execute(pendingRef.current):Promise.resolve()};
}
