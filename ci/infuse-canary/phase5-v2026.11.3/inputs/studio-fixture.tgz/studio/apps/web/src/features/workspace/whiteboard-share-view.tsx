import { Button } from './ui.js';
import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { whiteboardViewTarget } from '@studio/contracts';
import { api, projectPath } from './api.js';
import type { BoardPresence } from './whiteboard-presence.js';

/** A small native picker keeps sharing beside people, without opening an editor panel. */
export function WhiteboardShareView({projectId,presence}:{projectId:string;presence:BoardPresence}) {
  const targets=useQuery({queryKey:['whiteboard-share-targets',projectId],queryFn:async()=>{
    const value=await api(projectPath('/api/studio/whiteboard/v3/agents',projectId)) as {agents:unknown[]};
    return value.agents.map(target=>whiteboardViewTarget.parse(target));
  },refetchInterval:10000,retry:false});
  const selected=presence.state.shareView,encoded=selected?JSON.stringify(selected):'';
  useEffect(()=>{if(selected&&targets.data&&!targets.data.some(t=>t.gatewayId===selected.gatewayId&&t.agentId===selected.agentId))presence.update({shareView:null});},[presence,selected,targets.data]);
  if(!targets.data?.length&&!selected)return null;
  return <div className="wboard-share-view wboard-float" role="group" aria-label="Share your view with an agent">
    <select className="ui-control" aria-label="Share view with agent" title="Share your section, visible area and selected items. Unsaved text is never shared."
      value={encoded} disabled={presence.status!=='Connected'} onChange={event=>presence.update({shareView:event.target.value?whiteboardViewTarget.parse(JSON.parse(event.target.value)):null})}>
      <option value="">Share view…</option>
      {(targets.data??[]).map(target=><option key={JSON.stringify(target)} value={JSON.stringify(target)}>{target.agentId} · {target.gatewayId}</option>)}
    </select>
    {selected&&<Button variant="quiet" type="button" onClick={()=>presence.update({shareView:null})}>Stop sharing</Button>}
    <span className="wboard-sr-only" role="status">{selected?'Sharing your view with '+selected.agentId+'. Unsaved text stays private.':'Your view is not shared with agents.'}</span>
  </div>;
}
