import { Tooltip } from 'radix-ui';
import { useEffect, useRef, useState, type ReactElement } from 'react';

type HintProps = { label: string; children: ReactElement; side?: 'bottom' | 'right'; enabled?: boolean };

export function ControlHint({ enabled = true, ...props }: HintProps) {
  return enabled ? <Hint {...props} /> : props.children;
}

function Hint({ label, children, side = 'bottom' }: HintProps) {
  const trigger = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false), [keyboard, setKeyboard] = useState(false);

  // Tabbing to an offscreen icon scrolls the rail. Keep its label visible through
  // that scroll, until focus leaves, Escape dismisses it, or the pointer takes over.
  useEffect(() => {
    if (!keyboard) return;
    const release = () => setKeyboard(false);
    document.addEventListener('pointermove', release, { once: true });
    return () => document.removeEventListener('pointermove', release);
  }, [keyboard]);
  return <Tooltip.Root open={open || keyboard} onOpenChange={setOpen}>
    <Tooltip.Trigger asChild ref={trigger} onFocus={e => setKeyboard(e.currentTarget.matches(':focus-visible'))}
      onBlur={() => setKeyboard(false)} onPointerDown={() => setKeyboard(false)}>{children}</Tooltip.Trigger>
    <Tooltip.Portal container={trigger.current?.closest('dialog, .studio-workbench')}>
      <Tooltip.Content className="ws-control-hint" side={side} sideOffset={6} collisionPadding={8} hideWhenDetached
        onEscapeKeyDown={() => { setOpen(false); setKeyboard(false); }}>{label}</Tooltip.Content>
    </Tooltip.Portal>
  </Tooltip.Root>;
}
