import { Button } from './ui.js';
import type { RepositorySetup } from '@studio/contracts';

/** Historical setup records remain readable; registration and edits are retired. */
export function RepositorySetupForm({ initial, onClose }: {
  initial?: RepositorySetup; revision?: number;
  onConnected(repository: { id: string; slug: string }): void; onClose(): void;
}) {
  return <section className="ws-form-paper ui-layout-form ui-page-content" aria-label="Repository setup">
    <h2>{initial ? 'Repository settings' : 'Connect repository'}</h2>
    <p role="status">Repository registration and settings changes are unavailable. A GitLab-backed replacement is not yet available; existing sources remain available for review.</p>
    <Button variant="quiet" type="button" onClick={onClose}>Return to floor</Button>
  </section>;
}
