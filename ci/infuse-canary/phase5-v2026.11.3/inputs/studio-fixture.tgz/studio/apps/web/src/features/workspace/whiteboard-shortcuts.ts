import type { ComponentProps, KeyboardEvent } from 'react';
import type { WhiteboardCanvas } from './whiteboard-canvas.js';
import type { BoardPanel, CanvasItem } from './whiteboard-types.js';
import { isTyping } from './whiteboard-history.js';
import { defaultShape } from './whiteboard-shapes.js';
import { readableError } from './api.js';
type Controls = Pick<ComponentProps<typeof WhiteboardCanvas>,
  'canvas' | 'tool' | 'setTool' | 'setAutoFocusId' | 'setFocused' | 'setPanel' | 'blocks' |
  'setLockPrompt' | 'flow' | 'viewport' | 'saveShape' | 'shapeKind' | 'penColor' | 'penWidth' | 'setMessage' | 'create'> & {
  panel: BoardPanel; focused: CanvasItem | null; lockPrompt: unknown;
  canvasSize: { width: number; height: number }; selection: string[];
  dismissPanel(): void; copySelection(): Promise<void>; reverse(direction: 'undo' | 'redo'): Promise<void>;
  selectionAction(action: 'duplicate' | 'delete'): Promise<void>;
};
/** Keyboard equivalents for canvas gestures; mutations stay with their action owners. */
export function whiteboardKeyDown(controls: Controls, event: KeyboardEvent<HTMLElement>) {
  const { canvas, tool, setTool, setAutoFocusId, panel, dismissPanel, focused, setFocused, setPanel, blocks, selection, copySelection, selectionAction, reverse, lockPrompt, setLockPrompt, flow, viewport, canvasSize, saveShape, shapeKind, penColor, penWidth, setMessage, create } = controls;

  if (event.key === 'Escape') {
    if (lockPrompt) {
      event.preventDefault();
      event.stopPropagation();
      setLockPrompt(null);
      canvas.current?.focus();
      return;
    }
    if (tool === 'note' || tool === 'shape') {
      event.preventDefault();
      setTool('select');
      canvas.current?.focus();
      return;
    }
    setAutoFocusId(null);
    if (panel) {
      event.stopPropagation();
      dismissPanel();
    } else if (focused?.kind === 'note' || focused?.kind === 'document') {
      event.stopPropagation();
      setFocused(null);
      canvas.current?.focus();
    }
  }
  if (isTyping(event.target)) return;
  if (
    event.key === 'Enter' &&
    event.shiftKey &&
    (event.target as Element).closest('.react-flow__node')
  )
    setAutoFocusId(null);
  const key = event.key.toLowerCase(),
    modifier = event.metaKey || event.ctrlKey;
  if (
    tool === 'shape' &&
    event.key === 'Enter' &&
    (event.target === canvas.current ||
      (event.target as Element).classList.contains('wboard-shape-layer'))
  ) {
    event.preventDefault();
    const camera = flow.current?.getViewport() ?? viewport;
    try {
      void saveShape(
        defaultShape(
          shapeKind,
          [
            (canvasSize.width / 2 - camera.x) / camera.zoom,
            (canvasSize.height / 2 - camera.y) / camera.zoom,
          ],
          penColor,
          penWidth,
          crypto.randomUUID(),
        ),
      );
    } catch (error) {
      setMessage(readableError(error));
    }
  } else if (tool === 'note' && event.key === 'Enter') {
    event.preventDefault();
    void create('note');
  } else if (
    event.key === 'Enter' &&
    !event.shiftKey &&
    tool === 'select' &&
    (event.target as Element).closest('.react-flow__node')
  ) {
    const item = blocks.find(
      (b) =>
        b.id ===
        (event.target as Element).closest('.react-flow__node')?.getAttribute('data-id'),
    );
    if (
      item &&
      (item.kind === 'note' ||
        item.kind === 'document' ||
        (item.kind === 'stroke' && !!item.shape))
    ) {
      event.preventDefault();
      setFocused(item);
      setAutoFocusId(item.id);
      setPanel(null);
    }
  } else if (modifier && key === 'z') {
    event.preventDefault();
    void reverse(event.shiftKey ? 'redo' : 'undo');
  } else if (modifier && key === 'y') {
    event.preventDefault();
    void reverse('redo');
  } else if (modifier && key === 'c' && selection.length) {
    event.preventDefault();
    void copySelection();
  } else if (modifier && key === 'd') {
    event.preventDefault();
    void selectionAction('duplicate');
  } else if ((key === 'delete' || key === 'backspace') && selection.length) {
    event.preventDefault();
    void selectionAction('delete');
  }
}
