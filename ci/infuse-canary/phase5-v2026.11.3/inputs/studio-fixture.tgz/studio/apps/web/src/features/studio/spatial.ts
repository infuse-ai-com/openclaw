import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { furnishOffice, type BoardPaper, type Finish, type OfficeLayout, type ReviewPaper } from '@studio/spatial/office';
import { createOfficeMaterials, surfaceUVs } from '@studio/spatial/office-materials';
import { OFFICE_WORKSTATIONS } from '@studio/spatial/office-presence';
import { createFloorActors } from './floor-actors.js';
import { createFloorAtmosphere } from './floor-atmosphere.js';
import { icons } from '@studio/ui/icons';
import type { SpatialDestination, SpatialProjection } from './spatial-projection.js';
import { createFloorExplorer, type ExplorerSummary, type FloorNavigation } from './floor-explorer.js';

const layout: OfficeLayout = {
  width: 22, depth: 14, board: [-8.65, -5.6], shelf: [-4.7, -5.8],
  founder: [-8.3, 2.5], operations: [8.2, -5.3], lounge: [4.15, 4.3], entrance: [-2.3, 6.15],
  // These are furniture positions, not a company roster or a claim of project membership.
  workstations: OFFICE_WORKSTATIONS,
};
const places: Record<SpatialDestination, [number, number, number]> = {
  missions: [-7.9, 2.8, -4.7], paper: [-7.9, 2.1, 2.3], activity: [.3, 2.3, -3.8], evidence: [9.5, 2.8, -.3],
};
const zones: Record<string, SpatialDestination> = {
  whiteboard: 'missions', founder: 'paper', team: 'activity', review: 'evidence', entrance: 'missions',
};
const defaultLabels: Record<SpatialDestination, string> = { missions: 'Missions', paper: 'Mission paper', activity: 'Team & activity', evidence: 'Evidence review' };
const destinationIcons: Record<SpatialDestination, string> = { missions: icons.files, paper: icons.document, activity: icons.operations, evidence: icons.review };

function setDestinationLabel(button: HTMLButtonElement, destination: SpatialDestination, text: string): void {
  const icon = document.createElement('span');
  icon.className = 'studio-space-destination-icon'; icon.setAttribute('aria-hidden', 'true');
  icon.innerHTML = destinationIcons[destination];
  const label = document.createElement('span');
  label.className = 'studio-space-destination-label'; label.textContent = text;
  button.replaceChildren(icon, label);
}

export interface AgentScreenAnchor { key: string; x: number; y: number; visible: boolean }

export interface StudioSpace {
  readonly element: HTMLElement;
  update(projection: SpatialProjection): void;
  setPresented(presented: boolean): void;
  setAtmosphere(now: Date): void;
  selectAgent(key: string | null): void;
  setFloorSummary(summary: ExplorerSummary): void;
  dispose(): void;
}

/** One Studio floor with authoritative labels. Furniture is shared; no demo state is imported. */
export function createStudioSpace(onNavigate: (destination: SpatialDestination) => void, destinationLabels: Partial<Record<SpatialDestination, string>> = {}, options: { living?: boolean; projectName?: string; floorNavigation?: FloorNavigation; onAgentSelect?(key: string): void; onAgentAnchor?(anchor: AgentScreenAnchor | null): void; onBackgroundClick?(): void; onSettled?(): void } = {}): StudioSpace {
  const labels = { ...defaultLabels, ...destinationLabels };
  const element = document.createElement('section');
  element.className = 'studio-space';
  element.dataset.living = String(!!options.living);
  element.dataset.webgl = 'loading';
  element.setAttribute('aria-label', 'Studio spatial workspace');
  element.innerHTML = `<header class="studio-space-heading"><div><span class="studio-kicker">YOUR STUDIO WORKSPACE</span><h2>A place for the work.</h2></div><button type="button" class="studio-space-toggle" aria-expanded="true">Hide workspace</button></header><div class="studio-space-body"><div class="studio-space-scene"><div class="studio-space-viewport"></div><div class="studio-space-controls" role="group" aria-label="Workspace camera"><button type="button" data-camera="out" aria-label="Zoom out">−</button><button type="button" data-camera="in" aria-label="Zoom in">＋</button><button type="button" data-camera="fit">Fit workspace</button></div><p class="studio-space-hint">Drag to pan · + / − to zoom · Home to fit</p></div><aside class="studio-space-context"><span class="studio-kicker" data-space-status></span><h3 data-space-title></h3><p data-space-subtitle></p><div class="studio-space-people"></div><nav class="studio-space-links" aria-label="Workspace destinations"></nav><p class="studio-space-boundary">One mission workspace. Furniture is a navigation aid; status comes from the authority.</p></aside></div>`;
  const viewport = element.querySelector<HTMLElement>('.studio-space-viewport')!;
  const body = element.querySelector<HTMLElement>('.studio-space-body')!;
  const toggle = element.querySelector<HTMLButtonElement>('.studio-space-toggle')!;
  const people = element.querySelector<HTMLElement>('.studio-space-people')!;
  const links = element.querySelector<HTMLElement>('.studio-space-links')!;
  let disposed = false;
  let presented = true;
  let expanded = true;
  let failed = false;
  let frame = 0;
  let renderer: THREE.WebGLRenderer | undefined;
  let controls: OrbitControls | undefined;
  let explorer: ReturnType<typeof createFloorExplorer> | undefined;
  let materials: ReturnType<typeof createOfficeMaterials> | undefined;
  let observer: ResizeObserver | undefined;
  let assetsReady = false;
  let cameraMoved = false;
  let atmosphere: ReturnType<typeof createFloorAtmosphere> | undefined;
  let selectedAgent: string | null = null;
  let occupants: ReturnType<typeof createFloorActors> | undefined;
  let elapsed = 0, lastTime = 0, drawCount = 0;
  let arrival = !!options.living;
  const endArrival = () => { arrival = false; if (!cameraMoved && options.living) { camera.zoom=1;camera.updateProjectionMatrix(); } queueDraw(); };
  const ownedMaterials = new Map<string | number, THREE.Material>();
  const ownedTextures: THREE.Texture[] = [];
  const scene = new THREE.Scene();
  const office = new THREE.Group();
  office.userData.floor = 'studio';
  scene.add(office);
  const camera = new THREE.OrthographicCamera(-15, 15, 11, -11, .1, 120);
  const boardPapers: BoardPaper[] = [];
  const reviewPapers: ReviewPaper[] = [];
  const actorLayer = new THREE.Group();
  const actors: THREE.Group[] = [];
  const pins: { element: HTMLButtonElement; position: THREE.Vector3; destination: SpatialDestination }[] = [];
  const actorPins: HTMLButtonElement[] = [];
  const labelLayer = document.createElement('div'); labelLayer.className = 'studio-space-labels';
  const projected = new THREE.Vector3();
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  element.dataset.reducedMotion = String(reducedMotion.matches);
  if(reducedMotion.matches)arrival=false;
  const loadingTimeout=window.setTimeout(()=>{if(!disposed&&!assetsReady)fallback();},30000);
  const loadingManager=new THREE.LoadingManager(()=>{
    if(disposed||failed)return;
    assetsReady=true;clearTimeout(loadingTimeout);queueDraw();
  });

  for (const destination of Object.keys(labels) as SpatialDestination[]) {
    const button = document.createElement('button');
    button.type = 'button'; button.dataset.spaceDestination = destination;
    setDestinationLabel(button, destination, labels[destination]);
    links.append(button);
  }
  function fallback(): void {
    if(disposed||failed)return;
    clearTimeout(loadingTimeout);
    explorer?.dispose(); explorer = undefined;
    failed = true; element.dataset.webgl = 'unavailable'; options.onAgentAnchor?.(null);
    cancelAnimationFrame(frame); frame = 0;
    atmosphere?.dispose(); atmosphere=undefined; occupants?.setPresented(false);
    viewport.replaceChildren();
    const message = document.createElement('div'); message.className = 'studio-space-fallback';
    message.innerHTML = '<span aria-hidden="true">▤</span><h3>Your mission desk is ready.</h3><p>The spatial view is unavailable in this browser. Use the workspace links or mission list below; every mission action remains available.</p>';
    viewport.append(message);
    element.querySelector<HTMLElement>('.studio-space-controls')!.hidden = true;
    element.querySelector<HTMLElement>('.studio-space-hint')!.hidden = true;
    options.onSettled?.();
  }
  function finish(value: Finish): THREE.Material {
    if (value instanceof THREE.Material) return value;
    const color = value instanceof THREE.Color ? value.getHex() : value;
    let material = ownedMaterials.get(color);
    if (!material) {
      material = new THREE.MeshStandardMaterial(color === 'lamp'
        ? { color: 0xffe3ab, emissive: 0xffbe63, emissiveIntensity: .8, roughness: .6 }
        : { color, roughness: .85 });
      ownedMaterials.set(color, material);
    }
    return material;
  }
  function box(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, value: Finish, cast = true): THREE.Mesh {
    const material = finish(value);
    const mesh = new THREE.Mesh(surfaceUVs(new THREE.BoxGeometry(w, h, d), Number(material.userData.surfaceScale ?? 0)), material);
    mesh.position.set(x, y, z); mesh.castShadow = cast; mesh.receiveShadow = true; parent.add(mesh); return mesh;
  }
  function softBox(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, value: Finish, radius = .025): THREE.Mesh {
    const material = finish(value);
    const mesh = new THREE.Mesh(surfaceUVs(new RoundedBoxGeometry(w, h, d, 1, radius), Number(material.userData.surfaceScale ?? 0)), material);
    mesh.position.set(x, y, z); mesh.castShadow = mesh.receiveShadow = true; parent.add(mesh); return mesh;
  }
  function part(parent: THREE.Object3D, id: string, x: number, z: number): THREE.Group {
    const group = new THREE.Group(); group.position.set(x, 0, z); group.userData.zone = zones[id]; parent.add(group); return group;
  }
  function signMaterial(title: string): THREE.Material {
    const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 180;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#243e30'; ctx.fillRect(0, 0, 512, 180);
    ctx.fillStyle = '#f5efdc'; ctx.font = '600 106px StudioCondensed, sans-serif'; ctx.fillText(title, 24, 127);
    ctx.fillStyle = '#fe6b27'; ctx.fillRect(436, 109, 16, 16);
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace; ownedTextures.push(texture);
    const material = new THREE.MeshBasicMaterial({ map: texture }); ownedMaterials.set('sign', material); return material;
  }
  function batchFurniture(): void {
    office.updateMatrixWorld(true);
    const mutable = new Set<THREE.Mesh>([...boardPapers.flatMap(p => [p.mesh, ...p.marks]), ...reviewPapers.flatMap(p => [p.mesh, p.pin])]);
    const batches = new Map<string, { meshes: THREE.Mesh<THREE.BufferGeometry, THREE.Material>[]; material: THREE.Material; zone?: SpatialDestination; shadow: boolean }>();
    office.traverse(object => {
      if (!(object instanceof THREE.Mesh) || Array.isArray(object.material) || mutable.has(object)) return;
      for(let parent:THREE.Object3D|null=object;parent;parent=parent.parent) if(parent.userData.dynamic)return;
      let zone: SpatialDestination | undefined;
      for (let parent: THREE.Object3D | null = object; parent; parent = parent.parent) zone ??= parent.userData.zone as SpatialDestination | undefined;
      const key = `${zone ?? ''}:${object.material.uuid}:${object.castShadow}`;
      if (!batches.has(key)) batches.set(key, { meshes: [], material: object.material, zone, shadow: object.castShadow });
      batches.get(key)!.meshes.push(object as THREE.Mesh<THREE.BufferGeometry, THREE.Material>);
    });
    for (const batch of batches.values()) {
      const geometries = batch.meshes.map(mesh => (mesh.geometry.index ? mesh.geometry.toNonIndexed() : mesh.geometry.clone()).applyMatrix4(mesh.matrixWorld));
      const geometry = mergeGeometries(geometries);
      geometries.forEach(g => g.dispose());
      if (!geometry) continue;
      const mesh = new THREE.Mesh(geometry, batch.material); mesh.castShadow = batch.shadow; mesh.receiveShadow = true; mesh.userData.zone = batch.zone; office.add(mesh);
      batch.meshes.forEach(old => { old.removeFromParent(); old.geometry.dispose(); });
    }
  }
  function actor(index: number): THREE.Group {
    const group = new THREE.Group();
    const color = index === 0 ? 0xd97638 : 0x66886e;
    box(group, .62, .58, .38, 0, .97, 0, color);
    const head=new THREE.Group();group.add(head);head.position.y=1.5;group.userData.head=head;
    box(head, .44, .43, .42, 0, 0, 0, 0xc6aa89);
    box(head, .48, .16, .45, 0, .23, -.015, 0x3f4838);
    for (const side of [-1, 1]) {
      box(group, .23, .5, .26, side * .18, .45, 0, 0x33493d);
      box(group, .25, .13, .4, side * .18, .17, .04, 0x253a30);
      box(group, .17, .47, .24, side * .4, 1, 0, color);
    }
    const ring = new THREE.Mesh(new THREE.RingGeometry(.58, .67, 32), finish(0xd9b464));
    ring.rotation.x = -Math.PI / 2; ring.position.y = .13; group.add(ring); group.userData.ring = ring;
    group.position.set(index === 0 ? -.2 : 2.25, 0, -.95); group.rotation.y = Math.PI;
    group.userData.zone = 'activity';
    actorLayer.add(group); return group;
  }
  function queueDraw(): void {
    if (disposed || failed || !assetsReady || frame || !presented || !expanded || document.hidden || !element.isConnected) return;
    frame = requestAnimationFrame(draw);
  }
  function draw(time = performance.now()): void {
    frame = 0;
    if (disposed || failed || !assetsReady || !presented || !expanded || document.hidden || !renderer) return;
    if(options.living && lastTime && time-lastTime<1000/30){queueDraw();return;}
    if(lastTime)elapsed+=Math.min(.1,(time-lastTime)/1000);lastTime=time;
    const exploring=explorer?.active() ?? false;
    const exploringMotion=explorer?.tick(time) ?? false;
    const moving=!reducedMotion.matches;
    const motion=atmosphere?.animate(elapsed,moving,arrival&&!exploring);
    if(motion){
      element.dataset.arrival=motion.active?'arriving':'settled';element.dataset.doorOpen=motion.open.toFixed(3);
      element.dataset.flash=motion.flash.toFixed(3);
      if(arrival&&!cameraMoved&&!exploring){camera.zoom=moving?.94+.06*THREE.MathUtils.smoothstep(elapsed,0,1.8):1;camera.updateProjectionMatrix();}
    }
    const peopleMoving=occupants?.animate(time,moving) ?? false;
    if(exploring)renderer.shadowMap.needsUpdate=true;
    try { renderer.render(scene, camera); } catch { fallback();return; }
    element.dataset.frame=String(++drawCount);
    const width = viewport.clientWidth, height = viewport.clientHeight;
    let anchor: AgentScreenAnchor | null = null;
    const viewportRect = selectedAgent ? viewport.getBoundingClientRect() : null;
    const place = (button: HTMLButtonElement, position: THREE.Vector3): void => {
      projected.copy(position).project(camera);
      const x = (projected.x * .5 + .5) * width, y = (-projected.y * .5 + .5) * height;
      button.hidden = projected.z < -1 || projected.z > 1 || x < 8 || x > width - 8 || y < 10 || y > height - 10;
      button.style.left = `${Math.max(60, Math.min(width - 60, x))}px`;
      button.style.top = `${y}px`;
      if (button.dataset.deskKey === selectedAgent && viewportRect) anchor = { key: selectedAgent, x: viewportRect.left + x, y: viewportRect.top + y, visible: !button.hidden };
    };
    pins.forEach(pin => place(pin.element, pin.position));
    occupants?.project(place);
    actors.forEach((group, index) => {
      const button = actorPins[index]!;
      if (!group.visible) { button.hidden = true; return; }
      place(button, group.position.clone().add(new THREE.Vector3(0, 2.05, 0)));
    });
    options.onAgentAnchor?.(exploring?null:anchor);
    if(element.dataset.webgl!=='ready'){element.dataset.webgl='ready';options.onSettled?.();}
    if (exploringMotion || (!exploring&&(motion?.active || motion?.stormMotion || peopleMoving))) queueDraw();
  }
  function resize(): void {
    if (!renderer || !controls || !viewport.clientWidth || !viewport.clientHeight) return;
    const width = viewport.clientWidth, height = viewport.clientHeight;
    renderer.setSize(width, height, false);
    const span = Math.max(options.living ? 18 : 18.5, (options.living ? 26 : 32) * height / width);
    camera.left = -span * width / height / 2; camera.right = -camera.left; camera.top = span / 2; camera.bottom = -span / 2;
    camera.updateProjectionMatrix(); queueDraw();
  }
  function fit(): void {
    if (!controls) return;
    if(explorer?.active()){explorer.cancel();return;}
    controls.target.set(0, .7, 0); camera.position.copy(controls.target).add(new THREE.Vector3(-15, 25, 28));
    camera.zoom = 1; camera.updateProjectionMatrix(); controls.update(); cameraMoved = false; queueDraw();
  }
  function zoom(factor: number): void { if(explorer?.zoom(factor))return;camera.zoom = THREE.MathUtils.clamp(camera.zoom * factor, .65, 2.2); camera.updateProjectionMatrix(); cameraMoved = true; queueDraw(); }
  function focusZone(destination: SpatialDestination): void {
    if (controls) {
      const target = new THREE.Vector3(...places[destination]); target.y = .7;
      camera.position.add(target.clone().sub(controls.target)); controls.target.copy(target);
      camera.zoom = 1.5; camera.updateProjectionMatrix(); controls.update(); cameraMoved = true; queueDraw();
    }
  }
  function click(event: MouseEvent): void {
    const button = event.target instanceof Element ? event.target.closest<HTMLButtonElement>('button') : null;
    if (!button || !element.contains(button)) return;
    const destination = button.dataset.spaceDestination as SpatialDestination | undefined;
    if(button.dataset.deskKey && options.onAgentSelect){endArrival();options.onAgentSelect(button.dataset.deskKey);return;}
    if (destination) { endArrival();focusZone(destination); onNavigate(destination); return; }
    if(button.dataset.camera)endArrival();
    if (button.dataset.camera === 'fit') fit();
    if (button.dataset.camera === 'in') zoom(1.2);
    if (button.dataset.camera === 'out') zoom(1 / 1.2);
    if (button === toggle) {
      expanded = !expanded; body.hidden = !expanded; toggle.setAttribute('aria-expanded', String(expanded));
      toggle.textContent = expanded ? 'Hide workspace' : 'Show workspace';
      if (expanded) { resize(); queueDraw(); } else { cancelAnimationFrame(frame); frame = 0; }
    }
  }
  function keydown(event: KeyboardEvent): void {
    if(explorer?.key(event))return;
    if (event.key === 'Escape')endArrival();
    if (event.target !== renderer?.domElement || !controls) return;
    endArrival();
    const movement: Record<string, [number, number]> = { ArrowLeft: [-.7, 0], ArrowRight: [.7, 0], ArrowUp: [0, -.7], ArrowDown: [0, .7] };
    if (movement[event.key]) {
      event.preventDefault(); const [x, z] = movement[event.key]!;
      controls.target.x = THREE.MathUtils.clamp(controls.target.x + x, -9, 9); controls.target.z = THREE.MathUtils.clamp(controls.target.z + z, -6, 6);
      camera.position.copy(controls.target).add(new THREE.Vector3(-15, 25, 28)); controls.update(); cameraMoved = true; queueDraw();
    } else if (['+', '=', '-', 'Home'].includes(event.key)) {
      event.preventDefault(); if (event.key === 'Home') fit(); else zoom(event.key === '-' ? 1 / 1.2 : 1.2);
    }
  }
  const visibility = (): void => { occupants?.setPresented(presented&&!document.hidden); if (document.hidden) { cancelAnimationFrame(frame); frame = 0; } else queueDraw(); };
  const motion = (): void => { element.dataset.reducedMotion = String(reducedMotion.matches); if(reducedMotion.matches)endArrival();queueDraw(); };
  element.addEventListener('click', click); element.addEventListener('keydown', keydown);
  document.addEventListener('visibilitychange', visibility); reducedMotion.addEventListener('change', motion);

  function initialize(): void {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl2', { antialias: true, alpha: true, powerPreference: 'low-power' });
      if (!gl) { fallback(); return; }
      renderer = new THREE.WebGLRenderer({ canvas, context: gl, antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.3));
      renderer.setClearColor(0x203b2f, 0);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.12;
      renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap;
      canvas.tabIndex = 0; canvas.setAttribute('role', 'img');
      canvas.setAttribute('aria-label', 'Studio office. Arrow keys pan, plus and minus zoom, Home fits. Use workspace links for mission navigation.');
      viewport.append(canvas, labelLayer);
      canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); fallback(); });
      if(!options.living){
      scene.add(new THREE.HemisphereLight(0xfff1d5, 0x425748, 2));
      const sun = new THREE.DirectionalLight(0xffeed3, 3.2); sun.position.set(-8, 18, 5); sun.castShadow = true;
      sun.shadow.mapSize.set(1024, 1024); Object.assign(sun.shadow.camera, { left: -18, right: 18, top: 17, bottom: -17, near: .5, far: 60 });
      sun.shadow.bias = -.0004; sun.shadow.normalBias = .05; scene.add(sun);
      scene.add(new THREE.DirectionalLight(0xdce8d4, .65));
      }
      materials = createOfficeMaterials(renderer,loadingManager);
      const furniture=furnishOffice(office, layout, { title: options.projectName ?? 'Studio' }, {
        living: options.living,
        box, softBox, part, material: finish, surface: materials.surface,
        printMaterial: index => finish([0x90a17b, 0xb59c69, 0x657d68, 0xe1c69d][index % 4]!), signMaterial, boardPapers, reviewPapers,
      });
      batchFurniture(); office.add(actorLayer);
      if(options.living)occupants=createFloorActors(actorLayer,labelLayer,queueDraw);
      else for(let i=0;i<2;i++)actors.push(actor(i));
      if(options.living){
        atmosphere=createFloorAtmosphere(scene,office,furniture.doors,queueDraw,loadingManager);
        renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;
        setAtmosphere(new Date());
      }
      controls = new OrbitControls(camera, canvas); controls.enableRotate = false; controls.enableDamping = false;
      controls.minZoom = .65; controls.maxZoom = 2.2; controls.screenSpacePanning = false;
      controls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
      controls.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_PAN };
      controls.addEventListener('change', () => { cameraMoved = true; queueDraw(); });
      if(options.living&&options.floorNavigation){
        explorer=createFloorExplorer({host:viewport,element,scene,room:office,camera,controls,canvas,labels:labelLayer,navigation:options.floorNavigation,
          redraw:queueDraw,begin:()=>{endArrival();cameraMoved=true;options.onBackgroundClick?.();}});
      }
      for (const destination of ['missions', 'activity', 'evidence'] as const) {
        const pin = document.createElement('button'); pin.type = 'button'; pin.className = 'studio-space-pin';
        pin.dataset.spaceDestination = destination; setDestinationLabel(pin, destination, labels[destination]); pin.title = labels[destination];
        labelLayer.append(pin); pins.push({ element: pin, position: new THREE.Vector3(...places[destination]), destination });
      }
      for (let index = 0; index < actors.length; index++) {
        const pin = document.createElement('button'); pin.type = 'button'; pin.className = 'studio-space-person-pin'; pin.dataset.spaceDestination = 'activity';
        labelLayer.append(pin); actorPins.push(pin);
      }
      let down: { x: number; y: number } | undefined;
      const ray = new THREE.Raycaster(); const point = new THREE.Vector2();
      canvas.addEventListener('pointerdown', event => { endArrival();down = { x: event.clientX, y: event.clientY }; });
      canvas.addEventListener('pointerup', event => {
        if(explorer?.active()){down=undefined;return;}
        if (!down || Math.hypot(event.clientX - down.x, event.clientY - down.y) > 5) { down = undefined; return; }
        down = undefined; const rect = canvas.getBoundingClientRect();
        point.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1); ray.setFromCamera(point, camera);
        const hit = ray.intersectObject(office, true)[0];
        for (let object: THREE.Object3D | null = hit?.object ?? null; object; object = object.parent) {
          if(object.userData.deskKey && options.onAgentSelect){options.onAgentSelect(object.userData.deskKey);return;}
          const destination = object.userData.zone as SpatialDestination | undefined;
          if (destination) { focusZone(destination); onNavigate(destination); return; }
        }
        options.onBackgroundClick?.();
      });
      observer = new ResizeObserver(resize); observer.observe(viewport);
      fit(); resize();
    } catch { fallback(); }
  }
  initialize();

  function update(next: SpatialProjection): void {
    occupants?.update(next);
    const focusedRole = document.activeElement instanceof HTMLElement && people.contains(document.activeElement)
      ? document.activeElement.dataset.spaceRole : undefined;
    element.querySelector('[data-space-status]')!.textContent = next.stale ? 'LAST KNOWN STATE' : next.missionId ? 'SELECTED MISSION' : 'LIVE MISSION DESK';
    element.querySelector('[data-space-title]')!.textContent = next.title;
    element.querySelector('[data-space-subtitle]')!.textContent = next.subtitle;
    people.replaceChildren();
    actors.forEach(group=>{group.visible=false;group.userData.running=false;});
    if (next.agents.length) for (const [index, agent] of next.agents.entries()) {
      const row = document.createElement('button'); row.type = 'button'; row.className = 'studio-space-agent'; row.dataset.spaceDestination = 'activity'; row.dataset.tone = agent.tone; row.dataset.spaceRole = agent.role;
      const mark = document.createElement('span'); mark.className = 'studio-space-agent-mark'; mark.textContent = agent.role === 'coordinator' ? 'C' : 'S';
      const copy = document.createElement('span');
      const name = document.createElement('strong'); name.textContent = agent.target.agentId;
      const role = document.createElement('small'); role.textContent = `${agent.role} · ${agent.target.gatewayId}`;
      const state = document.createElement('span'); state.textContent = agent.status;
      copy.append(name, role, state); row.append(mark, copy); people.append(row);
      const group = actors[index];
      if (group) {
        group.visible = true;group.userData.deskKey=agent.key;group.userData.running=!next.stale&&!!agent.running;
        const ring = group.userData.ring as THREE.Mesh;
        ring.material = finish(agent.tone === 'uncertain' ? 0xc58a39 : agent.tone === 'evidence' ? 0x72a168 : agent.tone === 'admitted' ? 0x9eb39a : 0xc6bc99);
        if(options.living)ring.visible=agent.key===selectedAgent;
        const pin = actorPins[index]!; pin.textContent = agent.name?.split(' ')[0] ?? agent.target.agentId; pin.title = `${agent.role}: ${agent.status}`;
        if(agent.key)pin.dataset.deskKey=agent.key;
        if(options.living){pin.setAttribute('aria-label',`${agent.name ?? agent.target.agentId} · ${agent.status}`);pin.setAttribute('aria-pressed',String(agent.key===selectedAgent));}
      }
    } else {
      const counts = document.createElement('p'); counts.className = 'studio-space-counts';
      counts.textContent = `${next.missionCount} missions loaded · ${next.reviewCount} verified results await review.`;
      const hint = document.createElement('p'); hint.className = 'studio-space-empty-roster'; hint.textContent = 'Open a mission to see its named coordinator and specialist.';
      people.append(counts, hint); actors.forEach(group => { group.visible = false; });
    }
    for (const paper of boardPapers) {
      const recorded = paper.index < Math.min(next.paperCount, 8);
      paper.mesh.material = finish(recorded ? 0xe2c48c : 0xd1c3a5); paper.marks.forEach(mark => { mark.visible = recorded; });
    }
    for (const paper of reviewPapers) { paper.mesh.visible = paper.pin.visible = next.evidencePresent; }
    setDestinationLabel(element.querySelector<HTMLButtonElement>('[data-space-destination=paper]')!, 'paper', next.missionId ? 'Inspect this paper' : 'Shape a new mission');
    element.dataset.missionId = next.missionId ?? '';
    if (focusedRole) people.querySelector<HTMLElement>(`[data-space-role="${focusedRole}"]`)?.focus({ preventScroll: true });
    if (!cameraMoved) resize();
    queueDraw();
  }
  function setAtmosphere(now:Date):void {
    if(!atmosphere)return;
    const state=atmosphere.update(now);element.dataset.weather=state.storm?'storm':'clear';element.dataset.hour=String(now.getHours());element.dataset.night=state.night.toFixed(3);
    if(renderer)renderer.shadowMap.needsUpdate=true;queueDraw();
  }
  return {
    element, update, setAtmosphere, setFloorSummary(value){explorer?.summary(value);},
    selectAgent(key){selectedAgent=key;occupants?.select(key);actors.forEach((group,i)=>{if(options.living)(group.userData.ring as THREE.Mesh).visible=group.userData.deskKey===key;actorPins[i]?.setAttribute('aria-pressed',String(group.userData.deskKey===key));});queueDraw();},
    setPresented(value) { presented = value;occupants?.setPresented(value&&!document.hidden);lastTime=0; if (value) { resize(); queueDraw(); } else { explorer?.cancel();cancelAnimationFrame(frame); frame = 0; } },
    dispose() {
      if (disposed) return;
      disposed = true; clearTimeout(loadingTimeout); explorer?.dispose(); occupants?.dispose(); cancelAnimationFrame(frame); observer?.disconnect(); controls?.dispose();
      document.removeEventListener('visibilitychange', visibility); reducedMotion.removeEventListener('change', motion);
      element.removeEventListener('click', click); element.removeEventListener('keydown', keydown);
      const geometries = new Set<THREE.BufferGeometry>();
      scene.traverse(object => { if (object instanceof THREE.Mesh) geometries.add(object.geometry); });
      geometries.forEach(geometry => geometry.dispose());
      atmosphere?.dispose();
      materials?.dispose(); ownedMaterials.forEach(material => material.dispose()); ownedTextures.forEach(texture => texture.dispose());
      renderer?.dispose(); element.remove();
    },
  };
}
