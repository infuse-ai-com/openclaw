import { RepositoryIndexingNotice, repositoryHealthLabel } from './RepositoryIndexingNotice';
import { LoadingState } from '../../../loading.js';
import {
  useCallback,
  useEffect,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import type {
  Document,
  Repository,
  RepositoryTree,
} from '@studio/contracts/knowledge';
import { useKnowledgeApi } from '../api';
import { libraryFolderLabel } from '../libraryLabels';
import { HeaderIcon } from './TopBar';

interface LibraryPanelProps {
  compactHeader?: boolean;
  scopedRepository?: string;
  currentDocument: Document | undefined;
  home: boolean;
  onOpenDocument: (repository: string, path: string) => void;
  onOpenHome: () => void;
  onOpenRepository: (repository: Repository) => void;
  onOpenSearch: () => void;
  repositories: readonly Repository[];
}

function treeKey(repository: string, path: string): string {
  return `${repository}:${path}`;
}

interface KnowledgeFilters {
  owner: string;
  status: string;
  tag: string;
  type: string;
}

const emptyKnowledgeFilters: KnowledgeFilters = {
  owner: '',
  status: '',
  tag: '',
  type: '',
};

function filteredTreeKey(
  repository: string,
  path: string,
  filters: KnowledgeFilters,
): string {
  return `${treeKey(repository, path)}:${filters.type}:${filters.status}:${filters.owner}:${filters.tag}`;
}

export function LibraryPanel({
  currentDocument,
  home,
  onOpenDocument,
  onOpenHome,
  onOpenRepository,
  onOpenSearch,
  repositories,
  compactHeader,
  scopedRepository,
}: LibraryPanelProps) {
  const { loadRepositoryTree } = useKnowledgeApi();
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(
    new Set(),
  );
  const [trees, setTrees] = useState<Record<string, RepositoryTree>>({});
  const [loading, setLoading] = useState<Set<string>>(new Set());
  const [errors, setErrors] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState<KnowledgeFilters>(
    emptyKnowledgeFilters,
  );
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [selectedRepositorySlug, setSelectedRepositorySlug] = useState(
    () => currentDocument?.repository ?? 'company-docs',
  );

  const loadChildren = useCallback(
    async (repository: string, path: string, cursor?: string) => {
      const key = filteredTreeKey(repository, path, filters);
      setLoading((current) => new Set(current).add(key));
      setErrors((current) => {
        const next = new Set(current);
        next.delete(key);
        return next;
      });
      try {
        const nextTree = await loadRepositoryTree(
          repository,
          path,
          cursor,
          filters,
        );
        setTrees((current) => ({
          ...current,
          [key]: cursor
            ? {
                ...nextTree,
                entries: [
                  ...(current[key]?.entries ?? []),
                  ...nextTree.entries,
                ],
              }
            : nextTree,
        }));
      } catch {
        setErrors((current) => new Set(current).add(key));
      } finally {
        setLoading((current) => {
          const next = new Set(current);
          next.delete(key);
          return next;
        });
      }
    },
    [filters],
  );

  useEffect(() => {
    if (
      !currentDocument ||
      (scopedRepository && scopedRepository !== currentDocument.repository)
    )
      return;
    setSelectedRepositorySlug(currentDocument.repository);
    const repository = currentDocument.repository;
    const key = filteredTreeKey(repository, '', filters);
    const folderPaths = currentDocument.path
      .split('/')
      .slice(0, -1)
      .map((_, index, segments) => segments.slice(0, index + 1).join('/'));
    setExpandedFolders((current) => {
      const next = new Set(current);
      folderPaths.forEach((path) => next.add(treeKey(repository, path)));
      return next;
    });
    if (!trees[key] && !loading.has(key) && !errors.has(key)) {
      void loadChildren(repository, '');
    }
    folderPaths.forEach((path) => {
      const folderKey = filteredTreeKey(repository, path, filters);
      if (
        !trees[folderKey] &&
        !loading.has(folderKey) &&
        !errors.has(folderKey)
      ) {
        void loadChildren(repository, path);
      }
    });
  }, [
    currentDocument,
    scopedRepository,
    errors,
    filters,
    loadChildren,
    loading,
    trees,
  ]);

  const selectedRepository =
    repositories.find(
      (repository) =>
        repository.slug === (scopedRepository || selectedRepositorySlug),
    ) ?? repositories[0];
  const selectedRepositoryRoot = selectedRepository
    ? trees[filteredTreeKey(selectedRepository.slug, '', filters)]
    : undefined;
  const contentRoot = selectedRepositoryRoot?.entries.find(
    (entry) => entry.kind === 'folder' && entry.name === 'docs',
  );

  useEffect(() => {
    if (!selectedRepository) return;
    const rootKey = filteredTreeKey(selectedRepository.slug, '', filters);
    if (!trees[rootKey] && !loading.has(rootKey) && !errors.has(rootKey)) {
      void loadChildren(selectedRepository.slug, '');
    }
  }, [errors, filters, loadChildren, loading, selectedRepository, trees]);

  useEffect(() => {
    if (!selectedRepository || !contentRoot) return;
    const contentKey = filteredTreeKey(
      selectedRepository.slug,
      contentRoot.path,
      filters,
    );
    if (
      !trees[contentKey] &&
      !loading.has(contentKey) &&
      !errors.has(contentKey)
    ) {
      void loadChildren(selectedRepository.slug, contentRoot.path);
    }
  }, [
    contentRoot,
    errors,
    filters,
    loadChildren,
    loading,
    selectedRepository,
    trees,
  ]);

  function toggleFolder(repository: string, path: string) {
    const expansionKey = treeKey(repository, path);
    const dataKey = filteredTreeKey(repository, path, filters);
    const isExpanded = expandedFolders.has(expansionKey);
    setExpandedFolders((current) => {
      const next = new Set(current);
      if (isExpanded) next.delete(expansionKey);
      else next.add(expansionKey);
      return next;
    });
    if (!isExpanded && !trees[dataKey] && !loading.has(dataKey)) {
      void loadChildren(repository, path);
    }
  }

  function renderEntries(
    repository: string,
    path: string,
    depth: number,
    visibleEntries?: RepositoryTree['entries'],
  ): ReactNode {
    const key = filteredTreeKey(repository, path, filters);
    const tree = trees[key];
    if (loading.has(key) && !tree) {
      return <LoadingState label="Loading documents…" size="panel" />;
    }
    if (errors.has(key) && !tree) {
      return (
        <div className="library-tree-status">
          <span>Library unavailable.</span>
          <button
            onClick={() => void loadChildren(repository, path)}
            type="button"
          >
            Retry
          </button>
        </div>
      );
    }
    if (!tree) return null;
    const entries = visibleEntries ?? tree.entries;
    if (entries.length === 0 && visibleEntries) return null;
    if (entries.length === 0) {
      return <p className="library-tree-status">No documents here.</p>;
    }
    return (
      <div
        className="library-tree-group"
        role="group"
        style={
          {
            '--tree-guide-offset': `${String(13 + depth * 12)}px`,
          } as CSSProperties
        }
      >
        {entries.map((entry) => {
          const entryKey = treeKey(repository, entry.path);
          const isFolder = entry.kind === 'folder';
          const isExpanded = expandedFolders.has(entryKey);
          const isCurrent =
            !isFolder &&
            currentDocument?.repository === repository &&
            currentDocument.path === entry.path;
          const isCurrentPath =
            isFolder &&
            currentDocument?.repository === repository &&
            currentDocument.path.startsWith(`${entry.path}/`);
          return (
            <div key={entry.path}>
              <button
                aria-current={isCurrent ? 'page' : undefined}
                aria-expanded={isFolder ? isExpanded : undefined}
                className={`library-tree-entry ${entry.kind}${isCurrentPath ? ' is-current-path' : ''}${isCurrent ? ' is-current' : ''}`}
                data-document-status={
                  entry.kind === 'document' ? entry.status : undefined
                }
                data-document-type={
                  entry.kind === 'document' ? entry.type : undefined
                }
                onClick={() =>
                  isFolder
                    ? toggleFolder(repository, entry.path)
                    : onOpenDocument(repository, entry.path)
                }
                role="treeitem"
                style={{ '--tree-depth': depth } as CSSProperties}
                title={
                  entry.kind === 'document'
                    ? `${entry.path} · ${entry.type} · ${entry.status} · ${entry.owner}`
                    : entry.path
                }
                type="button"
              >
                {isFolder && (
                  <span aria-hidden="true" className="library-entry-icon">
                    {isExpanded ? '⌄' : '›'}
                  </span>
                )}
                <span>
                  <strong>
                    {isFolder ? libraryFolderLabel(entry.name) : entry.title}
                  </strong>
                </span>
              </button>
              {isFolder &&
                isExpanded &&
                renderEntries(repository, entry.path, depth + 1)}
            </div>
          );
        })}
        {!visibleEntries && tree.nextCursor && (
          <button
            className="library-load-more"
            disabled={loading.has(key)}
            onClick={() =>
              void loadChildren(repository, path, tree.nextCursor ?? undefined)
            }
            type="button"
          >
            {loading.has(key) ? 'Loading…' : 'Load more'}
          </button>
        )}
      </div>
    );
  }

  return (
    <aside
      className="library-panel atlas-library"
      aria-label="Library"
      data-sheet-background
    >
      {!compactHeader && (
        <div className="atlas-library-toolbar">
          <button
            aria-current={home ? 'page' : undefined}
            aria-label="Open Library home"
            className="brand-lockup atlas-home-link"
            onClick={onOpenHome}
            type="button"
          >
            <img
              alt=""
              aria-hidden="true"
              className="brand-mark"
              height="38"
              src={new URL('../atlas-mark.svg', import.meta.url).href}
              width="38"
            />
            <div className="brand-copy">
              <strong>Knowledge Base</strong>
              <span className="product-kicker">Library Atlas</span>
            </div>
          </button>
          <div className="atlas-library-actions">
            <button
              aria-haspopup="dialog"
              aria-keyshortcuts="Meta+K Control+K"
              aria-label="Search all documentation"
              className="command-search-trigger"
              onClick={onOpenSearch}
              title="Search all documentation (⌘K)"
              type="button"
            >
              <HeaderIcon name="search" />
              <span>Search library</span>
              <kbd>⌘K</kbd>
            </button>
          </div>
        </div>
      )}
      {selectedRepository && (
        <div className="atlas-repository-selector">
          <div className="atlas-repository-select-control">
            <select
              aria-label={
                compactHeader ? 'Browse repository tree' : 'Repository'
              }
              onChange={(event) => {
                const repository = repositories.find(
                  (candidate) => candidate.slug === event.target.value,
                );
                if (repository) {
                  setFilters(emptyKnowledgeFilters);
                  setSelectedRepositorySlug(repository.slug);
                  onOpenRepository(repository);
                }
              }}
              value={selectedRepository.slug}
            >
              {repositories.map((repository) => (
                <option key={repository.slug} value={repository.slug}>
                  {repository.displayName}
                </option>
              ))}
            </select>
          </div>
          <span className="atlas-repository-count">
            {selectedRepository.documentCount} docs
          </span>
          {selectedRepository.health === 'ready' ? (
            <span
              aria-hidden="true"
              className="repository-health-indicator ready"
              title="Repository ready"
            />
          ) : (
            <em
              className={`repository-health ${selectedRepository.health}`}
              title={`Repository ${repositoryHealthLabel(selectedRepository)}`}
            >
              {repositoryHealthLabel(selectedRepository)}
            </em>
          )}
        </div>
      )}
      {selectedRepository && <RepositoryIndexingNotice repository={selectedRepository} />}
      {selectedRepositoryRoot && (
        <div className="atlas-knowledge-filters">
          <button
            aria-expanded={filtersOpen}
            className="atlas-filter-toggle"
            onClick={() => setFiltersOpen((current) => !current)}
            type="button"
          >
            <span>Knowledge filters</span>
            <small>
              {Object.values(filters).filter(Boolean).length > 0
                ? `${String(Object.values(filters).filter(Boolean).length)} active`
                : 'All documents'}
            </small>
          </button>
          {filtersOpen && (
            <div className="atlas-filter-fields">
              {(
                [
                  ['type', 'Type', selectedRepositoryRoot.facets.types],
                  [
                    'status',
                    'Lifecycle',
                    selectedRepositoryRoot.facets.statuses,
                  ],
                  ['owner', 'Owner', selectedRepositoryRoot.facets.owners],
                  ['tag', 'Tag', selectedRepositoryRoot.facets.tags],
                ] as const
              ).map(([key, label, options]) => (
                <label key={key}>
                  <span>{label}</span>
                  <select
                    aria-label={`Filter by ${label.toLowerCase()}`}
                    onChange={(event) =>
                      setFilters((current) => ({
                        ...current,
                        [key]: event.target.value,
                      }))
                    }
                    value={filters[key]}
                  >
                    <option value="">All</option>
                    {options.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.value} ({option.count})
                      </option>
                    ))}
                  </select>
                </label>
              ))}
              {Object.values(filters).some(Boolean) && (
                <button
                  className="atlas-filter-reset"
                  onClick={() => setFilters(emptyKnowledgeFilters)}
                  type="button"
                >
                  Reset filters
                </button>
              )}
            </div>
          )}
        </div>
      )}
      <div className="atlas-library-scroll atlas-scroll-surface">
        <div
          aria-label={
            selectedRepository
              ? `${selectedRepository.displayName} documents`
              : 'Library'
          }
          className="repository-tree"
          role="tree"
        >
          {selectedRepository &&
            (contentRoot && selectedRepositoryRoot ? (
              <>
                {renderEntries(
                  selectedRepository.slug,
                  '',
                  0,
                  selectedRepositoryRoot.entries.filter(
                    (entry) => entry.kind === 'document',
                  ),
                )}
                {renderEntries(selectedRepository.slug, contentRoot.path, 0)}
              </>
            ) : (
              renderEntries(selectedRepository.slug, '', 0)
            ))}
        </div>
      </div>
    </aside>
  );
}
