import { createContext, useContext } from 'react';
import {
  documentSchema,
  diffSchema,
  graphSchema,
  historySchema,
  libraryUpdatesSchema,
  meaningSearchRequestSchema,
  meaningSearchResponseSchema,
  repositorySchema,
  searchResultSchema,
  semanticNeighborhoodRequestSchema,
  semanticNeighborhoodResponseSchema,
  semanticReadinessResponseSchema,
  sessionSchema,
  relationshipsSchema,
  repositoryTreeSchema,
  reviewWriteResponseSchema,
  reviewQueueSchema,
  type Document,
  type DocumentDiff,
  type History,
  type KnowledgeGraph,
  type LibraryUpdates,
  type MeaningSearchResponse,
  type Repository,
  type RepositoryTree,
  type SearchResult,
  type SemanticNeighborhoodRequest,
  type SemanticNeighborhoodResponse,
  type SemanticReadinessResponse,
  type Session,
  type Relationships,
  type ReviewQueue,
} from '@studio/contracts/knowledge';
import { z } from 'zod';

export function createKnowledgeApi(projectId: string, scopeRevision?: number) {
let controller = new AbortController();
function cancelPending() { controller.abort(); controller = new AbortController(); }
function denied() { globalThis.dispatchEvent(new CustomEvent('studio-knowledge-denied', { detail: { projectId, scopeRevision } })); }

async function getJson(url: string): Promise<unknown> {
  const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]);
  const response = await fetch(url.replace('/api/v1/',`/api/projects/${encodeURIComponent(projectId)}/studio/knowledge/`),{credentials:'same-origin',cache:'no-store',headers: scopeRevision === undefined ? {} : {'X-Studio-Floor-Revision':String(scopeRevision)},signal});
  signal.throwIfAborted();
  if ([401,403].includes(response.status)) denied();
  if(!response.ok)throw new Error('request_failed:'+response.status);
  return response.json();
}

async function postJson(
  url: string,
  body: unknown,
  signal?: AbortSignal,
): Promise<unknown> {
  const combined = AbortSignal.any([controller.signal, ...(signal ? [signal] : []), AbortSignal.timeout(15000)]);
  const response = await fetch(url.replace('/api/v1/', `/api/projects/${encodeURIComponent(projectId)}/studio/knowledge/`), {
    body: JSON.stringify(body),
    credentials: 'same-origin', cache: 'no-store',
    headers: { 'content-type': 'application/json', ...(scopeRevision === undefined ? {} : {'X-Studio-Floor-Revision':String(scopeRevision)}) },
    method: 'POST',
    signal: combined,
  });
  combined.throwIfAborted();
  if ([401,403].includes(response.status)) denied();
  if (!response.ok)
    throw new Error('request_failed:' + String(response.status));
  return response.json() as Promise<unknown>;
}

async function loadSession(): Promise<Session> {
  return sessionSchema.parse(await getJson('/api/v1/session'));
}

async function loadRepositories(): Promise<Repository[]> {
  return z.array(repositorySchema).parse(await getJson('/api/v1/repositories'));
}

async function loadLibraryUpdates(limit = 8): Promise<LibraryUpdates> {
  const search = new URLSearchParams({ limit: String(limit) });
  return libraryUpdatesSchema.parse(
    await getJson(`/api/v1/library/updates?${search.toString()}`),
  );
}

async function loadReviewQueue(limit = 8): Promise<ReviewQueue> {
  return reviewQueueSchema.parse(
    await getJson(`/api/v1/reviews/queue?limit=${String(limit)}`),
  );
}

async function searchDocuments(
  query: string,
  repository?: string,
): Promise<SearchResult[]> {
  const search = new URLSearchParams({ q: query });
  if (repository) search.set('repo', repository);
  return z
    .array(searchResultSchema)
    .parse(await getJson(`/api/v1/search?${search.toString()}`));
}

async function searchDocumentsByMeaning(
  objective: string,
  repository?: string,
): Promise<MeaningSearchResponse> {
  const request = meaningSearchRequestSchema.parse({
    objective,
    ...(repository ? { repository } : {}),
    limit: 8,
  });
  return meaningSearchResponseSchema.parse(
    await postJson('/api/v1/search/meaning', request),
  );
}

async function loadSemanticReadiness(
  repository?: string,
): Promise<SemanticReadinessResponse> {
  const search = new URLSearchParams();
  if (repository) search.set('repository', repository);
  const query = search.size > 0 ? `?${search.toString()}` : '';
  return semanticReadinessResponseSchema.parse(
    await getJson(`/api/v1/search/meaning/readiness${query}`),
  );
}

async function loadSemanticNeighborhood(
  input: SemanticNeighborhoodRequest,
  signal?: AbortSignal,
): Promise<SemanticNeighborhoodResponse> {
  const request = semanticNeighborhoodRequestSchema.parse(input);
  return semanticNeighborhoodResponseSchema.parse(
    await postJson('/api/v1/graph/neighborhood', request, signal),
  );
}

async function loadRepositoryTree(
  repository: string,
  path = '',
  cursor?: string,
  filters?: {
    owner?: string;
    status?: string;
    tag?: string;
    type?: string;
  },
): Promise<RepositoryTree> {
  const search = new URLSearchParams({ path, limit: '100' });
  if (cursor) search.set('cursor', cursor);
  if (filters?.type) search.set('type', filters.type);
  if (filters?.status) search.set('status', filters.status);
  if (filters?.owner) search.set('owner', filters.owner);
  if (filters?.tag) search.set('tag', filters.tag);
  return repositoryTreeSchema.parse(
    await getJson(
      `/api/v1/repositories/${encodeURIComponent(repository)}/tree?${search.toString()}`,
    ),
  );
}

async function loadDocument(
  repository: string,
  path: string,
): Promise<Document> {
  return documentSchema.parse(
    await getJson(
      `/api/v1/repositories/${encodeURIComponent(repository)}/document?path=${encodeURIComponent(path)}`,
    ),
  );
}

async function markDocumentReviewed(
  document: Document,
  note?: string,
): Promise<void> {
  reviewWriteResponseSchema.parse(
    await postJson(
      `/api/v1/repositories/${encodeURIComponent(document.repository)}/reviews`,
      {
        blob: document.blob,
        commit: document.provenance.commit,
        ...(note ? { note } : {}),
        path: document.path,
      },
    ),
  );
}

async function loadRelationships(
  repository: string,
  path: string,
): Promise<Relationships> {
  return relationshipsSchema.parse(
    await getJson(
      `/api/v1/repositories/${encodeURIComponent(repository)}/relationships?path=${encodeURIComponent(path)}&depth=1`,
    ),
  );
}

async function loadGraph(
  repositories: readonly string[],
): Promise<KnowledgeGraph> {
  const query = new URLSearchParams({ limit: '160' });
  for (const repository of repositories) query.append('repo', repository);
  return graphSchema.parse(await getJson(`/api/v1/graph?${query.toString()}`));
}

async function loadHistory(
  repository: string,
  path: string,
): Promise<History> {
  return historySchema.parse(
    await getJson(
      `/api/v1/repositories/${encodeURIComponent(repository)}/history?path=${encodeURIComponent(path)}&limit=20`,
    ),
  );
}

async function loadDiff(
  repository: string,
  path: string,
  base: string,
  head: string,
  rendered = false,
): Promise<DocumentDiff> {
  const search = new URLSearchParams({ path, base, head });
  if (rendered) search.set('rendered', '1');
  return diffSchema.parse(
    await getJson(
      `/api/v1/repositories/${encodeURIComponent(repository)}/diff?${search.toString()}`,
    ),
  );
}

return { projectId, scopeRevision, cancelPending, loadSession, loadRepositories, loadLibraryUpdates, loadReviewQueue, searchDocuments, searchDocumentsByMeaning, loadSemanticReadiness, loadSemanticNeighborhood, loadRepositoryTree, loadDocument, markDocumentReviewed, loadRelationships, loadGraph, loadHistory, loadDiff };
}
export const KnowledgeApiContext = createContext<ReturnType<typeof createKnowledgeApi> | undefined>(undefined);
export function useKnowledgeApi() { const api = useContext(KnowledgeApiContext); if (!api) throw Error('Knowledge context unavailable'); return api; }
