import type { WhiteboardStroke } from '@studio/contracts';
export const shapeNames = {
  'elbow-arrow':'Elbow arrow', 'curved-arrow':'Curved arrow', arrow:'Arrow', line:'Line',
  rectangle:'Rectangle', ellipse:'Ellipse', diamond:'Diamond', triangle:'Triangle',
  'inverted-triangle':'Inverted triangle', pill:'Pill', cylinder:'Cylinder',
  'rounded-rectangle':'Rounded rectangle', pentagon:'Pentagon', hexagon:'Hexagon', star:'Star', 'speech-bubble':'Speech bubble',
} as const;
export type ShapeKind=keyof typeof shapeNames;
export type ShapePoint=[number,number];
export const commonShapes:ShapeKind[]=['elbow-arrow','curved-arrow','arrow','line','rectangle','ellipse','diamond','triangle','inverted-triangle','pill','cylinder'];
export const extraShapes:ShapeKind[]=['rounded-rectangle','pentagon','hexagon','star','speech-bubble'];
export const isLineShape=(kind:ShapeKind)=>['line','arrow','elbow-arrow','curved-arrow'].includes(kind);
const arc=(cx:number,cy:number,rx:number,ry:number,start:number,end:number,steps=24):ShapePoint[]=>Array.from({length:steps+1},(_,i)=>{const a=start+(end-start)*i/steps;return [cx+Math.cos(a)*rx,cy+Math.sin(a)*ry];});
const polygon=(count:number,inner?:number):ShapePoint[]=>Array.from({length:count+1},(_,i)=>{const a=-Math.PI/2+i*Math.PI*2/count,r=inner&&i%2?inner:.5;return [.5+Math.cos(a)*r,.5+Math.sin(a)*r];});

/** Presets produce ordinary bounded vectors: optional preset metadata keeps labels and connectors compatible with existing drawings. */
export function shapePoints(kind:ShapeKind,start:ShapePoint,end:ShapePoint,constrain=false):ShapePoint[] {
  let [dx,dy]=[end[0]-start[0],end[1]-start[1]];
  if(constrain){if(isLineShape(kind)){const a=Math.round(Math.atan2(dy,dx)/(Math.PI/4))*Math.PI/4,r=Math.hypot(dx,dy);dx=Math.cos(a)*r;dy=Math.sin(a)*r;}else{const side=Math.max(Math.abs(dx),Math.abs(dy));dx=(dx<0?-1:1)*side;dy=(dy<0?-1:1)*side;}}
  const finish:ShapePoint=[start[0]+dx,start[1]+dy];
  if(isLineShape(kind)) {
    let points:ShapePoint[];
    if(kind==='elbow-arrow')points=[start,[start[0]+dx/2,start[1]],[start[0]+dx/2,finish[1]],finish];
    else if(kind==='curved-arrow')points=Array.from({length:33},(_,i)=>{const t=i/32,u=1-t;return [u*u*u*start[0]+3*u*u*t*(start[0]+dx/2)+3*u*t*t*(finish[0]-dx/2)+t*t*t*finish[0],u*u*u*start[1]+3*u*u*t*start[1]+3*u*t*t*finish[1]+t*t*t*finish[1]];});
    else points=[start,finish];
    if(kind==='line')return points;
    const before=points.slice(0,-1).reverse().find(p=>Math.hypot(finish[0]-p[0],finish[1]-p[1])>.001)??start;
    const angle=Math.atan2(finish[1]-before[1],finish[0]-before[0]),head=Math.min(18,Math.hypot(dx,dy)*.3);
    const wing=(a:number):ShapePoint=>[finish[0]-head*Math.cos(a),finish[1]-head*Math.sin(a)];
    return [...points,wing(angle-.5),finish,wing(angle+.5)];
  }
  const x=Math.min(start[0],finish[0]),y=Math.min(start[1],finish[1]),width=Math.abs(dx),height=Math.abs(dy);
  let normalized:ShapePoint[];
  switch(kind) {
    case 'rectangle': normalized=[[0,0],[1,0],[1,1],[0,1],[0,0]];break;
    case 'ellipse': normalized=arc(.5,.5,.5,.5,0,2*Math.PI,96);break;
    case 'diamond': normalized=[[.5,0],[1,.5],[.5,1],[0,.5],[.5,0]];break;
    case 'triangle': normalized=[[.5,0],[1,1],[0,1],[.5,0]];break;
    case 'inverted-triangle': normalized=[[0,0],[1,0],[.5,1],[0,0]];break;
    case 'pentagon': normalized=polygon(5);break;
    case 'hexagon': normalized=polygon(6);break;
    case 'star': normalized=polygon(10,.22);break;
    case 'speech-bubble': normalized=[[0,0],[1,0],[1,.75],[.45,.75],[.2,1],[.2,.75],[0,.75],[0,0]];break;
    case 'cylinder': normalized=[...arc(.5,.14,.5,.14,Math.PI,3*Math.PI,48),[0,.86],...arc(.5,.86,.5,.14,Math.PI,0),[1,.14]];break;
    default: {
      const radius=Math.min(width,height)*(kind==='pill'?.5:.14),rx=width?radius/width:0,ry=height?radius/height:0;
      normalized=[...arc(1-rx,ry,rx,ry,-Math.PI/2,0,10),...arc(1-rx,1-ry,rx,ry,0,Math.PI/2,10),...arc(rx,1-ry,rx,ry,Math.PI/2,Math.PI,10),...arc(rx,ry,rx,ry,Math.PI,Math.PI*1.5,10)];
      normalized.push(normalized[0]!);
    }
  }
  return normalized.map(([px,py])=>[x+px*width,y+py*height]);
}
export function shapeStroke(kind:ShapeKind,start:ShapePoint,end:ShapePoint,constrain:boolean,color:WhiteboardStroke['color'],thickness:number,id:string):Omit<WhiteboardStroke,'revision'> {
  const points=shapePoints(kind,start,end,constrain),x=Math.min(...points.map(p=>p[0])),y=Math.min(...points.map(p=>p[1]));
  const width=Math.max(1,Math.max(...points.map(p=>p[0]))-x),height=Math.max(1,Math.max(...points.map(p=>p[1]))-y);
  if(![x,y,width,height].every(Number.isFinite)||width>4000||height>4000||Math.abs(x)>100000||Math.abs(y)>100000)throw Error('That shape is too large. Draw a smaller shape or zoom in.');
  return {id,kind:'stroke',shape:kind,x,y,width,height,color,thickness,points:points.map(([px,py])=>[Math.max(0,Math.min(1,Number(((px-x)/width).toFixed(5)))),Math.max(0,Math.min(1,Number(((py-y)/height).toFixed(5))))])};
}
export function defaultShape(kind:ShapeKind,center:ShapePoint,color:WhiteboardStroke['color'],thickness:number,id:string) {
  const halfHeight=kind==='elbow-arrow'||kind==='curved-arrow'?50:isLineShape(kind)?0:70;
  return shapeStroke(kind,[center[0]-100,center[1]-halfHeight],[center[0]+100,center[1]+halfHeight],false,color,thickness,id);
}
