import type { SidePanel } from './DocumentPanel';
import { HeaderIcon } from './TopBar';

interface AtlasToolRailProps {
  readerOnly?: boolean;
  documentToolsAvailable: boolean;
  onToggleContext: () => void;
  onToggleExplore: () => void;
  onToggleInspect: () => void;
  onToggleSettings: () => void;
  sidePanel: SidePanel;
}

export function AtlasToolRail({
  readerOnly = false,
  documentToolsAvailable,
  onToggleContext,
  onToggleExplore,
  onToggleInspect,
  onToggleSettings,
  sidePanel,
}: AtlasToolRailProps) {
  const controls = [
    {
      available: !readerOnly,
      icon: 'explore' as const,
      label: 'Explore',
      onClick: onToggleExplore,
      pressed: false,
    },
    {
      available: documentToolsAvailable,
      icon: 'context' as const,
      label: 'Context',
      onClick: onToggleContext,
      pressed: sidePanel === 'context',
    },
    {
      available: documentToolsAvailable,
      icon: 'inspect' as const,
      label: 'Inspect',
      onClick: onToggleInspect,
      pressed: sidePanel === 'inspect',
    },
    {
      available: true,
      icon: 'settings' as const,
      label: 'Settings',
      onClick: onToggleSettings,
      pressed: sidePanel === 'settings',
    },
  ].filter((control) => control.available);

  return (
    <nav
      aria-label={documentToolsAvailable ? 'Document tools' : 'Workspace tools'}
      className="atlas-tool-rail"
      data-sheet-background
    >
      {controls.map((control) => (
        <button
          aria-pressed={control.pressed}
          key={control.icon}
          onClick={control.onClick}
          title={control.label}
          type="button"
        >
          <HeaderIcon name={control.icon} />
          <span className="sr-only">{control.label}</span>
        </button>
      ))}
    </nav>
  );
}
