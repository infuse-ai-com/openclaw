import { Button, IconButton } from './ui.js';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { icons } from '@studio/ui/icons';

function MenuIcon({ name }: { name: 'board' | 'copy' | 'trash' }) {
  return (
    <span
      className="wboard-icon"
      aria-hidden="true"
      dangerouslySetInnerHTML={{ __html: icons[name] }}
    />
  );
}

export function SelectionMenu({
  x,
  y,
  width,
  height,
  count,
  reason,
  locked,
  lockReason,
  close,
  create,
  duplicate,
  remove,
  setLocked,
  copy,
  paste,
}: {
  x: number;
  y: number;
  width: number;
  height: number;
  count: number;
  reason: string;
  locked: number;
  lockReason: string;
  copy(): void;
  paste(): void;
  close(restore?: boolean): void;
  create(): void;
  duplicate(): void;
  remove(): void;
  setLocked(locked: boolean): void;
}) {
  const menu = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ left: x, top: y });
  useLayoutEffect(() => {
    const box = menu.current!.getBoundingClientRect();
    setPosition({
      left: Math.max(8, Math.min(x, width - box.width - 8)),
      top: Math.max(8, Math.min(y, height - box.height - 8)),
    });
    menu.current?.querySelector<HTMLButtonElement>('button')?.focus();
  }, [x, y, width, height, reason, locked]);
  useEffect(() => {
    const outside = (event: PointerEvent) => {
      if (!menu.current?.contains(event.target as Node)) close();
    };
    document.addEventListener('pointerdown', outside, true);
    return () => document.removeEventListener('pointerdown', outside, true);
  }, [close]);
  return (
    <div
      ref={menu}
      className="wboard-selection-menu wboard-float"
      style={position}
      role="menu"
      aria-label="Selection actions"
      onContextMenu={(event) => event.preventDefault()}
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node)) close();
      }}
      onKeyDown={(event) => {
        if (event.key === 'Escape') {
          event.preventDefault();
          event.stopPropagation();
          close(true);
        }
        if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
          event.preventDefault();
          event.stopPropagation();
          const buttons = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('button')];
          const at = buttons.indexOf(document.activeElement as HTMLButtonElement);
          const next =
            event.key === 'Home'
              ? 0
              : event.key === 'End'
                ? buttons.length - 1
                : (at + (event.key === 'ArrowUp' ? -1 : 1) + buttons.length) % buttons.length;
          buttons[next]?.focus();
        }
      }}
    >
      {count > 0 && (
        <>
          <span className="wboard-selection-menu-count">{count} selected</span>
          <Button variant="quiet"
            type="button"
            role="menuitem"
            aria-disabled={!!reason}
            aria-describedby={reason ? 'wboard-group-reason' : undefined}
            onClick={() => {
              if (!reason) create();
            }}
          >
            <MenuIcon name="board" />
            <span>Create section from selection</span>
          </Button>
          {reason && <p id="wboard-group-reason">{reason}</p>}
          <Button variant="quiet" type="button" role="menuitem" onClick={copy}>
            <MenuIcon name="copy" />
            <span>Copy selection</span>
          </Button>
          <Button variant="quiet" type="button" role="menuitem" onClick={duplicate}>
            <MenuIcon name="copy" />
            <span>Duplicate selection</span>
          </Button>
          {locked < count && (
            <Button variant="quiet"
              type="button"
              role="menuitem"
              aria-disabled={!!lockReason}
              title={lockReason || undefined}
              onClick={() => {
                if (!lockReason) setLocked(true);
              }}
            >
              <LockIcon />
              <span>Lock</span>
            </Button>
          )}
          {locked > 0 && (
            <Button variant="quiet"
              type="button"
              role="menuitem"
              aria-disabled={!!lockReason}
              title={lockReason || undefined}
              onClick={() => {
                if (!lockReason) setLocked(false);
              }}
            >
              <LockIcon open />
              <span>Unlock</span>
            </Button>
          )}
          <Button variant="quiet"
            type="button"
            role="menuitem"
            aria-disabled={locked > 0}
            title={locked ? 'Unlock these elements before deleting them.' : undefined}
            onClick={() => {
              if (!locked) remove();
            }}
          >
            <MenuIcon name="trash" />
            <span>Delete selection</span>
          </Button>
        </>
      )}
      <Button variant="quiet" type="button" role="menuitem" onClick={paste}>
        <MenuIcon name="copy" />
        <span>Paste here</span>
      </Button>
    </div>
  );
}

export function LockIcon({ open = false }: { open?: boolean }) {
  return (
    <svg
      className="wboard-lock-icon"
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      aria-hidden="true"
    >
      <rect x="5" y="10" width="14" height="11" rx="2" />
      <path d={open ? 'M8 10V6a4 4 0 0 1 8 0' : 'M8 10V6a4 4 0 0 1 8 0v4'} />
      <path d="M12 14v3" />
    </svg>
  );
}
export function LockPrompt({
  x,
  y,
  width,
  height,
  count,
  enabled,
  unlock,
  close,
}: {
  x: number;
  y: number;
  width: number;
  height: number;
  count: number;
  enabled: boolean;
  unlock(): void;
  close(): void;
}) {
  return (
    <div
      className="wboard-lock-prompt wboard-float"
      role="group"
      aria-label="Locked elements"
      style={{
        left: Math.max(8, Math.min(x, width - 278)),
        top: Math.max(8, Math.min(y, height - 100)),
      }}
    >
      <span role="status">
        <LockIcon /> {count === 1 ? 'Locked in place' : `${count} elements locked in place`}
      </span>
      <Button variant="quiet" type="button" disabled={!enabled} onClick={unlock}>
        Unlock
      </Button>
      <IconButton type="button" aria-label="Dismiss lock message" onClick={close}>
        ×
      </IconButton>
    </div>
  );
}
