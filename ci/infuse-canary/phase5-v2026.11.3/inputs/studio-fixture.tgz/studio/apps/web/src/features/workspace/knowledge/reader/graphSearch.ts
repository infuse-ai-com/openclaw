import type { GraphNode } from '@studio/contracts/knowledge';

export function matchesGraphDocumentQuery(
  node: GraphNode,
  query: string,
): boolean {
  const normalizedQuery = query.trim().toLocaleLowerCase();
  if (!normalizedQuery) return true;
  return [
    node.title,
    node.description,
    node.repository,
    node.path,
    node.type,
    node.status,
    node.owner,
    ...node.tags,
  ]
    .join(' ')
    .toLocaleLowerCase()
    .includes(normalizedQuery);
}
