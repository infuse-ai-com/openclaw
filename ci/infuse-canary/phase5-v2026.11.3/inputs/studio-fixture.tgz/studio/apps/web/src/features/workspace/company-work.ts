import { useQueries, useQuery } from '@tanstack/react-query';
import { parseMissionList, parseMissionView, type MissionSummary, type MissionView, type NativeMission, type NativeMissionView, type RuntimeTarget, type MissionListCursor } from '@studio/contracts';
import { useWorkspace } from './context.js';
import { api, ApiError, accessDenied, getSession, readableError, type SignedInSession } from './api.js';
import { getNativeMissions, getNativeMission } from './native-missions.js';
import { workCards } from './collection.js';
import { targetKey, terminal, dispatchLabel, nextDecision } from '../studio/presentation.js';

const MAX_PROJECTS = 8, MAX_PAGES = 3, MAX_DETAILS = 12;
export interface ProjectWork {
  session: SignedInSession; legacy: MissionSummary[]; native: NativeMission[];
  nativeViews: NativeMissionView[]; legacyViews: MissionView[]; coverage: string[];
}
async function projectWork(base: SignedInSession, projectId: string, signal: AbortSignal): Promise<ProjectWork> {
  const session = await getSession(signal, undefined, projectId);
  if (!session.authenticated || session.profileId !== base.profileId || session.bootstrap.authorityId !== base.bootstrap.authorityId || session.project.id !== projectId) throw new ApiError('IDENTITY_CHANGED', 'Project identity changed. Refresh your access.', 403);
  const legacy: MissionSummary[] = []; let cursor: MissionListCursor | undefined; const coverage: string[] = [];
  if (session.legacyProject) for (let pageNumber = 0; pageNumber < MAX_PAGES; pageNumber++) {
    const page = parseMissionList(await api(`/api/studio/missions?${new URLSearchParams({ limit: '30', ...(cursor ? { cursor: JSON.stringify(cursor) } : {}) })}`, { signal }));
    legacy.push(...page.missions); const next = page.nextCursor;
    if (next && JSON.stringify(next) === JSON.stringify(cursor)) throw Error('The mission page did not advance.');
    cursor = next; if (!cursor) break;
  }
  if (cursor) coverage.push('Earlier legacy missions are outside this view.');
  const native = session.nativeMissions ? await getNativeMissions(projectId, signal) : [];
  if (native.length >= 100) coverage.push('Native history covers the latest 100 missions.');
  // Inspect real current assignments/receipts, bounded and with three concurrent requests per project.
  const activeNative = native.filter(m => !['closed','cancelled'].includes(m.state)); const activeLegacy = legacy.filter(m => !terminal(m));
  const selected = [...activeNative.map(m => ({ id:m.id, native:true })), ...activeLegacy.map(m => ({ id:m.id, native:false }))].slice(0,MAX_DETAILS);
  if (activeNative.length + activeLegacy.length > selected.length) coverage.push(`Work details cover ${selected.length} of ${activeNative.length + activeLegacy.length} loaded open missions.`);
  const nativeViews: NativeMissionView[] = [], legacyViews: MissionView[] = [];
  for (let offset = 0; offset < selected.length; offset += 3) {
    const results = await Promise.allSettled(selected.slice(offset,offset+3).map(async m => {
      if (m.native) return { native:true as const, view:await getNativeMission(projectId,m.id,signal) };
      const view = parseMissionView(await api(`/api/studio/missions/${encodeURIComponent(m.id)}`,{ signal }));
      if (view.mission.id !== m.id) throw Error('Mission identity does not match');
      return { native:false as const, view };
    }));
    for (const result of results) {
      if (result.status === 'fulfilled') { if (result.value.native) nativeViews.push(result.value.view); else legacyViews.push(result.value.view); }
      else { if (signal.aborted || accessDenied(result.reason)) throw result.reason; coverage.push(`Some work details could not refresh: ${readableError(result.reason)}`); }
    }
  }
  return { session, legacy, native, nativeViews, legacyViews, coverage:[...new Set(coverage)] };
}
export function useCompanyWork() {
  const { session, current, visible } = useWorkspace(); const admitted = session.projects; const selected = admitted.slice(0,MAX_PROJECTS);
  const membership = JSON.stringify([admitted.map(p => [p.id,p.name]).sort(),session.bootstrap.capabilities.approver,session.bootstrap.targets.map(targetKey).sort()]);
  const queries = useQueries({ queries:selected.map(project => ({ queryKey:['workspace','company',session.bootstrap.authorityId,session.profileId,membership,project.id], enabled:current,
    queryFn:({signal}: {signal:AbortSignal}) => projectWork(session,project.id,signal), refetchInterval:current && visible ? 15000 : false })) });
  const projects = selected.map((project,index) => {
    const query = queries[index]!; return { project, data:accessDenied(query.error) ? undefined : query.data, loading:query.isPending, stale:!current || query.isError, error:query.isError ? readableError(query.error) : '' };
  });
  return { projects, admitted:admitted.length, omitted:Math.max(0,admitted.length-MAX_PROJECTS), loading:queries.some(q => q.isPending), refreshing:queries.some(q => q.isFetching), current,
    refresh:() => { for (const q of queries) void q.refetch(); } };
}
/** The floor inspects only its selected project; it never fetches the company roster. */
export function useFloorWork(shown: boolean) {
  const { session, current, visible } = useWorkspace();
  const membership = JSON.stringify([session.project.id, session.bootstrap.targets.map(targetKey).sort(), session.bootstrap.capabilities.approver]);
  const query = useQuery({ queryKey: ['workspace', 'floor', session.bootstrap.authorityId, session.profileId, membership],
    enabled: current && shown, queryFn: ({ signal }) => projectWork(session, session.project.id, signal),
    refetchInterval: current && visible && shown ? 15000 : false });
  return { data: accessDenied(query.error) ? undefined : query.data, stale: !current || query.isError,
    loading: query.isPending, error: query.isError ? readableError(query.error) : '', refresh: () => void query.refetch() };
}
export type CompanyWork = ReturnType<typeof useCompanyWork>;
export interface AgentWork { projectId:string; projectName:string; missionTitle:string; path:string; title:string; state:string; receipt:string; proposed:boolean; next:string; held:boolean; stale?:boolean }
export function agentDirectory(work: CompanyWork) {
  const targets = new Map<string,{target:RuntimeTarget; projects:string[]; projectIds:string[]; roles:string[]; work:AgentWork[]; observationOnly:boolean}>();
  for (const { data, project, stale } of work.projects) {
    if (!data) continue;
    for (const target of [...data.session.bootstrap.targets,...(data.session.observedAgents??[])]) {
      const key = targetKey(target); let entry = targets.get(key);
      if (!entry) { entry={target,projects:[],projectIds:[],roles:[],work:[],observationOnly:!data.session.bootstrap.targets.some(t=>targetKey(t)===key)}; targets.set(key,entry); }
      if (!entry.projects.includes(project.name)) entry.projects.push(project.name);
      if (!entry.projectIds.includes(project.id)) entry.projectIds.push(project.id);
      if (data.session.nativeMissions?.coordinator && targetKey(data.session.nativeMissions.coordinator) === key && !entry.roles.includes('Coordinator')) entry.roles.push('Coordinator');
    }
    const add = (target:RuntimeTarget, item:AgentWork, role:string) => { const entry=targets.get(targetKey(target)); if (!entry) return; entry.work.push({...item,stale,receipt:`${stale ? 'Last known · ' : ''}${item.receipt}`}); if (!entry.roles.includes(role)) entry.roles.push(role); };
    for (const view of data.nativeViews) {
      const m=view.mission; const path=`/missions/v2/${encodeURIComponent(m.id)}?${new URLSearchParams({project:project.id,section:'tasks'})}`;
      for (const assignment of view.assignments.filter(a => a.state === 'current' && (a.role === 'coordinator' ? a.id === m.coordinatorAssignmentId : view.tasks.some(task => task.assignmentId === a.id)))) {
        const task=view.tasks.find(t => t.assignmentId === assignment.id); const actions=view.actions.filter(a => a.assignmentId === assignment.id);
        const active=actions.find(a => ['running','dispatching','uncertain'].includes(a.state)); const latest=active ?? [...actions].sort((a,b)=>b.createdAt.localeCompare(a.createdAt))[0];
        add(assignment,{projectId:project.id,projectName:project.name,missionTitle:m.paper.title,path,title:task?.plan.title ?? 'Mission coordination',state:task?.state ?? m.state, held:m.held, next:workCards([], [m])[0]!.next,
          receipt:latest ? `${latest.state}${latest.runId ? ' · run observed' : ' · no run observed'}${m.held ? ' · mission on hold' : ''}` : 'Assignment recorded · no runtime receipt',proposed:false},task?.plan.role ?? 'Coordinator');
      }
      for (const task of m.paper.tasks.filter(t => !view.tasks.find(current => current.id === t.id)?.assignmentId)) add(task.owner,{projectId:project.id,projectName:project.name,missionTitle:m.paper.title,path,title:task.title,state:'Planned',held:m.held,next:'Named in the plan; assignment has not started.',receipt:'Named in paper · not assigned',proposed:true},task.role);
    }
    for (const view of data.legacyViews) {
      const m=view.mission;
      for (const role of ['coordinator','specialist'] as const) { const assignment=m.assignments[role]; const receipt=view.dispatches.find(d => d.id === assignment?.dispatchId);
        add(m.paper[role],{projectId:project.id,projectName:project.name,missionTitle:m.paper.title,path:`/missions/${encodeURIComponent(m.id)}?${new URLSearchParams({project:project.id,section:'activity'})}`,title:role === 'coordinator' ? 'Mission coordination' : 'Mission delivery',state:role === 'specialist' ? m.task.state : m.state,held:m.held,next:nextDecision(m),receipt:receipt ? dispatchLabel(receipt) : 'Named in paper · not assigned',proposed:!assignment},role);
      }
    }
  }
  return [...targets.values()].sort((a,b) => a.target.agentId.localeCompare(b.target.agentId) || a.target.gatewayId.localeCompare(b.target.gatewayId));
}
export function deskItems(work: CompanyWork, view: 'needs' | 'active' = 'needs') {
  return work.projects.flatMap(({data,project,stale}) => data ? workCards(data.legacy,data.native).filter(m => view === 'active' ? !m.closed : data.session.bootstrap.capabilities.approver ? m.decision : !m.closed).map(item => ({item,project,stale,approver:data.session.bootstrap.capabilities.approver})) : []);
}
