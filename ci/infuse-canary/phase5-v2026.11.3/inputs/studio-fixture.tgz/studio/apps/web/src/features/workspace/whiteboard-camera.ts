import { unobscuredCanvas } from './whiteboard-companion-layout.js';
import { useEffect, useRef, useState } from 'react';
import type { ReactFlowInstance } from '@xyflow/react';
import type { BoardCamera } from './whiteboard-section-zoom.js';
import type { CanvasItem, BlockNode } from './whiteboard-types.js';

/** Owns camera memory and canvas measurement; no command or draft state lives here. */
export function useWhiteboardCamera(sectionId: string) {
  const canvas = useRef<HTMLDivElement>(null);
  const flow = useRef<ReactFlowInstance<BlockNode> | null>(null);
  const cameras = useRef(new Map<string, BoardCamera>());
  const framed = useRef(new Set<string>());
  const [canvasSize, setCanvasSize] = useState({ width: 1200, height: 800 });
  const [viewport, setViewport] = useState<BoardCamera>({ x: 40, y: 40, zoom: 1 });
  const [previousView, setPreviousView] = useState<({ sectionId: string } & BoardCamera) | null>(
    null,
  );
  useEffect(() => {
    const element = canvas.current;
    if (!element) return;
    const resize = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (rect) setCanvasSize({ width: rect.width, height: rect.height });
    });
    resize.observe(element);
    return () => resize.disconnect();
  }, []);
  useEffect(() => {
    const camera = cameras.current.get(sectionId) ?? { x: 40, y: 40, zoom: 1 };
    setViewport(camera);
    void flow.current?.setViewport(camera);
  }, [sectionId]);
  function moveCamera(next: { x: number; y: number; zoom: number }, remember = true) {
    if (
      Math.abs(next.x - viewport.x) < 0.5 &&
      Math.abs(next.y - viewport.y) < 0.5 &&
      Math.abs(next.zoom - viewport.zoom) < 0.001
    )
      return;
    if (remember) setPreviousView({ sectionId, ...viewport });
    void flow.current?.setViewport(next);
  }
  function frameBlock(block: CanvasItem, withComments = false) {
    const small = canvasSize.width < 720;
    const width = Math.max(180, canvasSize.width - (withComments && !small ? 368 : 40));
    const height = Math.max(
      100,
      withComments && small ? canvasSize.height * 0.6 - 360 : canvasSize.height - 300,
    );
    const zoom = Math.min(1, width / (block.width + 50), height / (block.height + 50));
    moveCamera({
      x: 20 + width / 2 - (block.x + block.width / 2) * zoom,
      y: 180 + height / 2 - (block.y + block.height / 2) * zoom,
      zoom,
    });
  }
  function fitBoard(blocks: {x:number;y:number;width:number;height:number}[], remember = true) {
    if (!blocks.length || !flow.current) return;
    const x = Math.min(...blocks.map((b) => b.x)),
      y = Math.min(...blocks.map((b) => b.y));
    const width = Math.max(...blocks.map((b) => b.x + b.width)) - x,
      height = Math.max(...blocks.map((b) => b.y + b.height)) - y;
    const rect = canvas.current?.getBoundingClientRect();
    const panel = canvas.current?.closest('.ws-whiteboard')?.querySelector<HTMLElement>('.wboard-companion-panel:not([hidden])')?.getBoundingClientRect();
    const available = unobscuredCanvas({ x: 24, y: 140, width: Math.max(100, (rect?.width ?? canvasSize.width) - 48),
      height: Math.max(100, (rect?.height ?? canvasSize.height) - (canvasSize.width < 720 ? 360 : 240)) },
      panel && rect ? { x: panel.left - rect.left, y: panel.top - rect.top, width: panel.width, height: panel.height } : undefined);
    const zoom = Math.max(
      0.1,
      Math.min(1, available.width / (width + 40), available.height / (height + 40)),
    );
    moveCamera(
      {
        x: available.x + available.width / 2 - (x + width / 2) * zoom,
        y: available.y + available.height / 2 - (y + height / 2) * zoom,
        zoom,
      },
      remember,
    );
  }

  function changed(camera: BoardCamera) {
    setViewport(camera);
    cameras.current.set(sectionId, camera);
  }
  function remember() {
    cameras.current.set(sectionId, flow.current?.getViewport() ?? viewport);
  }
  function saved(section: string) {
    return cameras.current.get(section);
  }
  function seed(section: string, camera: BoardCamera) {
    cameras.current.set(section, camera);
  }
  function markFramed(section = sectionId) {
    framed.current.add(section);
  }
  function fitInitial(blocks: CanvasItem[], deepLink: boolean) {
    if (framed.current.has(sectionId) || !flow.current) return;
    framed.current.add(sectionId);
    // Large sections keep their readable entry scale; Fit remains an explicit overview.
    if (!deepLink && blocks.length && blocks.length <= 12) fitBoard(blocks, false);
  }
  return {
    canvas,
    flow,
    canvasSize,
    viewport,
    previousView,
    setPreviousView,
    changed,
    remember,
    saved,
    seed,
    markFramed,
    fitInitial,
    frameBlock,
    fitBoard,
  };
}
