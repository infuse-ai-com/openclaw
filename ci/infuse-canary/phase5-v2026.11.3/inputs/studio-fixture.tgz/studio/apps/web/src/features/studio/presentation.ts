import type { Mission, MissionDispatch, MissionSummary, MissionView, RuntimeTarget } from '@studio/contracts';

export const escapeHtml = (value: unknown): string => String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
export const targetKey = (target: RuntimeTarget): string => JSON.stringify([target.gatewayId, target.agentId]);
export const targetLabel = (target: RuntimeTarget): string => `${target.agentId} · ${target.gatewayId}`;
export const coordinatorCloseout = (m: Mission | MissionSummary): boolean => 'paper' in m ? m.paper.closeoutPolicy?.mode === 'coordinator' : m.closeoutMode === 'coordinator';
export const gatePending = (m: Mission | MissionSummary): boolean => 'paper' in m
  ? m.paper.closeoutPolicy?.humanGate === 'required' && !m.closeoutGate : m.humanGatePending === true;
const closing = (m: Mission | MissionSummary): boolean => 'paper' in m ? !!m.closeoutRequest : m.closeoutRequested === true;
export function missionLabel(m: Mission | MissionSummary, progress?: MissionView['closeoutProgress']): string {
  if (m.state === 'closed') return 'Closed by coordinator';
  if (m.state === 'accepted') return 'Accepted';
  if (m.state === 'cancelled') return 'Cancelled';
  if (m.held) return 'On hold';
  if (progress?.state === 'blocked' || 'closeoutBlocked' in m && m.closeoutBlocked) return 'Closeout needs attention';
  if (m.state === 'draft') return 'Awaiting approval';
  if (m.state === 'approved') return 'Ready to start';
  const task = 'task' in m ? m.task.state : m.taskState;
  if (coordinatorCloseout(m) && task === 'verified') return gatePending(m) ? 'Human gate pending' : closing(m) ? 'Closing · awaiting runtime' : 'Verified · awaiting closeout';
  return task === 'verified' ? 'Ready for your review' : task === 'delivered' ? 'Coordinator reviewing' : 'In progress';
}
export function nextDecision(m: Mission | MissionSummary, progress?: MissionView['closeoutProgress']): string {
  if (m.state === 'closed') return 'Inspect the coordinator’s closeout; acknowledgement is optional';
  if (m.state === 'accepted') return 'Revisit the accepted evidence';
  if (m.state === 'cancelled') return 'Inspect the cancellation and runtime state';
  if (progress?.state === 'blocked') return progress.reason;
  if ('closeoutBlocked' in m && m.closeoutBlocked) return 'Inspect the blocked closeout and reconcile the recorded outcome or cancel';
  if (m.held) return closing(m) ? 'Reconcile the closing turn or cancel this held mission' : 'Decide when to resume';
  if (m.state === 'draft') return 'Review and approve the stored paper';
  if (m.state === 'approved') return 'Start the approved mission';
  const task = 'task' in m ? m.task.state : m.taskState;
  if ('correction' in m && m.correction && task === 'assigned') return 'Await the specialist’s replacement; the original result stays readable';
  if (coordinatorCloseout(m) && task === 'verified') return gatePending(m) ? 'Inspect the verified result and resolve the approved human gate' : closing(m) ? 'The coordinator requested closeout; Studio is checking terminal runtime receipts' : 'The coordinator has verified the evidence and can request closeout';
  return task === 'verified' ? 'Inspect the evidence and decide whether to accept' : task === 'delivered' ? 'The coordinator has evidence to verify' : task === 'assigned' ? 'Await specialist evidence' : 'Await coordinator delegation';
}
export const terminal = (m: Mission | MissionSummary): boolean => ['closed', 'accepted', 'cancelled'].includes(m.state);
export const needsDecision = (m: MissionSummary): boolean => !terminal(m) && (m.held || m.closeoutBlocked || m.state !== 'running' || m.taskState === 'verified' && (!coordinatorCloseout(m) || gatePending(m)));
export const closeoutPolicyLabel = (paper: Mission['paper']): string => paper.closeoutPolicy
  ? paper.closeoutPolicy.humanGate === 'required'
    ? 'The coordinator closes after verification and a required human gate. You can acknowledge the closed result afterwards.'
    : 'The coordinator closes after verification. Your acknowledgement afterwards is optional.'
  : 'A person accepts the verified result. This paper retains its original human acceptance policy.';
export function dispatchLabel(d: MissionDispatch): string {
  return ({ pending: 'Waiting to dispatch', creating: 'Preparing session', bound: 'Session bound · waiting to send', sending: 'Sending · outcome pending', accepted: 'Runtime admitted this turn', uncertain: 'Outcome uncertain', rejected: 'Runtime rejected this turn', revoked: 'Assignment revoked', superseded: 'Continuation no longer needed' })[d.state];
}
export function safeEvidenceUrl(uri: string): string | null {
  try { const url = new URL(uri); return url.protocol === 'https:' && !url.username && !url.password ? url.href : null; }
  catch { return null; }
}
export function dateLabel(value: string): string {
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}
export function errorCode(error: unknown): string | undefined {
  if (!error || typeof error !== 'object') return undefined;
  const candidate = error as { code?: unknown; details?: { studioCode?: unknown }; error?: { code?: unknown; details?: { studioCode?: unknown } } };
  const code = candidate.details?.studioCode ?? candidate.error?.details?.studioCode ?? candidate.code ?? candidate.error?.code;
  return typeof code === 'string' ? code : undefined;
}
