export type Rect = { x: number; y: number; width: number; height: number };
/** Largest rectangular camera area outside the floating chat; coordinates are canvas-local. */
export function unobscuredCanvas(area: Rect, obstruction?: Rect): Rect {
  if (!obstruction || obstruction.x >= area.x + area.width || obstruction.y >= area.y + area.height || obstruction.x + obstruction.width <= area.x || obstruction.y + obstruction.height <= area.y) return area;
  const gap = 16;
  return [
    { ...area, width: obstruction.x - gap - area.x },
    { ...area, x: obstruction.x + obstruction.width + gap, width: area.x + area.width - obstruction.x - obstruction.width - gap },
    { ...area, height: obstruction.y - gap - area.y },
    { ...area, y: obstruction.y + obstruction.height + gap, height: area.y + area.height - obstruction.y - obstruction.height - gap },
  ].filter(rect => rect.width > 0 && rect.height > 0).sort((a, b) => b.width * b.height - a.width * a.height)[0] ?? area;
}
export function clampChat(position: { x: number; y: number }, bounds: Rect, size: { width: number; height: number }) {
  return { x: Math.max(bounds.x, Math.min(position.x, bounds.x + Math.max(0, bounds.width - size.width))),
    y: Math.max(bounds.y, Math.min(position.y, bounds.y + Math.max(0, bounds.height - size.height))) };
}

/** Connections have no rectangle: reveal their endpoints as well as the edge. */
export function companionRevealIds(items: {id:string;kind:string;source?:string;target?:string}[], ids: string[]) {
  const result = new Set(ids);
  for (const item of items) if (result.has(item.id) && item.kind === 'connection') {
    if (item.source) result.add(item.source);
    if (item.target) result.add(item.target);
  }
  return [...result];
}
