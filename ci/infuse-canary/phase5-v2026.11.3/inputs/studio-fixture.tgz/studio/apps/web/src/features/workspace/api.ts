import { parseStudioBootstrap, parseConversationPage, parseConversationBinding, parseConversationDelivery,
  parseConversationBind, parseConversationComment, parseConversationResponseRequest, parseConversationResponse,
  type StudioBootstrap, type ConversationBindInput, type ConversationCommentInput, type ConversationResponseRequest } from '@studio/contracts';

import {missionIdentifier,type RuntimeTarget} from '@studio/contracts';

export type Session = { authenticated: false; loginUrl: string } | {
  authenticated: true; profileId: string; displayName: string; csrfToken: string;
  project: { id: string; name: string }; projects: { id: string; name: string; kind?: 'company'; knowledgeOnly?: boolean }[]; legacyProject: boolean; companyWorkspace: boolean; bootstrap: StudioBootstrap;
  observedAgents?: RuntimeTarget[];
  floorConnection?: 'ready' | 'connecting' | 'blocked' | 'unconfigured';
  workbenchAvailable?: boolean;
  canManageFloors?: boolean; knowledgeOnly?: boolean; knowledgeScope?: { revision: number };
  nativeMissions?: { enabled: boolean; cutover: boolean; coordinator?: { gatewayId: string; agentId: string } };
};
export type SignedInSession = Extract<Session, { authenticated: true }>;
export class ApiError extends Error {
  constructor(readonly code: string, message: string, readonly status: number, readonly details?: unknown) { super(message); }
}
/** Forbidden reads cannot retain private cached projections as ordinary stale data. */
export const accessDenied = (error: unknown): boolean => error instanceof ApiError && [401, 403].includes(error.status);
const denied = new Set<() => void>();
export function onAccessDenied(listener: () => void): () => void { denied.add(listener); return () => { denied.delete(listener); }; }

/** Same-origin cookies identify the person; runtime credentials never enter this client. */
export async function api(path: string, options: { signal?: AbortSignal; command?: unknown; csrf?: string; isCurrent?(): boolean } = {}): Promise<unknown> {
  const response = await fetch(path, {
    method: options.command === undefined ? 'GET' : 'POST', credentials: 'same-origin', cache: 'no-store',
    signal: options.signal ? AbortSignal.any([options.signal, AbortSignal.timeout(15000)]) : AbortSignal.timeout(15000),
    headers: { Accept: 'application/json', ...(options.command === undefined ? {} : { 'Content-Type': 'application/json', 'X-CSRF-Token': options.csrf ?? '' }) },
    ...(options.command === undefined ? {} : { body: JSON.stringify(options.command) }),
  });
  const notifyDenied = () => {
    if (!options.signal?.aborted && (options.isCurrent?.() ?? true)) denied.forEach(listener => listener());
  };
  let body: unknown;
  try { body = await response.json(); } catch { if (response.status === 401) notifyDenied(); throw new ApiError('INVALID_RESPONSE', 'Studio returned an unreadable response. Refresh before continuing.', response.status); }
  if (!response.ok) {
    const error = (body as { error?: { code?: unknown; message?: unknown; details?: unknown } })?.error;
    const code = typeof error?.code === 'string' ? error.code : 'UNAVAILABLE';
    if (response.status === 401 || code === 'UNAUTHENTICATED') notifyDenied();
    throw new ApiError(code, typeof error?.message === 'string' ? error.message : 'Studio could not complete this request.', response.status, error?.details);
  }
  return body;
}
export function parseSession(value: unknown): Session {
  const v = value as Omit<Partial<SignedInSession>, 'authenticated'> & { authenticated?: unknown; loginUrl?: unknown };
  if (!v || typeof v !== 'object') throw Error('Studio returned an invalid session.');
  if (v.authenticated === false) {
    const url = typeof v.loginUrl === 'string' ? new URL(v.loginUrl, location.origin) : null;
    if (!url || url.origin !== location.origin || !url.pathname.startsWith('/api/auth/')) throw Error('Studio returned an invalid sign-in destination.');
    return { authenticated: false, loginUrl: url.pathname + url.search };
  }
  if (v.authenticated !== true || typeof v.profileId !== 'string' || !v.profileId || typeof v.displayName !== 'string'
    || typeof v.csrfToken !== 'string' || !v.csrfToken || !v.project || typeof v.project.id !== 'string' || !v.project.id
    || typeof v.project.name !== 'string' || !v.project.name) throw Error('Studio returned an incomplete identity.');
  const bootstrap = parseStudioBootstrap(v.bootstrap);
  if (bootstrap.profileId !== v.profileId) throw Error('The workspace identity does not match the signed-in person.');
  if(v.observedAgents!==undefined&&(!Array.isArray(v.observedAgents)||v.observedAgents.length>100))throw Error('Invalid observed agents.');
  const observedAgents=(v.observedAgents??[]).map(a=>({gatewayId:missionIdentifier(a.gatewayId),agentId:missionIdentifier(a.agentId)}));
  if(new Set(observedAgents.map(a=>JSON.stringify(a))).size!==observedAgents.length||observedAgents.some(a=>bootstrap.targets.some(t=>t.gatewayId===a.gatewayId&&t.agentId===a.agentId)))throw Error('Ambiguous observed agent.');
  return { authenticated: true, observedAgents, profileId: v.profileId, displayName: v.displayName, csrfToken: v.csrfToken,
    ...(v.floorConnection && ['ready','connecting','blocked','unconfigured'].includes(v.floorConnection) ? { floorConnection: v.floorConnection } : {}),
    canManageFloors: v.canManageFloors === true, knowledgeOnly: v.knowledgeOnly === true,
    ...(v.knowledgeScope && Number.isSafeInteger(v.knowledgeScope.revision) && v.knowledgeScope.revision > 0 ? { knowledgeScope: v.knowledgeScope } : {}),
    project: { id: v.project.id, name: v.project.name }, bootstrap,
    projects: Array.isArray(v.projects) && v.projects.every(p => p && typeof p.id === 'string' && typeof p.name === 'string') ? v.projects : [v.project],
    legacyProject: v.legacyProject !== false, workbenchAvailable: v.workbenchAvailable === true, companyWorkspace: v.companyWorkspace === true,
    ...(v.nativeMissions && typeof v.nativeMissions.enabled === 'boolean' && typeof v.nativeMissions.cutover === 'boolean' ? { nativeMissions: v.nativeMissions } : {}) };
}
export const getSession = async (signal?: AbortSignal, isCurrent?: () => boolean, projectId?: string): Promise<Session> => parseSession(await api(`/api/session${projectId ? `?${new URLSearchParams({ projectId })}` : ''}`, { signal, isCurrent }));
export const projectPath = (path: string, projectId: string) => path.replace(/^\/api\/studio(?=\/)/, `/api/projects/${encodeURIComponent(projectId)}/studio`);
export const ownerKey = (session: SignedInSession): string => JSON.stringify([session.bootstrap.authorityId, session.profileId, session.project.id]);
export const readableError = (error: unknown): string => error instanceof Error ? error.message : 'Studio could not complete this request. Refresh and try again.';

export async function getConversations(missionId: string, beforeSequence?: number, signal?: AbortSignal) {
  const params = new URLSearchParams({ limit: '30', ...(beforeSequence === undefined ? {} : { beforeSequence: String(beforeSequence) }) });
  const page = parseConversationPage(await api(`/api/studio/missions/${encodeURIComponent(missionId)}/conversations?${params}`, { signal }));
  const bindings = new Set(page.bindings.map(binding => binding.id));
  if (page.missionId !== missionId || page.bindings.some(binding => binding.missionId !== missionId)
    || page.events.some(event => !bindings.has(event.bindingId))
    || page.deliveries.some(delivery => delivery.missionId !== missionId || !bindings.has(delivery.bindingId))
    || page.responses?.some(response => response.missionId !== missionId || !bindings.has(response.bindingId))) throw Error('The conversation does not match this mission.');
  return page;
}
export async function bindConversation(input: ConversationBindInput, csrf: string, isCurrent: () => boolean) {
  const command = parseConversationBind(input);
  const binding = parseConversationBinding(await api('/api/studio/conversations/bind', { command, csrf, isCurrent }));
  if (binding.missionId !== command.missionId || binding.rootPostId !== command.rootPostId) throw Error('The returned thread does not match the requested binding.');
  return binding;
}
export async function commentOnConversation(input: ConversationCommentInput, csrf: string, isCurrent: () => boolean) {
  const command = parseConversationComment(input);
  const delivery = parseConversationDelivery(await api('/api/studio/conversations/comments', { command, csrf, isCurrent }));
  if (delivery.missionId !== command.missionId || delivery.bindingId !== command.bindingId
    || delivery.commandId !== command.commandId || delivery.text !== command.text) throw Error('The comment receipt does not match the submitted request.');
  return delivery;
}
export async function requestConversationResponse(input: ConversationResponseRequest, csrf: string, isCurrent: () => boolean) {
  const command = parseConversationResponseRequest(input);
  const response = parseConversationResponse(await api('/api/studio/conversations/responses', { command, csrf, isCurrent }));
  const sourceId = command.source.kind === 'event' ? String(command.source.sequence) : command.source.deliveryId;
  if (response.missionId !== command.missionId || response.bindingId !== command.bindingId
    || response.source.kind !== command.source.kind || response.source.id !== sourceId) throw Error('The response receipt does not match the requested source.');
  return response;
}
