import { IconButton, Button } from './ui.js';
import {
  whiteboardChanges,
  whiteboardNavigation,
  type WhiteboardBlock,
  type WhiteboardStroke,
} from '@studio/contracts';
import { useWorkspace } from './context.js';
import { BlockEditor, type Draft } from './whiteboard-editing.js';
import { BoardIcon } from './whiteboard-icon.js';
import { useSpatialBoard } from './whiteboard-spatial.js';
import { PropertiesEditor } from './whiteboard-properties.js';
import { ArrangeActions, type ArrangeAction } from './whiteboard-arrange.js';
import { SectionTree } from './whiteboard-sections.js';
import { whiteboardConnectable, type WhiteboardNavigation } from '@studio/contracts';
import { type SharedBodyOptions } from './whiteboard-text.js';
import { BoardSearch } from './whiteboard-tiles.js';
import type { BoardPanel, CanvasItem } from './whiteboard-types.js';

import type * as React from 'react';
import type { Commit } from './whiteboard-types.js';

type Props = {
  setAutoFocusId: React.Dispatch<React.SetStateAction<string | null>>;
  openPanel: (next: BoardPanel) => void;
  selection: string[];
  selectionLocks: string[];
  arrange: (action: ArrangeAction) => Promise<void>;
  moveToSection: (destination: string, ids?: string[]) => Promise<void>;
  removeElement: (id: string) => void;
  renameSection: (section: WhiteboardNavigation['sections'][number]) => void;

  panel: BoardPanel;
  panelElement: React.RefObject<HTMLElement | null>;
  focused: CanvasItem | null;
  dismissPanel: () => void;
  path: string;
  session: ReturnType<typeof useWorkspace>['session'];
  navigation: { data?: ReturnType<typeof whiteboardNavigation.parse> };
  enterSection: (next: string, block?: string) => void;
  selectedSaved: CanvasItem | undefined;
  syncDraftStatus: () => void;
  enabled: boolean;
  commit: Commit;
  setReplaceHtml: React.Dispatch<React.SetStateAction<string | null>>;
  setPanel: React.Dispatch<React.SetStateAction<BoardPanel>>;
  isShared: boolean;
  board: Pick<ReturnType<typeof useSpatialBoard>, 'data' | 'isPending' | 'isError'>;
  blocks: CanvasItem[];
  select: (block: CanvasItem) => void;
  drafts: Map<string, Draft>;
  sectionId: string;
  editable: boolean;
  shared: SharedBodyOptions | undefined;
  target: string;
  setTarget: React.Dispatch<React.SetStateAction<string>>;
  activity: { data?: ReturnType<typeof whiteboardChanges.parse> };
  capability: { data?: { enabled: boolean } };
  hasDraft: boolean;
  enableCollaboration: () => Promise<void>;
};
export function WhiteboardPanel({
  setAutoFocusId,
  openPanel,
  selection,
  selectionLocks,
  arrange,
  moveToSection,
  renameSection,
  removeElement,
  panel,
  panelElement,
  focused,
  dismissPanel,
  path,
  session,
  navigation,
  enterSection,
  selectedSaved,
  syncDraftStatus,
  enabled,
  commit,
  setReplaceHtml,
  setPanel,
  isShared,
  board,
  blocks,
  select,
  drafts,
  sectionId,
  editable,
  shared,
  target,
  setTarget,
  activity,
  capability,
  hasDraft,
  enableCollaboration,
}: Props) {
  return (
    <>
      {panel && panel !== 'html' && panel !== 'comments' && (
        <aside
          ref={panelElement}
          tabIndex={-1}
          id="wboard-panel"
          className={'wboard-panel wboard-float wboard-panel--' + panel}
          aria-label={
            panel === 'editor'
              ? 'Block editor'
              : panel === 'outline'
                ? 'Board outline'
                : panel === 'activity'
                  ? 'Recent changes'
                  : panel === 'search'
                    ? 'Search whiteboard'
                    : panel === 'arrange'
                      ? 'Arrange selection'
                      : 'Whiteboard help'
          }
        >
          <header className="wboard-panel-heading">
            <h2>
              {panel === 'editor'
                ? 'Properties'
                : panel === 'outline'
                  ? 'Board outline'
                  : panel === 'activity'
                    ? 'Recent changes'
                    : panel === 'search'
                      ? 'Search whiteboard'
                      : panel === 'arrange'
                        ? 'Arrange selection'
                        : 'Make space for ideas'}
            </h2>
            <IconButton
              className="wboard-tool"
              aria-label="Close panel"
              title="Close panel (Escape)"
              onClick={dismissPanel}
            >
              <BoardIcon name="close" />
            </IconButton>
          </header>
          <div className="wboard-panel-content">
            {panel === 'arrange' && (
              <ArrangeActions
                count={selection.length}
                disabled={!enabled || hasDraft || !!selectionLocks.length}
                run={(action) => void arrange(action)}
              />
            )}
            {panel === 'search' && (
              <BoardSearch
                path={path}
                session={session}
                sections={navigation.data?.sections ?? []}
                open={enterSection}
              />
            )}
            {panel === 'editor' && selectedSaved && (
              <PropertiesEditor
                key={selectedSaved.id}
                block={selectedSaved}
                drafts={drafts}
                sectionId={sectionId}
                shared={isShared}
                changed={syncDraftStatus}
                enabled={editable}
                canAct={enabled}
                remove={() => removeElement(selectedSaved.id)}
                enter={() => enterSection(selectedSaved.id)}
                replace={() => {
                  setReplaceHtml(selectedSaved.id);
                  openPanel('html');
                }}
                editText={() => {
                  setPanel(null);
                  setAutoFocusId(selectedSaved.id);
                }}
              />
            )}
            {panel === 'editor' && selectedSaved && isShared && (
              <details className="wboard-organize">
                <summary>Move to section</summary>
                <label>
                  Destination
                  <select className="ui-control"
                    aria-label="Move to section"
                    value=""
                    disabled={!enabled || hasDraft || !!selectedSaved.locked}
                    onChange={async (e) => {
                      if (e.target.value)
                        await commit([
                          {
                            type: 'reparent',
                            id: selectedSaved.id,
                            expectedRevision: selectedSaved.revision,
                            sectionId: e.target.value,
                          },
                        ]);
                    }}
                  >
                    <option value="">Choose destination</option>
                    {[
                      ...(board.data?.ancestors ?? []),
                      ...blocks.filter((b) => b.kind === 'section' && b.id !== selectedSaved.id),
                    ].map((b) => (
                      <option key={b.id} value={b.id}>
                        {'title' in b ? b.title : b.id}
                      </option>
                    ))}
                  </select>
                </label>
              </details>
            )}
            {panel === 'outline' && (
              <SectionTree
                sections={navigation.data?.sections ?? []}
                current={sectionId}
                canMove={enabled && !hasDraft && !selectionLocks.length}
                selectedCount={selection.length}
                enter={enterSection}
                rename={renameSection}
                move={(destination) => void moveToSection(destination)}
              />
            )}
            {panel === 'outline' && (
              <div className="wboard-outline">
                <p className="wboard-help">
                  {blocks.length} {blocks.length === 1 ? 'block' : 'blocks'} · Select one to find
                  and edit it.
                </p>
                <ul>
                  {blocks.map((block) => (
                    <li key={block.id}>
                      <Button variant="quiet" aria-pressed={focused?.id === block.id} onClick={() => select(block)}>
                        <BoardIcon
                          name={
                            block.kind === 'stroke'
                              ? 'edit'
                              : block.kind === 'note'
                                ? 'note'
                                : 'document'
                          }
                        />{' '}
                        {block.kind === 'stroke' ? 'Drawing' : block.title || 'Untitled'}
                        {drafts.get(block.id)?.dirty && <small>Draft</small>}
                      </Button>
                    </li>
                  ))}
                </ul>
                {!blocks.length && (
                  <p className="wboard-help">
                    Your board is empty. Add a note from the toolbar below.
                  </p>
                )}
              </div>
            )}
            {panel === 'editor' &&
              !selectedSaved &&
              focused &&
              focused.kind !== 'note' &&
              focused.kind !== 'document' && (
                <div role="alert">
                  This item moved or was deleted. Any local changes are kept here.
                  <Button variant="quiet"
                    type="button"
                    onClick={() => {
                      drafts.delete(focused.id);
                      syncDraftStatus();
                      dismissPanel();
                    }}
                  >
                    Discard changes
                  </Button>
                </div>
              )}
            {panel === 'editor' &&
              !selectedSaved &&
              focused &&
              (focused.kind === 'note' || focused.kind === 'document') && (
                <BlockEditor
                  seed={focused}
                  enabled={editable}
                  canSave={false}
                  sectionId={sectionId}
                  drafts={drafts}
                  onDraftChange={syncDraftStatus}
                  commit={commit}
                  shared={shared}
                />
              )}
            {panel === 'editor' && selectedSaved && whiteboardConnectable(selectedSaved) && (
              <details className="wboard-links">
                <summary>Connections</summary>
                <label htmlFor="wboard-connect-target">Connect to</label>
                <select className="ui-control"
                  id="wboard-connect-target"
                  value={target}
                  onChange={(event) => setTarget(event.target.value)}
                >
                  <option value="">Choose a block</option>
                  {blocks
                    .filter((block) => block.id !== focused?.id && whiteboardConnectable(block))
                    .map((block) => (
                      <option key={block.id} value={block.id}>
                        {block.kind === 'stroke'
                          ? block.label || 'Shape'
                          : block.title || 'Untitled'}
                      </option>
                    ))}
                </select>
                <Button variant="quiet"
                  disabled={!enabled || !target}
                  onClick={() =>
                    void commit([
                      {
                        type: 'connect',
                        connection: {
                          id: crypto.randomUUID(),
                          kind: 'connection',
                          source: selectedSaved.id,
                          target,
                          label: '',
                        },
                      },
                    ])
                  }
                >
                  Connect blocks
                </Button>
                <ul>
                  {board.data?.items
                    .filter(
                      (item) =>
                        item.kind === 'connection' &&
                        (item.source === selectedSaved.id || item.target === selectedSaved.id),
                    )
                    .map(
                      (item) =>
                        item.kind === 'connection' && (
                          <li key={item.id}>
                            {blocks
                              .map((block) => ({
                                id: block.id,
                                title:
                                  block.kind === 'stroke' ? block.label || 'Shape' : block.title,
                              }))
                              .find(
                                (block) =>
                                  block.id ===
                                  (item.source === selectedSaved.id ? item.target : item.source),
                              )?.title || 'Untitled'}
                            <IconButton
                              disabled={!enabled}
                              aria-label={'Remove connection ' + item.id}
                              onClick={() =>
                                void commit([
                                  { type: 'delete', id: item.id, expectedRevision: item.revision },
                                ])
                              }
                            >
                              Remove
                            </IconButton>
                          </li>
                        ),
                    )}
                </ul>
              </details>
            )}
            {panel === 'activity' && (
              <div className="wboard-activity">
                <p className="wboard-help">
                  Project history · Revision {board.data?.revision ?? 0}
                </p>
                <ol>
                  {activity.data?.events.toReversed().map((event) => (
                    <li key={event.revision}>
                      <strong>{event.actor.id}</strong>{' '}
                      {event.actor.kind === 'agent' ? '(agent)' : ''} saved{' '}
                      {event.changedIds.length} {event.changedIds.length === 1 ? 'item' : 'items'}
                      <span>
                        Revision {event.revision} · {new Date(event.at).toLocaleTimeString()}
                      </span>
                    </li>
                  ))}
                </ol>
                {!activity.data?.events.length && (
                  <p className="wboard-help">Changes will appear here when you save.</p>
                )}
              </div>
            )}
            {panel === 'help' && (
              <div className="wboard-help-content">
                <p>
                  Choose Note, then click the canvas to place it and start writing. Titles and text
                  save automatically. Open Block options to adjust position and connections.
                  Documents edit directly on the canvas too. Properties save automatically; expand
                  Position and size for precise placement.
                </p>
                <dl>
                  <dt>Images</dt>
                  <dd>
                    Paste an image while the canvas is focused, drop image files onto the canvas, or
                    choose Upload image. PNG, JPEG and WebP up to 10 MB are supported. Upload
                    previews stay visible until saved; failed uploads can be retried. Drag to move,
                    resize from a corner, or choose View image. Choose Crop image to trim the edges
                    or move the crop area, then Apply crop. Restore full image brings the edges
                    back. Crops support Undo and Redo; Duplicate reuses the saved image.
                  </dd>
                  <dt>Explore and discuss</dt>
                  <dd>
                    Choose Add HTML to search the project library, preview a file and add it to the
                    current section. HTML previews appear automatically as you look around. Up to
                    two stay live at once; choose Show preview to switch to another. Choose Interact
                    to use its controls, or Expand for more room. Source details live in HTML
                    properties. Section cards show a miniature of the saved layout inside, plus the
                    item count. Enter a section to edit its contents. Search follows named section
                    paths; Fit and Return to previous view help you find your place. Comment badges
                    open discussions beside the note; Show in note selects the quoted text.
                  </dd>
                  <dt>Undo and selection</dt>
                  <dd>
                    Use the floating Undo and Redo buttons for board actions. ⌘/Ctrl Z undoes; Shift
                    Z redoes. While typing, these shortcuts edit text instead. Select blocks to
                    duplicate (⌘/Ctrl D) or delete them. Hold Shift to select several blocks.
                    Right-click the selection and choose Create section from selection, or use the
                    section button above the toolbar. Their layout and links move together; select
                    both ends of any connection. Undo brings the elements back. Lock keeps elements
                    in place across refreshes and shared sessions. Dragging or nudging a locked
                    element shows Unlock; right-click or use the selection toolbar to unlock it.
                    Text stays editable. Unlock before resizing, deleting or moving into another
                    section. Undo restores deleted text and comments. History is personal to this
                    browser session and section; newer shared edits are protected.
                  </dd>
                  <dt>Shapes and arrows</dt>
                  <dd>
                    Choose Shapes, then a shape, line or arrow. Click to place it, drag to choose
                    its size, or press Enter to place it in the center. Hold Shift for equal sides
                    or 45-degree line angles. The style menu sets color and thickness; More shapes
                    opens additional outlines. After placing, Select lets you move and resize the
                    saved vector, and the usual Duplicate, Delete, Undo and Redo actions work.
                    Double-click a shape or press Enter to add text; it saves automatically. Drawn
                    arrows are independent outlines. To attach an arrow, drag between connection
                    dots or choose Connections in properties; the connector follows both elements as
                    they move.
                  </dd>
                  <dt>Sketch and correct</dt>
                  <dd>
                    Choose the pencil, a color and a line sample, then drag to draw. Each stroke
                    saves when you release. The eraser removes whole strokes; board Undo restores
                    them. Escape cancels an unfinished drawing or erasing gesture. Select a drawing
                    to move, resize or delete it.
                  </dd>
                  <dt>Move around</dt>
                  <dd>
                    The board opens in Hand mode. Drag to look around, or click a note or document
                    to write without leaving Hand mode. Press Escape or click the canvas to finish
                    writing. Choose Select to select, move or resize blocks; double-click a
                    note/document or press Enter to write. Fit selection brings chosen items into
                    view. Hold Space to pan temporarily. Scroll to zoom. Zoom into a section until
                    it fills most of the view to enter it automatically; the + button works on a
                    centered section too. Zoom out beyond the section overview to return to its
                    parent; the − button works too. Your parent view is restored. Automatic
                    navigation pauses while you edit or save; breadcrumbs and Enter section are
                    always available.
                  </dd>
                  <dt>Arrange blocks</dt>
                  <dd>
                    Use the select tool to drag blocks, or focus a block and use the arrow keys.
                    Nearby edges and centers show alignment guides and gently snap into place. Hold
                    Alt/Option while dragging to place freely. A multi-selection keeps its spacing.
                  </dd>
                  <dt>Connect ideas</dt>
                  <dd>Drag between the dots on two blocks, or open Connections in the editor.</dd>
                  <dt>Keep your place</dt>
                  <dd>
                    Escape closes a panel. Your unsaved drafts stay here while you switch blocks.
                  </dd>
                </dl>
                {!isShared && capability.data?.enabled === true && (
                  <section aria-label="Enable board collaboration">
                    <h3>Write together</h3>
                    <p>
                      Enable shared text editing, presence and comments on the{' '}
                      {session.project.name} board. Existing saved blocks are preserved. This change
                      is permanent; ask anyone with an older tab to save and reload first.
                    </p>
                    {hasDraft && <p>Save or discard your drafts before enabling collaboration.</p>}
                    <Button
                      type="button"

                      disabled={!enabled || hasDraft}
                      onClick={() => void enableCollaboration()}
                    >
                      Enable collaboration on this board
                    </Button>
                  </section>
                )}
              </div>
            )}
          </div>
        </aside>
      )}
    </>
  );
}
