# Frontend features

Add company/projects, mission authoring, team, whiteboard and review features here as API-backed slices. Use `src/lib/api` for validated transport and shared presentation from `@studio/ui` and `@studio/spatial`. Do not import mockup models or simulated agent behavior. The current web app is a connectivity foundation only.
