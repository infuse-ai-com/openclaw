import { Button, EmptyState } from './ui.js';
import { useState } from 'react';
import type { FloorDefinition, FloorRepositoryCatalog, RepositorySetup } from '@studio/contracts';
import { icons } from '@studio/ui/icons';
import gitBranch from '@tabler/icons/outline/git-branch.svg?raw';

export type EditableFloor = FloorDefinition & { revision: number; configured: boolean; legacyCore: boolean; canRetire: boolean; retiredAt?: string };
export type FloorDirectory = { floors: EditableFloor[]; members: Array<{ id: string; name: string }> };
export function FloorIcon({ name }: { name: keyof typeof icons | 'repository' }) {
  return <span className="ws-glyph" aria-hidden="true" dangerouslySetInnerHTML={{ __html: name === 'repository' ? gitBranch : icons[name] }} />;
}
export function FloorDetails({ draft, change, creating }: { draft: EditableFloor; change(value: EditableFloor): void; creating: boolean }) {
  const [addressEdited, setAddressEdited] = useState(!!draft.id);
  return <div className="fd-details-fields">
    <label className="ws-field">Floor name<input className="ui-control" required maxLength={100} value={draft.name} placeholder="e.g. Design lab" onChange={e => {
      const name = e.target.value;
      const id = name.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^[^a-z]+|[-]+$/g, '').slice(0, 80);
      change({ ...draft, name, ...(creating && !addressEdited ? { id } : {}) });
    }} /></label>
    <label className="ws-field">Floor address<input className="ui-control" required pattern="[a-z][a-z0-9-]*" maxLength={80} value={draft.id} disabled={!creating} onChange={e => { setAddressEdited(true); change({ ...draft, id: e.target.value }); }} /><small>Lowercase letters, numbers and hyphens. This stays the same after creation.</small></label>
    <label className="ws-field fd-description">Description <span className="fd-optional">Optional</span><textarea className="ui-control" aria-label="Description" rows={3} maxLength={2000} placeholder="What will your team work on here?" value={draft.description} onChange={e => change({ ...draft, description: e.target.value })} /></label>
  </div>;
}
export function FloorMembers({ draft, members, change }: { draft: EditableFloor; members: FloorDirectory['members']; change(value: EditableFloor): void }) {
  return <div className="fd-members"><h3>Who works on this floor?</h3><p>Choose at least one workspace member. This does not change their approval permissions.</p>
    {members.map(member => <label className="fd-member-row" key={member.id}><input type="checkbox" checked={draft.memberProfileIds.includes(member.id)} onChange={e => change({ ...draft, memberProfileIds: e.target.checked ? [...draft.memberProfileIds, member.id] : draft.memberProfileIds.filter(id => id !== member.id) })} /><FloorIcon name="profile" /><span>{member.name}</span></label>)}
    {draft.memberProfileIds.filter(id => !members.some(member => member.id === id)).map(id => <p key={id}>A previously selected member is unavailable. Reload saved settings before changing membership.</p>)}
    {!draft.memberProfileIds.length && <p className="fd-validation" role="alert">Choose at least one member before saving.</p>}
  </div>;
}
export function FloorRepositories({ draft, catalog, picking, change, setup }: {
  draft: EditableFloor; catalog: FloorRepositoryCatalog; picking: boolean; change(value: EditableFloor): void;
  setup(value: { source?: RepositorySetup; revision?: number }): void;
}) {
  const [search, setSearch] = useState('');
  const matches = catalog.filter(repo => `${repo.displayName} ${repo.slug} ${repo.branch}`.toLowerCase().includes(search.toLowerCase()));
  const rows = picking ? matches : catalog.filter(repo => draft.repositories.some(source => source.id === repo.id));
  const unavailable = draft.repositories.filter(source => !catalog.some(repo => repo.id === source.id));
  return <div className="fd-repositories">
    {picking && <label className="fd-search"><FloorIcon name="search" /><input className="ui-control" aria-label="Search repositories" placeholder="Search repositories…" value={search} onChange={e => setSearch(e.target.value)} /></label>}
    <div className="fd-repository-list">
      {rows.map(repo => {
        const selected = draft.repositories.find(source => source.id === repo.id);
        const toggle = (checked: boolean) => change({ ...draft, repositories: checked ? [...draft.repositories, { id: repo.id, slug: repo.slug, shared: false }] : draft.repositories.filter(source => source.id !== repo.id) });
        return <div className={`fd-repository-row${picking && selected ? ' is-selected' : ''}`} key={repo.id}>
          <label className="fd-repository-main">
            {picking && <input type="checkbox" aria-label={`${repo.displayName} · ${repo.branch} · ${repo.state}`} checked={!!selected} disabled={!selected && draft.repositories.length >= 32} onChange={e => toggle(e.target.checked)} />}
            <FloorIcon name="repository" /><span className="fd-repository-name"><strong>{repo.displayName || repo.slug}</strong><small>{repo.branch} <span aria-hidden="true">·</span> {repo.documentCount} documents</small></span>
            <span className={`fd-source-state fd-source-state--${repo.state}`}>{repo.state[0]!.toUpperCase() + repo.state.slice(1)}</span>
          </label>
          {selected?.shared && !picking && <span className="fd-badge">Shared</span>}
          <details className="fd-source-options"><summary aria-label={`Repository options: ${repo.displayName}`}><FloorIcon name="more" /></summary><div>
            <p>{repo.commit ? `Indexed ${repo.commit.slice(0, 8)}` : 'No indexed revision yet.'}{repo.errorCode ? ` · ${repo.errorCode}` : ''}</p>
            {selected && <label className="fd-shared-toggle"><input type="checkbox" aria-label={`Shared company source: ${repo.displayName}`} checked={selected.shared} onChange={e => change({ ...draft, repositories: draft.repositories.map(source => source.id === repo.id ? { ...source, shared: e.target.checked } : source) })} />Shared company source</label>}
            {repo.setup && <Button variant="quiet" type="button"  onClick={() => setup({ source: repo.setup, revision: repo.revision })}>Edit repository settings</Button>}
            {selected && <Button variant="quiet" type="button" className="fd-text-button" onClick={() => toggle(false)}>Remove from this floor</Button>}
          </div></details>
        </div>;
      })}
      {unavailable.map(repo => <div className="fd-unavailable-row" key={repo.id}><FloorIcon name="repository" /><span><strong>{repo.slug}</strong><small>Unavailable in the current catalog. Its saved selection is retained.</small></span>{picking && <Button variant="quiet" type="button"  onClick={() => change({ ...draft, repositories: draft.repositories.filter(source => source.id !== repo.id) })}>Remove</Button>}</div>)}
    </div>
    {!rows.length && !unavailable.length && <EmptyState className="fd-empty" level={3} title={<>{picking ? search ? 'No matching repositories' : 'No repositories connected yet' : 'No repositories on this floor'}</>}  icon={<FloorIcon name="repository" />} actions={<></>}>{picking ? search ? 'Try a different name or branch.' : 'Connect a repository to make it available here.' : 'Add sources so your team can use them in Knowledge.'}</EmptyState>}
    {picking && <><Button variant="quiet" type="button" className="fd-text-button fd-connect" onClick={() => setup({})}><FloorIcon name="plus" />Connect repository</Button><p className="fd-hint">{draft.repositories.length}/32 selected. Adding a source does not change repository access.</p></>}
  </div>;
}
