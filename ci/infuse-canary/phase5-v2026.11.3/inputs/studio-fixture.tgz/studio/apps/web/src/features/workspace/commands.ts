import { useEffect, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { parseMissionCommand, parseMissionReceipt, type MissionCommand, type MissionReceipt } from '@studio/contracts';
import { api, ApiError, getSession, ownerKey, readableError, type SignedInSession } from './api.js';

export interface PendingCommand { command: MissionCommand; status: 'sending' | 'uncertain' }
export interface CommandConflict { missionId: string; at: number }
const definitive = new Set(['INVALID_INPUT', 'VERSION_CONFLICT', 'STATE_CONFLICT', 'EVIDENCE_CONFLICT', 'TERMINAL', 'CONFIGURATION', 'ALREADY_EXISTS', 'NOT_FOUND', 'DISPATCH_DISABLED', 'EXECUTION_DISABLED', 'CLOSEOUT_PENDING', 'PROJECT_BUSY']);

/** Commands have their own recovery protocol. Query retries never resend a mutation. */
export function useCommands(session: SignedInSession) {
  const query = useQueryClient();
  const owner = ownerKey(session);
  const key = `infuse-studio:pending:${encodeURIComponent(session.bootstrap.authorityId)}:${encodeURIComponent(session.profileId)}`;
  const [recovery] = useState(() => {
    try { const saved = session.legacyProject ? sessionStorage.getItem(key) : null; return { pending: saved ? { command: parseMissionCommand(JSON.parse(saved)), status: 'uncertain' as const } : undefined, error: '' }; }
    catch { return { pending: undefined, error: 'A saved command could not be recovered. Inspect current mission state before making another decision.' }; }
  });
  const [pending, setPending] = useState<PendingCommand | undefined>(recovery.pending);
  const [failure, setFailure] = useState(recovery.error);
  const [conflict, setConflict] = useState<CommandConflict>();
  const [notice, setNotice] = useState('');
  const mounted = useRef(true);
  const busy = useRef(false);
  const suspended = useRef(false);
  const pendingRef = useRef(pending);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  function save(command?: MissionCommand): boolean {
    try { if (command) sessionStorage.setItem(key, JSON.stringify(command)); else sessionStorage.removeItem(key); return true; }
    catch { return false; }
  }
  async function execute(command: MissionCommand): Promise<MissionReceipt | undefined> {
    if (!session.legacyProject || busy.current || suspended.current || !navigator.onLine) return;
    if (!save(command)) { setFailure('Browser session storage is unavailable. No command was sent. Restore storage to keep decisions recoverable through reload.'); return; }
    busy.current = true;
    pendingRef.current = { command, status: 'sending' }; setPending(pendingRef.current); setFailure(''); setNotice('');
    try {
      // A refreshed identity is required, but never changes the reviewed command envelope.
      const isCurrent = () => mounted.current && !suspended.current;
      const fresh = await getSession(undefined, isCurrent, session.project.id);
      if (!mounted.current) return;
      if (suspended.current) throw Error('Sign-out started before command admission. Its envelope is retained for recovery.');
      query.setQueryData(['workspace-session', session.project.id], fresh);
      if (!fresh.authenticated || ownerKey(fresh) !== owner) throw new ApiError('UNAUTHENTICATED', 'Your signed-in identity changed. Reconnect as the original person to recover this command.', 401);
      if (command.type !== 'create' && !fresh.bootstrap.capabilities.approver) throw new ApiError('ROLE_REVOKED', 'Your decision role has changed. This command remains available to recover under the original identity.', 403);
      const receipt = parseMissionReceipt(await api('/api/studio/commands', { command, csrf: fresh.csrfToken, isCurrent }));
      if (receipt.commandId !== command.commandId || receipt.missionId !== command.missionId || receipt.version !== command.expectedVersion + 1) throw Error('The receipt does not match the submitted command. Inspect the mission before retrying.');
      if (!mounted.current) return;
      const cleared = save();
      if (!cleared) setFailure('The decision was recorded, but browser recovery storage could not be cleared. Retry the exact command to recover its receipt before making another decision.');
      pendingRef.current = cleared ? undefined : { command, status: 'uncertain' }; setPending(pendingRef.current); setConflict(undefined);
      setNotice(`${command.type === 'create' ? 'Mission paper saved' : 'Decision recorded'} · ${command.missionId} · version ${receipt.version}`);
      await query.invalidateQueries({ queryKey: ['workspace', owner] });
      return receipt;
    } catch (error) {
      if (!mounted.current) return;
      if (error instanceof ApiError && definitive.has(error.code)) {
        if (save()) {
          pendingRef.current = undefined; setPending(undefined);
          // Rejected input is editable; it may refer to a mission that was never created.
          if (error.code !== 'INVALID_INPUT' && !(command.type === 'create' && error.code === 'CONFIGURATION')) {
            setConflict({ missionId: command.missionId, at: Date.now() });
            void query.invalidateQueries({ queryKey: ['workspace', owner] });
          }
        } else {
          pendingRef.current = { command, status: 'uncertain' }; setPending(pendingRef.current);
          setFailure('The request was rejected, but browser recovery storage could not be cleared. Restore storage and retry the exact command before editing this decision.');
          return;
        }
      } else {
        // Transport errors and forbidden responses can occur after commit. Preserve the exact envelope.
        pendingRef.current = { command, status: 'uncertain' }; setPending(pendingRef.current);
      }
      setFailure(readableError(error));
    } finally { busy.current = false; }
  }
  return {
    suspend: () => { suspended.current = true; }, unsuspend: () => { suspended.current = false; },
    pending, failure, notice, conflict, recoveryBlocked: !!recovery.error,
    reviewCurrent: () => { setConflict(undefined); setFailure(''); },
    send: (command: MissionCommand) => {
      if (pendingRef.current || conflict || recovery.error || busy.current) return Promise.resolve(undefined);
      try { return execute(parseMissionCommand(command)); }
      catch (error) { setFailure(readableError(error)); return Promise.resolve(undefined); }
    },
    retry: () => pendingRef.current?.status === 'uncertain' ? execute(pendingRef.current.command) : Promise.resolve(undefined),
  };
}
export type Commands = ReturnType<typeof useCommands>;
