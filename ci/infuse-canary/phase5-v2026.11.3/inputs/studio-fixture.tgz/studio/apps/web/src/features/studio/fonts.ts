import regular from '@fontsource/ibm-plex-sans/files/ibm-plex-sans-latin-400-normal.woff2?inline';
import semibold from '@fontsource/ibm-plex-sans/files/ibm-plex-sans-latin-600-normal.woff2?inline';
import condensed from '@fontsource/ibm-plex-sans-condensed/files/ibm-plex-sans-condensed-latin-600-normal.woff2?inline';
import mono from '@fontsource/ibm-plex-mono/files/ibm-plex-mono-latin-500-normal.woff2?inline';

function bytes(data: string): Uint8Array<ArrayBuffer> {
  const comma = data.indexOf(',');
  if (comma < 0 || !data.slice(0, comma).endsWith(';base64')) throw Error('Studio font was not embedded in the browser bundle');
  return Uint8Array.from(atob(data.slice(comma + 1)), value => value.charCodeAt(0));
}

/** Binary font sources avoid fetching a data: URL under the Gateway's font-src policy. */
export async function mountStudioFonts(): Promise<() => void> {
  const faces = [
    new FontFace('StudioPlex', bytes(regular), { weight: '400' }),
    new FontFace('StudioPlex', bytes(semibold), { weight: '600' }),
    new FontFace('StudioCondensed', bytes(condensed), { weight: '600' }),
    new FontFace('StudioMono', bytes(mono), { weight: '500' }),
  ];
  await Promise.all(faces.map(face => face.load()));
  for (const face of faces) document.fonts.add(face);
  return () => { for (const face of faces) document.fonts.delete(face); };
}
