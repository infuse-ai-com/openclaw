import { Button } from './ui.js';
import { LoadingState } from './loading.js';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { parseConversationBind, parseConversationComment, parseConversationResponseRequest, type ConversationBindInput, type ConversationCommentInput,
  type ConversationBinding, type ConversationDelivery, type ConversationEvent, type ConversationResponse, type ConversationResponseRequest } from '@studio/contracts';
import { useWorkspace } from './context.js';
import { ApiError, accessDenied, bindConversation, commentOnConversation, getConversations, getSession, ownerKey, readableError, requestConversationResponse } from './api.js';
import { dateLabel } from '../studio/presentation.js';

type Submission = { kind: 'bind'; input: ConversationBindInput } | { kind: 'comment'; input: ConversationCommentInput }
  | { kind: 'response'; input: ConversationResponseRequest };
type Pending = { submission: Submission; state: 'sending' | 'uncertain' };
// Disabled/unavailable transport can reject receipt recovery after an earlier commit.
// Preserve that exact envelope until Studio can return its original receipt.
const definitive = new Set(['INVALID_INPUT', 'NOT_FOUND', 'CONFIGURATION', 'IDEMPOTENCY_CONFLICT', 'CONVERSATION_CONFLICT', 'CONVERSATION_LIMIT']);
function parseSubmission(value: unknown, missionId: string): Submission {
  const stored = value as { kind?: unknown; input?: unknown };
  let result: Submission;
  if (stored?.kind === 'bind') result = { kind: 'bind', input: parseConversationBind(stored.input) };
  else if (stored?.kind === 'comment') result = { kind: 'comment', input: parseConversationComment(stored.input) };
  else if (stored?.kind === 'response') result = { kind: 'response', input: parseConversationResponseRequest(stored.input) };
  else throw Error('Invalid saved conversation request');
  if (result.input.missionId !== missionId) throw Error('Saved conversation request belongs to another mission');
  return result;
}

export function Conversations({ missionId, readable, responseEligible }: { missionId: string; readable: boolean; responseEligible: boolean }) {
  const { session, owner, current, visible } = useWorkspace();
  const queryClient = useQueryClient();
  const queryKey = ['workspace', owner, 'conversations', missionId];
  const pages = useInfiniteQuery({ queryKey, initialPageParam: undefined as number | undefined,
    queryFn: ({ pageParam, signal }) => getConversations(missionId, pageParam, signal),
    getNextPageParam: page => page.nextBeforeSequence, enabled: current && readable,
    refetchInterval: current && readable && visible ? 7000 : false });
  const snapshot = accessDenied(pages.error) ? undefined : pages.data;
  const page = snapshot?.pages[0];
  const bindings = page?.bindings ?? [];
  const events = [...new Map((snapshot?.pages.flatMap(item => item.events) ?? []).map(event => [event.sequence, event])).values()]
    .sort((a, b) => b.sequence - a.sequence);
  const deliveries = [...(page?.deliveries ?? [])].sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
  const comments = deliveries.filter(delivery => delivery.author.kind === 'studio');
  const responses = [...(page?.responses ?? [])].sort((a, b) => b.requestedAt.localeCompare(a.requestedAt) || b.id.localeCompare(a.id));
  const storageKey = `infuse-studio:conversation:${encodeURIComponent(session.bootstrap.authorityId)}:${encodeURIComponent(session.profileId)}:${encodeURIComponent(missionId)}`;
  const [recovery] = useState(() => {
    try {
      const saved = sessionStorage.getItem(storageKey);
      return { pending: saved ? { submission: parseSubmission(JSON.parse(saved), missionId), state: 'uncertain' as const } : undefined, error: '' };
    } catch { return { pending: undefined, error: 'The saved conversation request could not be recovered. Restore browser session storage before submitting another request.' }; }
  });
  const [pending, setPending] = useState<Pending | undefined>(recovery.pending);
  const pendingRef = useRef(pending);
  const [failure, setFailure] = useState(recovery.error);
  const [notice, setNotice] = useState('');
  const [draft, setDraft] = useState('');
  const [rootPostId, setRootPostId] = useState('');
  const [chosenBinding, setChosenBinding] = useState('');
  const mounted = useRef(true); const busy = useRef(false);
  const enabled = current && readable && page?.available === true && !pages.isError;
  const responseEnabled = enabled && responseEligible && page?.responseAvailable === true;
  const recoveryEnabled = current && readable && !!page && !pages.isError;
  const live = useRef({ enabled, responseEnabled, recoveryEnabled, approver: session.bootstrap.capabilities.approver });
  live.current = { enabled, responseEnabled, recoveryEnabled, approver: session.bootstrap.capabilities.approver };
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  const binding = bindings.find(item => item.id === chosenBinding) ?? (bindings.length === 1 ? bindings[0] : undefined);
  const writable = enabled && !pending && !recovery.error;
  function save(submission?: Submission): boolean {
    try { if (submission) sessionStorage.setItem(storageKey, JSON.stringify(submission)); else sessionStorage.removeItem(storageKey); return true; }
    catch { return false; }
  }
  async function execute(submission: Submission, recovering = false) {
    const accessible = () => submission.kind === 'response' ? recovering ? live.current.recoveryEnabled : live.current.responseEnabled : live.current.enabled;
    if (busy.current || !accessible() || submission.kind === 'bind' && !live.current.approver) return;
    if (!save(submission)) { setFailure('Browser session storage is unavailable. Nothing was sent; restore storage so the exact request can be recovered.'); return; }
    busy.current = true; pendingRef.current = { submission, state: 'sending' }; setPending(pendingRef.current); setFailure(''); setNotice('');
    try {
      const isCurrent = () => mounted.current && accessible();
      const fresh = await getSession(undefined, isCurrent);
      if (!mounted.current) return;
      if (!accessible()) throw Error('Conversation access changed. The exact request is retained for recovery.');
      queryClient.setQueryData(['workspace-session'], fresh);
      if (!fresh.authenticated || ownerKey(fresh) !== owner) throw new ApiError('UNAUTHENTICATED', 'Reconnect as the original person to recover this request.', 401);
      if (submission.kind === 'bind') {
        if (!fresh.bootstrap.capabilities.approver) throw new ApiError('ROLE_REVOKED', 'A current Studio approver must bind the thread.', 403);
        await bindConversation(submission.input, fresh.csrfToken, isCurrent);
      } else if (submission.kind === 'comment') {
        const result = await commentOnConversation(submission.input, fresh.csrfToken, isCurrent);
        if (result.author.kind !== 'studio' || result.author.profileId !== fresh.profileId) throw Error('The comment receipt does not identify the submitting person.');
      } else {
        const result = await requestConversationResponse(submission.input, fresh.csrfToken, isCurrent);
        if (result.requestedBy !== fresh.profileId) throw Error('The response receipt does not identify the requesting person.');
      }
      if (!mounted.current) return;
      if (!save()) {
        pendingRef.current = { submission, state: 'uncertain' }; setPending(pendingRef.current);
        setFailure('Studio returned a receipt, but browser recovery storage could not be cleared. Recover the exact receipt before submitting again.');
      } else {
        pendingRef.current = undefined; setPending(undefined);
        if (submission.kind === 'comment') setDraft(''); else if (submission.kind === 'bind') setRootPostId('');
        setNotice(submission.kind === 'bind' ? 'Mattermost thread bound. Its observed conversation will appear here.'
          : submission.kind === 'comment' ? 'Comment recorded in Studio. Its Mattermost delivery status is shown below.'
          : 'Emon’s response request is recorded. Follow its runtime and Mattermost delivery receipts below.');
      }
      await queryClient.invalidateQueries({ queryKey });
    } catch (error) {
      if (!mounted.current) return;
      if (error instanceof ApiError && definitive.has(error.code) && save()) {
        pendingRef.current = undefined; setPending(undefined);
        if (submission.kind === 'comment') setDraft(submission.input.text); else if (submission.kind === 'bind') setRootPostId(submission.input.rootPostId);
        void queryClient.invalidateQueries({ queryKey });
      }
      else { pendingRef.current = { submission, state: 'uncertain' }; setPending(pendingRef.current); }
      setFailure(readableError(error));
    } finally { busy.current = false; }
  }
  function submit(kind: 'bind' | 'comment') {
    if (!writable || pendingRef.current || busy.current) return;
    try {
      const submission: Submission = kind === 'bind'
        ? { kind, input: parseConversationBind({ missionId, commandId: crypto.randomUUID(), rootPostId: rootPostId.trim() }) }
        : { kind, input: parseConversationComment({ missionId, commandId: crypto.randomUUID(), bindingId: binding?.id, text: draft }) };
      void execute(submission);
    } catch { setFailure(kind === 'bind' ? 'Enter the 26-character Mattermost root post ID.' : 'Enter a comment of up to 16,000 characters and choose a bound thread.'); }
  }
  function askEmon(bindingId: string, source: ConversationResponseRequest['source']) {
    if (!responseEnabled || pendingRef.current || busy.current || recovery.error) return;
    try { void execute({ kind: 'response', input: parseConversationResponseRequest({ missionId, bindingId, commandId: crypto.randomUUID(), source }) }); }
    catch { setFailure('This source could not be selected for Emon. Refresh the conversation before continuing.'); }
  }
  function sourceAction(bindingId: string, source: ConversationResponseRequest['source']) {
    const id = source.kind === 'event' ? String(source.sequence) : source.deliveryId;
    if (responses.some(response => response.bindingId === bindingId && response.source.kind === source.kind && response.source.id === id)) {
      return <span className="ws-small">Response already requested</span>;
    }
    return <Button variant="quiet" className="ws-conversation-ask" disabled={!responseEnabled || !!pending || !!recovery.error}
      onClick={() => askEmon(bindingId, source)}>Ask Emon</Button>;
  }
  return <section className="ws-conversations" aria-label="Mission conversation">
    <header><div><span className="ws-eyebrow">CONVERSATION / MATTERMOST</span><h2>Keep the discussion connected.</h2></div>
      <Button variant="quiet" disabled={!current || !readable || pages.isFetching} onClick={() => void pages.refetch()}>{pages.isFetching ? 'Refreshing conversation…' : 'Refresh conversation'}</Button></header>
    <p className="ws-conversation-boundary">Conversation only; sending a comment does not start an agent turn.</p>
    <p className="ws-conversation-purpose">Choose <strong>Ask Emon</strong> on a human message to request a response in the coordinator’s existing mission session. The approved scope and mission lifecycle stay unchanged.</p>
    {page && !responseEnabled && <p className="ws-small ws-conversation-purpose">Ask Emon requires an enabled coordinator connection and a running mission with no hold or closeout request.</p>}
    {!page && (pages.isError ? null : current && readable ? <LoadingState label="Loading conversation…" size="panel" /> : <p role="status">Reconnect to load this conversation.</p>)}
    {pages.isError && <p className="ws-alert" role="alert">{readableError(pages.error)} Retained records may be out of date. Refresh successfully before submitting.</p>}
    {page && !page.available && <p className="ws-alert">Conversation service is unavailable. Retained history remains readable; binding and comments are disabled.</p>}
    {page && (!current || !readable) && <p className="ws-alert">This is the last observed conversation. Reconnect and refresh before submitting.</p>}
    {bindings.map(item => <BoundThread key={item.id} binding={item} />)}
    {failure && <p className="ws-alert" role="alert">{failure}</p>}
    {notice && <p className="ws-alert ws-alert--success" role="status">{notice}</p>}
    {pending && <section className="ws-conversation-recovery" aria-label="Conversation request recovery"><h3>{pending.state === 'sending' ? 'Recording your request…' : 'Submission receipt is not confirmed.'}</h3>
      <p>{pending.state === 'sending' ? 'The exact request is retained while Studio responds.' : 'Recover the exact Studio request before composing another. This does not retry an uncertain agent turn or Mattermost delivery.'}</p>
      <details><summary>Retained request</summary><p className="ws-literal">{pending.submission.kind === 'comment' ? pending.submission.input.text
        : pending.submission.kind === 'bind' ? `Root post ID: ${pending.submission.input.rootPostId}`
        : `Ask Emon about ${pending.submission.input.source.kind === 'event' ? `observation ${pending.submission.input.source.sequence}` : `Studio comment ${pending.submission.input.source.deliveryId}`}`}</p></details>
      {pending.state === 'uncertain' && <Button variant="quiet" disabled={!(pending.submission.kind === 'response' ? recoveryEnabled : enabled) || pending.submission.kind === 'bind' && !session.bootstrap.capabilities.approver}
        onClick={() => void execute(pending.submission, true)}>Recover submission receipt</Button>}</section>}
    {page && !bindings.length && <section className="ws-conversation-setup"><h3>Bind an existing mission thread.</h3>
      <p>Use the neutral root post created by the dedicated Studio bot in the configured project channel. Studio verifies the post before binding it.</p>
      {session.bootstrap.capabilities.approver ? <form onSubmit={event => { event.preventDefault(); submit('bind'); }}>
        <label className="ws-field">Mattermost root post ID<input value={pending?.submission.kind === 'bind' ? pending.submission.input.rootPostId : rootPostId}
          onChange={event => setRootPostId(event.target.value)} maxLength={26} autoComplete="off" spellCheck={false} disabled={!writable} placeholder="26-character post ID" /></label>
        <Button variant="quiet" type="submit" disabled={!writable || !/^[a-z0-9]{26}$/.test(rootPostId.trim())}>Bind mission thread</Button>
      </form> : <p className="ws-small">A Studio approver can bind the mission thread.</p>}</section>}
    {!!bindings.length && <form className="ws-conversation-compose" onSubmit={event => { event.preventDefault(); submit('comment'); }}>
      <h3>Add to the conversation.</h3><p>Your comment is attributed to {session.displayName || session.profileId} and delivered by the Studio bot.</p>
      {bindings.length > 1 && <label className="ws-field">Bound thread<select value={chosenBinding} onChange={event => setChosenBinding(event.target.value)} disabled={!writable}><option value="">Choose a thread</option>{bindings.map(item => <option key={item.id} value={item.id}>{item.rootPostId}</option>)}</select></label>}
      <label className="ws-field">Comment<textarea rows={4} maxLength={16000} value={pending?.submission.kind === 'comment' ? pending.submission.input.text : draft}
        onChange={event => setDraft(event.target.value)} disabled={!writable || binding?.syncError === 'route-revoked'} aria-describedby="ws-comment-purpose" /></label>
      <div className="ws-actions"><Button type="submit" disabled={!writable || !binding || binding.syncError === 'route-revoked' || !draft.trim()}>Send comment</Button><span id="ws-comment-purpose" className="ws-small">A comment does not approve, start, or resume mission work.</span></div>
    </form>}
    {!!responses.length && <section className="ws-conversation-history" aria-label="Emon response requests"><h3>Responses from Emon</h3><p className="ws-small">One explicit request per source. Runtime progress and Mattermost delivery are recorded separately.</p>
      <ol>{responses.map(response => <Response key={response.id} response={response} delivery={deliveries.find(delivery => delivery.id === response.reply?.deliveryId)} binding={bindings.find(item => item.id === response.bindingId)} />)}</ol></section>}
    {!!comments.length && <section className="ws-conversation-history" aria-label="Studio comment deliveries"><h3>Comments from Studio</h3><p className="ws-small">Latest recorded comments and their separate delivery receipts.</p>
      <ol>{comments.map(delivery => <Delivery key={delivery.id} delivery={delivery} binding={bindings.find(item => item.id === delivery.bindingId)} action={sourceAction(delivery.bindingId, { kind: 'delivery', deliveryId: delivery.id })} />)}</ol></section>}
    <section className="ws-conversation-history" aria-label="Observed Mattermost history"><h3>Observed thread history</h3><p className="ws-small">Newest observations first. Earlier messages and later edits or deletions remain separate records.</p>
      {events.length ? <ol>{events.map(event => {
        const thread = bindings.find(item => item.id === event.bindingId);
        const superseded = events.some(later => later.bindingId === event.bindingId && later.postId === event.postId && later.sourceRevision > event.sourceRevision);
        return <ObservedEvent key={event.sequence} event={event} binding={thread} action={event.kind === 'message' && !!event.text.trim() && !superseded && event.author.kind === 'mattermost' && !!event.author.profileId && event.author.id !== thread?.botUserId
          ? sourceAction(event.bindingId, { kind: 'event', sequence: event.sequence }) : undefined} />;
      })}</ol>
        : page && <p className="ws-conversation-empty">No Mattermost messages have been observed for this mission.</p>}
      {pages.hasNextPage && <Button variant="quiet" disabled={!current || !readable || pages.isFetching} onClick={() => void pages.fetchNextPage()}>{pages.isFetchingNextPage ? 'Loading earlier observations…' : 'Load earlier observations'}</Button>}
    </section>
  </section>;
}

function BoundThread({ binding }: { binding: ConversationBinding }) {
  const errors = { offline: 'Mattermost could not be reached. This is the last observed history.', 'route-revoked': 'This thread no longer matches the configured route. Comment delivery is unavailable.',
    'history-limit': 'The thread exceeds the synchronization limit. Some messages may be missing.', 'invalid-source': 'Mattermost returned a source record that could not be verified. History may be incomplete.' };
  return <section className="ws-conversation-thread" aria-label="Bound Mattermost thread"><div><span className="ws-eyebrow">BOUND MISSION THREAD</span>
    <a className="ws-text-link" href={binding.threadUrl} target="_blank" rel="noopener noreferrer">Open thread in Mattermost ↗</a></div>
    <p className="ws-small">{binding.lastSyncedAt ? `Last synced ${dateLabel(binding.lastSyncedAt)}` : 'Awaiting the first synchronization.'}</p>
    {binding.syncError && <p className="ws-warning" role="status">{errors[binding.syncError]}</p>}</section>;
}
function DeliveryReceipt({ delivery, binding }: { delivery: ConversationDelivery; binding?: ConversationBinding }) {
  const labels = { pending: 'Queued for delivery', sending: 'Sending · receipt pending', delivered: 'Delivered to Mattermost', uncertain: 'Delivery uncertain', failed: 'Delivery failed' };
  const reasons: Record<string, string> = {
    'author-revoked-before-send': 'The author’s project access was removed before this comment could be sent.',
    'authority-revoked-before-send': 'The configured route or permission changed before this comment could be sent.',
    'delivery-outcome-unknown': 'Studio did not receive a confirmed post receipt from Mattermost.',
    'process-restarted-during-send': 'Studio restarted while delivery was in progress. The post receipt still needs reconciliation.',
    'multiple-post-receipts': 'More than one post receipt matches this delivery. It needs reconciliation.',
  };
  return <div className="ws-conversation-receipt"><div><span className={`ws-conversation-delivery ws-conversation-delivery--${delivery.state}`}>{labels[delivery.state]}</span>
      {delivery.postId && binding && <a href={`${binding.origin}/_redirect/pl/${delivery.postId}`} target="_blank" rel="noopener noreferrer">View post ↗</a>}</div>
    {delivery.reason && <p className="ws-small">{reasons[delivery.reason] ?? 'Studio could not confirm the delivery outcome. It needs reconciliation.'}</p>}
    {delivery.state === 'uncertain' && <p className="ws-warning">Mattermost may have received this message. It will not be sent again automatically.</p>}</div>;
}
function Delivery({ delivery, binding, action }: { delivery: ConversationDelivery; binding?: ConversationBinding; action?: ReactNode }) {
  return <li className="ws-conversation-entry"><header><strong>{delivery.author.label}</strong><span>From Studio · {dateLabel(delivery.createdAt)}</span></header><p className="ws-literal">{delivery.text}</p>
    <DeliveryReceipt delivery={delivery} binding={binding} />{action && <footer>{action}</footer>}</li>;
}
function Response({ response, delivery, binding }: { response: ConversationResponse; delivery?: ConversationDelivery; binding?: ConversationBinding }) {
  const labels = { queued: 'Queued for Emon', running: 'Emon is responding', completed: 'Coordinator turn completed', uncertain: 'Coordinator outcome uncertain', blocked: 'Response blocked' };
  const reasons: Record<string, string> = {
    'mission-not-running': 'The mission is no longer running.', 'mission-held': 'The mission is on hold.',
    'closeout-requested': 'Mission closeout has begun.', 'requester-revoked': 'The requesting person no longer has project access.',
    'runtime-outcome-unknown': 'The coordinator’s exact runtime receipt still needs reconciliation.',
    'source-changed': 'The selected source was edited or deleted after the request.',
    'assignment-no-longer-current': 'The original coordinator assignment is no longer available for this response.',
    'runtime-not-successful': 'A response was recorded, but the coordinator turn did not finish successfully.',
    'turn-ended-without-reply': 'The coordinator turn ended without recording a response.',
    'interruption-requested': 'Studio has requested interruption and is waiting for the exact runtime receipt.',
  };
  return <li className="ws-conversation-entry ws-conversation-response"><header><strong>Asked by {response.requestedBy}</strong>
    <span>{dateLabel(response.requestedAt)}</span></header>
    <details className="ws-conversation-source"><summary>Source from {response.source.author.label} · {response.source.kind === 'event' ? 'Mattermost' : 'Studio'}</summary>
      <p className="ws-literal">{response.source.text}</p></details>
    <p className={`ws-conversation-runtime ws-conversation-runtime--${response.status}`} role="status">{labels[response.status]}</p>
    {response.reason && <p className="ws-small">{reasons[response.reason] ?? 'Studio could not confirm that this coordinator request can continue. Review the mission’s runtime activity.'}</p>}
    {response.status === 'uncertain' && <p className="ws-warning">The coordinator may have received this request. Studio will not start another turn automatically.</p>}
    {response.reply ? <section className="ws-conversation-reply" aria-label="Recorded coordinator response"><header><strong>{delivery?.author.label ?? 'Emon'}</strong><span>Coordinator · {dateLabel(response.reply.at)}</span></header>
      <p className="ws-literal">{response.reply.text}</p>
      {delivery ? <DeliveryReceipt delivery={delivery} binding={binding} /> : <p className="ws-small">Response recorded in Studio. Its Mattermost delivery receipt is not in this page.</p>}
    </section> : <p className="ws-small">No coordinator response has been recorded yet.</p>}
  </li>;
}
function ObservedEvent({ event, binding, action }: { event: ConversationEvent; binding?: ConversationBinding; action?: ReactNode }) {
  const labels = { message: 'Message', edit: 'Edited post', delete: 'Deleted post' };
  return <li className="ws-conversation-entry"><header><strong>{event.author.label}</strong><span>{event.author.kind === 'mattermost' ? 'Mattermost' : 'Studio'} · {labels[event.kind]}</span></header>
    {event.kind === 'delete' ? <p className="ws-conversation-deleted">Post deleted in Mattermost.</p> : <p className="ws-literal">{event.text || '(Empty message)'}</p>}
    <footer><span>Observed {dateLabel(event.observedAt)}</span>{binding && <a href={`${binding.origin}/_redirect/pl/${event.postId}`} target="_blank" rel="noopener noreferrer">View post ↗</a>}{action}</footer>
  </li>;
}
