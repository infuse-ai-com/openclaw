import { useState } from 'react';
import { useQueries } from '@tanstack/react-query';
import { useWorkspace } from './context.js';
import { agentDirectory } from './company-work.js';
import { agentRoleGuide, AgentPortrait } from './agent-portrait.js';
import { targetKey } from '../studio/presentation.js';
import { agentTelemetryQuery } from './agent-telemetry.js';
import {utcStamp,relativeStamp} from './evidence-time.js';
import { telemetrySummary } from './agent-telemetry-summary.js';

const count = (value:number | undefined) => value === undefined ? 'Unknown' : new Intl.NumberFormat('en').format(value);
function Freshness({label,value}:{label:string;value:string|undefined}){return <small>{label} <time dateTime={value} title={utcStamp(value)}>{relativeStamp(value)}</time></small>;}
export function AgentOverview({entries,onInspect}:{entries:ReturnType<typeof agentDirectory>;onInspect:(key:string)=>void}) {
  const {session,current,visible}=useWorkspace(),[attentionOnly,setAttentionOnly]=useState(false);
  const queries=useQueries({queries:entries.map(entry=>agentTelemetryQuery(session.bootstrap.authorityId,session.profileId,entry.projectIds[0]!,entry.target,current,visible))});
  const rows=entries.map((entry,index)=>{
    const query=queries[index]!,value=current&&query.data&&'value' in query.data?query.data.value:undefined;
    return {entry,loading:current&&query.isPending,summary:telemetrySummary(value),configuration:value?.configuration};
  }).sort((a,b)=>Number(b.summary.attention)-Number(a.summary.attention));
  const attention=rows.filter(row=>!row.loading&&row.summary.attention).length;
  const shown=rows.filter(row=>!attentionOnly||row.loading||row.summary.attention);
  return <section className="ws-agent-overview" aria-label="Agent operations"><header><div><h2 id="agent-team-heading" tabIndex={-1}>Team operations</h2><p>Runtime health, model settings and reported usage. Readiness does not mean an agent is idle.</p></div><button className="ws-button ws-button--quiet" disabled={!current||queries.some(q=>q.isFetching)} onClick={()=>{for(const query of queries)void query.refetch();}}>Refresh team telemetry</button></header>
    <p className="ws-agent-fleet-summary" role="status">{rows.some(row=>row.loading)?'Checking the team…':`${attention} of ${rows.length} agents need attention.`} Source ages update with telemetry; hover a time for its exact UTC timestamp.</p>
    <div className="ui-segmented" role="group" aria-label="Filter agent operations"><button aria-pressed={!attentionOnly} onClick={()=>setAttentionOnly(false)}>All agents · {rows.length}</button><button aria-pressed={attentionOnly} onClick={()=>setAttentionOnly(true)}>Needs attention · {attention}</button></div>
    <div className="ws-agent-operation-list">{shown.map(({entry,loading,summary:s})=>{
      const name=agentRoleGuide(entry.target.agentId)?.name??entry.target.agentId;
      return <article className="ws-agent-operation" key={targetKey(entry.target)}><header><div className="ws-agent-operation-name"><AgentPortrait target={entry.target}/><div><h3>{name}</h3>{entry.observationOnly&&<small>Observation only</small>}<small>{entry.target.gatewayId} · {entry.target.agentId}</small></div></div><span className="ws-agent-operation-state">{loading?'Checking…':s.attention?'Needs attention':'Current evidence'}</span></header><div className="ws-agent-operation-metrics">
        {loading?<p role="status">Loading telemetry…</p>:<><div><span>Runtime health</span><strong>{s.runtimeLabel}</strong>{s.observation&&<small>{s.observation.readyReplicas}/{s.observation.desiredReplicas} ready · {s.observation.restarts} restarts</small>}<Freshness label="Observed" value={s.runtimeAt}/></div><div><span>Model policy</span><strong>{s.policy}</strong>{s.roleUnobserved&&<small>Role intent not observed</small>}<Freshness label="Observed" value={s.modelAt}/></div><div><span>Tokens · last 7 days UTC</span><strong>{count(s.tokens)}</strong><small>{s.usageState==='fresh'?'Recorded buckets · current source':`Source ${s.usageState}`}</small><Freshness label="Generated" value={s.usageAt}/></div></>}
        </div><div className="ws-agent-next-action"><div><span>Next action</span><strong>{loading?'Waiting for current evidence':s.nextAction}</strong></div><button className="ws-button ws-button--quiet" aria-label={`View telemetry for ${name}`} onClick={()=>onInspect(targetKey(entry.target))}>View telemetry</button></div>
      </article>;
    })}</div>{!shown.length&&<p role="status">{entries.length?'No agents need attention in this view.':'No matching agents.'}</p>}
  </section>;
}
