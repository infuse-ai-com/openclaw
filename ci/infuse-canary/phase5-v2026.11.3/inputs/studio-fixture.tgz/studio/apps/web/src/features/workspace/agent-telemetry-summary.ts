import type { AgentTelemetry, ModelObservation, RuntimeObservation, TelemetrySource } from '@studio/contracts';

export function modelVerdict(source: TelemetrySource): { label: string; attention: boolean } {
  if (source.state !== 'fresh' || !source.data) return { label: 'Current policy unknown', attention: true };
  const model = source.data as ModelObservation;
  if (model.mismatchFields.length) return { label: 'Drift detected', attention: true };
  const settings = Object.keys(model.declared).filter(key => key !== 'roleIntent') as (keyof ModelObservation['declared'])[];
  if (!settings.length || settings.some(key => model.observed[key] === undefined)) return { label: 'Runtime comparison incomplete', attention: true };
  return { label: model.declared.roleIntent !== undefined && model.observed.roleIntent === undefined ? 'Runtime settings match' : 'Matches declared policy', attention: false };
}

export function telemetrySummary(value: AgentTelemetry | undefined) {
  // Multiple sources of one kind must be inspected, not silently summed or selected.
  const one = (kind: TelemetrySource['kind']) => {
    const sources = value?.sources.filter(source => source.kind === kind) ?? [];
    return sources.length === 1 ? sources[0] : undefined;
  };
  const runtime = one('runtime'), model = one('model'), usage = one('usage');
  const observation = runtime?.state === 'fresh' ? runtime.data as RuntimeObservation | undefined : undefined;
  const ready = !!observation && observation.desiredReplicas > 0 && observation.readyReplicas >= observation.desiredReplicas;
  const runtimeLabel = !observation ? 'Runtime unknown' : observation.desiredReplicas === 0 ? 'Scaled to zero' : ready ? 'Ready' : 'Degraded';
  const policy = model ? modelVerdict(model) : { label: 'Current policy unknown', attention: true };
  const modelData = model?.data as ModelObservation | undefined;
  const roleUnobserved = modelData?.declared.roleIntent !== undefined && modelData.observed.roleIntent === undefined;
  const sourceGap = !usage || !value || !value.sources.length || value.sources.length < (value.configuredSourceCount ?? 0) || value.sources.some(source => source.state !== 'fresh');
  const nextAction=!value?'Reconnect or check telemetry access':value.configuration==='unconfigured'?'Configure telemetry sources':value.configuration==='paused'?'Review paused collection':
    !observation?'Check runtime source':!ready?'Inspect workload health':policy.attention?
    (policy.label==='Drift detected'?'Review model drift':'Check model evidence'):sourceGap?'Check telemetry sources':'No immediate action indicated';
  return {
    nextAction, runtimeLabel, observation, policy: policy.label, roleUnobserved,
    attention: !ready || policy.attention || sourceGap || value?.configuration === 'paused',
    tokens: usage?.state === 'fresh' ? usage.usage?.last7d?.totalTokens : undefined,
    usageState: usage?.state ?? 'unknown',
    runtimeAt: runtime?.observedAt, modelAt: model?.observedAt, usageAt: usage?.generatedAt,
  };
}
