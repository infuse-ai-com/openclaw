import {
  whiteboardSpatialOperation,
  type WhiteboardNavigation,
  type WhiteboardSummary,
  type WhiteboardSpatialOperation,
} from '@studio/contracts';
type Section = WhiteboardNavigation['sections'][number];
export function moveSelection(
  items: WhiteboardSummary[],
  ids: string[],
  source: string,
  destination: string,
  sections: Section[],
  origin = { x: 40, y: 60 },
): WhiteboardSpatialOperation[] {
  const chosen = new Set(ids),
    blocks = items.filter((item) => item.kind !== 'connection' && chosen.has(item.id));
  if (
    !blocks.length ||
    blocks.length !== chosen.size ||
    blocks.some((item) => item.sectionId !== source)
  )
    throw Error('The selection changed. Select the elements again.');
  if (destination === source) throw Error('These elements are already in this section.');
  if (!sections.some((section) => section.id === destination))
    throw Error('This destination is no longer available.');
  if (blocks.some((item) => item.kind !== 'connection' && item.locked))
    throw Error('Unlock the selected elements before moving them.');
  let cursor: string | null = destination;
  const visited = new Set<string>();
  while (cursor && cursor !== 'root') {
    if (chosen.has(cursor) || visited.has(cursor))
      throw Error('A section cannot move inside itself or its descendants.');
    visited.add(cursor);
    cursor = sections.find((s) => s.id === cursor)?.parentId ?? null;
  }
  const links = items.filter(
    (item) => item.kind === 'connection' && (chosen.has(item.source) || chosen.has(item.target)),
  );
  if (
    links.some(
      (item) =>
        item.kind === 'connection' && (!chosen.has(item.source) || !chosen.has(item.target)),
    )
  )
    throw Error('Select both ends of connected elements before moving them.');
  if (blocks.length + links.length > 30)
    throw Error('Move up to 30 elements and connections at once.');
  const left = Math.min(...blocks.map((b) => (b.kind === 'connection' ? 0 : b.x))),
    top = Math.min(...blocks.map((b) => (b.kind === 'connection' ? 0 : b.y)));
  // Place the cluster inside its destination while keeping its relative geometry.
  return [...blocks, ...links].map((item) =>
    whiteboardSpatialOperation.parse({
      type: 'reparent',
      id: item.id,
      expectedRevision: item.revision,
      sectionId: destination,
      ...(item.kind !== 'connection'
        ? { position: { x: origin.x + item.x - left, y: origin.y + item.y - top } }
        : {}),
    }),
  );
}
export function SectionTree({
  sections,
  current,
  canMove,
  selectedCount,
  enter,
  rename,
  move,
}: {
  sections: Section[];
  current: string;
  canMove: boolean;
  selectedCount: number;
  enter(id: string): void;
  rename(section: Section): void;
  move(id: string): void;
}) {
  function branch(parent: string | null, depth = 0): React.ReactNode {
    if (depth > 8) return null;
    return (
      <ul>
        {sections
          .filter((section) => section.parentId === parent)
          .map((section) => (
            <li key={section.id}>
              <div className="wboard-section-tree-row">
                <button
                  type="button"
                  aria-current={current === section.id ? 'page' : undefined}
                  onClick={() => enter(section.id)}
                >
                  {section.title}
                  <small>{section.count}</small>
                </button>
                {section.id !== 'root' && (
                  <button
                    type="button"
                    aria-label={'Rename section ' + section.title}
                    title="Rename section"
                    onClick={() => rename(section)}
                  >
                    Rename
                  </button>
                )}
                {selectedCount > 0 && section.id !== current && (
                  <button
                    type="button"
                    disabled={!canMove}
                    aria-label={'Move selection to ' + section.title}
                    title={'Move ' + selectedCount + ' selected elements here'}
                    onClick={() => move(section.id)}
                  >
                    Move here
                  </button>
                )}
              </div>
              {branch(section.id, depth + 1)}
            </li>
          ))}
      </ul>
    );
  }
  return (
    <nav className="wboard-section-tree" aria-label="Section tree">
      <h3>Sections</h3>
      {branch(null)}
    </nav>
  );
}
