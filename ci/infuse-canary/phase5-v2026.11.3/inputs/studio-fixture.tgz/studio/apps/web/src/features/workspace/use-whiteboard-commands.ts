import { useEffect, useMemo, useRef, useSyncExternalStore } from 'react';
import { api } from './api.js';
import { whiteboardSessionStorage } from './whiteboard-storage.js';
import { WhiteboardCommands, type BoardCommandContext } from './whiteboard-commands.js';

export function useWhiteboardCommands(options: {
  owner: string;
  path: string;
  projectId: string;
  profileId: string;
  context(): BoardCommandContext;
}) {
  const context = useRef(options.context);
  context.current = options.context;
  const commands = useMemo(
    () =>
      new WhiteboardCommands({
        owner: options.owner,
        path: options.path,
        projectId: options.projectId,
        profileId: options.profileId,
        storage: whiteboardSessionStorage(),
        request: api,
        context: () => context.current(),
      }),
    [options.owner, options.path, options.projectId, options.profileId],
  );
  useEffect(() => {
    commands.activate();
    return () => commands.deactivate();
  }, [commands]);
  const state = useSyncExternalStore(commands.subscribe, commands.snapshot);
  return { commands, ...state, busy: state.phase === 'sending' || state.phase === 'recovering' };
}
