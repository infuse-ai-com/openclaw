import type {
  WhiteboardBlock, WhiteboardDetails, WhiteboardManifest, WhiteboardNavigation,
  WhiteboardSpatialItem, WhiteboardSpatialOperation, WhiteboardReceipt,
} from '@studio/contracts';
import type { Commit } from './whiteboard-types.js';
import { selectionSection } from './whiteboard-selection-section.js';
import { arrangeSelection, type ArrangeAction } from './whiteboard-arrange.js';
import { moveSelection } from './whiteboard-sections.js';
import { encodeBoardClipboard, decodeBoardClipboard, copyBoardItems } from './whiteboard-clipboard.js';

type Point = { x: number; y: number };
export type SelectionAction =
  | { kind: 'delete' | 'duplicate' | 'group' | 'copy'; ids?: string[] }
  | { kind: 'lock'; ids: string[]; locked: boolean }
  | { kind: 'color'; color: NonNullable<WhiteboardBlock['noteColor']> }
  | { kind: 'arrange'; action: ArrangeAction }
  | { kind: 'move'; destination: string; ids?: string[] }
  | { kind: 'paste'; text: string; point?: Point | null }
  | { kind: 'pasteClipboard'; point?: Point | null };
export type SelectionResult = {
  operations?: WhiteboardSpatialOperation[];
  selected?: string[];
  focused?: Extract<WhiteboardSpatialItem, { kind: 'section' }>;
  message?: string;
};
export type SelectionContext = {
  allowed: boolean; shared: boolean; scope: string; owner: string; projectId: string;
  sectionId: string; path: string; csrf: string; selection: string[]; pastePoint: Point;
  refresh(): Promise<WhiteboardManifest | undefined>;
  commit: Commit;
  started(action: SelectionAction): void;
  applied(action: SelectionAction, ids: string[], result: SelectionResult, receipt?: WhiteboardReceipt): void;
  finished(action: SelectionAction): void;
  notify(message: string): void;
};
export type SelectionIO = {
  details(context: SelectionContext, revision: number, ids: string[]): Promise<WhiteboardDetails>;
  navigation(context: SelectionContext): Promise<WhiteboardNavigation>;
  section(context: SelectionContext, sectionId: string): Promise<WhiteboardManifest>;
  copy(text: string): Promise<void>;
  paste(): Promise<string>;
};

/** One preparation owner. Commands retain transmission, exact receipts and recovery. */
export class WhiteboardSelectionActions {
  #preparing = false;
  #generation = 0;
  constructor(private context: () => SelectionContext, private io: SelectionIO,
    private changed: (preparing: boolean) => void, private identifier = () => crypto.randomUUID()) {}
  get preparing() { return this.#preparing; }
  invalidate() { this.#generation++; }
  async run(action: SelectionAction) {
    const context = this.context();
    if (!context.allowed || this.#preparing || action.kind === 'group' && !context.shared) return;
    const ids = [...('ids' in action && action.ids ? action.ids : context.selection)];
    if (!['paste', 'pasteClipboard'].includes(action.kind) && !ids.length) return;
    const generation = this.#generation, scope = context.scope;
    const current = () => generation === this.#generation && scope === this.context().scope;
    this.#preparing = true; this.changed(true); context.started(action);
    try {
      if (ids.length > 30 && !['paste', 'pasteClipboard'].includes(action.kind)) throw Error('Choose up to 30 elements at once.');
      const result = await this.prepare(action, ids, context, current);
      if (!result || !current()) return;
      if ((result.operations?.length ?? 0) > 30) throw Error('Choose fewer blocks. One action supports up to 30 blocks and connections.');
      const receipt = result.operations?.length ? await context.commit(result.operations) : undefined;
      if (current() && (!result.operations?.length || receipt?.status === 'applied')) context.applied(action, ids, result, receipt);
    } catch (error) {
      if (current()) context.notify(error instanceof Error ? error.message : 'The selection action failed. Try again.');
    } finally {
      this.#preparing = false; this.changed(false);
      if (current()) context.finished(action);
    }
  }
  private async prepare(action: SelectionAction, ids: string[], context: SelectionContext, current: () => boolean): Promise<SelectionResult | undefined> {
    if (action.kind === 'paste' || action.kind === 'pasteClipboard') {
      let text: string;
      try { text = action.kind === 'paste' ? action.text : await this.io.paste(); }
      catch { throw Error('Press ⌘/Ctrl V to paste at this spot. Your browser did not provide clipboard access.'); }
      if (!current()) return;
      const prepared = decodeBoardClipboard(text, context.owner, context.sectionId, action.point ?? context.pastePoint, this.identifier);
      return { operations: prepared.operations, selected: prepared.ids };
    }
    const fresh = await context.refresh();
    if (!current()) return;
    if (!fresh || fresh.projectId !== context.projectId || fresh.sectionId !== context.sectionId)
      throw Error('The selection could not be refreshed. Try again.');
    const chosen = fresh.items.filter(item => item.kind !== 'connection').filter(item => ids.includes(item.id));
    if (chosen.length !== new Set(ids).size) throw Error('The selection changed. Select the elements again.');
    switch (action.kind) {
      case 'lock': return { operations: chosen.filter(item => !!item.locked !== action.locked).map(item => ({ type: 'setLocked', id: item.id, expectedRevision: item.revision, locked: action.locked })) };
      case 'color': return { operations: chosen.filter(item => item.kind === 'note' && (item.noteColor ?? 'yellow') !== action.color)
        .map(item => ({ type: 'update', id: item.id, expectedRevision: item.revision, patch: { noteColor: action.color } })) };
      case 'arrange': return { operations: arrangeSelection(fresh.items, ids, action.action) };
      case 'group': {
        const { section, operations } = selectionSection(fresh.items, ids, context.sectionId, this.identifier());
        return { operations, selected: [section.id], focused: { ...section, revision: 0 } };
      }
      case 'move': {
        const navigation = await this.io.navigation(context);
        if (!current()) return;
        if (navigation.projectId !== context.projectId) throw Error('The workspace changed. Reopen this board.');
        const contents = await this.io.section(context, action.destination);
        if (!current()) return;
        const occupied = contents.items.filter(item => item.kind !== 'connection');
        const origin = { x: 40, y: occupied.length ? Math.max(...occupied.map(item => item.y + item.height)) + 60 : 60 };
        return { operations: moveSelection(fresh.items, ids, context.sectionId, action.destination, navigation.sections, origin),
          selected: [], message: 'Moved into ' + (navigation.sections.find(s => s.id === action.destination)?.title ?? 'section') + '. Undo on this board brings the elements back.' };
      }
      case 'delete': {
        const links = fresh.items.filter(item => item.kind === 'connection' && (ids.includes(item.source) || ids.includes(item.target)));
        return { selected: [], operations: [...links, ...chosen].map(item => ({ type: 'delete', id: item.id, expectedRevision: item.revision })) };
      }
      case 'duplicate':
      case 'copy': {
        const details = await this.io.details(context, fresh.revision, ids);
        if (!current()) return;
        if (details.projectId !== context.projectId || details.sectionId !== context.sectionId || details.revision !== fresh.revision || details.missingIds.length)
          throw Error('The selection changed. Select the elements again.');
        const links = fresh.items.filter(item => item.kind === 'connection').filter(item => ids.includes(item.source) && ids.includes(item.target));
        if (action.kind === 'copy') { await this.io.copy(encodeBoardClipboard([...details.items, ...links], context.owner)); return { message: 'Copied. Paste here or in another section.' }; }
        const blocks = details.items.filter(item => item.kind !== 'connection');
        const prepared = copyBoardItems([...details.items, ...links], context.sectionId,
          { x: Math.min(...blocks.map(item => item.x)) + 32, y: Math.min(...blocks.map(item => item.y)) + 32 }, this.identifier);
        return { operations: prepared.operations, selected: prepared.ids };
      }
    }
  }
}
