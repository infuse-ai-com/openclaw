import { useEffect, useState, type ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import { icons } from '@studio/ui/icons';
import type { AgentTelemetry } from '@studio/contracts';
import { useWorkspace } from './context.js';
import { agentDirectory } from './company-work.js';
import { agentTelemetryQuery } from './agent-telemetry.js';
import { telemetrySummary } from './agent-telemetry-summary.js';
import { agentProfileEvidence, agentUsageDays, singleAgentSource } from './agent-profile-data.js';
import { AgentPortrait, agentRoleGuide, agentStrengthDescription } from './agent-portrait.js';
import { Link } from './navigation.js';
export type AgentEntry = ReturnType<typeof agentDirectory>[number];
export type AgentTab = 'about' | 'work' | 'telemetry';
export function AgentIcon({name}:{name:keyof typeof icons}) { return <span className="ws-glyph" aria-hidden="true" dangerouslySetInnerHTML={{__html:icons[name]}}/>; }
export function AgentHeading({icon,children}:{icon:keyof typeof icons;children:ReactNode}) {return <h3><AgentIcon name={icon}/>{children}</h3>;}
export function useAgentEvidence(entry:AgentEntry) {
  const {session,current,visible}=useWorkspace();
  const query=useQuery(agentTelemetryQuery(session.bootstrap.authorityId,session.profileId,entry.projectIds[0]!,entry.target,current,visible));
  return {value:current&&query.data&&'value' in query.data?query.data.value:undefined,loading:current&&query.isPending};
}
export function AgentCharacter({agentId}:{agentId:string}) {
  const [portrait,setPortrait]=useState<{state:'loading'|'unavailable'}|{state:'ready';src:string}>({state:'loading'});
  useEffect(()=>{
    let active=true;setPortrait({state:'loading'});
    void import('./floor-portrait.js').then(async ({floorPortrait})=>{
      if(!active)return;
      const src=floorPortrait(agentId,true);
      if(!src){setPortrait({state:'unavailable'});return;}
      const image=new Image();image.src=src;
      await image.decode();
      if(active)setPortrait({state:'ready',src});
    }).catch(()=>{if(active)setPortrait({state:'unavailable'});});
    return()=>{active=false;};
  },[agentId]);
  return <div className="ws-agent-character" aria-hidden="true" data-portrait-state={portrait.state}>{portrait.state==='ready'?<img src={portrait.src} alt=""/>:portrait.state==='unavailable'?<AgentPortrait target={{agentId}}/>:null}</div>;
}
export function AgentUsageChart({value}:{value:AgentTelemetry|undefined}) {
  const days=agentUsageDays(value),source=singleAgentSource(value,'usage');
  if(!days.length)return null;
  const max=Math.max(1,...days.map(day=>day.total??0));
  return <svg className="ws-agent-token-chart" viewBox="0 0 160 36" role="img" aria-label={`Recorded daily tokens · UTC · source ${source?.state}: ${days.map(day=>`${day.date}: ${day.total===null?'unknown':day.total}`).join(', ')}`}>
    {days.map((day,index)=>day.total===null?<path key={day.date} d={`M${index*23} 34h16`} stroke="currentColor" strokeDasharray="2 3" opacity=".35"/>:<rect key={day.date} x={index*23} y={34-Math.max(2,day.total/max*32)} width="16" height={Math.max(2,day.total/max*32)} rx="2" fill="currentColor" opacity={source?.state==='fresh'?.65:.35}/>)}
  </svg>;
}
const number=(value:number|undefined)=>value===undefined?'Unknown':new Intl.NumberFormat('en',{notation:'compact',maximumFractionDigits:1}).format(value);
export function AgentSnapshot({entry,value,loading,onTab}:{entry:AgentEntry;value:AgentTelemetry|undefined;loading:boolean;onTab:(tab:AgentTab)=>void}) {
  const summary=telemetrySummary(value),evidence=agentProfileEvidence(value),usage=singleAgentSource(value,'usage'),focus=entry.work.find(item=>!item.proposed&&!item.held)??entry.work[0];
  return <><div className="ws-agent-snapshot" aria-label="Agent operational summary">
    <button onClick={()=>onTab('telemetry')}><span><AgentIcon name="server"/>Runtime</span><strong>{loading?'Checking…':summary.runtimeLabel}</strong><small>{value?.configuration==='paused'?'Collection paused':summary.observation?`${summary.observation.readyReplicas} / ${summary.observation.desiredReplicas} ready`:'Current health unknown'}</small></button>
    <button onClick={()=>onTab('telemetry')}><span><AgentIcon name="settings"/>Model</span><strong>{loading?'Checking…':evidence.model??'Not observed'}</strong><small>{summary.policy}</small></button>
    <button onClick={()=>onTab('telemetry')}><span><AgentIcon name="chart"/>Tokens · last 7 days UTC</span><div className="ws-agent-token-summary"><strong>{loading?'Checking…':number(usage?.usage?.last7d?.totalTokens)}</strong><AgentUsageChart value={value}/></div><small>{usage?`${usage.state==='fresh'?'Recorded':'Retained'} · ${usage.state} source`:'No usage observation'}</small></button>
  </div>{focus?<button className="ws-agent-focus" onClick={()=>onTab('work')}><span className="ws-agent-focus-arrow" aria-hidden="true">↗</span><span><small>{focus.stale?'LAST KNOWN · ':''}{focus.proposed?'PROPOSED WORK':'LINKED WORK'} · {focus.projectName}</small><strong>{focus.missionTitle}</strong><span>{focus.next}</span></span><span aria-hidden="true">↗</span></button>:<p className="ws-agent-focus-empty">{entry.observationOnly?'This agent is observed in Studio and cannot be assigned Studio missions.':'No linked missions in the inspected records. This does not establish availability.'}</p>}</>;
}
export function AgentIdentity({entry,value}:{entry:AgentEntry;value:AgentTelemetry|undefined}) {
  const evidence=agentProfileEvidence(value),guide=agentRoleGuide(entry.target.agentId),missions=new Set(entry.work.map(item=>item.path));
  return <div className="ws-agent-identity"><span className="ws-eyebrow">{entry.observationOnly?'OBSERVATION ONLY':'INFUSE TEAM'}</span><h3 className="ws-agent-company-line">In good company.</h3><p><strong>{missions.size}</strong> linked {missions.size===1?'mission':'missions'}<small>Across {entry.projects.length} admitted {entry.projects.length===1?'project':'projects'}</small></p>
    <h3><AgentIcon name="building"/>Projects in view</h3><ul>{entry.projects.map((project,index)=><li key={entry.projectIds[index]}><Link to={`/floor?project=${encodeURIComponent(entry.projectIds[index]!)}`}>{project}</Link></li>)}</ul>
    <section className="ws-agent-details"><h3><AgentIcon name="profile"/>Profile details</h3><dl><dt>Agent / Gateway</dt><dd>{entry.target.agentId} / {entry.target.gatewayId}</dd><dt>Harness</dt><dd>{evidence.harness??'Not reported'}{evidence.harness&&evidence.modelState!=='fresh'&&<small>Retained harness · {evidence.modelState}.</small>}</dd><dt>Runtime version</dt><dd>{evidence.version??'Not reported'}{evidence.version&&evidence.runtimeState!=='fresh'&&<small>Retained version · {evidence.runtimeState}.</small>}</dd><dt>Work records inspected</dt><dd>{entry.work.length}</dd></dl>{guide&&<p>Maintained role introduction. <Link to="/knowledge?project=core&repo=agent-skills&path=skills%2Ftech-org%2Freferences%2Fagents.md">Read the role source ↗</Link></p>}</section>
  </div>;
}
const examples:Record<string,string[]>={
  ember:['Turn this idea into a scoped mission.','Choose the team and define who owns what.','Help me decide what to prioritize next.'],
  blue:['Build a bounded feature from this approved scope.','Find the cause of this bug and verify the fix.','Show runnable evidence for this change.'],
  plum:['Find what makes this flow hard to use.','Check the built experience against the design.','Make this interface clearer and more accessible.'],
  ochre:['Investigate this service’s runtime health.','Check why this rollout failed.','Make the deployment repeatable.'],
  teal:['Challenge the assumptions in this proposal.','Help us weigh this tradeoff.','Review how we work as a team.'],
  clay:['Turn this client message into clear next steps.','Prepare a reply for human review.','Clarify the handoff to delivery.'],
};
export function AgentAbout({entry}:{entry:AgentEntry}) {
  const guide=agentRoleGuide(entry.target.agentId);
  return <div className="ws-agent-about-grid"><div><section className="ws-agent-section"><AgentHeading icon="profile">About me</AgentHeading><p>{guide?.about??'This agent’s public introduction has not been added yet. Explore its recorded work and telemetry.'}</p></section>{guide&&<><section className="ws-agent-section"><AgentHeading icon="review">What I bring</AgentHeading><ul className="ws-agent-strengths">{guide.strengths.map(strength=><li key={strength}><span className="ws-agent-strength-icon"><AgentIcon name={(['document','users','review'] as const)[guide.strengths.indexOf(strength)%3]!}/></span><div><strong>{strength}</strong><small>{agentStrengthDescription(strength)}</small></div></li>)}</ul></section><section className="ws-agent-section"><AgentHeading icon="operations">How I work</AgentHeading><p>{guide.workingStyle}</p></section></>}</div><div><section className="ws-agent-section"><AgentHeading icon="pointer">Best used for</AgentHeading>{guide?<><p className="ws-agent-caption">Bring me a request like…</p><ul className="ws-agent-example-list">{(examples[guide.theme]??[]).map(example=><li key={example}>“{example}”</li>)}</ul></>:<p>Role-specific examples have not been added for this agent.</p>}</section><section className="ws-agent-section"><AgentHeading icon="library">Most used skills</AgentHeading><p className="ws-agent-caption">Skill-use counts are not recorded yet.</p>{guide&&<><h4>Recommended role guides</h4><div className="ws-agent-guide-links">{guide.guides.map(skill=><Link className="ws-agent-guide" key={skill.id} to={`/skills?skill=${encodeURIComponent(skill.id)}`}><span>{skill.name}</span><span aria-hidden="true">↗</span></Link>)}</div></>}</section></div></div>;
}
const stage=(state:string)=>({draft:'Shaping',approved:'Approved',running:'In progress',closing:'Closing',closed:'Closed',cancelled:'Cancelled',assigned:'Assigned',delivered:'Ready for review',verified:'Verified',pending:'Pending',blocked:'Blocked',revision:'Revision requested',Planned:'Planned'}[state]??state);
export function AgentWorkRecords({entry}:{entry:AgentEntry}) {
  return <section className="ws-agent-section ws-agent-records" id="agent-work-records"><AgentHeading icon="files">Work across projects</AgentHeading>{entry.work.map((item,index)=><Link className="ws-agent-work" key={`${item.projectId}:${item.path}:${index}`} to={item.path}><header><span>{item.projectName}</span><span>{item.proposed?'Proposed role':'Assigned role'} · {item.held?'On hold':stage(item.state)}</span></header><strong>{item.missionTitle}</strong><p>{item.title}</p><p className="ws-agent-receipt">{item.receipt}</p><footer>{item.stale&&<span>Last known · </span>}{item.next} <span aria-hidden="true">↗</span></footer></Link>)}{!entry.work.length&&<div className="ws-agent-no-work"><p>{entry.observationOnly?'Read-only telemetry':'No linked missions to show.'}</p><span>{entry.observationOnly?'This agent is observed in Studio and cannot be assigned Studio missions.':'Work appears here when this agent is named in a mission you can access.'}</span></div>}</section>;
}
