type Box={id:string;kind:string;title?:string;x:number;y:number;width:number;height:number};
export type AlignmentGuide={axis:'x'|'y';position:number;start:number;end:number;label:string};
type Match={delta:number;position:number;target:Box;anchor:number;targetAnchor:number;gap:number};
const rectangular=new Set(['note','document','section','html','image']);
const anchorNames={x:['Left edge','Center','Right edge'],y:['Top edge','Center','Bottom edge']};

/** A six-screen-pixel magnet for the moving selection's edges and center. */
export function alignWhiteboardDrag(moving:Box[],targets:Box[],zoom:number,bypass=false) {
  const offset={x:0,y:0},guides:AlignmentGuide[]=[];
  if(bypass||!moving.some(item=>rectangular.has(item.kind))||!Number.isFinite(zoom)||zoom<=0)return {offset,guides};
  const x=Math.min(...moving.map(item=>item.x)),y=Math.min(...moving.map(item=>item.y));
  const bounds={x,y,width:Math.max(...moving.map(item=>item.x+item.width))-x,height:Math.max(...moving.map(item=>item.y+item.height))-y};
  const excluded=new Set(moving.map(item=>item.id));
  const candidates=targets.filter(item=>rectangular.has(item.kind)&&!excluded.has(item.id));
  const matches:Partial<Record<'x'|'y',Match>>={};
  for(const axis of ['x','y'] as const) {
    const length=axis==='x'?'width':'height',other=axis==='x'?'y':'x',otherLength=axis==='x'?'height':'width';
    let best:Match|undefined;
    for(const target of candidates)for(let anchor=0;anchor<3;anchor++)for(let targetAnchor=0;targetAnchor<3;targetAnchor++) {
      const position=target[axis]+target[length]*targetAnchor/2;
      const delta=position-(bounds[axis]+bounds[length]*anchor/2);
      if(Math.abs(delta)*zoom>6||moving.some(item=>item[axis]+delta < -100000||item[axis]+delta > 100000))continue;
      const gap=Math.max(0,target[other]-bounds[other]-bounds[otherLength],bounds[other]-target[other]-target[otherLength]);
      // Prefer the closest line, then matching edges/centers and the nearer neighbor.
      const comparison=best?Math.abs(delta)-Math.abs(best.delta)
        ||Number(anchor!==targetAnchor)-Number(best.anchor!==best.targetAnchor)
        ||gap-best.gap||target.id.localeCompare(best.target.id):-1;
      if(comparison<0)best={delta,position,target,anchor,targetAnchor,gap};
    }
    if(best){offset[axis]=best.delta;matches[axis]=best;}
  }
  for(const axis of ['x','y'] as const) {
    const match=matches[axis];if(!match)continue;
    const other=axis==='x'?'y':'x',length=axis==='x'?'height':'width';
    guides.push({axis,position:match.position,
      start:Math.min(bounds[other]+offset[other],match.target[other])-8/zoom,
      end:Math.max(bounds[other]+offset[other]+bounds[length],match.target[other]+match.target[length])+8/zoom,
      label:`${anchorNames[axis][match.anchor]} aligned with ${match.target.title||match.target.kind} (${anchorNames[axis][match.targetAnchor]!.toLowerCase()}).`});
  }
  return {offset,guides};
}
