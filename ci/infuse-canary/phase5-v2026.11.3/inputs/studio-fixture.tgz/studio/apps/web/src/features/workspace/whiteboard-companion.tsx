import { Button, IconButton, ViewSwitch } from './ui.js';
import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { whiteboardCompanionPage, type WhiteboardAgentPresence } from '@studio/contracts';
import { api } from './api.js';
import { WhiteboardChat } from './whiteboard-chat.js';
import { BoardIcon } from './whiteboard-icon.js';
import './whiteboard-companion.css';
import { useCompanionPlacement } from './whiteboard-companion-placement.js';

type Props = { path:string; projectId:string; owner:string; csrf:string; sectionId:string; suspended:boolean;
  reveal(section:string,ids:string[]):void;
  locate(presence:WhiteboardAgentPresence):boolean;
  openLink(section:string,block?:string):void };
const agentName = (id:string) => id.replace(/[-_]/g,' ').replace(/^./,letter=>letter.toUpperCase());
const identity = (p:WhiteboardAgentPresence) => JSON.stringify([p.actorId,p.sessionId]);
/** A compact conversation alongside saved agent observations; camera following remains opt-in. */
export function WhiteboardCompanion({path,projectId,owner,csrf,sectionId,suspended,locate,openLink,reveal}:Props) {
  const [tab,setTab]=useState<'chat'|'updates'>('chat');
  const [open,setOpen]=useState(false),[following,setFollowing]=useState<string|null>(null);
  const [older,setOlder]=useState<ReturnType<typeof whiteboardCompanionPage.parse>['updates']>([]);
  const [historyHead,setHistoryHead]=useState<ReturnType<typeof whiteboardCompanionPage.parse>['updates']|null>(null);
  const [before,setBefore]=useState<number|null>(null),[loading,setLoading]=useState(false),[error,setError]=useState('');
  const trigger=useRef<HTMLButtonElement>(null),panel=useRef<HTMLElement>(null),location=useRef(locate);
  const placement=useCompanionPlacement(panel,owner,open);
  location.current=locate;
  const feed=useQuery({queryKey:['workspace',owner,'whiteboard-companions'],queryFn:async({signal})=>
    whiteboardCompanionPage.parse(await api(path+'/v3/companions',{signal})),refetchInterval:2000,retry:false});
  const people=(feed.data?.presence??[]).filter(p=>Date.parse(p.expiresAt)>Date.now());
  useEffect(()=>{if(suspended){setOpen(false);setFollowing(null);}},[suspended]);
  useEffect(()=>{
    if(!following)return;
    const peer=feed.data?.presence.find(p=>identity(p)===following);
    if(feed.isError || !peer || Date.parse(peer.expiresAt)<=Date.now() || !location.current(peer))setFollowing(null);
  },[following,feed.dataUpdatedAt,feed.isError]);
  useEffect(()=>{
    if(!following)return;
    const stop=(event:Event)=>{if(!panel.current?.contains(event.target as Node)&&event.target!==trigger.current)setFollowing(null);};
    document.addEventListener('pointerdown',stop,true);document.addEventListener('wheel',stop,true);document.addEventListener('keydown',stop,true);
    return()=>{document.removeEventListener('pointerdown',stop,true);document.removeEventListener('wheel',stop,true);document.removeEventListener('keydown',stop,true);};
  },[following]);
  const close=()=>{setOpen(false);setFollowing(null);trigger.current?.focus();};
  useEffect(()=>{
    if(!open)return;
    const dismiss=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();}};
    document.addEventListener('keydown',dismiss,true);return()=>document.removeEventListener('keydown',dismiss,true);
  },[open]);
  const updates=[...(historyHead??feed.data?.updates??[]),...older].filter((update,index,all)=>all.findIndex(u=>u.id===update.id)===index);
  const loadOlder=async()=>{
    const cursor=before??feed.data?.nextBefore;if(cursor==null||loading)return;
    setLoading(true);setError('');
    try {const head=historyHead??feed.data?.updates??[];const page=whiteboardCompanionPage.parse(await api(path+'/v3/companions?before='+cursor));setHistoryHead(head);setOlder(previous=>[...previous,...page.updates]);setBefore(page.nextBefore??0);}
    catch{setError('Could not load earlier updates. Try again.');}finally{setLoading(false);}
  };
  return <div className="wboard-companion" hidden={suspended}>
    <Button variant="quiet" ref={trigger} type="button" className="wboard-companion-trigger wboard-float" aria-expanded={open} aria-controls="wboard-companion-panel"
      onClick={()=>{if(open)close();else {setOpen(true);setTimeout(()=>panel.current?.focus(),0);}}}>
      <BoardIcon name="users"/> Companion{people.length>0&&<span className="wboard-companion-count">{people.length}</span>}
    </Button>
    <section hidden={!open} ref={panel} id="wboard-companion-panel" className="wboard-companion-panel wboard-float" style={{left:placement.position?.x,top:placement.position?.y}} role="region" aria-label="Board companion" tabIndex={-1}
      onKeyDown={event=>{if(event.key==='Escape'){event.stopPropagation();close();}}}>
      <header><button type="button" className="wboard-companion-grip" aria-label="Move chat" title="Drag to move, or use arrow keys" {...placement.handle}>⠿</button><strong>Companion</strong><Button variant="quiet" type="button" onClick={placement.toggle}>{placement.expanded?'Compact':'Expand'}</Button><IconButton type="button" aria-label="Collapse agent updates" onClick={close}><BoardIcon name="close"/></IconButton></header>
      <label className="wboard-companion-placement">Position<select className="ui-control" aria-label="Chat position" value="" onChange={event=>placement.preset(event.target.value as 'bottom-left'|'bottom-right'|'top-left'|'top-right')}><option value="" disabled>Move chat…</option><option value="bottom-left">Bottom left</option><option value="bottom-right">Bottom right</option><option value="top-left">Top left</option><option value="top-right">Top right</option></select></label>
      <ViewSwitch<'chat' | 'updates'> segmented className="wboard-companion-tabs" label="Companion views" value={tab} onChange={setTab} options={[["chat","Chat"],["updates","Updates"]]} />
      <div className="wboard-chat-view" hidden={tab!=='chat'}><WhiteboardChat visible={open&&tab==='chat'} projectId={projectId} reveal={(section,ids)=>{setFollowing(null);if((panel.current?.closest('.ws-whiteboard')?.clientWidth??1000)<720)close();reveal(section,ids);}} openLink={(section,block)=>{setFollowing(null);if((panel.current?.closest('.ws-whiteboard')?.clientWidth??1000)<720)close();openLink(section,block);}} path={path} owner={owner} csrf={csrf} sectionId={sectionId}/></div>
      <div hidden={tab!=='updates'} className="wboard-companion-content">
        {feed.isPending?<p role="status">Loading board activity…</p>:feed.isError?<p role="status">Board activity is unavailable. <Button variant="quiet" type="button" onClick={()=>void feed.refetch()}>Retry</Button></p>:<>
          <ul className="wboard-companion-people" aria-label="Agents on this board">{people.map(person=><li key={identity(person)}>
            <div><strong>{agentName(person.agentId)}</strong><span>{person.activity} · {person.sectionId==='root'?'Whiteboard':person.sectionId}</span></div>
            <Button variant="quiet" type="button" aria-pressed={following===identity(person)} onClick={()=>setFollowing(following===identity(person)?null:identity(person))}>
              {following===identity(person)?'Stop following':'Follow'}</Button>
          </li>)}</ul>
          {!people.length&&<p className="wboard-companion-empty">No recent agent activity. Updates stay here after an agent leaves.</p>}
          {historyHead&&<Button variant="quiet" type="button" onClick={()=>{setHistoryHead(null);setOlder([]);setBefore(null);}}>Latest updates</Button>}
          <ol className="wboard-companion-updates" aria-label="Saved agent updates">{updates.map(update=><li key={update.id}>
            <div className="wboard-companion-byline"><strong>{agentName(update.provenance.invocation.agentId)}</strong><time dateTime={update.at} title={new Date(update.at).toLocaleString()}>{new Date(update.at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</time></div>
            <p>{update.text}</p>
            <div className="wboard-companion-links"><Button variant="quiet" type="button" onClick={()=>{setFollowing(null);openLink(update.sectionId);}}>Open section</Button>
              {update.blockIds.map((id,index)=><Button variant="quiet" type="button" key={id} title={id} onClick={()=>{setFollowing(null);openLink(update.sectionId,id);}}>Item {index+1}</Button>)}</div>
            {update.receiptIds.length>0&&<small>{update.receiptIds.length} linked {update.receiptIds.length===1?'edit':'edits'}</small>}
          </li>)}</ol>
          {!updates.length&&<p className="wboard-companion-empty">Agents can leave linked updates here without starting a chat.</p>}
          {(before!==0&&(before!==null||feed.data?.hasMore))&&<Button variant="quiet" type="button" disabled={loading} onClick={()=>void loadOlder()}>{loading?'Loading…':'Earlier updates'}</Button>}
          {error&&<p role="status">{error}</p>}
        </>}
      </div>
    </section>
  </div>;
}
