import {
  whiteboardSpatialOperation,
  type WhiteboardBlock,
  type WhiteboardStroke,
  type WhiteboardSection,
  type WhiteboardHtml,
  type WhiteboardImage,
  type WhiteboardSpatialOperation,
  type WhiteboardReceipt,
} from '@studio/contracts';

export type EditableBlock =
  WhiteboardBlock | WhiteboardStroke | WhiteboardSection | WhiteboardHtml | WhiteboardImage;
export type Draft = {
  block: EditableBlock;
  base: EditableBlock;
  dirty: boolean;
  sectionId: string;
  blocked?: boolean;
  inFlight?: Record<string, unknown>;
};
export type DraftCommit = (
  operations: WhiteboardSpatialOperation[],
) => Promise<WhiteboardReceipt | undefined>;
const geometry = ['x', 'y', 'width', 'height'] as const;
function fields(block: EditableBlock, shared: boolean): string[] {
  return [
    ...geometry,
    ...(block.kind === 'note' ? ['noteColor'] : []),
    ...(block.kind === 'stroke' ? ['color', 'thickness', 'label'] : ['title']),
    ...((block.kind === 'note' || block.kind === 'document') && !shared ? ['text'] : []),
  ];
}
function value(block: EditableBlock, key: string): unknown {
  return Reflect.get(block, key);
}
export function draftPatch(draft: Draft, shared: boolean) {
  return Object.fromEntries(
    fields(draft.block, shared)
      .filter((key) => value(draft.block, key) !== value(draft.base, key))
      .map((key) => [key, value(draft.block, key)]),
  );
}
export function editDraft<T extends EditableBlock>(
  drafts: Map<string, Draft>,
  saved: T,
  values: Partial<T>,
  sectionId: string,
  shared: boolean,
) {
  const previous = drafts.get(saved.id),
    base = previous?.dirty ? previous.base : saved;
  const next: Draft = {
    base,
    block: { ...(previous?.dirty ? previous.block : saved), ...values } as T,
    dirty: true,
    sectionId,
    blocked: previous?.dirty && previous.blocked,
    inFlight: previous?.inFlight,
  };
  next.dirty = !!next.inFlight || Object.keys(draftPatch(next, shared)).length > 0;
  drafts.set(saved.id, next);
}
export function rebaseDraft(draft: Draft, base: EditableBlock, shared: boolean): Draft {
  const patch = draftPatch(draft, shared);
  for (const key of Object.keys(draft.inFlight ?? {})) patch[key] = value(draft.block, key);
  const next = {
    ...draft,
    base,
    block: { ...base, ...patch },
    blocked: false,
    inFlight: undefined,
  };
  next.dirty = Object.keys(draftPatch(next, shared)).length > 0;
  return next;
}
export function draftOperation(draft: Draft, shared: boolean) {
  const block = draft.block;
  const minimum = block.kind === 'stroke' ? 1 : block.kind === 'image' ? 16 : 160;
  if (
    !Number.isFinite(block.width) ||
    !Number.isFinite(block.height) ||
    block.width < minimum ||
    block.height < minimum
  )
    return undefined;
  const result = whiteboardSpatialOperation.safeParse({
    type:
      block.kind === 'stroke'
        ? 'updateStroke'
        : block.kind === 'note' || block.kind === 'document'
          ? 'update'
          : 'updateTile',
    id: block.id,
    expectedRevision: draft.base.revision,
    patch: draftPatch(draft, shared),
  });
  return result.success ? result.data : undefined;
}
/** Receipts reconcile only the fields sent, including after a lost response. */
export function settleDrafts(
  operations: WhiteboardSpatialOperation[],
  receipt: WhiteboardReceipt,
  drafts: Map<string, Draft>,
  shared: boolean,
) {
  if (receipt.status !== 'applied') return;
  for (const op of operations) {
    if (op.type !== 'update' && op.type !== 'updateTile' && op.type !== 'updateStroke') continue;
    const draft = drafts.get(op.id);
    if (!draft || (!draft.dirty && !draft.inFlight)) continue;
    const patch = draftPatch(draft, shared);
    // A submitted field is settled only if it still matches the current input.
    for (const [key, sent] of Object.entries(op.patch)) {
      if (patch[key] === sent) delete patch[key];
      else if (
        draft.inFlight &&
        Object.hasOwn(draft.inFlight, key) &&
        value(draft.block, key) !== sent
      )
        patch[key] = value(draft.block, key);
    }
    const base = { ...draft.base, ...op.patch, revision: receipt.revision } as EditableBlock;
    drafts.set(op.id, {
      ...draft,
      base,
      block: { ...base, ...patch },
      dirty: Object.keys(patch).length > 0,
      blocked: false,
      inFlight: undefined,
    });
  }
}
export async function saveDraft(
  id: string,
  drafts: Map<string, Draft>,
  shared: boolean,
  commit: DraftCommit,
  changed: () => void,
) {
  const draft = drafts.get(id);
  if (!draft?.dirty || draft.blocked) return;
  const operation = draftOperation(draft, shared);
  if (!operation) return;
  drafts.set(id, { ...draft, inFlight: draftPatch(draft, shared) });
  const receipt = await commit([operation]);
  if (receipt?.status === 'applied') settleDrafts([operation], receipt, drafts, shared);
  else {
    const latest = drafts.get(id);
    if (latest) drafts.set(id, { ...latest, blocked: true });
  }
  changed();
}
