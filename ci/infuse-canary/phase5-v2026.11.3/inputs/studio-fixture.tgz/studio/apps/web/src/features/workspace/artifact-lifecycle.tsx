import { Button } from './ui.js';
import {useEffect,useRef,useState} from 'react';
import {useQuery,useInfiniteQuery,useQueryClient} from '@tanstack/react-query';
import {artifactLifecycleConfirmation,parseArtifactLifecycleCommand,parseArtifactLifecycleReceipt,parseArtifactLifecycleState,type ArtifactLifecycleCommand,type ArtifactLifecycleReceipt} from '@studio/contracts';
import {api,getSession,projectPath,readableError} from './api.js';
import {useWorkspace} from './context.js';
import './artifact-lifecycle.css';
const base='/api/studio/artifact-lifecycle';
export function useArtifactLifecycleController(onReceipt?:(receipt:ArtifactLifecycleReceipt)=>void){
 const {owner,session,current}=useWorkspace(),queries=useQueryClient(),key='infuse-studio:artifact-lifecycle:'+owner;
 const [saved]=useState(()=>{try{const raw=sessionStorage.getItem(key);return {command:raw?parseArtifactLifecycleCommand(JSON.parse(raw)):undefined,error:''};}catch{return {command:undefined,error:'Saved artifact command could not be read. Check its Registry audit before starting another action.'};}});
 const [pending,setPending]=useState<ArtifactLifecycleCommand|undefined>(saved.command),[busy,setBusy]=useState(false),[error,setError]=useState(saved.error),[notice,setNotice]=useState('');
 const mounted=useRef(true),locked=useRef(false),pendingRef=useRef(pending);useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
 const refresh=()=>{void queries.invalidateQueries({queryKey:['workspace',owner,'artifacts']});void queries.invalidateQueries({queryKey:['workspace',owner,'artifact']});void queries.invalidateQueries({queryKey:['workspace',owner,'artifact-lifecycle']});};
 async function execute(command:ArtifactLifecycleCommand){
  if(!current||locked.current||!navigator.onLine)return;
  try{sessionStorage.setItem(key,JSON.stringify(command));}catch{setError('Browser recovery storage is unavailable. No artifact command was sent.');return;}
  pendingRef.current=command;setPending(command);locked.current=true;setBusy(true);setError('');setNotice('');
  try{
   const fresh=await getSession(undefined,()=>mounted.current,session.project.id);if(!mounted.current)return;
   if(!fresh.authenticated||fresh.profileId!==session.profileId||fresh.bootstrap.authorityId!==session.bootstrap.authorityId||fresh.project.id!==session.project.id)throw Error('Reconnect as the original identity and floor to recover this artifact command.');
   const receipt=parseArtifactLifecycleReceipt(await api(projectPath(base+'/commands',session.project.id),{command,csrf:fresh.csrfToken,isCurrent:()=>mounted.current}));
   if(receipt.commandId!==command.commandId||receipt.producer!==command.producer||receipt.artifactId!==command.artifactId||receipt.project!==session.project.id||receipt.revision!==command.revision||receipt.generation!==command.generation+1||receipt.action!==command.action)throw Error('The Registry receipt does not match the exact reviewed command.');
   if(!mounted.current)return;sessionStorage.removeItem(key);pendingRef.current=undefined;setPending(undefined);setNotice(receipt.action==='trash' && onReceipt ? '' : `Artifact ${receipt.state==='bin'?'moved to bin':receipt.state==='active'?'restored':'permanently purged'}. Exact receipt recorded.`);refresh();onReceipt?.(receipt);return receipt;
  }catch(error){if(mounted.current)setError(readableError(error));}finally{locked.current=false;if(mounted.current)setBusy(false);}
 }
 return {pending,busy,error,notice,blocked:!!saved.error,refresh,send:(command:ArtifactLifecycleCommand)=>!pendingRef.current&&!saved.error?execute(parseArtifactLifecycleCommand(command)):Promise.resolve(),recover:()=>pendingRef.current?execute(pendingRef.current):Promise.resolve()};
}
export function ArtifactLifecycleRecovery({controller:c}:{controller:ReturnType<typeof useArtifactLifecycleController>}){
 const {current}=useWorkspace();return <div className="ws-artifact-lifecycle-recovery">{c.notice&&<p role="status">{c.notice}</p>}{c.error&&<p className="ws-alert" role="alert">{c.error}</p>}{c.pending&&<div className="ws-record"><p>An exact {c.pending.action} command for <code>{c.pending.producer}/{c.pending.artifactId}</code> is awaiting a verified receipt. Its outcome may already be recorded.</p><code>{c.pending.commandId}</code><Button variant="quiet" disabled={!current||c.busy} onClick={()=>void c.recover()}>{c.busy?'Checking exact receipt…':'Recover exact artifact receipt'}</Button></div>}</div>;
}
function useArtifactLifecycleState(producer:string,artifactId:string,enabled:boolean){
 const {owner,session,current,visible}=useWorkspace();
 const path=projectPath(`${base}/${encodeURIComponent(producer)}/${encodeURIComponent(artifactId)}`,session.project.id);
 return useQuery({queryKey:['workspace',owner,'artifact-lifecycle',producer,artifactId],enabled:current&&enabled,queryFn:async({signal})=>{const raw=await api(path,{signal}) as {state:unknown;canPurge:boolean};const state=parseArtifactLifecycleState(raw.state);if(state.project!==session.project.id||state.producer!==producer||state.artifactId!==artifactId||typeof raw.canPurge!=='boolean')throw Error('Artifact state identity mismatch');return {state,canPurge:raw.canPurge};},gcTime:0,refetchOnWindowFocus:visible,retry:false});
}
export function ArtifactLifecyclePanel({producer,artifactId,revision,controller:c}:{producer:string;artifactId:string;revision:string;controller:ReturnType<typeof useArtifactLifecycleController>}){
 const {owner,session,current,visible}=useWorkspace(),[open,setOpen]=useState(false),[action,setAction]=useState<'trash'|'restore'|'purge'>('trash'),[confirmation,setConfirmation]=useState(''),[auditOpen,setAuditOpen]=useState(false);
 const path=projectPath(`${base}/${encodeURIComponent(producer)}/${encodeURIComponent(artifactId)}`,session.project.id);
 const query=useArtifactLifecycleState(producer,artifactId,open);
 const data=current&&!query.isError?query.data:undefined,state=data?.state;
 const options:('trash'|'restore'|'purge')[]=state?.state==='active'?['trash']:state?.state==='bin'?['restore',...(data?.canPurge?['purge' as const]:[])]:[];
 const selected=options.includes(action)?action:options[0];
 const expected=state&&selected?artifactLifecycleConfirmation({...state,action:selected}):'';
 const audit=useInfiniteQuery({queryKey:['workspace',owner,'artifact-lifecycle',producer,artifactId,'audit'],enabled:current&&open&&auditOpen&&data?.canPurge===true,initialPageParam:undefined as string|undefined,queryFn:async({signal,pageParam})=>{
  const raw=await api(path+'/audit'+(pageParam?'?'+new URLSearchParams({before:pageParam}):''),{signal}) as {receipts:unknown[];nextCursor:string|null};
  if(!Array.isArray(raw.receipts)||raw.receipts.length>50||raw.nextCursor!==null&&(typeof raw.nextCursor!=='string'||!/^[a-f0-9]{64}$/.test(raw.nextCursor)||pageParam!==undefined&&raw.nextCursor>=pageParam))throw Error('Invalid audit response');
  const receipts=raw.receipts.map(parseArtifactLifecycleReceipt);if(receipts.some(r=>r.project!==session.project.id||r.producer!==producer||r.artifactId!==artifactId))throw Error('Artifact audit identity mismatch');return {receipts,nextCursor:raw.nextCursor};
 },getNextPageParam:page=>page.nextCursor??undefined,gcTime:0,retry:false,refetchOnWindowFocus:visible});
 async function submit(){if(!state||!selected||selected==='purge'&&confirmation!==expected||state.revision!==revision||state.pending)return;await c.send(parseArtifactLifecycleCommand({commandId:crypto.randomUUID(),producer,artifactId,revision:state.revision,generation:state.generation,action:selected,confirmation:selected==='purge'?confirmation:expected}));setConfirmation('');}
 return <details className="ws-record ws-artifact-lifecycle" onToggle={e=>setOpen(e.currentTarget.open)}><summary>Manage artifact</summary>{open&&<div>{query.isPending?<p>Loading exact artifact state…</p>:!data?<p className="ws-alert" role="alert">{query.error?readableError(query.error):'Reconnect to inspect artifact state.'}</p>:<>
  <p><strong>{state!.state==='active'?'In your library':state!.state==='bin'?'In the bin':'Permanently deleted'}</strong>. Moving to the bin keeps all versions available to restore. Permanent deletion removes every version.</p>
  {state!.pending&&<p className="ws-alert">A Registry command requires reconciliation. Recover its exact receipt before another action.</p>}
  {state!.revision!==revision&&<p className="ws-alert">This view is an older content revision. Open the current artifact before changing its lifecycle.</p>}
  {!!options.length&&<><label>Artifact action<select className="ui-control" aria-label="Artifact action" value={selected} onChange={e=>{setAction(e.target.value as typeof action);setConfirmation('');}}>{options.map(o=><option key={o} value={o}>{o==='trash'?'Move to bin':o==='restore'?'Restore artifact':'Delete permanently'}</option>)}</select></label>{selected==='purge'&&<><p>Type this exact confirmation:</p><code className="ws-artifact-confirmation">{expected}</code><label>Exact artifact confirmation<input className="ui-control" aria-label="Exact artifact confirmation" value={confirmation} onChange={e=>setConfirmation(e.target.value)} autoComplete="off" /></label></>}<Button variant={selected==='purge'?'danger':'primary'} disabled={!current||c.busy||!!c.pending||c.blocked||state!.pending||state!.revision!==revision||selected==='purge'&&confirmation!==expected} onClick={()=>void submit()}>{c.busy?'Saving…':selected==='trash'?'Move to bin':selected==='restore'?'Restore artifact':'Delete permanently'}</Button></>}
  {data.canPurge&&<><Button variant="quiet" onClick={()=>setAuditOpen(!auditOpen)}>{auditOpen?'Hide artifact audit':'Inspect artifact audit'}</Button>{auditOpen&&(audit.isError?<p className="ws-alert" role="alert">Audit is unavailable. Previous records are hidden.</p>:audit.isPending?<p>Loading artifact audit…</p>:<div className="ws-artifact-audit"><p>Content-free durable lifecycle receipts{audit.hasNextPage?' · more records remain':''}.</p>{audit.data?.pages.flatMap(p=>p.receipts).map(r=><p key={r.commandId}><time>{r.occurredAt}</time> · {r.action} → {r.state} · generation {r.generation}<br/><code>{r.commandId}</code></p>)}{audit.hasNextPage&&<Button variant="quiet" disabled={audit.isFetchingNextPage} onClick={()=>void audit.fetchNextPage()}>Load more artifact audit</Button>}</div>)}</>}
 </>}<Button variant="quiet" disabled={query.isFetching} onClick={()=>void query.refetch()}>Refresh artifact state</Button></div>}</details>;
}

/** Header deletion uses the same exact state, command and receipt recovery as the bin. */
export function ArtifactDeleteForm({producer,artifactId,revision,title,controller:c,onCancel}:{
 producer:string;artifactId:string;revision:string;title:string;controller:ReturnType<typeof useArtifactLifecycleController>;
 onCancel():void;
}){
 const {current}=useWorkspace(),query=useArtifactLifecycleState(producer,artifactId,true);
 const state=current&&!query.isError?query.data?.state:undefined;
 const available=!!state&&state.state==='active'&&state.revision===revision&&!state.pending;
 const canSubmit=available&&current&&!query.isFetching&&!c.busy&&!c.pending&&!c.blocked;
 async function submit(){
  if(!canSubmit||!state)return;
  await c.send(parseArtifactLifecycleCommand({commandId:crypto.randomUUID(),producer,artifactId,revision:state.revision,generation:state.generation,action:'trash',confirmation:artifactLifecycleConfirmation({...state,action:'trash'})}));
 }
 return <form className="ws-artifact-delete-form" onSubmit={event=>{event.preventDefault();void submit();}}>
  <p><strong>{title}</strong> will move to the artifact bin. You can restore it and all its versions later.</p>
  <ArtifactLifecycleRecovery controller={c}/>
  {query.isPending&&current?<p role="status">Loading artifact…</p>:!state?<p className="ws-alert" role="alert">{query.error?readableError(query.error):'Reconnect to delete this artifact.'}</p>:<>
   {state.state!=='active'?<p role="status">{state.state==='bin'?'This artifact is already in the bin.':'This artifact has been permanently deleted.'}</p>
    :state.revision!==revision?<p role="alert">This is an older version. Open the current artifact before deleting it.</p>
    :state.pending?<p role="alert">Recover the pending artifact receipt before starting another action.</p>
    :null}
  </>}
  {query.isError&&<Button variant="quiet" disabled={query.isFetching} onClick={()=>void query.refetch()}>Try again</Button>}
  <div className="ws-artifact-delete-actions"><Button variant="quiet" onClick={onCancel}>Cancel</Button><Button variant="danger" type="submit" disabled={!canSubmit}>{c.busy?'Deleting…':'Delete artifact'}</Button></div>
 </form>;
}
