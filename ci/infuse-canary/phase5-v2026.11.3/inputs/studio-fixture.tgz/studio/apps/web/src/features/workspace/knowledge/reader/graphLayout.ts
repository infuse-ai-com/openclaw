import type { GraphNode } from '@studio/contracts/knowledge';
import type { SimulationLinkDatum, SimulationNodeDatum } from 'd3-force';

export interface PositionedNode extends GraphNode, SimulationNodeDatum {
  x: number;
  y: number;
  radius: number;
  color: string;
}

export interface PositionedLink extends SimulationLinkDatum<PositionedNode> {
  id: string;
}

export interface GraphTransform {
  x: number;
  y: number;
  scale: number;
}

const colors = [
  '#7067f0',
  '#12a594',
  '#d95f8d',
  '#d98618',
  '#3182ce',
  '#8b5fc7',
  '#df6651',
  '#43a047',
];

export function clusterColor(index: number): string {
  return colors[index % colors.length] ?? '#7067f0';
}

export function clamp(value: number, minimum: number, maximum: number): number {
  return Math.min(maximum, Math.max(minimum, value));
}

export function graphFitTransform(
  nodes: readonly PositionedNode[],
  viewport: { height: number; width: number },
): GraphTransform | undefined {
  if (nodes.length === 0) return undefined;
  const left = Math.min(...nodes.map((node) => node.x - node.radius));
  const right = Math.max(...nodes.map((node) => node.x + node.radius));
  const top = Math.min(...nodes.map((node) => node.y - node.radius));
  const bottom = Math.max(...nodes.map((node) => node.y + node.radius));
  const scale = clamp(
    Math.min(
      (viewport.width - 156) / Math.max(1, right - left),
      (viewport.height - 156) / Math.max(1, bottom - top),
    ),
    0.24,
    1.35,
  );
  return {
    x: viewport.width / 2 - ((left + right) / 2) * scale,
    y: viewport.height / 2 - ((top + bottom) / 2) * scale,
    scale,
  };
}

export interface GraphEntryOrigin {
  x: number;
  y: number;
}
