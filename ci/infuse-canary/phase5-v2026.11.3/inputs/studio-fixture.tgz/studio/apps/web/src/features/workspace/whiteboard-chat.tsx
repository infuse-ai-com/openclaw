import { Button } from './ui.js';
import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {companionChatPage,companionStart,type CompanionTurn} from '@studio/contracts';
import {api,ApiError,accessDenied} from './api.js';
import { activeCompanionTurn as active, companionProgress, companionElapsed } from './whiteboard-chat-progress.js';
import { WhiteboardChatChanges } from './whiteboard-chat-changes.js';
import { WhiteboardChatReply } from './whiteboard-chat-reply.js';
import {chooseCompanion, companionKey} from './whiteboard-chat-state.js';
type Start=ReturnType<typeof companionStart.parse>;
const name=(id:string)=>id.replace(/[-_]/g,' ').replace(/^./,c=>c.toUpperCase());
const status=(turn:CompanionTurn)=>companionProgress(turn).label;
export function WhiteboardChat({path,owner,csrf,sectionId,visible,projectId,openLink,reveal}:{path:string;owner:string;csrf:string;sectionId:string;visible:boolean;projectId:string;openLink(section:string,block?:string):void;reveal(section:string,ids:string[]):void}) {
  const key='studio-board-chat:'+owner;
  const [draft,setDraft]=useState(()=>{try{return sessionStorage.getItem(key+':draft')??'';}catch{return '';}});
  const [pending,setPending]=useState<Start|null>(()=>{try{return companionStart.parse(JSON.parse(sessionStorage.getItem(key+':pending')??'null'));}catch{return null;}});
  const [target,setTarget]=useState(()=>{if(pending)return JSON.stringify([pending.gatewayId,pending.agentId]);try{return sessionStorage.getItem(key+':target')??'';}catch{return '';}}),[sending,setSending]=useState(false),[stopping,setStopping]=useState(false),[error,setError]=useState('');
  const list=useRef<HTMLOListElement>(null),mounted=useRef(true),followTail=useRef(true),listHeight=useRef(0);
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
  const feed=useQuery({queryKey:['workspace',owner,'whiteboard-chat'],queryFn:async({signal})=>companionChatPage.parse(await api(path+'/v3/chat',{signal})),refetchInterval:1500,retry:false});
  const agents=feed.data?.agents??[],selected=chooseCompanion(agents,target,feed.data?.turns??[]);
  // Freeze the displayed choice: a later availability poll must not retarget a draft.
  useEffect(()=>{if(!target&&selected){const value=companionKey(selected);setTarget(value);try{sessionStorage.setItem(key+':target',value);}catch{/* Retain the choice in memory. */}}},[target,selected?.gatewayId,selected?.agentId]);
  const chosen=selected?companionKey(selected):target;
  const turns=[...(feed.data?.turns??[])].reverse().filter(t=>chosen&&companionKey(t)===chosen);
  const current=turns.findLast(active);
  const [now,setNow]=useState(Date.now);
  useEffect(()=>{if(!visible||!current)return;setNow(Date.now());const timer=setInterval(()=>setNow(Date.now()),5000);return()=>clearInterval(timer);},[visible,current?.id]);
  const progress=current?companionProgress(current,Math.max(now,feed.dataUpdatedAt)):null;
  const clearPending=()=>{setPending(null);setDraft('');setError('');try{sessionStorage.removeItem(key+':pending');sessionStorage.removeItem(key+':draft');}catch{/* State remains safe in this tab. */}};
  useEffect(()=>{if(pending&&feed.data?.turns.some(t=>t.commandId===pending.commandId))clearPending();},[feed.dataUpdatedAt,pending]);
  useLayoutEffect(()=>{
    const el=list.current;if(!el||!visible)return;
    followTail.current=true;
    // A responsive resize is not a request to stop following the conversation.
    const revealLatest=()=>{listHeight.current=el.clientHeight;if(followTail.current)el.scrollTop=el.scrollHeight;};
    revealLatest();const observer=new ResizeObserver(revealLatest);observer.observe(el);
    return()=>observer.disconnect();
  },[visible,selected?.gatewayId,selected?.agentId]);
  useEffect(()=>{const el=list.current;if(el&&visible&&followTail.current)el.scrollTop=el.scrollHeight;},[turns.length,current?.state,visible]);
  const start=async()=>{
    if(sending||!selected||!draft.trim()&&!pending)return;
    const parsed=companionStart.safeParse(pending??{commandId:crypto.randomUUID(),gatewayId:selected.gatewayId,agentId:selected.agentId,sectionId,text:draft});
    if(!parsed.success){setError('Write a message of up to 4,000 characters.');return;}const command=parsed.data;
    try{sessionStorage.setItem(key+':pending',JSON.stringify(command));}catch{setError('This tab cannot save a recovery receipt. Enable site storage before starting.');return;}
    setPending(command);setSending(true);setError('');
    try{sessionStorage.setItem(key+':target',companionKey(command));}catch{/* Pending custody already retains the exact target. */}
    try{await api(path+'/v3/chat/start',{command,csrf});if(mounted.current)await feed.refetch();}
    catch(e){if(mounted.current){
      if(!pending&&e instanceof ApiError&&['AGENT_OCCUPIED','AGENT_OFFLINE','FORBIDDEN','NOT_FOUND','AUTHORITY_REVOKED','INVALID_INPUT'].includes(e.code)){setPending(null);sessionStorage.removeItem(key+':pending');setError(e.message);}
      else setError('Checking whether Start arrived. Retry uses the same request.');
      void feed.refetch();
    }}finally{if(mounted.current)setSending(false);}
  };
  const stop=async()=>{if(!current||stopping)return;setStopping(true);setError('');try{await api(path+'/v3/chat/stop',{command:{turnId:current.id},csrf});await feed.refetch();}
    catch{setError('Could not confirm Stop. Reconnect and try Stop again.');}finally{if(mounted.current)setStopping(false);}};
  if(accessDenied(feed.error))return <p role="status">Your access to this board changed. Refresh Studio.</p>;
  return <div className="wboard-chat">
    <div className="wboard-chat-agent"><label>Agent<select className="ui-control" aria-label="Companion agent" disabled={!!pending||sending} value={selected?JSON.stringify([selected.gatewayId,selected.agentId]):''} onChange={e=>{setTarget(e.target.value);try{sessionStorage.setItem(key+':target',e.target.value);}catch{/* Keep the selection in this tab. */}}}>
      {!selected&&<option value="">{target?'Choose another agent':agents.length?'No agents available':'No connected agents'}</option>}{agents.map(a=><option key={JSON.stringify(a)} value={JSON.stringify([a.gatewayId,a.agentId])}>{name(a.agentId)} · {a.availability}</option>)}
    </select></label><span role="status">{feed.isError?'Connection lost. Reconnecting…':current?progress!.label:!selected?(target?'This agent is no longer connected. Choose another for new work.':agents.length?'All agents are busy or offline. Choose one or wait.':'No agents are connected to this board.'):selected.availability==='occupied'?'Busy elsewhere':selected.availability==='offline'?'Agent offline':feed.data?.enabled?'Ready when you are':'Chat is not enabled here yet'}</span>{current&&<div className="wboard-chat-progress"><p role="status">{feed.isError?'Your request may still be running. Reconnecting will check it without starting again.':progress!.detail}</p><small aria-live="off">{companionElapsed(current,now)}</small></div>}</div>
    <ol ref={list} onScroll={()=>{const el=list.current;if(el&&visible&&el.clientHeight>0&&el.clientHeight===listHeight.current)followTail.current=el.scrollHeight-el.scrollTop-el.clientHeight<24;}} className="wboard-chat-messages" aria-label="Board conversation">
      {!turns.length&&<li className="wboard-companion-empty">Ask for a review, add ideas, or work together here. Sharing your view is optional.</li>}
      {turns.map(t=><li key={t.id}><div className="wboard-chat-human"><strong>{name(t.authorId)}</strong><p>{t.text}</p></div>
        {t.reply&&<div className="wboard-chat-reply"><strong>{name(t.agentId)}</strong><WhiteboardChatReply text={t.reply} projectId={projectId} openLink={openLink}/>{t.replyTruncated&&<small>Reply shortened for this chat.</small>}</div>}
        {!active(t)&&<small>{status(t)}</small>}{!active(t)&&t.changes&&<WhiteboardChatChanges changes={t.changes} reveal={reveal}/>}</li>)}
    </ol>
    <form className="wboard-chat-compose" onSubmit={e=>{e.preventDefault();void start();}}>
      <label className="sr-only" htmlFor="wboard-chat-message">Message your companion</label>
      <textarea className="ui-control" id="wboard-chat-message" aria-label="Message your companion" placeholder="Think together on this board…" rows={2} maxLength={4000} value={draft} disabled={!!pending}
        onChange={e=>{setDraft(e.target.value);try{sessionStorage.setItem(key+':draft',e.target.value);}catch{/* Start separately requires recovery storage. */}}}/>
      <div><span>Shared with people on this board</span>{current&&<Button variant="quiet" type="button" disabled={stopping||feed.isError} onClick={()=>void stop()}>{stopping?'Stopping…':'Stop'}</Button>}
        <Button variant="quiet" type="submit" disabled={sending||feed.isError||!feed.data?.enabled||!selected||(!pending&&(selected.availability!=='available'||!draft.trim()))}>{sending?'Starting…':pending?'Retry Start':'Start'}</Button></div>
      {error&&<p role="alert">{error}</p>}
    </form>
  </div>;
}
