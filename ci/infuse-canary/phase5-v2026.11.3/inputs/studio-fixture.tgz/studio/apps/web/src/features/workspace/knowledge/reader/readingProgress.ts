import type { Document } from '@studio/contracts/knowledge';
import { useEffect, useState, type RefObject } from 'react';

export interface ReadingProgress {
  path: string;
  repository: string;
  scrollTop: number;
  title: string;
  updatedAt: string;
}

export function readReadingProgress(
  storageKey = 'studio.knowledge.progress',
): ReadingProgress | undefined {
  try {
    const raw = globalThis.localStorage.getItem(storageKey);
    if (!raw) return;
    const value = JSON.parse(raw) as Partial<ReadingProgress>;
    if (
      typeof value.repository !== 'string' ||
      typeof value.path !== 'string' ||
      typeof value.title !== 'string' ||
      typeof value.scrollTop !== 'number' ||
      !Number.isFinite(value.scrollTop) ||
      typeof value.updatedAt !== 'string'
    ) {
      return;
    }
    return {
      repository: value.repository,
      path: value.path,
      title: value.title,
      scrollTop: Math.max(0, value.scrollTop),
      updatedAt: value.updatedAt,
    };
  } catch {
    return;
  }
}

export function writeReadingProgress(
  document: Document,
  scrollTop: number,
  storageKey = 'studio.knowledge.progress',
): ReadingProgress {
  const progress = {
    repository: document.repository,
    path: document.path,
    title: document.title,
    scrollTop: Math.max(0, scrollTop),
    updatedAt: new Date().toISOString(),
  } satisfies ReadingProgress;
  try {
    globalThis.localStorage.setItem(storageKey, JSON.stringify(progress));
  } catch {
    /* Reading remains available without persistent preferences. */
  }
  return progress;
}

export function useReadingProgress(
  document: Document | undefined,
  readerRef: RefObject<HTMLElement | null>,
  storageKey = 'studio.knowledge.progress',
  surface: 'document' | 'zoom' | 'map' = 'document',
): ReadingProgress | undefined {
  const [progress, setProgress] = useState<ReadingProgress | undefined>(() =>
    readReadingProgress(storageKey),
  );

  useEffect(() => {
    if (!document || surface === 'map') return;
    const existing = readReadingProgress(storageKey);
    setProgress(
      writeReadingProgress(
        document,
        existing?.repository === document.repository &&
          existing.path === document.path
          ? existing.scrollTop
          : 0,
        storageKey,
      ),
    );

    const reader =
      surface === 'zoom'
        ? readerRef.current?.querySelector<HTMLElement>(
            '.semantic-reader-portal',
          )
        : readerRef.current;
    if (!reader) return;
    let frame = 0;
    const persist = () => {
      globalThis.cancelAnimationFrame(frame);
      frame = globalThis.requestAnimationFrame(() => {
        const useWindowScroll =
          globalThis.getComputedStyle(reader).overflowY === 'visible';
        setProgress(
          writeReadingProgress(
            document,
            useWindowScroll ? globalThis.scrollY : reader.scrollTop,
            storageKey,
          ),
        );
      });
    };
    reader.addEventListener('scroll', persist, { passive: true });
    globalThis.addEventListener('scroll', persist, { passive: true });
    return () => {
      globalThis.cancelAnimationFrame(frame);
      reader.removeEventListener('scroll', persist);
      globalThis.removeEventListener('scroll', persist);
    };
  }, [document, readerRef, storageKey, surface]);

  return progress;
}
