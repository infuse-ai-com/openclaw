import { PageHeader, Button, ViewSwitch, EmptyState } from './ui.js';
import { LoadingState } from './loading.js';
import { useState } from 'react';
import { Link } from './navigation.js';
import { useWorkspace } from './context.js';
import { deskItems, type CompanyWork } from './company-work.js';
import { ShellIcon } from './shell.js';
import './company.css';

export function Coverage({ work }: { work: CompanyWork }) {
  const refreshed = work.projects.filter(p => p.data && !p.stale).length;
  const incomplete = work.loading || !work.current || work.omitted > 0 || work.projects.some(p => p.error || p.stale || p.data?.coverage.length);
  return <section className="ws-company-coverage" aria-label="Project coverage"><details open={incomplete}><summary>{refreshed} of {work.admitted} admitted projects refreshed.{!work.current ? ' · last known state' : ''}<span>{incomplete ? 'Incomplete coverage · inspect' : 'Inspect project coverage'}</span></summary><p>Work and availability cover inspected records.</p>{work.omitted > 0 && <p>{work.omitted} further admitted projects are outside this bounded view.</p>}{work.projects.map(({ project, data, loading, error, stale }) => <div key={project.id}><strong>{project.name}</strong><span>{loading ? <LoadingState label="Loading…" size="inline" /> : error || (stale ? 'Last known state' : 'Refreshed')}</span>{data?.coverage.map(note => <p key={note}>{note}</p>)}</div>)}</details></section>;
}
function CompanyHeader({ title, description, work }: { title: string; description: string; work: CompanyWork }) {
  return <PageHeader eyebrow="COMPANY / ALL ADMITTED PROJECTS" title={title} description={description} actions={<Button variant="quiet" disabled={!work.current || work.refreshing} onClick={work.refresh}>{work.refreshing ? 'Refreshing…' : 'Refresh'}</Button>} />;
}
export function DecisionInbox({ work }: { work: CompanyWork }) {
  const { session } = useWorkspace(); const [view, setView] = useState<'needs' | 'active'>('needs');
  const needs = deskItems(work), active = deskItems(work, 'active'), items = view === 'needs' ? needs : active;
  const initialLoading = work.current && work.loading && !needs.length && !active.length;
  return <section className="ws-surface ws-company-surface" aria-label="Decision inbox"><CompanyHeader title="Decision inbox" description={`${session.displayName || session.profileId}, see the next decision and return to the work.`} work={work} />{initialLoading ? <LoadingState label="Loading your desk…" size="panel" /> : <><Coverage work={work} />
    <div className="ws-desk-inbox"><header><div><span className="ws-eyebrow">YOUR WORK IN VIEW</span><h2>{`${needs.length} ${needs.length === 1 ? 'item needs' : 'items need'} you.`}</h2></div><p>Decisions and work to continue across your admitted projects. Coverage above explains incomplete reads.</p></header>
      <ViewSwitch<'needs' | 'active'> label="Desk views" value={view} onChange={setView} options={[
        ['needs', <>Needs you <span>{needs.length}</span></>], ['active', <>Open work <span>{active.length}</span></>],
      ]} />
      <div className="ws-desk-items">{items.map(({ item, project, stale, approver }) => <Link className="ui-card ws-desk-item" key={`${project.id}:${item.path}`} to={`${item.path}?${new URLSearchParams({ project: project.id, ...(!approver ? { section: 'conversations' } : {}) })}`}><header><span>{project.name}</span><span>{stale ? 'Last known · ' : ''}{item.label}</span></header><h2>{item.title}</h2><p>{approver ? item.next : 'Read progress and join the mission conversation.'}</p><footer>Inspect the originating mission ↗</footer></Link>)}
        {!items.length && !work.loading && <EmptyState className="ws-desk-empty" level={2} title={<>{view === 'needs' ? 'No actionable work in the inspected records.' : 'No open work in the inspected records.'}</>}  icon={<ShellIcon name="desk" />} actions={<><Link className="ws-button ws-button--quiet" to={'/grilling'}>{'Start grilling →'}</Link></>}>Shape your next mission, or inspect the recorded work in Missions. Project coverage above explains any gaps.</EmptyState>}{work.loading && <LoadingState label="Loading remaining projects…" size="inline" />}
      </div>
    </div></>}
  </section>;
}

export { Agents } from './agents.js';
