import { Button, EmptyState } from './ui.js';
import { LoadingState } from './loading.js';
import { useEffect, useRef, useState } from 'react';
import { useParams, useSearchParams } from 'react-router';
import { Link, useNavigate } from './navigation.js';
import { useQuery } from '@tanstack/react-query';
import { parseMissionView, parseMissionCapabilities, type Mission, type MissionCommand, type MissionPaper, type MissionView } from '@studio/contracts';
import { closeoutPolicyLabel, dateLabel, dispatchLabel, missionLabel, nextDecision, targetKey, targetLabel, terminal } from '../studio/presentation.js';
import { useWorkspace } from './context.js';
import { api, accessDenied, readableError } from './api.js';
import { Icon } from './app.js';
import { ArtifactReview } from './review.js';
import { Conversations } from './conversations.js';

export function Paper({ paper }: { paper: MissionPaper }) {
  return <article className="ws-paper"><div className="ws-paper-mark"><span>INFUSE / STUDIO</span><span>MISSION PAPER</span></div><h2>{paper.title}</h2>
    <section><span className="ws-eyebrow">01 / THE OUTCOME</span><h3>What we want to achieve</h3><p className="ws-literal">{paper.objective}</p></section>
    <section><span className="ws-eyebrow">02 / THE EVIDENCE</span><h3>What success looks like</h3><p className="ws-literal">{paper.acceptance}</p></section>
    <section><span className="ws-eyebrow">03 / THE PEOPLE</span><h3>Accountable for the work</h3><div className="ws-paper-team">{(['coordinator', 'specialist'] as const).map(role => <div key={role}><span className={`ws-avatar ws-avatar--${role}`}>{role === 'coordinator' ? 'C' : 'S'}</span><div><strong>{paper[role].agentId}</strong><span>{role} · {paper[role].gatewayId}</span></div></div>)}</div></section>
    <section><span className="ws-eyebrow">04 / CLOSING THE WORK</span><h3>How the outcome is recorded</h3><p>{closeoutPolicyLabel(paper)}</p></section>
    {paper.capabilities && <section><span className="ws-eyebrow">05 / PERMISSIONS</span><h3>Approved source access</h3><p>The team can manage its assignment and evidence, and read the exact source revisions listed here. This paper grants no shell, network or workspace write access.</p>{(['coordinator', 'specialist'] as const).map(role => <div key={role}><h4>{role === 'coordinator' ? 'Coordinator' : 'Specialist'}</h4>{paper.capabilities![role].sources.length ? <dl>{paper.capabilities![role].sources.map(source => <div key={source.path}><dt>{source.path}</dt><dd><code>{source.sha256}</code></dd></div>)}</dl> : <p>No workspace sources.</p>}</div>)}</section>}
  </article>;
}
export function ComposeMission() {
  const { session, commands, current } = useWorkspace();
  const navigate = useNavigate();
  const targets = session.bootstrap.targets;
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState(() => ({ title: '', objective: '', acceptance: '', humanGate: false,
    coordinatorSource: '', coordinatorSourceHash: '', specialistSource: '', specialistSourceHash: '',
    coordinator: targets[0] ? targetKey(targets[0]) : '', specialist: targets[1] ? targetKey(targets[1]) : targets[0] ? targetKey(targets[0]) : '' }));
  const [paper, setPaper] = useState<MissionPaper>();
  const [error, setError] = useState('');
  const heading = useRef<HTMLHeadingElement>(null);
  const locked = !current || !!commands.pending || !!commands.conflict || commands.recoveryBlocked;
  useEffect(() => { heading.current?.focus(); }, [step]);
  function review() {
    const coordinator = targets.find(t => targetKey(t) === draft.coordinator);
    const specialist = targets.find(t => targetKey(t) === draft.specialist);
    if (!coordinator || !specialist) { setError('Choose configured agents for both roles.'); return; }
    try {
      const capabilities = parseMissionCapabilities({ version: 1,
        coordinator: { sources: draft.coordinatorSource ? [{ path: draft.coordinatorSource, sha256: draft.coordinatorSourceHash }] : [] },
        specialist: { sources: draft.specialistSource ? [{ path: draft.specialistSource, sha256: draft.specialistSourceHash }] : [] } });
      setError(''); setPaper({ title: draft.title, objective: draft.objective, acceptance: draft.acceptance, coordinator, specialist, capabilities,
        closeoutPolicy: { version: 1, mode: 'coordinator', humanGate: draft.humanGate ? 'required' : 'none' } }); setStep(2);
    } catch { setError('Each source needs a relative workspace path and its 64-character lowercase SHA-256 revision.'); }
  }
  async function create() {
    if (!paper || locked) return;
    const receipt = await commands.send({ type: 'create', missionId: crypto.randomUUID(), commandId: crypto.randomUUID(), expectedVersion: 0, paper });
    if (receipt) navigate(`/missions/${encodeURIComponent(receipt.missionId)}`);
  }
  return <section className="ws-surface" aria-label="Compose a mission"><header className="ws-surface-header"><div><span className="ws-eyebrow">{session.project.name} / GRILLING</span><h1 ref={heading} tabIndex={-1}>{['Grilling', 'Give the work an owner.', 'Read the whole paper.'][step]}</h1></div><Link className="ws-icon-button" aria-label="Back to mission board" to="/missions"><Icon name="close" /></Link></header>
    <div className="ws-compose-layout"><nav className="ws-outline" aria-label="Mission creation steps">{['The intention', 'The people', 'Mission paper'].map((label, index) => <button key={label} disabled={locked || index > step} aria-current={step === index ? 'step' : undefined} onClick={() => setStep(index)}><span>{String(index + 1).padStart(2, '0')}</span>{label}</button>)}<div><span className="ws-eyebrow">BEFORE THE WORK BEGINS</span><p>A saved paper is a draft. Approval and starting are separate decisions.</p></div></nav>
      <div className="ws-compose-content">{error && <div className="ws-alert" role="alert">{error}</div>}
        {step === 0 && <form className="ws-form-paper" onSubmit={event => { event.preventDefault(); setStep(1); }}><span className="ws-eyebrow">MAKE THE OUTCOME CLEAR</span><h2>What should be different?</h2><p className="ws-muted">Use your own words. This paper carries the exact intention the team will review.</p>
          <label className="ws-field">Mission name<input required maxLength={200} value={draft.title} disabled={locked} placeholder="A short name for the work" onChange={e => setDraft({ ...draft, title: e.target.value })} /></label>
          <label className="ws-field">Desired outcome<textarea required maxLength={8000} rows={5} value={draft.objective} disabled={locked} placeholder="What do you want to achieve, and why does it matter?" onChange={e => setDraft({ ...draft, objective: e.target.value })} /><small>Describe the bounded result, including any important limits.</small></label>
          <label className="ws-field">Acceptance criteria<textarea required maxLength={4000} rows={4} value={draft.acceptance} disabled={locked} placeholder="What evidence would demonstrate that the outcome has been achieved?" onChange={e => setDraft({ ...draft, acceptance: e.target.value })} /></label>
          <div className="ws-actions ws-actions--end"><Button type="submit" disabled={locked || !draft.title.trim() || !draft.objective.trim() || !draft.acceptance.trim()}>Choose the people <Icon name="arrow" /></Button></div></form>}
        {step === 1 && <form className="ws-form-paper" onSubmit={event => { event.preventDefault(); review(); }}><span className="ws-eyebrow">ONE OWNER FOR EACH ROLE</span><h2>Who will carry this forward?</h2><p className="ws-muted">Choose from the agents registered with this Studio authority. Selecting a person does not contact them.</p>{(['coordinator', 'specialist'] as const).map(role => <label className="ws-field" key={role}>{role === 'coordinator' ? 'Coordinator' : 'Specialist'}<select required value={draft[role]} disabled={locked} onChange={e => setDraft({ ...draft, [role]: e.target.value })}><option value="">Choose an agent</option>{targets.map(target => <option value={targetKey(target)} key={targetKey(target)}>{targetLabel(target)}</option>)}</select><small>{role === 'coordinator' ? 'Coordinates the approved assignment, verifies the result and requests closeout.' : 'Produces the bounded result and records its evidence.'}</small></label>)}
          <label className="ws-policy-choice"><input type="checkbox" checked={draft.humanGate} disabled={locked} onChange={e => setDraft({ ...draft, humanGate: e.target.checked })} /> Require a human gate before the coordinator closes this mission.</label><p className="ws-small">By default the coordinator verifies and closes the work. You can inspect and acknowledge the outcome afterwards.</p>
          <details className="ws-record"><summary>Workspace source access (optional)</summary><p>Approve one existing UTF-8 file per role, up to 64 KiB. Use its path inside that agent’s workspace and the SHA-256 of the reviewed bytes. A changed file needs a new approval.</p>{(['coordinator', 'specialist'] as const).map(role => <div key={role}><h3>{role === 'coordinator' ? 'Coordinator source' : 'Specialist source'}</h3><label className="ws-field">Workspace path<input maxLength={512} disabled={locked} value={draft[`${role}Source`]} onChange={e => setDraft({ ...draft, [`${role}Source`]: e.target.value })} placeholder="docs/brief.md" /></label><label className="ws-field">Approved SHA-256<input disabled={locked} required={Boolean(draft[`${role}Source`])} pattern="[a-f0-9]{64}" maxLength={64} value={draft[`${role}SourceHash`]} onChange={e => setDraft({ ...draft, [`${role}SourceHash`]: e.target.value })} /></label></div>)}</details>
          {!targets.length && <div className="ws-alert">No agents are configured. An administrator needs to register the project’s runtime targets.</div>}<div className="ws-actions ws-actions--end"><Button variant="quiet" type="button"  onClick={() => setStep(0)}>Back to intention</Button><Button type="submit" disabled={locked || !draft.coordinator || !draft.specialist}>Review mission paper <Icon name="arrow" /></Button></div></form>}
        {step === 2 && paper && <><Paper paper={paper} /><div className="ws-review-footer"><div><span className="ws-eyebrow">READY TO SAVE?</span><p>This exact paper will be stored as a draft. No agent work starts.</p></div><div className="ws-actions"><Button variant="quiet" disabled={locked} onClick={() => setStep(0)}>Edit paper</Button><Button disabled={locked} onClick={() => void create()}>Create mission</Button></div></div></>}
      </div></div>
  </section>;
}

export function MissionDetail() {
  const { missionId = '' } = useParams();
  const { owner, current, visible, commands } = useWorkspace();
  const view = useQuery({ queryKey: ['workspace', owner, 'mission', missionId],
    queryFn: async ({ signal }) => {
      const result = parseMissionView(await api(`/api/studio/missions/${encodeURIComponent(missionId)}`, { signal }));
      if (result.mission.id !== missionId) throw Error('The returned mission does not match the requested paper.');
      return result;
    }, enabled: current, refetchInterval: current && visible ? 7000 : false,
  });
  const data = accessDenied(view.error) ? undefined : view.data;
  if (!data && current && !view.isError) return <section className="ws-surface"><header className="ws-surface-header"><div><Link className="ws-text-link" to="/missions">← Missions</Link><h1>Mission</h1></div></header><LoadingState label="Loading mission…" size="page" /></section>;
  if (!data) return <section className="ws-surface"><EmptyState level={1} eyebrow="MISSION PAPER" role={view.isError ? 'alert' : 'status'} title={view.isError ? 'The mission could not be opened.' : 'Reconnect to open this mission.'} actions={<><Link className="ws-button ws-button--quiet" to="/missions">Back to missions</Link><Button disabled={!current || view.isFetching} onClick={() => void view.refetch()}>Refresh mission</Button></>}>{view.isError ? readableError(view.error) : 'Refresh your access to read this mission.'}</EmptyState></section>;
  const freshReviewReady = !!commands.conflict && commands.conflict.missionId === missionId && view.dataUpdatedAt > commands.conflict.at && !view.isFetching && !view.isError && current;
  return <MissionDesk key={missionId} view={data} stale={!current || view.isError} refreshing={view.isFetching} refresh={() => void view.refetch()} freshReviewReady={freshReviewReady} />;
}

type Decision = { type: 'approve' | 'start' | 'hold' | 'resume' | 'cancel'; version: number };
function MissionDesk({ view, stale, refreshing, refresh, freshReviewReady }: {
  view: MissionView; stale: boolean; refreshing: boolean; refresh(): void; freshReviewReady: boolean;
}) {
  const { session, commands, current } = useWorkspace();
  const m = view.mission;
  const [search, setSearch] = useSearchParams();
  const selected = ['paper', 'activity', 'conversations', 'evidence'].includes(search.get('section') ?? '') ? search.get('section')! : 'paper';
  const [decision, setDecision] = useState<Decision>();
  const [reason, setReason] = useState('');
  const reviewHeading = useRef<HTMLHeadingElement>(null);
  const canDecide = current && !stale && !refreshing && session.bootstrap.capabilities.approver && !commands.pending && !commands.conflict && !commands.recoveryBlocked;
  const outbound = view.dispatches.some(dispatch => dispatch.transport === 'outbound-v1');
  const frozenCloseout = !terminal(m) && m.held && !!m.closeoutRequest;
  const interrupted = !terminal(m) && m.held && (view.resumeProgress ? view.resumeProgress.state === 'blocked'
    : view.dispatches.some(dispatch => dispatch.transport === 'outbound-v1' && dispatch.abortState));
  const interruptionNotice = frozenCloseout ? 'This closeout is on hold. Resuming it requires reconciliation of the coordinator’s closing turn; cancellation remains available.'
    : view.resumeProgress?.reason ?? 'An interrupted remote turn needs reconciliation before this mission can resume. Inspect Team & activity; cancellation remains available.';
  useEffect(() => { if (decision) reviewHeading.current?.focus(); }, [decision]);
  const labels = { approve: 'Approve paper', start: 'Start mission', hold: 'Put on hold', resume: 'Resume mission', cancel: 'Cancel mission' };
  function open(type: Decision['type']) { if (type !== 'resume' || !interrupted && !frozenCloseout) setDecision({ type, version: m.version }); }
  async function confirm() {
    if (!decision || decision.version !== m.version || !canDecide || decision.type === 'resume' && (interrupted || frozenCloseout)) return;
    const base = { commandId: crypto.randomUUID(), missionId: m.id, expectedVersion: decision.version };
    const command: MissionCommand = decision.type === 'cancel' ? { ...base, type: 'cancel', reason } : { ...base, type: decision.type };
    const result = await commands.send(command);
    if (result) { setDecision(undefined); setReason(''); }
  }
  return <section className="ws-surface" aria-label="Mission workspace"><header className="ws-surface-header"><div><span className="ws-eyebrow">{session.project.name} / MISSION / v{m.version}{stale ? ' / LAST KNOWN STATE' : ''}</span><h1>{m.paper.title}</h1></div><div className="ws-actions"><span className={`ws-status ws-status--${m.state}`}>{missionLabel(m, view.closeoutProgress)}</span><Button variant="quiet" onClick={refresh} disabled={!current || refreshing}>{refreshing ? 'Refreshing…' : 'Refresh'}</Button><Link className="ws-icon-button" aria-label="Back to mission board" to="/missions"><Icon name="close" /></Link></div></header>
    <div className="ws-detail-tabs ui-tabs" role="group" aria-label="Mission sections">{[['paper', 'Mission paper'], ['activity', 'Team & activity'], ['conversations', 'Conversation'], ['evidence', 'Evidence & review']].map(([id, label]) => <button key={id} aria-pressed={selected === id} onClick={() => setSearch(previous => { const next = new URLSearchParams(previous); next.set('section', id!); return next; })}>{label}</button>)}</div>
    {stale && <div className="ws-alert" role="alert">This is the last known mission state. Refresh successfully before deciding or inspecting content.</div>}
    {commands.conflict?.missionId === m.id && <div className="ws-fresh-review"><p>{freshReviewReady ? 'The current version has loaded. Review its paper and evidence before making a new decision.' : 'Refresh this mission to load the state that rejected the previous decision.'}</p><Button variant="quiet" disabled={!freshReviewReady} onClick={() => { commands.reviewCurrent(); setDecision(undefined); }}>I reviewed the current state</Button></div>}
    <div className="ws-desk-layout"><div className="ws-desk-content">
      {selected === 'paper' && <><Paper paper={m.paper} /><DecisionRecords mission={m} progress={view.closeoutProgress} /></>}
      {selected === 'activity' && <Activity view={view} />}
      {selected === 'conversations' && <Conversations key={m.id} missionId={m.id} readable={current && !stale} responseEligible={m.state === 'running' && !m.held && !m.closeoutRequest} />}
      {selected === 'evidence' && <ArtifactReview key={m.id} mission={m} progress={view.closeoutProgress} readable={current && !stale && !commands.pending} decisions={canDecide} />}
    </div><aside className="ws-decision-panel"><span className="ws-eyebrow">THE NEXT DECISION</span><h2>{terminal(m) ? 'The outcome is recorded.' : m.state === 'draft' ? 'Ready to approve?' : m.state === 'approved' ? 'Ready when you are.' : m.held ? 'Work is on hold.' : 'Keep the work in view.'}</h2><p id={interrupted || frozenCloseout ? 'ws-interruption-notice' : undefined}>{view.closeoutProgress?.state === 'blocked' ? view.closeoutProgress.reason : interrupted || frozenCloseout ? interruptionNotice : nextDecision(m, view.closeoutProgress)}</p>
      {!session.bootstrap.capabilities.approver && <p className="ws-role-note">You can inspect mission records. A Studio approver makes lifecycle decisions.</p>}
      {!session.bootstrap.dispatchEnabled && !terminal(m) && <div className="ws-execution-note"><strong>Execution is off.</strong><p>You can prepare and approve this paper. Starting agent work is unavailable in this workspace.</p></div>}
      {m.state === 'draft' && <Button disabled={!canDecide} onClick={() => open('approve')}>Approve paper</Button>}
      {m.state === 'approved' && <Button disabled={!canDecide || m.held || !session.bootstrap.dispatchEnabled} onClick={() => open('start')}>Start mission</Button>}
      {!terminal(m) && <><Button variant="quiet" disabled={!canDecide || interrupted || frozenCloseout || m.held && m.state === 'running' && !session.bootstrap.dispatchEnabled} aria-describedby={interrupted || frozenCloseout ? 'ws-interruption-notice' : undefined} onClick={() => open(m.held ? 'resume' : 'hold')}>{m.held ? 'Resume mission' : 'Put on hold'}</Button><Button variant="quiet" disabled={!canDecide} onClick={() => open('cancel')}>Cancel mission…</Button><p className="ws-small">{outbound ? 'Hold pauses new dispatches and requests interruption of remote turns. Admitted work may still finish and record evidence.' : 'Hold pauses new dispatches. An admitted turn may still finish and record evidence.'}</p></>}
      {decision && <section className="ws-confirmation" aria-label="Review decision"><h3 ref={reviewHeading} tabIndex={-1}>{labels[decision.type]}</h3><p>For this paper at version {decision.version}.</p>{decision.type === 'approve' && <p>Approval records this exact paper. It does not start any agent.</p>}{decision.type === 'cancel' && <label className="ws-field">Cancellation reason<textarea rows={4} maxLength={2000} value={reason} onChange={e => setReason(e.target.value)} /></label>}
        {decision.version !== m.version && <p className="ws-warning">The mission changed. Close this review and inspect the current version before deciding.</p>}
        <Button variant={decision.type === 'cancel' ? 'danger' : 'primary'} disabled={!canDecide || decision.version !== m.version || decision.type === 'resume' && (interrupted || frozenCloseout) || decision.type === 'cancel' && !reason.trim()} onClick={() => void confirm()}>Confirm {decision.type === 'approve' ? 'approval' : decision.type === 'cancel' ? 'cancellation' : decision.type}</Button><Button variant="quiet" onClick={() => setDecision(undefined)}>Close review</Button></section>}
      <div className="ws-decision-foot">Reviewing v{m.version}<br />{dateLabel(m.updatedAt)}</div>
    </aside></div>
  </section>;
}
function DecisionRecords({ mission: m, progress }: { mission: Mission; progress?: MissionView['closeoutProgress'] }) {
  return <details className="ws-record"><summary>Stored paper & decision records</summary><dl>
    <dt>Mission ID</dt><dd>{m.id}</dd><dt>Paper SHA-256</dt><dd>{m.paperDigest}</dd>
    {m.approval && <><dt>Approved by</dt><dd>{m.approval.profileId} · {dateLabel(m.approval.at)}</dd><dt>Approved paper</dt><dd>{m.approval.paperDigest}</dd></>}
    {m.verification && <><dt>Verified by</dt><dd>{targetLabel(m.verification.actor)} · {dateLabel(m.verification.at)}</dd><dt>Verified evidence</dt><dd>{m.verification.evidenceRevision} · {m.verification.evidenceHash}</dd><dt>Coordinator assessment</dt><dd className="ws-literal">{m.verification.assessment.summary}</dd><dt>Residual gaps</dt><dd>{m.verification.assessment.residualGaps.length ? m.verification.assessment.residualGaps.join('\n') : 'None reported'}</dd><dt>Artifact read receipt</dt><dd>{m.verification.assessment.readReceiptId}</dd></>}
    {m.closeoutRequest && !m.closeout && <><dt>Closeout requested by</dt><dd>{targetLabel(m.closeoutRequest.actor)} · {dateLabel(m.closeoutRequest.at)}</dd><dt>Closeout progress</dt><dd>{m.state === 'cancelled' ? 'The mission was cancelled before closeout. This request remains in its history.' : progress?.reason ?? 'Waiting for the approved gate and terminal runtime receipts.'}</dd></>}
    {m.closeoutGate && <><dt>Human gate resolved by</dt><dd>{m.closeoutGate.profileId} · {dateLabel(m.closeoutGate.at)}</dd><dt>Gate evidence</dt><dd>{m.closeoutGate.evidenceRevision} · {m.closeoutGate.evidenceHash}</dd></>}
    {m.closeout && <><dt>Closed by</dt><dd>{targetLabel(m.closeout.actor)} · {dateLabel(m.closeout.closedAt)}</dd><dt>Closed evidence</dt><dd>{m.closeout.evidenceRevision} · {m.closeout.evidenceHash}</dd><dt>Closeout assignment</dt><dd>{m.closeout.actor.assignmentId} · generation {m.closeout.actor.generation}</dd><dt>Closeout session</dt><dd>{m.closeout.actor.sessionId}</dd><dt>Closeout policy SHA-256</dt><dd>{m.closeout.policyDigest}</dd></>}
    {m.acknowledgement && <><dt>Acknowledged by</dt><dd>{m.acknowledgement.profileId} · {dateLabel(m.acknowledgement.at)}</dd><dt>Acknowledged evidence</dt><dd>{m.acknowledgement.evidenceRevision} · {m.acknowledgement.evidenceHash}</dd></>}
    {m.acceptance && <><dt>Accepted by</dt><dd>{m.acceptance.profileId} · {dateLabel(m.acceptance.at)}</dd><dt>Accepted evidence</dt><dd>{m.acceptance.evidenceRevision} · {m.acceptance.evidenceHash}</dd></>}
    {m.cancellation && <><dt>Cancelled by</dt><dd>{m.cancellation.profileId} · {dateLabel(m.cancellation.at)}</dd><dt>Reason</dt><dd className="ws-literal">{m.cancellation.reason}</dd></>}
  </dl></details>;
}
function Activity({ view }: { view: MissionView }) {
  const m = view.mission;
  return <section className="ws-activity"><span className="ws-eyebrow">TEAM / RECORDED ACTIVITY</span><h2>Each handoff stays connected.</h2><p>Runtime admission, delivery and verification are separate records. A recorded turn is not proof that someone is currently working.</p><div className="ws-paper-team">{(['coordinator', 'specialist'] as const).map(role => <div key={role}><span className={`ws-avatar ws-avatar--${role}`}>{role === 'coordinator' ? 'C' : 'S'}</span><div><strong>{m.paper[role].agentId}</strong><span>{role} · {m.paper[role].gatewayId}</span></div></div>)}</div>
    {view.dispatches.length ? <ol className="ws-timeline">{view.dispatches.map(d => <li key={d.id}><span /><div><header><h3>{d.continuation ? (d.continuation.kind === 'resume' ? 'Assignment recovery' : 'Coordinator continuation') : `${d.role === 'coordinator' ? 'Coordinator' : 'Specialist'} assignment`}</h3><small>{dispatchLabel(d)}</small></header><p>{targetLabel(d)}</p>{d.reason && <p className="ws-literal">{d.reason}</p>}{d.resumedBy && <p>Recovery dispatch: {d.resumedBy}</p>}{d.abortState && <p>Abort: {d.abortState}{d.abortState !== 'done' ? ' · runtime cancellation is not confirmed' : ''}</p>}<details><summary>Runtime binding & receipt</summary><dl>{[['Dispatch', d.id], ['Session key', d.sessionKey], ['Session ID', d.sessionId], ['Run ID', d.runId]].filter(([, value]) => value).map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></details></div></li>)}</ol> : <div className="ws-inline-empty"><h3>No runtime assignments yet.</h3><p>Approving the paper does not start the team. Execution remains a separate step.</p></div>}
  </section>;
}
