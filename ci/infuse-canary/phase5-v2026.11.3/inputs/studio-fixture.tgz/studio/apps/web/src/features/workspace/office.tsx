import { IconButton, Button, Toolbar } from './ui.js';
import { OfficeLoading } from './office-loading.js';
import { officeThunderstorm } from '@studio/spatial/weather';
import { lazy, Suspense, useEffect, useState } from 'react';
import { useWorkspace } from './context.js';
import { Link, useNavigate } from './navigation.js';
import { SceneBoundary } from './scene-boundary.js';
import './office.css';
const OfficeScene = lazy(() => import('./office-scene.js').then(module => ({ default: module.OfficeScene })));

export function Office({ shown }: { shown: boolean }) {
  const { session, visible, current } = useWorkspace(); const navigate = useNavigate(); const [ready, setReady] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const [reduced, setReduced] = useState(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => {
    const query = matchMedia('(prefers-reduced-motion: reduce)'), change = () => setReduced(query.matches);
    query.addEventListener('change', change); return () => query.removeEventListener('change', change);
  }, []);
  useEffect(() => {
    if (!shown) return;
    const tick = () => { if (!document.hidden) setNow(new Date()); }; tick();
    const interval = window.setInterval(tick, 30_000); document.addEventListener('visibilitychange', tick);
    return () => { clearInterval(interval); document.removeEventListener('visibilitychange', tick); };
  }, [shown]);
  const hour = now.getHours() + now.getMinutes() / 60;
  const storm = officeThunderstorm(now.getTime());
  const enter = (id: string) => { if (session.projects.some(project => project.id === id)) navigate(`/floor?${new URLSearchParams({ project: id })}`); };
  return <section className="ws-office" hidden={!shown} aria-label="Company office">
    <header className="ws-office-heading"><h1>Office</h1><p>Choose a project floor.</p>{session.canManageFloors && <div className="ws-office-management"><Link to="/floors" className={ready ? 'ws-directory-fallback' : undefined}>Manage floors →</Link></div>}</header>
    <SceneBoundary><Suspense fallback={<OfficeLoading />}><OfficeScene projects={session.projects} shown={shown && visible && current} enter={enter} ready={setReady} hour={hour} moving={!reduced} storm={storm} manage={session.canManageFloors && current ? () => navigate('/floors') : undefined} /></Suspense></SceneBoundary>
    <div className="ws-office-atmosphere" role="group" aria-label="Office atmosphere">
      <div className="ws-office-clock"><span className="ws-office-clock-dot" aria-hidden="true" /><span><time dateTime={now.toISOString()}>{now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time><small>Your local time</small></span></div>
    </div>
    <Toolbar className="ws-office-camera" aria-label="Building camera"><IconButton type="button" disabled={!ready} data-building-camera="out" aria-label="Zoom out">−</IconButton><Button variant="quiet" type="button" disabled={!ready} data-building-camera="fit">Fit building</Button><IconButton type="button" disabled={!ready} data-building-camera="in" aria-label="Zoom in">＋</IconButton></Toolbar>
  </section>;
}
