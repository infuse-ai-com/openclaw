import * as THREE from 'three';
import { officeDaylight } from '@studio/spatial/neighborhood';
import { officeThunderstorm } from '@studio/spatial/weather';
import dayUrl from '../../../../../packages/ui/assets/floor-window-day.jpg';
import nightUrl from '../../../../../packages/ui/assets/floor-window-night.jpg';

/** Decorative view through the windows, sharing the exterior's clock and hourly weather. */
export function createFloorAtmosphere(scene: THREE.Scene, office: THREE.Group, doors: THREE.Group[], redraw: () => void, manager: THREE.LoadingManager) {
  const sky = new THREE.HemisphereLight(0xfff1d5, 0x425748, 1.7); scene.add(sky);
  const sun = new THREE.DirectionalLight(0xffeed3, 3); sun.castShadow = true;
  sun.shadow.mapSize.set(1024,1024); Object.assign(sun.shadow.camera, {left:-18,right:18,top:17,bottom:-17,near:.5,far:60});
  sun.shadow.bias=-.0004; sun.shadow.normalBias=.05; scene.add(sun);
  const fill = new THREE.DirectionalLight(0xb8c9ee,.6); fill.position.set(-8,8,12); scene.add(fill);
  const flash = new THREE.DirectionalLight(0xcbdcff,0); flash.position.set(0,7,-10); scene.add(flash);
  const lamps: {light:THREE.PointLight; intensity:number}[]=[];
  office.traverse(object => {if(object instanceof THREE.PointLight) lamps.push({light:object,intensity:object.intensity});});
  let disposed=false;
  const loader=new THREE.TextureLoader(manager);
  const textures=[dayUrl,nightUrl].map((url,index)=>{
    const texture=loader.load(url,()=>{if(!disposed)redraw();},undefined,()=>{
      // Keep the room usable without a failed decorative image or an untextured plane.
      if(!disposed){windows[index]!.visible=false;redraw();}
    });
    texture.colorSpace=THREE.SRGBColorSpace; texture.repeat.set(1,.29); texture.offset.set(0,.33); return texture;
  });
  const materials=textures.map((map,i)=>new THREE.MeshBasicMaterial({map,transparent:i===1,opacity:i===0?1:0,depthWrite:false,toneMapped:false}));
  const windows=materials.map((material,i)=>{
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(21.9,2.02),material);
    mesh.position.set(0,1.94,-7.005+i*.002);mesh.renderOrder=i;office.add(mesh);return mesh;
  });
  let storm=false, start=0, elapsed=0, lastStorm=false;
  const update=(now:Date)=>{
    const light=officeDaylight(now.getHours()+now.getMinutes()/60);
    storm=officeThunderstorm(now.getTime()); if(storm!==lastStorm){start=elapsed;lastStorm=storm;}
    sky.color.set(0xfff2d9).lerp(new THREE.Color(0xcbd9ed),light.night*.65);sky.intensity=1.9+light.ambient*.5;
    sun.color.copy(light.sun).lerp(new THREE.Color(0xfff2de),.4);sun.intensity=light.sunlight*(storm?.42:.92);
    const arc=(light.hour-6)/14*Math.PI;
    sun.position.set(-Math.cos(arc)*15,6+Math.max(0,Math.sin(arc))*14,-10);
    fill.intensity=.35+light.night*.45;
    for(const lamp of lamps) lamp.light.intensity=lamp.intensity*(.35+light.night*.9);
    materials[0]!.color.setRGB(storm?.55:1,storm?.59:1,storm?.65:1);
    materials[1]!.opacity=THREE.MathUtils.smoothstep(light.night,.45,1); materials[1]!.color.setScalar(storm?.7:1);
    return {night:light.night,storm};
  };
  return { update,
    animate(seconds:number,moving:boolean,arrival:boolean) {
      elapsed=seconds;
      const t=arrival&&moving?seconds:6;
      const open=THREE.MathUtils.smoothstep(t,.4,1.6)*(1-THREE.MathUtils.smoothstep(t,3.6,4.8));
      for(const door of doors)door.position.x=door.userData.closedX+door.userData.side*open*.76;
      const phase=(Math.max(0,seconds-start)+10)%13;
      flash.intensity=storm&&moving&&phase<.8?Math.sin(phase/.8*Math.PI)*1.1:0;
      return {open,active:t<5,stormMotion:storm&&moving,flash:flash.intensity};
    },
    dispose(){disposed=true;textures.forEach(t=>t.dispose());materials.forEach(m=>m.dispose());windows.forEach(w=>{w.geometry.dispose();w.removeFromParent();});},
  };
}
