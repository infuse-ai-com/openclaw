import { useState, useCallback, useEffect } from 'react';
import { intersects, type useSpatialBoard } from './whiteboard-spatial.js';
import type { CanvasItem } from './whiteboard-types.js';
import type { BoardCamera } from './whiteboard-section-zoom.js';
/** Keeps at most two nearby HTML previews live, retaining frames currently in use. */
export function useWhiteboardHtmlFrames({
  blocks,
  canvasSize,
  viewport,
  editable,
  visible,
  panel,
  sectionId,
  board,
}: {
  blocks: CanvasItem[];
  canvasSize: { width: number; height: number };
  viewport: BoardCamera;
  editable: boolean;
  visible: boolean;
  panel: string | null;
  sectionId: string;
  board: Pick<ReturnType<typeof useSpatialBoard>, 'data'>;
}) {
  const [activeHtml, setActiveHtml] = useState<string[]>([]);
  const [engagedHtml, setEngagedHtml] = useState<string[]>([]);
  const engageHtml = useCallback(
    (id: string, engaged: boolean) =>
      setEngagedHtml((values) =>
        engaged === values.includes(id)
          ? values
          : engaged
            ? [...values, id]
            : values.filter((value) => value !== id),
      ),
    [],
  );
  useEffect(() => {
    setActiveHtml([]);
    setEngagedHtml([]);
  }, [sectionId]);
  useEffect(() => {
    const center = {
      x: (canvasSize.width / 2 - viewport.x) / viewport.zoom,
      y: (canvasSize.height / 2 - viewport.y) / viewport.zoom,
    };
    const available =
      editable && visible && panel !== 'html' && board.data?.sectionId === sectionId;
    const html = available ? blocks.filter((block) => block.kind === 'html') : [];
    const pinned = engagedHtml.filter((id) => html.some((block) => block.id === id));
    const inView = html.filter((block) =>
      intersects({ ...block, sectionId }, viewport, canvasSize),
    );
    const nearby = inView
      .filter((block) => board.data?.loadedIds.has(block.id))
      .sort(
        (a, b) =>
          Math.hypot(a.x + a.width / 2 - center.x, a.y + a.height / 2 - center.y) -
          Math.hypot(b.x + b.width / 2 - center.x, b.y + b.height / 2 - center.y),
      )
      .map((block) => block.id);
    setActiveHtml((previous) => {
      // Keep visible frames stable while panning; never evict HTML being used or expanded.
      const next = [
        ...new Set([
          ...pinned,
          ...previous.filter((id) => inView.some((block) => block.id === id)),
          ...(viewport.zoom >= 0.45 ? nearby : []),
        ]),
      ].slice(0, 2);
      return next.length === previous.length && next.every((id, index) => id === previous[index])
        ? previous
        : next;
    });
  }, [blocks, editable, visible, board.data, sectionId, viewport, canvasSize, engagedHtml, panel]);
  return { activeHtml, setActiveHtml, engagedHtml, engageHtml };
}
