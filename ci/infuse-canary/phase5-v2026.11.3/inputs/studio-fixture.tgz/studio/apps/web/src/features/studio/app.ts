import {
  parseMissionCommand, parseMissionList, parseMissionReceipt, parseMissionView, parseStudioBootstrap,
  type MissionCommand, type MissionListCursor, type MissionPaper, type MissionSummary,
  type MissionView, type RuntimeTarget, type StudioBootstrap,
} from '@studio/contracts';
import type { StudioContext, StudioMount } from './host.js';
import { closeoutPolicyLabel, coordinatorCloseout, dateLabel, dispatchLabel, errorCode, gatePending, escapeHtml as e, missionLabel, needsDecision, nextDecision, targetKey, targetLabel, terminal } from './presentation.js';
import { checkArtifact, displayedEvidence, evidenceRevisions, evidenceKey, evidenceMarkup, inspected, isLatestEvidence, managedEvidence, type EvidenceInspection } from './evidence.js';
import { correctionBaseMatches, type CorrectionDraft } from './corrections.js';
import logo from '../../../../../packages/ui/assets/INFUSE_horizontal_for_dark_background.png?inline';
import { createStudioSpace, type StudioSpace } from './spatial.js';
import { projectStudioSpace, type SpatialDestination } from './spatial-projection.js';

type Draft = { title: string; objective: string; acceptance: string; coordinator: string; specialist: string };
type Pending = { command: MissionCommand; status: 'sending' | 'uncertain'; profileId: string; authorityId: string };
const newDraft = (): Draft => ({ title: '', objective: '', acceptance: '', coordinator: '', specialist: '' });
const uid = (): string => crypto.randomUUID();
const validFilter = (value?: string): string => ['decision', 'running', 'review', 'closed'].includes(value ?? '') ? value! : 'all';
const button = (text: string, action: string, disabled = false, secondary = false): string => `<button type="button" class="studio-button${secondary ? ' studio-button--secondary' : ''}" data-action="${action}" ${disabled ? 'disabled' : ''}>${text}</button>`;
const textBlock = (label: string, content: string): string => `<section class="studio-paper-section"><h3>${label}</h3><p class="studio-prose">${e(content)}</p></section>`;
const codeBlock = (label: string, value: string): string => `<div class="studio-fact"><dt>${label}</dt><dd><code>${e(value)}</code></dd></div>`;

/** Mount owns only its supplied root. Mission data always comes from the plugin authority. */
export function mountStudio(root: HTMLElement, initial: StudioContext): StudioMount {
  let context = initial;
  let disposed = false;
  let epoch = 0;
  let commandEpoch = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let refreshing = false;
  let bootstrap: StudioBootstrap | undefined;
  let missions: MissionSummary[] = [];
  let cursor: MissionListCursor | undefined;
  let view: MissionView | undefined;
  let selected = initial.props.missionId ?? '';
  let composing = initial.props.compose === '1';
  let draft = newDraft();
  let reviewDraft = false;
  let loading = true;
  let forbidden = false;
  let stale = false;
  let conflict = false;
  let notice = '';
  let failure = '';
  let filter = validFilter(initial.props.filter);
  let cancelReason = '';
  let cancelOpen = false;
  let reviewedEvidence = false;
  let inspection: EvidenceInspection = { status: 'idle' };
  let inspectionEpoch = 0;
  let selectedEvidenceRevision = '';
  let correctionDraft: CorrectionDraft | undefined;
  let pending: Pending | undefined;
  let loadedPendingFor = '';
  let ownerKey = '';
  let loadedPages = 1;
  let space: StudioSpace | undefined;
  const connectionKey = (): string => JSON.stringify(context.host.connection);
  let lastConnection = connectionKey();

  const active = (): boolean => !disposed && !context.signal.aborted;
  const connected = (): boolean => active() && context.host.connection.connected;
  const canWrite = (): boolean => connected() && context.host.connection.canWrite && !!bootstrap && !stale && !conflict && !pending;
  const approver = (): boolean => canWrite() && bootstrap?.capabilities.approver === true;
  const current = (readEpoch: number): boolean => active() && epoch === readEpoch;
  const selectedEvidence = () => displayedEvidence(view?.mission, selectedEvidenceRevision);
  const inspectionKey = (): string => evidenceKey(ownerKey, view?.mission, selectedEvidence());
  const canInspect = (): boolean => connected() && !!bootstrap && !stale && !refreshing && !pending;
  const contentReviewed = (): boolean => isLatestEvidence(view?.mission, selectedEvidence())
    && (!managedEvidence(view?.mission) || inspected(inspection, inspectionKey()));
  const eligibleCorrection = (): boolean => approver() && view?.mission.state === 'running'
    && view.mission.task.state === 'verified' && !coordinatorCloseout(view.mission) && !view.mission.correction
    && view.mission.task.evidence?.revision === '1' && managedEvidence(view.mission) && contentReviewed();
  function resetInspection(): void {
    inspectionEpoch++; inspection = { status: 'idle' }; reviewedEvidence = false;
    if (correctionDraft) correctionDraft.reviewing = false;
  }
  function clearCorrection(): void { correctionDraft = undefined; selectedEvidenceRevision = ''; }
  function clearAccess(): void {
    bootstrap = undefined; view = undefined; missions = []; clearCorrection(); resetInspection();
    pending = undefined; draft = newDraft(); reviewDraft = false; cancelReason = ''; cancelOpen = false;
    loadedPendingFor = ''; notice = ''; conflict = false; forbidden = true; stale = true;
    space?.dispose(); space = undefined;
  }
  const storageKey = (): string | undefined => bootstrap ? `infuse-studio:pending:${encodeURIComponent(bootstrap.authorityId)}:${encodeURIComponent(bootstrap.profileId)}` : undefined;
  function persistPending(): boolean {
    const key = storageKey();
    if (!key) return false;
    try {
      if (pending) sessionStorage.setItem(key, JSON.stringify(pending.command));
      else sessionStorage.removeItem(key);
      return true;
    } catch { return false; }
  }
  function restorePending(): void {
    const key = storageKey();
    if (!key || key === loadedPendingFor || !bootstrap) return;
    loadedPendingFor = key;
    pending = undefined;
    try {
      const saved = sessionStorage.getItem(key);
      if (saved) pending = { command: parseMissionCommand(JSON.parse(saved)), status: 'uncertain', profileId: bootstrap.profileId, authorityId: bootstrap.authorityId };
    } catch {
      failure = 'A saved command could not be recovered. Inspect the mission before attempting another change.';
      conflict = true;
    }
  }
  async function request(method: string, params: Record<string, unknown>): Promise<unknown> {
    // The public host request has no AbortSignal argument. Epoch checks cancel application of stale results.
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([
        context.host.request(method, params),
        new Promise<never>((_, reject) => { timeout = setTimeout(() => reject(new Error('Request timed out')), 15000); }),
      ]);
    } finally { clearTimeout(timeout); }
  }
  function schedule(): void {
    clearTimeout(timer);
    if (active() && context.presented && !document.hidden && connected() && !composing && !forbidden) {
      timer = setTimeout(() => { void refresh(false); }, 7000);
    }
  }
  async function refresh(showLoading = false): Promise<void> {
    if (!connected()) { loading = false; render(); schedule(); return; }
    const readEpoch = ++epoch;
    refreshing = true;
    if (showLoading) { loading = true; render(); }
    try {
      const nextBootstrap = parseStudioBootstrap(await request('studio.bootstrap', {}));
      if (!current(readEpoch)) return;
      const nextOwner = JSON.stringify([nextBootstrap.authorityId, nextBootstrap.profileId]);
      if (ownerKey && nextOwner !== ownerKey) {
        missions = []; view = undefined; pending = undefined; draft = newDraft(); reviewDraft = false;
        clearCorrection(); resetInspection(); cancelReason = ''; conflict = false; loadedPendingFor = '';
        space?.dispose(); space = undefined; loadedPages = 1;
        bootstrap = undefined; render();
      }
      ownerKey = nextOwner;
      bootstrap = nextBootstrap;
      restorePending();
      if (composing) {
        draft.coordinator ||= bootstrap.targets[0] ? targetKey(bootstrap.targets[0]) : '';
        draft.specialist ||= bootstrap.targets[1] ? targetKey(bootstrap.targets[1]) : draft.coordinator;
      } else if (selected) {
        const next = parseMissionView(await request('studio.get', { missionId: selected }));
        if (!current(readEpoch)) return;
        if (next.mission.id !== selected) throw new Error('Mission response does not match this view');
        if (evidenceKey(ownerKey, next.mission, displayedEvidence(next.mission, selectedEvidenceRevision)) !== inspectionKey()) resetInspection();
        view = next;
      } else {
        // Refresh the complete loaded window so pagination never silently freezes older rows.
        const rows: MissionSummary[] = [];
        let nextCursor: MissionListCursor | undefined;
        for (let page = 0; page < loadedPages; page++) {
          const list = parseMissionList(await request('studio.list', { limit: 30, ...(nextCursor ? { cursor: nextCursor } : {}) }));
          if (!current(readEpoch)) return;
          rows.push(...list.missions); nextCursor = list.nextCursor;
          if (!nextCursor) break;
        }
        missions = [...new Map(rows.map(m => [m.id, m])).values()]; cursor = nextCursor;
      }
      stale = false; forbidden = false; failure = '';
    } catch (error) {
      if (!current(readEpoch)) return;
      const code = errorCode(error);
      forbidden = ['FORBIDDEN', 'AUTHORITY_REVOKED'].includes(code ?? ''); stale = true;
      if (forbidden) {
        clearAccess();
      }
      failure = forbidden ? 'This connection cannot access the Studio authority. A configured Studio member profile is required.'
        : code === 'NOT_FOUND' ? 'This mission could not be found. Check the link or return to Missions.'
        : 'Studio could not refresh this view. Any information shown is the last known state; decisions are disabled until it refreshes.';
    } finally {
      if (current(readEpoch)) { loading = false; refreshing = false; render(); schedule(); }
    }
  }
  async function inspectEvidence(): Promise<void> {
    if (!canInspect() || !managedEvidence(view?.mission, selectedEvidence())) return;
    resetInspection();
    const operation = inspectionEpoch;
    // Recheck identity and the current version before requesting protected artifact bytes.
    await refresh(false);
    if (operation !== inspectionEpoch || !canInspect() || !view) return;
    const mission = view.mission; const evidence = selectedEvidence();
    if (!evidence) return;
    const key = inspectionKey();
    const applies = (): boolean => active() && connected() && operation === inspectionEpoch && key === inspectionKey();
    inspection = { status: 'loading', key }; render();
    try {
      const value = await request('studio.evidence.read', { missionId: mission.id, evidenceHash: evidence.sha256, evidenceRevision: evidence.revision });
      if (!applies()) return;
      const artifact = await checkArtifact(value, mission, evidence);
      if (!applies()) return;
      inspection = { status: 'ready', key, artifact };
    } catch (error) {
      if (!applies()) return;
      if (['FORBIDDEN', 'AUTHORITY_REVOKED'].includes(errorCode(error) ?? '')) {
        epoch++; refreshing = false; clearAccess();
        failure = 'This connection cannot access the Studio authority. A configured Studio member profile is required.';
      } else inspection = { status: 'error', key, message: errorCode(error) === 'ARTIFACT_INTEGRITY'
        ? 'The stored contents failed their integrity check. Acceptance is disabled until the artifact is restored.'
        : error instanceof Error && !errorCode(error) ? error.message
        : 'These contents could not be retrieved. Refresh the mission, then inspect again.' };
    } finally { if (active() && operation === inspectionEpoch) render(); else if (forbidden) render(); }
  }
  async function loadMore(): Promise<void> {
    if (!cursor || refreshing || !connected() || loadedPages >= 10) return;
    const readEpoch = ++epoch;
    refreshing = true; clearTimeout(timer); render();
    try {
      const list = parseMissionList(await request('studio.list', { limit: 30, cursor }));
      if (!current(readEpoch)) return;
      const known = new Set(missions.map(m => m.id));
      missions.push(...list.missions.filter(m => !known.has(m.id))); cursor = list.nextCursor; loadedPages++;
    } catch (error) {
      if (current(readEpoch)) {
        stale = true;
        if (['FORBIDDEN', 'AUTHORITY_REVOKED'].includes(errorCode(error) ?? '')) {
          clearAccess(); failure = 'Studio access ended while reading missions. Refresh to check your current profile.'; return;
        }
        failure = 'More missions could not be loaded. Refresh and try again.';
      }
    }
    finally { if (current(readEpoch)) { refreshing = false; render(); schedule(); } }
  }
  function navigate(params: Record<string, string>): void {
    context.host.navigation.openPage({ id: 'missions', params });
  }
  function navigateSpace(destination: SpatialDestination): void {
    if (destination === 'missions') navigate({});
    else if (selected) navigate({ missionId: selected, section: destination });
    else if (destination === 'paper') navigate({ compose: '1' });
    else navigate({ filter: destination === 'activity' ? 'running' : 'review' });
  }
  function getPaper(): MissionPaper {
    if (!bootstrap) throw Error('Studio is not connected');
    const resolve = (key: string): RuntimeTarget => {
      const target = bootstrap!.targets.find(t => targetKey(t) === key);
      if (!target) throw Error('Choose an available runtime target');
      return target;
    };
    return { title: draft.title, objective: draft.objective, acceptance: draft.acceptance, coordinator: resolve(draft.coordinator), specialist: resolve(draft.specialist) };
  }
  function prepare(command: MissionCommand): void {
    if (!canWrite() || !bootstrap) return;
    pending = { command: parseMissionCommand(command), status: 'sending', profileId: bootstrap.profileId, authorityId: bootstrap.authorityId };
    if (!persistPending()) {
      pending = undefined;
      failure = 'This browser cannot retain a command for recovery. Allow session storage before making decisions; no command was sent.';
      render(); return;
    }
    void submit();
  }
  async function submit(): Promise<void> {
    if (!pending || !connected() || !bootstrap || pending.profileId !== bootstrap.profileId || pending.authorityId !== bootstrap.authorityId) return;
    if (!context.host.connection.canWrite || pending.command.type !== 'create' && !bootstrap.capabilities.approver) return;
    if (!persistPending()) { failure = 'Session storage is unavailable. No retry was sent. Restore browser storage to retain this exact command through reload.'; render(); return; }
    const item = pending;
    epoch++; refreshing = false; resetInspection();
    item.status = 'sending'; failure = ''; notice = ''; clearTimeout(timer);
    const sendEpoch = ++commandEpoch;
    render();
    try {
      const receipt = parseMissionReceipt(await request('studio.command', item.command as unknown as Record<string, unknown>));
      if (!active() || sendEpoch !== commandEpoch || item !== pending) return;
      if (receipt.commandId !== item.command.commandId || receipt.missionId !== item.command.missionId || receipt.version !== item.command.expectedVersion + 1) throw Error('Receipt does not match command');
      pending = undefined; persistPending(); conflict = false; stale = false;
      notice = `${item.command.type === 'create' ? 'Paper stored' : 'Decision recorded'} for ${receipt.missionId} · version ${receipt.version}.`;
      if (item.command.type === 'request-correction') clearCorrection();
      if (item.command.type === 'cancel') { cancelOpen = false; cancelReason = ''; }
      reviewedEvidence = false;
      if (item.command.type === 'create') {
        draft = newDraft(); reviewDraft = false;
        navigate({ missionId: receipt.missionId });
      } else await refresh(false);
    } catch (error) {
      if (!active() || sendEpoch !== commandEpoch || item !== pending) return;
      const code = errorCode(error);
      // FORBIDDEN can be returned by the final live-authority guard after commit. Preserve its envelope.
      const definitive = ['PROJECT_BUSY', 'CLOSEOUT_PENDING', 'VERSION_CONFLICT', 'STATE_CONFLICT', 'EVIDENCE_CONFLICT', 'TERMINAL', 'CONFIGURATION', 'ALREADY_EXISTS', 'NOT_FOUND'].includes(code ?? '');
      if (definitive) {
        pending = undefined; persistPending();
        conflict = true; stale = true; reviewedEvidence = false;
        failure = code === 'CONFIGURATION' ? 'The selected runtime targets are no longer available. Refresh and review the paper again.'
          : 'The mission changed or this decision is no longer valid. Your input is preserved. Refresh, then review the current mission before deciding again.';
      } else {
        item.status = 'uncertain'; persistPending();
        failure = 'The command outcome is unknown. It may already have been recorded. Inspect the current mission or retry this exact command; Studio will not send another decision automatically.';
      }
    } finally { if (active() && sendEpoch === commandEpoch) { render(); schedule(); } }
  }
  function humanCommand(type: 'approve' | 'start' | 'hold' | 'resume' | 'accept' | 'resolve-closeout-gate' | 'acknowledge' | 'cancel'): void {
    const m = view?.mission;
    if (!m || !approver()) return;
    if (type === 'resume' && m.held && m.closeoutRequest) return;
    const base = { commandId: uid(), missionId: m.id, expectedVersion: m.version };
    if (type === 'accept' || type === 'resolve-closeout-gate' || type === 'acknowledge') {
      if (!reviewedEvidence || !contentReviewed() || m.task.state !== 'verified' || !m.task.evidence) return;
      if (m.held && type === 'resolve-closeout-gate') return;
      if (type === 'accept' && (coordinatorCloseout(m) || terminal(m)) || type === 'resolve-closeout-gate' && (terminal(m) || !gatePending(m)) || type === 'acknowledge' && (m.state !== 'closed' || m.acknowledgement)) return;
      prepare({ ...base, type, evidenceHash: m.task.evidence.sha256, evidenceRevision: m.task.evidence.revision });
    } else if (type === 'cancel') {
      if (!cancelReason.trim()) return;
      prepare({ ...base, type, reason: cancelReason });
    } else prepare({ ...base, type });
  }

  function openCorrection(): void {
    const m = view?.mission;
    if (!eligibleCorrection() || !m?.task.evidence) return;
    correctionDraft = { missionId: m.id, baseVersion: m.version, evidenceRevision: m.task.evidence.revision,
      evidenceHash: m.task.evidence.sha256, reason: '', reviewing: false };
    reviewedEvidence = false; render(); root.querySelector<HTMLTextAreaElement>('[data-field="correctionReason"]')?.focus();
  }
  function sendCorrection(): void {
    const m = view?.mission; const d = correctionDraft;
    if (!m || !d || !d.reviewing || !d.reason.trim() || !eligibleCorrection()
      || !correctionBaseMatches(d, m) || d.baseVersion !== m.version) return;
    prepare({ type: 'request-correction', commandId: uid(), missionId: d.missionId, expectedVersion: d.baseVersion,
      reason: d.reason, evidenceHash: d.evidenceHash, evidenceRevision: d.evidenceRevision });
  }

  function paperMarkup(paper: MissionPaper): string {
    const permissions = paper.capabilities ? textBlock('Approved source access', 'Assignment and evidence tools, plus the exact source revisions listed below. No shell, network or workspace write access.\n'
      + (['coordinator', 'specialist'] as const).map(role => `${role}: ${paper.capabilities![role].sources.map(source => `${source.path} (SHA-256 ${source.sha256})`).join(', ') || 'No workspace sources.'}`).join('\n')) : '';
    return `<article class="studio-paper" data-section="paper"><div class="studio-kicker">MISSION PAPER</div><h2>${e(paper.title)}</h2>${textBlock('Objective', paper.objective)}${textBlock('Acceptance criteria', paper.acceptance)}${textBlock('Closing the work', closeoutPolicyLabel(paper))}${permissions}<section class="studio-paper-section"><h3>The team</h3><div class="studio-team"><div><span class="studio-avatar">C</span><span><strong>${e(paper.coordinator.agentId)}</strong><small>Coordinator · ${e(paper.coordinator.gatewayId)}</small></span></div><div><span class="studio-avatar studio-avatar--specialist">S</span><span><strong>${e(paper.specialist.agentId)}</strong><small>Specialist · ${e(paper.specialist.gatewayId)}</small></span></div></div></section></article>`;
  }
  function header(): string {
    return `<header class="studio-header"><a href="${e(context.host.navigation.pageHref({ id: 'missions' }))}" data-nav="board" class="studio-brand" aria-label="Studio missions"><img src="${e(logo)}" alt="Infuse"><span>STUDIO</span></a><div class="studio-identity"><span class="studio-connection ${connected() ? '' : 'studio-connection--offline'}">${connected() ? 'Connected' : 'Disconnected'}</span>${bootstrap ? `<span>${e(bootstrap.profileId)}</span><strong>${bootstrap.capabilities.approver ? 'Approver' : 'Member'}</strong>` : '<span>Verifying access</span>'}</div></header><nav class="studio-nav" aria-label="Studio workspace"><a href="${e(context.host.navigation.pageHref({ id: 'missions' }))}" data-nav="board" ${!selected && !composing ? 'aria-current="page"' : ''}>Missions</a><span>One workspace. Every decision connected.</span><button type="button" data-action="refresh" ${refreshing || !connected() ? 'disabled' : ''}>${refreshing ? 'Refreshing…' : 'Refresh'}</button></nav>`;
  }
  function banners(): string {
    return `${!connected() ? '<div class="studio-banner studio-banner--warning" role="status"><strong>Connection lost.</strong> Decisions are disabled. Reconnect through OpenClaw to refresh the authority’s current state.</div>' : ''}${failure ? `<div class="studio-banner studio-banner--warning" role="alert">${e(failure)}</div>` : ''}${notice ? `<div class="studio-banner" role="status">${e(notice)}</div>` : ''}${bootstrap && !bootstrap.dispatchEnabled ? '<div class="studio-banner studio-banner--warning"><strong>Dispatch is disabled on this authority.</strong> Starting records the mission, but runtime work waits until dispatch is enabled.</div>' : ''}${pending ? `<section class="studio-pending" aria-label="Pending command"><div><span class="studio-kicker">${pending.status === 'sending' ? 'AWAITING RECEIPT' : 'REVIEW BEFORE RETRY'}</span><strong>${e(pending.command.type)} · ${e(pending.command.missionId)}</strong><p>Command <code>${e(pending.command.commandId)}</code> · based on v${pending.command.expectedVersion}</p>${pending.command.type === 'request-correction' ? `<p>Artifact revision ${e(pending.command.evidenceRevision)} · <code>${e(pending.command.evidenceHash)}</code></p><p class="studio-prose">${e(pending.command.reason).replaceAll('\r', '&#13;')}</p>` : ''}</div>${pending.status === 'uncertain' ? `<div class="studio-actions">${button('Retry exact command', 'retry-command', !connected() || !bootstrap || !context.host.connection.canWrite || pending.command.type !== 'create' && !bootstrap.capabilities.approver)}<a class="studio-button studio-button--secondary" href="${e(context.host.navigation.pageHref({ id: 'missions', params: { missionId: pending.command.missionId } }))}" data-mission="${e(pending.command.missionId)}">Inspect mission</a></div>` : '<span role="status">Waiting…</span>'}</section>` : ''}${conflict && !pending ? `<div class="studio-banner studio-banner--warning"><strong>A fresh review is required.</strong> ${stale ? 'Refresh the current state first.' : 'Inspect the current paper, evidence and version before enabling decisions.'}${button('I reviewed the current state', 'review-current', stale || !connected(), true)}</div>` : ''}`;
  }
  function board(): string {
    const shown = missions.filter(m => filter === 'all' || filter === 'decision' && needsDecision(m) || filter === 'running' && m.state === 'running' && !m.held || filter === 'review' && m.state === 'running' && m.taskState === 'verified' && needsDecision(m) || filter === 'closed' && terminal(m));
    return `<section class="studio-workspace"><div class="studio-page-heading"><div><span class="studio-kicker">STUDIO / MISSIONS</span><h1>Your work, in view<span>.</span></h1><p>What is moving forward. What needs your judgment.</p></div>${button('+ New mission', 'compose', !canWrite())}</div><div class="studio-overview"><div><strong>${missions.length}</strong><span>missions loaded${cursor ? ' · more available' : ''}</span></div><div><strong>${missions.filter(needsDecision).length}</strong><span>need a decision</span></div><div><strong>${missions.filter(m => m.state === 'running' && !m.held).length}</strong><span>in progress</span></div></div><div class="studio-filters" role="group" aria-label="Filter missions">${[['all', 'All missions'], ['decision', 'Need a decision'], ['running', 'In progress'], ['review', 'Result review'], ['closed', 'Closed']].map(([value, label]) => `<button type="button" data-filter="${value}" aria-pressed="${filter === value}">${label}</button>`).join('')}</div>${shown.length ? `<div class="studio-mission-grid">${shown.map(m => `<a class="studio-mission-card" data-mission="${e(m.id)}" href="${e(context.host.navigation.pageHref({ id: 'missions', params: { missionId: m.id } }))}"><div class="studio-card-meta"><span class="studio-state" data-state="${m.state}">${missionLabel(m)}</span><span>v${m.version}</span></div><h2>${e(m.title)}</h2><div class="studio-next"><span class="studio-kicker">NEXT STEP</span><p>${e(nextDecision(m))}</p></div><footer><span>${e(dateLabel(m.updatedAt))}</span><strong>Open mission ↗</strong></footer></a>`).join('')}</div>` : `<div class="studio-empty"><span class="studio-empty-mark">＋</span><h2>${missions.length ? 'No missions in this view.' : 'Make room for your first mission.'}</h2><p>${missions.length ? 'Choose another filter to see the rest of your work.' : 'Write the outcome, define the evidence, and choose who will carry the work forward.'}</p>${!missions.length ? button('Compose a mission', 'compose', !canWrite()) : ''}</div>`}${cursor ? `<div class="studio-load-more">${loadedPages < 10 ? button('Load more missions', 'more', refreshing || !connected(), true) : '<p class="studio-small">Showing the first 300 missions. Loaded missions stay live; use a mission link to open an older record.</p>'}</div>` : ''}</section>`;
  }
  function compose(): string {
    const targets = bootstrap?.targets ?? [];
    const select = (role: 'coordinator' | 'specialist'): string => `<label class="studio-field">${role === 'coordinator' ? 'Coordinator' : 'Specialist'}<select name="${role}" data-field="${role}" required ${pending ? 'disabled' : ''}><option value="">Choose a configured agent</option>${targets.map(t => `<option value="${e(targetKey(t))}" ${draft[role] === targetKey(t) ? 'selected' : ''}>${e(targetLabel(t))}</option>`).join('')}</select></label>`;
    return `<section class="studio-workspace"><div class="studio-page-heading"><div><span class="studio-kicker">${reviewDraft ? '02 / REVIEW THE PAPER' : '01 / A STARTING POINT'}</span><h1>${reviewDraft ? 'Before we begin' : 'It starts with an idea'}<span>.</span></h1><p>${reviewDraft ? 'Review the exact paper that will be stored. Approval and start come next.' : 'A clear outcome. A named team. Evidence you can judge.'}</p></div><span class="studio-draft-label">Not stored yet</span></div>${reviewDraft ? `<div class="studio-detail-layout">${paperMarkup(getPaper())}<aside class="studio-decision"><span class="studio-kicker">YOUR NEXT STEP</span><h2>Store this paper?</h2><p>The stored paper is immutable. Check the complete objective, criteria and runtime targets before creating it.</p><p>Creation does not approve or start work.</p>${button('Create mission', 'create', !canWrite())}${button('← Edit paper', 'edit-paper', !!pending, true)}</aside></div>` : `<form data-form="paper" class="studio-compose-layout"><div class="studio-paper studio-form-paper"><label class="studio-field">Mission name<input name="title" data-field="title" required maxlength="200" value="${e(draft.title)}" placeholder="A name for the outcome" ${pending ? 'disabled' : ''}></label><label class="studio-field">What do you want to achieve?<span>Include the outcome, scope and relevant context in the objective.</span><textarea name="objective" data-field="objective" required maxlength="8000" rows="8" placeholder="Describe the work and its boundaries…" ${pending ? 'disabled' : ''}>${e(draft.objective)}</textarea></label><label class="studio-field">How will you judge the result?<span>Describe the evidence you will inspect before accepting the work.</span><textarea name="acceptance" data-field="acceptance" required maxlength="4000" rows="5" placeholder="What must be true when this is done?" ${pending ? 'disabled' : ''}>${e(draft.acceptance)}</textarea></label></div><aside class="studio-decision"><span class="studio-kicker">PEOPLE FOR THIS MISSION</span><h2>Give the work a team.</h2><p>The coordinator delegates and verifies; the specialist delivers evidence.</p>${select('coordinator')}${select('specialist')}${!targets.length ? '<p role="alert">No runtime targets are configured on this authority.</p>' : ''}<button class="studio-button" type="submit" ${!canWrite() || !targets.length ? 'disabled' : ''}>Review the paper →</button><p class="studio-small">Your edits stay in this view until you create the mission. Leaving this page discards an unstored paper.</p></aside></form>`}</section>`;
  }
  function detail(): string {
    if (!view) return `<section class="studio-workspace studio-empty"><h1>Mission unavailable.</h1><p>Refresh this page or return to Missions to choose a stored paper.</p></section>`;
    const m = view.mission;
    const decisions = approver();
    const uncertain = view.dispatches.some(d => d.state === 'uncertain' || d.abortState === 'uncertain');
    return `<section class="studio-workspace"><div class="studio-page-heading"><div><span class="studio-kicker">MISSION / v${m.version}${stale ? ' · LAST KNOWN STATE' : ''}</span><h1>${e(m.paper.title)}<span>.</span></h1><p>${e(nextDecision(m, view.closeoutProgress))}</p></div><span class="studio-state studio-state--large" data-state="${m.state}">${missionLabel(m, view.closeoutProgress)}</span></div>${uncertain ? '<div class="studio-banner studio-banner--warning"><strong>A runtime outcome is uncertain.</strong> Its effect needs investigation. No completion or safe fresh dispatch can be inferred from this record.</div>' : ''}<div class="studio-detail-layout"><div class="studio-detail-main">${paperMarkup(m.paper)}<details class="studio-record" data-detail="paper-record"><summary data-focus="paper-record">Stored paper and decision records</summary><dl>${codeBlock('Mission ID', m.id)}${codeBlock('Paper SHA-256', m.paperDigest)}${codeBlock('Created', dateLabel(m.createdAt))}${m.approval ? codeBlock('Approved by', `${m.approval.profileId} · ${dateLabel(m.approval.at)}`) + codeBlock('Approved paper', m.approval.paperDigest) : ''}${m.verification ? codeBlock('Verified by', `${targetLabel(m.verification.actor)} · ${dateLabel(m.verification.at)}`) + codeBlock('Verified evidence', `${m.verification.evidenceRevision} · ${m.verification.evidenceHash}`) + codeBlock('Artifact read receipt', m.verification.assessment.readReceiptId) : ''}${m.closeoutGate ? codeBlock('Human gate resolved by', `${m.closeoutGate.profileId} · ${dateLabel(m.closeoutGate.at)}`) : ''}${m.closeout ? codeBlock('Closed by', `${targetLabel(m.closeout.actor)} · ${dateLabel(m.closeout.closedAt)}`) + codeBlock('Closed evidence', `${m.closeout.evidenceRevision} · ${m.closeout.evidenceHash}`) + codeBlock('Closeout policy SHA-256', m.closeout.policyDigest) : m.closeoutRequest ? codeBlock('Closeout requested by', `${targetLabel(m.closeoutRequest.actor)} · ${dateLabel(m.closeoutRequest.at)}`) : ''}${m.acknowledgement ? codeBlock('Acknowledged by', `${m.acknowledgement.profileId} · ${dateLabel(m.acknowledgement.at)}`) + codeBlock('Acknowledged evidence', `${m.acknowledgement.evidenceRevision} · ${m.acknowledgement.evidenceHash}`) : ''}${m.acceptance ? codeBlock('Accepted by', `${m.acceptance.profileId} · ${dateLabel(m.acceptance.at)}`) + codeBlock('Accepted evidence', m.acceptance.evidenceHash) + (m.acceptance.evidenceRevision ? codeBlock('Accepted revision', m.acceptance.evidenceRevision) : '') : ''}${m.cancellation ? codeBlock('Cancelled by', `${m.cancellation.profileId} · ${dateLabel(m.cancellation.at)}`) : ''}</dl>${m.cancellation ? textBlock('Cancellation reason', m.cancellation.reason) : ''}</details><section class="studio-activity" data-section="activity"><div class="studio-section-heading"><div><span class="studio-kicker">THE WORK</span><h2>Each handoff stays connected.</h2></div><span>Task: ${e(m.task.state)}</span></div><p class="studio-small">Runtime admission means a turn was accepted to run. Delivery, verification, coordinator closeout and human decisions are separate records.</p>${view.dispatches.length ? `<ol class="studio-dispatches">${view.dispatches.map((d, index) => `<li><span class="studio-step-number">${String(index + 1).padStart(2, '0')}</span><div><div class="studio-dispatch-top"><h3>${d.continuation ? (d.continuation.kind === 'resume' ? 'Assignment recovery' : d.continuation.kind === 'conversation' ? 'Coordinator response' : 'Coordinator continuation') : d.role === 'coordinator' ? 'Coordinator assignment' : 'Specialist assignment'}</h3><span class="studio-runtime-state ${d.state === 'uncertain' || d.state === 'rejected' ? 'studio-runtime-state--warning' : ''}">${dispatchLabel(d)}</span></div><p>${e(targetLabel(d))}</p>${d.reason ? `<p class="studio-prose">${e(d.reason)}</p>` : ''}${d.abortState ? `<p><strong>Abort: ${e(d.abortState)}</strong>${d.abortState !== 'done' ? ' · cancellation is not yet confirmed at the runtime' : ''}</p>` : ''}<details data-detail="runtime-${e(d.id)}"><summary data-focus="runtime-${e(d.id)}">Runtime receipt and binding</summary><dl>${codeBlock('Dispatch', d.id)}${codeBlock('Session key', d.sessionKey)}${d.sessionId ? codeBlock('Session ID', d.sessionId) : ''}${d.runId ? codeBlock('Run ID', d.runId) : ''}${d.continuation ? codeBlock('Continues assignment', d.continuation.assignmentId) + (d.continuation.kind === 'resume' ? codeBlock('Previous dispatch', d.continuation.predecessorDispatchId) + codeBlock('Previous run', d.continuation.predecessorRunId) : d.continuation.kind === 'conversation' ? codeBlock('Response request', d.continuation.responseId) + codeBlock('Source', `${d.continuation.source.kind} · ${d.continuation.source.id}`) : codeBlock('Evidence hash', d.continuation.evidenceHash) + (d.continuation.evidenceRevision ? codeBlock('Evidence revision', d.continuation.evidenceRevision) : '')) : ''}</dl></details></div></li>`).join('')}</ol>` : '<div class="studio-inline-empty">No runtime assignments have been created. Approving a paper does not start work.</div>'}</section>${evidenceMarkup(m, inspection, { progress: view.closeoutProgress, key: inspectionKey(), readable: canInspect(), decisions, reviewed: reviewedEvidence, selection: selectedEvidenceRevision, correctionDraft, correctionEligible: eligibleCorrection(), pending: !!pending })}</div><aside class="studio-decision"><span class="studio-kicker">YOUR DECISION</span><h2>${terminal(m) ? 'The outcome is recorded.' : m.state === 'draft' ? 'Ready to approve?' : m.state === 'approved' ? 'Ready to start?' : m.held ? 'Work is on hold.' : 'Keep the work in view.'}</h2><p>${terminal(m) ? 'The paper, runtime observations and decision records remain inspectable.' : m.state === 'draft' ? 'Approval authorizes this exact stored paper. It does not start the coordinator.' : m.state === 'approved' ? 'Starting creates the coordinator assignment for the approved paper.' : 'New activity is read from the authority. Refreshing this page does not send another instruction.'}</p>${!bootstrap?.capabilities.approver ? '<p class="studio-role-note">You are a Studio member. An approver makes lifecycle decisions and accepts results.</p>' : ''}${m.state === 'draft' ? button('Approve paper', 'approve', !decisions) : ''}${m.state === 'approved' ? button('Start mission', 'start', !decisions || m.held) : ''}${!terminal(m) ? `${button(m.held ? 'Resume mission' : 'Put on hold', m.held ? 'resume' : 'hold', !decisions || m.held && !!m.closeoutRequest, true)}${m.held && m.closeoutRequest ? '<p class="studio-small">This closeout is on hold. Reconcile the closing turn before resuming; cancellation remains available.</p>' : ''}<p class="studio-small">Holding pauses new dispatches. An already running turn may still finish and record evidence.</p>${button(cancelOpen ? 'Keep mission' : 'Cancel mission…', 'toggle-cancel', !decisions, true)}${cancelOpen ? `<form data-form="cancel" class="studio-cancel-form"><label class="studio-field">Why are you cancelling?<textarea data-field="cancelReason" required maxlength="2000" rows="4">${e(cancelReason)}</textarea></label><button class="studio-button studio-button--danger" type="submit" ${!decisions ? 'disabled' : ''}>Confirm cancellation</button><p class="studio-small">Assignments are revoked; inspect runtime abort receipts for confirmation.</p></form>` : ''}` : ''}<div class="studio-decision-version">Reviewing v${m.version}<br><span>${e(dateLabel(m.updatedAt))}</span></div></aside></div></section>`;
  }
  function render(): void {
    if (!active()) return;
    const focused = root.contains(document.activeElement) ? document.activeElement as HTMLElement : null;
    const focusType = ['data-field', 'data-action', 'data-focus', 'data-mission', 'data-nav', 'data-filter', 'data-space-role'].find(key => focused?.hasAttribute(key));
    const focusKey = focusType ? focused?.getAttribute(focusType) : null;
    const openDetails = new Set([...root.querySelectorAll<HTMLDetailsElement>('details[open][data-detail]')].map(el => el.dataset.detail));
    const selection = focused instanceof HTMLInputElement || focused instanceof HTMLTextAreaElement ? [focused.selectionStart, focused.selectionEnd] : null;
    const scroll = root.querySelector('.studio-workspace')?.scrollTop ?? 0;
    const artifactSource = root.querySelector<HTMLElement>('.studio-artifact-source');
    let content: string;
    if (loading && !bootstrap) content = '<section class="studio-workspace studio-empty" role="status"><div class="studio-loading-mark"></div><h1>Opening your workspace.</h1><p>Checking membership and loading the mission authority.</p></section>';
    else if (forbidden) content = '<section class="studio-workspace studio-empty"><h1>Studio access is required.</h1><p>Use a profile configured as a member on the authority Gateway. Bridge Gateways do not own mission records.</p></section>';
    else if (!bootstrap) content = `<section class="studio-workspace studio-empty"><h1>Your workspace is waiting.</h1><p>Connect to the Studio authority to read and operate missions.</p>${button('Try again', 'refresh', !connected(), true)}</section>`;
    else {
      try { content = composing ? compose() : selected ? detail() : board(); }
      catch { reviewDraft = false; content = compose(); }
    }
    const showSpace = !!bootstrap && !forbidden && !composing;
    const spaceFocus = focused && space?.element.contains(focused) ? focused : null;
    space?.setPresented(false);
    // Retain the owned viewport across data refreshes, keeping camera and keyboard focus intact.
    space?.element.remove();
    root.innerHTML = `${header()}<div class="studio-notices" aria-live="polite">${banners()}</div>${showSpace ? '<div data-studio-space-slot></div>' : ''}${content}<footer class="studio-footer"><span>STUDIO / MISSION AUTHORITY</span>${bootstrap ? `<span>${e(bootstrap.authorityId)} · ${e(bootstrap.gatewayId)}</span>` : ''}</footer>`;
    const newArtifactSource = root.querySelector<HTMLElement>('.studio-artifact-source');
    if (artifactSource && newArtifactSource && newArtifactSource.dataset.artifactKey === artifactSource.dataset.artifactKey) {
      newArtifactSource.replaceWith(artifactSource);
    }
    if (showSpace) {
      space ??= createStudioSpace(navigateSpace);
      root.querySelector('[data-studio-space-slot]')!.append(space.element);
      space.update(projectStudioSpace(missions, view, stale || !connected()));
      space.setPresented(context.presented && !document.hidden);
      if (spaceFocus?.isConnected) spaceFocus.focus({ preventScroll: true });
    }
    for (const detail of root.querySelectorAll<HTMLDetailsElement>('details[data-detail]')) detail.open = openDetails.has(detail.dataset.detail);
    if (focusKey && focusType) {
      const next = [...root.querySelectorAll<HTMLElement>(`[${focusType}]`)].find(el => el.getAttribute(focusType) === focusKey);
      next?.focus({ preventScroll: true });
      if (selection && (next instanceof HTMLTextAreaElement || next instanceof HTMLInputElement) && selection[0] !== null && selection[1] !== null) {
        try { next.setSelectionRange(selection[0]!, selection[1]!); } catch { /* Checkbox and select controls do not have text selection. */ }
      }
    }
    const workspace = root.querySelector('.studio-workspace'); if (workspace) workspace.scrollTop = scroll;
  }
  function focus(): void {
    const section = ['paper', 'activity', 'evidence'].includes(context.props.section ?? '') ? context.props.section : undefined;
    const heading = section ? root.querySelector<HTMLElement>(`[data-section="${section}"] h2`) ?? root.querySelector<HTMLElement>('h1') : root.querySelector<HTMLElement>('h1');
    if (heading) {
      heading.tabIndex = -1; heading.focus({ preventScroll: true });
      if (section) heading.scrollIntoView({ behavior: 'auto', block: 'start' });
    }
  }
  function onClick(event: MouseEvent): void {
    const target = event.target instanceof Element ? event.target.closest<HTMLElement>('[data-action],[data-mission],[data-nav],[data-filter]') : null;
    if (!target || !root.contains(target) || target instanceof HTMLButtonElement && target.disabled) return;
    if (target instanceof HTMLAnchorElement && (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)) return;
    if (target.dataset.mission) { event.preventDefault(); navigate({ missionId: target.dataset.mission }); return; }
    if (target.dataset.nav) { event.preventDefault(); navigate({}); return; }
    if (target.dataset.filter) { navigate({ filter: target.dataset.filter }); return; }
    switch (target.dataset.action) {
      case 'open-correction': openCorrection(); break;
      case 'send-correction': sendCorrection(); break;
      case 'edit-correction': if (correctionDraft && !pending) { correctionDraft.reviewing = false; render(); root.querySelector<HTMLTextAreaElement>('[data-field="correctionReason"]')?.focus(); } break;
      case 'discard-correction': if (!pending) { correctionDraft = undefined; render(); } break;
      case 'latest-evidence': selectedEvidenceRevision = ''; resetInspection(); render(); break;
      case 'inspect-evidence': void inspectEvidence(); break;
      case 'refresh': loadedPages = 1; void refresh(true); break;
      case 'more': void loadMore(); break;
      case 'compose': navigate({ compose: '1' }); break;
      case 'edit-paper': reviewDraft = false; render(); focus(); break;
      case 'create': if (reviewDraft) prepare({ type: 'create', commandId: uid(), missionId: uid(), expectedVersion: 0, paper: getPaper() }); break;
      case 'retry-command': void submit(); break;
      case 'review-current': if (!stale) { conflict = false; failure = ''; render(); } break;
      case 'toggle-cancel': cancelOpen = !cancelOpen; render(); root.querySelector<HTMLTextAreaElement>('[data-field="cancelReason"]')?.focus(); break;
      case 'approve': case 'start': case 'hold': case 'resume': case 'accept': case 'resolve-closeout-gate': case 'acknowledge': humanCommand(target.dataset.action); break;
    }
  }
  function onInput(event: Event): void {
    const el = event.target;
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement)) return;
    const field = el.dataset.field;
    if (field && Object.hasOwn(draft, field)) draft[field as keyof Draft] = el.value;
    if (field === 'cancelReason') cancelReason = el.value;
    if (field === 'correctionReason' && correctionDraft && !pending) { correctionDraft.reason = el.value; correctionDraft.reviewing = false; }
    if (field === 'evidenceRevision' && evidenceRevisions(view?.mission).some(item => item.revision === el.value)
      && selectedEvidenceRevision !== el.value) { selectedEvidenceRevision = el.value; resetInspection(); render(); }
    if (field === 'reviewedEvidence' && el instanceof HTMLInputElement) {
      reviewedEvidence = el.checked && contentReviewed();
      const accept = root.querySelector<HTMLButtonElement>('[data-action="accept"],[data-action="resolve-closeout-gate"],[data-action="acknowledge"]');
      if (accept) accept.disabled = !approver() || !contentReviewed() || !reviewedEvidence;
    }
  }
  function onSubmit(event: SubmitEvent): void {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || !root.contains(form)) return;
    event.preventDefault();
    if (!form.reportValidity()) return;
    if (form.dataset.form === 'paper') {
      if (!canWrite()) return;
      if (!draft.title.trim() || !draft.objective.trim() || !draft.acceptance.trim()) { failure = 'Give the paper a name, an objective and acceptance criteria before reviewing it.'; render(); return; }
      try { getPaper(); reviewDraft = true; render(); focus(); } catch { failure = 'Choose registered agents for both roles.'; render(); }
    } else if (form.dataset.form === 'correction') {
      if (!correctionDraft || !view || !eligibleCorrection() || !correctionDraft.reason.trim()
        || !correctionBaseMatches(correctionDraft, view.mission)) return;
      correctionDraft.baseVersion = view.mission.version; correctionDraft.reviewing = true; render();
      root.querySelector<HTMLButtonElement>('[data-action="send-correction"]')?.focus();
    } else if (form.dataset.form === 'cancel') humanCommand('cancel');
  }
  function onVisibility(): void {
    space?.setPresented(context.presented && !document.hidden && !composing);
    if (document.hidden) clearTimeout(timer); else if (context.presented) void refresh(false);
  }
  const unsubscribe = context.host.subscribe(() => {
    if (!active()) return;
    const now = connectionKey();
    if (now !== lastConnection) {
      lastConnection = now; epoch++; refreshing = false; resetInspection();
      if (!connected()) { stale = true; clearTimeout(timer); render(); }
      else void refresh(true);
    }
  });
  root.addEventListener('click', onClick);
  root.addEventListener('input', onInput);
  root.addEventListener('change', onInput);
  root.addEventListener('submit', onSubmit);
  document.addEventListener('visibilitychange', onVisibility);
  function dispose(): void {
    if (disposed) return;
    disposed = true; epoch++; commandEpoch++; resetInspection(); clearTimeout(timer); unsubscribe();
    space?.dispose(); space = undefined;
    initial.signal.removeEventListener('abort', dispose);
    document.removeEventListener('visibilitychange', onVisibility);
    root.removeEventListener('click', onClick); root.removeEventListener('input', onInput);
    root.removeEventListener('change', onInput); root.removeEventListener('submit', onSubmit);
    root.replaceChildren();
  }
  initial.signal.addEventListener('abort', dispose, { once: true });
  render(); void refresh(true);
  return {
    update(next) {
      const changed = selected !== (next.props.missionId ?? '') || composing !== (next.props.compose === '1');
      const destinationChanged = context.props.section !== next.props.section || context.props.filter !== next.props.filter;
      const shown = !context.presented && next.presented;
      context = next;
      filter = validFilter(next.props.filter);
      space?.setPresented(next.presented && !document.hidden && !composing);
      if (changed) {
        epoch++; selected = next.props.missionId ?? ''; composing = next.props.compose === '1';
        view = undefined; reviewDraft = false; draft = newDraft(); clearCorrection(); resetInspection();
        cancelReason = ''; cancelOpen = false; failure = ''; notice = ''; conflict = false; loadedPages = 1;
        void refresh(true).then(focus);
      } else if (shown) void refresh(false);
      else if (destinationChanged) { render(); focus(); }
      if (!next.presented) { epoch++; refreshing = false; resetInspection(); clearTimeout(timer); render(); }
    }, focus, dispose,
  };
}
