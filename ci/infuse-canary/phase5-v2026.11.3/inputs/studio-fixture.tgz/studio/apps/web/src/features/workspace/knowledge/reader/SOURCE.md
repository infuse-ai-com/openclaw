# Established KB reader provenance

Ported from knowledge-base `fe0600754f53a30b2dc6a3ad14384468493ac0be`.
Studio owns this integrated feature. The wire contract is in
`packages/contracts/src/knowledge.ts`. Existing components, typography, library,
search and reader behavior are retained. Router/API URLs and global theme effects
are adapted to the admitted Core workspace. History and review writes remain deferred; the original KB site remains available.

Explore modules are ported from KB main `3f5dc350476a0e036035f0b8a6df3cbb1ba83da2`.
The existing authored graph, semantic previews and zoom reader use Core read APIs.
Studio query parameters preserve Explore and zoom reading across reload/back.

C4 (14 October 2026) applies the selected native Studio option 2 layout. Studio
chrome, on-demand Sources/reading tools and one shared article surface replace
the nested Atlas shell. Catalog/tree/facets, search readiness/fallback, canonical
graph/semantic/zoom behavior and exact source evidence remain. See
`docs/plans/active/014-knowledge-integration/native-workspace.md`.
