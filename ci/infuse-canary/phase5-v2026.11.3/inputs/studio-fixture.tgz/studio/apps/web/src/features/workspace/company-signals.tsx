import { Button } from './ui.js';
import {useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {parseCompanySignalsView,providerUsageWindow,type CompanySignalView,type ProviderUsageData,type PipelineData,type PipelineBuild,type RuntimeObservation} from '@studio/contracts';
import {useWorkspace} from './context.js';
import {api} from './api.js';
import './company-signals.css';
const number=(value:number|null|undefined)=>value===null||value===undefined?'Unknown':new Intl.NumberFormat('en').format(value);
const money=(value:number|null|undefined)=>value===null||value===undefined?'Unknown':value>0&&value<0.01?'< $0.01':new Intl.NumberFormat('en',{style:'currency',currency:'USD'}).format(value);
const stamp=(value:string|null|undefined)=>value?new Date(value).toLocaleString():'Not recorded';
const names={runtime:'Runtime workload','provider-usage':'Provider usage',pipeline:'Pipeline attention'};
async function read(path:string,signal:AbortSignal){try{return {value:parseCompanySignalsView(await api(path,{signal}))};}catch(error){if(signal.aborted)throw error;return {unavailable:true} as const;}}
function Build({build}:{build:PipelineBuild}) {
 return <li><div><strong>Build {build.number}</strong><span>{build.status} · {build.result??'result unknown'}</span></div><p>{build.branch??'Branch not recorded'}</p><small>Queued {stamp(build.queuedAt)} · finished {stamp(build.finishedAt)}</small>{build.version&&<code>{build.version}</code>}</li>;
}
function Evidence({source,readAt,expanded}:{source:CompanySignalView;readAt:string;expanded:boolean}) {
 const input=source.input;if(!input)return <p>No observation is recorded for this source configuration.</p>;
 if(input.kind==='runtime'){
  const data=input.data as RuntimeObservation;
  if(expanded)return <div><strong>Deployment template image</strong><code>{data.image??'Not recorded'}</code><p>Template image/version describe deployment configuration. Readiness and restart counts describe the selected observed pods.</p></div>;
  return <><dl><div><dt>Ready / desired replicas</dt><dd>{data.readyReplicas} / {data.desiredReplicas}</dd></div><div><dt>Restarts in selected pods</dt><dd>{number(data.restarts)}</dd></div><div><dt>Template version</dt><dd>{data.version??'Unknown'}</dd></div></dl>{data.desiredReplicas===0&&<p>Deployment is configured with zero replicas.</p>}</>;
 }
 if(input.kind==='provider-usage') {
  const data=input.data as ProviderUsageData,window=providerUsageWindow(data,readAt);
  if(expanded)return <div><p>Up to 31 retained dates in the source calendar. Missing amounts stay unknown; costs are estimates for this declared usage scope.</p><div className="ws-company-signal-table" tabIndex={0} role="region" aria-label="Recorded provider dates"><table><thead><tr><th>Date</th><th>Tokens</th><th>Estimated USD</th><th>Incomplete requests</th></tr></thead><tbody>{data.days.map(day=><tr key={day.date}><th scope="row">{day.date}</th><td>{number(day.totalTokens)}</td><td>{money(day.costUsd)}</td><td>{number(day.incompleteRequests)}</td></tr>)}</tbody></table></div>{data.days.map(day=>!!day.models.length&&<details key={day.date}><summary>Models · {day.date}</summary><ul className="ws-company-models">{day.models.map(model=><li key={model.model}><strong>{model.model}</strong><span>{number(model.totalTokens)} tokens · {money(model.costUsd)} estimate{model.incompleteRequests?` · ${number(model.incompleteRequests)} incomplete requests`:''}</span></li>)}</ul></details>)}</div>;
  return <><p><strong>{data.provider}</strong> · scope owner: {data.owner}</p><dl><div><dt>Today · {data.bucketTimeZone??'timezone unknown'}</dt><dd>{number(window.today?.totalTokens)} tokens · {money(window.today?.costUsd)} estimate</dd></div><div><dt>{window.todayDate?'Seven calendar-day recorded subtotal':'Latest recorded dates subtotal'}</dt><dd>{number(window.tokensSubtotal)} tokens · {money(window.costSubtotal)} estimate</dd></div></dl><p>{window.recordedDays} recorded date{window.recordedDays===1?'':'s'} · {window.complete?'complete dated window':'partial or unconfirmed window'} · source history {data.coverage}</p>{!data.bucketTimeZone&&<p>Today cannot be determined without the source bucket timezone.</p>}</>;
 }
 const data=input.data as PipelineData,active=data.recent.filter(b=>['inProgress','notStarted','postponed','cancelling'].includes(b.status)),latest=data.completed[0];
 if(expanded)return <><h4>Recent queued builds</h4>{data.recent.length?<ul className="ws-company-builds">{data.recent.map(build=><Build key={build.id} build={build}/>)}</ul>:<p>No builds were returned in this window.</p>}<h4>Latest completed builds</h4>{data.completed.length?<ul className="ws-company-builds">{data.completed.map(build=><Build key={build.id} build={build}/>)}</ul>:<p>No completed builds were returned.</p>}</>;
 return <><dl><div><dt>Latest returned completed build</dt><dd>{latest?`${latest.number} · ${latest.result??'result unknown'}`:'No completed build returned'}</dd></div><div><dt>Active in recent queued window</dt><dd>{active.length} of {data.recent.length} returned builds</dd></div></dl><p>Up to ten recent queued and ten latest completed builds. {data.recentLimited||data.completedLimited?'Older work may fall outside these bounded windows.':'No continuation was reported for these reads.'} These windows do not establish a full-day failure count or deployment health.</p></>;
}

function Signal({source,readAt}:{source:CompanySignalView;readAt:string}) {
 const [expanded,setExpanded]=useState(false),def=source.definition;
 return <article className="ws-company-signal" aria-label={def.name}><header><div><span className="ws-eyebrow">{names[def.kind]}</span><h3>{def.name}</h3></div><span className="ws-company-source-state" data-state={source.state}>{source.state==='fresh'?'Fresh source read':source.state}</span></header>
  {source.state!=='fresh'&&source.input&&<p className="ws-company-retained">Retained evidence · the source is not currently confirmed fresh.</p>}
  {source.lastError&&<p className="ws-company-retained">{source.lastError==='SOURCE_GENERATION_MISSING'?'The latest feed has no generation time; the last dated observation is retained.':source.lastError==='OLDER_GENERATION_IGNORED'?'An older generation was ignored.':source.lastError==='RETAINED_IMPORT'?'Imported evidence awaits direct source qualification.':source.lastError==='SOURCE_MISSING'?'The configured source feed is missing.':source.lastError==='SOURCE_INVALID'?'The source could not be validated.':'The source is unavailable.'}</p>}
  <Evidence source={source} readAt={readAt} expanded={false}/>
  {source.input&&<details onToggle={event=>setExpanded(event.currentTarget.open)}><summary>Inspect operational evidence</summary>{expanded&&<Evidence source={source} readAt={readAt} expanded/>}</details>}
  <footer><span>Source generation {stamp(source.generatedAt)}</span><span>Observed {stamp(source.observedAt)} · last attempt {stamp(source.lastAttemptAt)}</span></footer>
 </article>;
}
export function CompanySignals({floor}:{floor:string}) {
 const {session,current,visible}=useWorkspace();
 const query=useQuery({queryKey:['workspace','company-signals',session.bootstrap.authorityId,session.profileId,floor],enabled:current,queryFn:({signal})=>read('/api/monitoring/signals'+(floor?'?'+new URLSearchParams({floor}):''),signal),refetchInterval:current&&visible?15000:false,gcTime:0});
 const data=current&&query.data&&'value' in query.data?query.data.value:undefined;
 return <section className="ws-company-signals" aria-label="Company operational evidence"><header><div><h2>Company operational evidence</h2><p>Infrastructure, pipeline and declared provider usage sources for these floors.</p></div><Button variant="quiet" disabled={!current||query.isFetching} onClick={()=>void query.refetch()}>Refresh operational data</Button></header>
  {!current?<p role="status">Reconnect to refresh operational evidence.</p>:query.isPending?<p role="status">Loading recorded operational evidence…</p>:!data?<p role="status">Operational evidence is unavailable. Previous private records are hidden.</p>:<><p>{data.collecting?'Company source collection enabled.':'Company source collection paused.'} Source freshness describes when evidence was produced; each card preserves its own operational meaning.</p>{!data.sources.length?<p>No company operational sources are admitted for these floors.</p>:<div className="ws-company-signal-grid">{data.sources.map(source=><Signal key={`${source.definition.sourceId}:${source.definition.specDigest}`} source={source} readAt={data.readAt}/>)}</div>}</>}
 </section>;
}
