import type { ComponentProps } from 'react';
import type { WhiteboardSection } from '@studio/contracts';
import type { WhiteboardCanvas } from './whiteboard-canvas.js';
import type { BlockNode } from './whiteboard-types.js';
import { alignWhiteboardDrag } from './whiteboard-alignment.js';
import { geometryUpdate } from './whiteboard-geometry.js';
import { intersects } from './whiteboard-spatial.js';
type DragContext = Pick<ComponentProps<typeof WhiteboardCanvas>,
  'flow' | 'viewport' | 'blocks' | 'sectionId' | 'setNodes' | 'setAlignmentGuides' | 'interacting' | 'presence' | 'commit'> & {
  canvasSize: { width: number; height: number };
};
/** Canvas alignment and destination hit-testing; commits still use the command owner. */
export function whiteboardDrag(context: DragContext) {
  const { flow, viewport, blocks, sectionId, canvasSize, setNodes, setAlignmentGuides, interacting, presence, commit } = context;
  function alignDrag(
    event: MouseEvent | TouchEvent,
    node: BlockNode,
    moved: BlockNode[],
    finished = false,
  ) {
    const camera = flow.current?.getViewport() ?? viewport;
    const moving = moved.map((item) => ({
      ...item.data.block,
      ...item.position,
    }));
    const candidates = blocks.filter((block) =>
      intersects({ ...block, sectionId }, camera, canvasSize),
    );
    const alignment = alignWhiteboardDrag(moving, candidates, camera.zoom, event.altKey);
    const positions = new Map(
      moved.map((item) => [
        item.id,
        {
          x: item.position.x + alignment.offset.x,
          y: item.position.y + alignment.offset.y,
        },
      ]),
    );
    setNodes((previous) =>
      previous.map((item) =>
        positions.has(item.id) ? { ...item, position: positions.get(item.id)! } : item,
      ),
    );
    setAlignmentGuides(finished ? [] : alignment.guides);
    if (finished) {
      interacting.current = false;
      presence.update({ drag: null });
      void commit(moved.map((item) => geometryUpdate(item.data.block, positions.get(item.id)!)));
    } else
      presence.update({
        drag: {
          blockId: node.id,
          ...positions.get(node.id)!,
          width: node.data.block.width,
          height: node.data.block.height,
        },
      });
  }
  function dragDestination(event: MouseEvent | TouchEvent, moved: BlockNode[]) {
    const point = 'touches' in event ? (event.touches[0] ?? event.changedTouches[0]) : event;
    if (!point) return null;
    const position = flow.current?.screenToFlowPosition({ x: point.clientX, y: point.clientY });
    if (!position) return null;
    return (
      blocks
        .filter(
          (block): block is WhiteboardSection =>
            block.kind === 'section' && !moved.some((n) => n.id === block.id),
        )
        .find(
          (block) =>
            position.x >= block.x &&
            position.x <= block.x + block.width &&
            position.y >= block.y &&
            position.y <= block.y + block.height,
        )?.id ?? null
    );
  }
  return { alignDrag, dragDestination };
}
