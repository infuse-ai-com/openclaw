import type { SidePanel } from './DocumentPanel';

interface TopBarProps {
  exploring: boolean;
  readerOnly?: boolean;
  home: boolean;
  onOpenHome: () => void;
  onOpenSearch: () => void;
  onToggleContext: () => void;
  onToggleSettings: () => void;
  onToggleInspect: () => void;
  onToggleExplore: () => void;
  onToggleLibrary: () => void;
  sidePanel: SidePanel;
}

type HeaderIconName =
  | 'close'
  | 'context'
  | 'explore'
  | 'inspect'
  | 'library'
  | 'search'
  | 'settings';

export function HeaderIcon({ name }: { name: HeaderIconName }) {
  const content = {
    close: <path d="M5 5l14 14M19 5 5 19" />,
    context: (
      <>
        <rect height="14" rx="2" width="18" x="3" y="5" />
        <path d="M14 5v14" />
      </>
    ),
    explore: (
      <>
        <circle cx="6" cy="7" r="2.25" />
        <circle cx="18" cy="6" r="2.25" />
        <circle cx="15" cy="18" r="2.25" />
        <circle cx="5" cy="17" r="2.25" />
        <path d="m8 7 7.75-.75M7.5 8.75l6 7.25M7 16.5l5.75 1" />
      </>
    ),
    inspect: (
      <>
        <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h7A2.5 2.5 0 0 1 16 5.5v7a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 4 12.5z" />
        <circle cx="10" cy="9" r="2.5" />
        <path d="m15 14 5 5" />
      </>
    ),
    library: (
      <>
        <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H11v17H6.5A2.5 2.5 0 0 0 4 21.5z" />
        <path d="M20 4.5A2.5 2.5 0 0 0 17.5 2H13v17h4.5a2.5 2.5 0 0 1 2.5 2.5z" />
      </>
    ),
    search: (
      <>
        <circle cx="10.5" cy="10.5" r="6.5" />
        <path d="m15.5 15.5 4.5 4.5" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.86 2.86-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21H9.55v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.86-2.86.06-.06A1.7 1.7 0 0 0 4.2 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2.4V9.55h.1A1.7 1.7 0 0 0 4.2 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06L6.66 3.8l.06.06A1.7 1.7 0 0 0 8.6 4.2a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1v-.1h4.05v.1a1.7 1.7 0 0 0 .95 1.7 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.86 2.86-.06.06A1.7 1.7 0 0 0 19.4 8.6a1.7 1.7 0 0 0 .6 1 1.7 1.7 0 0 0 1.1.4h.1v4.05h-.1a1.7 1.7 0 0 0-1.7.95Z" />
      </>
    ),
  }[name];

  return (
    <svg
      aria-hidden="true"
      className="header-icon"
      data-icon={name}
      fill="none"
      focusable="false"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.7"
      viewBox="0 0 24 24"
    >
      {content}
    </svg>
  );
}

export function TopBar({
  readerOnly = false,
  exploring,
  home,
  onOpenHome,
  onOpenSearch,
  onToggleContext,
  onToggleInspect,
  onToggleSettings,
  onToggleExplore,
  onToggleLibrary,
  sidePanel,
}: TopBarProps) {
  return (
    <header className="topbar" data-sheet-background>
      <button
        aria-current={home ? 'page' : undefined}
        aria-label="Open Library home"
        className="brand-lockup atlas-home-link"
        onClick={onOpenHome}
        type="button"
      >
        <img
          alt=""
          aria-hidden="true"
          className="brand-mark"
          height="38"
          src={new URL("../atlas-mark.svg", import.meta.url).href}
          width="38"
        />
        <div className="brand-copy">
          <strong>Knowledge Base</strong>
          <span className="product-kicker">Library Atlas</span>
        </div>
      </button>
      <button
        aria-haspopup="dialog"
        aria-keyshortcuts="Meta+K Control+K"
        aria-label="Search all documentation"
        className="command-search-trigger"
        onClick={onOpenSearch}
        title="Search all documentation (⌘K)"
        type="button"
      >
        <HeaderIcon name="search" />
        <kbd>⌘K</kbd>
      </button>
      <div className="reader-controls">
        <button
          className="mobile-library-toggle"
          onClick={onToggleLibrary}
          title="Library"
          type="button"
        >
          <HeaderIcon name="library" />
          <span className="sr-only">Library</span>
        </button>
        {!readerOnly && (<button
          aria-pressed={exploring}
          className="explore-toggle"
          onClick={onToggleExplore}
          title="Explore"
          type="button"
        >
          <HeaderIcon name="explore" />
          <span className="sr-only">Explore</span>
        </button>)}
        {!home && (
          <>
            <button
              aria-pressed={sidePanel === 'context'}
              className="context-toggle"
              onClick={onToggleContext}
              title="Context"
              type="button"
            >
              <HeaderIcon name="context" />
              <span className="sr-only">Context</span>
            </button>
            <button
              aria-pressed={sidePanel === 'inspect'}
              className="inspect-toggle"
              onClick={onToggleInspect}
              title="Inspect"
              type="button"
            >
              <HeaderIcon name="inspect" />
              <span className="sr-only">Inspect</span>
            </button>
          </>
        )}
        <button
          aria-pressed={sidePanel === 'settings'}
          className="settings-toggle"
          onClick={onToggleSettings}
          title="Settings"
          type="button"
        >
          <HeaderIcon name="settings" />
          <span className="sr-only">Settings</span>
        </button>
      </div>
    </header>
  );
}
