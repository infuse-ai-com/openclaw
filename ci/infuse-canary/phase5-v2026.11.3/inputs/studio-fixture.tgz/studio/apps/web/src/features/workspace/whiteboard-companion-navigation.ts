import { companionRevealIds } from './whiteboard-companion-layout.js';
import { useEffect, useRef, useState } from 'react';
import { readSectionManifest } from './whiteboard-spatial.js';
import type { useWhiteboardCamera } from './whiteboard-camera.js';
import type { WhiteboardSummary } from '@studio/contracts';
type Options = { path: string; projectId: string; sectionId: string; blocked: boolean;
  camera: ReturnType<typeof useWhiteboardCamera>; navigate(section: string): void; notify(message: string): void };
/** Explicit companion navigation reveals content without selecting it or opening an editor. */
export function useCompanionNavigation(options: Options) {
  const current = useRef(options); current.current = options;
  const request = useRef<AbortController | null>(null);
  const [destination, setDestination] = useState<{ section: string; source: string; items: WhiteboardSummary[]; ids: string[] } | null>(null);
  const [highlighted, setHighlighted] = useState<string[]>([]);
  useEffect(() => () => request.current?.abort(), []);
  useEffect(() => {
    if (!destination) return;
    if (options.blocked || ![destination.source, destination.section].includes(options.sectionId)) { setDestination(null); return; }
    if (options.sectionId !== destination.section) return;
    options.camera.fitBoard(destination.items.filter(item => item.kind !== 'connection'));
    setHighlighted(destination.ids); setDestination(null);
  }, [destination, options.sectionId, options.blocked]);
  useEffect(() => { if (!highlighted.length) return; const timer = setTimeout(() => setHighlighted([]), 3500); return () => clearTimeout(timer); }, [highlighted]);
  async function reveal(section: string, ids: string[] = []) {
    if (current.current.blocked) { options.notify('Finish saving your edit before navigating.'); return; }
    request.current?.abort(); const controller = new AbortController(); request.current = controller;
    const scope = current.current;
    try {
      const manifest = await readSectionManifest(scope.path, section, scope.projectId, controller.signal);
      if (controller.signal.aborted || current.current.blocked || current.current.projectId !== scope.projectId || current.current.sectionId !== scope.sectionId) return;
      const items = ids.length ? manifest.items.filter(item => ids.includes(item.id)) : manifest.items;
      if (ids.length && !items.length) { scope.notify('These items are no longer in this section.'); return; }
      if (ids.length > items.length) scope.notify('Showing remaining items; some were moved or deleted.');
      const revealIds = companionRevealIds(manifest.items, ids);
      const framing = ids.length ? manifest.items.filter(item => revealIds.includes(item.id)) : items;
      scope.camera.markFramed(section);
      setDestination({ section, source: scope.sectionId, items: framing, ids: revealIds });
      if (scope.sectionId !== section) scope.navigate(section);
    } catch { if (!controller.signal.aborted) scope.notify('This section is unavailable. It may have been removed or your access changed.'); }
  }
  return { reveal, highlighted };
}
