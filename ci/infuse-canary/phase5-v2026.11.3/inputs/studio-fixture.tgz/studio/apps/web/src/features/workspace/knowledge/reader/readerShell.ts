/** Established KB shell classes, extracted without importing deferred graph/diff views. */
export function appShellClassName(options: {
  contextMode: 'contents' | 'relationships' | 'history' | 'graph';
  diffOpen: boolean;
  focusReader: boolean;
  home: boolean;
  mobileLibrary: boolean;
}): string {
  return [
    'app-shell',
    options.focusReader ? 'focus-reader' : '',
    options.mobileLibrary ? 'mobile-library-open' : '',
    options.contextMode === 'graph' ? 'graph-workspace' : '',
    options.diffOpen ? 'diff-workspace' : '',
    options.home ? 'home-workspace' : '',
  ]
    .filter(Boolean)
    .join(' ');
}
