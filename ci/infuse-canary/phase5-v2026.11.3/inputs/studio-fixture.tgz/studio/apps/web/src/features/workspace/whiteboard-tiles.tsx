import { Button } from './ui.js';
import { LoadingState } from './loading.js';
import { useEffect,useRef,useState } from 'react';
import { createPortal } from 'react-dom';
import { useInfiniteQuery,useQuery } from '@tanstack/react-query';
import { type WhiteboardHtml,type WhiteboardSearch } from '@studio/contracts';
import { api,readableError,type SignedInSession } from './api.js';

function HtmlPreview({url,title,interactive}:{url:string;title:string;interactive:boolean}) {
  const [loaded,setLoaded]=useState(false);
  return <div className={'wboard-html-preview'+(interactive?' is-interactive nodrag nopan nowheel':'')}>
    {!loaded && <LoadingState label="Loading preview…" size="panel" />}
    <iframe title={title+' preview'} src={url+'/preview'} sandbox="allow-scripts" referrerPolicy="no-referrer" tabIndex={interactive?0:-1} onLoad={()=>setLoaded(true)} />
    {!interactive&&<div className="wboard-preview-shield" aria-hidden="true"/>}
  </div>;
}
function ExpandedHtml({url,title,close}:{url:string;title:string;close():void}) {
  const dialog=useRef<HTMLDialogElement>(null);const [interactive,setInteractive]=useState(false);
  useEffect(()=>{const previous=document.activeElement;dialog.current?.showModal();return()=>{if(previous instanceof HTMLElement&&previous.isConnected)previous.focus();};},[]);
  return createPortal(<dialog ref={dialog} className="wboard-expanded" aria-label={title+' expanded preview'} onCancel={event=>{event.preventDefault();close();}} onClose={close}>
    <header><div><h2>{title||'HTML artifact'}</h2><p>{interactive?'You can use the controls inside this HTML.':'Viewing the saved HTML. Choose Interact to use its controls.'}</p></div>
      <Button variant="quiet" type="button" aria-pressed={interactive} onClick={()=>setInteractive(v=>!v)}>{interactive?'Stop interacting':'Interact with HTML'}</Button>
      <Button variant="quiet" type="button" onClick={close} autoFocus>Return to board</Button>
    </header><HtmlPreview key={url} url={url} title={title} interactive={interactive}/>
  </dialog>,document.querySelector('.ws-whiteboard')??document.body);
}
export function HtmlTile({tile,path,enabled,active,canActivate,activate,engage,inspect}:{tile:WhiteboardHtml;path:string;enabled:boolean;active:boolean;canActivate:boolean;activate():void;engage(id:string,engaged:boolean):void;inspect():void}) {
  const [expanded,setExpanded]=useState(false),[interactive,setInteractive]=useState(false);
  useEffect(()=>{if(!active||!enabled){setExpanded(false);setInteractive(false);}},[active,enabled]);
  useEffect(()=>{engage(tile.id,active&&enabled&&(expanded||interactive));return()=>engage(tile.id,false);},[tile.id,active,enabled,expanded,interactive,engage]);
  const url=path+'/v3/tiles/'+encodeURIComponent(tile.id)+'/'+tile.revision;
  const status=useQuery({queryKey:['whiteboard-tile',url,active],gcTime:0,queryFn:({signal})=>api(url+'/status'+(active?'?verify=1':''),{signal}) as Promise<{status:'current'|'changed'}>,enabled,refetchInterval:enabled?15000:false,retry:false});
  useEffect(()=>{if(status.isError){setExpanded(false);setInteractive(false);}},[status.isError]);
  return <div className="wboard-html" onClick={event=>{if((event.target as Element).closest('button'))event.stopPropagation();}}>
    <header><div><span className="wboard-card-kind">HTML</span><h2>{tile.title || 'HTML artifact'}</h2></div><button type="button" className="nodrag nopan" aria-label="HTML properties" onClick={inspect}>•••</button></header>
    {!enabled?<p>Select or zoom in to inspect this source.</p>:status.isPending?<LoadingState label="Loading HTML source…" size="panel" />:status.isError?<p role="status">Source unavailable. {readableError(status.error)}</p>:<>
      {status.data?.status==='changed' && <p className="wboard-source-changed">A newer source exists. Viewing the saved version.</p>}
      {active?<><div className="wboard-preview-actions nodrag nopan"><button type="button" aria-pressed={interactive} onClick={()=>setInteractive(v=>!v)}>{interactive?'Stop interacting':'Interact with HTML'}</button><button type="button" onClick={()=>setExpanded(true)}>Expand preview</button></div>
        {expanded?<ExpandedHtml url={url} title={tile.title} close={()=>setExpanded(false)}/>:<HtmlPreview key={url} url={url} title={tile.title} interactive={interactive}/>}</>:<div className="wboard-html-cover"><span aria-hidden="true">&lt;/&gt;</span><p>Preview paused to keep the board responsive.</p><button type="button" className="nodrag nopan" disabled={!canActivate} title={canActivate?undefined:"Stop interacting with another block to show this preview."} onClick={activate}>Show preview</button></div>}
    </>}
  </div>;
}
export function sectionPath(sections:Array<{id:string;parentId:string|null;title:string}>,id:string) {
  const path:string[]=[],seen=new Set<string>();
  while(id&&!seen.has(id)){seen.add(id);const section=sections.find(s=>s.id===id);if(!section)break;path.unshift(section.title);id=section.parentId??'';}
  return path.length?path.join(' › '):id==='root'?'Whiteboard':'Section';
}
export function BoardSearch({path,session,sections,open}:{path:string;session:SignedInSession;sections:Array<{id:string;parentId:string|null;title:string}>;open(section:string,id:string):void}) {
  const [draft,setDraft]=useState(''),[term,setTerm]=useState('');
  const results=useInfiniteQuery({queryKey:['workspace',session.profileId,session.project.id,'whiteboard-search',term],gcTime:0,initialPageParam:undefined as {after:string;revision:number}|undefined,enabled:!!term,
    queryFn:({pageParam,signal})=>api(path+'/v3/search',{command:{query:term,...pageParam},csrf:session.csrfToken,signal}) as Promise<WhiteboardSearch>,getNextPageParam:last=>last.nextCursor?{after:last.nextCursor,revision:last.revision}:undefined,retry:false});
  return <div className="wboard-search"><form onSubmit={e=>{e.preventDefault();setTerm(draft.trim());}}><label>Search all sections<input className="ui-control" type="search" value={draft} maxLength={160} onChange={e=>setDraft(e.target.value)}/></label><Button type="submit" disabled={!draft.trim()}>Search</Button></form>
    {results.isError && <p role="alert">{readableError(results.error)} <Button variant="quiet" type="button" onClick={()=>void results.refetch()}>Refresh search</Button></p>}
    {term&&results.isFetching && <LoadingState label="Searching this board…" size={results.data ? 'inline' : 'panel'} />}
    <ul>{results.data?.pages.flatMap(p=>p.items).map(item=><li key={item.id}><Button variant="quiet" type="button" onClick={()=>open(item.sectionId,item.id)}>{'title' in item?item.title:item.kind}<small>{sectionPath(sections,item.sectionId)} · {item.excerpt}</small></Button></li>)}</ul>
    {term&&!results.isFetching&&!results.data?.pages.some(p=>p.items.length)&&!results.isError && <p>No matching blocks.</p>}
    {results.hasNextPage && <Button variant="quiet" type="button" disabled={results.isFetching} onClick={()=>void results.fetchNextPage()}>More results</Button>}
  </div>;
}
