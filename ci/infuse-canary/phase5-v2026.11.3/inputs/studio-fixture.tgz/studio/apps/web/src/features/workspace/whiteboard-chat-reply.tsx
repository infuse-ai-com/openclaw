import type { ReactNode } from 'react';
import { companionLink } from './whiteboard-chat-links.js';

type Props = { text: string; projectId: string; openLink(section: string, block?: string): void };
/** Deliberately small Markdown subset rendered as React nodes, never injected HTML. */
export function WhiteboardChatReply({ text, projectId, openLink }: Props) {
  function inline(source: string, depth = 0): ReactNode[] {
    if (depth > 2) return [source];
    const pattern = /(`[^`\n]+`|!\[[^\]\n]*\]\([^\s)]*\)|\[[^\]\n]+\]\([^\s)]+\)|\*\*[^*\n]+\*\*|\*[^*\n]+\*)/g;
    const parts: ReactNode[] = []; let start = 0;
    for (const match of source.matchAll(pattern)) {
      const token = match[0]; parts.push(source.slice(start, match.index)); start = match.index + token.length;
      const key = match.index;
      if (token.startsWith('`')) parts.push(<code key={key}>{token.slice(1, -1)}</code>);
      else if (token.startsWith('**')) parts.push(<strong key={key}>{inline(token.slice(2, -2), depth + 1)}</strong>);
      else if (token.startsWith('*')) parts.push(<em key={key}>{inline(token.slice(1, -1), depth + 1)}</em>);
      else if (token.startsWith('!')) parts.push(token);
      else {
        const split = token.indexOf(']('), label = token.slice(1, split), href = token.slice(split + 2, -1);
        const link = companionLink(href, window.location.origin, projectId);
        parts.push(link ? <a key={key} href={link.href} target={link.section ? undefined : '_blank'} rel="noopener noreferrer"
          onClick={event => { if (link.section && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) { event.preventDefault(); openLink(link.section, link.block); } }}>{inline(label, depth + 1)}</a> : label);
      }
    }
    parts.push(source.slice(start)); return parts;
  }
  const lines = text.split('\n'), result: ReactNode[] = [];
  for (let i = 0; i < lines.length;) {
    const key = i, line = lines[i]!;
    if (line.startsWith('```')) {
      const code: string[] = []; i++;
      while (i < lines.length && !lines[i]!.startsWith('```')) code.push(lines[i++]!);
      if (i < lines.length) i++;
      result.push(<pre key={key}><code>{code.join('\n')}</code></pre>);
    } else if (/^\s*(?:[-*] |\d+\. )/.test(line)) {
      const ordered = /^\s*\d+\. /.test(line), items: ReactNode[] = [], pattern = ordered ? /^\s*\d+\. / : /^\s*[-*] /;
      while (i < lines.length && pattern.test(lines[i]!)) { items.push(<li key={i}>{inline(lines[i++]!.replace(pattern, ''))}</li>); }
      result.push(ordered ? <ol key={key}>{items}</ol> : <ul key={key}>{items}</ul>);
    } else if (!line.trim()) i++;
    else { const paragraph: string[] = [line]; i++; while (i < lines.length && lines[i]!.trim() && !/^(?:```|\s*[-*] |\s*\d+\. )/.test(lines[i]!)) paragraph.push(lines[i++]!);
      result.push(<p key={key}>{inline(paragraph.join('\n'))}</p>); }
  }
  return <div className="wboard-chat-markdown">{result}</div>;
}
