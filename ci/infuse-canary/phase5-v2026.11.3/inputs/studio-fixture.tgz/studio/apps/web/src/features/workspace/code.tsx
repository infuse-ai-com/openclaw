import { EmptyState, PageHeader, Button } from './ui.js';
import { useEffect, useRef, useState } from 'react';
import { z } from 'zod';
import { useWorkspace } from './context.js';
import { api, readableError } from './api.js';
import { Link } from './navigation.js';
import './code.css';

const searchResult = z.object({ isSearchExhaustive: z.boolean(), files: z.array(z.object({
  repository: z.string().max(512), fileName: z.object({ text: z.string().max(4096) }),
  chunks: z.array(z.object({ content: z.string().max(200000), contentStart: z.object({ lineNumber: z.number().int() }) })).max(1000),
})).max(1000) });
const fileResult = z.object({ repo: z.string(), path: z.string(), source: z.string().max(4 * 1024 * 1024) });
type SearchResult = z.infer<typeof searchResult>;

export function CodeWorkspace() {
  const { owner, session, current } = useWorkspace();
  return <FloorCode key={`${owner}:${session.knowledgeScope?.revision ?? 'unset'}`} current={current} />;
}
function FloorCode({ current }: { current: boolean }) {
  const { session } = useWorkspace();
  const [query, setQuery] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const [result, setResult] = useState<SearchResult | null>(null), [file, setFile] = useState<z.infer<typeof fileResult> | null>(null);
  const request = useRef<AbortController | null>(null), expiry = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const revision = session.knowledgeScope?.revision;
  const base = `/api/projects/${encodeURIComponent(session.project.id)}/studio/code/`;
  useEffect(() => { if (!current) { request.current?.abort(); setResult(null); setFile(null); } }, [current]);
  useEffect(() => () => { request.current?.abort(); clearTimeout(expiry.current); }, []);
  function begin() { request.current?.abort(); clearTimeout(expiry.current); const controller = new AbortController(); request.current = controller;
    setBusy(true); setError(''); setFile(null); return controller; }
  function expires() { expiry.current = setTimeout(() => { setResult(null); setFile(null); setError('Results expired. Search again to refresh this floor’s code.'); }, 15000); }
  async function search() {
    if (!current || !revision || !query.trim()) return;
    const controller = begin(); setResult(null);
    try {
      const value = searchResult.parse(await api(`${base}search?floorRevision=${revision}`, { signal: controller.signal,
        command: { query: query.trim(), matches: 100, contextLines: 2, isRegexEnabled: false, isCaseSensitivityEnabled: false }, csrf: session.csrfToken }));
      if (!controller.signal.aborted) { setResult(value); expires(); }
    } catch (failure) { if (!controller.signal.aborted) { setResult(null); setError(readableError(failure)); } }
    finally { if (!controller.signal.aborted) setBusy(false); }
  }
  async function read(repository: string, path: string) {
    if (!current || !revision) return;
    const controller = begin();
    try {
      const params = new URLSearchParams({ repo: repository, path, ref: 'HEAD', floorRevision: String(revision) });
      const value = fileResult.parse(await api(`${base}source?${params}`, { signal: controller.signal }));
      if (value.repo !== repository || value.path !== path) throw Error('The returned file does not match the selected result.');
      if (!controller.signal.aborted) { setFile(value); expires(); }
    } catch (failure) { if (!controller.signal.aborted) { setResult(null); setFile(null); setError(readableError(failure)); } }
    finally { if (!controller.signal.aborted) setBusy(false); }
  }
  return <section className="ws-surface ws-code ui-layout-list"><PageHeader eyebrow={<>{session.project.name} / REPOSITORIES</>} title={<>Code</>} description={<>Search code enabled in repositories attached to {session.project.name}.</>} />
    <div className="ws-code-content ui-page-content">
    {!revision ? <EmptyState level={3} title={<>Choose repositories first.</>} actions={<>{session.canManageFloors && <Link className="ws-text-link" to="/floors">Manage repositories →</Link>}</>}>Code search uses the repositories attached to this floor.</EmptyState> :
      <form className="ws-code-search" onSubmit={event => { event.preventDefault(); void search(); }}><label className="ws-field">Search floor code<input type="search" placeholder="Find a symbol, function or phrase" value={query} maxLength={2048} disabled={!current} onChange={event => setQuery(event.target.value)} /></label>
        <Button type="submit" disabled={!current || busy || !query.trim()}>{busy ? 'Loading…' : 'Search'}</Button></form>}
    {!current && <p role="status">Reconnect before reading floor code.</p>}
    {error && <p role="alert" className="ws-alert">{error}</p>}
    {current && result && <div className="ws-code-results" aria-live="polite"><p>{result.files.length ? `${result.files.length} files returned.` : 'No matches in the available floor index.'} {!result.isSearchExhaustive && 'More matches may exist; narrow the search.'}</p>
      {result.files.map(row => <article key={`${row.repository}:${row.fileName.text}`}><h2><Button variant="quiet" disabled={busy} onClick={() => void read(row.repository, row.fileName.text)}>{row.fileName.text}</Button></h2>
        <p>{row.repository}</p>{row.chunks.map((chunk, index) => <pre tabIndex={0} aria-label={`Code excerpt starting at line ${chunk.contentStart.lineNumber}`} key={index}><code>{`Line ${chunk.contentStart.lineNumber}\n${chunk.content}`}</code></pre>)}</article>)}</div>}
    {current && file && <article className="ws-code-file" aria-label="Selected code file"><h2>{file.path}</h2><p>{file.repo} · local default-branch clone</p><pre tabIndex={0} aria-label="File contents"><code>{file.source}</code></pre></article>}
    </div>
  </section>;
}
