import type { CharacterAppearance } from '@studio/spatial/character';
import type { MissionSummary, MissionView, RuntimeTarget } from '@studio/contracts';
import { coordinatorCloseout, dispatchLabel, gatePending, missionLabel } from './presentation.js';

export type SpatialDestination = 'missions' | 'paper' | 'activity' | 'evidence';
export interface SpatialAgent {
  key?: string; name?: string; running?: boolean;
  assigned?: boolean; seat?: number; appearance?: CharacterAppearance;
  role: 'coordinator' | 'specialist';
  target: RuntimeTarget;
  status: string;
  tone: 'quiet' | 'admitted' | 'evidence' | 'uncertain';
}
export interface SpatialProjection {
  missionId?: string;
  title: string;
  subtitle: string;
  missionCount: number;
  reviewCount: number;
  paperCount: number;
  evidencePresent: boolean;
  stale: boolean;
  agents: SpatialAgent[];
}

/** This projection never turns runtime admission into an assertion of active work. */
export function projectStudioSpace(missions: MissionSummary[], view: MissionView | undefined, stale: boolean): SpatialProjection {
  if (!view) return {
    title: 'Your Studio workspace', subtitle: 'A place for the work and the decisions it needs.',
    missionCount: missions.length,
    reviewCount: missions.filter(m => m.taskState === 'verified' && m.state === 'running' && (!coordinatorCloseout(m) || gatePending(m))).length,
    paperCount: missions.length, evidencePresent: missions.some(m => ['delivered', 'verified'].includes(m.taskState)),
    stale, agents: [],
  };
  const m = view.mission;
  const agents: SpatialAgent[] = (['coordinator', 'specialist'] as const).map(role => {
    const assignment = m.assignments[role];
    const binding = view.dispatches.find(d => d.id === assignment?.dispatchId && !d.continuation);
    const turns = binding ? view.dispatches.filter(d => d.id === binding.id || d.continuation?.assignmentId === binding.id) : [];
    const latest = turns.at(-1);
    const uncertain = turns.some(d => d.state === 'uncertain' || d.abortState === 'uncertain');
    let status = latest ? dispatchLabel(latest) : 'Named in the paper · not assigned';
    let tone: SpatialAgent['tone'] = latest?.state === 'accepted' ? 'admitted' : 'quiet';
    if (role === 'specialist' && ['delivered', 'verified'].includes(m.task.state)) { status = 'Evidence delivered'; tone = 'evidence'; }
    if (role === 'coordinator' && m.task.state === 'verified') { status = 'Evidence verified'; tone = 'evidence'; }
    if (m.state === 'cancelled') {
      // A later continuation's abort receipt cannot settle an earlier admitted turn.
      const allAborted = turns.length > 0 && turns.every(turn => turn.abortState === 'done');
      status = allAborted ? 'Cancelled · recorded runtime aborts confirmed' : 'Cancelled · inspect runtime receipts'; tone = 'quiet';
    }
    if (uncertain) { status = 'Runtime outcome uncertain'; tone = 'uncertain'; }
    if (stale) status = `Last known: ${status.toLowerCase()}`;
    return { role, target: m.paper[role], status, tone };
  });
  return {
    missionId: m.id, title: m.paper.title, subtitle: `${missionLabel(m, view.closeoutProgress)} · version ${m.version}`,
    missionCount: 1, reviewCount: m.task.state === 'verified' && m.state === 'running' && (!coordinatorCloseout(m) || gatePending(m)) ? 1 : 0,
    paperCount: 1, evidencePresent: !!m.task.evidence || !!m.correction, stale, agents,
  };
}
