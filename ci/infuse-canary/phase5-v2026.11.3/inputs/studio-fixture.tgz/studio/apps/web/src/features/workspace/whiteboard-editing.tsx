import { useEffect, useRef } from 'react';
import { NoteTextFit } from './whiteboard-note-fit.js';
import { icons } from '@studio/ui/icons';
import type { WhiteboardBlock } from '@studio/contracts';
import { SharedBodyEditor, type SharedBodyOptions } from './whiteboard-text.js';
import { editDraft, rebaseDraft, draftOperation, saveDraft, type Draft, type DraftCommit as Commit } from './whiteboard-drafts.js';
export { settleDrafts } from './whiteboard-drafts.js';
export type { Draft } from './whiteboard-drafts.js';

/** The queue belongs to the board, so closing an editor never drops a save. */
export function useDraftAutosave(drafts:Map<string,Draft>,version:number,enabled:boolean,sectionId:string,shared:boolean,commit:Commit,changed:()=>void) {
  const latest=useRef({commit,changed});latest.current={commit,changed};
  useEffect(()=> {
    if(!enabled)return;
    const draft=[...drafts.values()].find(d=>d.dirty&&!d.blocked&&d.sectionId===sectionId&&draftOperation(d,shared));
    if(!draft)return;
    const timer=setTimeout(()=>void saveDraft(draft.block.id,drafts,shared,latest.current.commit,latest.current.changed),500);
    return()=>clearTimeout(timer);
  },[drafts,version,enabled,sectionId,shared]);
}
export function BlockEditor({seed,saved,enabled,canSave,commit,drafts,onDraftChange,mode='document',options,shared,sectionId,autoFocus=false}:{
  seed:WhiteboardBlock;saved?:WhiteboardBlock;enabled:boolean;canSave:boolean;commit:Commit;drafts:Map<string,Draft>;onDraftChange():void;
  mode?:'inline'|'document';options?():void;shared?:SharedBodyOptions;sectionId:string;autoFocus?:boolean;
}) {
  const cached=drafts.get(seed.id),draft=(cached?.dirty?cached.block:saved??seed) as WhiteboardBlock;
  const dirty=cached?.dirty??false,blocked=cached?.blocked??false;
  function edit(values:Partial<WhiteboardBlock>) {
    editDraft(drafts,saved??seed,values,sectionId,!!shared);onDraftChange();
  }
  const fitNote=mode==='inline'&&seed.kind==='note';
  const body=<textarea id={'wboard-text-'+seed.id} disabled={!enabled} value={draft.text} maxLength={12000} placeholder="Write a thought…" onChange={e=>edit({text:e.target.value})} autoFocus={autoFocus} rows={4}/>;
  function useSaved(){if(saved){drafts.delete(seed.id);onDraftChange();}}
  return <form className={'wboard-editor'+(mode==='inline'?' wboard-inline-editor nodrag nopan nowheel':'')}
    onClick={event=>event.stopPropagation()} onSubmit={event=>{event.preventDefault();if(canSave)void saveDraft(seed.id,drafts,!!shared,commit,onDraftChange);}}>
    {blocked&&<div role="alert">Your draft is kept. Check the saved version before trying again.
      {saved&&<button type="button" onClick={useSaved}>Use saved version</button>}
      <button type="button" disabled={!canSave} onClick={()=>{if(cached){drafts.set(seed.id,rebaseDraft(cached,saved??cached.base,!!shared));onDraftChange();}}}>Save my version</button>
    </div>}
    {!saved&&<p role="alert">This block moved or was deleted. Your draft is still here.</p>}
    <>
      <label htmlFor={'wboard-title-'+seed.id} className={mode==='inline'?'wboard-sr-only':undefined}>Block title</label>
      <input id={'wboard-title-'+seed.id} disabled={!enabled} value={draft.title} placeholder="Untitled note" maxLength={160} onChange={e=>edit({title:e.target.value})}/>
      {shared?<SharedBodyEditor blockId={seed.id} options={shared} enabled={shared.enabled} autoFocus={autoFocus} fitNote={fitNote}/>:<>
        <label className={mode==='inline'?'wboard-sr-only':undefined} htmlFor={'wboard-text-'+seed.id}>Block text</label>
        {fitNote?<NoteTextFit text={draft.text||"Write a thought…"}>{body}</NoteTextFit>:body}
      </>}
    </>
    <div className={mode==='inline'?'wboard-note-actions':'wboard-actions'}>
      <small data-quiet={fitNote&&!dirty&&!blocked||undefined} aria-live="polite">{blocked?'Needs attention':dirty?'Saving…':shared?'Title saved':'All changes saved'}</small>
      {mode==='inline'&&<button type="button" className="wboard-note-options" aria-label="Block options" title="Position and connections" onClick={options}><span className="wboard-icon" aria-hidden="true" dangerouslySetInnerHTML={{__html:icons.more}}/></button>}
    </div>
    {dirty&&cached&&saved&&cached.base.revision!==saved.revision&&<details><summary>Saved version</summary><strong>{saved.title}</strong><pre>{saved.text}</pre></details>}
  </form>;
}
