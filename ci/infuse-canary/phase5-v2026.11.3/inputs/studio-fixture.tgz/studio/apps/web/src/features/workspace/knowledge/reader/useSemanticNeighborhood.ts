import { useEffect, useRef, useState } from 'react';
import type { GraphNode, SemanticNeighborhoodResponse } from '@studio/contracts/knowledge';
import { useKnowledgeApi } from './api';

export function useSemanticNeighborhood(
  visibleNodes: readonly GraphNode[],
  focusId: string | undefined,
) {
  const { projectId, scopeRevision, loadSemanticNeighborhood } = useKnowledgeApi();
  const [response, setResponse] = useState<SemanticNeighborhoodResponse>();
  const [loading, setLoading] = useState(false);
  const [activeNodeIds, setActiveNodeIds] = useState<Set<string>>();
  const cacheRef = useRef(new Map<string, SemanticNeighborhoodResponse>());
  const requestRef = useRef(0);

  useEffect(() => {
    if (!focusId) {
      setResponse(undefined);
      return;
    }
    const focus = visibleNodes.find((node) => node.id === focusId);
    if (!focus) {
      setResponse(undefined);
      setActiveNodeIds(undefined);
      return;
    }
    const candidates = visibleNodes.map((node) => ({
      repository: node.repository,
      path: node.path,
    }));
    const scopeKey = visibleNodes
      .map((node) => `${node.id}@${node.provenance.commit}`)
      .slice()
      .sort((left, right) => left.localeCompare(right, 'en'))
      .join('\u0001');
    const cacheKey = `${projectId}:${scopeRevision ?? "legacy"}\u0000${focus.id}\u0000${scopeKey}`;
    const cached = cacheRef.current.get(cacheKey);
    if (cached) {
      setResponse(cached);
      setLoading(false);
      return;
    }
    setResponse(undefined);
    const controller = new AbortController();
    const requestId = requestRef.current + 1;
    requestRef.current = requestId;
    const timer = globalThis.setTimeout(() => {
      setLoading(true);
      void loadSemanticNeighborhood(
        {
          focus: { repository: focus.repository, path: focus.path },
          repositories: [
            ...new Set(visibleNodes.map((node) => node.repository)),
          ],
          candidates,
          limit: 5,
        },
        controller.signal,
      )
        .then((next) => {
          if (requestRef.current !== requestId) return;
          if (cacheRef.current.size >= 64) {
            const oldest = cacheRef.current.keys().next().value;
            if (oldest) cacheRef.current.delete(oldest);
          }
          cacheRef.current.set(cacheKey, next);
          setResponse(next);
        })
        .catch((error: unknown) => {
          if (
            requestRef.current === requestId &&
            !(error instanceof DOMException && error.name === 'AbortError')
          ) {
            setResponse(undefined);
          }
        })
        .finally(() => {
          if (requestRef.current === requestId) setLoading(false);
        });
    }, 300);
    return () => {
      if (requestRef.current === requestId) requestRef.current += 1;
      globalThis.clearTimeout(timer);
      controller.abort();
    };
  }, [focusId, visibleNodes, projectId, scopeRevision, loadSemanticNeighborhood]);

  return {
    activeNodeIds,
    clear: () => setActiveNodeIds(undefined),
    loading,
    response,
    show: (nodeIds: Set<string>) => setActiveNodeIds(nodeIds),
  };
}
