import { IconButton, Toolbar } from './ui.js';
import { useLayoutEffect, useRef, useState } from 'react';
import type { WhiteboardBlock } from '@studio/contracts';
import { BoardIcon } from './whiteboard-icon.js';
import { LockIcon } from './whiteboard-selection-menu.js';
import { NoteColors } from './whiteboard-colors.js';
import type { BoardCamera } from './whiteboard-section-zoom.js';
import type { BlockNode, BoardPanel } from './whiteboard-types.js';

export type SelectionToolbarProps = {
  nodes: BlockNode[];
  viewport: BoardCamera;
  canvasSize: { width: number; height: number };
  selection: string[];
  enabled: boolean;
  hasDraft: boolean;
  copySelection: (ids?: string[]) => Promise<void>;
  fitSelection: () => void;
  selectionLocks: string[];
  lockReason: string;
  setSelectionLocked: (ids: string[], locked: boolean) => Promise<void>;
  sectionSelectionReason: (ids: string[]) => string;
  groupSelection: (ids?: string[]) => Promise<void>;
  selectionAction: (action: 'duplicate' | 'delete') => Promise<void>;
  colorNotes: (color: NonNullable<WhiteboardBlock['noteColor']>) => Promise<void>;
  setAutoFocusId: (id: string | null) => void;
  openPanel: (next: BoardPanel) => void;
};

/** Selection chrome uses live node geometry, never persisted camera or item coordinates. */
export function SelectionToolbar({
  nodes,
  viewport,
  canvasSize,
  selection,
  enabled,
  hasDraft,
  copySelection,
  fitSelection,
  selectionLocks,
  lockReason,
  setSelectionLocked,
  sectionSelectionReason,
  groupSelection,
  selectionAction,
  colorNotes,
  setAutoFocusId,
  openPanel,
}: SelectionToolbarProps) {
  const element = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const selected = nodes.filter((node) => selection.includes(node.id) && !node.hidden);
  const left = Math.min(...selected.map((node) => node.position.x)) * viewport.zoom + viewport.x;
  const top = Math.min(...selected.map((node) => node.position.y)) * viewport.zoom + viewport.y;
  const right =
    Math.max(
      ...selected.map(
        (node) => node.position.x + (node.measured?.width ?? node.width ?? node.data.block.width),
      ),
    ) *
      viewport.zoom +
    viewport.x;
  const bottom =
    Math.max(
      ...selected.map(
        (node) =>
          node.position.y + (node.measured?.height ?? node.height ?? node.data.block.height),
      ),
    ) *
      viewport.zoom +
    viewport.y;
  const visible =
    selected.length > 0 &&
    right > 0 &&
    bottom > 0 &&
    left < canvasSize.width &&
    top < canvasSize.height;
  useLayoutEffect(() => {
    const bar = element.current;
    if (!bar) return;
    const measure = () => {
      const { width, height } = bar.getBoundingClientRect();
      setSize((previous) =>
        previous.width === width && previous.height === height ? previous : { width, height },
      );
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(bar);
    return () => observer.disconnect();
  }, [visible]);
  if (!visible) return null;

  const notes = selected
    .map((node) => node.data.block)
    .filter((item): item is WhiteboardBlock => item.kind === 'note');
  const colors = new Set(notes.map((note) => note.noteColor ?? 'yellow'));
  const color = colors.size === 1 ? (notes[0]?.noteColor ?? 'yellow') : undefined;
  const margin = 12,
    gap = 8;
  // Keep controls outside the fixed header/dock; flip below a note near the upper edge.
  const minY = Math.min(
    canvasSize.width <= 640 ? 156 : 116,
    Math.max(margin, canvasSize.height - size.height - margin),
  );
  const maxY = Math.max(
    minY,
    canvasSize.height - (canvasSize.width <= 900 ? 142 : 82) - size.height,
  );
  const above = top - size.height - gap;
  const y = Math.max(minY, Math.min(maxY, above >= minY ? above : bottom + gap));
  const x = Math.max(
    margin,
    Math.min(canvasSize.width - size.width - margin, (left + right - size.width) / 2),
  );
  const groupReason = sectionSelectionReason(selection);
  return (
    <Toolbar
      ref={element}
      className="wboard-selection-tools wboard-float"

      aria-label="Selected blocks"
      style={{ left: x, top: y, visibility: size.width ? 'visible' : 'hidden' }}
    >
      {selection.length > 1 && (
        <span className="wboard-selection-count">{selection.length} selected</span>
      )}
      {notes.length > 0 && (
        <>
          <NoteColors
            compact
            value={color}
            disabled={!enabled || hasDraft}
            choose={(next) => void colorNotes(next)}
          />
          <span className="wboard-divider" aria-hidden="true" />
        </>
      )}
      <IconButton
        className="wboard-tool"
        aria-label="Copy selection"
        title="Copy (⌘/Ctrl C)"
        disabled={!enabled || hasDraft}
        onClick={() => void copySelection()}
      >
        <BoardIcon name="copy" />
      </IconButton>
      {selection.length > 1 && (
        <IconButton
          className="wboard-tool"
          aria-label="Arrange selection"
          title="Align, distribute and size"
          onClick={() => {
            setAutoFocusId(null);
            openPanel('arrange');
          }}
        >
          <BoardIcon name="list" />
        </IconButton>
      )}
      <IconButton
        className="wboard-tool"
        aria-label="Fit selection"
        title="Fit selection"
        onClick={fitSelection}
      >
        <BoardIcon name="search" />
      </IconButton>
      <IconButton
        className="wboard-tool"
        aria-label={selectionLocks.length ? 'Unlock selection' : 'Lock selection'}
        title={lockReason || (selectionLocks.length ? 'Unlock selection' : 'Lock in place')}
        disabled={!!lockReason}
        onClick={() => void setSelectionLocked(selection, selectionLocks.length === 0)}
      >
        <LockIcon open={selectionLocks.length > 0} />
      </IconButton>
      <IconButton
        className="wboard-tool"
        aria-label="Create section from selection"
        title={groupReason || 'Create section from selection'}
        disabled={!!groupReason}
        onClick={() => void groupSelection()}
      >
        <BoardIcon name="board" />
      </IconButton>
      <IconButton
        className="wboard-tool"
        aria-label="Duplicate selection"
        title="Duplicate (⌘/Ctrl D)"
        disabled={!enabled || hasDraft}
        onClick={() => void selectionAction('duplicate')}
      >
        <BoardIcon name="copy" />
      </IconButton>
      <IconButton
        className="wboard-tool"
        aria-label="Delete selection"
        title="Delete selection"
        disabled={!enabled || hasDraft}
        onClick={() => void selectionAction('delete')}
      >
        <BoardIcon name="trash" />
      </IconButton>
    </Toolbar>
  );
}
