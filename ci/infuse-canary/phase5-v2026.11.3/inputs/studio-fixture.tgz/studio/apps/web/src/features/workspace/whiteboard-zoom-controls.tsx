import { IconButton, Toolbar, Button } from './ui.js';
import { type ReactFlowInstance } from '@xyflow/react';
import { BoardIcon } from './whiteboard-icon.js';
import { useWhiteboardSectionZoom } from './whiteboard-section-navigation.js';
import { useSectionTransition } from './whiteboard-section-transition.js';
import { whiteboardMaxZoom, type BoardCamera } from './whiteboard-section-zoom.js';
import type { BlockNode } from './whiteboard-types.js';

import type * as React from 'react';

type Props = {
  setFollowing: React.Dispatch<React.SetStateAction<string | null>>;
  transition: ReturnType<typeof useSectionTransition>;
  zoom: number;
  sectionId: string;
  flow: React.RefObject<ReactFlowInstance<BlockNode> | null>;
  zoomNavigation: ReturnType<typeof useWhiteboardSectionZoom>;
  setPreviousView: React.Dispatch<
    React.SetStateAction<({ sectionId: string } & BoardCamera) | null>
  >;
  viewport: BoardCamera;
  fitBoard: (remember?: boolean) => void;
  previousView: ({ sectionId: string } & BoardCamera) | null;
};
export function WhiteboardZoomControls({
  setFollowing,
  transition,
  zoom,
  sectionId,
  flow,
  zoomNavigation,
  setPreviousView,
  viewport,
  fitBoard,
  previousView,
}: Props) {
  return (
    <>
      <Toolbar
        className="wboard-zoom wboard-float"

        aria-label="Canvas zoom"
        onClickCapture={() => setFollowing(null)}
      >
        <IconButton
          className="wboard-tool"
          aria-label="Zoom out"
          title="Zoom out"
          disabled={transition.active || (zoom <= 0.1 && sectionId === 'root')}
          onClick={async () => {
            const instance = flow.current;
            if (!instance) return;
            const before = instance.getViewport();
            await instance.zoomOut();
            const after = instance.getViewport();
            if (after.zoom < before.zoom * 0.99 || before.zoom <= 0.1)
              zoomNavigation.navigate(sectionId, after, 'out');
          }}
        >
          <BoardIcon name="minus" />
        </IconButton>
        <Button variant="quiet"
          className="wboard-zoom-value"
          aria-label="Reset zoom to 100%"
          disabled={transition.active}
          title="Reset zoom to 100%"
          onClick={() => {
            setPreviousView({ sectionId, ...viewport });
            void flow.current?.zoomTo(1);
          }}
        >
          {Math.round(zoom * 100)}%
        </Button>
        <IconButton
          className="wboard-tool"
          aria-label="Zoom in"
          title="Zoom in"
          disabled={transition.active || zoom >= whiteboardMaxZoom}
          onClick={async () => {
            const instance = flow.current;
            if (!instance) return;
            const before = instance.getViewport();
            await instance.zoomIn();
            const after = instance.getViewport();
            if (after.zoom > before.zoom * 1.01) zoomNavigation.navigate(sectionId, after, 'in');
          }}
        >
          <BoardIcon name="plus" />
        </IconButton>
        <span className="wboard-divider" />
        <IconButton
          className="wboard-tool"
          aria-label="Fit view"
          disabled={transition.active}
          title="Fit all blocks"
          onClick={() => fitBoard()}
        >
          <BoardIcon name="fit" />
        </IconButton>
        {previousView?.sectionId === sectionId && (
          <IconButton
            className="wboard-tool"
            aria-label="Return to previous view"
            disabled={transition.active}
            title="Return to previous view"
            onClick={() => {
              void flow.current?.setViewport(previousView);
              setPreviousView(null);
            }}
          >
            <BoardIcon name="undo" />
          </IconButton>
        )}
      </Toolbar>
    </>
  );
}
