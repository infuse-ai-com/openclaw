import type { Mission } from '@studio/contracts';
import { escapeHtml as e } from './presentation.js';

export interface CorrectionDraft {
  missionId: string;
  baseVersion: number;
  evidenceRevision: string;
  evidenceHash: string;
  reason: string;
  reviewing: boolean;
}
export function correctionBaseMatches(draft: CorrectionDraft, mission: Mission): boolean {
  return draft.missionId === mission.id && draft.evidenceRevision === mission.task.evidence?.revision
    && draft.evidenceHash === mission.task.evidence?.sha256;
}
export function correctionMarkup(mission: Mission, draft: CorrectionDraft | undefined, eligible: boolean, pending: boolean): string {
  if (!draft) return '';
  const sameBase = correctionBaseMatches(draft, mission);
  const reviewed = draft.reviewing && draft.baseVersion === mission.version && eligible && sameBase;
  return `<section class="studio-correction-compose" aria-label="Correction request"><span class="studio-kicker">${reviewed ? 'REVIEW YOUR REQUEST' : 'ONE CORRECTION ROUND'}</span>
    <h3>${reviewed ? 'Send this correction?' : 'What should change?'}</h3>
    <p class="studio-small">Feedback for revision ${e(draft.evidenceRevision)} · based on mission v${draft.baseVersion}. The approved paper and team stay the same.</p>
    ${!sameBase || mission.correction ? '<div class="studio-banner studio-banner--warning">This draft belongs to an earlier result. Its text is preserved, but it cannot be sent against another revision or an already requested correction.</div>' : draft.baseVersion !== mission.version ? '<div class="studio-banner studio-banner--warning">The mission changed. Inspect the current result, then review this feedback again before sending.</div>' : ''}
    ${reviewed ? `<p class="studio-prose studio-correction-preview">${e(draft.reason).replaceAll('\r', '&#13;')}</p><p class="studio-small">Sending records your request and assigns a fresh specialist session. The replacement will need coordinator verification and your acceptance.</p><div class="studio-actions"><button class="studio-button" type="button" data-action="send-correction" ${pending ? 'disabled' : ''}>Send correction</button><button class="studio-button studio-button--secondary" type="button" data-action="edit-correction" ${pending ? 'disabled' : ''}>Edit feedback</button></div>`
      : `<form data-form="correction"><label class="studio-field">Correction feedback<textarea data-field="correctionReason" required maxlength="2000" rows="5" ${pending ? 'disabled' : ''}>${e(draft.reason)}</textarea></label><p class="studio-small">Describe the change needed to meet the approved criteria. A change of scope needs a new mission.</p><button class="studio-button" type="submit" ${!eligible || !sameBase || pending ? 'disabled' : ''}>Review correction</button></form>`}
    <button class="studio-button studio-button--secondary" type="button" data-action="discard-correction" ${pending ? 'disabled' : ''}>Discard correction</button>
  </section>`;
}
