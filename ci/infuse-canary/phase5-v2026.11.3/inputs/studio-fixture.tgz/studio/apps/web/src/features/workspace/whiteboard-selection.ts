import { useEffect, useRef, useState } from 'react';
import { whiteboardDetails, whiteboardNavigation } from '@studio/contracts';
import { api } from './api.js';
import { readSectionManifest } from './whiteboard-spatial.js';
import { WhiteboardSelectionActions, type SelectionContext, type SelectionIO } from './whiteboard-selection-actions.js';

const io: SelectionIO = {
  details: async (context, revision, ids) => whiteboardDetails.parse(await api(context.path + '/v3/details', {
    command: { sectionId: context.sectionId, revision, ids }, csrf: context.csrf,
  })),
  navigation: async context => whiteboardNavigation.parse(await api(context.path + '/v3/navigation')),
  section: (context, sectionId) => readSectionManifest(context.path, sectionId, context.projectId),
  copy: text => navigator.clipboard.writeText(text),
  paste: async () => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([navigator.clipboard.readText(), new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(Error('Clipboard access is unavailable.')), 1800);
      })]);
    } finally { clearTimeout(timer); }
  },
};
export function useWhiteboardSelection(context: () => SelectionContext) {
  const latest = useRef(context); latest.current = context;
  const [preparing, setPreparing] = useState(false);
  const [actions] = useState(() => new WhiteboardSelectionActions(() => latest.current(), io, setPreparing));
  useEffect(() => () => actions.invalidate(), [actions]);
  return { preparing, preparingRef: { get current() { return actions.preparing; } }, run: actions.run.bind(actions) };
}
