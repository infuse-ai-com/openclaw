import { icons } from '@studio/ui/icons';
export function BoardIcon({ name }: { name: keyof typeof icons }) {
  return (
    <span
      className="wboard-icon"
      aria-hidden="true"
      dangerouslySetInnerHTML={{ __html: icons[name] }}
    />
  );
}
