import * as THREE from 'three';
import { createOfficeCharacter } from '@studio/spatial/character';
import { agentAppearance, agentPortraitId } from './agent-identity.js';

// Seven artwork variants with head/full-body framing, independent of canonical identity.
const portraits = new Map<string, string>();

/** One still of the existing floor character; no extra animated scene remains alive. */
export function floorPortrait(agentId: string, fullBody = false): string | undefined {
  const key = `${agentPortraitId(agentId) ?? 'plain'}:${fullBody ? 'full' : 'head'}`;
  if (portraits.has(key)) return portraits.get(key);
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('webgl2', { alpha: true, antialias: true });
  if (!context) return;
  let renderer: THREE.WebGLRenderer | undefined, geometry: THREE.PlaneGeometry | undefined, material: THREE.ShadowMaterial | undefined;
  const character = createOfficeCharacter(agentAppearance(agentId));
  const keyLight = new THREE.DirectionalLight(fullBody ? 0xffdfba : 0xfff1d7, fullBody ? 4 : 3);
  try {
    renderer = new THREE.WebGLRenderer({ canvas, context, alpha: true, antialias: true });
    renderer.setSize(fullBody ? 800 : 256, fullBody ? 1000 : 256, false);
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    const scene = new THREE.Scene();
    scene.add(character.group, new THREE.HemisphereLight(fullBody ? 0xfff3df : 0xfff5e3, fullBody ? 0x587666 : 0x53614e, fullBody ? 2.3 : 2.6));
    keyLight.position.set(-3, fullBody ? 4 : 5, fullBody ? 5 : 4); scene.add(keyLight);
    let camera: THREE.Camera;
    if (fullBody) {
      renderer.toneMappingExposure = 1.25;
      renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      keyLight.castShadow = true; keyLight.shadow.mapSize.set(1024, 1024); keyLight.shadow.bias = -.001;
      const rim = new THREE.DirectionalLight(0xfe8d45, 3); rim.position.set(2, 2, -2); scene.add(rim);
      character.pose({ seated: 0, stride: 0, walking: false, gesture: 0, working: false });
      character.group.traverse(object => { if (object instanceof THREE.Mesh) object.castShadow = true; });
      geometry = new THREE.PlaneGeometry(200, 200); material = new THREE.ShadowMaterial({ opacity: .24 });
      const floor = new THREE.Mesh(geometry, material); floor.rotation.x = -Math.PI / 2; floor.position.y = -.035; floor.receiveShadow = true; scene.add(floor);
      camera = new THREE.PerspectiveCamera(30, .8, .1, 20); camera.position.set(1.35, 1.25, 4.1); camera.lookAt(0, .79, 0);
    } else {
      camera = new THREE.OrthographicCamera(-.64, .64, .64, -.64, .1, 20);
      const target = new THREE.Vector3(0, 1.12, 0); camera.position.copy(target).add(new THREE.Vector3(2.4, 1.2, 4)); camera.lookAt(target);
    }
    renderer.render(scene, camera);
    const image = canvas.toDataURL('image/png'); portraits.set(key, image); return image;
  } finally {
    character.dispose(); geometry?.dispose(); material?.dispose(); keyLight.shadow.map?.dispose(); renderer?.dispose(); renderer?.forceContextLoss();
  }
}
