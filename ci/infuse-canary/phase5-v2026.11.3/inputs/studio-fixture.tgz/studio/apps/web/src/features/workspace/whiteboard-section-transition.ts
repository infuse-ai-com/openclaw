import { useEffect, useRef, useState, type RefObject } from 'react';
import { cameraTransform, type BoardCamera } from './whiteboard-section-zoom.js';

type PendingJourney=Journey&{source:string;cover:HTMLDivElement;scene:HTMLElement;started:number;arrived:boolean;aligned?:BoardCamera};
type Journey={destination:string;from?:BoardCamera;to?:BoardCamera;returnThrough?:string;alignReturn?(preview:BoardCamera):BoardCamera};

function sectionNode(canvas:HTMLElement|null,id:string) {
  return Array.from(canvas?.querySelectorAll<HTMLElement>(':scope > .react-flow .react-flow__node')??[]).find(node=>node.dataset.id===id);
}

/** Read the actual thumbnail transform, including its inset and its parent camera. */
export function previewCamera(canvas:HTMLElement|null,id:string):BoardCamera|undefined {
  const node=sectionNode(canvas,id);
  const stage=node?.querySelector<HTMLElement>('.wboard-mini-stage');
  if(!canvas||!stage||!stage.offsetWidth)return;
  const rect=stage.getBoundingClientRect(),origin=canvas.getBoundingClientRect(),zoom=rect.width/stage.offsetWidth;
  if(zoom>0&&Number.isFinite(zoom))return {x:rect.x-origin.x,y:rect.y-origin.y,zoom};
}

/** Retain one inert view until the next section has rendered, then bridge their coordinates. */
export function useSectionTransition(canvas:RefObject<HTMLDivElement|null>,owner:string,sectionId:string,ready:boolean,unavailable:boolean) {
  const [active,setActive]=useState(false);
  const pending=useRef<PendingJourney|null>(null);
  const state=useRef({sectionId,ready,unavailable});state.current={sectionId,ready,unavailable};
  const frame=useRef(0),animations=useRef<Animation[]>([]);
  function clear() {
    cancelAnimationFrame(frame.current);animations.current.forEach(animation=>animation.cancel());animations.current=[];
    pending.current?.cover.remove();pending.current=null;setActive(false);
  }
  useEffect(()=>{clear();const motion=matchMedia('(prefers-reduced-motion: reduce)');const settle=()=>{if(motion.matches&&animations.current.length)clear();};motion.addEventListener('change',settle);return()=>{motion.removeEventListener('change',settle);cancelAnimationFrame(frame.current);animations.current.forEach(animation=>animation.cancel());pending.current?.cover.remove();pending.current=null;};},[owner]);
  useEffect(()=>{const journey=pending.current;if(unavailable||journey&&sectionId!==journey.destination&&(sectionId!==journey.source||journey.arrived))clear();},[sectionId,unavailable]);
  function begin(journey:Journey) {
    clear();
    const host=canvas.current,flow=host?.querySelector<HTMLElement>('.react-flow');
    if(!host||!flow)return;
    const cover=document.createElement('div'),scene=document.createElement('div');
    cover.className='wboard-section-transition';cover.setAttribute('aria-hidden','true');
    scene.className='wboard-section-transition-scene';scene.inert=true;
    const clone=flow.cloneNode(true) as HTMLElement;
    // This is a visual bridge only: never duplicate browsing contexts, ids or active controls.
    clone.querySelectorAll('iframe,script,video,audio').forEach(element=>element.remove());
    clone.querySelectorAll('[id]').forEach(element=>element.removeAttribute('id'));
    scene.append(clone);cover.append(scene);host.append(cover);
    const journeyState:PendingJourney={...journey,source:sectionId,cover,scene,started:performance.now(),arrived:false};pending.current=journeyState;setActive(true);
    function waitForView() {
      if(pending.current!==journeyState)return;
      const now=performance.now(),current=state.current;
      if(current.unavailable||now-journeyState.started>8000){clear();return;}
      if(current.sectionId===journey.destination)journeyState.arrived=true;
      if(current.sectionId!==journey.destination||!current.ready){frame.current=requestAnimationFrame(waitForView);return;}
      let to=journeyState.aligned??(journey.returnThrough?previewCamera(host,journey.returnThrough):journey.to);
      // Parent thumbnails load independently; keep the previous canvas while they arrive.
      const portal=journey.returnThrough?sectionNode(host,journey.returnThrough):null;
      const waitingForPreview=!portal||portal.querySelector('.wboard-section-preview')?.getAttribute('aria-busy')==='true';
      if(journey.returnThrough&&!to&&waitingForPreview&&now-journeyState.started<1200){frame.current=requestAnimationFrame(waitForView);return;}
      if(to&&journey.alignReturn&&!journeyState.aligned){journeyState.aligned=journey.alignReturn(to);frame.current=requestAnimationFrame(waitForView);return;}
      const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
      if(reduced){clear();return;}
      const transform=journey.from&&to?cameraTransform(journey.from,to):{x:0,y:0,scale:1};
      cover.dataset.phase='moving';
      const options={duration:420,easing:'cubic-bezier(.22,.68,0,1)',fill:'forwards' as const};
      const motion=scene.animate([{transform:'translate(0px,0px) scale(1)'},{transform:`translate(${transform.x}px,${transform.y}px) scale(${transform.scale})`}],options);
      const fade=cover.animate([{opacity:1,offset:0},{opacity:1,offset:.45},{opacity:0,offset:1}],options);
      animations.current=[motion,fade];
      void fade.finished.then(()=>{if(pending.current===journeyState)clear();}).catch(()=>{});
    }
    frame.current=requestAnimationFrame(waitForView);
  }
  return {active,begin};
}
