import { InfuseSpinner } from './loading.js';
import { useLayoutEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { whiteboardNoteColors, whiteboardDetails, whiteboardManifest, type WhiteboardImage, type WhiteboardSpatialItem } from '@studio/contracts';
import { api, ApiError } from './api.js';
import { useWorkspace } from './context.js';
import { StrokeGraphic } from './whiteboard-drawing.js';
import { NoteTextFit } from './whiteboard-note-fit.js';

type Block=Exclude<WhiteboardSpatialItem,{kind:'connection'}>;
const previewLimit=12;

function PreviewImage({item,path}:{item:WhiteboardImage;path:string}) {
  const [ratio,setRatio]=useState<number|null>(null),[failed,setFailed]=useState(false);
  const crop=item.crop,aspect=ratio&&crop?ratio*crop.width/crop.height:null,frame=item.width/item.height;
  if(failed)return <span className="wboard-mini-placeholder">Image unavailable</span>;
  return <div className="wboard-image-viewport" style={aspect?{width:Math.min(1,aspect/frame)*100+'%',height:Math.min(1,frame/aspect)*100+'%'}:undefined}>
    <img src={path+'/v3/images/'+encodeURIComponent(item.id)+'/'+item.revision} alt="" draggable={false}
      onLoad={event=>setRatio(event.currentTarget.naturalWidth/event.currentTarget.naturalHeight)} onError={()=>setFailed(true)}
      style={crop?{position:'absolute',maxWidth:'none',width:100/crop.width+'%',height:100/crop.height+'%',left:-100*crop.x/crop.width+'%',top:-100*crop.y/crop.height+'%',objectFit:'fill'}:undefined}/>
  </div>;
}
function PreviewBlock({item,path,showImage}:{item:Block;path:string;showImage:boolean}) {
  return <div className={'wboard-mini-block wboard-mini-block--'+item.kind} data-preview-id={item.id} style={{left:item.x,top:item.y,width:item.width,height:item.height,...(item.kind==='note'&&item.noteColor?{background:whiteboardNoteColors[item.noteColor],color:'#283342'}:{})}}>
    {item.kind==='stroke'?<StrokeGraphic stroke={item}/>:item.kind==='image'?(showImage?<PreviewImage key={item.revision} item={item} path={path}/>:<span className="wboard-mini-placeholder">Image · {item.title}</span>):<>
      <span className="wboard-card-kind">{item.kind}</span><strong>{item.title}</strong>
      {item.kind==='note'?<NoteTextFit text={item.text}><p>{item.text}</p></NoteTextFit>:item.kind==='document'?<p>{item.text}</p>:<span className="wboard-mini-placeholder">{item.kind==='section'?'↳ Section':'〈/〉 HTML'}</span>}
    </>}
  </div>;
}
/** A bounded, read-only view of direct children, without recursive boards or active HTML. */
export function SectionPreview({id,title,path,revision}:{id:string;title:string;path:string;revision:number}) {
  const {session,owner,current,visible}=useWorkspace();
  const host=useRef<HTMLDivElement>(null),[size,setSize]=useState({width:0,height:0});
  useLayoutEffect(()=>{if(!host.current)return;const observer=new ResizeObserver(entries=>{const r=entries[0]?.contentRect;if(r)setSize({width:r.width,height:r.height});});observer.observe(host.current);return()=>observer.disconnect();},[]);
  const preview=useQuery({queryKey:['workspace',owner,'whiteboard-section-preview',id,revision],gcTime:0,
    queryFn:async({signal})=>{
      const manifest=whiteboardManifest.parse(await api(path+'/v3?'+new URLSearchParams({sectionId:id,limit:String(previewLimit)}),{signal}));
      if(manifest.projectId!==session.project.id||manifest.sectionId!==id)throw Error('Section preview scope changed');
      const ids=manifest.items.filter(item=>item.kind!=='connection').map(item=>item.id);
      const details=ids.length?whiteboardDetails.parse(await api(path+'/v3/details',{command:{sectionId:id,revision:manifest.revision,ids},csrf:session.csrfToken,signal})):null;
      if(details&&(details.projectId!==session.project.id||details.sectionId!==id||details.revision!==manifest.revision))throw Error('Section preview scope changed');
      return {items:[...manifest.items.filter(item=>item.kind==='connection'),...(details?.items??[])],partial:!!manifest.nextCursor||!!details?.missingIds.length};
    },enabled:current&&visible,retry:(count,error)=>error instanceof ApiError&&error.code==='VERSION_CONFLICT'&&count<2});
  const blocks=(preview.data?.items??[]).filter((item):item is Block=>item.kind!=='connection');
  const left=Math.min(...blocks.map(item=>item.x)),top=Math.min(...blocks.map(item=>item.y));
  const width=Math.max(...blocks.map(item=>item.x+item.width))-left,height=Math.max(...blocks.map(item=>item.y+item.height))-top;
  const scale=blocks.length?Math.max(0,Math.min((size.width-20)/width,(size.height-20)/height)):0;
  const imageIds=new Set(blocks.filter(item=>item.kind==='image').slice(0,2).map(item=>item.id));
  const names=blocks.map(item=>item.kind==='stroke'?'Drawing':item.title||item.kind).join(', ');
  const description=preview.isError?'Preview unavailable':preview.isPending?'Loading preview':!blocks.length?'Empty section':names;
  return <div ref={host} className="wboard-section-preview" role="img" aria-label={'Contents of '+title+': '+description+(preview.data?.partial?' · Partial preview':'')} aria-busy={preview.isPending}>
    {preview.isError?<span className="wboard-section-preview-message">Preview unavailable</span>:preview.isPending?<span className="wboard-section-preview-message"><InfuseSpinner /> Loading preview…</span>:!blocks.length?<span className="wboard-section-preview-message">{preview.data?.partial?'Enter to see all items':'An empty space to explore'}</span>:<>
      <div className="wboard-mini-stage" aria-hidden="true" style={{transform:`translate(${(size.width-width*scale)/2-left*scale}px,${(size.height-height*scale)/2-top*scale}px) scale(${scale})`}}>
        <svg className="wboard-mini-links">{preview.data?.items.map(item=>{
          if(item.kind!=='connection')return null;const a=blocks.find(b=>b.id===item.source),b=blocks.find(b=>b.id===item.target);
          return a&&b?<line key={item.id} x1={a.x+a.width/2} y1={a.y+a.height/2} x2={b.x+b.width/2} y2={b.y+b.height/2}/>:null;
        })}</svg>
        {blocks.map(item=><PreviewBlock key={item.id} item={item} path={path} showImage={imageIds.has(item.id)}/>)}
      </div>
      {preview.data?.partial&&<span className="wboard-section-preview-limit">Partial preview · Enter to see all</span>}
    </>}
  </div>;
}
