import { useEffect, useRef } from 'react';
import type { CanvasItem } from './whiteboard-types.js';
import { isTyping } from './whiteboard-history.js';
import { previewCamera, type useSectionTransition } from './whiteboard-section-transition.js';
import type { useWhiteboardCamera } from './whiteboard-camera.js';
import {
  sectionZoomTarget,
  sectionZoomExitThreshold,
  whiteboardMaxZoom,
  zoomCameraAt,
  sectionReturnCamera,
  transformCamera,
  type BoardCamera,
} from './whiteboard-section-zoom.js';
import type { WhiteboardSection } from '@studio/contracts';

type MoveEvent = MouseEvent | TouchEvent | null;
export function useWhiteboardSectionZoom({
  cameraOwner,
  sectionId,
  blocks,
  ancestors,
  transition,
  enterSection,
  blocked,
  moved,
  updatePresence,
}: {
  cameraOwner: ReturnType<typeof useWhiteboardCamera>;
  sectionId: string;
  blocks: CanvasItem[];
  ancestors: { id: string }[];
  transition: ReturnType<typeof useSectionTransition>;
  enterSection(next: string): void;
  blocked(): boolean;
  moved(): void;
  updatePresence(camera: BoardCamera): void;
}) {
  const { canvas, flow, viewport } = cameraOwner;
  const zoomGesture = useRef<{
    sectionId: string;
    start: number;
    last: number;
    increasing: boolean;
  } | null>(null);
  const zoomNavigationAfter = useRef(0);

  useEffect(() => {
    zoomGesture.current = null;
    zoomNavigationAfter.current = performance.now() + 800;
  }, [sectionId]);
  function navigateZoomedSection(
    source: string,
    camera: BoardCamera,
    direction: 'in' | 'out',
    event?: MouseEvent | TouchEvent | null,
  ) {
    if (blocked() || source !== sectionId || performance.now() < zoomNavigationAfter.current)
      return;
    if (isTyping(document.activeElement) || document.querySelector('.ws-whiteboard dialog[open]'))
      return;
    const rect = canvas.current?.getBoundingClientRect();
    if (!rect) return;
    if (direction === 'out') {
      const parent = ancestors.at(-2);
      if (
        !parent ||
        ancestors.at(-1)?.id !== sectionId ||
        camera.zoom > sectionZoomExitThreshold(blocks, rect) + 0.00001
      )
        return;
      zoomNavigationAfter.current = performance.now() + 800;
      transition.begin({
        destination: parent.id,
        from: camera,
        returnThrough: sectionId,
        alignReturn: (preview) => {
          const saved = flow.current?.getViewport() ?? cameraOwner.saved(parent.id) ?? viewport;
          const next = sectionReturnCamera(saved, preview, camera, rect);
          cameraOwner.seed(parent.id, next);
          void flow.current?.setViewport(next);
          return transformCamera(preview, saved, next);
        },
      });
      enterSection(parent.id);
      return;
    }
    const touches =
      event && 'touches' in event
        ? Array.from(event.touches.length ? event.touches : event.changedTouches)
        : null;
    const pointer = touches?.length
      ? {
          clientX: touches.reduce((n, t) => n + t.clientX, 0) / touches.length,
          clientY: touches.reduce((n, t) => n + t.clientY, 0) / touches.length,
        }
      : event && 'clientX' in event
        ? event
        : null;
    const point = pointer
      ? { x: pointer.clientX - rect.x, y: pointer.clientY - rect.y }
      : { x: rect.width / 2, y: rect.height / 2 };
    const hitId =
      document
        .elementFromPoint(rect.x + point.x, rect.y + point.y)
        ?.closest('.react-flow__node')
        ?.getAttribute('data-id') ?? undefined;
    const target = sectionZoomTarget(
      blocks.filter((block): block is WhiteboardSection => block.kind === 'section'),
      camera,
      rect,
      point,
      hitId,
    );
    if (!target) return;
    zoomNavigationAfter.current = performance.now() + 800;
    const from = previewCamera(canvas.current, target.id);
    if (from) {
      const next = zoomCameraAt(
        from,
        point,
        Math.max(0.45, Math.min(whiteboardMaxZoom, from.zoom * 1.6)),
      );
      cameraOwner.seed(target.id, next);
      cameraOwner.markFramed(target.id);
      transition.begin({ destination: target.id, from, to: next });
    } else transition.begin({ destination: target.id });
    enterSection(target.id);
  }

  // React Flow's gesture end can arrive after a render; consult the current navigation guard.
  const navigate = useRef(navigateZoomedSection);
  navigate.current = navigateZoomedSection;
  function onMoveStart(event: MoveEvent, camera: BoardCamera) {
    zoomGesture.current = event
      ? { sectionId, start: camera.zoom, last: camera.zoom, increasing: false }
      : null;
    if (event) {
      moved();
      cameraOwner.markFramed();
    }
  }
  function onMove(_event: MoveEvent, viewport: BoardCamera) {
    const gesture = zoomGesture.current;
    if (gesture && Math.abs(viewport.zoom - gesture.last) > 0.00001) {
      gesture.increasing = viewport.zoom > gesture.last;
      gesture.last = viewport.zoom;
    }
    cameraOwner.changed(viewport);
    updatePresence(viewport);
  }
  function onMoveEnd(event: MoveEvent, camera: BoardCamera) {
    const gesture = zoomGesture.current;
    zoomGesture.current = null;
    if (event && gesture?.sectionId === sectionId) {
      if (gesture.increasing && camera.zoom > gesture.start * 1.01)
        navigate.current(sectionId, camera, 'in', event);
      else if (!gesture.increasing && camera.zoom < gesture.start * 0.99)
        navigate.current(sectionId, camera, 'out', event);
    }
  }
  return {
    navigate: (...args: Parameters<typeof navigateZoomedSection>) => navigate.current(...args),
    onMoveStart,
    onMove,
    onMoveEnd,
  };
}
