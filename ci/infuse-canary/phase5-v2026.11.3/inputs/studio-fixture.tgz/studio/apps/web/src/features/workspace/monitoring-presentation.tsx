import type {HealthCheckView} from '@studio/contracts';
import {api} from './api.js';
export const stamp=(value:string|undefined)=>value?new Date(value).toLocaleString(undefined,{timeZoneName:'short'}):'Not recorded';
export const stateLabel=(value:string)=>value.replaceAll('-',' ');
export const needsAttention=(check:HealthCheckView)=>check.definition.enabled&&(['critical','warning','stale','unknown'].includes(check.status)||!!check.collectorError||check.openIncidents>0||check.outstandingDeliveries>0);
export const priority=(check:HealthCheckView)=>check.status==='critical'?0:check.status==='warning'?1:needsAttention(check)?2:check.status==='healthy'?3:4;
export const systemOf=(check:HealthCheckView)=>check.definition.system??{id:check.definition.resourceId,name:check.definition.resourceName};
export async function read<T>(path:string,signal:AbortSignal,parse:(v:unknown)=>T):Promise<{value:T}|{unavailable:true}>{try{return {value:parse(await api(path,{signal}))};}catch(error){if(signal.aborted)throw error;return {unavailable:true};}}
export function Status({status}:{status:string}){return <span className="ws-monitor-status" data-status={status}>{stateLabel(status)}</span>;}
