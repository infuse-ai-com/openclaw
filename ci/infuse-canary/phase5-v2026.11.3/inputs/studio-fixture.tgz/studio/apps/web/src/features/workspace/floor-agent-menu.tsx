import { IconButton } from './ui.js';
import { useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';
import { icons } from '@studio/ui/icons';
import conversationIcon from '@tabler/icons/outline/message-circle.svg?raw';
import diamondIcon from '@tabler/icons/outline/diamond.svg?raw';
import type { AgentScreenAnchor } from '../studio/spatial.js';
import type { FloorAssignment, FloorDesk } from './floor-model.js';
import { AgentPortrait, agentRoleGuide } from './agent-portrait.js';
import { Link } from './navigation.js';

/** Reposition DOM only: camera/character frames must not rerender the workspace. */
export function positionAgentMenu(menu: HTMLElement, anchor: AgentScreenAnchor | null) {
  const floor = menu.parentElement!;
  const bounds = floor.getBoundingClientRect();
  const card = menu.querySelector<HTMLElement>('.ws-floor-agent-card')!;
  const tethered = anchor && anchor.key === menu.dataset.agent && anchor.visible ? anchor : null;
  const compact = floor.clientWidth < 540 || !tethered;
  menu.dataset.compact = String(compact);
  menu.dataset.tethered = String(!!tethered);
  menu.style.setProperty('--agent-card-height', `${card.offsetHeight}px`);
  const width = menu.offsetWidth, height = menu.offsetHeight;
  const x = tethered ? tethered.x - bounds.left : floor.clientWidth / 2;
  const y = tethered ? tethered.y - bounds.top : (floor.querySelector<HTMLElement>('.ws-floor-intro')?.offsetHeight ?? 160) + height + 20;
  const left = Math.max(12, Math.min(floor.clientWidth - width - 12, x - width / 2));
  const top = Math.max(12, Math.min(floor.clientHeight - height - 12, y - card.offsetHeight - (compact ? height - card.offsetHeight + 24 : 32)));
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;
  // A clamped menu must not draw a selection marker at a false character position.
  menu.dataset.clamped = String(Math.abs(left + width / 2 - x) > 12 || Math.abs(top + card.offsetHeight + 32 - y) > 12);
}

function Icon({ source }: { source: string }) {
  return <span className="ws-glyph" aria-hidden="true" dangerouslySetInnerHTML={{ __html: source }} />;
}

function FloorPortrait({ agentId }: { agentId: string }) {
  const [image, setImage] = useState<string>();
  useEffect(() => {
    let current = true;
    void import('./floor-portrait.js').then(({ floorPortrait }) => {
      if (current) setImage(floorPortrait(agentId));
    }).catch(() => { /* The approved portrait remains available without WebGL. */ });
    return () => { current = false; };
  }, [agentId]);
  return <span className="ws-floor-portrait" aria-hidden="true">{image ? <img src={image} alt="" /> : <AgentPortrait target={{ agentId }} />}</span>;
}

export function FloorAgentMenu({ desk, item, projectName, profilePath, anchor, menuRef, onAssignment, onClose }: {
  desk: FloorDesk; item?: FloorAssignment; projectName: string; profilePath: string;
  anchor: RefObject<AgentScreenAnchor | null>; menuRef: RefObject<HTMLElement | null>;
  onAssignment(id: string): void; onClose(): void;
}) {
  const heading = useRef<HTMLHeadingElement>(null);
  useLayoutEffect(() => {
    const menu = menuRef.current!;
    const position = () => positionAgentMenu(menu, anchor.current);
    position(); heading.current?.focus({ preventScroll: true });
    const observer = new ResizeObserver(position);
    observer.observe(menu); observer.observe(menu.parentElement!);
    observer.observe(menu.querySelector('.ws-floor-agent-card')!);
    // Page scrolling changes viewport-relative anchor coordinates. The scene republishes
    // on its next frame; until then, use the current selected pin for scroll-only changes.
    const scroll = () => {
      const pin = [...menu.parentElement!.querySelectorAll<HTMLElement>('[data-desk-key]')].find(p => p.dataset.deskKey === desk.key);
      if (pin && !pin.hidden) {
        const rect = pin.getBoundingClientRect();
        anchor.current = { key: desk.key, x: rect.x + rect.width / 2, y: rect.y + rect.height / 2, visible: true };
      }
      position();
    };
    window.addEventListener('scroll', scroll, true);
    return () => { observer.disconnect(); window.removeEventListener('scroll', scroll, true); };
  }, [desk.key, anchor, menuRef]);
  const guide = agentRoleGuide(desk.target.agentId);
  return <section ref={menuRef} className="ws-floor-orbit" aria-label="Selected agent work" data-agent={desk.key}>
    <div className="ws-floor-agent-card">
      <FloorPortrait key={desk.target.agentId} agentId={desk.target.agentId} />
      <div className="ws-floor-agent-copy">
      <div className="ws-floor-person"><h2 ref={heading} tabIndex={-1}>{guide?.name ?? desk.target.agentId}</h2><p>{guide?.role ?? (item?.role === 'coordinator' ? 'Coordinator' : 'Team member')} · {projectName}</p></div>
      <div className="ws-floor-assignment"><Icon source={icons.document} /><div>{item ? <>
        {desk.work.length > 1 ? <select className="ui-control" aria-label="Assigned mission" value={item.id} onChange={e => onAssignment(e.target.value)}>{desk.work.map(w => <option key={w.id} value={w.id}>{w.missionTitle} · {w.title}</option>)}</select> : <strong>{item.missionTitle}</strong>}
        <p>{item.title} · {item.status}</p>
      </> : <><strong>{desk.status}.</strong><small>Availability is not reported.</small></>}</div></div>
      </div>
      <IconButton className="ws-floor-close" aria-label="Close agent details" onClick={onClose}><Icon source={icons.close} /></IconButton>
    </div>
    <span className="ws-floor-selection-marker" aria-hidden="true"><Icon source={diamondIcon} /></span>
    <nav className="ws-floor-orbit-actions" aria-label={`${guide?.name ?? desk.target.agentId} quick actions`}>
      {item ? <Link className="ws-floor-orbit-action ws-floor-orbit-primary" to={item.path} aria-label="Open mission ↗"><Icon source={icons.document} />Open mission</Link>
        : <Link className="ws-floor-orbit-action ws-floor-orbit-primary" to={profilePath} aria-label="View profile ↗"><Icon source={icons.profile} />View profile</Link>}
      {item?.conversationUrl ? <a className="ws-floor-orbit-action ws-floor-orbit-conversation" href={item.conversationUrl} target="_blank" rel="noopener noreferrer" aria-label="Conversation in Mattermost (opens a new tab)"><Icon source={conversationIcon} />Conversation</a>
        : !item && <Link className="ws-floor-orbit-action ws-floor-orbit-conversation" to="/missions"><Icon source={icons.files} />Mission board</Link>}
      {item && <Link className="ws-floor-orbit-action ws-floor-orbit-profile" to={profilePath} aria-label="View profile ↗"><Icon source={icons.profile} />View profile</Link>}
    </nav>
  </section>;
}
