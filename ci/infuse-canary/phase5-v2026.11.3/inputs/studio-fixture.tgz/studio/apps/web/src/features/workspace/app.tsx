import { Fragment } from 'react';
import {RouterProvider} from 'react-router/dom';
import {Monitoring} from './monitoring.js';
import { Contributions } from './contributions.js';
import { MyApps, appsLoginUrl } from './my-apps.js';
import { LoadingState } from './loading.js';
import { MyDesk } from './desk.js';
import { KnowledgeWorkspace } from './knowledge.js';
import { CodeWorkspace } from './code.js';
import { ProfileSettings } from './settings.js';
import { FloorManager } from './floors.js';
import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router';
import { Link, useNavigate } from './navigation.js';
import { QueryClient, QueryClientProvider, useInfiniteQuery, useQuery, useQueryClient } from '@tanstack/react-query';
import { parseMissionList, type MissionListCursor } from '@studio/contracts';
import logo from '../../../../../packages/ui/assets/INFUSE_horizontal_for_dark_background.png?inline';
import { mountStudioFonts } from '../studio/fonts.js';
import '../studio/styles.css';
import { api, ApiError, accessDenied, getSession, onAccessDenied, ownerKey, readableError, type SignedInSession, type Session } from './api.js';
import { useCommands } from './commands.js';
import { WorkspaceContext, useWorkspace } from './context.js';
import { clearWhiteboardTextRecovery, confirmWhiteboardExit } from './whiteboard-recovery.js';
import { WorkspaceShell, PendingDestination } from './shell.js';
import { LoginEntrance, WorkspaceArrival, hasArrivalIntent, clearArrivalIntent } from './entrance.js';
const ProjectFloor = lazy(() => import('./floor.js').then(module => ({default:module.ProjectFloor})));
const WhiteboardWorkspace = lazy(() => import('./whiteboard.js').then(module => ({ default: module.WhiteboardWorkspace })));
import { ComposeMission, MissionDetail } from './mission.js';
import { ArtifactSession } from './artifact-session.js';
import { ArtifactLibrary, ArtifactViewer } from './artifacts.js';
import { SceneBoundary } from './scene-boundary.js';
import { PageBoundary } from './page-boundary.js';
import { Agents } from './company.js';
import { Skills } from './skill-guides.js';
import { Office } from './office.js';
import { useAppearance } from './appearance.js';
import { MissionCollection, ProjectReview } from './collection.js';
import { ComposeNativeMission, NativeMissionDetail, getNativeMissions } from './native-missions.js';

const queryClient = new QueryClient({ defaultOptions: {
  queries: { retry: false, staleTime: 0, gcTime: 0, refetchOnWindowFocus: true, refetchOnReconnect: true },
  mutations: { retry: false },
} });
function useActivity() {
  const [activity, setActivity] = useState({ online: navigator.onLine, visible: !document.hidden });
  useEffect(() => {
    const update = () => setActivity({ online: navigator.onLine, visible: !document.hidden });
    window.addEventListener('online', update); window.addEventListener('offline', update); document.addEventListener('visibilitychange', update);
    return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); document.removeEventListener('visibilitychange', update); };
  }, []);
  return activity;
}
export function Icon({ name }: { name: 'company' | 'floor' | 'missions' | 'people' | 'arrow' | 'close' }) {
  const paths = { company: 'M4 21V4h10v17M14 10h6v11M7 8h4M7 12h4M7 16h4M17 14h1M17 18h1M2 21h20',
    floor: 'M3 7l9-4 9 4-9 4-9-4zm0 5 9 4 9-4M3 17l9 4 9-4',
    missions: 'M4 4h16v16H4zM8 4v16M12 8h5M12 12h5M12 16h3',
    people: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm-6 10v-3a6 6 0 0 1 12 0v3M16 4a4 4 0 0 1 0 7m3 10v-3a6 6 0 0 0-3-5',
    arrow: 'M4 12h15M13 5l7 7-7 7', close: 'M5 5l14 14M5 19L19 5' };
  return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]} /></svg>;
}
function clearKnowledgeProgress(){try{for(const key of Object.keys(localStorage))if(key.startsWith('studio.knowledge.progress:'))localStorage.removeItem(key);}catch{ /* Reading remains available without persistent storage. */ }}
function SessionLoading() {
  const appearance = useAppearance();
  return <div className="ws-session-loading studio-workbench" data-studio-theme={appearance.theme}><LoadingState label="Opening your workspace…" overlay /></div>;
}
function SessionGate() {
  const activity = useActivity();
  const location = useLocation(); const navigate = useNavigate(); const projectId = new URLSearchParams(location.search).get('project') ?? undefined;
  // Direct launcher entry must resolve app-only admission before any workspace read.
  // Once entered, keep this gate and the shell mounted across ordinary routes.
  const [appsAdmission,setAppsAdmission]=useState<'pending'|'workspace'|'complete'>(()=>location.pathname==='/apps'?'pending':'complete');
  const admitWorkspace=useCallback(()=>setAppsAdmission(state=>state==='pending'?'workspace':state),[]);
  const [sessionPaused, setSessionPaused] = useState(false);
  const [entering, setEntering] = useState(hasArrivalIntent);
  const query = useQueryClient();
  const session = useQuery<Session>({ queryKey: ['workspace-session', projectId],
    placeholderData: previous => previous?.authenticated && previous.project.id === projectId ? previous : undefined, queryFn: ({ signal }) => getSession(signal, undefined, projectId),
    refetchInterval: activity.online && activity.visible && !sessionPaused ? 7000 : false, enabled: activity.online && !sessionPaused && appsAdmission!=='pending' });
  useEffect(()=>{if(appsAdmission==='workspace'&&!session.isPending)setAppsAdmission('complete');},[appsAdmission,session.isPending]);
  useEffect(() => {
    if (session.data?.authenticated && (!projectId || location.pathname === '/')) {
      // Canonicalizing a just-validated project must retain the mounted work/focus.
      // Never seed a newly selected foreign project with the previous project's data.
      if (!projectId) query.setQueryData(['workspace-session', session.data.project.id], session.data);
      navigate({ pathname: location.pathname === '/' ? '/desk' : location.pathname, search: `?${new URLSearchParams({ ...Object.fromEntries(new URLSearchParams(location.search)), project: session.data.project.id })}` }, { replace: true });
    }
  }, [session.data, projectId, location.pathname, location.search]);
  useEffect(() => onAccessDenied(() => {
    clearWhiteboardTextRecovery();
    clearKnowledgeProgress();window.dispatchEvent(new Event('studio-knowledge-denied'));
    void query.cancelQueries({queryKey:['my-apps']});query.removeQueries({queryKey:['my-apps']});
    void query.cancelQueries({ queryKey: ['workspace'] }); query.removeQueries({ queryKey: ['workspace'] });
    void query.cancelQueries({ queryKey: ['workspace-session'] });
    query.setQueriesData({ queryKey: ['workspace-session'] }, { authenticated: false, loginUrl: '/api/auth/login' });
  }), [query]);
  const projectDenied = session.error instanceof ApiError && session.error.status === 403;
  useEffect(() => {
    if (session.data?.authenticated || projectDenied) clearArrivalIntent();
    if (projectDenied || session.data?.authenticated === false) setEntering(false);
  }, [session.data?.authenticated, projectDenied]);
  useEffect(() => {
    if (projectDenied) { clearWhiteboardTextRecovery(); clearKnowledgeProgress();window.dispatchEvent(new Event('studio-knowledge-denied')); void query.cancelQueries({ queryKey: ['workspace'] }); query.removeQueries({ queryKey: ['workspace'] }); }
  }, [projectDenied, query]);
  if(appsAdmission!=='complete'&&(appsAdmission==='pending'||session.isPending))return <MyApps onWorkspaceAvailable={admitWorkspace}/>;
  if (projectDenied) return <div className="ws-entry"><main><h1>Project access unavailable.</h1>
    <p>{readableError(session.error)}</p><p>Your sign-in is still active. Select an available project or retry after access is restored.</p>
    <a className="ws-button" href="/missions">Choose an available project</a>
    <button className="ws-button ws-button--quiet" onClick={() => void session.refetch()}>Check access again</button>
  </main></div>;
  if (session.data?.authenticated) return <WorkspaceArrival active={entering} onComplete={() => setEntering(false)}>
    <SignedIn key={ownerKey(session.data)} session={session.data} onSessionPause={setSessionPaused}
      current={activity.online && !session.isError} visible={activity.visible} sessionFailure={session.isError ? readableError(session.error) : ''} />
  </WorkspaceArrival>;
  if (session.isPending && activity.online && !entering) return <SessionLoading />;
  return <LoginEntrance pending={session.isPending} online={activity.online}
    error={session.isError ? readableError(session.error) : ''} retry={() => void session.refetch()}
    loginUrl={location.pathname==='/apps'?appsLoginUrl(location.search):session.data?.authenticated === false ? session.data.loginUrl : '/api/auth/login'} />;
}

function SignedIn({ session, current, visible, sessionFailure, onSessionPause }: { session: SignedInSession; current: boolean; visible: boolean; sessionFailure: string; onSessionPause(paused: boolean): void }) {
  const owner = ownerKey(session);
  const commands = useCommands(session);
  const route = useLocation();
  const navigate = useNavigate();
  const query = useQueryClient();
  const [logoutError, setLogoutError] = useState('');
  const [loggingOut, setLoggingOut] = useState(false);
  const [screenZen, setScreenZen] = useState(false);
  const monitorOpen = route.pathname === '/desk' && new URLSearchParams(route.search).get('desk') === 'monitor';
  const zen = monitorOpen && !!session.workbenchAvailable && screenZen;
  useEffect(() => { if (!monitorOpen) setScreenZen(false); }, [monitorOpen]);
  const deskAlias = new URLSearchParams(route.search); deskAlias.set('desk', 'monitor');
  const list = useInfiniteQuery({ queryKey: ['workspace', owner, 'missions'],
    initialPageParam: undefined as MissionListCursor | undefined,
    queryFn: async ({ signal, pageParam }) => parseMissionList(await api(`/api/studio/missions?${new URLSearchParams({ limit: '30', ...(pageParam ? { cursor: JSON.stringify(pageParam) } : {}) })}`, { signal })),
    getNextPageParam: (last, pages) => pages.length < 10 ? last.nextCursor : undefined,
    enabled: current && session.legacyProject, refetchInterval: current && visible && session.legacyProject ? 7000 : false,
  });
  const missions = useMemo(() => session.legacyProject && !accessDenied(list.error) ? list.data?.pages.flatMap(page => page.missions) ?? [] : [], [list.data, list.error, session.legacyProject]);
  const legacyError = session.legacyProject && list.isError;
  const nativeList = useQuery({ queryKey: ['workspace', owner, 'native-missions'], enabled: current && !!session.nativeMissions,
    queryFn: ({ signal }) => getNativeMissions(session.project.id, signal), refetchInterval: current && visible ? 7000 : false });
  const nativeMissions = accessDenied(nativeList.error) ? [] : nativeList.data ?? [];
  const RouteScope = /^\/artifacts(?:\/|$)/.test(route.pathname) ? ArtifactSession : Fragment;
  const floor = route.pathname === '/floor';
  const office = route.pathname === '/company';
  const [officeVisited, setOfficeVisited] = useState(office);
  useEffect(() => { if (office) setOfficeVisited(true); }, [office]);
  const [floorVisited, setFloorVisited] = useState(floor);
  useEffect(() => { if (floor) setFloorVisited(true); }, [floor]);
  const context = { session, owner, current: current && !loggingOut, visible, commands };
  async function logout() {
    if (!confirmWhiteboardExit()) return;
    clearWhiteboardTextRecovery();
    clearKnowledgeProgress();
    setLoggingOut(true); onSessionPause(true); commands.suspend(); setLogoutError('');
    // Clear sensitive projections as soon as sign-out begins, regardless of its network outcome.
    await Promise.all([query.cancelQueries({ queryKey: ['workspace'] }), query.cancelQueries({ queryKey: ['workspace-session'] }),query.cancelQueries({queryKey:['my-apps']})]); query.removeQueries({ queryKey: ['workspace'] });query.removeQueries({queryKey:['my-apps']});
    try {
      await api('/api/logout', { command: {}, csrf: session.csrfToken });
      await query.cancelQueries({ queryKey: ['workspace-session'] });
      query.setQueriesData({ queryKey: ['workspace-session'] }, { authenticated: false, loginUrl: '/api/auth/login' });
    } catch (error) { setLogoutError(readableError(error)); }
    finally { onSessionPause(false); setLoggingOut(false); commands.unsuspend(); }
  }
  return <WorkspaceContext value={context}><WorkspaceShell floor={floor} screenZen={zen} logout={() => void logout()} loggingOut={loggingOut}>
      <div className="ws-alerts" aria-live="polite">
        {!current && <div className="ws-alert">Connection unavailable. Decisions are disabled until Studio refreshes your access. {sessionFailure}</div>}
        {logoutError && <div className="ws-alert" role="alert">Sign-out could not be confirmed. {logoutError}</div>}
        {commands.failure && <div className="ws-alert" role="alert">{commands.failure}</div>}
        {commands.notice && <div className="ws-alert ws-alert--success">{commands.notice}</div>}
        {commands.pending && <section className="ws-recovery" aria-label="Pending command"><div><span className="ws-eyebrow">{commands.pending.status === 'sending' ? 'AWAITING RECEIPT' : 'REVIEW BEFORE RETRY'}</span><strong>{commands.pending.command.type} · {commands.pending.command.missionId}</strong><p>Command {commands.pending.command.commandId} · based on version {commands.pending.command.expectedVersion}</p></div>
          {commands.pending.status === 'uncertain' && <div className="ws-actions"><button className="ws-button ws-button--quiet" disabled={!current || loggingOut || commands.pending.command.type !== 'create' && !session.bootstrap.capabilities.approver} onClick={() => void commands.retry().then(receipt => { if (receipt && commands.pending?.command.type === 'create') navigate(`/missions/${encodeURIComponent(receipt.missionId)}`); })}>Retry exact command</button><Link className="ws-text-link" to={`/missions/${encodeURIComponent(commands.pending.command.missionId)}`}>Inspect mission</Link></div>}</section>}
        {commands.conflict && <div className="ws-alert">The mission changed. <Link to={`/missions/${encodeURIComponent(commands.conflict.missionId)}`}>Refresh and review its current state</Link> before making another decision. Your draft has been kept.</div>}
      </div>
      <div className="ws-floor" hidden={!floor || loggingOut}>
        {(floor || floorVisited) && <SceneBoundary><Suspense fallback={<LoadingState label="Loading project floor…" size="page" overlay />}><ProjectFloor shown={floor && visible && !loggingOut} /></Suspense></SceneBoundary>}
      </div>
      {!loggingOut && (office || officeVisited) && <Office shown={office} />}
      {loggingOut ? <LoadingState label="Signing out…" /> : <RouteScope><PageBoundary key={route.pathname}><Routes><Route path="/" element={null} /><Route path="/floor" element={null} /><Route path="/company" element={null} />
        <Route path="/missions" element={<MissionCollection missions={missions} native={nativeMissions} limited={!!list.data?.pages.at(-1)?.nextCursor && list.data.pages.length >= 10} loading={(session.legacyProject && list.isPending) || !!session.nativeMissions && nativeList.isPending} error={[legacyError ? readableError(list.error) : '', nativeList.isError ? readableError(nativeList.error) : ''].filter(Boolean).join(' ')} refreshing={session.legacyProject && list.isFetching || !!session.nativeMissions && nativeList.isFetching} refresh={() => { if (session.legacyProject) void list.refetch(); if (session.nativeMissions) void nativeList.refetch(); }} more={session.legacyProject && !!list.hasNextPage} loadMore={() => { if (session.legacyProject) void list.fetchNextPage(); }} />} />
        <Route path="/artifacts" element={<ArtifactLibrary />} />
        <Route path="/artifacts/:producer/:artifactId/:revision" element={<ArtifactViewer />} />
        <Route path="/grilling" element={(!session.nativeMissions && !session.legacyProject || session.floorConnection === 'connecting' || session.floorConnection === 'blocked') ? <PendingDestination actionTo="/floor" actionLabel="Open floor →" title="Connecting your team" description={session.floorConnection === 'blocked' ? "Studio could not finish connecting the team. Your floor is available; an operator needs to check the connection." : "Studio is connecting the shared team and preparing this floor’s conversations. Grilling will become available automatically."} /> : session.nativeMissions?.cutover ? <ComposeNativeMission /> : <ComposeMission />} />
        <Route path="/missions/new" element={(!session.nativeMissions && !session.legacyProject || session.floorConnection === 'connecting' || session.floorConnection === 'blocked') ? <PendingDestination actionTo="/floor" actionLabel="Open floor →" title="Connecting your team" description={session.floorConnection === 'blocked' ? "Studio could not finish connecting the team. Your floor is available; an operator needs to check the connection." : "Studio is connecting the shared team and preparing this floor’s conversations. Grilling will become available automatically."} /> : session.nativeMissions?.cutover ? <ComposeNativeMission /> : <ComposeMission />} />
        <Route path="/missions/v2/new" element={(!session.nativeMissions && !session.legacyProject || session.floorConnection === 'connecting' || session.floorConnection === 'blocked') ? <PendingDestination actionTo="/floor" actionLabel="Open floor →" title="Connecting your team" description={session.floorConnection === 'blocked' ? "Studio could not finish connecting the team. Your floor is available; an operator needs to check the connection." : "Studio is connecting the shared team and preparing this floor’s conversations. Grilling will become available automatically."} /> : <ComposeNativeMission />} />
        <Route path="/missions/v2/:missionId" element={<NativeMissionDetail />} />
        <Route path="/missions/:missionId" element={session.legacyProject ? <MissionDetail /> : <p>Historical missions belong to the original Studio project.</p>} />
        <Route path="/desk" element={<MyDesk zen={zen} toggleZen={() => setScreenZen(value => !value)} />} />
        <Route path="/agents" element={<Agents />} />
        <Route path="/apps" element={<MyApps embedded suspended={loggingOut} />} />
        <Route path="/contributions" element={<Contributions />} />
        <Route path="/monitoring" element={<Monitoring />} />
        <Route path="/review" element={<ProjectReview missions={missions} native={nativeMissions} error={[legacyError ? readableError(list.error) : '', nativeList.isError ? readableError(nativeList.error) : ''].filter(Boolean).join(' ')} loading={(session.legacyProject && list.isPending) || !!session.nativeMissions && nativeList.isPending} />} />
        <Route path="/skills" element={<Skills />} />
        <Route path="/tools" element={<Navigate to={`/apps?${new URLSearchParams({ project: session.project.id })}`} replace />} />
        <Route path="/knowledge" element={<KnowledgeWorkspace />} />
        <Route path="/code" element={<CodeWorkspace />} />
        <Route path="/floors" element={<FloorManager />} />
        <Route path="/settings" element={<ProfileSettings logout={() => void logout()} loggingOut={loggingOut} />} />
        <Route path="/prototype" element={<PendingDestination title="Prototype" description="Inspect and compare exact project prototypes when the preview service is connected." />} />
        <Route path="/computer" element={<Navigate to={`/desk?${deskAlias}`} replace />} />
        <Route path="/screen" element={<Navigate to={`/desk?${deskAlias}`} replace />} />
        <Route path="/whiteboard" element={<Suspense fallback={<LoadingState label="Loading whiteboard…" size="page" overlay />}><WhiteboardWorkspace /></Suspense>} />
        <Route path="/operations" element={<Monitoring projectOnly />} />
        <Route path="*" element={<div className="ws-empty"><span className="ws-eyebrow">WORKSPACE</span><h1>This page is not here.</h1><Link className="ws-button" to="/floor">Return to the project floor</Link></div>} />
      </Routes></PageBoundary></RouteScope>}
  </WorkspaceShell></WorkspaceContext>;
}

export async function startWorkspace(root: HTMLElement): Promise<() => void> {
  let removeFonts: (() => void) | undefined;
  try { removeFonts = await mountStudioFonts(); } catch { /* System fonts keep the workspace usable if a font cannot load. */ }
  const app = createRoot(root);
  const router=createBrowserRouter([{ path:'*',element:<SessionGate /> }]);
  app.render(<QueryClientProvider client={queryClient}><RouterProvider router={router} /></QueryClientProvider>);
  return () => { app.unmount(); router.dispose(); queryClient.clear(); removeFonts?.(); };
}
