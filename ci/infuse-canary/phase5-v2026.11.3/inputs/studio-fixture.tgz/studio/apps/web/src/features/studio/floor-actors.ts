import * as THREE from 'three';
import { icons } from '@studio/ui/icons';
import { createOfficeCharacter } from '@studio/spatial/character';
import { createOfficeTravel, presenceRoute } from '@studio/spatial/office-presence';
import type { SpatialAgent, SpatialProjection } from './spatial-projection.js';

type Character = ReturnType<typeof createOfficeCharacter>;
type Travel = ReturnType<typeof createOfficeTravel>;
interface Occupant {
  key: string; agent: SpatialAgent; slot: number; character: Character; travel: Travel;
  pin: HTMLButtonElement; name: HTMLSpanElement; light: THREE.PointLight; marker: THREE.Mesh<THREE.BoxGeometry, THREE.MeshBasicMaterial>;
  gestureAt: number; gestureEnd: number; walkAt: number; ambientDesk: boolean; stride: number;
}
const seedOf = (key: string) => [...key].reduce((n,c)=>(Math.imul(n,31)+c.charCodeAt(0))>>>0,0);

/** Ephemeral visual state. Assignment and receipt truth remain in the floor projection. */
export function createFloorActors(layer: THREE.Group, labels: HTMLElement, wake: () => void) {
  const actors = new Map<string,Occupant>();
  let selected: string|null = null, presented = true, reduced = false, stale = false;
  let timer: ReturnType<typeof setTimeout>|undefined, last = 0, walker: string|undefined;

  const cancelWake = () => { if(timer!==undefined)clearTimeout(timer);timer=undefined; };
  function schedule(now: number) {
    cancelWake();
    if(!presented||reduced||stale||!actors.size)return;
    const next=Math.min(...[...actors.values()].flatMap(a=>[
      a.gestureEnd>now?a.gestureEnd:a.gestureAt,
      !a.agent.assigned&&presenceRoute(a.slot).lounge?a.walkAt:Infinity,
    ]));
    if(Number.isFinite(next))timer=setTimeout(()=>{timer=undefined;wake();},Math.max(30,next-now));
  }
  function remove(a: Occupant) {
    a.character.dispose(); a.pin.remove(); a.light.removeFromParent(); a.marker.removeFromParent();
    a.marker.geometry.dispose(); a.marker.material.dispose(); actors.delete(a.key);
    if(walker===a.key)walker=undefined;
  }
  function settle() {
    walker=undefined;last=0;
    const now=performance.now();
    for(const a of actors.values()) {
      a.ambientDesk=false;
      a.travel.aim(!!a.agent.assigned);a.travel.settle();a.gestureEnd=0;
      a.gestureAt=now+8000+seedOf(a.key)%9000;
      a.walkAt=now+45000+seedOf(a.key)%25000;
    }
  }
  function create(agent: SpatialAgent, now: number): Occupant {
    const key=agent.key!,slot=agent.seat!;
    const character=createOfficeCharacter(agent.appearance!);
    character.group.userData.deskKey=key;
    layer.add(character.group);
    const pin=document.createElement('button');pin.type='button';pin.className='studio-space-person-pin';
    pin.dataset.deskKey=key;pin.dataset.seat=String(slot);pin.dataset.character=agent.appearance!.detail;
    const icon=document.createElement('span');icon.className='studio-space-person-icon';
    icon.setAttribute('aria-hidden','true');icon.innerHTML=icons.profile;
    const name=document.createElement('span');
    pin.append(icon,name);
    labels.append(pin);
    const route=presenceRoute(slot),travel=createOfficeTravel(route,!!agent.assigned);
    character.group.rotation.y=travel.facing;
    const light=new THREE.PointLight(0xaddac3,0,2,2);
    light.position.set(route.desk.x,1.45,route.desk.z+Math.cos(route.desk.facing)*.9);layer.add(light);
    const marker=new THREE.Mesh(new THREE.BoxGeometry(.38,.018,.035),new THREE.MeshBasicMaterial({color:0x9ccbb0}));
    marker.position.set(route.desk.x,1.03,route.desk.z+Math.cos(route.desk.facing)*.65);layer.add(marker);
    return {key,agent,slot,character,travel,pin,name,light,marker,
      gestureAt:now+6000+seedOf(key)%9000,gestureEnd:0,walkAt:now+45000+seedOf(key)%25000,ambientDesk:false,stride:0};
  }
  return {
    update(projection: SpatialProjection) {
      const now=performance.now();stale=projection.stale;
      const shown=projection.agents.filter(a=>a.key&&a.appearance&&a.seat!==undefined);
      const keys=new Set(shown.map(a=>a.key!));
      for(const a of actors.values())if(!keys.has(a.key))remove(a);
      for(const agent of shown) {
        let a=actors.get(agent.key!);
        if(a&&a.slot!==agent.seat){remove(a);a=undefined;}
        if(!a){a=create(agent,now);actors.set(a.key,a);}
        const changed=a.agent.assigned!==agent.assigned;
        if(changed){a.ambientDesk=false;a.walkAt=now+45000+seedOf(a.key)%25000;}
        a.agent=agent;
        a.travel.aim(!!agent.assigned||a.ambientDesk);
        if(stale||reduced||!presented)a.travel.settle();
        if(!agent.running)a.gestureEnd=0;
        a.name.textContent=agent.name?.split(' ')[0]??agent.target.agentId;
        a.pin.title=agent.status;
        a.pin.setAttribute('aria-label',`${agent.name??agent.target.agentId} · ${agent.status}`);
        a.pin.setAttribute('aria-pressed',String(a.key===selected));
        a.character.select(a.key===selected);
      }
      schedule(now);
    },
    animate(now: number, moving: boolean) {
      const nextReduced=!moving;
      if(nextReduced!==reduced){reduced=nextReduced;if(reduced)settle();}
      const dt=last?Math.min(.1,(now-last)/1000):0;last=now;
      let active=false;
      if(walker&&!actors.get(walker)?.travel.moving)walker=undefined;
      for(const a of actors.values()) {
        if(moving&&!stale) {
          if(!a.agent.assigned&&presenceRoute(a.slot).lounge&&now>=a.walkAt&&!a.travel.moving) {
            a.ambientDesk=!a.ambientDesk;a.travel.aim(a.ambientDesk);
            a.walkAt=now+60000+seedOf(a.key)%20000;
          }
          if(a.travel.moving&&!walker)walker=a.key;
          a.travel.step(dt,walker===a.key);
          if(now>=a.gestureAt&&!a.travel.moving) {
            a.gestureEnd=now+1600;a.gestureAt=now+(a.agent.running?6000:14000)+seedOf(a.key)%5000;
          }
        } else a.travel.settle();
        const walking=a.travel.moving&&a.travel.seated===0&&walker===a.key;
        if(walking)a.stride+=dt*10;
        const gesture=moving&&!stale&&!a.travel.moving&&a.gestureEnd>now?Math.sin((1600-(a.gestureEnd-now))/1600*Math.PI*2):0;
        const working=!stale&&!!a.agent.running&&a.travel.atDesk&&!a.travel.moving;
        const position=a.travel.position;
        a.character.group.position.set(position.x,.13,position.z);
        const delta=Math.atan2(Math.sin(a.travel.facing-a.character.group.rotation.y),Math.cos(a.travel.facing-a.character.group.rotation.y));
        a.character.group.rotation.y+=moving?delta*Math.min(1,dt*14):delta;
        a.character.pose({seated:a.travel.seated,stride:a.stride,walking,gesture,working});
        a.light.intensity=working?.65:0;
        a.marker.visible=working||a.agent.tone==='evidence';
        a.marker.material.color.setHex(working?0x9ccbb0:0xd9bc80);
        a.pin.dataset.location=a.travel.moving?'walking':a.travel.atDesk?'desk':'lounge';
        a.pin.dataset.pose=a.travel.moving?(walking?'walking':'settling'):working?'working':'quiet';
        a.pin.dataset.working=String(working);
        a.pin.dataset.x=position.x.toFixed(3);a.pin.dataset.z=position.z.toFixed(3);
        active ||= moving&&!stale&&(a.travel.moving||a.gestureEnd>now||Math.abs(delta)>.01);
      }
      schedule(now);
      return active;
    },
    project(place: (pin: HTMLButtonElement, position: THREE.Vector3) => void) {
      for(const a of actors.values())place(a.pin,a.character.group.position.clone().add(new THREE.Vector3(0,2.05,0)));
    },
    select(key: string|null) {
      selected=key;
      for(const a of actors.values()){a.character.select(a.key===key);a.pin.setAttribute('aria-pressed',String(a.key===key));}
    },
    setPresented(value: boolean) {
      if(presented===value)return;
      presented=value;cancelWake();settle();if(value)schedule(performance.now());
    },
    dispose() { cancelWake();for(const a of actors.values())remove(a); },
  };
}
