import { Button } from './ui.js';
import { useEffect, useRef } from 'react';
import { useBlocker } from 'react-router';

let leaveCheck: (() => boolean) | undefined;
export function confirmWhiteboardExit(): boolean { return leaveCheck?.() ?? true; }

/** Router transitions can wait; closing/reloading uses the browser's native warning. */
export function useWhiteboardExit(dirty: boolean, discard: () => void) {
  const latest=useRef({ dirty,discard }); latest.current={ dirty,discard };
  const blocker=useBlocker(({ currentLocation,nextLocation }) => latest.current.dirty &&
    (currentLocation.pathname!==nextLocation.pathname || currentLocation.search!==nextLocation.search));
  useEffect(()=> {
    const check=()=> {
      if (!latest.current.dirty) return true;
      if (!window.confirm('Leave and discard local whiteboard drafts? An edit already sent may still be saved. Stay here to check its receipt first.')) return false;
      latest.current.discard(); return true;
    };
    leaveCheck=check;
    const unload=(event:BeforeUnloadEvent)=> { if (latest.current.dirty) { event.preventDefault(); event.returnValue=''; } };
    window.addEventListener('beforeunload',unload);
    return ()=> { if (leaveCheck===check) leaveCheck=undefined; window.removeEventListener('beforeunload',unload); };
  },[]);
  return blocker;
}

export function WhiteboardExitDialog({ blocker,discard }:{ blocker:ReturnType<typeof useWhiteboardExit>;discard():void }) {
  const dialog=useRef<HTMLDialogElement>(null);
  useEffect(()=> { if (blocker.state==='blocked') dialog.current?.showModal(); else dialog.current?.close(); },[blocker.state]);
  return <dialog ref={dialog} className="wboard-exit wboard-float" aria-label="Unsaved whiteboard work" onCancel={event=> { event.preventDefault(); if(blocker.state==='blocked') blocker.reset(); }}>
    <h2>Keep your work here?</h2><p>You have drafts or saves awaiting a receipt. Stay to settle them, or discard local recovery and leave. An edit already sent may still be saved.</p>
    <Button variant="quiet" autoFocus onClick={()=> { if(blocker.state==='blocked') blocker.reset(); }}>Stay on whiteboard</Button>
    <Button variant="quiet" onClick={()=> { if(blocker.state==='blocked') { discard(); blocker.proceed(); } }}>Discard local drafts and leave</Button>
  </dialog>;
}

/** Private text recovery belongs to the authenticated workspace, never a later sign-in. */
export function hasPendingWhiteboardText(owner: string): boolean {
  try { return Object.keys(sessionStorage).some(key => key.startsWith(`studio.whiteboard.text.pending:${owner}:`) || key===`studio.whiteboard.comments.pending:${owner}`); }
  catch { return false; } // Storage failure is handled by the editor before any send.
}

export function clearWhiteboardTextRecovery(owner?: string): void {
  try {
    for (const key of Object.keys(sessionStorage)) {
      if (owner===undefined ? key.startsWith('studio.whiteboard.comments.pending:') : key===`studio.whiteboard.comments.pending:${owner}`) sessionStorage.removeItem(key);
      if (['pending', 'editor'].some(kind => key.startsWith(`studio.whiteboard.text.${kind}:${owner === undefined ? '' : owner + ':'}`))) {
        sessionStorage.removeItem(key);
      }
    }
  } catch { /* Unavailable storage must not prevent hiding private projections. */ }
}
