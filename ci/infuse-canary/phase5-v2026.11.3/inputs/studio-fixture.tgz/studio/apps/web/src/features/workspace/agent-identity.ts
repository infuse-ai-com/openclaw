import type { CharacterAppearance } from '@studio/spatial/character';

const aliases: Record<string, string> = {
  emon: 'emon', 'agent-coordinator': 'emon', tinus: 'tinus', 'agent-developer': 'tinus',
  stewie: 'stewie', 'agent-designer': 'stewie', satwa: 'satwa', 'agent-infra': 'satwa',
  kapiteky: 'kapiteky', ramiro: 'ramiro', 'agent-intake': 'ramiro',
};
const appearances: Record<string, CharacterAppearance> = {
  emon: { shirt: 0xfe6b27, hair: 0x433324, skin: 0xc99c7c, detail: 'badge' },
  tinus: { shirt: 0x8c9cbc, hair: 0x272630, skin: 0xc99c7c, detail: 'headphones' },
  stewie: { shirt: 0x454b50, hair: 0x645344, skin: 0xc99c7c, detail: 'glasses' },
  satwa: { shirt: 0xc3ad70, hair: 0x865936, skin: 0xc99c7c, detail: 'cap' },
  kapiteky: { shirt: 0x7eb2ad, hair: 0xc5b398, skin: 0xc99c7c, detail: 'beard' },
  ramiro: { shirt: 0xb88169, hair: 0x352c28, skin: 0xc99c7c, detail: 'tie' },
};
/** Artwork aliases never collapse canonical Gateway/agent identities. */
export const agentPortraitId = (id: string) => aliases[id];
export const agentAppearance = (id: string): CharacterAppearance => appearances[aliases[id] ?? ''] ?? { shirt: 0x708775, hair: 0x39443c, skin: 0xbd9276, detail: 'plain' };
export const agentSeatPreference = (id: string) => ['emon', 'tinus', 'stewie', 'satwa', 'kapiteky', 'ramiro'].indexOf(aliases[id] ?? '');
