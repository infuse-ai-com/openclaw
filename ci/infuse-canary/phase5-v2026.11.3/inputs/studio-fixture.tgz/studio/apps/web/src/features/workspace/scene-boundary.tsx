import { Component, type ReactNode } from 'react';
import { Link } from './navigation.js';
import { isModuleLoadError, PageLoadFailure } from './page-boundary.js';
/** The optional scene must never take mission navigation down with a failed chunk. */
export class SceneBoundary extends Component<{ children: ReactNode }, { failed: boolean; moduleLoad: boolean }> {
  state = { failed: false, moduleLoad: false };
  static getDerivedStateFromError(error: unknown) { return { failed: true, moduleLoad: isModuleLoadError(error) }; }
  render() {
    if (this.state.moduleLoad) return <PageLoadFailure moduleLoad />;
    return this.state.failed ? <section className="ws-scene-error" aria-label="Office unavailable"><h2>Office view unavailable.</h2><p>Your missions and decisions remain available.</p><Link className="ws-button" to="/missions">Open missions</Link></section> : this.props.children;
  }
}
