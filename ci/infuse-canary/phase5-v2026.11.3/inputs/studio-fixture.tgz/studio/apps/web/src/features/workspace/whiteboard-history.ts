import { whiteboardSessionStorage } from './whiteboard-storage.js';
export type HistoryIntent={commandId:string;sectionId:string;direction:'edit'|'undo'|'redo';target?:string};
type Stacks={undo:string[];redo:string[]};
type Stored={sections:Record<string,Stacks>;settled:string[]};
/** Only receipt IDs live here. The writer owns all inverse data and conflict checks. */
export class BoardHistory {
  private state:Stored={sections:Object.create(null),settled:[]};
  constructor(private key:string, private storage:Storage=whiteboardSessionStorage()){try{const raw=JSON.parse(this.storage.getItem(key)??'null');if(raw&&Array.isArray(raw.settled)&&raw.sections&&typeof raw.sections==='object'){
    for(const [section,entry] of Object.entries(raw.sections).slice(0,100)){const s=entry as Stacks;if(Array.isArray(s.undo)&&Array.isArray(s.redo)&&[...s.undo,...s.redo].every(id=>typeof id==='string'&&id.length<=128))this.state.sections[section]={undo:s.undo.slice(-50),redo:s.redo.slice(-50)};}
    this.state.settled=raw.settled.filter((id:unknown)=>typeof id==='string').slice(-100);
  }}catch{/* A corrupt view history cannot affect saved work. */}}
  get(section:string):Stacks{return this.state.sections[section]??{undo:[],redo:[]};}
  prepare(intent:HistoryIntent){this.storage.setItem(this.key+'.pending',JSON.stringify(intent));}
  settle(commandId:string,applied:boolean){
    const raw=this.storage.getItem(this.key+'.pending');const intent:HistoryIntent|undefined=raw?JSON.parse(raw):undefined;
    if(!intent||intent.commandId!==commandId||this.state.settled.includes(commandId))return;
    if(applied){const stacks=this.get(intent.sectionId);
      if(intent.direction==='edit'){stacks.redo=[];stacks.undo=[...stacks.undo,commandId].slice(-50);}
      else {const from=intent.direction==='undo'?'undo':'redo',to=intent.direction==='undo'?'redo':'undo';if(stacks[from].at(-1)===intent.target)stacks[from].pop();else stacks[from]=[];stacks[to]=[...stacks[to],commandId].slice(-50);}
      this.state.sections[intent.sectionId]=stacks;
    }
    this.state.settled=[...this.state.settled,commandId].slice(-100);
    this.storage.setItem(this.key,JSON.stringify(this.state));this.storage.removeItem(this.key+'.pending');
  }
  clear(){this.state={sections:Object.create(null),settled:[]};this.storage.removeItem(this.key);this.storage.removeItem(this.key+'.pending');}
}
export function isTyping(target:EventTarget|null){return target instanceof Element&&!!target.closest('input,textarea,select,[contenteditable="true"],[role="textbox"]');}
