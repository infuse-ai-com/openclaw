import { LoadingState } from '../../../loading.js';
import type { History } from '@studio/contracts/knowledge';
import { TerminalState } from './TerminalState';

interface HistoryTimelineProps {
  currentPath: string | undefined;
  error: boolean;
  history: History | undefined;
  onCompareRevision: (commit: string) => void;
  onRetry: () => void;
}

function formatHistoryDate(value: string): string {
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value));
}

export function HistoryTimeline({
  currentPath,
  error,
  history,
  onCompareRevision,
  onRetry,
}: HistoryTimelineProps) {
  if (error) {
    return (
      <TerminalState
        actions={
          <button onClick={onRetry} type="button">
            Retry history
          </button>
        }
        detail="The indexed snapshot is still readable. Its revision timeline could not be loaded."
        eyebrow="Document history"
        title="History is temporarily unavailable"
      />
    );
  }

  if (!history) {
    return <LoadingState label="Loading history…" size="panel" />;
  }

  if (history.entries.length === 0) {
    return (
      <TerminalState
        detail="No revision touching this path is present in the indexed history."
        eyebrow="Document history"
        title="No history is available"
      />
    );
  }

  return (
    <div className="history-timeline-wrap">
      <ol aria-label="Document revision timeline" className="history-timeline">
        {history.entries.map((entry, index) => {
          const current = index === 0;
          const pathChanged = entry.path !== (currentPath ?? history.path);
          return (
            <li key={entry.commit}>
              <span aria-hidden="true" className="history-timeline-marker" />
              <article className="history-entry-card">
                <div className="history-entry-heading">
                  <div className="history-entry-meta">
                    <time dateTime={entry.authoredAt}>
                      {formatHistoryDate(entry.authoredAt)}
                    </time>
                    <span aria-hidden="true">·</span>
                    <span>{entry.authorName}</span>
                    <span aria-hidden="true">·</span>
                    <code>{entry.commit.slice(0, 8)}</code>
                  </div>
                  {current && <em>Current</em>}
                </div>
                <h3>{entry.message}</h3>
                {pathChanged && (
                  <p className="history-path">
                    <span>Path</span>
                    <strong>{entry.path}</strong>
                  </p>
                )}
                {entry.renamedFrom && (
                  <p className="history-rename">
                    <span>Renamed from</span>
                    <strong>{entry.renamedFrom}</strong>
                  </p>
                )}
                {!current && (
                  <div
                    aria-label={`Actions for ${entry.message}`}
                    className="history-entry-actions"
                  >
                    <button
                      aria-label={`Compare ${entry.message} with current revision`}
                      onClick={() => onCompareRevision(entry.commit)}
                      title="Compare revisions"
                      type="button"
                    >
                      <svg aria-hidden="true" viewBox="0 0 20 20">
                        <path d="M6 4.5h8M6 15.5h8M8.5 2 6 4.5 8.5 7M11.5 13 14 15.5 11.5 18" />
                      </svg>
                    </button>
                    {entry.sourceUrl && (
                      <a
                        aria-label={`Open exact revision for ${entry.message}`}
                        href={entry.sourceUrl}
                        rel="noreferrer"
                        target="_blank"
                        title="Open exact revision"
                      >
                        <svg aria-hidden="true" viewBox="0 0 20 20">
                          <path d="M10.5 4H16v5.5M16 4l-7 7M14 11.5V15a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h3.5" />
                        </svg>
                      </a>
                    )}
                  </div>
                )}
              </article>
            </li>
          );
        })}
      </ol>
      {history.truncated && (
        <p className="history-truncated">
          Showing the newest {history.limit} revisions.
        </p>
      )}
    </div>
  );
}
