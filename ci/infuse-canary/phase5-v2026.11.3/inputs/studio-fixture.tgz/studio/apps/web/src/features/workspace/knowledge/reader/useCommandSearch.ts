import { useEffect, useRef, useState, type SubmitEvent } from 'react';
import type {
  MeaningSearchResponse,
  SearchResult,
  SemanticReadinessResponse,
} from '@studio/contracts/knowledge';
import { useKnowledgeApi } from './api';
import type { SearchMode } from './components/CommandSearch';
import { LatestRequest } from './latestRequest';

export function useCommandSearch(open: boolean, repository = '') {
  const { projectId, scopeRevision, loadSemanticReadiness,
  searchDocuments,
  searchDocumentsByMeaning, } = useKnowledgeApi();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [meaningResponse, setMeaningResponse] =
    useState<MeaningSearchResponse>();
  const [mode, setMode] = useState<SearchMode>('keywords');
  const [error, setError] = useState<string>();
  const [pending, setPending] = useState(false);

  const [hasSearched, setHasSearched] = useState(false);
  const [responseRepository, setResponseRepository] = useState(repository);
  const requestsRef = useRef(new LatestRequest());
  const [readiness, setReadiness] = useState<SemanticReadinessResponse>();
  const [readinessError, setReadinessError] = useState(false);
  const [readinessPending, setReadinessPending] = useState(false);
  const readinessRequestsRef = useRef(new LatestRequest());

  useEffect(() => {
    requestsRef.current.invalidate();
    setPending(false);
    setResults([]);
    setMeaningResponse(undefined);
    setHasSearched(false);
    setError(undefined);
    return () => requestsRef.current.invalidate();
  }, [repository, projectId, scopeRevision]);

  useEffect(() => {
    if (!open) {
      readinessRequestsRef.current.invalidate();
      setReadinessPending(false);
      return;
    }
    const request = readinessRequestsRef.current.begin();
    setReadiness(undefined);
    setReadinessPending(true);
    setReadinessError(false);
    void loadSemanticReadiness(repository || undefined)
      .then((response) => {
        if (readinessRequestsRef.current.owns(request)) {
          setReadiness(response);
        }
      })
      .catch(() => {
        if (readinessRequestsRef.current.owns(request)) {
          setReadiness(undefined);
          setReadinessError(true);
        }
      })
      .finally(() => {
        if (readinessRequestsRef.current.owns(request)) {
          setReadinessPending(false);
        }
      });
    return () => readinessRequestsRef.current.invalidate();
  }, [open, repository, loadSemanticReadiness]);

  async function run(nextMode: SearchMode = mode) {
    if (!query.trim()) return;
    setError(undefined);
    setPending(true);
    setHasSearched(false);
    setResults([]);
    setMeaningResponse(undefined);
    const request = requestsRef.current.begin();
    try {
      if (nextMode === 'keywords') {
        const nextResults = await searchDocuments(
          query,
          repository || undefined,
        );
        if (!requestsRef.current.owns(request)) return;
        setResults(nextResults);
      } else {
        const response = await searchDocumentsByMeaning(
          query,
          repository || undefined,
        );
        if (!requestsRef.current.owns(request)) return;
        setMeaningResponse(response);
      }
      setResponseRepository(repository);
      setHasSearched(true);
    } catch {
      if (requestsRef.current.owns(request)) {
        setError(
          nextMode === 'keywords'
            ? 'Search is temporarily unavailable. Try again.'
            : 'Search by meaning is temporarily unavailable. Try again.',
        );
      }
    } finally {
      if (requestsRef.current.owns(request)) setPending(false);
    }
  }

  async function submit(event: SubmitEvent<HTMLFormElement>) {
    event.preventDefault();
    await run();
  }

  function changeMode(nextMode: SearchMode) {
    if (nextMode === mode) return;
    cancelSearch();
    setMode(nextMode);
    setError(undefined);
    setHasSearched(false);
    setResults([]);
    setMeaningResponse(undefined);
  }

  function searchByMeaning() {
    changeMode('meaning');
    void run('meaning');
  }

  function cancel() {
    cancelSearch();
    readinessRequestsRef.current.invalidate();
    setReadinessPending(false);
  }

  function cancelSearch() {
    requestsRef.current.invalidate();
    setPending(false);
  }

  return {
    cancel,
    changeMode,
    error,
    hasSearched: responseRepository === repository && hasSearched,
    meaningResponse:
      responseRepository === repository ? meaningResponse : undefined,
    mode,
    pending,
    query,
    readiness,
    readinessError,
    readinessPending,
    repository,
    results: responseRepository === repository ? results : [],
    searchByMeaning,
    setError,
    setQuery,
    submit,
  };
}
