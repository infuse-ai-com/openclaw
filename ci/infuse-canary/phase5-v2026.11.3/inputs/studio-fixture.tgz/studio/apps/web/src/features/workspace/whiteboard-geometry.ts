import type { WhiteboardSpatialOperation } from '@studio/contracts';
import type { CanvasItem, Bounds } from './whiteboard-types.js';
export function geometryUpdate(
  item: CanvasItem,
  bounds: Partial<Bounds>,
): WhiteboardSpatialOperation {
  return item.kind === 'section' || item.kind === 'html' || item.kind === 'image'
    ? { type: 'updateTile', id: item.id, expectedRevision: item.revision, patch: bounds }
    : item.kind === 'stroke'
      ? { type: 'updateStroke', id: item.id, expectedRevision: item.revision, patch: bounds }
      : { type: 'update', id: item.id, expectedRevision: item.revision, patch: bounds };
}
