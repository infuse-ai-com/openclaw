import { Button } from './ui.js';
import { useEffect, useRef, useState } from 'react';
import type { SkillGuideCatalog, SkillGuideProvenance } from '@studio/contracts';
import { Link } from './navigation.js';
import { projectPath } from './api.js';
import motif from '../../../../../packages/ui/assets/skill-reader-motif.png';

function useReaderFocus(explicit: boolean) {
  const title = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    const reader = title.current?.closest('.sg-reader');
    if (reader) reader.scrollTop = 0;
    if (explicit) title.current?.focus({ preventScroll: true });
  }, [explicit]);
  return title;
}
const sourceLink = (p: { path: string }) => `/knowledge?${new URLSearchParams({ project: 'core', repo: 'agent-skills', path: p.path })}`;

export function SkillReader({ p, catalog, revision, explicit, close, clear, filtered }: {
  p: SkillGuideProvenance; catalog: SkillGuideCatalog; revision: string; explicit: boolean;
  close(): void; clear(): void; filtered: boolean;
}) {
  const g = p.guide;
  const entry = catalog.entries.find(e => e.id === g.id)!;
  const [sourceOpen, setSourceOpen] = useState(false);
  const sourceRef = useRef<HTMLDetailsElement>(null);
  const title = useReaderFocus(explicit);
  const fileEndpoint = projectPath(`/api/studio/artifacts/${catalog.producer}/${entry.artifactId}/${entry.revision}/download?path=index.html`, 'core');
  function readSource() {
    setSourceOpen(true);
    requestAnimationFrame(() => {
      sourceRef.current?.scrollIntoView({ block: 'start', behavior: 'instant' });
      sourceRef.current?.querySelector('summary')?.focus({ preventScroll: true });
    });
  }
  return <article className="sg-guide">
    <nav className="sg-reader-toolbar" aria-label="Guide actions"><Button variant="quiet" onClick={close}>← Back to results</Button><div>{filtered && <Button variant="quiet" onClick={clear}>All skills</Button>}<a href={fileEndpoint}>Download HTML ↓</a></div></nav>
    <div className="sg-reader-page">
      <header className="sg-guide-heading"><span className="sg-kicker">{g.category} / FIELD GUIDE</span><h2 ref={title} tabIndex={-1}>{g.name}</h2><p className="sg-promise">{g.promise}</p></header>
      <img className="sg-reader-motif" src={motif} alt="" />
      <section className="sg-when"><h3>When this helps</h3><p>{g.when}</p></section>
      <div className="sg-pair"><section><h3>Bring</h3><p>{g.input}</p></section><section><h3>Walk away with</h3><p>{g.output}</p></section></div>
      <section className="sg-how"><h3>How it works</h3><ol className="sg-steps">{g.steps.map(([name, description], i) => <li key={name}><span className="sg-step-index">{String(i + 1).padStart(2, '0')}</span><div><h4>{name}</h4><p>{description}</p></div></li>)}</ol></section>
      <aside className="sg-example"><h3>In practice</h3><p>{g.example}</p></aside>
      <section><h3>A useful boundary</h3><p>{g.guardrail}</p></section>
      {!!g.apps.length && <section className="sg-companions"><h3>Supporting apps</h3><div className="sg-apps">{g.apps.map(a => <div className="sg-app-reference" key={a.id}><strong>{catalog.apps.find(x => x.id === a.id)?.name}</strong><small>{a.relation === 'source' ? 'Source-backed' : 'Suggested companion'}</small></div>)}</div></section>}
      <div className="sg-source-action"><Button onClick={readSource}>Read full source instructions</Button><span>Exact instructions behind this guide</span></div>
      <details className="sg-source" ref={sourceRef} open={sourceOpen} onToggle={e => setSourceOpen(e.currentTarget.open)}><summary>Full source instructions</summary><p>{p.source.repository} / {p.source.path} · {p.source.branch}@{p.source.commit.slice(0, 8)}</p><pre>{p.markdown}</pre><Button variant="quiet" onClick={() => { setSourceOpen(false); title.current?.closest('.sg-reader')?.scrollTo({ top: 0, behavior: 'instant' }); title.current?.focus({ preventScroll: true }); }}>Back to human guide ↑</Button> <Link to={sourceLink(p.source)}>Open current source in Knowledge ↗</Link><p>The instructions above are the exact version used for this guide. Knowledge opens the current indexed source, which may have changed.</p></details>
      <details className="sg-source"><summary>Source and generation details</summary><dl><dt>Source commit</dt><dd>{p.source.commit}</dd><dt>Source SHA-256</dt><dd>{p.source.sha256}</dd><dt>Generated</dt><dd>{p.generatedAt}</dd><dt>HTML SHA-256</dt><dd>{p.htmlSha256}</dd><dt>Artifact revision</dt><dd>{entry.revision}</dd><dt>Catalog release</dt><dd>{revision}</dd><dt>Generation recipe</dt><dd>{p.recipe.version} · {p.recipe.sha256}</dd></dl><details><summary>{p.inputs.length} hashed source files</summary><dl>{p.inputs.map(f => <div key={f.path}><dt>{f.path}</dt><dd>{f.sha256}</dd></div>)}</dl></details></details>
      <footer className="sg-reader-note">Reading a guide does not install a skill or grant app access.</footer>
    </div>
  </article>;
}
