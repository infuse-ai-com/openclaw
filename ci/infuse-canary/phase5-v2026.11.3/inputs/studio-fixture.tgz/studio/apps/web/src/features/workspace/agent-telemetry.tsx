import { Button } from './ui.js';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { parseAgentTelemetry, type TelemetrySource, type RuntimeTarget, type RuntimeObservation, type ModelObservation, type CollectorObservation, type UsageBucket, type TokenTotals } from '@studio/contracts';
import { useWorkspace } from './context.js';
import { api } from './api.js';
import { modelVerdict } from './agent-telemetry-summary.js';
import { AgentSchedules } from './agent-schedules.js';
import type { ScheduleObservation } from '@studio/contracts';
import './agent-telemetry.css';
const format=(v:number|null|undefined)=>v===null||v===undefined?'Unknown':new Intl.NumberFormat('en').format(v);
const date=(v:string|undefined)=>v?new Date(v).toLocaleString(): 'Not recorded';
function SourceTimes({source:s}:{source:TelemetrySource}){
  return <section className="ws-telemetry-times"><h5>Source and freshness</h5><dl><dt>Source</dt><dd>{s.sourceId}</dd><dt>Generated</dt><dd>{date(s.generatedAt)}</dd><dt>Observed</dt><dd>{date(s.observedAt)}</dd><dt>Imported</dt><dd>{date(s.importedAt)}</dd><dt>Last attempt</dt><dd>{date(s.lastAttemptAt)}</dd><dt>Last success</dt><dd>{date(s.lastSuccessAt)}</dd><dt>Reported state</dt><dd>{s.sourceStatus??'Unknown'}</dd>{s.lastError&&<><dt>Collection</dt><dd>{s.lastError}</dd></>}</dl></section>;
}
function usageRows(buckets:UsageBucket[],view:string){
  const map=new Map<string,TokenTotals>();
  for(const b of buckets){const key=view==='model'?`${b.provider} / ${b.model}`:view==='four-hour'?`${b.start} · ${b.minutes===1440?'Daily fallback':'4 hours'}`:b.start.slice(0,10);
    const total=map.get(key)??{input:0,output:0,cacheRead:0,cacheWrite:0,totalTokens:0};for(const k of Object.keys(total) as (keyof TokenTotals)[])total[k]+=b[k];map.set(key,total);}
  return [...map.entries()].sort((a,b)=>view==='model'?b[1].totalTokens-a[1].totalTokens:a[0].localeCompare(b[0]));
}
function Usage({source:s}:{source:TelemetrySource}){
  const [view,setView]=useState('daily'),usage=s.usage,rows=usageRows(usage?.buckets??[],view);
  return <><div className="ws-telemetry-totals"><div><span>Today · UTC</span><strong>{format(usage?.today?.totalTokens)}</strong></div><div><span>Last seven days · UTC</span><strong>{format(usage?.last7d?.totalTokens)}</strong></div></div>
    <p>Reported tokens from recorded buckets. Missing days are unknown; partial coverage is shown below. Cache counters may overlap input.</p>
    <label className="ws-telemetry-select">Usage view <select aria-label={`Usage view ${s.sourceId}`} value={view} onChange={e=>setView(e.target.value)}><option value="daily">Daily</option><option value="four-hour">Four-hour periods</option><option value="model">Provider / model</option></select></label>
    {rows.length?<div className="ws-telemetry-table" tabIndex={0} role="region" aria-label="Recorded token usage"><table><thead><tr><th>{view==='model'?'Provider / model':view==='daily'?'UTC day':'UTC period'}</th><th>Input</th><th>Output</th><th>Cache read</th><th>Cache write</th><th>Reported total</th></tr></thead><tbody>{rows.map(([key,t])=><tr key={key}><th scope="row">{key}</th><td>{format(t.input)}</td><td>{format(t.output)}</td><td>{format(t.cacheRead)}</td><td>{format(t.cacheWrite)}</td><td>{format(t.totalTokens)}</td></tr>)}</tbody></table></div>:<p>No retained usage buckets. A missing window does not establish zero use.</p>}
    {s.usageSummary&&<section><h5>Feed-reported window summary</h5><p>As of {date(s.generatedAt)}. These source-reported totals are separate from retained bucket coverage.</p><dl><dt>Reported today</dt><dd>{format(s.usageSummary.today?.totalTokens)}</dd><dt>Reported last seven days</dt><dd>{format(s.usageSummary.last7d?.totalTokens)}</dd></dl>{!!s.usageSummary.byModel.length&&<><p>Provider/model totals for the feed's reported window:</p><div className="ws-telemetry-table"><table><thead><tr><th>Provider / model</th><th>Reported total</th></tr></thead><tbody>{s.usageSummary.byModel.map(r=><tr key={JSON.stringify([r.provider,r.model])}><th scope="row">{r.provider} / {r.model}</th><td>{format(r.totalTokens)}</td></tr>)}</tbody></table></div></>}</section>}
    {!!usage?.days.length&&<section><h5>Recorded coverage · {usage.days.length} UTC {usage.days.length===1?'day':'days'}</h5>{usage.days.map(d=><p key={d.date}>{d.date} · {d.granularity==='daily'?'Daily fallback':`${d.minutes/60} hours of detailed periods`}</p>)}</section>}
  </>;
}
function Source({source:s}:{source:TelemetrySource}){
  const titles={usage:'Token usage',runtime:'Runtime health',model:'Model policy',collectors:'Collector summary',schedules:'Scheduled tasks'};
  let content;
  if(s.kind==='usage')content=<Usage source={s}/>;
  else if(!s.data)content=<p>No successful observation recorded.</p>;
  else if(s.kind==='schedules')content=<AgentSchedules data={s.data as ScheduleObservation}/>;
  else if(s.kind==='runtime'){
    const d=s.data as RuntimeObservation,label=s.state!=='fresh'?'Unknown · evidence is not current':d.desiredReplicas===0?'Scaled to zero':d.readyReplicas>=d.desiredReplicas?'Ready':'Degraded';
    content=<><strong className="ws-telemetry-verdict">{label}</strong><dl><dt>Ready / desired replicas</dt><dd>{d.readyReplicas} / {d.desiredReplicas}</dd><dt>Container restarts</dt><dd>{d.restarts}</dd><dt>Runtime version</dt><dd>{d.version??'Not reported'}</dd><dt>Image</dt><dd>{d.image??'Not reported'}</dd></dl><p>Sampled workload health does not establish idle/busy state or execution enrollment.</p></>;
  }else if(s.kind==='model'){
    const d=s.data as ModelObservation,keys=[...new Set([...Object.keys(d.declared),...Object.keys(d.observed)])] as (keyof ModelObservation['declared'])[];
    const labels={model:'Model',thinkingDefault:'Thinking',reasoningDefault:'Reasoning',runtime:'Runtime',roleIntent:'Role intent'};
    content=<><strong className="ws-telemetry-verdict">{modelVerdict(s).label}</strong><div className="ws-telemetry-table"><table><thead><tr><th>Setting</th><th>Declared</th><th>Observed</th></tr></thead><tbody>{keys.map(k=><tr key={k}><th scope="row">{labels[k]}</th><td>{d.declared[k]??'Not declared'}</td><td>{d.observed[k]??'Not observed'}{d.mismatchFields.includes(k)?' · differs':''}</td></tr>)}</tbody></table></div>{d.declared.roleIntent!==undefined&&d.observed.roleIntent===undefined&&<p>Role intent is declared context and has not been observed by this source. The full policy comparison remains incomplete.</p>}</>;
  }else {const d=s.data as CollectorObservation;content=<><p>Sanitized counts in this source observation, with a 24-hour recent activity window. Sessions and tasks can describe related work; these counts are not distinct missions.</p><dl>{([['Sessions',d.sessions],['Tasks',d.tasks],['Recent running records',d.running],['Recent waiting records',d.waiting],['Completed in 24h',d.completed24h],['Failed in 24h',d.failed24h],['Unclassified / undated',d.unknown]] as const).map(([label,value])=><div key={label}><dt>{label}</dt><dd>{format(value)}</dd></div>)}</dl></>;}
  return <article className={`ws-telemetry-source ws-telemetry-source--${s.state}`} data-source={s.sourceId}><header><h4>{titles[s.kind]}</h4><span>{s.state==='fresh'?'Current':s.state}</span></header>{s.state!=='fresh'&&s.data&&<p role="status">Last recorded observation · {s.state}. Current state is unknown.</p>}{s.state!=='fresh'&&s.usage&&<p role="status">Recorded usage · source {s.state}.</p>}{content}<SourceTimes source={s}/></article>;
}
export function agentTelemetryQuery(authorityId:string,profileId:string,projectId:string,target:RuntimeTarget,current:boolean,visible:boolean){
  return {queryKey:['workspace','agent-telemetry',authorityId,profileId,projectId,target.gatewayId,target.agentId],enabled:current,
    queryFn:async({signal}:{signal:AbortSignal})=>{
      try{const value=parseAgentTelemetry(await api(`/api/projects/${encodeURIComponent(projectId)}/agents/${encodeURIComponent(target.gatewayId)}/${encodeURIComponent(target.agentId)}/telemetry`,{signal}));
        if(value.gatewayId!==target.gatewayId||value.agentId!==target.agentId)throw Error('Telemetry identity changed');return {value};}
      catch{if(signal.aborted)throw Error('Telemetry request cancelled');return {unavailable:true as const};}
    },gcTime:0,staleTime:10000,refetchInterval:current&&visible?15000:false as const,refetchOnWindowFocus:true};
}
export function AgentTelemetryPanel({target,projectId}:{target:RuntimeTarget;projectId:string}){
  const {session,current,visible}=useWorkspace();
  const query=useQuery(agentTelemetryQuery(session.bootstrap.authorityId,session.profileId,projectId,target,current,visible));
  const value=current&&query.data&&'value'in query.data?query.data.value:undefined;
  return <section tabIndex={-1} id="agent-telemetry" className="ws-agent-section ws-agent-telemetry" aria-label="Agent telemetry"><div className="ws-telemetry-heading"><h3>Agent telemetry</h3><Button variant="quiet" disabled={!current||query.isFetching} onClick={()=>void query.refetch()}>Refresh telemetry</Button></div><p>Recorded usage and operational evidence for this Gateway and agent.</p>
    {!current?<p>Reconnect to refresh telemetry.</p>:query.isPending?<p role="status">Loading telemetry…</p>:!value?<p role="status">Telemetry is unavailable. Current evidence cannot be shown.</p>:<>
      {value.configuration==='imported'&&<p>Retained imported records. No live telemetry collection is configured.</p>}
      {value.configuration==='paused'&&<p role="status">Collection is paused. Recorded evidence remains subject to its source freshness.</p>}
      {!value.sources.length&&<p>{value.configuration==='unconfigured'?'Telemetry is not configured for this agent.':'Waiting for the first recorded source observation.'}</p>}
      {value.sources.length<(value.configuredSourceCount??0)&&<p>Some configured sources have no recorded observation yet.</p>}
      <div className="ws-telemetry-sources">{value.sources.map(s=><Source key={s.sourceId} source={s}/>)}</div>
    </>}
  </section>;
}
