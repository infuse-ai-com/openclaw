import type { GraphNode, KnowledgeGraph } from '@studio/contracts/knowledge';

const filterValues = {
  repository: (node: GraphNode) => [node.repository],
  cluster: (node: GraphNode) => [node.clusterId],
  type: (node: GraphNode) => [node.type],
  status: (node: GraphNode) => [node.status],
  owner: (node: GraphNode) => [node.owner],
  tag: (node: GraphNode) => node.tags,
};
export type FilterKind = keyof typeof filterValues;
export type FilterPreview = { kind: FilterKind; value: string };
export type HiddenFilters = Record<FilterKind, ReadonlySet<string>>;
const kinds = Object.keys(filterValues) as FilterKind[];

export function emptyFilters(): HiddenFilters {
  return {
    repository: new Set(),
    cluster: new Set(),
    type: new Set(),
    status: new Set(),
    owner: new Set(),
    tag: new Set(),
  };
}

export function changeFilter(
  hidden: HiddenFilters,
  kind: FilterKind,
  value: string,
  action: 'toggle' | 'show',
): HiddenFilters {
  const next = new Set(hidden[kind]);
  if (action === 'show' || next.has(value)) next.delete(value);
  else next.add(value);
  return { ...hidden, [kind]: next };
}

export function neighborIds(edges: KnowledgeGraph['edges'], id?: string): Set<string> {
  if (!id) return new Set();
  const ids = new Set([id]);
  for (const edge of edges) {
    if (edge.sourceId === id) ids.add(edge.targetId);
    if (edge.targetId === id) ids.add(edge.sourceId);
  }
  return ids;
}

export function projectGraph(
  graph: KnowledgeGraph,
  hidden: HiddenFilters,
  scope: 'global' | 'local',
  focusId?: string,
) {
  const local = neighborIds(graph.edges, focusId);
  const nodes = graph.nodes.filter(
    (node) =>
      kinds.every((kind) => !filterValues[kind](node).some((value) => hidden[kind].has(value))) &&
      (scope === 'global' || local.has(node.id)),
  );
  const ids = new Set(nodes.map((node) => node.id));
  const edges = graph.edges.filter((edge) => ids.has(edge.sourceId) && ids.has(edge.targetId));
  return { nodes, edges };
}

export function filterPreviewIds(nodes: GraphNode[], preview: FilterPreview): Set<string> {
  return new Set(
    nodes
      .filter((node) => filterValues[preview.kind](node).includes(preview.value))
      .map((node) => node.id),
  );
}

/** Counts describe the admitted graph, independently of which nodes are hidden. */
export function graphCounts(nodes: GraphNode[]) {
  const counts = Object.fromEntries(
    kinds.map((kind) => [kind, new Map<string, number>()]),
  ) as Record<FilterKind, Map<string, number>>;
  for (const node of nodes)
    for (const kind of kinds)
      for (const value of filterValues[kind](node)) {
        counts[kind].set(value, (counts[kind].get(value) ?? 0) + 1);
      }
  const repositories = [...counts.repository.keys()].sort((left, right) =>
    left.localeCompare(right, 'en'),
  );
  const repositoryInsights = new Map<
    string,
    { exceptions: number; owners: number; topTags: string[] }
  >();
  for (const repository of repositories) {
    const members = nodes.filter((node) => node.repository === repository);
    const tags = new Map<string, number>();
    for (const node of members)
      for (const tag of node.tags) tags.set(tag, (tags.get(tag) ?? 0) + 1);
    repositoryInsights.set(repository, {
      exceptions: members.filter((node) => node.status !== 'active').length,
      owners: new Set(members.map((node) => node.owner)).size,
      topTags: [...tags]
        .sort(([left, a], [right, b]) => b - a || left.localeCompare(right))
        .slice(0, 2)
        .map(([tag]) => tag),
    });
  }
  return { counts, repositories, repositoryInsights };
}

export function graphDegrees(edges: KnowledgeGraph['edges']) {
  const degree = new Map<string, number>();
  for (const edge of edges) {
    degree.set(edge.sourceId, (degree.get(edge.sourceId) ?? 0) + 1);
    degree.set(edge.targetId, (degree.get(edge.targetId) ?? 0) + 1);
  }
  return degree;
}
