import { IconButton, Button } from './ui.js';
import { useEffect,useRef,useState } from 'react';
import { useReactFlow,useViewport } from '@xyflow/react';
import type { WhiteboardStroke } from '@studio/contracts';
import { PenOptions,strokeColors } from './whiteboard-drawing.js';
import { commonShapes,extraShapes,shapeNames,shapePoints,shapeStroke,defaultShape,type ShapeKind,type ShapePoint } from './whiteboard-shapes.js';

export function ShapeIcon({kind}:{kind:ShapeKind}) {
  const points=shapePoints(kind,[0,0],[22,20]);
  // Center the visible geometry too: arrowheads and polygons have uneven extents.
  const xs=points.map(([x])=>x),ys=points.map(([,y])=>y);
  const offsetX=15-(Math.min(...xs)+Math.max(...xs))/2,offsetY=15-(Math.min(...ys)+Math.max(...ys))/2;
  return <svg className="wboard-shape-icon" viewBox="0 0 30 30" aria-hidden="true"><polyline points={points.map(([x,y])=>`${x+offsetX},${y+offsetY}`).join(' ')} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
export function ShapePalette({kind,choose,color,width,setColor,setWidth}:{kind:ShapeKind;choose(kind:ShapeKind):void;color:WhiteboardStroke['color'];width:number;setColor(color:WhiteboardStroke['color']):void;setWidth(width:number):void}) {
  const [popup,setPopup]=useState<'more'|'style'|null>(null);const host=useRef<HTMLDivElement>(null),more=useRef<HTMLButtonElement>(null),style=useRef<HTMLButtonElement>(null);
  useEffect(()=>{const outside=(event:PointerEvent)=>{if(!host.current?.contains(event.target as Node))setPopup(null);};document.addEventListener('pointerdown',outside);return()=>document.removeEventListener('pointerdown',outside);},[]);
  const pick=(value:ShapeKind)=>{setPopup(null);choose(value);};
  return <div ref={host} className="wboard-shape-options wboard-float" role="group" aria-label="Shapes" onKeyDown={event=>{if(event.key==='Escape'&&popup){event.stopPropagation();setPopup(null);(popup==='more'?more:style).current?.focus();}}}>
    <div className="wboard-shape-strip"><IconButton ref={style} type="button" className="wboard-shape-style" aria-label="Shape style" title="Color and thickness" aria-expanded={popup==='style'} aria-controls="wboard-shape-style" onClick={()=>setPopup(v=>v==='style'?null:'style')}><span style={{borderColor:strokeColors[color],borderWidth:Math.min(5,width)}}/><span aria-hidden="true">⌄</span></IconButton><span className="wboard-divider"/>
      {commonShapes.map(value=><IconButton type="button" key={value} aria-label={'Draw '+shapeNames[value].toLowerCase()} title={shapeNames[value]} aria-pressed={kind===value} onClick={()=>pick(value)}><ShapeIcon kind={value}/></IconButton>)}
      {!commonShapes.includes(kind)&&<IconButton type="button" aria-label={'Draw '+shapeNames[kind].toLowerCase()} title={shapeNames[kind]} aria-pressed="true" onClick={()=>pick(kind)}><ShapeIcon kind={kind}/></IconButton>}
      <Button variant="quiet" ref={more} type="button" className="wboard-more-shapes" aria-expanded={popup==='more'} aria-controls="wboard-more-shapes" onClick={()=>setPopup(v=>v==='more'?null:'more')}>More shapes</Button>
    </div>
    {popup==='more'&&<div id="wboard-more-shapes" className="wboard-shape-popover wboard-shape-grid wboard-float" role="group" aria-label="More shapes">{extraShapes.map(value=><Button variant="quiet" type="button" key={value} aria-pressed={kind===value} onClick={()=>pick(value)}><ShapeIcon kind={value}/><span>{shapeNames[value]}</span></Button>)}</div>}
    {popup==='style'&&<div id="wboard-shape-style" className="wboard-shape-popover wboard-float"><PenOptions color={color} width={width} setColor={setColor} setWidth={setWidth}/></div>}
  </div>;
}

export function ShapeLayer({kind,enabled,color,thickness,save,notify,exit}:{kind:ShapeKind;enabled:boolean;color:WhiteboardStroke['color'];thickness:number;save(stroke:Omit<WhiteboardStroke,'revision'>):void;notify(message:string):void;exit():void}) {
  const flow=useReactFlow(),viewport=useViewport();const active=useRef<{pointer:number;start:ShapePoint;client:ShapePoint}|null>(null);
  const [preview,setPreview]=useState<ShapePoint[]>([]);
  const position=(event:{clientX:number;clientY:number}):ShapePoint=>{const p=flow.screenToFlowPosition({x:event.clientX,y:event.clientY});return [p.x,p.y];};
  const cancel=()=>{active.current=null;setPreview([]);};
  useEffect(()=>{cancel();},[kind,enabled]);
  return <div className="wboard-drawing-layer wboard-shape-layer nodrag nopan nowheel" role="region" aria-label="Shape drawing surface" tabIndex={0}
    onKeyDown={event=>{if(event.key==='Escape'){event.stopPropagation();cancel();exit();}}}
    onPointerDown={event=>{if(!enabled||event.button!==0||active.current)return;event.preventDefault();event.stopPropagation();event.currentTarget.focus();event.currentTarget.setPointerCapture(event.pointerId);active.current={pointer:event.pointerId,start:position(event),client:[event.clientX,event.clientY]};}}
    onPointerMove={event=>{if(active.current?.pointer===event.pointerId)setPreview(shapePoints(kind,active.current.start,position(event),event.shiftKey));}}
    onPointerCancel={cancel} onLostPointerCapture={cancel}
    onPointerUp={event=>{
      const gesture=active.current;if(gesture?.pointer!==event.pointerId)return;
      cancel();event.currentTarget.releasePointerCapture(event.pointerId);if(!enabled)return;
      try {const click=Math.hypot(event.clientX-gesture.client[0],event.clientY-gesture.client[1])<4;
        save(click?defaultShape(kind,gesture.start,color,thickness,crypto.randomUUID()):shapeStroke(kind,gesture.start,position(event),event.shiftKey,color,thickness,crypto.randomUUID()));
      }catch(error){notify(error instanceof Error?error.message:'That shape could not be placed.');}
    }}>
    <svg aria-hidden="true"><g transform={`translate(${viewport.x},${viewport.y}) scale(${viewport.zoom})`}><polyline points={preview.map(p=>p.join(',')).join(' ')} fill="none" stroke={strokeColors[color]} strokeWidth={thickness} strokeLinecap="round" strokeLinejoin="round"/></g></svg>
  </div>;
}
