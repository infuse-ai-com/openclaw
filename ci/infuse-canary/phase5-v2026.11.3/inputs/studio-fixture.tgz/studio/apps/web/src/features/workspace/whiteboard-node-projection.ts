import { whiteboardNavigation } from '@studio/contracts';
import type { BoardPanel, BoardTool } from './whiteboard-types.js';

import { useEffect, useRef } from 'react';
import { type CommentSelection } from './whiteboard-comments.js';
import { geometryUpdate } from './whiteboard-geometry.js';
import { intersects, type useSpatialBoard } from './whiteboard-spatial.js';
import { type SharedBodyOptions } from './whiteboard-text.js';
import type { BlockNode, CanvasItem } from './whiteboard-types.js';

import type * as React from 'react';
import type { Draft } from './whiteboard-editing.js';
import type { BoardCamera } from './whiteboard-section-zoom.js';
import type { Commit } from './whiteboard-types.js';

type Props = {
  dropTarget: string | null;
  dropReady: string | null;
  selectedIds: string[];
  selectionLocks: string[];
  commit: Commit;
  interacting: React.RefObject<boolean>;
  focused: CanvasItem | null;
  panel: BoardPanel;
  tool: BoardTool;
  commentsOpen: boolean;
  busy: boolean;
  setNodes: React.Dispatch<React.SetStateAction<BlockNode[]>>;
  canvasSize: { width: number; height: number };
  viewport: BoardCamera;
  current: boolean;
  visible: boolean;
  blocks: CanvasItem[];
  engagedHtml: string[];
  selectNext: React.RefObject<string[]>;
  board: Pick<ReturnType<typeof useSpatialBoard>, 'data' | 'loadingIds'>;
  navigation: { data?: ReturnType<typeof whiteboardNavigation.parse> };
  setCommentsOpen: (open: boolean) => void;
  setCommentSelection: React.Dispatch<React.SetStateAction<CommentSelection | null>>;
  commentFrame: React.RefObject<(id: string) => void>;
  autoFocusId: string | null;
  enabled: boolean;
  activeHtml: string[];
  setActiveHtml: React.Dispatch<React.SetStateAction<string[]>>;
  enterSection: (next: string, block?: string) => void;
  drafts: Map<string, Draft>;
  syncDraftStatus: () => void;
  setFocused: React.Dispatch<React.SetStateAction<CanvasItem | null>>;
  openPanel: (next: BoardPanel) => void;
  editable: boolean;
  draftVersion: number;
  resetGeometry: number;
  shared: SharedBodyOptions | undefined;
  engageHtml: (id: string, engaged: boolean) => void;
  sectionId: string;
  path: string;
};
export function useWhiteboardNodeProjection({
  dropTarget,
  dropReady,
  selectedIds,
  selectionLocks,
  commit,
  interacting,
  focused,
  panel,
  tool,
  commentsOpen,
  busy,
  setNodes,
  canvasSize,
  viewport,
  current,
  visible,
  blocks,
  engagedHtml,
  selectNext,
  board,
  navigation,
  setCommentsOpen,
  setCommentSelection,
  commentFrame,
  autoFocusId,
  enabled,
  activeHtml,
  setActiveHtml,
  enterSection,
  drafts,
  syncDraftStatus,
  setFocused,
  openPanel,
  editable,
  draftVersion,
  resetGeometry,
  shared,
  engageHtml,
  sectionId,
  path,
}: Props) {
  const commitRef = useRef(commit);
  commitRef.current = commit;
  useEffect(() => {
    if (interacting.current) {
      setNodes((previous) =>
        previous.map((node) => ({
          ...node,
          className: [
            node.data.block.locked ? 'wboard-node-locked' : '',
            dropTarget === node.id ? 'wboard-section-drop' : '',
            dropReady === node.id ? 'is-drop-ready' : '',
          ]
            .filter(Boolean)
            .join(' '),
        })),
      );
      return;
    }
    const inlineEditing = (block: CanvasItem) =>
      autoFocusId === block.id &&
      focused?.id === block.id &&
      panel !== 'editor' &&
      (block.kind === 'note' ||
        block.kind === 'document' ||
        (block.kind === 'stroke' && !!block.shape)) &&
      (tool === 'select' || tool === 'hand');
    if (busy) {
      setNodes((previous) =>
        previous.map((node) => ({
          ...node,
          data: {
            ...node.data,
            enabled: false,
            canSave: false,
            editing: inlineEditing(node.data.block),
          },
        })),
      );
      return;
    }
    const center = {
      x: (canvasSize.width / 2 - viewport.x) / viewport.zoom,
      y: (canvasSize.height / 2 - viewport.y) / viewport.zoom,
    };
    const previews = new Set(
      current && visible && viewport.zoom >= 0.45
        ? blocks
            .filter(
              (block) =>
                block.kind === 'section' &&
                intersects({ ...block, sectionId }, viewport, canvasSize),
            )
            .sort(
              (a, b) =>
                Math.hypot(a.x + a.width / 2 - center.x, a.y + a.height / 2 - center.y) -
                Math.hypot(b.x + b.width / 2 - center.x, b.y + b.height / 2 - center.y),
            )
            .slice(0, 4)
            .map((block) => block.id)
        : [],
    );
    setNodes((previous) =>
      blocks
        .filter(
          (block) =>
            engagedHtml.includes(block.id) ||
            block.id === focused?.id ||
            previous.some((n) => n.id === block.id && n.selected) ||
            intersects({ ...block, sectionId }, viewport, canvasSize),
        )
        .map((block) => ({
          // Retain React Flow measurements so a refresh cannot start a resize from zero.
          ...previous.find((node) => node.id === block.id),
          id: block.id,
          type: block.kind === 'stroke' ? 'stroke' : 'block',
          draggable:
            enabled &&
            tool === 'select' &&
            !block.locked &&
            !(
              selectionLocks.length &&
              previous.some((node) => node.id === block.id && node.selected)
            ),
          className: [
            block.locked ? 'wboard-node-locked' : '',
            dropTarget === block.id ? 'wboard-section-drop' : '',
            dropReady === block.id ? 'is-drop-ready' : '',
          ]
            .filter(Boolean)
            .join(' '),
          ariaLabel: block.locked
            ? ('title' in block ? block.title : 'Drawing') + '. Locked in place.'
            : undefined,
          position: { x: block.x, y: block.y },
          width: block.width,
          height: block.height,
          zIndex:
            block.id === focused?.id
              ? 100
              : previous.some((n) => n.id === block.id && n.selected)
                ? 50
                : block.kind === 'stroke'
                  ? 1
                  : 0,
          selected: selectNext.current.length
            ? selectNext.current.includes(block.id)
            : (previous.find((node) => node.id === block.id)?.selected ?? false),
          data: {
            block,
            editable,
            sectionId,
            previewSection: previews.has(block.id),
            boardRevision: board.data?.revision ?? 0,
            sectionCount: navigation.data?.sections.find((s) => s.id === block.id)?.count,
            commentCount: navigation.data?.comments.find((c) => c.blockId === block.id)?.open ?? 0,
            comments: () => {
              setCommentsOpen(true);
              setCommentSelection(null);
              commentFrame.current(block.id);
            },
            autoFocus: autoFocusId === block.id,
            canSave: enabled,
            enabled: enabled && tool === 'select' && !block.locked,
            loaded:
              (board.data?.loadedIds.has(block.id) ?? false) ||
              (block.kind === 'html' && activeHtml.includes(block.id)),
            loading: board.loadingIds.includes(block.id),
            path,
            activeHtml: panel !== 'html' && activeHtml.includes(block.id),
            canActivateHtml: engagedHtml.length < 2,
            engageHtml,
            activateHtml: () =>
              setActiveHtml((values) =>
                [...new Set([...engagedHtml, block.id, ...values])].slice(0, 2),
              ),
            enter: () => enterSection(block.id),
            editing: inlineEditing(block),
            shared,
            drafts: drafts,
            commit: (operations) => commitRef.current(operations),
            onDraftChange: syncDraftStatus,
            options: () => {
              setFocused(block);
              setNodes((previous) =>
                previous.map((node) => ({ ...node, selected: node.id === block.id })),
              );
              openPanel('editor');
            },
            resizeStart: () => {
              interacting.current = true;
            },
            resize: (source, bounds) => {
              interacting.current = false;
              void commitRef.current([geometryUpdate(source, bounds)]);
            },
          },
        })),
    );
  }, [
    blocks,
    current,
    visible,
    board.data?.revision,
    enabled,
    editable,
    autoFocusId,
    draftVersion,
    busy,
    resetGeometry,
    tool,
    focused?.id,
    panel,
    syncDraftStatus,
    shared,
    viewport,
    canvasSize,
    activeHtml,
    engagedHtml,
    engageHtml,
    sectionId,
    path,
    board.loadingIds.join(','),
    navigation.data,
    commentsOpen,
    dropTarget,
    dropReady,
    selectedIds.join(','),
    selectionLocks.length,
  ]);
}
