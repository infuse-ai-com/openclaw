import type { StudioActivationHost } from './features/studio/host.js';
import { mountStudio } from './features/studio/app.js';
import { mountStudioFonts } from './features/studio/fonts.js';
import './features/studio/styles.css';

/** Structural public SDK contract; the SDK's defineControlUiPlugin helper is an identity. */
export default {
  id: 'infuse-studio',
  async activate(host: StudioActivationHost) {
    const removeFonts = await mountStudioFonts();
    let removePage: (() => void) | undefined;
    try {
      removePage = host.ui.registerPage({
      id: 'missions', label: 'Studio',
      mount(container, context) {
        const root = document.createElement('div');
        root.className = 'infuse-studio-root';
        root.lang = 'en';
        container.append(root);
        const app = mountStudio(root, context);
        return { ...app, dispose() { app.dispose(); root.remove(); } };
      },
      });
      const removeNavigation = host.ui.registerNavigation({ id: 'studio', label: 'Studio', page: { id: 'missions' }, order: 40 });
      return () => { removeNavigation(); removePage?.(); removeFonts(); };
    } catch (error) { removePage?.(); removeFonts(); throw error; }
  },
};
