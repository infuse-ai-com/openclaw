import type { Node } from '@xyflow/react';
import type {
  WhiteboardBlock,
  WhiteboardStroke,
  WhiteboardSection,
  WhiteboardHtml,
  WhiteboardImage,
  WhiteboardSpatialOperation,
  WhiteboardReceipt,
} from '@studio/contracts';
import type { Draft } from './whiteboard-editing.js';
import type { SharedBodyOptions } from './whiteboard-text.js';

export type CanvasItem =
  WhiteboardBlock | WhiteboardStroke | WhiteboardSection | WhiteboardHtml | WhiteboardImage;
export type Bounds = { x: number; y: number; width: number; height: number };
export type Commit = (
  operations: WhiteboardSpatialOperation[],
) => Promise<WhiteboardReceipt | undefined>;
export type BlockNode = Node<
  {
    block: CanvasItem;
    enabled: boolean;
    canSave: boolean;
    editable: boolean;
    sectionId: string;
    autoFocus: boolean;
    editing: boolean;
    drafts: Map<string, Draft>;
    loaded: boolean;
    loading: boolean;
    path: string;
    previewSection: boolean;
    boardRevision: number;
    sectionCount?: number;
    commentCount: number;
    comments(): void;
    activeHtml: boolean;
    canActivateHtml: boolean;
    activateHtml(): void;
    engageHtml(id: string, engaged: boolean): void;
    enter(): void;
    shared?: SharedBodyOptions;
    commit: Commit;
    onDraftChange(): void;
    options(): void;
    resizeStart(): void;
    resize(block: CanvasItem, bounds: Bounds): void;
  },
  'block' | 'stroke'
>;

export type BoardTool = 'select' | 'hand' | 'draw' | 'erase' | 'note' | 'shape';
export type BoardPanel =
  | 'outline'
  | 'activity'
  | 'help'
  | 'editor'
  | 'html'
  | 'search'
  | 'comments'
  | 'arrange'
  | null;
