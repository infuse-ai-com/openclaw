declare module '@studio/spatial/office' {
  import type { Color, Group, Material, Mesh, Object3D } from 'three';
  export interface OfficeLayout {
    width: number; depth: number; board: [number, number]; shelf: [number, number];
    founder: [number, number]; operations: [number, number]; lounge: [number, number]; entrance: [number, number];
    workstations: { x: number; z: number; facing: number; guest?: boolean }[];
  }
  export interface BoardPaper { mesh: Mesh; marks: Mesh[]; index: number; floor: string }
  export interface ReviewPaper { mesh: Mesh; pin: Mesh; floor: string }
  export type Finish = number | string | Color | Material;
  export type OfficeBox = (parent: Object3D, w: number, h: number, d: number, x: number, y: number, z: number, finish: Finish, cast?: boolean) => Mesh;
  export function furnishOffice(parent: Group, layout: OfficeLayout, floorInfo: { title: string }, kit: {
    living?: boolean;
    box: OfficeBox;
    softBox: (parent: Object3D, w: number, h: number, d: number, x: number, y: number, z: number, finish: Finish, radius?: number) => Mesh;
    part: (parent: Object3D, id: string, x: number, z: number) => Group;
    material: (finish: Finish) => Material;
    surface: (type: string, color: number | Color) => Material;
    printMaterial: (index: number) => Material;
    signMaterial: (title: string) => Material;
    boardPapers: BoardPaper[];
    reviewPapers: ReviewPaper[];
  }): { founderSeat: [number, number]; doors: Group[] };
}
declare module '@studio/spatial/office-materials' {
  import type { BufferGeometry, Color, LoadingManager, Material, WebGLRenderer } from 'three';
  export function createOfficeMaterials(renderer: WebGLRenderer, manager?: LoadingManager): { surface(type: string, color: number | Color): Material; dispose(): void };
  export function surfaceUVs<T extends BufferGeometry>(geometry: T, scale: number): T;
}

declare module '@studio/spatial/building' {
  import type { Group, Material, Texture, Vector3 } from 'three';
  import type { OfficeBox } from '@studio/spatial/office';
  export const STOREY_HEIGHT: number;
  export function createDirectoryKiosk(kit: { root: Group; box: OfficeBox; ownedMaterials: Material[]; brandMap: Texture }): { position: Vector3; highlight(value: boolean): void };
  export function createBuildingExterior(kit: { box: OfficeBox; ownedMaterials: Material[]; textures: Texture[]; fontFamily?: string }): {
    build(root: Group, floors: { id: string; title: string; number: string; accent?: string }[], addLabel: (text: string, position: Vector3, click: () => void, className: string) => HTMLElement, onSelect: (destination: { floor: string }) => void): void;
    setNight(night: number): void; highlight(id: string | null): void; clear(): void; dispose(): void;
  };
}

declare module '@studio/spatial/neighborhood' {
  import type { Group, Material, Texture, Color } from 'three';
  import type { OfficeBox } from '@studio/spatial/office';
  export function officeDaylight(hours: number): { sunVisibility: number; elevation: number; sky: Color; horizon: Color; sun: Color; sunlight: number; ambient: number; night: number; hour: number };
  export function createNeighborhood(kit: { root: Group; box: OfficeBox; ownedMaterials: Material[]; textures: Texture[] }): {
    animate(seconds: number): void; setNight(night: number): void;
  };
}

declare module '@studio/spatial/weather' {
  export function officeThunderstorm(timestamp: number): boolean;
}
