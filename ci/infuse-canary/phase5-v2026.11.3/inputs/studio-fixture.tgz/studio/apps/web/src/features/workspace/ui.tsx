import type { ComponentPropsWithRef, HTMLAttributes, ReactNode } from 'react';

// React adapters for @studio/ui presentation. Routes retain state, permissions
// and navigation; native links stay links and genuine tablists keep their keys.
export function PageHeader({ title, eyebrow, description, actions, leading, metadata, level = 1, compact = false, headingProps, descriptionProps, className = '' }: {
  title: ReactNode; eyebrow?: ReactNode; description?: ReactNode; actions?: ReactNode; leading?: ReactNode; metadata?: ReactNode; className?: string;
  level?: 1 | 2 | 3; compact?: boolean; headingProps?: ComponentPropsWithRef<'h1'>; descriptionProps?: HTMLAttributes<HTMLParagraphElement>;
}) {
  const Heading = `h${level}` as 'h1' | 'h2' | 'h3';
  return <header className={`ws-surface-header ui-page-header${compact ? ' ui-page-header--compact' : ''} ${className}`}>
    {leading && <div className="ui-page-leading">{leading}</div>}
    <div className="ui-page-heading">{eyebrow && <span className="ws-eyebrow">{eyebrow}</span>}{metadata ? <div className="ui-page-title"><Heading {...headingProps}>{title}</Heading>{metadata}</div> : <Heading {...headingProps}>{title}</Heading>}{description && <p {...descriptionProps}>{description}</p>}</div>
    {actions && <div className="ws-actions ui-page-actions">{actions}</div>}
  </header>;
}

export function Button({ variant = 'primary', className = '', type = 'button', ...props }: ComponentPropsWithRef<'button'> & {
  variant?: 'primary' | 'quiet' | 'danger';
}) {
  return <button {...props} type={type} className={`ws-button${variant === 'primary' ? '' : ` ws-button--${variant}`} ${className}`} />;
}

export function EmptyState({ title, children, actions, icon, eyebrow, level = 2, className = '', descriptionRole, ...props }: Omit<HTMLAttributes<HTMLDivElement>, 'title'> & {
  title: ReactNode; children?: ReactNode; actions?: ReactNode; icon?: ReactNode; eyebrow?: ReactNode; level?: 1 | 2 | 3; descriptionRole?: 'alert' | 'status';
}) {
  const Heading = `h${level}` as 'h1' | 'h2' | 'h3';
  return <div {...props} className={`ui-empty ${className}`}>{icon}{eyebrow && <span className="ws-eyebrow">{eyebrow}</span>}<Heading>{title}</Heading>{children && <p role={descriptionRole}>{children}</p>}{actions && <div className="ui-actions">{actions}</div>}</div>;
}

export function IconButton({ className = '', ...props }: ComponentPropsWithRef<'button'> & { 'aria-label': string }) {
  return <Button {...props} variant="quiet" className={`ui-icon-button ${className}`} />;
}

// A labelled native-button group. Does not promise ARIA toolbar arrow-key behavior.
export function Toolbar({ className = '', ...props }: ComponentPropsWithRef<'div'> & { 'aria-label': string }) {
  return <div {...props} role="group" className={`ui-toolbar ${className}`} />;
}

// A group of pressed buttons, not an ARIA tablist. Native Tab/Enter/Space
// behavior is deliberate; consumers with tabpanels retain their roving focus.
export function ViewSwitch<T extends string>({ label, value, options, onChange, segmented = false, className = '' }: {
  label: string; value: T; options: ReadonlyArray<readonly [T, ReactNode]>; onChange(value: T): void; segmented?: boolean; className?: string;
}) {
  return <div className={`${segmented ? 'ui-segmented' : 'ui-tabs'} ${className}`} role="group" aria-label={label}>
    {options.map(([id, name]) => <button type="button" key={id} aria-pressed={value === id} onClick={() => onChange(id)}>{name}</button>)}
  </div>;
}
