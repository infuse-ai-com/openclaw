import type { CompanionTurn } from '@studio/contracts';
type Agent = { gatewayId: string; agentId: string; availability: 'available' | 'occupied' | 'offline' };
export const companionKey = (target: { gatewayId: string; agentId: string }) => JSON.stringify([target.gatewayId, target.agentId]);
/** Explicit/pending choices never fall back to another identity. */
export function chooseCompanion<T extends Agent>(agents: T[], target: string, turns: CompanionTurn[]): T | undefined {
  if (target) return agents.find(agent => companionKey(agent) === target);
  const running = turns.find(turn => !['completed', 'failed', 'stopped'].includes(turn.state));
  return (running && agents.find(agent => companionKey(agent) === companionKey(running)))
    || agents.find(agent => agent.availability === 'available');
}
