import { useCallback, useMemo, useState } from 'react';
import { CommentDrafts } from './whiteboard-comments.js';
import type { Draft } from './whiteboard-editing.js';
import { clearWhiteboardTextRecovery, hasPendingWhiteboardText } from './whiteboard-recovery.js';

/** Owns the editor's local drafts, distinct from structural command recovery. */
export function useWhiteboardDrafts(owner: string) {
  const drafts = useMemo(
    () => ({
      blocks: new Map<string, Draft>(),
      bodies: new Map<string, string>(),
      bodyDirty: new Map<string, boolean>(),
      comments: new CommentDrafts(),
    }),
    [owner],
  );
  const [version, setVersion] = useState(0);
  const changed = useCallback(() => {
    // Retain dirty work, but never accumulate saved copies while browsing blocks.
    for (const cache of [drafts.blocks]) {
      for (const [id, draft] of cache) {
        if (cache.size <= 30) break;
        if (!draft.dirty) cache.delete(id);
      }
    }
    for (const [id, dirty] of drafts.bodyDirty) if (!dirty) drafts.bodyDirty.delete(id);
    setVersion((value) => value + 1);
  }, [drafts]);
  const clear = useCallback(() => {
    clearWhiteboardTextRecovery(owner);
    for (const cache of Object.values(drafts)) cache.clear();
    setVersion((value) => value + 1);
  }, [owner, drafts]);
  const hasDraft =
    [...drafts.blocks.values()].some((draft) => draft.dirty) ||
    [...drafts.bodyDirty.values()].some(Boolean) ||
    hasPendingWhiteboardText(owner) ||
    drafts.comments.dirty();
  return { drafts, version, changed, clear, hasDraft };
}
