import { Button, EmptyState } from './ui.js';
import { useEffect, useState, type ReactNode } from 'react';
import { artifactViewerPath, artifactPreviewKind, type ArtifactManifest } from '@studio/contracts';
import { useLocation, useSearchParams } from 'react-router';
import { ControlHint } from './control-hint.js';
import { projectPath } from './api.js';
import { LoadingState } from './loading.js';
import { ArtifactIcon } from './artifact-ui.js';

export type ReaderControls = { filePicker?: ReactNode; fileName: string; download: ReactNode; fileDetails: ReactNode; link: string };

/** One exact manifest owns selection, preview and download; never borrow a file from another revision. */
export function ArtifactFiles({ manifest, projectId, revisionControl, readerChrome }: {
  manifest: ArtifactManifest; projectId: string; revisionControl?: ReactNode;
  readerChrome?: (controls: ReaderControls) => ReactNode;
}) {
  const [inlineFile, setInlineFile] = useState(''), [params, setParams] = useSearchParams(), location = useLocation();
  const selected = readerChrome ? params.get('file') : inlineFile;
  function selectFile(path: string) {
    if (!readerChrome) { setInlineFile(path); return; }
    setParams(previous => { const next = new URLSearchParams(previous); next.set('file', path); return next; }, { replace:true, state:location.state });
  }
  const files = manifest.files;
  const file = files.find(f => f.path === selected)
    ?? files.find(f => f.path === 'index.html' && f.mediaType === 'text/html')
    ?? files.find(f => artifactPreviewKind(f.mediaType) !== 'download') ?? files[0];
  if (!file) return <EmptyState title="No files in this revision." />;
  const kind = artifactPreviewKind(file.mediaType);
  const base = projectPath(`/api/studio/artifacts/${[manifest.producer, manifest.artifactId, manifest.revision].map(encodeURIComponent).join('/')}`, projectId);
  const query = new URLSearchParams({ path: file.path });
  const bytes = file.bytes < 1024 ? `${file.bytes} bytes` : file.bytes < 1048576 ? `${(file.bytes / 1024).toFixed(1)} KB` : `${(file.bytes / 1048576).toFixed(1)} MB`;
  const fileSelect = <label className="ws-artifact-file-select"><span>File <small>({files.length})</small></span><select className="ui-control" aria-label="File" value={file.path} onChange={event => selectFile(event.target.value)}>{files.map(f => <option key={f.path} value={f.path}>{f.path}</option>)}</select></label>;
  const shareLink = new URL(artifactViewerPath(manifest.producer, manifest.artifactId, manifest.revision), window.location.origin);
  shareLink.searchParams.set('project', projectId);
  if (files.length > 1) shareLink.searchParams.set('file', file.path);
  const filePicker = files.length > 1 ? <label className="ws-artifact-header-files"><ArtifactIcon name="files"/><span aria-hidden="true">Files · {files.length}</span>
    <select aria-label="File" value={file.path} onChange={event => selectFile(event.target.value)}>{files.map(f=><option key={f.path} value={f.path}>{f.path}</option>)}</select>
  </label> : undefined;
  const downloadLabel = `Download ${kind === 'html' ? 'HTML' : kind === 'image' ? 'image' : 'file'} ↓`;
  const download = <a className="ws-button ws-button--quiet ws-artifact-download" aria-label={downloadLabel} title={readerChrome ? undefined : downloadLabel} href={`${base}/download?${query}`}>{readerChrome ? <ArtifactIcon name="download" /> : downloadLabel}</a>;
  const fileDetails = <div className="ws-artifact-details"><details className="ws-record"><summary>File details <span>{bytes}</span></summary><p>{file.path} · {file.mediaType} · {file.bytes} bytes</p><p>SHA-256 <code>{file.sha256}</code></p></details></div>;
  return <div className="ws-artifact-files">
    {readerChrome ? readerChrome({ filePicker, fileName:file.path, download:<ControlHint label={downloadLabel.replace(' ↓','')}>{download}</ControlHint>, fileDetails, link:shareLink.href }) : <div className="ws-artifact-file-toolbar">
      {files.length > 1 ? fileSelect : <div className="ws-artifact-single-value"><span>File</span><strong>{file.path}</strong></div>}
      {revisionControl}
      {download}
    </div>}
    {kind === 'download' ? <EmptyState className="ws-artifact-file-fallback" level={2} icon={<ArtifactIcon name="document" />} title="This file is available to download."
      actions={readerChrome && <a className="ws-button ws-button--quiet" href={`${base}/download?${query}`} aria-label={`Download ${file.path}`}><ArtifactIcon name="download" />Download file</a>}>Preview is not available for <strong>{file.path}</strong>.</EmptyState>
      : <ArtifactFilePreview key={`${manifest.revision}/${file.path}`} kind={kind} title={`${manifest.title} preview`} src={`${base}/${kind === 'html' ? 'preview' : 'image'}?${query}`} />}
    {!readerChrome && fileDetails}
  </div>;
}

function ArtifactFilePreview({ src, title, kind }: { src: string; title: string; kind: 'html' | 'image' }) {
  const [state, setState] = useState<'loading' | 'loaded' | 'slow' | 'error'>('loading');
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    const timer = window.setTimeout(() => setState(previous => previous === 'loading' ? 'slow' : previous), 15000);
    return () => window.clearTimeout(timer);
  }, [src, attempt]);
  return <div className="ws-preview-wrap">
    {state === 'loading' && <LoadingState label="Loading preview…" size="page" />}
    {(state === 'slow' || state === 'error') && <div className="ws-preview-retry" role="status"><p>{state === 'error' ? 'This preview could not be displayed.' : 'The preview has not finished loading.'} Retry, download the file, or choose another revision.</p><Button variant="quiet" onClick={() => { setState('loading'); setAttempt(value => value + 1); }}>Retry preview</Button></div>}
    {kind === 'image'
      ? <img key={`${src}:${attempt}`} className="ws-artifact-image" src={src} alt={title} onLoad={() => setState('loaded')} onError={() => setState('error')} referrerPolicy="no-referrer" />
      : <iframe key={`${src}:${attempt}`} className="ws-artifact-frame" title={title} src={src} onLoad={() => setState('loaded')} onError={() => setState('error')} sandbox="allow-scripts" referrerPolicy="no-referrer" />}
  </div>;
}
