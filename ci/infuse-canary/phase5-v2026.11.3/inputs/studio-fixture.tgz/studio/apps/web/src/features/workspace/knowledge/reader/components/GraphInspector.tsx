import type {FilterKind,FilterPreview,HiddenFilters} from '../graphFilters';
import { LoadingState } from '../../../loading.js';
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type ReactNode,
} from 'react';
import type {
  GraphNode,
  KnowledgeGraph,
  SemanticNeighborhoodResponse,
} from '@studio/contracts/knowledge';
import { matchesGraphDocumentQuery } from '../graphSearch';
import { HeaderIcon } from './TopBar';

type FilterGroup =
  'repositories' | 'types' | 'owners' | 'tags' | 'statuses' | 'clusters';
export type InspectorMode = 'filters' | 'documents' | 'preview';

interface GraphInspectorProps {
  mode?: InspectorMode;
  onModeChange?: (mode: InspectorMode) => void;
  clusterColors: ReadonlyMap<string, string>;
  degree: ReadonlyMap<string, number>;
  graph: KnowledgeGraph;
  hiddenFilters: HiddenFilters;
  hoveredNode?: GraphNode;
  neighborhood?: SemanticNeighborhoodResponse;
  neighborhoodActive: boolean;
  neighborhoodLoading: boolean;
  onClearNeighborhood: () => void;
  onClose: () => void;
  onHoverNode: (nodeId: string | undefined) => void;
  onOpen: (node: GraphNode) => void;
  onViewNeighborhood: () => void;
  onPreview: (preview: FilterPreview | undefined) => void;
  onResetFilters: () => void;
  onShowFilter: (kind: FilterKind, value: string) => void;
  onToggleFilter: (kind: FilterKind, value: string) => void;
  ownerCounts: ReadonlyMap<string, number>;
  repositories: readonly string[];
  repositoryCounts: ReadonlyMap<string, number>;
  repositoryInsights: ReadonlyMap<
    string,
    { exceptions: number; owners: number; topTags: string[] }
  >;
  statusCounts: ReadonlyMap<string, number>;
  tagCounts: ReadonlyMap<string, number>;
  typeCounts: ReadonlyMap<string, number>;
  visibleEdgeCount: number;
  visibleNodes: readonly GraphNode[];
}

interface ActiveFilter {
  kind: FilterKind;
  value: string;
}

interface FilterSectionProps {
  children: ReactNode;
  count: number;
  hiddenCount: number;
  id: FilterGroup;
  label: string;
  onToggle: (id: FilterGroup) => void;
  open: boolean;
}

function FilterSection({
  children,
  count,
  hiddenCount,
  id,
  label,
  onToggle,
  open,
}: FilterSectionProps) {
  const contentId = `graph-filter-${id}`;
  return (
    <section className="graph-filter-section">
      <button
        aria-controls={contentId}
        aria-expanded={open}
        className="graph-filter-section-trigger"
        onClick={() => onToggle(id)}
        type="button"
      >
        <span>
          <strong>{label}</strong>
          <small>{count}</small>
        </span>
        <span>
          {hiddenCount > 0 && <small>{hiddenCount} hidden</small>}
          <span aria-hidden="true" className="graph-filter-chevron" />
        </span>
      </button>
      {open && (
        <div className="graph-filter-section-content" id={contentId}>
          {children}
        </div>
      )}
    </section>
  );
}

function filterDetail(
  repository: string,
  insight:
    { exceptions: number; owners: number; topTags: string[] } | undefined,
): string {
  const owners = insight?.owners ?? 0;
  const exceptions = insight?.exceptions ?? 0;
  const tags = insight?.topTags ?? [];
  return `${repository}: ${String(owners)} owner${owners === 1 ? '' : 's'}, ${String(exceptions)} lifecycle flag${exceptions === 1 ? '' : 's'}${tags.length > 0 ? `, leading tags ${tags.join(', ')}` : ''}`;
}

export function SemanticNeighborhood({
  graph,
  neighborhood,
  neighborhoodActive,
  neighborhoodLoading,
  onClearNeighborhood,
  onOpen,
  onViewNeighborhood,
}: Readonly<
  Pick<
    GraphInspectorProps,
    | 'graph'
    | 'neighborhood'
    | 'neighborhoodActive'
    | 'neighborhoodLoading'
    | 'onClearNeighborhood'
    | 'onOpen'
    | 'onViewNeighborhood'
  >
>) {
  let content: ReactNode;
  if (neighborhoodLoading) {
    content = <LoadingState label="Finding related documents…" size="panel" />;
  } else if (neighborhood?.mode === 'semantic') {
    if (neighborhood.results.length === 0) {
      content = <small>No related documents in this graph scope.</small>;
    } else {
      content = (
        <div className="graph-semantic-neighborhood-list">
          {neighborhood.results.map((result) => {
            const node = graph.nodes.find(
              (candidate) =>
                candidate.repository === result.repository &&
                candidate.path === result.path,
            );
            if (!node) return null;
            const section = result.sections[0];
            return (
              <button
                key={`${result.repository}:${result.path}`}
                onClick={() => onOpen(node)}
                type="button"
              >
                <strong>{result.title}</strong>
                <span>
                  {result.repository}
                  {section ? ` · ${section.headingPath}` : ''}
                </span>
                {section && <small>{section.excerpt}</small>}
              </button>
            );
          })}
        </div>
      );
    }
  } else if (neighborhood?.mode === 'unavailable') {
    const updating =
      neighborhood.unavailableReason === 'generation_pending' ||
      neighborhood.unavailableReason === 'generation_stale';
    content = (
      <small>
        {updating
          ? 'Semantic neighborhood is updating.'
          : 'Related documents are temporarily unavailable.'}
      </small>
    );
  } else {
    content = <small>Focus a document to find related knowledge.</small>;
  }
  let action: ReactNode = null;
  if (neighborhoodActive) {
    action = (
      <button onClick={onClearNeighborhood} type="button">
        Clear
      </button>
    );
  } else if (
    neighborhood?.mode === 'semantic' &&
    neighborhood.results.length > 0
  ) {
    action = (
      <button onClick={onViewNeighborhood} type="button">
        View neighborhood
      </button>
    );
  }
  return (
    <section
      aria-label="Related by meaning"
      className="graph-semantic-neighborhood"
    >
      <div className="graph-semantic-neighborhood-heading">
        <strong>Related by meaning</strong>
        {action}
      </div>
      {content}
    </section>
  );
}

function NodePreview({
  graph,
  hoveredNode,
  neighborhood,
  neighborhoodActive,
  neighborhoodLoading,
  onClearNeighborhood,
  onOpen,
  onViewNeighborhood,
}: Readonly<
  Pick<
    GraphInspectorProps,
    | 'graph'
    | 'hoveredNode'
    | 'neighborhood'
    | 'neighborhoodActive'
    | 'neighborhoodLoading'
    | 'onClearNeighborhood'
    | 'onOpen'
    | 'onViewNeighborhood'
  >
>) {
  return (
    <div
      aria-label="Node preview"
      className={`graph-node-preview${hoveredNode ? ' is-focused' : ' is-idle'}`}
    >
      <p className="eyebrow">Node preview</p>
      {hoveredNode ? (
        <>
          <strong className="graph-node-preview-title">
            {hoveredNode.title}
          </strong>
          <span className="graph-node-preview-meta">
            {hoveredNode.repository} · {hoveredNode.type} · {hoveredNode.status}
          </span>
          <small className="graph-node-preview-description">
            {hoveredNode.description}
          </small>
          <span className="sr-only">
            {hoveredNode.owner}; tags {hoveredNode.tags.join(', ')}; path{' '}
            {hoveredNode.path}
          </span>
          <button onClick={() => onOpen(hoveredNode)} type="button">
            Open document
          </button>
          <SemanticNeighborhood
            graph={graph}
            neighborhood={neighborhood}
            neighborhoodActive={neighborhoodActive}
            neighborhoodLoading={neighborhoodLoading}
            onClearNeighborhood={onClearNeighborhood}
            onOpen={onOpen}
            onViewNeighborhood={onViewNeighborhood}
          />
        </>
      ) : (
        <>
          <strong>Ready to explore</strong>
          <small>Focus a node or document result to inspect it here.</small>
        </>
      )}
    </div>
  );
}

export function GraphInspector({
  mode: controlledMode,
  onModeChange,
  clusterColors,
  degree,
  graph,
  hiddenFilters,
  hoveredNode,
  neighborhood,
  neighborhoodActive,
  neighborhoodLoading,
  onClearNeighborhood,
  onClose,
  onHoverNode,
  onOpen,
  onViewNeighborhood,
  onPreview,
  onResetFilters,
  onShowFilter,
  onToggleFilter,
  ownerCounts,
  repositories,
  repositoryCounts,
  repositoryInsights,
  statusCounts,
  tagCounts,
  typeCounts,
  visibleEdgeCount,
  visibleNodes,
}: GraphInspectorProps) {
  const inspector = useRef<HTMLElement>(null);
  const mobileQuery = '(max-width: 720px)';
  const [localMode, setMode] = useState<InspectorMode>(() =>
    globalThis.matchMedia(mobileQuery).matches ? 'documents' : 'filters',
  );
  const mode = controlledMode ?? localMode;
  const [openGroup, setOpenGroup] = useState<FilterGroup>('repositories');
  const [documentQuery, setDocumentQuery] = useState('');

  useEffect(() => {
    if (controlledMode !== undefined) return;
    const surface = inspector.current?.closest('.studio-knowledge');
    if (surface) {
      let compact: boolean | undefined;
      const observer = new ResizeObserver(([entry]) => {
        if (!entry) return;
        const next = entry.contentRect.width <= 720;
        if (compact !== next) {
          compact = next;
          setMode(next ? 'documents' : 'filters');
        }
      });
      observer.observe(surface);
      return () => observer.disconnect();
    }
    const media = globalThis.matchMedia(mobileQuery);
    const update = () => setMode(media.matches ? 'documents' : 'filters');
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);

  const activeFilters = useMemo<ActiveFilter[]>(
    () => [
      ...[...hiddenFilters.repository].map((value) => ({
        kind: 'repository' as const,
        value,
      })),
      ...[...hiddenFilters.type].map((value) => ({
        kind: 'type' as const,
        value,
      })),
      ...[...hiddenFilters.owner].map((value) => ({
        kind: 'owner' as const,
        value,
      })),
      ...[...hiddenFilters.tag].map((value) => ({
        kind: 'tag' as const,
        value,
      })),
      ...[...hiddenFilters.status].map((value) => ({
        kind: 'status' as const,
        value,
      })),
      ...[...hiddenFilters.cluster].map((value) => ({
        kind: 'cluster' as const,
        value,
      })),
    ],
    [hiddenFilters],
  );
  const filteredDocuments = useMemo(
    () =>
      visibleNodes
        .filter((node) => matchesGraphDocumentQuery(node, documentQuery))
        .slice()
        .sort(
          (left, right) =>
            left.title.localeCompare(right.title) ||
            left.path.localeCompare(right.path),
        ),
    [documentQuery, visibleNodes],
  );

  function selectMode(nextMode: InspectorMode) {
    setMode(nextMode);
    onModeChange?.(nextMode);
    onPreview(undefined);
    onHoverNode(undefined);
  }

  function handleTabKey(event: KeyboardEvent<HTMLButtonElement>) {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
    event.preventDefault();
    const nextMode = mode === 'filters' ? 'documents' : 'filters';
    selectMode(nextMode);
    globalThis.requestAnimationFrame(() => {
      document.querySelector<HTMLElement>(`#graph-${nextMode}-tab`)?.focus();
    });
  }

  function toggleGroup(group: FilterGroup) {
    setOpenGroup((current) => (current === group ? 'repositories' : group));
    onPreview(undefined);
  }

  const filterButtonHandlers = (kind: FilterKind, value: string) => ({
    onBlur: () => onPreview(undefined),
    onClick: () => {
      onPreview(undefined);
      onToggleFilter(kind, value);
    },
    onFocus: () => onPreview({ kind, value }),
    onPointerEnter: () => onPreview({ kind, value }),
    onPointerLeave: () => onPreview(undefined),
  });

  return (
    <aside
      ref={inspector}
      aria-label="Explore intelligence"
      className="graph-inspector atlas-scroll-surface"
    >
      <div className="graph-inspector-sticky">
        <div className="graph-inspector-header">
          <strong>
            {mode === 'preview'
              ? 'Document preview'
              : mode === 'filters'
                ? 'Map filters'
                : 'Documents'}
          </strong>
          <button
            aria-label="Close graph tools"
            onClick={onClose}
            title="Close graph tools"
            type="button"
          >
            <HeaderIcon name="close" />
          </button>
        </div>

        <div className="graph-inspector-stats" aria-label="Visible graph scope">
          <span>
            <strong>{visibleNodes.length}</strong> documents
          </span>
          <span aria-hidden="true">·</span>
          <span>
            <strong>{visibleEdgeCount}</strong> explicit links
          </span>
        </div>

        {mode === 'preview' && (
          <NodePreview
            graph={graph}
            hoveredNode={hoveredNode}
            neighborhood={neighborhood}
            neighborhoodActive={neighborhoodActive}
            neighborhoodLoading={neighborhoodLoading}
            onClearNeighborhood={onClearNeighborhood}
            onOpen={onOpen}
            onViewNeighborhood={onViewNeighborhood}
          />
        )}

        {mode !== 'preview' && (
          <div
            aria-label="Explore intelligence mode"
            className="graph-inspector-tabs"
            role="tablist"
          >
            <button
              aria-controls="graph-filters-panel"
              aria-selected={mode === 'filters'}
              id="graph-filters-tab"
              onClick={() => selectMode('filters')}
              onKeyDown={handleTabKey}
              role="tab"
              tabIndex={mode === 'filters' ? 0 : -1}
              type="button"
            >
              Filters
              {activeFilters.length > 0 && (
                <small>{activeFilters.length}</small>
              )}
            </button>
            <button
              aria-controls="graph-documents-panel"
              aria-selected={mode === 'documents'}
              id="graph-documents-tab"
              onClick={() => selectMode('documents')}
              onKeyDown={handleTabKey}
              role="tab"
              tabIndex={mode === 'documents' ? 0 : -1}
              type="button"
            >
              Documents
              <small>{visibleNodes.length}</small>
            </button>
          </div>
        )}
      </div>

      {mode === 'preview' ? null : mode === 'filters' ? (
        <div
          aria-labelledby="graph-filters-tab"
          className="graph-filters"
          id="graph-filters-panel"
          role="tabpanel"
        >
          <div className="graph-filter-heading">
            <span>
              {activeFilters.length > 0
                ? `${String(activeFilters.length)} hidden`
                : 'All visible'}
            </span>
            {activeFilters.length > 0 && (
              <button onClick={onResetFilters} type="button">
                Reset
              </button>
            )}
          </div>

          {activeFilters.length > 0 && (
            <div aria-label="Hidden filters" className="graph-active-filters">
              {activeFilters.map((filter) => (
                <button
                  aria-label={`Show ${filter.value}`}
                  key={`${filter.kind}:${filter.value}`}
                  onClick={() => onShowFilter(filter.kind, filter.value)}
                  type="button"
                >
                  <span>{filter.value}</span>
                  <span aria-hidden="true">×</span>
                </button>
              ))}
            </div>
          )}

          <div className="graph-filter-accordion">
            <FilterSection
              count={repositories.length}
              hiddenCount={hiddenFilters.repository.size}
              id="repositories"
              label="Repositories"
              onToggle={toggleGroup}
              open={openGroup === 'repositories'}
            >
              <div className="graph-repository-filters">
                {repositories.map((repository) => {
                  const visible = !hiddenFilters.repository.has(repository);
                  const detail = filterDetail(
                    repository,
                    repositoryInsights.get(repository),
                  );
                  return (
                    <button
                      {...filterButtonHandlers('repository', repository)}
                      aria-label={`${repository}, ${String(repositoryCounts.get(repository) ?? 0)} documents, ${visible ? 'visible' : 'hidden'}. ${detail}`}
                      aria-pressed={visible}
                      className="graph-repository-filter"
                      key={repository}
                      title={detail}
                      type="button"
                    >
                      <span
                        aria-hidden="true"
                        className="graph-filter-visibility"
                      />
                      <strong>{repository}</strong>
                      <small>{repositoryCounts.get(repository) ?? 0}</small>
                    </button>
                  );
                })}
              </div>
            </FilterSection>

            <FilterSection
              count={typeCounts.size}
              hiddenCount={hiddenFilters.type.size}
              id="types"
              label="Document types"
              onToggle={toggleGroup}
              open={openGroup === 'types'}
            >
              <div className="graph-filter-pills">
                {[...typeCounts]
                  .sort(([left], [right]) => left.localeCompare(right))
                  .map(([type, count]) => (
                    <button
                      {...filterButtonHandlers('type', type)}
                      aria-pressed={!hiddenFilters.type.has(type)}
                      key={type}
                      type="button"
                    >
                      <span>{type}</span>
                      <small>{count}</small>
                    </button>
                  ))}
              </div>
            </FilterSection>

            <FilterSection
              count={ownerCounts.size}
              hiddenCount={hiddenFilters.owner.size}
              id="owners"
              label="Owners"
              onToggle={toggleGroup}
              open={openGroup === 'owners'}
            >
              <div className="graph-filter-pills">
                {[...ownerCounts]
                  .sort(([left], [right]) => left.localeCompare(right))
                  .map(([owner, count]) => (
                    <button
                      {...filterButtonHandlers('owner', owner)}
                      aria-pressed={!hiddenFilters.owner.has(owner)}
                      key={owner}
                      type="button"
                    >
                      <span>{owner}</span>
                      <small>{count}</small>
                    </button>
                  ))}
              </div>
            </FilterSection>

            <FilterSection
              count={tagCounts.size}
              hiddenCount={hiddenFilters.tag.size}
              id="tags"
              label="Tags"
              onToggle={toggleGroup}
              open={openGroup === 'tags'}
            >
              <div className="graph-filter-pills">
                {[...tagCounts]
                  .sort(
                    ([leftTag, leftCount], [rightTag, rightCount]) =>
                      rightCount - leftCount || leftTag.localeCompare(rightTag),
                  )
                  .map(([tag, count]) => (
                    <button
                      {...filterButtonHandlers('tag', tag)}
                      aria-pressed={!hiddenFilters.tag.has(tag)}
                      key={tag}
                      type="button"
                    >
                      <span>{tag}</span>
                      <small>{count}</small>
                    </button>
                  ))}
              </div>
            </FilterSection>

            <FilterSection
              count={statusCounts.size}
              hiddenCount={hiddenFilters.status.size}
              id="statuses"
              label="Lifecycle"
              onToggle={toggleGroup}
              open={openGroup === 'statuses'}
            >
              <div className="graph-filter-pills">
                {[...statusCounts]
                  .sort(([left], [right]) => left.localeCompare(right))
                  .map(([status, count]) => (
                    <button
                      {...filterButtonHandlers('status', status)}
                      aria-pressed={!hiddenFilters.status.has(status)}
                      key={status}
                      type="button"
                    >
                      <span>{status}</span>
                      <small>{count}</small>
                    </button>
                  ))}
              </div>
            </FilterSection>

            <FilterSection
              count={graph.clusters.length}
              hiddenCount={hiddenFilters.cluster.size}
              id="clusters"
              label="Similarity clusters"
              onToggle={toggleGroup}
              open={openGroup === 'clusters'}
            >
              <small className="graph-filter-note">
                Layout aid · explicit links remain authoritative
              </small>
              <div className="graph-cluster-filters">
                {graph.clusters.map((cluster) => (
                  <button
                    {...filterButtonHandlers('cluster', cluster.id)}
                    aria-pressed={!hiddenFilters.cluster.has(cluster.id)}
                    key={cluster.id}
                    type="button"
                  >
                    <span
                      aria-hidden="true"
                      style={{ background: clusterColors.get(cluster.id) }}
                    />
                    <strong>{cluster.label}</strong>
                    <small
                      title={`${cluster.types.join(', ')} · ${cluster.tags.join(', ')}`}
                    >
                      {cluster.documentCount}
                    </small>
                  </button>
                ))}
              </div>
            </FilterSection>
          </div>
        </div>
      ) : (
        <div
          aria-labelledby="graph-documents-tab"
          className="graph-documents"
          id="graph-documents-panel"
          role="tabpanel"
        >
          <label className="graph-document-search">
            <span className="sr-only">Find in graph</span>
            <svg
              aria-hidden="true"
              fill="none"
              focusable="false"
              viewBox="0 0 20 20"
            >
              <circle cx="8.5" cy="8.5" r="5.25" />
              <path d="m12.5 12.5 4 4" />
            </svg>
            <input
              aria-label="Find in graph"
              onChange={(event) => setDocumentQuery(event.currentTarget.value)}
              placeholder="Find in graph"
              type="search"
              value={documentQuery}
            />
          </label>
          <div className="graph-document-results-heading">
            <span>
              {filteredDocuments.length} result
              {filteredDocuments.length === 1 ? '' : 's'}
            </span>
            {documentQuery && (
              <button onClick={() => setDocumentQuery('')} type="button">
                Clear
              </button>
            )}
          </div>
          {graph.truncated && (
            <p className="graph-truncated">
              Showing the first {graph.limit} documents. Narrow the filters to
              refine the corpus.
            </p>
          )}
          <div className="graph-document-list">
            {filteredDocuments.map((node) => {
              const linkCount = degree.get(node.id) ?? 0;
              const detail = `${node.repository} · ${node.path} · ${node.type} · ${node.status} · ${node.owner} · ${String(linkCount)} explicit link${linkCount === 1 ? '' : 's'}`;
              return (
                <button
                  aria-label={`${node.title}. ${detail}`}
                  key={node.id}
                  onBlur={() => onHoverNode(undefined)}
                  onClick={() => onOpen(node)}
                  onFocus={() => onHoverNode(node.id)}
                  onPointerEnter={() => onHoverNode(node.id)}
                  onPointerLeave={() => onHoverNode(undefined)}
                  title={detail}
                  type="button"
                >
                  <strong>{node.title}</strong>
                  <span>{node.repository}</span>
                  <small>
                    {linkCount} link{linkCount === 1 ? '' : 's'}
                  </small>
                </button>
              );
            })}
          </div>
          {filteredDocuments.length === 0 && (
            <p className="graph-document-empty">No visible documents match.</p>
          )}
        </div>
      )}
    </aside>
  );
}
