import { IconButton, Toolbar } from './ui.js';
import { SelectionToolbar, type SelectionToolbarProps } from './whiteboard-selection-toolbar.js';
import { type WhiteboardBlock, type WhiteboardStroke } from '@studio/contracts';
import { PenOptions } from './whiteboard-drawing.js';
import { BoardIcon } from './whiteboard-icon.js';
import { useWhiteboardImages } from './whiteboard-images.js';
import { ShapeIcon, ShapePalette } from './whiteboard-shape-tools.js';
import { type ShapeKind } from './whiteboard-shapes.js';
import type { BoardPanel, BoardTool, CanvasItem } from './whiteboard-types.js';

import type * as React from 'react';
import type { BoardHistory } from './whiteboard-history.js';

type Props = SelectionToolbarProps & {
  tool: BoardTool;
  shapeKind: ShapeKind;
  chooseShape: (kind: ShapeKind) => void;
  penColor: WhiteboardStroke['color'];
  penWidth: number;
  setPenColor: React.Dispatch<React.SetStateAction<'blue' | 'ink' | 'orange' | 'red'>>;
  setPenWidth: React.Dispatch<React.SetStateAction<number>>;
  setTool: React.Dispatch<React.SetStateAction<BoardTool>>;
  setPanel: React.Dispatch<React.SetStateAction<BoardPanel>>;
  setFocused: React.Dispatch<React.SetStateAction<CanvasItem | null>>;
  setAutoFocusId: React.Dispatch<React.SetStateAction<string | null>>;
  canvas: React.RefObject<HTMLDivElement | null>;
  create: (kind: WhiteboardBlock['kind'], placed?: { x: number; y: number }) => Promise<void>;
  isShared: boolean;
  createSection: () => Promise<void>;
  images: ReturnType<typeof useWhiteboardImages>;
  imageCapability: { data?: { enabled: boolean } };
  imagePending: boolean;
  setReplaceHtml: React.Dispatch<React.SetStateAction<string | null>>;
  openPanel: (next: BoardPanel) => void;
  panel: BoardPanel;
  historyVersion: number;
  history: BoardHistory;
  sectionId: string;
  reverse: (direction: 'undo' | 'redo') => Promise<void>;
};
export function WhiteboardToolbar(props: Props) {
  const {
    enabled,
    hasDraft,
    tool,
    shapeKind,
    chooseShape,
    penColor,
    penWidth,
    setPenColor,
    setPenWidth,
    setTool,
    setPanel,
    setFocused,
    setAutoFocusId,
    canvas,
    create,
    isShared,
    createSection,
    images,
    imageCapability,
    imagePending,
    setReplaceHtml,
    openPanel,
    panel,
    historyVersion,
    history,
    sectionId,
    reverse,
  } = props;
  return (
    <>
      {(tool === 'select' || tool === 'hand') && props.selection.length > 0 && (
        <SelectionToolbar {...props} />
      )}
      <div className="wboard-tool-stack">
        {tool === 'shape' && (
          <ShapePalette
            kind={shapeKind}
            choose={chooseShape}
            color={penColor}
            width={penWidth}
            setColor={setPenColor}
            setWidth={setPenWidth}
          />
        )}
        {tool === 'draw' && (
          <PenOptions
            color={penColor}
            width={penWidth}
            setColor={setPenColor}
            setWidth={setPenWidth}
          />
        )}
        <Toolbar className="wboard-dock wboard-float"  aria-label="Whiteboard tools">
          <IconButton
            className="wboard-tool"
            aria-label="Select tool"
            title="Select and move blocks"
            aria-pressed={tool === 'select'}
            onClick={() => setTool('select')}
          >
            <BoardIcon name="pointer" />
          </IconButton>
          <IconButton
            className="wboard-tool"
            aria-label="Hand tool"
            title="Pan canvas"
            aria-pressed={tool === 'hand'}
            onClick={() => {
              setTool('hand');
              setPanel(null);
              setFocused(null);
              setAutoFocusId(null);
            }}
          >
            <BoardIcon name="hand" />
          </IconButton>
          <IconButton
            className="wboard-tool"
            aria-label="Pencil tool"
            title="Draw freehand"
            aria-pressed={tool === 'draw'}
            onClick={() => {
              setTool('draw');
              setPanel(null);
              setFocused(null);
            }}
          >
            <BoardIcon name="edit" />
          </IconButton>
          <IconButton
            className="wboard-tool"
            aria-label="Shapes tool"
            title="Shapes, lines and arrows"
            aria-pressed={tool === 'shape'}
            disabled={!enabled}
            onClick={() => chooseShape(shapeKind)}
          >
            <ShapeIcon kind={shapeKind} />
          </IconButton>
          <IconButton
            className="wboard-tool"
            aria-label="Eraser tool"
            title="Erase whole drawings"
            aria-pressed={tool === 'erase'}
            disabled={!enabled || hasDraft}
            onClick={() => {
              setTool('erase');
              setPanel(null);
              setFocused(null);
            }}
          >
            <BoardIcon name="eraser" />
          </IconButton>
          <span className="wboard-divider" />
          <IconButton
            className="wboard-tool wboard-add-note"
            aria-label="Add note"
            title="Place a note"
            aria-pressed={tool === 'note'}
            disabled={!enabled}
            onClick={() => {
              setTool('note');
              setPanel(null);
              setFocused(null);
              canvas.current?.focus();
            }}
          >
            <BoardIcon name="note" />
          </IconButton>
          <IconButton
            className="wboard-tool"
            aria-label="Add document"
            title="Add document"
            disabled={!enabled}
            onClick={() => void create('document')}
          >
            <BoardIcon name="document" />
          </IconButton>
          <span className="wboard-divider" />
          <IconButton
            className="wboard-tool"
            aria-label="Add section"
            title={isShared ? 'Add section' : 'Enable collaboration in help to add sections'}
            disabled={!enabled || !isShared}
            onClick={() => void createSection()}
          >
            <BoardIcon name="board" />
          </IconButton>
          <input
            ref={images.input}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            multiple
            className="wboard-sr-only"
            tabIndex={-1}
            aria-label="Choose images"
            onChange={(e) => {
              const files = Array.from(e.target.files ?? []);
              e.target.value = '';
              void images.add(files);
            }}
          />
          <IconButton
            className="wboard-tool"
            aria-label="Upload image"
            title={
              imageCapability.data?.enabled
                ? 'Paste, drop or upload an image'
                : 'Image storage is not enabled for this project'
            }
            disabled={!enabled || !isShared || !imageCapability.data?.enabled || imagePending}
            onClick={() => images.input.current?.click()}
          >
            <BoardIcon name="image" />
          </IconButton>
          <IconButton
            className="wboard-tool"
            aria-label="Add HTML tile"
            title="Add HTML from library"
            disabled={!enabled || !isShared}
            onClick={() => {
              setReplaceHtml(null);
              openPanel('html');
            }}
          >
            <BoardIcon name="files" />
          </IconButton>
          <IconButton
            className="wboard-tool"
            aria-label="Whiteboard help"
            title="Whiteboard help"
            aria-expanded={panel === 'help'}
            aria-controls="wboard-panel"
            onClick={() => openPanel('help')}
          >
            <BoardIcon name="help" />
          </IconButton>
        </Toolbar>
      </div>
      {tool === 'shape' && (
        <p className="wboard-shape-hint wboard-float" role="status">
          Click to place or drag to size · Shift constrains · Enter places in the center · Escape
          cancels
        </p>
      )}
      {tool === 'note' && (
        <div className="wboard-placement-hint wboard-float" role="status">
          Click the canvas to place a note · Enter places it in the center · Escape cancels
        </div>
      )}
      <Toolbar
        className="wboard-edit-tools wboard-float"

        aria-label="Board editing"
        data-version={historyVersion}
      >
        <IconButton
          className="wboard-tool"
          aria-label="Undo board action"
          title="Undo board action (⌘/Ctrl Z)"
          disabled={!enabled || hasDraft || !history.get(sectionId).undo.length}
          onClick={() => void reverse('undo')}
        >
          <BoardIcon name="undo" />
        </IconButton>
        <IconButton
          className="wboard-tool"
          aria-label="Redo board action"
          title="Redo board action (⌘/Ctrl Shift Z)"
          disabled={!enabled || hasDraft || !history.get(sectionId).redo.length}
          onClick={() => void reverse('redo')}
        >
          <BoardIcon name="redo" />
        </IconButton>
      </Toolbar>
      {tool === 'erase' && (
        <div className="wboard-placement-hint wboard-float" role="status">
          Drag across ink to erase whole strokes · Undo restores them · Escape cancels a gesture
        </div>
      )}
    </>
  );
}
