/** Find only headings in the current embedded reader, avoiding shell ID collisions. */
export function findRenderedHeading(headingId: string): HTMLElement | null {
  const article = globalThis.document.querySelector(
    '.studio-knowledge .markdown-body',
  );
  return (
    [...(article?.querySelectorAll<HTMLElement>('[id]') ?? [])].find(
      (element) =>
        element.id === headingId || element.id === `user-content-${headingId}`,
    ) ?? null
  );
}
