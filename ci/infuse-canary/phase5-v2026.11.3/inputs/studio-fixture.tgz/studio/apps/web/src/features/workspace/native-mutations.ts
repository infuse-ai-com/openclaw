import { useEffect, useRef, useState } from 'react';
import { useWorkspace } from './context.js';
import { api, projectPath, ApiError, getSession, ownerKey, readableError } from './api.js';

/** A lost HTTP receipt must retain the exact idempotent envelope across reload. */
export function useNativeMutation<T>(scope: string, parse: (input: unknown) => T) {
  const { session, owner, current } = useWorkspace();
  const key = `infuse-studio:native:${encodeURIComponent(session.bootstrap.authorityId)}:${encodeURIComponent(session.profileId)}:${session.legacyProject ? '' : `project:${encodeURIComponent(session.project.id)}:`}${scope}`;
  const [recovery] = useState(() => {
    try { const saved = sessionStorage.getItem(key); return { pending: saved ? parse(JSON.parse(saved)) : undefined, error: '' }; }
    catch { return { pending: undefined, error: 'Restore browser session storage before submitting. A saved request could not be recovered.' }; }
  });
  const [pending, setPending] = useState(recovery.pending);
  const pendingRef = useRef(pending);
  const [error, setError] = useState(recovery.error);
  const [busy, setBusy] = useState(false);
  const lock = useRef(false); const mounted = useRef(true); const live = useRef(current); live.current = current;
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  const definitive = new Set(['INVALID_INPUT', 'CONFIGURATION', 'NOT_FOUND', 'IDEMPOTENCY_CONFLICT', 'VERSION_CONFLICT']);
  function clear() { sessionStorage.removeItem(key); pendingRef.current = undefined; if (mounted.current) setPending(undefined); }
  async function send(input: T, path: string, verify: (receipt: unknown, command: T) => void): Promise<unknown> {
    if (lock.current || !live.current || recovery.error) return;
    lock.current = true; setBusy(true); setError('');
    try {
      const command = pendingRef.current ?? parse(input);
      sessionStorage.setItem(key, JSON.stringify(command));
      pendingRef.current = command; setPending(command);
      const isCurrent = () => mounted.current && live.current;
      const fresh = await getSession(undefined, isCurrent, session.project.id);
      if (!isCurrent() || !fresh.authenticated || ownerKey(fresh) !== owner) throw Error('Reconnect as the original person to recover this exact request.');
      const result = await api(projectPath(path, session.project.id), { command, csrf: fresh.csrfToken, isCurrent });
      verify(result, command);
      clear(); return result;
    } catch (failure) {
      if (failure instanceof ApiError && definitive.has(failure.code)) {
        try { clear(); } catch { /* Keep the exact envelope if storage is unavailable. */ }
      }
      if (mounted.current) setError(readableError(failure));
    } finally { lock.current = false; if (mounted.current) setBusy(false); }
  }
  return { pending, error, busy, send, blocked: !!recovery.error };
}
