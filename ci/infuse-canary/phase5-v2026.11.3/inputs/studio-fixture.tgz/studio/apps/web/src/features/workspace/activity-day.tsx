import {useEffect,useRef,useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {contributionDate,gitAuthorKey,parseContributionsDay,type ContributionsView,type ContributionsDayView,type ContributionCursor} from '@studio/contracts';
import {useWorkspace} from './context.js';
import {readActivity as read} from './activity-read.js';
import {utcStamp as stamp,localStamp} from './evidence-time.js';
import {ShellIcon} from './shell.js';
type Commit=ContributionsDayView['commits'][number];
function CommitInspector({commit,data,onClose}:{commit:Commit;data:ContributionsView;onClose:()=>void}){
 const dialog=useRef<HTMLDialogElement>(null),repo=data.repositories.find(r=>r.sourceId===commit.sourceId),date=contributionDate(commit);
 const author=data.authors.find(a=>a.key===gitAuthorKey(commit));
 useEffect(()=>{const element=dialog.current; element?.showModal();return ()=>element?.close();},[]);
 return <dialog ref={dialog} className="ws-activity-inspector" aria-labelledby="activity-commit-title" onKeyDown={event=>{if(event.key!=='Tab')return;const controls=Array.from(event.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled),a[href]'));const first=controls[0],last=controls.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}}} onCancel={event=>{event.preventDefault();onClose();}} onClick={event=>{if(event.target===event.currentTarget){const rect=event.currentTarget.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right)onClose();}}}>
  <header><span className="ws-eyebrow"><ShellIcon name="artifact"/> COMMIT DETAILS</span><button autoFocus className="ws-button ws-button--quiet" aria-label="Close commit details" onClick={onClose}><ShellIcon name="close"/></button></header>
  <p className="ws-activity-repo-tag">{repo?`${repo.projectName} / ${repo.name}`:commit.sourceId}</p>
  <h2 id="activity-commit-title">{commit.message.split(/\r?\n/)[0]||'No commit message'}</h2>
  <div className="ws-activity-person"><span className="ws-activity-avatar" aria-hidden="true">{(author?.label??commit.authorName).slice(0,1).toUpperCase()}</span><div><strong>{author?.label??commit.authorName}</strong><small>{author?.kind?`${author.kind} · `:''}{stamp(date.date??undefined)}</small></div></div>
  <p className="ws-activity-literal">{commit.message||'No commit message'}</p>{commit.messageTruncated&&<p className="ws-activity-warning">Message truncated at source or by the metadata bound.</p>}
  <h3>Recorded metadata</h3><dl>
   <dt>Commit</dt><dd><code>{commit.sha}</code></dd>
   <dt>Graph date · UTC</dt><dd>{stamp(date.date??undefined)}</dd>
   <dt>Date used</dt><dd>{date.basis==='legacy'?'Retained legacy date':date.basis==='author'?'Author date':date.basis==='committer'?'Committer date fallback':'Unknown'}</dd>
   <dt>Graph date · local</dt><dd>{localStamp(date.date??undefined)}</dd>
   <dt>Author identity</dt><dd>{commit.authorName}{commit.authorEmail?` · ${commit.authorEmail}`:''}</dd>
   <dt>Author date</dt><dd>{stamp(commit.authorDate??undefined)}</dd>
   <dt>Committer identity</dt><dd>{commit.committerName??'Not recorded'}{commit.committerEmail?` · ${commit.committerEmail}`:''}</dd>
   <dt>Committer date</dt><dd>{stamp(commit.committerDate??undefined)}</dd>
   <dt>Retained date</dt><dd>{stamp(commit.legacyGraphDate)}</dd>
   <dt>Imported</dt><dd>{stamp(commit.importedAt)}</dd>
   <dt>Source</dt><dd>{{azure:'Azure Git',backoffice:'Retained Backoffice import',gitlab:'GitLab'}[commit.provenance]}</dd>
  </dl>
 </dialog>;
}
export function ActivityDay({day,filters,data,onClose}:{day:string;filters:Record<string,string>;data:ContributionsView;onClose?:()=>void}){
 const {session,current,visible}=useWorkspace(),[cursors,setCursors]=useState<ContributionCursor[]>([]),region=useRef<HTMLElement>(null),cursor=cursors.at(-1);
 const [selected,setSelected]=useState(''),trigger=useRef<HTMLButtonElement|null>(null);
 const scope=data.repositories.map(r=>[r.sourceId,r.organization,r.projectId,r.repositoryId]).sort();
 const query=useQuery({queryKey:['workspace','contribution-day',session.profileId,session.projects.map(p=>p.id).sort(),scope,day,filters,cursor],enabled:current,
  queryFn:({signal})=>read(`/api/contributions/day?${new URLSearchParams({date:day,...filters,...(cursor?{cursor:JSON.stringify(cursor)}:{})})}`,signal,parseContributionsDay),refetchInterval:current&&visible?15000:false,gcTime:0});
 useEffect(()=>{if(onClose||cursors.length){region.current?.focus({preventScroll:true});region.current?.scrollIntoView({block:'start'});}},[day,cursors.length,Boolean(onClose)]);
 const value=current&&query.data&&'value'in query.data?query.data.value:undefined;
 const commit=value?.commits.find(c=>c.sourceId+':'+c.sha===selected);
 function closeCommit(){setSelected('');queueMicrotask(()=>trigger.current?.focus({preventScroll:true}));}
 return <section className="ws-contrib-day" aria-label={`Commits on ${day}`} tabIndex={-1} ref={region} onKeyDown={event=>{if(event.key==='Escape'&&!selected&&onClose){event.stopPropagation();onClose();}}}>
  <header><h3>{day} <span>· UTC</span></h3>{onClose&&<button className="ws-activity-link" onClick={onClose}>Close day details</button>}</header>
  {query.isPending?<p role="status">Loading recorded commits…</p>:!value?<div role="status"><p>Day details are unavailable. Refresh your access and retry.</p><button className="ws-activity-link" onClick={()=>void query.refetch()}>Retry day</button></div>:<>
   {!value.commits.length&&<p className="ws-activity-note">No commits recorded for this day and these filters. Inspect source coverage before interpreting an empty day.</p>}
   <div className="ws-contrib-commits">{value.commits.map(c=>{const repo=data.repositories.find(r=>r.sourceId===c.sourceId),date=contributionDate(c),author=data.authors.find(a=>a.key===gitAuthorKey(c)),name=author?.label??c.authorName;return <article key={c.sourceId+':'+c.sha}><button className="ws-activity-commit-row" onClick={event=>{trigger.current=event.currentTarget;setSelected(c.sourceId+':'+c.sha);}} aria-haspopup="dialog"><span className="ws-activity-avatar" aria-hidden="true">{name.slice(0,1).toUpperCase()}</span><span className="ws-activity-change"><strong>{c.message.split(/\r?\n/)[0]||'No commit message'}</strong><small>{name} · {repo?.name??c.sourceId} · {stamp(date.date??undefined)}{date.basis!=='author'?` · ${date.basis==='legacy'?'Retained legacy date':'Committer date fallback'}`:''}</small></span><code>{c.sha.slice(0,7)}</code><span aria-hidden="true">›</span></button></article>;})}</div>
   {(cursors.length>0||value.nextCursor)&&<div className="ws-contrib-paging"><button className="ws-button ws-button--quiet" disabled={!cursors.length||query.isFetching} onClick={()=>{setSelected('');setCursors(previous=>previous.slice(0,-1));}}>Previous commits</button><span>Page {cursors.length+1}</span><button className="ws-button ws-button--quiet" disabled={!value.nextCursor||query.isFetching} onClick={()=>{if(value.nextCursor){setSelected('');setCursors(previous=>[...previous,value.nextCursor!]);}}}>Next commits</button></div>}
  </>}
  {commit&&<CommitInspector commit={commit} data={data} onClose={closeCommit}/>}
 </section>;
}
