import { agentAppearance, agentSeatPreference } from './agent-identity.js';
import type { RuntimeTarget } from '@studio/contracts';
import type { ProjectWork } from './company-work.js';
import type { SpatialProjection } from '../studio/spatial-projection.js';
import { projectStudioSpace } from '../studio/spatial-projection.js';
import { targetKey, terminal } from '../studio/presentation.js';

export interface FloorAssignment {
  id: string; missionTitle: string; title: string; path: string; role: 'coordinator' | 'specialist';
  conversationUrl?: string;
  status: string; running: boolean; uncertain: boolean; at: string;
}
export interface FloorDesk { key: string; target: RuntimeTarget; work: FloorAssignment[]; status: string; seat: number }
/** The roster represents the team; only observed current work can drive a work gesture. */
export function floorModel(data: ProjectWork | undefined, stale: boolean) {
  const desks = new Map<string, FloorDesk>();
  const admitted = new Set(data?.session.bootstrap.targets.map(targetKey));
  for (const target of data?.session.bootstrap.targets ?? []) {
    const key = targetKey(target);
    desks.set(key, { key, target: { gatewayId: target.gatewayId, agentId: target.agentId }, work: [], status: '', seat: -1 });
  }
  const add = (target: RuntimeTarget, work: FloorAssignment) => {
    const key = targetKey(target); if (!admitted.has(key)) return;
    const desk = desks.get(key)!;
    desk.work.push(work); desks.set(key, desk);
  };
  for (const view of data?.nativeViews ?? []) {
    const m = view.mission;
    if (m.projectId !== data?.session.project.id || ['closed', 'cancelled'].includes(m.state)) continue;
    for (const a of view.assignments) {
      const task = view.tasks.find(t => t.assignmentId === a.id);
      if (a.state !== 'current' || (a.role === 'coordinator' ? m.coordinatorAssignmentId !== a.id : !task)) continue;
      const actions = view.actions.filter(action => action.assignmentId === a.id).sort((x,y) => y.createdAt.localeCompare(x.createdAt));
      const uncertain = actions.some(action => action.state === 'uncertain' || action.abortState === 'uncertain');
      const recordedRunning = !m.held && !uncertain && actions.some(action => action.state === 'running' && !!action.runId && !action.abortState);
      const running = !stale && recordedRunning;
      const queued = actions.some(action => action.state === 'queued');
      const connecting = actions.some(action => action.state === 'dispatching');
      const status = m.held ? 'On hold' : uncertain ? 'Outcome uncertain' : recordedRunning ? 'Working' : connecting ? 'Connecting' : queued ? 'Queued' : task?.state === 'delivered' ? 'Ready for review' : task?.state === 'verified' ? 'Verified' : task?.state === 'blocked' ? 'Blocked' : actions[0]?.state === 'failed' ? 'Last attempt failed' : 'Waiting';
      const thread = view.threads?.find(t => t.id === a.threadId && t.assignmentId === a.id && t.missionId === m.id && t.generation === a.generation && t.protected && /^https:\/\//.test(t.origin));
      add(a, { id: a.id, missionTitle: m.paper.title, title: task?.plan.title ?? 'Mission coordination',
        path: `/missions/v2/${encodeURIComponent(m.id)}?${new URLSearchParams({ project: m.projectId, section: 'tasks' })}`,
        ...(thread ? { conversationUrl: `${thread.origin}/_redirect/pl/${encodeURIComponent(thread.rootPostId)}` } : {}),
        role: a.role, status: stale ? `Last known · ${status === 'Working' ? 'Run recorded' : status}` : status,
        running, uncertain, at: actions[0]?.settledAt ?? actions[0]?.createdAt ?? a.createdAt });
    }
  }
  for (const view of data?.legacyViews ?? []) {
    const m = view.mission; if (terminal(m)) continue;
    for (const agent of projectStudioSpace([], view, stale).agents) {
      const assignment = m.assignments[agent.role]; if (!assignment) continue;
      add(agent.target, { id: `${m.id}:${agent.role}`, missionTitle: m.paper.title,
        title: agent.role === 'coordinator' ? 'Mission coordination' : 'Mission delivery',
        path: `/missions/${encodeURIComponent(m.id)}?${new URLSearchParams({ project: data!.session.project.id, section: 'activity' })}`,
        role: agent.role, status: agent.status, running: false, uncertain: agent.tone === 'uncertain', at: m.updatedAt });
    }
  }
  const entries = [...desks.values()].sort((a,b) => a.key.localeCompare(b.key));
  const seats = new Set<number>();
  // Known portraits keep their regular desk. Canonical sorting resolves aliases on different Gateways.
  for (const desk of entries) {
    const preferred = agentSeatPreference(desk.target.agentId);
    if (preferred >= 0 && !seats.has(preferred)) { desk.seat = preferred; seats.add(preferred); }
    desk.work.sort((a,b) => Number(b.running) - Number(a.running) || Number(b.uncertain) - Number(a.uncertain) || a.id.localeCompare(b.id));
    desk.status = desk.work[0]?.status ?? (stale ? 'Last known · no work shown on this floor' : 'No work shown on this floor');
  }
  for (const desk of entries.filter(d => d.seat < 0)) {
    let seat = 0; while (seats.has(seat)) seat++;
    desk.seat = seat; seats.add(seat);
  }
  const count = (data?.native.length ?? 0) + (data?.legacy.length ?? 0);
  const reviewCount = (data?.nativeViews ?? []).reduce((n,v) => n + v.tasks.filter(t => t.state === 'delivered').length, 0);
  const projection: SpatialProjection = { title: data?.session.project.name ?? 'Project floor', subtitle: 'Recorded project work',
    missionCount: count, paperCount: count, reviewCount, evidencePresent: reviewCount > 0, stale,
    agents: entries.filter(d => d.seat < 8).map(d => ({ key: d.key, target: d.target, role: d.work[0]?.role ?? 'specialist',
      seat: d.seat, appearance: agentAppearance(d.target.agentId), assigned: d.work.length > 0,
      status: d.status, running: d.work.some(w => w.running), tone: d.work.some(w => w.uncertain) ? 'uncertain' : d.work.some(w => ['Ready for review','Verified'].includes(w.status)) ? 'evidence' : d.work.length ? 'admitted' : 'quiet' })) };
  return { desks: entries, assignedCount: entries.filter(d => d.work.length).length, projection };
}
