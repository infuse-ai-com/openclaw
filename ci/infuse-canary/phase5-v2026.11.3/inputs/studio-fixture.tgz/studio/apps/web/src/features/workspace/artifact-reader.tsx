import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import type { ArtifactDetail, ArtifactManifest } from '@studio/contracts';
import { ControlHint } from './control-hint.js';
import { useArtifactSession } from './artifact-session.js';
import { ArtifactFiles, type ReaderControls } from './artifact-files.js';
import { ArtifactDate, ArtifactIcon, ArtifactVersion } from './artifact-ui.js';
import { ArtifactDeleteForm, ArtifactLifecyclePanel, ArtifactLifecycleRecovery, useArtifactLifecycleController } from './artifact-lifecycle.js';
import { Button, EmptyState, IconButton } from './ui.js';
import { LoadingState } from './loading.js';
import { Link, useNavigate } from './navigation.js';

/** The exact URL is a reading surface. Secondary controls never occupy its footer. */
export function ArtifactReader({ manifest, revisions, producer, artifactId, revision, projectId, controller,
  current, refreshing, error, onRefresh, onRevision }: {
  manifest?: ArtifactManifest; revisions: ArtifactDetail['revisions']; producer: string; artifactId: string;
  revision: string; projectId: string; controller: ReturnType<typeof useArtifactLifecycleController>;
  current: boolean; refreshing: boolean; error?: string; onRefresh(): void; onRevision(revision: string): void;
}) {
  const [details, setDetails] = useState(false), [expanded, setExpanded] = useState(false), [deleting, setDeleting] = useState(false);
  const info = useRef<HTMLButtonElement>(null), deleteButton = useRef<HTMLButtonElement>(null), { backTo, backState, visit } = useArtifactSession(), navigate = useNavigate();
  const title = manifest?.title ?? (error || !current ? 'Artifact unavailable' : 'Artifact');
  function closeDetails() { setDetails(false); info.current?.focus({ preventScroll: true }); }
  function closeDelete() { setDeleting(false); deleteButton.current?.focus({ preventScroll: true }); }
  function chrome(controls?: ReaderControls) {
    return <>
      {!details && !deleting && <ArtifactLifecycleRecovery controller={controller} />}
      <header className="ws-artifact-canvas-bar">
        <ControlHint label="Back to artifacts"><Link className="ws-artifact-back" to={backTo} state={backState} replace onClick={e => { if (visit && e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) { e.preventDefault(); navigate(-1); } }} aria-label="Artifacts"><ArtifactIcon name="back" /></Link></ControlHint>
        <div className="ws-artifact-canvas-heading"><h1 title={title}>{title}</h1>
          {manifest && <span className="ws-artifact-category" title={manifest.kind}><span className="ws-artifact-sr">Category: </span>{manifest.kind}</span>}
        </div>
        <div className="ws-artifact-canvas-actions">
          {controls?.filePicker}
          {controls && <CopyArtifactLink link={controls.link}/>}
          {controls?.download}
          <ControlHint label={expanded ? 'Restore workspace' : 'Focus on artifact'}><IconButton className="ws-artifact-focus" aria-label={expanded ? 'Restore view' : 'Expand preview'} aria-pressed={expanded} onClick={() => setExpanded(value => !value)}><ArtifactIcon name={expanded ? 'minimize' : 'fit'} /></IconButton></ControlHint>
          <ControlHint label="Artifact details"><IconButton ref={info} aria-label="Artifact details" aria-haspopup="dialog" aria-expanded={details} onClick={() => setDetails(true)}><ArtifactIcon name="info" /></IconButton></ControlHint>
          <ControlHint label="Move to bin"><IconButton ref={deleteButton} className="ws-artifact-delete-button" aria-label="Delete artifact" aria-haspopup="dialog" aria-expanded={deleting} disabled={!manifest || !current || controller.busy || !!controller.pending || controller.blocked} onClick={() => setDeleting(true)}><ArtifactIcon name="trash" /></IconButton></ControlHint>
        </div>
      </header>
      {details && <ReaderDialog title="Artifact details" kind="details" onClose={closeDetails}>{close => <>
        <ArtifactLifecycleRecovery controller={controller} />
        <h3>{title}</h3>
        {manifest?.summary && <p>{manifest.summary}</p>}
        {controls && <div className="ws-artifact-reader-options"><div className="ws-artifact-single-value"><span>File</span><strong>{controls.fileName}</strong></div>
          <ArtifactVersion revisions={revisions} revision={revision} onChange={value=>{setDetails(false);onRevision(value);}}/>
        </div>}
        {controls && <div className="ws-artifact-mobile-actions">{controls.download}<Button variant="quiet" aria-label={expanded ? 'Restore view' : 'Expand preview'} onClick={()=>{close();setExpanded(!expanded);}}>{expanded ? 'Restore view' : 'Focus on artifact'}</Button></div>}
        {manifest && <><dl><dt>Published by</dt><dd>{manifest.producer}</dd><dt>Published</dt><dd><ArtifactDate value={manifest.createdAt}/></dd></dl>
          {manifest.missionId && <p>Publisher association: <Link to={`/missions/v2/${encodeURIComponent(manifest.missionId)}`}>View mission ↗</Link>{manifest.taskId ? ` · task ${manifest.taskId}` : ''}.</p>}
          {controls?.fileDetails}
          <details className="ws-record"><summary>Provenance</summary><dl><dt>Source supplied by publisher</dt><dd>{manifest.sourceRef ?? 'Not supplied'}</dd><dt>Exact revision</dt><dd><code>artifact-registry:{manifest.producer}/{manifest.artifactId}@{manifest.revision}</code></dd></dl>
            <p>HTML runs in an isolated preview. Publication and byte integrity do not establish that its claims are correct or verify task delivery.</p>
          </details></>}
        <Button variant="quiet" disabled={!current || refreshing} onClick={onRefresh}>Refresh artifact</Button>
        <ArtifactLifecyclePanel producer={producer} artifactId={artifactId} revision={revision} controller={controller} />
      </>}</ReaderDialog>}
    </>;
  }
  return <section className={`ws-surface ws-artifact-viewer ws-artifact-canvas${expanded ? ' ws-artifact-expanded' : ''}`} aria-label="Artifact viewer"
    onKeyDown={event => { if (event.key === 'Escape' && !details && !deleting && expanded) { event.preventDefault(); setExpanded(false); } }}>
    {manifest ? <ArtifactFiles key={`${producer}/${artifactId}/${revision}`} manifest={manifest} projectId={projectId} readerChrome={chrome} />
      : <>{chrome()}{error ? <EmptyState title="This artifact is unavailable" descriptionRole="alert" actions={<Button variant="quiet" disabled={!current || refreshing} onClick={onRefresh}>Try again</Button>}>{error}</EmptyState>
        : !current ? <EmptyState title="Reconnect to inspect this artifact." /> : <LoadingState label="Loading artifact…" size="page" />}</>}
    {deleting && <ReaderDialog title="Delete artifact?" kind="delete" onClose={closeDelete}>{close =>
      <ArtifactDeleteForm producer={producer} artifactId={artifactId} revision={revision} title={title} controller={controller} onCancel={close} />
    }</ReaderDialog>}
  </section>;
}

function ReaderDialog({ children, title, kind, onClose }: { children(close: () => void): ReactNode; title: string; kind: 'details' | 'delete' | 'copy'; onClose(): void }) {
  const dialog = useRef<HTMLDialogElement>(null), titleId = useId();
  useEffect(() => { const element = dialog.current!; element.showModal(); return () => element.close(); }, []);
  function close() { dialog.current?.close(); onClose(); }
  return <dialog ref={dialog} className={`ws-artifact-reader-dialog ws-artifact-reader-${kind}`} aria-labelledby={titleId} onCancel={event => { event.preventDefault(); close(); }}
    onKeyDown={event => {
      if (event.key !== 'Tab') return;
      const controls = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],select:not(:disabled),input:not(:disabled),textarea:not(:disabled),summary,[tabindex="0"]')).filter(element => element.getClientRects().length > 0);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }}
    onClick={event => { if (event.target === event.currentTarget) { const rect = event.currentTarget.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) close(); } }}>
    <header><h2 id={titleId}>{title}</h2><IconButton autoFocus aria-label={kind === 'details' ? 'Close artifact details' : kind === 'copy' ? 'Close copy link' : 'Close delete confirmation'} onClick={close}><ArtifactIcon name="close" /></IconButton></header>
    <div className="ws-artifact-reader-details-body">{children(close)}</div>
  </dialog>;
}

function CopyArtifactLink({link}:{link:string}) {
  const [status,setStatus]=useState<'idle'|'copied'|'manual'>('idle');
  useEffect(()=>{if(status!=='copied')return;const timer=window.setTimeout(()=>setStatus('idle'),2500);return()=>window.clearTimeout(timer);},[status]);
  async function copy(){try{await navigator.clipboard.writeText(link);setStatus('copied');}catch{setStatus('manual');}}
  return <><ControlHint label={status==='copied'?'Link copied':'Copy link'}><IconButton aria-label="Copy link" onClick={()=>void copy()}><ArtifactIcon name={status==='copied'?'check':'copy'}/></IconButton></ControlHint>
    <span role="status" className="ws-artifact-sr">{status==='copied'?'Link copied':''}</span>
    {status==='manual'&&<ReaderDialog title="Copy link" kind="copy" onClose={()=>setStatus('idle')}>{()=> <label>Copy this artifact link<input className="ui-control" aria-label="Artifact link" readOnly value={link} onFocus={e=>e.target.select()}/></label>}</ReaderDialog>}</>;
}
