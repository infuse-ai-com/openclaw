import { LoadingState } from './loading.js';
import { lazy, Suspense, useMemo, useEffect } from 'react';
import { createKnowledgeApi, KnowledgeApiContext } from './knowledge/reader/api.js';
import { useWorkspace } from './context.js';
import { Link } from './navigation.js';
const Reader = lazy(() => import('./knowledge/reader-root.js'));
export function KnowledgeWorkspace() {
  const { session, current, owner } = useWorkspace();
  const readerApi = useMemo(() => createKnowledgeApi(session.project.id, session.knowledgeScope?.revision), [session.project.id, session.knowledgeScope?.revision]);
  useEffect(() => () => readerApi.cancelPending(), [readerApi]);
  const core = session.projects.find(
    (p) => p.id === 'core' && p.kind === 'company',
  );
  if (!(session.project.id === 'core' && core) && !session.knowledgeScope)
    return (
      <section className="ws-surface">
        <header className="ws-surface-header">
          <h1>Knowledge</h1>
        </header>
        <div className="ws-empty">
          <h2>Choose repositories for this floor.</h2>
          {session.canManageFloors && <Link className="ws-button" to="/floors">Manage floor sources →</Link>}
          {core ? (
            <Link className="ws-button" to="/knowledge?project=core">
              Open {core.name} Knowledge →
            </Link>
          ) : (
            <p>Choose sources to read Knowledge on this floor.</p>
          )}
        </div>
      </section>
    );
  if (!current)
    return (
      <section className="ws-surface">
        <div className="ws-empty">
          <h1>Reconnect to read Knowledge.</h1>
          <p>Refresh successfully before loading private company sources.</p>
        </div>
      </section>
    );
  return (
    <Suspense fallback={<section className="ws-surface"><header className="ws-surface-header"><h1>Knowledge</h1></header><LoadingState label="Loading Knowledge…" size="page" /></section>}>
      <KnowledgeApiContext.Provider value={readerApi}><Reader key={`${owner}:${session.knowledgeScope?.revision ?? 'legacy'}`} owner={`${owner}:${session.knowledgeScope?.revision ?? 'legacy'}`} /></KnowledgeApiContext.Provider>
    </Suspense>
  );
}
