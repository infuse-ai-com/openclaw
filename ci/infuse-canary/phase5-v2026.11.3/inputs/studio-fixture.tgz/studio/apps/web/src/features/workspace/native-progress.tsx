import type { NativeInstruction, NativeMissionView } from '@studio/contracts';

function transport(item: NativeInstruction, data: NativeMissionView) {
  const action = data.actions.find(a => a.id === item.actionId);
  const effect = action?.requiredEffectIds?.map(id => data.provisioning.find(p => p.id === id)).find(p => p?.state !== 'delivered');
  if (effect) return effect.state === 'uncertain' ? 'Uncertain native delivery' : 'Awaiting native delivery';
  if (action?.waitForActionId && data.actions.find(a => a.id === action.waitForActionId)?.state !== 'settled') return 'Awaiting source run';
  return 'Posted';
}
export function NativeTaskInbox({ taskId, data }: { taskId: string; data: NativeMissionView }) {
  const items = (data.instructions ?? []).filter(i => i.taskId === taskId);
  if (!items.length) return null;
  const pending = items.filter(i => !['applied', 'superseded'].includes(i.state));
  return <section aria-label="Task instruction inbox"><h3>Instructions · {pending.length} awaiting application</h3>
    {pending.length > 0 && <p className="ws-small">The specialist must read and apply this feedback before delivery, or record a blocker. Reading alone does not resolve it.</p>}
    {items.map(i => <details key={i.id} className="ws-record"><summary>#{i.sequence} · {transport(i, data)} · {i.state}</summary>
      <p className="ws-literal">{i.text}</p>{i.receipts.map((r, index) => <p key={index} className="ws-small">{r.state} · session {r.sessionGeneration} · {new Date(r.at).toLocaleString()}{r.reason ? ` · ${r.reason}` : ''}</p>)}
    </details>)}
  </section>;
}
export function NativeProgress({ data }: { data: NativeMissionView }) {
  const pending = (data.instructions ?? []).filter(i => !['applied', 'superseded'].includes(i.state));
  const active = data.actions.filter(a => ['running', 'dispatching', 'uncertain'].includes(a.state));
  const blocked = data.tasks.filter(t => t.state === 'blocked' || t.state === 'revision');
  const latest = [...data.evidence].sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  const references = [...new Map(data.evidence.flatMap(e => e.references).map(r => [r.url + r.revision, r])).values()];
  const next = data.mission.held ? 'Resume when ready; queued instructions are preserved.'
    : ['closed', 'cancelled'].includes(data.mission.state) ? 'No further mission execution is scheduled.'
    : blocked.length ? 'Resolve the recorded blocker or requested revision.'
    : pending.length ? 'Read and apply pending instructions before delivery.'
    : data.tasks.some(t => t.state === 'delivered') ? 'Emon reviews the exact delivered evidence.'
    : active.length ? 'Agents continue their admitted work.' : 'Waiting for the next eligible task or decision.';
  return <section className="ws-native-progress" aria-label="Mission progress"><div><span className="ws-eyebrow">NEXT ACTION</span><p>{next}</p></div>
    <details><summary>{active.length} active {active.length === 1 ? 'run' : 'runs'} · {pending.length} unresolved {pending.length === 1 ? 'instruction' : 'instructions'} · {data.tasks.filter(t => t.state === 'delivered').length} {data.tasks.filter(t => t.state === 'delivered').length === 1 ? 'delivery' : 'deliveries'} awaiting review</summary>
      {latest ? <p className="ws-small">Last delivery: {latest.summary} · {new Date(latest.createdAt).toLocaleString()}</p> : <p className="ws-small">No delivery recorded yet.</p>}
      {references.length > 0 && <p className="ws-small">{references.filter(r => r.kind !== 'repository').map(r => <a key={r.url + r.revision} href={r.url} target="_blank" rel="noreferrer">{r.kind} ↗ </a>)} Evidence links do not imply a merge or deployment.</p>}
    </details>
  </section>;
}

export function NativeTaskFindings({ taskId, data }: { taskId: string; data: NativeMissionView }) {
  const findings = (data.findings ?? []).filter(f => f.taskId === taskId);
  if (!findings.length) return null;
  return <section aria-label="Review findings"><h3>Review findings</h3>{findings.map(f => <details key={f.id} className="ws-record" open={f.required && f.state !== 'closed'}>
    <summary>{f.id} · {f.title} · {f.severity} · {f.state}{f.required ? ' · Required' : ''}</summary>
    <p>{f.acceptance}</p><p className="ws-literal">{f.reproduction}</p>
    {f.proposal && <><p>Proposed fix: {f.proposal.summary}</p><p>Checks: {f.proposal.checks}</p>{f.proposal.artifactSha256 && <p>Exact artifact SHA-256: <code>{f.proposal.artifactSha256}</code></p>}</>}
    {f.review && <p>Coordinator review: {f.review.summary}</p>}
    <p className="ws-small">Owner: {data.tasks.find(t => t.id === f.taskId)?.plan.owner.agentId} · Finding revision {f.version}</p>
    {f.history.map(h => <p className="ws-small" key={h.version}>Revision {h.version}: {h.state} · {h.summary}</p>)}
  </details>)}</section>;
}
