/** Evidence dates use explicit zones; relative age never changes source freshness. */
export function utcStamp(value:string|undefined):string {
 if(!value||!Number.isFinite(Date.parse(value)))return 'Not recorded';
 return new Date(value).toISOString().slice(0,19).replace('T',' ')+' UTC';
}
export function localStamp(value:string|undefined):string {
 if(!value||!Number.isFinite(Date.parse(value)))return 'Not recorded';
 return new Date(value).toLocaleString(undefined,{timeZoneName:'short'})+' · local';
}
export function relativeStamp(value:string|undefined,now=Date.now()):string {
 if(!value||!Number.isFinite(Date.parse(value)))return 'Not recorded';
 const seconds=(Date.parse(value)-now)/1000,absolute=Math.abs(seconds);
 if(absolute<60)return seconds>5?'Within the next minute':'Just now';
 const unit=absolute<3600?'minute':absolute<86400?'hour':'day';
 const divisor=unit==='minute'?60:unit==='hour'?3600:86400;
 return new Intl.RelativeTimeFormat('en',{numeric:'auto'}).format(Math.trunc(seconds/divisor),unit);
}
export function contributionWeekRange(year:number,index:number):string {
 const start=Date.parse(`${String(year).padStart(4,'0')}-01-01T00:00:00Z`)+index*7*86400000;
 const end=Math.min(start+6*86400000,Date.parse(`${String(year).padStart(4,'0')}-12-31T00:00:00Z`));
 return `${new Date(start).toISOString().slice(0,10)} – ${new Date(end).toISOString().slice(0,10)} UTC`;
}
