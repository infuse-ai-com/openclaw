import type {
  WhiteboardSummary,
  WhiteboardSpatialOperation,
  WhiteboardSection,
} from '@studio/contracts';

/** Build one atomic move from fresh metadata; bodies and artifact bytes never need copying. */
export function selectionSection(
  items: WhiteboardSummary[],
  ids: string[],
  parentId: string,
  newId: string,
) {
  const selected = new Set(ids);
  const blocks = items
    .filter((item) => item.kind !== 'connection')
    .filter((item) => selected.has(item.id));
  if (
    !blocks.length ||
    blocks.length !== selected.size ||
    blocks.some((item) => item.sectionId !== parentId)
  )
    throw Error('The selection changed. Select the elements again.');
  if (blocks.some((item) => item.locked))
    throw Error('Unlock the selected elements before moving them into a section.');
  const links = items.filter(
    (item) =>
      item.kind === 'connection' && (selected.has(item.source) || selected.has(item.target)),
  );
  if (
    links.some(
      (item) =>
        item.kind === 'connection' && (!selected.has(item.source) || !selected.has(item.target)),
    )
  )
    throw Error('Select both ends of connected elements to put them in a section.');
  if (1 + blocks.length + links.length > 30)
    throw Error(
      'Choose fewer elements. A section can group up to 29 elements and connections at once.',
    );
  const x = Math.max(-100000, Math.min(...blocks.map((b) => b.x)) - 32);
  const y = Math.max(-100000, Math.min(...blocks.map((b) => b.y)) - 56);
  if (blocks.some((b) => Math.abs(b.x - x) > 100000 || Math.abs(b.y - y) > 100000))
    throw Error('Move these elements closer together before creating a section.');
  const section: Omit<WhiteboardSection, 'revision'> = {
    id: newId,
    kind: 'section',
    title: 'New section',
    x,
    y,
    width: Math.min(4000, Math.max(400, Math.max(...blocks.map((b) => b.x + b.width)) - x + 32)),
    height: Math.min(4000, Math.max(280, Math.max(...blocks.map((b) => b.y + b.height)) - y + 32)),
  };
  const operations: WhiteboardSpatialOperation[] = [
    { type: 'createSection', sectionId: parentId, section },
    ...[...blocks, ...links].map((item) => ({
      type: 'reparent' as const,
      id: item.id,
      expectedRevision: item.revision,
      sectionId: newId,
    })),
  ];
  return { section, operations };
}
