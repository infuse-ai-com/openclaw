import { useEffect, useRef, useState, type SubmitEvent } from 'react';
import type { Document, ReviewQueue } from '@studio/contracts/knowledge';

export type ReviewQueueEntry = ReviewQueue['entries'][number];

export function reviewStateLabel(state: Document['review']['state']): string {
  return {
    'never-reviewed': 'First review',
    changed: 'Changed',
    overdue: 'Overdue',
    reviewed: 'Reviewed',
  }[state];
}

export function reviewReason(state: Document['review']['state']): {
  detail: string;
  title: string;
} {
  return {
    'never-reviewed': {
      detail:
        'Read the current document and attest the exact Git version when it is trustworthy.',
      title: 'First human review needed',
    },
    changed: {
      detail:
        'Compare the last reviewed version with the current document before attesting the new Git blob.',
      title: 'Changed since human review',
    },
    overdue: {
      detail:
        'The review cadence has elapsed. Re-read the current version before renewing its attestation.',
      title: 'Review cadence reached',
    },
    reviewed: {
      detail: 'The current indexed Git blob has a human-review attestation.',
      title: 'Current version reviewed',
    },
  }[state];
}

export function reviewRisk(type: string): {
  label: string;
  level: 'high' | 'highest' | 'standard';
} {
  if (['policy', 'standard', 'decision'].includes(type)) {
    return { label: 'Highest priority', level: 'highest' };
  }
  if (['architecture', 'runbook'].includes(type)) {
    return { label: 'High priority', level: 'high' };
  }
  return { label: 'Standard priority', level: 'standard' };
}

interface ReviewReaderBannerProps {
  document: Document;
  onBackToDesk: () => void;
  onNavigate: (index: number) => void;
  onRequestReview: () => void;
  onReviewChanges: () => void;
  reviewRecorded: boolean;
  session: { entries: ReviewQueueEntry[]; index: number } | undefined;
}

export function ReviewReaderBanner(props: ReviewReaderBannerProps) {
  const reason = reviewReason(props.document.review.state);
  const sessionEntry = props.session?.entries[props.session.index];
  const show =
    props.document.review.state !== 'reviewed' ||
    props.reviewRecorded ||
    Boolean(sessionEntry);

  if (!show) return null;

  const previousIndex = props.session ? props.session.index - 1 : -1;
  const nextIndex = props.session ? props.session.index + 1 : -1;
  const hasPrevious = previousIndex >= 0;
  const hasNext = Boolean(
    props.session && nextIndex < props.session.entries.length,
  );

  return (
    <section
      aria-label="Human review"
      className={`review-reader-banner${props.reviewRecorded ? ' is-complete' : ''}`}
      data-review-state={props.document.review.state}
    >
      <div className="review-reader-context">
        <p className="eyebrow">
          {props.session
            ? `Review desk · ${String(props.session.index + 1)} of ${String(props.session.entries.length)}`
            : 'Human review'}
        </p>
        <strong>
          {props.reviewRecorded
            ? 'Review recorded for this exact version'
            : reason.title}
        </strong>
        <small>
          {props.reviewRecorded
            ? `Commit ${props.document.provenance.commit.slice(0, 8)} is now attested. Source Markdown was not changed.`
            : reason.detail}
        </small>
      </div>

      <div className="review-reader-actions">
        {props.document.review.state === 'changed' && !props.reviewRecorded && (
          <button onClick={props.onReviewChanges} type="button">
            Review exact changes
          </button>
        )}
        {props.document.review.canReview &&
          props.document.review.state !== 'reviewed' &&
          !props.reviewRecorded && (
            <button
              className="review-primary-action"
              onClick={props.onRequestReview}
              type="button"
            >
              Finish review
            </button>
          )}
        {props.session && (
          <div
            aria-label="Review queue navigation"
            className="review-session-navigation"
          >
            <button onClick={props.onBackToDesk} type="button">
              Back to desk
            </button>
            <button
              aria-label="Previous review document"
              disabled={!hasPrevious}
              onClick={() => props.onNavigate(previousIndex)}
              type="button"
            >
              ←
            </button>
            <button
              aria-label="Next review document"
              disabled={!hasNext}
              onClick={() => props.onNavigate(nextIndex)}
              type="button"
            >
              {props.reviewRecorded && hasNext ? 'Next' : '→'}
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

interface ReviewConfirmationDialogProps {
  document: Document | undefined;
  error: boolean;
  onCancel: () => void;
  onConfirm: (note: string | undefined) => void;
  open: boolean;
  pending: boolean;
}

export function ReviewConfirmationDialog(props: ReviewConfirmationDialogProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [note, setNote] = useState('');

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (props.open && !dialog.open) {
      setNote('');
      dialog.showModal();
    } else if (!props.open && dialog.open) {
      dialog.close();
    }
  }, [props.open]);

  function submit(event: SubmitEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = note.trim();
    props.onConfirm(normalized ? normalized : undefined);
  }

  return (
    <dialog
      aria-labelledby="review-confirmation-title"
      className="review-confirmation-dialog"
      onCancel={(event) => {
        if (props.pending) event.preventDefault();
        else props.onCancel();
      }}
      ref={dialogRef}
    >
      {props.document && (
        <form onSubmit={submit}>
          <div>
            <p className="eyebrow">Human attestation</p>
            <h2 id="review-confirmation-title">Attest this exact version</h2>
            <p>
              Record that you personally reviewed the current indexed document.
              This adds audit evidence in Atlas and never edits source Markdown.
            </p>
          </div>

          <dl className="review-evidence-summary">
            <div>
              <dt>Document</dt>
              <dd>{props.document.title}</dd>
            </div>
            <div>
              <dt>Source</dt>
              <dd>
                {props.document.repository} / {props.document.path}
              </dd>
            </div>
            <div>
              <dt>Commit</dt>
              <dd>
                <code>{props.document.provenance.commit}</code>
              </dd>
            </div>
            <div>
              <dt>Blob</dt>
              <dd>
                <code>{props.document.blob}</code>
              </dd>
            </div>
          </dl>

          <label className="review-note-field">
            <span>
              Review note <small>Optional</small>
            </span>
            <textarea
              disabled={props.pending}
              maxLength={1000}
              onChange={(event) => setNote(event.target.value)}
              placeholder="Capture a decision, caveat, or follow-up for the audit trail."
              rows={3}
              value={note}
            />
          </label>

          {props.error && (
            <p className="panel-error" role="alert">
              The review was not recorded. The document may have changed; close,
              reload, and try again.
            </p>
          )}

          <footer>
            <button
              disabled={props.pending}
              onClick={props.onCancel}
              type="button"
            >
              Cancel
            </button>
            <button
              className="review-confirm-action"
              disabled={props.pending}
              type="submit"
            >
              {props.pending ? 'Recording attestation…' : 'Record human review'}
            </button>
          </footer>
        </form>
      )}
    </dialog>
  );
}
