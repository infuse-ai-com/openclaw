import { Button, IconButton, Toolbar } from './ui.js';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import type { DeskObject, DeskScene, DeskOverview, DeskCameraAction, DeskPointerInput, DeskMonitorBounds } from '@studio/spatial/desk';
import { useWorkspace } from './context.js';
import { useCompanyWork, deskItems } from './company-work.js';
import { DecisionInbox, Coverage } from './company.js';
import { ComputerView } from './computer.js';
import { workCards } from './collection.js';
import { Link } from './navigation.js';
import { ShellIcon } from './shell.js';
import { LoadingState } from './loading.js';
import { useWorkspaceArrival } from './entrance.js';
import '@studio/ui/desk.css';
import './desk.css';

const objects = [
  { id: 'monitor', name: 'Widescreen', detail: 'Your Workbench', icon: 'screen' },
  { id: 'tokens', name: 'Token meter', detail: 'Yesterday’s usage', icon: 'review' },
  { id: 'inbox', name: 'Decision tray', detail: 'Work needing you', icon: 'desk' },
  { id: 'notebook', name: 'Notebook', detail: 'Project missions', icon: 'missions' },
] as const;
const titles: Record<DeskObject, string> = { monitor: 'Workbench', tokens: 'Tokens yesterday', inbox: 'Decision inbox', notebook: 'Mission notebook', wall: 'Daily overview' };

/** React owns the controls and records; the shared scene owns only its canvas. */
export function MyDesk({ zen, toggleZen }: { zen: boolean; toggleZen(): void }) {
  const { session } = useWorkspace();
  const arrival = useWorkspaceArrival();
  const work = useCompanyWork();
  const [params, setParams] = useSearchParams();
  const key = params.get('desk');
  const selected = key && Object.hasOwn(titles, key) ? key as DeskObject : null;
  const [desktopCanvas, setDesktopCanvas] = useState<HTMLCanvasElement | null>(null);
  const [visitedMonitor, setVisitedMonitor] = useState(selected === 'monitor');
  const [failed, setFailed] = useState(false), [ready, setReady] = useState(false), [zoom, setZoom] = useState(100);
  const viewer = useRef<HTMLDivElement>(null);
  const host = useRef<HTMLDivElement>(null), scene = useRef<DeskScene | null>(null);
  const root = useRef<HTMLElement>(null), panel = useRef<HTMLDivElement>(null), heading = useRef<HTMLHeadingElement>(null);
  const desktopInput = useRef<((input: DeskPointerInput) => void) | null>(null);
  const focusRequested = useRef(false);
  const latest = useRef({ select: choose, selected, arrival });
  latest.current = { select: choose, selected, arrival };
  const currentProject = work.projects.find(p => p.project.id === session.project.id);
  const records = currentProject?.data;
  const cards = records ? workCards(records.legacy, records.native) : [];
  const needs = deskItems(work);
  const anyRead = work.projects.some(p => p.data);
  const incomplete = work.omitted > 0 || work.projects.some(p => !p.data || p.stale || p.data.coverage.length);
  const status = !work.current ? 'Last known work · connection unavailable' : work.loading ? 'Loading project work…' : incomplete ? 'Partial view · inspect project coverage' : 'Inspected records · open for project coverage';
  const needsCount = anyRead ? needs.length : null, missionCount = records ? cards.length : null;
  const overview: DeskOverview = useMemo(() => ({ decisions: needsCount, missions: missionCount, project: session.project.name, status }), [needsCount, missionCount, session.project.name, status]);

  function choose(id: DeskObject) {
    focusRequested.current = true;
    if (id === 'monitor') setVisitedMonitor(true);
    setParams(previous => { const next = new URLSearchParams(previous); next.set('desk', id); return next; });
    if (selected === id) {
      if (id === 'monitor') scene.current?.cameraAction('monitor');
      else heading.current?.focus({ preventScroll: true });
    }
  }
  function placeToolbar(bounds: DeskMonitorBounds | null) {
    if (!viewer.current || !host.current) return;
    const available = host.current.clientWidth;
    const width = Math.min(Math.max(bounds?.width ?? 680, 680), Math.max(0, available - 32));
    const center = bounds ? bounds.left + bounds.width / 2 : available / 2;
    viewer.current.style.setProperty('--desk-toolbar-left', `${Math.max(16, Math.min(center - width / 2, available - width - 16))}px`);
    viewer.current.style.setProperty('--desk-toolbar-width', `${width}px`);
    viewer.current.style.setProperty('--desk-monitor-top', `${bounds?.top ?? 220}px`);
    viewer.current.style.setProperty('--desk-monitor-left', `${bounds?.left ?? 16}px`);
    viewer.current.style.setProperty('--desk-monitor-width', `${bounds?.width ?? available - 32}px`);
    viewer.current.style.setProperty('--desk-monitor-height', `${bounds?.height ?? 300}px`);
  }
  function close() {
    const id = selected;
    setParams(previous => { const next = new URLSearchParams(previous); next.delete('desk'); return next; });
    root.current?.querySelector<HTMLButtonElement>(`[data-desk-object="${id}"]`)?.focus({ preventScroll: true });
  }
  useEffect(() => {
    let cancelled = false;
    void import('@studio/spatial/desk').then(({ createDesk }) => {
      if (cancelled || !host.current) return;
      scene.current = createDesk(host.current, {
        onSelect: id => latest.current.select(id), onFailure: () => { setFailed(true); latest.current.arrival.complete(); },
        arrival: latest.current.arrival.active, onArrivalStart: () => latest.current.arrival.ready(), onArrivalComplete: () => latest.current.arrival.complete(),
        selected: latest.current.selected, onMonitorBounds: placeToolbar, onDesktopInput: input => desktopInput.current?.(input), onCameraChange: view => setZoom(Math.round(view.zoom * 100)),
      });
      setReady(true);
    }).catch(() => { if (!cancelled) { setFailed(true); latest.current.arrival.complete(); } });
    return () => { cancelled = true; scene.current?.destroy(); scene.current = null; };
  }, []);
  useEffect(() => { if (!arrival.active) scene.current?.finishArrival(); }, [arrival.active, ready]);
  useEffect(() => { scene.current?.update({ overview, desktopCanvas }); }, [overview, desktopCanvas, ready]);
  useEffect(() => {
    scene.current?.select(selected);
    if (selected === 'monitor') { setVisitedMonitor(true); scene.current?.cameraAction('monitor'); }
    if (panel.current) panel.current.scrollTop = 0;
    if (selected && selected !== 'monitor' && focusRequested.current) {
      heading.current?.focus({ preventScroll: true });
    }
    focusRequested.current = false;
  }, [selected, ready]);
  useEffect(() => {
    const toolbar = viewer.current?.querySelector('.ws-surface-header');
    if (!toolbar) return;
    const observer = new ResizeObserver(() => {
      const height = toolbar.getBoundingClientRect().height;
      if (height) viewer.current?.style.setProperty('--desk-toolbar-height', `${height}px`);
    });
    observer.observe(toolbar);
    return () => observer.disconnect();
  }, [visitedMonitor]);
  // Remote keyboard events, including Escape, belong to the desktop itself.
  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key !== 'Escape' || !selected || zen || (event.target as Element).closest('[data-workbench-screen]')) return;
    event.preventDefault(); close();
  };
  const camera = (action: DeskCameraAction) => scene.current?.cameraAction(action);
  const refreshed = work.projects.filter(p => p.data && !p.stale).length;
  return <section ref={root} className={`ws-my-desk md-scroll${zen ? ' ws-my-desk--zen' : ''}${failed ? ' ws-my-desk--flat' : ''}`} aria-label="My desk" data-arriving={arrival.active} onKeyDown={onKeyDown}>
    <div className="md-layout" data-panel-open={!!selected && selected !== 'monitor'} data-desk-selection={selected ?? ''}>
      <div className="md-room" hidden={zen}>
        <div ref={host} className="md-world" hidden={failed} />
        {!ready && !failed && <LoadingState label="Loading your room…" overlay />}
        <p className="md-scene-fallback" role="status" hidden={!failed}>The 3D view is unavailable. Your desk objects are ready below.</p>
        <div className="md-camera-tools"><Toolbar className="md-camera-buttons" aria-label="Desk camera">
          {([['out','Zoom out','−'],['in','Zoom in','+']] as const).map(([action,label,symbol]) => <IconButton key={action} aria-label={label} disabled={!ready || failed} onClick={() => camera(action)}>{symbol}</IconButton>)}
          <output aria-label="Desk zoom">{zoom}%</output><span className="md-camera-divider" /><Button variant="quiet" className="md-reset-view" disabled={!ready || failed} onClick={() => camera('reset')}>Reset view</Button>
        </Toolbar></div>
        <div className="md-dock"><p hidden id="desk-camera-help">{selected === 'monitor' && desktopCanvas ? 'Click the desktop to work. Drag outside the monitor to look around.' : 'Drag to look around. Scroll or pinch to zoom. Choose an object.'} Arrow keys look around. Plus and minus zoom. Home resets your seat.</p>
          <Button className="md-overview-access" data-desk-object="wall" aria-pressed={selected === 'wall'} onClick={() => choose('wall')}>Daily overview</Button>
          <nav className="md-objects" aria-label="Desk objects">{objects.map(object => <button key={object.id} data-desk-object={object.id} aria-pressed={selected === object.id} onClick={() => choose(object.id)}><ShellIcon name={object.icon} /><span><strong>{object.name}</strong><small>{object.detail}</small></span></button>)}</nav>
        </div>
      </div>
      {/* Keep the same viewer mounted across desk objects and Zen, but never across a workspace owner change. */}
      <div ref={viewer} className="ws-desk-viewer" hidden={selected !== 'monitor'} inert={selected !== 'monitor'}>
        {visitedMonitor && (session.workbenchAvailable ? <ComputerView zen={zen} toggleZen={toggleZen} embedded onScreenChange={setDesktopCanvas} desktopInput={desktopInput} onClose={close} /> : <div className="ws-desk-content"><h3>Your desktop is not available yet.</h3><p>Your personal Workbench appears here when a managed desktop is available for your account.</p><Button onClick={close}>Sleep monitor</Button></div>)}
      </div>
      <div ref={panel} role="dialog" aria-modal="false" className="md-panel ws-desk-panel" hidden={!selected || selected === 'monitor'} aria-labelledby="desk-panel-title">
        <div className="md-panel-top" hidden={zen}><h2 id="desk-panel-title" ref={heading} tabIndex={-1}>{selected ? titles[selected] : 'Desk object'}</h2><IconButton aria-label="Close desk panel" onClick={close}><ShellIcon name="close" /></IconButton></div>
        {selected === 'inbox' && <DecisionInbox work={work} />}
        {selected === 'tokens' && <div className="ws-desk-content"><span className="ws-eyebrow">YESTERDAY</span><h3>Usage is not connected yet.</h3><p>Studio does not currently receive token usage for your account. The meter will show your recorded total when that source is connected.</p></div>}
        {selected === 'wall' && <div className="ws-desk-content"><p className="md-copy">{status}. Data covers inspected records; project coverage below explains any gaps.</p><div className="md-overview">
          <button onClick={() => choose('tokens')}><span>Tokens yesterday</span><strong>—</strong><small>Usage source not connected ↗</small></button>
          <button onClick={() => choose('inbox')}><span>Items needing you</span><strong>{needsCount ?? '—'}</strong><small>{refreshed} of {work.admitted} projects refreshed · Open decision tray ↗</small></button>
          <button onClick={() => choose('notebook')}><span>Missions in view</span><strong>{missionCount ?? '—'}</strong><small>{session.project.name} · Open notebook ↗</small></button>
        </div><Coverage work={work} /><Button variant="quiet" disabled={!work.current || work.refreshing} onClick={work.refresh}>{work.refreshing ? 'Refreshing…' : 'Refresh'}</Button></div>}
        {selected === 'notebook' && <div className="ws-desk-content"><span className="ws-eyebrow">{session.project.name}</span><h3>Your recorded missions.</h3>{currentProject?.loading ? <LoadingState label="Loading project missions…" size="panel" /> : !records ? <p>Project work is unavailable. Inspect coverage and refresh to try again.</p> : <><p>{cards.length} missions in view{currentProject?.stale ? ' · Last known state' : ''}.</p><div className="ws-desk-notebook">{cards.map(item => <Link key={item.path} to={item.path}><strong>{item.title}</strong><small>{item.label} ↗</small></Link>)}</div>{!cards.length && <p>No missions in the inspected records yet.</p>}</>}<Coverage work={work} /><Link className="ws-button ws-button--quiet" to="/missions">Open missions ↗</Link></div>}
      </div>
    </div>
  </section>;
}
