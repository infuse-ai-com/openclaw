import { Button } from './ui.js';
import {useState} from 'react';
import {useQuery,useInfiniteQuery} from '@tanstack/react-query';
import {parseArtifactRetainedPage,type ArtifactRetainedView} from '@studio/contracts';
import {api,projectPath,readableError} from './api.js';
import {useWorkspace} from './context.js';
function description(r:ArtifactRetainedView):string {
 if(r.kind==='audit')return 'Backoffice recorded '+r.action;
 if(r.kind==='lifecycle')return 'Backoffice lifecycle snapshot: '+r.state;
 return r.state==='succeeded'?'Backoffice reported a completed purge job':'Retained '+r.state+' purge job · review required; no execution imported';
}
export function ArtifactRetainedHistory(){
 const {owner,session,current,visible}=useWorkspace(),[open,setOpen]=useState(false),base=projectPath('/api/studio/artifact-lifecycle',session.project.id);
 const access=useQuery({queryKey:['workspace',owner,'artifact-retained-access'],enabled:current,queryFn:async({signal})=>{const v=await api(base+'/access',{signal}) as {canReadRetained:boolean};if(!v||typeof v.canReadRetained!=='boolean')throw Error('Invalid artifact history admission');return v;},gcTime:0,retry:false,refetchOnWindowFocus:visible});
 const enabled=current&&!access.isError&&access.data?.canReadRetained===true;
 const query=useInfiniteQuery({queryKey:['workspace',owner,'artifact-retained'],enabled:enabled&&open,initialPageParam:undefined as number|undefined,queryFn:async({signal,pageParam})=>{const p=parseArtifactRetainedPage(await api(base+'/retained'+(pageParam===undefined?'':'?before='+pageParam),{signal}));if(p.records.some(r=>r.projectId!==session.project.id)||p.nextCursor!==null&&p.nextCursor>=(pageParam??Number.MAX_SAFE_INTEGER))throw Error('Retained artifact history scope or cursor changed');return p;},getNextPageParam:p=>p.nextCursor??undefined,gcTime:0,retry:false,refetchOnWindowFocus:visible});
 if(!enabled)return null;
 const records=query.data?.pages.flatMap(p=>p.records)??[];
 return <details className="ws-record ws-artifact-retained" onToggle={e=>setOpen(e.currentTarget.open)}><summary>Retained Backoffice artifact history</summary>{open&&(query.isError?<p className="ws-alert" role="alert">Retained history is unavailable. Previous records are hidden. {readableError(query.error)}</p>:query.isPending?<p>Loading retained artifact history…</p>:<><p>Historical source assertions, in import order. These records authorize no deletion and do not establish the current Registry state. Unmapped records remain withheld.</p>{!records.length?<p>No retained rows are admitted to this floor.</p>:records.map(r=><article className="ws-record" key={`${r.sourceId}/${r.kind}/${r.recordId}`}><h3>{r.producer}/{r.artifactId}</h3><p>{description(r)}</p><dl><div><dt>Original source time</dt><dd><time>{r.at}</time></dd></div><div><dt>Recorded {r.revision?.startsWith('sha256:')?'feed':'Registry'} revision</dt><dd><code>{r.revision??'Unknown'}</code></dd></div><div><dt>Source record</dt><dd>{r.sourceId} · {r.kind} · {r.recordId}</dd></div><div><dt>Imported into Studio</dt><dd>{r.importedAt}</dd></div>{r.kind==='purge-job'&&<div><dt>Recorded attempts</dt><dd>{r.attempts}</dd></div>}{r.actorHash&&<div><dt>Source actor hash</dt><dd><code>{r.actorHash}</code></dd></div>}{r.hadError&&<div><dt>Source error</dt><dd>Backoffice recorded an error; private error text was omitted.</dd></div>}</dl></article>)}{query.hasNextPage&&<Button variant="quiet" disabled={query.isFetching} onClick={()=>void query.fetchNextPage()}>Load more retained artifact history</Button>}</>)}<Button variant="quiet" disabled={!current||access.isFetching||query.isFetching} onClick={()=>{void access.refetch();if(open)void query.refetch();}}>Refresh retained artifact history</Button></details>;
}
