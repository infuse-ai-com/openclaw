import { Button } from './ui.js';
import { useQuery } from '@tanstack/react-query';
import { floorSetupSnapshot, type FloorSetupCheck } from '@studio/contracts';
import { api } from './api.js';
import { LoadingState } from './loading.js';
import { FloorIcon } from './floor-fields.js';
const labels: Record<FloorSetupCheck['state'], string> = { verified: 'Verified', pending: 'Pending', blocked: 'Needs attention', unconfigured: 'Not configured', unverified: 'Not verified' };
export function FloorSetup({ floorId, owner, enabled }: { floorId: string; owner: unknown; enabled: boolean }) {
  const query = useQuery({ queryKey: ['workspace', owner, 'floor-setup', floorId], enabled,
    queryFn: async ({signal}) => floorSetupSnapshot.parse(await api(`/api/studio/floors/${encodeURIComponent(floorId)}/setup`, {signal})),
    staleTime: 30000, refetchInterval: 60000, retry: false });
  if (query.isPending) return <LoadingState label="Checking floor setup…" size="panel" />;
  if (query.isError) return <div role="alert"><h3>Setup could not be checked</h3><p>Refresh to check the current floor setup.</p><Button variant="quiet" type="button"  onClick={() => void query.refetch()}><FloorIcon name="refresh" />Try again</Button></div>;
  const checks = query.data.checks, verified = checks.filter(check => check.state === 'verified').length;
  return <section className="fd-setup" aria-label="Setup status">
    <div className="fd-section-heading"><div><h3>Setup status</h3><p>{verified} of {checks.length} checks verified · Each service is checked separately.</p></div>
      <Button variant="quiet" type="button"  disabled={query.isFetching} onClick={() => void query.refetch()}><FloorIcon name="refresh" />{query.isFetching ? 'Checking…' : 'Refresh'}</Button></div>
    <p className="fd-setup-note">Checks use saved floor settings. Viewing this page does not create infrastructure.</p>
    <ul className="fd-setup-list">{checks.map(check => <li key={check.id} data-state={check.state}>
      <span className="fd-setup-indicator" aria-hidden="true">{check.state === 'verified' ? '✓' : check.state === 'blocked' ? '!' : '·'}</span>
      <div className="fd-setup-body"><div className="fd-setup-title"><h4>{check.label}<span className="fd-setup-target">{check.target}</span></h4><span className="fd-setup-state">{labels[check.state]}</span></div>
        <p>{check.detail}</p>
        <div className="fd-setup-meta">{check.checkedAt ? <span>Checked <time dateTime={check.checkedAt}>{new Date(check.checkedAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</time></span> : <span>Awaiting configuration</span>}
          {check.href && <a href={check.href} {...(check.href.startsWith('https://') ? {target:'_blank',rel:'noreferrer'} : {})}>Open {check.id === 'grafana' ? 'Grafana' : check.id.startsWith('knowledge:') ? 'Knowledge' : 'project'} ↗</a>}</div>
      </div></li>)}</ul>
  </section>;
}
