import { contributionSummary, type ContributionsView } from '@studio/contracts';
const format = (n: number) => new Intl.NumberFormat('en').format(n);
const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export function ContributionSummary({ data, repositories }: { data: ContributionsView; repositories: number }) {
  const { longestStreak: streak, busiestWeekdays: busiest, weekdayCommits } = contributionSummary(data.year, data.days);
  return <section aria-label="Contribution summary">
    <div className="ws-contrib-summary">
      <div><strong>{format(data.total)}</strong><span>Commits in {data.year}</span></div>
      <div><strong>{data.days.filter(day => day.count > 0).length}</strong><span>Active days · UTC</span></div>
      <div><strong>{repositories}</strong><span>Repositories in these filters</span></div>
      <div role="group" aria-label="Longest streak"><strong>{streak.days} {streak.days === 1 ? 'day' : 'days'}</strong><span>Longest streak · UTC</span><small>{streak.start ? `${streak.start} – ${streak.end}` : 'No recorded activity'}</small></div>
    </div>
    <div className="ws-contrib-rhythm"><div role="group" aria-label="Busiest weekday"><strong className="ws-contrib-weekday">{busiest.length === 7 ? 'All weekdays' : busiest.length ? busiest.map(day => weekdays[day]).join(', ') : '—'}</strong><span>Busiest weekday · UTC{busiest.length > 1 ? ' · tied' : ''}</span><small>{weekdayCommits ? `${format(weekdayCommits)} recorded ${weekdayCommits === 1 ? 'commit' : 'commits'}${busiest.length > 1 ? ' each' : ''}` : 'No recorded activity'}</small></div></div>
    <p className="ws-contrib-summary-note">Collected history in {data.year} and the selected filters. Streaks count consecutive UTC days; the earliest longest run is shown. Busiest weekdays total recorded commits. Coverage gaps may change these summaries.</p>
  </section>;
}
