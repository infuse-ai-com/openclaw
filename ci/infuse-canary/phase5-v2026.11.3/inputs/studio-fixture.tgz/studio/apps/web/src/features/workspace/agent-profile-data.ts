import type { AgentTelemetry, TelemetrySource, ModelObservation, RuntimeObservation } from '@studio/contracts';

/** An ambiguous set of sources cannot silently become one authoritative observation. */
export function singleAgentSource(value: AgentTelemetry | undefined, kind: TelemetrySource['kind']) {
  const sources = value?.sources.filter(source => source.kind === kind) ?? [];
  return sources.length === 1 ? sources[0] : undefined;
}
export function agentProfileEvidence(value: AgentTelemetry | undefined) {
  const runtime = singleAgentSource(value, 'runtime'), model = singleAgentSource(value, 'model');
  const observedRuntime = runtime?.data as RuntimeObservation | undefined;
  const observedModel = model?.data as ModelObservation | undefined;
  return {
    harness: observedModel?.observed.runtime,
    version: observedRuntime?.version,
    runtimeState: runtime?.state ?? 'unknown', modelState: model?.state ?? 'unknown',
    model: model?.state === 'fresh' ? observedModel?.observed.model : undefined,
    reasoning: model?.state === 'fresh' ? observedModel?.observed.reasoningDefault ?? observedModel?.observed.thinkingDefault : undefined,
  };
}
/** Exactly seven UTC days ending at the read, with missing days left null, not zero. */
export function agentUsageDays(value: AgentTelemetry | undefined) {
  const source = singleAgentSource(value, 'usage');
  if (!value || !source?.usage || !source.usage.buckets.length) return [];
  const end = Date.parse(value.readAt.slice(0, 10) + 'T00:00:00.000Z');
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(end - (6 - index) * 86400000).toISOString().slice(0, 10);
    const buckets = source.usage!.buckets.filter(bucket => bucket.start.slice(0, 10) === date);
    return { date, total: buckets.length ? buckets.reduce((sum, bucket) => sum + bucket.totalTokens, 0) : null };
  });
}
