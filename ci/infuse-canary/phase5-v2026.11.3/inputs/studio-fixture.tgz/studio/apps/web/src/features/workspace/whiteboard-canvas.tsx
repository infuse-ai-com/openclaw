import {
  type WhiteboardSection,
  type WhiteboardBlock,
  type WhiteboardStroke,
} from '@studio/contracts';
import { Background, ReactFlow, applyNodeChanges, type ReactFlowInstance } from '@xyflow/react';
import { LoadingState } from './loading.js';
import { type AlignmentGuide } from './whiteboard-alignment.js';
import { DrawingLayer, EraserLayer } from './whiteboard-drawing.js';
import { geometryUpdate } from './whiteboard-geometry.js';
import { ImageUploads, useWhiteboardImages } from './whiteboard-images.js';
import { nodeTypes } from './whiteboard-nodes.js';
import { useBoardPresence } from './whiteboard-presence.js';
import { useWhiteboardSectionZoom } from './whiteboard-section-navigation.js';
import { useSectionTransition } from './whiteboard-section-transition.js';
import { whiteboardMaxZoom, type BoardCamera } from './whiteboard-section-zoom.js';
import { ShapeLayer } from './whiteboard-shape-tools.js';
import { type ShapeKind } from './whiteboard-shapes.js';
import { useSpatialBoard } from './whiteboard-spatial.js';
import type { BlockNode, BoardPanel, BoardTool, CanvasItem } from './whiteboard-types.js';

import type * as React from 'react';
import type { Commit } from './whiteboard-types.js';

type Props = {
  openSelectionMenu: (event: React.MouseEvent<HTMLDivElement>) => void;
  guardLockedGesture: (
    event: React.PointerEvent<HTMLDivElement> | React.KeyboardEvent<HTMLDivElement>,
  ) => void;
  pastePoint: React.RefObject<{ x: number; y: number } | null>;
  preparingRef: React.RefObject<boolean>;
  setLockPrompt: React.Dispatch<
    React.SetStateAction<{ x: number; y: number; ids: string[] } | null>
  >;
  setSelectionMenu: React.Dispatch<
    React.SetStateAction<{ x: number; y: number; ids: string[] } | null>
  >;
  selectedIds: string[];
  showLockPrompt: (ids: string[], point?: { x: number; y: number }) => void;
  dropTarget: string | null;
  dropReady: string | null;
  setDropTarget: React.Dispatch<React.SetStateAction<string | null>>;
  setDropReady: React.Dispatch<React.SetStateAction<string | null>>;
  dragDestination: (event: MouseEvent | TouchEvent, moved: BlockNode[]) => string | null;
  moveToSection: (destination: string, ids?: string[]) => Promise<void>;

  canvas: React.RefObject<HTMLDivElement | null>;
  tool: BoardTool;
  images: ReturnType<typeof useWhiteboardImages>;
  flow: React.RefObject<ReactFlowInstance<BlockNode> | null>;
  presence: ReturnType<typeof useBoardPresence>;
  zoomNavigation: ReturnType<typeof useWhiteboardSectionZoom>;
  sectionId: string;
  nodes: BlockNode[];
  edges: { id: string; source: string; target: string; label: string }[];
  enabled: boolean;
  setAutoFocusId: React.Dispatch<React.SetStateAction<string | null>>;
  create: (kind: WhiteboardBlock['kind'], placed?: { x: number; y: number }) => Promise<void>;
  setPanel: React.Dispatch<React.SetStateAction<BoardPanel>>;
  setFocused: React.Dispatch<React.SetStateAction<CanvasItem | null>>;
  selectNext: React.RefObject<string[]>;
  setNodes: React.Dispatch<React.SetStateAction<BlockNode[]>>;
  interacting: React.RefObject<boolean>;
  commit: Commit;
  transition: ReturnType<typeof useSectionTransition>;
  setFollowing: React.Dispatch<React.SetStateAction<string | null>>;
  setTarget: React.Dispatch<React.SetStateAction<string>>;
  commentsOpen: boolean;
  openPanel: (next: BoardPanel) => void;
  setAlignmentGuides: React.Dispatch<React.SetStateAction<AlignmentGuide[]>>;
  alignDrag: (
    event: MouseEvent | TouchEvent,
    node: BlockNode,
    moved: BlockNode[],
    finished?: boolean,
  ) => void;
  penColor: WhiteboardStroke['color'];
  penWidth: number;
  setMessage: (message: string) => void;
  shapeKind: ShapeKind;
  saveShape: (stroke: Omit<WhiteboardStroke, 'revision'>) => Promise<void>;
  setTool: React.Dispatch<React.SetStateAction<BoardTool>>;
  hasDraft: boolean;
  blocks: CanvasItem[];
  alignmentGuides: AlignmentGuide[];
  viewport: BoardCamera;
  board: Pick<ReturnType<typeof useSpatialBoard>, 'data' | 'isPending' | 'isError'>;
  current: boolean;
};
export function WhiteboardCanvas({
  openSelectionMenu,
  guardLockedGesture,
  pastePoint,
  preparingRef,
  setLockPrompt,
  setSelectionMenu,
  selectedIds,
  showLockPrompt,
  dropTarget,
  dropReady,
  setDropTarget,
  setDropReady,
  dragDestination,
  moveToSection,
  canvas,
  tool,
  images,
  flow,
  presence,
  zoomNavigation,
  sectionId,
  nodes,
  edges,
  enabled,
  setAutoFocusId,
  create,
  setPanel,
  setFocused,
  selectNext,
  setNodes,
  interacting,
  commit,
  transition,
  setFollowing,
  setTarget,
  commentsOpen,
  openPanel,
  setAlignmentGuides,
  alignDrag,
  penColor,
  penWidth,
  setMessage,
  shapeKind,
  saveShape,
  setTool,
  hasDraft,
  blocks,
  alignmentGuides,
  viewport,
  board,
  current,
}: Props) {
  return (
    <>
      <div
        ref={canvas}
        tabIndex={-1}
        className={'wboard-canvas wboard-canvas--' + tool}
        aria-label="Project whiteboard canvas"
        onContextMenuCapture={openSelectionMenu}
        onPointerDownCapture={guardLockedGesture}
        onKeyDownCapture={guardLockedGesture}
        onDragOver={images.dragOver}
        onDragLeave={images.dragLeave}
        onDrop={images.drop}
        onPointerMove={(event) => {
          const pointer = flow.current?.screenToFlowPosition({
            x: event.clientX,
            y: event.clientY,
          });
          if (pointer) {
            pastePoint.current = pointer;
            presence.update({ pointer });
          }
        }}
        onPointerLeave={() => {
          pastePoint.current = null;
          presence.update({ pointer: null });
        }}
        onWheelCapture={(event) => {
          // At the zoom floor React Flow emits no move gesture.
          if (event.target instanceof Element && event.target.closest('.nowheel')) return;
          const camera = flow.current?.getViewport();
          if (event.deltaY > 0 && camera && camera.zoom <= 0.10001)
            zoomNavigation.navigate(sectionId, camera, 'out', event.nativeEvent);
        }}
      >
        <ReactFlow<BlockNode>
          proOptions={{ hideAttribution: true }}
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onInit={(instance) => {
            flow.current = instance;
          }}
          nodesDraggable={enabled && tool === 'select'}
          nodesConnectable={enabled && tool === 'select'}
          edgesReconnectable={false}
          deleteKeyCode={null}
          multiSelectionKeyCode="Shift"
          panOnDrag={tool === 'hand' ? true : [1, 2]}
          selectionOnDrag={tool === 'select'}
          onMoveStart={zoomNavigation.onMoveStart}
          onMove={zoomNavigation.onMove}
          onMoveEnd={zoomNavigation.onMoveEnd}
          onPaneClick={(event) => {
            setLockPrompt(null);
            setSelectionMenu(null);
            setAutoFocusId(null);
            if (tool === 'note' && enabled) {
              const position = flow.current?.screenToFlowPosition({
                x: event.clientX,
                y: event.clientY,
              });
              if (position) void create('note', position);
            } else {
              setPanel(null);
              setFocused(null);
            }
          }}
          minZoom={0.1}
          maxZoom={whiteboardMaxZoom}
          defaultViewport={{ x: 40, y: 40, zoom: 1 }}
          zoomOnDoubleClick={false}
          onNodesChange={(changes) => {
            if (changes.some((change) => change.type === 'select')) selectNext.current = [];
            setNodes((previous) => applyNodeChanges(changes, previous));
            // React Flow's keyboard moves emit final position changes without drag callbacks.
            if (!interacting.current && !preparingRef.current) {
              const moves = changes.flatMap((change) => {
                if (change.type !== 'position' || change.dragging !== false || !change.position)
                  return [];
                const source = nodes.find((node) => node.id === change.id)?.data.block;
                return source ? [geometryUpdate(source, change.position)] : [];
              });
              if (moves.length) void commit(moves);
            }
          }}
          onNodeClick={(_event, node) => {
            if (transition.active) return;
            if (tool === 'select' && _event.shiftKey)
              setNodes((previous) =>
                previous.map((n) => ({
                  ...n,
                  selected:
                    n.id === node.id ? !selectedIds.includes(node.id) : selectedIds.includes(n.id),
                })),
              );
            if (tool === 'select' && node.data.block.locked) {
              showLockPrompt([node.id]);
              return;
            }
            if (
              tool === 'hand' &&
              (node.data.block.kind === 'note' || node.data.block.kind === 'document')
            ) {
              setFollowing(null);
              setFocused(node.data.block);
              setAutoFocusId(node.id);
              setTarget('');
              setPanel(null);
            } else if (tool === 'select') {
              setAutoFocusId(null);
              setFocused(node.data.block);
              setTarget('');
              if (
                node.data.block.kind === 'note' ||
                node.data.block.kind === 'html' ||
                node.data.block.kind === 'image' ||
                node.data.block.kind === 'document'
              )
                setPanel((value) => (value === 'comments' ? 'comments' : null));
              else openPanel('editor');
            }
          }}
          onNodeDoubleClick={(_event, node) => {
            if (
              tool === 'select' &&
              (node.data.block.kind === 'note' ||
                node.data.block.kind === 'document' ||
                (node.data.block.kind === 'stroke' && !!node.data.block.shape))
            ) {
              setFocused(node.data.block);
              setAutoFocusId(node.id);
              setPanel(null);
            }
          }}
          onNodeDragStart={() => {
            setAutoFocusId(null);
            setDropTarget(null);
            setDropReady(null);
            interacting.current = true;
            setFollowing(null);
            setAlignmentGuides([]);
          }}
          onNodeDrag={(event, node, moved) => {
            alignDrag(event, node, moved);
            setDropTarget(dragDestination(event, moved));
          }}
          onNodeDragStop={(event, node, moved) => {
            const destination = dragDestination(event, moved);
            setDropTarget(null);
            setDropReady(null);
            if (destination && destination === dropReady) {
              interacting.current = false;
              setAlignmentGuides([]);
              void moveToSection(
                destination,
                moved.map((n) => n.id),
              );
            } else alignDrag(event, node, moved, true);
          }}
          onConnect={(connection) => {
            if (connection.source && connection.target)
              void commit([
                {
                  type: 'connect',
                  connection: {
                    id: crypto.randomUUID(),
                    kind: 'connection',
                    source: connection.source,
                    target: connection.target,
                    label: '',
                  },
                },
              ]);
          }}
          onlyRenderVisibleElements={false}
        >
          <Background gap={10} size={0.8} />
          {tool === 'draw' && (
            <DrawingLayer
              enabled={enabled}
              color={penColor}
              thickness={penWidth}
              notify={setMessage}
              save={(stroke) => {
                void commit([{ type: 'draw', stroke }]);
              }}
            />
          )}
          {tool === 'shape' && (
            <ShapeLayer
              kind={shapeKind}
              enabled={enabled}
              color={penColor}
              thickness={penWidth}
              save={(stroke) => void saveShape(stroke)}
              notify={setMessage}
              exit={() => {
                setTool('select');
                canvas.current?.focus();
              }}
            />
          )}
          {tool === 'erase' && (
            <EraserLayer
              enabled={enabled && !hasDraft}
              strokes={blocks.filter(
                (b): b is WhiteboardStroke => b.kind === 'stroke' && !b.locked,
              )}
              notify={setMessage}
              erase={(strokes) => {
                const ids = new Set(strokes.map((stroke) => stroke.id));
                const links = (board.data?.items ?? []).filter(
                  (item) =>
                    item.kind === 'connection' && (ids.has(item.source) || ids.has(item.target)),
                );
                if (links.length + strokes.length > 30) {
                  setMessage(
                    'Erase fewer shapes at once. Their attached connections are included.',
                  );
                  return;
                }
                void commit(
                  [...links, ...strokes].map((item) => ({
                    type: 'delete',
                    id: item.id,
                    expectedRevision: item.revision,
                  })),
                );
              }}
            />
          )}
        </ReactFlow>
        {dropTarget && (
          <div className="wboard-drop-hint wboard-float" role="status">
            {dropReady === dropTarget ? 'Release to move into ' : 'Hold here to move into '}
            {blocks.find((b) => b.id === dropTarget && b.kind === 'section')?.kind === 'section'
              ? (blocks.find((b) => b.id === dropTarget) as WhiteboardSection).title
              : 'section'}
          </div>
        )}
        {alignmentGuides.length > 0 && (
          <svg className="wboard-alignment-guides" aria-hidden="true">
            {alignmentGuides.map((guide) => {
              const position =
                guide.position * viewport.zoom + (guide.axis === 'x' ? viewport.x : viewport.y);
              const start =
                  guide.start * viewport.zoom + (guide.axis === 'x' ? viewport.y : viewport.x),
                end = guide.end * viewport.zoom + (guide.axis === 'x' ? viewport.y : viewport.x);
              return (
                <line
                  key={guide.axis}
                  data-axis={guide.axis}
                  x1={guide.axis === 'x' ? position : start}
                  y1={guide.axis === 'x' ? start : position}
                  x2={guide.axis === 'x' ? position : end}
                  y2={guide.axis === 'x' ? end : position}
                />
              );
            })}
          </svg>
        )}
        <span className="wboard-sr-only" role="status">
          {alignmentGuides.map((guide) => guide.label).join(' ')}
        </span>
        <ImageUploads images={images} viewport={viewport} sectionId={sectionId} enabled={enabled} />
        <div className="wboard-presence-layer" aria-hidden="true">
          {presence.peers
            .filter((peer) => (peer.state.sectionId ?? 'root') === sectionId)
            .map((peer) => (
              <div key={peer.connectionId}>
                {peer.state.pointer && (
                  <div
                    className="wboard-peer-pointer"
                    style={{
                      color: peer.color,
                      transform: `translate(${peer.state.pointer.x * viewport.zoom + viewport.x}px,${peer.state.pointer.y * viewport.zoom + viewport.y}px)`,
                    }}
                  >
                    ↖ <span style={{ background: peer.color }}>{peer.name}</span>
                  </div>
                )}
                {peer.state.drag && (
                  <div
                    className="wboard-peer-drag"
                    style={{
                      borderColor: peer.color,
                      left: peer.state.drag.x * viewport.zoom + viewport.x,
                      top: peer.state.drag.y * viewport.zoom + viewport.y,
                      width: peer.state.drag.width * viewport.zoom,
                      height: peer.state.drag.height * viewport.zoom,
                    }}
                  />
                )}
              </div>
            ))}
        </div>
        {board.isPending && current && (
          <LoadingState label="Loading whiteboard…" size="page" overlay />
        )}
        {!blocks.length && !!board.data && !board.isError && (
          <div className="wboard-empty">
            <h2>A place to think together</h2>
            <p>Add a note or document to begin your project board.</p>
          </div>
        )}
      </div>
    </>
  );
}
