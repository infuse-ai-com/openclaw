import { Button } from './ui.js';
import {
  whiteboardSpatialOperation,
  type WhiteboardSummary,
  type WhiteboardSpatialOperation,
} from '@studio/contracts';
export const arrangeLabels = {
  left: 'Align left',
  center: 'Align horizontal centers',
  right: 'Align right',
  top: 'Align top',
  middle: 'Align vertical centers',
  bottom: 'Align bottom',
  horizontal: 'Distribute horizontally',
  vertical: 'Distribute vertically',
  width: 'Same width',
  height: 'Same height',
  size: 'Same size',
} as const;
export type ArrangeAction = keyof typeof arrangeLabels;
/** One bounded revision-guarded batch; the writer owns atomicity and undo. */
export function arrangeSelection(
  items: WhiteboardSummary[],
  ids: string[],
  action: ArrangeAction,
): WhiteboardSpatialOperation[] {
  const selected = ids
    .map((id) => items.find((item) => item.id === id))
    .filter(
      (item): item is Exclude<WhiteboardSummary, { kind: 'connection' }> =>
        !!item && item.kind !== 'connection',
    );
  if (
    selected.length !== ids.length ||
    new Set(ids).size !== ids.length ||
    ids.length < 2 ||
    ids.length > 30
  )
    throw Error('Choose between 2 and 30 elements to arrange.');
  if (selected.some((item) => item.locked))
    throw Error('Unlock the selection before arranging it.');
  if (new Set(selected.map((item) => item.sectionId)).size !== 1)
    throw Error('Arrange elements in the same section.');
  const left = Math.min(...selected.map((b) => b.x)),
    top = Math.min(...selected.map((b) => b.y)),
    right = Math.max(...selected.map((b) => b.x + b.width)),
    bottom = Math.max(...selected.map((b) => b.y + b.height));
  const width = Math.max(...selected.map((b) => b.width)),
    height = Math.max(...selected.map((b) => b.height));
  const positions = new Map<string, number>();
  if (action === 'horizontal' || action === 'vertical') {
    if (selected.length < 3) throw Error('Choose at least 3 elements to distribute.');
    const axis = action === 'horizontal' ? 'x' : 'y',
      size = axis === 'x' ? 'width' : 'height';
    const sorted = [...selected].sort((a, b) => a[axis] - b[axis] || a.id.localeCompare(b.id));
    const first = sorted[0]!,
      last = sorted.at(-1)!;
    const gap =
      (last[axis] + last[size] - first[axis] - sorted.reduce((sum, item) => sum + item[size], 0)) /
      (sorted.length - 1);
    let position = first[axis];
    for (const item of sorted) {
      positions.set(item.id, position);
      position += item[size] + gap;
    }
  }
  return selected.flatMap((item) => {
    const patch: Record<string, number> = {};
    switch (action) {
      case 'left':
        patch.x = left;
        break;
      case 'center':
        patch.x = (left + right - item.width) / 2;
        break;
      case 'right':
        patch.x = right - item.width;
        break;
      case 'top':
        patch.y = top;
        break;
      case 'middle':
        patch.y = (top + bottom - item.height) / 2;
        break;
      case 'bottom':
        patch.y = bottom - item.height;
        break;
      case 'horizontal':
        patch.x = positions.get(item.id)!;
        break;
      case 'vertical':
        patch.y = positions.get(item.id)!;
        break;
      case 'width':
        patch.width = width;
        break;
      case 'height':
        patch.height = height;
        break;
      case 'size':
        patch.width = width;
        patch.height = height;
    }
    for (const key of Object.keys(patch))
      if (patch[key] === Reflect.get(item, key)) delete patch[key];
    if (!Object.keys(patch).length) return [];
    return [
      whiteboardSpatialOperation.parse({
        type:
          item.kind === 'stroke'
            ? 'updateStroke'
            : item.kind === 'note' || item.kind === 'document'
              ? 'update'
              : 'updateTile',
        id: item.id,
        expectedRevision: item.revision,
        patch,
      }),
    ];
  });
}
export function ArrangeActions({
  count,
  disabled,
  run,
}: {
  count: number;
  disabled: boolean;
  run(action: ArrangeAction): void;
}) {
  return (
    <div className="wboard-arrange">
      <p>Arrange {count} selected elements. Matching sizes uses the largest selected dimensions.</p>
      {(
        [
          'left',
          'center',
          'right',
          'top',
          'middle',
          'bottom',
          'horizontal',
          'vertical',
          'width',
          'height',
          'size',
        ] as ArrangeAction[]
      ).map((action) => (
        <Button variant="quiet"
          type="button"
          key={action}
          disabled={
            disabled ||
            count < 2 ||
            ((action === 'horizontal' || action === 'vertical') && count < 3)
          }
          onClick={() => run(action)}
        >
          {arrangeLabels[action]}
        </Button>
      ))}
    </div>
  );
}
