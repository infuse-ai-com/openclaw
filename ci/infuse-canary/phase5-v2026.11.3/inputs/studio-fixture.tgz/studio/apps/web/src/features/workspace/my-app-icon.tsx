import { appIcons, appActionIcons } from '@studio/ui/app-icons';
import type { AppAccent } from '@studio/contracts';

export function MyAppIcon({ name, accent }: { name: string; accent?: AppAccent }) {
  // Only reviewed bundled SVG is rendered; the API supplies a lookup key, never markup.
  // Older/newer catalog keys retain a graphical fallback during rolling versions.
  const svg = (Object.hasOwn(appIcons, name) ? appIcons[name] : undefined) ?? appIcons.apps;
  return <span className="apps-icon" data-accent={accent ?? 'slate'} aria-hidden="true"
    dangerouslySetInnerHTML={{ __html: svg }} />;
}

export function MyAppActionIcon({ name }: { name: keyof typeof appActionIcons }) {
  return <span className="apps-action-icon" aria-hidden="true"
    dangerouslySetInnerHTML={{ __html: appActionIcons[name] }} />;
}
