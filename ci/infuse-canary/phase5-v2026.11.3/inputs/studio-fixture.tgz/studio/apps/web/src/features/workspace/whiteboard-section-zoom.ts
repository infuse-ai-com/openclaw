import type { WhiteboardSection } from '@studio/contracts';

export type BoardCamera={x:number;y:number;zoom:number};
export const whiteboardMaxZoom=8;
/** A pointed-at section becomes a destination once it dominates the visible view. */
export function sectionZoomTarget(sections:WhiteboardSection[],camera:BoardCamera,size:{width:number;height:number},point:{x:number;y:number},hitId?:string) {
  if(camera.zoom<1.25||size.width<=0||size.height<=0||point.x<0||point.y<0||point.x>size.width||point.y>size.height)return;
  const candidates=sections.filter(section=>{
    if(hitId&&section.id!==hitId)return false;
    const x=section.x*camera.zoom+camera.x,y=section.y*camera.zoom+camera.y;
    const width=section.width*camera.zoom,height=section.height*camera.zoom;
    const visibleWidth=Math.max(0,Math.min(size.width,x+width)-Math.max(0,x));
    const visibleHeight=Math.max(0,Math.min(size.height,y+height)-Math.max(0,y));
    return point.x>=x&&point.x<=x+width&&point.y>=y&&point.y<=y+height
      && Math.max(width/size.width,height/size.height)>=.7
      && visibleWidth*visibleHeight/(size.width*size.height)>=.2;
  });
  // Overlapping sections without an unambiguous pointer target need explicit entry.
  return candidates.length===1?candidates[0]:undefined;
}

/** Leave only beyond the section overview, with a reachable floor for very large boards. */
export function sectionZoomExitThreshold(blocks:{x:number;y:number;width:number;height:number}[],size:{width:number;height:number}) {
  if(!blocks.length)return .4;
  const width=Math.max(...blocks.map(b=>b.x+b.width))-Math.min(...blocks.map(b=>b.x));
  const height=Math.max(...blocks.map(b=>b.y+b.height))-Math.min(...blocks.map(b=>b.y));
  const overview=Math.min(1,Math.max(180,size.width-80)/(width+40),Math.max(160,size.height-320)/(height+40));
  return Math.max(.1,Math.min(.4,overview*.55));
}

/** Keep the same canvas point beneath the pointer while changing coordinate systems. */
export function zoomCameraAt(camera:BoardCamera,point:{x:number;y:number},zoom:number):BoardCamera {
  const ratio=zoom/camera.zoom;
  return {x:point.x-(point.x-camera.x)*ratio,y:point.y-(point.y-camera.y)*ratio,zoom};
}
/** Screen-space transform mapping one view of the same content onto another. */
export function cameraTransform(from:BoardCamera,to:BoardCamera) {
  const scale=to.zoom/from.zoom;
  return {x:to.x-from.x*scale,y:to.y-from.y*scale,scale};
}

/** A zoom-out handoff must not enlarge content merely to restore an old, close parent view. */
export function sectionReturnCamera(parent:BoardCamera,preview:BoardCamera,child:BoardCamera,size:{width:number;height:number}) {
  return zoomCameraAt(parent,{x:size.width/2,y:size.height/2},Math.max(.1,Math.min(parent.zoom,parent.zoom*child.zoom*.85/preview.zoom)));
}
export function transformCamera(camera:BoardCamera,from:BoardCamera,to:BoardCamera):BoardCamera {
  const delta=cameraTransform(from,to);
  return {x:camera.x*delta.scale+delta.x,y:camera.y*delta.scale+delta.y,zoom:camera.zoom*delta.scale};
}
