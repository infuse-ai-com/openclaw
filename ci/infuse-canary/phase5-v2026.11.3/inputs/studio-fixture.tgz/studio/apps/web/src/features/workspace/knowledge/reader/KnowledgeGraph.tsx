import type { GraphNode, KnowledgeGraph } from '@studio/contracts/knowledge';
import { useMemo, useState } from 'react';
import { GraphInspector } from './components/GraphInspector';
import { GraphCanvasView } from './GraphCanvasView';
import type { FilterPreview } from './graphFilters';
import {
  changeFilter,
  emptyFilters,
  filterPreviewIds,
  graphCounts,
  graphDegrees,
  neighborIds,
  projectGraph,
} from './graphFilters';
import type { GraphEntryOrigin } from './graphLayout';
import { clusterColor } from './graphLayout';
import { useGraphInteraction } from './useGraphInteraction';
import { useGraphSimulation } from './useGraphSimulation';
import { useSemanticNeighborhood } from './useSemanticNeighborhood';

interface KnowledgeGraphProps {
  centerFocusOnMount?: boolean;
  graph: KnowledgeGraph;
  inactive?: boolean;
  focusId?: string;
  initialScope?: 'global' | 'local';
  onClose: () => void;
  onEnter: (node: GraphNode, origin: GraphEntryOrigin) => void;
  onOpen: (node: GraphNode) => void;
}

export function KnowledgeGraphCanvas({
  centerFocusOnMount = false,
  graph,
  inactive,
  focusId,
  initialScope = 'global',
  onClose,
  onEnter,
  onOpen,
}: KnowledgeGraphProps) {
  const [scope, setScope] = useState<'global' | 'local'>(initialScope);
  const [hiddenFilters, setHiddenFilters] = useState(emptyFilters);
  const [filterPreview, setFilterPreview] = useState<FilterPreview>();
  const { counts, repositories, repositoryInsights } = useMemo(
    () => graphCounts(graph.nodes),
    [graph.nodes],
  );
  const clusterColors = useMemo(
    () => new Map(graph.clusters.map((cluster, index) => [cluster.id, clusterColor(index)])),
    [graph.clusters],
  );
  const { nodes: visibleGraphNodes, edges: visibleEdges } = useMemo(
    () => projectGraph(graph, hiddenFilters, scope, focusId),
    [graph.nodes, graph.edges, hiddenFilters, scope, focusId],
  );
  const degree = useMemo(() => graphDegrees(graph.edges), [graph.edges]);
  const simulation = useGraphSimulation(graph.clusters, visibleGraphNodes, visibleEdges, degree);
  const { layoutNodes } = simulation;
  const interaction = useGraphInteraction({
    graph,
    visibleGraphNodes,
    simulation,
    focusId,
    centerFocusOnMount,
    onEnter,
  });
  const {
    inspectorMode,
    setInspectorMode,
    hoveredId,
    setHoveredId,
    previewedId,
    viewMode,
    setViewMode,
    fitGraph,
    closeTools,
    openTools,
  } = interaction;
  const semanticNeighborhood = useSemanticNeighborhood(visibleGraphNodes, previewedId);
  const connectedToHovered = useMemo(
    () => neighborIds(visibleEdges, hoveredId),
    [visibleEdges, hoveredId],
  );
  const previewNodeIds = useMemo(
    () =>
      filterPreview
        ? filterPreviewIds(visibleGraphNodes, filterPreview)
        : semanticNeighborhood.activeNodeIds,
    [filterPreview, semanticNeighborhood.activeNodeIds, visibleGraphNodes],
  );

  const hoveredNode = hoveredId ? graph.nodes.find((node) => node.id === hoveredId) : undefined;
  const previewedNode = previewedId
    ? graph.nodes.find((node) => node.id === previewedId)
    : hoveredNode;

  function viewNeighborhood() {
    if (!previewedNode || semanticNeighborhood.response?.mode !== 'semantic') {
      return;
    }
    const ids = new Set([
      previewedNode.id,
      ...semanticNeighborhood.response.results.map(
        (result) => `${result.repository}:${result.path}`,
      ),
    ]);
    semanticNeighborhood.show(ids);
    fitGraph(layoutNodes.filter((node) => ids.has(node.id)));
  }

  function resetFilters() {
    setHiddenFilters(emptyFilters());
    setFilterPreview(undefined);
  }

  return (
    <section
      className="knowledge-graph atlas-graph"
      inert={inactive}
      data-filter-preview={
        filterPreview ? `${filterPreview.kind}:${filterPreview.value}` : undefined
      }
      data-testid="knowledge-graph"
      data-view={viewMode}
      data-inspector={viewMode === 'list' ? 'documents' : inspectorMode}
    >
      <header className="graph-workspace-header">
        <div>
          <strong>
            {visibleGraphNodes.length} mapped documents · {visibleEdges.length} explicit links
          </strong>
          <small>Bounded map of the current source scope</small>
        </div>
        <nav aria-label="Explore tools">
          <button
            className="graph-list-control"
            aria-pressed={viewMode === 'list'}
            onClick={() => {
              setViewMode('list');
              setInspectorMode('documents');
            }}
            type="button"
          >
            List
          </button>
          <button
            className="graph-map-control"
            aria-pressed={viewMode === 'canvas'}
            onClick={() => {
              setViewMode('canvas');
              setInspectorMode('closed');
            }}
            type="button"
          >
            Map
          </button>
          <button
            className="graph-documents-control"
            aria-expanded={inspectorMode === 'documents'}
            onClick={() => openTools('documents')}
            type="button"
          >
            Documents
          </button>
          <button
            aria-expanded={inspectorMode === 'filters'}
            onClick={() => openTools('filters')}
            type="button"
          >
            Filters
          </button>
        </nav>
      </header>
      <GraphCanvasView
        simulation={simulation}
        interaction={interaction}
        scope={scope}
        setScope={setScope}
        focusId={focusId}
        visibleEdges={visibleEdges}
        degree={degree}
        connectedToHovered={connectedToHovered}
        previewNodeIds={previewNodeIds}
        filterPreview={filterPreview}
      />
      {(viewMode === 'list' || inspectorMode !== 'closed') && (
        <GraphInspector
          mode={inspectorMode === 'closed' ? 'documents' : inspectorMode}
          onModeChange={setInspectorMode}
          clusterColors={clusterColors}
          degree={degree}
          graph={graph}
          hiddenFilters={hiddenFilters}
          hoveredNode={previewedNode}
          neighborhood={semanticNeighborhood.response}
          neighborhoodActive={Boolean(semanticNeighborhood.activeNodeIds)}
          neighborhoodLoading={semanticNeighborhood.loading}
          onClearNeighborhood={semanticNeighborhood.clear}
          onClose={closeTools}
          onHoverNode={setHoveredId}
          onOpen={(node) => {
            setInspectorMode('closed');
            onOpen(node);
          }}
          onViewNeighborhood={viewNeighborhood}
          onPreview={setFilterPreview}
          onResetFilters={resetFilters}
          onShowFilter={(kind, value) =>
            setHiddenFilters((previous) => changeFilter(previous, kind, value, 'show'))
          }
          onToggleFilter={(kind, value) =>
            setHiddenFilters((previous) => changeFilter(previous, kind, value, 'toggle'))
          }
          ownerCounts={counts.owner}
          repositories={repositories}
          repositoryCounts={counts.repository}
          repositoryInsights={repositoryInsights}
          statusCounts={counts.status}
          tagCounts={counts.tag}
          typeCounts={counts.type}
          visibleEdgeCount={visibleEdges.length}
          visibleNodes={visibleGraphNodes}
        />
      )}
    </section>
  );
}
