import { EmptyState, Button } from './ui.js';
import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import { useCompanyWork, agentDirectory, type CompanyWork } from './company-work.js';
import { targetKey } from '../studio/presentation.js';
import { agentPortraitId } from './agent-identity.js';
import { AgentPortrait, agentRoleGuide } from './agent-portrait.js';
import { AgentOverview } from './agent-overview.js';
import { AgentTelemetryPanel } from './agent-telemetry.js';
import { LoadingState } from './loading.js';
import { AgentIcon, AgentCharacter, AgentIdentity, AgentSnapshot, AgentAbout, AgentWorkRecords, useAgentEvidence, type AgentEntry, type AgentTab } from './agent-profile.js';
import './agents.css';
const tabs:AgentTab[]=['about','work','telemetry'];
const tabIcons={about:'profile',work:'files',telemetry:'chart'} as const;
function AgentProfile({entry,tab,onTab}:{entry:AgentEntry;tab:AgentTab;onTab:(tab:AgentTab)=>void}) {
  const {value,loading}=useAgentEvidence(entry),guide=agentRoleGuide(entry.target.agentId);
  return <article className="ws-agent-profile" data-agent-theme={guide?.theme??'neutral'} aria-labelledby="agent-profile-name">
    <aside className="ws-agent-profile-rail"><header><h2 id="agent-profile-name" tabIndex={-1}>{guide?.name??entry.target.agentId}</h2><p>{guide?.role??(entry.roles.join(' · ')||'Team member')}</p>{guide&&<blockquote>{guide.signature}</blockquote>}</header>
      <div className="ws-agent-stage"><span>{guide?.discipline??'Shared team'}</span><AgentCharacter key={entry.target.agentId} agentId={entry.target.agentId}/><p>{guide?.line??'One team. Across your projects.'}</p></div><AgentIdentity entry={entry} value={value}/>
    </aside><div className="ws-agent-dossier"><AgentSnapshot entry={entry} value={value} loading={loading} onTab={onTab}/>
      <div className="ws-agent-profile-tabs ui-tabs" role="tablist" aria-label="Agent profile sections" onKeyDown={event=>{
        if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
        event.preventDefault();const index=tabs.indexOf(tab),next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
        onTab(tabs[next]!);document.getElementById(`agent-tab-${tabs[next]}`)?.focus();
      }}>{tabs.map(name=><button key={name} id={`agent-tab-${name}`} role="tab" aria-selected={tab===name} aria-controls={`agent-panel-${name}`} tabIndex={tab===name?0:-1} onClick={()=>onTab(name)}><AgentIcon name={tabIcons[name]}/>{name[0]!.toUpperCase()+name.slice(1)}</button>)}</div>
      <div role="tabpanel" id="agent-panel-about" aria-labelledby="agent-tab-about" hidden={tab!=='about'} tabIndex={0}><AgentAbout entry={entry}/></div>
      <div role="tabpanel" id="agent-panel-work" aria-labelledby="agent-tab-work" hidden={tab!=='work'} tabIndex={0}><AgentWorkRecords entry={entry}/></div>
      <div role="tabpanel" id="agent-panel-telemetry" aria-labelledby="agent-tab-telemetry" hidden={tab!=='telemetry'} tabIndex={0}>{tab==='telemetry'&&<AgentTelemetryPanel target={entry.target} projectId={entry.projectIds[0]!}/>}</div>
    </div>
  </article>;
}
function AgentCoverage({work}:{work:CompanyWork}) {
  return <section className="ws-agent-project-coverage" id="agent-project-coverage" aria-label="Project coverage"><h2>Project coverage</h2><p>{work.projects.filter(p=>p.data&&!p.stale).length} of {work.admitted} admitted projects refreshed.{!work.current?' · last known state':''}</p><p>Work and availability cover inspected records.</p>{work.omitted>0&&<p>{work.omitted} further admitted projects are outside this bounded view.</p>}{work.projects.map(({project,data,loading,error,stale})=><div key={project.id}><strong>{project.name}</strong><span>{loading?'Loading…':error||(stale?'Last known state':'Refreshed')}</span>{data?.coverage.map(note=><p key={note}>{note}</p>)}</div>)}</section>;
}
export function Agents() {
  const work=useCompanyWork(),entries=agentDirectory(work).sort((a,b)=>{const order=['emon','kapiteky','tinus','satwa','stewie','ramiro'];const rank=(id:string)=>{const index=order.indexOf(agentPortraitId(id)??'');return index<0?order.length:index;};return rank(a.target.agentId)-rank(b.target.agentId);}),[search,setSearch]=useState(''),[params,setParams]=useSearchParams();
  const terms=search.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const filtered=entries.filter(entry=>{const guide=agentRoleGuide(entry.target.agentId);const text=[guide?.name,guide?.role,guide?.discipline,...(guide?.strengths??[]),entry.target.agentId,entry.target.gatewayId,...entry.roles].join(' ').toLowerCase();return terms.every(term=>text.includes(term));});
  const selected=filtered.find(entry=>targetKey(entry.target)===params.get('agent'))??filtered.find(entry=>entry.roles.includes('Coordinator'))??filtered[0];
  const selectedKey=selected&&targetKey(selected.target),teamView=params.get('view')==='team';
  const requestedTab=params.get('section'),tab:AgentTab=requestedTab==='telemetry'||requestedTab==='work'?requestedTab:'about';
  const [focusRequest,setFocusRequest]=useState(0),focusTarget=useRef<{id:string;agent?:string;team:boolean;section?:AgentTab}|null>(teamView?{id:'agent-team-heading',team:true}:params.get('section')==='telemetry'?{id:'agent-telemetry',team:false,section:'telemetry'}:null);
  useEffect(()=>{
    const pending=focusTarget.current;
    if(!pending||pending.team!==teamView||(pending.agent&&pending.agent!==selectedKey)||(pending.section&&pending.section!==tab))return;
    const element=document.getElementById(pending.id);
    if(element){element.focus({preventScroll:true});element.scrollIntoView({block:'nearest',behavior:'instant'});focusTarget.current=null;}
  },[selectedKey,teamView,tab,focusRequest]);
  function choose(key:string,section:AgentTab='about') {focusTarget.current={id:section==='telemetry'?'agent-telemetry':'agent-profile-name',agent:key,team:false,section};setFocusRequest(n=>n+1);setParams(previous=>{const next=new URLSearchParams(previous);next.set('agent',key);next.delete('view');if(section==='about')next.delete('section');else next.set('section',section);return next;});}
  function selectTab(nextTab:AgentTab) {setParams(previous=>{const next=new URLSearchParams(previous);if(nextTab==='about')next.delete('section');else next.set('section',nextTab);return next;},{replace:true});}
  function team(open:boolean) {focusTarget.current={id:open?'agent-team-heading':'agent-team-button',team:open};setFocusRequest(n=>n+1);setParams(previous=>{const next=new URLSearchParams(previous);if(open)next.set('view','team');else next.delete('view');return next;});}
  function clear(){setSearch('');setParams(previous=>{const next=new URLSearchParams(previous);next.delete('agent');return next;});}
  const incomplete=!work.current||work.omitted>0||work.projects.some(p=>p.error||p.stale||p.data?.coverage.length);
  const initialLoading=work.current&&work.loading&&!entries.length;
  return <section className="ws-surface ws-agents-surface ws-company-surface ui-layout-wide" aria-label="Agents">
      {!initialLoading&&incomplete&&<p className="ws-alert ws-agent-coverage-notice" role="status">{!work.current?'Showing last known work while Studio reconnects.':'Some project work is missing or could not refresh.'} <a href="#agent-project-coverage">See project coverage ↓</a></p>}
      <div className="ws-agents-layout"><section className="ws-agent-team"><header><h1><AgentIcon name="users"/>Meet the team <span aria-live="polite">{!initialLoading&&(search?`${filtered.length} of ${entries.length}`:entries.length)}</span></h1><div className="ws-agent-team-controls"><label className="ws-agent-search"><span className="sr-only">Find an agent</span><input className="ui-control" type="search" value={search} onChange={event=>setSearch(event.target.value)} placeholder="Find an agent…"/></label><Button variant="quiet" onClick={clear}>All agents</Button><Button variant="quiet" id="agent-team-button" aria-expanded={teamView} aria-controls="agent-team-view" onClick={()=>team(!teamView)}><AgentIcon name="operations"/>Team operations</Button><Button variant="quiet" disabled={!work.current||work.refreshing} onClick={work.refresh}>{work.refreshing?'Refreshing…':'Refresh'}</Button></div></header>
        <nav className="ws-agent-directory" aria-label="Agent profiles">{filtered.map(entry=>{const guide=agentRoleGuide(entry.target.agentId),name=guide?.name??entry.target.agentId,duplicate=entries.filter(other=>(agentRoleGuide(other.target.agentId)?.name??other.target.agentId)===name).length>1;return <button className="ws-agent-card" key={targetKey(entry.target)} aria-current={!teamView&&selectedKey===targetKey(entry.target)?'true':undefined} onClick={()=>choose(targetKey(entry.target))}><AgentPortrait target={entry.target}/><div><h2>{name}</h2><p>{guide?.role??(entry.roles.join(' · ')||'Team member')}</p>{duplicate&&<small>{entry.target.gatewayId} · {entry.target.agentId}</small>}</div></button>;})}</nav>
      </section>
      {initialLoading?<LoadingState label="Loading agents…" size="page"/>:teamView?<div className="ws-agent-team-view" id="agent-team-view"><Button variant="quiet" className="ws-agent-return" onClick={()=>team(false)}>← Back to profiles</Button><AgentOverview entries={entries} onInspect={key=>{setSearch('');choose(key,'telemetry');}}/></div>:selected?<AgentProfile key={selectedKey} entry={selected} tab={tab} onTab={selectTab}/>:<EmptyState title={<>{work.loading?'Meeting the team…':entries.length?'No matching agents.':'No agents to show yet.'}</>} actions={<>{entries.length>0&&<Button variant="quiet" onClick={clear}>Clear search</Button>}</>}>{entries.length?'Try a name, role or strength, or clear your search.':'The team appears after Studio reads your accessible projects.'}</EmptyState>}
      </div>{!initialLoading&&<><AgentCoverage work={work}/>{work.loading&&<LoadingState label="Loading remaining projects…" size="inline"/>}</>}
  </section>;
}
