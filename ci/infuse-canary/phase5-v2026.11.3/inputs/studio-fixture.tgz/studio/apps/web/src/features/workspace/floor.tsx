import { Button } from './ui.js';
import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { useWorkspace } from './context.js';
import { useNavigate, Link } from './navigation.js';
import { useFloorWork } from './company-work.js';
import { floorModel } from './floor-model.js';
import { WorkspaceScene } from './scene.js';
import { SceneBoundary } from './scene-boundary.js';
import { agentRoleGuide } from './agent-portrait.js';
import { LoadingState } from './loading.js';
import { FloorAgentMenu, positionAgentMenu } from './floor-agent-menu.js';
import type { AgentScreenAnchor } from '../studio/spatial.js';
import { useFloorSummary } from './floor-summary.js';
import './floor.css';

export function ProjectFloor({ shown }: { shown: boolean }) {
  const { session, visible, current } = useWorkspace(); const navigate=useNavigate();
  const [exploring,setExploring]=useState<string|null>(null);
  const floorSummary=useFloorSummary(exploring,shown);
  const work=useFloorWork(shown); const model=useMemo(()=>floorModel(work.data,work.stale),[work.data,work.stale]);
  const [now,setNow]=useState(()=>new Date());
  const [selected,setSelected]=useState<string|null>(null); const [assignment,setAssignment]=useState('');
  const floor=useRef<HTMLElement>(null), menu=useRef<HTMLElement>(null);
  const anchor=useRef<AgentScreenAnchor|null>(null);
  const lastSelected=useRef<HTMLElement|null>(null);
  useEffect(()=>{if(!shown)return;const tick=()=>{if(!document.hidden)setNow(new Date());};tick();const timer=window.setInterval(tick,30000);document.addEventListener('visibilitychange',tick);return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',tick);};},[shown]);
  useEffect(()=>{setSelected(null);setAssignment('');anchor.current=null;},[session.project.id]);
  const desk=model.desks.find(d=>d.key===selected); const item=desk?.work.find(w=>w.id===assignment) ?? desk?.work[0];
  useEffect(()=>{if(selected&&!desk)setSelected(null);},[desk,selected]);
  const close=(restoreFocus=true)=>{setSelected(null);anchor.current=null;if(restoreFocus&&lastSelected.current?.isConnected)lastSelected.current.focus({preventScroll:true});};
  const choose=(key:string)=>{if(selected===key){close();return;}lastSelected.current=document.activeElement instanceof HTMLElement?document.activeElement:null;anchor.current=null;setSelected(key);setAssignment('');};
  const position=(value:AgentScreenAnchor|null)=>{anchor.current=value;if(menu.current)positionAgentMenu(menu.current,value);};
  useEffect(()=>{
    if(!shown||!desk)return;
    const outside=(event:MouseEvent)=>{if(event.target instanceof Element&&floor.current?.contains(event.target)&&!event.target.closest('.ws-floor-orbit,.studio-space-person-pin,.ws-floor-team,.studio-space-controls,canvas'))close(false);};
    document.addEventListener('click',outside);
    return()=>document.removeEventListener('click',outside);
  },[shown,desk?.key]);
  const projection=useMemo(()=>({...model.projection,agents:model.projection.agents.map(agent=>({...agent,name:agentRoleGuide(agent.target.agentId)?.name ?? agent.target.agentId}))}),[model]);
  const summary=work.loading?'Loading project activity…':work.stale?'Project activity could not refresh.':model.desks.length
    ? `${model.desks.length} team members · ${model.assignedCount} with assignments in view` : 'Room for what comes next.';
  const profilePath=desk?`/agents?${new URLSearchParams({agent:desk.key,project:session.project.id})}`:'';
  return <section ref={floor} onKeyDown={e=>{if(e.key==='Escape'&&selected){e.preventDefault();close();}}} className="ws-living-floor" aria-label={`${session.project.name} project floor`} data-inspecting={!!desk}>
    <header className="ws-floor-intro"><div><span className="ws-eyebrow">{session.project.name} / PROJECT FLOOR</span><h1>{session.project.name}</h1><p role="status">{summary}</p><nav aria-label="Floor destinations"><Link to="/missions">Mission board ↗</Link><Link to="/grilling">New mission ↗</Link></nav></div><div className="ws-floor-clock"><time dateTime={now.toISOString()}>{now.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</time><span>Your local time</span><small>{now.toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'})}</small></div></header>
    {(work.error || work.data?.coverage.length) ? <details className="ws-floor-coverage"><summary>Some work is outside this view</summary>{work.error&&<p>{work.error}</p>}{work.data?.coverage.map(note=><p key={note}>{note}</p>)}<Button variant="quiet" onClick={work.refresh}>Refresh activity</Button></details>:null}
    <div className="ws-floor-stage"><SceneBoundary><Suspense fallback={<LoadingState label="Loading project floor…" size="page" overlay />}><WorkspaceScene key={session.project.id} projection={projection} shown={shown&&visible&&current} now={now} projectName={session.project.name} selected={selected} onAgentSelect={choose} onAgentAnchor={position} onBackgroundClick={()=>close(false)}
      floorSummary={floorSummary} floorNavigation={{projectId:session.project.id,projects:session.projects,changed:setExploring,
        enter:id=>{if(current&&session.projects.some(project=>project.id===id))navigate(`/floor?${new URLSearchParams({project:id})}`);}}}
      onNavigate={destination=>navigate({paper:'/grilling',missions:'/missions',activity:'/missions?view=activity',evidence:'/review'}[destination])}/></Suspense></SceneBoundary></div>
    {model.desks.length>0&&<nav className="ws-floor-team" data-overflow={model.desks.length>8} aria-label="Project team">{model.desks.length>8&&<span className="ws-floor-roster-count">{model.desks.length} team members · 8 in the scene</span>}{model.desks.map(d=><button key={d.key} type="button" aria-pressed={selected===d.key} onClick={()=>choose(d.key)}><span className="ws-floor-agent-dot" data-working={d.work.some(w=>w.running)} aria-hidden="true"/>{agentRoleGuide(d.target.agentId)?.name??d.target.agentId}<small>{d.status}</small></button>)}</nav>}
    {desk&&<FloorAgentMenu key={desk.key} desk={desk} item={item} projectName={session.project.name} profilePath={profilePath} anchor={anchor} menuRef={menu} onAssignment={setAssignment} onClose={()=>close()}/>}

  </section>;
}
