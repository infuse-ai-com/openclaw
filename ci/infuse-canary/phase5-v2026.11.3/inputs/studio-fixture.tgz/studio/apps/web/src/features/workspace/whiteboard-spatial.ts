import { useEffect,useMemo,useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { whiteboardManifest,whiteboardDetails,type WhiteboardManifest,type WhiteboardSpatialItem,type WhiteboardSummary } from '@studio/contracts';
import { api,ApiError,type SignedInSession } from './api.js';

type Camera={x:number;y:number;zoom:number};
export function intersects(item:WhiteboardSummary,camera:Camera,size:{width:number;height:number}) {
  if(item.kind==='connection')return false;
  const left=-camera.x/camera.zoom,top=-camera.y/camera.zoom;
  return item.x+item.width>=left-100 && item.y+item.height>=top-100 && item.x<=left+(size.width+100)/camera.zoom && item.y<=top+(size.height+100)/camera.zoom;
}
/** Revision-fenced pagination shared by the current view and destination placement. */
export async function readSectionManifest(path:string,sectionId:string,projectId:string,signal?:AbortSignal) {
  let result:WhiteboardManifest|undefined,after:string|undefined;
  do {
    const q=new URLSearchParams({sectionId,...(after?{after,revision:String(result!.revision)}:{})});
    const page=whiteboardManifest.parse(await api(path+'/v3?'+q,{signal})) as WhiteboardManifest;
    if(page.projectId!==projectId || page.sectionId!==sectionId)throw Error('Whiteboard scope changed');
    if(result)result.items.push(...page.items);else result=page;
    after=page.nextCursor??undefined;
    if(result.items.length>4800)throw Error('Section metadata exceeds its limit');
  }while(after);
  return {...result!,nextCursor:null};
}

/** Only this section's metadata is loaded. Retain at most 30 items from the last readable window while zooming out. */
export function useSpatialBoard(path:string,owner:string,session:SignedInSession,sectionId:string,current:boolean,visible:boolean,denied:boolean,camera:Camera,size:{width:number;height:number},focusedId?:string) {
  const readableWindow=useRef<{owner:string;sectionId:string;ids:string[]}|null>(null);
  const pinned=useRef<{id:string;item:WhiteboardSpatialItem}|null>(null);
  const manifest=useQuery({queryKey:['workspace',owner,'whiteboard',sectionId],gcTime:0,
    queryFn:async({signal})=> {
      return readSectionManifest(path,sectionId,session.project.id,signal);
    },enabled:current&&!denied,refetchInterval:current&&visible&&!denied?3000:false,
    retry:(count,error)=>error instanceof ApiError && error.code==='VERSION_CONFLICT' && count<2});
  const wanted=useMemo(()=> {
    const items=manifest.data?.items??[];
    const inView=camera.zoom>=0.45?items.filter(item=>item.kind!=='connection' && intersects(item,camera,size)):[];
    const center={x:(size.width/2-camera.x)/camera.zoom,y:(size.height/2-camera.y)/camera.zoom};
    inView.sort((a,b)=>a.kind==='connection'||b.kind==='connection'?0:Math.hypot(a.x-center.x,a.y-center.y)-Math.hypot(b.x-center.x,b.y-center.y));
    const previous=readableWindow.current;
    const visibleIds=camera.zoom>=.45?inView.map(item=>item.id):previous?.owner===owner&&previous.sectionId===sectionId?previous.ids.filter(id=>items.some(item=>item.id===id)):[];
    const wanted=[...new Set([...(focusedId && items.some(i=>i.id===focusedId)?[focusedId]:[]),...visibleIds])].slice(0,30).sort();
    if(camera.zoom>=.45)readableWindow.current={owner,sectionId,ids:wanted};
    return wanted;
  },[manifest.data,camera,size,focusedId,owner,sectionId]);
  const ids=wanted.join(',');
  const details=useQuery({queryKey:['workspace',owner,'whiteboard-details',sectionId,manifest.data?.revision,ids],gcTime:0,
    queryFn:async({signal})=> {
      const value=whiteboardDetails.parse(await api(path+'/v3/details',{command:{sectionId,revision:manifest.data!.revision,ids:wanted},csrf:session.csrfToken,signal}));
      if(value.projectId!==session.project.id || value.sectionId!==sectionId || value.revision!==manifest.data!.revision)throw Error('Whiteboard detail scope changed');
      return value;
    },enabled:current&&!denied&&!!manifest.data&&!!wanted.length,retry:false});
  useEffect(()=>{if(details.error instanceof ApiError && details.error.code==='VERSION_CONFLICT')void manifest.refetch({cancelRefetch:false});},[details.error,manifest.refetch]);
  const data=useMemo(()=> {
    const m=manifest.data;if(!m)return undefined;
    const content=new Map((details.data?.revision===m.revision?details.data.items:[]).map(item=>[item.id,item]));
    if(pinned.current?.id!==focusedId)pinned.current=null;
    const focused=focusedId?content.get(focusedId):undefined;
    if(focused)pinned.current={id:focused.id,item:focused};
    // The focused editor remains mounted during view/detail refresh; its text channel owns freshness.
    if(focusedId && pinned.current && m.items.some(item=>item.id===focusedId))content.set(focusedId,pinned.current.item);
    const items=m.items.map(item=> {
      const saved=content.get(item.id);
      if(saved)return {...saved,...item};
      if(item.kind==='note'||item.kind==='document')return {...item,text:''};
      if(item.kind==='stroke')return {...item,points:[]};
      return item;
    }) as WhiteboardSpatialItem[];
    return {...m,items,loadedIds:new Set(content.keys()),summaries:m.items,structureRevisions:Object.fromEntries(m.items.map(item=>[item.id,item.revision]))};
  },[manifest.data,details.data,focusedId]);
  useEffect(()=>()=>{pinned.current=null;},[owner,sectionId]);
  return {...manifest,data,loadingIds:details.isFetching ? wanted : [],detailError:details.error,error:manifest.error??(details.error instanceof ApiError&&details.error.code==='VERSION_CONFLICT'?null:details.error),
    refetch:manifest.refetch};
}
