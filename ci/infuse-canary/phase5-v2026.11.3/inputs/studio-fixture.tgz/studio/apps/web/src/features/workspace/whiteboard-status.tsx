import { IconButton, Button } from './ui.js';
import { WhiteboardShareView } from './whiteboard-share-view.js';
import { useWorkspace } from './context.js';
import { InfuseSpinner } from './loading.js';
import { BoardIcon } from './whiteboard-icon.js';
import { useBoardPresence } from './whiteboard-presence.js';
import { useSpatialBoard } from './whiteboard-spatial.js';
import type { BoardPanel, CanvasItem } from './whiteboard-types.js';

import type * as React from 'react';
import type { WhiteboardCommands } from './whiteboard-commands.js';

type Props = {
  informational: boolean;

  session: ReturnType<typeof useWorkspace>['session'];
  panel: BoardPanel;
  openPanel: (next: BoardPanel) => void;
  isShared: boolean;
  presence: ReturnType<typeof useBoardPresence>;
  following: string | null;
  setFollowing: React.Dispatch<React.SetStateAction<string | null>>;
  sectionId: string;
  board: Pick<ReturnType<typeof useSpatialBoard>, 'data' | 'isPending' | 'isError' | 'refetch'>;
  enterSection: (next: string, block?: string) => void;
  attention: boolean;
  loadingBoard: boolean;
  busy: boolean;
  imagePending: boolean;
  hasDraft: boolean;
  current: boolean;
  commentsOpen: boolean;
  focused: CanvasItem | null;
  commentFrame: React.RefObject<(id: string) => void>;
  setCommentsOpen: (open: boolean) => void;
  notice: string;
  pending: boolean;
  commands: Pick<WhiteboardCommands, 'recover'>;
};
export function WhiteboardStatus({
  informational,
  session,
  panel,
  openPanel,
  isShared,
  presence,
  following,
  setFollowing,
  sectionId,
  board,
  enterSection,
  attention,
  loadingBoard,
  busy,
  imagePending,
  hasDraft,
  current,
  commentsOpen,
  focused,
  commentFrame,
  setCommentsOpen,
  notice,
  pending,
  commands,
}: Props) {
  return (
    <>
      <div className="wboard-heading">
        <header className="wboard-title wboard-float">
          <BoardIcon name="board" />
          <div>
            <span>{session.project.name}</span>
            <h1>Whiteboard</h1>
          </div>
          <IconButton
            className="wboard-tool"
            aria-label="Board outline"
            title="Board outline"
            aria-expanded={panel === 'outline'}
            aria-controls="wboard-panel"
            onClick={() => openPanel('outline')}
          >
            <BoardIcon name="list" />
          </IconButton>
        </header>
        {isShared && (
          <div className="wboard-people wboard-float" aria-label="People on this board">
            <span>
              {presence.peers.length
                ? 'Together'
                : presence.status === 'Connected'
                  ? 'Just you here'
                  : presence.status}
            </span>
            {presence.peers.map((peer) => (
              <Button variant="quiet"
                key={peer.connectionId}
                type="button"
                aria-label={
                  (following === peer.connectionId ? 'Stop following ' : 'Follow ') + peer.name
                }
                aria-pressed={following === peer.connectionId}
                style={{ color: peer.color }}
                onClick={() =>
                  setFollowing(following === peer.connectionId ? null : peer.connectionId)
                }
              >
                {peer.name}
                {(peer.state.sectionId ?? 'root') !== sectionId ? ' · Another section' : ''}
                {following === peer.connectionId ? ' · Following' : ''}
              </Button>
            ))}
          </div>
        )}
        {isShared&&<WhiteboardShareView key={session.project.id} projectId={session.project.id} presence={presence}/>}
      </div>
      <nav className="wboard-breadcrumbs wboard-float" aria-label="Board sections">
        {(board.data?.ancestors ?? [{ id: 'root', title: 'Whiteboard' }]).map((a) => (
          <Button variant="quiet"
            key={a.id}
            aria-current={a.id === sectionId ? 'page' : undefined}
            onClick={() => enterSection(a.id)}
          >
            {a.title}
          </Button>
        ))}
      </nav>
      <div className="wboard-top-actions wboard-float">
        <span
          className="wboard-save-indicator"
          title={
            attention
              ? 'Board needs attention'
              : loadingBoard
                ? 'Loading board'
                : busy || imagePending
                  ? 'Saving changes'
                  : hasDraft
                    ? 'You have unsaved drafts'
                    : 'All changes saved'
          }
        >
          {loadingBoard ? (
            <InfuseSpinner />
          ) : (
            <BoardIcon
              name={
                attention ? 'alert' : busy || imagePending ? 'refresh' : hasDraft ? 'edit' : 'check'
              }
            />
          )}
          <span>
            {attention
              ? 'Check board'
              : loadingBoard
                ? 'Loading'
                : busy || imagePending
                  ? 'Saving'
                  : hasDraft
                    ? 'Draft'
                    : 'Saved'}
          </span>
        </span>
        <IconButton
          className="wboard-tool"
          aria-label="Search whiteboard"
          title="Search all sections"
          onClick={() => openPanel('search')}
        >
          <BoardIcon name="search" />
        </IconButton>
        <IconButton
          className="wboard-tool"
          aria-label="Refresh board"
          title="Refresh board"
          disabled={busy || !current}
          onClick={() => void board.refetch()}
        >
          <BoardIcon name="refresh" />
        </IconButton>
        <IconButton
          className="wboard-tool"
          aria-label="Recent changes"
          title="Recent changes"
          aria-expanded={panel === 'activity'}
          aria-controls="wboard-panel"
          onClick={() => openPanel('activity')}
        >
          <BoardIcon name="history" />
        </IconButton>
        {isShared && (
          <IconButton
            type="button"
            className="wboard-tool"
            aria-label="Comments"
            title="Comments"
            aria-expanded={commentsOpen}
            onClick={() => {
              if (!commentsOpen && focused) commentFrame.current(focused.id);
              setCommentsOpen(!commentsOpen);
            }}
          >
            <BoardIcon name="note" />
          </IconButton>
        )}
      </div>
      <div
        className={
          'wboard-status' +
          (attention || informational ? ' wboard-notice wboard-float' : ' wboard-sr-only')
        }
        role="status"
        aria-live="polite"
      >
        {attention || informational || busy
          ? notice
          : loadingBoard
            ? 'Loading board.'
            : imagePending
              ? 'An image is waiting to be saved.'
              : hasDraft
                ? 'You have unsaved drafts.'
                : 'All changes saved.'}
        {pending && !busy && (
          <Button variant="quiet" disabled={!current} onClick={() => void commands.recover()}>
            Check save and retry if needed
          </Button>
        )}
      </div>
    </>
  );
}
