import { createContext, useContext, useEffect, useState } from 'react';
export type Appearance = 'light' | 'dark' | 'system';
const key = 'infuse-studio:appearance';
export function useAppearance() {
  const [preference, setPreference] = useState<Appearance>(() => {
    try { const value = localStorage.getItem(key); return value === 'light' || value === 'dark' || value === 'system' ? value : 'light'; } catch { return 'light'; }
  });
  const [systemDark, setSystemDark] = useState(() => matchMedia('(prefers-color-scheme: dark)').matches);
  useEffect(() => {
    const media = matchMedia('(prefers-color-scheme: dark)'); const update = () => setSystemDark(media.matches);
    media.addEventListener('change', update); return () => media.removeEventListener('change', update);
  }, []);
  useEffect(() => { try { localStorage.setItem(key, preference); } catch { /* Appearance remains usable without storage. */ } }, [preference]);
  return { preference, setPreference, theme: preference === 'system' ? systemDark ? 'dark' : 'light' : preference };
}

export const AppearanceContext = createContext<ReturnType<typeof useAppearance> | undefined>(undefined);
export function useWorkspaceAppearance() {
  const value = useContext(AppearanceContext);
  if (!value) throw Error('Workspace appearance is unavailable');
  return value;
}
