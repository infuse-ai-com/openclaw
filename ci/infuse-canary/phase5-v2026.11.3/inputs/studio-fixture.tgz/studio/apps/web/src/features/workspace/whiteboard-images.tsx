import { Button } from './ui.js';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { whiteboardImageUploaded, type WhiteboardImage, type WhiteboardReceipt, type WhiteboardSpatialOperation } from '@studio/contracts';
import { readableError, type SignedInSession } from './api.js';
import { ImageCropEditor } from './whiteboard-image-crop.js';
import { isTyping } from './whiteboard-history.js';

type Point={x:number;y:number};
type Upload={scope:string;id:string;file:File;url:string;sectionId:string;position:Point;state:'queued'|'uploading'|'failed';error?:string;asset?:ReturnType<typeof whiteboardImageUploaded.parse>};
type Options={path:string;session:SignedInSession;sectionId:string;enabled:boolean;knownIds:string[];commit(ops:WhiteboardSpatialOperation[]):Promise<WhiteboardReceipt|undefined>;changed(pending:boolean):void;notify(message:string):void;place(point?:Point):Point};
const types=new Set(['image/png','image/jpeg','image/webp']);
export function useWhiteboardImages(options:Options) {
  const scope=JSON.stringify([options.path,options.session.profileId,options.session.bootstrap.authorityId]);
  const latest=useRef({...options,scope});latest.current={...options,scope};
  const jobs=useRef<Upload[]>([]),active=useRef(false),alive=useRef(true),abort=useRef(new AbortController());
  const [uploads,setUploads]=useState<Upload[]>([]),[dragging,setDragging]=useState(false);
  const input=useRef<HTMLInputElement>(null);
  function sync(){if(alive.current){setUploads([...jobs.current]);latest.current.changed(jobs.current.length>0);}}
  function remove(id:string){const job=jobs.current.find(j=>j.id===id);if(job)URL.revokeObjectURL(job.url);jobs.current=jobs.current.filter(j=>j.id!==id);sync();}
  useEffect(()=>{alive.current=true;abort.current=new AbortController();return()=>{alive.current=false;abort.current.abort();for(const job of jobs.current)URL.revokeObjectURL(job.url);jobs.current=[];};},[scope]);
  useEffect(()=>{setUploads([]);latest.current.changed(false);},[scope]);
  useEffect(()=>{for(const job of [...jobs.current])if(options.knownIds.includes(job.id))remove(job.id);},[options.knownIds.join(',')]);
  async function send(job:Upload) {
    if(job.scope!==latest.current.scope || active.current || !latest.current.enabled || latest.current.sectionId!==job.sectionId)return;
    active.current=true;job.state='uploading';delete job.error;latest.current.notify('Saving…');sync();
    try {
      if(!job.asset){
        const contentBase64=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(Error('This file could not be read'));reader.onload=()=>resolve(String(reader.result).split(',')[1]!);reader.readAsDataURL(job.file);});
        const response=await fetch(options.path+'/v3/images',{method:'POST',credentials:'same-origin',cache:'no-store',signal:AbortSignal.any([abort.current.signal,AbortSignal.timeout(100_000)]),headers:{'Content-Type':'application/json','X-CSRF-Token':options.session.csrfToken},body:JSON.stringify({uploadId:job.id,contentBase64})});
        const value=await response.json();if(!response.ok)throw Error(value.error?.message??'This image could not be uploaded. Retry when connected.');
        job.asset=whiteboardImageUploaded.parse(value);
      }
      if(!alive.current || !jobs.current.includes(job))return;
      if(latest.current.sectionId!==job.sectionId)throw Error('Return to the original section to finish adding this image.');
      const scale=Math.min(1,480/Math.max(job.asset.width,job.asset.height));
      const width=Math.max(16,job.asset.width*scale),height=Math.max(16,job.asset.height*scale);
      const receipt=await latest.current.commit([{type:'createImage',sectionId:job.sectionId,tile:{id:job.id,kind:'image',title:job.file.name.slice(0,160)||'Pasted image',reference:job.asset.reference,...job.position,width,height}}]);
      if(receipt?.status!=='applied')throw Error(receipt?.message??'Image uploaded. Check any pending board save, then retry to place it.');
      remove(job.id);latest.current.notify('Saved to this project.');
    }catch(error){job.state='failed';job.error=readableError(error);if(alive.current&&jobs.current.includes(job))latest.current.notify(job.error);sync();}finally{active.current=false;sync();}
  }
  async function add(files:File[],point?:Point) {
    if(!latest.current.enabled){latest.current.notify('Image uploads are not available right now.');return;}
    if(active.current){latest.current.notify('Wait for this image to finish uploading, then add another.');return;}
    if(jobs.current.length+files.length>5){latest.current.notify('Add up to five images at a time.');return;}
    const position=latest.current.place(point);
    for(const [index,file] of files.entries()) {
      if(!types.has(file.type)||!file.size||file.size>10*1024*1024){latest.current.notify('Choose a still PNG, JPEG or WebP image up to 10 MB.');continue;}
      const job:Upload={scope,id:crypto.randomUUID(),file,url:URL.createObjectURL(file),sectionId:latest.current.sectionId,position:{x:position.x+index*32,y:position.y+index*32},state:'queued'};
      jobs.current.push(job);
    }
    sync();
  }
  useEffect(()=>{if(options.enabled&&!active.current){const job=jobs.current.find(j=>j.state==='queued'&&j.scope===scope&&j.sectionId===options.sectionId);if(job)void send(job);}},[uploads,options.enabled,options.sectionId]);
  return {uploads:uploads.filter(job=>job.scope===scope),dragging,input,add,retry:send,remove:(id:string)=>{remove(id);if(!jobs.current.length&&latest.current.enabled)latest.current.notify('');},
    paste:(event:React.ClipboardEvent)=>{if(isTyping(event.target))return;const files=Array.from(event.clipboardData.files);if(files.length){event.preventDefault();void add(files);}},
    dragOver:(event:React.DragEvent)=>{if(event.dataTransfer.types.includes('Files')){event.preventDefault();event.dataTransfer.dropEffect=options.enabled?'copy':'none';setDragging(true);}},
    dragLeave:(event:React.DragEvent)=>{if(!event.currentTarget.contains(event.relatedTarget as Node|null))setDragging(false);},
    drop:(event:React.DragEvent)=>{setDragging(false);if(!event.dataTransfer.files.length)return;event.preventDefault();void add(Array.from(event.dataTransfer.files),{x:event.clientX,y:event.clientY});},
    discard:()=>{abort.current.abort();abort.current=new AbortController();for(const job of [...jobs.current])remove(job.id);},
  };
}
export function ImageUploads({images,viewport,sectionId,enabled}:{images:ReturnType<typeof useWhiteboardImages>;viewport:{x:number;y:number;zoom:number};sectionId:string;enabled:boolean}) {
  return <>{images.dragging&&<div className="wboard-image-drop" role="status">Drop images onto the board</div>}
    {images.uploads.filter(job=>job.sectionId===sectionId).map(job=><div key={job.id} className="wboard-image-upload wboard-float" style={{left:job.position.x*viewport.zoom+viewport.x,top:job.position.y*viewport.zoom+viewport.y}}>
      <img src={job.url} alt={job.file.name||'Image upload preview'}/><p role="status">{job.state==='failed'?job.error:'Adding image…'}</p>
      {job.state==='failed'&&<div><Button variant="quiet" type="button" disabled={!enabled} onClick={()=>void images.retry(job)}>Retry image</Button><Button variant="quiet" type="button" onClick={()=>images.remove(job.id)}>Dismiss</Button></div>}
    </div>)}
  </>;
}
function ExpandedImage({url,title,close}:{url:string;title:string;close():void}) {
  const dialog=useRef<HTMLDialogElement>(null);
  useEffect(()=>{const previous=document.activeElement;dialog.current?.showModal();return()=>{if(previous instanceof HTMLElement&&previous.isConnected)previous.focus();};},[]);
  return createPortal(<dialog ref={dialog} className="wboard-expanded wboard-expanded-image" aria-label={title+' full image'} onCancel={e=>{e.preventDefault();close();}} onClose={close}><header><h2>{title||'Image'}</h2><Button variant="quiet" type="button" onClick={close} autoFocus>Return to board</Button></header><img src={url} alt={title||'Whiteboard image'}/></dialog>,document.querySelector('.ws-whiteboard')??document.body);
}
export function ImageTile({tile,path,visible,inspect,enabled,commit}:{tile:WhiteboardImage;path:string;visible:boolean;inspect():void;enabled:boolean;commit(operations:WhiteboardSpatialOperation[]):Promise<WhiteboardReceipt|undefined>}) {
  const [sourceRatio,setSourceRatio]=useState<number|null>(null);
  const cropRatio=sourceRatio&&tile.crop?sourceRatio*tile.crop.width/tile.crop.height:null;
  const frameRatio=tile.width/tile.height;
  const viewportStyle=cropRatio?{width:Math.min(1,cropRatio/frameRatio)*100+'%',height:Math.min(1,frameRatio/cropRatio)*100+'%'}:undefined;
  const [cropping,setCropping]=useState(false),[expanded,setExpanded]=useState(false),[failed,setFailed]=useState(false),[attempt,setAttempt]=useState(0);
  const url=path+'/v3/images/'+encodeURIComponent(tile.id)+'/'+tile.revision+'?attempt='+attempt;
  useEffect(()=>setFailed(false),[url]);
  return <div className="wboard-image">
    {visible?failed?<div role="status">Image unavailable.<button className="nodrag nopan" onClick={()=>setAttempt(v=>v+1)}>Reload image</button></div>:<div className="wboard-image-viewport" style={viewportStyle}><img draggable={false} src={url} style={tile.crop?{position:'absolute',maxWidth:'none',width:100/tile.crop.width+'%',height:100/tile.crop.height+'%',left:-100*tile.crop.x/tile.crop.width+'%',top:-100*tile.crop.y/tile.crop.height+'%',objectFit:'fill'}:undefined} alt={tile.title||'Whiteboard image'} onLoad={event=>setSourceRatio(event.currentTarget.naturalWidth/event.currentTarget.naturalHeight)} onError={()=>setFailed(true)}/></div>:<span>Zoom in to see image</span>}
    <div className="wboard-image-actions nodrag nopan"><button disabled={!visible||failed} onClick={e=>{e.stopPropagation();setExpanded(true);}}>{tile.crop?'View full image':'View image'}</button><button disabled={!enabled||!visible||failed} onClick={e=>{e.stopPropagation();setCropping(true);}}>Crop image</button><button aria-label="Image properties" onClick={e=>{e.stopPropagation();inspect();}}>•••</button></div>
    {cropping&&<ImageCropEditor tile={tile} url={url} enabled={enabled} commit={commit} close={()=>setCropping(false)}/>}
    {expanded&&<ExpandedImage url={url} title={tile.title} close={()=>setExpanded(false)}/>}
  </div>;
}
