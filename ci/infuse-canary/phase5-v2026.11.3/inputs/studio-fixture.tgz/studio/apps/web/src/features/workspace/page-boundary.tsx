import { Component, useEffect, useRef, type ReactNode } from 'react';
import { Link } from './navigation.js';

export function isModuleLoadError(error: unknown): boolean {
  return error instanceof Error && /Failed to fetch dynamically imported module|Importing a module script failed|error loading dynamically imported module|Unable to preload CSS for/i.test(error.message);
}

export function PageLoadFailure({ moduleLoad }: { moduleLoad: boolean }) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => { heading.current?.focus(); }, []);
  return <section className="ws-surface" aria-label="Page unavailable"><div className="ws-empty">
    <h2 ref={heading} tabIndex={-1}>{moduleLoad ? 'This page needs a fresh load.' : 'This page could not open.'}</h2>
    <p>{moduleLoad ? 'Studio may have been updated, or the connection interrupted loading. Reload to try this address again.' : 'Reload to try again, or use the navigation to open another page.'}</p>
    <p>Reloading keeps this address and project. Unsaved work may be lost.</p>
    <div className="ws-actions"><button className="ws-button" onClick={() => window.location.reload()}>Reload this page</button><Link className="ws-text-link" to="/apps">Open My Apps</Link></div>
  </div></section>;
}

/** Keep the admitted shell and command receipts mounted when a destination fails.
 * Reload is explicit: never replay a command or refresh an editor automatically.
 */
export class PageBoundary extends Component<{ children: ReactNode }, { failed: boolean; moduleLoad: boolean }> {
  state = { failed: false, moduleLoad: false };
  static getDerivedStateFromError(error: unknown) { return { failed: true, moduleLoad: isModuleLoadError(error) }; }
  render() { return this.state.failed ? <PageLoadFailure moduleLoad={this.state.moduleLoad} /> : this.props.children; }
}
