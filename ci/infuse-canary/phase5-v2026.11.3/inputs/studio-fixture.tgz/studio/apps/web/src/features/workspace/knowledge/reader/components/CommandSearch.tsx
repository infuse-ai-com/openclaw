import { IconButton, Button } from '../../../ui.js';
import { LoadingState } from '../../../loading.js';
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type SubmitEventHandler,
} from 'react';
import type {
  AgentDiscoverMatchReason,
  MeaningSearchResponse,
  MeaningSearchResult,
  Repository,
  SearchResult,
  SemanticReadinessResponse,
} from '@studio/contracts/knowledge';

export type SearchMode = 'keywords' | 'meaning';

interface CommandSearchProps {
  error: string | undefined;
  hasSearched: boolean;
  meaningResponse: MeaningSearchResponse | undefined;
  mode: SearchMode;
  onClose: () => void;
  onModeChange: (mode: SearchMode) => void;
  onOpenMeaningSection: (
    result: MeaningSearchResult,
    section: MeaningSearchResult['sections'][number],
    newTab: boolean,
  ) => void;
  onOpenResult: (result: SearchResult, newTab: boolean) => void;
  onQueryChange: (value: string) => void;
  onRepositoryChange: (repository: string) => void;
  onSearch: SubmitEventHandler<HTMLFormElement>;
  onSearchByMeaning: () => void;
  open: boolean;
  pending: boolean;
  query: string;
  readiness: SemanticReadinessResponse | undefined;
  readinessError: boolean;
  readinessPending: boolean;
  repositories: readonly Repository[];
  repository: string;
  results: readonly SearchResult[];
}

const reasonLabels: Record<AgentDiscoverMatchReason, string> = {
  exact_title: 'Exact title',
  exact_heading: 'Exact heading',
  exact_path: 'Exact path',
  lexical_token_set: 'Keyword set',
  lexical_full_text: 'Keyword match',
  lexical_typo: 'Close spelling',
  semantic_similarity: 'Related by meaning',
};

function meaningTargetKey(
  result: MeaningSearchResult,
  section: MeaningSearchResult['sections'][number],
): string {
  return `${result.repository}:${result.path}:${section.headingId}`;
}

function displayLabel(value: string): string {
  return value
    .split('-')
    .map((part) => `${part.slice(0, 1).toUpperCase()}${part.slice(1)}`)
    .join(' ');
}

function semanticReadinessLabel(
  pending: boolean,
  state: SemanticReadinessResponse['state'] | 'unavailable' | undefined,
): string | undefined {
  if (pending) return 'Checking';
  return state
    ? `${state.slice(0, 1).toUpperCase()}${state.slice(1)}`
    : undefined;
}

function affectedRepositoryCount(
  readiness: SemanticReadinessResponse | undefined,
  state: SemanticReadinessResponse['state'] | 'unavailable' | undefined,
): number {
  if (state === 'updating') return readiness?.repositories.updating ?? 0;
  if (state === 'unavailable') return readiness?.repositories.unavailable ?? 0;
  return 0;
}

function repositoryCountCopy(count: number): string {
  return `${String(count)} ${count === 1 ? 'repository' : 'repositories'}`;
}

export function readinessCopy({
  readiness,
  readinessError,
  readinessPending,
}: Pick<
  CommandSearchProps,
  'readiness' | 'readinessError' | 'readinessPending'
>): { label: string | undefined; status: string } {
  const state = readinessError ? 'unavailable' : readiness?.state;
  const label = semanticReadinessLabel(readinessPending, state);
  const affectedRepositories = affectedRepositoryCount(readiness, state);
  if (readinessPending) {
    return { label, status: 'Checking Meaning readiness…' };
  }
  if (state === 'ready' && readiness) {
    return {
      label,
      status:
        readiness.repositories.selected === 1
          ? 'Meaning ready for this repository.'
          : `Meaning ready for all ${String(readiness.repositories.selected)} repositories.`,
    };
  }
  if (state === 'updating' && affectedRepositories) {
    return {
      label,
      status: `Meaning updating for ${repositoryCountCopy(affectedRepositories)}. Keywords remain available.`,
    };
  }
  if (state === 'unavailable' && affectedRepositories) {
    return {
      label,
      status: `Meaning unavailable for ${repositoryCountCopy(affectedRepositories)}. Keywords remain available.`,
    };
  }
  return {
    label,
    status: 'Meaning readiness unavailable. Keywords remain available.',
  };
}

export function resultStatus(
  props: Pick<
    CommandSearchProps,
    'error' | 'hasSearched' | 'meaningResponse' | 'mode' | 'pending' | 'results'
  >,
  readinessStatus: string,
): string {
  if (props.error) return props.error;
  if (props.pending) {
    return props.mode === 'keywords'
      ? 'Searching the indexed snapshots…'
      : 'Finding keyword and meaning matches…';
  }
  if (!props.hasSearched) {
    return props.mode === 'keywords'
      ? 'Fast, precise search with Git provenance.'
      : readinessStatus;
  }
  if (props.mode === 'keywords') {
    return `${String(props.results.length)} result${props.results.length === 1 ? '' : 's'}`;
  }
  const resultCount = props.meaningResponse?.results.length ?? 0;
  const documentCount = `${String(resultCount)} document${resultCount === 1 ? '' : 's'}`;
  if (props.meaningResponse?.mode === 'lexical_fallback') {
    return `Keywords only · ${documentCount}`;
  }
  return `Meaning + keywords · ${documentCount}`;
}

export function trapSearchFocus(
  event: KeyboardEvent<HTMLDivElement>,
  dialog: HTMLDivElement | null,
  onClose: () => void,
): void {
  if (event.key === 'Escape') {
    event.preventDefault();
    event.stopPropagation();
    onClose();
    return;
  }
  if (event.key !== 'Tab') return;
  const focusable = dialog?.querySelectorAll<HTMLElement>(
    'button:not(:disabled), input:not(:disabled), select:not(:disabled)',
  );
  if (!focusable?.length) return;
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && globalThis.document.activeElement === first) {
    event.preventDefault();
    last?.focus();
  } else if (!event.shiftKey && globalThis.document.activeElement === last) {
    event.preventDefault();
    first?.focus();
  }
}

export function handleResultKey(
  event: KeyboardEvent<HTMLButtonElement>,
  index: number,
  focusResult: (index: number) => void,
  openResult: (newTab: boolean) => void,
): void {
  if (event.key === 'ArrowDown') {
    event.preventDefault();
    focusResult(index + 1);
  } else if (event.key === 'ArrowUp') {
    event.preventDefault();
    focusResult(index - 1);
  } else if (event.key === 'Enter') {
    event.preventDefault();
    openResult(event.metaKey || event.ctrlKey);
  }
}

export function CommandSearch({
  error,
  hasSearched,
  meaningResponse,
  mode,
  onClose,
  onModeChange,
  onOpenMeaningSection,
  onOpenResult,
  onQueryChange,
  onRepositoryChange,
  onSearch,
  onSearchByMeaning,
  open,
  pending,
  query,
  readiness,
  readinessError,
  readinessPending,
  repositories,
  repository,
  results,
}: CommandSearchProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const resultRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const meaningTargets = useMemo(
    () =>
      (meaningResponse?.results ?? []).flatMap((result) =>
        result.sections.map((section) => ({ result, section })),
      ),
    [meaningResponse],
  );
  const meaningTargetIndexes = useMemo(
    () =>
      new Map(
        meaningTargets.map(({ result, section }, index) => [
          meaningTargetKey(result, section),
          index,
        ]),
      ),
    [meaningTargets],
  );
  const targetCount =
    mode === 'keywords' ? results.length : meaningTargets.length;

  useEffect(() => {
    if (!open) return;
    setActiveIndex(0);
    resultRefs.current = [];
    const frame = globalThis.requestAnimationFrame(() => {
      dialogRef.current?.querySelector<HTMLInputElement>('input')?.focus();
    });
    return () => globalThis.cancelAnimationFrame(frame);
  }, [mode, open]);

  useEffect(() => {
    setActiveIndex(0);
    resultRefs.current = [];
  }, [meaningResponse, results]);

  if (!open) return null;

  function focusResult(index: number) {
    if (targetCount === 0) return;
    const next = (index + targetCount) % targetCount;
    setActiveIndex(next);
    resultRefs.current[next]?.focus();
    globalThis.requestAnimationFrame(() => resultRefs.current[next]?.focus());
  }

  const readinessCopyValue = readinessCopy({
    readiness,
    readinessError,
    readinessPending,
  });
  const readinessState = readinessError ? 'unavailable' : readiness?.state;
  const readinessLabel = readinessCopyValue.label;
  const status = resultStatus(
    { error, hasSearched, meaningResponse, mode, pending, results },
    readinessCopyValue.status,
  );

  const empty =
    hasSearched &&
    !pending &&
    (mode === 'keywords'
      ? results.length === 0
      : (meaningResponse?.results.length ?? 0) === 0);

  return (
    <div
      className="command-search-backdrop atlas-scroll-surface"
      onMouseDown={onClose}
    >
      <div
        aria-label="Search the knowledge library"
        aria-modal="true"
        className="command-search-dialog"
        onKeyDown={(event) =>
          trapSearchFocus(event, dialogRef.current, onClose)
        }
        onMouseDown={(event) => event.stopPropagation()}
        ref={dialogRef}
        role="dialog"
      >
        <div className="command-search-heading">
          <div>
            <p className="eyebrow">Find knowledge</p>
            <h2>Search the library</h2>
          </div>
          <IconButton aria-label="Close search" onClick={onClose} type="button">
            Close
          </IconButton>
        </div>
        <div
          aria-label="Search approach"
          className="search-mode-tabs ui-tabs"
          role="tablist"
        >
          {(
            [
              ['keywords', 'Keywords'],
              ['meaning', 'Meaning'],
            ] as const
          ).map(([value, label]) => (
            <button
              aria-label={
                value === 'meaning' && readinessLabel
                  ? `Meaning · ${readinessLabel}`
                  : label
              }
              aria-selected={mode === value}
              key={value}
              onClick={() => onModeChange(value)}
              onKeyDown={(event) => {
                if (
                  event.key === 'ArrowLeft' ||
                  event.key === 'ArrowRight' ||
                  event.key === 'Home' ||
                  event.key === 'End'
                ) {
                  event.preventDefault();
                  onModeChange(
                    event.key === 'ArrowLeft' || event.key === 'Home'
                      ? 'keywords'
                      : 'meaning',
                  );
                }
              }}
              role="tab"
              tabIndex={mode === value ? 0 : -1}
              type="button"
            >
              <span>{label}</span>
              {value === 'meaning' && readinessLabel && (
                <span
                  aria-hidden="true"
                  className={`meaning-readiness-badge is-${readinessState ?? 'checking'}`}
                >
                  {readinessLabel}
                </span>
              )}
            </button>
          ))}
        </div>
        <form className="command-search-form" onSubmit={onSearch} role="search">
          <label className="sr-only" htmlFor="command-search-input">
            Search all documentation
          </label>
          <input className="ui-control"
            autoComplete="off"
            data-search-mode={mode}
            id="command-search-input"
            onChange={(event) => onQueryChange(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'ArrowDown' && targetCount > 0) {
                event.preventDefault();
                focusResult(0);
              }
            }}
            placeholder={
              mode === 'keywords'
                ? 'Search titles, headings, paths, and text'
                : 'Describe what you’re trying to find'
            }
            value={query}
          />
          <label>
            <span className="sr-only">Repository scope</span>
            <select className="ui-control"
              aria-label="Repository scope"
              onChange={(event) => onRepositoryChange(event.target.value)}
              value={repository}
            >
              <option value="">All repositories</option>
              {repositories.map((item) => (
                <option key={item.slug} value={item.slug}>
                  {item.displayName}
                </option>
              ))}
            </select>
          </label>
          <Button disabled={pending || !query.trim()} type="submit">
            {pending ? 'Searching…' : 'Search'}
          </Button>
        </form>

        <div className="command-search-status" aria-live={pending ? 'off' : 'polite'}>
          {pending && targetCount > 0 ? <LoadingState label="Searching knowledge…" size="inline" /> : !pending && status}
        </div>

        <div
          className="command-search-results atlas-scroll-surface"
          role={targetCount ? 'listbox' : undefined}
        >
          {pending && !targetCount && <LoadingState label="Searching knowledge…" size="panel" />}
          {mode === 'keywords' &&
            results.map((result, index) => (
              <button
                aria-label={`Open ${result.repository} ${result.path} ${result.headingPath || 'Document'}`}
                aria-selected={activeIndex === index}
                className="command-search-result"
                key={`${result.repository}:${result.path}:${result.headingId}`}
                onClick={(event) =>
                  onOpenResult(result, event.metaKey || event.ctrlKey)
                }
                onKeyDown={(event) =>
                  handleResultKey(event, index, focusResult, (newTab) =>
                    onOpenResult(result, newTab),
                  )
                }
                ref={(element) => {
                  resultRefs.current[index] = element;
                }}
                role="option"
                tabIndex={activeIndex === index ? 0 : -1}
                type="button"
              >
                <span className="command-result-kind">
                  {result.scoreReason}
                </span>
                <strong>{result.title}</strong>
                <span>{result.headingPath || 'Document'}</span>
                <span>
                  {result.type} · {result.status}
                </span>
                <small>
                  {result.repository} · {result.path} ·{' '}
                  {result.provenance.commit.slice(0, 8)}
                </small>
                <p>{result.description}</p>
              </button>
            ))}
          {mode === 'meaning' &&
            meaningResponse?.results.map((result) => (
              <div
                aria-label={result.title}
                className="meaning-search-result"
                key={`${result.repository}:${result.path}`}
                role="group"
              >
                <div className="meaning-result-heading">
                  <div>
                    <strong>{result.title}</strong>
                    <p>{result.description}</p>
                  </div>
                  <div
                    aria-label="Why this matched"
                    className="meaning-result-reasons"
                  >
                    {result.matchReasons.map((reason) => (
                      <span key={reason}>{reasonLabels[reason]}</span>
                    ))}
                  </div>
                </div>
                <small className="meaning-result-meta">
                  {displayLabel(result.type)} · {displayLabel(result.status)} ·{' '}
                  {displayLabel(result.review.state)} · {result.repository} ·{' '}
                  {result.path} · {result.provenance.commit.slice(0, 8)}
                </small>
                <div className="meaning-result-sections">
                  {result.sections.map((section) => {
                    const index =
                      meaningTargetIndexes.get(
                        meaningTargetKey(result, section),
                      ) ?? 0;
                    return (
                      <button
                        aria-label={`Open ${result.repository} ${result.path} ${section.headingPath}`}
                        aria-selected={activeIndex === index}
                        key={section.headingId}
                        onClick={(event) =>
                          onOpenMeaningSection(
                            result,
                            section,
                            event.metaKey || event.ctrlKey,
                          )
                        }
                        onKeyDown={(event) =>
                          handleResultKey(event, index, focusResult, (newTab) =>
                            onOpenMeaningSection(result, section, newTab),
                          )
                        }
                        ref={(element) => {
                          resultRefs.current[index] = element;
                        }}
                        role="option"
                        tabIndex={activeIndex === index ? 0 : -1}
                        type="button"
                      >
                        <span>{section.headingPath}</span>
                        <p>{section.excerpt}</p>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          {empty && (
            <div className="command-search-empty">
              <strong>
                {mode === 'keywords'
                  ? 'No matching documentation'
                  : 'No related documentation'}
              </strong>
              <p>
                {mode === 'keywords'
                  ? 'Try fewer terms, clear the repository scope, or search by meaning.'
                  : 'Try describing the outcome differently or clear the repository scope.'}
              </p>
              <div className="command-search-empty-actions">
                {mode === 'keywords' && (
                  <button onClick={onSearchByMeaning} type="button">
                    Search by meaning
                  </button>
                )}
                {repository && (
                  <button onClick={() => onRepositoryChange('')} type="button">
                    Search all repositories
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
        <footer className="command-search-footer">
          <span>↑↓ Navigate</span>
          <span>Enter Open</span>
          <span>⌘/Ctrl+Enter New tab</span>
          <span>Esc Close</span>
        </footer>
      </div>
    </div>
  );
}
