import type { GraphNode, KnowledgeGraph } from '@studio/contracts/knowledge';
import { useEffect, useRef, useState, type KeyboardEvent, type PointerEvent } from 'react';
import type { InspectorMode } from './components/GraphInspector';
import {
  clamp,
  graphFitTransform,
  type GraphEntryOrigin,
  type GraphTransform,
  type PositionedNode,
} from './graphLayout';
import type { useGraphSimulation } from './useGraphSimulation';
type DragState =
  | {
      kind: 'pan';
      startX: number;
      startY: number;
      originX: number;
      originY: number;
    }
  | {
      kind: 'node';
      id: string;
      startX: number;
      startY: number;
      moved: boolean;
    };

const DOCUMENT_ENTRY_SCALE = 2.8;
const DOCUMENT_ENTRY_RESUME_RADIUS = 72;

/** Owns viewport, gestures, document entry and focus return; D3 mutation stays in the layout owner. */
export function useGraphInteraction({
  graph,
  visibleGraphNodes,
  simulation,
  focusId,
  centerFocusOnMount,
  onEnter,
}: {
  graph: KnowledgeGraph;
  visibleGraphNodes: GraphNode[];
  simulation: ReturnType<typeof useGraphSimulation>;
  focusId?: string;
  centerFocusOnMount: boolean;
  onEnter(node: GraphNode, origin: GraphEntryOrigin): void;
}) {
  const { layoutNodes, nodeById } = simulation;
  const canvasRef = useRef<HTMLDivElement>(null);
  const graphSvgRef = useRef<SVGSVGElement>(null);
  const dragRef = useRef<DragState | null>(null);
  const entryTimerRef = useRef<ReturnType<typeof globalThis.setTimeout> | undefined>(undefined);
  const lastEntryRef = useRef<{ id: string; pointerX: number; pointerY: number } | undefined>(
    undefined,
  );
  const centeredFocusRef = useRef(false);
  const initialFitRef = useRef(false);
  const [inspectorMode, setInspectorMode] = useState<InspectorMode | 'closed'>('closed');
  const toolsTrigger = useRef<HTMLElement | SVGElement | null>(null);
  const [keyboardId, setKeyboardId] = useState<string>();
  const [hoveredId, setHoveredId] = useState<string>();
  const [previewedId, setPreviewedId] = useState<string | undefined>(focusId);
  const [enteringId, setEnteringId] = useState<string>();
  const [transform, setTransform] = useState<GraphTransform>({
    x: 520,
    y: 360,
    scale: 0.72,
  });
  const [viewport, setViewport] = useState({ width: 1040, height: 720 });
  const [viewportMeasured, setViewportMeasured] = useState(false);
  const [viewMode, setViewMode] = useState<'canvas' | 'list'>(() =>
    globalThis.matchMedia('(max-width: 720px)').matches ? 'list' : 'canvas',
  );

  useEffect(() => {
    if (hoveredId) setPreviewedId(hoveredId);
  }, [hoveredId]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const observer = new ResizeObserver(([entry]) => {
      if (!entry) return;
      setViewport({
        width: Math.max(320, entry.contentRect.width),
        height: Math.max(420, entry.contentRect.height),
      });
      setViewportMeasured(true);
    });
    observer.observe(canvas);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const surface = canvasRef.current?.closest('.studio-knowledge');
    if (surface) {
      let compact: boolean | undefined;
      const observer = new ResizeObserver(([entry]) => {
        if (!entry) return;
        const next = entry.contentRect.width <= 720;
        if (compact !== next) {
          compact = next;
          setViewMode(next ? 'list' : 'canvas');
        }
      });
      observer.observe(surface);
      return () => observer.disconnect();
    }
    const media = globalThis.matchMedia('(max-width: 720px)');
    const update = () => {
      setViewMode(media.matches ? 'list' : 'canvas');
    };
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);

  useEffect(
    () => () => {
      if (entryTimerRef.current) globalThis.clearTimeout(entryTimerRef.current);
    },
    [],
  );

  useEffect(() => {
    if (!centerFocusOnMount || !focusId || !viewportMeasured || centeredFocusRef.current) {
      return;
    }
    const focusNode = nodeById.get(focusId);
    if (!focusNode) return;
    centeredFocusRef.current = true;
    const scale = 1.05;
    setTransform({
      x: viewport.width / 2 - focusNode.x * scale,
      y: viewport.height / 2 - focusNode.y * scale,
      scale,
    });
  }, [centerFocusOnMount, focusId, nodeById, viewport, viewportMeasured]);
  useEffect(() => {
    if (
      centerFocusOnMount ||
      !viewportMeasured ||
      initialFitRef.current ||
      layoutNodes.length === 0
    ) {
      return;
    }
    const next = graphFitTransform(layoutNodes, viewport);
    if (!next) return;
    initialFitRef.current = true;
    setTransform(next);
  }, [centerFocusOnMount, layoutNodes, viewport, viewportMeasured]);

  function fitGraph(nodes: PositionedNode[] = layoutNodes) {
    const next = graphFitTransform(nodes, viewport);
    if (next) setTransform(next);
  }

  function zoomAt(factor: number, x = viewport.width / 2, y = viewport.height / 2) {
    setTransform((current) => {
      const scale = clamp(current.scale * factor, 0.2, 3.2);
      const worldX = (x - current.x) / current.scale;
      const worldY = (y - current.y) / current.scale;
      return {
        x: x - worldX * scale,
        y: y - worldY * scale,
        scale,
      };
    });
  }

  function handleWheel(event: globalThis.WheelEvent) {
    event.preventDefault();
    event.stopPropagation();
    if ((event.target as Element).closest('.graph-toolbar')) return;
    const bounds = canvasRef.current?.getBoundingClientRect();
    if (!bounds) return;
    const factor = Math.exp(-event.deltaY * 0.0012);
    const nextScale = clamp(transform.scale * factor, 0.2, 3.2);
    const pointerX = event.clientX - bounds.left;
    const pointerY = event.clientY - bounds.top;
    const pointerWorldX = (pointerX - transform.x) / transform.scale;
    const pointerWorldY = (pointerY - transform.y) / transform.scale;
    let pointerNode: PositionedNode | undefined;
    let pointerNodeDistance = Number.POSITIVE_INFINITY;
    for (const node of layoutNodes) {
      const distance = Math.hypot(node.x - pointerWorldX, node.y - pointerWorldY);
      if (distance <= node.radius + 4 && distance < pointerNodeDistance) {
        pointerNode = node;
        pointerNodeDistance = distance;
      }
    }
    const lastEntry = lastEntryRef.current;
    const resumeNode =
      lastEntry &&
      Math.hypot(pointerX - lastEntry.pointerX, pointerY - lastEntry.pointerY) <=
        DOCUMENT_ENTRY_RESUME_RADIUS
        ? nodeById.get(lastEntry.id)
        : undefined;
    const entryNode =
      pointerNode ?? (hoveredId ? nodeById.get(hoveredId) : undefined) ?? resumeNode;
    if (factor > 1 && nextScale >= DOCUMENT_ENTRY_SCALE && entryNode && !enteringId) {
      lastEntryRef.current = { id: entryNode.id, pointerX, pointerY };
      setEnteringId(entryNode.id);
      setTransform({
        x: pointerX - entryNode.x * 3.2,
        y: pointerY - entryNode.y * 3.2,
        scale: 3.2,
      });
      entryTimerRef.current = globalThis.setTimeout(() => {
        onEnter(entryNode, { x: pointerX, y: pointerY });
        setEnteringId(undefined);
      }, 270);
      return;
    }
    zoomAt(factor, event.clientX - bounds.left, event.clientY - bounds.top);
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.addEventListener('wheel', handleWheel, { passive: false });
    return () => canvas.removeEventListener('wheel', handleWheel);
  });

  function handlePointerDown(event: PointerEvent<HTMLDivElement>) {
    if (event.target !== graphSvgRef.current) return;
    lastEntryRef.current = undefined;
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      kind: 'pan',
      startX: event.clientX,
      startY: event.clientY,
      originX: transform.x,
      originY: transform.y,
    };
  }

  function handleNodePointerDown(event: PointerEvent<SVGGElement>, node: PositionedNode) {
    event.stopPropagation();
    if (lastEntryRef.current?.id !== node.id) {
      lastEntryRef.current = undefined;
    }
    canvasRef.current?.setPointerCapture(event.pointerId);
    simulation.startDrag(node.id);
    dragRef.current = {
      kind: 'node',
      id: node.id,
      startX: event.clientX,
      startY: event.clientY,
      moved: false,
    };
  }

  function handlePointerMove(event: PointerEvent<HTMLDivElement>) {
    const drag = dragRef.current;
    if (!drag) return;
    if (drag.kind === 'pan') {
      setTransform((current) => ({
        ...current,
        x: drag.originX + event.clientX - drag.startX,
        y: drag.originY + event.clientY - drag.startY,
      }));
      return;
    }
    const bounds = canvasRef.current?.getBoundingClientRect();
    if (!bounds) return;
    drag.moved ||= Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY) > 4;
    simulation.moveDrag(
      drag.id,
      (event.clientX - bounds.left - transform.x) / transform.scale,
      (event.clientY - bounds.top - transform.y) / transform.scale,
    );
  }

  function handlePointerUp(event: PointerEvent<HTMLDivElement>) {
    const drag = dragRef.current;
    dragRef.current = null;
    if (canvasRef.current?.hasPointerCapture(event.pointerId)) {
      canvasRef.current.releasePointerCapture(event.pointerId);
    }
    simulation.endDrag();
    if (drag?.kind === 'node' && !drag.moved) {
      const node = graph.nodes.find((candidate) => candidate.id === drag.id);
      if (node) {
        toolsTrigger.current =
          graphSvgRef.current?.querySelector<HTMLElement>(
            `[data-node-id="${CSS.escape(node.id)}"]`,
          ) ?? null;
        setPreviewedId(node.id);
        setInspectorMode('preview');
      }
    }
  }

  function handleNodeKey(event: KeyboardEvent<SVGGElement>, node: GraphNode) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      toolsTrigger.current = event.currentTarget;
      setPreviewedId(node.id);
      setInspectorMode('preview');
    } else if (
      ['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp', 'Home', 'End'].includes(event.key)
    ) {
      event.preventDefault();
      const index = visibleGraphNodes.findIndex((value) => value.id === node.id);
      const next =
        event.key === 'Home'
          ? 0
          : event.key === 'End'
            ? visibleGraphNodes.length - 1
            : (index +
                (['ArrowLeft', 'ArrowUp'].includes(event.key) ? -1 : 1) +
                visibleGraphNodes.length) %
              visibleGraphNodes.length;
      const id = visibleGraphNodes[next]?.id;
      if (id) {
        setKeyboardId(id);
        graphSvgRef.current
          ?.querySelector<HTMLElement>(`[data-node-id="${CSS.escape(id)}"]`)
          ?.focus();
      }
    }
  }

  const keyboardFocusId =
    visibleGraphNodes.find((node) => node.id === keyboardId)?.id ||
    visibleGraphNodes.find((node) => node.id === focusId)?.id ||
    visibleGraphNodes[0]?.id;
  function closeTools() {
    setInspectorMode('closed');
    if (viewMode === 'list') setViewMode('canvas');
    requestAnimationFrame(() => toolsTrigger.current?.focus());
  }
  function openTools(mode: InspectorMode) {
    toolsTrigger.current = globalThis.document.activeElement as HTMLElement;
    setInspectorMode((current) => (current === mode ? 'closed' : mode));
  }
  useEffect(() => {
    const escape = (event: globalThis.KeyboardEvent) => {
      if (
        event.defaultPrevented ||
        event.key !== 'Escape' ||
        inspectorMode === 'closed' ||
        !(event.target instanceof Node) ||
        !graphSvgRef.current?.closest('.knowledge-graph')?.contains(event.target)
      )
        return;
      event.preventDefault();
      closeTools();
    };
    window.addEventListener('keydown', escape, true);
    return () => window.removeEventListener('keydown', escape, true);
  }, [inspectorMode, viewMode]);
  return {
    canvasRef,
    graphSvgRef,
    inspectorMode,
    setInspectorMode,
    hoveredId,
    setHoveredId,
    previewedId,
    enteringId,
    transform,
    viewMode,
    setViewMode,
    keyboardFocusId,
    fitGraph,
    zoomAt,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
    handleNodePointerDown,
    handleNodeKey,
    closeTools,
    openTools,
  };
}
