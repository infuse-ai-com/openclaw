import { PageHeader, Button, EmptyState, ViewSwitch } from './ui.js';
import { companyNavigation } from './company-navigation.js';
import {useEffect,useMemo,useRef,useState} from 'react';
import {useQuery,useQueryClient} from '@tanstack/react-query';
import {Link,useNavigate} from './navigation.js';
import {useLocation} from 'react-router';
import {parseAppsSession,missionIdentifier,type AppsSession,type AppLink} from '@studio/contracts';
import {useAppearance} from './appearance.js';
import {LoginEntrance} from './entrance.js';
import {LoadingState} from './loading.js';
import {MyAppIcon} from './my-app-icon.js';
import {MyAppsLaunchpad} from './my-apps-launchpad.js';
import mark from '../../../../../packages/ui/assets/INFUSE_favicon.ico';
import './my-apps.css';
const loginUrl='/api/auth/login?returnTo=%2Fapps';
type AppsRead=AppsSession|{unavailable:true};
async function loadApps(signal:AbortSignal):Promise<AppsRead>{
 try{
  const r=await fetch('/api/apps',{credentials:'same-origin',cache:'no-store',signal:AbortSignal.any([signal,AbortSignal.timeout(15000)])});
  if(r.status===401||r.status===403)return {authenticated:false,loginUrl};
  if(!r.ok)return {unavailable:true};return parseAppsSession(await r.json());
 }catch(error){if(signal.aborted)throw error;return {unavailable:true};}
}
function hostname(url:string){try{return url.startsWith('/')?url:new URL(url).hostname;}catch{return '';}}
export function appsLoginUrl(search:string){
 let returnTo='/apps';try{const project=new URLSearchParams(search).get('project');if(project&&encodeURIComponent(missionIdentifier(project))===project)returnTo+='?project='+project;}catch{/* Invalid project hints grant no access. */}
 return '/api/auth/login?'+new URLSearchParams({returnTo});
}
export function MyApps({onWorkspaceAvailable,embedded=false,suspended=false}:{onWorkspaceAvailable?:()=>void;embedded?:boolean;suspended?:boolean}){
 const appearance=useAppearance(),navigate=useNavigate(),client=useQueryClient(),location=useLocation();
 const loginUrl=appsLoginUrl(location.search);
 const resultsList=useRef<HTMLUListElement>(null);
 const [search,setSearch]=useState(''),[active,setActive]=useState(0),[expanded,setExpanded]=useState(false),[signingOut,setSigningOut]=useState(false),[logoutError,setLogoutError]=useState('');
 // The admission-to-workspace handoff reuses this read; unobserved data is still discarded immediately.
 const query=useQuery({enabled:!suspended,queryKey:['my-apps'],queryFn:({signal})=>loadApps(signal),refetchInterval:7000,refetchOnWindowFocus:true,refetchOnMount:false,gcTime:0,staleTime:0});
 const session=query.data&&'authenticated' in query.data&&query.data.authenticated?query.data:undefined;
 const matches=useMemo(()=>{
  const q=search.trim().toLowerCase();if(!q||!session)return [];
  const rank=(a:AppLink)=>a.name.toLowerCase().startsWith(q)?0:a.name.toLowerCase().includes(q)?1:2;
  return session.apps.filter(a=>`${a.name} ${a.description} ${a.category} ${a.url}`.toLowerCase().includes(q))
   .sort((a,b)=>rank(a)-rank(b)||a.category.localeCompare(b.category)||a.name.localeCompare(b.name));
 },[session,search]);
 const results=useMemo(()=>matches.slice(0,12),[matches]);
 useEffect(()=>{if(session?.workspaceAvailable)onWorkspaceAvailable?.();},[session?.workspaceAvailable,onWorkspaceAvailable]);
 useEffect(()=>{
  const list=resultsList.current,option=list?.children[active];
  if(!expanded||!list||!option)return;
  const bounds=list.getBoundingClientRect(),row=option.getBoundingClientRect();
  const top=bounds.top+list.clientTop,bottom=top+list.clientHeight;
  // Scroll only the popup, preserving the page and its input position.
  if(row.top<top)list.scrollTop-=top-row.top;
  else if(row.bottom>bottom)list.scrollTop+=row.bottom-bottom;
 },[active,expanded,results]);
 function openApp(app:AppLink){setExpanded(false);setSearch('');if(app.url.startsWith('/'))navigate(app.url);else window.open(app.url,'_blank','noopener,noreferrer');}
 async function logout(){
  if(!session)return;setSigningOut(true);setLogoutError('');
  client.setQueryData(['my-apps'],{authenticated:false,loginUrl});
  try{const response=await fetch('/api/apps/logout',{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json','x-csrf-token':session.csrfToken},body:'{}'});if(!response.ok)throw Error('Sign-out was not confirmed.');}
  catch{setLogoutError('Sign-out could not be confirmed. Check your connection and try again.');}
  finally{setSigningOut(false);await query.refetch();}
 }
 if(!query.data||signingOut||suspended||session?.workspaceAvailable&&onWorkspaceAvailable)return embedded?<LoadingState label={suspended?'Signing out…':'Opening My Apps…'} size="page"/>: <div className="ws-app studio-workbench" data-studio-theme={appearance.theme}><LoadingState label={signingOut?'Signing out…':'Opening My Apps…'} size="page" /></div>;
 if('unavailable' in query.data){
  const Region=embedded?'section':'main';
  return <div className={embedded?'apps-content':'ws-entry studio-workbench'} data-studio-theme={appearance.theme}><Region aria-label="My Apps unavailable"><h1>My Apps is unavailable.</h1><p>Your app access could not be refreshed. No saved app links are shown.</p><Button onClick={()=>void query.refetch()}>Try again</Button></Region></div>;
 }
 if(!session)return <LoginEntrance pending={query.isFetching} online={navigator.onLine} error="" retry={()=>void query.refetch()} loginUrl={loginUrl}/>;
 const destinations=session.workspaceAvailable?companyNavigation.map(([to,name])=>[to,name] as const):[['/apps','My Apps']] as const;
 const quickLaunch=session.status==='ready'?<div className="apps-launch"><label htmlFor="apps-search">Quick launch</label><input className="ui-control" id="apps-search" role="combobox" aria-autocomplete="list" aria-expanded={expanded&&!!search.trim()} aria-controls={expanded&&!!search.trim()?'apps-results':undefined} aria-describedby={expanded&&!!search.trim()?'apps-search-status':undefined} aria-activedescendant={expanded&&results[active]?`app-result-${active}`:undefined} autoComplete="off" placeholder="Find an app, then press Enter" value={search} onChange={e=>{setSearch(e.target.value);setActive(0);setExpanded(true);}} onFocus={()=>setExpanded(true)} onBlur={()=>setExpanded(false)} onKeyDown={e=>{
    if(e.key==='Escape'){setExpanded(false);setSearch('');}
    if(e.key==='ArrowDown'){e.preventDefault();setExpanded(true);setActive(n=>Math.min(n+1,Math.max(0,results.length-1)));}
    if(e.key==='ArrowUp'){e.preventDefault();setActive(n=>Math.max(0,n-1));}
    if(e.key==='Enter'){e.preventDefault();const app=results[active]??results[0];if(app)openApp(app);}
   }}/>{expanded&&!!search.trim()&&<div className="apps-search-popover"><p id="apps-search-status" className="apps-search-status" role="status">{matches.length>results.length?`Showing ${results.length} of ${matches.length} matches. Refine your search to see more.`:`${matches.length} matching ${matches.length===1?'app':'apps'}.`}</p><ul ref={resultsList} tabIndex={-1} id="apps-results" role="listbox" aria-label="Matching apps">{results.map((a,i)=><li id={`app-result-${i}`} key={a.id} role="option" aria-selected={i===active}><button tabIndex={-1} onMouseDown={e=>e.preventDefault()} onMouseEnter={()=>setActive(i)} onClick={()=>openApp(a)}><MyAppIcon name={a.icon} accent={a.accent}/><strong>{a.name}</strong><span>{a.category} · {hostname(a.url)}</span></button></li>)}{!results.length&&<li role="presentation">No matching apps</li>}</ul></div>}</div>:null;
 const content=<section id="apps-main" tabIndex={-1} className="apps-main" aria-label="My Apps"><PageHeader className="apps-header" eyebrow="Your workspace" title="My Apps" metadata={<span className="apps-count">{session.apps.length} apps available to you</span>} description="Your tools and services, organized in one place." actions={quickLaunch} />

   <div className="apps-content">{logoutError&&<p className="ws-alert" role="alert">{logoutError}</p>}
   {session.status!=='ready'?<EmptyState level={2} title={<>{session.status==='expired'?'App access needs refreshing.':'Your apps are not connected yet.'}</>}  actions={<><Button onClick={()=>void query.refetch()}>Check again</Button></>}>An administrator needs to refresh your app access. Your Studio workspace permissions are separate.</EmptyState>:<>

   {!session.apps.length&&<EmptyState level={2} title={<>No apps available.</>}  >There are no active apps for your current access.</EmptyState>}
   {!!session.apps.length&&<MyAppsLaunchpad key={session.profileId} profileId={session.profileId} apps={session.apps} categories={session.categories}/>}
   </>}
   </div>
  </section>;
 if(embedded)return content;
 return <div className="ws-app studio-workbench apps-portal" data-studio-theme={appearance.theme}>
  <a className="ws-skip" href="#apps-main">Skip to My Apps</a>
  <aside className="apps-side" aria-label="Studio navigation"><Link to={session.workspaceAvailable?'/desk':'/apps'} className="apps-brand"><img src={mark} alt=""/><strong>INFUSE</strong><span>/ Studio</span></Link>
   <nav aria-label={session.workspaceAvailable?'Company navigation':'Your navigation'}>{destinations.map(([to,label])=><Link key={to} to={to!} aria-current={to==='/apps'?'page':undefined}>{label}</Link>)}</nav>
   <div className="apps-account"><p>{session.displayName}</p><ViewSwitch<'light' | 'dark' | 'system'> segmented className="apps-theme" label="Appearance" value={appearance.preference} onChange={appearance.setPreference} options={[['light','Light'],['dark','Dark'],['system','System']]} /><Button variant="quiet" onClick={()=>void logout()}>Sign out</Button></div>
  </aside>
{content}</div>;
}
