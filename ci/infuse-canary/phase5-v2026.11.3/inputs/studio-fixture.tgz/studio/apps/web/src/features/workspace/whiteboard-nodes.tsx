import { useLayoutEffect } from 'react';
import {
  Handle,
  NodeResizer,
  Position,
  useUpdateNodeInternals,
  type NodeProps,
} from '@xyflow/react';
import { whiteboardConnectable, whiteboardNoteColors } from '@studio/contracts';
import type { BlockNode } from './whiteboard-types.js';
import { BoardIcon } from './whiteboard-icon.js';
import { BlockEditor } from './whiteboard-editing.js';
import { StrokeGraphic } from './whiteboard-drawing.js';
import { ShapeLabelEditor } from './whiteboard-shape-label.js';
import { ImageTile } from './whiteboard-images.js';
import { SectionPreview } from './whiteboard-section-preview.js';
import { HtmlTile } from './whiteboard-tiles.js';
import { NoteTextFit } from './whiteboard-note-fit.js';
import { LoadingState } from './loading.js';
function Card(props: NodeProps<BlockNode>) {
  const { data } = props;
  const updateInternals = useUpdateNodeInternals();
  const connectable = whiteboardConnectable(data.block);
  useLayoutEffect(() => {
    updateInternals(props.id);
  }, [props.id, connectable, updateInternals]);
  return (
    <>
      {whiteboardConnectable(data.block) && (
        <Handle type="target" position={Position.Left} isConnectable={data.enabled} />
      )}
      <CardBody {...props} />
      {whiteboardConnectable(data.block) && (
        <Handle type="source" position={Position.Right} isConnectable={data.enabled} />
      )}
    </>
  );
}
function CardBody({ data, selected }: NodeProps<BlockNode>) {
  if (data.block.kind === 'stroke')
    return (
      <>
        <NodeResizer
          isVisible={selected && data.enabled}
          minWidth={1}
          minHeight={1}
          maxWidth={4000}
          maxHeight={4000}
          onResizeStart={data.resizeStart}
          onResizeEnd={(_event, bounds) => data.resize(data.block, bounds)}
        />
        <StrokeGraphic stroke={data.editing ? { ...data.block, label: '' } : data.block} />
        {data.editing && data.block.shape && (
          <ShapeLabelEditor
            block={data.block}
            drafts={data.drafts}
            sectionId={data.sectionId}
            shared={!!data.shared}
            enabled={data.editable}
            changed={data.onDraftChange}
          />
        )}
      </>
    );
  if (data.block.kind === 'image')
    return (
      <article className="wboard-card wboard-card--image">
        <NodeResizer
          isVisible={selected && data.enabled}
          keepAspectRatio
          minWidth={16}
          minHeight={16}
          maxWidth={4000}
          maxHeight={4000}
          onResizeStart={data.resizeStart}
          onResizeEnd={(_event, bounds) => data.resize(data.block, bounds)}
        />
        <ImageTile
          tile={data.block}
          path={data.path}
          visible={data.loaded}
          inspect={data.options}
          enabled={data.enabled}
          commit={data.commit}
        />
      </article>
    );
  if (data.block.kind === 'section' || data.block.kind === 'html')
    return (
      <article className={'wboard-card wboard-card--' + data.block.kind}>
        <NodeResizer
          isVisible={selected && data.enabled}
          minWidth={160}
          minHeight={160}
          maxWidth={4000}
          maxHeight={4000}
          onResizeStart={data.resizeStart}
          onResizeEnd={(_event, bounds) => data.resize(data.block, bounds)}
        />
        {data.block.kind === 'section' ? (
          <>
            <header className="wboard-section-heading">
              <span className="wboard-card-kind">Section</span>
              <h2>{data.block.title}</h2>
            </header>
            {data.previewSection ? (
              <SectionPreview
                id={data.block.id}
                title={data.block.title}
                path={data.path}
                revision={data.boardRevision}
              />
            ) : (
              <div className="wboard-section-preview">
                <span className="wboard-section-preview-message">Move closer to preview</span>
              </div>
            )}
            <footer className="wboard-section-footer">
              <span>
                {data.sectionCount === undefined
                  ? 'Explore this space'
                  : `${data.sectionCount} ${data.sectionCount === 1 ? 'item' : 'items'} inside`}
              </span>
              <button
                className="nodrag nopan"
                onClick={(e) => {
                  e.stopPropagation();
                  data.enter();
                }}
              >
                <span>Enter section</span>
                <BoardIcon name="enter" />
              </button>
            </footer>
          </>
        ) : (
          <HtmlTile
            tile={data.block}
            path={data.path}
            enabled={data.editable && data.loaded}
            active={data.activeHtml}
            canActivate={data.canActivateHtml}
            activate={data.activateHtml}
            engage={data.engageHtml}
            inspect={data.options}
          />
        )}
      </article>
    );
  const bodyText = data.loaded
    ? data.block.text || 'Select this block to start writing.'
    : 'Zoom in or select to load this block.';
  return (
    <article
      style={
        data.block.kind === 'note' && data.block.noteColor
          ? { background: whiteboardNoteColors[data.block.noteColor], color: '#283342' }
          : undefined
      }
      className={
        'wboard-card wboard-card--' +
        data.block.kind +
        (data.editing ? ' wboard-card--editing' : '')
      }
    >
      <NodeResizer
        isVisible={selected && data.enabled}
        minWidth={160}
        minHeight={160}
        maxWidth={4000}
        maxHeight={4000}
        onResizeStart={data.resizeStart}
        onResizeEnd={(_event, bounds) => data.resize(data.block, bounds)}
      />
      <span className="wboard-card-kind">{data.block.kind}</span>
      {data.commentCount > 0 && (
        <button
          className="wboard-comment-badge nodrag nopan"
          type="button"
          aria-label={`${data.commentCount} open ${data.commentCount === 1 ? 'comment' : 'comments'}`}
          onClick={(event) => {
            event.stopPropagation();
            data.comments();
          }}
        >
          <BoardIcon name="note" />
          {data.commentCount}
        </button>
      )}
      {data.editing && data.loaded ? (
        <BlockEditor
          seed={data.block}
          saved={data.block}
          enabled={data.editable}
          canSave={data.canSave}
          sectionId={data.sectionId}
          autoFocus={data.autoFocus}
          commit={data.commit}
          drafts={data.drafts}
          onDraftChange={data.onDraftChange}
          mode="inline"
          options={data.options}
          shared={data.shared}
        />
      ) : (
        <>
          <h2>{data.block.title || 'Untitled'}</h2>
          {data.loading && !data.loaded ? (
            <LoadingState label="Loading block…" size="panel" />
          ) : data.block.kind === 'note' ? (
            <NoteTextFit text={bodyText}>
              <p>{bodyText}</p>
            </NoteTextFit>
          ) : (
            <p>{bodyText}</p>
          )}
        </>
      )}
    </article>
  );
}
export const nodeTypes = { block: Card, stroke: Card };
