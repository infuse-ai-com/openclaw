import { Link as RouterLink, NavLink as RouterNavLink, useNavigate as routerNavigate, useLocation, type LinkProps, type NavLinkProps, type NavigateOptions, type To } from 'react-router';

function scoped(to: To, search: string): To {
  const project = new URLSearchParams(search).get('project');
  if (!project) return to;
  if (typeof to === 'string') {
    if (/^[a-z]+:|^\/\//i.test(to)) return to;
    const hashAt = to.indexOf('#'); const hash = hashAt < 0 ? '' : to.slice(hashAt);
    const path = hashAt < 0 ? to : to.slice(0, hashAt); const split = path.indexOf('?');
    const params = new URLSearchParams(split < 0 ? '' : path.slice(split + 1));
    if (!params.has('project')) params.set('project', project);
    return `${split < 0 ? path : path.slice(0, split)}?${params}${hash}`;
  }
  const params = new URLSearchParams(to.search);
  if (!params.has('project')) params.set('project', project);
  return { ...to, search: `?${params}` };
}
export function Link(props: LinkProps) { const { search } = useLocation(); return <RouterLink {...props} to={scoped(props.to, search)} />; }
export function NavLink(props: NavLinkProps) { const { search } = useLocation(); return <RouterNavLink {...props} to={scoped(props.to, search)} />; }
export function useNavigate() {
  const navigate = routerNavigate(); const { search } = useLocation();
  return (to: To | number, options?: NavigateOptions) => typeof to === 'number' ? navigate(to) : navigate(scoped(to, search), options);
}

/** Project changes preserve a collection/global view, never a foreign detail or its filters. */
export function projectDestination(pathname: string, projectId: string, _knowledgeOnly = false): string {
  const requested = pathname;
  const path = requested.startsWith('/missions/') ? '/missions' : requested.startsWith('/artifacts/') ? '/artifacts' : requested === '/' ? '/desk' : requested;
  return `${path}?${new URLSearchParams({ project: projectId })}`;
}
