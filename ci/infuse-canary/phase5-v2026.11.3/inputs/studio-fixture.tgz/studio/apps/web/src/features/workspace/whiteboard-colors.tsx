import { Button } from './ui.js';
import { whiteboardNoteColors, type WhiteboardBlock } from '@studio/contracts';
export function NoteColors({
  value,
  compact = false,
  disabled,
  choose,
}: {
  value?: WhiteboardBlock['noteColor'];
  compact?: boolean;
  disabled: boolean;
  choose(color: NonNullable<WhiteboardBlock['noteColor']>): void;
}) {
  return (
    <div
      className={'wboard-note-colors' + (compact ? ' wboard-note-colors--compact' : '')}
      role="group"
      aria-label="Note color"
    >
      {Object.entries(whiteboardNoteColors).map(([key, color]) => (
        <Button variant="quiet" className={compact ? 'ui-icon-button' : undefined}
          type="button"
          key={key}
          disabled={disabled}
          aria-label={'Note color ' + key}
          aria-pressed={value === key}
          title={key}
          onClick={() => choose(key as NonNullable<WhiteboardBlock['noteColor']>)}
        >
          <span style={{ background: color }} aria-hidden="true" />
          <span>{key}</span>
        </Button>
      ))}
    </div>
  );
}
