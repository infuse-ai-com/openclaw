import type { Repository } from '@studio/contracts/knowledge';

export function repositoryHealthLabel(repository: Repository): string {
  const indexing = repository.indexing;
  return indexing?.excludedCount && !indexing.refreshError
    ? `${String(indexing.excludedCount)} excluded`
    : repository.health;
}

function issueReason(code: string): string {
  if (code === 'ikf_frontmatter_missing')
    return 'Required document metadata is missing.';
  if (code === 'ikf_frontmatter_invalid')
    return 'Document metadata is invalid.';
  if (code === 'document_too_large') return 'Document exceeds the size limit.';
  return 'Document could not be safely parsed.';
}

export function RepositoryIndexingNotice({
  repository,
}: {
  repository: Repository;
}) {
  const indexing = repository.indexing;
  if (!indexing?.excludedCount) return null;
  return (
    <details className="repository-indexing-notice">
      <summary>
        {indexing.excludedCount}{' '}
        {indexing.excludedCount === 1 ? 'document' : 'documents'} excluded
      </summary>
      <p>
        {indexing.refreshError
          ? 'The latest refresh failed. The retained index also excludes these documents.'
          : 'Valid documents were refreshed. These documents are excluded from reading, search and Explore until corrected.'}
      </p>
      <ul>
        {indexing.issues.map((issue) => (
          <li key={issue.path}>
            <code>{issue.path}</code>
            <span>{issueReason(issue.code)}</span>
          </li>
        ))}
      </ul>
      {indexing.excludedCount > indexing.issues.length && (
        <p>
          Showing the first {indexing.issues.length} of {indexing.excludedCount}{' '}
          findings. Run the source repository’s knowledge check for the full
          report.
        </p>
      )}
    </details>
  );
}
