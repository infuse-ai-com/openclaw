import { ViewSwitch, PageHeader, Button, IconButton, EmptyState } from './ui.js';
import { ArtifactFiles } from './artifact-files.js';
import { ArtifactUndo, useArtifactSession } from './artifact-session.js';
import { ArtifactReader } from './artifact-reader.js';
import { ArtifactDate, ArtifactIcon, ArtifactSymbol, ArtifactVersion } from './artifact-ui.js';
import { ArtifactRetainedHistory } from './artifact-retained.js';
import { ArtifactLifecyclePanel, ArtifactLifecycleRecovery, useArtifactLifecycleController } from './artifact-lifecycle.js';
import { LoadingState } from './loading.js';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';
import { useLocation, useParams, useSearchParams } from 'react-router';
import { Link, useNavigate } from './navigation.js';
import { artifactViewerPath, type ArtifactPage, type ArtifactDetail, type ArtifactManifest } from '@studio/contracts';
import { api, projectPath, readableError } from './api.js';
import { useWorkspace } from './context.js';
import './artifacts.css';

const identity = (producer: string, id: string, revision: string) => `${encodeURIComponent(producer)}/${encodeURIComponent(id)}/${encodeURIComponent(revision)}`;
type Selection = { producer: string; artifactId: string; revision: string };
type LifecycleController = ReturnType<typeof useArtifactLifecycleController>;
function parsePage(value: unknown): ArtifactPage {
  const page = value as ArtifactPage;
  if (!page || !Array.isArray(page.artifacts) || page.artifacts.some(m => !m || m.schema !== 'infuse.artifact/v1' || !Array.isArray(m.files))
    || page.nextCursor !== null && (typeof page.nextCursor !== 'string' || !/^[1-9][0-9]{0,3}$/.test(page.nextCursor) || Number(page.nextCursor) > 1000)) throw Error('Studio returned an invalid artifact page.');
  return page;
}

export function ArtifactLibrary() {
  const { owner, session, current, visible } = useWorkspace();
  const { controller: lifecycle, visit, saved } = useArtifactSession(), location = useLocation();
  const [returning, setReturning] = useState(visit);
  const [search, setSearch] = useState(visit?.search ?? ''), [settledSearch, setSettledSearch] = useState(visit?.search.trim() ?? ''), [scope, setScope] = useState(visit?.scope ?? 'all');
  const [preview, setPreview] = useState<Selection>();
  const trigger = useRef<HTMLButtonElement | null>(null);
  const restoreFocus = useRef(false);
  const [params, setParams] = useSearchParams(), missionId = params.get('mission'), bin = params.get('view') === 'bin';
  useEffect(() => { const timer = setTimeout(() => setSettledSearch(search.trim()), 200); return () => clearTimeout(timer); }, [search]);
  useEffect(() => setPreview(undefined), [settledSearch, scope, missionId, bin]);
  useLayoutEffect(() => {
    if (!preview && restoreFocus.current) { restoreFocus.current = false; trigger.current?.focus(); }
  }, [preview]);
  const query = useInfiniteQuery({
    queryKey: ['workspace', owner, 'artifacts', bin ? 'bin' : 'active', settledSearch, scope, missionId], enabled: current,
    initialPageParam: undefined as string | undefined,
    queryFn: async ({ signal, pageParam }) => {
      const filters = new URLSearchParams({ scope, ...(settledSearch ? { q: settledSearch } : {}), ...(missionId ? { mission: missionId } : {}), ...(pageParam ? { cursor: pageParam } : {}) });
      const page = parsePage(await api(projectPath(`${bin ? '/api/studio/artifact-lifecycle/bin' : '/api/studio/artifacts'}?${filters}`, session.project.id), { signal }));
      if (page.nextCursor !== null && Number(page.nextCursor) <= Number(pageParam ?? 0)) throw Error('Studio returned an artifact page that did not advance.');
      return page;
    },
    getNextPageParam: page => page.nextCursor ?? undefined, refetchOnWindowFocus: visible,
  });
  const all = [...new Map((query.data?.pages.flatMap(p => p.artifacts) ?? []).map(m => [`${m.producer}/${m.artifactId}`, m])).values()];
  useLayoutEffect(() => {
    if (!returning || !current || !query.data || query.isError || query.isFetching) return;
    if (query.hasNextPage && query.data.pages.length < returning.pages && !query.isFetchNextPageError) { void query.fetchNextPage(); return; }
    const links = document.querySelectorAll<HTMLAnchorElement>('.ws-artifact-row h2 a');
    (Array.from(links).find(link => link.pathname === returning.path) ?? links[Math.min(returning.row, links.length - 1)])?.focus({ preventScroll: true });
    window.scrollTo(0, returning.scroll);
    setReturning(undefined);
  }, [returning, current, query.data, query.isError, query.isFetching, query.hasNextPage, query.isFetchNextPageError, query.fetchNextPage]);
  const selected = preview && all.some(m => m.producer === preview.producer && m.artifactId === preview.artifactId) ? preview : undefined;
  const filtered = !!settledSearch || scope !== 'all' || !!missionId;
  function clearFilters() {
    setSearch(''); setSettledSearch(''); setScope('all');
    setParams(previous => { const next = new URLSearchParams(previous); next.delete('mission'); return next; });
  }
  function closePreview() {
    restoreFocus.current = true;
    setPreview(undefined);
  }
  const status = query.isPending || search.trim() !== settledSearch ? 'Searching…' : query.isError ? 'Unavailable'
    : `${all.length} matching ${all.length === 1 ? 'artifact' : 'artifacts'}${query.hasNextPage ? ' loaded' : ''}`;
  return <section className="ws-surface ws-artifact-library" aria-label="Artifact library" onClickCapture={event => {
    const link = (event.target as Element).closest<HTMLAnchorElement>('a[href]');
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || !link || !link.pathname.startsWith('/artifacts/')) return;
    const row = Array.from(event.currentTarget.querySelectorAll('.ws-artifact-row')).indexOf(link.closest('.ws-artifact-row') ?? event.currentTarget.querySelector('.ws-artifact-row[data-selected=true]')!);
    saved.current = { key:location.key, url:location.pathname+location.search, search, scope, path:link.pathname, scroll:window.scrollY, pages:query.data?.pages.length ?? 1, row:Math.max(0,row) };
  }}>
    <PageHeader eyebrow={session.project.name} title="Artifacts" description="Published work, ready to explore." actions={
      <Button variant="quiet" disabled={!current || query.isFetching} onClick={() => void query.refetch()}><ArtifactIcon name="refresh" />Refresh</Button>
    } />
    <div className="ws-artifact-library-tools">
      <ViewSwitch className="ws-artifact-view-switch" label="Artifact view" value={bin ? 'bin' : 'active'}
        options={[["active", <><ArtifactIcon name="folder" />Active artifacts</>], ["bin", <><ArtifactIcon name="trash" />Artifact bin</>]]}
        onChange={value => setParams(previous => { const next = new URLSearchParams(previous); if (value === 'bin') next.set('view', 'bin'); else next.delete('view'); return next; })} />
      <div className="ws-artifact-filters">
        <label className="ws-artifact-search"><span className="ws-artifact-sr">Search project artifacts</span><ArtifactIcon name="search" />
          <input className="ui-control" type="search" maxLength={200} value={search} onChange={event => { setReturning(undefined); setSearch(event.target.value); }} placeholder="Search title, author or kind…" />
        </label>
        <label><span className="ws-artifact-sr">Show</span><select className="ui-control" aria-label="Show" value={scope} onChange={event => { setReturning(undefined); setScope(event.target.value); }}>
          <option value="all">All artifacts</option><option value="standalone">Standalone</option><option value="mission">Mission-linked</option>
        </select></label>
      </div>
    </div>
    <ArtifactUndo /><ArtifactLifecycleRecovery controller={lifecycle} />
    <div className="ws-artifact-collection">
      <div className="ws-artifact-collection-heading">
        <p role="status">{status}</p>
        {filtered ? all.length > 0 && <Button variant="quiet" className="ws-artifact-clear" onClick={clearFilters}>Clear filters<ArtifactIcon name="close" /></Button>
          : <span>{bin ? 'Restore work or remove it permanently' : 'Published in this project'}</span>}
      </div>
      {missionId && <p className="ws-artifact-scope-note">Filtered to this mission’s published work. <Link to="/artifacts">Show all artifacts</Link></p>}
      {query.isError ? <EmptyState title="Artifacts are unavailable" descriptionRole="alert" icon={<ArtifactIcon name="alert" />}
        actions={<Button variant="quiet" disabled={!current || query.isFetching} onClick={() => void query.refetch()}>Try again</Button>}>{readableError(query.error)}</EmptyState>
        : !current ? <EmptyState title="Reconnect to inspect artifacts." />
        : query.isPending ? <LoadingState label="Loading artifacts…" size="page" /> : <>
          {!all.length ? <EmptyState icon={<ArtifactIcon name={filtered ? 'search' : bin ? 'trash' : 'folder'} />}
            title={filtered ? 'No matching artifacts.' : bin ? 'The bin is empty.' : 'No artifacts yet.'}
            actions={filtered ? <Button variant="quiet" onClick={clearFilters}>Clear filters</Button> : undefined}>
            {filtered ? 'Try another title, author or kind, or clear your filters.' : bin ? 'Artifacts you move to the bin can be restored here.' : 'Reports, proposals and interactive work will appear here when your agents publish them.'}
          </EmptyState> : bin ? <div className="ws-artifact-bin-grid">
            {all.map(manifest => <article key={`${manifest.producer}/${manifest.artifactId}`}>
              <div className="ws-artifact-bin-heading"><ArtifactSymbol manifest={manifest} /><div><h2>{manifest.title}</h2>
                {manifest.summary && <p>{manifest.summary}</p>}<span>{manifest.producer} · <ArtifactDate value={manifest.createdAt} /></span>
              </div><span className="ws-artifact-kind">{manifest.kind}</span></div>
              <ArtifactLifecyclePanel producer={manifest.producer} artifactId={manifest.artifactId} revision={manifest.revision} controller={lifecycle} />
            </article>)}
          </div> : <div className={`ws-artifact-browser${selected ? ' has-preview' : ''}`}>
            <div className="ws-artifact-list-region">
              <div className="ws-artifact-columns" aria-hidden="true"><span>Artifact</span><span>Kind</span><span>Published by</span><span>Published</span><span /></div>
              <div className="ws-artifact-list" aria-label="Project artifacts">
                {all.map(manifest => <ArtifactRow key={`${manifest.producer}/${manifest.artifactId}`} manifest={manifest}
                  selected={selected?.producer === manifest.producer && selected.artifactId === manifest.artifactId}
                  onPreview={button => { trigger.current = button; setPreview({ producer: manifest.producer, artifactId: manifest.artifactId, revision: manifest.revision }); }} />)}
              </div>
              {query.hasNextPage && <div className="ws-load-more"><Button variant="quiet" disabled={query.isFetching || search.trim() !== settledSearch} onClick={() => void query.fetchNextPage()}>Load more artifacts</Button></div>}
            </div>
            {selected && <ArtifactInspection key={`${selected.producer}/${selected.artifactId}`} {...selected} controller={lifecycle}
              onRevision={revision => setPreview({ ...selected, revision })} onClose={closePreview} />}
          </div>}
          {bin && query.hasNextPage && <div className="ws-load-more"><Button variant="quiet" disabled={query.isFetching || search.trim() !== settledSearch} onClick={() => void query.fetchNextPage()}>Load more artifacts</Button></div>}
        </>}
    </div>
    <ArtifactRetainedHistory />
  </section>;
}

function ArtifactRow({ manifest: m, selected, onPreview }: { manifest: ArtifactManifest; selected: boolean; onPreview: (button: HTMLButtonElement) => void }) {
  const location = useLocation();
  return <article className="ws-artifact-row" data-selected={selected}>
    <div className="ws-artifact-row-main"><ArtifactSymbol manifest={m} /><div className="ws-artifact-row-copy">
      <h2><Link to={artifactViewerPath(m.producer, m.artifactId, m.revision)} state={{ artifactVisit: location.key }}>{m.title}</Link></h2>
      {m.summary && <p>{m.summary}</p>}
      <span className="ws-artifact-row-compact-meta">{m.producer} · <ArtifactDate value={m.createdAt} /></span>
    </div></div>
    <div className="ws-artifact-row-kind"><span className="ws-artifact-kind">{m.kind}</span><small>{m.missionId ? 'Mission-linked' : `${m.files.length} ${m.files.length === 1 ? 'file' : 'files'}`}</small></div>
    <span className="ws-artifact-row-author">{m.producer}</span>
    <span className="ws-artifact-row-date"><ArtifactDate value={m.createdAt} /></span>
    <IconButton className="ws-artifact-preview-button" aria-label={`Preview ${m.title}`} title={`Preview ${m.title}`} aria-pressed={selected} onClick={event => onPreview(event.currentTarget)}><ArtifactIcon name="chevron" /></IconButton>
  </article>;
}

export function ArtifactViewer() {
  const { controller, backState } = useArtifactSession(), { producer = '', artifactId = '', revision = '' } = useParams(), navigate = useNavigate();
  return <div className="ws-artifact-page">
    <ArtifactInspection producer={producer} artifactId={artifactId} revision={revision} controller={controller} onRevision={next => navigate(artifactViewerPath(producer, artifactId, next),{state: backState, replace:true})} />
  </div>;
}

function ArtifactInspection({ producer, artifactId, revision, controller: lifecycle, onRevision, onClose }: Selection & {
  controller: LifecycleController; onRevision: (revision: string) => void; onClose?: () => void;
}) {
  const { owner, current, session } = useWorkspace(), location = useLocation();
  const [expanded, setExpanded] = useState(false), region = useRef<HTMLElement>(null);
  useEffect(() => {
    if (onClose) { region.current?.focus({ preventScroll: true }); region.current?.scrollIntoView({ block: window.innerWidth < 1100 ? 'start' : 'nearest' }); }
  }, [producer, artifactId]);
  const query = useQuery({ queryKey: ['workspace', owner, 'artifact', producer, artifactId, revision], enabled: current,
    queryFn: async ({ signal }) => {
      const detail = await api(projectPath(`/api/studio/artifacts/${identity(producer, artifactId, revision)}`, session.project.id), { signal }) as ArtifactDetail;
      if (!detail?.manifest || detail.manifest.producer !== producer || detail.manifest.artifactId !== artifactId || detail.manifest.revision !== revision
        || !Array.isArray(detail.manifest.files) || !Array.isArray(detail.revisions)) throw Error('The artifact does not match the requested revision.');
      return detail;
    } });
  const m = current && !query.isError ? query.data?.manifest : undefined;
  if (!onClose) return <ArtifactReader manifest={m} revisions={query.data?.revisions ?? []} producer={producer} artifactId={artifactId} revision={revision}
    projectId={session.project.id} controller={lifecycle} current={current} refreshing={query.isFetching} error={query.isError ? readableError(query.error) : undefined}
    onRefresh={() => void query.refetch()} onRevision={onRevision} />;
  const Heading = 'h2';
  return <section className={`ws-surface ws-artifact-viewer${expanded ? ' ws-artifact-expanded' : ''}`} aria-label="Artifact viewer" ref={region} tabIndex={-1}
    onKeyDown={event => { if (event.key === 'Escape' && !event.defaultPrevented) { if (expanded) setExpanded(false); else onClose?.(); } }}>
    <header className="ws-artifact-reader-header">
      <div className="ws-artifact-reader-nav">
        <Link className="ws-artifact-reader-link" state={{ artifactVisit: location.key }} to={artifactViewerPath(producer, artifactId, revision)}>
          <ArtifactIcon name="document" />Open full page
        </Link>
        <div className="ws-artifact-reader-actions">
          <IconButton aria-label="Refresh" title="Refresh artifact" disabled={!current || query.isFetching} onClick={() => void query.refetch()}><ArtifactIcon name="refresh" /></IconButton>
          <IconButton aria-label={expanded ? 'Restore view' : 'Expand preview'} title={expanded ? 'Restore view' : 'Expand preview'} aria-pressed={expanded} onClick={() => setExpanded(value => !value)}><ArtifactIcon name={expanded ? 'minimize' : 'fit'} /></IconButton>
          <IconButton aria-label="Close preview" title="Close preview" onClick={onClose}><ArtifactIcon name="close" /></IconButton>
        </div>
      </div>
      <Heading>{m?.title ?? (current && !query.isError ? 'Artifact' : 'Artifact unavailable')}</Heading>
      {m && <><div className="ws-artifact-reader-meta"><span className="ws-artifact-kind">{m.kind}</span><span>{m.producer}</span><ArtifactDate value={m.createdAt} />
        {m.missionId && <Link to={`/missions/v2/${encodeURIComponent(m.missionId)}`}>View mission ↗</Link>}</div>
        {m.summary && <p className="ws-artifact-reader-summary">{m.summary}</p>}</>}
    </header>
    {query.isError ? <EmptyState title="This artifact is unavailable" descriptionRole="alert" actions={<Button variant="quiet" disabled={!current || query.isFetching} onClick={() => void query.refetch()}>Try again</Button>}>{readableError(query.error)}</EmptyState>
      : !current ? <EmptyState title="Reconnect to inspect this artifact." />
      : !m ? <LoadingState label="Loading artifact…" size="page" /> : <>
        <ArtifactFiles key={`${owner}/${producer}/${artifactId}/${revision}`} manifest={m} projectId={session.project.id}
          revisionControl={<ArtifactVersion revisions={query.data!.revisions} revision={revision} onChange={onRevision} />} />
        <div className="ws-artifact-details"><details className="ws-record"><summary>About this artifact</summary>
          <dl><div><dt>Published by</dt><dd>{m.producer}</dd></div><div><dt>Published</dt><dd><ArtifactDate value={m.createdAt} /></dd></div>
            <div><dt>Source supplied by publisher</dt><dd>{m.sourceRef ?? 'Not supplied'}</dd></div>
            <div><dt>Exact revision</dt><dd><code>artifact-registry:{m.producer}/{m.artifactId}@{m.revision}</code></dd></div></dl>
          {m.missionId && <p>Publisher association: <Link to={`/missions/v2/${encodeURIComponent(m.missionId)}`}>Mission ↗</Link>{m.taskId ? ` · task ${m.taskId}` : ''}. Publication is separate from task delivery and verification.</p>}
          <p>HTML runs in an isolated preview. Publication and byte integrity do not establish that its claims are correct.</p>
        </details></div>
      </>}
    <div className="ws-artifact-management"><ArtifactLifecyclePanel producer={producer} artifactId={artifactId} revision={revision} controller={lifecycle} /></div>
  </section>;
}
