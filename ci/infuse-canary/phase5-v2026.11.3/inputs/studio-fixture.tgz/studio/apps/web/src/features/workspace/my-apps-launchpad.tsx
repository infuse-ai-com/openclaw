import { Button, IconButton } from './ui.js';
import { useRef, useState } from 'react';
import type { AppLink } from '@studio/contracts';
import { Link } from './navigation.js';
import { MyAppIcon, MyAppActionIcon } from './my-app-icon.js';

const starterNames = ['Mattermost', 'Sourcebot', 'Grafana', 'Company Vaultwarden', 'Webmail'];
function readPins(key: string, apps: AppLink[]) {
  const initial = () => starterNames.flatMap(name => apps.filter(app => app.name === name).map(app => app.id));
  try {
    const saved = localStorage.getItem(key);
    if (saved !== null && saved.length <= 60000) {
      try {
        const value: unknown = JSON.parse(saved);
        if (Array.isArray(value) && value.length <= 500 && value.every(id => typeof id === 'string' && id.length > 0 && id.length <= 100)) {
          return { ids: [...new Set(value as string[])], temporary: false };
        }
      } catch { /* Invalid presentation preferences fall back to the starter selection. */ }
    }
    return { ids: initial(), temporary: false };
  } catch { return { ids: initial(), temporary: true }; }
}

/** Browser-local presentation preferences contain IDs only, never app destinations or grants. */
export function MyAppsLaunchpad({ apps, categories, profileId }: { apps: AppLink[]; categories: string[]; profileId: string }) {
  const key = `infuse-studio:app-pins:v1:${encodeURIComponent(profileId)}`;
  const [preferences, setPreferences] = useState(() => readPins(key, apps));
  const [editing, setEditing] = useState(false);
  const editButton = useRef<HTMLButtonElement>(null);
  const [announcement, setAnnouncement] = useState('');
  // Every render resolves pins against the current admitted catalog. Removed access never leaves a saved link.
  const byId = new Map(apps.map(app => [app.id, app]));
  const pinned = preferences.ids.flatMap(id => byId.has(id) ? [byId.get(id)!] : []);
  function togglePin(app: AppLink) {
    const removing = preferences.ids.includes(app.id);
    const current = preferences.ids.filter(id => byId.has(id));
    const ids = removing ? current.filter(id => id !== app.id) : [...current, app.id];
    let temporary = false;
    try { localStorage.setItem(key, JSON.stringify(ids)); } catch { temporary = true; }
    setPreferences({ ids, temporary });
    setAnnouncement(`${app.name} ${removing ? 'unpinned' : 'pinned'}.`);
  }
  return <>
    <section className="apps-pinned" aria-labelledby="apps-pinned-title">
      <header className="apps-section-heading"><h2 id="apps-pinned-title">Pinned</h2>
        <Button variant="quiet" ref={editButton} className="apps-edit-pins" aria-pressed={editing} aria-controls="apps-catalog" onClick={() => setEditing(!editing)}>
          <MyAppActionIcon name={editing ? 'check' : 'edit'} />{editing ? 'Done' : 'Edit pins'}
        </Button>
      </header>
      {editing && <p className="apps-pin-help">Use the pin buttons in All apps to choose your shortcuts. Saved in this browser.</p>}
      {preferences.temporary && <p className="apps-pin-help">Pins are available for this visit only because browser storage is unavailable.</p>}
      {pinned.length ? <div className="apps-pinned-grid">{pinned.map(app => <Link className="apps-pinned-app" key={app.id}
        to={app.url} target={app.url.startsWith('/') ? undefined : '_blank'} rel={app.url.startsWith('/') ? undefined : 'noopener noreferrer'}>
        <span className="apps-pin-mark"><MyAppActionIcon name="pin" /></span><MyAppIcon name={app.icon} accent={app.accent} /><strong>{app.name}</strong>
      </Link>)}</div> : <p className="apps-pins-empty">Pin the apps you reach for most. Choose Edit pins to get started.</p>}
    </section>
    <section className="apps-catalog" data-editing={editing || undefined} id="apps-catalog" aria-labelledby="apps-catalog-title">
      <header className="apps-section-heading"><h2 id="apps-catalog-title">All apps <span>{apps.length}</span></h2>{editing && <Button variant="quiet" className="apps-edit-pins" onClick={() => { setEditing(false); requestAnimationFrame(() => editButton.current?.focus()); }}><MyAppActionIcon name="check" />Done editing pins</Button>}</header>
      <div className="apps-catalog-grid">{categories.map(category => {
        const items = apps.filter(app => app.category === category);
        const wide = items.length > 6;
        return <section key={category} className="apps-category" data-wide={wide || undefined} aria-label={category}>
          <h3>{category}<span>{items.length}</span></h3>
          <div className="apps-grid" style={wide ? { gridTemplateRows: `repeat(${Math.ceil(items.length / 2)}, auto)` } : undefined}>
            {items.map(app => <div className="apps-catalog-row" key={app.id}>
              <Link className="apps-card" data-accent={app.accent ?? 'slate'} to={app.url}
                target={app.url.startsWith('/') ? undefined : '_blank'} rel={app.url.startsWith('/') ? undefined : 'noopener noreferrer'}>
                <MyAppIcon name={app.icon} accent={app.accent} /><span className="apps-card-copy"><strong>{app.name}</strong><span>{app.description}</span></span>
                {!editing && <MyAppActionIcon name="externalLink" />}
              </Link>
              {editing && <IconButton className="apps-pin-toggle" aria-label={`${preferences.ids.includes(app.id) ? 'Unpin' : 'Pin'} ${app.name}`}
                aria-pressed={preferences.ids.includes(app.id)} onClick={() => togglePin(app)}><MyAppActionIcon name="pin" /></IconButton>}
            </div>)}
          </div>
        </section>;
      })}</div>
    </section>
    <span className="apps-announcement" aria-live="polite">{announcement}</span>
  </>;
}
