import type { GraphNode, KnowledgeGraph } from '@studio/contracts/knowledge';
import {
  forceCollide,
  forceLink,
  forceManyBody,
  forceSimulation,
  forceX,
  forceY,
  type Simulation,
} from 'd3-force';
import { useEffect, useMemo, useRef, useState } from 'react';
import { clusterColor, type PositionedLink, type PositionedNode } from './graphLayout';

/** Only this owner mutates D3 nodes. Consumers receive immutable position snapshots. */
export function useGraphSimulation(
  clusters: KnowledgeGraph['clusters'],
  graphNodes: GraphNode[],
  edges: KnowledgeGraph['edges'],
  degree: ReadonlyMap<string, number>,
) {
  const simulationRef = useRef<Simulation<PositionedNode, PositionedLink> | null>(null);
  const [layoutNodes, setLayoutNodes] = useState<PositionedNode[]>([]);
  useEffect(() => {
    const clusterIndexes = new Map(clusters.map((cluster, index) => [cluster.id, index]));
    const clusterMembers = new Map<string, number>();
    const nodes = graphNodes.map<PositionedNode>((node) => {
      const clusterIndex = clusterIndexes.get(node.clusterId) ?? 0;
      const memberIndex = clusterMembers.get(node.clusterId) ?? 0;
      clusterMembers.set(node.clusterId, memberIndex + 1);
      const clusterAngle = (clusterIndex / Math.max(1, clusters.length)) * Math.PI * 2;
      const clusterRadius = clusters.length === 1 ? 0 : 460;
      const orbit = 74 + Math.floor(memberIndex / 8) * 58;
      const nodeAngle = (memberIndex * 2.399_963_23) % (Math.PI * 2);
      return {
        ...node,
        x: Math.cos(clusterAngle) * clusterRadius + Math.cos(nodeAngle) * orbit,
        y: Math.sin(clusterAngle) * clusterRadius + Math.sin(nodeAngle) * orbit,
        radius: 12 + Math.min(10, (degree.get(node.id) ?? 0) * 2),
        color: clusterColor(clusterIndex),
      };
    });
    const links: PositionedLink[] = edges.map((edge) => ({
      id: edge.id,
      source: edge.sourceId,
      target: edge.targetId,
    }));
    const centerRadius = clusters.length === 1 ? 0 : 460;
    const centerFor = (node: PositionedNode) => {
      const index = clusterIndexes.get(node.clusterId) ?? 0;
      const angle = (index / Math.max(1, clusters.length)) * Math.PI * 2;
      return {
        x: Math.cos(angle) * centerRadius,
        y: Math.sin(angle) * centerRadius,
      };
    };
    const simulation = forceSimulation<PositionedNode, PositionedLink>(nodes)
      .force('charge', forceManyBody().strength(-190).distanceMax(560))
      .force(
        'link',
        forceLink<PositionedNode, PositionedLink>(links)
          .id((node) => node.id)
          .distance(116)
          .strength(0.3),
      )
      .force(
        'collision',
        forceCollide<PositionedNode>()
          .radius((node) => node.radius + 12)
          .strength(0.9),
      )
      .force('cluster-x', forceX<PositionedNode>((node) => centerFor(node).x).strength(0.08))
      .force('cluster-y', forceY<PositionedNode>((node) => centerFor(node).y).strength(0.08))
      .alphaDecay(0.035)
      .velocityDecay(0.33);
    simulationRef.current = simulation;
    const reducedMotion = globalThis.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      simulation.stop();
      simulation.tick(180);
      setLayoutNodes(nodes.map((node) => ({ ...node })));
    } else {
      simulation.on('tick', () => {
        setLayoutNodes(nodes.map((node) => ({ ...node })));
      });
    }
    setLayoutNodes(nodes.map((node) => ({ ...node })));
    return () => {
      simulation.stop();
      if (simulationRef.current === simulation) simulationRef.current = null;
    };
  }, [degree, clusters, edges, graphNodes]);

  const nodeById = useMemo(
    () => new Map(layoutNodes.map((node) => [node.id, node])),
    [layoutNodes],
  );

  const clusterRegions = useMemo(
    () =>
      clusters.flatMap((cluster, index) => {
        const members = layoutNodes.filter((node) => node.clusterId === cluster.id);
        if (members.length === 0) return [];
        const left = Math.min(...members.map((node) => node.x - node.radius));
        const right = Math.max(...members.map((node) => node.x + node.radius));
        const top = Math.min(...members.map((node) => node.y - node.radius));
        const bottom = Math.max(...members.map((node) => node.y + node.radius));
        return [
          {
            ...cluster,
            x: (left + right) / 2,
            y: (top + bottom) / 2,
            width: Math.max(180, right - left + 110),
            height: Math.max(150, bottom - top + 90),
            color: clusterColor(index),
            labelWidth: Math.max(148, cluster.label.length * 8.4 + 30),
          },
        ];
      }),
    [clusters, layoutNodes],
  );

  function startDrag(id: string) {
    const node = simulationRef.current?.nodes().find((node) => node.id === id);
    if (node) {
      node.fx = node.x;
      node.fy = node.y;
    }
    simulationRef.current?.alphaTarget(0.12).restart();
  }
  function moveDrag(id: string, x: number, y: number) {
    const node = simulationRef.current?.nodes().find((node) => node.id === id);
    if (!node) return;
    node.fx = x;
    node.fy = y;
    node.x = x;
    node.y = y;
    setLayoutNodes(simulationRef.current?.nodes().map((node) => ({ ...node })) ?? []);
  }
  function endDrag() {
    simulationRef.current?.alphaTarget(0);
  }
  return { layoutNodes, nodeById, clusterRegions, startDrag, moveDrag, endDrag };
}
