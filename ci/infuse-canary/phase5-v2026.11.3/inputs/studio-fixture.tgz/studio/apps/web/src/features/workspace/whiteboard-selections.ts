import * as Y from 'yjs';
import { StateEffect, StateField } from '@codemirror/state';
import { Decoration, EditorView, WidgetType, type DecorationSet } from '@codemirror/view';
import type { WhiteboardParticipant } from '@studio/contracts';

class PeerCaret extends WidgetType {
  constructor(private name:string,private color:string) { super(); }
  toDOM() { const element=document.createElement('span'); element.className='wboard-peer-caret'; element.style.borderColor=this.color; element.title=this.name; element.setAttribute('aria-label',this.name+' is editing here'); return element; }
}
export const remoteSelections=StateEffect.define<DecorationSet>();
export const remoteSelectionField=StateField.define<DecorationSet>({
  create:()=>Decoration.none,
  update:(value,transaction)=> { value=value.map(transaction.changes); for (const effect of transaction.effects) if (effect.is(remoteSelections)) value=effect.value; return value; },
  provide:field=>EditorView.decorations.from(field),
});
export function selectionDecorations(doc:Y.Doc,blockId:string,epoch:string,peers:WhiteboardParticipant[]):DecorationSet {
  const ranges=[]; const body=doc.getText('body');
  for (const peer of peers) {
    const selection=peer.state.selection;
    if (!selection || selection.blockId!==blockId || selection.epoch!==epoch) continue;
    const anchor=Y.createAbsolutePositionFromRelativePosition(Y.createRelativePositionFromJSON(selection.anchor),doc);
    const head=Y.createAbsolutePositionFromRelativePosition(Y.createRelativePositionFromJSON(selection.head),doc);
    if (anchor?.type!==body || head?.type!==body) continue;
    const from=Math.min(anchor.index,head.index),to=Math.max(anchor.index,head.index);
    if (to>body.length) continue;
    if (from<to) ranges.push(Decoration.mark({ attributes:{ style:'background-color:'+peer.color+'25',title:peer.name+' selection' } }).range(from,to));
    ranges.push(Decoration.widget({ widget:new PeerCaret(peer.name,peer.color),side:1 }).range(head.index));
  }
  return Decoration.set(ranges,true);
}
