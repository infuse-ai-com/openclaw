import { createContext, useContext } from 'react';
import type { SignedInSession } from './api.js';
import type { Commands } from './commands.js';

export interface WorkspaceContextValue {
  session: SignedInSession; owner: string; current: boolean; visible: boolean;
  commands: Commands;
}
export const WorkspaceContext = createContext<WorkspaceContextValue | undefined>(undefined);
export function useWorkspace(): WorkspaceContextValue {
  const value = useContext(WorkspaceContext);
  if (!value) throw Error('Workspace context is unavailable');
  return value;
}
