import { useState } from 'react';
import type { ComponentProps, MouseEvent, PointerEvent, KeyboardEvent } from 'react';
import type { WhiteboardCanvas } from './whiteboard-canvas.js';
import { isTyping } from './whiteboard-history.js';
type MenuContext = Pick<ComponentProps<typeof WhiteboardCanvas>,
  'enabled' | 'hasDraft' | 'tool' | 'blocks' | 'canvas' | 'flow' | 'pastePoint' | 'setFocused' |
  'setPanel' | 'selectNext' | 'setNodes' | 'setAutoFocusId'> & {
  imagePending: boolean; selection: string[]; canvasSize: { width: number; height: number };
};
/** Context-menu placement and locked-gesture guidance; this owner never writes board state. */
export function useWhiteboardSelectionMenu(context: () => MenuContext) {
  const [selectionMenu, setSelectionMenu] = useState<{ x: number; y: number; ids: string[] } | null>(null);
  const [lockPrompt, setLockPrompt] = useState<{ x: number; y: number; ids: string[] } | null>(null);
  function closeSelectionMenu(restore = false) { setSelectionMenu(null); if (restore) context().canvas.current?.focus(); }
  const lockedIds = (ids: string[]) => context().blocks.filter(block => ids.includes(block.id) && block.locked).map(block => block.id);
  function showLockPrompt(ids: string[], point?: { x: number; y: number }) {
    const { canvasSize } = context();
    const locked = lockedIds(ids);
    if (!locked.length) return;
    setSelectionMenu(null);
    setLockPrompt({
      ids: locked,
      ...(point ?? { x: canvasSize.width / 2 - 135, y: canvasSize.height - 190 }),
    });
  }
  function guardLockedGesture(
    event: PointerEvent<HTMLDivElement> | KeyboardEvent<HTMLDivElement>,
  ) {
    const { enabled, tool, selection, canvas, setFocused, setPanel, selectNext, setNodes } = context();
    const target = event.target as Element;
    if (tool !== 'select' || !enabled || isTyping(target) || target.closest('button')) return;
    if ('button' in event && event.button !== 0) return;
    if ('key' in event && !['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key))
      return;
    const nodeId = target.closest('.react-flow__node')?.getAttribute('data-id');
    const group = target.closest('.react-flow__nodesselection');
    if (!nodeId && !group) return;
    const ids = group ? selection : selection.includes(nodeId!) ? selection : [nodeId!];
    if (!lockedIds(ids).length) return;
    event.preventDefault();
    event.stopPropagation();
    if (nodeId && !selection.includes(nodeId)) {
      setFocused(null);
      setPanel(null);
      selectNext.current = [];
      setNodes((previous) => previous.map((node) => ({ ...node, selected: node.id === nodeId })));
    }
    const rect = canvas.current?.getBoundingClientRect();
    showLockPrompt(
      ids,
      'clientX' in event && rect
        ? { x: event.clientX - rect.left + 12, y: event.clientY - rect.top + 12 }
        : undefined,
    );
  }
  function openSelectionMenu(event: MouseEvent<HTMLDivElement>) {
    const { enabled, hasDraft, imagePending, tool, selection, canvas, flow, pastePoint, setFocused, setPanel, selectNext, setNodes, setAutoFocusId } = context();
    if (!enabled || hasDraft || imagePending) return;
    const target = event.target as Element;
    if (isTyping(target) && selection.length <= 1) return;
    const nodeId = target.closest('.react-flow__node')?.getAttribute('data-id');
    const ids = nodeId && !selection.includes(nodeId) ? [nodeId] : selection;
    if (!['select', 'hand'].includes(tool)) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = canvas.current?.getBoundingClientRect();
    if (!rect) return;
    if (nodeId && !selection.includes(nodeId)) {
      selectNext.current = [];
      setFocused(null);
      setPanel(null);
      setNodes((previous) => previous.map((node) => ({ ...node, selected: node.id === nodeId })));
    }
    pastePoint.current =
      flow.current?.screenToFlowPosition({ x: event.clientX, y: event.clientY }) ?? null;
    setAutoFocusId(null);
    setLockPrompt(null);
    setSelectionMenu({ x: event.clientX - rect.left, y: event.clientY - rect.top, ids: [...ids] });
  }
  return { selectionMenu, lockPrompt, setSelectionMenu, setLockPrompt, closeSelectionMenu, lockedIds, showLockPrompt, guardLockedGesture, openSelectionMenu };
}
