export function resolveAssetPath(
  sourcePath: string,
  rawTarget: string,
): string | null {
  if (/^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(rawTarget)) return null;
  try {
    const [rawPath = ''] = rawTarget.split(/[?#]/, 1);
    const decodedPath = decodeURIComponent(rawPath);
    if (
      !decodedPath ||
      decodedPath.startsWith('/') ||
      decodedPath.includes('\0')
    ) {
      return null;
    }
    const segments = sourcePath.split('/').slice(0, -1);
    for (const segment of decodedPath.split('/')) {
      if (!segment || segment === '.') continue;
      if (segment === '..') {
        if (segments.length === 0) return null;
        segments.pop();
      } else {
        segments.push(segment);
      }
    }
    return segments.length > 0 ? segments.join('/') : null;
  } catch {
    return null;
  }
}
