import { IconButton, Button } from './ui.js';
import { useEffect, useRef, useState } from 'react';
import { whiteboardCommentCommand, whiteboardCommentPage, whiteboardReceipt, type WhiteboardCommentCommand, type WhiteboardCommentThread, type WhiteboardCommentPage } from '@studio/contracts';
import { api, accessDenied, readableError, ApiError, type SignedInSession } from './api.js';
import { persistWhiteboardEnvelope } from './whiteboard-storage.js';

export type CommentSelection={ blockId:string;epoch:string;expectedTextRevision:number;from:number;to:number;quote:string };
/** A stable bridge to the mounted editor: jumping must not reconnect or replace text. */
export class CommentNavigator {
  pending:WhiteboardCommentThread|null=null;
  private listeners=new Set<()=>void>();
  constructor(private report:(message:string)=>void) {}
  jump(thread:WhiteboardCommentThread) {this.pending=thread;for(const listener of this.listeners)listener();}
  subscribe(listener:()=>void) {this.listeners.add(listener);return()=>{this.listeners.delete(listener);};}
  finish(message='') {this.pending=null;if(message)this.report(message);}
}
export class CommentDrafts {
  texts=new Map<string,string>();
  pending:WhiteboardCommentCommand|null=null;
  loaded=false;
  blocked=false;
  dirty() { return this.blocked || !!this.pending || [...this.texts.values()].some(text=>!!text); }
  clear() { this.texts.clear(); this.pending=null; this.blocked=false; }
}

export function WhiteboardComments({ path,owner,session,blockId,selection,drafts,enabled,people,jump,changed,close }: {
  path:string;owner:string;session:SignedInSession;blockId?:string;selection:CommentSelection|null;
  drafts:CommentDrafts;enabled:boolean;people:Array<{id:string;name:string}>;jump(thread:WhiteboardCommentThread):void;changed():void;close():void;
}) {
  const [page,setPage]=useState<WhiteboardCommentPage>(); const [message,setMessage]=useState(''); const [busy,setBusy]=useState(false);
  const [,render]=useState(0); const live=useRef(true),saving=useRef(false);
  const composer=useRef<HTMLTextAreaElement>(null);const selectedBlock=useRef(blockId);selectedBlock.current=blockId;
  useEffect(()=> { if(selection?.blockId===blockId) composer.current?.focus(); },[selection,blockId]);
  const key='studio.whiteboard.comments.pending:'+owner;
  const refresh=async()=> {
    if (!blockId) return;
    try { const value=whiteboardCommentPage.parse(await api(path+'/comments?'+new URLSearchParams({ blockId }),{ isCurrent:()=>live.current })); if(live.current&&selectedBlock.current===blockId) setPage(value); }
    catch(error) { if (!live.current) return; if(accessDenied(error)) { drafts.clear(); changed(); setPage(undefined); } setMessage(readableError(error)); }
  };
  useEffect(()=> { live.current=true; return()=> { live.current=false; }; },[]);
  useEffect(()=> {
    if (!drafts.loaded) { drafts.loaded=true; try { const raw=sessionStorage.getItem(key); if (raw) drafts.pending=whiteboardCommentCommand.parse(JSON.parse(raw)); } catch { drafts.blocked=true; } changed(); }
    if(drafts.blocked) setMessage('Comment recovery could not be read. Discard local drafts before leaving, then reopen the board with session storage available.');
    setPage(undefined); void refresh(); const timer=setInterval(()=>void refresh(),2000); return()=>clearInterval(timer);
  },[blockId,path,key]);
  const text=(id:string)=>drafts.texts.get(id) ?? '';
  const edit=(id:string,value:string)=> { drafts.texts.set(id,value); changed(); render(n=>n+1); };
  function settled() { drafts.pending=null; sessionStorage.removeItem(key); changed(); }
  async function send(command:WhiteboardCommentCommand,recover=false) {
    if (!enabled || saving.current || drafts.blocked) return; saving.current=true; setBusy(true);
    try {
      command=whiteboardCommentCommand.parse(command);
      persistWhiteboardEnvelope(key,command); drafts.pending=command; changed();
      setMessage(recover?'Checking the original receipt…':'Saving comment…');
      let result=recover ? await api(path+'/receipts/'+command.commandId,{ isCurrent:()=>live.current }) : null;
      if (!result) result=await api(path+'/comments',{ command,csrf:session.csrfToken,isCurrent:()=>live.current });
      const receipt=whiteboardReceipt.parse(result);
      if (receipt.commandId!==command.commandId || receipt.projectId!==session.project.id || receipt.actor.kind!=='human' || receipt.actor.id!==session.profileId) throw Error('Comment receipt mismatch');
      if (!live.current) return;
      settled(); if (command.type==='create') drafts.texts.delete('new:'+command.blockId); else if(command.type==='reply') drafts.texts.delete(command.threadId);
      changed(); setMessage(receipt.message); await refresh();
    } catch(error) {
      if (!live.current) return;
      if (accessDenied(error)) { drafts.clear(); try { sessionStorage.removeItem(key); } catch {} setPage(undefined); changed(); }
      else if (error instanceof ApiError && error.status>=400 && error.status<500) settled();
      setMessage(drafts.pending?'Save status needs checking. Retry checks the original receipt before resending.':readableError(error));
    } finally { saving.current=false; if(live.current) setBusy(false); }
  }
  const available=enabled && !busy && !drafts.pending && !drafts.blocked;
  const chosen=selection?.blockId===blockId ? selection : null;
  return <aside className="wboard-comments wboard-panel wboard-float" aria-label="Comments">
    <header className="wboard-panel-heading"><h2>Comments</h2><IconButton type="button" onClick={close} aria-label="Close comments">×</IconButton></header>
    <div className="wboard-panel-content">
      <p role="status">{message}</p>
      {drafts.pending && <Button variant="quiet" disabled={!enabled || busy} onClick={()=>void send(drafts.pending!,true)}>Check comment and retry</Button>}
      {!blockId && <p>Select a note or document to read its comments.</p>}
      {blockId && <form onSubmit={event=> { event.preventDefault(); if (chosen) void send({ type:'create',commandId:crypto.randomUUID(),threadId:crypto.randomUUID(),...chosen,text:text('new:'+blockId) }); }}>
        {chosen ? <blockquote>{chosen.quote}</blockquote> : <p>Select saved text, then choose “Comment on selection”.</p>}
        {(chosen||text('new:'+blockId))&&<><label>New comment<textarea className="ui-control" ref={composer} aria-label="New comment" maxLength={2000} value={text('new:'+blockId)} onChange={event=>edit('new:'+blockId,event.target.value)} /></label>
        <Button variant="quiet" disabled={!available || !chosen || !text('new:'+blockId).trim()}>Post comment</Button></>}
      </form>}
      <ol>{page && page.blockId===blockId && page.threads.map(thread=><li key={thread.id} className="wboard-comment" aria-label={'Comment thread '+thread.anchor.quote}>
        <blockquote>{thread.anchor.quote}</blockquote><Button variant="quiet" type="button" disabled={thread.anchorState!=='live'} onClick={()=>jump(thread)}>Show in note</Button><p className="wboard-comment-state">{thread.anchorState==='deleted'?'Block deleted':thread.anchorState==='orphaned'?'Original range deleted':thread.resolved?'Resolved':'Open'}</p>
        {thread.messages.map(item=><div key={item.id}><strong>{item.author.kind==='human'?(people.find(p=>p.id===item.author.id)?.name??item.author.id):item.author.id}{item.author.kind==='agent'?' (agent)':''}</strong><p>{item.text}</p></div>)}
        {thread.anchorState!=='deleted' && <><form onSubmit={event=> { event.preventDefault(); void send({ type:'reply',commandId:crypto.randomUUID(),threadId:thread.id,expectedRevision:thread.revision,text:text(thread.id) }); }}>
          <label>Reply<textarea className="ui-control" aria-label="Reply" maxLength={2000} value={text(thread.id)} onChange={event=>edit(thread.id,event.target.value)} /></label>
          <Button variant="quiet" disabled={!available || !text(thread.id).trim() || thread.messages.length>=20}>Post reply</Button></form>
          <Button variant="quiet" disabled={!available} onClick={()=>void send({ type:'resolve',commandId:crypto.randomUUID(),threadId:thread.id,expectedRevision:thread.revision,resolved:!thread.resolved })}>{thread.resolved?'Reopen comment':'Resolve comment'}</Button></>}
      </li>)}</ol>
    </div>
  </aside>;
}
