import { IconButton, Button } from './ui.js';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useInfiniteQuery } from '@tanstack/react-query';
import { whiteboardHtmlReference, type ArtifactPage, type WhiteboardHtmlReference } from '@studio/contracts';
import { api, readableError, type SignedInSession } from './api.js';
import { LoadingState } from './loading.js';
import { ShellIcon } from './shell.js';

function LibraryPreview({ src, title }: { src: string; title: string }) {
  const [loaded, setLoaded] = useState(false);
  return <div className="wboard-library-frame">
    {!loaded && <LoadingState label="Loading preview…" size="panel" />}
    <iframe title={title + ' library preview'} src={src} sandbox="allow-scripts" referrerPolicy="no-referrer" onLoad={() => setLoaded(true)} />
  </div>;
}

/** Selecting a source only previews it; the explicit action pins its exact file revision. */
export function HtmlPicker({ path, session, sectionTitle, replacing, enabled, previewReady, notice, choose, close }: {
  path: string; session: SignedInSession; sectionTitle: string; replacing: boolean; enabled: boolean; previewReady: boolean; notice: string;
  choose(reference: WhiteboardHtmlReference, title: string): Promise<boolean>; close(): void;
}) {
  const dialog = useRef<HTMLDialogElement>(null), search = useRef<HTMLInputElement>(null), submittingRef = useRef(false);
  const [filter, setFilter] = useState(''), [selection, setSelection] = useState('');
  const [submitting, setSubmitting] = useState(false), [attempted, setAttempted] = useState(false), [error, setError] = useState('');
  useEffect(() => {
    const previous = document.activeElement;
    dialog.current?.showModal(); search.current?.focus();
    return () => {
      dialog.current?.close();
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus();
      else document.querySelector<HTMLButtonElement>('.wboard-dock button[aria-label="Add HTML tile"]')?.focus();
    };
  }, []);
  const library = path.replace(/whiteboard$/, 'artifacts');
  const pages = useInfiniteQuery({
    queryKey: ['workspace', session.profileId, session.project.id, 'whiteboard-library'], gcTime: 0, retry: false,
    initialPageParam: undefined as string | undefined,
    queryFn: async ({ pageParam, signal }) => {
      const page = await api(library + (pageParam ? '?' + new URLSearchParams({ cursor: pageParam }) : ''), { signal }) as ArtifactPage;
      if (!page || !Array.isArray(page.artifacts) || page.artifacts.some(m => !m || m.schema !== 'infuse.artifact/v1' || !Array.isArray(m.files))
        || page.nextCursor !== null && (typeof page.nextCursor !== 'string' || !/^[1-9][0-9]{0,3}$/.test(page.nextCursor) || Number(page.nextCursor) > 1000 || Number(page.nextCursor) <= Number(pageParam ?? 0))) throw Error('The library could not be read. Try again.');
      return page;
    },
    getNextPageParam: page => page.nextCursor ?? undefined,
  });
  const all = [...new Map((pages.data?.pages.flatMap(page => page.artifacts) ?? [])
    .filter(m => m.project === session.project.id).flatMap(manifest => manifest.files.filter(file => file.mediaType === 'text/html').map(file => {
      const key = JSON.stringify([manifest.producer, manifest.artifactId, manifest.revision, file.path]);
      return [key, { key, manifest, file }] as const;
    }))).values()].sort((a, b) => b.manifest.createdAt.localeCompare(a.manifest.createdAt) || a.manifest.title.localeCompare(b.manifest.title) || Number(b.file.path === 'index.html') - Number(a.file.path === 'index.html') || a.file.path.localeCompare(b.file.path));
  const term = filter.trim().toLowerCase();
  const shown = all.filter(({ manifest: m, file }) => [m.title, m.summary, m.artifactId, m.producer, file.path, ...m.tags].join(' ').toLowerCase().includes(term));
  // Hide cached private results on a failed read; retry keeps the entered search.
  const selected = pages.isError ? undefined : shown.find(item => item.key === selection) ?? shown[0];
  const previewUrl = selected ? `${library}/${[selected.manifest.producer, selected.manifest.artifactId, selected.manifest.revision].map(encodeURIComponent).join('/')}/preview?${new URLSearchParams({ path: selected.file.path })}` : '';
  async function add() {
    if (!selected || !enabled || submittingRef.current) return;
    submittingRef.current = true; setSubmitting(true); setAttempted(true); setError('');
    try {
      const { manifest: m, file } = selected;
      await choose(whiteboardHtmlReference.parse({ producer: m.producer, artifactId: m.artifactId, revision: m.revision, path: file.path, sha256: file.sha256, bytes: file.bytes }), m.title);
    } catch (error) { setError(readableError(error)); }
    finally { submittingRef.current = false; setSubmitting(false); }
  }
  return createPortal(<dialog ref={dialog} className="wboard-library" aria-labelledby="wboard-library-title" aria-describedby="wboard-library-description"
    onKeyDown={event => event.stopPropagation()} onPaste={event => event.stopPropagation()} onDragOver={event => { event.preventDefault(); event.stopPropagation(); }} onDrop={event => { event.preventDefault(); event.stopPropagation(); }} onCancel={event => { event.preventDefault(); if (!submittingRef.current) close(); }}>
    <header className="wboard-library-heading"><div className="wboard-library-symbol"><ShellIcon name="artifact" /></div><div>
      <h2 id="wboard-library-title">{replacing ? 'Replace HTML source' : 'Add HTML to your board'}</h2>
      <p id="wboard-library-description">Browse {session.project.name}’s library and preview a file before {replacing ? 'replacing this block' : 'adding it'}.</p>
    </div><IconButton type="button" className="wboard-library-close" aria-label="Close HTML library" title="Close (Escape)" disabled={submitting} onClick={close}><ShellIcon name="close" /></IconButton></header>
    <div className="wboard-library-body">
      <section className="wboard-library-browse" aria-label="HTML files">
        <div className="wboard-library-search"><ShellIcon name="search" /><input className="ui-control" ref={search} type="search" disabled={submitting} aria-label="Search HTML library" placeholder="Search titles, files, or descriptions…" value={filter} onChange={event => setFilter(event.target.value)} /></div>
        <p className="wboard-library-count" role="status">{pages.isPending ? 'Loading your library…' : pages.isError ? 'Library unavailable' : `${shown.length} ${shown.length === 1 ? 'HTML file' : 'HTML files'}${term ? ` matching “${filter.trim()}”` : ''}${pages.hasNextPage ? ' · more available' : ''}`}</p>
        <div className="wboard-library-results">
          {pages.isPending ? <LoadingState label="Loading HTML files…" size="panel" /> : pages.isError ? <div className="wboard-library-empty"><h3>Couldn’t load the library</h3><p role="alert">{readableError(pages.error)}</p><Button variant="quiet" type="button" disabled={pages.isFetching} onClick={() => void pages.refetch()}>Try again</Button></div> : <>
            <ul aria-label="Choose an HTML file">{shown.map(({ key, manifest: m, file }) => <li key={key}><Button variant="quiet" type="button" aria-pressed={selected?.key === key} disabled={submitting} onClick={() => { setSelection(key); setAttempted(false); setError(''); }}>
              <span className="wboard-library-file-icon" aria-hidden="true">&lt;/&gt;</span><span className="wboard-library-file-copy"><strong>{m.title}</strong><span>{file.path}</span>{m.summary && <small>{m.summary}</small>}<small className="wboard-library-date">{m.createdAt.slice(0, 10)}</small></span>
            </Button></li>)}</ul>
            {!shown.length && <div className="wboard-library-empty"><ShellIcon name="artifact" /><h3>{term ? 'No matching HTML files' : pages.hasNextPage ? 'No HTML in these results yet' : 'Your HTML library is empty'}</h3><p>{term ? 'Try a title, file name, or a word from the description.' : 'HTML artifacts published to this project will appear here.'}</p>{term && <Button variant="quiet" type="button" onClick={() => { setFilter(''); search.current?.focus(); }}>Clear search</Button>}</div>}
          </>}
        </div>
        {pages.hasNextPage && !pages.isError && <div className="wboard-library-more"><p>Search covers the files loaded so far.</p><Button variant="quiet" type="button" disabled={pages.isFetching || submitting} onClick={() => void pages.fetchNextPage()}>{pages.isFetching ? 'Loading more…' : 'Load more files'}</Button></div>}
      </section>
      <section className="wboard-library-preview" aria-label="Selected HTML preview">
        {selected ? <><header><div><span className="wboard-library-eyebrow">Preview</span><h3>{selected.manifest.title}</h3><p>{selected.file.path}</p></div><span className="wboard-library-type">HTML</span></header>
          {previewReady && <LibraryPreview key={previewUrl} src={previewUrl} title={selected.manifest.title} />}
          <details className="wboard-library-details"><summary>File details</summary><dl><dt>Published by</dt><dd>{selected.manifest.producer}</dd><dt>File size</dt><dd>{new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(selected.file.bytes / 1024)} KB</dd><dt>Saved version</dt><dd>{selected.manifest.revision.slice(0, 12)}</dd></dl><p>This exact file version will stay on your board.</p></details>
        </> : <div className="wboard-library-empty"><span className="wboard-library-preview-symbol" aria-hidden="true">&lt;/&gt;</span><h3>A little preview before you place it</h3><p>Choose an HTML file from the library.</p></div>}
      </section>
    </div>
    <footer className="wboard-library-footer"><div className="wboard-library-destination"><span>{replacing ? 'Replacing the selected HTML block' : `Adding to ${sectionTitle}`}</span><small>{selected ? selected.file.path : 'Choose a file to continue'}</small></div>
      {attempted && !submitting && <p role="alert" className="wboard-library-notice">{error || notice || 'Could not save this HTML. Try again.'}{!enabled && ' Return to the board to check the save status.'}</p>}
      <div className="wboard-library-actions"><Button variant="quiet" type="button" disabled={submitting} onClick={close}>{attempted && !enabled ? 'Return to board' : 'Cancel'}</Button><Button variant="quiet" type="button" className="wboard-library-add" disabled={!selected || !enabled || submitting} onClick={() => void add()}>{submitting ? 'Saving…' : replacing ? 'Replace HTML' : 'Add to board'}</Button></div>
    </footer>
  </dialog>, document.querySelector('.ws-whiteboard') ?? document.body);
}
