import { useState } from 'react';
import type { CompanionTurn } from '@studio/contracts';
import { Button } from './ui.js';
export function WhiteboardChatChanges({ changes, reveal }: { changes: NonNullable<CompanionTurn['changes']>; reveal(section: string, ids: string[]): void }) {
  const [choosing, setChoosing] = useState(false);
  const sections = [...new Set(changes.items.flatMap(item => item.sectionId === null ? [] : [item.sectionId]))];
  const missing = changes.items.filter(item => item.sectionId === null).length;
  const show = (section: string) => { setChoosing(false); reveal(section, changes.items.filter(item => item.sectionId === section).map(item => item.id)); };
  if (!changes.items.length && !changes.truncated) return null;
  return <div className="wboard-chat-changes">
    {!!sections.length && <Button variant="quiet" type="button" onClick={() => sections.length === 1 ? show(sections[0]!) : setChoosing(value => !value)} aria-expanded={sections.length > 1 ? choosing : undefined}>Show changes · {changes.items.length}{changes.truncated ? '+' : ''}</Button>}
    {choosing && <ul aria-label="Sections with changes">{sections.map(section => <li key={section}><Button variant="quiet" type="button" onClick={() => show(section)}>{section === 'root' ? 'Whiteboard' : section} · {changes.items.filter(item => item.sectionId === section).length}</Button></li>)}</ul>}
    {!!missing && <small>{missing} {missing === 1 ? 'item is' : 'items are'} deleted or no longer available.</small>}
    {changes.truncated && <small>Showing a limited set of this turn’s changes.</small>}
  </div>;
}
