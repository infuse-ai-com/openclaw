declare module '@studio/ui/icons' {
  export const icons: Record<'back' | 'download' | 'info' | 'minimize' | 'moon' | 'sun' | 'plugConnected' | 'plugDisconnected' | 'image' | 'eraser' | 'copy' | 'trash' | 'undo' | 'redo' | 'enter' | 'desktop' | 'folder' | 'home' | 'users' | 'board' | 'chart' | 'files' | 'library' | 'calendar' | 'settings' | 'operations' | 'radar' | 'plus' | 'list' | 'server' | 'document' | 'pause' | 'chevron' | 'edit' | 'alert' | 'building' | 'flask' | 'help' | 'search' | 'more' | 'profile' | 'switchProject' | 'review' | 'menu' | 'close' | 'pointer' | 'hand' | 'note' | 'minus' | 'fit' | 'refresh' | 'history' | 'check', string>;
}

declare module '@studio/ui/app-icons' {
  export const appActionIcons: Readonly<Record<'pin' | 'edit' | 'externalLink' | 'check', string>>;
  export const appIcons: Readonly<Record<string, string> & { apps: string }>;
}
