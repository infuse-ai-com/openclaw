import { PageHeader, Button, EmptyState } from './ui.js';
import { LoadingState } from './loading.js';
import { NativeProgress } from './native-progress.js';
import { NativeTaskInspection } from './native-task-inspection.js';
import { useState } from 'react';
import { useParams, useSearchParams } from 'react-router';
import { Link, useNavigate } from './navigation.js';
import { useQuery } from '@tanstack/react-query';
import { NATIVE_MESSAGE_MAX_UNITS, parseNativePaper, parseNativeCommand, missionIdentifier, type NativeMission, type NativeMissionView, type NativeDecision, type NativeReceipt, type NativeProvisionEffect } from '@studio/contracts';
import { useWorkspace } from './context.js';
import { api, accessDenied, projectPath, readableError } from './api.js';
import { useNativeMutation } from './native-mutations.js';
import './native-missions.css';

function parseView(input: unknown, id: string): NativeMissionView {
  const v = input as NativeMissionView;
  if (!v || v.mission?.contractVersion !== 2 || v.mission.id !== id || !Array.isArray(v.tasks) || !Array.isArray(v.assignments)
    || !Array.isArray(v.actions) || !Array.isArray(v.threads) || !Array.isArray(v.evidence) || !Array.isArray(v.events) || !Array.isArray(v.replies)) throw Error('Studio returned an invalid mission');
  parseNativePaper(v.mission.paper);
  if (v.tasks.some(t => t.missionId !== id) || v.assignments.some(a => a.missionId !== id) || v.threads.some(t => t.missionId !== id || new URL(t.origin).protocol !== 'https:')) throw Error('Mission records do not match');
  return v;
}
const label = (m: NativeMission) => m.held ? 'On hold' : ({ draft: 'Shaping', approved: 'Approved', running: 'In motion', closing: 'Closing', closed: 'Closed', cancelled: 'Cancelled' }[m.state]);

function NativeDelivery({ effect: p, data }: { effect: NativeProvisionEffect; data: NativeMissionView }) {
  const thread = data.threads.find(t => t.id === p.lifecycle?.threadId || t.rootPostId === p.rootPostId);
  const description = p.state === 'superseded' ? p.reason
    : p.state === 'uncertain' ? 'Waiting for an exact Mattermost receipt. This message will not be resent.'
    : p.state === 'queued' ? data.mission.held ? 'Waiting while the mission is on hold.' : 'Waiting for protected routes, account availability and preceding messages.'
    : p.state === 'sending' ? 'Sending; awaiting the Mattermost receipt.' : 'Delivered through the agent’s Mattermost account.';
  return <article className="ws-native-message"><span className="ws-status">{p.state}</span><strong>{p.taskMessage ? `Emon → @${p.taskMessage.recipientUsername}` : p.lifecycle ? `${p.lifecycle.agentId} · ${p.lifecycle.event}` : `${p.kind} delivery`}</strong>
    <p>{description}</p>{(p.lifecycle || p.taskMessage) && <details><summary>{p.taskMessage ? 'Task instruction' : 'Mission update'}</summary><p className="ws-literal">{p.text.replace(/\n\nStudio delivery: [^\n]+$/, '')}</p></details>}
    {p.postId && thread && <a className="ws-text-link" href={`${thread.origin}/_redirect/pl/${encodeURIComponent(p.postId)}`} target="_blank" rel="noreferrer">View message in Mattermost ↗</a>}</article>;
}

function NativeCommentBox({ missionId, threadId, coordination, disabled, refresh }: { missionId: string; threadId: string; coordination: boolean; disabled: boolean; refresh(): void }) {
  const { session, current } = useWorkspace();
  type Comment = { commandId: string; missionId: string; threadId: string; text: string };
  const mutation = useNativeMutation<Comment>(`comment:${missionId}:${threadId}`, input => {
    const value = input as Comment;
    if (!value || value.missionId !== missionId || value.threadId !== threadId || typeof value.text !== 'string' || !value.text.trim() || value.text.length > NATIVE_MESSAGE_MAX_UNITS) throw Error('Invalid saved comment');
    return { commandId: missionIdentifier(value.commandId), missionId, threadId, text: value.text };
  });
  const [text, setText] = useState(mutation.pending?.text ?? ''); const { busy, error, pending } = mutation;
  async function send() {
    if (!current || disabled || busy || !text.trim()) return;
    const result = await mutation.send({ commandId: crypto.randomUUID(), missionId, threadId, text }, '/api/studio/v2/comments', (receipt, command) => {
      const effect = receipt as { missionId?: string; authorProfileId?: string; text?: string };
      if (effect.missionId !== command.missionId || effect.authorProfileId !== session.profileId) throw Error('Comment receipt does not match its submitting person.');
    });
    if (result) { setText(''); refresh(); }
  }
  return <form className="ws-native-comment" onSubmit={e => { e.preventDefault(); void send(); }}><label className="ws-field">Comment as {session.displayName}<textarea required rows={3} maxLength={NATIVE_MESSAGE_MAX_UNITS} value={text} disabled={disabled || busy || !!pending} onChange={e => setText(e.target.value)} /></label><p className="ws-small">Sent through Emon’s account with your name attached. {coordination ? 'Emon receives messages here without a mention.' : 'Use an explicit @handle to request action; other messages add context.'} {text.length}/{NATIVE_MESSAGE_MAX_UNITS} units (emoji may count as two). Split longer comments explicitly.</p>{error && <p className="ws-alert" role="alert">{error}</p>}<Button type="submit" disabled={!current || disabled || busy || mutation.blocked || !text.trim()}>{busy ? 'Saving…' : pending ? 'Retry exact comment' : 'Send comment'}</Button></form>;
}

export async function getNativeMission(projectId: string, missionId: string, signal?: AbortSignal) {
  const view = parseView(await api(projectPath(`/api/studio/v2/missions/${encodeURIComponent(missionId)}`, projectId), { signal }), missionId);
  if (view.mission.projectId !== projectId) throw Error('The mission does not match the selected project.');
  return view;
}

export async function getNativeMissions(projectId: string, signal?: AbortSignal) {
  const v = await api(projectPath('/api/studio/v2/missions', projectId), { signal });
  if (!Array.isArray(v) || v.some(m => m.contractVersion !== 2 || m.projectId !== projectId)) throw Error('Invalid native mission list');
  for (const m of v) parseNativePaper(m.paper);
  return v as NativeMission[];
}

export function ComposeNativeMission() {
  const { session, current } = useWorkspace(); const navigate = useNavigate();
  const mutation = useNativeMutation('draft', input => {
    const command = parseNativeCommand(input);
    if (command.type !== 'create' || command.projectId !== session.project.id) throw Error('Saved draft belongs to another project');
    return command;
  });
  const [draft, setDraft] = useState(mutation.pending?.paper ?? { title: '', objective: '', acceptance: '' });
  const { error, busy, pending } = mutation;
  const configured = session.nativeMissions?.coordinator;
  const coordinator = session.bootstrap.targets.find(t => t.gatewayId === configured?.gatewayId && t.agentId === configured?.agentId);
  async function save() {
    if (!current || busy || !coordinator) return;
    const result = await mutation.send({ contractVersion: 2, commandId: crypto.randomUUID(), missionId: crypto.randomUUID(), type: 'create', projectId: session.project.id,
      paper: { title: draft.title, objective: draft.objective, acceptance: draft.acceptance, coordinator, tasks: [], permissions: [], humanAcceptance: false } },
    '/api/studio/v2/commands', (value, command) => {
      const receipt = value as NativeReceipt;
      if (receipt.contractVersion !== 2 || receipt.commandId !== command.commandId || receipt.missionId !== command.missionId) throw Error('Draft receipt does not match the saved request.');
    }) as NativeReceipt | undefined;
    if (result) navigate(`/missions/v2/${encodeURIComponent(result.missionId)}`);
  }
  return <section className="ws-surface ui-layout-list"><PageHeader eyebrow={<>{session.project.name} / GRILLING</>} title={<>Grilling</>} description={<>Turn an intention into a mission with Emon.</>} actions={<><Link to="/missions" className="ws-text-link">Back to missions</Link></>} />
    <div className="ws-compose-layout ws-native-intake ui-page-content"><aside className="ws-outline"><span className="ws-eyebrow">SHAPE WITH EMON</span><p>Emon clarifies the work and prepares independently verifiable tasks. You approve the exact paper before specialists begin.</p><p>Starting this intake can ask Emon to shape the draft. Conversations continue in the project’s Mattermost channel and task threads.</p><p>Open an existing draft from Missions to continue its current paper and thread.</p></aside>
      <form className="ws-form-paper" onSubmit={e => { e.preventDefault(); void save(); }}><h2>What should be different?</h2>{error && <p className="ws-alert" role="alert">{error}</p>}
        {(['title', 'objective', 'acceptance'] as const).map(field => <label key={field} className="ws-field">{{ title: 'Mission name', objective: 'Desired outcome', acceptance: 'What would make this successful?' }[field]}{field === 'title' ? <input required maxLength={180} value={draft[field]} disabled={busy || !!pending} onChange={e => setDraft({ ...draft, [field]: e.target.value })} placeholder="A short name for the work" /> : <textarea required maxLength={8192} rows={4} value={draft[field]} disabled={busy || !!pending} onChange={e => setDraft({ ...draft, [field]: e.target.value })} placeholder={field === 'objective' ? 'What should change, and why does it matter?' : 'What evidence would show that it worked?'} />}</label>)}
        <p className="ws-small">{coordinator?.agentId ?? 'No coordinator is configured'} coordinates this draft. Agents keep their existing tools and skills; this adds no access.</p><div className="ws-actions ws-actions--end"><Button type="submit" disabled={!current || busy || mutation.blocked || !coordinator}>{busy ? 'Saving…' : pending ? 'Retry exact draft' : 'Save draft for Emon'}</Button></div>
      </form></div>
  </section>;
}

export function NativeMissionDetail() {
  const { missionId = '' } = useParams(); const { session, owner, current, visible } = useWorkspace();
  const [search, setSearch] = useSearchParams(); const section = search.get('section') ?? 'tasks';
  const [decision, setDecision] = useState<NativeDecision>(); const [error, setError] = useState(''); const [busy, setBusy] = useState(false); const [selectedThread, setSelectedThread] = useState('');
  const view = useQuery({ queryKey: ['workspace', owner, 'native-mission', missionId], enabled: current,
    queryFn: ({ signal }) => getNativeMission(session.project.id, missionId, signal), refetchInterval: current && visible ? 5000 : false });
  const data = accessDenied(view.error) ? undefined : view.data; const stale = !current || view.isError;
  if (!data && current && !view.isError) return <section className="ws-surface"><header className="ws-surface-header"><div><Link className="ws-text-link" to="/missions">← Missions</Link><h1>Mission</h1></div></header><LoadingState label="Loading mission…" size="page" /></section>;
  if (!data) return <section className="ws-surface"><EmptyState level={1} role={view.isError ? 'alert' : 'status'} title={view.isError ? 'This mission could not be opened.' : 'Reconnect to open this mission.'} actions={<Link to="/missions">Back to missions</Link>}>{view.isError ? readableError(view.error) : undefined}</EmptyState></section>;
  const m = data.mission; const terminal = ['closed', 'cancelled'].includes(m.state);
  const decisionCurrent = decision?.missionId === m.id && decision.controlEpoch === m.controlEpoch && decision.paperRevision === m.paperRevision && decision.paperDigest === m.paperDigest;
  const thread = data.threads.find(t => t.id === selectedThread) ?? data.threads.find(t => t.kind === 'coordination') ?? data.threads[0];
  const uncertain = data.actions.filter(a => ['uncertain', 'failed'].includes(a.state));
  async function prepare(action: NativeDecision['action']) {
    setBusy(true); setError('');
    try { const d = await api(projectPath('/api/studio/v2/decisions/prepare', session.project.id), { command: { missionId, action }, csrf: session.csrfToken }) as NativeDecision;
      if (d.missionId !== missionId || d.action !== action) throw Error('Decision does not match'); setDecision(d); }
    catch (e) { setError(readableError(e)); } finally { setBusy(false); }
  }
  async function confirm() {
    if (!current || !session.bootstrap.capabilities.approver || view.isFetching || !decision || !decisionCurrent) return; setBusy(true); setError('');
    try { await api(projectPath('/api/studio/v2/decisions/resolve', session.project.id), { command: { decisionId: decision.id }, csrf: session.csrfToken }); setDecision(undefined); await view.refetch(); }
    catch (e) { setError(readableError(e)); } finally { setBusy(false); }
  }
  return <section className="ws-surface" aria-label="Native mission"><header className="ws-surface-header ws-surface-header--document"><div><span className="ws-eyebrow">{session.project.name} / PAPER {m.paperRevision}</span><h1>{m.paper.title}</h1><p>{label(m)} · {m.paper.coordinator.agentId} coordinates · {data.tasks.filter(t => t.plan.required && t.state === 'verified').length}/{data.tasks.filter(t => t.plan.required).length} required tasks verified</p></div><Link to="/missions" className="ws-text-link">Mission board ↗</Link></header>
    {stale && <p className="ws-alert" role="alert">Showing the last known state. Refresh before making a decision.</p>}{error && <p className="ws-alert" role="alert">{error}</p>}
    {uncertain.length > 0 && <div className="ws-alert">{uncertain.length} runtime actions need attention. Uncertain actions wait for a matching receipt before any retry.</div>}
    <NativeProgress data={data} />
    <div className="ws-native-controls"><span className={`ws-status ws-status--${m.state}`}>{label(m)}</span><div className="ws-actions">{session.bootstrap.capabilities.approver && !terminal && (m.held ? ['resume', 'cancel'] : m.state === 'draft' ? ['approve', 'hold', 'cancel'] : m.state === 'closing' && m.paper.humanAcceptance ? ['accept', 'hold', 'cancel'] : ['hold', 'cancel']).map(action => <Button variant="quiet" key={action}  disabled={stale || busy || view.isFetching || action === 'approve' && !m.paper.tasks.some(task => task.required) || (['approve', 'resume'].includes(action) && !session.nativeMissions?.enabled)} onClick={() => void prepare(action as NativeDecision['action'])}>{action[0]!.toUpperCase() + action.slice(1)}</Button>)}<Button variant="quiet" disabled={!current || view.isFetching} onClick={() => void view.refetch()}>Refresh</Button></div></div>
    {decision && <section className="ws-native-decision" aria-label="Review exact decision"><span className="ws-eyebrow">REVIEWED PAPER {decision.paperRevision}</span><h2>{decision.action[0]!.toUpperCase() + decision.action.slice(1)} this mission?</h2><p>This applies to the exact reviewed paper and permission scope.</p><p className="ws-literal">{m.paper.objective}</p><p className="ws-literal">{m.paper.acceptance}</p><ul>{m.paper.tasks.map(task => <li key={task.id}>{task.title} · {task.owner.agentId} · {task.acceptance}</li>)}</ul><p>{m.paper.permissions.join(' · ') || 'No additional permissions granted.'}</p><code>{decision.paperDigest}</code>{!decisionCurrent && <p className="ws-alert">The paper or mission controls changed. Prepare a new decision after reviewing it.</p>}<p className="ws-small">Mattermost control: <code>!studio {decision.action} {decision.id}</code></p><div className="ws-actions"><Button disabled={stale || busy || view.isFetching || !session.bootstrap.capabilities.approver || !decisionCurrent} onClick={() => void confirm()}>Confirm {decision.action}</Button><Button variant="quiet" disabled={busy} onClick={() => setDecision(undefined)}>Dismiss</Button></div></section>}
    <div className="ws-detail-tabs ui-tabs" role="group" aria-label="Mission sections">{[['paper', 'Mission paper'], ['tasks', 'Tasks & owners'], ['conversations', 'Conversations'], ['evidence', 'Evidence & review'], ['activity', 'Runtime activity']].map(([id, name]) => <button key={id} aria-pressed={section === id} onClick={() => setSearch(previous => { const next = new URLSearchParams(previous); next.set('section', id!); return next; })}>{name}</button>)}</div>
    {section === 'paper' && <article className="ws-paper"><div className="ws-paper-mark"><span>INFUSE / STUDIO</span><span>PAPER {m.paperRevision}</span></div><h2>{m.paper.title}</h2><section><span className="ws-eyebrow">01 / THE OUTCOME</span><p className="ws-literal">{m.paper.objective}</p></section><section><span className="ws-eyebrow">02 / ACCEPTANCE</span><p className="ws-literal">{m.paper.acceptance}</p></section><section><span className="ws-eyebrow">03 / PERMISSION SCOPE</span><p>Agents retain their enrolled tools and skills. This paper adds no tools or credentials.</p>{m.paper.permissions.map(p => <p key={p} className="ws-literal">{p}</p>)}</section><section><span className="ws-eyebrow">04 / CLOSEOUT</span><p>Emon verifies every required task and closes after runs settle. {m.paper.humanAcceptance ? 'Final human acceptance is required.' : 'Final human acceptance is optional.'}</p></section>{m.approval && <p className="ws-small">Approved by {m.approval.profileId} · paper {m.approval.paperRevision}</p>}</article>}
    {section === 'evidence' && <p className="ws-evidence-library"><Link className="ws-text-link" to={`/artifacts?${new URLSearchParams({ mission: m.id })}`}>Browse this mission's HTML artifacts ↗</Link></p>}
    {(section === 'tasks' || section === 'evidence') && <NativeTaskInspection data={data} evidenceView={section === 'evidence'} taskId={search.get('task')} selectTask={id => setSearch(previous => { const next = new URLSearchParams(previous); next.set('task', id); return next; })} />}
    {section === 'conversations' && <div className="ws-native-conversations"><aside><h2>Conversations</h2>{data.threads.map(t => <button key={t.id} aria-pressed={t.id === thread?.id} onClick={() => setSelectedThread(t.id)}><strong>{t.kind === 'coordination' ? 'Mission coordination' : data.tasks.find(task => task.id === t.taskId)?.plan.title ?? t.taskId}</strong><small>Assignment {t.generation}</small></button>)}</aside><section aria-label="Selected conversation">{thread ? <><header><h2>{thread.kind === 'coordination' ? 'With Emon' : 'Specialist thread'}</h2><a className="ws-text-link" target="_blank" rel="noreferrer" href={`${thread.origin}/_redirect/pl/${encodeURIComponent(thread.rootPostId)}`}>Open in Mattermost ↗</a></header>{data.events.filter(e => e.threadId === thread.id && !data.provisioning?.some(p => (p.kind === 'lifecycle' || p.kind === 'task-message') && p.postId === e.sourceId)).map(e => <article className="ws-native-message" key={e.sequence}><strong>{e.author.displayName}</strong><small>{e.author.kind} · {new Date(e.at).toLocaleString()}</small><p className="ws-literal">{e.text}</p>{e.addressedAgentIds.length > 0 && <span className="ws-small">Addressed to {e.addressedAgentIds.join(', ')}</span>}</article>)}{!data.events.some(e => e.threadId === thread.id) && <p>No messages recorded yet.</p>}{data.provisioning?.filter(p => p.rootPostId === thread.rootPostId && (p.kind === 'lifecycle' || p.kind === 'task-message' || p.state !== 'delivered')).map(p => <NativeDelivery key={p.id} effect={p} data={data} />)}<NativeCommentBox key={thread.id} missionId={missionId} threadId={thread.id} coordination={thread.kind === 'coordination'} disabled={stale} refresh={() => void view.refetch()} /></> : <EmptyState level={2} title={<>Conversation is being prepared.</>}  >Studio waits for protected native routes before posting a handoff.</EmptyState>}</section></div>}
    {section === 'activity' && <div className="ws-native-activity">{data.provisioning?.map(p => <NativeDelivery key={p.id} effect={p} data={data} />)}{data.actions.map(a => <article key={a.id}><span className={`ws-status ws-status--${a.state}`}>{a.state}</span><strong>{a.agentId}</strong><span>{a.cause}</span><p>{a.failure ?? (a.state === 'queued' ? 'Waiting for dependencies, native thread and agent availability.' : a.state === 'uncertain' ? 'Awaiting reconciliation with the Gateway receipt.' : '')}</p><details><summary>Identity and receipts</summary><dl><div><dt>Action</dt><dd>{a.id}</dd></div><div><dt>Assignment</dt><dd>{a.assignmentId}</dd></div><div><dt>Session</dt><dd>{a.sessionId ?? 'Awaiting binding'}</dd></div><div><dt>Run</dt><dd>{a.runId ?? 'Not observed'}</dd></div></dl></details></article>)}</div>}
  </section>;
}
