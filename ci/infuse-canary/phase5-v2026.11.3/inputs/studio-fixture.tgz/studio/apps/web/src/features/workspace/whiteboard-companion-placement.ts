import { useLayoutEffect, useRef, useState, type RefObject, type PointerEvent, type KeyboardEvent } from 'react';
import { clampChat } from './whiteboard-companion-layout.js';
type Position = { x: number; y: number };
type Preset = 'bottom-left' | 'bottom-right' | 'top-left' | 'top-right';
export function useCompanionPlacement(panel: RefObject<HTMLElement | null>, owner: string, open: boolean) {
  const key = 'studio-companion-placement:' + owner;
  const [expanded, setExpanded] = useState(false), [position, setPosition] = useState<Position>();
  const saved = useRef<Position | Preset>('bottom-left');
  const drag = useRef<{ pointer: number; x: number; y: number; start: Position } | null>(null);
  useLayoutEffect(() => { try { const value = JSON.parse(localStorage.getItem(key) || 'null');
    if (['bottom-left','bottom-right','top-left','top-right'].includes(value) || value && Number.isFinite(value.x) && Number.isFinite(value.y)) saved.current = value;
  } catch { /* Default placement works without storage. */ } }, [key]);
  function layout() {
    const element = panel.current, workspace = element?.closest('.ws-whiteboard')?.getBoundingClientRect();
    if (!element || !workspace) return;
    const short = Math.min(innerHeight, workspace.height) < 600;
    const top = Math.max(0, workspace.top) + (short ? 12 : 64), bottom = Math.min(innerHeight, workspace.bottom) - (short ? 24 : workspace.width < 720 ? 152 : 80);
    const left = Math.max(0, workspace.left) + 12, right = Math.min(innerWidth, workspace.right) - 12;
    const bounds = { x: left, y: top, width: Math.max(0, right - left), height: Math.max(180, bottom - top) };
    element.style.width = Math.min(340, bounds.width) + 'px';
    element.style.height = Math.min(expanded ? 640 : 520, bounds.height) + 'px';
    const size = element.getBoundingClientRect(), value = saved.current;
    const desired = typeof value === 'string' ? { x: value.endsWith('right') ? right - size.width : left, y: value.startsWith('bottom') ? bottom - size.height : top }
      : { x: workspace.left + value.x, y: workspace.top + value.y };
    const next = clampChat(desired, bounds, size);
    setPosition(old => old?.x === next.x && old?.y === next.y ? old : next);
    return { workspace, bounds, size, next };
  }
  function remember(value: Position | Preset) { saved.current = value; try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* Keep placement for this tab. */ } layout(); }
  useLayoutEffect(() => {
    if (!open) return;
    layout(); const workspace = panel.current?.closest('.ws-whiteboard');
    const observer = new ResizeObserver(() => layout()); if (workspace) observer.observe(workspace);
    window.addEventListener('resize', layout);
    return () => { observer.disconnect(); window.removeEventListener('resize', layout); };
  }, [open, expanded]);
  function move(x: number, y: number) { const state = layout(); if (!state) return;
    const next = clampChat({x,y}, state.bounds, state.size); remember({x:next.x-state.workspace.left,y:next.y-state.workspace.top}); }
  return { position, expanded, toggle: () => setExpanded(value => !value), preset: (value: Preset) => remember(value),
    handle: {
      onPointerDown(event: PointerEvent<HTMLButtonElement>) { if(event.button !== 0) return; const state = layout(); if (!state) return;
        event.preventDefault(); event.currentTarget.focus(); event.currentTarget.setPointerCapture(event.pointerId);
        drag.current = { pointer: event.pointerId, x: event.clientX, y: event.clientY, start: state.next }; },
      onPointerMove(event: PointerEvent<HTMLButtonElement>) { const active = drag.current; if(active?.pointer === event.pointerId) move(active.start.x + event.clientX - active.x, active.start.y + event.clientY - active.y); },
      onPointerUp() { drag.current = null; }, onPointerCancel() { drag.current = null; },
      onKeyDown(event: KeyboardEvent<HTMLButtonElement>) { const offset = {ArrowLeft:[-24,0],ArrowRight:[24,0],ArrowUp:[0,-24],ArrowDown:[0,24]}[event.key];
        const state = layout(); if(offset && state) { event.preventDefault(); event.stopPropagation(); move(state.next.x+offset[0]!,state.next.y+offset[1]!); } },
    },
  };
}
