import { OfficeLoading } from './office-loading.js';
import { useEffect, useRef, useState } from 'react';
import { createCompanyBuilding, type CompanyProject } from '../studio/company-building.js';

export function OfficeScene({ projects, shown, enter, ready, hour, moving, storm, manage }: { projects: CompanyProject[]; shown: boolean; hour: number; moving: boolean; storm: boolean; enter(id: string): void; manage?: () => void; ready(value: boolean): void }) {
  const root = useRef<HTMLDivElement>(null), scene = useRef<ReturnType<typeof createCompanyBuilding> | undefined>(undefined);
  const navigate = useRef(enter); navigate.current = enter;
  const management = useRef(manage); management.current = manage;
  const canManage = !!manage;
  const latest = useRef(projects); latest.current = projects;
  const presented = useRef(shown); presented.current = shown;
  const atmosphere = useRef({ hour, moving, storm }); atmosphere.current = { hour, moving, storm };
  const [failed, setFailed] = useState(false);
  const [loading, setLoading] = useState(true);
  const projectKey = JSON.stringify(projects);
  useEffect(() => {
    ready(false); if (failed) return; setLoading(true);
    let cancelled = false;
    void document.fonts.load('600 33px StudioPlex').then(() => {
      if (cancelled) return;
      const space = createCompanyBuilding(root.current!, latest.current, id => navigate.current(id), () => setFailed(true), canManage ? () => management.current?.() : undefined);
      scene.current = space; space.setAtmosphere(atmosphere.current.hour, atmosphere.current.moving, atmosphere.current.storm); space.setPresented(presented.current); ready(root.current?.dataset.webgl === 'ready'); setLoading(false);
    }).catch(() => { if (!cancelled) setFailed(true); });
    return () => { cancelled = true; scene.current?.dispose(); scene.current = undefined; };
  }, [projectKey, failed, ready, canManage]);
  useEffect(() => { scene.current?.setPresented(shown); }, [shown, projectKey, failed]);
  useEffect(() => { scene.current?.setAtmosphere(hour, moving, storm); }, [hour, moving, storm]);
  return failed ? <div key="unavailable" className="ws-scene-error" role="status"><h2>Office view unavailable.</h2><p>Use the Project selector and Project floor in the sidebar. Your missions and decisions remain available.</p></div>
    : <><div key="scene" className="ws-office-world" ref={root} />{loading && <OfficeLoading />}</>;
}
