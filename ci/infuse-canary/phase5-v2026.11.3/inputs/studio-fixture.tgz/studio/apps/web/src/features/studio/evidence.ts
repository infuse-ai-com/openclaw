import { parseMissionEvidenceRead, type Mission, type MissionArtifact, type MissionEvidence, type MissionView } from '@studio/contracts';
import { correctionMarkup, type CorrectionDraft } from './corrections.js';
import { coordinatorCloseout, dateLabel, escapeHtml as e, gatePending, safeEvidenceUrl, targetLabel, terminal } from './presentation.js';

export type EvidenceInspection =
  | { status: 'idle' }
  | { status: 'loading'; key: string }
  | { status: 'error'; key: string; message: string }
  | { status: 'ready'; key: string; artifact: MissionArtifact };

export function evidenceRevisions(mission?: Mission): MissionEvidence[] {
  if (!mission) return [];
  return [...(mission.correction ? [mission.correction.evidence] : []), ...(mission.task.evidence ? [mission.task.evidence] : [])];
}
export function displayedEvidence(mission: Mission | undefined, selection: string): MissionEvidence | undefined {
  const revisions = evidenceRevisions(mission);
  return revisions.find(evidence => evidence.revision === selection) ?? revisions.at(-1);
}
export function isLatestEvidence(mission?: Mission, evidence?: MissionEvidence): boolean {
  return !!evidence && evidence.revision === mission?.task.evidence?.revision && evidence.sha256 === mission.task.evidence.sha256;
}
export function managedEvidence(mission?: Mission, evidence = mission?.task.evidence): boolean {
  return evidence?.uri.startsWith('artifact:studio:') === true;
}
export function evidenceKey(owner: string, mission?: Mission, evidence = mission?.task.evidence): string {
  return mission && evidence ? JSON.stringify([owner, mission.id, mission.version, evidence]) : '';
}
export function inspected(inspection: EvidenceInspection, key: string): boolean {
  return inspection.status === 'ready' && inspection.key === key;
}

/** Content stays untrusted text even after its integrity has been established. */
export async function checkArtifact(value: unknown, mission: Mission, evidence = mission.task.evidence): Promise<MissionArtifact> {
  const result = parseMissionEvidenceRead(value);
  if (!evidence || result.missionId !== mission.id || result.version !== mission.version
    || result.evidenceHash !== evidence.sha256 || result.evidenceRevision !== evidence.revision || result.status !== 'available') {
    throw Error('The response does not match the mission and evidence being reviewed. Refresh the mission and inspect again.');
  }
  const artifact = result.artifact;
  const bytes = new TextEncoder().encode(artifact.content);
  const digest = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
    .map(byte => byte.toString(16).padStart(2, '0')).join('');
  if (artifact.uri !== evidence.uri || artifact.revision !== evidence.revision || artifact.sha256 !== evidence.sha256
    || artifact.byteLength !== bytes.length || digest !== evidence.sha256) {
    throw Error('These contents do not match the recorded evidence. Acceptance is disabled. Refresh the mission or inspect again.');
  }
  return artifact;
}

const fact = (label: string, value: string): string => `<div class="studio-fact"><dt>${label}</dt><dd><code>${e(value)}</code></dd></div>`;
export function evidenceMarkup(m: Mission, inspection: EvidenceInspection, options: {
  progress?: MissionView['closeoutProgress']; key: string; readable: boolean; decisions: boolean; reviewed: boolean; selection: string;
  correctionDraft?: CorrectionDraft; correctionEligible: boolean; pending: boolean;
}): string {
  const revisions = evidenceRevisions(m);
  const evidence = displayedEvidence(m, options.selection);
  if (!evidence) return `<section class="studio-evidence-empty studio-inline-empty" data-section="evidence"><h2>${m.state === 'cancelled' ? 'No evidence was delivered.' : 'Evidence will appear here.'}</h2><p>${m.state === 'cancelled' ? 'This cancelled mission has no recorded evidence.' : 'No evidence has been delivered for this mission.'}</p></section>`;
  const latest = isLatestEvidence(m, evidence);
  const managed = managedEvidence(m, evidence);
  const ready = inspected(inspection, options.key);
  const autonomous = coordinatorCloseout(m);
  const action = m.state === 'closed' && !m.acknowledgement ? 'acknowledge'
    : !terminal(m) && m.task.state === 'verified' && autonomous && gatePending(m) ? 'resolve-closeout-gate'
    : !terminal(m) && m.task.state === 'verified' && !autonomous ? 'accept' : undefined;
  const reviewable = options.decisions && latest && (!managed || ready) && (action !== 'resolve-closeout-gate' || !m.held);
  const actionLabel = action === 'acknowledge' ? 'Acknowledge this result' : action === 'resolve-closeout-gate' ? 'Resolve human gate' : 'Accept this result';
  const loading = inspection.status === 'loading' && inspection.key === options.key;
  const url = safeEvidenceUrl(evidence.uri);
  const heading = m.state === 'cancelled' ? 'Evidence from this cancelled mission.' : !latest ? m.task.evidence ? 'An earlier result.' : 'The correction is underway.' : m.state === 'closed' ? 'The coordinator closed this result.' : m.state === 'accepted' ? 'The accepted result.' : m.task.state === 'verified' ? autonomous ? 'The coordinator verified this result.' : 'The result needs your judgment.' : 'Evidence awaits coordinator verification.';
  const artifact = ready && inspection.status === 'ready' ? inspection.artifact : undefined;
  return `<section class="studio-evidence" data-section="evidence" aria-label="Evidence review">
    <span class="studio-kicker">DELIVERY / REVISION ${e(evidence.revision)}</span><h2>${heading}</h2>
    ${m.correction ? `<div class="studio-correction-record"><span class="studio-kicker">CORRECTION REQUESTED / REVISION ${e(m.correction.evidence.revision)}</span><p class="studio-prose">${e(m.correction.reason).replaceAll('\r', '&#13;')}</p><p class="studio-small">${e(m.correction.profileId)} · ${e(dateLabel(m.correction.at))}</p><p class="studio-small">${m.task.evidence ? 'A replacement is available. Review it against this request and the approved criteria.' : m.state === 'cancelled' ? 'The mission was cancelled before a replacement was delivered.' : 'A fresh specialist assignment will produce the replacement. The original result remains readable below.'}</p></div><label class="studio-revision-picker">Artifact revision<select data-field="evidenceRevision">${revisions.map(item => `<option value="${e(item.revision)}" ${item.revision === evidence.revision ? 'selected' : ''}>Revision ${e(item.revision)} · ${isLatestEvidence(m, item) ? 'Latest result' : 'Original result'}</option>`).join('')}</select></label>` : ''}
    ${!latest ? `<div class="studio-banner studio-banner--warning studio-revision-warning"><strong>Earlier revision.</strong> This result is read-only. ${m.task.evidence ? '<button type="button" class="studio-button studio-button--secondary" data-action="latest-evidence">Return to latest result</button>' : m.state === 'cancelled' ? 'This mission is cancelled.' : 'Acceptance waits for a verified replacement.'}</div>` : ''}
    <p class="studio-prose">${e(evidence.summary)}</p>
    ${managed ? `<div class="studio-artifact-toolbar"><div><strong>${artifact ? 'Contents loaded' : 'A stored mission artifact'}</strong><p class="studio-small">Read the result against the approved criteria before deciding.</p></div><button type="button" class="studio-button studio-button--secondary" data-action="inspect-evidence" ${!options.readable || loading ? 'disabled' : ''}>${loading ? 'Loading contents…' : 'Inspect contents'}</button></div>
      ${loading ? '<p class="studio-small" role="status">Retrieving the stored text and checking its SHA-256…</p>' : ''}
      ${inspection.status === 'error' && inspection.key === options.key ? `<div class="studio-banner studio-banner--warning" role="alert">${e(inspection.message)}</div>` : ''}
      ${artifact ? `<div class="studio-artifact-integrity" role="status"><strong>Content hash matches</strong><span>${artifact.byteLength.toLocaleString('en')} bytes · ${e(artifact.mediaType)} · SHA-256 checked in this browser</span><code>${e(artifact.sha256)}</code></div>
        <div class="studio-artifact-review"><div class="studio-artifact-document"><h3>Artifact contents</h3><pre class="studio-artifact-source" data-focus="artifact-content" data-artifact-key="${e(options.key)}" tabindex="0" aria-label="Artifact contents"><code class="studio-artifact-content">${e(artifact.content).replaceAll('\r', '&#13;')}</code></pre><p class="studio-small">${artifact.mediaType === 'text/markdown' ? 'Markdown source, shown as literal text.' : 'Exact stored text.'} A matching hash confirms these bytes; it does not establish that the work meets the criteria.</p></div><aside class="studio-artifact-criteria" aria-label="Approved acceptance criteria"><span class="studio-kicker">JUDGE THE RESULT</span><h3>Approved criteria</h3><p class="studio-prose">${e(m.paper.acceptance)}</p></aside></div>
        <dl class="studio-artifact-producer">${fact('Produced by', targetLabel(artifact.producer))}${fact('Stored', dateLabel(artifact.createdAt))}${fact('Assignment', artifact.producer.assignmentId)}${fact('Assignment generation', String(artifact.producer.generation))}</dl>` : '<p class="studio-small">Contents must load and match the recorded hash before you can confirm review in Studio.</p>'}`
      : `${url ? `<a href="${e(url)}" target="_blank" rel="noopener noreferrer" class="studio-button studio-button--secondary">Open evidence ↗</a>` : '<p class="studio-small">This external artifact reference has no content provider in Studio.</p>'}<p class="studio-small">These are recorded evidence metadata. Studio has not fetched the artifact contents or independently checked their hash.</p>`}
    <details class="studio-artifact-provenance" data-detail="evidence-provenance"><summary data-focus="evidence-provenance">Evidence reference and recorded digest</summary><dl>${fact('Evidence reference', evidence.uri)}${fact('Revision', evidence.revision)}${fact('SHA-256', evidence.sha256)}</dl></details>
    ${options.correctionDraft ? correctionMarkup(m, options.correctionDraft, options.correctionEligible, options.pending) : !autonomous && latest && managed && m.state === 'running' && m.task.state === 'verified' && !m.correction ? `<div class="studio-correction-entry"><button type="button" class="studio-button studio-button--secondary" data-action="open-correction" ${options.correctionEligible ? '' : 'disabled'}>Request correction…</button><p class="studio-small">One correction round is available before acceptance. Inspect the contents first.</p></div>` : ''}
    ${m.verification && latest ? `<div class="studio-correction-record"><span class="studio-kicker">COORDINATOR VERIFICATION</span><p class="studio-prose">${e(m.verification.assessment.summary)}</p><p class="studio-small">${e(targetLabel(m.verification.actor))} · ${e(dateLabel(m.verification.at))} · revision ${e(m.verification.evidenceRevision)}</p><p class="studio-small">${m.verification.assessment.residualGaps.length ? `Residual gaps: ${e(m.verification.assessment.residualGaps.join('; '))}` : 'No residual gaps reported.'}</p></div>` : ''}
    ${action ? `<div class="studio-accept"><label><input type="checkbox" data-field="reviewedEvidence" ${options.reviewed ? 'checked' : ''} ${reviewable ? '' : 'disabled'}> I reviewed this evidence and its acceptance criteria.</label><button type="button" class="studio-button" data-action="${action}" ${!reviewable || !options.reviewed ? 'disabled' : ''}>${actionLabel}</button><p class="studio-small">${action === 'acknowledge' ? 'Acknowledgement is optional. Coordinator closeout is already recorded.' : action === 'resolve-closeout-gate' ? 'This paper requires this human gate before coordinator closeout can finish.' : 'This paper retains its human acceptance step.'}</p></div>` : ''}
    ${m.state === 'closed' ? `<div class="studio-banner">Closed by ${e(m.closeout?.actor.agentId)} for revision ${e(m.closeout?.evidenceRevision)}. ${m.acknowledgement ? `Acknowledged by ${e(m.acknowledgement.profileId)}.` : 'No human acceptance is required.'}</div>` : m.state === 'accepted' ? latest ? '<div class="studio-banner">Your acceptance is recorded for this evidence hash.</div>' : '<p class="studio-small">Acceptance belongs to the latest result. This original revision remains in the history.</p>' : m.state === 'cancelled' ? '<p class="studio-small">This mission was cancelled. Its recorded evidence remains inspectable.</p>' : m.closeoutRequest ? `<p class="${options.progress?.state === 'blocked' ? 'studio-banner studio-banner--warning' : 'studio-small'}">${e(options.progress?.reason ?? 'Closeout requested. Studio is waiting for the approved gate and terminal runtime receipts.')}</p>` : autonomous ? '<p class="studio-small">The coordinator verifies the current revision and requests closeout under the approved policy.</p>' : '<p class="studio-small">Human acceptance becomes available after the assigned coordinator verifies the latest result’s revision and hash.</p>'}

  </section>`;
}
