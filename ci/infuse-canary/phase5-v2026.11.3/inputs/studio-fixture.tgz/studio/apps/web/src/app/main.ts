import './styles.css';
import { startWorkspace } from '../features/workspace/app.js';
const root = document.querySelector<HTMLElement>('#app');
if (!root) throw new Error('Missing app root');
void startWorkspace(root).catch(() => {
  root.textContent = 'Studio could not start. Reload this page to try again.';
});
