import { Button, IconButton, ViewSwitch } from '../../../ui.js';
import {
  readerTextSizes,
  type ReaderTextSize,
  type ReaderWidth,
  type Theme,
} from '../useDisplayPreferences';

interface ReadingSettingsProps {
  focusAvailable: boolean;
  focusReader: boolean;
  onReaderWidthChange: (width: ReaderWidth) => void;
  onResetDisplayPreferences: () => void;
  onTextSizeChange: (size: ReaderTextSize) => void;
  onThemeChange: (theme: Theme) => void;
  onToggleFocus: () => void;
  readerTextSize: ReaderTextSize;
  readerWidth: ReaderWidth;
  theme: Theme;
}

function ThemeIcon({ theme }: { theme: Theme }) {
  if (theme === 'system') {
    return (
      <svg aria-hidden="true" viewBox="0 0 20 20">
        <rect height="11" rx="2" width="16" x="2" y="2" />
        <path d="M7 17h6M10 13v4" />
      </svg>
    );
  }
  if (theme === 'light') {
    return (
      <svg aria-hidden="true" viewBox="0 0 20 20">
        <circle cx="10" cy="10" r="3.25" />
        <path d="M10 1.75v2M10 16.25v2M1.75 10h2M16.25 10h2M4.16 4.16l1.42 1.42M14.42 14.42l1.42 1.42M15.84 4.16l-1.42 1.42M5.58 14.42l-1.42 1.42" />
      </svg>
    );
  }
  return (
    <svg aria-hidden="true" viewBox="0 0 20 20">
      <path d="M16.75 12.6A7.25 7.25 0 0 1 7.4 3.25a7.25 7.25 0 1 0 9.35 9.35Z" />
    </svg>
  );
}

export function ReadingSettings(props: ReadingSettingsProps) {
  const textSizeIndex = readerTextSizes.indexOf(props.readerTextSize);
  const preferencesAreDefault =
    props.theme === 'system' &&
    props.readerWidth === 'comfortable' &&
    props.readerTextSize === '100';

  function changeTextSize(offset: -1 | 1) {
    const next = readerTextSizes[textSizeIndex + offset];
    if (next) props.onTextSizeChange(next);
  }

  return (
    <div className="settings-panel" data-testid="settings-panel">
      <section className="settings-section settings-appearance">
        <p className="eyebrow">Appearance</p>
        <fieldset className="settings-choice-group settings-theme-group">
          <legend>Theme</legend>
          <ViewSwitch<Theme> segmented className="settings-theme-options" label="Reader theme" value={props.theme} onChange={props.onThemeChange} options={(['system', 'light', 'dark'] as const).map(theme => [theme, <><ThemeIcon theme={theme} />{theme === 'system' ? 'Studio theme' : theme === 'light' ? 'Light' : 'Dark'}</>] as const)} />
        </fieldset>
      </section>

      <section className="settings-section settings-reading">
        <p className="eyebrow">Reading</p>
        <fieldset className="settings-choice-group">
          <legend>Reading measure</legend>
          <ViewSwitch<ReaderWidth> segmented className="settings-measure-options" label="Reading measure" value={props.readerWidth} onChange={props.onReaderWidthChange} options={[["comfortable", "Comfortable"], ["wide", "Wide"]]} />
        </fieldset>

        <div className="settings-text-size">
          <span id="reader-text-size-label">Text size</span>
          <div aria-labelledby="reader-text-size-label" role="group">
            <IconButton
              aria-label="Decrease text size"
              disabled={textSizeIndex === 0}
              onClick={() => changeTextSize(-1)}
              type="button"
            >
              <span aria-hidden="true">−</span>
            </IconButton>
            <output aria-live="polite">{props.readerTextSize}%</output>
            <IconButton
              aria-label="Increase text size"
              disabled={textSizeIndex === readerTextSizes.length - 1}
              onClick={() => changeTextSize(1)}
              type="button"
            >
              <span aria-hidden="true">+</span>
            </IconButton>
          </div>
        </div>
      </section>

      {props.focusAvailable && (
        <section className="settings-section settings-focus">
          <p className="eyebrow">Focus</p>
          <strong>Calm focus</strong>
          <p>
            Hide the Knowledge header for focused reading. Reading tools stay
            within reach.
          </p>
          <Button variant="quiet"
            aria-pressed={props.focusReader}
            className="inspect-focus-toggle"
            onClick={props.onToggleFocus}
            type="button"
          >
            {props.focusReader ? 'Exit calm focus' : 'Enter calm focus'}
          </Button>
        </section>
      )}

      {!preferencesAreDefault && (
        <Button variant="quiet"
          className="settings-reset"
          onClick={props.onResetDisplayPreferences}
          type="button"
        >
          Reset reading defaults
        </Button>
      )}
    </div>
  );
}
