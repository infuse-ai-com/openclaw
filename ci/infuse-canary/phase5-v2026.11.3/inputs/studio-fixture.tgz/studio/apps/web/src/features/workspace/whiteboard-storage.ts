/** A blocked browser getter must not prevent mounting the board; writes still fail closed. */
export function whiteboardSessionStorage(): Storage {
  try {
    return sessionStorage;
  } catch {
    return {
      length: 0,
      key: () => null,
      getItem: () => null,
      setItem: () => {
        throw Error('Session storage is unavailable.');
      },
      removeItem: () => {},
      clear: () => {},
    };
  }
}

/** All whiteboard outboxes share a bounded browser-session storage budget. */
export function persistWhiteboardEnvelope(
  key: string,
  command: unknown,
  storage: Storage = sessionStorage,
): void {
  const serialized = JSON.stringify(command),
    encoder = new TextEncoder();
  let bytes = encoder.encode(serialized).length;
  for (const existing of Object.keys(storage)) {
    if (
      existing !== key &&
      [
        'studio.whiteboard.text.pending:',
        'studio.whiteboard.comments.pending:',
        'studio.whiteboard.pending:',
      ].some((prefix) => existing.startsWith(prefix))
    )
      bytes += encoder.encode(storage.getItem(existing) ?? '').length;
  }
  if (bytes > 262144)
    throw Error(
      'Pending whiteboard storage limit reached. Settle an earlier save before adding more.',
    );
  storage.setItem(key, serialized);
}
