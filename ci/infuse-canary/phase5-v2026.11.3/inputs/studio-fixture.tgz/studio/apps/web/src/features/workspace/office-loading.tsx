import { LoadingState } from './loading.js';

/** Shared by scene download and initialization. */
export function OfficeLoading() {
  return <LoadingState label="Loading Office…" overlay className="ws-office-loading" />;
}
