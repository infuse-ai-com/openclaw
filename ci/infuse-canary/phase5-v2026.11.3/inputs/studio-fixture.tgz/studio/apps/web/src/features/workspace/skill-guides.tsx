import { PageHeader, Button, EmptyState, ViewSwitch } from './ui.js';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useSearchParams } from 'react-router';
import { skillGuideCatalogSchema, skillGuideProvenanceSchema } from '@studio/contracts';
import { api, projectPath, readableError } from './api.js';
import { useWorkspace } from './context.js';
import { LoadingState } from './loading.js';
import { SkillReader } from './skill-reader.js';
import './skill-guides.css';

function useGuides() {
  const { owner, current, session, visible } = useWorkspace();
  const admitted = session.projects.some(p => p.id === 'core' && p.kind === 'company');
  const query = useQuery({
    queryKey: ['workspace', owner, 'skill-catalog', 'outcomes'], enabled: current && admitted,
    refetchOnWindowFocus: visible,
    queryFn: async ({ signal }) => {
      const value = await api(projectPath('/api/studio/artifacts/skill-catalog?presentation=outcomes', 'core'), { signal }) as { catalog: unknown; revision: unknown };
      if (typeof value.revision !== 'string' || !/^[a-f0-9]{64}$/.test(value.revision)) throw Error('The skill release could not be verified.');
      return { catalog: skillGuideCatalogSchema.parse(value.catalog), revision: value.revision };
    },
  });
  return { query, admitted, current };
}
function useGuide(id: string | undefined, revision: string | undefined, enabled: boolean) {
  const { owner } = useWorkspace();
  return useQuery({
    queryKey: ['workspace', owner, 'skill-guide', revision, id], enabled: enabled && !!id && !!revision,
    queryFn: async ({ signal }) => skillGuideProvenanceSchema.parse(await api(projectPath(
      `/api/studio/artifacts/skill-guides/${encodeURIComponent(id!)}?${new URLSearchParams({ catalogRevision: revision! })}`, 'core'), { signal })),
  });
}
function Connection({ admitted, current, query, title }: ReturnType<typeof useGuides> & { title: string }) {
  if (admitted && current && !query.isError) return <LoadingState label={`Loading ${title.toLowerCase()}…`} size="panel" />;
  return <EmptyState className="sg-message" level={2} title={<>{!admitted ? 'The company skill library is unavailable.' : !current ? `Reconnect to read ${title}.` : 'The skill catalog is unavailable.'}</>} descriptionRole={query.isError ? 'alert' : 'status'} >{!admitted ? 'The floor hosting this library is not available to your current Studio profile.' : query.isError ? readableError(query.error) : 'Studio needs to verify your access before showing this library.'}</EmptyState>;
}

// Keep discovery in the URL, but selection in its own history entry. A pending
// search is committed before opening a reader so Back restores the same results.
function useDiscovery() {
  const selectionKey = 'skill';
  const [params, setParams] = useSearchParams();
  const query = params.get('q') ?? '';
  const id = params.get(selectionKey);
  const [search, setSearch] = useState(query);
  const paramsRef = useRef(params);
  const listRef = useRef<HTMLDivElement>(null);
  const returnTo = useRef<string | null>(null);
  const previousId = useRef(id);
  const suppressReturnFocus = useRef(false);
  useEffect(() => { paramsRef.current = params; }, [params]);
  useEffect(() => { setSearch(query); }, [query]);
  useEffect(() => {
    if (previousId.current && !id && !suppressReturnFocus.current) {
      const item = returnTo.current ?? previousId.current;
      const target = listRef.current?.querySelector<HTMLButtonElement>(`[data-entry="${item.replace(/[^a-z0-9-]/g, '')}"]`)
        ?? listRef.current?.closest('.sg-browser')?.querySelector<HTMLInputElement>('input[type="search"]');
      target?.focus({ preventScroll: true });
    }
    previousId.current = id;
    suppressReturnFocus.current = false;
  }, [id]);
  const update = (key: string, value: string) => {
    const next = new URLSearchParams(paramsRef.current);
    if (search) next.set('q', search); else next.delete('q');
    if (value) next.set(key, value); else next.delete(key);
    if (key !== selectionKey) { next.delete(selectionKey); suppressReturnFocus.current = true; }
    if (key === selectionKey && value && search !== query) {
      const results = new URLSearchParams(next); results.delete(selectionKey);
      setParams(results, { replace: true });
    }
    paramsRef.current = next;
    setParams(next, { replace: key !== selectionKey || !value });
  };
  useEffect(() => {
    if (search === query) return;
    const timer = window.setTimeout(() => {
      const next = new URLSearchParams(paramsRef.current);
      if (search) next.set('q', search); else next.delete('q');
      paramsRef.current = next; setParams(next, { replace: true });
    }, 250);
    return () => window.clearTimeout(timer);
  }, [search, query, setParams]);
  const changeSearch = (value: string) => {
    setSearch(value);
    if (id) {
      suppressReturnFocus.current = true;
      const next = new URLSearchParams(paramsRef.current); next.delete(selectionKey);
      paramsRef.current = next; setParams(next, { replace: true });
    }
  };
  const clear = () => {
    suppressReturnFocus.current = true;
    const next = new URLSearchParams(paramsRef.current);
    for (const key of ['q', 'purpose', 'app', selectionKey]) next.delete(key);
    paramsRef.current = next; setSearch(''); setParams(next, { replace: true });
    if (listRef.current) listRef.current.scrollTop = 0;
  };
  const open = (value: string) => { returnTo.current = value; update(selectionKey, value); };
  return { params, id, search, changeSearch, update, clear, open, listRef, close: () => update(selectionKey, '') };
}

function Library({ title, subtitle, state, open, browser, reader }: {
  title: string; subtitle: string; state: ReturnType<typeof useGuides>; open: boolean;
  browser: ReactNode; reader: ReactNode;
}) {
  const ready = state.current && state.admitted && !state.query.isError && !!state.query.data;
  return <section className={`ws-surface sg-surface${open && ready ? ' sg-open' : ''}`} aria-label={title}>
    <div className="sg-browser">
      <PageHeader className="sg-library-heading" eyebrow="COMPANY / WORKING METHODS" title={title} description={subtitle} actions={<Button variant="quiet" disabled={!state.current || !state.admitted || state.query.isFetching} onClick={() => void state.query.refetch()}>Refresh</Button>} />
      {ready ? browser : <Connection {...state} title={title} />}
    </div>
    <div className="sg-reader" aria-label="Skill reader" role="region" tabIndex={0}>
      {ready ? reader : <div className="sg-reader-intro"><span className="sg-kicker">THE COMPANY FIELD GUIDE</span><h2>A useful way forward.</h2><p>Shared methods and the apps that support them, together in one place.</p></div>}
    </div>
  </section>;
}

const purposes = [
  ['build', 'Build & deliver'], ['understand', 'Research & understand'],
  ['quality', 'Review & verify'], ['operate', 'Run the company'],
] as const;

export function Skills() {
  const state = useGuides(); const discovery = useDiscovery();
  const { id, params, search, changeSearch, update, clear, open, close, listRef } = discovery;
  const catalog = state.query.data?.catalog;
  const category = params.get('purpose') ?? '', app = params.get('app') ?? '';
  const terms = search.toLocaleLowerCase().trim();
  const shown = catalog?.entries.filter(g => (!category || g.purpose === category) && (!app || g.apps.some(a => a.id === app)) &&
    (!terms || [g.name, g.promise, g.summary, g.category, ...g.apps.map(a => catalog.apps.find(x => x.id === a.id)?.name)].join(' ').toLocaleLowerCase().includes(terms))) ?? [];
  const selected = id ? catalog?.entries.find(g => g.id === id) : shown[0];
  const ready = state.current && state.admitted && !state.query.isError && !!catalog;
  const detail = useGuide(selected?.id, state.query.data?.revision, ready);
  const filtered = !!(search || category || app);
  return <Library title="Skills" subtitle="Methods for moving work forward." state={state} open={!!id}
    browser={catalog ? <>
      <div className="sg-discovery">
        <label className="sg-search"><span className="sg-label">Search skills</span><input className="ui-control" type="search" aria-label="Search" value={search} onChange={e => changeSearch(e.target.value)} placeholder="Find a skill or an outcome" /></label>
        <fieldset className="sg-categories"><legend>Browse by purpose</legend>
          <ViewSwitch segmented label="Browse by purpose" className="sg-purpose-options" value={category} onChange={value => update('purpose', value)} options={[
            ['', <>All skills <span>{catalog!.entries.length}</span></>],
            ...purposes.map(([value, label]) => [value, <>{label} <span>{catalog!.entries.filter(g => g.purpose === value).length}</span></>] as const),
          ]} />
        </fieldset>
        <label className="sg-app-filter"><span>Supporting app</span><select className="ui-control" aria-label="App or tool" value={app} onChange={e => update('app', e.target.value)}><option value="">All apps & tools</option>{catalog!.apps.map(a => <option value={a.id} key={a.id}>{a.name}</option>)}</select></label>
        <div className="sg-result-meta"><p aria-live="polite">{shown.length} of {catalog!.entries.length} skills</p><Button variant="quiet" disabled={!filtered} onClick={clear}>Clear filters</Button></div>
      </div>
      <div className="sg-results" ref={listRef} aria-label="Skill results" role="region" tabIndex={0}>
        {shown.map(g => <button className="sg-entry" key={g.id} data-entry={g.id} data-skill={g.id} aria-current={selected?.id === g.id ? 'true' : undefined} aria-label={`Read ${g.name}`} onClick={() => open(g.id)}><span className="sg-entry-title">{g.name}</span><span className="sg-entry-promise">{g.promise}</span><span className="sg-entry-category">{g.category}</span></button>)}
        {!shown.length && <EmptyState className="sg-message" level={2} title={<>No matching skills.</>}  actions={<><Button variant="quiet" onClick={clear}>Show all skills</Button></>}>Try another search or clear your filters.</EmptyState>}
      </div>
    </> : null}
    reader={!selected ? <EmptyState className="sg-message" level={2} title={<>{id ? 'This guide is unavailable.' : 'Find your next method.'}</>}  actions={<>{id && <Button variant="quiet" onClick={close}>← Back to results</Button>}</>}>{id ? 'Choose a guide from the current library.' : 'Choose another purpose or search to explore a guide.'}</EmptyState>
      : detail.isError ? <EmptyState role="alert" className="sg-message" level={2} title={<>This guide is unavailable.</>}  actions={<><Button variant="quiet" onClick={close}>← Back to results</Button></>}>{readableError(detail.error)}</EmptyState>
      : detail.data ? <SkillReader key={`${selected.id}/${state.query.data!.revision}`} p={detail.data} catalog={catalog!} revision={state.query.data!.revision} explicit={!!id} close={close} clear={clear} filtered={filtered} />
      : <div className="sg-reader-loading"><Button variant="quiet" onClick={close}>← Back to results</Button><LoadingState label="Loading guide…" size="panel" /></div>}
  />;
}
