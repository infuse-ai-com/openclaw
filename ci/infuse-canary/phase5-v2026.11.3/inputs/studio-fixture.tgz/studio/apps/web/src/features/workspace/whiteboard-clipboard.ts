import {
  whiteboardLocatedItem,
  whiteboardSpatialCommand,
  type WhiteboardSpatialItem,
  type WhiteboardSpatialOperation,
} from '@studio/contracts';
export const boardClipboardPrefix = 'INFUSE_WHITEBOARD_V1\n';
export function encodeBoardClipboard(items: WhiteboardSpatialItem[], owner: string) {
  if (!items.length || items.length > 30)
    throw Error('Copy up to 30 elements and connections at once.');
  if (items.some((item) => item.kind === 'section'))
    throw Error(
      'Open the section and copy its contents; sections are not copied without their contents.',
    );
  const text = boardClipboardPrefix + JSON.stringify({ owner, items });
  if (new TextEncoder().encode(text).length > 65536)
    throw Error('This selection is too large for one paste. Copy fewer elements.');
  return text;
}
export function decodeBoardClipboard(
  text: string,
  owner: string,
  sectionId: string,
  point: { x: number; y: number },
  newId: () => string,
) {
  if (!text.startsWith(boardClipboardPrefix))
    throw Error('Copy whiteboard elements before using Paste here.');
  if (new TextEncoder().encode(text).length > 65536)
    throw Error('Clipboard selection exceeds the size limit.');
  const raw = JSON.parse(text.slice(boardClipboardPrefix.length));
  if (!raw || raw.owner !== owner)
    throw Error('Paste elements within the same project and signed-in workspace.');
  if (!Array.isArray(raw.items) || !raw.items.length || raw.items.length > 30)
    throw Error('Clipboard selection is invalid.');
  const items: WhiteboardSpatialItem[] = raw.items.map((item: unknown) =>
    whiteboardLocatedItem.parse(item),
  );
  return copyBoardItems(items, sectionId, point, newId);
}

/** Shared literal-preserving placement for duplicate and paste; clipboard byte limits belong to its codec. */
export function copyBoardItems(items: WhiteboardSpatialItem[], sectionId: string, point: { x: number; y: number }, newId: () => string) {
  if (items.some((item) => item.kind === 'section'))
    throw Error('Section copies are not supported. Copy their contents instead.');
  const blocks = items.filter((item) => item.kind !== 'connection');
  if (!blocks.length) throw Error('Copy at least one element.');
  if (new Set(items.map((i) => i.id)).size !== items.length)
    throw Error('Clipboard contains duplicate identifiers.');
  const ids = new Map(items.map((item) => [item.id, newId()]));
  const left = Math.min(...blocks.map((i) => i.x)),
    top = Math.min(...blocks.map((i) => i.y));
  const operations: WhiteboardSpatialOperation[] = items.map((item) => {
    const { revision: _revision, sectionId: _section, ...body } = item;
    if (item.kind === 'connection') {
      if (!blocks.some((b) => b.id === item.source) || !blocks.some((b) => b.id === item.target))
        throw Error('Clipboard connection is missing an endpoint.');
      return {
        type: 'connect',
        connection: {
          id: ids.get(item.id)!,
          kind: 'connection',
          source: ids.get(item.source)!,
          target: ids.get(item.target)!,
          label: item.label,
        },
      };
    }
    const copy = {
      ...body,
      id: ids.get(item.id)!,
      locked: false,
      x: item.x - left + point.x,
      y: item.y - top + point.y,
    };
    if (item.kind === 'stroke') return { type: 'draw', stroke: copy as typeof item };
    if (item.kind === 'image') return { type: 'createImage', sectionId, tile: copy as typeof item };
    if (item.kind === 'html') return { type: 'createHtml', sectionId, tile: copy as typeof item };
    if (item.kind === 'section') throw Error('Copy the section contents instead.');
    return { type: 'create', block: copy as typeof item };
  });
  // Validate all geometry and byte limits before making any write.
  whiteboardSpatialCommand.parse({ commandId: 'clipboard-validation', sectionId, operations });
  return { operations, ids: blocks.map((item) => ids.get(item.id)!) };
}
