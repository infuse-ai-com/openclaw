import {useEffect,useRef,useState} from 'react';
import type {ContributionsView} from '@studio/contracts';
import {utcStamp as stamp} from './evidence-time.js';
import {ShellIcon} from './shell.js';
const format=(n:number)=>new Intl.NumberFormat('en').format(n);
export function ActivityPeople({data,selected,onSelect}:{data:ContributionsView;selected:string;onSelect:(key:string)=>void}){
 const [limit,setLimit]=useState(8);
 const people=[...data.authors].sort((a,b)=>b.count-a.count||(a.label??a.name).localeCompare(b.label??b.name));
 return <section className="ws-activity-people" aria-label="Contributors"><header><h2>The people behind it</h2><p>All retained years · selected repositories{data.authorsTruncated?' · first 200 authors':''}.</p></header>
  {people.slice(0,limit).map(a=><button key={a.key} className="ws-activity-person" aria-pressed={selected===a.key} onClick={()=>onSelect(selected===a.key?'':a.key)}><span className="ws-activity-avatar" aria-hidden="true">{(a.label??a.name).slice(0,1).toUpperCase()}</span><span><strong>{a.label??a.name}</strong><small>{a.kind??'Recorded author'}{people.filter(other=>(other.label??other.name)===(a.label??a.name)).length>1?` · ${a.email??a.key}`:''}</small></span><span className="ws-activity-person-count"><strong>{format(a.count)}</strong><small>retained commits</small></span></button>)}
  {!people.length&&<p className="ws-activity-note">No contributors recorded in these filters.</p>}
  {people.length>limit&&<button className="ws-activity-link" onClick={()=>setLimit(n=>n+8)}>Show more contributors</button>}
 </section>;
}
export function ActivityCoverage({data,onClose}:{data:ContributionsView;onClose:()=>void}){
 const title=useRef<HTMLHeadingElement>(null);useEffect(()=>{title.current?.focus();},[]);
 return <section className="ws-contrib-coverage" aria-label="Git source coverage"><header><div><h2 id="activity-sources" ref={title} tabIndex={-1}>What this history covers</h2><p>Source coverage is independent of activity filters.</p></div><button className="ws-activity-link" onClick={onClose}>← Back to activity</button></header>
  <p className="ws-activity-source-intro">Coverage applies to the observed branch heads at each scan. Retained history can include deleted branches. A gap means history may be incomplete, not that no one contributed.</p>
  {!data.collecting&&(data.configuredSources??0)>0&&<p className="ws-activity-warning">Collection is paused. The view uses retained records.</p>}
  {data.repositories.length<(data.configuredSources??0)&&<p className="ws-activity-warning">Some admitted sources have no recorded metadata yet.</p>}
  {!data.repositories.length&&<p>No source metadata is available.</p>}
  {data.repositories.map(r=><article key={r.sourceId}><span className="ws-activity-symbol"><ShellIcon name="artifact"/></span><div><h3>{r.name}</h3><p>{r.projectName}</p></div><div><strong>{r.lastError?`Read failed · ${r.lastError}`:r.stage==='complete'?r.historyGap?'Current heads scanned · historical gap':'Observed heads scanned':r.stage==='idle'?'Retained import · awaiting direct scan':`${r.stage} in progress`}</strong><p>{r.completed} / {r.branches} observed branches · {format(r.retainedCommits)} retained commits</p><small>Last attempt {stamp(r.lastAttemptAt)} · complete scan {stamp(r.lastCompleteAt)}</small>{r.historyGap&&<p>An earlier scan was interrupted by an unavailable head or cursor. Historical coverage needs reconciliation; collected records are preserved.</p>}</div><span className={`ws-activity-source-status ${r.stage==='complete'&&!r.lastError&&!r.historyGap?'is-complete':''}`}>{r.stage==='complete'&&!r.lastError&&!r.historyGap?'Scanned':'Incomplete'}</span></article>)}
 </section>;
}
