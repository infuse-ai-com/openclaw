export type GraphControlIconName =
  'all' | 'connected' | 'fit' | 'zoom-in' | 'zoom-out';

export function GraphControlIcon({ name }: { name: GraphControlIconName }) {
  const content = {
    all: (
      <>
        <rect height="5" rx="1" width="5" x="3" y="3" />
        <rect height="5" rx="1" width="5" x="12" y="3" />
        <rect height="5" rx="1" width="5" x="3" y="12" />
        <rect height="5" rx="1" width="5" x="12" y="12" />
      </>
    ),
    connected: (
      <>
        <circle cx="5" cy="10" r="2.25" />
        <circle cx="15" cy="5" r="2.25" />
        <circle cx="15" cy="15" r="2.25" />
        <path d="m7 9 5.75-2.9M7 11l5.75 2.9" />
      </>
    ),
    fit: <path d="M8 3H3v5M12 3h5v5M17 12v5h-5M8 17H3v-5" />,
    'zoom-in': <path d="M10 5v10M5 10h10" />,
    'zoom-out': <path d="M5 10h10" />,
  }[name];

  return (
    <svg
      aria-hidden="true"
      className="graph-control-icon"
      fill="none"
      focusable="false"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.6"
      viewBox="0 0 20 20"
    >
      {content}
    </svg>
  );
}
