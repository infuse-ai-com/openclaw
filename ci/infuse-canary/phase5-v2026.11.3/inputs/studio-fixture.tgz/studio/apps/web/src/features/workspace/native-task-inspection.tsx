import { EmptyState } from './ui.js';
import type { NativeMissionView } from '@studio/contracts';
import { NativeTaskInbox, NativeTaskFindings } from './native-progress.js';
import { AgentPortrait } from './agent-portrait.js';

type Task = NativeMissionView['tasks'][number];
function TaskContext({ task, data }: { task: Task; data: NativeMissionView }) {
  return <><p className="ws-literal">{task.plan.objective}</p><dl><div><dt>Acceptance</dt><dd>{task.plan.acceptance}</dd></div><div><dt>Depends on</dt><dd>{task.plan.dependencies.length ? task.plan.dependencies.map(id => data.tasks.find(t => t.id === id)?.plan.title ?? id).join(', ') : 'Ready independently'}</dd></div></dl>{task.blocker && <p className="ws-alert">{task.state === 'revision' ? 'Revision requested' : 'Blocked'}: {task.blocker}</p>}{task.review && <details className="ws-record"><summary>Verified · coordinator review</summary><p className="ws-native-verified ws-literal">{task.review.summary}</p></details>}</>;
}
function Deliveries({ task, data, evidenceView }: { task: Task; data: NativeMissionView; evidenceView: boolean }) {
  const evidence = data.evidence.filter(e => e.taskId === task.id).sort((a, b) => b.revision - a.revision);
  return <section className="ws-task-deliveries" aria-label="Task evidence"><h3>Delivered revisions</h3>{!evidence.length && <p>No delivery recorded for this task.</p>}{evidence.map(e => <details key={e.id} className="ws-record ws-evidence-revision" open={evidenceView && task.evidenceId === e.id}><summary>Evidence revision {e.revision} · {e.summary}{task.evidenceId !== e.id ? ' (historical)' : ''}</summary><div className="ws-evidence-identity"><span>{task.evidenceId === e.id ? 'Current task delivery' : 'Historical delivery'} · {e.artifact.mediaType}</span><span>Exact SHA-256</span><code>{e.sha256}</code></div><pre className="ws-native-artifact">{e.artifact.content}</pre>{e.references.map(r => <p key={r.url + r.revision}><a href={r.url} target="_blank" rel="noreferrer">{r.kind} ↗</a> · <code>{r.revision}</code></p>)}</details>)}</section>;
}
/** Selection changes presentation only; task/evidence and approval authority stay in the existing records. */
export function NativeTaskInspection({ data, evidenceView, taskId, selectTask }: { data: NativeMissionView; evidenceView: boolean; taskId: string | null; selectTask(id: string): void }) {
  const selected = data.tasks.find(t => t.id === taskId) ?? data.tasks[0];
  if (!selected) return <EmptyState level={2} title={<>Emon is shaping the work.</>}  >The draft needs independently verifiable tasks before approval.</EmptyState>;
  return <section className="ws-task-inspection" aria-label={evidenceView ? 'Evidence inspection' : 'Task inspection'}><header><h2>{evidenceView ? 'Evidence & review' : 'Tasks & owners'}</h2><p>{data.tasks.filter(t => t.plan.required && t.state === 'verified').length} of {data.tasks.filter(t => t.plan.required).length} required tasks verified. Emon reviews exact evidence.</p></header>
    {taskId && !data.tasks.some(t => t.id === taskId) && <p className="ws-alert" role="status">The requested task is not in this mission. Showing the first available task.</p>}
    <div className="ws-task-layout"><nav aria-label="Mission tasks">{data.tasks.map((t, index) => {
      const pending = (data.instructions ?? []).filter(i => i.taskId === t.id && !['applied', 'superseded'].includes(i.state)).length;
      const findings = (data.findings ?? []).filter(f => f.taskId === t.id && f.required && f.state !== 'closed').length;
      return <button key={t.id} data-task-id={t.id} aria-pressed={t.id === selected.id} aria-controls="native-task-detail" onClick={() => selectTask(t.id)}><small>{String(index + 1).padStart(2, '0')} · {t.plan.owner.agentId}</small><strong>{t.plan.title}</strong><span>{t.state} · {t.plan.required ? 'Required' : 'Optional'}</span>{pending > 0 && <span>{pending} awaiting application</span>}{findings > 0 && <span>{findings} required {findings === 1 ? 'finding' : 'findings'} open</span>}</button>;
    })}</nav><article className="ws-native-task" id="native-task-detail" key={selected.id}><header><div><span className="ws-eyebrow">{selected.plan.role} / {selected.plan.required ? 'REQUIRED' : 'OPTIONAL'}</span><h2>{selected.plan.title}</h2></div><span className="ws-status">{selected.state}</span></header><div className="ws-native-owner"><AgentPortrait target={selected.plan.owner} /><div><strong>{selected.plan.owner.agentId}</strong><small>{selected.plan.owner.gatewayId}</small></div></div>
      {evidenceView ? <><Deliveries task={selected} data={data} evidenceView /><details className="ws-record ws-task-context"><summary>Task outcome, acceptance and coordinator review</summary><TaskContext task={selected} data={data} /></details></> : <TaskContext task={selected} data={data} />}
      <NativeTaskInbox taskId={selected.id} data={data} /><NativeTaskFindings taskId={selected.id} data={data} />
      {!evidenceView && <Deliveries task={selected} data={data} evidenceView={false} />}
    </article></div>
  </section>;
}
