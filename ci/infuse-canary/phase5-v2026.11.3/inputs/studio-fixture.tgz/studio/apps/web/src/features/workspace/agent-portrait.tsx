import type { RuntimeTarget } from '@studio/contracts';
import '@studio/ui/portraits.css';

import { agentPortraitId } from './agent-identity.js';

export function AgentPortrait({ target }: { target: Pick<RuntimeTarget, 'agentId'> }) {
  const portrait = agentPortraitId(target.agentId);
  return <span className="ws-agent-avatar" aria-hidden="true">{portrait ? <span className={`avatar avatar--${portrait}`}><i /></span> : target.agentId.slice(0, 1).toUpperCase()}</span>;
}

// Public role copy is grounded in agent-skills 6ccb973,
// skills/tech-org/references/agents.md. Voice/covers follow the accepted Studio
// prototype; these are editorial introductions, not live persona or skill reads.
interface RoleGuide {
  name: string; role: string; discipline: string; theme: string;
  line: string; signature: string; about: string; workingStyle: string;
  strengths: string[]; guides: { id: string; name: string }[];
  apps: { id: string; name: string }[];
}
const roleGuides: Record<string, RoleGuide> = {
  'agent-coordinator': {
    name: 'Emon Lusk', role: 'Team coordinator', discipline: 'Coordination', theme: 'ember',
    line: 'Big ambition. Small, owned steps.', signature: 'Make the next decision obvious.',
    about: 'I turn an unfinished thought into a mission the team can deliver. I clarify the outcome, connect the right specialists and keep the next decision visible.',
    workingStyle: 'I break the work into clear responsibilities, review the results together and follow through until the agreed outcome is verified.',
    strengths: ['Mission shaping', 'Team coordination', 'Delivery review'],
    guides: [{ id: 'mission-shaping', name: 'Mission Shaping' }, { id: 'agentic-product-engineering', name: 'Agentic Product Engineering' }, { id: 'verify-this', name: 'Verify This' }],
    apps: [{ id: 'knowledge-base', name: 'Knowledge Base' }, { id: 'mattermost', name: 'Mattermost' }],
  },
  'agent-developer': {
    name: 'Tinus Lordvals', role: 'AI engineer', discipline: 'Engineering', theme: 'blue',
    line: 'Make it work. Show that it works.', signature: 'Replace “should work” with a runnable proof.',
    about: 'I turn approved ideas into something you can use. I build bounded changes, check the code and try the result in the browser so you can see what works.',
    workingStyle: 'I work in small, testable slices. I show the evidence with the change and make remaining risks clear before handing it over.',
    strengths: ['Implementation', 'Browser verification', 'Delivery evidence'],
    guides: [{ id: 'agentic-product-engineering', name: 'Agentic Product Engineering' }, { id: 'playwright-browser-evidence', name: 'Playwright Browser Evidence' }, { id: 'verify-this', name: 'Verify This' }],
    apps: [{ id: 'workbench', name: 'Workbench' }, { id: 'sourcebot', name: 'Sourcebot UX' }],
  },
  'agent-designer': {
    name: 'Stewie Hobs', role: 'Product & design', discipline: 'Product & design', theme: 'plum',
    line: 'Make the next move feel natural.', signature: 'Let the interface do the explaining.',
    about: 'I start with the person on the other side of the screen. I inspect the experience, its screenshots and its accessibility to make the next step easier to understand.',
    workingStyle: 'I compare the built experience with the accepted design, make findings concrete and explain which details would make it clearer and more usable.',
    strengths: ['UX review', 'Accessibility', 'Design parity'],
    guides: [{ id: 'infuse-product-design', name: 'Infuse Product Design' }, { id: 'playwright-browser-evidence', name: 'Playwright Browser Evidence' }],
    apps: [{ id: 'workbench', name: 'Workbench' }, { id: 'knowledge-base', name: 'Knowledge Base' }],
  },
  'agent-infra': {
    name: 'Satwa Nutella', role: 'Infrastructure engineer', discipline: 'Infrastructure', theme: 'ochre',
    line: 'Tomorrow should be reproducible.', signature: 'Make the second run as clear as the first.',
    about: 'I look after the path from a build to a running service. I investigate the environment, the rollout and the logs to turn operational questions into clear next steps.',
    workingStyle: 'I start with the observed runtime state, keep checks bounded and leave evidence that the next person can use to understand the result.',
    strengths: ['Kubernetes', 'Runtime health', 'CI/CD triage'],
    guides: [{ id: 'runtime-operations', name: 'Runtime Operations' }, { id: 'verify-this', name: 'Verify This' }],
    apps: [],
  },
  'agent-intake': {
    name: 'Ramiro Garcia', role: 'Client partnership', discipline: 'Client partnership', theme: 'clay',
    line: 'No surprises. Clear next steps.', signature: 'Connect expectations to the work.',
    about: 'I turn a client message into a useful next step. I clarify the opportunity, prepare proposed replies and help make the handoff to delivery understandable.',
    workingStyle: 'I prepare drafts and qualification notes, surface the decisions that need a person and keep external replies and commercial commitments with the authorized human.',
    strengths: ['Consulting intake', 'Qualification', 'Delivery handoffs'],
    guides: [{ id: 'consulting-intake-orchestrator', name: 'Consulting Intake Orchestrator' }, { id: 'spec-driven-delivery', name: 'Spec-Driven Delivery' }],
    apps: [{ id: 'mattermost', name: 'Mattermost' }],
  },
  kapiteky: {
    name: 'Kapiteky', role: 'Strategy & review', discipline: 'Strategy & review', theme: 'teal',
    line: 'A better question changes the work.', signature: 'Find the assumption hiding in plain sight.',
    about: 'I connect the work to why we are doing it. Bring me an unclear tradeoff, a confident assumption or a proposal that needs a second perspective.',
    workingStyle: 'I advise Emon and the team, improve the working system and take on named reviews. I make evidence, risks and decisions clear so the human owner can judge them.',
    strengths: ['Direction', 'Tradeoffs', 'Working systems'],
    guides: [{ id: 'tech-org', name: 'Tech Org' }, { id: 'spec-driven-delivery', name: 'Spec-Driven Delivery' }, { id: 'verify-this', name: 'Verify This' }],
    apps: [{ id: 'knowledge-base', name: 'Knowledge Base' }, { id: 'sourcebot', name: 'Sourcebot UX' }],
  },
};
const roleAliases: Record<string, string> = { emon: 'agent-coordinator', tinus: 'agent-developer', stewie: 'agent-designer', satwa: 'agent-infra', ramiro: 'agent-intake' };
export const agentRoleGuide = (id: string) => roleGuides[roleAliases[id] ?? id];

// Editorial descriptions of the maintained role, not observed skill usage.
const strengthDescriptions: Record<string, string> = {
  'Mission shaping': 'Turn intent into an actionable mission paper.',
  'Team coordination': 'Give each specialist a clear responsibility.',
  'Delivery review': 'Make outcomes and supporting evidence easy to judge.',
  'Implementation': 'Build bounded changes that fit the existing product.',
  'Browser verification': 'Check the experience where people actually use it.',
  'Delivery evidence': 'Show what changed and how it was verified.',
  'UX review': 'Find the friction in everyday product flows.',
  'Accessibility': 'Make the experience usable across inputs and needs.',
  'Design parity': 'Bring the built interface closer to the accepted design.',
  'Kubernetes': 'Inspect workloads and their operating environment.',
  'Runtime health': 'Connect observed symptoms to useful next checks.',
  'CI/CD triage': 'Follow a build through release and rollout.',
  'Consulting intake': 'Turn client context into a clear next step.',
  'Qualification': 'Surface the questions needed before committing.',
  'Delivery handoffs': 'Keep expectations and responsibilities connected.',
  'Direction': 'Connect the work to the outcome that matters.',
  'Tradeoffs': 'Make alternatives and assumptions easier to compare.',
  'Working systems': 'Improve how the team plans, delivers and learns.',
};
export const agentStrengthDescription = (strength: string) => strengthDescriptions[strength];
