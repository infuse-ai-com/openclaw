import { InfuseSpinner } from './loading.js';
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { useLocation } from 'react-router';
import logo from '../../../../../packages/ui/assets/INFUSE_horizontal_for_dark_background.png?inline';
import headquarters from '../../../../../packages/ui/assets/studio-headquarters.webp';
import lift from '../../../../../packages/ui/assets/studio-lift.webp';
import './entrance.css';

const intentKey = 'studio.entrance.intent';
const motionKey = 'studio.entrance.motion';
const intentLifetime = 15 * 60 * 1000;
// Presentation only. This marker never establishes a session or grants access.
export function hasArrivalIntent() {
  try {
    const age = Date.now() - Number(sessionStorage.getItem(intentKey));
    return age >= 0 && age < intentLifetime;
  } catch { return false; }
}
export function clearArrivalIntent() {
  try { sessionStorage.removeItem(intentKey); } catch { /* Storage is optional. */ }
}
function rememberArrival() {
  try { sessionStorage.setItem(intentKey, String(Date.now())); } catch { /* Sign-in still works. */ }
}
function motionPaused() {
  try { return sessionStorage.getItem(motionKey) === 'paused'; } catch { return false; }
}
function useReducedMotion() {
  const [reduced, setReduced] = useState(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(media.matches);
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  return reduced;
}
function Building({ moving, inviting = false, onFailure }: {
  moving: boolean; inviting?: boolean; onFailure?(): void;
}) {
  const scene = useRef<HTMLDivElement>(null);
  const world = useRef<HTMLDivElement>(null);
  const pointer = useRef({ x: 0, y: 0 });
  useEffect(() => {
    if (!moving) return;
    let frame = 0, elapsed = 0, last = 0;
    const tick = (now: number) => {
      if (!document.hidden) {
        elapsed += last ? Math.min(now - last, 60) : 0;
        const t = elapsed / 1000;
        scene.current?.style.setProperty('--entry-warm-a', String(.05 + (Math.sin(t * .47) + 1) * .12));
        scene.current?.style.setProperty('--entry-warm-b', String(.03 + (Math.sin(t * .36 + 2.5) + 1) * .13));
        scene.current?.style.setProperty('--entry-breeze', `${Math.sin(t * .62) * .7}px`);
        if (world.current) world.current.style.transform = `translate3d(${pointer.current.x * 5 + Math.sin(t * .19) * 1.2}px, ${pointer.current.y * 3}px, 0) scale(1.018)`;
      }
      last = now;
      frame = requestAnimationFrame(tick);
    };
    const move = (event: PointerEvent) => { pointer.current = { x: (event.clientX / innerWidth - .5) * 2, y: (event.clientY / innerHeight - .5) * 2 }; };
    window.addEventListener('pointermove', move);
    frame = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(frame); window.removeEventListener('pointermove', move); };
  }, [moving]);
  return <div className="se-scene" aria-hidden="true" ref={scene}>
    <div className="se-scene-fit"><div className="se-world" ref={world} style={{ transform: 'scale(1.018)' }}>
      <img className="se-architecture" src={headquarters} alt="" draggable={false} onError={onFailure} fetchPriority="high" />
      <img className="se-architecture se-relight se-relight-a" src={headquarters} alt="" draggable={false} />
      <img className="se-architecture se-relight se-relight-b" src={headquarters} alt="" draggable={false} />
      <img className="se-architecture se-leaves" src={headquarters} alt="" draggable={false} />
      <img className={`se-architecture se-doorlight${inviting ? ' inviting' : ''}`} src={headquarters} alt="" draggable={false} />
      <img className="se-lift" src={lift} alt="" draggable={false} onError={onFailure} style={{ top: '63.8%' }} />
    </div></div><div className="se-scrim" />
  </div>;
}

function Brand() {
  return <header className="se-brand"><img src={logo} alt="INFUSE" /><span>STUDIO</span></header>;
}

export function LoginEntrance({ pending, error, online, loginUrl, retry }: {
  pending: boolean; error: string; online: boolean; loginUrl: string; retry(): void;
}) {
  const reduced = useReducedMotion();
  const [paused, setPaused] = useState(motionPaused);
  const [inviting, setInviting] = useState(false);
  const [sceneFailed, setSceneFailed] = useState(false);
  const moving = !reduced && !paused;
  // An unauthenticated return (including a cancelled login) must not retain an old ceremony.
  useEffect(() => { if (!pending && !error) clearArrivalIntent(); }, [pending, error]);
  function toggleMotion() {
    const next = !paused;
    setPaused(next);
    try { sessionStorage.setItem(motionKey, next ? 'paused' : 'on'); } catch { /* Optional preference. */ }
  }
  return <div className={`studio-entrance${moving ? '' : ' se-still'}`}>
    {!sceneFailed && <Building moving={moving} inviting={inviting} onFailure={() => setSceneFailed(true)} />}
    <Brand />
    <main className="se-welcome">
      <p className="se-eyebrow">YOUR SHARED WORKPLACE</p>
      <h1>Great things<br />start here.</h1>
      <p className="se-description">A place to build with your team.</p>
      <section className="se-access" aria-label="Sign in" aria-live="polite">
        {!online ? <><h2>You are offline.</h2><p>Reconnect to sign in and open your workspace.</p></>
          : pending ? <p className="se-checking" role="status"><InfuseSpinner /> Opening your workspace…</p>
            : error ? <><h2>Studio is unavailable.</h2><p>{error}</p><button className="se-primary" onClick={retry}>Try again</button></>
              : <><a className="se-primary" href={loginUrl} onClick={event => {
                if (event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) rememberArrival();
              }} onPointerEnter={() => setInviting(true)} onPointerLeave={() => setInviting(false)} onFocus={() => setInviting(true)} onBlur={() => setInviting(false)}>
                Sign in to Studio <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="M4 12h15M13 5l7 7-7 7" /></svg>
              </a><p className="se-note">Your team. Your next chapter.</p></>}
      </section>
    </main>
    <footer className="se-footer"><span>INFUSE / A PLACE FOR THE WORK</span>
      <button className="se-motion" aria-pressed={!moving} disabled={reduced} onClick={toggleMotion}>
        <span className={moving ? 'se-motion-dot on' : 'se-motion-dot'} />{reduced ? 'Reduced motion' : paused ? 'Resume motion' : 'Pause motion'}
      </button>
    </footer>
  </div>;
}

const ArrivalContext = createContext({ active: false, ready: () => {}, complete: () => {} });
export const useWorkspaceArrival = () => useContext(ArrivalContext);

/** Authentication owns the single-use intent; the real desk scene owns the movement. */
export function WorkspaceArrival({ active, onComplete, children }: { active: boolean; onComplete(): void; children: ReactNode }) {
  const reduced = useReducedMotion();
  const location = useLocation();
  const [ready, setReady] = useState(false);
  const skip = useRef<HTMLButtonElement>(null);
  const workspace = useRef<HTMLDivElement>(null);
  const complete = useRef(onComplete);
  complete.current = onComplete;
  const finish = useCallback(() => complete.current(), []);
  const sceneReady = useCallback(() => setReady(true), []);
  const deskRoute = (location.pathname === '/' || location.pathname === '/desk') && !new URLSearchParams(location.search).has('desk');
  const visible = active && deskRoute && !reduced && !motionPaused() && !document.hidden;
  useEffect(() => {
    if (!active) return;
    if (!visible) { finish(); return; }
    skip.current?.focus({ preventScroll: true });
    // A missing/slow optional scene must never hold the authenticated workspace captive.
    const timeout = setTimeout(finish, 8000);
    const hide = () => { if (document.hidden) finish(); };
    document.addEventListener('visibilitychange', hide);
    return () => { clearTimeout(timeout); document.removeEventListener('visibilitychange', hide); };
  }, [active, visible, finish]);
  const wasVisible = useRef(false);
  useEffect(() => {
    if (wasVisible.current && !visible) workspace.current?.querySelector<HTMLElement>('#workspace-main')?.focus({ preventScroll: true });
    wasVisible.current = visible;
  }, [visible]);
  return <ArrivalContext.Provider value={{ active: visible, ready: sceneReady, complete: finish }}>
    <div ref={workspace} inert={visible}>{children}</div>
    {visible && <div className="se-room-arrival" data-ready={ready} role="dialog" aria-modal="true" aria-label="Entering your room"
      onPointerDown={event => { event.preventDefault(); finish(); }} onKeyDown={event => {
        if (event.key === 'Escape') { event.preventDefault(); finish(); }
        if (event.key === 'Tab') { event.preventDefault(); skip.current?.focus(); }
      }}>
      <div className="se-room-arrival-controls">
        <p role="status">{ready ? 'Taking your seat…' : 'Opening your room…'}</p>
        <button ref={skip} onClick={finish}>Skip to workspace</button>
      </div>
    </div>}
  </ArrivalContext.Provider>;
}
