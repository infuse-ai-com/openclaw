import { Button } from '../../../ui.js';
import { icons } from '@studio/ui/icons';
import type { SidePanel } from './DocumentPanel.js';

/** Trusted bundled icons; chrome uses the same artwork as Studio navigation. */
export function KnowledgeIcon({ name }: { name: keyof typeof icons }) {
  return (
    <span
      className="knowledge-icon"
      aria-hidden="true"
      dangerouslySetInnerHTML={{ __html: icons[name] }}
    />
  );
}
export function KnowledgeHeader({
  exploring,
  onLibrary,
  onExplore,
  onSearch,
  disabled,
}: {
  exploring: boolean;
  onLibrary(): void;
  onExplore(): void;
  onSearch(): void;
  disabled: boolean;
}) {
  return (
    <header className="knowledge-header">
      <h1>Knowledge</h1>
      <nav className="ui-tabs" aria-label="Knowledge views">
        <button
          aria-current={!exploring ? 'page' : undefined}
          onClick={onLibrary}
          type="button"
        >
          Library
        </button>
        <button
          aria-current={exploring ? 'page' : undefined}
          className="explore-toggle"
          disabled={disabled}
          onClick={onExplore}
          type="button"
        >
          Explore
        </button>
      </nav>
      <Button variant="quiet"
        className="knowledge-search-trigger"
        aria-haspopup="dialog"
        aria-keyshortcuts="Meta+K Control+K"
        aria-label="Search floor knowledge"
        disabled={disabled}
        onClick={onSearch}
        type="button"
      >
        <KnowledgeIcon name="search" />
        <span>Search floor knowledge</span>
        <kbd>⌘ K</kbd>
      </Button>
    </header>
  );
}
export function KnowledgeScope({
  name,
  count,
  pending = false,
  sourceOpen,
  onSources,
  onClear,
  filtered,
}: {
  name: string;
  count: number;
  pending?: boolean;
  sourceOpen: boolean;
  onSources(): void;
  onClear(): void;
  filtered: boolean;
}) {
  return (
    <div className="knowledge-scope">
      <Button variant="quiet"
        aria-expanded={sourceOpen}
        aria-controls="knowledge-sources"
        onClick={onSources}
        type="button"
      >
        <KnowledgeIcon name="folder" />
        Sources
      </Button>
      <span>
        {name}{!pending && ` · ${count} indexed documents`}
      </span>
      {filtered && (
        <Button variant="quiet" onClick={onClear} type="button">
          <KnowledgeIcon name="close" />
          <span>Clear source</span>
        </Button>
      )}
    </div>
  );
}
export function ReadingTools({
  onBack,
  backLabel,
  sidePanel,
  onToggle,
}: {
  onBack(): void;
  backLabel: string;
  sidePanel: SidePanel;
  onToggle(panel: SidePanel): void;
}) {
  return (
    <div className="knowledge-reading-tools">
      <Button variant="quiet" onClick={onBack} className="knowledge-back" type="button">
        <KnowledgeIcon name="chevron" />
        {backLabel}
      </Button>
      <nav aria-label="Reading tools">
        {(
          [
            ['context', 'Contents'],
            ['inspect', 'Source'],
            ['settings', 'Reading'],
          ] as const
        ).map(([panel, label]) => (
          <Button variant="quiet"
            key={panel}
            aria-expanded={sidePanel === panel}
            aria-controls="knowledge-document-tools"
            onClick={() => onToggle(panel)}
            type="button"
          >
            {label}
          </Button>
        ))}
      </nav>
    </div>
  );
}
