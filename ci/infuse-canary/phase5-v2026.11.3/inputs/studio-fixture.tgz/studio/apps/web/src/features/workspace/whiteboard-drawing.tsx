import { IconButton } from './ui.js';
import { useRef, useState } from 'react';
import { useReactFlow, useViewport } from '@xyflow/react';
import { shapeLabelLayout, type WhiteboardStroke } from '@studio/contracts';

type Point = [number, number];
export const strokeColors = { ink: 'var(--ui-ink)', orange: 'var(--ui-accent)', blue: '#497fdf', red: '#de5757' };
export function StrokeGraphic({ stroke }: { stroke: WhiteboardStroke }) {
  const label=shapeLabelLayout(stroke.label??'',stroke.width,stroke.height);
  return <svg className="wboard-stroke" width={stroke.width} height={stroke.height} aria-label={stroke.label||'Vector drawing'} role="img">
    {stroke.shape&&!['line','arrow','elbow-arrow','curved-arrow'].includes(stroke.shape)&&<rect className="wboard-shape-surface" width={stroke.width} height={stroke.height} fill="transparent"/>}
    <polyline className="wboard-stroke-hit" points={stroke.points.map(([x, y]) => `${x * stroke.width},${y * stroke.height}`).join(' ')}
      fill="none" stroke="transparent" strokeWidth={Math.max(12, stroke.thickness)} strokeLinecap="round" strokeLinejoin="round" />
    <polyline points={stroke.points.map(([x, y]) => `${x * stroke.width},${y * stroke.height}`).join(' ')}
      fill="none" stroke={strokeColors[stroke.color]} strokeWidth={stroke.thickness} strokeLinecap="round" strokeLinejoin="round" />
    {stroke.label&&<text className="wboard-shape-text" x={stroke.width/2} y={stroke.height/2-(label.lines.length-1)*label.size*.65} textAnchor="middle" dominantBaseline="central" fontSize={label.size} fill="var(--ui-text)">{label.lines.map((line,index)=><tspan key={index} x={stroke.width/2} dy={index?label.size*1.3:0}>{line}</tspan>)}</text>}
  </svg>;
}

/** Pointer positions are converted to world coordinates before normalization. */
export function DrawingLayer({ enabled, color, thickness, save, notify }: {
  enabled: boolean; color: WhiteboardStroke['color']; thickness: number;
  save(stroke: Omit<WhiteboardStroke, 'revision'>): void; notify(message: string): void;
}) {
  const flow = useReactFlow(); const viewport = useViewport();
  const active = useRef<{ pointer: number; points: Point[] } | null>(null);
  const [points, setPoints] = useState<Point[]>([]);
  function position(event: { clientX: number; clientY: number }): Point {
    const value = flow.screenToFlowPosition({ x: event.clientX, y: event.clientY }); return [value.x, value.y];
  }
  function append(point: Point, force = false) {
    if (!active.current) return;
    const previous = active.current.points.at(-1)!;
    if (!force && Math.hypot(point[0] - previous[0], point[1] - previous[1]) * viewport.zoom < 2) return;
    active.current.points.push(point);
    // Bound long gestures while retaining the first and latest samples.
    if (active.current.points.length > 1024) active.current.points = active.current.points.filter((_point, index) => index % 2 === 0);
    setPoints([...active.current.points]);
  }
  function cancel() { active.current = null; setPoints([]); }
  return <div className="wboard-drawing-layer nodrag nopan nowheel" role="region" aria-label="Drawing surface" tabIndex={0}
    onKeyDown={event => { if (event.key === 'Escape') { event.stopPropagation(); cancel(); } }}
    onPointerDown={event => {
      if (!enabled || event.button !== 0 || active.current) return;
      event.preventDefault(); event.stopPropagation(); event.currentTarget.focus();
      event.currentTarget.setPointerCapture(event.pointerId);
      active.current = { pointer: event.pointerId, points: [position(event)] }; setPoints(active.current.points);
    }}
    onPointerMove={event => {
      if (active.current?.pointer !== event.pointerId) return;
      const samples = event.nativeEvent.getCoalescedEvents?.();
      for (const sample of samples?.length ? samples : [event]) append(position(sample));
    }}
    onPointerCancel={cancel} onLostPointerCapture={cancel}
    onPointerUp={event => {
      if (active.current?.pointer !== event.pointerId) return;
      append(position(event), true);
      const captured = active.current.points; cancel();
      event.currentTarget.releasePointerCapture(event.pointerId);
      if (!enabled) return;
      const xs = captured.map(point => point[0]); const ys = captured.map(point => point[1]);
      const x = Math.min(...xs); const y = Math.min(...ys);
      const width = Math.max(1, Math.max(...xs) - x); const height = Math.max(1, Math.max(...ys) - y);
      if (width > 4000 || height > 4000 || Math.abs(x) > 100000 || Math.abs(y) > 100000) {
        notify('That drawing is too large. Try a smaller stroke or zoom in.'); return;
      }
      save({ id: crypto.randomUUID(), kind: 'stroke', x, y, width, height, color, thickness,
        points: captured.map(([px, py]) => [Number(((px - x) / width).toFixed(5)), Number(((py - y) / height).toFixed(5))]) });
    }}>
    <svg aria-hidden="true"><g transform={`translate(${viewport.x},${viewport.y}) scale(${viewport.zoom})`}>
      <polyline points={points.map(point => point.join(',')).join(' ')} fill="none" stroke={strokeColors[color]} strokeWidth={thickness} strokeLinecap="round" strokeLinejoin="round" />
    </g></svg>
  </div>;
}

function segmentDistance(point:Point,a:Point,b:Point) {
  const dx=b[0]-a[0],dy=b[1]-a[1],length=dx*dx+dy*dy;
  const t=length?Math.max(0,Math.min(1,((point[0]-a[0])*dx+(point[1]-a[1])*dy)/length)):0;
  return Math.hypot(point[0]-a[0]-t*dx,point[1]-a[1]-t*dy);
}
/** Erases only loaded vector ink, with captured revisions and one reversible batch. */
export function EraserLayer({enabled,strokes,erase,notify}:{enabled:boolean;strokes:WhiteboardStroke[];erase(strokes:WhiteboardStroke[]):void;notify(message:string):void}) {
  const flow=useReactFlow(),viewport=useViewport();
  const active=useRef<{pointer:number;last:Point;hits:Map<string,WhiteboardStroke>;strokes:WhiteboardStroke[]}|null>(null);
  const [hits,setHits]=useState<WhiteboardStroke[]>([]);
  const position=(event:{clientX:number;clientY:number}):Point=>{const p=flow.screenToFlowPosition({x:event.clientX,y:event.clientY});return [p.x,p.y];};
  function sweep(point:Point) {
    const gesture=active.current;if(!gesture)return;
    const distance=Math.hypot(point[0]-gesture.last[0],point[1]-gesture.last[1]);
    const steps=Math.min(2048,Math.max(1,Math.ceil(distance*viewport.zoom/6)));
    for(let step=0;step<=steps;step++) {
      const p:Point=[gesture.last[0]+(point[0]-gesture.last[0])*step/steps,gesture.last[1]+(point[1]-gesture.last[1])*step/steps];
      for(const stroke of gesture.strokes) {
        if(gesture.hits.has(stroke.id)||gesture.hits.size>=30)continue;
        const radius=10/viewport.zoom+stroke.thickness/2;
        if(p[0]<stroke.x-radius||p[0]>stroke.x+stroke.width+radius||p[1]<stroke.y-radius||p[1]>stroke.y+stroke.height+radius)continue;
        const points=stroke.points.map(([x,y]):Point=>[stroke.x+x*stroke.width,stroke.y+y*stroke.height]);
        if(points.some((end,i)=>segmentDistance(p,points[Math.max(0,i-1)]!,end)<=radius))gesture.hits.set(stroke.id,stroke);
      }
    }
    gesture.last=point;setHits([...gesture.hits.values()]);
  }
  const cancel=()=>{active.current=null;setHits([]);};
  return <div className="wboard-drawing-layer wboard-eraser-layer nodrag nopan nowheel" role="region" aria-label="Eraser surface" tabIndex={0}
    onKeyDown={event=>{if(event.key==='Escape'){event.stopPropagation();cancel();}}}
    onPointerDown={event=>{
      if(!enabled||event.button!==0||active.current)return;
      event.preventDefault();event.stopPropagation();event.currentTarget.focus();event.currentTarget.setPointerCapture(event.pointerId);
      active.current={pointer:event.pointerId,last:position(event),hits:new Map(),strokes:strokes.filter(s=>s.points.length>0)};sweep(position(event));
    }}
    onPointerMove={event=>{if(active.current?.pointer===event.pointerId)sweep(position(event));}}
    onPointerCancel={cancel} onLostPointerCapture={cancel}
    onPointerUp={event=>{
      if(active.current?.pointer!==event.pointerId)return;
      sweep(position(event));const removed=[...active.current.hits.values()];cancel();event.currentTarget.releasePointerCapture(event.pointerId);
      if(!enabled)return;
      if(removed.length)erase(removed);else notify('No drawing here. Zoom in to load ink, or select a drawing and Delete it.');
    }}>
    <svg aria-hidden="true"><g transform={`translate(${viewport.x},${viewport.y}) scale(${viewport.zoom})`}>{hits.map(stroke=><polyline key={stroke.id}
      points={stroke.points.map(([x,y])=>`${stroke.x+x*stroke.width},${stroke.y+y*stroke.height}`).join(' ')} fill="none" stroke="var(--ui-canvas)" strokeWidth={stroke.thickness+3} strokeLinecap="round" strokeLinejoin="round"/>)}</g></svg>
  </div>;
}

export function PenOptions({disabled=false,color,width,setColor,setWidth}:{disabled?:boolean;color:WhiteboardStroke['color'];width:number;setColor(color:WhiteboardStroke['color']):void;setWidth(width:number):void}) {
  return <div className="wboard-pen-options wboard-float" role="group" aria-label="Drawing options">
    <div role="group" aria-label="Pen color">{(Object.keys(strokeColors) as WhiteboardStroke['color'][]).map(key=><IconButton type="button" className="wboard-swatch" disabled={disabled} key={key} title={key} aria-label={'Pen color '+key} aria-pressed={color===key} onClick={()=>setColor(key)}><span style={{background:strokeColors[key]}}/></IconButton>)}</div>
    <span className="wboard-divider"/>
    <div role="group" aria-label="Pen thickness">{([['Fine',2],['Medium',3],['Bold',6]] as const).map(([name,size])=><IconButton type="button" className="wboard-line-sample" disabled={disabled} key={name} title={name} aria-label={'Pen thickness '+name} aria-pressed={width===size} onClick={()=>setWidth(size)}><svg width="24" height="20" aria-hidden="true"><path d="M3 10h18" stroke="currentColor" strokeWidth={size} strokeLinecap="round"/></svg></IconButton>)}</div>
  </div>;
}
