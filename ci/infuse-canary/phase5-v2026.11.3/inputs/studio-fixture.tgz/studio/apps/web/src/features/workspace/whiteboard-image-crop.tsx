import { IconButton, Button } from './ui.js';
import { useEffect, useRef, useState, type PointerEvent, type KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import type { WhiteboardImage, WhiteboardImageCrop, WhiteboardReceipt, WhiteboardSpatialOperation } from '@studio/contracts';
import { readableError } from './api.js';

const full:WhiteboardImageCrop={x:0,y:0,width:1,height:1};
const rounded=(value:number)=>Math.round(value*1e6)/1e6;
const clamp=(value:number,min:number,max:number)=>Math.max(min,Math.min(max,value));
type Handle='move'|'nw'|'ne'|'sw'|'se';
function adjust(c:WhiteboardImageCrop,handle:Handle,dx:number,dy:number):WhiteboardImageCrop {
  if(handle==='move')return {...c,x:clamp(c.x+dx,0,1-c.width),y:clamp(c.y+dy,0,1-c.height)};
  let left=c.x,top=c.y,right=c.x+c.width,bottom=c.y+c.height;
  if(handle.includes('w'))left=clamp(left+dx,0,right-.01);else right=clamp(right+dx,left+.01,1);
  if(handle.includes('n'))top=clamp(top+dy,0,bottom-.01);else bottom=clamp(bottom+dy,top+.01,1);
  return {x:rounded(left),y:rounded(top),width:Math.max(.01,rounded(right-left)),height:Math.max(.01,rounded(bottom-top))};
}

/** The editor keeps a revision-fenced draft; only Apply writes a normal board command. */
export function ImageCropEditor({tile,url,enabled,commit,close}:{tile:WhiteboardImage;url:string;enabled:boolean;
  commit(operations:WhiteboardSpatialOperation[]):Promise<WhiteboardReceipt|undefined>;close():void}) {
  const loadError='This image could not be loaded. Close the editor and reload the image.';
  const [seed]=useState(tile),[crop,setCrop]=useState<WhiteboardImageCrop>(tile.crop??full);
  const [size,setSize]=useState<{width:number;height:number}|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const dialog=useRef<HTMLDialogElement>(null),stage=useRef<HTMLDivElement>(null);
  const drag=useRef<{pointer:number;x:number;y:number;width:number;height:number;crop:WhiteboardImageCrop;handle:Handle}|null>(null);
  const changed=tile.revision!==seed.revision;
  useEffect(()=>{const previous=document.activeElement;dialog.current?.showModal();return()=>{if(previous instanceof HTMLElement&&previous.isConnected)previous.focus();};},[]);
  function start(event:PointerEvent<HTMLElement>,handle:Handle) {
    if(event.button!==0||busy)return;
    const bounds=stage.current?.getBoundingClientRect();if(!bounds?.width||!bounds.height)return;
    event.preventDefault();event.stopPropagation();event.currentTarget.focus();event.currentTarget.setPointerCapture(event.pointerId);
    drag.current={pointer:event.pointerId,x:event.clientX,y:event.clientY,width:bounds.width,height:bounds.height,crop,handle};
  }
  function move(event:PointerEvent<HTMLElement>) {
    const d=drag.current;if(!d||d.pointer!==event.pointerId)return;
    setCrop(adjust(d.crop,d.handle,(event.clientX-d.x)/d.width,(event.clientY-d.y)/d.height));
  }
  function keys(event:KeyboardEvent<HTMLElement>,handle:Handle) {
    const delta=event.shiftKey?.05:.01;
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)||busy)return;
    event.preventDefault();setCrop(c=>adjust(c,handle,event.key==='ArrowLeft'?-delta:event.key==='ArrowRight'?delta:0,event.key==='ArrowUp'?-delta:event.key==='ArrowDown'?delta:0));
  }
  function field(key:keyof WhiteboardImageCrop,value:number) {
    if(!Number.isFinite(value))return;
    setCrop(c=>({...c,[key]:clamp(value/100,key==='width'||key==='height'?.01:0,key==='x'?1-c.width:key==='y'?1-c.height:key==='width'?1-c.x:1-c.y)}));
  }
  async function apply() {
    if(!enabled||busy||changed||!size)return;
    setBusy(true);setError('');
    try {
      const previous=seed.crop??full;
      // Retain displayed scale where possible, with the existing board size bounds.
      const sourceScale=Math.min(seed.width/(size.width*previous.width),seed.height/(size.height*previous.height));
      const width=size.width*crop.width,height=size.height*crop.height;
      const scale=Math.min(4000/Math.max(width,height),Math.max(sourceScale,16/Math.min(width,height)));
      const isFull=crop.x===0&&crop.y===0&&crop.width===1&&crop.height===1;
      const receipt=await commit([{type:'updateTile',id:seed.id,expectedRevision:seed.revision,patch:{crop:isFull?null:crop,width:clamp(width*scale,16,4000),height:clamp(height*scale,16,4000)}}]);
      if(receipt?.status==='applied')close();
      else setError(receipt?.message??'The crop is not confirmed. Close this editor and check the board’s save status before trying again.');
    }catch(cause){setError(readableError(cause));}finally{setBusy(false);}
  }
  return createPortal(<dialog ref={dialog} className="wboard-image-crop nodrag nopan" aria-labelledby="wboard-crop-title" aria-describedby="wboard-crop-instructions"
    onClick={event=>event.stopPropagation()} onDoubleClick={event=>event.stopPropagation()} onKeyDown={event=>event.stopPropagation()} onPointerDown={event=>event.stopPropagation()} onPaste={event=>event.stopPropagation()}
    onCancel={event=>{event.preventDefault();if(!busy)close();}}>
    <header><div><h2 id="wboard-crop-title">Crop image</h2><p id="wboard-crop-instructions">Drag the corners to trim. Drag inside to move the crop. Your full image stays available.</p></div><IconButton type="button" aria-label="Close crop editor" disabled={busy} onClick={close}>×</IconButton></header>
    <div className="wboard-crop-preview"><div ref={stage} className="wboard-crop-stage" style={{width:size?`min(100%, ${size.width/size.height*48}vh)`:'100%',aspectRatio:size?`${size.width} / ${size.height}`:undefined}}>
      <img src={url} draggable={false} alt={seed.title||'Image to crop'} onLoad={event=>{setSize({width:event.currentTarget.naturalWidth,height:event.currentTarget.naturalHeight});setError(value=>value===loadError?'':value);}} onError={()=>{setSize(null);setError(loadError);}}/>
      {size&&<div className="wboard-crop-area" style={{left:crop.x*100+'%',top:crop.y*100+'%',width:crop.width*100+'%',height:crop.height*100+'%'}}>
        <button type="button" className="wboard-crop-move" aria-label="Move crop area" title="Move crop area with arrow keys; hold Shift for larger steps" disabled={busy} autoFocus onPointerDown={e=>start(e,'move')} onPointerMove={move} onPointerUp={()=>{drag.current=null;}} onPointerCancel={()=>{drag.current=null;}} onKeyDown={e=>keys(e,'move')}/>
        {(['nw','ne','sw','se'] as const).map(handle=><button key={handle} type="button" className={'wboard-crop-handle wboard-crop-handle--'+handle} disabled={busy}
          aria-label={'Resize crop '+({nw:'top left',ne:'top right',sw:'bottom left',se:'bottom right'}[handle])} title="Resize with arrow keys; hold Shift for larger steps"
          onPointerDown={e=>start(e,handle)} onPointerMove={move} onPointerUp={()=>{drag.current=null;}} onPointerCancel={()=>{drag.current=null;}} onKeyDown={e=>keys(e,handle)}/>)}
      </div>}
    </div></div>
    <details className="wboard-crop-precise"><summary>Precise crop</summary><div>{(['x','y','width','height'] as const).map(key=><label key={key}>{({x:'Left',y:'Top',width:'Width',height:'Height'}[key])} (%)<input className="ui-control" type="number" step="0.1" min={key==='x'||key==='y'?0:1} max={100} value={Math.round(crop[key]*1000)/10} disabled={busy} onChange={event=>field(key,event.currentTarget.valueAsNumber)}/></label>)}</div><p>Arrow keys move the crop or a focused corner. Hold Shift for larger steps.</p></details>
    {changed&&<p role="alert">This image changed while you were cropping. Close and reopen the editor to use the saved version.</p>}
    {error&&!changed&&<p role="alert">{error}</p>}
    <footer><Button variant="quiet" type="button" disabled={busy||!size} onClick={()=>setCrop(full)}>Restore full image</Button><span/><Button variant="quiet" type="button" disabled={busy} onClick={close}>Cancel</Button><Button type="button" className="wboard-crop-apply" disabled={!enabled||busy||changed||!size} onClick={()=>void apply()}>{busy?'Saving…':'Apply crop'}</Button></footer>
  </dialog>,document.querySelector('.ws-whiteboard')??document.body);
}
