import { PageHeader } from './ui.js';
import { useWorkspace } from './context.js';
import { useWorkspaceAppearance, type Appearance } from './appearance.js';
import { Link } from './navigation.js';
import { ShellIcon } from './shell.js';
import './settings.css';

const themes: Array<{ value: Appearance; title: string; description: string }> = [
  { value: 'light', title: 'Light', description: 'A bright workspace' },
  { value: 'dark', title: 'Dark', description: 'A quieter backdrop' },
  { value: 'system', title: 'System', description: 'Follow your device' },
];
export function ProfileSettings({ logout, loggingOut }: { logout(): void; loggingOut: boolean }) {
  const { session, current } = useWorkspace(), appearance = useWorkspaceAppearance();
  const name = session.displayName || session.profileId;
  const initials = name.trim().split(/\s+/).slice(0, 2).map(word => Array.from(word)[0]).join('').toUpperCase();
  return <section className="ws-surface ws-settings ui-layout-form">
    <PageHeader eyebrow={<>YOUR WORKSPACE</>} title={<>Profile & settings</>} description={<>A little more you. Make Studio feel at home.</>} />
    <div className="ws-settings-content ui-page-content">
      <section className="ws-settings-profile" aria-labelledby="profile-heading">
        <div className="ws-profile-avatar" aria-hidden="true">{initials}</div>
        <div><span className="ws-eyebrow">SIGNED IN AS</span><h2 id="profile-heading">{name}</h2><p>{current ? 'Connected to Studio' : 'Offline · last known profile'}</p></div>
        <span className="ws-settings-badge">{session.projects.length} {session.projects.length === 1 ? 'floor' : 'floors'}</span>
      </section>
      <section className="ws-settings-card" aria-labelledby="appearance-heading">
        <div className="ws-settings-section-heading"><ShellIcon name="settings" /><div><h2 id="appearance-heading">Appearance</h2><p>Choose how Studio looks on this browser.</p></div></div>
        <div className="ws-theme-options" role="group" aria-label="Appearance">{themes.map(theme => <button type="button" key={theme.value} aria-pressed={appearance.preference === theme.value} onClick={() => appearance.setPreference(theme.value)}>
          <span className={`ws-theme-preview ws-theme-preview--${theme.value}`} aria-hidden="true"><span /><span><i /><i /><i /></span></span>
          <span className="ws-theme-label"><strong>{theme.title}</strong><span className="ws-theme-selected" aria-hidden="true">{appearance.preference === theme.value ? '✓' : ''}</span></span><small>{theme.description}</small>
        </button>)}</div>
        <p className="ws-settings-hint">Changes apply immediately and are remembered in this browser.</p>
      </section>
      <section className="ws-settings-card" aria-labelledby="access-heading">
        <div className="ws-settings-section-heading"><ShellIcon name="account" /><div><h2 id="access-heading">Profile & access</h2><p>Your identity and permissions are managed by your workspace.</p></div></div>
        <dl className="ws-settings-details"><div><dt>Display name</dt><dd>{name}</dd></div><div><dt>Current floor</dt><dd>{session.project.name}</dd></div><div><dt>Mission approvals</dt><dd>{session.bootstrap.capabilities.approver ? 'Can approve missions on this floor' : 'Member · approval access not enabled'}</dd></div><div><dt>Floor management</dt><dd>{session.canManageFloors ? 'Can create floors and manage sources' : 'Managed by your workspace administrator'}</dd></div></dl>
      </section>
      <section className="ws-settings-card" aria-labelledby="floors-heading">
        <div className="ws-settings-section-heading"><ShellIcon name="floor" /><div><h2 id="floors-heading">Your floors</h2><p>Open a project or manage the places your team works.</p></div></div>
        <ul className="ws-settings-floors">{session.projects.map(project => <li key={project.id}><Link to={`/floor?project=${encodeURIComponent(project.id)}`}><ShellIcon name="floor" /><span>{project.name}</span>{project.id === session.project.id && <small>Current floor</small>}<span aria-hidden="true">↗</span></Link></li>)}</ul>
        {session.canManageFloors && <div className="ws-settings-actions"><Link className="ws-button ws-button--quiet" to="/floors"><ShellIcon name="settings" />Manage floors & repositories</Link><Link className="ws-text-link" to="/floors?create=1">Create floor →</Link></div>}
      </section>
      <section className="ws-settings-signout" aria-label="Session"><div><h2>All done for now?</h2><p>Sign out of Studio on this browser.</p></div><button type="button" className="ws-button ws-button--quiet" disabled={loggingOut} onClick={logout}>{loggingOut ? 'Signing out…' : 'Sign out'}</button></section>
    </div>
  </section>;
}
