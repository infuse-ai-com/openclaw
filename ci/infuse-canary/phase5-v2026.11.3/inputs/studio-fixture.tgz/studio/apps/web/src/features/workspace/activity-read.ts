import {api,ApiError} from './api.js';
export type Read<T>={value:T}|{unavailable:true; reason?:string};
export async function readActivity<T>(path:string,signal:AbortSignal,parse:(v:unknown)=>T):Promise<Read<T>>{try{return {value:parse(await api(path,{signal}))};}catch(error){if(signal.aborted)throw error;const details=error instanceof ApiError?error.details:undefined;
  const reason=details&&typeof details==='object'&&'capability'in details&&details.capability==='contributions'&&'reason'in details&&typeof details.reason==='string'&&['checkpoint_storage','credential','provider_unavailable','policy_invalid','policy_expired','binding_mismatch'].includes(details.reason)?details.reason:undefined;
  return {unavailable:true,...(reason?{reason}:{})};}}
