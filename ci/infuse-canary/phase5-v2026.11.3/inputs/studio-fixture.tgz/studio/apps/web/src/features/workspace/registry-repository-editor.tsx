import { Button } from './ui.js';

/** The old registry identity and mutation contract is retired. */
export function RegistryRepositoryEditor({ onClose }: { onClose: () => void }) {
  return <section aria-label="Shared repository settings">
    <h2>Shared repository settings</h2>
    <p role="status">Repository changes are unavailable. A GitLab-backed replacement is not yet available; existing records remain available for review.</p>
    <Button variant="quiet" onClick={onClose}>Return to floor picker</Button>
  </section>;
}
