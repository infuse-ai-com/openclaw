import { Tooltip } from 'radix-ui';
import { ControlHint } from './control-hint.js';
import { companyNavigation } from './company-navigation.js';
import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router';
import { Link, NavLink, useNavigate, projectDestination } from './navigation.js';
import { useWorkspace } from './context.js';
import { AppearanceContext, useAppearance } from './appearance.js';
import mark from '../../../../../packages/ui/assets/INFUSE_favicon.ico';
import { icons } from '@studio/ui/icons';
import './workbench.css';

const company = companyNavigation;
const project = [['/floor', 'Project floor', 'floor'], ['/whiteboard', 'Whiteboard', 'board'], ['/grilling', 'Grilling', 'edit'], ['/missions', 'Missions', 'missions'], ['/review', 'Review', 'review'], ['/knowledge', 'Knowledge', 'knowledge'], ['/code', 'Code', 'search'], ['/artifacts', 'Artifacts', 'artifact'], ['/prototype', 'Prototype', 'prototype'], ['/operations', 'Operations', 'operations']] as const;
/** Only bundled, trusted Tabler artwork enters this markup boundary. */
export function ShellIcon({ name }: { name: string }) {
  const mapping: Record<string, keyof typeof icons> = { contributions:'operations', monitoring:'radar', light:'sun', dark:'moon', system:'desktop', settings:'settings', more:'more', company:'building', floor:'building', desk:'home', screen:'desktop', agents:'users', skills:'library', apps:'server', switchProject:'switchProject', missions:'files', review:'review', knowledge:'library', artifact:'document', board:'board', edit:'edit', prototype:'flask', operations:'operations', search:'search', collapse:'chevron', menu:'menu', help:'help', account:'profile', close:'close' };
  return <span className="ws-glyph" aria-hidden="true" dangerouslySetInnerHTML={{ __html: icons[mapping[name] ?? 'files'] }} />;
}
/** Native disclosures retain keyboard behavior; flyouts stay within the viewport. */
function SidebarMenu({ label, text = label, icon, className = '', hint=false, children }: { hint?:boolean; label: string; text?: string; icon: string; className?: string; children: React.ReactNode }) {
  const details = useRef<HTMLDetailsElement>(null);
  function place() {
    const menu = details.current;
    if (!menu?.open) return;
    if (!menu.getClientRects().length) { menu.open = false; return; }
    const panel = menu.querySelector<HTMLElement>('.wb-popover');
    const sidebar = menu.closest('.wb-sidebar');
    if (!panel || !sidebar) return;
    const anchor = menu.querySelector('summary')!.getBoundingClientRect();
    panel.style.left = `${Math.max(12, Math.min(sidebar.getBoundingClientRect().right + 8, innerWidth - panel.offsetWidth - 12))}px`;
    panel.style.top = `${Math.max(12, Math.min(anchor.top, innerHeight - panel.offsetHeight - 12))}px`;
  }
  useEffect(() => {
    const dismiss = (event: MouseEvent) => { if (details.current?.open && !details.current.contains(event.target as Node)) details.current.open = false; };
    const escape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape' || !details.current?.open) return;
      event.preventDefault(); event.stopPropagation(); details.current.open = false;
      details.current.querySelector('summary')?.focus();
    };
    document.addEventListener('click', dismiss); document.addEventListener('keydown', escape);
    window.addEventListener('resize', place); window.addEventListener('scroll', place, true);
    return () => { document.removeEventListener('click', dismiss); document.removeEventListener('keydown', escape); window.removeEventListener('resize', place); window.removeEventListener('scroll', place, true); };
  }, []);
  return <details className={`wb-menu ${className}`} ref={details} onToggle={place}><ControlHint label={label} side="right" enabled={hint}><summary aria-label={label} title={hint ? undefined : label}><ShellIcon name={icon} /><span>{text}</span></summary></ControlHint><div className="wb-popover">{children}</div></details>;
}
export function WorkspaceShell({ children, floor, screenZen = false, logout, loggingOut }: { children: React.ReactNode; floor: boolean; screenZen?: boolean; logout(): void; loggingOut: boolean }) {
  const { session, current } = useWorkspace(); const route = useLocation(); const navigate = useNavigate(); const appearance = useAppearance();
  const [collapsed, setCollapsed] = useState(() => { try { return localStorage.getItem('infuse-studio:sidebar') === 'collapsed'; } catch { return false; } });
  const [mobile, setMobile] = useState(false); const [navigatorOpen, setNavigatorOpen] = useState(false); const [search, setSearch] = useState('');
  const drawer = useRef<HTMLDialogElement>(null); const navigatorDialog = useRef<HTMLDialogElement>(null); const navigatorSearch = useRef<HTMLInputElement>(null);
  useEffect(() => { try { localStorage.setItem('infuse-studio:sidebar', collapsed ? 'collapsed' : 'expanded'); } catch { /* Presentation only. */ } }, [collapsed]);
  useEffect(() => { const media = matchMedia('(max-width:760px)'); const update = () => { if (!media.matches) setMobile(false); }; media.addEventListener('change', update); return () => media.removeEventListener('change', update); }, []);
  useEffect(() => { setMobile(false); setNavigatorOpen(false); for (const menu of document.querySelectorAll('.wb-menu[open]')) menu.removeAttribute('open'); }, [route.pathname, route.search, screenZen]);
  useEffect(() => { if (mobile) drawer.current?.showModal(); else drawer.current?.close(); }, [mobile]);
  useEffect(() => { if (navigatorOpen) { navigatorDialog.current?.showModal(); navigatorSearch.current?.focus(); } else navigatorDialog.current?.close(); }, [navigatorOpen]);
  const openNavigator = () => { for (const menu of document.querySelectorAll('.wb-menu[open]')) menu.removeAttribute('open'); setSearch(''); setMobile(false); setNavigatorOpen(true); };
  useEffect(() => {
    const open = (event: KeyboardEvent) => { if (screenZen) return; if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'p') { event.preventDefault(); openNavigator(); } };
    window.addEventListener('keydown', open); return () => window.removeEventListener('keydown', open);
  }, [screenZen]);
  const projectDestinations = project;
  const companyDestinations = company;
  const destinations = [...companyDestinations, ...(session.canManageFloors ? [['/floors', 'Manage floors', 'floor'] as const] : []), ...projectDestinations, ['/settings', 'Profile & settings', 'settings'] as const];
  const selectProject = <label className="wb-project"><span className="wb-label">Project</span><select aria-label="Project" value={session.project.id} disabled={loggingOut} onChange={e => navigate(projectDestination(route.pathname, e.target.value, false))}>{session.projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>;
  const projectPicker = <SidebarMenu hint={collapsed} className="wb-project-menu" label={`Switch project: ${session.project.name}`} text={session.project.name} icon="switchProject"><p>Switch project</p><nav aria-label="Choose project">{session.projects.map(p => <button key={p.id} disabled={loggingOut} aria-current={p.id === session.project.id ? 'true' : undefined} onClick={event => { event.currentTarget.closest('details')?.removeAttribute('open'); navigate(projectDestination(route.pathname, p.id, false)); }}><ShellIcon name="floor" /><span>{p.name}</span></button>)}</nav></SidebarMenu>;
  const panel = (inDrawer = false) => <aside className="wb-sidebar" aria-label="Studio sidebar" onClick={event => { if (inDrawer && (event.target as Element).closest('a[href]')) setMobile(false); }}>
    <div className="wb-brand-row"><Link className="wb-brand" to="/floor" aria-label={`INFUSE Studio · ${session.project.name} project floor`}><img src={mark} alt="" /><strong>INFUSE</strong><span>/ Studio</span></Link><ControlHint label={collapsed ? "Expand sidebar" : "Collapse sidebar"} side="right" enabled={!inDrawer}><button className="wb-collapse" aria-label={inDrawer ? 'Close navigation' : collapsed ? 'Expand sidebar' : 'Collapse sidebar'} aria-expanded={inDrawer ? mobile : !collapsed} onClick={() => inDrawer ? setMobile(false) : setCollapsed(!collapsed)}><ShellIcon name={inDrawer ? 'close' : 'collapse'} /></button></ControlHint></div>
    <ControlHint label="Go to…" side="right" enabled={collapsed && !inDrawer}><button className="wb-search" onClick={openNavigator} aria-label="Go to…"><ShellIcon name="search" /><span>Go to…</span><kbd>⌘ P</kbd></button></ControlHint>
    <nav className="wb-navigation" aria-label="Company and project navigation"><div className="wb-scope" role="group" aria-label="Company navigation"><p className="wb-label">Company</p>{companyDestinations.map(([to, name, icon]) => <ControlHint key={to} label={name} enabled={collapsed && !inDrawer} side="right"><NavLink to={to} aria-label={name} className={({ isActive }) => isActive || (to === '/company' && route.pathname === '/floors') ? 'active' : ''}><ShellIcon name={icon} /><span>{name}</span></NavLink></ControlHint>)}</div>
    <div className="wb-scope wb-project-scope" role="group" aria-label={`Project navigation: ${session.project.name}`}><div className="wb-project-controls">{selectProject}{projectPicker}</div>{projectDestinations.map(([to, name, icon]) => <ControlHint key={to} label={name} enabled={collapsed && !inDrawer} side="right"><NavLink to={to} className={({ isActive }) => (to === '/grilling' ? ['/grilling', '/missions/new', '/missions/v2/new'].includes(route.pathname) : to === '/missions' ? isActive && !['/missions/new', '/missions/v2/new'].includes(route.pathname) : isActive) ? 'active' : ''} aria-label={name === 'Missions' ? 'Mission board' : name === 'Artifacts' ? 'Artifact library' : name}><ShellIcon name={icon} /><span>{name}</span></NavLink></ControlHint>)}</div></nav>
    <div className="wb-bottom"><SidebarMenu hint={collapsed && !inDrawer} label="Help" icon="help"><p>{'Shape work in Grilling, approve the exact mission paper, and inspect its tasks and evidence.'}</p><p>⌘ / Ctrl + P · Go to…<br />Escape · Close navigation</p><Link to={'/missions'}>{'Open missions'}</Link></SidebarMenu>
    <div className="wb-account-row"><ControlHint label="Profile & settings" side="right" enabled={collapsed && !inDrawer}><NavLink className="wb-profile-link" to="/settings" title="Profile & settings" aria-label={`Profile & settings: ${session.displayName || session.profileId}`}><ShellIcon name="account" /><span>{session.displayName || session.profileId}</span></NavLink></ControlHint><SidebarMenu hint={collapsed && !inDrawer} className="wb-account-menu" label={`Account: ${session.displayName || session.profileId}`} text="" icon="more"><Link to="/settings">Profile & settings</Link><p>{current ? 'Connected to Studio' : 'Offline · last known state'}</p><fieldset><legend>Appearance</legend>{(['light', 'dark', 'system'] as const).map(value => <button key={value} aria-pressed={appearance.preference === value} onClick={() => appearance.setPreference(value)}><ShellIcon name={value} />{value[0]!.toUpperCase() + value.slice(1)}</button>)}</fieldset><button onClick={logout} disabled={loggingOut}>Sign out</button></SidebarMenu></div></div>
  </aside>;
  return <AppearanceContext value={appearance}><Tooltip.Provider delayDuration={250}><div className={`ws-app studio-workbench${collapsed ? ' wb-collapsed' : ''}${screenZen ? ' wb-zen' : ''}`} data-studio-theme={appearance.theme}>
    <a className="ws-skip" href="#workspace-main">Skip to workspace</a>{!screenZen && <div className="wb-desktop">{panel()}</div>}
    {!screenZen && <header className="wb-mobile-bar"><button aria-label="Open navigation" onClick={() => setMobile(true)}><ShellIcon name="menu" /></button><Link to="/floor">INFUSE / Studio</Link><span>{session.project.name}</span></header>}
    {!screenZen && <dialog className="wb-drawer" ref={drawer} aria-label="Workspace navigation" onCancel={() => setMobile(false)} onClose={() => setMobile(false)}>{panel(true)}</dialog>}
    <main id="workspace-main" tabIndex={-1} className={floor ? 'ws-floor-main' : route.pathname === '/whiteboard' ? 'ws-canvas-main' : route.pathname === '/desk' ? 'ws-paper-main ws-desk-main' : 'ws-paper-main'}>{children}</main>
    {!screenZen && <dialog ref={navigatorDialog} className="wb-navigator" aria-label="Go to…" onCancel={() => setNavigatorOpen(false)} onClose={() => setNavigatorOpen(false)}><header><h2>Go to…</h2><button aria-label="Close navigator" onClick={() => setNavigatorOpen(false)}><ShellIcon name="close" /></button></header><input aria-label="Find a destination" ref={navigatorSearch} value={search} onChange={e => setSearch(e.target.value)} placeholder="Find a destination…" /><nav>{destinations.filter(([, name]) => name.toLowerCase().includes(search.toLowerCase())).map(([to, name, icon]) => <Link key={to} to={to} onClick={() => setNavigatorOpen(false)}><ShellIcon name={icon} />{name}<small>{to === '/settings' ? 'Account' : to === '/floors' ? 'Office' : to.includes('?project=core') ? session.projects.find(p => p.id === 'core')?.name ?? 'Company' : companyDestinations.some(([path]) => path === to) ? 'Company' : session.project.name}</small></Link>)}</nav></dialog>}
  </div></Tooltip.Provider></AppearanceContext>;
}
export function PendingDestination({ title, description, actionTo = "/missions", actionLabel = "Open missions ↗" }: { title: string; description: string; actionTo?: string; actionLabel?: string }) {
  return <section className="ws-surface"><header className="ws-surface-header"><h1>{title}</h1></header><div className="ws-empty"><h2>Not connected yet.</h2><p>{description}</p><Link className="ws-text-link" to={actionTo}>{actionLabel}</Link></div></section>;
}
