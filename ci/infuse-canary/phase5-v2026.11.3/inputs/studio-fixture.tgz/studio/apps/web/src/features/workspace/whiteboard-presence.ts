import { useEffect, useMemo, useState } from 'react';
import { whiteboardPresence, whiteboardEvent, whiteboardManifest, type WhiteboardParticipant, type WhiteboardPresenceState } from '@studio/contracts';
import { api, type SignedInSession } from './api.js';

export class BoardPresence {
  peers:WhiteboardParticipant[]=[];
  state:WhiteboardPresenceState={ pointer:null,viewport:null,selection:null,drag:null };
  status='Connecting…';
  private listeners=new Set<()=>void>();
  update(patch:Partial<WhiteboardPresenceState>) { const changed='shareView' in patch && JSON.stringify(patch.shareView)!==JSON.stringify(this.state.shareView); this.state={ ...this.state,...patch }; if(changed)for(const listener of this.listeners)listener(); }
  subscribe(listener:()=>void) { this.listeners.add(listener); return ()=> { this.listeners.delete(listener); }; }
  receive(peers:WhiteboardParticipant[],status:string) { this.peers=peers; this.status=status; for (const listener of this.listeners) listener(); }
}

/** A board-level connection survives block changes; no presence is written to disk. */
export function useBoardPresence(path:string,session:SignedInSession,enabled:boolean,onEvent:()=>void) {
  const channel=useMemo(()=>new BoardPresence(),[path,session.profileId,session.csrfToken]);
  const [,render]=useState(0);
  useEffect(()=>channel.subscribe(()=>render(n=>n+1)),[channel]);
  useEffect(()=> {
    if (!enabled) { channel.update({shareView:null}); channel.receive([],'Collaboration paused'); return; }
    let live=true,socket:WebSocket|undefined,ready=false,cursor=0,last='',sentAt=0,retry:ReturnType<typeof setTimeout>|undefined,refresh:ReturnType<typeof setTimeout>|undefined;
    let attempts=0;
    // Text has its own committed stream. Coalesce the secondary board projection
    // reads during an edit burst; a fixed window also refreshes during continuous
    // edits instead of postponing forever. No optimistic state is published.
    function changed() {
      if (refresh!==undefined) return;
      refresh=setTimeout(()=>{refresh=undefined;if(live)onEvent();},200);
    }
    async function connect() {
      try {
        const board=whiteboardManifest.parse(await api(path.replace(/\/v2$/,'/v3')+'?limit=1',{ isCurrent:()=>live })); if (!live) return;
        cursor=board.revision; onEvent();
        const url=new URL(path+'/stream',location.origin); url.protocol=location.protocol==='https:'?'wss:':'ws:';
        socket=new WebSocket(url);
        socket.onopen=()=>socket?.send(JSON.stringify({ type:'hello',version:4,csrf:session.csrfToken }));
        socket.onmessage=event=> {
          if (!live) return;
          try {
            const message=JSON.parse(String(event.data));
            if (message.type==='hello') socket?.send(JSON.stringify({ type:'watch',after:cursor }));
            else if (message.type==='watching') { ready=true; last=''; attempts=0; channel.receive([],'Connected'); }
            else if (message.type==='presence') { const value=whiteboardPresence.parse(message); channel.receive(value.participants.filter(peer=>peer.connectionId!==value.self),'Connected'); }
            else if (message.type==='event') {
              const value=whiteboardEvent.parse(message.event);
              if (value.receipt.projectId!==session.project.id || value.receipt.revision!==cursor+1) throw Error('Feed gap');
              cursor=value.receipt.revision; changed();
            } else if (message.type==='error') {
              // Presence is replaceable advisory state: retry the latest value
              // on the normal coalescing interval without tearing down the feed.
              if (message.code==='BUSY') last='';
              else if (['INVALID_INPUT','EPOCH_CHANGED','NOT_FOUND'].includes(message.code)) { channel.update({ selection:null,drag:null,selectedIds:[],shareView:null }); last=''; }
              else throw Error('Read a fresh board');
            }
          } catch { socket?.close(); }
        };
        socket.onerror=()=>socket?.close();
        socket.onclose=()=> { ready=false; channel.update({shareView:null}); channel.receive([],'Reconnecting…'); if (live) retry=setTimeout(()=>void connect(),Math.min(10000,1000*++attempts)); };
      } catch { if (live) { channel.receive([],'Presence unavailable'); retry=setTimeout(()=>void connect(),10000); } }
    }
    void connect();
    const timer=setInterval(()=> {
      if (!live || !ready || socket?.readyState!==WebSocket.OPEN) return;
      const outgoing={...channel.state,selectedIds:[...(channel.state.selectedIds??[])]};
      while(outgoing.selectedIds.length&&new TextEncoder().encode(JSON.stringify({type:'presence',state:outgoing})).length>2048)outgoing.selectedIds.pop();
      const state=JSON.stringify(outgoing);
      if (state===last && Date.now()-sentAt<10000) return;
      socket.send(JSON.stringify({ type:'presence',state:outgoing })); last=state; sentAt=Date.now();
    },200);
    return ()=> { live=false; clearInterval(timer); clearTimeout(retry); clearTimeout(refresh); socket?.close(); channel.update({ pointer:null,selection:null,drag:null,selectedIds:[],shareView:null }); };
  },[path,session.profileId,session.csrfToken,session.project.id,enabled,channel,onEvent]);
  return channel;
}
