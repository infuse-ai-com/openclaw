import type { ReactNode } from 'react';

interface TerminalStateProps {
  actions?: ReactNode;
  detail: string;
  eyebrow?: string;
  live?: 'off' | 'polite' | 'assertive';
  title: string;
}

export function TerminalState({
  actions,
  detail,
  eyebrow = 'Knowledge Base',
  live = 'off',
  title,
}: TerminalStateProps) {
  return (
    <section
      aria-live={live}
      className="terminal-state"
      data-testid="terminal-state"
    >
      <p className="eyebrow">{eyebrow}</p>
      <h2>{title}</h2>
      <p>{detail}</p>
      {actions && <div className="terminal-state-actions">{actions}</div>}
    </section>
  );
}
