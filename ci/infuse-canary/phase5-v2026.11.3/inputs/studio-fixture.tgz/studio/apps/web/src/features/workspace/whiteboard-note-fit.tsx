import { useLayoutEffect, useRef, type ReactNode } from 'react';

/** Fit literal text, not the editor DOM (which may virtualize long documents).
 * Sizes are world-space pixels: zoom must never change the chosen typography.
 * The hidden probe leaves the live editor, caret and composition untouched. */
export function NoteTextFit({ text, children, onFit }: { text:string; children:ReactNode; onFit?():void }) {
  const region=useRef<HTMLDivElement>(null),probe=useRef<HTMLDivElement>(null);
  const latest=useRef(onFit);latest.current=onFit;
  useLayoutEffect(()=> {
    const box=region.current,measure=probe.current;if(!box||!measure)return;
    let frame=0,live=true;
    const fit=()=> {
      if(!live||box.clientWidth<=0||box.clientHeight<=0)return;
      // Match the body width, including room for the caret at the right edge.
      measure.style.width=box.clientWidth+'px';
      const fits=(size:number)=> {
        measure.style.fontSize=size+'px';
        return measure.scrollHeight<=box.clientHeight-2 && measure.scrollWidth<=box.clientWidth;
      };
      let size=24;
      while(size>2&&!fits(size))size-=2;
      // Extremely dense pasted text still fits; never truncate or rewrite it.
      if(!fits(size)) { let low=0,high=size;for(let i=0;i<12;i++){const mid=(low+high)/2;if(fits(mid))low=mid;else high=mid;}size=low; }
      const value=size+'px';
      if(box.style.getPropertyValue('--wboard-note-font')!==value){box.style.setProperty('--wboard-note-font',value);latest.current?.();}
    };
    const schedule=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(fit);};
    const resize=new ResizeObserver(schedule);resize.observe(box);
    document.fonts.addEventListener('loadingdone',schedule);
    void document.fonts.ready.then(()=>{if(live)schedule();});
    fit();
    return()=>{live=false;cancelAnimationFrame(frame);resize.disconnect();document.fonts.removeEventListener('loadingdone',schedule);};
  },[text]);
  return <div ref={region} className="wboard-note-fit">
    <div ref={probe} className="wboard-note-measure" aria-hidden="true">{text+'\u200b'}</div>
    {children}
  </div>;
}
