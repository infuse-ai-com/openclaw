import { request } from 'node:https';
import { randomUUID } from 'node:crypto';
import { SignJWT, importPKCS8 } from 'jose';
import type { StudioCompanyComputerBinding, StudioComputerWorkspace } from '@studio/server';
export interface ProtectedWorkbenchPreview {
  grantIssuer?: string;
  gatewayServerName?: string;
  clientTls(): { cert: Buffer; key: Buffer; ca: Buffer };
  signingKey(): { kid: string; pem: string };
  readWorkspaces(): readonly StudioComputerWorkspace[];
  authorityAvailable(): boolean;
  /** Test-only suppression proves the independent gateway/broker lease deadline. */
  renewalsEnabled(): boolean;
}
export async function protectedComputerRequest(options: ProtectedWorkbenchPreview, gateway: URL,
  binding: StudioCompanyComputerBinding, expiresAt: number, websocketKey: string, protocol: string | undefined,
  allowed: () => boolean, withdraw: () => void) {
  const streamId=randomUUID();let sequence=0,inflight=false;
  const common={v:1,operatorKind:'human',workspaceId:binding.workspaceId,environmentId:binding.environmentId,
    generation:binding.generation,authorizationRevision:binding.authorizationRevision,streamId};
  const sign=async(audience:string,action:string,lifetime:number)=>{
    const signer=options.signingKey(),key=await importPKCS8(signer.pem,'EdDSA'),now=Math.floor(Date.now()/1000);
    return new SignJWT({...common,action,...(action==='screen.renew'?{sequence}:{})}).setProtectedHeader({alg:'EdDSA',typ:'wb-grant+jwt',kid:signer.kid})
      .setIssuer(options.grantIssuer ?? 'studio-local-workbench').setAudience(audience).setSubject(binding.profileId).setJti(randomUUID())
      .setIssuedAt(now).setNotBefore(now).setExpirationTime(Math.min(now+lifetime,Math.floor(expiresAt/1000))).sign(key);
  };
  const grants=async(action:string,lifetime:number)=>{
    if(!options.authorityAvailable()||!allowed())throw Error('Current Workbench authorization unavailable');
    const [access,runtime]=await Promise.all([sign('workbench-gateway',action,lifetime),sign('workbench-runtime',action,lifetime)]);
    if(!options.authorityAvailable()||!allowed())throw Error('Workbench authorization changed');
    return {Authorization:`Bearer ${access}`,'X-Workbench-Runtime-Grant':`Bearer ${runtime}`};
  };
  const tls=()=>({...options.clientTls(),servername:options.gatewayServerName ?? 'workbench-gateway.fixture',rejectUnauthorized:true,minVersion:'TLSv1.3' as const,agent:false as const});
  const upstream=request(new URL(`/environments/${binding.environmentId}/generations/${binding.generation}/websockify`,gateway),
    {...tls(),headers:{...await grants('screen.control',30),Connection:'Upgrade',Upgrade:'websocket','Sec-WebSocket-Key':websocketKey,'Sec-WebSocket-Version':'13',...(protocol?{'Sec-WebSocket-Protocol':protocol}:{})},timeout:3000});
  const renewing=new Set<ReturnType<typeof request>>();
  const renew=async()=>{
    if(inflight||!options.renewalsEnabled())return;inflight=true;sequence++;
    try{
      const headers=await grants('screen.renew',5);
      await new Promise<void>((yes,no)=>{
        const req=request(new URL(`/streams/${streamId}/lease`,gateway),{...tls(),method:'POST',headers,timeout:1500});renewing.add(req);
        req.once('response',res=>{res.resume();res.once('end',()=>res.statusCode===204?yes():no(Error('Lease denied')));});
        req.once('error',no);req.once('timeout',()=>req.destroy(Error('Lease timeout')));req.once('close',()=>renewing.delete(req));req.end();
      });
    }catch{withdraw();}finally{inflight=false;}
  };
  let timer: ReturnType<typeof setInterval> | undefined;
  upstream.once('upgrade',()=>{timer=setInterval(()=>void renew(),1000);timer.unref();});
  return {upstream,close(){if(timer)clearInterval(timer);for(const req of renewing)req.destroy();}};
}
