import type { FastifyInstance } from 'fastify';
import { whiteboardAgentContextInput, whiteboardAgentReadInput, whiteboardAgentSearchInput, whiteboardAgentFailure, whiteboardAgentLimits,
  type WhiteboardSharedView } from '@studio/contracts';
import { MachineError, MissionError, WhiteboardAgentReader, WhiteboardArtifactSource, whiteboardMcpIdentity, whiteboardAgentActorId,
  type WhiteboardPrincipal, type WhiteboardService, type WhiteboardSourcePort } from '@studio/server';
import type { StandaloneConfig } from './config.js';
import type { FloorDirectory } from './floors.js';
import type { FloorRuntimeController } from './floor-runtime.js';
import { connectedWhiteboardAgents } from './whiteboard-agent-access.js';
import { boardAgentPolicy } from './whiteboard-agent-bridge.js';

const inputs = { context: whiteboardAgentContextInput, read: whiteboardAgentReadInput, search: whiteboardAgentSearchInput };
/** Autonomous reads have their own admission. They never invent native session/run custody. */
export async function registerWhiteboardMcp(app: FastifyInstance, options: {
  initial: StandaloneConfig; readConfig(): StandaloneConfig; floors: FloorDirectory; runtime?: FloorRuntimeController;
  board: WhiteboardService; sharedViews(principal: WhiteboardPrincipal): WhiteboardSharedView[];
}) {
  const initial = structuredClone(options.initial);
  if (!initial.whiteboardMcp?.enabled) return;
  const source: WhiteboardSourcePort = async (projectId, reference, kind, guard) => {
    const controller = new AbortController();
    const current = () => {
      guard();
      if (JSON.stringify(options.readConfig().artifacts) !== JSON.stringify(initial.artifacts)) throw new MissionError('FORBIDDEN', 'Registry configuration changed');
    };
    const pulse = setInterval(() => { try { current(); } catch { controller.abort(); } }, 25);
    try {
      current();
      if (!initial.artifacts) throw new MissionError('UNAVAILABLE', 'Registry unavailable');
      return await new WhiteboardArtifactSource(initial.artifacts, projectId, controller.signal).read(reference, kind, current);
    } catch (error) { current(); throw error; }
    finally { clearInterval(pulse); }
  };
  const reader = new WhiteboardAgentReader(options.board, options.sharedViews, Date.now, undefined, initial.artifacts ? source : undefined);
  await app.register(async http => {
    http.removeContentTypeParser('application/json');
    http.addContentTypeParser('application/json', { parseAs: 'buffer', bodyLimit: whiteboardAgentLimits.requestBytes }, (_request, body, done) => done(null, body));
    http.addHook('onRequest', async (_request, reply) => { reply.header('Cache-Control', 'no-store'); });
    http.setErrorHandler((error, _request, reply) => {
      const code = error instanceof MachineError || error instanceof MissionError ? error.code :
        ['FST_ERR_CTP_BODY_TOO_LARGE', 'FST_ERR_CTP_INVALID_MEDIA_TYPE'].includes(String((error as {code?:string}).code)) ? 'INVALID_INPUT' : 'UNAVAILABLE';
      const failure = whiteboardAgentFailure(code === 'UNAUTHENTICATED' ? 'FORBIDDEN' : code);
      const status = error instanceof MachineError ? error.status : code === 'FORBIDDEN' ? 403 : code === 'INVALID_INPUT' ? 400 : code === 'CANCELLED' ? 408 : code === 'UNAVAILABLE' ? 503 : 409;
      return reply.code(status).send(failure);
    });
    for (const kind of ['context', 'read', 'search'] as const) {
      const path = `/api/machine/whiteboard/v1/${kind}`;
      http.post(path, async (request, reply) => {
        const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 10000);
        const abort = () => controller.abort();
        request.raw.once('aborted', abort); reply.raw.once('close', abort);
        let outcome = 'denied';
        try {
          if (request.url !== path || !Buffer.isBuffer(request.body) || !/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(request.headers['content-type'] ?? '')) throw new MachineError('INVALID_INPUT');
          const body = request.body;
          let value: unknown;
          try { value = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(body)); }
          catch { throw new MachineError('INVALID_INPUT'); }
          const parsed = inputs[kind].safeParse(value);
          if (!parsed.success) throw new MachineError('INVALID_INPUT');
          const projectId = parsed.data.projectId;
          // Startup grants are an upper bound: rotation or added grants require restart;
          // live removal, expiry, policy loss and route changes deny immediately.
          const admitted = whiteboardMcpIdentity(request.headers.authorization, path, body, projectId, initial.whiteboardMcp);
          const guard = (): WhiteboardPrincipal => {
            if (controller.signal.aborted || request.raw.aborted || reply.raw.destroyed) throw new MissionError('CANCELLED', 'Read cancelled');
            const config = options.readConfig();
            const live = whiteboardMcpIdentity(request.headers.authorization, path, body, projectId, config.whiteboardMcp);
            if (admitted.bindingHash !== live.bindingHash || config.authorityId !== initial.authorityId
              || !initial.bridge?.enabled || !config.bridge?.enabled || boardAgentPolicy(initial, config, projectId).access === 'disabled') throw new MachineError('FORBIDDEN');
            for (const settings of [initial, config]) {
              if (!settings.bridge?.gateways.some(g => g.enabled && g.gatewayId === live.gatewayId && g.generation === live.enrollmentGeneration && g.agents.includes(live.agentId))) throw new MachineError('FORBIDDEN');
            }
            if (!connectedWhiteboardAgents({ ...options, initial }, projectId).some(a => a.gatewayId === live.gatewayId && a.agentId === live.agentId)) throw new MachineError('FORBIDDEN');
            return { projectId, actor: { kind: 'agent', id: whiteboardAgentActorId(initial.authorityId, live.gatewayId, live.agentId) }, canWrite: false };
          };
          guard();
          const response = await reader.request({ kind, input: parsed.data }, guard);
          guard(); outcome = 'success'; return response;
        } finally {
          clearTimeout(timer); request.raw.off('aborted', abort); reply.raw.off('close', abort);
          // Fixed operation/outcome only; no bearer, body, cursor, subject or source text.
          console.info(JSON.stringify({ event: 'studio-whiteboard-mcp-read', operation: kind, outcome }));
        }
      });
    }
  });
}
