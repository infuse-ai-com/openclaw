import { whiteboardAgentRequest, whiteboardAgentFailure, whiteboardAgentResponse, WHITEBOARD_AGENT_PROTOCOL, type BridgePrincipal, type WhiteboardSharedView } from '@studio/contracts';
import { WhiteboardAgentReader, WhiteboardAgentEditor, WhiteboardAgentPresenceService, WhiteboardAgentRenderer, whiteboardRendererClient, WhiteboardArtifactSource, whiteboardAgentActorId, MissionError, type CollaborativeWhiteboardService, type WhiteboardService, type WhiteboardPrincipal } from '@studio/server';
import { whiteboardAgentFloorGuard, connectedWhiteboardAgents } from './whiteboard-agent-access.js';
import type { StandaloneConfig } from './config.js';
import type { FloorDirectory } from './floors.js';
import type { FloorRuntimeController } from './floor-runtime.js';

export function boardAgentPolicy(initial: StandaloneConfig, live: StandaloneConfig, projectId: string) {
  const access = (config: StandaloneConfig) => config.whiteboardAgents?.projects.find(p => p.projectId === projectId)?.access
    ?? config.whiteboardAgents?.defaultAccess ?? 'disabled';
  const levels = ['disabled','read','edit'] as const;
  return { version: 1 as const, access: levels[Math.min(levels.indexOf(access(initial)), levels.indexOf(access(live)))]! };
}
export function whiteboardShareTargets(options: {initial:StandaloneConfig;readConfig():StandaloneConfig;floors:FloorDirectory;runtime?:FloorRuntimeController},projectId:string,current=options.floors.readCurrent()) {
  const live=current.config,initial=options.initial;
  if(live.authorityId!==initial.authorityId||!initial.bridge?.enabled||!live.bridge?.enabled||boardAgentPolicy(initial,live,projectId).access==='disabled')return [];
  return connectedWhiteboardAgents(options,projectId,current).filter(route=>
    initial.bridge!.gateways.some(g=>g.enabled&&g.gatewayId===route.gatewayId&&g.agents.includes(route.agentId))&&
    live.bridge!.gateways.some(g=>g.enabled&&g.gatewayId===route.gatewayId&&g.agents.includes(route.agentId)))
    .map(({gatewayId,agentId})=>({gatewayId,agentId}));
}
export function createWhiteboardAgentBridge(options: {
  initial: StandaloneConfig; readConfig(): StandaloneConfig; floors: FloorDirectory; runtime?: FloorRuntimeController;
  executionEnabled(projectId: string): boolean; board: WhiteboardService; text: CollaborativeWhiteboardService;
  sharedViews?: (principal: WhiteboardPrincipal) => WhiteboardSharedView[];
}) {
  const initial = structuredClone(options.initial);
  const presence = new WhiteboardAgentPresenceService(options.board);
  const source:import('@studio/server').WhiteboardSourcePort=async(projectId,reference,kind,guard)=>{
    if(!initial.artifacts)throw new MissionError('ARTIFACTS_UNAVAILABLE','Registry unavailable');
    return new WhiteboardArtifactSource(initial.artifacts,projectId).read(reference,kind,guard);
  };
  const renderer=initial.whiteboardAgents?.rendererUrl?new WhiteboardAgentRenderer(options.board,source,whiteboardRendererClient(initial.whiteboardAgents.rendererUrl)):undefined;
  const reader = new WhiteboardAgentReader(options.board, options.sharedViews, Date.now, {protocol:WHITEBOARD_AGENT_PROTOCOL,
    tools:['studio_whiteboard_context','studio_whiteboard_read','studio_whiteboard_search','studio_whiteboard_apply','studio_whiteboard_receipt','studio_whiteboard_changes','studio_whiteboard_presence','studio_whiteboard_post_update',...(renderer?['studio_whiteboard_render' as const]:[])],imageContent:!!renderer},initial.artifacts?source:undefined);
  const editor = new WhiteboardAgentEditor(options.board,options.text,async(command,guard)=>{
    const projectId=guard().projectId, config=initial.artifacts;
    if(!config)throw new MissionError('ARTIFACTS_UNAVAILABLE','Registry is unavailable');
    const source=new WhiteboardArtifactSource(config,projectId);
    for(const op of command.operations) {
      if(op.type==='createHtml')await source.read(op.tile.reference,'html',guard);
      if(op.type==='createImage')await source.read(op.tile.reference,'image',guard);
      if(op.type==='updateTile'&&op.patch.reference) {
        const tile=await options.board.tile(op.id,op.expectedRevision,guard);
        await source.read(op.patch.reference,tile.kind,guard);
      }
    }
  });
  return {
    async companions(guard:import('@studio/server').WhiteboardGuard,before?:number) {
      const page=await options.board.agentUpdates(before,20,guard);
      return {...page,presence:await presence.list(guard)};
    },
    async request(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal) {
    const parsed = whiteboardAgentRequest.safeParse(input);
    if (!parsed.success) return whiteboardAgentFailure('INVALID_INPUT');
    const { invocation, operation } = parsed.data;
    try {
      if(operation.kind==='receipt') {
        // Enrollment and host call remain mandatory; only the exact actor/hash outcome bypasses board policy/routes.
        const recovery=()=>{
          const live=current(), config=options.readConfig();
          if(config.authorityId!==initial.authorityId||!config.bridge?.enabled||!initial.bridge?.enabled||
            live.gatewayId!==principal.gatewayId||live.generation!==principal.generation||!live.agents.includes(invocation.agentId)||
            !initial.bridge.gateways.some(g=>g.enabled&&g.gatewayId===live.gatewayId&&g.agents.includes(invocation.agentId)))
            throw new MissionError('FORBIDDEN','Current enrolled identity required');
          return {projectId:operation.input.projectId,actor:{kind:'agent' as const,id:whiteboardAgentActorId(initial.authorityId,live.gatewayId,invocation.agentId)},canWrite:false,
            nativeCustody:{gatewayId:live.gatewayId,invocation,managedExecutionEnabled:false}};
        };
        const value=await options.board.agentOutcome(operation.input.commandId,operation.input.payloadHash,recovery);
        return whiteboardAgentResponse.parse({version:2,kind:'whiteboard',protocol:WHITEBOARD_AGENT_PROTOCOL,ok:true,result:{kind:'receipt',value}});
      }
      const guard = whiteboardAgentFloorGuard({ ...options, initial,
        policy: (projectId,config) => boardAgentPolicy(initial, config, projectId) }, operation.input.projectId,
      invocation, () => {
        const live = current();
        if (live.gatewayId !== principal.gatewayId || live.generation !== principal.generation) throw new MissionError('FORBIDDEN', 'Enrollment changed');
        return live;
      }, () => { current(); }); // Host liveness is attested by the enrolled plugin; HTTP cancellation remains live here.
      if(operation.kind==='presence') {
        // A completed HTTP request is not a lease keeper. Revalidate the admitted
        // enrollment snapshot against current config, floor and writer custody.
        const retained=whiteboardAgentFloorGuard({...options,initial,policy:(projectId,config)=>boardAgentPolicy(initial,config,projectId)},
          operation.input.projectId,invocation,()=>{
            const live=options.readConfig().bridge?.gateways.find(g=>g.enabled&&g.gatewayId===principal.gatewayId&&g.generation===principal.generation);
            if(!live?.agents.includes(invocation.agentId))throw new MissionError('FORBIDDEN','Enrollment changed');
            return {...principal,agents:live.agents};
          },()=>{});
        const value=await presence.publish(operation.input,guard,retained);
        return whiteboardAgentResponse.parse({version:2,kind:'whiteboard',protocol:WHITEBOARD_AGENT_PROTOCOL,ok:true,result:{kind:'presence',value}});
      }
      if(operation.kind==='post_update') {
        const value=await editor.postUpdate(operation.input,guard);
        return whiteboardAgentResponse.parse({version:2,kind:'whiteboard',protocol:WHITEBOARD_AGENT_PROTOCOL,ok:true,result:{kind:'post_update',value}});
      }
      if(operation.kind==='render') {
        if(!renderer||options.readConfig().whiteboardAgents?.rendererUrl!==initial.whiteboardAgents?.rendererUrl)throw new MissionError('UNSUPPORTED_CAPABILITY','Renderer unavailable');
        const rendered=await renderer.render(operation.input,guard);
        const response=whiteboardAgentResponse.parse({version:2,kind:'whiteboard',protocol:WHITEBOARD_AGENT_PROTOCOL,ok:true,result:{kind:'render',value:rendered.metadata}});
        return {response,image:{mimeType:'image/png',data:rendered.png.toString('base64')}};
      }
      if(operation.kind==='apply') {
        const value=await editor.apply(operation.input,guard);
        return whiteboardAgentResponse.parse({version:2,kind:'whiteboard',protocol:WHITEBOARD_AGENT_PROTOCOL,ok:true,result:{kind:'apply',value}});
      }
      return await reader.request(operation, guard);
    } catch (error) {
      return whiteboardAgentFailure((error as { code?: string }).code);
    }
  } };
}
