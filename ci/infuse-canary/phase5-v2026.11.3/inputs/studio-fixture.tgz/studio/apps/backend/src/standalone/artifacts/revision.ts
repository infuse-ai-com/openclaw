export { computeArtifactRevision } from '@studio/server';
