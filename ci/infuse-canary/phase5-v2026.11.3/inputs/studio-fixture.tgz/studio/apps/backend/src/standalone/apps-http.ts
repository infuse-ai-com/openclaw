import type { FastifyInstance,FastifyRequest } from 'fastify';
import { readMyApps,resolveAppAccess } from '@studio/server';
import { timingSafeEqual } from 'node:crypto';
import type { BrowserAuthStore,AuthSession } from './auth-store.js';
import type { StandaloneConfig,StudioMember } from './config.js';
import { HttpError } from './http-error.js';
export function registerAppsHttp(app:FastifyInstance,o:{auth:BrowserAuthStore;cookieName:string;origin:string;readConfig:()=>StandaloneConfig;member:(issuer:string,subject:string)=>StudioMember|undefined;hasWorkspace:(id:string)=>boolean}){
 const decision=(i:{issuer:string;subject:string;profileId?:string})=>{
  try{return resolveAppAccess(o.readConfig().apps,i,o.member(i.issuer,i.subject));}
  catch(error){if(error instanceof HttpError)throw error;throw new HttpError('AUTH_UNAVAILABLE',503,'App access policy is unavailable');}
 };
 function access(request:Pick<FastifyRequest,'cookies'>){
  const token=request.cookies[o.cookieName],session=o.auth.session(token);
  if(!session)throw new HttpError('UNAUTHENTICATED',401,'Sign in to My Apps');
  const current=decision(session);
  if(!current.eligible){void Promise.resolve(o.auth.revoke(token)).catch(()=>{});throw new HttpError('ROLE_REVOKED',403,'My Apps access was revoked');}
  const fingerprint=(v:ReturnType<typeof decision>)=>JSON.stringify([v.profileId,v.workspaceMember,v.status,v.groups]);
  return {session,token,current,guard:()=>{if(!o.auth.session(token))throw new HttpError('AUTHORITY_REVOKED',403,'Sign-in ended');if(fingerprint(decision(session))!==fingerprint(current))throw new HttpError('AUTHORITY_REVOKED',403,'App permissions changed during this request');}};
 }
 app.get('/api/apps',async(request)=>{
  if(Object.keys(request.query as object).length)throw new HttpError('INVALID_INPUT',400,'My Apps does not accept an identity or group selector');
  const p=access(request),catalog=p.current.status==='ready'?readMyApps(p.current.groups):{categories:[],apps:[]};
  const workspaceAvailable=!!p.current.workspaceMember&&o.hasWorkspace(p.session.profileId);p.guard();
  return {authenticated:true,profileId:p.session.profileId,displayName:p.current.displayName,csrfToken:p.session.csrfToken,workspaceAvailable,status:p.current.status,...catalog};
 });
 app.post('/api/apps/logout',async(request,reply)=>{
  const p=access(request),csrf=request.headers['x-csrf-token'];
  if(request.headers.origin!==o.origin)throw new HttpError('ORIGIN_FORBIDDEN',403,'A same-origin request is required');
  if(typeof csrf!=='string'||Buffer.byteLength(csrf)!==Buffer.byteLength(p.session.csrfToken)||!timingSafeEqual(Buffer.from(csrf),Buffer.from(p.session.csrfToken)))throw new HttpError('CSRF_INVALID',403,'Refresh My Apps before signing out');
  p.guard();await o.auth.revoke(p.token);reply.clearCookie(o.cookieName,{path:'/',httpOnly:true,secure:new URL(o.origin).protocol==='https:',sameSite:'lax'});return {ok:true};
 });
 return {
  login:(issuer:string,subject:string)=>decision({issuer,subject}),
  launcherOnly:(session:AuthSession)=>{const v=decision(session);return v.eligible&&!v.workspaceMember;},
 };
}
