import type { BridgePrincipal, WhiteboardAgentInvocation, WhiteboardAgentPolicy } from '@studio/contracts';
import { createWhiteboardAgentGuard } from '@studio/server';
import { isCurrentStudioMember, configuredProjects, type StandaloneConfig } from './config.js';
import type { FloorDirectory } from './floors.js';
import type { FloorRuntimeController } from './floor-runtime.js';

type FloorOptions={ initial:StandaloneConfig; readConfig():StandaloneConfig; floors:FloorDirectory; runtime?:FloorRuntimeController };
/** Current routes must retain an installation identity enrolled at process startup. */
export function connectedWhiteboardAgents(options:FloorOptions,projectId:string,current = options.floors.readCurrent()) {
  options.floors.assertSettled(projectId);
  const floor=current.projects.find(p=>p.id===projectId);
  if(!floor || (options.runtime && options.runtime.status(projectId,current)!=='ready'))return [];
  const native=(options.runtime?.config(projectId,false,current)??current.baseConfig(projectId)).nativeMissions;
  const initialRoutes=configuredProjects(options.initial).flatMap(p=>p.nativeMissions
    ? p.nativeMissions.routes.map(route=>({...route,installationId:p.nativeMissions!.installationId,origin:p.nativeMissions!.origin})):[]);
  return (native?.routes??[]).filter(route=>initialRoutes.some(r=>r.installationId===native?.installationId&&r.origin===native?.origin&&
    r.gatewayId===route.gatewayId&&r.agentId===route.agentId&&r.accountId===route.accountId&&r.nativeBotUserId===route.nativeBotUserId));
}
/** Live floor, enrollment and host identity checks for every native read. */
export function whiteboardAgentFloorGuard(options: {
  initial: StandaloneConfig;
  readConfig(): StandaloneConfig;
  floors: FloorDirectory;
  runtime?: FloorRuntimeController;
  executionEnabled(projectId: string): boolean;
  policy(projectId: string, config: StandaloneConfig): WhiteboardAgentPolicy;
}, projectId: string, invocation: WhiteboardAgentInvocation,
currentEnrollment: () => BridgePrincipal, assertInvocationCurrent: (invocation: WhiteboardAgentInvocation) => void) {
  // Enrollment is transport-owned. Neither floor-manager permission nor mission
  // execution enables board access; the separate board policy defaults off.
  const initial = structuredClone(options.initial);
  return createWhiteboardAgentGuard(projectId, invocation, () => {
    options.floors.assertSettled(projectId);
    const config = options.readConfig(), enrollment = currentEnrollment(), current = options.floors.project(config);
    const live = config.bridge?.gateways.find(g => g.enabled && g.gatewayId === enrollment.gatewayId && g.generation === enrollment.generation);
    const started = initial.bridge?.gateways.find(g => g.enabled && g.gatewayId === enrollment.gatewayId);
    const floor = current.projects.find(p => p.id === projectId);
    const connectedAgents = connectedWhiteboardAgents({ ...options, initial }, projectId, current);
    return { authorityId: config.authorityId, enrollment,
      projectId, active: !!floor && config.authorityId === initial.authorityId &&
        config.bridge?.enabled === true && initial.bridge?.enabled === true &&
        !!started?.agents.includes(invocation.agentId) && !!live?.agents.includes(invocation.agentId),
      connectedAgents, companionMemberIds:floor?.memberProfileIds.filter(id=>config.members.some(m=>m.profileId===id&&isCurrentStudioMember(m)))??[], companionExecutionEnabled:initial.whiteboardAgents?.companionEnabled===true&&config.whiteboardAgents?.companionEnabled===true, managedExecutionEnabled: !!floor && options.executionEnabled(projectId), policy: options.policy(projectId, config), assertInvocationCurrent };
  });
}
