import { createHash } from 'node:crypto';
import { SKILL_CATALOG_PRODUCER, SKILL_CATALOG_ARTIFACT, parseArtifactRetainedSource, type ArtifactRetainedSource, type WhiteboardHtmlReference, type ArtifactManifest, type ArtifactPage, type ArtifactDetail } from '@studio/contracts';
import { parseSkillCatalog, parseSkillProvenance } from '@studio/server';
import { ArtifactRegistryReadClient, ArtifactRegistryReadError, artifactRegistryEndpoint, artifactRegistryTokenFile } from './read-client.js';

export interface StudioArtifactsConfig { registryUrl: string; readTokenFile: string; retainedSources?:ArtifactRetainedSource[]; lifecycle?:{tokenFiles:Record<string,string>;floorTokenFile?:string}; imageUpload?:{producer:string;tokenFiles:Record<string,string>;floorTokenFile?:string} }
export function parseArtifactsConfig(value: unknown): StudioArtifactsConfig {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid artifact configuration');
  const v = value as Record<string, unknown>;
  if (Object.keys(v).some(k => !['registryUrl', 'readTokenFile', 'imageUpload','lifecycle','retainedSources'].includes(k)) || typeof v.registryUrl !== 'string' || typeof v.readTokenFile !== 'string') throw Error('Invalid artifact configuration');
  let retainedSources:ArtifactRetainedSource[]|undefined;if(v.retainedSources!==undefined){if(!Array.isArray(v.retainedSources)||v.retainedSources.length>50)throw Error('Invalid retained artifact sources');retainedSources=v.retainedSources.map(parseArtifactRetainedSource);if(new Set(retainedSources.map(s=>s.sourceId)).size!==retainedSources.length)throw Error('Duplicate retained artifact source');}
  let lifecycle:StudioArtifactsConfig['lifecycle'];
  if(v.lifecycle!==undefined){const l=v.lifecycle as NonNullable<StudioArtifactsConfig['lifecycle']>;if(!l||typeof l!=='object'||Array.isArray(l)||Object.keys(l).some(k=>!['tokenFiles','floorTokenFile'].includes(k))||!l.tokenFiles||typeof l.tokenFiles!=='object'||Array.isArray(l.tokenFiles))throw Error('Invalid artifact lifecycle configuration');for(const [project,file] of Object.entries(l.tokenFiles)){if(!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(project)||typeof file!=='string')throw Error('Invalid lifecycle project');artifactRegistryTokenFile(file);}if(l.floorTokenFile!==undefined)artifactRegistryTokenFile(l.floorTokenFile);lifecycle=l;}
  let imageUpload:StudioArtifactsConfig['imageUpload'];
  if(v.imageUpload!==undefined){const u=v.imageUpload as NonNullable<StudioArtifactsConfig['imageUpload']>;if(!u||Object.keys(u).some(k=>!['producer','tokenFiles','floorTokenFile'].includes(k))||typeof u.producer!=='string'||!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(u.producer)||!u.tokenFiles||Array.isArray(u.tokenFiles)||typeof u.tokenFiles!=='object')throw Error('Invalid image upload configuration');for(const [project,file] of Object.entries(u.tokenFiles)){if(!/^[a-z0-9][a-z0-9._-]{0,127}$/.test(project)||typeof file!=='string')throw Error('Invalid image upload tenant');artifactRegistryTokenFile(file);}if(u.floorTokenFile!==undefined)artifactRegistryTokenFile(u.floorTokenFile);imageUpload=u;}
  return { ...(retainedSources?{retainedSources}:{}), ...(lifecycle?{lifecycle}:{}), ...(imageUpload?{imageUpload}:{}), registryUrl: artifactRegistryEndpoint(v.registryUrl).href, readTokenFile: artifactRegistryTokenFile(v.readTokenFile) };
}
const missing = (): never => { throw new ArtifactRegistryReadError('not_found'); };
export class StudioArtifacts {
  private readonly client: ArtifactRegistryReadClient;
  constructor(config: StudioArtifactsConfig, private readonly projectId: string) {
    this.client = new ArtifactRegistryReadClient({ baseUrl: artifactRegistryEndpoint(config.registryUrl), tokenFile: artifactRegistryTokenFile(config.readTokenFile) });
  }
  private visible(manifest: ArtifactManifest) { return manifest.project === this.projectId; }
  list(cursor?:string,state:'active'|'bin'='active',filters:Record<string,string>={}):Promise<ArtifactPage> {
    return this.client.library(this.projectId,state,{...filters,...(cursor?{cursor}:{})});
  }
  private async current(producer: string, artifactId: string, guard: () => void = () => {}) {
    guard();
    const current = await this.client.current(this.projectId, producer, artifactId);
    guard();
    return current;
  }
  /** Exact machine metadata never fetches history or file bodies. */
  async metadata(producer: string, artifactId: string, revision: string, guard: () => void): Promise<ArtifactManifest> {
    await this.current(producer, artifactId, guard);
    guard(); const manifest = await this.client.manifest(producer, artifactId, revision); guard();
    if (!this.visible(manifest)) return missing();
    await this.current(producer, artifactId, guard); guard();
    return manifest;
  }
  async detail(producer: string, artifactId: string, revision: string): Promise<ArtifactDetail> {
    await this.current(producer, artifactId);
    const manifest = await this.client.manifest(producer, artifactId, revision);
    if (!this.visible(manifest)) return missing();
    const history = (await this.client.history(producer, artifactId)).filter(m => this.visible(m));
    if (!history.some(m => m.revision === revision)) return missing();
    return { manifest, revisions: history.map(({ revision, createdAt, title }) => ({ revision, createdAt, title })) };
  }
  async file(producer: string, artifactId: string, revision: string, path: string, mediaTypes?: readonly string[]) {
    const { manifest } = await this.detail(producer, artifactId, revision);
    const expected = manifest.files.find(f => f.path === path && (!mediaTypes || mediaTypes.includes(f.mediaType)));
    if (!expected) return missing();
    const content = await this.client.file(producer, artifactId, revision, path);
    if (content.mediaType !== expected.mediaType || content.body.length !== expected.bytes
      || createHash('sha256').update(content.body).digest('hex') !== expected.sha256) throw new ArtifactRegistryReadError('integrity_failure');
    // Do not expose a response if the artifact was removed/moved while bytes loaded.
    await this.current(producer, artifactId);
    return { file: expected, body: content.body };
  }
  private async bytes(producer: string, artifactId: string, revision: string, path: string, mediaType: string) {
    return (await this.file(producer, artifactId, revision, path, [mediaType])).body;
  }
  async pinned(reference:WhiteboardHtmlReference,content=false) {
    const current=await this.current(reference.producer,reference.artifactId);
    const {manifest}=await this.detail(reference.producer,reference.artifactId,reference.revision);
    const file=manifest.files.find(file=>file.path===reference.path && file.mediaType==='text/html');
    if(!file || file.sha256!==reference.sha256 || file.bytes!==reference.bytes) throw new ArtifactRegistryReadError('integrity_failure');
    const body=content?await this.html(reference.producer,reference.artifactId,reference.revision,reference.path):undefined;
    return {status:current.revision===reference.revision?'current' as const:'changed' as const,latestRevision:current.revision,...(body?{body}:{})};
  }
  async image(reference:WhiteboardHtmlReference) {
    const {manifest}=await this.detail(reference.producer,reference.artifactId,reference.revision);
    const file=manifest.files.find(f=>f.path===reference.path && f.mediaType==='image/webp');
    if(manifest.kind!=='whiteboard-image' || !file || file.bytes!==reference.bytes || file.sha256!==reference.sha256)throw new ArtifactRegistryReadError('integrity_failure');
    return this.bytes(reference.producer,reference.artifactId,reference.revision,reference.path,'image/webp');
  }
  html(producer: string, artifactId: string, revision: string, path: string) { return this.bytes(producer, artifactId, revision, path, 'text/html'); }
  async skillCatalog(revision?: string) {
    if (this.projectId !== 'core') return missing();
    const current = await this.current(SKILL_CATALOG_PRODUCER, SKILL_CATALOG_ARTIFACT);
    const selected = revision ?? current.revision;
    const { manifest } = await this.detail(SKILL_CATALOG_PRODUCER, SKILL_CATALOG_ARTIFACT, selected);
    if (manifest.kind !== 'skill-guide-catalog') throw new ArtifactRegistryReadError('integrity_failure');
    try {
      const catalog = parseSkillCatalog(JSON.parse((await this.bytes(SKILL_CATALOG_PRODUCER, SKILL_CATALOG_ARTIFACT, selected, 'catalog.json', 'application/json')).toString('utf8')));
      if (catalog.producer !== SKILL_CATALOG_PRODUCER || catalog.project !== this.projectId) throw Error('Catalog identity mismatch');
      return { catalog, revision: selected };
    } catch (error) { if (error instanceof ArtifactRegistryReadError) throw error; throw new ArtifactRegistryReadError('integrity_failure'); }
  }
  async skillGuide(skillId: string, revision: string) {
    const { catalog } = await this.skillCatalog(revision);
    const entry = catalog.entries.find(e => e.id === skillId);
    if (!entry) return missing();
    const { manifest } = await this.detail(catalog.producer, entry.artifactId, entry.revision);
    if (manifest.kind !== 'skill-guide' || !manifest.files.some(f => f.path === 'index.html' && f.mediaType === 'text/html' && f.sha256 === entry.htmlSha256)) throw new ArtifactRegistryReadError('integrity_failure');
    try {
      const p = parseSkillProvenance(JSON.parse((await this.bytes(catalog.producer, entry.artifactId, entry.revision, 'provenance.json', 'application/json')).toString('utf8')), catalog, skillId);
      if (createHash('sha256').update(p.markdown).digest('hex') !== p.source.sha256) throw Error('Source byte mismatch');
      return p;
    } catch (error) { if (error instanceof ArtifactRegistryReadError) throw error; throw new ArtifactRegistryReadError('integrity_failure'); }
  }
}
