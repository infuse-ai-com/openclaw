import { createHash } from 'node:crypto';
import { MissionError, requireMission, type FloorChannelProvider, type FloorRuntimeSpec } from '@studio/server';
import type { NativeRouteIdentity } from '@studio/contracts';

type Value = Record<string, unknown>;
/** Only the configured Mattermost origin and credential are used; no floor supplies an endpoint. */
export class MattermostFloorChannels implements FloorChannelProvider {
  constructor(private tokenEnv: () => string, private signal: AbortSignal,
    private request?: (spec: FloorRuntimeSpec, path: string, method?: string, body?: unknown) => Promise<{ status: number; value: Value }>) {}
  private async call(spec: FloorRuntimeSpec, path: string, method = 'GET', body?: unknown) {
    if (this.request) return this.request(spec, path, method, body);
    const token = process.env[this.tokenEnv()];
    requireMission(token, 'CONNECTION_UNAVAILABLE', 'Floor connection credential is unavailable');
    try {
      const response = await fetch(`${spec.origin}/api/v4${path}`, { method, headers: { Authorization: `Bearer ${token}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
        ...(body ? { body: JSON.stringify(body) } : {}), redirect: 'error', signal: AbortSignal.any([this.signal, AbortSignal.timeout(5000)]) });
      if (!response.ok) return { status: response.status, value: {} };
      const text = await response.text(); requireMission(text.length < 128 * 1024, 'CONNECTION_UNAVAILABLE', 'Floor connection response is too large');
      return { status: response.status, value: text ? JSON.parse(text) as Value : {} };
    } catch { throw new MissionError('CONNECTION_UNAVAILABLE', 'Mattermost connection could not be completed'); }
  }
  private id(value: unknown): string {
    requireMission(typeof value === 'string' && /^[a-z0-9]{26}$/.test(value), 'CHANNEL_CONFLICT', 'Mattermost returned an invalid identity'); return value;
  }
  async ensureChannel(spec: FloorRuntimeSpec, role: string, custodyKey: string, existing?: string) {
    const anchor = await this.call(spec, `/channels/${this.id(spec.anchorChannelId)}`);
    requireMission(anchor.status === 200 && !anchor.value.delete_at, 'CONNECTION_UNAVAILABLE', 'The shared team channel is unavailable');
    const teamId = this.id(anchor.value.team_id);
    const suffix = createHash('sha256').update(`${custodyKey}:${role}`).digest('hex').slice(0, 12);
    const slug = (value: string, limit: number) => value.toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, limit).replace(/-+$/, '') || 'floor';
    const name = `studio-${slug(spec.projectId, 20)}-${slug(role, 8)}-${suffix}`;
    const marker = `Studio floor: ${spec.authorityId}/${spec.projectId}/${role}/${custodyKey}`;
    let channel = await this.call(spec, existing ? `/channels/${this.id(existing)}` : `/teams/${teamId}/channels/name/${name}`);
    if (channel.status === 404 && !existing) channel = await this.call(spec, '/channels', 'POST', {
      team_id: teamId, name, display_name: `${spec.projectId} · ${role}`.slice(0, 64), type: 'P', header: marker,
      purpose: 'Studio mission conversations. Managed execution requires exact mission approval.',
    });
    requireMission(channel.status >= 200 && channel.status < 300, 'CONNECTION_UNAVAILABLE', 'The floor channel could not be prepared');
    requireMission(channel.value.team_id === teamId && !channel.value.delete_at, 'CHANNEL_CONFLICT', 'The floor channel does not match its team');
    const baseline = spec.roles.find(item => item.role === role)?.channelId;
    if (!baseline) requireMission(channel.value.type === 'P' && channel.value.name === name && channel.value.header === marker,
      'CHANNEL_CONFLICT', 'The floor channel ownership does not match its saved connection');
    else requireMission(channel.value.id === baseline, 'CHANNEL_CONFLICT', 'The configured channel identity changed');
    return this.id(channel.value.id);
  }
  async verifyBot(spec: FloorRuntimeSpec, route: NativeRouteIdentity) {
    const bot = await this.call(spec, `/users/${this.id(route.nativeBotUserId)}`);
    requireMission(bot.status === 200 && bot.value.id === route.nativeBotUserId && bot.value.is_bot === true
      && bot.value.username === route.nativeUsername && !bot.value.delete_at,
    'IDENTITY_UNAVAILABLE', 'The shared agent identity could not be verified');
  }
  async ensureMember(spec: FloorRuntimeSpec, channelId: string, userId: string) {
    const path = `/channels/${this.id(channelId)}/members`;
    let result = await this.call(spec, `${path}/${this.id(userId)}`);
    if (result.status === 404) result = await this.call(spec, path, 'POST', { user_id: userId });
    requireMission(result.status >= 200 && result.status < 300 && result.value.user_id === userId && result.value.channel_id === channelId,
      'IDENTITY_UNAVAILABLE', 'Floor channel membership could not be verified');
  }
  async removeMember(spec: FloorRuntimeSpec, channelId: string, userId: string) {
    const result = await this.call(spec, `/channels/${this.id(channelId)}/members/${this.id(userId)}`, 'DELETE');
    requireMission(result.status === 404 || result.status >= 200 && result.status < 300, 'IDENTITY_UNAVAILABLE', 'Former floor membership could not be removed');
  }
}
