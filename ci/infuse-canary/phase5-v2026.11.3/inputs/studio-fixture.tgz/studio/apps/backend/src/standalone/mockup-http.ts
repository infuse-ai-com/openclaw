import { existsSync } from 'node:fs';
import { isAbsolute } from 'node:path';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import staticFiles from '@fastify/static';

/** Separately built design reference. No mockup state enters the real application. */
export async function registerMockupHttp(app: FastifyInstance, root: string | undefined, authenticate: (request: FastifyRequest) => unknown) {
  await app.register(async scope => {
    scope.addHook('onRequest', async (request, reply) => {
      reply.header('Cache-Control', 'no-store');
      try { authenticate(request); }
      catch (error) {
        if ((error as { code?: string }).code === 'UNAUTHENTICATED' && ['GET', 'HEAD'].includes(request.method) && request.headers.accept?.includes('text/html')) {
          return reply.redirect('/api/auth/login?returnTo=%2Fprototype-mockup%2F');
        }
        throw error;
      }
    });
    scope.get('', async (_request, reply) => reply.redirect('/prototype-mockup/'));
    scope.setNotFoundHandler((_request, reply) => reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Mockup file not found' } }));
    if (root && isAbsolute(root) && existsSync(root)) {
      await scope.register(staticFiles, { root, prefix: '/', index: 'index.html', dotfiles: 'ignore', decorateReply: false, cacheControl: false });
    } else {
      scope.get('/*', async (_request, reply) => reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Mockup build unavailable' } }));
    }
  }, { prefix: '/prototype-mockup' });
}
