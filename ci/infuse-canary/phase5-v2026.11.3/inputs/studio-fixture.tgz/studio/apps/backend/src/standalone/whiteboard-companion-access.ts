import type { StandaloneConfig } from './config.js';
import { isCurrentStudioMember } from './config.js';
import type { FloorDirectory } from './floors.js';
import type { FloorRuntimeController } from './floor-runtime.js';
import { whiteboardShareTargets } from './whiteboard-agent-bridge.js';
export function companionAccess(options:{initial:StandaloneConfig;readConfig():StandaloneConfig;floors:FloorDirectory;runtime?:FloorRuntimeController}) {
  const live=options.readConfig();
  if(!options.initial.whiteboardAgents?.companionEnabled||!live.whiteboardAgents?.companionEnabled)return [];
  const members=live.members.filter(isCurrentStudioMember).map(m=>m.profileId);
  const current=options.floors.project(live);
  const routes=current.projects.flatMap(p=>whiteboardShareTargets(options,p.id,current).map(target=>({...target,generation:live.bridge?.gateways.find(g=>g.gatewayId===target.gatewayId)?.generation,projectId:p.id,memberIds:p.memberProfileIds.filter(id=>members.includes(id))})));
  return [...new Map(routes.map(route=>[JSON.stringify([route.projectId,route.gatewayId,route.agentId]),route])).values()];
}
