import * as oidc from 'openid-client';
import { loopback, type StandaloneConfig } from './config.js';
import type { LoginTransaction } from './auth-store.js';

export async function createOidc(config: StandaloneConfig) {
  const secret = config.oidc.clientSecretEnv ? process.env[config.oidc.clientSecretEnv] : undefined;
  if (config.oidc.clientSecretEnv && !secret) throw Error('Configured OIDC client secret environment variable is missing');
  const insecure = config.oidc.allowInsecureLoopback === true;
  const client = await oidc.discovery(new URL(config.oidc.issuer), config.oidc.clientId,
    { token_endpoint_auth_method: secret ? 'client_secret_basic' : 'none' }, secret ? oidc.ClientSecretBasic(secret) : oidc.None(),
    { execute: [...(insecure ? [oidc.allowInsecureRequests] : []), oidc.enableNonRepudiationChecks], timeout: 10 });
  for (const endpoint of ['authorization_endpoint', 'token_endpoint', 'jwks_uri'] as const) {
    const value = client.serverMetadata()[endpoint]; if (!value) throw Error('OIDC provider is missing a required endpoint');
    const url = new URL(value);
    if (url.username || url.password || !(url.protocol === 'https:' || (insecure && url.protocol === 'http:' && loopback(url)))) throw Error('Invalid OIDC provider endpoint');
  }
  const callback = new URL('/api/auth/callback', config.origin).href;
  return {
    async begin() {
      const transaction = { state: oidc.randomState(), verifier: oidc.randomPKCECodeVerifier(), nonce: oidc.randomNonce() };
      const url = oidc.buildAuthorizationUrl(client, { redirect_uri: callback, scope: 'openid', response_type: 'code',
        state: transaction.state, nonce: transaction.nonce, code_challenge: await oidc.calculatePKCECodeChallenge(transaction.verifier), code_challenge_method: 'S256' });
      return { transaction, url: url.href };
    },
    async complete(url: URL, transaction: LoginTransaction) {
      const tokens = await oidc.authorizationCodeGrant(client, url, { expectedState: transaction.state, expectedNonce: transaction.nonce,
        pkceCodeVerifier: transaction.verifier, idTokenExpected: true });
      const claims = tokens.claims();
      if (!claims || claims.iss !== config.oidc.issuer || typeof claims.sub !== 'string' || !claims.sub || claims.sub.length > 1024) throw Error('OIDC identity was not verified');
      // Access/refresh/ID tokens never leave this call or enter the session database.
      return { issuer: claims.iss, subject: claims.sub };
    },
  };
}
