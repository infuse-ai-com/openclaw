import { createHash } from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { MACHINE_CONTRACT, MACHINE_REQUEST_BYTES, machineOperations, parseMachineRequest } from '@studio/contracts';
import { MachineError, machineCursorKey, machineIdentity, type StudioAuthority } from '@studio/server';
import { isCurrentStudioMember, type StandaloneConfig, type StudioMember } from './config.js';
import type { FloorDirectory } from './floors.js';
import { StudioArtifacts } from './artifacts/service.js';
import { ArtifactRegistryReadError } from './artifacts/read-client.js';

export async function registerMachineHttp(app: FastifyInstance, options: {
  config: StandaloneConfig; readConfig(): StandaloneConfig; readMembers(): StudioMember[];
  authority: StudioAuthority; floors: FloorDirectory;
}) {
  if (!options.config.machine?.enabled) return;
  machineCursorKey(options.config.machine); // Enabled configuration fails closed before serving.
  await app.register(async machine => {
    // Raw bytes are scoped to these routes; browser and bridge parsers stay unchanged.
    machine.removeContentTypeParser('application/json');
    machine.addContentTypeParser('application/json', { parseAs: 'buffer', bodyLimit: MACHINE_REQUEST_BYTES }, (_request, body, done) => done(null, body));
    machine.setErrorHandler((error, request, reply) => {
      const code = (error as { code?: string }).code;
      const failure = error instanceof MachineError ? error : new MachineError(code === 'FST_ERR_CTP_BODY_TOO_LARGE' || code === 'FST_ERR_CTP_INVALID_MEDIA_TYPE' ? 'INVALID_INPUT' : 'UNAVAILABLE');
      return reply.code(code === 'FST_ERR_CTP_BODY_TOO_LARGE' ? 413 : failure.status).send({ apiContract: MACHINE_CONTRACT, requestId: request.id,
        error: { code: failure.code, message: failure.code === 'UNAVAILABLE' ? 'Studio could not complete this read.' : 'Studio could not admit or return this read.', retryable: failure.code === 'UNAVAILABLE', ...(failure.humanUrl ? { humanUrl: failure.humanUrl } : {}) } });
    });
    for (const operation of machineOperations) {
      const path = `/api/machine/v1/${operation}`;
      machine.post(path, async (request, reply) => {
        let outcome = 'denied', subjectDigest: string | undefined, serviceIssuer: string | undefined, clientId: string | undefined, failureCode: string | undefined;
        try {
          if (request.url !== path || !Buffer.isBuffer(request.body) || !/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(request.headers['content-type'] ?? '')) throw new MachineError('INVALID_INPUT');
          const body = request.body;
          let parsed: ReturnType<typeof parseMachineRequest>;
          try { parsed = parseMachineRequest(operation, JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(body))); }
          catch { throw new MachineError('INVALID_INPUT'); }
          const initial = machineIdentity(request.headers.authorization, path, body, parsed.value.projectId, options.readConfig().machine);
          serviceIssuer = initial.serviceIssuer; clientId = initial.clientId;
          subjectDigest = createHash('sha256').update(initial.profileId).digest('hex').slice(0, 16);
          const guard = () => {
            if (request.raw.aborted || reply.raw.destroyed) throw new MachineError('FORBIDDEN');
            const config = options.readConfig();
            const live = machineIdentity(request.headers.authorization, path, body, parsed.value.projectId, config.machine);
            if (live.profileId !== initial.profileId || live.cursorBinding !== initial.cursorBinding || !options.readMembers().some(m => m.profileId === live.profileId && isCurrentStudioMember(m))) throw new MachineError('FORBIDDEN');
            options.authority.floors.assertSettled(parsed.value.projectId);
            const project = options.floors.projects().find(p => p.id === parsed.value.projectId);
            if (!project?.memberProfileIds.includes(live.profileId)) throw new MachineError('FORBIDDEN');
            const routes = options.floors.config(project.id).nativeMissions?.routes ?? [];
            const targets = routes.filter(r => config.bridge?.gateways.some(g => g.enabled && g.gatewayId === r.gatewayId && g.agents.includes(r.agentId)))
              .map(({ gatewayId, agentId }) => ({ gatewayId, agentId }));
            return { ...live, project: { id: project.id, name: project.name }, targets: [...new Map(targets.map(t => [JSON.stringify(t), t])).values()] };
          };
          guard();
          const result = await options.authority.machineReads.read(parsed, { requestId: request.id, origin: options.config.origin, authorityId: options.config.authorityId,
            cursorKey: () => machineCursorKey(options.readConfig().machine), guard,
            artifact: async (producer, artifactId, revision) => {
              const config = options.readConfig().artifacts;
              if (!config) throw new MachineError('UNAVAILABLE');
              const artifactGuard = () => { guard(); if (JSON.stringify(options.readConfig().artifacts) !== JSON.stringify(config)) throw new MachineError('FORBIDDEN'); };
              try { return await new StudioArtifacts(config, parsed.value.projectId).metadata(producer, artifactId, revision, artifactGuard); }
              catch (error) { if (error instanceof ArtifactRegistryReadError) throw new MachineError(error.code === 'not_found' ? 'NOT_FOUND' : 'UNAVAILABLE'); throw error; }
            } });
          guard(); outcome = 'success'; return result;
        } catch (error) {
          failureCode = error instanceof MachineError ? error.code : 'UNAVAILABLE'; throw error;
        } finally {
          // No bodies, URLs, raw subjects, claims or bearer credentials enter the audit event.
          console.info(JSON.stringify({ event: 'studio-machine-read', operation, requestId: request.id, subjectDigest, serviceIssuer, clientId, outcome, failureCode }));
        }
      });
    }
  });
}
