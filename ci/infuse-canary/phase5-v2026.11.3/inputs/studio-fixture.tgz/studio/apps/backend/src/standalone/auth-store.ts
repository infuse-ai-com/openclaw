import { randomBytes } from 'node:crypto';

export const SESSION_SECONDS = 8 * 60 * 60;
export const LOGIN_SECONDS = 10 * 60;
export interface AuthSession { issuer: string; subject: string; profileId: string; csrfToken: string; expiresAt: number }
export interface LoginTransaction { state: string; verifier: string; nonce: string; returnTo?: "/prototype-mockup/" | "/apps" | `/apps?project=${string}`; expiresAt: number }
type MaybePromise<T> = T | Promise<T>;
export interface BrowserAuthStore {
  refresh(token: unknown): Promise<void>;
  session(token: unknown): AuthSession | undefined;
  createSession(identity: Pick<AuthSession, 'issuer' | 'subject' | 'profileId'>): MaybePromise<{token: string; session: AuthSession}>;
  revoke(token: unknown): MaybePromise<void>;
  createLogin(transaction: Omit<LoginTransaction, 'expiresAt'>): MaybePromise<string>;
  consumeLogin(token: unknown): MaybePromise<LoginTransaction | undefined>;
  close(): MaybePromise<void>;
}
export const opaque = () => randomBytes(32).toString('base64url');
