import { floorBridgeRequest, type BridgePrincipal, type FloorCommand, type FloorRecord } from '@studio/contracts';
import { MissionError, type FloorGuard, type FloorService, type FloorManagementService } from '@studio/server';
import { isCurrentStudioMember, configuredProjects, type StandaloneConfig, type StudioProject } from './config.js';

/** Management policy never substitutes for current Studio enrollment. */
export function canManageFloors(config: StandaloneConfig, profileId: string): boolean {
  return config.members.some(member => member.profileId === profileId && member.canManageFloors !== false && isCurrentStudioMember(member))
    && (config.floorManagement?.allMembers === true || config.floorManagement?.humanProfileIds.includes(profileId) === true);
}

/** Enrollment bounds saved floor membership; runtime configuration supplies team identities. */
export class FloorDirectory {
  constructor(private floors: FloorService, private readConfig: () => StandaloneConfig) {}
  assertSettled(id: string) { this.floors.assertSettled(id); }
  runtimeConfig?: (id: string) => StandaloneConfig;
  /** Fresh, synchronous projection. Never retain this across an await/admission boundary. */
  readCurrent(includeRetired = false) { return this.project(this.readConfig(), includeRetired); }
  /** Project an input freshly acquired by the same synchronous authorization check. */
  project(config: StandaloneConfig, includeRetired = false) {
    const configured = configuredProjects(config), records = this.floors.readSnapshot();
    const projects: StudioProject[] = [
      ...configured.map(project => {
        const saved = records.find(f => f.id === project.id);
        return { ...project, name: saved?.name ?? project.name, memberProfileIds: (saved?.memberProfileIds ?? project.memberProfileIds).filter(id => config.members.some(member => member.profileId === id && isCurrentStudioMember(member))) };
      }),
      ...records.filter(f => f.origin === 'created' && !configured.some(p => p.id === f.id)).map(f => ({
        id: f.id, name: f.name, memberProfileIds: f.memberProfileIds.filter(id => config.members.some(member => member.profileId === id && isCurrentStudioMember(member))),
      })),
    ].filter(project => includeRetired || !records.find(f => f.id === project.id)?.retiredAt);
    return { config, projects, baseConfig(id: string): StandaloneConfig {
      const project = projects.find(p => p.id === id);
      if (!project) throw new MissionError('NOT_FOUND', 'Floor unavailable');
      return { ...config, project: { id, name: project.name }, projects: undefined,
        members: config.members.filter(m => project.memberProfileIds.includes(m.profileId)), nativeMissions: project.nativeMissions ? { ...project.nativeMissions,
          members: project.nativeMissions.members.filter(member => project.memberProfileIds.includes(member.profileId)) } : undefined };
    } };
  }
  projects(includeRetired = false): StudioProject[] { return this.readCurrent(includeRetired).projects; }
  record(id: string): FloorRecord | undefined { return this.floors.record(id); }
  configured(id: string): boolean { return configuredProjects(this.readConfig()).some(p => p.id === id); }
  knowledgeOnly(id: string): boolean {
    const config = this.readConfig();
    return id !== config.project.id && !configuredProjects(config).find(p => p.id === id)?.nativeMissions;
  }
  validate(command: FloorCommand): void {
    const config = this.readConfig();
    if (!('floor' in command)) {
      if (!this.projects(true).some(p => p.id === command.floorId)) throw new MissionError('NOT_FOUND', 'This floor is no longer available');
      return;
    }
    if (command.floor.memberProfileIds.some(id => !config.members.some(member => member.profileId === id && isCurrentStudioMember(member)))) throw new MissionError('FORBIDDEN', 'Choose currently enrolled Studio members');
    const configured = configuredProjects(config).find(p => p.id === command.floor.id);
    if (command.intent === 'create' && configured) throw new MissionError('ALREADY_EXISTS', 'A configured floor already uses this address');
    if (command.intent === 'update' && !configured && !this.record(command.floor.id)) throw new MissionError('NOT_FOUND', 'This floor is no longer available');
  }
  config(id: string): StandaloneConfig { return this.runtimeConfig?.(id) ?? this.baseConfig(id); }
  baseConfig(id: string): StandaloneConfig { return this.readCurrent().baseConfig(id); }
}

export function floorAgentAdapter(management: FloorManagementService, readConfig: () => StandaloneConfig) {
  return { async agentRequest(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal) {
    const parsed = floorBridgeRequest.safeParse(input);
    if (!parsed.success) throw new MissionError('INVALID_INPUT', 'Invalid floor management request');
    const request = parsed.data;
    const guard: FloorGuard = () => {
      const live = current();
      if (live.gatewayId !== principal.gatewayId || live.generation !== principal.generation || !live.agents.includes(request.actor.id))
        throw new MissionError('FORBIDDEN', 'Agent enrollment changed');
      return { actor: { kind: 'agent', id: request.actor.id, gatewayId: live.gatewayId,
        sessionId: request.actor.sessionId, sessionKey: request.actor.sessionKey, runId: request.actor.runId },
        canManage: readConfig().floorManagement?.allEnrolledAgents === true
          || readConfig().floorManagement?.agents.some(a => a.gatewayId === live.gatewayId && a.agentId === request.actor.id) === true };
    };
    switch (request.operation.kind) {
      case 'registry-catalog': return management.registryOperation('catalog',guard);
      case 'registry-preview': return management.registryOperation('preview',guard,request.operation.draft);
      case 'registry-compare': return management.registryOperation('compare',guard,request.operation.proposal);
      case 'registry-command': return management.registryOperation('command',guard,request.operation.command);
      case 'registry-receipt': return management.registryOperation('receipt',guard,request.operation.commandId);
      case 'list': return management.list(guard);
      case 'repositories': return management.catalog(guard);
      case 'repository-inventory': return management.repositoryInventory(guard, request.operation.after);
      case 'save': return management.apply(request.operation.command, guard);
      case 'receipt': return management.receipt(request.operation.commandId, guard);
      case 'connect-repository': return management.repositoryOperation(guard, undefined, request.operation.command);
      case 'repository-receipt': return management.repositoryOperation(guard, request.operation.commandId);
    }
  }
};
}
