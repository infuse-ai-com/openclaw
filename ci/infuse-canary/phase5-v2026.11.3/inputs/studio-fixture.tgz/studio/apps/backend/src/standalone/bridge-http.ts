import { timingSafeEqual } from 'node:crypto';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { parseBridgePrincipal, type BridgePrincipal, type RuntimeTarget } from '@studio/contracts';
import { MissionError, type StudioBridgeAuthority } from '@studio/server';
import { loopback, type StandaloneBridgeConfig, type StandaloneConfig } from './config.js';

export type BridgeConfigReader = () => StandaloneBridgeConfig | undefined;
function tokenBytes(value: unknown): Buffer | undefined {
  if (typeof value !== 'string') return;
  if (/^[a-fA-F0-9]{64}$/.test(value)) return Buffer.from(value, 'hex');
  if (/^[A-Za-z0-9_-]{43}$/.test(value)) {
    const bytes = Buffer.from(value, 'base64url');
    if (bytes.length === 32 && bytes.toString('base64url') === value) return bytes;
  }
}
/** Credential values never enter configuration projections, error messages or logs. */
export function validateBridgeCredentials(bridge: StandaloneBridgeConfig | undefined): void {
  if (!bridge?.enabled) return;
  const tokens: Buffer[] = [];
  for (const gateway of bridge.gateways.filter(item => item.enabled)) {
    const token = tokenBytes(process.env[gateway.tokenEnv]);
    if (!token || tokens.some(prior => timingSafeEqual(prior, token))) throw Error('Enabled Gateway enrollments need distinct 256-bit token environment values');
    tokens.push(token);
  }
}
/** Startup opt-in is sticky; live edits may revoke it, but cannot turn a disabled process on. */
export function bridgeRuntime(config: StandaloneConfig, read: BridgeConfigReader = () => config.bridge) {
  const optedIn = config.bridge?.enabled === true;
  // Native guards may pass their freshly read input; credentials are still checked now.
  function enabled(current?: StandaloneConfig): boolean {
    if (!optedIn) return false;
    try {
      const bridge = current ? current.bridge : read(); validateBridgeCredentials(bridge);
      return bridge?.enabled === true && bridge.gateways.some(item => item.enabled);
    } catch { return false; }
  }
  function targets(): RuntimeTarget[] {
    if (!optedIn) return [];
    try {
      const bridge = read(); validateBridgeCredentials(bridge);
      if (!bridge?.enabled) return [];
      return bridge.gateways.filter(item => item.enabled).flatMap(item => item.agents.map(agentId => ({ gatewayId: item.gatewayId, agentId })));
    } catch { return []; }
  }
  function enrollmentGeneration(gatewayId: string): number | undefined {
    if (!optedIn) return;
    try {
      const bridge = read(); validateBridgeCredentials(bridge);
      if (!bridge?.enabled) return;
      return bridge.gateways.find(item => item.enabled && item.gatewayId === gatewayId)?.generation;
    } catch { return; }
  }
  return { enabled, targets, enrollmentGeneration };
}
function peerIsLoopback(request: FastifyRequest): boolean {
  const address = request.ip;
  return address === '127.0.0.1' || address === '::1' || address === '::ffff:127.0.0.1';
}
export function registerBridgeHttp(app: FastifyInstance, options: {
  config: StandaloneConfig; authority?: StudioBridgeAuthority; readBridge?: BridgeConfigReader;
  native?: { request(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal): Promise<unknown> };
  companion?: { request(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal): Promise<unknown> };
  whiteboard?: { request(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal): Promise<unknown> };
  floors?: { agentRequest(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal): Promise<unknown> };
}): void {
  const { config, authority, readBridge = () => config.bridge } = options;
  const optedIn = config.bridge?.enabled === true;
  const origin = new URL(config.origin);
  function authenticate(request: FastifyRequest): BridgePrincipal {
    // HTTPS is terminated in front of the loopback-bound backend; forwarded headers are never trusted.
    if (!peerIsLoopback(request)) throw new MissionError('BRIDGE_TRANSPORT_REQUIRED', 'Gateway bridge requires the configured secure transport');
    let bridge: StandaloneBridgeConfig | undefined;
    try { bridge = readBridge(); validateBridgeCredentials(bridge); }
    catch { throw new MissionError('BRIDGE_UNAVAILABLE', 'Gateway enrollment configuration is unavailable'); }
    if (!optedIn || (!authority && !options.native && !options.floors && !options.whiteboard && !options.companion) || !bridge?.enabled) throw new MissionError('BRIDGE_DISABLED', 'Gateway bridge is disabled');
    if (origin.protocol !== 'https:' && !(loopback(origin) && bridge.allowInsecureLoopback === true)) throw new MissionError('BRIDGE_TRANSPORT_REQUIRED', 'Gateway bridge requires the configured secure transport');
    const gatewayId = request.headers['x-studio-gateway'];
    const generation = request.headers['x-studio-enrollment'];
    const header = request.headers.authorization;
    const supplied = typeof header === 'string' && header.startsWith('Bearer ') ? tokenBytes(header.slice(7)) : undefined;
    const enrollment = typeof gatewayId === 'string' ? bridge.gateways.find(item => item.enabled && item.gatewayId === gatewayId) : undefined;
    const expected = enrollment ? tokenBytes(process.env[enrollment.tokenEnv]) : undefined;
    // Both operands always have equal length. The enrollment headers only narrow a credential's scope.
    const matches = timingSafeEqual(supplied ?? Buffer.alloc(32), expected ?? Buffer.alloc(32, 1));
    if (!supplied || !expected || !matches || !enrollment || generation !== String(enrollment.generation)
      || request.headers['x-studio-authority'] !== config.authorityId) throw new MissionError('BRIDGE_UNAUTHENTICATED', 'Gateway enrollment could not be authenticated');
    return parseBridgePrincipal({ gatewayId: enrollment.gatewayId, generation: enrollment.generation, agents: enrollment.agents });
  }
  app.post('/api/bridge/v1', async (request: FastifyRequest, reply: FastifyReply) => {
    if (!authority) throw new MissionError('BRIDGE_DISABLED', 'Legacy bridge is disabled');
    if (Object.keys(request.query as object).length) throw new MissionError('INVALID_INPUT', 'Bridge query parameters are not supported');
    const principal = authenticate(request);
    const current = (): BridgePrincipal => {
      if (request.raw.aborted || reply.raw.destroyed) throw new MissionError('AUTHORITY_REVOKED', 'Gateway invocation ended before admission');
      return authenticate(request);
    };
    const response = await authority!.request(request.body, principal, current);
    // The service also guards its store admission and reply; retain the transport's final boundary.
    current(); return response;
  });
  app.post('/api/bridge/v2', async (request: FastifyRequest, reply: FastifyReply) => {
    const companionRequest = (request.body as {kind?:string}|undefined)?.kind==='whiteboard-companion';
    const whiteboardRequest = (request.body as { kind?: string } | undefined)?.kind === 'whiteboard';
    const floorRequest = (request.body as { kind?: string } | undefined)?.kind === 'floor-management';
    if (companionRequest ? !options.companion : whiteboardRequest ? !options.whiteboard : floorRequest ? !options.floors : !options.native) throw new MissionError('BRIDGE_DISABLED', 'This Studio bridge operation is disabled');
    if (Object.keys(request.query as object).length) throw new MissionError('INVALID_INPUT', 'Bridge query parameters are not supported');
    const principal = authenticate(request);
    const current = (): BridgePrincipal => {
      if (request.raw.aborted || reply.raw.destroyed) throw new MissionError('AUTHORITY_REVOKED', 'Gateway invocation ended before admission');
      return authenticate(request);
    };
    const response = companionRequest ? await options.companion!.request(request.body,principal,current) : whiteboardRequest ? await options.whiteboard!.request(request.body, principal, current) : floorRequest ? await options.floors!.agentRequest(request.body, principal, current)
      : await options.native!.request(request.body, principal, current); current(); return response;
  });
}
