import {createHash} from 'node:crypto';
import type {FastifyInstance,FastifyRequest,FastifyReply} from 'fastify';
import {parseHealthDeliveryControl,type HealthCheckView} from '@studio/contracts';
import {companySignalDefinition,healthDefinition,monitoringEmission,healthWebhookUrl,type StudioAuthority} from '@studio/server';
import type {StandaloneConfig} from './config.js';
import {HttpError} from './http-error.js';
interface Principal {actor:{profileId:string};session:{issuer:string;subject:string};guard:()=>unknown}
interface Options {
 authority:StudioAuthority;readConfig:()=>StandaloneConfig;
 access:(request:FastifyRequest,reply:FastifyReply,write?:boolean)=>Principal;
 floors:()=>{id:string;name:string;memberProfileIds:string[]}[];assertSettled:(id:string)=>void;isAdmin:(p:Principal)=>boolean;
}
function query(value:unknown,allowed:string[]):Record<string,string> {
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.entries(value).some(([k,v])=>!allowed.includes(k)||typeof v!=='string'))throw new HttpError('INVALID_INPUT',400,'Invalid monitoring filter or cursor');return value as Record<string,string>;
}
function cursor(value:string|undefined):number|undefined {if(value===undefined)return undefined;const n=Number(value);if(!/^(?:0|[1-9]\d*)$/.test(value)||!Number.isSafeInteger(n))throw new HttpError('INVALID_INPUT',400,'Invalid monitoring history cursor');return n;}
export function registerMonitoringHttp(app:FastifyInstance,o:Options):void {
 let readiness:{at:number;promise:Promise<{ready:true}>}|undefined;
 app.get('/api/ready',async(request,reply)=>{
  query(request.query,[]);const now=Date.now();
  if(!readiness||now-readiness.at>1000){
   const deadline=now+3000;let timer:ReturnType<typeof setTimeout>;
   const promise=Promise.race([o.authority.monitoring.ready(()=>{if(Date.now()>deadline)throw Error('Readiness deadline exceeded');}),new Promise<never>((_resolve,reject)=>{timer=setTimeout(()=>reject(Error('Writer readiness timeout')),3000);timer.unref();})]).finally(()=>clearTimeout(timer));
   readiness={at:now,promise};void promise.catch(()=>{});
  }
  try{await readiness.promise;return {ready:true};}catch{return reply.code(503).send({ready:false});}
 });
 function scope(request:FastifyRequest,reply:FastifyReply,write=false) {
  const p=o.access(request,reply,write),values=query(request.query,['floor',...(write?[]:['observationBefore','episodeBefore','deliveryBefore','incidents','before'])]);
  const admitted=()=>{
   p.guard();const config=o.readConfig(),floors=o.floors().filter(f=>f.memberProfileIds.includes(p.actor.profileId)).filter(f=>{try{o.assertSettled(f.id);return true;}catch{return false;}}).map(f=>({id:f.id,name:f.name})).sort((a,b)=>a.id.localeCompare(b.id));
   if(!floors.length)throw new HttpError('PROJECT_FORBIDDEN',403,'A currently admitted Studio floor is required');
   if(values.floor&&!floors.some(f=>f.id===values.floor))throw new HttpError('FORBIDDEN',403,'This floor is outside your monitoring admission');
   const floorIds=values.floor?[values.floor]:floors.map(f=>f.id),checks=config.monitoring?.checks.filter(c=>c.floorIds.some(id=>floorIds.includes(id)))??[],companySources=config.monitoring?.signals?.sources.filter(c=>c.floorIds.some(id=>floorIds.includes(id)))??[],admin=o.isAdmin(p);
   return {floors,checks,companySources,admin,monitoring:config.monitoring};
  };
  const initial=admitted(),snapshot=JSON.stringify(initial);
  const guard=()=>{if(JSON.stringify(admitted())!==snapshot)throw new HttpError('AUTHORITY_REVOKED',403,'Monitoring source admission changed during this request');};
  if(write&&!initial.admin)throw new HttpError('ADMIN_REQUIRED',403,'Trusted infuse-admins membership is required for alert controls');
  return {...initial,p,values,guard};
 }
 function selected(request:FastifyRequest,reply:FastifyReply,write=false){const s=scope(request,reply,write),id=(request.params as {checkId:string}).checkId,check=s.checks.find(c=>c.id===id);if(!check)throw new HttpError('FORBIDDEN',403,'This health check is outside your admitted sources');return {...s,check};}
 app.get('/api/monitoring',async(request,reply)=>{
  query(request.query,['floor']);const s=scope(request,reply),checks=await o.authority.monitoring.read<HealthCheckView[]>({kind:'read',checks:s.checks.map(healthDefinition)},s.guard);
  const emission=s.monitoring?monitoringEmission(s.monitoring):undefined;let deliveryState:'off'|'shadow'|'ready'|'unavailable'=s.monitoring?.enabled?emission?.mode==='live'?'ready':'shadow':'off';
  if(deliveryState==='ready')try{healthWebhookUrl(process.env[s.monitoring!.delivery.webhookEnv!]);}catch{deliveryState='unavailable';}
  s.guard();return {readAt:new Date().toISOString(),collecting:s.monitoring?.enabled===true,deliveryState,canAdmin:s.admin,floors:s.floors,checks};
 });
 app.get('/api/monitoring/signals',async(request,reply)=>{
  query(request.query,['floor']);const s=scope(request,reply);
  const sources=await o.authority.companySignals.read({kind:'read',definitions:s.companySources.map(companySignalDefinition)},s.guard);s.guard();
  return {readAt:new Date().toISOString(),collecting:s.monitoring?.enabled===true&&s.monitoring.signals?.enabled===true,sources};
 });
 app.get('/api/monitoring/signals/:sourceId',async(request,reply)=>{
  query(request.query,['floor']);const s=scope(request,reply),id=(request.params as {sourceId:string}).sourceId,source=s.companySources.find(c=>c.sourceId===id);if(!source)throw new HttpError('FORBIDDEN',403,'This company source is outside your admitted floors');
  const sources=await o.authority.companySignals.read({kind:'read',definitions:[companySignalDefinition(source)]},s.guard);s.guard();
  return {readAt:new Date().toISOString(),collecting:s.monitoring?.enabled===true&&s.monitoring.signals?.enabled===true,sources};
 });
 app.get('/api/monitoring/checks/:checkId',async(request,reply)=>{
  query(request.query,['floor','observationBefore','episodeBefore','deliveryBefore','incidents']);const s=selected(request,reply),v=s.values;
  if(v.incidents!==undefined&&!['all','unresolved'].includes(v.incidents))throw new HttpError('INVALID_INPUT',400,'Invalid incident filter');
  const result=await o.authority.monitoring.read({kind:'detail',check:healthDefinition(s.check),unresolvedOnly:v.incidents==='unresolved',observationBefore:cursor(v.observationBefore),episodeBefore:cursor(v.episodeBefore),deliveryBefore:cursor(v.deliveryBefore)},s.guard);s.guard();return result;
 });
 app.get('/api/monitoring/checks/:checkId/audit',async(request,reply)=>{
  query(request.query,['floor','before']);const s=selected(request,reply);if(!s.admin)throw new HttpError('ADMIN_REQUIRED',403,'Trusted infuse-admins membership is required for audit');
  const result=await o.authority.monitoring.read({kind:'audit',check:healthDefinition(s.check),before:cursor(s.values.before)},s.guard);s.guard();return result;
 });
 app.post('/api/monitoring/checks/:checkId/deliveries/actions',{bodyLimit:4096},async(request,reply)=>{
  const s=selected(request,reply,true);let command;try{command=parseHealthDeliveryControl(request.body);}catch{throw new HttpError('INVALID_INPUT',400,'Use an exact alert action, revision and confirmation');}
  if(!s.monitoring)throw new HttpError('FORBIDDEN',403,'Monitoring is not configured');
  const actorId='human-'+createHash('sha256').update(JSON.stringify([s.p.session.issuer,s.p.session.subject,s.p.actor.profileId])).digest('hex');
  try{const result=await o.authority.monitoring.control({kind:'control',check:healthDefinition(s.check),emission:monitoringEmission(s.monitoring),actorId,command},s.guard);s.guard();return result;}
  catch(error){const code=String((error as {code?:string}).code);if(['CONFIRMATION_REQUIRED','INVALID_STATE'].includes(code))throw new HttpError(code,409,'Refresh the exact alert state and confirm the requested action with evidence');throw error;}
 });
}
