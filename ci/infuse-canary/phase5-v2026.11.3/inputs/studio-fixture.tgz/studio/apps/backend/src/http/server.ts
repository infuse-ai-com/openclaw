import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { getSystemHealth } from '@studio/server';

const contentTypes: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
};

export function createStudioServer({ webRoot }: { webRoot?: string } = {}) {
  const root = webRoot ? resolve(webRoot) : undefined;

  return createServer(async (req, res) => {
    const json = (status: number, body: unknown) => {
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      });
      res.end(req.method === 'HEAD' ? undefined : JSON.stringify(body));
    };

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.setHeader('Allow', 'GET, HEAD');
      json(405, { error: 'Method not allowed' });
      return;
    }

    let pathname: string;
    try {
      pathname = decodeURIComponent(new URL(req.url || '/', 'http://studio.local').pathname);
    } catch {
      json(400, { error: 'Invalid URL' });
      return;
    }

    if (pathname === '/api/health') {
      json(200, getSystemHealth());
      return;
    }
    if (pathname === '/api' || pathname.startsWith('/api/')) {
      json(404, { error: 'API route not found' });
      return;
    }
    if (!root) {
      json(503, { error: 'Frontend build is unavailable. Run npm run build.' });
      return;
    }

    let target = resolve(root, '.' + pathname);
    if (target !== root && !target.startsWith(root + sep)) {
      json(403, { error: 'Invalid asset path' });
      return;
    }

    try {
      if (pathname === '/') {
        target = resolve(root, 'index.html');
      } else {
        try {
          if (!(await stat(target)).isFile()) throw new Error('Not a file');
        } catch {
          // Only browser page navigation falls back to the frontend entry point.
          if (!extname(pathname) && req.headers.accept?.includes('text/html')) {
            target = resolve(root, 'index.html');
          } else {
            json(404, { error: 'Asset not found' });
            return;
          }
        }
      }
      const body = await readFile(target);
      res.writeHead(200, {
        'content-type': contentTypes[extname(target)] || 'application/octet-stream',
        'x-content-type-options': 'nosniff',
        'cache-control': 'no-cache',
      });
      res.end(req.method === 'HEAD' ? undefined : body);
    } catch {
      json(503, { error: 'Frontend build is unavailable. Run npm run build.' });
    }
  });
}
