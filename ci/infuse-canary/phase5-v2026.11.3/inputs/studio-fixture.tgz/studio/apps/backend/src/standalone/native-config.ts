import { mattermostId, missionIdentifier, type RuntimeTarget } from '@studio/contracts';

export interface NativeProjectRoute extends RuntimeTarget {
  role: string; accountId: string; nativeBotUserId: string; nativeUsername: string; channelId: string;
}
export interface NativeMissionsConfig {
  enabled: boolean; cutover: boolean; installationId: string; origin: string; tokenEnv: string;
  lifecycleNotifications?: boolean; instructionVersion?: 1;
  routes: NativeProjectRoute[]; members: { userId: string; profileId: string }[];
}
function record(v: unknown, allowed: string[]): Record<string, unknown> {
  if (!v || typeof v !== 'object' || Array.isArray(v) || Object.keys(v).some(k => !allowed.includes(k))) throw Error('Invalid native mission configuration');
  return v as Record<string, unknown>;
}
export function parseNativeMissionsConfig(input: unknown, targets: RuntimeTarget[]): NativeMissionsConfig {
  const v = record(input, ['enabled', 'cutover', 'lifecycleNotifications', 'instructionVersion', 'installationId', 'origin', 'tokenEnv', 'routes', 'members']);
  if (typeof v.enabled !== 'boolean' || typeof v.cutover !== 'boolean') throw Error('Native execution and cutover require explicit flags');
  if (v.lifecycleNotifications !== undefined && typeof v.lifecycleNotifications !== 'boolean') throw Error('Native lifecycle notifications require an explicit boolean');
  if (v.instructionVersion !== undefined && v.instructionVersion !== 1) throw Error('Native instructionVersion must be 1 when enabled');
  const url = new URL(String(v.origin));
  if (url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw Error('Native Mattermost needs an HTTPS origin');
  if (typeof v.tokenEnv !== 'string' || !/^[A-Z][A-Z0-9_]*$/.test(v.tokenEnv)) throw Error('Native Mattermost needs a token environment reference');
  if (!Array.isArray(v.routes) || v.routes.length < 1 || v.routes.length > 100 || !Array.isArray(v.members) || v.members.length > 1000) throw Error('Invalid native project routes');
  const routes = v.routes.map(input => {
    const r = record(input, ['role', 'gatewayId', 'agentId', 'accountId', 'nativeBotUserId', 'nativeUsername', 'channelId']);
    const target = { gatewayId: missionIdentifier(r.gatewayId), agentId: missionIdentifier(r.agentId) };
    if (!targets.some(t => t.gatewayId === target.gatewayId && t.agentId === target.agentId)) throw Error('Native agent must already be enrolled');
    if (typeof r.nativeUsername !== 'string' || !/^[a-z0-9._-]{1,64}$/.test(r.nativeUsername)) throw Error('Invalid native username');
    return { ...target, role: missionIdentifier(r.role), accountId: missionIdentifier(r.accountId), nativeBotUserId: mattermostId(r.nativeBotUserId),
      nativeUsername: r.nativeUsername, channelId: mattermostId(r.channelId) };
  });
  if (routes.filter(r => r.role === 'coordinator').length !== 1 || new Set(routes.map(r => r.role)).size !== routes.length) throw Error('Configure one coordinator and one channel route per specialist role');
  const members = v.members.map(input => {
    const m = record(input, ['userId', 'profileId']); return { userId: mattermostId(m.userId), profileId: missionIdentifier(m.profileId) };
  });
  if (new Set(members.map(m => m.userId)).size !== members.length || new Set(members.map(m => m.profileId)).size !== members.length) throw Error('Duplicate native human identity');
  return { ...(v.instructionVersion === 1 ? { instructionVersion: 1 as const } : {}), enabled: v.enabled, cutover: v.cutover, ...(v.lifecycleNotifications !== undefined ? { lifecycleNotifications: v.lifecycleNotifications } : {}), installationId: missionIdentifier(v.installationId), origin: url.origin, tokenEnv: v.tokenEnv, routes, members };
}
