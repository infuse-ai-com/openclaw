import {
  mattermostId, parseConversationBind, parseConversationComment, parseConversationPost, parseConversationRead, parseConversationRoute, parseConversationResponseRequest,
  type ConversationAuthor, type ConversationBinding, type ConversationDelivery, type ConversationPage, type ConversationPost,
  type ConversationRoute, type ConversationSyncError, type ConversationExecutionScope, type ConversationResponse, type RuntimeExecutionTarget,
} from '@studio/contracts';
import { MissionError, type MissionStore, type StudioHumanActor } from '@studio/server';
import type { StandaloneConfig, StandaloneMattermostConfig } from './config.js';

type Guard = () => void;
type HumanGuard = () => StudioHumanActor;
type RecordValue = Record<string, unknown>;
type Attestation = {
  route: ConversationRoute; settings: StandaloneMattermostConfig; token: string; guard: Guard;
  authors: Map<string, ConversationAuthor>;
};
const PAGE_SIZE = 100;
const MAX_POSTS = 1000;
const MAX_MEMBERS = 1000;
const MAX_BYTES = 2 * 1024 * 1024;
const invalid = () => new MissionError('CONVERSATION_SOURCE_INVALID', 'Mattermost returned an invalid or unsupported source');
function record(value: unknown): RecordValue {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw invalid();
  return value as RecordValue;
}
function sourceId(value: unknown): string { try { return mattermostId(value); } catch { throw invalid(); } }
function routeKey(value: ConversationRoute): string { return JSON.stringify(parseConversationRoute({ installationId: value.installationId, origin: value.origin, botUserId: value.botUserId, channelId: value.channelId })); }
function user(value: unknown): { id: string; bot: boolean; label: string } {
  const u = record(value);
  if (u.delete_at !== 0 || (u.is_bot !== undefined && typeof u.is_bot !== 'boolean') || typeof u.username !== 'string'
    || !u.username.trim() || u.username.length > 256 || /[\u0000-\u001f\u007f]/u.test(u.username)) throw invalid();
  return { id: sourceId(u.id), bot: u.is_bot === true, label: u.username };
}
function post(value: unknown): ConversationPost {
  const p = record(value); const props = p.props === undefined ? {} : record(p.props);
  // Attachments, system posts and presentation transforms are outside the initial text-only adapter.
  if ((p.type !== undefined && p.type !== '') || (p.file_ids !== undefined && (!Array.isArray(p.file_ids) || p.file_ids.length))
    || (p.message_source !== undefined && p.message_source !== '' && p.message_source !== p.message)) throw invalid();
  try {
    return parseConversationPost({ id: p.id, channelId: p.channel_id, rootId: p.root_id, userId: p.user_id,
      createAt: p.create_at, updateAt: p.update_at, deleteAt: p.delete_at, message: p.message,
      ...(props.studio_delivery_id === undefined ? {} : { deliveryId: props.studio_delivery_id }) });
  } catch { throw invalid(); }
}
function input<T>(parse: (value: unknown) => T, value: unknown): T {
  try { return parse(value); } catch { throw new MissionError('INVALID_INPUT', 'Invalid conversation request'); }
}
function syncError(error: unknown): ConversationSyncError {
  const code = (error as { code?: string }).code;
  if (code === 'CONVERSATION_HISTORY_LIMIT' || code === 'CONVERSATION_LIMIT') return 'history-limit';
  if (code === 'CONVERSATION_SOURCE_INVALID' || code === 'CONVERSATION_CONFLICT') return 'invalid-source';
  if (code === 'CONVERSATION_ROUTE_REVOKED' || code === 'CONVERSATION_DISABLED' || code === 'AUTHORITY_REVOKED') return 'route-revoked';
  return 'offline';
}

/** A single local adapter. Conversation observations never invoke the runtime or mission commands. */
export class ConversationService {
  private readonly initialRoute?: string;
  private readonly optedIn: boolean;
  private readonly responsesOptedIn: boolean;
  private readonly controller = new AbortController();
  private timer?: ReturnType<typeof setTimeout>;
  private polling?: Promise<void>;
  private stopped = false;
  private started = false;
  constructor(private readonly options: { store: MissionStore; config: StandaloneConfig; readConfig?: () => StandaloneConfig;
    executionEnabled?: () => boolean; executionGuard?: (targets: RuntimeExecutionTarget[]) => void }) {
    this.optedIn = options.config.mattermost?.enabled === true;
    this.responsesOptedIn = options.config.mattermost?.coordinatorResponsesEnabled === true;
    this.initialRoute = options.config.mattermost && routeKey(options.config.mattermost);
  }
  private current(): StandaloneConfig { return (this.options.readConfig ?? (() => this.options.config))(); }
  private snapshot(): { settings: StandaloneMattermostConfig; token: string; guard: Guard; config: StandaloneConfig } {
    if (!this.optedIn || this.stopped) throw new MissionError('CONVERSATION_DISABLED', 'Mattermost conversations are disabled');
    let config: StandaloneConfig;
    try { config = this.current(); } catch { throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Mattermost configuration is unavailable'); }
    const settings = config.mattermost;
    if (!settings?.enabled || routeKey(settings) !== this.initialRoute) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Mattermost route changed or was disabled');
    const token = process.env[settings.tokenEnv];
    if (!token || token.length > 4096 || /\s/u.test(token)) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Mattermost credential is unavailable');
    const stamp = JSON.stringify({ mattermost: settings, members: config.members });
    const guard = () => {
      let next: StandaloneConfig;
      try { next = this.current(); } catch { throw new MissionError('AUTHORITY_REVOKED', 'Conversation authority changed'); }
      if (this.stopped || !next.mattermost?.enabled || JSON.stringify({ mattermost: next.mattermost, members: next.members }) !== stamp
        || process.env[settings.tokenEnv] !== token) throw new MissionError('AUTHORITY_REVOKED', 'Conversation authority changed');
    };
    return { settings, token, guard, config };
  }
  available(): boolean { try { this.snapshot(); return true; } catch { return false; } }
  private assertResponses(): void {
    if (!this.responsesOptedIn || !this.current().mattermost?.coordinatorResponsesEnabled || !this.options.executionEnabled?.()
      || !this.options.executionGuard) throw new MissionError('CONVERSATION_DISABLED', 'Coordinator responses are not enabled');
    this.snapshot().guard();
  }
  private responsesAvailable(): boolean { try { this.assertResponses(); return true; } catch { return false; } }
  private async request(attestation: Pick<Attestation, 'settings' | 'token' | 'guard'>, path: string, body?: unknown): Promise<unknown> {
    attestation.guard();
    const response = await fetch(`${attestation.settings.origin}/api/v4${path}`, {
      method: body === undefined ? 'GET' : 'POST', redirect: 'error',
      headers: { authorization: `Bearer ${attestation.token}`, accept: 'application/json', ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.any([this.controller.signal, AbortSignal.timeout(10000)]),
    }).catch(() => { throw new MissionError('CONVERSATION_OFFLINE', 'Mattermost connection is unavailable'); });
    if (!response.ok) {
      await response.body?.cancel();
      throw new MissionError([401, 403, 404].includes(response.status) ? 'CONVERSATION_ROUTE_REVOKED' : 'CONVERSATION_OFFLINE', 'Mattermost request failed');
    }
    if (Number(response.headers.get('content-length')) > MAX_BYTES) { await response.body?.cancel(); throw invalid(); }
    const reader = response.body?.getReader(); if (!reader) throw invalid();
    let length = 0; const chunks: Uint8Array[] = [];
    try {
      while (true) { const chunk = await reader.read(); if (chunk.done) break; length += chunk.value.length; if (length > MAX_BYTES) throw invalid(); chunks.push(chunk.value); }
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch (error) {
      await reader.cancel().catch(() => {});
      if (error instanceof MissionError) throw error;
      if (error instanceof SyntaxError) throw invalid();
      throw new MissionError('CONVERSATION_OFFLINE', 'Mattermost response was interrupted');
    }
    finally { reader.releaseLock(); }
  }
  private async attest(): Promise<Attestation> {
    const snapshot = this.snapshot(); const { settings, config, guard } = snapshot;
    const me = user(await this.request(snapshot, '/users/me'));
    if (me.id !== settings.botUserId || !me.bot) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Configured Mattermost bot identity is unavailable');
    const channel = record(await this.request(snapshot, `/channels/${settings.channelId}`));
    if (channel.id !== settings.channelId || channel.type !== 'P' || channel.delete_at !== 0) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Mattermost requires the configured active private project channel');
    const ids = new Set<string>();
    for (let page = 0; ; page++) {
      const values = await this.request(snapshot, `/channels/${settings.channelId}/members?page=${page}&per_page=${PAGE_SIZE}`);
      if (!Array.isArray(values) || values.length > PAGE_SIZE) throw invalid();
      for (const value of values) {
        const entry = record(value); const id = sourceId(entry.user_id);
        if (entry.channel_id !== settings.channelId || ids.has(id)) throw invalid();
        ids.add(id);
      }
      if (ids.size > MAX_MEMBERS) throw new MissionError('CONVERSATION_HISTORY_LIMIT', 'Mattermost channel membership exceeds the adapter limit');
      if (values.length < PAGE_SIZE) break;
    }
    if (!ids.has(me.id)) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Studio bot is not a channel member');
    const authors = new Map<string, ConversationAuthor>();
    // Canonical user records distinguish bots; channel-member role strings do not.
    for (const id of ids) {
      const person = id === me.id ? me : user(await this.request(snapshot, `/users/${id}`));
      if (person.id !== id || (person.bot && id !== me.id)) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Other bots are not allowed in the Studio project channel');
      if (id === me.id) { authors.set(id, { kind: 'mattermost', id, label: person.label }); continue; }
      const mapped = settings.members.find(item => item.userId === id);
      if (!mapped || !config.members.some(member => member.profileId === mapped.profileId)) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Every channel member must be enrolled in this Studio project');
      authors.set(id, { kind: 'mattermost', id, label: person.label, profileId: mapped.profileId });
    }
    guard();
    return { ...snapshot, route: parseConversationRoute({ installationId: settings.installationId, origin: settings.origin, botUserId: settings.botUserId, channelId: settings.channelId }), authors };
  }
  private match(binding: ConversationBinding, attestation: Attestation): void {
    if (routeKey(binding) !== routeKey(attestation.route)) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Conversation belongs to another Mattermost route');
  }
  private async root(rootId: string, attestation: Attestation): Promise<ConversationPost> {
    const root = post(await this.request(attestation, `/posts/${rootId}`));
    if (root.id !== rootId || root.rootId !== '' || root.channelId !== attestation.route.channelId || root.userId !== attestation.route.botUserId || root.deleteAt !== 0) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Conversation root must be an active post by the configured Studio bot');
    return root;
  }
  private human(guard: HumanGuard, approver = false): { profileId: string; label: string } {
    const actor = guard(); const member = this.current().members.find(item => item.profileId === actor.profileId);
    if (!member || (approver && (!member.approver || !actor.approver))) throw new MissionError('FORBIDDEN', 'Current Studio permission is required');
    return { profileId: member.profileId, label: member.displayName ?? member.profileId };
  }
  async read(value: unknown, guard: HumanGuard): Promise<ConversationPage> {
    const parsed = input(parseConversationRead, value); this.human(guard);
    const page = await this.options.store.conversationRead(parsed, guard); guard();
    const mission = (await this.options.store.view(parsed.missionId, guard)).mission;
    return { ...page, available: this.available(), responseAvailable: this.responsesAvailable()
      && mission.state === 'running' && !mission.held && !mission.closeoutRequest };
  }
  private responseGuard(attestation: Attestation, profiles: (string | undefined)[]): Guard {
    return () => {
      this.assertResponses(); attestation.guard();
      for (const profileId of profiles) if (!profileId || ![...attestation.authors.values()].some(author => author.profileId === profileId))
        throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'The conversation participants must remain enrolled in the project channel');
    };
  }
  /** Explicit human request only. Retained comments and scans never create work automatically. */
  async requestResponse(value: unknown, guard: HumanGuard): Promise<ConversationResponse> {
    const parsed = input(parseConversationResponseRequest, value); const actor = this.human(guard);
    const receipt = await this.options.store.conversationResponseReceipt(parsed, actor, () => { this.human(guard); });
    if (receipt) { this.human(guard); return receipt; }
    this.assertResponses();
    const selected = parsed.source;
    const attestation = await this.attest();
    const page = await this.options.store.conversationRead({ missionId: parsed.missionId, limit: 1,
      ...(selected.kind === 'event' ? { beforeSequence: selected.sequence + 1 } : {}) }, guard);
    const binding = page.bindings.find(item => item.id === parsed.bindingId);
    if (!binding) throw new MissionError('CONVERSATION_CONFLICT', 'Conversation binding is not current');
    this.match(binding, attestation);
    const source = selected.kind === 'event' ? page.events.find(item => item.sequence === selected.sequence)
      : page.deliveries.find(item => item.id === selected.deliveryId);
    const participants = this.responseGuard(attestation, [actor.profileId, source?.author.profileId]);
    const current = () => { this.human(guard); participants(); }; current();
    const posts = await this.scan(binding, attestation);
    if (selected.kind === 'event' && (!source || !('postId' in source) || !posts.some(item => item.post.id === source.postId
      && item.post.message === source.text && item.post.deleteAt === 0 && item.post.updateAt <= item.post.createAt)))
      throw new MissionError('CONVERSATION_CONFLICT', 'The original source message is no longer available');
    await this.options.store.conversationIngest(binding.id, attestation.route, posts, current);
    const response = await this.options.store.conversationResponse(parsed, actor, current, this.options.executionGuard!);
    current(); return response;
  }
  /** REST preflight followed by a synchronous authority/configuration guard at the worker commit. */
  async prepareConversation(scope: ConversationExecutionScope): Promise<Guard> {
    this.assertResponses(); const attestation = await this.attest(); this.match(scope.binding, attestation);
    const guard = this.responseGuard(attestation, [scope.response.requestedBy, scope.response.source.author.profileId]); guard();
    const posts = await this.scan(scope.binding, attestation);
    if (scope.response.source.kind === 'event' && !posts.some(item => item.post.id === scope.response.source.postId
      && item.post.message === scope.response.source.text && item.post.deleteAt === 0
      && Math.max(item.post.createAt, item.post.updateAt, item.post.deleteAt) === scope.response.source.revision))
      throw new MissionError('CONVERSATION_CONFLICT', 'The original source message changed or is no longer available');
    await this.options.store.conversationIngest(scope.binding.id, attestation.route, posts, guard);
    guard(); return guard;
  }
  async bind(value: unknown, guard: HumanGuard): Promise<ConversationBinding> {
    const parsed = input(parseConversationBind, value); const actor = this.human(guard, true); const attestation = await this.attest();
    const root = await this.root(parsed.rootPostId, attestation);
    const current = () => { attestation.guard(); this.human(guard, true); };
    const binding = await this.options.store.conversationBind(parsed, attestation.route, root, actor, current); current(); return binding;
  }
  async comment(value: unknown, guard: HumanGuard): Promise<ConversationDelivery> {
    const parsed = input(parseConversationComment, value); const actor = this.human(guard); const snapshot = this.snapshot();
    const current = () => { snapshot.guard(); this.human(guard); };
    const bindings = await this.options.store.conversationBindings(current);
    const binding = bindings.find(item => item.id === parsed.bindingId && item.missionId === parsed.missionId);
    if (!binding || routeKey(binding) !== this.initialRoute) throw new MissionError('CONVERSATION_ROUTE_REVOKED', 'Conversation route is unavailable');
    const delivery = await this.options.store.conversationComment(parsed, actor, current); current(); return delivery;
  }
  private async scan(binding: ConversationBinding, attestation: Attestation): Promise<{ post: ConversationPost; author: ConversationAuthor }[]> {
    this.match(binding, attestation); await this.root(binding.rootPostId, attestation);
    const found = new Map<string, ConversationPost>(); let cursor: ConversationPost | undefined;
    for (let page = 0; ; page++) {
      const suffix = cursor ? `&fromPost=${cursor.id}&fromCreateAt=${cursor.createAt}` : '';
      const list = record(await this.request(attestation, `/posts/${binding.rootPostId}/thread?perPage=${PAGE_SIZE}&direction=down${suffix}`));
      if (!Array.isArray(list.order) || list.order.length > PAGE_SIZE + 1 || typeof list.has_next !== 'boolean'
        || (list.first_inaccessible_post_time !== undefined && list.first_inaccessible_post_time !== 0)) throw invalid();
      const values = record(list.posts); const order = list.order;
      if (Object.keys(values).length > PAGE_SIZE + 1 || new Set(order).size !== order.length || Object.keys(values).some(id => !order.includes(id))) throw invalid();
      const pagePosts = order.map(id => { const p = post(values[sourceId(id)]); if (p.id !== id) throw invalid(); return p; });
      let next = cursor;
      for (const p of pagePosts) {
        if (p.channelId !== binding.channelId || (p.id === binding.rootPostId ? p.rootId !== '' || p.userId !== binding.botUserId || p.deleteAt !== 0 : p.rootId !== binding.rootPostId)) throw invalid();
        if (p.id === binding.rootPostId) continue;
        if (cursor && (p.createAt < cursor.createAt || p.createAt === cursor.createAt && p.id <= cursor.id)) throw invalid();
        if (found.has(p.id)) throw invalid(); found.set(p.id, p);
        if (!next || p.createAt > next.createAt || p.createAt === next.createAt && p.id > next.id) next = p;
      }
      if (found.size > MAX_POSTS || page > MAX_POSTS / PAGE_SIZE) throw new MissionError('CONVERSATION_HISTORY_LIMIT', 'Conversation exceeds the bounded history scan');
      if (!list.has_next) break;
      if (next === cursor) throw invalid(); cursor = next;
    }
    const result: { post: ConversationPost; author: ConversationAuthor }[] = [];
    for (const p of found.values()) {
      const author = attestation.authors.get(p.userId);
      // Posts outside current attested membership cannot introduce source material; own bot receipts reach reconciliation.
      if (author) result.push({ post: p, author });
    }
    return result;
  }
  private async send(binding: ConversationBinding): Promise<void> {
    const attestation = await this.attest(); this.match(binding, attestation); await this.root(binding.rootPostId, attestation);
    const allowedAuthors = [...attestation.authors.values()].flatMap(author => author.profileId ? [author.profileId] : []);
    const delivery = await this.options.store.conversationNext(binding.id, allowedAuthors, attestation.guard);
    if (!delivery) return;
    const attemptId = delivery.attemptId!;
    // Once sending is persisted, retain its outcome even if permissions are revoked during the request.
    const receiptGuard = () => { if (routeKey(binding) !== this.initialRoute) throw invalid(); };
    try {
      attestation.guard();
      if (delivery.author.kind !== 'agent' && (!delivery.author.profileId || ![...attestation.authors.values()].some(author => author.profileId === delivery.author.profileId))) {
        await this.options.store.conversationObserve(delivery.id, attemptId, { state: 'failed', reason: 'author-revoked-before-send' }, receiptGuard); return;
      }
    } catch {
      await this.options.store.conversationObserve(delivery.id, attemptId, { state: 'failed', reason: 'authority-revoked-before-send' }, receiptGuard); return;
    }
    try {
      const sent = post(await this.request(attestation, '/posts', { channel_id: binding.channelId, root_id: binding.rootPostId,
        message: delivery.message, pending_post_id: delivery.id.slice(0, 26), props: { studio_delivery_id: delivery.id } }));
      if (sent.channelId !== binding.channelId || sent.rootId !== binding.rootPostId || sent.userId !== binding.botUserId
        || sent.deliveryId !== delivery.id || sent.message !== delivery.message || sent.deleteAt !== 0) throw invalid();
      await this.options.store.conversationObserve(delivery.id, attemptId, { state: 'delivered', post: sent }, receiptGuard);
    } catch {
      await this.options.store.conversationObserve(delivery.id, attemptId, { state: 'uncertain', reason: 'delivery-outcome-unknown' }, receiptGuard);
    }
  }
  pollOnce(): Promise<void> {
    if (this.polling) return this.polling;
    this.polling = this.poll().finally(() => { this.polling = undefined; }); return this.polling;
  }
  private async poll(): Promise<void> {
    if (!this.available()) return;
    const bindings = await this.options.store.conversationBindings(() => { this.snapshot().guard(); });
    for (const binding of bindings) {
      if (this.stopped) break;
      try {
        const attestation = await this.attest(); this.match(binding, attestation);
        const observations = await this.scan(binding, attestation);
        await this.options.store.conversationIngest(binding.id, attestation.route, observations, attestation.guard);
        await this.options.store.conversationSync(binding.id, undefined, attestation.guard);
        await this.send(binding);
      } catch (error) {
        // Recording loss of access never authorizes another read, post or runtime turn.
        await this.options.store.conversationSync(binding.id, syncError(error), () => {}).catch(() => {});
      }
    }
  }
  start(): void {
    if (this.started || this.stopped || !this.optedIn) return; this.started = true;
    const tick = async () => {
      await this.pollOnce().catch(() => {});
      if (!this.stopped) { this.timer = setTimeout(tick, this.options.config.mattermost?.pollIntervalMs ?? 10000); this.timer.unref(); }
    };
    this.timer = setTimeout(tick, 0); this.timer.unref();
  }
  async stop(): Promise<void> {
    this.stopped = true; clearTimeout(this.timer); this.controller.abort(); await this.polling?.catch(() => {});
  }
}
