import type { IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';
import { randomUUID } from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { WebSocketServer, WebSocket } from 'ws';
import { whiteboardClientMessage, whiteboardId, type WhiteboardPresenceState, type WhiteboardParticipant, type WhiteboardEventPage } from '@studio/contracts';
import { MissionError, type CollaborativeWhiteboardService, type WhiteboardGuard, type WhiteboardSharedViews } from '@studio/server';

type Admission = { guard: WhiteboardGuard; name():string; csrf(value: string): void };
export const isWhiteboardStream = (url:string) => /^\/api\/projects\/[^/]+\/studio\/whiteboard\/v2\/stream(?:\?|$)/.test(url);
class Bucket {
  private tokens: number; private at = Date.now();
  constructor(private rate: number, private burst: number) { this.tokens=burst; }
  take() { const now=Date.now(); this.tokens=Math.min(this.burst,this.tokens+(now-this.at)*this.rate/1000); this.at=now;
    if (this.tokens < 1) return false; this.tokens--; return true; }
}
type Peer = { socket: WebSocket; guard: WhiteboardGuard; project: string; hello: boolean; busy: boolean;
  version?:2|3|4;id:string;name():string;watching?:boolean;presence?:WhiteboardPresenceState;seen?:number;
  cursor?: number; blockId?: string; epoch?: string; clientKey?: string; leaseKey?: string;
  budget: Bucket; helloTimer: ReturnType<typeof setTimeout> };

/** Durable events require commit; bounded presence is separately attributed and ephemeral. */
export function registerWhiteboardSocket(app: FastifyInstance, service: CollaborativeWhiteboardService, origin: string,
  admit: (request: IncomingMessage, project: string) => Admission | Promise<Admission>, shared?:WhiteboardSharedViews): void {
  const server=new WebSocketServer({ noServer: true, maxPayload: 65536, perMessageDeflate: false });
  const peers=new Set<Peer>(); const leases=new Set<string>(); const budgets=new Map<string,Bucket>();
  let stopping=false; let polling=false;
  let presenceDirty=false;
  const close=(peer: Peer, reason='Reconnect to check saved text') => peer.socket.close(1008,reason);
  const unavailable=(peer:Peer,failure:unknown)=>close(peer,failure instanceof MissionError && failure.code==='COLLABORATION_DISABLED'?'Collaboration paused':'Access changed');
  function send(peer: Peer,value: unknown): void {
    peer.guard(); const text=JSON.stringify(value);
    if (peer.socket.readyState !== WebSocket.OPEN || peer.socket.bufferedAmount+Buffer.byteLength(text)>262144) { close(peer,'Read a fresh snapshot'); return; }
    peer.socket.send(text);
  }
  function error(peer: Peer,failure: unknown): void {
    const code=failure instanceof MissionError ? failure.code : 'INVALID_INPUT';
    try { send(peer,{ type:'error',code }); } catch (failure) { unavailable(peer,failure); }
  }
  function forVersion(participant:WhiteboardParticipant,version:Peer['version']):WhiteboardParticipant {
    if(version===4)return participant;
    const {shareView:_share,viewSize:_size,selectedIds:_ids,...spatial}=participant.state;
    if(version===3)return {...participant,state:spatial};
    const {sectionId:_section,...legacy}=spatial;
    return {...participant,state:legacy};
  }
  function publishPresence() {
    const colors:WhiteboardParticipant['color'][]=['#2459a6','#9a3d82','#26745d','#a45a22','#6653a6'];
    const valid=new Map<string,WhiteboardParticipant[]>();
    for (const peer of peers) {
      if (!peer.watching || !peer.presence || Date.now()-(peer.seen ?? 0)>30000) continue;
      try {
        const { actor }=peer.guard(); const list=valid.get(peer.project) ?? [];
        list.push({ connectionId:peer.id,profileId:actor.id,name:peer.name().slice(0,100) || actor.id,
          color:colors[[...actor.id].reduce((sum,c)=>sum+c.charCodeAt(0),0)%colors.length]!,state:peer.presence }); valid.set(peer.project,list);
      } catch (failure) { unavailable(peer,failure); }
    }
    for (const peer of peers) if (peer.watching) {
      try { send(peer,{ type:'presence',self:peer.id,participants:(valid.get(peer.project) ?? []).filter(p=>(peer.version??2)>=3 || (p.state.sectionId??'root')==='root').map(p=>forVersion(p,peer.version)) }); } catch (failure) { unavailable(peer,failure); }
    }
    presenceDirty=false;
  }
  const upgrade=async (request: IncomingMessage,socket: Duplex,head: Buffer) => {
    if (!isWhiteboardStream(request.url ?? '')) return;
    try {
      const path=new URL(request.url!,origin);
      const match=path.pathname.match(/^\/api\/projects\/([^/]+)\/studio\/whiteboard\/v2\/stream$/);
      if (!match) throw Error('Path');
      if (stopping || path.search || request.headers.host !== new URL(origin).host || request.headers.origin !== origin) throw Error('Origin');
      const project=whiteboardId.parse(decodeURIComponent(match[1]!));
      const admission=await admit(request,project); admission.guard();
      if (stopping || socket.destroyed) throw Error('Connection ended');
      if (peers.size>=32 || [...peers].filter(p=>p.project===project).length>=10) throw Error('Capacity');
      server.handleUpgrade(request,socket,head,ws=> {
        const peer: Peer={ socket:ws,project,id:randomUUID(),name:admission.name,hello:false,busy:false,budget:new Bucket(10,20),
          guard:()=> { if (stopping || ws.readyState!==WebSocket.OPEN) throw new MissionError('AUTHORITY_REVOKED','Connection ended'); return admission.guard(); },
          helloTimer:setTimeout(()=>ws.close(1008,'Protocol hello required'),5000) };
        peers.add(peer); shared?.register(peer.id,{guard:peer.guard,name:peer.name,current:()=>({state:peer.presence,seen:peer.seen})}); if (!budgets.has(project)) budgets.set(project,new Bucket(30,60));
        ws.on('error',()=>ws.terminate());
        ws.on('close',()=> { clearTimeout(peer.helloTimer); peers.delete(peer); shared?.remove(peer.id); if (peer.leaseKey) leases.delete(peer.leaseKey);
          if (![...peers].some(p=>p.project===project)) budgets.delete(project); presenceDirty=true; });
        ws.on('message',(bytes,binary)=> { void (async()=> {
          try {
            peer.guard();
            if (binary) throw Error('Frame');
            if (!peer.budget.take() || !budgets.get(project)!.take()) { close(peer,'Editing rate limit reached'); return; }
            const message=whiteboardClientMessage.parse(JSON.parse(bytes.toString()));
            if (message.type==='hello') {
              if (peer.hello) throw Error('Repeated hello'); admission.csrf(message.csrf); peer.hello=true; peer.version=message.version; clearTimeout(peer.helloTimer);
              send(peer,{ type:'hello',version:peer.version }); return;
            }
            if (!peer.hello) { close(peer,'Protocol hello required'); return; }
            if (peer.busy) throw new MissionError('BUSY','Wait for the previous request');
            peer.busy=true;
            try {
              if (message.type==='watch') {
                if (peer.cursor!==undefined) throw Error('Already subscribed');
                await service.events({ after:message.after,limit:1 },peer.guard);
                peer.cursor=message.after; peer.watching=true; peer.seen=Date.now();
                // V3 location is unknown until the client publishes its actual section.
                peer.presence=peer.version!==2?undefined:{ pointer:null,viewport:null,selection:null,drag:null };
                send(peer,{ type:'watching',connectionId:peer.id }); presenceDirty=true;
              } else if (message.type==='presence') {
                if (!peer.watching || Buffer.byteLength(JSON.stringify(message))>2048) throw Error('Presence subscription required');
                if(peer.version!==4&&(message.state.shareView!==undefined||message.state.viewSize!==undefined||message.state.selectedIds!==undefined))throw Error('View sharing requires protocol 4');
                if(message.state.shareView)shared?.assertTarget(project,message.state.shareView);
                // Pointer/viewport motion does not repeatedly decode an unchanged selection.
                if (JSON.stringify(message.state.selectedIds)!==JSON.stringify(peer.presence?.selectedIds) || message.state.sectionId!==peer.presence?.sectionId || JSON.stringify(message.state.selection)!==JSON.stringify(peer.presence?.selection) || message.state.drag?.blockId!==peer.presence?.drag?.blockId)
                  await service.presence(message.state,peer.guard);
                peer.presence=message.state; peer.seen=Date.now(); presenceDirty=true;
              } else if (message.type==='subscribe') {
                if (peer.cursor!==undefined) throw Error('Already subscribed');
                const leaseKey=JSON.stringify([project,message.blockId,peer.guard().actor,message.clientKey]);
                if (leases.has(leaseKey)) throw new MissionError('EDITOR_IN_USE','This editor is already connected');
                leases.add(leaseKey); peer.leaseKey=leaseKey;
                try {
                  const lease=await service.join({ blockId:message.blockId,epoch:message.epoch,clientKey:message.clientKey },peer.guard);
                  await service.events({ after:message.after,limit:1 },peer.guard);
                  peer.blockId=message.blockId; peer.epoch=message.epoch; peer.clientKey=message.clientKey; peer.cursor=message.after;
                  send(peer,{ type:'subscribed',clientId:lease.clientId });
                } catch (failure) { leases.delete(leaseKey); peer.leaseKey=undefined; throw failure; }
              } else {
                if (message.command.blockId!==peer.blockId || message.command.epoch!==peer.epoch || message.command.clientKey!==peer.clientKey) throw Error('Subscription mismatch');
                send(peer,{ type:'receipt',receipt:await service.submit(message.command,peer.guard) });
              }
            } finally { peer.busy=false; }
          } catch (failure) { error(peer,failure); }
        })(); });
      });
    } catch { socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); }
  };
  app.server.on('upgrade',upgrade);
  const timer=setInterval(()=> { void (async()=> {
    if (polling || stopping) return; polling=true;
    try {
      // Committed event pages are project-scoped, not actor-specific. Reuse only
      // an identical cursor within this pass; every send still checks its peer.
      // Nothing survives into the next poll or bypasses the authority read.
      const pages=new Map<string,WhiteboardEventPage>();
      for (const peer of peers) {
        try {
          const principal=peer.guard(); // Includes idle session/membership revalidation within 5s.
          if (peer.presence && Date.now()-(peer.seen ?? 0)>30000) { peer.presence=undefined; presenceDirty=true; }
          if (!peer.hello || peer.cursor===undefined) continue;
          const key=JSON.stringify([principal.projectId,peer.cursor]);
          const share=principal.actor.kind==='human' && !principal.nativeCustody && !principal.nativeCommand;
          let page=share?pages.get(key):undefined;
          if (!page) {
            page=await service.events({ after:peer.cursor,limit:10 },peer.guard);
            if (share) pages.set(key,page);
          }
          for (const event of page.events) {
            if (peer.presence && !event.text && event.receipt.changedIds.some(id=>id===peer.presence?.selection?.blockId || id===peer.presence?.drag?.blockId || peer.presence?.selectedIds?.includes(id))) {
              try { await service.presence(peer.presence,peer.guard); }
              catch { peer.presence={ ...peer.presence,selection:null,drag:null,selectedIds:[] }; presenceDirty=true; }
            }
            send(peer,{ type:'event',event }); peer.cursor=event.receipt.revision;
          }
        } catch (failure) { if (failure instanceof MissionError && failure.code==='BUSY') continue; error(peer,failure); close(peer); }
      }
      if (presenceDirty) publishPresence();
    } finally { polling=false; }
  })(); },100);
  timer.unref();
  app.addHook('preClose',async()=> { stopping=true; clearInterval(timer); app.server.off('upgrade',upgrade);
    for (const peer of peers) { clearTimeout(peer.helloTimer); peer.socket.terminate(); }
    server.close(); await service.close(); });
}
