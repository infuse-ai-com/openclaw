import {readFile} from 'node:fs/promises';
import {parseArtifactLifecycleReceipt,parseArtifactLifecycleState,type ArtifactLifecycleCommand} from '@studio/contracts';
import {artifactRegistryEndpoint,ArtifactRegistryReadError} from './read-client.js';
export class ArtifactLifecycleError extends Error {constructor(readonly code:string,readonly status:number){super(code==='ARTIFACT_COMMAND_CONFLICT'?'The exact artifact state changed or another command requires reconciliation. Refresh before starting another action.':code==='ARTIFACT_COMMAND_REJECTED'?'The Registry rejected this exact action. Refresh its state and access.':'The Registry outcome could not be confirmed. Recover the same command after checking the connection.');}}
export class StudioArtifactLifecycleClient {
 constructor(private readonly registryUrl:string,private readonly tokenFile:string,private readonly project:string){}
 private async request(producer:string,artifactId:string,suffix:string,guard:()=>unknown,command?:ArtifactLifecycleCommand,actorId?:string):Promise<unknown>{
  if(![producer,artifactId,this.project].every(s=>/^[a-z0-9][a-z0-9._-]{0,127}$/.test(s)))throw new ArtifactRegistryReadError('not_found');
  const url=new URL(`/v1/artifacts/${encodeURIComponent(producer)}/${encodeURIComponent(artifactId)}/lifecycle${suffix}`,artifactRegistryEndpoint(this.registryUrl));
  if(!command)url.searchParams.set('project',this.project);
  let token:string;
  try{const raw=await readFile(this.tokenFile,'utf8');token=raw.endsWith('\n')?raw.slice(0,-1):raw;if(token.length<32||token.length>512||/[\u0000-\u0020\u007f]/.test(token))throw Error();}catch{throw new ArtifactLifecycleError('ARTIFACT_LIFECYCLE_UNAVAILABLE',503);}
  guard();
  try{
   const response=await fetch(url,{method:command?'POST':'GET',headers:{authorization:'Bearer '+token,accept:'application/json',...(command?{'content-type':'application/json'}:{})},...(command?{body:JSON.stringify({commandId:command.commandId,producer,artifactId,project:this.project,revision:command.revision,generation:command.generation,action:command.action,actorId})}:{}),redirect:'manual',signal:AbortSignal.timeout(12000)});
   if(!response.ok){await response.body?.cancel();throw new ArtifactLifecycleError(response.status===409?'ARTIFACT_COMMAND_CONFLICT':[400,401,403,404].includes(response.status)?'ARTIFACT_COMMAND_REJECTED':command?'ARTIFACT_COMMAND_UNCERTAIN':'ARTIFACT_LIFECYCLE_UNAVAILABLE',response.status===409?409:[400,401,403,404].includes(response.status)?409:503);}
   if(response.headers.get('content-type')?.split(';')[0]!=='application/json')throw Error();
   const chunks:Uint8Array[]=[];let size=0;for await(const chunk of response.body as unknown as AsyncIterable<Uint8Array>){size+=chunk.length;if(size>65536)throw Error();chunks.push(chunk);}const raw=JSON.parse(Buffer.concat(chunks).toString('utf8'));
   if(command){const r=parseArtifactLifecycleReceipt(raw);if(r.commandId!==command.commandId||r.actorId!==actorId||r.project!==this.project||r.producer!==producer||r.artifactId!==artifactId||r.revision!==command.revision||r.generation!==command.generation+1||r.action!==command.action)throw Error();return r;}
   if(suffix.startsWith('/audit')){const value=raw as {receipts:unknown[];nextCursor:string|null};if(!value||Object.keys(value).sort().join(',')!=='nextCursor,receipts'||!Array.isArray(value.receipts)||value.receipts.length>50||value.nextCursor!==null&&(typeof value.nextCursor!=='string'||!/^[a-f0-9]{64}$/.test(value.nextCursor)))throw Error();const receipts=value.receipts.map(parseArtifactLifecycleReceipt);if(receipts.some(r=>r.project!==this.project||r.producer!==producer||r.artifactId!==artifactId))throw Error();return {receipts,nextCursor:value.nextCursor};}
   const state=parseArtifactLifecycleState(raw);if(state.project!==this.project||state.producer!==producer||state.artifactId!==artifactId)throw Error();return state;
  }catch(error){if(error instanceof ArtifactLifecycleError)throw error;throw new ArtifactLifecycleError(command?'ARTIFACT_COMMAND_UNCERTAIN':'ARTIFACT_LIFECYCLE_UNAVAILABLE',503);}
 }
 state(producer:string,id:string,guard:()=>unknown){return this.request(producer,id,'',guard);}
 audit(producer:string,id:string,before:string|undefined,guard:()=>unknown){if(before!==undefined&&!/^[a-f0-9]{64}$/.test(before))throw new ArtifactLifecycleError('ARTIFACT_COMMAND_REJECTED',400);return this.request(producer,id,'/audit'+(before?'?before='+before:''),guard);}
 apply(command:ArtifactLifecycleCommand,actorId:string,guard:()=>unknown){return this.request(command.producer,command.artifactId,'',guard,command,actorId);}
}
