import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { StudioArtifacts, type StudioArtifactsConfig } from './service.js';
import { ArtifactRegistryReadError } from './read-client.js';
import { ARTIFACT_RASTER_MEDIA_TYPES } from '@studio/contracts';
import { ARTIFACT_CONTENT_SECURITY_POLICY } from './preview-security.js';

type Params = { producer: string; artifactId: string; revision: string };
type Guard = (request: FastifyRequest, reply: FastifyReply) => { guard(): unknown };
export function registerArtifactsHttp(app: FastifyInstance, config: StudioArtifactsConfig | undefined, projectId: string | ((request: FastifyRequest) => string), access: Guard, prefix = '/api/studio/artifacts') {
  const services = new Map<string, StudioArtifacts>();
  const query = (value: unknown, allowed: string[]) => {
    if (!value || typeof value !== 'object' || Array.isArray(value) || Object.entries(value).some(([k, v]) => !allowed.includes(k) || typeof v !== 'string')) throw new ArtifactRegistryReadError('not_found');
    return value as Record<string, string>;
  };
  async function read<T>(request: FastifyRequest, reply: FastifyReply, operation: (service: StudioArtifacts) => Promise<T>) {
    const principal = access(request, reply);
    const id = typeof projectId === 'string' ? projectId : projectId(request);
    if (config && !services.has(id)) services.set(id, new StudioArtifacts(config, id));
    const service = services.get(id);
    if (!service) return reply.code(503).send({ error: { code: 'ARTIFACTS_NOT_CONFIGURED', message: 'The artifact library is not connected yet.' } });
    try { const result = await operation(service); principal.guard(); return result; }
    catch (error) {
      if (!(error instanceof ArtifactRegistryReadError)) throw error;
      const missing = error.code === 'not_found';
      return reply.code(missing ? 404 : 503).send({ error: { code: missing ? 'ARTIFACT_NOT_FOUND' : 'ARTIFACT_REGISTRY_UNAVAILABLE',
        message: missing ? 'This artifact revision is not available in this project.' : 'The artifact library could not verify this response. Retry or ask an operator to check its connection.' } });
    }
  }
  app.get(`${prefix}/skill-catalog`, (request, reply) => read(request, reply, async s => {
    const q = query(request.query, ['presentation']);
    if (q.presentation !== undefined && q.presentation !== 'outcomes') throw new ArtifactRegistryReadError('not_found');
    const result = await s.skillCatalog();
    if (q.presentation === 'outcomes') return result;
    // Existing loaded clients use a strict catalog schema without outcome metadata.
    return { ...result, catalog: { ...result.catalog, entries: result.catalog.entries.map(({ output, ...entry }) => entry) } };
  }));
  app.get<{ Params: { skillId: string } }>(`${prefix}/skill-guides/:skillId`, (request, reply) => read(request, reply, s => {
    const q = query(request.query, ['catalogRevision']);
    if (!q.catalogRevision || !/^[a-f0-9]{64}$/.test(q.catalogRevision)) throw new ArtifactRegistryReadError('not_found');
    return s.skillGuide(request.params.skillId, q.catalogRevision);
  }));
  app.get(prefix, (request, reply) => read(request, reply, s => {const q=query(request.query,['cursor','q','scope','mission']);return s.list(q.cursor,'active',q);}));
  app.get<{ Params: Params }>(`${prefix}/:producer/:artifactId/:revision`, (request, reply) => read(request, reply, s => {
    query(request.query, []); const p = request.params; return s.detail(p.producer, p.artifactId, p.revision);
  }));
  for (const mode of ['preview', 'image', 'download'] as const) app.get<{ Params: Params }>(`${prefix}/:producer/:artifactId/:revision/${mode}`, async (request, reply) => {
    const result = await read(request, reply, async s => {
      const { path } = query(request.query, ['path']);
      if (!path || mode === 'preview' && request.headers['sec-fetch-dest'] !== 'iframe'
        || mode === 'image' && request.headers['sec-fetch-dest'] !== 'image') throw new ArtifactRegistryReadError('not_found');
      const p = request.params;
      return s.file(p.producer, p.artifactId, p.revision, path, mode === 'preview' ? ['text/html'] : mode === 'image' ? ARTIFACT_RASTER_MEDIA_TYPES : undefined);
    });
    if (!('file' in result)) return result;
    reply.header('Cache-Control', 'no-store').header('Referrer-Policy', 'no-referrer').header('X-Content-Type-Options', 'nosniff');
    if (mode === 'preview') {
      reply.header('X-Frame-Options', 'SAMEORIGIN').header('Content-Security-Policy', ARTIFACT_CONTENT_SECURITY_POLICY);
      return reply.type('text/html; charset=utf-8').send(result.body);
    }
    reply.header('Content-Security-Policy', "default-src 'none'; sandbox; frame-ancestors 'none'");
    if (mode === 'image') return reply.header('Cross-Origin-Resource-Policy', 'same-origin').type(result.file.mediaType).send(result.body);
    const filename = result.file.path.split('/').at(-1)!;
    const encoded = encodeURIComponent(filename).replace(/[!'()*]/g, char => `%${char.charCodeAt(0).toString(16).toUpperCase()}`);
    return reply.header('Content-Disposition', `attachment; filename="artifact"; filename*=UTF-8''${encoded}`).type('application/octet-stream').send(result.body);
  });
}
