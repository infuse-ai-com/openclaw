import { createHash } from 'node:crypto';
import { nativeToolTextWeight } from '@studio/contracts';
import { requireMission } from '@studio/server';
import type { StandaloneConfig } from './config.js';

/** Public planning context only. Dispatch still checks enrollment and membership. */
export function nativeProjectRouting(config: StandaloneConfig, query: unknown = {}) {
  requireMission(!!query && typeof query === 'object' && !Array.isArray(query), 'INVALID_INPUT', 'Invalid routing page');
  const q = query as Record<string, unknown>;
  requireMission(Object.keys(q).every(k => ['offset', 'configurationDigest'].includes(k)), 'INVALID_INPUT', 'Unknown routing field');
  const offset = q.offset ?? 0;
  requireMission(typeof offset === 'number' && Number.isSafeInteger(offset) && offset >= 0, 'INVALID_INPUT', 'Invalid routing offset');
  const routes = config.nativeMissions!.routes.map(({ role, gatewayId, agentId, nativeUsername, channelId }) => ({
    role, gatewayId, agentId, nativeUsername, channelId,
    enrolled: config.bridge?.enabled === true && config.bridge.gateways.some(g => g.enabled && g.gatewayId === gatewayId && g.agents.includes(agentId)),
  })).sort((a, b) => a.role < b.role ? -1 : a.role > b.role ? 1 : 0);
  const identity = { authorityId: config.authorityId, projectId: config.project.id };
  const configurationDigest = createHash('sha256').update(JSON.stringify({ ...identity, routes })).digest('hex');
  requireMission((offset === 0 && q.configurationDigest === undefined) || q.configurationDigest === configurationDigest,
    'CONFIGURATION', 'Project routing changed or page digest is missing; read current context again');
  requireMission(offset < routes.length, 'INVALID_INPUT', 'Routing offset is outside this project');
  const page = { version: 1, ...identity, configurationDigest, offset, total: routes.length, routes: [] as typeof routes,
    nextOffset: undefined as number | undefined,
    note: 'Use exact role, gatewayId and agentId tuples when shaping tasks. These are configured routes, not grants or proof of current channel membership. Dispatch rechecks authority. For more routes, request routing with nextOffset as offset and this configurationDigest.' };
  for (let index = offset; index < routes.length; index++) {
    const next = [...page.routes, routes[index]!];
    // Leave room beside the bounded 12k mission envelope on existing hosts.
    if (nativeToolTextWeight(JSON.stringify({ ...page, routes: next, nextOffset: index + 1 })) > 2800) break;
    page.routes = next;
  }
  requireMission(page.routes.length > 0, 'CONTEXT_LIMIT', 'Project routing exceeds the supported context budget');
  if (offset + page.routes.length < routes.length) page.nextOffset = offset + page.routes.length;
  return page;
}
