import { WhiteboardSharedViews } from '@studio/server';
import { FloorSetupService } from '@studio/server';
import {registerArtifactLifecycleHttp} from './artifacts/lifecycle-http.js';
import {registerMonitoringHttp} from './monitoring-http.js';
import { gitGuid, gitText, gitTime, missionIdentifier, parseContributionCursor, parseGitRepositoryIdentity, type ContributionsView } from '@studio/contracts';
import { registerMachineHttp } from './machine.js';
import { registerWhiteboardMcp } from './whiteboard-mcp.js';
import { companionAccess } from './whiteboard-companion-access.js';
import { createWhiteboardAgentBridge, whiteboardShareTargets } from './whiteboard-agent-bridge.js';
import { registerSpatialWhiteboard } from './whiteboard-spatial.js';
import type { FloorRuntimeController } from './floor-runtime.js';
import { FloorDirectory, floorAgentAdapter, canManageFloors } from './floors.js';
import { registerComputerPreview, type WorkbenchPreviewOptions } from './computers.js';
import { readFloorCode, registryFloorSelection, registryValidationGuard, RepositoryRegistryService, RegistryProviderClient, KnowledgeClient, KnowledgeManagementClient, FloorManagementService, KnowledgeError, knowledgeOperation } from '@studio/server';
import { registerMockupHttp } from './mockup-http.js';
import { registerArtifactsHttp } from './artifacts/http.js';
import { registerWhiteboardSocket, isWhiteboardStream } from '../realtime/whiteboard.js';
import { timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import { extname, isAbsolute } from 'node:path';
import Fastify, { type FastifyReply, type FastifyRequest } from 'fastify';
import cookie from '@fastify/cookie';
import staticFiles from '@fastify/static';
import { MissionError, type StudioAuthority, type StudioHumanActor, type StudioBridgeAuthority } from '@studio/server';
import { LOGIN_SECONDS, SESSION_SECONDS, type LoginTransaction, type BrowserAuthStore } from './auth-store.js';
import { isCurrentStudioMember, configuredProjects, projectConfig, type StandaloneConfig, type StudioMember } from './config.js';
import { createOidc } from './oidc.js';
import { bridgeRuntime, registerBridgeHttp, validateBridgeCredentials, type BridgeConfigReader } from './bridge-http.js';
import type { ConversationService } from './mattermost.js';
import type { NativeBridgeService } from './native-bridge.js';
import type { NativeProjectsBridge } from './native-projects.js';

import { HttpError } from './http-error.js';
import { registerAppsHttp } from './apps-http.js';
import { registerDashboardCustodyHttp, type DashboardCustodyService } from './dashboard-custody-http.js';
const whiteboardErrors: Record<string,number> = { ARTIFACTS_UNAVAILABLE:503, UPGRADE_REQUIRED:409, CONVERSION_REQUIRED:409, COLLABORATION_DISABLED:409,
  EPOCH_CHANGED:409, CURSOR_EXPIRED:409, HEAD_CHANGED:409, HISTORY_LIMIT:409, PATCH_CONFLICT:409,
  PREPARE_TIMEOUT:503, BUSY:503, WORKER_FAILED:503, WORKER_START_TIMEOUT:503,
  INVALID_ENCODING:400, TEXT_ONLY:400, INVALID_CLOCK:400, INVALID_PARENT:400, INCOMPLETE_UPDATE:400, CLOCK_REUSED:400, BODY_LIMIT:400, UPDATE_LIMIT:400 };
function equal(a: unknown, b: string): boolean {
  return typeof a === 'string' && Buffer.byteLength(a) === Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a), Buffer.from(b));
}
function query(value: unknown, names: string[]): Record<string, string> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new HttpError('INVALID_INPUT', 400, 'Invalid query');
  const result: Record<string, string> = {};
  for (const [key, item] of Object.entries(value)) {
    if (!names.includes(key) || typeof item !== 'string') throw new HttpError('INVALID_INPUT', 400, 'Invalid query');
    result[key] = item;
  }
  return result;
}
const statuses: Record<string, number> = { AGENT_OCCUPIED:409, AGENT_OFFLINE:503, CAPACITY:409, COLLABORATION_DISABLED:409, INSTRUCTION_CONFLICT: 409, UNSUPPORTED_CAPABILITY: 409, FINDING_CONFLICT: 409, FORBIDDEN: 403, AUTHORITY_REVOKED: 403, NOT_FOUND: 404, INVALID_INPUT: 400, CONFIGURATION: 400,
  VERSION_CONFLICT: 409, IDEMPOTENCY_CONFLICT: 409, STATE_CONFLICT: 409, EVIDENCE_CONFLICT: 409, TERMINAL: 409,
  ALREADY_EXISTS: 409, STALE_ASSIGNMENT: 409, DISPATCH_DISABLED: 409, EXECUTION_DISABLED: 409,
  BRIDGE_UNAUTHENTICATED: 401, BRIDGE_TRANSPORT_REQUIRED: 403, BRIDGE_DISABLED: 503, BRIDGE_UNAVAILABLE: 503,
  BRIDGE_CONFLICT: 409, CLAIM_CONFLICT: 409, ADMISSION_CONFLICT: 409, DISPATCH_CONFLICT: 409,
  CLOSEOUT_PENDING: 409, CLOSEOUT_REQUIRED: 409, VERIFICATION_REQUIRED: 409, READ_REQUIRED: 409, UNSETTLED_ASSIGNMENT: 409, PROJECT_BUSY: 409,
  ARTIFACT_UNAVAILABLE: 409, ARTIFACT_INTEGRITY: 409, UNAVAILABLE: 503,
  CONVERSATION_CONFLICT: 409, CONVERSATION_SOURCE_CHANGED: 409, CONVERSATION_LIMIT: 409, CONVERSATION_DISABLED: 503, CONVERSATION_ROUTE_REVOKED: 409,
  CONVERSATION_SOURCE_INVALID: 502, CONVERSATION_OFFLINE: 503, CONVERSATION_HISTORY_LIMIT: 409 };

export interface StandaloneServerOptions {
  authStore: BrowserAuthStore;
  readContributions?: () => StandaloneConfig['contributions'];
  floors?: FloorDirectory; floorRuntime?: FloorRuntimeController;
  workbenchPreview?: WorkbenchPreviewOptions;
  config: StandaloneConfig; authority: StudioAuthority; webRoot?: string; mockupRoot?: string;
  /** Local administrator configuration, never an HTTP-selected identity. Must be synchronous. */
  readMembers?: () => StudioMember[];
  bridgeAuthority?: StudioBridgeAuthority; readBridge?: BridgeConfigReader;
  conversations?: ConversationService;
  native?: NativeBridgeService | NativeProjectsBridge; readConfig?: () => StandaloneConfig;
  dashboardCustody?: DashboardCustodyService;
}
export async function createStandaloneServer({ config, authority, authStore, webRoot, mockupRoot, workbenchPreview, readMembers = () => config.members, bridgeAuthority, readBridge = () => config.bridge, conversations, native, dashboardCustody, floors: suppliedFloors, floorRuntime, readConfig = () => config, readContributions = () => readConfig().contributions }: StandaloneServerOptions) {
  // Request logging stays off: callback queries and Cookie headers contain credentials.
  // Paper limits count UTF-16 characters; UTF-8 and JSON escaping can exceed 32 KiB.
  // Domain parsing still bounds every field after this transport ceiling.
  validateBridgeCredentials(config.bridge);
  await authority.floors.refresh();
  const floors = suppliedFloors ?? new FloorDirectory(authority.floors, readConfig);
  const knowledge = config.knowledge ? new KnowledgeClient(config.knowledge) : undefined;
  const registry = new RepositoryRegistryService(floors,()=>readConfig().contributions,new RegistryProviderClient(config.knowledgeManagement,config.repositoryRegistry));
  const floorManagement = new FloorManagementService(authority.floors, floors, () => readConfig().members.filter(m => isCurrentStudioMember(m)).map(m => ({ id: m.profileId, name: m.displayName ?? m.profileId })), knowledge,
    config.knowledgeManagement ? new KnowledgeManagementClient(config.knowledgeManagement) : undefined,
    async (after, guard) => {
      const configured = () => {
        const current = readConfig().contributions;
        return {enabled:current?.enabled===true,repositories:(current?.repositories??[]).map(r=>({
          ...parseGitRepositoryIdentity(r),floorIds:[...r.floorIds].sort(),
        })).sort((a,b)=>a.sourceId.localeCompare(b.sourceId))};
      };
      guard(); const before = configured();
      const retained = await authority.contributions.read({kind:'inventory',...(after===undefined?{}:{after})},guard);
      guard();
      if (JSON.stringify(before)!==JSON.stringify(configured())) throw new HttpError('BUSY',409,'Repository configuration changed; restart inventory');
      return {configured:before,retained};
    }, registry);
  const runtime = bridgeRuntime(config, readBridge);
  const app = Fastify({ logger: false, bodyLimit: 128 * 1024, trustProxy: false, requestTimeout: 15000 });
  if (!authStore) throw Error('PostgreSQL requires the same-authority authentication store');
  const auth = authStore;
  let oidc: Awaited<ReturnType<typeof createOidc>>;
  try { oidc = await createOidc(config); } catch { await auth.close(); throw Error('OIDC initialization failed; verify the configured issuer, client and secret environment reference'); }
  // Fastify runs onClose hooks in reverse order. Drain transport before main closes storage.
  app.addHook('preClose', async () => { await floorRuntime?.stop(); await conversations?.stop(); });
  app.addHook('onClose', async () => { await auth.close(); });
  app.addHook('onListen', async () => { conversations?.start(); floorRuntime?.start(); });
  await app.register(cookie);
  const origin = new URL(config.origin); const secure = origin.protocol === 'https:';
  // Cookies are host-scoped, not port-scoped. Isolate HTTP loopback previews so
  // another preview's polling, login or logout cannot erase this one's session.
  // Production HTTPS retains its established protected cookie names.
  const localPort = origin.port || '80';
  const sessionCookie = secure ? '__Host-studio-session' : `studio-session-${localPort}`;
  const loginCookie = secure ? '__Host-studio-login' : `studio-login-${localPort}`;
  const cookieOptions = { path: '/', secure, httpOnly: true, sameSite: 'lax' as const };
  const clear = (reply: FastifyReply, name: string) => reply.clearCookie(name, cookieOptions);
  function member(issuer: string, subject: string): StudioMember | undefined {
    try { return readMembers().find(m => m.issuer === issuer && m.subject === subject && isCurrentStudioMember(m)); }
    catch { throw new HttpError('AUTH_UNAVAILABLE', 503, 'Authentication configuration changed or is unavailable; an operator must reload it'); }
  }
  const appsAccess = registerAppsHttp(app, {auth,cookieName:sessionCookie,origin:config.origin,readConfig,member,hasWorkspace:id=>floors.projects().some(f=>f.memberProfileIds.includes(id))});
  function authenticate(request: Pick<FastifyRequest, 'cookies'>) {
    const token = request.cookies[sessionCookie]; const session = auth.session(token);
    if (!session) throw new HttpError('UNAUTHENTICATED', 401, 'Sign in to Studio');
    const current = member(session.issuer, session.subject);
    if (!current && appsAccess.launcherOnly(session)) throw new HttpError('MEMBERSHIP_REQUIRED', 403, 'This sign-in has My Apps access only');
    if (!current || current.profileId !== session.profileId) { void Promise.resolve(auth.revoke(token)).catch(() => {}); throw new HttpError('ROLE_REVOKED', 403, 'Studio membership was revoked; sign in again'); }
    const actor: StudioHumanActor = { kind: 'human', profileId: current.profileId, approver: current.approver };
    return { actor, session, token, displayName: current.displayName ?? current.profileId };
  }
  function access(request: FastifyRequest, reply: FastifyReply, write = false, projectId?: string) {
    const principal = authenticate(request);
    const projectGuard = () => {
      if (projectId === undefined) return;
      authority.floors.assertSettled(projectId);
      const project = floors.projects().find(p => p.id === projectId);
      if (!project?.memberProfileIds.includes(principal.actor.profileId)) throw new HttpError('PROJECT_FORBIDDEN', 403, 'This project is not available to your Studio profile');
    };
    projectGuard();
    if (write) {
      if (request.headers.origin !== config.origin) throw new HttpError('ORIGIN_FORBIDDEN', 403, 'A same-origin request is required');
      if (!equal(request.headers['x-csrf-token'], principal.session.csrfToken)) throw new HttpError('CSRF_INVALID', 403, 'Refresh Studio before submitting this action');
    }
    const guard = (): StudioHumanActor => {
      if (request.raw.aborted || reply.raw.destroyed) throw new HttpError('AUTHORITY_REVOKED', 403, 'The requesting connection ended');
      const current = authenticate(request); projectGuard();
      if (current.actor.profileId !== principal.actor.profileId || current.actor.approver !== principal.actor.approver) throw new HttpError('AUTHORITY_REVOKED', 403, 'Studio permissions changed during this request');
      return current.actor;
    };
    return { ...principal, guard };
  }
  const selectedProjectId = (request: FastifyRequest) => (request.params as { projectId?: string }).projectId ?? config.project.id;
  const projectAccess = (request: FastifyRequest, reply: FastifyReply, write = false) => access(request, reply, write, selectedProjectId(request));
  app.addHook('onRequest', async (request, reply) => {
    reply.header('X-Content-Type-Options', 'nosniff').header('Referrer-Policy', 'no-referrer').header('X-Frame-Options', 'DENY');
    reply.header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; frame-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    if (request.url.startsWith('/api/')) reply.header('Cache-Control', 'no-store');
    if (request.headers.host !== new URL(config.origin).host) throw new HttpError('ORIGIN_FORBIDDEN', 403, 'Request host does not match the configured Studio origin');
    await auth.refresh(request.cookies[sessionCookie]);
  });
  app.setErrorHandler((error, _request, reply) => {
    if (error instanceof HttpError) return reply.code(error.status).send({ error: { code: error.code, message: error.message } });
    const code = (error as { code?: string }).code;
    if (code && (statuses[code] || whiteboardErrors[code])) return reply.code((statuses[code] || whiteboardErrors[code])!).send({ error: { code, message: code === 'AUTHORITY_REVOKED' ? 'Studio authority changed before this request completed' : (error as Error).message, ...(error instanceof MissionError && error.details ? { details: error.details } : {}) } });
    if ((error as { statusCode?: number }).statusCode === 400 || code === 'FST_ERR_CTP_INVALID_JSON_BODY') return reply.code(400).send({ error: { code: 'INVALID_INPUT', message: 'Invalid request body' } });
    if (code === 'FST_ERR_CTP_BODY_TOO_LARGE') return reply.code(413).send({ error: { code: 'INVALID_INPUT', message: 'Request body is too large' } });
    if (code === 'FST_ERR_CTP_INVALID_MEDIA_TYPE') return reply.code(415).send({ error: { code: 'INVALID_INPUT', message: 'JSON content is required' } });
    return reply.code(500).send({ error: { code: 'INTERNAL_ERROR', message: 'Studio could not complete this request' } });
  });
  if (workbenchPreview) await registerComputerPreview(app, workbenchPreview, config.origin, cookies => { const p=authenticate({ cookies }); return { profileId:p.actor.profileId, expiresAt:p.session.expiresAt }; }, isWhiteboardStream, cookies => auth.refresh(cookies[sessionCookie]));
  app.get('/api/health', async () => {
    if (!authority.available()) throw new HttpError('UNAVAILABLE', 503, 'Studio storage authority is unavailable');
    return { service: 'studio', apiVersion: 1, status: 'ok', mode: 'standalone',
      capabilities: { database: true, liveMissions: true, authentication: 'oidc', dispatch: !!bridgeAuthority && runtime.enabled(), realtime: false, machineRead: config.machine?.enabled === true && readConfig().machine?.enabled === true } };
  });
  await registerMachineHttp(app, { config, readConfig, readMembers, authority, floors });
  registerArtifactsHttp(app, config.artifacts, config.project.id, projectAccess);
  const boardAgentOptions={initial:structuredClone(config),readConfig,floors,runtime:floorRuntime};
  const sharedViews=new WhiteboardSharedViews((projectId,target)=>whiteboardShareTargets(boardAgentOptions,projectId).some(t=>t.gatewayId===target.gatewayId&&t.agentId===target.agentId));
  const boardPath = '/api/projects/:projectId/studio/whiteboard';
  const boardGuard = (request: FastifyRequest, reply: FastifyReply, write = false) => {
    const principal = projectAccess(request, reply, write);
    return () => {
      const actor = principal.guard();
      return { projectId: selectedProjectId(request), actor: { kind: 'human' as const, id: actor.profileId }, canWrite: true };
    };
  };
  app.get(boardPath+'/v3/agents',async(request,reply)=>{query(request.query,[]);const guard=boardGuard(request,reply);const {projectId}=guard();const agents=whiteboardShareTargets(boardAgentOptions,projectId);guard();return {agents};});
  const collaborative = authority.collaborativeWhiteboard;
  registerSpatialWhiteboard(app,authority.whiteboard,collaborative,config.artifacts,boardGuard,boardPath);
  app.get(boardPath+'/v3/navigation',async(request,reply)=> {
    query(request.query,[]);const guard=boardGuard(request,reply);
    const overview=await authority.whiteboard.overview(guard);
    const live=readConfig(),members=floors.projects().find(p=>p.id===overview.projectId)?.memberProfileIds??[];
    const people=overview.authors.flatMap(id=>{const person=live.members.find(m=>m.profileId===id&&members.includes(id));return person?[{id,name:person.displayName??id}]:[];});
    guard();return {...overview,people};
  });
  const v2 = boardPath + '/v2';
  app.get(v2, async (request,reply) => { query(request.query,[]); return collaborative.snapshot(boardGuard(request,reply)); });
  app.get(v2 + '/capabilities', async (request,reply) => { boardGuard(request,reply)(); query(request.query,[]); return { version:2, enabled:readConfig().whiteboardCollaboration===true }; });
  app.get<{ Params: { projectId:string; blockId:string } }>(v2 + '/text/:blockId', async (request,reply) => { query(request.query,[]); return collaborative.head(request.params.blockId,boardGuard(request,reply)); });
  app.get<{ Params: { projectId:string; commandId:string } }>(v2 + '/receipts/:commandId', async (request,reply) => { query(request.query,[]); return collaborative.receipt(request.params.commandId,boardGuard(request,reply)); });
  app.post(v2 + '/convert', async (request,reply) => { query(request.query,[]); return collaborative.convert(request.body,boardGuard(request,reply,true)); });
  app.post(v2 + '/commands', async (request,reply) => { query(request.query,[]); return collaborative.structure(request.body,boardGuard(request,reply,true)); });
  app.post(v2 + '/read', async (request,reply) => { query(request.query,[]); return collaborative.read(request.body,boardGuard(request,reply,true)); });
  app.get(v2 + '/comments',async(request,reply)=> { const values=query(request.query,['blockId']); return collaborative.comments(values.blockId,boardGuard(request,reply)); });
  app.post(v2 + '/comments',async(request,reply)=> { query(request.query,[]); return collaborative.comment(request.body,boardGuard(request,reply,true)); });
  registerWhiteboardSocket(app,collaborative,config.origin,async (request,projectId) => {
    const cookies=app.parseCookie(request.headers.cookie ?? ''); await auth.refresh(cookies[sessionCookie]); const initial=authenticate({ cookies });
    const guard=() => {
      const current=authenticate({ cookies });
      authority.floors.assertSettled(projectId);
      if (floors.record(projectId)?.retiredAt || current.actor.profileId!==initial.actor.profileId || current.actor.approver!==initial.actor.approver
        || !floors.projects().find(p=>p.id===projectId)?.memberProfileIds.includes(current.actor.profileId)) throw new HttpError('AUTHORITY_REVOKED',403,'Whiteboard access changed');
      if (readConfig().whiteboardCollaboration!==true) throw new MissionError('COLLABORATION_DISABLED','Collaborative editing is paused');
      return { projectId,actor:{ kind:'human' as const,id:current.actor.profileId },canWrite:true };
    };
    return { guard,name:()=> { guard(); return readConfig().members.find(member=>member.profileId===initial.actor.profileId)?.displayName ?? initial.actor.profileId; },
      csrf:(value:string)=> { guard(); if (!equal(value,authenticate({ cookies }).session.csrfToken)) throw new HttpError('CSRF_INVALID',403,'Refresh Studio'); } };
  },sharedViews);
  app.server.on('upgrade',(request,socket)=> {
    if (isWhiteboardStream(request.url ?? '') || workbenchPreview) return;
    socket.end('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
  });
  app.get(boardPath, async (request, reply) => {
    const guard = boardGuard(request, reply); query(request.query, []);
    return authority.whiteboard.snapshot(guard);
  });
  app.post(boardPath + '/commands', async (request, reply) => {
    const guard = boardGuard(request, reply, true); query(request.query, []);
    return authority.whiteboard.apply(request.body, guard);
  });
  app.get<{ Params: { projectId: string; commandId: string } }>(boardPath + '/receipts/:commandId', async (request, reply) => {
    const guard = boardGuard(request, reply); query(request.query, []);
    return authority.whiteboard.receipt(request.params.commandId, guard);
  });
  app.get(boardPath + '/changes', async (request, reply) => {
    const guard = boardGuard(request, reply); const values = query(request.query, ['after', 'limit']);
    for (const value of Object.values(values)) if (!/^(0|[1-9][0-9]*)$/.test(value)) throw new HttpError('INVALID_INPUT', 400, 'Invalid change cursor');
    return authority.whiteboard.changes({ ...(values.after === undefined ? {} : { after: Number(values.after) }),
      ...(values.limit === undefined ? {} : { limit: Number(values.limit) }) }, guard);
  });
  app.post(boardPath + '/read', async (request, reply) => {
    const guard = boardGuard(request, reply, true); query(request.query, []);
    return authority.whiteboard.read(request.body, guard);
  });
  app.post(boardPath + '/context', async (request, reply) => {
    const guard = boardGuard(request, reply, true); query(request.query, []);
    return authority.whiteboard.context(request.body, guard);
  });
  registerArtifactsHttp(app, config.artifacts, selectedProjectId, projectAccess, '/api/projects/:projectId/studio/artifacts');
  await registerWhiteboardMcp(app, { ...boardAgentOptions, board: authority.whiteboard, sharedViews: principal => sharedViews.views(principal) });
  const boardAgent = createWhiteboardAgentBridge({ initial: config, readConfig, floors, runtime: floorRuntime, board: authority.whiteboard, text: authority.collaborativeWhiteboard, sharedViews:principal=>sharedViews.views(principal),
    executionEnabled: projectId => { try { return native?.forProject(projectId).enabled() ?? false; } catch { return false; } } });
  app.get(boardPath+'/v3/companions',async(request,reply)=>{
    const values=query(request.query,['before']);
    return boardAgent.companions(boardGuard(request,reply),values.before===undefined?undefined:Number(values.before));
  });
  const companionAllowed=()=>companionAccess(boardAgentOptions);
  app.get(boardPath+'/v3/chat',async(request,reply)=>{
    const values=query(request.query,['before']),guard=boardGuard(request,reply),{projectId}=guard();
    return authority.whiteboardCompanion.page(companionAllowed().filter(a=>a.projectId===projectId),
      config.whiteboardAgents?.companionEnabled===true&&readConfig().whiteboardAgents?.companionEnabled===true,
      values.before===undefined?undefined:Number(values.before),guard);
  });
  app.post(boardPath+'/v3/chat/start',async(request,reply)=>{query(request.query,[]);return authority.whiteboardCompanion.start(request.body,boardGuard(request,reply,true),companionAllowed);});
  app.post(boardPath+'/v3/chat/stop',async(request,reply)=>{query(request.query,[]);return authority.whiteboardCompanion.stop(request.body,boardGuard(request,reply,true));});
  const companion={request:(input:unknown,principal:import('@studio/contracts').BridgePrincipal,current:()=>import('@studio/contracts').BridgePrincipal)=>authority.whiteboardCompanion.request(input,principal,current,companionAllowed)};
  registerBridgeHttp(app, { companion, whiteboard: boardAgent, config, authority: bridgeAuthority, readBridge, native, ...(config.floorManagement ? { floors: floorAgentAdapter(floorManagement, readConfig) } : {}) });
  registerDashboardCustodyHttp(app, { authorityId: config.authorityId, service: dashboardCustody });
  const floorGuard = (request: FastifyRequest, reply: FastifyReply, write = false) => {
    const principal = access(request, reply, write);
    return () => ({ actor: { kind: 'human' as const, id: principal.guard().profileId },
      canManage: !!config.floorManagement && canManageFloors(readConfig(), principal.actor.profileId) });
  };
  const floorSetup = new FloorSetupService(floorManagement, () => readConfig().floorSetup,
    id => floorRuntime?.status(id) ?? 'unconfigured');
  app.get<{ Params: { floorId: string } }>('/api/studio/floors/:floorId/setup', async (request, reply) => {
    query(request.query, []); return floorSetup.read(request.params.floorId, floorGuard(request, reply));
  });
  app.get('/api/studio/floors', async (request, reply) => { query(request.query, []); return floorManagement.list(floorGuard(request, reply)); });
  app.get('/api/studio/floors/repositories', async (request, reply) => { query(request.query, []); return floorManagement.catalog(floorGuard(request, reply)); });
  app.get('/api/studio/repositories/inventory', async (request, reply) => {
    void reply.header('Cache-Control','private, no-store');
    const values=query(request.query,['after']);
    return floorManagement.repositoryInventory(floorGuard(request,reply),values.after);
  });
  app.post('/internal/repository-registry/validate', async (request) => {
    query(request.query, []);
    const guard = registryValidationGuard(request.headers.authorization, process.env.STUDIO_REGISTRY_VALIDATION_HASH_FILE);
    const result = await registry.validateContributionRequest(request.body, guard);
    await guard(); return result;
  });
  app.get('/api/studio/repositories/registry/catalog', async (request,reply)=>{query(request.query,[]);return floorManagement.registryOperation('catalog',floorGuard(request,reply));});
  app.post('/api/studio/repositories/registry/commands', async (request,reply)=>{query(request.query,[]);return floorManagement.registryOperation('command',floorGuard(request,reply,true),request.body);});
  app.get<{Params:{commandId:string}}>('/api/studio/repositories/registry/commands/:commandId', async (request,reply)=>{query(request.query,[]);return floorManagement.registryOperation('receipt',floorGuard(request,reply),request.params.commandId);});
  app.post('/api/studio/repositories/registry/preview', async (request,reply)=>{query(request.query,[]);return floorManagement.registryOperation('preview',floorGuard(request,reply,true),request.body);});
  app.post('/api/studio/repositories/registry/compare', {bodyLimit:1024*1024}, async (request,reply)=>{query(request.query,[]);return floorManagement.registryOperation('compare',floorGuard(request,reply,true),request.body);});
  app.post('/api/studio/floors/commands', async (request, reply) => { query(request.query, []); return floorManagement.apply(request.body, floorGuard(request, reply, true)); });
  app.post('/api/studio/repositories/commands', async (request, reply) => { query(request.query, []); return floorManagement.repositoryOperation(floorGuard(request, reply, true), undefined, request.body); });
  app.get<{ Params: { commandId: string } }>('/api/studio/repositories/commands/:commandId', async (request, reply) => { query(request.query, []); return floorManagement.repositoryOperation(floorGuard(request, reply), request.params.commandId); });
  app.get<{ Params: { commandId: string } }>('/api/studio/floors/receipts/:commandId', async (request, reply) => {
    query(request.query, []); return floorManagement.receipt(request.params.commandId, floorGuard(request, reply));
  });
  const readKnowledge = async (request: FastifyRequest<{ Params: { projectId: string; '*': string } }>, reply: FastifyReply) => {
    void reply.header('Cache-Control','private, no-store');
    const principal = projectAccess(request,reply);
    const binding = floors.record(request.params.projectId);
    const currentCore = () => {
      principal.guard();
      const current = floors.record(request.params.projectId);
      if (current?.revision !== binding?.revision) throw new HttpError('AUTHORITY_REVOKED',403,'The floor sources changed. Refresh Knowledge.');
      if (!binding && (request.params.projectId !== 'core' || configuredProjects(readConfig()).find(p => p.id === 'core')?.kind !== 'company')) throw new HttpError('PROJECT_FORBIDDEN',403,'Choose repositories for this floor to open Knowledge.');
    };
    currentCore();
    const path = request.params['*'] ?? 'graph/neighborhood';
    if (path.startsWith('floors/')) throw new HttpError('FORBIDDEN',403,'Use the floor management catalog.');
    if (!knowledgeOperation(request.method,path)) throw new HttpError('FORBIDDEN',403,'This Knowledge operation is unavailable.');
    if (request.method === 'POST' && request.headers.origin !== config.origin) throw new HttpError('ORIGIN_FORBIDDEN',403,'A same-origin request is required.');
    if (!knowledge) throw new HttpError('UNAVAILABLE',503,'The Knowledge service is not connected.');
    const controller = new AbortController();request.raw.once('aborted',()=>controller.abort());reply.raw.once('close',()=>{if(!reply.raw.writableFinished)controller.abort();});
    const search = new URL(request.url,config.origin).searchParams;
    if (binding && (request.headers['x-studio-floor-revision'] ?? search.get('floorRevision')) !== String(binding.revision)) throw new HttpError('AUTHORITY_REVOKED',403,'Refresh this floor before reading its sources.');
    search.delete('floorRevision');
    const scope = process.env.STUDIO_REGISTRY_DOCUMENTATION_CONFIG
      ? await registryFloorSelection(process.env.STUDIO_REGISTRY_DOCUMENTATION_CONFIG, 'documentation', request.params.projectId, floors, currentCore)
      : undefined;
    try {
      const result = await knowledge.read(request.method,path,search,request.method === 'POST' ? request.body : undefined,JSON.stringify([config.authorityId,principal.session.issuer,principal.session.subject]),controller.signal,
        scope?.repositories ?? binding?.repositories.map(({ id, slug }) => ({ id, slug })), scope);
      currentCore();scope?.guard();return reply.type(result.contentType).send(Buffer.from(result.body));
    } catch(error) {
      currentCore();if(error instanceof KnowledgeError){if(error.retryAfterSeconds)void reply.header('Retry-After',String(error.retryAfterSeconds));return reply.code(error.status).send({error:{code:'KNOWLEDGE_UNAVAILABLE',message:error.message}});}throw error;
    }
  };
  app.route({ method: ['GET','POST'], bodyLimit: 8192, url: '/api/projects/:projectId/studio/knowledge/*', handler: readKnowledge });
  app.post('/api/projects/:projectId/studio/knowledge/graph/neighborhood', { bodyLimit: 256 * 1024 }, readKnowledge);
  app.route<{Params:{projectId:string;'*':string}}>({ method: ['GET','POST'], bodyLimit:16384,
    url:'/api/projects/:projectId/studio/code/*', handler:async(request,reply)=>{
      void reply.header('Cache-Control','private, no-store');
      const principal=projectAccess(request,reply), configPath=process.env.STUDIO_REGISTRY_CODE_CONFIG;
      if(!configPath)throw new HttpError('UNAVAILABLE',503,'Floor code search is not connected.');
      if(request.method==='POST'&&request.headers.origin!==config.origin)throw new HttpError('ORIGIN_FORBIDDEN',403,'A same-origin request is required.');
      const search=new URL(request.url,config.origin).searchParams, binding=floors.record(request.params.projectId);
      if(!binding||(request.headers['x-studio-floor-revision']??search.get('floorRevision'))!==String(binding.revision))throw new HttpError('AUTHORITY_REVOKED',403,'Refresh this floor before reading its code.');
      search.delete('floorRevision');
      const controller=new AbortController();request.raw.once('aborted',()=>controller.abort());
      reply.raw.once('close',()=>{if(!reply.raw.writableFinished)controller.abort();});
      const result=await readFloorCode({configPath,floorId:request.params.projectId,floors,method:request.method,path:request.params['*'],query:search,
        body:request.method==='POST'?request.body:undefined,identity:JSON.stringify([config.authorityId,principal.session.issuer,principal.session.subject]),guard:principal.guard,signal:controller.signal});
      principal.guard();return reply.type('application/json').send(Buffer.from(result));
    }});
  for(const prefix of ['/api/studio/artifact-lifecycle','/api/projects/:projectId/studio/artifact-lifecycle'])registerArtifactLifecycleHttp(app,{authority,readConfig,access:projectAccess,projectId:selectedProjectId,isAdmin:p=>appsAccess.login(p.session.issuer,p.session.subject).groups.includes('infuse-admins')},prefix);
  registerMonitoringHttp(app,{authority,readConfig,access,floors:()=>floors.projects(),assertSettled:id=>authority.floors.assertSettled(id),isAdmin:p=>appsAccess.login(p.session.issuer,p.session.subject).groups.includes('infuse-admins')});
  function gitRead(request:FastifyRequest,reply:FastifyReply) {
    const principal=access(request,reply);
    const admitted=()=>{
      principal.guard();
      const floorIds=floors.projects().filter(p=>p.memberProfileIds.includes(principal.actor.profileId)).filter(p=>{try{authority.floors.assertSettled(p.id);return true;}catch{return false;}}).map(p=>p.id).sort();
      if(!floorIds.length)throw new HttpError('PROJECT_FORBIDDEN',403,'A currently admitted Studio floor is required');
      const sources=readContributions()?.repositories.filter(r=>r.floorIds.some(id=>floorIds.includes(id)))??[];
      return {sources,floorIds};
    };
    const initial=admitted(),fingerprint=JSON.stringify(initial);
    return {...initial,guard:()=>{if(JSON.stringify(admitted())!==fingerprint)throw new HttpError('AUTHORITY_REVOKED',403,'Git source admission changed during this read');}};
  }
  const gitValue=<T,>(read:()=>T):T=>{try{return read();}catch{throw new HttpError('INVALID_INPUT',400,'Invalid contribution filter or cursor');}};
  app.get('/api/contributions',async(request,reply)=>{
    const values=query(request.query,['year','repository','azureProject','author']),scope=gitRead(request,reply);
    const year=values.year===undefined?new Date().getUTCFullYear():Number(values.year);
    if(values.year!==undefined&&!/^\d{1,4}$/.test(values.year)||!Number.isInteger(year)||year<0||year>9999)throw new HttpError('INVALID_INPUT',400,'Choose a valid contribution year');
    const projectId=values.azureProject===undefined?undefined:gitValue(()=>gitGuid(values.azureProject));
    const authorKey=values.author===undefined?undefined:gitValue(()=>gitText(values.author,1024).trim().toLowerCase());
    if(values.repository!==undefined&&!scope.sources.some(r=>r.sourceId===values.repository))throw new HttpError('FORBIDDEN',403,'Repository is outside your admitted sources');
    const value=await authority.contributions.read<ContributionsView>({kind:'read',sourceIds:scope.sources.map(r=>r.sourceId),expectedRepositories:scope.sources.map(parseGitRepositoryIdentity),year,selectedSourceId:values.repository,projectId,authorKey},scope.guard);
    const aliases=readConfig().contributions?.authorAliases??[];scope.guard();
    return {...value,authors:value.authors.map(a=>{const alias=aliases.find(x=>x.key===a.key);return {...a,...(alias?{label:alias.label,kind:alias.kind}:{})};}),collecting:readConfig().contributions?.enabled===true,configuredSources:scope.sources.length};
  });
  app.get('/api/contributions/day',async(request,reply)=>{
    const values=query(request.query,['date','repository','azureProject','author','cursor']),scope=gitRead(request,reply);
    if(!values.date||!/^\d{4}-\d\d-\d\d$/.test(values.date))throw new HttpError('INVALID_INPUT',400,'Choose an exact UTC day');
    gitValue(()=>gitTime(values.date+'T00:00:00Z'));
    const projectId=values.azureProject===undefined?undefined:gitValue(()=>gitGuid(values.azureProject));
    if(values.repository!==undefined&&!scope.sources.some(r=>r.sourceId===values.repository))throw new HttpError('FORBIDDEN',403,'Repository is outside your admitted sources');
    const sources=scope.sources.filter(r=>(!values.repository||r.sourceId===values.repository)&&(!projectId||r.projectId===projectId));
    const after=values.cursor===undefined?undefined:gitValue(()=>parseContributionCursor(JSON.parse(gitText(values.cursor,1024))));
    const authorKey=values.author===undefined?undefined:gitValue(()=>gitText(values.author,1024).trim().toLowerCase());
    const value=await authority.contributions.read({kind:'day',sourceIds:sources.map(r=>r.sourceId),expectedRepositories:sources.map(parseGitRepositoryIdentity),date:values.date,authorKey,after},scope.guard);scope.guard();return value;
  });
  app.get('/api/projects/:projectId/agents/:gatewayId/:agentId/telemetry', async (request, reply) => {
    query(request.query, []);
    const principal=projectAccess(request,reply),params=request.params as {projectId:string;gatewayId:string;agentId:string};
    const target={gatewayId:params.gatewayId,agentId:params.agentId};
    const admittedSources=()=>{
      principal.guard();const current=readConfig(),selected=floors.config(params.projectId);
      const targets=params.projectId===current.project.id?authority.bootstrap(principal.actor).targets:selected.nativeMissions?.routes??[];
      const observed=current.agentTelemetry?.observedAgents?.filter(a=>a.floorIds.includes(params.projectId))??[];
      if(![...targets,...observed].some(t=>t.gatewayId===target.gatewayId&&t.agentId===target.agentId))throw new HttpError('FORBIDDEN',403,'This agent is outside the admitted project roster');
      return current.agentTelemetry?.sources.filter(s=>s.gatewayId===target.gatewayId&&s.agentId===target.agentId)??[];
    };
    const sources=admittedSources(),fingerprint=JSON.stringify(sources);
    const guard=()=>{if(JSON.stringify(admittedSources())!==fingerprint)throw new HttpError('AUTHORITY_REVOKED',403,'Telemetry source admission changed');};
    const value=await authority.agentTelemetry.read(target,sources.map(s=>s.sourceId),guard,Object.fromEntries(sources.map(s=>[s.sourceId,s.staleAfterMs])));
    guard();if(value.sources.some(s=>sources.find(c=>c.sourceId===s.sourceId)?.kind!==s.kind))throw new HttpError('AUTHORITY_REVOKED',403,'Stored telemetry source kind disagrees with current admission');return {...value,configuration:!sources.length?'unconfigured':sources.every(s=>s.transport.type==='retained')?'imported':readConfig().agentTelemetry?.enabled?'collecting':'paused',configuredSourceCount:sources.length};
  });
  app.get('/api/session', async (request, reply) => {
    const values = query(request.query, ['projectId']);
    try {
      const authenticated = authenticate(request);
      const projectId = values.projectId ?? floors.projects().find(p => p.memberProfileIds.includes(authenticated.actor.profileId))?.id ?? config.project.id;
      const principal = access(request, reply, false, projectId); const selected = floors.config(projectId);
      const bootstrap = authority.bootstrap(principal.actor); principal.guard();
      if (floors.knowledgeOnly(projectId)) bootstrap.dispatchEnabled = false;
      if (projectId !== config.project.id) bootstrap.targets = selected.nativeMissions?.routes.map(({ gatewayId, agentId }) => ({ gatewayId, agentId })) ?? [];
      const nativeService = selected.nativeMissions ? native?.forProject(projectId) : undefined;
      return { authenticated: true, profileId: principal.actor.profileId, displayName: principal.displayName,
        canManageFloors: !!config.floorManagement && canManageFloors(readConfig(), principal.actor.profileId),
        knowledgeOnly: false,
        floorConnection: floorRuntime?.status(projectId) ?? (selected.nativeMissions ? 'ready' : 'unconfigured'),
        knowledgeScope: floors.record(projectId) ? { revision: floors.record(projectId)!.revision } : undefined,
        observedAgents: readConfig().agentTelemetry?.observedAgents?.filter(a=>a.floorIds.includes(projectId)).map(({gatewayId,agentId})=>({gatewayId,agentId}))??[],
        csrfToken: principal.session.csrfToken, workbenchAvailable: !!workbenchPreview, project: selected.project, bootstrap, legacyProject: projectId === config.project.id, companyWorkspace: false,
        projects: floors.projects().filter(p => p.memberProfileIds.includes(principal.actor.profileId)).map(({ id, name, kind }) => ({ id, name, knowledgeOnly: false, ...(kind ? { kind } : {}) })),
        ...(nativeService ? { nativeMissions: { enabled: nativeService.enabled(), cutover: selected.nativeMissions?.cutover === true,
          coordinator: selected.nativeMissions?.routes.find(r => r.role === 'coordinator') && {
            gatewayId: selected.nativeMissions.routes.find(r => r.role === 'coordinator')!.gatewayId,
            agentId: selected.nativeMissions.routes.find(r => r.role === 'coordinator')!.agentId } } } : {}) };
    } catch (error) {
      if (error instanceof HttpError && ['UNAUTHENTICATED', 'ROLE_REVOKED'].includes(error.code)) {
        clear(reply, sessionCookie); return { authenticated: false, loginUrl: '/api/auth/login' };
      }
      throw error;
    }
  });
  app.get('/api/auth/login', async (request, reply) => {
    const values = query(request.query, ['returnTo']);
    // Preserve only the My Apps project hint; admission still happens on every project read.
    if (values.returnTo !== undefined && values.returnTo !== '/prototype-mockup/' && values.returnTo !== '/apps') {
      try {
        if (!values.returnTo.startsWith('/apps?project=')) throw Error('Invalid destination');
        const project = values.returnTo.slice('/apps?project='.length);
        if (encodeURIComponent(missionIdentifier(project)) !== project) throw Error('Invalid project hint');
      } catch { throw new HttpError('INVALID_INPUT', 400, 'Invalid sign-in destination'); }
    }
    const { transaction, url } = await oidc.begin();
    await auth.consumeLogin(request.cookies[loginCookie]);
    const token = await auth.createLogin({ ...transaction, ...(values.returnTo ? { returnTo: values.returnTo as LoginTransaction['returnTo'] } : {}) }); reply.setCookie(loginCookie, token, { ...cookieOptions, maxAge: LOGIN_SECONDS });
    return reply.redirect(url);
  });
  app.get('/api/auth/callback', async (request, reply) => {
    const transaction = await auth.consumeLogin(request.cookies[loginCookie]); clear(reply, loginCookie);
    if (!transaction) throw new HttpError('LOGIN_INVALID', 400, 'Sign-in expired or was already used; start again');
    try {
      const callback = new URL('/api/auth/callback', config.origin); callback.search = new URL(request.url, config.origin).search;
      const identity = await oidc.complete(callback, transaction); const current = member(identity.issuer, identity.subject);
      const launcher = !current ? appsAccess.login(identity.issuer, identity.subject) : undefined;
      if (!current && !launcher?.eligible) throw new HttpError('FORBIDDEN', 403, 'This identity is not enrolled in Studio or My Apps');
      await auth.revoke(request.cookies[sessionCookie]); const { token } = await auth.createSession({ ...identity, profileId: current?.profileId ?? launcher!.profileId! });
      reply.setCookie(sessionCookie, token, { ...cookieOptions, maxAge: SESSION_SECONDS }); return reply.redirect(!current ? '/apps' : transaction.returnTo ?? '/');
    } catch (error) {
      if (error instanceof HttpError) throw error;
      throw new HttpError('LOGIN_INVALID', 400, 'Sign-in could not be verified; start again');
    }
  });
  app.post('/api/logout', async (request, reply) => { const principal = access(request, reply, true); principal.guard(); await auth.revoke(principal.token); clear(reply, sessionCookie); return { ok: true }; });
  app.get('/api/studio/missions', async (request, reply) => {
    const principal = projectAccess(request, reply); const input = query(request.query, ['limit', 'cursor']); let cursor: unknown;
    try { cursor = input.cursor === undefined ? undefined : JSON.parse(input.cursor); } catch { throw new HttpError('INVALID_INPUT', 400, 'Invalid pagination cursor'); }
    if (input.limit !== undefined && !/^[1-9][0-9]?$/.test(input.limit)) throw new HttpError('INVALID_INPUT', 400, 'Invalid pagination limit');
    return authority.list({ ...(input.limit ? { limit: Number(input.limit) } : {}), ...(cursor === undefined ? {} : { cursor }) }, principal.actor, principal.guard);
  });
  app.get<{ Params: { id: string } }>('/api/studio/missions/:id', async (request, reply) => {
    const principal = projectAccess(request, reply); query(request.query, []); return authority.get(request.params.id, principal.actor, principal.guard);
  });
  app.get<{ Params: { id: string } }>('/api/studio/missions/:id/evidence', async (request, reply) => {
    const principal = projectAccess(request, reply); const input = query(request.query, ['evidenceHash', 'evidenceRevision']);
    return authority.evidence({ missionId: request.params.id, ...input }, principal.actor, principal.guard);
  });
  app.get<{ Params: { id: string } }>('/api/studio/missions/:id/conversations', async (request, reply) => {
    const principal = projectAccess(request, reply); const values = query(request.query, ['beforeSequence', 'limit']);
    for (const value of Object.values(values)) if (!/^[1-9][0-9]*$/.test(value) || !Number.isSafeInteger(Number(value))) throw new HttpError('INVALID_INPUT', 400, 'Invalid conversation pagination');
    if (values.limit && Number(values.limit) > 100) throw new HttpError('INVALID_INPUT', 400, 'Invalid conversation pagination');
    const input = { missionId: request.params.id, ...(values.beforeSequence ? { beforeSequence: Number(values.beforeSequence) } : {}), ...(values.limit ? { limit: Number(values.limit) } : {}) };
    if (conversations) return conversations.read(input, principal.guard);
    await authority.get(request.params.id, principal.actor, principal.guard);
    return { missionId: request.params.id, available: false, bindings: [], events: [], deliveries: [] };
  });
  app.post('/api/studio/conversations/bind', async (request, reply) => {
    const principal = projectAccess(request, reply, true); query(request.query, []);
    if (!conversations) throw new HttpError('CONVERSATION_DISABLED', 503, 'Mattermost conversations are disabled');
    return conversations.bind(request.body, principal.guard);
  });
  app.post('/api/studio/conversations/comments', async (request, reply) => {
    const principal = projectAccess(request, reply, true); query(request.query, []);
    if (!conversations) throw new HttpError('CONVERSATION_DISABLED', 503, 'Mattermost conversations are disabled');
    return conversations.comment(request.body, principal.guard);
  });
  app.post('/api/studio/conversations/responses', async (request, reply) => {
    const principal = projectAccess(request, reply, true); query(request.query, []);
    if (!conversations) throw new HttpError('CONVERSATION_DISABLED', 503, 'Coordinator responses are disabled');
    return conversations.requestResponse(request.body, principal.guard);
  });
  app.post('/api/studio/commands', async (request, reply) => {
    if (config.nativeMissions?.cutover && (request.body as { type?: unknown })?.type === 'create') throw new HttpError('LEGACY_RETIRED', 409, 'Create new missions through the native Studio workflow');
    const principal = projectAccess(request, reply, true); query(request.query, []); return authority.command(request.body, principal.actor, principal.guard);
  });
  if (native) for (const prefix of ['/api/studio/v2', '/api/projects/:projectId/studio/v2']) {
    app.get(`${prefix}/missions`, async (request, reply) => {
      const p = projectAccess(request, reply); query(request.query, []); return native.forProject(selectedProjectId(request)).authority.list(p.actor, p.guard);
    });
    app.get<{ Params: { id: string } }>(`${prefix}/missions/:id`, async (request, reply) => {
      const p = projectAccess(request, reply); query(request.query, []); return native.forProject(selectedProjectId(request)).authority.read(request.params.id, p.actor, p.guard);
    });
    app.post(`${prefix}/commands`, async (request, reply) => {
      const p = projectAccess(request, reply, true); query(request.query, []); return native.forProject(selectedProjectId(request)).authority.command(request.body, p.actor, p.guard);
    });
    app.post(`${prefix}/comments`, async (request, reply) => {
      const p = projectAccess(request, reply, true); query(request.query, []); return native.forProject(selectedProjectId(request)).comment(request.body, p.guard);
    });
    app.post(`${prefix}/decisions/prepare`, async (request, reply) => {
      const p = projectAccess(request, reply, true); query(request.query, []); return native.forProject(selectedProjectId(request)).authority.prepare(request.body, p.actor, p.guard);
    });
    app.post(`${prefix}/decisions/resolve`, async (request, reply) => {
      const p = projectAccess(request, reply, true); query(request.query, []); return native.forProject(selectedProjectId(request)).authority.decide(request.body, p.actor, p.guard);
    });
  }
  await registerMockupHttp(app, mockupRoot, authenticate);
  if (webRoot && isAbsolute(webRoot) && existsSync(webRoot)) await app.register(staticFiles, { root: webRoot, index: 'index.html', dotfiles: 'deny' });
  app.setNotFoundHandler((request, reply) => {
    if (request.url === '/api' || request.url.startsWith('/api/')) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'API route not found' } });
    if (webRoot && existsSync(webRoot) && ['GET', 'HEAD'].includes(request.method) && !extname(new URL(request.url, config.origin).pathname) && request.headers.accept?.includes('text/html')) return reply.sendFile('index.html');
    return reply.code(webRoot && existsSync(webRoot) ? 404 : 503).send({ error: { code: 'NOT_FOUND', message: 'Frontend unavailable. Run npm run build.' } });
  });
  return app;
}
