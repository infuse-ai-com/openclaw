import { readFileSync, openSync, fstatSync, readSync, closeSync, constants } from 'node:fs';

export type ConfigurationSourceReader = (file: string, bounded?: boolean) => string;

/** Protected Kubernetes projections are symlinks; pin one regular file while reading bounded bytes. */
export const readConfigurationSource: ConfigurationSourceReader = (file, bounded = false) => {
  if (!bounded) return readFileSync(file, 'utf8');
  const descriptor = openSync(file, constants.O_RDONLY | constants.O_NONBLOCK);
  try {
    const maximum = 1024 * 1024, info = fstatSync(descriptor);
    if (!info.isFile() || info.size > maximum) throw Error('Invalid operations configuration file');
    const buffer = Buffer.alloc(Math.min(info.size + 1, maximum + 1));
    let length = 0;
    while (length < buffer.length) {
      const count = readSync(descriptor, buffer, length, buffer.length - length, null);
      if (!count) break;
      length += count;
    }
    if (length > maximum || length > info.size) throw Error('Operations configuration changed or is too large');
    return buffer.subarray(0, length).toString('utf8');
  } finally { closeSync(descriptor); }
};

function freeze<T>(value: T): T {
  if (value && typeof value === 'object') {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}

/** Reuse parsing, never admission. Check actual bytes/readability on every call, without a TTL or watcher race. */
export function reuseConfiguration<T>(load: (read: ConfigurationSourceReader) => T, environment: () => string): () => T {
  let cached: { value: T; environment: string; sources: Map<string, { file: string; bounded: boolean; text: string }> } | undefined;
  return () => {
    const currentEnvironment = environment();
    if (cached && cached.environment === currentEnvironment) {
      let unchanged = true;
      try {
        for (const source of cached.sources.values()) {
          if (readConfigurationSource(source.file, source.bounded) !== source.text) { unchanged = false; break; }
        }
      } catch { unchanged = false; }
      if (unchanged) return cached.value;
    }
    // Load fresh sources after a change. An obsolete indirect file can disappear
    // when its reference is removed; only the new generation's dependencies matter.
    const sources = new Map<string, { file: string; bounded: boolean; text: string }>();
    const read: ConfigurationSourceReader = (file, bounded = false) => {
      const key = JSON.stringify([file, bounded]);
      let source = sources.get(key);
      if (!source) {
        source = { file, bounded, text: readConfigurationSource(file, bounded) };
        sources.set(key, source);
      }
      return source.text;
    };
    // A failed generation is never published or served as a last-known-good fallback.
    const value = freeze(load(read));
    cached = { value, environment: currentEnvironment, sources };
    return value;
  };
}
