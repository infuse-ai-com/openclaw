# Realtime transport

`whiteboard.ts` adapts same-origin authenticated WebSockets to the shared
`CollaborativeWhiteboardService`. The route is
`/api/projects/:projectId/studio/whiteboard/v2/stream`; the local collaboration
capability defaults off. Each connection admits a cookie-bound identity, requires
a CSRF hello within five seconds, and subscribes to one body/epoch/editor key.

Every command, commit grant and outbound event rechecks current access. Durable
committed events are read from the existing writer every 100 ms; no optimistic
peer, awareness or cross-tab relay is used. Bounded frames, leases, rates, queues
and send buffers fail closed. Initial checkpoints and exact receipts use the
versioned HTTP surface. Within one poll, identical project/cursor pages may be
shared by browser peers; no page survives the pass, and every peer retains its
own send/access check. Native custody reads are never shared this way.

The browser coalesces secondary board-projection refreshes in fixed 200 ms windows;
committed text continues directly on its separate stream. Presence remains
advisory and bounded, and comments remain durable in the central writer.

The Workbench and whiteboard handlers share the server upgrade listener while
retaining ownership of their own routes; unknown upgrades still receive 404.
See [W3 architecture](../../../../docs/plans/active/020-collaborative-whiteboard/w3-design.md)
and [local evidence](../../../../docs/plans/active/020-collaborative-whiteboard/w3-results.md).
