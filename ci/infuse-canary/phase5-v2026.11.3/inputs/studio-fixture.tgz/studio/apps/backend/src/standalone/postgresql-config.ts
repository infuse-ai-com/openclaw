import { readFileSync } from 'node:fs';
import type { ClientConfig } from 'pg';
import type { StandaloneConfig } from './config.js';

/** Explicit selection fails closed. URI options cannot override TLS validation. */
export function postgresqlConnection(config: StandaloneConfig): ClientConfig {
  if (!config.storage) throw Error('Studio requires PostgreSQL; central SQLite is retired');
  try {
    const raw = process.env[config.storage.connectionEnv];
    if (!raw) throw Error('Missing connection');
    const url = new URL(raw), port = url.port ? Number(url.port) : 5432;
    if (!['postgresql:', 'postgres:'].includes(url.protocol) || !url.hostname || !url.username || !url.password
      || !/^\/[A-Za-z_][A-Za-z0-9_]{0,62}$/.test(url.pathname) || url.hash || url.search || !Number.isInteger(port) || port < 1 || port > 65535) throw Error('Invalid connection');
    return {host: url.hostname, port, user: decodeURIComponent(url.username), password: decodeURIComponent(url.password),
      database: url.pathname.slice(1), ssl: {ca: readFileSync(config.storage.caFile, 'utf8'), rejectUnauthorized: true, minVersion: 'TLSv1.2'}};
  } catch { throw Error('PostgreSQL is selected but its connection or trusted CA is unavailable; SQLite fallback is disabled'); }
}
