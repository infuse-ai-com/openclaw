import type {StudioAuthority} from '@studio/server';
import {createHash} from 'node:crypto';
import type {FastifyInstance,FastifyRequest,FastifyReply} from 'fastify';
import {parseArtifactLifecycleCommand} from '@studio/contracts';
import type {StandaloneConfig} from '../config.js';
import {HttpError} from '../http-error.js';
import {StudioArtifactLifecycleClient,ArtifactLifecycleError} from './lifecycle-client.js';
import {StudioArtifacts} from './service.js';
import {ArtifactRegistryReadError} from './read-client.js';
interface Principal {actor:{profileId:string};session:{issuer:string;subject:string};guard:()=>unknown}
export function registerArtifactLifecycleHttp(app:FastifyInstance,o:{authority:StudioAuthority;readConfig:()=>StandaloneConfig;access:(req:FastifyRequest,rep:FastifyReply,write?:boolean)=>Principal;projectId:(r:FastifyRequest)=>string;isAdmin:(p:Principal)=>boolean},prefix:string){
 function scope(request:FastifyRequest,reply:FastifyReply,write=false){
  const p=o.access(request,reply,write),id=o.projectId(request),config=o.readConfig().artifacts,snapshot=JSON.stringify(config);
  const guard=()=>{p.guard();if(JSON.stringify(o.readConfig().artifacts)!==snapshot)throw new HttpError('AUTHORITY_REVOKED',403,'Registry admission changed during this request');};
  const admin=()=>{guard();return o.isAdmin(p);};
  const token=config?.lifecycle?.tokenFiles[id]??config?.lifecycle?.floorTokenFile;
  const client=()=>{guard();if(!config||!token)throw new HttpError('ARTIFACT_LIFECYCLE_NOT_CONFIGURED',503,'Artifact lifecycle is not connected for this floor yet');return new StudioArtifactLifecycleClient(config.registryUrl,token,id);};
  return {p,id,config,guard,admin,client};
 }
 const query=(v:unknown,keys:string[])=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.entries(v).some(([k,x])=>!keys.includes(k)||typeof x!=='string'))throw new HttpError('INVALID_INPUT',400,'Invalid artifact filter');return v as Record<string,string>;};
 async function run(request:FastifyRequest,reply:FastifyReply,write:boolean,operation:(s:ReturnType<typeof scope>)=>Promise<unknown>){const s=scope(request,reply,write);try{const result=await operation(s);s.guard();return result;}catch(error){s.guard();if(error instanceof ArtifactLifecycleError)throw new HttpError(error.code,error.status,error.message);if(error instanceof ArtifactRegistryReadError)throw new HttpError('ARTIFACT_REGISTRY_UNAVAILABLE',503,'The Registry could not verify this response');throw error;}}
 app.get(prefix+'/access',(request,reply)=>run(request,reply,false,async s=>{query(request.query,[]);return {canReadRetained:s.admin()&&(s.config?.retainedSources?.length??0)>0};}));
 app.get(prefix+'/retained',(request,reply)=>run(request,reply,false,async s=>{
  const q=query(request.query,['producer','artifactId','before']);const guard=()=>{s.guard();if(!s.admin())throw new HttpError('ADMIN_REQUIRED',403,'Trusted infuse-admins membership is required for retained artifact history');};guard();
  let before:number|undefined;if(q.before!==undefined){before=Number(q.before);if(!/^(?:0|[1-9]\d*)$/.test(q.before)||!Number.isSafeInteger(before))throw new HttpError('INVALID_INPUT',400,'Invalid retained artifact cursor');}
  const result=await o.authority.artifactRetained.read({kind:'read',sources:s.config?.retainedSources??[],projectId:s.id,producer:q.producer,artifactId:q.artifactId,before},guard);guard();return result;
 }));
 app.get(prefix+'/bin',(request,reply)=>run(request,reply,false,async s=>{const q=query(request.query,['cursor','q','scope','mission']);if(!s.config)throw new HttpError('ARTIFACTS_NOT_CONFIGURED',503,'Artifact library is not connected');return new StudioArtifacts(s.config,s.id).list(q.cursor,'bin',q);}));
 app.get(prefix+'/:producer/:artifactId',(request,reply)=>run(request,reply,false,async s=>{query(request.query,[]);const p=request.params as {producer:string;artifactId:string};const state=await s.client().state(p.producer,p.artifactId,s.guard);return {state,canPurge:s.admin()};}));
 app.get(prefix+'/:producer/:artifactId/audit',(request,reply)=>run(request,reply,false,async s=>{const q=query(request.query,['before']);if(!s.admin())throw new HttpError('ADMIN_REQUIRED',403,'Trusted infuse-admins membership is required for artifact audit');const p=request.params as {producer:string;artifactId:string};const result=await s.client().audit(p.producer,p.artifactId,q.before,s.guard);if(!s.admin())throw new HttpError('AUTHORITY_REVOKED',403,'Artifact audit authority changed');return result;}));
 app.post(prefix+'/commands',{bodyLimit:4096},(request,reply)=>run(request,reply,true,async s=>{
  query(request.query,[]);let command;try{command=parseArtifactLifecycleCommand(request.body);}catch{throw new HttpError('INVALID_INPUT',400,'Confirm the exact artifact revision, generation and action');}
  const guard=()=>{s.guard();if(command.action==='purge'&&!s.admin())throw new HttpError('ADMIN_REQUIRED',403,'Trusted infuse-admins membership is required for permanent purge');};guard();
  const actorId=createHash('sha256').update(JSON.stringify([s.p.session.issuer,s.p.session.subject,s.p.actor.profileId])).digest('hex');
  const result=await s.client().apply(command,actorId,guard);guard();return result;
 }));
}
