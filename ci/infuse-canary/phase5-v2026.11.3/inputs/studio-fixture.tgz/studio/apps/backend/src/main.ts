import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import { RegistryContributionsAdapter, requireLegacyContributionsAuthority, CompanySignalsCollector, MonitoringController, GitContributionsCollector, AgentTelemetryCollector, MissionStore, StudioAuthority, StudioBridgeAuthority, requireMission } from '@studio/server';
import { postgresqlConnection } from './standalone/postgresql-config.js';
import { PostgresAuthStore } from './standalone/postgresql-auth-store.js';
import { configRealm } from './standalone/config.js';
import { createStandaloneServer } from './standalone/server.js';
import { configuredProjects, projectConfig, liveStandaloneConfig, loadStandaloneConfig } from './standalone/config.js';
import { bridgeRuntime } from './standalone/bridge-http.js';
import { ConversationService } from './standalone/mattermost.js';
import { FloorDirectory } from './standalone/floors.js';
import { FloorRuntimeController } from './standalone/floor-runtime.js';
import { NativeProjectsBridge } from './standalone/native-projects.js';

const workbenchConfigFile = process.env.STUDIO_WORKBENCH_CONFIG;
const floorsConfigFile = process.env.STUDIO_FLOORS_CONFIG;
const machineConfigFile = process.env.STUDIO_MACHINE_CONFIG;
const operationsConfigFile = process.env.STUDIO_OPERATIONS_CONFIG;
const config = loadStandaloneConfig(process.env.STUDIO_CONFIG, workbenchConfigFile, floorsConfigFile, machineConfigFile, operationsConfigFile);
const readConfig = liveStandaloneConfig(process.env.STUDIO_CONFIG!, config, workbenchConfigFile, floorsConfigFile, machineConfigFile, operationsConfigFile);
const readBridge = () => readConfig().bridge;
const runtime = bridgeRuntime(config, readBridge);
const host = process.env.HOST || '127.0.0.1';
if (config.bridge?.enabled && !['127.0.0.1', '::1', 'localhost'].includes(host)) throw Error('The Gateway bridge backend must bind loopback; terminate production TLS in a local reverse proxy');
const port = Number(process.env.PORT || new URL(config.origin).port || (config.origin.startsWith('https:') ? 443 : 80));
if (!Number.isInteger(port) || port < 1 || port > 65535) throw Error('Invalid PORT');
const postgresql = postgresqlConnection(config);
const store = new MissionStore({ postgresql, authorityId: config.authorityId, projectId: config.project.id, projectIds: configuredProjects(config).map(p => p.id) });
await store.open();
try {
  const authority = new StudioAuthority({ store, authorityId: config.authorityId, targets: config.targets, dispatchEnabled: runtime.enabled, executionCommandsEnabled: runtime.enabled, executionTargets: runtime.targets, executionEnrollment: runtime.enrollmentGeneration, dispatchTransport: 'outbound-v1', singleActiveMission: true,
    whiteboardCollaborationEnabled: () => readConfig().whiteboardCollaboration === true });
  await authority.floors.refresh();
  const floors = new FloorDirectory(authority.floors, readConfig);
  const floorRuntime = config.floorRuntime?.enabled ? new FloorRuntimeController(config, readConfig, floors, store) : undefined;
  await floorRuntime?.open();
  if (floorRuntime) floors.runtimeConfig = id => floorRuntime.config(id);
  const conversations = new ConversationService({ store, config: projectConfig(config, config.project.id),
    readConfig: () => floors.baseConfig(config.project.id),
    executionEnabled: runtime.enabled, executionGuard(targets) {
      requireMission(runtime.enabled(), 'DISPATCH_DISABLED', 'Outbound dispatch is disabled');
      for (const target of targets) requireMission(runtime.targets().some(item => item.gatewayId === target.gatewayId && item.agentId === target.agentId)
        && (target.enrollmentGeneration === undefined || runtime.enrollmentGeneration(target.gatewayId) === target.enrollmentGeneration),
      'CONFIGURATION', 'The coordinator execution target is no longer enrolled');
    } });
  const bridgeAuthority = new StudioBridgeAuthority({ store, dispatchEnabled: runtime.enabled, executionTargets: runtime.targets,
    executionEnrollment: runtime.enrollmentGeneration, prepareConversation: scope => conversations.prepareConversation(scope) });
  const native = configuredProjects(config).some(p => p.nativeMissions) ? new NativeProjectsBridge({ store, config, readConfig, executionEnabled: runtime.enabled,
    projectConfigs: () => floors.projects().map(project => floors.config(project.id)),
    ...(floorRuntime ? { automaticFloors: true, projectConfigs: () => floorRuntime.configurations(), projectConfig: (id, protection) => floorRuntime.findConfiguration(id, protection), protectionConfigs: () => floorRuntime.configurations(true), discover: (principal) => floorRuntime.discovery(principal) } : {}) }) : undefined;
  const workbench = config.workbench?.enabled ? { fixture:false, gatewayOrigin:config.workbench.gatewayOrigin, clientRoot:config.workbench.clientRoot, protectedAccess:{
    grantIssuer:config.workbench.grantIssuer,gatewayServerName:config.workbench.gatewayServerName,
    clientTls:()=>({cert:readFileSync(config.workbench!.clientCertFile),key:readFileSync(config.workbench!.clientKeyFile),ca:readFileSync(config.workbench!.caFile)}),
    signingKey:()=>({kid:config.workbench!.signingKeyId,pem:readFileSync(config.workbench!.signingPrivateKeyFile,'utf8')}),
    readWorkspaces:()=>{const current=readConfig().workbench;return current?.enabled?current.workspaces:[];},
    authorityAvailable:()=>{try{return readConfig().workbench?.enabled===true;}catch{return false;}},renewalsEnabled:()=>true
  }} as const : undefined;
  const registryContributions = process.env.STUDIO_REGISTRY_CONTRIBUTIONS_CONFIG ? new RegistryContributionsAdapter(process.env.STUDIO_REGISTRY_CONTRIBUTIONS_CONFIG, () => readConfig().contributions, floors, store) : undefined;
  if (!registryContributions) await requireLegacyContributionsAuthority(store);
  const readContributions = () => registryContributions ? registryContributions.read() : readConfig().contributions;
  if (process.env.STUDIO_RETIRE_AZURE_CONTRIBUTION_HISTORY === 'true') {
    if (!registryContributions || !config.contributions?.enabled || !config.contributions.gitLabProjects?.length)
      throw Error('Azure history retirement requires enabled registry-owned GitLab collection');
    await registryContributions.refresh();
    const sourceIds = () => registryContributions.read().repositories.filter(source => source.gitLabProject).map(source => source.sourceId);
    const sources = sourceIds();
    const result = await store.gitContributions({kind:'retire-azure-history',gitLabSourceIds:sources}, () => {
      requireMission(JSON.stringify(sourceIds()) === JSON.stringify(sources), 'AUTHORITY_REVOKED', 'GitLab source admission changed');
    });
    console.log(JSON.stringify({event:'azure_contributions_history_retired',result}));
  }
  const contributions = new GitContributionsCollector(store, readContributions);
  const companySignals = new CompanySignalsCollector(store, () => {const m=readConfig().monitoring;return m?.enabled?m.signals:undefined;});
  const monitoring = new MonitoringController(store, () => readConfig().monitoring);
  const telemetry = new AgentTelemetryCollector(store, () => readConfig().agentTelemetry);
  const authStore = await PostgresAuthStore.open(store, configRealm(config));
  const dashboardCustody = { snapshot: (input: unknown, guard: () => void) => store.dashboardCustody(input, guard) };
  const server = await createStandaloneServer({ authStore, config, authority, bridgeAuthority, readBridge, conversations, native, dashboardCustody, floors, floorRuntime, readContributions, workbenchPreview:workbench, readMembers: () => readConfig().members, readConfig,
    mockupRoot: fileURLToPath(new URL('../../mockup/dist/', import.meta.url)),
    webRoot: fileURLToPath(new URL('../../web/dist/', import.meta.url)) });
  server.addHook('onListen', async () => { registryContributions?.start(); telemetry.start(); contributions.start(); monitoring.start(); companySignals.start(); });
  server.addHook('preClose', async () => { await Promise.all([telemetry.stop(), contributions.stop(), monitoring.stop(), companySignals.stop(), registryContributions?.stop()]); });
  server.addHook('onClose', async () => { await store.close(); });
  let stopping = false;
  for (const signal of ['SIGINT', 'SIGTERM'] as const) process.once(signal, () => {
    if (stopping) return; stopping = true;
    server.close().catch(() => { process.exitCode = 1; });
  });
  try { await server.listen({ port, host }); console.log(`Studio backend listening on port ${port}`); }
  catch { await server.close(); throw Error('Studio could not listen on the configured host and port'); }
} catch (error) { await store.close(); throw error; }
