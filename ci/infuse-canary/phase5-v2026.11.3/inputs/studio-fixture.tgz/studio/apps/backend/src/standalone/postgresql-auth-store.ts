import { createHash } from 'node:crypto';
import type { MissionStore } from '@studio/server';
import { opaque, LOGIN_SECONDS, SESSION_SECONDS, type AuthSession, type LoginTransaction, type BrowserAuthStore } from './auth-store.js';

const hash = (value: string) => createHash('sha256').update(value).digest('hex');
const valid = (token: unknown): token is string => typeof token === 'string' && /^[A-Za-z0-9_-]{43}$/.test(token);

/** SQL happens before admission. Synchronous guards use the session already read
 * for this request, with immediate local revocation, expiry and writer health.
 * The sole authority worker owns every durable auth mutation as well as commands.
 */
export class PostgresAuthStore implements BrowserAuthStore {
  private readonly sessions = new Map<string, AuthSession>();
  private revision = 0;
  private failed = false;
  private constructor(private readonly store: MissionStore) {}

  static async open(store: MissionStore, realm: string): Promise<PostgresAuthStore> {
    await store.authentication({kind: 'realm', realmHash: hash(realm)});
    return new PostgresAuthStore(store);
  }

  private cache(key: string, session: AuthSession): void {
    for (const [id, item] of this.sessions) if (item.expiresAt <= Date.now()) this.sessions.delete(id);
    if (this.sessions.size >= 10000 && !this.sessions.has(key)) this.sessions.delete(this.sessions.keys().next().value!);
    this.sessions.set(key, session);
  }

  async refresh(token: unknown): Promise<void> {
    if (!valid(token) || this.failed) return;
    const key = hash(token), revision = this.revision;
    const body = await this.store.authentication<string | undefined>({kind: 'read-session', idHash: key, now: Date.now()});
    // A concurrent logout may already have invalidated a read queued before it.
    if (revision !== this.revision || this.failed) return;
    if (body) this.cache(key, JSON.parse(body) as AuthSession); else this.sessions.delete(key);
  }

  session(token: unknown): AuthSession | undefined {
    if (!valid(token) || this.failed || !this.store.available()) return;
    const key = hash(token), session = this.sessions.get(key);
    if (session && session.expiresAt > Date.now()) return session;
    this.sessions.delete(key); return;
  }

  async createSession(identity: Pick<AuthSession, 'issuer' | 'subject' | 'profileId'>) {
    if (this.failed) throw Error('Authentication is unavailable');
    const token = opaque(), now = Date.now();
    const session = {...identity, csrfToken: opaque(), expiresAt: now + SESSION_SECONDS * 1000};
    await this.store.authentication({kind: 'create-session', idHash: hash(token), body: JSON.stringify(session), expiresAt: session.expiresAt, now});
    this.cache(hash(token), session); return {token, session};
  }

  async revoke(token: unknown): Promise<void> {
    if (!valid(token)) return;
    const idHash = hash(token); this.revision++; this.sessions.delete(idHash);
    try { await this.store.authentication({kind: 'revoke', idHash}); }
    catch (error) { this.failed = true; this.sessions.clear(); throw error; }
  }

  async createLogin(transaction: Omit<LoginTransaction, 'expiresAt'>): Promise<string> {
    if (this.failed) throw Error('Authentication is unavailable');
    const token = opaque(), now = Date.now(), body = {...transaction, expiresAt: now + LOGIN_SECONDS * 1000};
    await this.store.authentication({kind: 'create-login', idHash: hash(token), body: JSON.stringify(body), expiresAt: body.expiresAt, now});
    return token;
  }

  async consumeLogin(token: unknown): Promise<LoginTransaction | undefined> {
    if (!valid(token) || this.failed) return;
    const body = await this.store.authentication<string | undefined>({kind: 'consume-login', idHash: hash(token), now: Date.now()});
    return body ? JSON.parse(body) as LoginTransaction : undefined;
  }

  async close(): Promise<void> { this.failed = true; this.revision++; this.sessions.clear(); }
}
