import type { FastifyInstance,FastifyRequest,FastifyReply } from 'fastify';
import { whiteboardSpatialCommand } from '@studio/contracts';
import { publishWhiteboardImage,MissionError,type WhiteboardService,type CollaborativeWhiteboardService,type WhiteboardGuard } from '@studio/server';
import { StudioArtifacts,type StudioArtifactsConfig } from './artifacts/service.js';
import { ARTIFACT_CONTENT_SECURITY_POLICY } from './artifacts/preview-security.js';
import { ArtifactRegistryReadError } from './artifacts/read-client.js';

export function registerSpatialWhiteboard(app:FastifyInstance,board:WhiteboardService,text:CollaborativeWhiteboardService,
  config:StudioArtifactsConfig|undefined,admit:(req:FastifyRequest,reply:FastifyReply,write?:boolean)=>WhiteboardGuard,prefix:string) {
  const readers=new Map<string,StudioArtifacts>();
  function reader(project:string) {if(!config)throw new MissionError('ARTIFACTS_UNAVAILABLE','The artifact library is not connected');if(!readers.has(project))readers.set(project,new StudioArtifacts(config,project));return readers.get(project)!;}
  async function verified<T>(action:()=>Promise<T>):Promise<T> {try{return await action();}catch(e){if(e instanceof ArtifactRegistryReadError)throw new MissionError('ARTIFACTS_UNAVAILABLE','This exact source cannot be verified in this project');throw e;}}
  const base=prefix+'/v3';
  app.get(base+'/images/capabilities',(req,reply)=>{const principal=admit(req,reply)();return {enabled:!!(config?.imageUpload?.tokenFiles[principal.projectId] ?? config?.imageUpload?.floorTokenFile)};});
  app.post(base+'/images',{bodyLimit:14*1024*1024},async(req,reply)=>{
    const guard=admit(req,reply,true);const principal=guard();
    if(!(config?.imageUpload?.tokenFiles[principal.projectId] ?? config?.imageUpload?.floorTokenFile))throw new MissionError('ARTIFACTS_UNAVAILABLE','Image uploads are not enabled for this project');
    const manifest=await board.manifest({},guard);
    if(manifest.mode!=='collaborative')throw new MissionError('CONVERSION_REQUIRED','Enable board collaboration before adding images');
    const result=await publishWhiteboardImage(req.body,{registryUrl:config.registryUrl,...config.imageUpload},guard);
    await verified(()=>reader(principal.projectId).image(result.reference));guard();return result;
  });
  app.get(base+'/images/:id/:revision',async(req,reply)=>{
    const params=req.params as {id:string;revision:string};const guard=admit(req,reply);
    const tile=await board.tile(params.id,Number(params.revision),guard);
    if(tile.kind!=='image')throw new MissionError('NOT_FOUND','This image is unavailable');
    const bytes=await verified(()=>reader(guard().projectId).image(tile.reference));
    await board.tile(tile.id,tile.revision,guard);guard();
    return reply.header('Cache-Control','private, no-store').header('X-Content-Type-Options','nosniff').header('Content-Security-Policy',"default-src 'none'; sandbox").header('Content-Disposition','inline; filename="whiteboard-image.webp"').type('image/webp').send(bytes);
  });
  app.get(base,async(req,reply)=> {
    const q=req.query as Record<string,string>;const {after,sectionId,revision,limit,...extra}=q;
    if(Object.keys(extra).length)throw new MissionError('INVALID_INPUT','Unknown manifest query');
    return board.manifest({sectionId,...(after?{after}:{}),...(revision!==undefined?{revision:Number(revision)}:{}),...(limit!==undefined?{limit:Number(limit)}:{})},admit(req,reply));
  });
  for(const kind of ['details','search','render'] as const) app.post(base+'/'+kind,(req,reply)=>board[kind](req.body,admit(req,reply,true)));
  app.post(base+'/commands',async(req,reply)=> {
    const guard=admit(req,reply,true);const parsed=whiteboardSpatialCommand.safeParse(req.body);
    if(!parsed.success)throw new MissionError('INVALID_INPUT','Invalid spatial edit');
    // Recover accepted effects before checking sources which may since have disappeared.
    // The service still checks the exact fingerprint when returning this receipt.
    const receipt=await text.receipt(parsed.data.commandId,guard);
    if(!receipt)for(const op of parsed.data.operations) {
      const ref=op.type==='createHtml'?op.tile.reference:op.type==='updateTile'?op.patch.reference:undefined;
      if(op.type==='createImage')await verified(()=>reader(guard().projectId).image(op.tile.reference));
      if(ref)await verified(()=>reader(guard().projectId).pinned(ref,true));
    }
    guard();return text.spatial(parsed.data,guard);
  });
  app.post(base+'/revert',async(req,reply)=> {
    const guard=admit(req,reply,true);
    const manifest=await board.manifest({},guard);
    return manifest.mode==='collaborative'?text.revert(req.body,guard):board.revert(req.body,guard);
  });
  type TileParams={projectId:string;id:string;revision:string};
  for(const mode of ['status','preview'] as const)app.get<{Params:TileParams}>(base+'/tiles/:id/:revision/'+mode,async(req,reply)=> {
    const guard=admit(req,reply);const tile=await board.tile(req.params.id,Number(req.params.revision),guard);
    if(tile.kind!=='html')throw new MissionError('NOT_FOUND','This HTML tile is unavailable');
    if(mode==='preview' && req.headers['sec-fetch-dest']!=='iframe')throw new MissionError('NOT_FOUND','Preview is only available in a sandboxed frame');
    const q=req.query as Record<string,string>;if(Object.keys(q).some(k=>k!=='verify') || q.verify!==undefined && q.verify!=='1')throw new MissionError('INVALID_INPUT','Invalid preview query');
    const source=await verified(()=>reader(guard().projectId).pinned(tile.reference,mode==='preview'||q.verify==='1'));
    await board.tile(tile.id,tile.revision,guard);guard();
    if(mode==='status')return {status:source.status,latestRevision:source.latestRevision};
    return reply.header('Cache-Control','no-store').header('Referrer-Policy','no-referrer').header('X-Frame-Options','SAMEORIGIN').header('Content-Security-Policy',ARTIFACT_CONTENT_SECURITY_POLICY).type('text/html; charset=utf-8').send(source.body);
  });
}
