import type { BridgePrincipal } from '@studio/contracts';
import { FloorRuntimeService, requireMission, type FloorRuntimeSpec, type MissionStore, type FloorChannelProvider } from '@studio/server';
import { configuredProjects, type StandaloneConfig } from './config.js';
import type { FloorDirectory } from './floors.js';
import { MattermostFloorChannels } from './floor-channels.js';

type CurrentFloors = ReturnType<FloorDirectory['readCurrent']>;

/** A configured shared team supplies identities; floors supply only membership and a name. */
export class FloorRuntimeController {
  readonly service: FloorRuntimeService;
  private abort = new AbortController();
  private timer?: ReturnType<typeof setTimeout>;
  private running?: Promise<void>;
  private cursor = 0;
  constructor(private initial: StandaloneConfig, private readConfig: () => StandaloneConfig,
    private floors: FloorDirectory, store: MissionStore, provider?: FloorChannelProvider) {
    this.service = new FloorRuntimeService(store, provider ?? new MattermostFloorChannels(() => this.template().tokenEnv, this.abort.signal));
  }
  private template(live = this.readConfig()) {
    requireMission(this.initial.floorRuntime?.enabled && live.floorRuntime?.enabled
      && this.initial.floorRuntime.templateProjectId === live.floorRuntime.templateProjectId,
    'EXECUTION_DISABLED', 'Automatic floor connections are disabled');
    const start = configuredProjects(this.initial).find(p => p.id === this.initial.floorRuntime!.templateProjectId)?.nativeMissions;
    const template = configuredProjects(live).find(p => p.id === live.floorRuntime!.templateProjectId)?.nativeMissions;
    requireMission(start?.enabled && template?.enabled && template.cutover && start.installationId === template.installationId
      && start.origin === template.origin && start.tokenEnv === template.tokenEnv && JSON.stringify(start.routes) === JSON.stringify(template.routes),
    'CONFIGURATION', 'The shared team connection needs an operator review');
    return template;
  }
  spec(id: string): FloorRuntimeSpec { return this.specFrom(id, this.floors.readCurrent()); }
  private specFrom(id: string, current: CurrentFloors, template = this.template(current.config)): FloorRuntimeSpec {
    const config = current.config;
    const floor = current.projects.find(p => p.id === id);
    requireMission(floor, 'NOT_FOUND', 'Floor unavailable');
    const existing = floor.nativeMissions;
    requireMission(!existing || existing.installationId === template.installationId && existing.origin === template.origin,
      'CONFIGURATION', 'This floor uses a different team connection');
    const roles = template.routes.map(({ channelId: _channelId, ...route }) => {
      const current = existing?.routes.find(item => item.role === route.role);
      requireMission(!current || ['gatewayId', 'agentId', 'accountId', 'nativeBotUserId', 'nativeUsername'].every(key => current[key as keyof typeof current] === route[key as keyof typeof route]),
        'CONFIGURATION', 'The floor team identity differs from the shared team');
      return { ...route, ...(current ? { channelId: current.channelId } : {}) };
    }).sort((a,b) => a.role.localeCompare(b.role));
    const enrollments = (config.bridge?.gateways ?? []).filter(g => g.enabled)
      .map(g => ({ gatewayId: g.gatewayId, generation: g.generation, agentIds: [...g.agents].sort() })).sort((a,b) => a.gatewayId.localeCompare(b.gatewayId));
    requireMission(roles.every(role => enrollments.some(g => g.gatewayId === role.gatewayId && g.agentIds.includes(role.agentId))),
      'CONFIGURATION', 'The shared team must be currently enrolled');
    // Explicit browser-only partners do not change the native channel audience.
    // Other members still require a verified identity; omission never weakens that gate.
    const nativeProfileIds = floor.memberProfileIds.filter(profileId => config.members.find(member => member.profileId === profileId)?.nativeMember !== false);
    const members = nativeProfileIds.map(profileId => {
      const member = template.members.find(m => m.profileId === profileId);
      requireMission(member, 'IDENTITY_UNAVAILABLE', 'A floor member has no verified conversation identity'); return member;
    }).sort((a,b) => a.profileId.localeCompare(b.profileId));
    return { projectId: id, authorityId: config.authorityId, installationId: template.installationId, origin: template.origin,
      anchorChannelId: (existing?.routes.find(r => r.role === 'coordinator') ?? template.routes.find(r => r.role === 'coordinator'))!.channelId, roles,
      configuredMemberUserIds: [...new Set(existing?.members.map(member => member.userId) ?? [])].sort(),
      memberProfileIds: [...nativeProfileIds].sort(), members, enrollments };
  }
  private complete(id: string, current: CurrentFloors) {
    const project = current.projects.find(p => p.id === id), template = this.template(current.config);
    return project?.nativeMissions && template.routes.every(role => project.nativeMissions!.routes.some(r => r.role === role.role));
  }
  /** Supplied inputs belong to this synchronous check only; defaults always read afresh. */
  config(id: string, protection = false, current = this.floors.readCurrent()): StandaloneConfig {
    return this.configFrom(id, protection, current);
  }
  /** Direct selection avoids deriving unrelated floors at each live guard. */
  findConfiguration(id: string, protection = false): StandaloneConfig | undefined {
    const current = this.floors.readCurrent();
    return current.projects.some(p => p.id === id) ? this.configFrom(id, protection, current) : undefined;
  }
  private configFrom(id: string, protection: boolean, current: CurrentFloors): StandaloneConfig {
    const base = current.baseConfig(id);
    try {
      const template = this.template(current.config), spec = this.specFrom(id, current, template), record = this.service.readCurrent(spec);
      const ready = record?.state === 'ready';
      if (record && (ready || protection && record.state === 'protecting')) return { ...base, nativeMissions: {
        ...template, enabled: ready, routes: record.routes.map(route => ({ ...route })), members: spec.members,
      } };
      const saved = this.service.readRecord(id);
      if (saved?.routes.length === spec.roles.length && spec.roles.every(role => saved.routes.some(route =>
        route.role === role.role && route.gatewayId === role.gatewayId && route.agentId === role.agentId && route.nativeBotUserId === role.nativeBotUserId && route.accountId === role.accountId))) {
        // Preserve known channel custody during enrollment/membership reconciliation.
        return { ...base, nativeMissions: { ...template, enabled: false, routes: saved.routes.map(route => ({ ...route })), members: spec.members } };
      }
      if (base.nativeMissions) return base;
      return { ...base, nativeMissions: { ...template, enabled: false, routes: [], members: spec.members } };
    } catch { return { ...base, nativeMissions: base.nativeMissions ? { ...base.nativeMissions, enabled: false } : undefined }; }
  }
  status(id: string, current?: CurrentFloors): 'ready' | 'connecting' | 'blocked' | 'unconfigured' {
    try {
      current ??= this.floors.readCurrent();
      const record = this.service.readCurrent(this.specFrom(id, current));
      if (!this.service.readRecord(id) && this.complete(id, current)) return 'ready';
      return record?.state === 'ready' ? 'ready' : record?.state === 'blocked' ? 'blocked' : 'connecting';
    } catch { return this.initial.floorRuntime?.enabled ? 'blocked' : 'unconfigured'; }
  }
  configurations(protection = false) {
    const current = this.floors.readCurrent();
    return current.projects.map(p => this.configFrom(p.id, protection, current));
  }
  discovery(principal: BridgePrincipal) {
    return this.configurations(true).flatMap(config => {
      const native = config.nativeMissions;
      if (!native) return [];
      return native.routes.filter(r => r.gatewayId === principal.gatewayId && principal.agents.includes(r.agentId)).flatMap(route =>
        (route.role === 'coordinator' ? native.routes : [route]).map(target => ({
          projectId: config.project.id, installationId: native.installationId, agentId: route.agentId,
          accountId: route.accountId, nativeBotUserId: route.nativeBotUserId, channelId: target.channelId, role: route.role,
        })));
    });
  }
  async open() { await this.service.refresh(); }
  async tick() {
    if (this.abort.signal.aborted || this.running) return this.running;
    this.running = (async () => {
      const projects = this.floors.projects();
      if (!projects.length) return;
      const project = projects[this.cursor++ % projects.length]!;
      try { await this.service.reconcile(() => this.spec(project.id)); }
      catch { /* Safe status is visible to members; no credentials or upstream bodies enter logs. */ }
    })().finally(() => { this.running = undefined; });
    return this.running;
  }
  start() {
    const run = async () => { await this.tick(); if (!this.abort.signal.aborted) { this.timer = setTimeout(run, 2000); this.timer.unref(); } };
    void run();
  }
  async stop() { this.abort.abort(); clearTimeout(this.timer); await this.running; }
}
