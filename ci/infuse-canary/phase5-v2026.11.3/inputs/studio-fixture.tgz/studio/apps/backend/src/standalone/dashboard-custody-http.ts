import { timingSafeEqual } from 'node:crypto';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { MissionError } from '@studio/server';

export interface DashboardCustodyService {
  snapshot(input: unknown, guard: () => void): Promise<unknown>;
}

function tokenBytes(value: unknown): Buffer | undefined {
  if (typeof value !== 'string') return;
  if (/^[a-fA-F0-9]{64}$/.test(value)) return Buffer.from(value, 'hex');
  if (/^[A-Za-z0-9_-]{43}$/.test(value)) {
    const bytes = Buffer.from(value, 'base64url');
    if (bytes.length === 32 && bytes.toString('base64url') === value) return bytes;
  }
}

function loopback(request: FastifyRequest): boolean {
  return ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(request.ip);
}

export function registerDashboardCustodyHttp(app: FastifyInstance, options: {
  authorityId: string; service?: DashboardCustodyService; token?: () => string | undefined;
}): void {
  const service = options.service;
  if (!service) return;
  const readToken = options.token ?? (() => process.env.STUDIO_DASHBOARD_CUSTODY_TOKEN);
  app.post('/api/dashboard/v1/custody', async (request: FastifyRequest, reply: FastifyReply) => {
    if (Object.keys(request.query as object).length) throw new MissionError('INVALID_INPUT', 'Dashboard custody query parameters are not supported');
    if (!loopback(request)) throw new MissionError('BRIDGE_TRANSPORT_REQUIRED', 'Dashboard custody requires the private Studio transport');
    const header = request.headers.authorization;
    const supplied = typeof header === 'string' && header.startsWith('Bearer ') ? tokenBytes(header.slice(7)) : undefined;
    const expected = tokenBytes(readToken());
    const matches = timingSafeEqual(supplied ?? Buffer.alloc(32), expected ?? Buffer.alloc(32, 1));
    if (!supplied || !expected || !matches || request.headers['x-studio-authority'] !== options.authorityId) {
      throw new MissionError('BRIDGE_UNAUTHENTICATED', 'Dashboard custody client could not be authenticated');
    }
    const current = () => {
      if (request.raw.aborted || reply.raw.destroyed) throw new MissionError('AUTHORITY_REVOKED', 'Dashboard custody request ended before admission');
      const latest = tokenBytes(readToken());
      if (!latest || !timingSafeEqual(supplied, latest)) throw new MissionError('AUTHORITY_REVOKED', 'Dashboard custody credential changed before admission');
    };
    const result = await service.snapshot(request.body, current);
    current();
    return result;
  });
}
