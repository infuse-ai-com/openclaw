import { missionIdentifier, type BridgePrincipal } from '@studio/contracts';
import { requireMission } from '@studio/server';
import { configuredProjects, projectConfig, type StandaloneConfig } from './config.js';
import { NativeBridgeService } from './native-bridge.js';

type Options = ConstructorParameters<typeof NativeBridgeService>[0] & {
  projectConfigs?: () => StandaloneConfig[]; protectionConfigs?: () => StandaloneConfig[];
  projectConfig?: (id: string, protection: boolean) => StandaloneConfig | undefined;
  discover?: (principal: BridgePrincipal) => unknown[];
  automaticFloors?: boolean;
};
/** One authority/writer and enrollment, with project-local conversations and controls. */
export class NativeProjectsBridge {
  private services = new Map<string, NativeBridgeService>();
  private cursors = new Map<string, number>();
  constructor(private options: Options) {
    this.refresh();
  }
  private configurations(protection = false): StandaloneConfig[] {
    const read = protection ? this.options.protectionConfigs : this.options.projectConfigs;
    const dynamic = read?.();
    if (dynamic && !protection) return dynamic;
    const current = this.options.readConfig();
    if (dynamic && protection) for (const project of configuredProjects(current)) {
      if (project.nativeMissions && !dynamic.some(p => p.project.id === project.id)) dynamic.push(projectConfig(current, project.id));
    }
    return dynamic ?? configuredProjects(current).map(p => projectConfig(current, p.id));
  }
  private selected(id: string, protection = false) {
    let config: StandaloneConfig | undefined;
    if (this.options.projectConfig) {
      config = this.options.projectConfig(id, protection);
      // Retired configured channels retain custody without enabling ordinary intake.
      // This is the same configured fallback used by configurations(true).
      if (!config && protection) {
        const current = this.options.readConfig();
        if (configuredProjects(current).some(p => p.id === id && p.nativeMissions)) config = projectConfig(current, id);
      }
    } else config = this.configurations(protection).find(p => p.project.id === id);
    requireMission(config?.nativeMissions, 'FORBIDDEN', 'Native floor is unavailable'); return config;
  }
  private refresh(configurations = this.configurations()) {
    for (const config of configurations) if (config.nativeMissions && !this.services.has(config.project.id)) {
      // The workspace startup flag is the upper bound. A pending dynamic floor becomes
      // executable only when its live configuration has verified every protected route.
      const startup = configuredProjects(this.options.config).find(project => project.id === config.project.id)?.nativeMissions;
      const initial = { ...config, nativeMissions: { ...config.nativeMissions, enabled: startup?.enabled ?? this.options.automaticFloors === true } };
      this.services.set(config.project.id, new NativeBridgeService({ ...this.options, config: initial,
        readConfig: () => this.selected(config.project.id) }));
    }
  }
  forProject(id: string) {
    this.refresh(); this.selected(id);
    const service = this.services.get(id); requireMission(service, 'FORBIDDEN', 'Native project is not configured'); return service;
  }
  async request(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal): Promise<unknown> {
    const v = input as Record<string, unknown>;
    requireMission(v?.version === 2 && typeof v.kind === 'string', 'INVALID_INPUT', 'Native bridge version 2 is required');
    if (v.kind === 'floor-routes') {
      requireMission(Object.keys(v).every(key => ['version', 'kind'].includes(key)), 'INVALID_INPUT', 'Invalid route discovery request');
      const live = current();
      requireMission(live.gatewayId === principal.gatewayId && live.generation === principal.generation && JSON.stringify(live.agents) === JSON.stringify(principal.agents), 'AUTHORITY_REVOKED', 'Gateway enrollment changed');
      const routes = this.options.discover?.(live) ?? [];
      requireMission(routes.length <= 4096, 'CONFIGURATION', 'Too many floor routes');
      return { version: 2, kind: v.kind, value: routes };
    }
    const configurations = this.configurations();
    this.refresh(configurations);
    if (v.kind === 'claim' || v.kind === 'provision-next') {
      // Rotate the first project considered. Durable receipts retain their original project
      // across retries and process restarts; every child still uses the global agent mutex.
      const services = configurations.filter(p => p.nativeMissions).map(p => this.services.get(p.project.id)!); const key = `${principal.gatewayId}:${v.kind}`;
      const start = this.cursors.get(key) ?? 0;
      for (let i = 0; i < services.length; i++) {
        const index = (start + i) % services.length; const service = services[index]!;
        if (!service.enabled()) continue;
        const result = await service.request(input, principal, current);
        if ((result as { value: unknown }).value !== null) { this.cursors.set(key, (index + 1) % services.length); return result; }
      }
      return { version: 2, kind: v.kind, value: null };
    }
    if (v.kind === 'managed-message' || v.kind === 'route-protected') {
      const source = (v.kind === 'route-protected' ? v.route : v.source) as Record<string, unknown> | undefined;
      const project = this.configurations(v.kind === 'route-protected').find(p => p.nativeMissions?.installationId === source?.installationId
        && p.nativeMissions?.routes.some(r => r.channelId === source?.channelId));
      if (!project && v.kind === 'managed-message') { current(); return { version: 2, kind: v.kind, value: { disposition: 'blocked', reason: 'Floor is unavailable' } }; }
      requireMission(project, 'FORBIDDEN', 'Channel is not enrolled in a Studio project');
      if (v.kind === 'route-protected') return new NativeBridgeService({ ...this.options, config: project,
        readConfig: () => this.selected(project.project.id, true) }).request(input, principal, current);
      return this.forProject(project.project.id).request(input, principal, current);
    }
    const reference = ['inspect-provision', 'admit-provision', 'observe-provision', 'reconcile-provision'].includes(v.kind) ? 'effect' : 'action';
    let id: string;
    try { id = missionIdentifier(reference === 'effect' ? v.effectId : v.actionId); }
    catch { requireMission(false, 'INVALID_INPUT', 'An exact native operation reference is required'); }
    // The authenticated child validates ownership of this reference. The client never
    // selects a project for an action, run or effect, and receives no lookup metadata.
    const projectId = await this.options.store.native<string>({ kind: 'route-project', reference, id }, () => { current(); });
    return this.forProject(projectId).request(input, principal, current);
  }
}
