import { parseRegistryCodeConnection, type RegistryCodeConnection } from '@studio/server';
import { parseFloorSetupConfig, type FloorSetupConfig } from '@studio/server';
import {parseMonitoringConfig,withMonitoringSystems,type MonitoringConfig} from '@studio/server';
import { parseGitContributionsConfig, registryGitCredentialBindings, type GitContributionsConfig } from '@studio/server';
import { parseAgentTelemetryConfig, type AgentTelemetryConfig } from '@studio/server';
import { parseAppsAccessPolicy, type AppsAccessPolicy } from '@studio/server';
import { parseWhiteboardMcpConfig, type WhiteboardMcpConfig, parseMachineConfig, type MachineConfig } from '@studio/server';
import { parseKnowledgeConfig, parseKnowledgeManagementConfig, type KnowledgeConfig, type KnowledgeManagementConfig, type StudioComputerWorkspace } from '@studio/server';
import { parseArtifactsConfig, type StudioArtifactsConfig } from './artifacts/service.js';
import { readConfigurationSource, reuseConfiguration, type ConfigurationSourceReader } from './configuration-sources.js';
import { isAbsolute, resolve } from 'node:path';
import { whiteboardAgentAccessConfig, type WhiteboardAgentAccessConfig, mattermostId, missionIdentifier, parseConversationRoute, type ConversationRoute, type RuntimeTarget, type FloorManagerPolicy } from '@studio/contracts';
import { parseNativeMissionsConfig, type NativeMissionsConfig } from './native-config.js';

export interface StudioMember { issuer: string; subject: string; profileId: string; displayName?: string; approver: boolean; validUntil?: string; canManageFloors?: boolean; nativeMember?: boolean }
export interface BridgeGateway { gatewayId: string; generation: number; agents: string[]; tokenEnv: string; enabled: boolean }
export interface StandaloneBridgeConfig { enabled: boolean; gateways: BridgeGateway[]; allowInsecureLoopback?: boolean }
export interface StandaloneMattermostConfig extends ConversationRoute {
  enabled: boolean; tokenEnv: string; pollIntervalMs?: number; coordinatorResponsesEnabled?: boolean; members: { userId: string; profileId: string }[];
}
export interface StudioProject { id: string; name: string; memberProfileIds: string[]; kind?: 'company'; nativeMissions?: NativeMissionsConfig }
export interface StandaloneWorkbenchConfig {
  enabled: boolean; gatewayOrigin: string; gatewayServerName: string; grantIssuer: string; clientRoot: string;
  clientCertFile: string; clientKeyFile: string; caFile: string; signingPrivateKeyFile: string; signingKeyId: string;
  workspaces: StudioComputerWorkspace[];
}
export interface StandaloneConfig {
  floorSetup?: FloorSetupConfig;
  monitoring?: MonitoringConfig;
  repositoryRegistry?: RegistryCodeConnection;
  contributions?: GitContributionsConfig;
  agentTelemetry?: AgentTelemetryConfig;
  apps?: AppsAccessPolicy;
  machine?: MachineConfig;
  whiteboardMcp?: WhiteboardMcpConfig;
  floorManagement?: FloorManagerPolicy;
  floorRuntime?: { enabled: boolean; templateProjectId: string };
  knowledgeManagement?: KnowledgeManagementConfig;
  whiteboardCollaboration?: boolean;
  whiteboardAgents?: WhiteboardAgentAccessConfig;
  authorityId: string; origin: string;
  storage?: { backend: 'postgresql'; connectionEnv: string; caFile: string };
  project: { id: string; name: string; memberProfileIds?: string[] }; projects?: StudioProject[]; targets: RuntimeTarget[];
  oidc: { issuer: string; clientId: string; clientSecretEnv?: string; allowInsecureLoopback?: boolean };
  members: StudioMember[]; bridge?: StandaloneBridgeConfig; mattermost?: StandaloneMattermostConfig;
  nativeMissions?: NativeMissionsConfig; artifacts?: StudioArtifactsConfig; knowledge?: KnowledgeConfig; workbench?: StandaloneWorkbenchConfig;
}
const object = (value: unknown): Record<string, unknown> => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Expected a configuration object');
  return value as Record<string, unknown>;
};
function keys(value: Record<string, unknown>, allowed: string[]) {
  if (Object.keys(value).some(key => !allowed.includes(key))) throw Error('Unknown Studio configuration field');
}
function text(value: unknown, max = 256): string {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\u0000-\u001f\u007f]/u.test(value)) throw Error('Invalid Studio configuration string');
  return value;
}
function identifier(value: unknown): string {
  return missionIdentifier(value);
}
export function loopback(url: URL): boolean { return ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname); }
function endpoint(value: unknown): URL {
  const url = new URL(text(value, 2048));
  if (url.username || url.password || url.hash || url.search || !['https:', 'http:'].includes(url.protocol)) throw Error('Invalid Studio endpoint');
  if (url.protocol === 'http:' && !loopback(url)) throw Error('HTTP is only permitted on loopback');
  return url;
}
function path(value: unknown): string {
  const result = text(value, 4096); if (!isAbsolute(result)) throw Error('Studio database paths must be absolute'); return resolve(result);
}
export function parseStandaloneConfig(value: unknown): StandaloneConfig {
  return parseConfiguration(value, readConfigurationSource);
}
function parseConfiguration(value: unknown, read: ConfigurationSourceReader): StandaloneConfig {
  const root = object(value); keys(root, ['storage', 'authorityId', 'databasePath', 'authDatabasePath', 'origin', 'project', 'targets', 'oidc', 'members', 'bridge', 'mattermost', 'nativeMissions', 'artifacts', 'projects', 'knowledge', 'whiteboardCollaboration', 'whiteboardAgents', 'whiteboardMcp', 'whiteboardMcpConfigFile', 'workbench', 'floorManagement', 'knowledgeManagement', 'floorRuntime', 'machine', 'apps', 'agentTelemetry', 'contributions', 'monitoring', 'floorSetup', 'repositoryRegistry']);
  const project = object(root.project); keys(project, ['id', 'name', 'memberProfileIds']);
  const oidc = object(root.oidc); keys(oidc, ['issuer', 'clientId', 'clientSecretEnv', 'allowInsecureLoopback']);
  const origin = endpoint(root.origin); if (origin.pathname !== '/') throw Error('Studio origin cannot include a path');
  const issuer = endpoint(oidc.issuer);
  if (oidc.allowInsecureLoopback !== undefined && typeof oidc.allowInsecureLoopback !== 'boolean') throw Error('Invalid loopback configuration');
  if (oidc.allowInsecureLoopback === true && !(loopback(origin) && loopback(issuer))) throw Error('Insecure OIDC is only permitted for a loopback Studio and issuer');
  if (issuer.protocol === 'http:' && !(oidc.allowInsecureLoopback === true && loopback(origin))) throw Error('HTTP OIDC requires explicit loopback-only configuration');
  if (!Array.isArray(root.members) || root.members.length > 1000 || !Array.isArray(root.targets) || root.targets.length > 100) throw Error('Invalid configured membership or targets');
  const members = root.members.map(value => {
    const item = object(value); keys(item, ['issuer', 'subject', 'profileId', 'displayName', 'approver', 'validUntil', 'canManageFloors', 'nativeMember']);
    if (typeof item.approver !== 'boolean') throw Error('A member needs an explicit approver role');
    const result: StudioMember = { issuer: text(item.issuer, 2048), subject: text(item.subject, 1024), profileId: text(item.profileId, 8192), approver: item.approver };
    if (item.validUntil !== undefined) {
      const stamp = text(item.validUntil, 40);
      if (!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(stamp) || !Number.isFinite(Date.parse(stamp))
        || new Date(stamp).toISOString().slice(0, 19) !== stamp.slice(0, 19)) throw Error('Invalid member expiry');
      result.validUntil = new Date(stamp).toISOString();
    }
    if (item.canManageFloors !== undefined) {
      if (typeof item.canManageFloors !== 'boolean') throw Error('Invalid member management ceiling');
      result.canManageFloors = item.canManageFloors;
    }
    if (item.nativeMember !== undefined) {
      if (typeof item.nativeMember !== 'boolean') throw Error('Invalid native member policy');
      result.nativeMember = item.nativeMember;
    }
    if (result.issuer !== oidc.issuer) throw Error('Member issuer must equal the configured issuer');
    if (item.displayName !== undefined) result.displayName = text(item.displayName, 256);
    return result;
  });
  if (new Set(members.map(m => JSON.stringify([m.issuer, m.subject]))).size !== members.length
    || new Set(members.map(m => m.profileId)).size !== members.length) throw Error('Duplicate Studio membership identity');
  const targets = root.targets.map(value => { const item = object(value); keys(item, ['gatewayId', 'agentId']); return { gatewayId: identifier(item.gatewayId), agentId: identifier(item.agentId) }; });
  if (new Set(targets.map(t => JSON.stringify(t))).size !== targets.length) throw Error('Duplicate Studio target');
  const config: StandaloneConfig = { authorityId: identifier(root.authorityId),
    origin: origin.origin, project: { id: identifier(project.id), name: text(project.name) }, targets,
    oidc: { issuer: text(oidc.issuer, 2048), clientId: text(oidc.clientId), ...(oidc.allowInsecureLoopback === true ? { allowInsecureLoopback: true } : {}) }, members };
  if (root.storage !== undefined) {
    const storage = object(root.storage); keys(storage, ['backend', 'connectionEnv', 'caFile']);
    if (storage.backend !== 'postgresql' || typeof storage.connectionEnv !== 'string' || !/^[A-Z][A-Z0-9_]{2,127}$/.test(storage.connectionEnv)) throw Error('Invalid explicit PostgreSQL configuration');
    config.storage = {backend: 'postgresql', connectionEnv: storage.connectionEnv, caFile: path(storage.caFile)};
    // Older mounted configs may contain inert file paths. They never enter
    // effective configuration; every process entry requires PostgreSQL.
    // Tests may inject a PostgreSQL store/auth pair without connection config.
  } else if (process.env.NODE_ENV === 'production') {
    throw Error('Studio requires PostgreSQL; central SQLite is retired');
  }
  if (root.apps !== undefined) {
    config.apps = parseAppsAccessPolicy(root.apps, config.oidc.issuer);
    for (const entry of config.apps.identities) {
      const member = members.find(m => m.issuer === entry.issuer && m.subject === entry.subject);
      if ((member && member.profileId !== entry.profileId) || members.some(m => m.profileId === entry.profileId && m.subject !== entry.subject)) throw Error('App/member identities disagree');
    }
  }
  if (root.monitoring !== undefined) config.monitoring = parseMonitoringConfig(root.monitoring);
  if (root.repositoryRegistry !== undefined) config.repositoryRegistry=parseRegistryCodeConnection(root.repositoryRegistry);
  if (root.contributions !== undefined) config.contributions = parseGitContributionsConfig(root.contributions);
  if (root.agentTelemetry !== undefined) config.agentTelemetry = parseAgentTelemetryConfig(root.agentTelemetry, targets);
  if (root.whiteboardMcpConfigFile !== undefined) {
    if (root.whiteboardMcp !== undefined) throw Error('Whiteboard MCP configuration must have one source');
    config.whiteboardMcp = parseWhiteboardMcpConfig(object(JSON.parse(read(path(root.whiteboardMcpConfigFile), true))));
  } else if (root.whiteboardMcp !== undefined) config.whiteboardMcp = parseWhiteboardMcpConfig(root.whiteboardMcp);
  if (root.machine !== undefined) config.machine = parseMachineConfig(root.machine);
  if (root.artifacts !== undefined) config.artifacts = parseArtifactsConfig(root.artifacts);
  if (root.nativeMissions !== undefined) config.nativeMissions = parseNativeMissionsConfig(root.nativeMissions, targets);
  if (root.whiteboardAgents !== undefined) config.whiteboardAgents = whiteboardAgentAccessConfig.parse(root.whiteboardAgents);
  if (root.whiteboardCollaboration !== undefined) {
    if (typeof root.whiteboardCollaboration !== 'boolean') throw Error('Invalid whiteboard collaboration setting');
    config.whiteboardCollaboration = root.whiteboardCollaboration;
  }
  if (oidc.clientSecretEnv !== undefined) {
    const env = text(oidc.clientSecretEnv); if (!/^[A-Z][A-Z0-9_]*$/.test(env)) throw Error('Invalid client secret environment reference'); config.oidc.clientSecretEnv = env;
  }
  if (root.bridge !== undefined) {
    const bridge = object(root.bridge); keys(bridge, ['enabled', 'gateways', 'allowInsecureLoopback']);
    if (typeof bridge.enabled !== 'boolean' || !Array.isArray(bridge.gateways) || bridge.gateways.length > 100
      || (bridge.allowInsecureLoopback !== undefined && typeof bridge.allowInsecureLoopback !== 'boolean')) throw Error('Invalid Studio bridge configuration');
    if (bridge.allowInsecureLoopback === true && !loopback(origin)) throw Error('Insecure bridge transport is only permitted on loopback');
    if (bridge.enabled && origin.protocol !== 'https:' && bridge.allowInsecureLoopback !== true) throw Error('HTTP bridge requires explicit loopback-only configuration');
    const gateways = bridge.gateways.map(value => {
      const item = object(value); keys(item, ['gatewayId', 'generation', 'agents', 'tokenEnv', 'enabled']);
      if (typeof item.enabled !== 'boolean' || !Number.isSafeInteger(item.generation) || Number(item.generation) < 1
        || !Array.isArray(item.agents) || !item.agents.length || item.agents.length > 100) throw Error('Invalid Gateway enrollment');
      const gatewayId = identifier(item.gatewayId); const agents = item.agents.map(identifier);
      if (new Set(agents).size !== agents.length || agents.some(agentId => !targets.some(target => target.gatewayId === gatewayId && target.agentId === agentId))) throw Error('Enrolled agents must be unique configured runtime targets');
      const tokenEnv = text(item.tokenEnv); if (!/^[A-Z][A-Z0-9_]*$/.test(tokenEnv)) throw Error('Invalid Gateway token environment reference');
      return { gatewayId, generation: Number(item.generation), agents, tokenEnv, enabled: item.enabled };
    });
    if (new Set(gateways.map(gateway => gateway.gatewayId)).size !== gateways.length
      || new Set(gateways.map(gateway => gateway.tokenEnv)).size !== gateways.length) throw Error('Duplicate Gateway enrollment or token reference');
    config.bridge = { enabled: bridge.enabled, gateways, ...(bridge.allowInsecureLoopback === true ? { allowInsecureLoopback: true } : {}) };
  }
  if (root.mattermost !== undefined) {
    const mm = object(root.mattermost); keys(mm, ['enabled', 'installationId', 'origin', 'botUserId', 'channelId', 'tokenEnv', 'pollIntervalMs', 'coordinatorResponsesEnabled', 'members']);
    if (typeof mm.enabled !== 'boolean' || !Array.isArray(mm.members) || mm.members.length > 1000) throw Error('Invalid Mattermost configuration');
    if (mm.coordinatorResponsesEnabled !== undefined && typeof mm.coordinatorResponsesEnabled !== 'boolean') throw Error('Invalid coordinator response configuration');
    const route = parseConversationRoute({ installationId: mm.installationId, origin: mm.origin, botUserId: mm.botUserId, channelId: mm.channelId });
    const tokenEnv = text(mm.tokenEnv); if (!/^[A-Z][A-Z0-9_]*$/.test(tokenEnv)) throw Error('Invalid Mattermost token environment reference');
    if (mm.pollIntervalMs !== undefined && (!Number.isSafeInteger(mm.pollIntervalMs) || Number(mm.pollIntervalMs) < 1000 || Number(mm.pollIntervalMs) > 300000)) throw Error('Invalid Mattermost poll interval');
    const mappings = mm.members.map(value => {
      const item = object(value); keys(item, ['userId', 'profileId']);
      return { userId: mattermostId(item.userId), profileId: text(item.profileId, 8192) };
    });
    if (new Set(mappings.map(item => item.userId)).size !== mappings.length || new Set(mappings.map(item => item.profileId)).size !== mappings.length
      || mappings.some(item => item.userId === route.botUserId)) throw Error('Duplicate or bot Mattermost member mapping');
    config.mattermost = { ...route, enabled: mm.enabled, tokenEnv, members: mappings,
      ...(mm.coordinatorResponsesEnabled === undefined ? {} : { coordinatorResponsesEnabled: mm.coordinatorResponsesEnabled }),
      ...(mm.pollIntervalMs === undefined ? {} : { pollIntervalMs: Number(mm.pollIntervalMs) }) };
  }
  if (project.memberProfileIds !== undefined) {
    if (!Array.isArray(project.memberProfileIds)) throw Error('Project members must be explicit');
    const ids = project.memberProfileIds.map(identifier);
    if (new Set(ids).size !== ids.length || ids.some(id => !members.some(m => m.profileId === id))) throw Error('Project members must be enrolled Studio profiles');
    config.project.memberProfileIds = ids;
  }
  if (root.projects !== undefined) {
    if (!Array.isArray(root.projects) || root.projects.length > 100) throw Error('Invalid additional projects');
    config.projects = root.projects.map(value => {
      const p = object(value); keys(p, ['id', 'name', 'memberProfileIds', 'nativeMissions', 'kind']);
      if (!Array.isArray(p.memberProfileIds)) throw Error('Project members must be explicit');
      const memberProfileIds = p.memberProfileIds.map(identifier);
      if (new Set(memberProfileIds).size !== memberProfileIds.length || memberProfileIds.some(id => !members.some(m => m.profileId === id))) throw Error('Project members must be enrolled Studio profiles');
      // Legacy company markers no longer reserve a name, address or execution policy.
      if (p.kind !== undefined && p.kind !== 'company') throw Error('Invalid project kind');
      const kind = p.kind === 'company' ? { kind: 'company' as const } : {};
      if (p.nativeMissions === undefined) return { id: identifier(p.id), name: text(p.name), memberProfileIds, ...kind };
      const nativeMissions = parseNativeMissionsConfig(p.nativeMissions, targets);
      if (!nativeMissions.cutover || nativeMissions.members.some(m => !memberProfileIds.includes(m.profileId))) throw Error('Additional projects require native cutover and explicit human membership');
      return { id: identifier(p.id), name: text(p.name), memberProfileIds, nativeMissions, ...kind };
    });
    if (new Set([config.project.id, ...config.projects.map(p => p.id)]).size !== config.projects.length + 1) throw Error('Duplicate Studio project');
  }
  const nativeMappings = [config.mattermost?.members ?? [], ...configuredProjects(config).map(p => p.nativeMissions?.members ?? [])].flat();
  if (nativeMappings.some(mapping => members.some(member => member.profileId === mapping.profileId && member.nativeMember === false)))
    throw Error('A browser-only member cannot have a native conversation identity');
  const channels = new Map<string, string>();
  for (const p of configuredProjects(config)) for (const route of p.nativeMissions?.routes ?? []) {
    const key = JSON.stringify([p.nativeMissions!.installationId, route.channelId]);
    if (channels.has(key) && channels.get(key) !== p.id) throw Error('A native channel cannot belong to multiple projects');
    channels.set(key, p.id);
  }
  if (root.knowledge !== undefined) config.knowledge = parseKnowledgeConfig(root.knowledge);
  if (root.knowledgeManagement !== undefined) config.knowledgeManagement = parseKnowledgeManagementConfig(root.knowledgeManagement);
  if (root.workbench !== undefined) {
    const wb = object(root.workbench); keys(wb, ['enabled', 'gatewayOrigin', 'gatewayServerName', 'grantIssuer', 'clientRoot', 'clientCertFile', 'clientKeyFile', 'caFile', 'signingPrivateKeyFile', 'signingKeyId', 'workspaces']);
    if (typeof wb.enabled !== 'boolean' || !Array.isArray(wb.workspaces) || wb.workspaces.length > 100) throw Error('Invalid Workbench configuration');
    const gateway = endpoint(wb.gatewayOrigin); if (gateway.protocol !== 'https:' || gateway.pathname !== '/' || !gateway.hostname.endsWith('.svc.cluster.local')) throw Error('Workbench gateway requires an internal HTTPS origin without a path');
    const dns = (value: unknown) => { const result=text(value,253); if(!/^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])$/.test(result)||!result.includes('.'))throw Error('Invalid Workbench service name'); return result; };
    const workspaces = wb.workspaces.map(value => {
      const item=object(value);keys(item,['workspaceId','environmentId','generation','authorizationRevision','operatorProfileIds']);
      if(!Number.isSafeInteger(item.generation)||Number(item.generation)<1||!Number.isSafeInteger(item.authorizationRevision)||Number(item.authorizationRevision)<1||!Array.isArray(item.operatorProfileIds))throw Error('Invalid Workbench workspace');
      const operatorProfileIds=item.operatorProfileIds.map(identifier);
      if(!operatorProfileIds.length||new Set(operatorProfileIds).size!==operatorProfileIds.length||operatorProfileIds.some(id=>!members.some(member=>member.profileId===id)))throw Error('Workbench operators must be explicitly enrolled Studio profiles');
      return {workspaceId:identifier(item.workspaceId),environmentId:identifier(item.environmentId),generation:Number(item.generation),authorizationRevision:Number(item.authorizationRevision),operatorProfileIds};
    });
    if(wb.enabled&&workspaces.length!==1)throw Error('The first Workbench pilot requires exactly one workspace');
    config.workbench={enabled:wb.enabled,gatewayOrigin:gateway.origin,gatewayServerName:dns(wb.gatewayServerName),grantIssuer:identifier(wb.grantIssuer),clientRoot:path(wb.clientRoot),
      clientCertFile:path(wb.clientCertFile),clientKeyFile:path(wb.clientKeyFile),caFile:path(wb.caFile),signingPrivateKeyFile:path(wb.signingPrivateKeyFile),signingKeyId:identifier(wb.signingKeyId),workspaces};
  }
  if (root.floorSetup !== undefined) config.floorSetup = parseFloorSetupConfig(root.floorSetup);
  if (root.floorRuntime !== undefined) {
    const runtime = object(root.floorRuntime); keys(runtime, ['enabled', 'templateProjectId']);
    if (typeof runtime.enabled !== 'boolean') throw Error('Floor runtime requires explicit activation');
    const templateProjectId = identifier(runtime.templateProjectId);
    const template = configuredProjects(config).find(project => project.id === templateProjectId)?.nativeMissions;
    if (!template?.cutover) throw Error('Floor runtime requires an existing native shared-team template');
    config.floorRuntime = { enabled: runtime.enabled, templateProjectId };
  }
  if (root.floorManagement !== undefined) {
    const managers = object(root.floorManagement); keys(managers, ['humanProfileIds', 'agents', 'allMembers', 'allEnrolledAgents']);
    for (const flag of ['allMembers', 'allEnrolledAgents']) if (managers[flag] !== undefined && typeof managers[flag] !== 'boolean') throw Error('Invalid floor management enrollment policy');
    if (!Array.isArray(managers.humanProfileIds) || managers.humanProfileIds.length > 100 || !Array.isArray(managers.agents) || managers.agents.length > 100) throw Error('Invalid floor management policy');
    const humanProfileIds = managers.humanProfileIds.map(value => text(value, 256));
    const agents = managers.agents.map(value => { const agent = object(value); keys(agent, ['gatewayId', 'agentId']); return { gatewayId: identifier(agent.gatewayId), agentId: identifier(agent.agentId) }; });
    if (new Set(humanProfileIds).size !== humanProfileIds.length || humanProfileIds.some(id => !members.some(member => member.profileId === id))
      || new Set(agents.map(a => JSON.stringify(a))).size !== agents.length
      || agents.some(a => !config.bridge?.gateways.some(g => g.gatewayId === a.gatewayId && g.agents.includes(a.agentId)))) throw Error('Floor managers must be explicitly enrolled humans or Gateway agents');
    config.floorManagement = { humanProfileIds, agents, allMembers: managers.allMembers === true, allEnrolledAgents: managers.allEnrolledAgents === true };
  }
  return config;
}
export function loadStandaloneConfig(file: string | undefined, workbenchFile?: string, floorsFile?: string, machineFile?: string, operationsFile?: string): StandaloneConfig {
  return loadConfiguration(readConfigurationSource, file, workbenchFile, floorsFile, machineFile, operationsFile);
}
function loadConfiguration(read: ConfigurationSourceReader, file: string | undefined, workbenchFile?: string, floorsFile?: string, machineFile?: string, operationsFile?: string): StandaloneConfig {
  if (!file || !isAbsolute(file)) throw Error('Set STUDIO_CONFIG to an absolute JSON configuration path with OIDC and explicit members');
  if (workbenchFile !== undefined && !isAbsolute(workbenchFile)) throw Error('Set STUDIO_WORKBENCH_CONFIG to an absolute JSON configuration path');
  if (floorsFile !== undefined && !isAbsolute(floorsFile)) throw Error('Set STUDIO_FLOORS_CONFIG to an absolute JSON configuration path');
  if (machineFile !== undefined && !isAbsolute(machineFile)) throw Error('Set STUDIO_MACHINE_CONFIG to an absolute JSON configuration path');
  if (operationsFile !== undefined && !isAbsolute(operationsFile)) throw Error('Set STUDIO_OPERATIONS_CONFIG to an absolute JSON configuration path');
  try {
    const root = object(JSON.parse(read(file)));
    const storageFile = process.env.STUDIO_STORAGE_CONFIG;
    if (storageFile !== undefined) {
      if (!isAbsolute(storageFile) || root.storage !== undefined) throw Error('Storage configuration must have one absolute file source');
      const storage = object(JSON.parse(read(storageFile, true)));
      if (Object.keys(storage).length) root.storage = storage;
    }
    if (machineFile !== undefined) {
      if (root.machine !== undefined) throw Error('Machine configuration must have one source');
      root.machine = JSON.parse(read(machineFile));
    }
    if (workbenchFile !== undefined) {
      if (root.workbench !== undefined) throw Error('Workbench configuration must have one source');
      root.workbench = JSON.parse(read(workbenchFile));
    }
    if (floorsFile !== undefined) {
      const floors = object(JSON.parse(read(floorsFile)));
      keys(floors, ['floorManagement', 'knowledgeManagement', 'floorRuntime', 'artifacts', 'whiteboardAgents', 'whiteboardMcpConfigFile']);
      for (const [key, value] of Object.entries(floors)) {
        if (root[key] !== undefined) throw Error('Floor configuration must have one source');
        root[key] = value;
      }
    }
    if (operationsFile !== undefined) {
      const operations = object(JSON.parse(read(operationsFile, true)));
      keys(operations, ['apps', 'agentTelemetry', 'contributions', 'monitoring', 'artifacts', 'floorSetup']);
      for (const [key, value] of Object.entries(operations)) {
        if (root[key] !== undefined) throw Error('Operational configuration must have one source');
        root[key] = value;
      }
    }
    const registryFile = process.env.STUDIO_REGISTRY_MANAGER_CONFIG;
    if (registryFile !== undefined) {
      if (!isAbsolute(registryFile) || root.repositoryRegistry !== undefined) throw Error('Registry manager configuration must have one absolute file source');
      root.repositoryRegistry = object(JSON.parse(read(registryFile, true)));
    }
    if (process.env.STUDIO_REGISTRY_BINDINGS_ONLY === 'true') {
      if (!process.env.STUDIO_REGISTRY_CONTRIBUTIONS_CONFIG || !root.contributions) throw Error('Registry credential bindings require policy configuration');
      root.contributions = registryGitCredentialBindings(root.contributions);
    }
    const config=parseConfiguration(root,read);
    const systems=process.env.STUDIO_MONITORING_SYSTEMS;
    if(systems!==undefined){
      if(!config.monitoring)throw Error('System labels require configured monitoring');
      config.monitoring=withMonitoringSystems(config.monitoring,systems);
    }
    const lifecycleFiles=process.env.STUDIO_ARTIFACT_LIFECYCLE_TOKEN_FILES;
    if(lifecycleFiles!==undefined){
      if(!config.artifacts||config.artifacts.lifecycle||Buffer.byteLength(lifecycleFiles)>2048)throw Error('Lifecycle token paths require one configured artifact owner');
      const tokenFiles=object(JSON.parse(lifecycleFiles));
      if(!Object.keys(tokenFiles).length||Object.keys(tokenFiles).length>8)throw Error('Invalid lifecycle project paths');
      config.artifacts=parseArtifactsConfig({...config.artifacts,lifecycle:{tokenFiles}});
    }
    return config;
  }
  catch { throw Error('Invalid STUDIO_CONFIG: check configuration files, absolute database paths, OIDC, source bindings and explicit issuer/subject members'); }
}
export function configRealm(config: StandaloneConfig): string {
  return JSON.stringify({ authorityId: config.authorityId, origin: config.origin, projectId: config.project.id, issuer: config.oidc.issuer, clientId: config.oidc.clientId });
}
export function liveStandaloneConfig(file: string, initial: StandaloneConfig, workbenchFile?: string, floorsFile?: string, machineFile?: string, operationsFile?: string): () => StandaloneConfig {
  const stable = ({ apps: _apps, members: _members, bridge: _bridge, mattermost: _mattermost, nativeMissions: _nativeMissions, whiteboardCollaboration: _whiteboardCollaboration, whiteboardAgents: _whiteboardAgents, whiteboardMcp: _whiteboardMcp, floorManagement: _floorManagement, floorRuntime: _floorRuntime, floorSetup: _floorSetup, projects, workbench, ...rest }: StandaloneConfig) => JSON.stringify({
    ...rest,
    project: { id: rest.project.id, name: rest.project.name },
    projects: projects?.map(({ id, name, kind }) => ({ id, name, ...(kind ? {kind} : {}) })),
    workbench: workbench ? (({enabled:_enabled,workspaces:_workspaces,...connection})=>connection)(workbench) : undefined
  });
  const initialSettings = stable(initial);
  const read = reuseConfiguration(source => loadConfiguration(source, file, workbenchFile, floorsFile, machineFile, operationsFile),
    () => JSON.stringify([process.env.STUDIO_STORAGE_CONFIG, process.env.STUDIO_MONITORING_SYSTEMS, process.env.STUDIO_ARTIFACT_LIFECYCLE_TOKEN_FILES, process.env.STUDIO_REGISTRY_MANAGER_CONFIG, process.env.STUDIO_REGISTRY_BINDINGS_ONLY, process.env.STUDIO_REGISTRY_CONTRIBUTIONS_CONFIG]));
  let accepted: StandaloneConfig | undefined;
  return () => {
    const current = read();
    if (current !== accepted) {
      if (stable(current) !== initialSettings) throw Error('Studio configuration changed; restart required');
      accepted = current;
    }
    return current;
  };
}
export function liveMembers(file: string, initial: StandaloneConfig, workbenchFile?: string, floorsFile?: string, machineFile?: string, operationsFile?: string): () => StudioMember[] {
  const read = liveStandaloneConfig(file, initial, workbenchFile, floorsFile, machineFile, operationsFile); return () => read().members;
}
export function liveBridge(file: string, initial: StandaloneConfig, workbenchFile?: string, floorsFile?: string, machineFile?: string, operationsFile?: string): () => StandaloneBridgeConfig | undefined {
  const read = liveStandaloneConfig(file, initial, workbenchFile, floorsFile, machineFile, operationsFile); return () => read().bridge;
}

/** The original project remains the owner of legacy records and auth realm. */
export function configuredProjects(config: StandaloneConfig) {
  return [{ ...config.project, memberProfileIds: config.project.memberProfileIds ?? config.members.map(m => m.profileId), nativeMissions: config.nativeMissions, kind: undefined as 'company' | undefined }, ...(config.projects ?? [])];
}
export function projectConfig(config: StandaloneConfig, projectId: string): StandaloneConfig {
  const project = configuredProjects(config).find(p => p.id === projectId);
  if (!project) throw Error('Unknown Studio project');
  return { ...config, project: { id: project.id, name: project.name }, projects: undefined,
    members: config.members.filter(m => project.memberProfileIds.includes(m.profileId) && isCurrentStudioMember(m)), nativeMissions: project.nativeMissions };
}

/** Optional pilot expiry is enforced at request time, including existing sessions. */
export function isCurrentStudioMember(member: Pick<StudioMember, 'validUntil'>, now = Date.now()): boolean {
  return member.validUntil === undefined || Date.parse(member.validUntil) > now;
}
