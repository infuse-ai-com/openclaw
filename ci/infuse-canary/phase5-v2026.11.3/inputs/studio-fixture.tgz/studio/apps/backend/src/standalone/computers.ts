import { request as httpRequest } from 'node:http';
import type { IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';
import { resolveStudioComputer, resolveStudioCompanyComputer, type StudioComputerBinding, type StudioCompanyComputerBinding } from '@studio/server';
import type { FastifyInstance } from 'fastify';
import staticFiles from '@fastify/static';
import { protectedComputerRequest, type ProtectedWorkbenchPreview } from './workbench-protected.js';
export interface WorkbenchPreviewOptions {
  fixture: boolean;
  gatewayOrigin: string;
  serviceToken?: string;
  protectedAccess?: ProtectedWorkbenchPreview;
  clientRoot: string;
  readBindings?(): readonly StudioComputerBinding[];
}
export async function registerComputerPreview(app: FastifyInstance, options: WorkbenchPreviewOptions, origin: string,
  authenticate: (cookies: Record<string, string | undefined>) => { profileId: string; expiresAt: number },
  handledElsewhere: (url: string) => boolean = () => false,
  refreshSession: (cookies: Record<string, string | undefined>) => Promise<void> = async () => {}) {
  const gateway = new URL(options.gatewayOrigin);
  const local = options.fixture === true;
  if (gateway.protocol !== (options.protectedAccess ? 'https:' : 'http:') || gateway.pathname !== '/'
    || gateway.search || gateway.hash || gateway.username || gateway.password
    || (local && (gateway.hostname !== '127.0.0.1' || !['127.0.0.1','localhost'].includes(new URL(origin).hostname)))
    || (!local && (gateway.protocol !== 'https:' || !gateway.hostname.endsWith('.svc.cluster.local') || new URL(origin).protocol !== 'https:' || !options.protectedAccess))
    || (!options.protectedAccess && !/^[a-f0-9]{64}$/.test(options.serviceToken ?? '')) || (options.protectedAccess && options.serviceToken !== undefined)) throw Error('Computer adapter requires the exact configured protected gateway');
  const principal = (cookies: Record<string,string | undefined>) => {
    const current = authenticate(cookies);
    let binding: StudioComputerBinding | StudioCompanyComputerBinding;
    try {
      if(options.protectedAccess&&!options.protectedAccess.authorityAvailable())throw Error('Authority unavailable');
      binding = options.protectedAccess ? resolveStudioCompanyComputer(current.profileId,options.protectedAccess.readWorkspaces()) : resolveStudioComputer(current.profileId, options.readBindings?.() ?? []);
    } catch { throw Object.assign(Error('Computer access is unavailable for this profile'), { code:'FORBIDDEN', statusCode:403 }); }
    return { ...current, binding };
  };
  app.get('/api/workbench', async (request, reply) => {
    if (request.url !== '/api/workbench') return reply.code(400).send({ error: { code:'INVALID_INPUT',message:'The computer route has no caller-selected owner' } });
    const current = principal(request.cookies);
    return { environmentId: current.binding.environmentId, generation: current.binding.generation, websocketPath: '/api/workbench/stream', adapterVersion: 1, fixture: local };
  });
  await app.register(async scoped => {
    scoped.addHook('onRequest', async request => { principal(request.cookies); });
    await scoped.register(staticFiles, { root: options.clientRoot, prefix: '/api/workbench-client/', decorateReply: false });
  });
  let closing=false;
  const sockets = new Set<Duplex>(); const pending = new Set<ReturnType<typeof httpRequest>>();
  const upgrade = (request: IncomingMessage, socket: Duplex, head: Buffer) => { void (async () => {
    const reject = (status: number) => { socket.end(`HTTP/1.1 ${status} Rejected\r\nConnection: close\r\n\r\n`); };
    if (request.url !== '/api/workbench/stream') { if (handledElsewhere(request.url ?? '')) return; return reject(404); }
    if (request.headers.host !== new URL(origin).host || request.headers.origin !== origin) return reject(403);
    const key = request.headers['sec-websocket-key'];
    if (request.headers.upgrade?.toLowerCase() !== 'websocket' || request.headers['sec-websocket-version'] !== '13'
      || typeof key !== 'string' || !/^[A-Za-z0-9+/]{22}==$/.test(key)) return reject(400);
    const cookies = app.parseCookie(request.headers.cookie ?? '');
    let current: ReturnType<typeof principal>;
    try { await refreshSession(cookies); current = principal(cookies); } catch { return reject(401); }
    const stillAllowed = () => {
      try {
        const now = principal(cookies);
        return now.profileId === current.profileId && now.expiresAt > Date.now()
          && now.binding.environmentId === current.binding.environmentId && now.binding.generation === current.binding.generation
          && (!options.protectedAccess || ((now.binding as StudioCompanyComputerBinding).workspaceId === (current.binding as StudioCompanyComputerBinding).workspaceId && (now.binding as StudioCompanyComputerBinding).authorizationRevision === (current.binding as StudioCompanyComputerBinding).authorizationRevision));
      } catch { return false; }
    };
    const path = `/environments/${current.binding.environmentId}/generations/${current.binding.generation}/websockify`;
    let remote: Duplex | undefined;
    let protectedRequest: Awaited<ReturnType<typeof protectedComputerRequest>> | undefined;
    let upstream: ReturnType<typeof httpRequest>;
    let timer: ReturnType<typeof setInterval> | undefined;
    const close = () => { if(timer)clearInterval(timer); protectedRequest?.close(); if(upstream)pending.delete(upstream); sockets.delete(socket); upstream?.destroy(); remote?.destroy(); socket.destroy(); };
    if(options.protectedAccess){
      try { protectedRequest=await protectedComputerRequest(options.protectedAccess,gateway,current.binding as StudioCompanyComputerBinding,current.expiresAt,key,
        typeof request.headers['sec-websocket-protocol']==='string'?request.headers['sec-websocket-protocol']:undefined,()=>!closing&&!socket.destroyed&&stillAllowed(),close); }
      catch { return reject(503); }
      upstream=protectedRequest.upstream;
    }else upstream=httpRequest(new URL(path,gateway),{headers:{Connection:'Upgrade',Upgrade:'websocket','Sec-WebSocket-Key':key,'Sec-WebSocket-Version':'13',Authorization:`Bearer ${options.serviceToken}`,
      ...(request.headers['sec-websocket-protocol']?{'Sec-WebSocket-Protocol':request.headers['sec-websocket-protocol']}:{})},timeout:10000});
    pending.add(upstream);
    // Revalidate during handshake and streaming, including logout, membership,
    // rebinding and generation withdrawal. No cached browser authority grant.
    timer = setInterval(() => { if (!stillAllowed()) close(); }, 200); timer.unref();
    socket.once('close', () => { clearInterval(timer); pending.delete(upstream); sockets.delete(socket); close(); });
    socket.once('error', close); sockets.add(socket);
    upstream.once('upgrade', (response, peer, peerHead) => {
      pending.delete(upstream); remote=peer; upstream.setTimeout(0); peer.setTimeout(0);
      if (!stillAllowed()) return close();
      const headers = ['upgrade','connection','sec-websocket-accept','sec-websocket-protocol'].filter(h=>response.headers[h] !== undefined);
      socket.write(`HTTP/1.1 101 Switching Protocols\r\n${headers.map(h=>`${h}: ${response.headers[h]}`).join('\r\n')}\r\n\r\n`);
      if(peerHead.length)socket.write(peerHead); if(head.length)peer.write(head);
      peer.once('error',close); peer.once('close',close); socket.pipe(peer); peer.pipe(socket);
    });
    upstream.once('response', response => { response.resume(); protectedRequest?.close(); reject(response.statusCode === 401 ? 401 : 502); });
    upstream.once('timeout', close); upstream.once('error', () => { if(!remote) reject(502); else close(); }); if(closing||socket.destroyed||!stillAllowed())return close(); upstream.end();
  })().catch(() => socket.destroy()); };
  app.server.on('upgrade',upgrade);
  app.addHook('preClose', async () => { closing=true; app.server.off('upgrade',upgrade); for(const request of pending)request.destroy(); for(const socket of sockets)socket.destroy(); });
}
