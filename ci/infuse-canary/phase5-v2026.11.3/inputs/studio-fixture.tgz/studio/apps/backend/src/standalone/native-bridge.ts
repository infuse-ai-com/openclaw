import { createHash } from 'node:crypto';
import { NATIVE_MESSAGE_MAX_UNITS, missionIdentifier, mattermostId, parseNativeCommand, parseNativeHistoryQuery, parseNativeRecordQuery, parseNativeInboxQuery, type NativePaper, type BridgePrincipal, type NativeThread, type NativeMissionView, type NativeDecision, type NativeProvisionEffect, type NativeReply, type NativeAssignment } from '@studio/contracts';
import { MissionError, NativeAuthority, requireMission, type MissionStore, type NativeGateway, type NativeOperation, type NativeRouteScope } from '@studio/server';
import type { StandaloneConfig } from './config.js';
import type { NativeMissionsConfig } from './native-config.js';
import type { StudioAccessGuard } from '@studio/server';
import { nativeProjectRouting } from './native-project-routing.js';

type Obj = Record<string, unknown>;
function record(value: unknown, allowed: string[]): Obj {
  requireMission(!!value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).every(k => allowed.includes(k)), 'INVALID_INPUT', 'Invalid native bridge request');
  return value as Obj;
}
function text(value: unknown, max = 8192): string {
  requireMission(typeof value === 'string' && value.length > 0 && value.length <= max && !value.includes('\0'), 'INVALID_INPUT', 'Invalid text'); return value;
}
function id(value: unknown): string { try { return missionIdentifier(value); } catch { throw new MissionError('INVALID_INPUT', 'Invalid identifier'); } }
function mmId(value: unknown): string { try { return mattermostId(value); } catch { throw new MissionError('INVALID_INPUT', 'Invalid Mattermost identifier'); } }
function intakeTitle(content: string): string {
  // NativePaper titles allow 180 UTF-8 bytes, not 180 JavaScript characters.
  let title = ''; let bytes = 0;
  for (const character of content.replace(/\s+/g, ' ')) {
    const size = Buffer.byteLength(character);
    if (bytes + size > 180) break;
    title += character; bytes += size;
  }
  return title;
}

export class NativeBridgeService {
  readonly authority: NativeAuthority;
  constructor(private options: { store: MissionStore; config: StandaloneConfig; readConfig(): StandaloneConfig;
    executionEnabled(config: StandaloneConfig): boolean; requestMattermost?: (path: string, config: NativeMissionsConfig) => Promise<Obj> }) {
    this.authority = new NativeAuthority({ store: options.store, projectId: options.config.project.id,
      targets: () => options.readConfig().targets, executionEnabled: () => this.enabled(), validatePaper: paper => this.validatePaper(paper),
      lifecycleScope: () => this.lifecycleScope() });
  }
  forProject(projectId: string): NativeBridgeService {
    requireMission(projectId === this.options.config.project.id, 'FORBIDDEN', 'Project is not configured'); return this;
  }
  private validatePaper(paper: NativePaper) {
    const config = this.options.readConfig().nativeMissions;
    const coordinator = config?.routes.find(r => r.role === 'coordinator');
    requireMission(coordinator && coordinator.gatewayId === paper.coordinator.gatewayId && coordinator.agentId === paper.coordinator.agentId,
      'CONFIGURATION', 'Paper coordinator must match the configured native coordinator');
    for (const task of paper.tasks) {
      const route = config!.routes.find(r => r.role === task.role && r.role !== 'coordinator');
      requireMission(route && route.gatewayId === task.owner.gatewayId && route.agentId === task.owner.agentId,
        'CONFIGURATION', 'Task owner must match its configured specialist role route');
    }
  }
  enabled() {
    try { return this.enabledFrom(this.options.readConfig()); }
    catch { return false; }
  }
  private enabledFrom(config: StandaloneConfig) {
    try { return this.options.config.nativeMissions?.enabled === true && config.nativeMissions?.enabled === true && this.options.executionEnabled(config); }
    catch { return false; }
  }
  private scope(config: NativeMissionsConfig, current = this.options.readConfig()): NativeRouteScope {
    return { installationId: config.installationId, origin: config.origin, projectId: this.options.config.project.id, routes: config.routes,
      enrollments: current.bridge?.gateways.filter(g => g.enabled).map(g => ({ gatewayId: g.gatewayId, generation: g.generation, agentIds: g.agents })) ?? [] };
  }
  private lifecycleScope() {
    const config = this.options.readConfig().nativeMissions;
    return config?.lifecycleNotifications === true ? { ...this.scope(config), studioOrigin: this.options.config.origin } : undefined;
  }
  async comment(input: unknown, current: StudioAccessGuard) {
    const actor = current(); const v = record(input, ['commandId', 'missionId', 'threadId', 'text']);
    const config = this.options.readConfig().nativeMissions; requireMission(config, 'CONVERSATION_DISABLED', 'Native conversation routes are not configured');
    const view = await this.authority.read(id(v.missionId), actor, current);
    const thread = view.threads.find(t => t.id === id(v.threadId)); requireMission(thread, 'NOT_FOUND', 'Conversation thread not found');
    const member = this.options.readConfig().members.find(m => m.profileId === actor.profileId); requireMission(member, 'FORBIDDEN', 'Current project membership is required');
    return this.options.store.native({ kind: 'provision', operation: { kind: 'comment', commandId: id(v.commandId), thread,
      text: text(v.text, NATIVE_MESSAGE_MAX_UNITS), authorProfileId: actor.profileId, authorDisplayName: member.displayName ?? member.profileId, scope: this.scope(config) } }, () => {
      const live = current(); requireMission(live.profileId === actor.profileId && JSON.stringify(this.options.readConfig().nativeMissions) === JSON.stringify(config), 'AUTHORITY_REVOKED', 'Comment membership or routes changed');
    });
  }
  private async mm(path: string, config: NativeMissionsConfig): Promise<Obj> {
    if (this.options.requestMattermost) return this.options.requestMattermost(path, config);
    const token = process.env[config.tokenEnv]; requireMission(token, 'CONFIGURATION', 'Native Mattermost reader credential is unavailable');
    let response: Response;
    try { response = await fetch(`${config.origin}/api/v4${path}`, { headers: { Authorization: `Bearer ${token}` }, redirect: 'error', signal: AbortSignal.timeout(5000) }); }
    catch { throw new MissionError('CONVERSATION_OFFLINE', 'Mattermost identity could not be verified'); }
    requireMission(response.ok, 'CONVERSATION_SOURCE_INVALID', 'Mattermost source or current membership could not be verified');
    const content = await response.text(); requireMission(content.length < (path.includes('/posts?') ? 1024 * 1024 : 128 * 1024), 'CONVERSATION_SOURCE_INVALID', 'Mattermost returned an oversized record');
    try { return JSON.parse(content) as Obj; } catch { throw new MissionError('CONVERSATION_SOURCE_INVALID', 'Mattermost returned an invalid record'); }
  }
  async request(input: unknown, principal: BridgePrincipal, current: () => BridgePrincipal): Promise<unknown> {
    const base = input as Obj; requireMission(base?.version === 2 && typeof base.kind === 'string', 'INVALID_INPUT', 'Native bridge version 2 is required');
    const initialConfig = this.options.readConfig(), initial = initialConfig.nativeMissions;
    requireMission(initial && this.options.config.nativeMissions, 'BRIDGE_DISABLED', 'Native missions are not configured');
    const gateway: NativeGateway = { gatewayId: principal.gatewayId, enrollmentGeneration: principal.generation, agentIds: principal.agents };
    const guard = () => {
      const live = current(); requireMission(live.gatewayId === principal.gatewayId && live.generation === principal.generation
        && JSON.stringify(live.agents) === JSON.stringify(principal.agents), 'AUTHORITY_REVOKED', 'Gateway enrollment changed');
      const config = this.options.readConfig();
      requireMission(JSON.stringify(config.nativeMissions) === JSON.stringify(initial), 'AUTHORITY_REVOKED', 'Native project routes changed');
      return config;
    };
    guard();
    const executionGuard = () => { requireMission(this.enabledFrom(guard()), 'EXECUTION_DISABLED', 'Native execution is disabled'); };
    const run = (operation: NativeOperation, execute = false) => this.options.store.native(operation, execute ? executionGuard : guard);
    let value: unknown;
    if (base.kind === 'route-protected') {
      const v = record(base, ['version', 'kind', 'route', 'routeId']);
      const r = record(v.route, ['installationId', 'accountId', 'agentId', 'nativeBotUserId', 'channelId']);
      const route = initial.routes.find(route => route.gatewayId === gateway.gatewayId && gateway.agentIds.includes(route.agentId)
        && route.agentId === r.agentId && route.accountId === r.accountId && route.nativeBotUserId === r.nativeBotUserId);
      requireMission(route && r.installationId === initial.installationId && initial.routes.some(route => route.channelId === r.channelId), 'FORBIDDEN', 'Protected route is outside this project enrollment');
      requireMission(route.role === 'coordinator' || route.channelId === r.channelId, 'FORBIDDEN', 'Specialist account cannot protect another role channel');
      const [bot, channel, member] = await Promise.all([this.mm(`/users/${route.nativeBotUserId}`, initial),
        this.mm(`/channels/${mmId(r.channelId)}`, initial), this.mm(`/channels/${mmId(r.channelId)}/members/${route.nativeBotUserId}`, initial)]);
      requireMission(bot.id === route.nativeBotUserId && bot.is_bot === true && bot.username === route.nativeUsername && !bot.delete_at
        && !channel.delete_at && member.user_id === route.nativeBotUserId, 'CONVERSATION_SOURCE_INVALID', 'Native account identity or membership could not be verified');
      value = await run({ kind: 'provision', operation: { kind: 'protect', protection: { installationId: initial.installationId, accountId: route.accountId,
        agentId: route.agentId, nativeBotUserId: route.nativeBotUserId, channelId: mmId(r.channelId), routeId: text(v.routeId, 2048), gateway } } });
    } else if (['provision-next', 'inspect-provision', 'admit-provision', 'observe-provision', 'reconcile-provision'].includes(base.kind)) {
      const v = record(base, ['version', 'kind', ...(base.kind === 'provision-next' ? ['requestId', 'lifecycleVersion', 'taskMessageVersion'] : ['inspect-provision', 'admit-provision', 'reconcile-provision'].includes(base.kind) ? ['effectId'] : ['effectId', 'state', 'postId'])]);
      const scope = this.scope(initial, initialConfig);
      if (v.kind === 'provision-next') {
        requireMission(v.lifecycleVersion === undefined || v.lifecycleVersion === 1, 'INVALID_INPUT', 'Unknown lifecycle notification protocol');
        requireMission(v.taskMessageVersion === undefined || v.taskMessageVersion === 1, 'INVALID_INPUT', 'Unknown task message protocol');
        value = await run({ kind: 'provision', operation: { kind: 'next', requestId: id(v.requestId), gateway, scope,
          ...(v.taskMessageVersion === 1 ? { taskMessageVersion: 1 } : {}),
          ...(v.lifecycleVersion === 1 && initial.lifecycleNotifications ? { lifecycleVersion: 1 } : {}) } }, true);
      }
      else {
        const effectId = id(v.effectId);
        const effect = await this.options.store.native<NativeProvisionEffect>({ kind: 'provision', operation: { kind: 'inspect', effectId, gateway, scope } }, guard);
        if (v.kind === 'inspect-provision') value = effect;
        else if (v.kind === 'reconcile-provision') {
          requireMission(effect.state !== 'superseded', 'DISPATCH_CONFLICT', 'Superseded effects cannot be reconciled');
          if (effect.state === 'delivered') value = effect;
          else {
            // A bounded read can prove delivery, never prove absence or authorize a replay.
            const matches = new Set<string>();
            for (let page = 0; page < 4; page++) {
              const history = await this.mm(`/channels/${effect.channelId}/posts?page=${page}&per_page=50`, initial);
              requireMission(Array.isArray(history.order) && history.posts && typeof history.posts === 'object', 'CONVERSATION_SOURCE_INVALID', 'Invalid native post history');
              for (const post of Object.values(history.posts as Record<string, Obj>)) {
                if (post.channel_id === effect.channelId && post.user_id === effect.nativeBotUserId && post.message === effect.text
                  && (post.root_id || undefined) === effect.rootPostId && !post.delete_at) matches.add(mmId(post.id));
              }
              if (history.order.length < 50) break;
            }
            requireMission(matches.size <= 1, 'DISPATCH_CONFLICT', 'Multiple native posts match this immutable delivery; operator reconciliation is required');
            value = matches.size === 1 ? await run({ kind: 'provision', operation: { kind: 'observe', effectId, gateway, scope,
              state: 'delivered', postId: [...matches][0]! } }) : { state: 'uncertain', effectId };
          }
        } else if (v.kind === 'admit-provision') {
          if (effect.kind === 'lifecycle') requireMission(initial.lifecycleNotifications === true, 'EXECUTION_DISABLED', 'Lifecycle notifications are paused');
          if (effect.authorProfileId) requireMission(this.options.readConfig().members.some(m => m.profileId === effect.authorProfileId), 'FORBIDDEN', 'Comment author membership was revoked');
          if (effect.kind === 'lifecycle' || effect.kind === 'task-message') {
            const bot = await this.mm(`/users/${effect.nativeBotUserId}`, initial);
            const sender = initial.routes.find(r => r.accountId === effect.accountId && r.nativeBotUserId === effect.nativeBotUserId);
            requireMission(sender && bot.id === sender.nativeBotUserId && bot.is_bot === true && bot.username === sender.nativeUsername && !bot.delete_at,
              'CONVERSATION_SOURCE_INVALID', 'Lifecycle sender identity was revoked');
          }
          if (effect.taskMessage) {
            const recipient = await this.mm(`/users/${effect.taskMessage.recipientUserId}`, initial);
            requireMission(recipient.id === effect.taskMessage.recipientUserId && recipient.is_bot === true && !recipient.delete_at
              && recipient.username === effect.taskMessage.recipientUsername, 'CONVERSATION_SOURCE_INVALID', 'Task recipient native identity was revoked');
          }
          const route = initial.routes.find(r => r.channelId === effect.channelId)!;
          for (const userId of new Set([effect.nativeBotUserId, route.nativeBotUserId])) {
            const member = await this.mm(`/channels/${effect.channelId}/members/${userId}`, initial);
            requireMission(member.user_id === userId, 'CONVERSATION_SOURCE_INVALID', 'Native route membership was revoked');
          }
          value = await run({ kind: 'provision', operation: { kind: 'admit', effectId, gateway, scope } }, true);
        } else {
          requireMission(v.state === 'delivered' || v.state === 'uncertain', 'INVALID_INPUT', 'Unknown provisioning receipt state');
          if (v.state === 'delivered') {
            const post = await this.mm(`/posts/${mmId(v.postId)}`, initial);
            requireMission(post.id === v.postId && post.channel_id === effect.channelId && post.user_id === effect.nativeBotUserId
              && post.message === effect.text && (post.root_id || undefined) === effect.rootPostId && !post.delete_at,
              'CONVERSATION_SOURCE_INVALID', 'Native receipt does not match the committed effect');
          }
          value = await run({ kind: 'provision', operation: { kind: 'observe', effectId, gateway, scope, state: v.state, ...(v.postId ? { postId: mmId(v.postId) } : {}) } });
        }
      }
    } else if (base.kind === 'managed-message') {
      value = await this.message(base, gateway, initial, guard);
    } else if (base.kind === 'claim') {
      const v = record(base, ['version', 'kind', 'requestId', 'instructionVersion']);
      requireMission(v.instructionVersion === undefined || v.instructionVersion === 1, 'UNSUPPORTED_CAPABILITY', 'Supported instructionVersion is 1');
      value = await run({ kind: 'claim', projectId: this.options.config.project.id, requestId: id(v.requestId), gateway, executionEnabled: this.enabled(), requireNativeHandoff: true, ...(v.instructionVersion === 1 ? { instructionVersion: 1 } : {}) }, true);
    } else if (['bind-thread', 'bind-session', 'admit', 'observe', 'inspect-action', 'action-uncertain', 'observe-abort'].includes(base.kind)) {
      const fields = ['version', 'kind', 'actionId', 'leaseId'];
      const v = record(base, [...fields, ...({ 'bind-thread': ['thread'], 'bind-session': ['sessionId'], admit: ['instructionVersion'], observe: ['observation'], 'action-uncertain': ['phase', 'reason'], 'observe-abort': ['state'] }[base.kind] ?? [])]);
      const lease = { actionId: id(v.actionId), leaseId: text(v.leaseId, 256), gateway };
      if (v.kind === 'inspect-action') {
        const inspected = await run({ kind: 'inspect-action', ...lease }) as Obj;
        value = { ...inspected, abortRequested: inspected.abortRequested === true || !this.enabled() };
      }
      else if (v.kind === 'action-uncertain') value = await run({ kind: 'action-uncertain', ...lease, phase: text(v.phase, 30), reason: text(v.reason, 2048) });
      else if (v.kind === 'observe-abort') {
        requireMission(v.state === 'done' || v.state === 'uncertain', 'INVALID_INPUT', 'Unknown abort receipt'); value = await run({ kind: 'observe-abort', ...lease, state: v.state });
      }
      else if (v.kind === 'bind-session') value = await run({ kind: 'bind-session', ...lease, sessionId: id(v.sessionId) }, true);
      else if (v.kind === 'admit') value = await run({ kind: 'admit', ...lease, executionEnabled: this.enabled(), ...(v.instructionVersion === 1 ? { instructionVersion: 1 } : {}) }, true);
      else if (v.kind === 'observe') {
        const o = record(v.observation, ['state', 'runId', 'reason']);
        requireMission(['running', 'settled', 'failed'].includes(String(o.state)), 'INVALID_INPUT', 'Unknown runtime observation');
        value = await run({ kind: 'observe', ...lease, observation: { state: o.state as 'running' | 'settled' | 'failed', runId: id(o.runId), ...(o.reason ? { reason: text(o.reason, 2048) } : {}) }, lifecycleScope: this.lifecycleScope() });
      } else {
        const t = record(v.thread, ['installationId', 'channelId', 'rootPostId', 'origin', 'routeId', 'protected']);
        const route = initial.routes.find(r => r.gatewayId === gateway.gatewayId && gateway.agentIds.includes(r.agentId) && r.channelId === t.channelId);
        requireMission(route && t.installationId === initial.installationId && t.origin === initial.origin && t.protected === true, 'FORBIDDEN', 'Thread does not belong to the enrolled native route');
        const root = await this.mm(`/posts/${mmId(t.rootPostId)}`, initial);
        requireMission(root.id === t.rootPostId && root.channel_id === t.channelId && !root.root_id && !root.delete_at, 'CONVERSATION_SOURCE_INVALID', 'Native root is unavailable');
        value = await run({ kind: 'bind-thread', ...lease, thread: { installationId: initial.installationId, channelId: route.channelId,
          rootPostId: mmId(t.rootPostId), origin: initial.origin, routeId: text(t.routeId, 2048), protected: true } }, true);
      }
    } else {
      const fields: Record<string, string[]> = { context: ['history', 'record', 'routing', 'inbox'], command: ['command'], evidence: ['evidenceId'],
        'prepare-reply': ['replyId', 'text'], 'observe-reply': ['replyId', 'state', 'postId'], 'reconcile-reply': ['replyId'] };
      requireMission(base.kind in fields, 'INVALID_INPUT', 'Unknown native bridge operation');
      const v = record(base, ['version', 'kind', 'actionId', 'runId', ...fields[base.kind]!]);
      const scope = { actionId: id(v.actionId), runId: id(v.runId) };
      if (v.kind === 'context') {
        let history, record, inbox; try { requireMission([v.history, v.record, v.routing, v.inbox].filter(x => x !== undefined).length <= 1, 'INVALID_INPUT', 'Choose history, record, routing or inbox'); inbox = v.inbox === undefined ? undefined : parseNativeInboxQuery(v.inbox); history = v.history === undefined ? undefined : parseNativeHistoryQuery(v.history); record = v.record === undefined ? undefined : parseNativeRecordQuery(v.record); }
        catch (error) { throw new MissionError('INVALID_INPUT', (error as Error).message); }
        value = await this.options.store.nativeAgent({ kind: 'context', ...scope, ...(inbox ? { inbox } : {}), ...(history ? { history } : {}), ...(record ? { record } : {}) }, gateway, guard);
        if (!history && !record && !inbox) {
          guard();
          const projectRouting = nativeProjectRouting(this.options.readConfig(), v.routing);
          value = v.routing === undefined ? { ...value as Obj, projectRouting } : { projectRouting };
        }
      }
      else if (v.kind === 'command') {
        const context = await this.options.store.nativeAgent<NativeMissionView>({ kind: 'context', ...scope }, gateway, guard);
        const model = v.command as Obj;
        requireMission(model && typeof model === 'object' && !Array.isArray(model), 'INVALID_INPUT', 'Invalid mission command');
        requireMission((model.missionId === undefined || model.missionId === context.mission.id) && (model.contractVersion === undefined || model.contractVersion === 2), 'FORBIDDEN', 'Tool scope cannot override admitted mission');
        let command; try { command = parseNativeCommand({ ...model, missionId: context.mission.id, contractVersion: 2 }); } catch (e) { throw new MissionError('INVALID_INPUT', (e as Error).message); }
        const commandGuard = () => { executionGuard(); if (command.type === 'create' || command.type === 'shape') this.validatePaper(command.paper); };
        commandGuard();
        value = await this.options.store.nativeAgent({ kind: 'agent-command', ...scope, command,
          targets: this.options.readConfig().targets, executionEnabled: this.enabled(), lifecycleScope: this.lifecycleScope(), routeScope: this.scope(initial), instructionVersion: initial.instructionVersion }, gateway, commandGuard);
      } else if (v.kind === 'evidence') value = await this.options.store.nativeAgent({ kind: 'agent-evidence', ...scope, evidenceId: id(v.evidenceId) }, gateway, guard);
      else if (v.kind === 'prepare-reply') value = await this.options.store.nativeAgent({ kind: 'prepare-reply', ...scope, replyId: id(v.replyId), text: text(v.text, NATIVE_MESSAGE_MAX_UNITS) }, gateway, executionGuard);
      else {
        if (v.kind === 'reconcile-reply') {
          const receipt = await this.options.store.nativeAgent<{ reply: NativeReply; thread: NativeThread; assignment: NativeAssignment }>({ kind: 'inspect-reply', ...scope, replyId: id(v.replyId) }, gateway, guard);
          if (receipt.reply.state === 'delivered') value = receipt.reply;
          else {
            const route = initial.routes.find(r => r.gatewayId === gateway.gatewayId && r.agentId === receipt.assignment.agentId);
            requireMission(route, 'FORBIDDEN', 'Native reply account is no longer enrolled');
            const matches = new Set<string>();
            for (let page = 0; page < 4; page++) {
              const history = await this.mm(`/channels/${receipt.thread.channelId}/posts?page=${page}&per_page=50`, initial);
              requireMission(Array.isArray(history.order) && history.posts && typeof history.posts === 'object', 'CONVERSATION_SOURCE_INVALID', 'Invalid native post history');
              for (const post of Object.values(history.posts as Record<string, Obj>)) {
                if (post.channel_id === receipt.thread.channelId && post.root_id === receipt.thread.rootPostId && post.user_id === route.nativeBotUserId
                  && post.message === receipt.reply.deliveryText && !post.delete_at) matches.add(mmId(post.id));
              }
              if (history.order.length < 50) break;
            }
            requireMission(matches.size <= 1, 'DISPATCH_CONFLICT', 'Multiple native posts match this reply; operator reconciliation is required');
            value = matches.size === 1 ? await this.options.store.nativeAgent({ kind: 'observe-reply', ...scope, replyId: receipt.reply.id,
              state: 'delivered', postId: [...matches][0]! }, gateway, guard) : { ...receipt.reply, state: 'uncertain' };
          }
          if (value && ['context', 'evidence', 'command'].includes(base.kind)) {
      const result = value as Obj;
      const missionId = result.missionId ?? (result.mission as Obj | undefined)?.id ?? (result.evidence as Obj | undefined)?.missionId;
      if (typeof missionId === 'string') {
        const missionUrl = new URL(`/missions/v2/${encodeURIComponent(missionId)}`, this.options.config.origin);
        missionUrl.searchParams.set('project', this.options.config.project.id);
        value = { ...result, links: { mission: missionUrl.href, evidence: `${missionUrl.href}&section=evidence` } };
      }
    }
    guard(); return { version: 2, kind: base.kind, value };
        }
        requireMission(v.state === 'delivered' || v.state === 'uncertain', 'INVALID_INPUT', 'Unknown native reply state');
        if (v.state === 'delivered') {
          const receipt = await this.options.store.nativeAgent<{reply: NativeReply; thread: NativeThread; assignment: NativeAssignment}>({ kind: 'inspect-reply', ...scope, replyId: id(v.replyId) }, gateway, guard);
          const route = initial.routes.find(r => r.gatewayId === gateway.gatewayId && r.agentId === receipt.assignment.agentId);
          const post = await this.mm(`/posts/${mmId(v.postId)}`, initial);
          requireMission(route && post.id === v.postId && post.channel_id === receipt.thread.channelId && post.root_id === receipt.thread.rootPostId
            && post.user_id === route.nativeBotUserId && post.message === receipt.reply.deliveryText && !post.delete_at,
            'CONVERSATION_SOURCE_INVALID', 'Reply receipt does not match its admitted native author and thread');
        }
        value = await this.options.store.nativeAgent({ kind: 'observe-reply', ...scope, replyId: id(v.replyId), state: v.state,
          ...(v.postId ? { postId: mmId(v.postId) } : {}) }, gateway, guard);
      }
    }
    if (value && ['context', 'evidence', 'command'].includes(base.kind)) {
      const result = value as Obj;
      const missionId = result.missionId ?? (result.mission as Obj | undefined)?.id ?? (result.evidence as Obj | undefined)?.missionId;
      if (typeof missionId === 'string') {
        const missionUrl = new URL(`/missions/v2/${encodeURIComponent(missionId)}`, this.options.config.origin);
        missionUrl.searchParams.set('project', this.options.config.project.id);
        value = { ...result, links: { mission: missionUrl.href, evidence: `${missionUrl.href}&section=evidence` } };
      }
    }
    guard(); return { version: 2, kind: base.kind, value };
  }
  private async message(base: Obj, gateway: NativeGateway, config: NativeMissionsConfig, guard: () => void) {
    const v = record(base, ['version', 'kind', 'source', 'text', 'wasMentioned', 'props', 'self', 'postType', 'fileIds']);
    const s = record(v.source, ['installationId', 'accountId', 'channelId', 'rootPostId', 'postId', 'nativeBotUserId', 'senderUserId', 'revision', 'routeId']);
    const receiver = config.routes.find(r => r.gatewayId === gateway.gatewayId && gateway.agentIds.includes(r.agentId)
      && r.accountId === s.accountId && r.nativeBotUserId === s.nativeBotUserId);
    const coordination = config.routes.find(r => r.role === 'coordinator')!;
    requireMission(receiver && s.installationId === config.installationId && config.routes.some(r => r.channelId === s.channelId), 'FORBIDDEN', 'Message came from an unenrolled native route');
    requireMission(receiver.role === 'coordinator' || receiver.channelId === s.channelId, 'FORBIDDEN', 'Specialist intake belongs to its configured role channel');
    const sourcePostId = mmId(s.postId); const channelId = mmId(s.channelId); const sender = mmId(s.senderUserId);
    const [post, channel, member, user, receiverMembership] = await Promise.all([
      this.mm(`/posts/${sourcePostId}`, config), this.mm(`/channels/${channelId}`, config),
      this.mm(`/channels/${channelId}/members/${sender}`, config), this.mm(`/users/${sender}`, config),
      this.mm(`/channels/${channelId}/members/${receiver.nativeBotUserId}`, config),
    ]);
    requireMission(post.id === sourcePostId && post.channel_id === channelId && post.user_id === sender && post.message === v.text
      && String(post.update_at || post.create_at) === String(s.revision) && !post.delete_at && !channel.delete_at && !user.delete_at
      && user.id === sender && member.user_id === sender && receiverMembership.user_id === receiver.nativeBotUserId,
      'CONVERSATION_SOURCE_INVALID', 'Native message or membership changed');
    if (post.type || (Array.isArray(post.file_ids) && post.file_ids.length)) return { disposition: 'blocked', reason: 'Only native text posts are admitted' };
    const senderAgent = config.routes.find(r => r.nativeBotUserId === sender);
    const mapping = config.members.find(m => m.userId === sender);
    const liveHuman = mapping && this.options.readConfig().members.find(m => m.profileId === mapping.profileId);
    // Reject the post, not its authenticated Gateway. A shared channel may
    // contain unenrolled observers; their posts must not poison the intake queue.
    requireMission(senderAgent ? user.is_bot === true && user.username === senderAgent.nativeUsername : liveHuman && user.is_bot !== true,
      'CONVERSATION_SOURCE_INVALID', 'Native author is not a currently enrolled human or agent');
    const actor = liveHuman ? { kind: 'human' as const, profileId: liveHuman.profileId, approver: liveHuman.approver } : undefined;
    const approvalGuard = () => {
      guard(); if (actor) {
        const member = this.options.readConfig().members.find(m => m.profileId === actor.profileId);
        requireMission(member && member.approver === actor.approver, 'AUTHORITY_REVOKED', 'Human membership or role changed');
      }
    };
    const rootPostId = post.root_id ? mmId(post.root_id) : sourcePostId;
    requireMission(!s.rootPostId || s.rootPostId === rootPostId, 'CONVERSATION_SOURCE_INVALID', 'Message thread changed');
    const threads = await this.options.store.native<NativeThread[]>({ kind: 'threads' }, guard);
    let thread = threads.find(t => t.installationId === config.installationId && t.channelId === channelId && t.rootPostId === rootPostId);
    if (thread) {
      const view = await this.options.store.native<NativeMissionView>({ kind: 'read', missionId: thread.missionId }, guard);
      requireMission(view.mission.projectId === this.options.config.project.id, 'FORBIDDEN', 'Thread belongs to another project');
    }
    const content = text(v.text);
    // Deterministic controls reference a prepared decision. A free-form yes is conversation only.
    const decision = /^!studio (approve|hold|resume|cancel|accept) ([A-Za-z0-9_-]+)$/u.exec(content.trim());
    if (decision && actor && thread) {
      const d = await this.options.store.native<NativeDecision>({ kind: 'decision', decisionId: id(decision[2]) }, approvalGuard);
      requireMission(d.missionId === thread.missionId && d.action === decision[1], 'VERSION_CONFLICT', 'Decision reference belongs to a different action or mission');
      await this.authority.decide({ decisionId: d.id }, actor, () => { approvalGuard(); return actor; }); return { disposition: 'accepted', decisionId: d.id };
    }
    const prepare = /^!studio prepare (approve|hold|resume|cancel|accept)$/u.exec(content.trim());
    if (prepare && actor && thread) {
      const d = await this.options.store.native<NativeDecision>({ kind: 'prepare-native', requestId: `mm-${sourcePostId}-${text(s.revision, 100)}`,
        thread, action: prepare[1] as NativeDecision['action'], actor, scope: this.scope(config) }, approvalGuard);
      return { disposition: 'accepted', decision: d, instruction: `!studio ${d.action} ${d.id}` };
    }
    const mentionText = content.replace(/```[\s\S]*?```/g, '').replace(/`[^`]*`/g, '');
    const addressed = [...new Set(config.routes.filter(r => new RegExp(`(^|[^a-zA-Z0-9_])@${r.nativeUsername.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![a-zA-Z0-9_.-])`, 'u').test(mentionText)).map(r => r.agentId))];
    // Emon listens to coordination conversations without a mention. Specialist
    // threads still require explicit addressing; committed bot notices are filtered below.
    if (channelId === coordination.channelId && !addressed.includes(coordination.agentId)) addressed.push(coordination.agentId);
    const fingerprint = createHash('sha256').update(`${config.installationId}:${sourcePostId}`).digest('hex');
    if (!thread) {
      if (!actor || post.root_id || channelId !== coordination.channelId || !this.enabled()) return { disposition: 'context' };
      const mission = await this.options.store.native<NativeMissionView>({ kind: 'intake', actor, targets: this.options.readConfig().targets,
        command: { contractVersion: 2, commandId: `intake-${fingerprint}`, missionId: `mm-${fingerprint}`, type: 'create', projectId: this.options.config.project.id,
          paper: { title: intakeTitle(content), objective: content, acceptance: 'Shape independently verifiable acceptance criteria with the requester before approval.',
            coordinator: { gatewayId: coordination.gatewayId, agentId: coordination.agentId }, permissions: [], tasks: [], humanAcceptance: false } },
        thread: { installationId: config.installationId, origin: config.origin, channelId, rootPostId, protected: true, routeId: text(s.routeId, 2048) } }, approvalGuard);
      thread = mission.threads[0]!;
    }
    const effect = await this.options.store.native<NativeProvisionEffect | null>({ kind: 'provision', operation: { kind: 'recognize', installationId: config.installationId,
      channelId, rootPostId, senderUserId: sender, text: content } }, guard);
    const humanComment = effect?.kind === 'comment' && effect.authorProfileId ? this.options.readConfig().members.find(m => m.profileId === effect.authorProfileId) : undefined;
    const eventGuard = () => {
      approvalGuard();
      if (humanComment) requireMission(this.options.readConfig().members.some(m => m.profileId === humanComment.profileId),
        'AUTHORITY_REVOKED', 'Studio comment author membership changed');
    };
    await this.options.store.native({ kind: 'event', missionId: thread.missionId, event: { threadId: thread.id, sourceId: sourcePostId, revision: text(s.revision, 100), text: content,
      author: humanComment ? { kind: 'human', id: humanComment.profileId, displayName: humanComment.displayName ?? humanComment.profileId } : senderAgent ? { kind: 'agent', id: senderAgent.agentId, displayName: senderAgent.nativeUsername }
        : { kind: 'human', id: actor!.profileId, displayName: liveHuman!.displayName ?? liveHuman!.profileId },
      addressedAgentIds: (effect && !humanComment) || thread.missionId === `mm-${fingerprint}` ? [] : addressed } }, eventGuard);
    return { disposition: addressed.length ? 'accepted' : 'context', missionId: thread.missionId };
  }
}
