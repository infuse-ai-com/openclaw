import { checkWorkerRuntime } from './consumers/system.js';
console.log(JSON.stringify({worker:'studio',event:'startup',health:checkWorkerRuntime(),message:'No durable queue configured; no business jobs are consumed.'}));
if (!process.argv.includes('--once')) {
  // Keep the worker entry point alive until a durable transport is selected.
  const timer = setInterval(() => console.log(JSON.stringify({worker:'studio',event:'heartbeat',health:checkWorkerRuntime()})), 30000);
  for (const signal of ['SIGINT','SIGTERM'] as const) process.once(signal, () => clearInterval(timer));
}
