# Scheduled work

Add schedules after a durable job transport and execution contract are selected. Schedules enqueue named jobs; shared handlers live in `@studio/server`. Define idempotency, retries and shutdown behavior alongside each real consumer. There are no scheduled business jobs yet.
