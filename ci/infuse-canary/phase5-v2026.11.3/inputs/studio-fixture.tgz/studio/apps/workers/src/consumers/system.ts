import { executeSystemJob } from '@studio/server';
export function checkWorkerRuntime() { return executeSystemJob({kind:'system.health'}); }
