# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

React, TypeScript, Vite, React Router and TanStack Query for the standalone
workspace, with INFUSE component CSS and the existing Three.js office. Radix is available
for future composite controls.
Fastify and OIDC adapt authenticated requests to the shared Studio authority;
the existing SQLite worker owns mission state. See the
[approved stack](docs/architecture/technology-stack.md).

The earlier native OpenClaw UI remains compatible. Production uses the
standalone workspace and native Mattermost integration on enrolled Gateways.
The broader playable company mockup remains JavaScript with local simulated
state. The [roadmap](docs/ROADMAP.md) separates shipped features, activation
work and later product intent.

## Users

Studio initially serves 2–5 Infuse AI partners building the company and their
projects with one shared Infuse agentic team. Fito remains the initial dogfood
user and product owner. Kapiteky advises on company direction and coherence;
Emon coordinates shared execution with the same specialists across projects.

Partners can work directly with that team. Personal agents for thinking and
organizing intent are optional. Managed personal Linux desktops are a later
work environment; private Studio workspaces are not an initial requirement.

## Product Purpose

Infuse AI Studio makes shared agents, knowledge, skills, working methods and
infrastructure useful to partners building the company and delivering projects.
It accepts ideas and tasks, supports exploration and prototypes, and provides
bounded missions for work that needs coordinated execution and verification.
The spatial office gives the shared workplace presence and personality.

The [product vision](docs/PRODUCT_VISION.md) defines the partner journey,
knowledge and learning loop, Lab, scope and unresolved choices. The next partner
validation must demonstrate a useful outcome and reuse of company capabilities;
its exact scenario remains to be selected.

## Positioning

Studio feels like leading a small company floor, not administering an agent
dashboard or submitting prompts to a chatbot. Its spatial controls expose real
mission, task, artifact, blocker, approval, and evidence concepts while keeping
their owning systems authoritative.

## Operating Context

The durable hierarchy is:

```text
company -> initiative / BET / project (floor) -> mission -> task / loop -> artifact / evidence
```

Studio is the human experience over the Infuse AI/OpenClaw harness. This Studio
repository owns the durable mission authority, with standalone service and native
OpenClaw plugin adapters. A deployment has one store owner.
Backoffice is not the lifecycle authority. Repositories and governed
knowledge systems remain canonical for code, Markdown, decisions, and source
material. Mattermost is the primary communication channel in the intended
experience. [Backoffice consolidation](docs/plans/active/025-backoffice-consolidation/proposal.md)
now targets its full retirement, with launcher, Agents telemetry, contributions,
monitoring and artifact lifecycle/Registry ownership moving into Studio. Scheduling/
portfolio ports are deprecated for separate from-scratch replacements; the full
catalog is deferred. Other bounded external systems retain their own authority.

The [native operating contract](docs/architecture/native-missions.md)
uses named agents, project role channels and independently owned tasks. Its
production rollout, multi-project support and source-access repair are complete.
The Finaxis EUR/USD mission delivered a reviewed PR and autonomous closeout;
merge and deployment were outside its scope. Scoped proactive task instructions
and subsequent reliability repairs have bounded live proof in the roadmap.

The swarm keeps one persistent company agent per Gateway/pod, with shared release
management. Studio currently relies on each runtime's configured model accounts.
A mission default account with per-agent session overrides is planned, subject
to provider support and enforced spending boundaries; selecting an account must
not change agent identity or project permissions. See the
[account-selection contract gap](docs/architecture/native-missions.md#model-account-selection-planned).

## Capabilities and Constraints

These combine implemented mission behavior with target product capabilities.
Use the roadmap for delivery status; the mockup alone does not prove a feature.

- Work with one shared company team, with optional personal-agent participation.
- Accept ideas, links and tasks without requiring a mission for every interaction.
- Ask only the next useful shaping question when coordinated work is needed.
- Connect backlogs, roadmaps, a knowledge library and prototype exploration.
- Make reviewed skills, role hats, templates and runbooks reusable by partners.
- Keep a canonical mission paper visible as answers arrive.
- Record outcome, sources, scope, non-goals, acceptance evidence, approval
  boundaries, complexity, and exact next action.
- Explain recommended agents, skills, tools, models, and human operators.
- Explain which authorized account funds execution once session account binding
  is supported; personal desktops and a universal model gateway are not prerequisites.
- Keep persistent agent identity separate from mission-scoped capabilities.
- Represent controlled launch and execution honestly; distinguish live Studio
  receipts from the mockup's simulated state.
- Organize artifacts by mission and expose source revision, projection time,
  generator, review state, and source drift.
- Turn feedback into a source proposal or explicit follow-up.
- Close only with visible resolution evidence.
- Emon can close verified work within approved mission authority without
  mandatory final human acceptance; explicit human gates remain in force.
- Specialists can clarify and continue in the same active task/thread when
  scope, acceptance criteria and permissions stay unchanged.
- Reuse the existing Three.js office. The pinned OpenClaw fork carries the
  required-owner routing contract; Studio retains sole mission authority.
  External users, billing, marketplace and multi-company tenancy remain later
  scope. Narrow screens retain mission access.

## Brand Commitments

The product is **Studio by INFUSE**. It follows the approved INFUSE masterbrand:
dark-first, Foundry Black, INFUSE Orange as signal rather than decoration, IBM
Plex, precise modular geometry, direct evidence-led voice, and
construction-to-resolution motion. Approved logo artwork remains unmodified.

Product promise:

> Shape the mission. Assemble the squad. Run the company.

The approved visual rule is **Built, not decorated.** Pixel/spatial character
may make the operating floor feel alive, but the office must remain functional
and inspectable rather than decorative game UI.

## Evidence on Hand

- Approved product direction: `docs/PRODUCT_VISION.md`.
- Historical first-slice scope and acceptance: `docs/PROJECT_BRIEF.md`.
- Target operating journey: `docs/END_TO_END_USER_FLOW.md`.
- Current native lifecycle: `docs/architecture/native-missions.md`.
- Approved architecture decisions: `docs/DECISIONS.md`.
- Current milestones: `docs/ROADMAP.md`; active delivery plans: `docs/plans/README.md`.
- Selected spatial and interaction direction: `DESIGN.md`.
- Approved INFUSE artwork and brand direction live in the separate
  `infuse-ai-brand` repository and are consumed without modification.
- The [live UI proof](research/mission-harness/ui-proof/README.md) records an actual
  native browser mission journey across two disposable OpenClaw Gateways, using
  synthetic identities and a deterministic local model.
- Production real-model and Mac/Tailscale pilots are linked from the roadmap,
  with operator assistance recorded. Broad user research, independent code
  delivery and product-owner experience acceptance are not implied by those pilots.

## Product Principles

1. Human responsibility stays human.
2. Shape the mission before creating execution noise.
3. Complexity determines process weight.
4. Spatial state must map to inspectable work.
5. Canonical truth remains with the system that owns it.

## Accessibility & Inclusion

The prototype uses semantic controls, visible keyboard focus, legible contrast,
reduced-motion support, and desktop-first responsive behavior. Color, motion,
and spatial position are never the only carriers of state.
